## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Publik。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5补丁暗影牧师指南。在这里，你将学习如何在团队副本和大秘境中扮演暗影牧师：从入门到最大化你的伤害输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

暗影大秘境资源

[全新！顶级暗影天赋构建](<https://raider.io/specs/shadow-priest/talents>)

[顶尖暗影大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/priest/shadow>)

[暗影大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=priest--shadow>)

[热门暗影队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=priest--shadow>)

1.

### 暗影牧师概述

在至暗之夜中，暗影牧师延续了积攒-消耗的设计，同时还拥有一些有趣的持续伤害和范围伤害机制。你可以使用两种不同的英雄天赋，它们会显著改变你的核心玩法： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官专注于通过[[spell:228260]]和[[spell:120644]]在冷却窗口内打出持续伤害，而
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者则专注于通过[[spell:450405]]施法来积攒[[spell:447444]]以打出爆发伤害。两种英雄天赋各有千秋，根据不同的战斗场景各有优劣。

[观看原文视频](<https://www.youtube.com/embed/2OS9e2aMAlw>)

强大的持续伤害与更优的分散压制能力

暗影牧师在至暗之夜第2赛季中已成为一个强大的持续伤害专精，核心在于保持持续伤害效果的覆盖率以及把握好冷却窗口的时机。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官提供可延长、可预测的窗口以打出高额持续输出，而
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者则在积攒[[spell:447444]]时提供一定的爆发和顺劈伤害能力。

合理的天赋选择能让你在可靠的持久战和更强的分散顺劈场景之间灵活切换。

优秀的团队副本选择

在至暗之夜团队副本中，暗影在拥有较长稳定阶段、持续伤害效果和协调冷却对齐至关重要的战斗中表现出色。能够允许持续[[spell:228260]]窗口或不间断持续伤害覆盖的战斗会极大利好暗影。

在快速击杀、以爆发为主的战斗中，暗影在伤害榜上的排名会更接近中游，但它仍然是开荒时一个稳妥、灵活的选择，尤其是在分散顺劈的战斗环境中。

拥有出色分散伤害的强力大秘境选择

暗影是至暗之夜大秘境中的强力选择。在你能维持持续伤害效果时，它能提供出色的单体伤害和更强的多目标分散伤害。

高机动性路线和大量小怪包仍会惩罚暗影有限的移动能力。你的价值往往来自功能性：[[spell:10060]]、[[spell:15487]]以及通过[[spell:15286]]实现的可控续航，因此团队协作和拉怪规划至关重要。

高功能性

暗影的功能性是将其带入至暗之夜的重要原因。可靠的冷却辅助如[[spell:10060]]、通过[[spell:15487]]/[[spell:9484]]进行的群体控制，以及来自[[spell:15286]]的团队续航，都使暗影的价值远超纯粹的伤害输出。

这些工具使暗影在团队副本和地下城环境中都保持实用，即使数值调整下滑也是如此。

耐久性

在至暗之夜中，生存能力非常强，这得益于内置的续航和防御选项。[[spell:335467]]提供的生命偷取、被动治疗节点以及[[spell:47585]]提供了可靠的个人生存能力。

增强瞬发治疗和伤害减免的天赋与主动型打法相辅相成；使用得当的话，暗影可以轻松应对大多数团队副本机制和大秘境的紧急爆发伤害。

机动性有限

机动性是暗影在至暗之夜中最薄弱的领域。该专精缺乏内置的位移或突进能力，因此高移动战和大秘境机制可能会很棘手。你可以通过[[spell:64129]]、天赋选择和外部移动工具来缓解这一点，但核心限制依然存在，请提前规划站位并利用冷却窗口来尽量减少移动带来的损失。

1.

### 暗影牧师在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

本次补丁中暗影牧师没有任何改动。本次补丁提供了2项新的终局内容，一个新团队副本和新的
[地下堡](<https://www.icy-veins.com/wow/delves-guide>) 内容。请务必查看关于新的基斯希克斯团队副本首领的信息，以及全新的精彩迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 在至暗之夜中继续第二赛季的征程，新的基斯希克斯的解放团队副本和金多'詹迷宫巨型地下堡同步上线，同时还有追赶装备和升阶物品等级的获取途径。基斯希克斯团队副本还新增了装备，包括一件饰品、一个戒指和一件腿部装备。从10月20日开始，可以使用[[item:280562]]来升级武器、项链和饰品。请访问我们的补丁中心，全面了解补丁12.1.5中的新内容。

2.3.

#### 职业改动

遗憾的是，补丁12.1.5本身并没有对暗影牧师做出任何改动。我们的天赋、输出循环、装备和附魔指南已针对该补丁进行了更新。你可以点击下方的下拉菜单，查看上一个12.1补丁中暗影牧师的改动列表。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_deathmark.jpg>) 点击查看上赛季第二赛季的改动
[乌拉特克之诅咒 补丁说明](<https://us.forums.blizzard.com/en/wow/t/2317811/1>)

**暗影 牧师**

<em>开发者说明：对于乌拉泰克的诅咒中的暗影专精，我们希望改善[[spell:228260]]的玩法，并新增一种多目标伤害来源，以降低该专精在范围伤害场景中对[[spell:199484]]的依赖。针对虚空形态，我们将[[spell:1240401]]改为使用次数有限的技能，在虚空形态期间只能使用固定次数；这既能为技能循环留出更多空间，也让你有机会在最有利的时机使用它。我们还调整了虚空形态的配套天赋，使其效果更加明显，以契合我们的设计目标。</em>

- 新天赋：[[spell:1231479]] - 飘向你主要目标的[[spell:341491]]会爆炸，对8码范围内的所有敌人造成暗影伤害。超过5个目标时伤害降低。
- [[spell:341240]]已被重新设计 - [[spell:228260]]使你的法术伤害额外提高5%，并提供2次额外的[[spell:1240401]]使用次数。
- [[spell:341240]]已被重新设计 - [[spell:335467]]在[[spell:228260]]期间使你的急速提高2%，并使其持续时间延长1.5秒，最多叠加5次。当虚空形态结束时，急速效果会残留并在10秒内逐渐衰减。
- [[spell:228260]]现在提供3次[[spell:1240401]]的使用次数，而不是虚空齐射在虚空形态期间拥有冷却时间。
- [[spell:17]]吸收量提高25%。
- 幻影威胁已被移除。
- 英雄天赋
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官
    
    
    
    
    - [[spell:1272320]]已被重新设计 - [[spell:1240401]]伤害提高15%，且在[[spell:228260]]期间施放的[[spell:335467]]会对你的目标释放一次[[spell:1240401]]。
    - [[spell:453845]]已略微重新设计 - 创建一个[[spell:120644]]会使你的法术伤害提高2%，持续10秒，最多叠加4次。

:::

### 至暗之夜改动概述

2.4.

#### 暗影牧师的至暗之夜总结

[观看原文视频](<https://www.youtube.com/embed/c_fDQWyqhwM>)

2.5.

#### 巅峰天赋

一旦你开始在至暗之夜中升级，你将开始获得专精树中新的顶峰天赋。这些点数独立存在于专精树上，你最多可以投入4点。

你必须按顺序投入这些点数，而最后一个点数是价值最高的节点。

- [[spell:1264096]]
- [[spell:1264104]]（2点）
- [[spell:1264107]]

这些天赋不仅仅是用额外的力量来为天赋树收尾，它们还积极地重塑了我们构建其余天赋的方式。虽然它们的基础功能可能很直接，但它们的深远影响才是真正的游戏风格转变所在。

最明显的效果之一是它们强烈激励我们投入能够增强[[spell:341491]]的天赋。由于这种协同效应，我们被强烈鼓励围绕最大化[[spell:341491]]的生成和伤害来构建，这反过来又鼓励我们选择更多支持这种玩法风格的天赋。

随着所有顶峰天赋的完整力量，你还被引入了新的游戏循环，鼓励偶像触发以触发更多[[spell:341491]]。这成为至暗之夜中该专精的核心游戏循环之一，你希望尽可能多地生成偶像触发以召唤更多[[spell:341491]]。

2.6.

#### 改动总结

由于改动量较大，我将其分成了几个部分，以便更容易理解本补丁中暗影牧师有何不同。请注意，除了这些改动之外，我们技能组合中的法术整体数值也进行了许多调整。

- 我们的核心 **暗影 牧师** 法术进行了几项改动。
  
  
  
  
  - 黑暗升华已被移除，现在[[spell:228260]]是我们主要的冷却技能。它不再提供虚空箭的使用权限，而是让你可以使用[[spell:1240401]]，冷却时间为15秒并受急速缩减。它不会刷新我们的持续伤害效果。
  - [[spell:34433]]、[[spell:200174]]和[[spell:451234]]现在都是被动法术。
  - [[spell:1279355]]是一个新天赋，让我们在AoE中获得持续的持续伤害效果延长。
  - 噬灵瘟疫已更名为[[spell:335467]]。
  - 暗影崩溃已被重做为[[spell:1227280]]。
  - [[spell:1279350]]是一个新的抉择节点，与[[spell:238558]]相对，它带回了持续伤害效果管理玩法，在低目标数量场景中能带来巨大收益。
  - [[spell:375888]]现在提供一次[[spell:8092]]的临时充能，而不是仅仅重置一次充能。
  - [[spell:341491]]不再由[[spell:8092]]触发。
- 我们的 **英雄天赋** 进行了几项基础更新。
  
  
  
  
  2.7.
  
  
  
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官
  
  
  
  
  - [[spell:120644]]现在专属于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官.
  - [[spell:391399]]触发现在专属于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官，且仅由[[spell:120644]]触发。
  - [[spell:453844]]已被移除。
  - 新天赋：[[spell:1247178]] - 提高[[spell:341491]]的伤害。
  - 新天赋：[[spell:1272308]] - [[spell:453109]]持续时间延长5秒（相当于额外提供一次[[spell:120644]]）。
  - 新天赋：[[spell:1272326]] - [[spell:32379]]伤害提高，冷却时间缩短。
  - 新天赋：[[spell:1272320]] - [[spell:1240401]]伤害提高，冷却时间缩短。
  - [[spell:453917]]现在在[[spell:228260]]期间使伤害提高5%（原为20%）。
  
  
  
  
  2.8.
  
  
  
  
  ### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者
  
  
  
  
  - [[spell:263165]]现在专属于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者.
  - 新天赋：[[spell:1266883]] - [[spell:263165]]伤害提高。
  - 新天赋：[[spell:1266845]] - [[spell:589]]和[[spell:447444]]更频繁地造成伤害。
  - 新天赋：[[spell:1266856]] - [[spell:449880]]在[[spell:447444]]结束后会短暂持续一段时间。
  - 暗影之深现在是专精树中的[[spell:34433]]天赋。这意味着我们总是会获得其新被动版本的[[spell:451234]]。
  - [[spell:450138]]现在提供一次[[spell:375888]]的充能，而不是[[spell:373202]]。
- 基本保持不变，我们对 **功能性法术**.
  
  
  
  
  - [[spell:15487]]、[[spell:47585]]和[[spell:15286]]都是暗影牧师的基础法术。
  - [[spell:1250691]] - 它不再是一个独立的主动技能，而是在[[spell:8122]]减益效果结束时定身敌人。
  - 束缚亡灵现在是[[spell:9484]]，并且还可以额外对畸变体使用。
- 以下是暗影牧师的一些其他值得注意的改动。
  
  
  
  
  - [[spell:8092]]现在位于职业树中，[[spell:32379]]不再默认获得。[[spell:34433]]也不再默认获得，而是作为触发效果添加到了专精树中。
  - [[spell:8122]]、[[spell:19236]]和[[spell:586]]已移入职业树（原本为基础技能）。
  - 虚空变换已被移除。
  - [[spell:321291]]现在是专精树中与[[spell:392507]]相对的抉择节点。
  - 心灵惊骇已被移除。

1.

### 暗影牧师玩法基础

暗影牧师的玩法结合了其他专精中使用的基本积攒-消耗理念，同时融入了作为主动型持续伤害职业的特点，拥有大量冷却技能可以使用。输出循环的基础包括尽可能延长冷却技能的覆盖时间，同时确保在尽可能多的活跃目标上保持所有三个持续伤害效果，尤其是[[spell:335467]]。

暗影牧师可以分解为以下三个核心原则，以帮助更好地理解该专精的骨干。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) **管理你的疯狂值**
  
  
  
  
  暗影的资源是疯狂值，用于施放[[spell:335467]]。它会随着你用法术造成伤害而积累，上限为100，因此避免浪费。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_unholyfrenzy.jpg>) **施放冷却技能**
  
  
  
  
  暗影有很多法术可以在任意时刻施放。刚开始时，你的目标是确保没有任何技能不必要地处于冷却状态。这主要包括像[[spell:8092]]和[[spell:1227280]]这样的法术。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowwordpain.jpg>) **保持减益效果激活**
  
  
  
  
  作为一名暗影牧师，当你拥有激活的持续伤害效果（DoT）时，你的所有法术都会获得伤害加成。始终在你的目标身上保持[[spell:589]]和[[spell:34914]]。

1.

### 如何为暗影牧师配装

虽然我们始终建议你自己进行模拟以获得理想结果，但我们确实提供了专门的暗影配装页面。我们目前涵盖了第二赛季装备的推荐，以便在至暗之夜终局内容发布时有一个良好的开端。一旦你获得了一些装备，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新虚空编织者团队副本配装。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年9月1日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 默认战斗药水更新及注意事项。
- **2026年9月1日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 在团队副本配装中添加乌拉特克变体。
- **2026年8月25日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为虚空编织者添加高层大秘境配装变体。
- **2026年8月25日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 在团队副本部分为迷失的探险者添加3目标配装。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在猎人仪式石削弱后更新制造建议。
- **2026 年 8 月 17 日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 按天赋配装更新单体伤害分解。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品排名以反映即将到来的数值调整。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为制造和额外拾取添加更多直接建议。
- **2026年8月11日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 简化戒指附魔说明。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为第二赛季中发生变化的几个部分添加说明。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为所有配装添加无套装变体。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新装备列表，添加更多关于催化剂来源和额外拾取指南的信息。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在执政官大秘境配装中重新添加萦绕暗影。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新围绕虚空齐射和暗影言术：癫使用的输出循环。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 在执政官大秘境配装中重新添加萦绕暗影。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对第二赛季和补丁12.1进行更新。
- **2026年8月10日（本页）：** 针对第二赛季和补丁12.1进行更新。
- **2026年8月3日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 将执政官和虚空编织者的饰品排名合并为一个梯队列表，并将暗月马戏团饰品上限设为C级。
- **2026年8月3日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为第二赛季效用网格更新循环切换和地下城效用提示。
- **2026年6月22日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品提示信息以显示正确的物品等级。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 针对12.0.7版本进行了审阅，包含针对 虚空编织者 的特定尤格-萨隆构筑。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新，包含万法典籍信息。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 针对12.0.7进行更新。
- **2026年5月19日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于项链选择的说明。
- **2026年5月19日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为 虚空编织者 构筑添加关于尤格-萨隆神像的说明。
- **2026年5月19日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新 虚空编织者 三目标构筑。
- **2026年4月22日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 在近期增强后更新戒指附魔。
- **2026年4月22日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为殁言先驱 虚空编织者 构筑变体添加幻象。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为至尊和虚空核心添加新章节。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对12.0.5补丁进行了审阅，修正了属性递减阈值。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 针对12.0.5进行更新。
- **2026年4月10日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新虚空编织者团队副本配装。
- **2026年4月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了一个完全专门的日志审阅章节，包含工作流程、检查清单和故障排除指南。
- **2026年4月9日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为三目标构筑移除扭曲现实，简化 虚空编织者 三目标配置。
- **2026年4月9日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为清晰起见，重新添加专门的三目标构筑。
- **2026年4月8日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 从 执政官 团队副本构筑中移除心灵之眼。
- **2026年4月6日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加一个包含额外 暗影 牧师 模拟资源的下拉菜单。
- **2026年4月6日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加关于模拟配置选择和解读小属性差异的常见问题指南。
- **2026年4月6日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加大秘境执行检查清单和实用的日志审阅章节。
- **2026年4月6日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加移动处理、日志审阅检查清单和验证常见问题指南。
- **2026年4月6日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加关于基于模拟和日志调整天赋的常见问题指南。
- **2026年4月6日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 添加一个包含核心执行技巧的'如何快速提升'字段集。
- **2026年4月6日（本页）：** 添加一个快速提升下拉菜单和额外资源字段集。
- **2026年4月4日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新大秘境构筑。
- **2026年4月4日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新多个构筑的天赋默认设置。
- **2026年4月4日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新 执政官 团队副本和大秘境构筑以及 虚空编织者 大秘境构筑。
- **2026年4月4日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 在近期热修后更新天赋构筑。
- **2026年4月2日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为 虚空编织者 团队副本添加 暗影 言出即灭构筑变体。
- **2026年4月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更换美化，不使用奥术织锦套装。
- **2026年4月1日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为虚空触及添加注意事项。
- **2026年3月29日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在赛季第一周后调整饰品排名。
- **2026年3月29日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为高层大秘境推荐 执政官，并添加关于获得更多范围伤害的说明。
- **2026年3月29日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 提高 暗影 言出即灭的优先级，并添加更多关于扭曲现实的说明。
- **2026年3月29日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新用于团队副本的三目标天赋构筑。
- **2026年3月29日（本页）：** 为3月31日即将到来的职业调整更新指南。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 移除关于茶类消耗品的提及，并添加替代附魔。
- **2026年3月22日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 调整受折磨灵魂之容器的排名。
- **2026年3月22日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新 能量灌注 建议，添加关于触手猛击的说明，并调整关于光晕的说明。
- **2026年3月22日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为团队副本添加三目标构筑。
- **2026年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新天赋构筑。
- **2026年3月18日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新大秘境和地下堡天赋构筑。
- **2026年3月18日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新范围伤害构筑。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对 至暗之夜 第一赛季的上线进行更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 针对第一赛季的上线进行更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对第一赛季进行审阅。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 换入关于皇家烤肉个人食物的提及。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对第一赛季进行审阅。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对第1赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了更多关于使用触手猛击层数的细节。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 构筑已针对第一赛季的上线进行审阅。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对第一赛季进行审阅。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已更新第一赛季的循环章节。
- **2026年3月16日（本页面）：** 已针对 至暗之夜 第一赛季的上线进行更新。
- **2026年3月6日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品排名。
- **2026年3月6日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加 虚空洪流 + 光晕宏。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 添加80级起始的导入字符串。
- **2026年3月2日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新专业制造建议，为第一赛季上线做好准备。
- **2026年3月2日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 修正食物消耗品，并添加关于茶类的提及。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为 至暗之夜 上线至90级提供新的练级构筑。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已为 至暗之夜 赛季前阶段更新页面。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 调整饰品排名以考虑史诗地下城的物品等级。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 更新样式以便于轻松复制宏。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为 至暗之夜 上线添加了新的消耗品和附魔。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对90级的属性范围进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于巅峰天赋的专门章节。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对 至暗之夜 资料片的上线更新了新的构筑。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 添加了关于巅峰天赋的专门章节。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对 至暗之夜 上线更新天赋构筑。
- **2026年2月26日（本页）：** 已针对 至暗之夜 资料片的上线进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对职业点数门槛的更改更新天赋树。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 提升遗忘天空的尖啸饰品的排名。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 从束缚亡灵换为束缚恐惧。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对职业点数门槛的更改更新天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在漏洞修复后，移除关于狂乱猛击互动的提及，并将触手猛击提前到起手循环中。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对职业点数门槛的更改更新天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 从束缚亡灵换为束缚恐惧。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对职业点数门槛的更改更新天赋树。
- **2026年2月10日（本页面）：** 已针对职业点数门槛的更改更新天赋树。
- **2026年1月23日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为前瞻补丁添加了更多常见问题条目。
- **2026年1月23日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为前瞻补丁添加了更多常见问题条目。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对 至暗之夜 前瞻补丁进行更新。
- **2026年1月19日（本页）：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月21日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 对谜之卡特尔筹码章节进行了进一步的澄清和细化。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加了迪纳尔章节，并根据涡轮增压物品等级调整了饰品排名。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月29日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 更新 能量灌注 宏，在施放 能量灌注 前使用饰品。
- **2025年8月29日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为 执政官 起手循环添加关于使用心灵震爆的说明。
- **2025年8月29日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 在第三赛季上线后进行了审阅。
- **2025年8月26日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加天赋视频指南，并在宏图大道中加入幻象。
- **2025年8月26日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加视频指南。
- **2025年8月18日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 对饰品层级排名进行小幅调整。
- **2025年8月18日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在第一周后添加更多地下城技巧。
- **2025年8月11日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 更新全合一的 暗影 冲击宏。
- **2025年8月7日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025年8月7日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加关于 虚空洪流 取消的说明，并更新默认的 虚空编织者 天赋。
- **2025年8月7日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025年8月7日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025年8月7日（本页面）：** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 针对11.2.0补丁进行更新，包含一个新宏。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 天赋已更新为推荐 执政官。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 针对11.2.0补丁进行更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对11.2.0补丁进行更新。
- **2025年8月4日（本页面）：** 针对11.2.0补丁进行更新。
- **2025年6月22日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为即将到来的热修调整D.I.S.C.腰带效能。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于坚固信息保护容器腰带物品的信息。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加关于战斗助手的信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 审阅11.1.7补丁的信息。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 添加关于战斗助手的信息。
- **2025年6月15日（本页）：** 针对11.1.7补丁的更新。
- **2025年5月28日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 新增史诗加里维克斯视频。
- **2025年5月25日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 在近期热修后复核信息，确认仍然准确。
- **2025年5月25日（本页）：** 根据五月末的热修进行更新。
- **2025年5月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 新增史诗斯图克斯视角视频。
- **2025 年 5 月 19 日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 更新腐蚀排名并新增视频攻略。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 新增关于购买修道院徽记的说明。
- **2025年5月9日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 为最后几个史诗首领新增更多提示。
- **2025年5月8日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 瑟尔西的指环已不再是毕业装备。
- **2025年5月5日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新卡特尔代币部分。
- **2025年5月5日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 更新腐蚀部分，提供更多最新信息。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 新增关于11.1.5补丁新冷却管理器的说明。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对11.1.5补丁更新，并新增腐蚀部分。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 针对11.1.5补丁的更新。
- **2025年4月6日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 更新里克和齿轮大师的视频，并为史诗首领新增几条提示。
- **2025年4月2日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 更新执政官天赋构建。
- **2025年4月2日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新执政官团队副本构建的默认天赋配置。
- **2025年4月2日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新执政官单体目标构建，移除尤格-萨隆。
- **2025年3月28日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 根据近期热修更新饰品排名。
- **2025年3月28日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 新增其他消耗品部分。
- **2025年3月19日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在漏洞修复后移除对无定形圣物的提及。
- **2025年3月19日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 更新维克斯和混沌熔炉的史诗难度视频。
- **2025年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 新增巢穴的视频链接。
- **2025年3月19日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在点出Unfurling Darkness天赋时，在纯单体战斗中移除对暗影 Crash的使用。
- **2025年3月14日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 经过更多测试后，调整第二赛季的属性目标。
- **2025年3月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品排名，并为各部分补充更多信息。
- **2025年3月13日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 移除不再有用的心灵鞭笞：疯狂宏。
- **2025年3月13日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 更新关于在混沌熔炉中站在中间的说明。
- **2025年3月13日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 从虚空编织者多目标构建中移除舒展黑暗。
- **2025年3月12日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 新增更多提示并更新各场战斗的视频。
- **2025年3月10日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 新增更多副本提示，附带视频和WeakAuras链接。
- **2025年3月9日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 第一周后新增副本提示。
- **2025年3月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 移除暗影言术：灭多目标部分中令人困惑的目标死亡描述。
- **2025年3月5日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 新增关于何时更换为第二赛季套装的说明。
- **2025年3月5日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 团本开放第一天后，调整部分首领提示。
- **2025年3月3日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 新增关于使用超线程护腕的信息。
- **2025年3月3日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 针对维克斯切换为虚空编织者，并修复单体目标+暗影崩溃执政官构建冲突的问题。
- **2025年3月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 新增关于超线程护腕的部分。
- **2025年3月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新第二赛季瑟尔西的指环宝石。
- **2025年3月1日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 新增心灵鞭笞虚空编织者构建和更多副本提示。
- **2025年3月1日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 新增第二赛季的新能量灌注目标。
- **2025年2月28日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 移除虚空冲击在引导其他法术时施放的能力。
- **2025年2月28日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 从虚空编织者单体目标构建中移除舒展黑暗。
- **2025年2月28日（本页）：** 移除虚空冲击在引导其他法术时施放的能力。
- **2025年2月26日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新第二赛季饰品排名。
- **2025年2月26日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 更新第二赛季大秘境属性目标。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 更新11.1.0补丁天赋构建。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 针对11.1.0补丁更新页面。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对 11.1.0 补丁进行审阅。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 更新11.1.0补丁属性目标。
- **2025年2月24日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 更新天赋字符串以适配11.1.0补丁。
- **2025年2月24日（[解放安德迈页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新第二赛季构建，并为每个副本新增提示。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为第2赛季更新输出循环。移除了在拥有不可逃脱的折磨时对暗影言：灭和心灵震爆的更高优先级，引导法术时使用虚空箭，并添加了新饰品。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 新增11.1.0天赋构建。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对 11.1.0 补丁进行审阅。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对11.1.0更新，新增天赋构建。
- **2025年2月24日（本页面）：** 针对11.1.0更新。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新瑟尔西的指环提示说明，并提供风属性宝石替代方案。
- **2024年12月16日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 根据近期增益更新瑟尔西的指环宝石。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为11.0.7新增瑟尔西的指环。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 首次发布后更新瑟尔西的指环建议。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 为特定首领新增几段视角视频。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 推荐从三重偶像开始。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 建议大多数内容从执政官构建开始。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 简化循环部分。
- **2024年12月15日（本页）：** 新增关于11.0.7内容更新的说明。
- **2024年11月16日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 更新一键驱散宏和停止引导宏，使其更加简洁。
- **2024年11月4日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 更新执政官循环中光环的优先级。
- **2024年11月4日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为整体毕业列表武器新增注意事项。
- **2024年11月4日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 根据近期热修进行复核。
- **2024年11月4日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 澄清武器附魔的使用。
- **2024年11月4日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对近期热修进行复核。
- **2024年11月4日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 为席克兰添加额外信息。
- **2024年11月4日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 针对近期热修进行复核。
- **2024年11月4日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新能量灌注目标建议。
- **2024年11月4日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新心灵之眼与扭曲现实部分，使其更加清晰。
- **2024年11月4日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 根据近期热修进行复核。
- **2024年11月4日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 新增易于复制的天赋字符串，并更新光环在循环部分中的位置。
- **2024年11月4日（本页）：** 十一月复核。
- **2024年10月27日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 移除知识迸发。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 调整 执政官 起手式，在开怪前使用光晕。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5更新，为史诗难度的多场战斗新增更多提示和额外信息。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 对于 执政官 配装，已默认改为使用持续效能来处理脱战暂停机制。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 对于 执政官 配装，已默认改为使用持续效能来处理脱战暂停机制。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年10月17日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 修复了史诗钥石地下城装备套装中戒指的错误。
- **2024年10月15日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 从千丝之城中移除幻象。
- **2024年10月14日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 在更多测试后更新属性建议，使其更加精确。
- **2024年10月11日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为虚空编织者练级移除了虚空编织者。
- **2024年10月10日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 更新虚空编织者配装，部分情况下使用精神衰竭和无法逃脱的折磨。
- **2024年10月10日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新虚空编织者配装。
- **2024年10月10日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新间谍大师之网的使用方法。
- **2024年10月10日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加虚空编织者团队顺劈天赋选择器。
- **2024年10月10日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 虚空编织者配装使用精神衰竭，单体+崩裂变体使用无法逃脱的折磨。大元帅的统御之力在大秘境中现在是可选的。
- **2024年10月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 为虚空编织者配装将虚空编织者替换为暗影之拥。
- **2024年10月9日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新单体目标 + 暗影 Crash 虚空编织者配装。
- **2024年10月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新虚空编织者单体目标配装的默认天赋。
- **2024年10月9日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为虚空编织者团队配装将虚空编织者替换为暗影之拥。
- **2024年10月7日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 更新默认配装建议以包含更多虚空编织者内容，并添加更多虚空编织者技巧。
- **2024年10月7日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 根据最近的热修复更新配装建议。
- **2024年10月7日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新虚空编织者的默认天赋。
- **2024年10月7日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 根据最近的热修复更新天赋配装。
- **2024年10月6日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 根据最近的热修复更新输出循环。
- **2024年10月6日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 将虚空编织者AoE配装更新为默认使用暗影之拥。
- **2024年10月6日（本页）：** 根据最近的热修复进行了更新。
- **2024年10月4日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 更新地下城属性建议以适应更高的层数。
- **2024年10月4日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 当使用暗影深渊天赋时，移除多余的 暗影言：灭 条目。
- **2024年10月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 调整装备配置以包含更多单手武器。
- **2024年10月1日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加关于迷雾唤灵者使用闪避球击杀小怪的技巧。
- **2024年9月30日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品排名，并为地下城BiS列表添加一些额外的装备选项。
- **2024年9月25日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为混合配装设置独立章节。
- **2024年9月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 添加安苏雷克女王指南。
- **2024年9月19日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加烛芯密友。
- **2024年9月18日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 为11.0.5版本进行了更新，移除了旧的宏并添加了新的WeakAuras。
- **2024年9月18日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 开始第2周的更新。
- **2024年9月17日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更改命运编织武器的提及。
- **2024年9月17日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 第1周后更新技巧。
- **2024年9月17日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加关于尤格-萨隆偶像的章节。
- **2024年9月16日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品排名并提及命运编织之针武器。
- **2024年9月16日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 为执政官和虚空编织者添加具体的属性建议。
- **2024年9月16日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新天赋章节以提高可读性。
- **2024年9月16日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 修复输出循环章节中噬灭瘟疫优先级的几个问题，特别是虚空编织者AoE。
- **2024年9月16日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加新的输出循环章节以提供更多关于冷却技能使用的细节。
- **2024年9月15日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 重构天赋配装章节使其更易于使用。
- **2024年9月13日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 将默认地下堡配装更新为使用执政官。
- **2024年9月12日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 移除赛季前BiS列表。
- **2024年9月10日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 为乌尔格拉克斯切换为纯单体配装。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在团本层级列表中提升疯王的敕令。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于丰盛大餐的说明。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为执政官大秘境配装添加变体以获得更多单体能力。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在输出循环说明中添加心灵震爆章节。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为执政官大秘境配装添加变体以获得更多单体能力。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已针对《地心之战》第1赛季更新。
- **2024年9月6日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 调整史诗宝石的指导建议以包含狡诈亵渎宝石。
- **2024年9月5日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 修复虚空编织者配装和执政官AoE的起手序列。
- **2024年9月4日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加AoE武器附魔选项。
- **2024年9月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 从制造装备建议中移除束缚之缚。
- **2024年9月1日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于戒指附魔的说明。
- **2024年8月31日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新第1赛季的制造装备建议。
- **2024年8月31日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新单体目标 + 暗影 崩塌流派以适用于虚空编织者，并将执政官整合为单一构建。
- **2024年8月31日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新 虚空编织者 单体 + 暗影 崩塌构筑，为地下堡构筑添加黑暗蔓延，并将 执政官 AOE 整合为一个构筑。
- **2024年8月29日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于赛季前附魔的说明。
- **2024年8月25日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加了地下堡构筑和赛前 执政官 地下城变体，并调整了 执政官 对比 虚空编织者 的百分比差异。
- **2024年8月23日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加执政官高层大秘境配装选择器
- **2024年8月22日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为“地心之战”的上线更新了页面。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为“地心之战”的上线进行了更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为“地心之战”的上线进行了更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 新增 WeakAura 链接。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为《地心之战》上线更新附魔和消耗品。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 为“地心之战”的上线进行了更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战的上线更新了输出循环。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为《地心之战》上线更新天赋配置。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 添加了英雄天赋的条目。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 为地心之战的上线更新了配装和输出循环。
- **2024年8月21日（本页）：** 为“地心之战”的上线进行了更新。
- **2024年8月13日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年8月13日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年8月13日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年8月13日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年7月25日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新天赋配置，在恩佐斯的肖像仍然存在错误时不再使用它。
- **2024年7月25日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新天赋配置，在恩佐斯的肖像仍然存在错误时不再使用它。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月7日（[地心之战](<https://www.icy-veins.com/wow/shadow-priest-the-war-within-pve-guide>)):** 根据虚空碎裂的改名进行更新。
- **2024年7月1日（[地心之战](<https://www.icy-veins.com/wow/shadow-priest-the-war-within-pve-guide>)):** 更新视频。
- **2024年6月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 修正终局精通数值，以遵循67%的上限。
- **2024年6月16日（[地心之战](<https://www.icy-veins.com/wow/shadow-priest-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月27日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 更新工程宝石排名并添加副属性目标。将团队副本中暗影坠落的默认配置改为暗影。
- **2024年5月20日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 在最近的在线修正后更新工程宝石排名。
- **2024年5月18日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 更新工程宝石排名，增加更多选项并对各类棱彩宝石进行排名。
- **2024年5月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 更新初始工程宝石排名，并调整地下城配置的路径选择，优先考虑暗影坠落。
- **2024年5月15日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/shadow-priest-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在大秘境中将 受难 列为S级。
- **2024年5月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于为史诗+购买防御性饰品的说明。
- **2024年5月13日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加关于高层大秘境防御性配装的章节。
- **2024年5月9日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加更多关于容器和火焰伤害触发的信息，并添加史诗+的饰品组合示例。
- **2024年5月9日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加关于诺库德阻击战中格拉尼思的心灵控制技巧的说明。
- **2024年5月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加在AOE场景中取消精神鞭笞：狂乱的选项。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已更新至10.2.7。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 将视频更新为第4赛季播放列表。
- **2024年5月5日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 增加关于容器的更多细节，并调整部分排名顺序。
- **2024年5月2日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 提高虚空箭的优先级，并根据此更改修正起手循环。
- **2024年5月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新炽烈暗影容器的排名，因为它可以帮助触发戒指效果。
- **2024年4月30日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 增加关于铸币购买和额外火焰伤害来源的更多信息。
- **2024年4月30日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为奥达曼添加幻影建议，并添加关于疯狂之触使用的说明。
- **2024年4月30日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 在大秘境天赋配置中添加关于疯狂之触的说明。
- **2024年4月29日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 修复了在奥达曼中推荐 净化疾病 时切换器的错误。
- **2024年4月28日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于大秘境中使用主动饰品的说明。
- **2024年4月28日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为注能大厅添加幻影。
- **2024年4月26日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为诺库德添加 净化疾病 和精神控制。
- **2024年4月26日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 调整在多目标战斗中精神鞭笞：狂乱和暗影之刺：狂乱的优先级。
- **2024年4月25日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加装备ID以更清晰地显示制造装备，为铸币添加新视频，并为团本和大秘境拆分建议。
- **2024年4月25日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 调整Plater模块链接并添加个人配置文件。
- **2024年4月25日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加新视频链接。
- **2024年4月25日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 移除碧蓝魔馆的幻影建议。
- **2024年4月25日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加新视频链接，并说明尼缪饰品与暗影魔的配合使用。
- **2024年4月25日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加新天赋视频。
- **2024年4月25日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 添加第4赛季新视频播放列表。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为第4赛季更新，并提供新的装备建议。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 为第4赛季更新，包括一个新的用于追踪套装奖励的WeakAura。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 更新腿部附魔建议并进行第4赛季审查。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 更新第4赛季的次要属性目标。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为第4赛季更新天赋配置。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季更新输出循环，提供新的占位天赋配置和选项。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为第4赛季更新所有天赋配置，并用一份深入的职业天赋指南替换天赋路径部分。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 为第4赛季进行了更新。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 为第4赛季更新天赋配置。
- **2024年4月22日（本页）：** 为第4赛季更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新高层大秘境副本的美化装备指南。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 对宝石选择的额外说明。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为潮汐王座添加 神圣 新星建议，以及为黑鸦堡垒和迦拉克隆陨落添加新的精神控制技巧。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 为10.2.6版本更新更新日志。
- **2024年3月10日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 更新 能量灌注 特殊宏，使其在没有设置目标的情况下也能在团本外使用。
- **2024年2月19日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为幽灵优先级天赋配置添加精神鞭笞心灵之眼变体。
- **2024年2月14日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 修复幽灵天赋配置中插件的名称，并为心灵之眼版本添加直接天赋字符串。
- **2024年2月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新地下城饰品排名以与梯队列表保持一致。
- **2024年2月13日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 移除关于在永恒绽放中对毒刺使用精神控制的提及。
- **2024年2月13日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新所有天赋配置的默认职业天赋，并将暗影幻象天赋配置更新为幽灵优先级天赋配置版本。
- **2024年2月13日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新大秘境天赋配置中的默认职业天赋和功能选择。
- **2024年2月9日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加关于对岩脊毒刺使用精神控制的说明。
- **2024年2月8日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加精通视频链接。
- **2024年2月8日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加多目标输出循环视频链接。
- **2024年2月8日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加多目标输出循环视频链接。
- **2024年1月28日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 建议在所有受折磨词缀的钥石副本中使用 群体驱散。
- **2024年1月25日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在大秘境排名中提升灾祸之枝和 烬魄之灰 的等级。
- **2024年1月21日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 增加关于堆叠精通的额外说明。
- **2024年1月21日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 根据近期增益更新虚空爆发大秘境天赋配置的默认设置。
- **2024年1月21日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 根据近期增益更新3目标议会战天赋配置。
- **2024年1月21日（本页）：** 根据即将发布的 暗影牧师 热修复增益进行更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 说明涌动时间之帽在大秘境中的使用方法。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加提供更高机动性的靴子附魔替代方案。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 说明与涌动时间之帽配合的急速阈值，并提及精通在冲层大秘境中的价值。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加视频链接和更多WeakAura。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5进行审阅。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为单体目标 + 暗影坠落配置添加可选变更，并更新3目标议会配置。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新10.2.5版本的默认天赋配置，使其更加全面。
- **2024年1月15日（本页）：** 为10.2.5版本更新更新日志。
- **2024年1月2日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在套装部分增加关于消耗死亡折磨层数的更多细节。
- **2023年12月23日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加舍弃心灵掌握和无法逃脱的折磨的天赋配置选项。
- **2023年12月20日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在地下城饰品排名中降低尼缪的排名。
- **2023年12月19日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新装备套装，提供更多项链选择。
- **2023年12月19日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 移除过时的部分并调整精神鞭笞选项。
- **2023年12月18日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于原初火焰预兆的额外说明。
- **2023年12月18日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 根据近期心灵链接增益更新大秘境天赋配置。
- **2023年12月18日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加关于暗影坠落配置在单体目标中损失的说明。
- **2023年12月18日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新默认大秘境天赋配置中的可选天赋点，并更新3目标议会战天赋配置。
- **2023年12月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于优先升级头盔以获得炽热精华的说明。
- **2023年12月13日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于炽热精华的部分。
- **2023年12月13日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在钥石天赋配置中，放弃尤格萨隆偶像，改用阴险之怒。
- **2023年12月12日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新默认大秘境天赋配置，不再使用尤格萨隆偶像。
- **2023年12月8日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在潮汐王座中默认建议使用 群体驱散。
- **2023年12月3日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新黑暗升华三偶像天赋配置，默认使用精神鞭笞。
- **2023年12月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加关于4件套套装奖励如何运作的说明。
- **2023年12月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加关于优化尤格萨隆偶像的部分。
- **2023年12月3日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新默认大秘境天赋配置以使用精神鞭笞。
- **2023年12月3日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 添加关于尤格萨隆偶像的更多细节。
- **2023年12月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加制造装备插件。
- **2023年12月1日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加更多关于何时选择哪种配置的信息。重构暗影幻象配置，使其与第3赛季套装加成配合得更好。
- **2023年12月1日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新3目标议会战天赋配置，默认使用精神鞭笞。
- **2023年11月30日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加饰品梯队列表以及一些选项的更详细信息。
- **2023年11月30日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加一些新的WeakAuras和Plater模块。
- **2023年11月25日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为各副本添加更多驱散建议。
- **2023年11月24日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品和武器排名/评论。
- **2023年11月24日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在阿塔达萨建议中添加净化疾病。
- **2023年11月24日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 移除移动时使用真言术：盾的操作。
- **2023年11月20日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 将第2赛季构筑更名为暗影化身构筑，并讲解其使用场景。
- **2023年11月19日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 当仅使用两件套套装效果时，添加额外的暗言术：死一行。
- **2023年11月17日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新第3赛季的秘境+构筑，使其更加精简。
- **2023年11月17日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新3目标和秘境+构筑，使其更加精简。
- **2023年11月16日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新关于灰烬饰品的说明。
- **2023年11月16日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加第2赛季套装构筑，供提升装备时使用。
- **2023年11月14日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于在斩杀阶段使用伊雷达尔的小注。
- **2023年11月14日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加饰品视频链接。
- **2023年11月14日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为单体目标 + 暗影坠落配置添加精神鞭笞配置选项。
- **2023年11月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 更新饰品建议，并添加更多关于何时使用每个饰品的细节。
- **2023年11月8日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加制造装备视频链接。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 在波动孢子斗篷削弱后更新装饰建议。
- **2023年11月7日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加关于暴击/全能与咒术物品配合的注释。
- **2023年11月7日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 对使用召日者贝洛雷洛斯进行小幅澄清更新。
- **2023年11月7日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在主要循环优先级中调整移动时的GCD。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对10.2补丁更新，采用新的天赋构筑。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为第3赛季和10.2补丁更新装备列表和建议。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对10.2.0补丁进行审阅。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为第3赛季更新所有消耗品。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已更新10.2.0补丁的属性阈值和目标。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 重新调整章节顺序，并更新第3赛季和10.2补丁的信息。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.0补丁和新的第3赛季套装效果更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为10.2补丁和第3赛季更新天赋构筑和建议。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 根据10.2补丁的改动更新法术。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已更新天赋构筑，并为10.2.0补丁添加循环目标。
- **2023年11月6日（本页）：** 已更新10.2.0补丁的更新日志。
- **2023年10月3日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为第2赛季使用正确的插槽物品名称。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已为10.1.7版本审核。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加新的装备列表。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已为10.1.7版本审核。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已为10.1.7版本审核。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已为10.1.7版本审核。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 重新组织标题使其更易读，并移动天赋法术详解。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 根据10.1.7的改动更新天使的慈悲的描述。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已为10.1.7版本审核。
- **2023年9月4日（本页）：** 添加了10.1.7补丁的改动信息。
- **2023年8月18日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 修正三神像暗影化身构筑描述中的错别字。
- **2023年8月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加视频链接。
- **2023年8月13日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 更新视频链接。
- **2023年8月13日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加视频链接。
- **2023年8月13日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新视频链接，并阐明三神像配置之间的差异。
- **2023年8月13日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新视频链接。
- **2023年8月13日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 阐明高层钥匙中三神像配置的注释，并更新视频链接。
- **2023年8月13日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新视频链接。
- **2023年8月10日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为暗影化身构筑添加关于艾瑞达斯碎片的注释。
- **2023年8月10日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加副属性深入解析章节，以优化顶级装备。
- **2023年8月9日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加更多关于何时选择哪种构筑的细节，并润色多个章节使内容更清晰。
- **2023年8月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为暗影化身起手法添加注释，使其更清晰。
- **2023年8月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在使用无法逃脱的折磨时，从虚空爆发起手中移除暗影言术：死。
- **2023年8月8日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加新章节，阐明何时使用各副本构筑。
- **2023年8月8日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 调整暗影化身起手法以纳入扭曲现实。
- **2023年8月8日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 修复暗影化身单体目标构筑未使用扭曲现实的问题。
- **2023年8月8日（本页）：** 更新视频链接。
- **2023年8月7日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 根据近期对各种法术的热修削弱添加新构筑。
- **2023年8月7日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 根据近期热修添加新构筑。
- **2023年8月7日（本页）：** 添加了关于近期热修对我们DoT、暗影幻象和吸血鬼之触的改动的更新日志。
- **2023年7月31日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为群体驱散使用场景添加一些缺失的条目。
- **2023年7月31日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 默认为暗影化身单体构筑切换到扭曲现实。
- **2023年7月26日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 调整神圣之星和心灵游戏的使用章节，将其优先级降低。
- **2023年7月25日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加暗影化身+暗影崩塌构筑。
- **2023年7月23日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已根据近期热修进行审阅。
- **2023年7月23日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已根据近期热修进行审阅。
- **2023年7月23日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已根据近期热修进行审阅。
- **2023年7月23日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已根据近期热修进行审阅。
- **2023年7月23日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已根据近期热修进行审阅，并提及新的天赋选项。
- **2023年7月23日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已根据近期热修进行审阅。
- **2023年7月23日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已根据近期热修进行审阅。注明了单体目标构筑之间的差异。
- **2023年7月23日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已根据近期热修进行审阅。
- **2023年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已根据近期热修进行审阅。
- **2023年7月23日（本页）：** 添加了近期热修的更新日志。
- **2023年7月17日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 重构以使用新的天赋布局。
- **2023年7月17日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 重构以使用新的天赋布局。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对10.1.5补丁更新，采用新的天赋字符串。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 10.1.5补丁的更新，包括来自永恒黎明的新物品。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加了一个新的能量灌注宏。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已更新10.1.5补丁的天赋字符串。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审阅，并对虚空形态起手法进行小幅更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新10.1.5补丁的天赋字符串。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 在10.1.5补丁中添加关于仁慈和精华噬灭天赋的参考。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 为10.1.5添加新的天赋字符串。
- **2023年7月10日（本页）：** 已针对10.1.5补丁更新，采用新的改动。
- **2023年6月28日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 在暗影化身构筑中将诅咒之语换为死亡代言人。
- **2023年6月27日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 澄清了一些关于饰品和装饰物品的选择。
- **2023年6月27日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 调整关于不使用玛瑙印记的表述。
- **2023年6月27日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 调整构筑以包含扭曲现实、暗影化身和心灵操纵者选项。
- **2023年6月27日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 根据所选天赋更新暗影言术：死的循环。阐明一些扭曲现实的使用。
- **2023年6月27日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 根据近期热修添加新的天赋构筑。
- **2023年6月27日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新默认构筑。
- **2023年6月27日（本页）：** 添加关于近期暗影热修的注释。
- **2023年6月23日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新扭曲现实的一些数据。
- **2023年6月23日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 调整关于扭曲现实的注释。
- **2023年6月22日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 修正精神鞭笞与心灵刺的对比问题。
- **2023年6月20日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 澄清暗影法力值与心灵法力值，以及心灵刺与精神鞭笞的DPS对比。
- **2023年6月20日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新吞噬瘟疫刷新细节。
- **2023年6月20日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 添加关于扭曲现实的说明。
- **2023年6月16日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加更多关于在大秘境中使用心灵刺的原因细节。
- **2023年6月15日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 关于吞噬瘟疫的虚空洪流的说明。
- **2023年6月7日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加关于在大秘境中使用彼界灯塔的说明。
- **2023年6月7日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加爆发伤害章节。
- **2023年6月6日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加说明，澄清虚空洪流应始终完整引导。
- **2023年6月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 关于T30套装效果如何运作的技术说明，并添加大致数值。
- **2023年6月1日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加简单的群体驱散宏。
- **2023年6月1日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于插槽大致价值的说明。
- **2023年6月1日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 关于套装效果如何运作的说明。
- **2023年6月1日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 为暗影坠落添加更多细节。
- **2023年5月31日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加更多关于武器制造的细节。
- **2023年5月30日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加几个用于处理第2赛季词缀的鼠标悬停宏。
- **2023年5月30日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加几个用于处理第2赛季词缀的鼠标悬停宏。
- **2023年5月28日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 移除关于注能大厅的净化疾病和精神控制的建议。
- **2023年5月26日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 调整章节顺序，并添加更多关于防御技能使用的细节。
- **2023年5月26日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加关于大秘境中套装优化的说明。
- **2023年5月25日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加了关于不祥的多彩精华的额外说明。
- **2023年5月24日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 删除了部分示例起手式，改用循环页面。
- **2023年5月23日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加了时光漫游部分。
- **2023年5月23日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 根据近期改动调整了时光漫游部分
- **2023年5月22日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 添加了更多关于急速软上限的细节。
- **2023年5月22日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为第2赛季添加了更多提示和细节。
- **2023年5月22日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了更多关于在开怪前使用光晕、神圣之星和暗影坠落的细节。添加了关于战利品使用的说明。
- **2023年5月21日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加了按地下城和词缀查看功能选择的简便方法。
- **2023年5月19日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加了精神控制部分，介绍值得控制的有趣小怪。
- **2023年5月18日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 修正了简介部分的拼写错误。
- **2023年5月16日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加了关于波动孢子斗篷的bug，并移除了旧的奈萨里奥巢穴物品。
- **2023年5月16日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 移除了关于波动孢子斗篷bug的引用，因为已修复。
- **2023年5月15日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 修正了波动孢子斗篷的信息，因为其属性已固定。
- **2023年5月15日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 愤怒药水已修复，因此调整回建议并添加了腰带扣。
- **2023年5月6日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加了关于不祥的多彩精华飞行选择的说明。
- **2023年5月6日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 建议在注能大厅使用群体驱散，并添加了更多关于在大秘境中使用精神鞭笞的细节。
- **2023年5月5日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 根据近期改动更新了武器和饰品排名。
- **2023年5月5日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 澄清了暗影坠落的使用仅用于刷新DoT。
- **2023年5月4日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加第2赛季地下城实用工具部分。
- **2023年5月4日（本页）：** 移除待处理更改部分。
- **2023年5月3日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 在你获得低语暗影之前，修正暗影崩溃说明。
- **2023年5月3日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 由于狂暴存在错误，将默认药剂改回全能。
- **2023年5月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 降低暗影言：死的优先级。
- **2023年5月2日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于睿智与飘渺的额外说明。
- **2023年5月2日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 澄清Dstar和光晕，并在吞噬瘟疫部分扩展扭曲现实的说明。
- **2023年5月2日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 关于灵活天赋点的小提示
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为10.1.0版本更新天赋配置。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为10.1和第2赛季更新所有装备建议。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为10.1.0更换建议的药水，并审查其他附魔。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 更新属性优先级中关于10.1.0已修复错误的引用。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为10.1.0更新天赋配置和建议。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 重大更新以支持10.1重做。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 为10.1.0重做更新天赋配置。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 根据10.1.0中的新法术进行更新。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（本页）：** 根据10.1补丁进行更新。
- **2023年4月25日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 为10.1补丁进行了复查。
- **2023年3月23日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 根据最近的热修复更新黑曜石指环建议。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 根据最近的热修复更新黑曜石指环建议。
- **2023年3月22日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 根据最近关于先知的暮色宝石交互的信息更新黑曜石指环建议。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 根据最近关于先知的暮色宝石交互的信息更新黑曜石指环建议。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/shadow-priest-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为10.0.7补丁更新，并添加关于黑曜石指环的新章节。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 为10.0.7补丁进行审查，并添加关于黑曜石指环的信息。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 为10.0.7补丁更新，并添加已知错误章节。
- **2023年3月5日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 微调地下城饰品建议。
- **2023年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 修正心能游戏目标上限的错误。
- **2023年2月25日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 澄清起手循环中虚空洪流的使用。
- **2023年2月23日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 修正单体目标中虚空洪流的问题，应在全部3个持续伤害激活时才施放。
- **2023年2月22日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加关于在大秘境中使用精神灼烧的注意事项。
- **2023年2月17日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 根据最近的平衡性调整更新练级天赋配置。
- **2023年2月17日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为示例起手循环添加更多细节。
- **2023年2月15日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 澄清宝石使用方法。
- **2023年2月4日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 调整常见天赋配置的单体目标差异。
- **2023年2月4日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新双目标天赋配置，并添加关于单体目标使用暗影魔的说明。
- **2023年2月3日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 修正精神控制宏的问题。
- **2023年2月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 调整高优先级的精神鞭笞：疯狂动作，仅在虚空洪流不可用时使用。
- **2023年2月2日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加更多关于驱散和群体驱散的用途。
- **2023年1月31日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 修正未点出摧心魔时配合恩佐斯的高优先级精神鞭笞：疯狂行。精简AoE循环使其更易读。
- **2023年1月25日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为10.0.5补丁更新天赋树。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为10.0.5更新装备建议。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加精神控制宏，并清理其他几个宏。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于急速/精通组合宝石的提及。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新10.0.5的天赋构筑和建议。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 使用虚空洪流更新10.0.5的循环指南。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新10.0.5补丁的天赋构筑。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 为10.0.5添加新的天赋。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 为10.0.5的构筑更新天赋。
- **2023年1月24日（本页）：** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月12日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 为怨毒词缀添加虚空触须建议。
- **2023年1月12日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 移除单体目标上的心灵灼烧使用。
- **2023年1月11日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 根据近期的增益添加新的天赋构筑。
- **2023年1月11日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 10.0.5的循环更新，主要是格式变更和一些小的清晰度更新。
- **2023年1月11日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 根据近期的改动更新大秘境天赋构筑。
- **2023年1月4日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 对噬灵疫病刷新说明进行小的澄清，并添加一些饰品说明。
- **2023年1月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新起手式并添加更多细节。按冷却时间拆分，以便更容易维护。
- **2023年1月1日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 在搭配无尽折磨时，降低暗影言：灭的优先级。
- **2022年12月29日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 为心灵鞭笞：疯狂添加新逻辑，并更改默认复选框。
- **2022年12月24日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加绝望召唤者法典饰品。
- **2022年12月23日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 在大秘境中选择两种天赋构筑时添加更多细节。
- **2022年12月23日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新天赋构筑以考虑虚空尖啸的错误。
- **2022年12月21日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 为专业制造装备部分添加更多细节。
- **2022年12月21日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于何时使用全能药水的额外说明。
- **2022年12月21日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新天赋建议，使其更简单易上手。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 添加专业制造装备的视频指南，并移除关于在元素织法者项链中使用不同元素的说明。
- **2022年12月13日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 添加提供更高爆发的备选单体构筑。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已为第一赛季上线更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 添加关于更多我不建议使用的药水的说明。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加一些第一赛季开局的技巧。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了讨论第29赛季套装奖励循环变化的章节。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月9日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于心灵震爆与心灵鞭笞在搭配心灵融合和克苏恩偶像时的额外说明。
- **2022年11月8日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 将种族技能从循环中移出，放入独立章节。修复了起手式以使其更易阅读。
- **2022年11月7日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 使循环中关于心灵震爆的部分更易阅读。
- **2022年11月7日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新了玛里莱斯灵魂羁绊计算器以移除不谐回声之力。
- **2022年11月5日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 添加了关于大秘境起手式和简化版优先级列表的章节。
- **2022年11月5日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 整理了噬灵疫病的行文，使其更清晰。
- **2022年11月3日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 更新了循环的填充技能章节使其更清晰。添加了关于如何使用心灵灼烧的新章节。
- **2022年11月3日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 包含了缩写和常用的法术简称。
- **2022年11月2日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 通过底部章节更清晰地说明何时使用填充法术。
- **2022年10月31日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新天赋构筑以不再建议心灵链接，并移除了无偶像构筑。
- **2022年10月31日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 更新天赋构筑以不再建议心灵链接，并将默认大秘境构筑改为尤格-萨隆。
- **2022年10月31日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 更新天赋构筑以不再建议心灵链接。
- **2022年10月30日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 添加了额外的移动宏。
- **2022年10月27日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 更新了信仰飞跃宏，并为天赋选择节点添加了新宏。
- **2022年10月26日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-castle-nathria-raid-guide>)):** 更新了推荐构筑以使用亚煞极偶像和塔巴达的诡计传奇。
- **2022年10月26日（[统御圣所页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sanctum-of-domination-raid-guide>)):** 更新了推荐构筑以使用亚煞极偶像和塔巴达的诡计传奇。
- **2022年10月26日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 更新了推荐构筑以使用亚煞极偶像和塔巴达的诡计传奇。
- **2022年10月26日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 更新构筑以点出半透明影像。
- **2022年10月26日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 添加了更多循环切换以使内容更易查看。
- **2022年10月26日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 根据近期发现的虚空尖啸错误更新了天赋构筑。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/shadow-priest-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/shadow-priest-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/shadow-priest-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/shadow-priest-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)):** 调整了暗影言：灭、心灵鞭笞和心灵震爆的优先级。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年7月29日（[9.2版本分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-2-changes-analysis>)):** 添加了9.2.5和第4赛季的改动。
- **2022年2月22日（[9.2版本分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-2-changes-analysis>)):** 根据苍白敕令削弱更新了更新日志。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-2-changes-analysis>)):** 添加了9.2补丁的改动和初步想法。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** 添加了9.1.5补丁的改动。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** 添加了新的热修，并移除了PTR说明。
- **2021年7月6日（[9.1 补丁分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** 移除了心能之力章节。
- **2021年6月29日（[9.1 补丁分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** 添加了所有改动及最新评论。
- **2021年5月2日（[9.1 补丁分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** 来自最新版本的更多PTR改动，影响基础法术、传奇和羁绊之力。
- **2021年4月22日（[9.1 补丁分析](<https://www.icy-veins.com/wow/shadow-priest-patch-9-1-changes-analysis>)):** 添加了初始内容。
- **2020年10月26日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-ny-alotha-raid-guide>)):** 预补丁调整后更新了疯狂鞭笞师和远古狂乱的建议。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** 本页面已针对8.3补丁审查，无需更改。
- **2019年10月6日（[永恒宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** 为几个首领添加了更多技巧。
- **2019年10月5日（[永恒宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** 添加了更多提示。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月11日（[风暴熔渣页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** 更新了天赋建议，并为恩佐斯添加了技巧。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月26日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了若干天赋建议和玩法技巧。
- **2019年1月29日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了剩余的天赋建议和首领技巧。
- **2019年1月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 填写了大部分天赋建议和首领技巧。
- **2019年1月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为达萨罗之战中的暗影牧师添加了首领技巧。
- **2018年12月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 更新了部分天赋推荐和战斗技巧。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 更新以适应8.1补丁的改动。
- **2018年10月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 在可以基于数据得出确切结论后进行了更新。
- **2018年9月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 在看到首周奥杜尔的数据后进行了更新。
- **2018年9月5日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 重构了玩法建议并更新了天赋推荐。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 为奥杜尔开放进行了初步更新。
- **2018年8月9日（[奥杜尔页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-uldir-raid-guide>)):** 移除了军团再临的信息，并为奥杜尔添加了占位符。

显示更多

显示更少

:::

## 练级

在本页面，你将找到我们的逐级暗影牧师练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[牧师升级指南](<https://www.icy-veins.com/wow/priest-leveling-guide>).

1.

### 暗影牧师练级指南——适用于至暗之夜

暗影牧师在练级方面提供了某种独特的体验，

你可以根据自己的节奏偏好选择几种不同的玩法。作为

持续伤害专家，你可以一次拉很多怪物，然后让你的

持续伤害效果在它们身上自然跳完，或者你也可以拉一组怪物然后爆发

将它们击杀，这取决于你的天赋选择。

作为暗影牧师练级时，你想要优先用

[[spell:589]]和[[spell:1227280]]给怪物上标记，然后

让你的持续伤害效果完成剩下的工作。然后你可以使用[[spell:586]]和[[spell:8122]]

来避免被怪物击中，并 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 可以进一步延长

方法是在移动时施放 [[spell:263165]]。

在战斗间隙，务必使用 [[spell:1231418]] 来快速恢复生命值，

无需进食消耗品即可脱离战斗。该技能可以在法术书的

通用标签页中找到。

1.1.

#### 升级装备选择

在为你的 暗影牧师 选择装备时，你应当始终优先选择

智力数值更高的那件装备，通常可以通过该装备的

物品等级来判断。智力远远是我们更优秀的属性，它能让你

所做的一切都造成更高伤害，并更快地击杀怪物。

当你获得智力相同的装备时，你应当大致

优先选择带有急速、精通，或理想情况下同时带有两者的装备，以获得略微更优的效果。

使用传家宝物品时，我们推荐使用带有急速属性的，因为它们

会略微改善升级过程中的游戏体验流程。

1.2.

#### 至暗之夜升级实用消耗品

在新资料片中升级，关键在于最大限度地减少停顿时间并提前积累力量。

在游戏早期，终局附魔和消耗品通常被禁用或大幅缩减，

升级过程中通常会被禁用或大幅缩减效果，但仍有几件物品值得提前囤积，以便让

整个过程更顺畅、更快捷、更少挫折。以下推荐专注于

历史上在资料片开服时仍然有用且能提供价值的

物品，无论数值调整如何变化都如此。

地心之战的附魔在升级过程中仍然有效，并且可以作为

一种廉价的方式来获得小幅的力量提升。提供急速或速度的附魔

在早期装备升级稀少时尤其有价值。

优先考虑以下物品：

- [[item:223674]]（在你升级过程中急速下降时有所帮助）
- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

淬火药水在较低等级时仍然可用，能显著加快

艰难的拉怪、精英任务或剧情遭遇战。请储备少量以备

爆发伤害或生存能力至关重要的时刻使用。请务必在到达满级

内容之前使用这些药水！

一旦你达到81级，你就可以获取

[[item:241305]]，这是对你自我治疗能力的极佳补充。

某些消耗品可以显著改善升级流程：

- [[item:109076]]
- [[item:132516]]或[[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]]或[[item:133576]]

1.

### 升级天赋

你在10级时解锁天赋树。下方是推荐的升级

天赋路线。如果你仍在升向80级的过程中，可以随意选择

任一套升级天赋方案。

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 升级天赋

这套天赋为你提供一个以高伤害为核心的练级天赋，围绕

[[spell:391399]]和[[spell:120644]]，同时仍然依赖于基础

来自你的主要持续伤害效果的伤害。

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)我们为你准备了一套80级

字符串。你可以在开始获得

至暗之夜等级后，按照下面天赋树的逐点分配进行。

:::talents 执政官 80级起始天赋
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzwMDMYmZGLIzYxMNAGgZWMDzmBgMGLAYmZmhxMzMzsxMAYGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzwMDbzYMzMjFkZsYmGADwMLmhZzAQGjFAMzMzwYmZmZ2YmtlBYGMA"
}
```
:::

:::details 来源计算器编码
```
#CE-BAkWldvNOsbKKqHoaQw4K2edaaWUghJdJxA-ZaDxqS7wNJZx1Y55JpZSCEaTzwvviiD-AAAA-IGAUSOKCMKohxS-
```

:::

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 升级天赋

这套天赋更侧重于持续伤害效果，并可使用

[[spell:448278]] 和 [[spell:1266845]]，同时还能获得

[[spell:451018]] 以便在移动时施放 [[spell:263165]]。

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)我们为你准备了一套80级

字符串。你可以在开始获得

至暗之夜等级后，按照下面天赋树的逐点分配进行。

:::talents 执政官 80级起始天赋
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzMmZgBzMzYBZGLmpBwMzAABY2mNgZDAjZmhxMzMzsxMwMYGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAAzmBAAAAAAAAAAAwYsYGjlxYmZzMmZYbGjZmZsgMjFz0AYmZAgAMbz2GY2YAGzMDjZmZmZjZwMDmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BAkWldvNOsbKKqHoaQw4K2edaaWUghJdJxA-ZaDxqS7wNJZR31Y55pZSCEaTzwvviiD-AAAA-TOGYIUEgohZRBJ-
```

:::

2.3.

#### 升级用战争模式天赋

在本节中，我们将逐一介绍你在升级过程中

应该考虑使用的每项战争模式/PvP天赋。

1. [[spell:211522]] 会在相对较短的冷却时间内
   
   
   
   
   造成可观的一段伤害。
2. 使用 [[spell:199445]]，并确保你尽量完整
   
   
   
   
   引导 [[spell:391399]]。
3. 在你解锁更多天赋之前，使用 [[spell:1246968]]。
4. [[spell:199259]] 让你可以更频繁地使用你的主要
   
   
   
   
   冷却技能。可以随时开始在冷却完毕时就使用它，而不必只是
   
   
   
   
   把它留给大波怪或重要敌人。
5.

### 升级循环

为了在升级和学习专精时保持简单，请使用滑块

来选择你的等级，并观察升级循环如何随着每个

等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

使用以下选项来切换显示哪套升级天赋循环。

<table>&#10;<tr>&#10;<th colspan="2">天赋选择器</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<strong> <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp"/> 执政官</span></strong>&#10;</td>&#10;<td>&#10;<strong> <span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> 虚空编织者</span></strong>&#10;</td>&#10;</tr>&#10;</table>

为升级推荐的天赋方案围绕持续伤害效果（DoT）和快速

推进升级过程。在升级时，尤其是在组队时，

怪物存活时间不会很长，所以我们优先考虑的是能够

在目标身上挂上DoT，然后就转向下一个目标。这让你能够持续

使用 [[spell:589]] 和 [[spell:1227280]] 拉怪，并让你的DoT

为你完成主要工作。一旦你在你关注的敌人身上激活了DoT，

你就可以使用其他法术了。

**适用条件：执政官（启用）。** 当前循环是为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 准备的，使用上方的天赋选择器进行切换。

**适用条件：虚空编织者（启用）。** 当前循环是为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者，使用上方的天赋选择器进行切换。

**等级 1–2：**从1级开始，你只有 [[spell:585]]，所以

现在就一直刷这个技能吧。

**等级 6 起：**战斗前，确保你拥有以下增益效果：

- **等级 6 起：**[[spell:21562]]
- **等级 10 起：**[[spell:232698]]

1. **等级 2 起：**尽可能在更多目标身上保持 [[spell:589]]。
2. **等级 10–14：**尽可能在更多目标身上保持 [[spell:34914]]。
3. **等级 15 起：**使用 [[spell:1227280]] 快速对多个目标施加 [[spell:34914]]。
4. **等级 71 起：**冷却完毕就使用 [[spell:120644]]。
5. **等级 27 起：**对抗更强的敌人时，将 [[spell:228260]] 作为你的主要冷却技能使用。
6. **等级 12 起：**对抗更强的敌人时，将 [[spell:10060]] 作为冷却技能使用。
7. **等级 27 起：**在 [[spell:228260]] 激活期间施放 [[spell:1240401]]。
8. **等级 11 起：**使用 [[spell:335467]] 消耗理智值来对单个目标造成伤害。
9. **等级 10 起：**冷却完毕就使用 [[spell:8092]]。
10. **等级 75 起：**施放 [[spell:391399]] 以消耗所有 [[spell:391399]] 的层数。
11. **等级 30 起：**对任何生命值低于20%的目标使用 [[spell:32379]]。
12. **等级 10 起：**使用 [[spell:15407]] 作为填充法术。
13. **等级 2–9：**使用 [[spell:585]] 作为填充法术。
14. **等级 2 起：**尽可能在更多目标身上保持 [[spell:589]]。
15. **等级 10–14：**尽可能在更多目标身上保持 [[spell:34914]]。
16. **等级 15 起：**使用 [[spell:1227280]] 快速对多个目标施加 [[spell:34914]]。
17. **等级 27 起：**对抗更强的敌人时，将 [[spell:228260]] 作为你的主要冷却技能使用。
18. **等级 12 起：**对抗更强的敌人时，将 [[spell:10060]] 作为冷却技能使用。
19. **等级 27 起：**在 [[spell:228260]] 激活期间施放 [[spell:1240401]]。
20. **等级 77 起：**如果目标身上有吸收盾激活，使用 [[spell:32379]]。
21. **等级 71 起：**在 [[spell:447444]] 期间使用 [[spell:450405]]。
22. **等级 11 起：**使用 [[spell:335467]] 消耗理智值来对单个目标造成伤害。
23. **等级 71 起：**冷却完毕就使用 [[spell:263165]]。
24. **等级 10 起：**冷却完毕就使用 [[spell:8092]]。
25. **等级 30 起：**对任何生命值低于20%的目标使用 [[spell:32379]]。
26. **等级 10 起：**使用 [[spell:15407]] 作为填充法术。
27. **等级 2–9：**使用 [[spell:585]] 作为填充法术。

你还有以下法术可以使用。

- [[spell:17]] 可提供一个额外的防御护盾。
- **等级 10 起：**[[spell:8122]] 作为范围群体控制技能。
- **等级 40 起：**[[spell:19236]] 作为防御技能。
- **等级 18 起：**[[spell:453]] 用于帮助跳过敌人。
- **等级 18 起：**[[spell:528]] 用于驱散敌人身上的增益效果。
- **等级 36–81：**[[spell:586]] 用于借助降低的仇恨半径跳过怪物。
- **等级 82 起：**[[spell:586]]用于帮助跳过小怪，降低仇恨
  
  
  
  
  半径跳过怪物，或作为防御手段。
- **等级 26 起：**[[spell:15487]] 用于打断敌人施法。
- **等级 13 起：**[[spell:47585]] 作为你最强大的防御技能。
- **等级 10–87：**如果你生命值偏低，使用 [[spell:2061]]。
- **等级 88 起：**[[spell:2061]]如果你的生命值过低或
  
  
  
  
  为了获得 [[spell:193063]] 的防御增益。
- **等级 25 起：**[[spell:15286]] 用于在高额伤害窗口期间提供强力治疗。
- **等级 16–21：**[[spell:121536]] 用于移动。
- **等级 22 起：**[[spell:121536]] 或 [[spell:17]] 用于移动。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对 至暗之夜 第一赛季的上线进行更新。
- **2026年3月2日：** 添加80级起始的导入字符串。
- **2026年2月26日：** 为 至暗之夜 上线至90级提供新的练级构筑。
- **2026年2月10日：** 已针对职业点数门槛的更改更新天赋树。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 审阅11.1.7补丁的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 更新11.1.0补丁天赋构建。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月4日：** 更新执政官循环中光环的优先级。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年10月11日：** 为虚空编织者练级移除了虚空编织者。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为“地心之战”的上线进行了更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁更新，采用新的天赋构筑。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁更新，采用新的天赋字符串。
- **2023年5月3日：** 在你获得低语暗影之前，修正暗影崩溃说明。
- **2023年5月1日：** 为10.1.0版本更新天赋配置。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月17日：** 根据最近的平衡性调整更新练级天赋配置。
- **2023年1月25日：** 为10.0.5补丁更新天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页面中，我们将讲解如何在《魔兽世界》12.1.5版本补丁中轻松游玩 暗影牧师，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 暗影牧师基础

本章节面向刚接触游戏或职业的玩家，或

希望以更直接的方式游玩专精，而不

被众多需要考虑的优先级和主动技能

为达到最佳游玩效果所压垮的玩家。

暗影牧师本质上是一个积攒-消耗型专精

专注于持续伤害（DoT）效果。从宏观上看，该专精

主要围绕尽可能多地在目标身上保持DoT效果

同时积攒狂乱值用于消耗在 [[spell:335467]] 上。本页面的其余

内容致力于以最简单的方式帮助你达成这一目标

以降低该专精在高端游玩时的要求，同时

不会造成数值输出的大幅下降。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) **管理你的疯狂值**
  
  
  
  
  暗影的资源是狂乱值，用于消耗在
  
  
  
  
  [[spell:335467]]上。它会随着你用法术造成伤害而积攒，
  
  
  
  
  上限为100，因此请避免浪费。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_unholyfrenzy.jpg>) **施放冷却技能**
  
  
  
  
  暗影有许多法术可以在任意时刻按下。
  
  
  
  
  开始时，你的目标是确保没有任何技能不必要地处于冷却状态。
  
  
  
  
  这主要包括像 [[spell:8092]] 和 [[spell:1227280]] 这样的法术。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowwordpain.jpg>) **保持减益效果激活**
  
  
  
  
  作为 暗影牧师，当你身上的持续伤害
  
  
  
  
  效果（DoT）激活时，你所有法术的伤害都会提高。保持 [[spell:589]] 和 [[spell:34914]]
  
  
  
  
  在你的目标身上始终生效。

1.

### 暗影牧师在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者单体构建

2.1.

#### 暗影牧师新手单体天赋

该构建是你在单体场景（如团队副本首领战）中的最佳起点。

下方的构建建议从 [[spell:409044]] 开始。

这可以让维持 [[spell:335467]] 的高覆盖率变得更加宽容

并稍微放慢专精节奏，同时仍能打出不错的伤害。

注意：对于纯单体战斗，你可以移除 [[spell:199484]]

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 单体简单模式
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAAMbmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAAMbmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx15pSMRpI980YJU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者地下城构建

2.2.

#### 暗影牧师新手AoE与大秘境天赋

对于以AoE为主的战斗或场景，请以此构建作为起点。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 苦难大秘境 - 虚空编织者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### 暗影牧师基础输出循环

2.3.

#### 新手 暗影牧师输出循环

游玩 暗影牧师时，你可以将输出循环归结为保持

核心DoT法术与 [[spell:34914]]，积攒狂乱值，然后

将其消耗在 [[spell:335467]] 上。这些步骤被分解为

游玩该专精时的四个输出循环目标。如果你掌握了这些目标，

你将拥有一个良好的基础来在PvE内容中游玩该专精。

1. 大致保持 [[spell:34914]] 和 [[spell:589]]
   
   
   
   
   最多12个目标。使用 [[spell:1227280]] 来辅助完成。
2. 在主目标上保持 [[spell:335467]] 的最大持续时间
   
   
   
   
   优先目标上的最大覆盖率。尽量避免在它即将到期之前刷新，或者
   
   
   
   
   如果你即将达到狂乱值上限。
3. 使用短冷却的狂乱值生成法术，以确保你不会
   
   
   
   
   浪费它们的使用次数。这包括像 [[spell:8092]] 和 [[spell:1227280]] 这样的法术。
4. 理想情况下，在不会损失任何短冷却法术使用次数时使用你的长冷却法术，
   
   
   
   
   同时确保不要保留太久，以便仍然
   
   
   
   
   利用任何激活的增益效果。这包括像 [[spell:120644]]
   
   
   
   
   或 [[spell:263165]] 这样的法术。

如果你能正确把握这些目标，输出循环应该会更有意义，并且

自然而然地运作。查看下方的优先级列表以获取更具体的

建议。

由于 [[spell:199484]] 是我们的核心AoE技能之一，我们的玩法大体上

在面对多个目标时不会改变。最大的变化只是确保

在怪物被聚拢时，用 [[spell:1227280]] 或 [[spell:34914]] 给目标挂上DoT

当怪物群被聚拢时。

2.3.1.

##### 优先级列表

在开始战斗前，确保你拥有 [[spell:232698]] 和

[[spell:21562]] 激活，然后使用 [[spell:34914]] 开始

战斗。

1. 在尽可能多的目标上保持 [[spell:589]] 和 [[spell:34914]]。
   
   
   
   
   注意，拥有 [[spell:238558]] 时，你应该始终使用
   
   
   
   
   [[spell:34914]] 来刷新这两个DoT中的任意一个，
   
   
   
   
   除非你在移动。 [[spell:1227280]] 应尽可能使用
   
   
   
   
   这样你就不会浪费时间手动给每只怪挂DoT。
2. 冷却完毕时施放 [[spell:228260]]。
3. 冷却完毕时施放 [[spell:10060]]（确保施放在拥有 [[spell:373466]] 的队友身上）。
4. 将狂乱值消耗在 [[spell:335467]] 上。
5. 冷却完毕时施放 [[spell:1240401]]。
6. 可用时施放 [[spell:8092]] 以生成狂乱值。
7. 施放 [[spell:263165]]。
8. 如果你还有任何充能可用，施放 [[spell:1227280]]。
9. 当目标进入斩杀范围时施放 [[spell:32379]]。
10. 施放 [[spell:15407]] 作为填充法术来生成狂乱值。

:::details **如何快速提升**
**保持全局冷却时间不空转**

- 在当前施法结束前排队下一个施法，这样整场战斗中就不会损失施法次数。

**规划移动**

- 使用瞬发施法进行走砍，例如

[[spell:1240401]]

,

[[spell:32379]]

，以及

[[spell:375888]]

触发效果，然后再使用

[[spell:589]]

边移动边输出。

**追踪冷却技能的使用**

- 漏放

[[spell:228260]]

,

[[spell:10060]]

，或者

[[spell:263165]]

通常比小幅度的属性或装备差异造成的DPS损失更大。

:::

2.3.2.

##### 巅峰天赋： ![Void Apparitions Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) 虚空幻灵

一旦你解锁了巅峰天赋，关键是绝不能让

[[spell:1227280]]停留在最大充能层数。理想情况下，你应该

定期使用这个冷却技能，尤其是在爆发期间，以获得更多我们神像法术的触发

以及[[spell:341491]]。

2.3.3.

##### 第2赛季套装

本赛季作为暗影牧师，你可以获得以下套装加成：

- 2件套效果：[[spell:1296579]] - [[spell:1227280]]的冷却时间缩短
  
  
  
  
  ```
  reduced by 3 sec and its damage is increased by 100%.
  ```
- 4件套效果：[[spell:1296580]] - [[spell:1227280]]有100%
  
  
  
  
  ```
  chance to grant a free use of [[spell:1240401]] at 100% effectiveness.
  ```

从循环角度来看，这个套装加成将使[[spell:1227280]]成为你

输出循环中更核心的部分，允许更多的施法和触发，从而获得使用

[[spell:1240401]].

比以往任何时候都更关键的是，绝不能让[[spell:1227280]]停留在最大充能层数。

当你施放它时，你会获得一次[[spell:1240401]]的免费施放，所以你想要

确保你也穿插施放虚空齐射。

### 暗影牧师防御法术

2.4.

#### 暗影牧师的防御法术

暗影牧师可以使用许多防御法术。使用以下列表

来帮助在承受伤害时存活下来。

- [[spell:47585]]是你最大的主动防御技能，应该
  
  
  
  
  在你处于危急情况时使用，或者用来帮助减轻一次巨大的 incoming 伤害。
  
  
  
  
  在效果持续期间，你无法施法，但你可以再次施放该法术
  
  
  
  
  来提前取消它。
- [[spell:19236]]既是一个中等程度的治疗，也是一个
  
  
  
  
  防御技能，通过增加你的生命值上限。这可以在特定情况下救你一命
  
  
  
  
  并且非常强大，尤其是配合职业天赋树中的[[spell:238100]]或
  
  
  
  
  [[spell:373450]]时。
- [[spell:586]]配合点出[[spell:373446]]天赋，可以将这个法术变成一个
  
  
  
  
  低冷却的防御技能，应该尽早且频繁使用以减少承受的
  
  
  
  
  伤害。
- [[spell:2061]]配合点出[[spell:193063]]天赋，可以将一个
  
  
  
  
  小型治疗法术变成另一个主动防御法术，我们可以将其与
  
  
  
  
  [[spell:586]]叠加，在需要时获得大约20%的伤害减免。
- [[spell:17]]是你最后的手段之一，可以通过
  
  
  
  
  在施放时为自己提供一个小护盾来挽救你的生命。

### 暗影牧师属性优先级

2.5.

#### 暗影牧师的属性优先级

在游玩暗影牧师时，你可以按照

以下优先级作为大致指南来选择装备。这只应该被用作

一个起点，因为针对特定装备升级对你的角色进行模拟

永远是最准确的。

关于本页呈现内容的更多信息，请查看我们的主要

[属性优先级页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>).

装备等级

急速

精通

暴击

全能

通常，你会寻找急速/精通的装备，但由于

智力的强大属性，任何高装等的装备都是一个

很好的起点。在熟悉战斗机制的过程中，堆叠急速会让你获得更多收益，

因为它比其他属性更能帮助你弥补失误。

某些配置在追求极致最优时会偏向精通而非急速，但作为一个

新玩家，优先选择急速会让专精更流畅，总体容错率更高。

当你对专精熟悉后，可以参考属性页面的

指南来确定你的属性优先级。

### 暴风雪战斗助手

2.6.

#### 暗影牧师战斗助手

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 是一种让新手玩家无需

完全理解整个循环优先级列表就能上手游戏的方式。启用

该功能后，你可以使用一个动态更新的单键助手。这将

按照预设的顺序自动循环施放你的法术。

作为一名暗影牧师，这个助手不会为你使用所有法术，只会使用

常用的循环法术。你需要手动穿插以下主要冷却

法术，才能充分利用这个工具：

- [[spell:228260]]
- [[spell:10060]]
- 主动使用饰品
- 战斗药水：[[item:241308]]
- 种族技能，如[[spell:33697]]或[[spell:26297]]

通过使用这个助手并穿插你的冷却技能，你将发挥出

尽可能好的水平。游戏平衡这一点的方式是增加基础

公共冷却时间来减缓你的游戏节奏。考虑到这一点，你可以预期

DPS比不使用助手的玩家低大约15%。

这个工具是深入了解游戏的好方法，一旦你熟悉了，试着自己

打循环，以进一步提升你的游戏水平！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月6日：** 添加一个包含核心执行技巧的'如何快速提升'字段集。
- **2026年4月4日：** 在近期热修后更新天赋构筑。
- **2026年3月18日：** 更新范围伤害构筑。
- **2026年3月16日：** 已更新第一赛季的循环章节。
- **2026年2月26日：** 已针对 至暗之夜 上线更新天赋构筑。
- **2026年2月10日：** 已针对职业点数门槛的更改更新天赋树。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月29日：** 在第三赛季上线后进行了审阅。
- **2025年8月7日：** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 添加关于战斗助手的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月13日：** 从虚空编织者多目标构建中移除舒展黑暗。
- **2025 年 2 月 28 日：** 从虚空编织者单体目标构建中移除舒展黑暗。
- **2025 年 2 月 24 日：** 针对11.1.0更新，新增天赋构建。
- **2024年12月15日：** 简化循环部分。
- **2024年11月4日：** 新增易于复制的天赋字符串，并更新光环在循环部分中的位置。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年10月6日：** 将虚空编织者AoE配装更新为默认使用暗影之拥。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战的上线更新了配装和输出循环。
- **2024年8月13日：** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年7月25日：** 更新天赋配置，在恩佐斯的肖像仍然存在错误时不再使用它。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月25日：** 添加第4赛季新视频播放列表。
- **2024年4月22日：** 为第4赛季更新天赋配置。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 更新10.2.5版本的默认天赋配置，使其更加全面。
- **2023年11月6日：** 已更新天赋构筑，并为10.2.0补丁添加循环目标。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月13日：** 更新视频链接。
- **2023年7月23日：** 已根据近期热修进行审阅。
- **2023年7月10日：** 为10.1.5添加新的天赋字符串。
- **2023年6月27日：** 更新默认构筑。
- **2023年6月20日：** 添加关于扭曲现实的说明。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5的构筑更新天赋。
- **2022年12月21日：** 更新天赋建议，使其更简单易上手。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月7日：** 更新了玛里莱斯灵魂羁绊计算器以移除不谐回声之力。
- **2022年10月31日：** 更新天赋构筑以不再建议心灵链接。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面，你将找到魔兽世界12.1.5补丁中暗影牧师的最佳天赋。我们还为不同类型的活动（如团队副本或大秘境）提供了默认天赋构建。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 暗影牧师的至暗之夜最佳天赋

作为至暗之夜第2赛季中的暗影牧师，我们

可以自由选择任一英雄天赋树，而且两者

都非常强大。我们强烈建议从

使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者开始，然后根据情况调整为

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官，如果你想要更持续的伤害模式的话。

要查看两种专精的完整详细天赋配置，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者，请使用该工具

来根据你想要的英雄天赋树切换推荐方案。

请注意，你选择的天赋树将影响

<em>整个页面，</em> 信息将根据

该选择进行调整。

:::details 常见问题：如果我还在使用第1赛季的套装或没有第2赛季的套装，我应该使用赛季前的构建吗？
如果你仍然在使用第1赛季套装，或者还没有任何第2赛季套装，你应该避免使用

[[spell:1242666]]

和

[[spell:1279354]]

天赋方案。相反，将那些点数从使用它们的天赋方案中移出，改加到

[[spell:377349]]

以及天赋树中间部分的合适天赋上。

:::

**快速开始导入代码：**

:::talents 暗影团本 - 执政官
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

:::talents 暗影AoE - 虚空编织者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents 暗影地下堡 - 虚空编织者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYmx2MYmZmZDZGLb0AMzMDAEgZb2WAzGDAMwMzMzMbMDmZwMYA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

执政官

团队副本

推荐

秘境+

地下堡

虚空编织者

团队副本

秘境+

推荐

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官团本天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 暗影牧师的核心循环围绕着施放[[spell:120644]]来强化[[spell:228260]]。在大多数团本战斗中使用此天赋作为你的默认方案。

:::details 常见问题 如果我还没有第2赛季4件套，应该导入什么？
使用这个替代的无4件套导入字符串：

:::talents 执政官团本 - 无第2赛季4件套
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAgxMMjx2MDzsNzwMjtZMmZmBmMwMNzAzAMzmZ0sZAIjxCAmBYMzMjZbMz2yAMDGA"
}
```
:::

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) 点击查看按Boss分类的团本天赋选项
虽然上面的团本天赋是你在大多数战斗中的默认方案，但你可以进行一些天赋替换以获得更优的表现。

1.1.1.

##### [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

这个Boss是纯单体目标，所以我们不需要点出[[spell:199484]]。

:::talents 执政官团本 - 斯索拉克
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

- **点出**: [[spell:407469]]
- **放弃**: [[spell:199484]]

1.1.2.

##### [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)

这个Boss是一个分散站位的双目标战斗，所以我们移除部分[[spell:1227280]]的伤害，因为我们无法用猛击同时击中两个目标。

:::talents 执政官团本 - 陵寝哨兵
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAMmZxMGbzMmZ2mBzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

- **点出**：[[spell:407469]] 和 [[spell:377349]]
- **放弃**：[[spell:1242666]] 和 [[spell:1279354]]

1.1.3.

##### [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)

这个Boss是一个三目标战斗，所以我们可以更多地投入到持续伤害天赋上。

:::talents 执政官团本 - 失落的探险者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPAAAAAAAAAAAAghZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZMYMzMjZjZ2WGgZwA"
}
```
:::

- **点出**：[[spell:1242862]] x2 和 [[spell:377349]]
- **放弃**：[[spell:391151]] x2 和 [[spell:373212]] x1

1.1.4.

##### [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

这个Boss有大量的多目标场景以及许多血量较低的小怪。因此，你可以根据自己的需求选择调整一些天赋。

下面的字符串是3目标天赋配置，然后在其中舍弃[[spell:454001]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官天赋树中放弃[[spell:449874]]，换取[[spell:449874]]。这是一个小的优化，能为团队提供更多的治疗和更广泛的小怪伤害。你通常会将[[spell:228260]]与伤害增益对齐，该增益只持续20秒，之后就没有目标可打了，所以额外的持续时间用处不大。出于类似的原因，你也可以用[[spell:341240]]代替[[spell:341240]]，以在该窗口期获得更多爆发，但这通常会在整场战斗中损失伤害。

在英雄难度下，你可能可以保留[[spell:391151]]和[[spell:373212]]以获得更多对Boss的伤害，但在史诗难度下，我会考虑使用[[spell:1242862]]和[[spell:377349]]。

:::talents 执政官团本 - Ulatek（英雄）
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZZmxMz2MGzw2MzYmZGbIzYxMNAzAMziZY2MAkxYBAzMIjZmZMbMz2yAMTMA"
}
```
:::

:::talents 执政官团本 - Ulatek（史诗）
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDPAAAAAAAAAAAAghZxMmZZmxMz2MGzw2MzYmZGbIzYxMNAzAMziZY2MAkxYBAzMGZMzMjZjZ2WGgZiB"
}
```
:::

- **点出**：[[spell:341240]]、[[spell:449874]]、[[spell:1242862]] x2 和 [[spell:377349]]
- **放弃**：[[spell:341240]]、[[spell:454001]]、[[spell:391151]] x2 和 [[spell:373212]] x1

:::

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 史诗钥石地下城配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官在你需要大量AoE持续伤害时表现出色。如果你刚开始你的地下城之旅，或者只是在不配合的队伍中混钥匙，一开始可能会感觉有些迟缓，你应该考虑尝试
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者。

我建议在大多数情况下默认使用[[spell:238558]]，但在有足够准备和良好操作的情况下，你也可以在地下城中使用[[spell:1279350]]。

:::details 常见问题 如果我还没有第2赛季4件套，应该导入什么？
使用这个替代的无4件套导入字符串：

:::talents 执政官AoE - 无第2赛季4件套
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYGgZ2MjmNDAZMWAwMAjZmZMbjZ2WGgZwA"
}
```
:::

:::

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官地下堡天赋

这个天赋方案是专门为 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 在至暗之夜第2赛季中设计的。专精天赋树与地下城天赋几乎相同，但职业天赋树进行了大量修改，以优先考虑在地下堡中有用的功能性天赋。

- [[spell:205364]] - 可用于控制一个额外的敌人，帮助你通过困难的区域。
- [[spell:9484]] - 强力的控制技能，尽可能使用。
- [[spell:1250378]] - 将[[spell:586]]变成一个小型嘲讽，允许你使用治疗或伤害专精与瓦莉拉配合。
- [[spell:528]] 和 [[spell:32375]] - 轻松移除敌人身上的恶心减益效果。
- [[spell:213634]] - 轻松驱散你身上的疾病效果。
- [[spell:108942]] - 使[[spell:586]]也能移除某些移动受限效果。

**注意：** 这个天赋方案特意放弃了[[spell:373466]]以获得更多功能性。如果你是与另一名玩家组队，请考虑将此天赋加回你的天赋树中。

[[spell:32379]]已从该方案中移除，因为它的伤害贡献已经相当低。这使我们能够获得更多功能性天赋。

:::details 常见问题 如果我还没有第2赛季4件套，应该导入什么？
对于地下堡，请使用这个替代的AoE无4件套导入字符串：

:::talents 执政官地下堡 - 无第2赛季4件套
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYGgZ2MjmNDAZMWAwMAjZmZMbjZ2WGgZwA"
}
```
:::

:::

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者团队副本构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 暗影牧师的核心循环围绕着施放[[spell:263165]]来制造一个[[spell:447444]]并尽可能多地施放[[spell:450405]]。在大多数团本战斗中使用此天赋作为你的默认方案。

:::details 常见问题 如果我还没有第2赛季4件套，应该导入什么？
使用这个替代的无4件套导入字符串：

:::talents 虚空编织者团本 - 无第2赛季4件套
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAgxMMjx2MDzsNzwMsNzMmZmxGyMWMTDwMzMAQAmtZbJY2YAmBYMzMjZbMDmZwMYA"
}
```
:::

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) 点击查看按Boss分类的团本天赋选项
虽然上面的团本天赋是你在大多数战斗中的默认方案，但你可以进行一些天赋替换以获得更优的表现。

1.4.1.

##### [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

这个Boss是纯单体目标，所以我们不需要点出[[spell:199484]]。

:::talents 虚空编织者团本 - 斯索拉克
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAAegZxMmZbmBz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

1.4.2.

##### [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)

这个Boss是一个分散站位的双目标战斗，所以我们移除部分[[spell:1227280]]的伤害，因为我们无法用猛击同时击中两个目标。

:::talents 虚空编织者团本 - 陵寝哨兵
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMjZGAAAAAAAAAAAgxDMLmxYbmhZ2mZYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGz2YGMzgZwA"
}
```
:::

1.4.3.

##### [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)

这个Boss是一个三目标战斗，所以我们可以更多地投入到持续伤害天赋上。

:::talents 虚空编织者团本 - 失落的探险者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMj5BAAAAAAAAAAAAgZxMzMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwMMmZmxsNmBzMYGMA"
}
```
:::

:::

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者大秘境构建

这个天赋是你进入地下城或其他AoE场景的起点。这些天赋在打出优秀AoE伤害的同时，在AoE期间也能对优先目标造成可观的伤害，并且单体伤害也不错。

我建议在大多数情况下默认使用[[spell:238558]]，但在有足够准备和良好操作的情况下，你也可以在地下城中使用[[spell:1279350]]。

:::details 常见问题 为什么这个天赋方案不使用[[spell:406788]]？
目前

[[spell:8092]]

甚至

[[spell:450405]]

与其他法术相比相当弱。除此之外

[[spell:406788]]

处于一个很难点出的位置，因为我们的天赋树顶部区域非常拥挤，尤其是当它被

[[spell:199484]]

锁定时。此外，心灵震爆本身不再产生

[[spell:341491]]

，这严重影响了该法术的价值。幸运的是

[[spell:375888]]

有助于弥补这一损失。

:::

:::details 常见问题 如果我还没有第2赛季4件套，应该导入什么？
使用这个替代的无4件套导入字符串：

:::talents 虚空编织者AoE - 无第2赛季4件套
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

:::

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者地下堡天赋

这个天赋方案是专门为 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 在至暗之夜第2赛季中设计的。专精天赋树与地下城天赋几乎相同，但职业天赋树进行了大量修改，以优先考虑在地下堡中有用的功能性天赋。

- [[spell:205364]] - 可用于控制一个额外的敌人，帮助你通过困难的区域。
- [[spell:9484]] - 强力的控制技能，尽可能使用。
- [[spell:1250378]] - 将[[spell:586]]变成一个小型嘲讽，允许你使用治疗或伤害专精与瓦莉拉配合。
- [[spell:528]] 和 [[spell:32375]] - 轻松移除敌人身上的恶心减益效果。
- [[spell:213634]] - 轻松驱散你身上的疾病效果。
- [[spell:108942]] - 使[[spell:586]]也能移除某些移动受限效果。

**注意：** 这个天赋方案特意放弃了[[spell:373466]]以获得更多功能性。如果你是与另一名玩家组队，请考虑将此天赋加回你的天赋树中。

[[spell:32379]]已从该方案中移除，因为它的伤害贡献已经相当低。这使我们能够获得更多功能性天赋。

:::details 常见问题 如果我还没有第2赛季4件套，应该导入什么？
对于地下堡，请使用这个替代的AoE无4件套导入字符串：

:::talents 虚空编织者地下堡 - 无第2赛季4件套
```json
{
  "code": "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGbzMmZWmZYmx2MGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

:::

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZY2MAkxYBAzMgxMzMmNmZbZAmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx5NSWqMRdlksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZWmxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx5NSqMRdZkksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbjxMzyMGzM2mBzMzMbIzYZjGgZAmZzMMbGAyYsAgZGgZmZmZ2YmtlBYGMA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04c1py26+eoogawwYaeKUcI9J74C-ZaCT7Uhx5NSWqMdZkksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAegZxMzMbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtFwsxAADGzMzY2YGMzgZwA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx159MRdlosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYmx2MYmZmZDZGLb0AMzMDAEgZb2WAzGDAMwMzMzMbMDmZwMYA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04c1py26+eoogawwYaeKUMb6wz4C-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

上面列出的构建是热门推荐，

涵盖了适合每种终局内容风格的各种不同配装。

每个天赋方案都有其自己的输出循环，也可以根据

特定类型的内容进一步调整，以更好地造福你的队伍。

1.

### 全知典籍

在至暗之夜的 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)中加入，万灵谱在完成一个简短的任务线后解锁，并

让你从灵活的小型增益中选择。有些符文倾向于提高输出，

而另一些则提供生存能力和功能性。

将以下顺序作为你早期开荒的默认路径。由于万灵谱符文可以

随时更换，你总是可以根据战斗或你的个人

偏好进行调整，一旦你熟悉了基础选择：

1. [[spell:1279599]]
2. [[spell:1279603]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279614]]

:::details 常见问题 我应该选择哪个副属性符文？
作为暗影牧师，一般性的答案是默认选择

[[spell:1279609]]

。虽然急速和精通是我们作为暗影牧师最理想的属性，但在补丁的这个阶段我们已经拥有相当多的这些属性了。由于这些符文提供的是属性等级，这意味着它们会受到递减收益的影响，你拥有的某项属性越多，从中获得的价值就越少。在你收集装备的过程中，急速或精通符文可能会带来更高的价值，但请务必模拟一下最适合你角色的选择。

:::

1.

### 巅峰天赋： ![Void Apparitions Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_priest_voidform.jpg>) 虚空幻灵

巅峰天赋在你开始在至暗之夜中升级时解锁，作为

专精天赋树中的基石天赋。这里总共有4点可以投入，其中最后

一点影响最大。

- [[spell:1264096]]
- [[spell:1264104]]（2点）
- [[spell:1264107]]

这些天赋不仅仅是用额外的力量来封顶天赋树，它们还积极地重塑

了我们构建天赋方案的方式。虽然它们的基础功能可能很直接，

但它们的后续影响才是真正的玩法转变所在。

最明显的效果之一是它们强烈激励我们投入点数到

增强[[spell:341491]]的天赋上。由于这种协同作用，我们被强烈鼓励

围绕最大化我们的[[spell:341491]]产生和伤害来构建，这反过来

鼓励我们选择更多支持这种玩法的天赋。

拥有所有巅峰天赋的全部力量后，你还将引入新的游戏循环，

鼓励神像生成以触发更多[[spell:341491]]。这成为该专精在

至暗之夜中的核心游戏循环之一，在那里你希望尽可能多地触发神像以

生成更多[[spell:341491]]。

1.

### 英雄天赋

从71级开始，你将获得全新的英雄天赋。这就是

你可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官或 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 暗影 牧师 的玩法围绕使用

[[spell:120644]] 来强化你的 [[spell:228260]] 并施放极其强大的

[[spell:391399]] 法术。

在功能性方面 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 为你提供 [[spell:453726]]，使

耐力提高5%。这只对作为 牧师 的你自身生效。在大秘境中，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 也为你的

队伍带来重要的功能性，以 [[spell:453918]] 的形式提供额外的打断。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 暗影 牧师可以使用 [[spell:263165]] 来

创造一个高伤害的 [[spell:447444]]，对范围内的敌人造成

AoE伤害。这随后使你能在裂隙激活期间获得强化版的 [[spell:8092]]，

以 [[spell:450405]] 的形式呈现。虚空编织者 在

团队副本战斗中表现更佳，因为你可以利用

[[spell:451840]].

功能性方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 相比于

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 在团队副本中要好得多，因为它不仅拥有出色的自保

选择，如 [[spell:451311]] 或 [[spell:451569]]，还

通过 [[spell:451018]] 为 [[spell:263165]] 提供移动施放能力。

1.

### 暗影 牧师 选择天赋节点

本节旨在更详细地介绍我们拥有的各种选择

节点，位于 暗影 牧师 专精天赋树中，以及每种选择何时

比较合理。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_priest_tentacleslam.jpg>) 点击查看更多天赋信息
5.1.

#### 召唤梦魇 vs 苦难

这是最具影响力、最能定义玩法风格的选择节点之一，位于

暗影 牧师 天赋树中。[[spell:1279350]] 和 [[spell:238558]] 从根本上

改变了伤害的预热和施加方式，使得这个决定高度取决于

战斗结构和目标存活时间。

[[spell:1279350]] 最适合目标数量较少的场景，敌人

存活足够长的时间，使得手动施加 [[spell:589]] 是值得的。当这些

条件满足时，它能提供显著的伤害提升，并奖励深思熟虑、

有条不紊的玩法。虽然它在某些AoE场景中也能发挥作用，但其有效性

在目标过快死亡时会急剧下降，因为预热时间会成为负担。

[[spell:238558]] 是大多数地下城和爆发导向环境中的首选。

通过 [[spell:34914]] 自动施加 [[spell:589]]，它省去了

大量的准备工作，使 暗影 牧师 能更快进入其伤害输出模式。这使得

苦难在大秘境以及任何需要快速

换目标或敌人存活时间短的战斗中，成为更实用、更稳定的选择。

5.2.

#### 强化虚空形态 vs 远古疯狂

这个选择节点直接强化 [[spell:228260]]，几乎总是

会点出，既为了威力也为了路径规划，因为它通向关键天赋如

[[spell:407470]] 或 [[spell:409044]]。虽然两个天赋都修改同一个

冷却技能，但它们适应截然不同的伤害输出模式和英雄天赋协同。

[[spell:341240]] 通常不会被广泛使用，但在需要最大化

在想要最大化单次[[spell:228260]]伤害的特殊情况下爆发

[[spell:1240401]] 的特殊情况下可以更具爆发力。

[[spell:341240]] 是我们从第2赛季开始的默认选择，代表了

[[spell:228260]] 延长玩法风格，

增加了冷却技能的基础数值，并且与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官.

这个天赋不会改变你的玩法，但会让我们的主要冷却技能感觉

更有影响力。这也可以让你比平常少堆一些急速。

5.3.

#### 心灵之眼 vs 扭曲现实

改变我们消耗狂乱值的方式，对玩法风格和伤害输出有着重大影响，

说到游戏风格和伤害输出，正是这些造就了 [[spell:407470]]

和 [[spell:409044]] 往往是配装中一个重大选择的原因。

偏好 [[spell:407470]] 的配装通常已经有良好的

狂乱值生成能力，以便你能保持高覆盖率的

[[spell:335467]]，同时也利用能带来更多收益的互动机制

暗影言术：癫 施放次数的互动，例如生成 [[spell:341491]] 或

更长的 [[spell:375767]] 覆盖时间。

另一方面，偏好 [[spell:409044]] 的配装通常

通常当你想要最大化某个技能的覆盖率时会选择这个选项

[[spell:335467]]的覆盖率时（尤其是在装备等级较低时），会选择这个。扭曲现实

配装还可以在AoE场景中更好地传播 暗影言术：癫

以利用 [[spell:407469]] 之类的效果，如果你

愿意牺牲一些优先目标的伤害的话。

5.4.

#### 死亡代言人 vs 死亡与疯狂

这个选择节点目前是 暗影 牧师 天赋树中较弱的一环，

因为 [[spell:32379]] 目前强度不足。因此，大多数配装会

避免这两个选项，除非被路径规划或特定战斗的小怪模式所迫。虽然

[[spell:392507]] 和 [[spell:321291]] 历来协同良好，

但它们互斥导致其价值主张冲突，限制了

任一选择在实际游戏中的有效性。

两者之间，当必须花费一点时，[[spell:392507]] 通常是更优的选择，

主要是因为它提升了斩杀阶段的价值，并且

在35%生命值以下时与 [[spell:34433]] 协同更好。这在较长的Boss战中提供了更稳定的价值，

斩杀伤害在此时很重要。相比之下，[[spell:321291]]

高度依赖场景，主要用于那些频繁出现、

可预测的低血量小怪刷新且能可靠补刀的战斗。

1.

### 牧师 职业天赋选择

虽然上述配装对职业天赋有合理的默认设置，本

节将深入探讨根据你所处情况而有的各种职业

根据你所处的情况选择天赋。

6.1.

#### 始终使用的职业天赋

以下是我作为一个永远会使用的

暗影牧师始终会使用的天赋列表。这些天赋在PvE的几乎所有情况下都很有用

并且是任何配装的核心天赋。

- [[spell:8092]] - 基础技能
- [[spell:8122]] - 基础技能
- [[spell:121536]] 和/或 [[spell:64129]] -
  
  
  
  
  移动类天赋，通常我建议两个都点。
- [[spell:528]] 和 [[spell:73325]] - 用于
  
  
  
  
  规划路线和极佳的功能性。
- [[spell:10060]] 和 [[spell:373466]] -
  
  
  
  
  伤害冷却技能和强大的团队治疗功能性。
- [[spell:1250818]], [[spell:1251030]],
  
  
  
  
  [[spell:1250820]], [[spell:1251077]],
  
  
  
  
  [[spell:1251029]]、[[spell:1249230]]，以及
  
  
  
  
  [[spell:1250835]] 全部
  
  
  
  
  提供少量进攻或防御收益，我们总是会点出。
- [[spell:32379]]通常是必点的，在某些情况下
  
  
  
  
  你可以跳过这个，但那样你就需要点出 [[spell:373218]]。
- [[spell:390972]] - 斩杀 伤害，可解锁节点
  
  
  
  
  在底部区域。
- [[spell:586]] - 我们最强大的功能性和防御性法术之一。
- 使用 [[spell:368275]] 接 [[spell:19236]] 作为另一个防御手段。
- [[spell:459559]] 大幅提升我们法术的射程。
- [[spell:373446]] 将 [[spell:586]] 变为关键防御技能。

6.2.

#### 情境性职业天赋

既然你已经了解了基础建议的职业天赋，你就可以

根据你所进行的内容来完成你的天赋配置。

根据具体的团队副本首领或地下城环境，你应该

根据你的需求来调整这些选择。在某些情况下，你

可能需要更多的功能性，而在其他情况下，如果你不需要那些功能性，

你可以改为选择更多的防御性选择。

以下天赋是我们作为 牧师 的功能性选择。

你应该只在需要时才点出这些；否则，把点数

用在其他地方。

- [[spell:196704]] - 降低冷却时间
  
  
  
  
  [[spell:8122]] 的冷却时间，这有助于获得更多群体控制
  
  
  
  
  手段。
- [[spell:108942]] - 使 [[spell:586]] 也能解除减速
  
  
  
  
  效果。请注意这与定身效果不同。
- [[spell:9484]] - 对亡灵或异怪
  
  
  
  
  敌人有效的硬控制技能。
- [[spell:1250691]] - 对敌人的群体定身技能
  
  
  
  
  在 [[spell:8122]] 结束后。
- [[spell:205364]] - 将你的 [[spell:605]] 法术
  
  
  
  
  变为使敌人成为宠物的法术。这在某些
  
  
  
  
  大秘境中特别有用。这个节点也是某些
  
  
  
  
  路线选择所必需的，通常人们会仅为此原因点出它。
- [[spell:32375]] - 强大的驱散工具。
- [[spell:1250378]] 在升级时很有用。

一旦你获得了你所进行内容需要的所有功能性点数，

你就可以添加你需要的防御性点数。这部分比较棘手，

因为根据内容的不同，变化可能很大，但以下是你的选项，

大致按强度排序。

1. [[spell:390667]] - 4% 法术伤害减免
2. [[spell:390670]] - 允许你更频繁地使用 [[spell:586]]
   
   
   
   
   以获得防御价值。
3. [[spell:193063]]
4. [[spell:238100]] - 根据你要反制的机制的
   
   
   
   
   时机可能有用，但点出它的路线
   
   
   
   
   可能很繁琐。
5. [[spell:373450]] - 使 [[spell:19236]] 更强，
   
   
   
   
   但通常这种提升并不会真正改变什么会被视为
   
   
   
   
   致命的情况。
6. [[spell:108945]] - 不稳定的类诈死护盾，
   
   
   
   
   通常在你真正需要时不会触发。

:::

:::details 常见问题解答：如果我的模拟或日志与推荐的天赋配置不一致怎么办？
将推荐配置作为你的默认基准，然后只调整有争议的节点并重新测试。在比较选项时，在断定某个配置更差之前，要同时检查模拟输出和日志执行质量（施法次数、冷却时机和持续伤害覆盖率）。对于更高级的比较，可以使用公开的

[WarcraftPriests 图表](<https://warcraftpriests.github.io/>)

和

[模拟仓库](<https://github.com/WarcraftPriests/mid-shadow-priest>)

.

:::

1.

### PvP天赋（战争模式）

在开放世界中，你可以进入“战争模式”。开启战争

模式可提供以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提升 10% 以上。
- 升级时获得的经验值提升 10% 以上。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式对升级和PvE内容的好处，

建议开启此功能，以在满级时最大化你的升级速度和奖励。

然而，你会使自己可以被开放世界 PvP，

并且在升级或进行世界任务时有可能

被“偷袭”。

[暗影 牧师 PvP 指南](<https://www.icy-veins.com/wow/shadow-priest-pvp-guide>)

在本节中，我们将对最适合升级和进行

单人/小队 PvE 内容的 PvP 天赋进行排名。以下是

[暗影 牧师](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>)职业专属的

PvE 天赋排名。

- [[spell:199259]] 让你的冷却更快转好，以获得更好的
  
  
  
  
  覆盖率。
- [[spell:199445]] 非常适合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 配置，
  
  
  
  
  [[spell:391399]] 可以叠加层数。
- 最后的选择通常是 [[spell:357711]] 以获得更多总体
  
  
  
  
  伤害，不过 [[spell:375901]] 或 [[spell:211522]] 也可以作为
  
  
  
  
  更多单体目标的选择。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新虚空编织者团队副本配装。
- **2026年9月1日：** 在团队副本配装中添加乌拉特克变体。
- **2026年8月25日：** 在团队副本部分为迷失的探险者添加3目标配装。
- **2026年8月11日：** 为所有配装添加无套装变体。
- **2026年8月10日：** 在执政官大秘境配装中重新添加萦绕暗影。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7补丁更新，包含万法典籍信息。
- **2026年5月19日：** 更新 虚空编织者 三目标构筑。
- **2026年4月22日：** 为殁言先驱 虚空编织者 构筑变体添加幻象。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月10日：** 更新虚空编织者团队副本配装。
- **2026年4月9日：** 为清晰起见，重新添加专门的三目标构筑。
- **2026年4月9日：** 为三目标构筑移除扭曲现实，简化 虚空编织者 三目标配置。
- **2026年4月8日：** 从 执政官 团队副本构筑中移除心灵之眼。
- **2026年4月6日：** 添加关于基于模拟和日志调整天赋的常见问题指南。
- **2026年4月4日：** 更新 执政官 团队副本和大秘境构筑以及 虚空编织者 大秘境构筑。
- **2026年4月2日：** 为 虚空编织者 团队副本添加 暗影 言出即灭构筑变体。
- **2026年3月29日：** 更新用于团队副本的三目标天赋构筑。
- **2026 年 3 月 22 日：** 为团队副本添加三目标构筑。
- **2026年3月18日：** 更新大秘境和地下堡天赋构筑。
- **2026年3月16日：** 构筑已针对第一赛季的上线进行审阅。
- **2026年2月26日：** 已针对 至暗之夜 资料片的上线更新了新的构筑。
- **2026年2月10日：** 已针对职业点数门槛的更改更新天赋树。
- **2026年1月23日：** 为前瞻补丁添加了更多常见问题条目。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月26日：** 添加视频指南。
- **2025年8月7日：** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 审阅11.1.7补丁的信息。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月2日：** 更新执政官单体目标构建，移除尤格-萨隆。
- **2025 年 2 月 24 日：** 新增11.1.0天赋构建。
- **2024年12月15日：** 建议大多数内容从执政官构建开始。
- **2024年11月4日：** 更新心灵之眼与扭曲现实部分，使其更加清晰。
- **2024年10月21日：** 对于 执政官 配装，已默认改为使用持续效能来处理脱战暂停机制。
- **2024年10月10日：** 虚空编织者配装使用精神衰竭，单体+崩裂变体使用无法逃脱的折磨。大元帅的统御之力在大秘境中现在是可选的。
- **2024年10月9日：** 为虚空编织者团队配装将虚空编织者替换为暗影之拥。
- **2024 年 10 月 7 日：** 根据最近的热修复更新天赋配装。
- **2024年9月15日：** 重构天赋配装章节使其更易于使用。
- **2024年9月13日：** 将默认地下堡配装更新为使用执政官。
- **2024年9月9日：** 为执政官大秘境配装添加变体以获得更多单体能力。
- **2024年8月31日：** 更新 虚空编织者 单体 + 暗影 崩塌构筑，为地下堡构筑添加黑暗蔓延，并将 执政官 AOE 整合为一个构筑。
- **2024年8月25日：** 添加了地下堡构筑和赛前 执政官 地下城变体，并调整了 执政官 对比 虚空编织者 的百分比差异。
- **2024年8月21日：** 为《地心之战》上线更新天赋配置。
- **2024年8月13日：** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年7月25日：** 更新天赋配置，在恩佐斯的肖像仍然存在错误时不再使用它。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月30日：** 在大秘境天赋配置中添加关于疯狂之触的说明。
- **2024年4月25日：** 添加新天赋视频。
- **2024年4月22日：** 为第4赛季更新所有天赋配置，并用一份深入的职业天赋指南替换天赋路径部分。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月13日：** 更新大秘境天赋配置中的默认职业天赋和功能选择。
- **2024年1月21日：** 根据近期增益更新3目标议会战天赋配置。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024年1月15日：** 为单体目标 + 暗影坠落配置添加可选变更，并更新3目标议会配置。
- **2023年12月19日：** 移除过时的部分并调整精神鞭笞选项。
- **2023年12月18日：** 更新默认大秘境天赋配置中的可选天赋点，并更新3目标议会战天赋配置。
- **2023年12月18日：** 添加关于暗影坠落配置在单体目标中损失的说明。
- **2023 年 12 月 12 日：** 更新默认大秘境天赋配置，不再使用尤格萨隆偶像。
- **2023年12月3日：** 更新默认大秘境天赋配置以使用精神鞭笞。
- **2023年12月1日：** 更新3目标议会战天赋配置，默认使用精神鞭笞。
- **2023年11月17日：** 更新3目标和秘境+构筑，使其更加精简。
- **2023年11月14日：** 为单体目标 + 暗影坠落配置添加精神鞭笞配置选项。
- **2023年11月6日：** 为10.2补丁和第3赛季更新天赋构筑和建议。
- **2023年9月4日：** 重新组织标题使其更易读，并移动天赋法术详解。
- **2023年8月18日：** 修正三神像暗影化身构筑描述中的错别字。
- **2023年8月13日：** 阐明高层钥匙中三神像配置的注释，并更新视频链接。
- **2023年8月8日：** 修复暗影化身单体目标构筑未使用扭曲现实的问题。
- **2023年8月7日：** 根据近期热修添加新构筑。
- **2023年7月31日：** 默认为暗影化身单体构筑切换到扭曲现实。
- **2023年7月25日：** 添加暗影化身+暗影崩塌构筑。
- **2023年7月23日：** 已根据近期热修进行审阅。注明了单体目标构筑之间的差异。
- **2023年7月17日：** 重构以使用新的天赋布局。
- **2023年7月10日：** 更新10.1.5补丁的天赋字符串。
- **2023年6月28日：** 在暗影化身构筑中将诅咒之语换为死亡代言人。
- **2023年6月27日：** 根据近期热修添加新的天赋构筑。
- **2023年6月23日：** 调整关于扭曲现实的注释。
- **2023年5月2日：** 关于灵活天赋点的小提示
- **2023年5月1日：** 为10.1.0重做更新天赋配置。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月4日：** 更新双目标天赋配置，并添加关于单体目标使用暗影魔的说明。
- **2023年1月24日：** 更新10.0.5补丁的天赋构筑。
- **2023年1月11日：** 根据近期的改动更新大秘境天赋构筑。
- **2022年12月23日：** 更新天赋构筑以考虑虚空尖啸的错误。
- **2022年12月13日：** 添加提供更高爆发的备选单体构筑。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月31日：** 更新天赋构筑以不再建议心灵链接，并将默认大秘境构筑改为尤格-萨隆。
- **2022年10月26日：** 根据近期发现的虚空尖啸错误更新了天赋构筑。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标情况下优化你的 暗影 牧师 的输出循环。我们还有关于冷却、触发效果等方面的进阶内容，以最大化你的 DPS。我们所有内容均针对《魔兽世界》12.1.5 版本更新。

1.

### 暗影 牧师 游戏手法与输出循环指南

该 [暗影 牧师](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>) 输出循环是一种攒能-耗能的玩法风格，专注于维持持续伤害效果并将疯狂值用于 [[spell:335467]]。用短冷却法术产生疯狂值，并消耗它来刷新疯狂，同时避免疯狂值溢出。

**总结：** 保持 [[spell:34914]] + [[spell:589]] 挂在目标身上，将疯狂值用于 [[spell:335467]]（剩余时间少于1秒或疯狂值缺口少于35时刷新），使用 [[spell:8092]] 以避免损失它们的冷却时间，并同步 [[spell:228260]] + [[spell:10060]] 用于爆发窗口。

关于12.1补丁中 暗影 牧师 变化内容的视频讲解， [请查看 Publik 的这个视频](<https://www.youtube.com/watch?v=2OS9e2aMAlw>).

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

单体目标

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:1279350]]

[[spell:238558]]

[[spell:407470]]

[[spell:409044]]

[[spell:228260]]

[[spell:1227280]]

[[spell:373310]]

[[spell:34433]]

[[spell:373427]]

[[spell:373202]]

[[spell:392507]]

[[spell:200174]]

[[spell:375888]]

[[spell:1264107]]

[[spell:1279353]]

[[spell:1296580]]

### 暗影 牧师 讲解

1.1.

#### 暗影 牧师 单体循环目标

这些目标描述了驱动下方优先级列表的核心法术。

1. **适用条件：触须猛击（启用）。** 始终保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。如果可用，使用 [[spell:1227280]] 来施加或刷新。
2. **适用条件：触须猛击（未启用）。** 始终保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。
3. 保持 [[spell:335467]] 的激活时间，同时不要让疯狂值溢出。
4. **适用条件：虚空形态（启用）。** 使用短冷却时间的疯狂值生成技能（例如 [[spell:1240401]] 或 [[spell:8092]]）。
5. **适用条件：虚空形态（未启用）。** 使用短冷却时间的疯狂值生成技能（例如 [[spell:8092]]）。
6. **适用条件：虚空编织者（启用）。** 当使用长冷却技能（例如 [[spell:263165]]）不会导致你损失短冷却技能的使用时，使用它们。
7. **适用条件：执政官（启用）。** 当使用长冷却技能（例如 [[spell:120644]]）不会导致你损失短冷却技能的使用时，使用它们。
8. 当没有更高优先级的技能可用时，使用 [[spell:15407]] 填充。

**适用条件：执政官（启用）。**

:::details 常见问题我应该始终完成精神鞭笞的引导吗？
不应该。

[[spell:15407]]

被视为填充法术，这意味着只有在没有其他更重要的法术可以施放时才会使用它。你通常需要在引导进行到大约一半时开始考虑重新施放精神鞭笞。

[[spell:391399]]

只有 1 个 GCD 长，因此无法提前结束。

:::

**适用条件：执政官（未启用）。**

:::details 常见问题我应该始终完成精神鞭笞的引导吗？
不应该。

[[spell:15407]]

被视为填充法术，这意味着只有在没有其他更重要的法术可以施放时才会使用它。你通常需要在引导进行到大约一半时开始考虑重新施放精神鞭笞。

:::

如果你能正确掌握这些目标，循环应该会变得更加清晰，并且自然而然地流畅运作。剩下的只是进一步追求极致优化。

1.2.

#### 暗影 牧师 AoE循环目标

**适用条件：触须猛击（未启用）。** **警告** 上方表格中未选择 [[spell:1227280]]，或者你未使用 AoE 预设。请在上方选择此选项以查看准确的 AoE 建议。作为 暗影 牧师，在没有此技能的情况下进行 AoE 内容将会非常痛苦。

暗影 牧师 的多目标循环与上方的单体优先级列表非常相似，只有很小的差异。我们的 AoE 伤害主要通过良好地执行单体循环来解锁。如果你能做好这一点，你只需要保持 DoT，一切就会自然而然地到位。

在 AoE 期间，你将使用任何可用的手段在多个目标上保持 [[spell:34914]] 和 [[spell:589]]。你应该尝试在大约最多 12 个目标上保持这些 DoT。[[spell:1227280]] 应该能够覆盖 6 个聚集的目标。你最初可以通过 2 次施放让最多 12 个目标挂上 DoT，但在某些情况下，你需要手动刷新以补充大量目标数。不要费心手动给任何存活时间不足 18 秒的目标挂 DoT。

作为一名 暗影 牧师，你应该发挥你在优先目标伤害上的优势，在处理 AoE 时将 [[spell:335467]] 的施放集中到血量最高的优先目标敌人身上。不过，将这些分散开来也可以提升 AoE 伤害，但在大秘境中不建议这样做。请查看下方关于 暗影 Word: Madness 的专门章节以了解更多信息。

**适用条件：扭曲现实（启用）。** 使用 [[spell:409044]] 时，你可以选择通过每次拥有足够疯狂值施放时对新目标施放来分散 [[spell:335467]]。在某些情况下，这可以带来总体伤害的提升，尤其是对于存活时间长的目标。

1. **适用条件：触须猛击（启用）。** 使用 [[spell:1227280]] 来启动你的 DoT。如果你在拉怪时此技能正在冷却中，你需要尽力在穿插其他法术的同时手动给尽可能多的目标挂上 DoT。
2. 此时，你的最高优先级是保持 DoT。你应该选择一个主要优先目标来集中施放你的 [[spell:335467]]。这通常是血量最高的目标或特别强大的敌人。
3. **适用条件：虚空形态（启用）。** 使用短冷却时间的疯狂值生成技能（例如 [[spell:1240401]] 或 [[spell:8092]]）。
4. **适用条件：虚空形态（未启用）。** 使用短冷却时间的疯狂值生成技能（例如 [[spell:8092]]）。
5. **适用条件：虚空编织者（启用）。** 当使用长冷却技能（例如 [[spell:263165]]）不会导致你损失短冷却技能的使用时，使用它们。
6. **适用条件：执政官（启用）。** 当使用长冷却技能（例如 [[spell:120644]]）不会导致你损失短冷却技能的使用时，使用它们。
7. 当没有更高优先级的技能可用时，使用 [[spell:15407]] 填充。

### 单体输出循环

1.3.

#### 暗影 牧师 单体起手式

这些起手式假设没有触发效果，是循环的一个简短快照。请参考下方的优先级列表以了解变化和触发驱动的改变。

**适用条件：牧师 暗影 12.1 职业套装 4件套（启用）；触须猛击（启用）。**

[[spell:8092]]

**适用条件：触须猛击（未启用）。**

[[spell:34914]]

**适用条件：触须猛击（启用）。**

[[spell:1227280]]

**适用条件：召唤梦魇（启用）。**

[[spell:589]]

**适用条件：执政官（启用）。**

[[spell:120644]]

**适用条件：牧师 暗影 12.1 职业套装 4件套（启用）。**

[[spell:1240401]]

**适用条件：虚空形态（启用）。**

[[spell:228264]]

[[spell:10060]]

[[item:241288]]

[[item:250215]]

**适用条件：牧师 暗影 12.1 职业套装 4件套（未启用）。**

[[spell:1240401]]

[[spell:335467]]

**适用条件：虚空编织者（启用）。**

[[spell:263165]]

战斗开始前，确保你已激活 [[spell:232698]] 和 [[spell:21562]]。

1. **适用条件：触须猛击（未启用）。** 预读 [[spell:34914]]。
2. **适用条件：牧师 暗影 12.1 职业套装 4件套（启用）；触须猛击（启用）。** 预读 [[spell:8092]]。
3. **适用条件：触须猛击（启用）；牧师 暗影 12.1 职业套装 4件套（未启用）。** 预读 [[spell:1227280]]。
4. **适用条件：触须猛击（启用）；牧师 暗影 12.1 职业套装 4件套（启用）。** 施放 [[spell:1227280]]。
5. **适用条件：召唤梦魇（启用）。** 施放 [[spell:589]]。
6. **适用条件：执政官（启用）。** 施放 [[spell:120644]]。
7. **适用条件：牧师 暗影 12.1 职业套装 4件套（启用）。** 施放 [[spell:1240401]]。
8. **适用条件：虚空形态（启用）。** 施放 [[spell:228260]]。
9. 使用你装备的任何主动饰品。
10. 使用 [[item:241288]]。
11. 施放 [[spell:10060]] 以及任何基于属性的种族技能。如果使用 [[spell:373466]]，请确保对队友施放 能量灌注。
12. **适用条件：牧师 暗影 12.1 职业套装 4件套（未启用）。** 施放 [[spell:1240401]]。
13. 施放 [[spell:335467]]。
14. **适用条件：虚空编织者（启用）。** 施放 [[spell:263165]]。
15. 继续按照下面描述的优先级列表进行。

1.4.

#### 暗影 牧师 单体优先级列表

以下是用于单体战斗基准的精简优先级列表。如需更轻松的入门介绍，请参阅 [新手页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>).

1. **适用条件：苦难（启用）；触须猛击（未启用）。** 通过使用 吸血鬼之触 同时施加两个 DoT 来保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。在适当的传染窗口期内刷新它们（见下文）。
2. **适用条件：召唤梦魇（启用）；触须猛击（未启用）。** 保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。在适当的传染窗口期内刷新它们（见下文）。
3. **适用条件：苦难（启用）；触须猛击（启用）。** 通过使用 吸血鬼之触 同时施加两个 DoT 来保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。当你需要刷新 [[spell:34914]] 时，如果可用则使用 [[spell:1227280]]。在适当的传染窗口期内刷新它们（见下文）。
4. **适用条件：召唤梦魇（启用）；触须猛击（启用）。** 保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。当你需要刷新 [[spell:34914]] 时，如果可用则使用 [[spell:1227280]]。在适当的传染窗口期内刷新它们（见下文）。
5. **适用条件：执政官（启用）。** 施放 [[spell:120644]]。
6. **适用条件：虚空形态（启用）。** 施放 [[spell:228260]]。
7. 施放 [[spell:10060]]。
8. 将你的任何饰品与你的冷却技能同步使用（见饰品章节）。
9. **适用条件：虚空编织者（启用）。** 如果目标有 [[spell:451840]] 的吸收护盾，则施放 [[spell:32379]]。
10. **适用条件：心灵 噬灭（未启用）。** 保持 [[spell:335467]] 的激活时间，同时不要让疯狂值溢出。当它即将过期、你即将达到疯狂值上限，或在 [[spell:228260]] 期间以保持爆发窗口激活时刷新它。如果虚空形态将在 25 秒或更短时间内可用，请积攒疯狂值。
11. **适用条件：心灵 噬灭（启用）。** 保持 [[spell:335467]] 的激活时间，同时不要让疯狂值溢出。当它即将过期、你即将达到疯狂值上限、[[spell:373202]] 处于激活状态，或在 [[spell:228260]] 期间以保持爆发窗口激活时刷新它。如果虚空形态将在 25 秒或更短时间内可用，请积攒疯狂值。
12. **适用条件：虚空编织者（启用）。** 如果 [[spell:335467]] 处于激活状态或 [[spell:447444]] 即将过期，则在可用时施放 [[spell:450405]]。
13. **适用条件：触须猛击（启用）。** 如果你即将达到充能次数上限或 [[spell:34914]] 未处于激活状态，则施放 [[spell:1227280]]。
14. **适用条件：虚空编织者（启用）。** 施放 [[spell:263165]] 以开启 [[spell:447444]]。
15. 施放 [[spell:8092]]。
16. **适用条件：触须猛击（启用）；虚空幻影（启用）。** 如果没有即将到来的小怪需要你保留一次充能，则完全消耗 [[spell:1227280]] 的充能次数。
17. **适用条件：执政官（启用）。** 如果 [[spell:335467]] 处于激活状态，则施放 [[spell:391399]]。
18. **适用条件：亚煞极之像（启用）；暗影魔（启用）；无法逃避的折磨（启用）；死亡代言人（未启用）。** 如果任何宠物处于激活状态或目标生命值低于 20%，则施放 [[spell:32379]]。
19. **适用条件：亚煞极之像（启用）；暗影魔（启用）；无法逃避的折磨（启用）；死亡代言人（启用）。** 如果任何宠物处于激活状态或目标生命值低于 35%，则施放 [[spell:32379]]。
20. **适用条件：死亡代言人（未启用）。** 如果目标生命值低于 20%，则施放 [[spell:32379]]。
21. **适用条件：死亡代言人（启用）。** 如果目标生命值低于 35%，则施放 [[spell:32379]]。
22. **适用条件：虚空形态（启用）。** 施放 [[spell:1240401]]。
23. 施放 [[spell:15407]]。当其他行动可用时，打断此引导。
24. **适用条件：暗影魔（未启用）。** 如果你没有其他技能可按，则施放 [[spell:32379]] 用于移动。

:::details 常见问题我应该何时刷新我的 DoT？
[[spell:34914]] 和 [[spell:589]] 都受益于所谓的“传染”机制。你可以在 DoT 持续时间剩余 30% 或更少时刷新它们，而不会受到惩罚。这本质上延长了你刷新 DoT 的窗口期。举例来说，暗影 Word: Pain 持续 16 秒（在没有 [[spell:238558]] 的情况下），因此其传染阈值为 4.8 秒。换句话说，刷新 暗影 Word: Pain 的最佳时机是当它剩余 4.8 秒或更少时。在此阈值或以下进行刷新会将剩余时间加到原始持续时间上。如果你在 暗影 Word: Pain 剩余 3 秒时刷新它；例如，这将使新的持续时间变为 19 秒。

在点出 [[spell:238558]] 的情况下，[[spell:34914]] 和 [[spell:589]] 的持续时间均为 21 秒，因此它们的传染阈值为 6.3 秒。

[[spell:335467]] 是一个独特的 DoT，受益于特定的刷新机制。[[spell:335467]] 在刷新时会滚动伤害，这意味着当你刷新 DoT 时，DoT 剩余的任何伤害都会被结转，并作为乘数加到新 DoT 的跳数上。因此，刷新没有相关的“成本”，即使我们花费了疯狂值来施放该法术。这不应该过多改变你的循环；只是不要觉得你必须等待当前 DoT 完成后再重新施放它。你仍然应该尝试在剩余约 1 秒时刷新，以为我们的 [[spell:343690]] 获得最大的 DoT 覆盖率。它会将到下一跳的时间加到新 DoT 上，这样你就不会错过一跳。

:::

### AOE循环

1.5.

#### 暗影 牧师 AoE起手式

**适用条件：触须猛击（未启用）。** **警告** 上方表格中未选择 [[spell:1227280]]，或者你未使用 AoE 预设。请在上方选择此选项以查看准确的 AoE 建议。作为 暗影 牧师，在没有此技能的情况下进行 AoE 内容将会非常痛苦。

这是作为在 AoE 环境中开怪的非常基础的示例。确切的怪物数量和怪物的聚集方式自然会改变你每次拉怪要做的事，尤其是取决于你的冷却状态。请将其与通用优先级列表一起作为起点。

战斗开始前，确保你已激活 [[spell:232698]] 和 [[spell:21562]]。

**适用条件：召唤梦魇（启用）。**

[[spell:589]]

**适用条件：苦难（启用）。**

[[spell:34914]]

**适用条件：触须猛击（启用）。**

[[spell:1227280]]

**适用条件：执政官（启用）。**

[[spell:120644]]

**适用条件：牧师 暗影 12.1 职业套装 4件套（启用）。**

[[spell:1240401]]

**适用条件：虚空形态（启用）。**

[[spell:228264]]

[[spell:10060]]

[[item:241288]]

[[item:250215]]

**适用条件：牧师 暗影 12.1 职业套装 4件套（未启用）。**

[[spell:1240401]]

[[spell:335467]]

**适用条件：虚空编织者（启用）。**

[[spell:263165]]

1. **适用条件：召唤梦魇（启用）。** 在怪物群被 [[spell:586]] 聚集时，对任何目标施放 [[spell:589]]。
2. **适用条件：苦难（启用）。** 在怪物群被 [[spell:586]] 聚集时，对任何目标施放 [[spell:34914]]。
3. **适用条件：触须猛击（启用）。** 在所有目标聚拢后，施放 [[spell:1227280]] 为目标挂上持续伤害效果。如果怪群足够大且你有可用充能，考虑把两层充能都用掉。
4. **适用条件：执政官（启用）。** 在所有小怪进入战斗且进入范围后，施放 [[spell:120644]]。
5. **适用条件：牧师 暗影 12.1 职业套装 4件套（启用）。** 施放 [[spell:1240401]] 以便能够施放 [[spell:228260]]。
6. **适用条件：虚空形态（启用）。** 施放 [[spell:228260]]。
7. 使用你的战斗药水 [[item:241288]]，除非你想留给即将到来的怪群或首领。
8. 使用 [[spell:10060]] 以及任何基于属性的种族技能。如果使用 [[spell:373466]]，请确保将 能量灌注 施放在一名队友身上。
9. **适用条件：牧师 暗影 12.1 职业套装 4件套（未启用）。** 施放 [[spell:1240401]]。
10. 施放 [[spell:335467]]。
11. **适用条件：虚空编织者（启用）。** 施放 [[spell:263165]]。
12. 继续正常执行输出循环。

**适用条件：触须猛击（启用）。** 注意，如果怪群目标超过 6 个，或目标过于分散而无法用 [[spell:1227280]] 覆盖，你应该尽量与坦克一起拉怪，使用 [[spell:586]] 避免获得仇恨，同时在怪群被拉聚的过程中挂上你的持续伤害效果。

1.6.

#### 暗影 牧师 AoE 优先级列表

如果你在寻找更容易理解的内容，或者你才刚刚入门，我强烈建议查看 [新手页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-easy-mode>) 页面。下面的输出循环指南面向希望尽可能极限优化输出循环的高级玩家。

在进行 AoE 输出时，确保你将法术施放在拥有 [[spell:335467]] 的目标上至关重要。这可以确保 [[spell:199484]] 的伤害通过像 [[spell:343690]] 或 [[spell:373212]] 这样的法术获得尽可能大的提升。

1. **适用条件：苦难（启用）；触须猛击（未启用）。** 通过使用 吸血鬼之触 同时施加两个 DoT 来保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。在适当的传染窗口期内刷新它们（见下文）。
2. **适用条件：召唤梦魇（启用）；触须猛击（未启用）。** 保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。在适当的传染窗口期内刷新它们（见下文）。
3. **适用条件：Tentacle Slam（启用）；Misery（启用）。** 通过使用 吸血鬼之触 同时施加两个 DoT 来保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。当你需要刷新 [[spell:34914]] 时，如果可用则使用 [[spell:1227280]]。在适当的传染窗口期内刷新它们（见下文）。
4. **适用条件：Tentacle Slam（启用）；Invoked Nightmare（启用）。** 保持 [[spell:34914]] 和 [[spell:589]] 处于激活状态。当你需要刷新 [[spell:34914]] 时，如果可用则使用 [[spell:1227280]]。在适当的传染窗口期内刷新它们（见下文）。
5. **适用条件：执政官（启用）。** 施放 [[spell:120644]]。
6. **适用条件：虚空形态（启用）。** 施放 [[spell:228260]]。
7. 施放 [[spell:10060]]。
8. 将你的任何饰品与你的冷却技能同步使用（见饰品章节）。
9. **适用条件：虚空编织者（启用）。** 如果目标有 [[spell:451840]] 的吸收护盾，则施放 [[spell:32379]]。
10. **适用条件：Mind 噬灭（未启用）；Distorted Reality（未启用）。** 如果 [[spell:335467]] 未激活、即将到期，或者你即将达到疯狂值上限，请高优先级地将疯狂值用于该法术。为了更多 AoE 伤害，你可以在每次获得足够资源时将其施放在新的目标上。
11. **适用条件：Distorted Reality（启用）；Mind 噬灭（未启用）。** 如果 [[spell:335467]] 未激活、即将到期，或者你即将达到疯狂值上限，请高优先级地将疯狂值用于该法术。每次获得足够资源以造成更多 AoE 伤害时，将其施放在新的目标上。
12. **适用条件：Mind 噬灭（启用）；Distorted Reality（未启用）。** 如果 [[spell:335467]] 未激活、即将到期、你即将达到疯狂值上限，或 [[spell:373202]] 已激活，请高优先级地将疯狂值用于该法术。
13. **适用条件：Distorted Reality（启用）；Mind 噬灭（启用）。** 如果 [[spell:335467]] 未激活、即将到期、你即将达到疯狂值上限，或 [[spell:373202]] 已激活，请高优先级地将疯狂值用于该法术。每次获得足够资源以造成更多 AoE 伤害时，将其施放在新的目标上。
14. **适用条件：虚空编织者（启用）。** 如果 [[spell:335467]] 处于激活状态或 [[spell:447444]] 即将过期，则在可用时施放 [[spell:450405]]。
15. **适用条件：触须猛击（启用）。** 如果你即将达到充能次数上限或 [[spell:34914]] 未处于激活状态，则施放 [[spell:1227280]]。
16. **适用条件：虚空编织者（启用）。** 施放 [[spell:263165]] 以开启 [[spell:447444]]。
17. **适用条件：召唤梦魇（启用）。** 如果目标身上没有激活且能存活至少 12 秒，对任何目标施放 [[spell:589]]。
18. 施放 [[spell:8092]]。
19. **适用条件：执政官（启用）。** 如果 [[spell:335467]] 处于激活状态，则施放 [[spell:391399]]。
20. **适用条件：Inescapable Torment（启用）；Shadowfiend（启用）；Idol of Y'Shaarj（启用）；Deathspeaker（未启用）。** 如果任何宠物处于激活状态或目标生命值低于 20%，则施放 [[spell:32379]]。
21. **适用条件：Inescapable Torment（启用）；Deathspeaker（启用）；Shadowfiend（启用）；Idol of Y'Shaarj（启用）。** 如果任何宠物处于激活状态或目标生命值低于 35%，则施放 [[spell:32379]]。
22. **适用条件：死亡代言人（未启用）。** 如果目标生命值低于 20%，则施放 [[spell:32379]]。
23. **适用条件：死亡代言人（启用）。** 如果目标生命值低于 35%，则施放 [[spell:32379]]。
24. **适用条件：虚空形态（启用）。** 施放 [[spell:1240401]]。
25. 施放 [[spell:15407]]。当其他行动可用时，打断此引导。
26. **适用条件：暗影魔（未启用）。** 在移动场景中，当你没有其他瞬发法术可用时，施放 [[spell:32379]]。

:::details 小贴士：在没有 [[spell:238558]] 的情况下传播 [[spell:589]]
如果你选择使用

[[spell:1279350]]

而不是

[[spell:238558]]

保持将会让你获得很多好处

[[spell:589]]

中获得大量收益。使用这些构筑时，至关重要的是在怪群聚拢期间尽可能多地手动为这些目标挂上持续伤害效果，然后在聚拢后你可以使用

[[spell:1227280]]

来让

[[spell:34914]]

也运转起来。一旦你获得了新的巅峰天赋，这足以在大部分拉怪过程中维持你的输出。

:::

除了上面的 AoE 优先级列表外，请注意这些重要的目标切换：

- 12+ 目标：手动挂持续伤害效果的目标上限，通常不值得超过这个数量，除非是在使用 [[spell:586]]（包括 [[spell:1227280]] 带来的 6 个）聚拢怪群的过程中。

关于使用 [暗影 牧师](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>) 进行大秘境的特定技巧，请随时查看下方的专属页面。从输出循环的角度来看，将遵循上面的优先级列表。

[暗影 牧师 大秘境指南](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-mythic-plus-tips>)

1.

### 至暗之夜 第2赛季套装

在至暗之夜第2赛季中，你将获得以下套装效果：

- [[spell:1296579]]
- [[spell:1296580]]

这套套装在输出循环方面很重要，原因有几点：

- 由于 [[spell:1296579]] 缩短了冷却时间，更频繁地使用 [[spell:1227280]] 以避免停留在法术的最大充能层数变得更加重要。
- 当你获得 [[spell:1296580]] 时，你需要将 [[spell:1240401]] 穿插进你的常规输出循环中，以从套装加成中获得最大收益，即使在 [[spell:228260]] 之外也是如此。将其视为仅次于疯狂值溢出的最高优先级法术。
- 由于 4 件套的增益在战斗开始时重置，你应该避免将 [[spell:1227280]] 作为开怪前的起手技能。相反，在获得套装后选择预读 [[spell:8092]]，然后进入你的第一个 [[spell:1227280]]。

1.

### 饰品使用

任何提供属性加成的主动使用饰品，最好都在你的冷却技能期间使用以获得最大收益。任何例外情况在下方注明。

1. [[item:270169]] 应在 [[spell:10060]] 期间使用，当你拥有超过 5 层 [[spell:1307470]] 或战斗将在不到 30 秒内结束时。
2. [[item:270602]] 应每分钟使用一次。
3. [[item:250215]] 的使用方式与其他饰品相同，按 2 分钟冷却时间计算。
4. **默认**：将所有其他饰品与 [[spell:228260]] 或 [[spell:10060]] 同步。如果冷却时间为一分钟或更短，则按冷却使用。最后，如果战斗会在你的冷却技能转好之前结束，就使用它。

对于任何纯造成伤害的主动使用饰品，你应该尽量按冷却使用。造成 暗影 伤害的饰品会被 [[spell:447444]] 在 [[spell:449880]] 期间增强，所以尽量将这些施法与饰品使用对齐。注意，暗影 伤害还会增强混沌、宇宙、瘟疫、暗影烈焰、暗影冰霜、法术暗影、暗影打击或暮光伤害类型。

1.

### 职业与专精机制详解

### [[spell:8092]]

4.1.

#### 心灵震爆

[[spell:8092]] 是我们主要的循环技能之一，目标是在大多数情况下不损失任何潜在的施放次数。有了 [[spell:406788]]，这变得容易得多，因为它为我们提供了 2 层充能。由于同一时间只有一层充能可以冷却，我们只在你充能层数达到上限（此处为 2 层）时才优先更多地施放心灵震爆。

除了正常的玩法之外，我们还可以使用 [[spell:375888]] 专精天赋，这在几乎所有场景中都会点出。关于这些触发效果，重要的是要理解它们并不会具体改变你的循环优先级。这是因为暗影洞察触发会为你提供一个完整的 [[spell:8092]] 临时充能，所以你可以在通常使用一次心灵震爆的任何时候使用它。

关于 [[spell:8092]] 的另一个重要循环要点，特别涉及该法术作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者。由于心灵震爆在[[spell:447444]]激活期间会被转化为[[spell:450405]]，我们希望确保尽可能多地施放该法术。

从起手的角度来看，如果你拥有第 2 赛季 4 件套加成，你的第一个法术应该是 [[spell:8092]]，然后是你的第一个 [[spell:1227280]]。这可以保持爆发窗口干净，并避免在战斗开始时因重置效果而损失价值。

### [[spell:335467]]

4.2.

#### 暗言术：癫

[[spell:335467]] 是一个相对独特的持续伤害效果，其运作方式与 [[spell:34914]] 或 [[spell:589]] 不同。因此，你必须在宏观层面理解它的工作原理，以避免误用其独特效果。

刷新 [[spell:335467]] 时，它会将未来跳数上剩余的伤害滚入，并以修正值的形式加到新的持续伤害跳数上。这实际上意味着，当你经常达到或接近 100 疯狂值（称为溢出）时，你可以自由刷新 暗影 Word: Madness 而不损失任何伤害，前提是目标在整个持续伤害期间存活。重要的是要注意，此过程的任何部分都不是属性快照，而是将未来的伤害跳数转换为新跳数的修正值。因此，智力和急速的变化不会改变滚入的方式；无论何时它都以相同的方式运作。

虽然无论你何时使用 [[spell:335467]] 伤害都会滚入，但刷新的确切时机很重要。暗影 牧师精通 [[spell:343690]] 受益于 暗影 Word: Madness 的覆盖率。因此，为了从持续伤害中获得最大伤害，你应该只在持续伤害剩余时间不足一个 GCD 时，或者你接近疯狂值溢出（缺口约 35 或更少）时刷新，以从我们的精通中获得最大伤害。此外，这样玩还能从 [[spell:373212]] 天赋中获得最大价值，如果你正在使用它的话。

这个机制大多是被动的，但可以利用其优势来爆发击杀特定目标。通过积攒 100 疯狂值（使用 [[spell:407430]] 时为 150），你可以连续施放多次 [[spell:335467]]，并在与单次 [[spell:335467]] 相同的时间内获得一个拥有更强大跳数的新持续伤害效果。否则，如果你的目标存活，你应该始终优先让持续伤害效果在目标身上保持尽可能长的时间，以从我们的精通中获得最大收益。在最大化这一点的同时，确保你也没有溢出疯狂值。兼顾这两个条件将是你精通这个法术的关键。

对于大多数类型的内容，你应该完全正常地玩；除非你试图专门爆发击杀某个目标，否则没有任何需要利用其机制的地方。正常地玩，并享受在原本会溢出疯狂值时不损失伤害的乐趣。

如果你想以视频形式了解这一变化，我在 [这个视频](<https://youtu.be/5PBi816Qy5w>).

4.2.1.

##### 多目标

你如何使用 [[spell:335467]] 严格取决于你想要优先考虑什么：整体 AoE 伤害或优先目标伤害。这两种都是可行的策略，几乎可以与任何天赋组合一起使用。

为了优先考虑整体 AoE 伤害，你可以 **传播**
[[spell:335467]]。这可以通过每次获得足够疯狂值时将 暗影 Word: Madness 施放在一个新目标上，然后将其作为你的新主要目标，直到你积累足够的疯狂值重新开始这个过程来实现。这种玩法风格与 [[spell:409044]] 和 [[spell:407469]] 等天赋配合得特别好，但这些并非这种玩法风格获得收益的必要条件。虽然 暗影 Word: Madness 在重新施加时确实会滚入伤害；但根据目标死亡的时机，你最终可能会损失伤害。通过将持续伤害效果传播到当前生命值最高的目标上，你可以从这种玩法风格中获得收益。

或者，你可以选择在 AoE 期间通过将 [[spell:335467]] 的施放集中到怪群中最重要的小怪身上，来提高你的优先目标伤害。这种伤害模式在游戏中其他专精中较少见，这使得 暗影 牧师 在高端大秘境阵容中尤其受到青睐。通常，怪群中有几只优先目标小怪，它们要么比怪群中大多数小怪拥有更多生命值，要么可能拥有一套致命的技能，使得优先击杀该小怪变得重要。这种玩法风格通常倾向于选择 [[spell:407470]] 以便在地下城中施放更多次 暗影 Word: Madness。

:::details 常见问题：给次要目标挂持续伤害效果会提高单体 DPS 吗？
这取决于天赋和期望的结果。传播持续伤害效果会提供更多的触发机会（有衰减），而集中施法则会增加优先目标的伤害。根据像

[[spell:391228]]

,

[[spell:155271]]

这样的天赋以及你队伍的策略来决定。

:::

### [[spell:586]] 拉怪

4.3.

#### 渐隐术拉怪

特别是在地下城拉怪时，你应该始终与坦克一起拉怪，而不是在坦克之后。通过在坦克拉怪时尽快挂上 [[spell:34914]] 进行适当的准备，你可以在不损失疯狂值消耗技能施放的情况下，进一步增加对怪群的伤害。只有使用 [[spell:586]] 作为仇恨消除手段才可能做到这一点，这样你才能在坦克拉怪、仇恨完全建立之前就开始输出。掌握这一点对于在大秘境中表现出色至关重要。

通常，我们在一次拉怪中只维持最多 12 个目标的持续伤害效果（6 个来自 [[spell:1227280]]，最多 6 个来自手动的 [[spell:34914]]）。如果值得投入，你可以双倍施放。通过与坦克一起拉怪，这使你能够施放更多手动的 吸血鬼之触 持续伤害效果，从而增加我们可以维持伤害的目标数量。

:::details 常见问题：如何在不可避免的移动中处理而不损失太多伤害？
采用碎步走位法：在技能公共冷却之间小幅度移动，并在移动时优先使用瞬发法术，例如

[[spell:1240401]]

,

[[spell:32379]]

,

[[spell:335467]]

，以及

[[spell:375888]]

触发效果。如果没有瞬发法术可用，使用

[[spell:589]]

作为后备手段，而不是完全停止你的输出循环。

:::

:::details 提升输出循环的日志审查清单
- 在得出结论之前，先与相似的击杀时间和相似的装备等级进行比较。
- 首先检查关键法术和冷却技能的施放次数，例如 [[spell:228260]] 和 [[spell:10060]]。
- 检查持续伤害效果的覆盖率（[[spell:589]] 和 [[spell:34914]]）以及主要增益窗口。
- 审查冷却技能时机、药水使用以及饰品与战斗阶段的对齐情况。

:::

### [[spell:373273]]

4.4.

#### 尤格-萨隆的神像

[[spell:373273]] 是在寻求最大化你的 暗影 牧师 伤害时的一个常见问题。特别是，如果你能围绕它进行干净的操作，让这个触发效果在更好的时机出现会很有优势，尤其是在大秘境环境中。

每次你生成一个 [[spell:341491]] 时，你都会生成一层 [[spell:373273]]。不幸的是，我们对此没有太多控制权，因为我们的许多法术都会生成幻影，但你可以选择牺牲一波怪末尾的伤害，以尝试让触发效果出现在下一波怪的开始。

至关重要的是，如果你试图控制 [[spell:373273]] 的触发，你需要比你想象的更早开始考虑。由于 [[spell:391284]] 在你拥有 [[spell:589]] 激活期间会随机触发，如果你试图为下一波怪保留，你很容易会触发几次。因此，等待到 24 层是永远不建议的；你总是需要比那更早规划，可能在 20 层左右。

注意，虽然你可以取消用于积攒 [[spell:373273]] 的增益，但从整体 DPS 的角度来看这几乎永远不值得。请特别小心这些关于该法术的微优化，因为如果操作不当，你可能会损失相当多的伤害。

### 巅峰天赋：[[spell:1264096]]

4.5.

#### 虚空幻灵

我们的巅峰天赋大多是被动的，但重要的是增强了我们已经在关注的施放内容。[[spell:1264096]] 所促成的核心玩法循环是希望尽可能多地触发偶像效果，然后获得 [[spell:341491]]。

围绕这一点的最好方法就是正常地玩。通过这样做，我们自然会产生大量的偶像触发效果。需要记住的重要一点是永远不要让 [[spell:1227280]] 的充能达到上限，尤其是在冷却技能期间。此外，在你的主要冷却技能期间，你应该更自由地使用冷却技能以获得最佳伤害。

1.

### 暗影 牧师 的重要冷却技能

### [[spell:228260]]

5.1.

#### 虚空形态

[[spell:228260]] 是 暗影 牧师 的主要冷却技能之一。这是一个 2 分钟的冷却技能，与 [[spell:10060]] 配合得很好，并让你能够使用 [[spell:1240401]]。

对于基础输出循环，主要思路很简单：将 [[spell:228260]] 与 [[spell:10060]] 以及任何主要饰品窗口对齐，然后高效地消耗爆发周期。这是 暗影 牧师 围绕优化的主要爆发窗口，所以不要将其视为一个可以安全地不同步的独立冷却技能。

这个冷却技能让你能够使用：

- 3 层 [[spell:1240401]] 充能（使用 [[spell:341240]] 时会额外增加 2 层充能）。
- 法术造成伤害时视为 [[spell:343690]] 已完全叠加。
- 使用 [[spell:453917]] 时 +5% 伤害（![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官)
- +5% 伤害（使用 [[spell:341240]] 时额外增加 +5%）
- 替换 [[spell:232698]]（抵消伤害提升效果）

[[spell:228260]] 的另一个关键部分是 [[spell:341240]] 天赋，它为该法术添加了增益延展机制和叠加急速。该天赋会在虚空形态期间，每施放一次 [[spell:335467]] 就延长虚空形态的持续时间。

5.1.1.

##### 虚空齐射

[[spell:1240401]] 是一个瞬发、充能型法术，你在 [[spell:228260]] 期间可以使用，并且通过套装加成也可以成为常规循环按钮。作为基础，请将其视为低优先级施放：它没有冷却时间，所以你的目标只是在虚空形态结束前用完所有充能。

**进阶优化：** 如果你想进一步优化，为你的 [[spell:453845]] 窗口积攒充能，然后在 [[spell:228260]] 处于光晕循环内、处于虚空形态期间，或者你即将溢出层数时，一次性倾泻充能。

- **没有 [[spell:453845]] 时：** 随意施放 [[spell:1240401]]。
- **拥有 [[spell:453845]] 时：** 尽可能为增益窗口积攒 [[spell:1240401]]。
- **倾泻触发条件：** [[spell:228260]] 在 60 秒内即将冷却完毕、当前处于 [[spell:228260]] 中、[[spell:453845]] 伤害增益激活、[[spell:1279354]] 达到 4 层及以上，或战斗即将结束（少于 45 秒）。

### [[spell:10060]]

5.2.

#### 能量灌注

除了我们的核心冷却选择外，你还可以使用 [[spell:10060]]。这是一个 2 分钟冷却的法术，因此它自然地与每次 [[spell:228260]] 的施放同步。这个冷却只是在持续时间内为你提供一个急速增益。

凭借我们职业树中的 [[spell:373466]] 天赋，这成为游戏中最强大的外部增益之一，使你能够将 [[spell:10060]] 给予他人，然后自己也获得该增益。作为 暗影 牧师，在团队环境中这至关重要，因为根据你增益的对象不同，这很容易为你的整个团队带来额外的 4-5% DPS 提升。

暗影 牧师 的时间轴相对严格，且喜欢卡着冷却使用 [[spell:10060]]。这会影响我们将 能量灌注 给予谁的选择，以便我们能在对自己最有利的时候继续施放它。以下是 2 分钟时间轴上 能量灌注 的强力目标列表。

1. [踏风 武僧](<https://www.icy-veins.com/wow/windwalker-monk-pve-dps-guide>)
2. [湮灭 唤魔师](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-guide>) (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者)
3. [痛苦 术士](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-guide>)
4. [射击 猎人](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-guide>) (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵)
5. [噬灭 恶魔猎手](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-guide>)

请注意，此列表假设获得增益的玩家水平相当，但这并不总是一个好的假设。有时候，给团队中最强的人上增益，比单纯给一个适合 [[spell:10060]] 的专精上增益更有意义。

### [[spell:120644]]

5.3.

#### 光晕

如果你玩的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官 可以使用 [[spell:120644]]。这个法术需要卡着冷却使用，因此了解它在循环中的位置非常重要。

由于 [[spell:120644]] 有施法时间，且施放频率是 [[spell:228260]] 的两倍，因此在战斗过程中冷却时间会略微不同步。这是正常的，随着时间推移，你只需在虚空形态更靠后的阶段施放它即可。

### [[spell:263165]]

5.4.

#### 虚空洪流

[[spell:263165]] 是一个强大的天赋，可供 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 暗影 牧师使用。这是一个固定 3 秒的引导法术，随着你获得更多的急速，会产生更多的伤害跳数。无论你获得多少跳数，理智值的生成量始终是固定的。

值得注意的是，这个法术不会与我们技能库的任何部分进行快照；每一跳都会重新检查像 [[spell:343690]] 这样的修正效果。

这个法术的主要驱动力在于，施放开始时它会召唤一个 [[spell:447444]]，并在 [[spell:263165]] 的引导结束时将其刷新至完整持续时间。

从循环角度来看，请务必记住以下提示：

- 在引导施放前，务必让 [[spell:335467]] 处于激活状态。
- 优先在爆发窗口的早期使用它，这样高额的理智值生成可以支撑你更长时间的开场爆发。
- 在 AOE 环境中，如果你知道接下来需要对一波小怪进行 AOE 爆发，可以选择将其保留最多 10 秒。

### [[spell:1227280]]

5.5.

#### 触须猛击

**概述：** [[spell:1227280]] 是一个瞬发的顺劈伤害效果，召唤一个巨大的暗影肢体，在你前方和目标周围造成伤害。它会对最多 6 个敌人施加 [[spell:34914]]，优先选择尚未被该持续伤害效果影响的敌人。请注意，严格来说它并不优先选择你的当前目标。当点出 [[spell:1279353]] 天赋时，触须猛击还会以 25% 的效果降低值向你的当前目标施加 [[spell:335467]]（不会造成 AOE）。

在实践中，触须猛击作为维持工具最为重要。用它在小怪较多的战斗中刷新 [[spell:34914]]、防止充能溢出，或者在你已经循环使用关键伤害法术时为爆发窗口做准备。它是一个强大的 AOE 工具，但 APL 也非常看重它在保持持续伤害激活以及在战斗中分散使用时机方面的作用。

请注意，如果你用 [[spell:1227280]] 产生的效果覆盖了正常的 [[spell:335467]]，提示框中的跳数伤害将会下降。这是预期的结果，因为你只增加了 25% 的伤害，但完全刷新了持续伤害效果的完整持续时间。这是正常运作，伤害正确地进行了滚动。

迄今为止，这是一个关键冷却的最重要原因在于 至暗之夜 中即将到来的顶峰天赋——虚空幻影。当你点出这些效果时，它还会从你的某个偶像法术中获得一个效果，无论你是否点出了该偶像天赋。通过顶峰天赋，这一效果会进一步扩展，使每个生成的偶像法术都会召唤 [[spell:341491]]。

5.5.1.

##### 机制与行为

- **范围/顺劈：** 根据触须位置和小怪位置，它可以命中附近的多个敌人。
- **部分 [[spell:335467]] 应用：** 如果 [[spell:1227280]] 被 [[spell:1279353]] 强化，它会以 25% 的效果施加一个免费的 暗影 Word: Madness。
- **冷却/充能：** 注意不要让冷却充能溢出，不要在低价值目标上浪费猛击。

1.

### 如何查看你的 暗影 牧师 日志

日志回顾是提高伤害的最快方法之一，作为一名
[暗影 牧师](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>)。使用日志来评估 **执行** （施法、覆盖率、时机），并使用模拟来评估 **配装** （装备、天赋、附魔）。两者都做，你会比只依赖其中一种工具进步得更快。

:::details **快速日志回顾顺序**
**1) 匹配可比日志**

- 相似的击杀时间、战斗时长和装等。

**2) 检查施法次数**

- 寻找遗漏的冷却技能和核心资源生成技能的使用。

**3) 检查覆盖率**

- 确认持续伤害效果和关键增益/减益保持。

**4) 检查冷却时机**

- 确认与阶段、小怪波次和增益的对齐情况。

**5) 检查起手 + 移动**

- 将时间轴执行与你计划的顺序进行比较。

:::

6.1.

#### 第一步：寻找可比日志

在查看细节之前，先与一个真正可比的战斗进行比较。选择同一 Boss 上击杀时间相似且装备大致相同的玩家。如果战斗时长差异很大，施法次数的比较就会产生误导。

如果需要，在比较法术次数和冷却使用前，将时间轴范围裁剪到等效的战斗窗口。

6.2.

#### 第二步：首先检查施法次数

施法次数通常是影响最大的问题。如果你整体上遗漏了施法，这通常意味着移动导致的空闲时间、排队缓慢，或冷却技能握得太久。

:::details 施法次数检查清单
- 你是否遗漏了 [[spell:228260]]、[[spell:10060]] 或 [[spell:263165]] 的施放？
- 你是否持续使用 [[spell:8092]] 和 [[spell:1240401]]，以避免浪费冷却技能的使用次数？
- 移动窗口是否造成了没有施放任何法术的空闲 GCD？
- 你是否在本可以使用 [[spell:1227280]] 进行铺垫的情况下，过度手动施放了 [[spell:34914]]？

:::

6.3.

#### 第三步：验证覆盖率和增益窗口

一旦施法次数可以接受，就回顾覆盖率质量。对于持续伤害效果，目标是在安全处理机制的同时保持极高的覆盖率。

- [[spell:589]] 覆盖率：在优先目标上通常目标为 99%+。
- [[spell:34914]] 覆盖率：在优先目标上通常目标为 99%+。
- [[spell:335467]] 覆盖率：通常目标为 90%+。
- 检查 [[spell:228260]] 窗口，确保理智值生成和消耗使用顺畅。

不要忘记背景信息：如果你的团队在非常不同的时间使用了 [[spell:2825]]，直接比较可能会失真。

6.4.

#### 第四步：冷却时机与战斗情境

好的日志不仅仅在于卡着冷却按技能。许多战斗奖励轻微的延迟，以便与小怪、斩杀窗口或伤害增幅器对齐。

比较你的主要冷却和饰品/药水使用的确切时间戳，然后询问你的时机是否与有意义的战斗事件相匹配。

:::details 常见问题：我是否应该总是严格卡着冷却使用技能？
并不总是。默认快速使用冷却技能以避免损失总使用次数，但当小的计划性延迟能与高价值的 Boss 阶段、小怪刷新或团队增益对齐时，这样做是正确的。

:::

6.5.

#### 第五步：回顾起手和移动执行

使用时间轴视图将你的起手和第一个主要冷却循环与你预期的顺序进行比较。大多数重大损失来自于早期的偏差，这些偏差会级联导致整场战斗中高价值施法次数减少。

关于移动，重点在于你在重新定位时是否保持了行动。在 GCD 之间碎步移动，并尽可能用瞬发施法覆盖移动，而不是完全的空闲时间。

6.6.

#### 进阶工具与常见误区

对于特定战斗的时机比较， [lorrgs.io](<https://lorrgs.io/>)
对于并排查看许多顶级日志的施法时间轴很有用。

:::details 常见日志回顾误区
- 在不同击杀时间下比较总伤害，而没有归一化窗口。
- 忽略外部增益和团队背景（例如额外的 [[spell:10060]] 支持）。
- 对处于正常波动范围内的极小模拟/日志差异反应过度。
- 将大秘境地城结束时的总伤害视为直接的苹果对苹果比较。

:::

6.7.

#### 何时使用你的种族技能

根据你决定使用的种族，你将获得不同数量的法术来进一步增强你的角色。不幸的是，并非所有这些都有用。如果你好奇如何在战斗中使用它们，请参考本节。

请注意，截至撰写时，各种种族增益之间的 DPS 差异在 1-2% 之间。由于差异如此之小，通常不建议仅为了 DPS 产出而选择种族。通常，选择具有更好非 DPS 选项的种族会更有价值，例如地精的 [[spell:69070]] 或矮人的 [[spell:20594]]。

- [[spell:265221]]、[[spell:26297]]、[[spell:33697]] 和 [[spell:274738]] 应与 [[spell:10060]] 同步以最大化伤害。
- 光铸德莱尼的 [[spell:255647]] 应作为高于填充技能的低优先级动作。它在有小怪时效果更好，值得留着对他们使用。
- 鲜血 精灵的 [[spell:28730]] 只应在战斗前使用；在战斗中使用会造成 DPS 损失。
- 作为赞达拉巨魔，我建议你的 [[spell:292752]] 选择 [[spell:292361]]。
- 夜之子的 [[spell:260364]] 不值得用于输出目的。
- 狐人的 [[spell:312411]] 不值得用于输出目的。

:::details 常见问题 哪个种族最适合 暗影 牧师？
所有种族在提供的输出收益方面都非常接近，所以答案通常就是选择你喜欢的。也许更重要的是，除了输出之外，还要看看每个种族给你带来的好处；例如，像 [[spell:20594]] 或 [[spell:58984]] 这样的工具并不能直接提高你的输出，但它们提供的实用性对团队来说可能比其他任何种族能提供的微小输出更有用。

你也可以考虑龙希尔、地精或虚空精灵来帮助提升机动性。所有这些都能以不同方式提升你的机动性，哪个更好纯粹是个人选择。

- 龙希尔：[[spell:131347]]
- 地精：[[spell:69070]]
- 虚空精灵：[[spell:256948]]

:::

:::details 常见问题 我如何验证我的输出循环是否正确？
首先在战斗日志中检查你的起手和冷却时间，然后将施法次数和持续伤害覆盖率与战斗时长相近的优秀日志进行比较。一旦输出循环干净了，就使用模拟来评估装备和天赋的更换；模拟最适合做配置决策，而日志最适合做执行决策。

:::

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月11日：** 为第二赛季中发生变化的几个部分添加说明。
- **2026年8月10日：** 更新围绕虚空齐射和暗影言术：癫使用的输出循环。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月9日：** 添加了一个完全专门的日志审阅章节，包含工作流程、检查清单和故障排除指南。
- **2026年4月6日：** 添加移动处理、日志审阅检查清单和验证常见问题指南。
- **2026年4月4日：** 更新多个构筑的天赋默认设置。
- **2026年3月29日：** 提高 暗影 言出即灭的优先级，并添加更多关于扭曲现实的说明。
- **2026 年 3 月 22 日：** 更新 能量灌注 建议，添加关于触手猛击的说明，并调整关于光晕的说明。
- **2026年3月16日：** 添加了更多关于使用触手猛击层数的细节。
- **2026年2月26日：** 添加了关于巅峰天赋的专门章节。
- **2026年2月10日：** 在漏洞修复后，移除关于狂乱猛击互动的提及，并将触手猛击提前到起手循环中。
- **2026年1月23日：** 为前瞻补丁添加了更多常见问题条目。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月29日：** 为 执政官 起手循环添加关于使用心灵震爆的说明。
- **2025年8月7日：** 添加关于 虚空洪流 取消的说明，并更新默认的 虚空编织者 天赋。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 添加关于战斗助手的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年4月2日：** 更新执政官团队副本构建的默认天赋配置。
- **2025年3月19日：** 在点出Unfurling Darkness天赋时，在纯单体战斗中移除对暗影 Crash的使用。
- **2025年3月9日：** 移除暗影言术：灭多目标部分中令人困惑的目标死亡描述。
- **2025年3月3日：** 新增关于超线程护腕的部分。
- **2025年3月1日：** 新增第二赛季的新能量灌注目标。
- **2025 年 2 月 28 日：** 移除虚空冲击在引导其他法术时施放的能力。
- **2025 年 2 月 24 日：** 为第2赛季更新输出循环。移除了在拥有不可逃脱的折磨时对暗影言：灭和心灵震爆的更高优先级，引导法术时使用虚空箭，并添加了新饰品。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月4日：** 更新能量灌注目标建议。
- **2024年10月22日：** 调整 执政官 起手式，在开怪前使用光晕。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年10月10日：** 添加虚空编织者团队顺劈天赋选择器。
- **2024年10月10日：** 更新间谍大师之网的使用方法。
- **2024年10月9日：** 更新虚空编织者单体目标配装的默认天赋。
- **2024 年 10 月 7 日：** 更新虚空编织者的默认天赋。
- **2024年10月6日：** 根据最近的热修复更新输出循环。
- **2024年10月4日：** 当使用暗影深渊天赋时，移除多余的 暗影言：灭 条目。
- **2024年9月17日：** 添加关于尤格-萨隆偶像的章节。
- **2024年9月16日：** 添加新的输出循环章节以提供更多关于冷却技能使用的细节。
- **2024年9月16日：** 修复输出循环章节中噬灭瘟疫优先级的几个问题，特别是虚空编织者AoE。
- **2024年9月9日：** 在输出循环说明中添加心灵震爆章节。
- **2024年9月5日：** 修复虚空编织者配装和执政官AoE的起手序列。
- **2024年8月23日：** 添加执政官高层大秘境配装选择器
- **2024年8月21日：** 为地心之战的上线更新了输出循环。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月9日：** 添加在AOE场景中取消精神鞭笞：狂乱的选项。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年5月2日：** 提高虚空箭的优先级，并根据此更改修正起手循环。
- **2024年4月26日：** 调整在多目标战斗中精神鞭笞：狂乱和暗影之刺：狂乱的优先级。
- **2024年4月25日：** 添加新视频链接，并说明尼缪饰品与暗影魔的配合使用。
- **2024年4月22日：** 为第4赛季更新输出循环，提供新的占位天赋配置和选项。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月8日：** 添加多目标输出循环视频链接。
- **2024年1月15日：** 已针对10.2.5进行审阅。
- **2024年1月2日：** 在套装部分增加关于消耗死亡折磨层数的更多细节。
- **2023年12月3日：** 添加关于优化尤格萨隆偶像的部分。
- **2023年12月3日：** 添加关于4件套套装奖励如何运作的说明。
- **2023年11月24日：** 移除移动时使用真言术：盾的操作。
- **2023年11月19日：** 当仅使用两件套套装效果时，添加额外的暗言术：死一行。
- **2023年11月7日：** 在主要循环优先级中调整移动时的GCD。
- **2023年11月7日：** 对使用召日者贝洛雷洛斯进行小幅澄清更新。
- **2023年11月6日：** 已针对10.2.0补丁和新的第3赛季套装效果更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月13日：** 更新视频链接。
- **2023年8月9日：** 在使用无法逃脱的折磨时，从虚空爆发起手中移除暗影言术：死。
- **2023年8月9日：** 为暗影化身起手法添加注释，使其更清晰。
- **2023年8月8日：** 调整暗影化身起手法以纳入扭曲现实。
- **2023年7月26日：** 调整神圣之星和心灵游戏的使用章节，将其优先级降低。
- **2023年7月23日：** 已根据近期热修进行审阅。
- **2023年7月10日：** 已针对10.1.5补丁进行审阅，并对虚空形态起手法进行小幅更新。
- **2023年6月27日：** 根据所选天赋更新暗影言术：死的循环。阐明一些扭曲现实的使用。
- **2023年6月20日：** 更新吞噬瘟疫刷新细节。
- **2023年6月15日：** 关于吞噬瘟疫的虚空洪流的说明。
- **2023年6月6日：** 添加说明，澄清虚空洪流应始终完整引导。
- **2023年6月1日：** 关于套装效果如何运作的说明。
- **2023年5月26日：** 添加关于大秘境中套装优化的说明。
- **2023年5月22日：** 添加了更多关于在开怪前使用光晕、神圣之星和暗影坠落的细节。添加了关于战利品使用的说明。
- **2023年5月18日：** 修正了简介部分的拼写错误。
- **2023年5月5日：** 澄清了暗影坠落的使用仅用于刷新DoT。
- **2023年5月3日：** 降低暗影言：死的优先级。
- **2023年5月2日：** 澄清Dstar和光晕，并在吞噬瘟疫部分扩展扭曲现实的说明。
- **2023年5月1日：** 重大更新以支持10.1重做。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月25日：** 澄清起手循环中虚空洪流的使用。
- **2023年2月23日：** 修正单体目标中虚空洪流的问题，应在全部3个持续伤害激活时才施放。
- **2023年2月3日：** 调整高优先级的精神鞭笞：疯狂动作，仅在虚空洪流不可用时使用。
- **2023年1月31日：** 修正未点出摧心魔时配合恩佐斯的高优先级精神鞭笞：疯狂行。精简AoE循环使其更易读。
- **2023年1月24日：** 使用虚空洪流更新10.0.5的循环指南。
- **2023年1月12日：** 移除单体目标上的心灵灼烧使用。
- **2023年1月11日：** 10.0.5的循环更新，主要是格式变更和一些小的清晰度更新。
- **2023年1月4日：** 对噬灵疫病刷新说明进行小的澄清，并添加一些饰品说明。
- **2023年1月3日：** 更新起手式并添加更多细节。按冷却时间拆分，以便更容易维护。
- **2023年1月1日：** 在搭配无尽折磨时，降低暗影言：灭的优先级。
- **2022年12月29日：** 为心灵鞭笞：疯狂添加新逻辑，并更改默认复选框。
- **2022年12月11日：** 添加了讨论第29赛季套装奖励循环变化的章节。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月9日：** 添加了关于心灵震爆与心灵鞭笞在搭配心灵融合和克苏恩偶像时的额外说明。
- **2022年11月8日：** 将种族技能从循环中移出，放入独立章节。修复了起手式以使其更易阅读。
- **2022年11月7日：** 使循环中关于心灵震爆的部分更易阅读。
- **2022年11月5日：** 整理了噬灵疫病的行文，使其更清晰。
- **2022年11月3日：** 更新了循环的填充技能章节使其更清晰。添加了关于如何使用心灵灼烧的新章节。
- **2022年11月2日：** 通过底部章节更清晰地说明何时使用填充法术。
- **2022年10月26日：** 添加了更多循环切换以使内容更易查看。
- **2022年10月25日：** 调整了暗影言：灭、心灵鞭笞和心灵震爆的优先级。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面，你将找到《魔兽世界》12.1.5中你的 暗影 牧师 的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们一应俱全！

1.

### 暗影 牧师 毕业装备指南

欢迎来到我们的 暗影 牧师 装备页面。本部分

将涵盖你为角色正确配装所需了解的一切

以用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 和第2赛季。查看以下部分

以了解来自所有来源的最佳装备信息以及

关于饰品和制造物品的具体细节。

许多人过度考虑了他们副属性

的分配。需要记住的重要一点是，更高的 **属性数值** 属性

通常比更好的 **属性质量** 要好。因此，

穿着装等更高但属性较差的装备通常比装等较低

但属性优秀的装备要好。在考虑装备时请记住这一点。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 中升级装备继续使用纹章系统，该系统让你

沿着与获取物品来源相关的轨道提升装备物品等级，

更难的内容掉落的装备可以升级到更高的物品等级。

欲了解更多信息，请阅读我们专门介绍

[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 如何运作以及

在 至暗之夜 资料片中有什么变化的专页。

关于补丁对 暗影 牧师 影响的视频演示

12.1, [请查看 Publik 的这个视频](<https://www.youtube.com/watch?v=2OS9e2aMAlw>).

### 总体

此列表包含 暗影 牧师 来自所有来源的最高输出配置。请注意，还有许多其他配置的表现也在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高装等的制造装备在技术上是最优的，因为你可以根据喜好自定义副属性。你在这里的体验可能因人而异。

:::details 常见问题我需要哪些套装部件？
你应该优先获取 **头盔、胸甲、护腿和手套** 套装部件。然而，本赛季拥有特定部位的重要性比以往任何时候都低，因为我们在物品属性上有了更多的选择。

在 至暗之夜 第2赛季中，当你 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 一件物品时，它不仅在核心5个部位获得套装奖励，还保留了该物品的属性以及它可能具有的任何奖励效果。这意味着只要有一件基础物品可供催化，你就可以使用转化器在任何物品上获得理想的属性。这与之前的赛季相比是一个巨大的变化，在之前的赛季中，物品被用于套装奖励时其属性会丢失。

- 头盔：来自的 [[item:271874]] [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：来自的 [[item:239045]] [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸甲：来自的 [[item:273785]] [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手套：来自的 [[item:268243]] [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 护腿：来自的 [[item:251160]] [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

使用套装代币时属性是固定的，对于 暗影 牧师 来说，代币提供的所有5种属性对我们都很好，除了护腿是急速和精通。由于有魔杖头盔，你最好将套装头盔和套装护腿都进行催化。

:::

:::details 常见问题 早期应该制造什么？
虽然你可能很想早期制造法杖或副手，但我们建议使用

[[item:240167]]

制造以下物品之一，以便在赛季初期最优化地使用你的火花和纹章：

- [[item:239648@JAAKAAwt1ENMMYTWiAGM]]
- [[item:239649@JAAKAAwt1ENMMYTWiAGM]]
- [[item:239656@JAAKAAwt1ENMMYTWiAGM]]

副手上的 [[item:273060]] 是早期制造的一个选择，但从长远来看通常并不理想。

:::

:::details 常见问题 我应该从大秘库和虚空核心中优先获取什么？
尽早使用你的大秘库奖励来获得一把强力武器、一个关键饰品或你套装中缺失的部件。如果你仍然缺少某个特定的升级，并且想更快地推进单个部位， [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可以是一种非常高效的方式，用来定向获取史诗级路线的武器或饰品，而无需等待秘库。

对于 暗影 牧师，你最高优先级的目标应该是你在 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 上的额外掉落，选择 神圣 战利品专精以获取3件魔杖物品，尤其是主手。头盔和项链也非常强，值得在史诗难度前几个首领上使用额外掉落来获取英雄难度。这些物品在英雄难度下掉落于史诗路线。继续对这个首领使用额外掉落，并将这些物品升级到满级。

你应该使用额外掉落 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 并选择 神圣 战利品专精，以避免获得战利品表上我们不想要的伤害饰品。在这些额外掉落之后，你可能会转向价值较低的掉落。这可以是定向获取来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) 或 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)的理想饰品之一，或者是你可以在诸如 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)之类的地方获得的一些散件。此时选择很艰难，因为你真的要等到在史诗难度中打到团本后半段才能对那些首领使用额外掉落；前半段通常对我们来说没有好选择。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271555@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的头盔 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的手套 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAKAAwt1ENMMYTWiAGM]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:239045@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的护腿 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的胸甲 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYTWiAGM]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含第2赛季大秘境地下城中仅掉落且可刷取的最佳物品。此列表并非用于冲层的毕业装备列表，请使用总览列表。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：出色的饰品选择，带有 [[item:250215@JAACAAgNyA]] 和一条很棒的项链。
- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：魔杖武器，能让你使用一段时间，以及一个不错的饰品。
- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：不错的披风和腰带物品。

:::

:::details 常见问题我需要哪些套装部件？
你应该优先获取 **头盔、胸甲、护腿和手套** 套装部件。然而，本赛季拥有特定部位的重要性比以往任何时候都低，因为我们在物品属性上有了更多的选择。

在 至暗之夜 第2赛季中，当你 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 一件物品时，它不仅在核心5个部位获得套装奖励，还保留了该物品的属性以及它可能具有的任何奖励效果。这意味着只要有一件基础物品可供催化，你就可以使用转化器在任何物品上获得理想的属性。这与之前的赛季相比是一个巨大的变化，在之前的赛季中，物品被用于套装奖励时其属性会丢失。

- 头盔：来自的 [[item:251232]] [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 肩部：来自的 [[item:239045]] [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸甲：来自的 [[item:273785]] [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手套：来自的 [[item:273773]] [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 护腿：来自的 [[item:251160]] [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

使用套装代币时属性是固定的，对于 暗影 牧师 来说，代币提供的所有5种属性对我们都很好，除了护腿是急速和精通。由于有魔杖头盔，你最好将套装头盔和套装护腿都进行催化。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271555@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的头盔 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的手套<a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:251185@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>护肩</th><td>[[item:239045@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的护腿 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的胸甲 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:251127@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>饰品</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td>[[item:251191@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含第2赛季团队副本中仅掉落的最佳物品。此列表并非用于团队副本的毕业装备列表，请使用总览列表。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 小贴士我最想要哪些团队副本物品？
使用以下列表来指导你的团队副本刷取优先级。

- 来自的全部3件魔杖物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)。我们将 [[item:271874@JAACAAAG2A]] 催化为套装，然后使用 [[item:268265@JAACAAAG2A]] 和 [[item:271092@JAACAAAG2A]]。
- [[item:270169@JAACAAAG2A]]：我们最好的主动使用型饰品，掉落自团队副本，对于有伤害增幅阶段的战斗特别强。
- [[item:270167@JAACAAgNyA]]：这通常是我们第2赛季饰品的最佳被动选择，仅略优于盖博。
- [[item:270164@JAACAAgNyA]]：最好的团队副本饰品之一。掉落自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

:::

:::details 常见问题我需要哪些套装部件？
你应该优先获取 **头盔、胸甲、护腿和手套** 套装部件。然而，本赛季拥有特定部位的重要性比以往任何时候都低，因为我们在物品属性上有了更多的选择。

在 至暗之夜 第2赛季中，当你 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 一件物品时，它不仅在核心5个部位获得套装奖励，还保留了该物品的属性以及它可能具有的任何奖励效果。这意味着只要有一件基础物品可供催化，你就可以使用转化器在任何物品上获得理想的属性。这与之前的赛季相比是一个巨大的变化，在之前的赛季中，物品被用于套装奖励时其属性会丢失。

- 头盔：来自的 [[item:271874]] [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：来自的套装代币 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- 胸甲：来自的套装代币 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：来自的 [[item:268243]] [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 护腿：来自的套装代币 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

使用套装代币时属性是固定的，对于 暗影 牧师 来说，代币提供的所有5种属性对我们都很好，除了护腿是急速和精通。由于有魔杖头盔，你最好将套装头盔和套装护腿都进行催化。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271555@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的头盔 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271556@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的手套 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271553@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271554@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自的护腿 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271558@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270169@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:268228@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/shadow-priest-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244031]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 暗影 牧师 饰品推荐

暗影 牧师 在整个赛季中有许多出色的饰品可供选择。本指南

旨在帮助你了解哪些最值得追求以及可以期待什么

第二赛季的饰品选择中。这些是

针对目标的一般性建议，但任何装等提升幅度大的装备

都可能是升级，即使它不在此列表上。务必熟悉

通过 [装备升级系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 系统。

本赛季，你应该以1个主动使用饰品和1个被动饰品为目标。使用以下列表来帮助指导你，

通常你希望每个类别各选一个。特别是[[item:270169@JAACAAAG2A]]

是来自团队副本的强力主动使用饰品，奖励在于将其使用时机与伤害增益阶段对齐

或当你特别需要伤害时。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **暗影牧师饰品**
**最佳主动使用 -**

[[item:250215@JAACAAgNyA]]

或

[[item:270169@JAACAAAG2A]]

**最佳被动 -**

[[item:281215@JAACAAgNyA]]

或

[[item:270164@JAACAAgNyA]]

:::

还有很多其他有竞争力的选择，一定要查看下方的完整

排名。

2.1.

#### 单体目标饰品排名

- [虚空编织者](<https://warcraftpriests.github.io/?talents=voidweaver&sims=trinkets&fightStyle=Single>)
- [执政官](<https://warcraftpriests.github.io/?talents=archon&sims=trinkets&fightStyle=Single>)

2.2.

#### 地下城饰品排名

- [虚空编织者](<https://warcraftpriests.github.io/?talents=voidweaver&sims=trinkets&fightStyle=Dungeons>)
- [执政官](<https://warcraftpriests.github.io/?talents=archon&sims=trinkets&fightStyle=Dungeons>)

2.3.

#### 饰品详解

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看暗影牧师饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>两大英雄天赋（合计）</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:248583@JAACAAgNyA]]</li>&#10;<li>[[item:251792@JAACAAgNyA]]</li>&#10;<li>[[item:250144@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:250256@JAACAAgNyA]]</li>&#10;<li>[[item:251786@JAACAAgNyA]]</li>&#10;<li>[[item:251785@JAACAAgNyA]]</li>&#10;<li>[[item:246304@JAAGAAwt1ENMMYD]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是一种货币，可以保证从你指定的首领或地下城获得战利品。

虽然具体物品是随机的，但你永远不会获得重复物品，每次新的

虚空核心都会保证一件不同的掉落，直到你收集完该来源的所有可获得

物品。

3.1.

#### 暗影牧师的推荐迷雾虚空核心使用策略

你的迷雾虚空核心是一种宝贵的资源，用于获取那些原本可能与你擦肩而过的装备。

你的虚空核心策略应优先弥补当前配装中的缺口，同时牢记

你已经从 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 获得的物品，以及你的团队副本进度层级。将

虚空核心花费在未来几周可以通过更高难度内容获取的装备上，通常是

低效的。以下是你应该重点关注的内容：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心定向优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 为奇术物品使用神圣专精拾取
2. 神话级武器（单手或双手）
3. 咒术物品和神话级饰品，例如来自的 [[item:281215@JAACAAgNyA]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
4. 套装中你缺少的用于凑齐2件或4件效果的部件
5. 你毕业列表中影响较大的部位

:::

3.2.

#### 晋升毒液石

在决定将你的 [[item:280562]] 用在哪里时，你应该

按以下顺序优先考虑：

1. 你的主手武器是最高优先级
2. 你的副手武器
3. 你的主动使用饰品
4. 你的被动饰品
5. 你的项链。

你还可以升级来自团本最后两个Boss的咒术物品，这些

物品在英雄难度下通过额外拾取获得。它们会被升级到340物品等级。

1.

### 暗影 牧师最佳制造物品

自己制造装备或委托专业物品是

提升角色实力的好方法。

作为一名 暗影 牧师，尽早用制造系统做出你最终毕业列表中的一个部位，

[[item:240167]]：手腕、腰部或披风。[[item:273060]]

放在副手上是一个可以早期制作的选择，但通常不是你想要的

长期装备。

你可以通过使用你的两个制作专精槽位来进一步提升角色实力。

两个制造附魔槽位。你可以装备任意数量的制造装备，

但你最多只能装备2个装饰。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **暗影牧师制作装备优先级**
- [[item:239648@JAAKAAwt1ENMMYTWiAGM]]搭配[[item:240167]]
- [[item:239649@JAAKAAwt1ENMMYTWiAGM]]搭配[[item:240167]]
- [[item:239656@JAAKAAwt1ENMMYTWiAGM]]搭配[[item:240167]]
- [[item:273060]]放在副手上是一个可选的早期制作选择，但不是长期推荐。
- 任何你还没有在神话装备轨迹上获得的物品

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 暗影牧师的最佳装饰

作为一名暗影牧师，你有两个装饰槽位可以选择，

具体取决于你目前拥有的装备。你应该使用这些制作装备

来弥补你配装过程中的任何缺口，或你特别需要的槽位。

- [[item:239648@JAAKAAwt1ENMMYTWiAGM]]和[[item:239649@JAAKAAwt1ENMMYTWiAGM]]搭配[[item:240167]]——最终毕业手腕和腰部制作装备。
- [[item:239656@JAAKAAwt1ENMMYTWiAGM]]搭配[[item:240167]]——披风槽位的替代制作选择。
- [[item:273060]]——可选的早期副手制作装备，但通常长期不理想。
- [[item:239662]]和[[item:239661]]——两件套奖励可以
  
  
  
  
  ```
  optimal for certain situations. Uptime is typically lower on progression, so it's not our default choice.
  ```
- [[item:240167]]——在需要时用于低预算槽位的强力通用装饰。
- [[item:251513]]——如果你难以找到好的戒指，早期可能不错。触发效果会变化
  
  
  
  
  ```
  based on gem colors you have, our best procs are usually with Garnet or Peridot gems.
  ```

4.2.

#### 为装备添加插槽

在第二赛季中，你可以使用以下物品为任意头部、腰部或手腕装备添加插槽

[[item:275707]]消耗品为任何头部、腰部或手腕物品插槽，如果你在

你的宏伟宝库。不选择奖励会给你代币，其中六个可以

兑换成[[item:275707]]物品，该物品允许你为上述装备添加插槽

装备，如果你是在第2赛季获得的话。

1.

### 纹章使用

雾冠是一种限时获取的资源，你需要合理地使用它

以确保随着赛季的推进，你的角色强度提升能够最大化。

这些雾冠可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)

提升到更高的物品等级。重要的是，你需要优先考虑

将它们用在你短期内不打算替换的物品上，或者那些能提供

最大的收益。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **暗影牧师 雾冠升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**副手**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些并不是唯一值得升级的装备。它们只是在赛季初期

当你升级货币有限时，能够提供最高的DPS提升。

请注意，可能存在例外情况，例如带有额外

触发效果的特殊物品。

1.

### 评估升级

在本页及我们指南的其他地方，我们经常提到

在Raidbots上模拟自己的重要性。这是因为每个角色都是

独特的，你所拥有的每一件装备都可能改变什么是最好的

现在为你。

虽然我们确实为装备和饰品提供建议，但这些并非完整的

替代品来自模拟你自己。真正优化你角色的唯一方法

达到那种程度的方法就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月18日：** 在猎人仪式石削弱后更新制造建议。
- **2026年8月15日：** 更新饰品排名以反映即将到来的数值调整。
- **2026年8月11日：** 为制造和额外拾取添加更多直接建议。
- **2026年8月10日：** 更新装备列表，添加更多关于催化剂来源和额外拾取指南的信息。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年8月3日：** 将执政官和虚空编织者的饰品排名合并为一个梯队列表，并将暗月马戏团饰品上限设为C级。
- **2026年6月22日：** 更新饰品提示信息以显示正确的物品等级。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月19日：** 添加关于项链选择的说明。
- **2026年4月20日：** 为至尊和虚空核心添加新章节。
- **2026年4月6日：** 添加一个包含额外 暗影 牧师 模拟资源的下拉菜单。
- **2026年4月1日：** 更换美化，不使用奥术织锦套装。
- **2026年3月29日：** 在赛季第一周后调整饰品排名。
- **2026 年 3 月 22 日：** 调整受折磨灵魂之容器的排名。
- **2026年3月16日：** 针对第一赛季的上线进行更新。
- **2026年3月6日：** 更新饰品排名。
- **2026年3月2日：** 更新专业制造建议，为第一赛季上线做好准备。
- **2026年2月26日：** 调整饰品排名以考虑史诗地下城的物品等级。
- **2026年2月26日：** 已为 至暗之夜 赛季前阶段更新页面。
- **2026年2月10日：** 提升遗忘天空的尖啸饰品的排名。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年10月21日：** 对谜之卡特尔筹码章节进行了进一步的澄清和细化。
- **2025 年 10 月 5 日：** 添加了迪纳尔章节，并根据涡轮增压物品等级调整了饰品排名。
- **2025年8月18日：** 对饰品层级排名进行小幅调整。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月22日：** 为即将到来的热修调整D.I.S.C.腰带效能。
- **2025年6月15日：** 添加关于坚固信息保护容器腰带物品的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年5月12日：** 新增关于购买修道院徽记的说明。
- **2025年5月8日：** 瑟尔西的指环已不再是毕业装备。
- **2025年5月5日：** 更新卡特尔代币部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月28日：** 根据近期热修更新饰品排名。
- **2025年3月19日：** 在漏洞修复后移除对无定形圣物的提及。
- **2025年3月13日：** 更新饰品排名，并为各部分补充更多信息。
- **2025年3月5日：** 新增关于何时更换为第二赛季套装的说明。
- **2025年3月3日：** 新增关于使用超线程护腕的信息。
- **2025年3月1日：** 更新第二赛季瑟尔西的指环宝石。
- **2025年2月26日：** 更新第二赛季饰品排名。
- **2025 年 2 月 24 日：** 针对11.1.0补丁更新页面。
- **2024年12月17日：** 更新瑟尔西的指环提示说明，并提供风属性宝石替代方案。
- **2024年12月16日：** 根据近期增益更新瑟尔西的指环宝石。
- **2024年12月15日：** 首次发布后更新瑟尔西的指环建议。
- **2024年12月15日：** 为11.0.7新增瑟尔西的指环。
- **2024年11月4日：** 为整体毕业列表武器新增注意事项。
- **2024年10月27日：** 移除知识迸发。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年10月17日：** 修复了史诗钥石地下城装备套装中戒指的错误。
- **2024年10月1日：** 调整装备配置以包含更多单手武器。
- **2024年9月30日：** 更新饰品排名，并为地下城BiS列表添加一些额外的装备选项。
- **2024年9月19日：** 添加烛芯密友。
- **2024年9月17日：** 更改命运编织武器的提及。
- **2024年9月16日：** 更新饰品排名并提及命运编织之针武器。
- **2024年9月12日：** 移除赛季前BiS列表。
- **2024年9月9日：** 在团本层级列表中提升疯王的敕令。
- **2024年9月1日：** 从制造装备建议中移除束缚之缚。
- **2024年8月31日：** 更新第1赛季的制造装备建议。
- **2024年8月21日：** 为“地心之战”的上线进行了更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月15日：** 在大秘境中将 受难 列为S级。
- **2024年5月13日：** 添加关于为史诗+购买防御性饰品的说明。
- **2024年5月9日：** 添加更多关于容器和火焰伤害触发的信息，并添加史诗+的饰品组合示例。
- **2024年5月7日：** 已更新至10.2.7。
- **2024年5月5日：** 增加关于容器的更多细节，并调整部分排名顺序。
- **2024年5月1日：** 更新炽烈暗影容器的排名，因为它可以帮助触发戒指效果。
- **2024年4月30日：** 增加关于铸币购买和额外火焰伤害来源的更多信息。
- **2024年4月28日：** 添加关于大秘境中使用主动饰品的说明。
- **2024年4月25日：** 添加装备ID以更清晰地显示制造装备，为铸币添加新视频，并为团本和大秘境拆分建议。
- **2024年4月22日：** 为第4赛季更新，并提供新的装备建议。
- **2024年3月19日：** 更新高层大秘境副本的美化装备指南。
- **2024年2月13日：** 更新地下城饰品排名以与梯队列表保持一致。
- **2024年1月25日：** 在大秘境排名中提升灾祸之枝和 烬魄之灰 的等级。
- **2024年1月15日：** 说明涌动时间之帽在大秘境中的使用方法。
- **2023年12月20日：** 在地下城饰品排名中降低尼缪的排名。
- **2023年12月19日：** 更新装备套装，提供更多项链选择。
- **2023年12月18日：** 添加关于原初火焰预兆的额外说明。
- **2023年12月13日：** 添加关于优先升级头盔以获得炽热精华的说明。
- **2023年12月1日：** 添加制造装备插件。
- **2023年11月30日：** 添加饰品梯队列表以及一些选项的更详细信息。
- **2023年11月24日：** 更新饰品和武器排名/评论。
- **2023年11月16日：** 更新关于灰烬饰品的说明。
- **2023年11月14日：** 添加饰品视频链接。
- **2023年11月14日：** 添加关于在斩杀阶段使用伊雷达尔的小注。
- **2023年11月13日：** 更新饰品建议，并添加更多关于何时使用每个饰品的细节。
- **2023年11月8日：** 添加制造装备视频链接。
- **2023年11月7日：** 在波动孢子斗篷削弱后更新装饰建议。
- **2023年11月6日：** 为第3赛季和10.2补丁更新装备列表和建议。
- **2023年9月4日：** 添加新的装备列表。
- **2023年8月13日：** 添加视频链接。
- **2023年8月10日：** 为暗影化身构筑添加关于艾瑞达斯碎片的注释。
- **2023年7月23日：** 已根据近期热修进行审阅。
- **2023年7月10日：** 10.1.5补丁的更新，包括来自永恒黎明的新物品。
- **2023年6月27日：** 澄清了一些关于饰品和装饰物品的选择。
- **2023年6月7日：** 添加关于在大秘境中使用彼界灯塔的说明。
- **2023年6月1日：** 关于T30套装效果如何运作的技术说明，并添加大致数值。
- **2023年5月31日：** 添加更多关于武器制造的细节。
- **2023年5月23日：** 根据近期改动调整了时光漫游部分
- **2023年5月23日：** 添加了时光漫游部分。
- **2023年5月16日：** 移除了关于波动孢子斗篷bug的引用，因为已修复。
- **2023年5月16日：** 添加了关于波动孢子斗篷的bug，并移除了旧的奈萨里奥巢穴物品。
- **2023年5月15日：** 修正了波动孢子斗篷的信息，因为其属性已固定。
- **2023年5月6日：** 添加了关于不祥的多彩精华飞行选择的说明。
- **2023年5月5日：** 根据近期改动更新了武器和饰品排名。
- **2023年5月1日：** 为10.1和第2赛季更新所有装备建议。
- **2023年3月23日：** 根据最近的热修复更新黑曜石指环建议。
- **2023年3月22日：** 根据最近关于先知的暮色宝石交互的信息更新黑曜石指环建议。
- **2023年3月20日：** 为10.0.7补丁更新，并添加关于黑曜石指环的新章节。
- **2023年3月5日：** 微调地下城饰品建议。
- **2023年1月24日：** 为10.0.5更新装备建议。
- **2022年12月24日：** 添加绝望召唤者法典饰品。
- **2022年12月21日：** 为专业制造装备部分添加更多细节。
- **2022年12月13日：** 添加专业制造装备的视频指南，并移除关于在元素织法者项链中使用不同元素的说明。
- **2022年12月11日：** 已为第一赛季上线更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到你的 暗影牧师 的最佳属性优先级。我们首先展示属性优先级，然后深入解释这些属性如何与你的专精和游戏玩法相互作用。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 暗影牧师属性优先级

作为一名暗影牧师，你的英雄天赋选择以及你所参与的战斗类型

都会影响你对次要属性的重视程度。总体

而言， **急速** 和 **精通** 是你最重要的次要属性，

使用 **暴击** 和 **全能** 则退居其次。确切的

急速与精通之间的平衡会根据你的英雄天赋以及你

是在进行单目标还是多目标内容而变化。

装备等级

急速

精通

暴击

全能

上面的总体优先级只是一个简单的总结。以下部分提供了更

具体的指导，供你在为特定玩法选择装备时使用。

如果你想为多种类型的内容进行优化，值得维护

两套装备：一套用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者，另一套用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官.

虚空编织者通常更倾向于急速而非精通，而执政官在急速与精通保持相近时

急速和精通的差距更小。

1.1.

#### 单体目标属性优先级

以下是单目标战斗的实用属性目标。评分

范围是大致的目标，而非严格的最低或最高值。它们

代表了在模拟中表现出色的属性分布，同时帮助

你避免过度堆叠某一属性而陷入过度的收益递减。

1.1.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

1. 智力
2. 精通（1200 - 1400 评分）
3. 暴击（800 - 1200 评分）
4. 急速（1400 - 1600 评分）
5. 全能（400 评分或以下）

1.1.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

1. 智力
2. 精通（1200 - 1400 评分）
3. 急速（1400 - 1800 评分）
4. 暴击（800 - 1200 评分）
5. 全能（400 评分或以下）

1.2.

#### 多目标属性优先级

以下是AoE和大秘境类内容的实用属性目标。

以下范围是大秘境环境中无增益角色的大致目标，

并非硬性上限，其目的是帮助你接近推荐的

平衡，而不过度投入单一属性。

1.2.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

1. 智力
2. 精通（1000 - 1200 评分）
3. 急速（1600 - 1800 评分）
4. 暴击（800 - 1200 评分）
5. 全能（400 评分或以下）

1.2.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者

1. 智力
2. 急速（1600 - 1800 评分）
3. 精通（1000 - 1200 评分）
4. 暴击（800 - 1200 评分）
5. 全能（400 评分或以下）
6.

### 深入属性解析

**智力** 是你的主要属性。你应该在所有

升级中寻找该属性。它为你提供法术强度，增加你的法术

伤害。

**暴击** 提高你所有法术和技能的

暴击几率。暴击默认造成双倍伤害，但有若干

效果可以提高你的暴击伤害，使暴击更加强力。

**急速** 提高你的施法速度和周期性

效果的跳动频率。

:::details 常见问题：暗影牧师有急速上限吗？
没有，暗影牧师没有硬性急速上限。你不需要在特定数量的急速、暴击、精通或全能处停止，专精才能发挥作用。话虽如此，一旦你达到大约30%的急速、暴击或全能，这些属性就会开始因收益递减而贬值。精通大约在19%时开始出现这种情况。

:::

**精通** （[[spell:343690]]）根据你在目标身上激活的持续伤害效果数量

你对目标激活的每个持续伤害效果的法术。这个

仅适用于[[spell:589]]、[[spell:34914]]和

[[spell:335467]]。当[[spell:228260]]激活时，你会在

每个目标身上获得如同所有三个持续伤害效果都激活的收益。

**全能** 提高你造成的所有伤害和治疗，并降低

你受到的所有伤害。

2.1.

#### 属性递减收益

每种属性都有一个上限，在该上限之后每点属性获得的提升会减少，

这就是已知的收益递减点。一旦你达到

这些数值，属性将逐渐变得不那么有价值，并可能落后于

其他选择。当前的阈值如下：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对12.0.5补丁进行了审阅，修正了属性递减阈值。
- **2026年4月6日：** 添加关于模拟配置选择和解读小属性差异的常见问题指南。
- **2026年3月16日：** 已针对第一赛季进行审阅。
- **2026年2月26日：** 已针对90级的属性范围进行更新。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 审阅11.1.7补丁的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月14日：** 经过更多测试后，调整第二赛季的属性目标。
- **2025年2月26日：** 更新第二赛季大秘境属性目标。
- **2025 年 2 月 24 日：** 更新11.1.0补丁属性目标。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月4日：** 针对近期热修进行复核。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年10月14日：** 在更多测试后更新属性建议，使其更加精确。
- **2024年10月4日：** 更新地下城属性建议以适应更高的层数。
- **2024年9月16日：** 为执政官和虚空编织者添加具体的属性建议。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为“地心之战”的上线进行了更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月25日：** 添加新视频链接。
- **2024年4月22日：** 更新第4赛季的次要属性目标。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月8日：** 添加精通视频链接。
- **2024年1月21日：** 增加关于堆叠精通的额外说明。
- **2024年1月15日：** 说明与涌动时间之帽配合的急速阈值，并提及精通在冲层大秘境中的价值。
- **2023年11月7日：** 添加关于暴击/全能与咒术物品配合的注释。
- **2023年11月6日：** 已更新10.2.0补丁的属性阈值和目标。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月13日：** 添加视频链接。
- **2023年8月10日：** 添加副属性深入解析章节，以优化顶级装备。
- **2023年7月23日：** 已根据近期热修进行审阅。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月25日：** 添加了关于不祥的多彩精华的额外说明。
- **2023年5月22日：** 添加了更多关于急速软上限的细节。
- **2023年5月1日：** 更新属性优先级中关于10.1.0已修复错误的引用。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的暗影牧师所能获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你将有两类宝石可供选择：稀有或史诗。稀有宝石要么是单一属性，要么是两种次要属性的组合。史诗宝石要强大得多，但你的整个角色同时只能使用一颗。

作为一名暗影牧师，你应该使用[[item:240983]]作为你的史诗宝石选择。

为了最好地优化你的稀有宝石，你应该使用带有急速和精通的宝石。如果你不使用制造物品（参见下面的常见问题），你应该在[[item:240983]]的基础上堆叠[[item:240892]]或[[item:240900]]。通常在配装过程的早期，你会倾向于提供更多急速的宝石，而在后期，你会堆叠更多精通。在单目标中，你通常会注意到精通更有价值；在AoE中，急速更有价值。无论你选择哪种，只要宝石同时具有这两种属性，就不要过度纠结于宝石的选择。

稀有宝石大约价值0.4%的DPS。如果你正在考虑更换一件有插槽的物品，请记住这一点。随着你获得更好的装备，这个数值可能更高，但这是一个你可以使用的粗略数字。由于提升幅度如此之低，对不同宝石选择进行模拟极其困难，你应该非常谨慎地看待宝石模拟结果，因为通常在比较宝石时如此小的收益都在误差范围内；这意味着它们价值相等，你可以直接选择更便宜的选项。

:::details 常见问题：当我需要多种不同颜色时，应该使用什么宝石？
某些制造物品从拥有所有颜色的宝石中获益更多，因此请使用下面的列表来优化你的宝石使用。

- 橄榄石：[[item:240892]]
- 石榴石：[[item:240908]]或[[item:240906]]
- 紫水晶：[[item:240900]]
- 青金石：[[item:240917]]或[[item:240916]]

:::

1.

### 最佳附魔和武器强化

对于你的临时武器油，你应该使用[[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳</th>&#10;<th>备选</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244031]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244031]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部（非输出）</td>&#10;<td>[[item:243981]]</td>&#10;<td>[[item:243979]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;<td>[[item:244003]]</td>&#10;</tr>&#10;<tr>&#10;<td>肩部（非输出）</td>&#10;<td>[[item:243963]]</td>&#10;<td>[[item:243961]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;<td>[[item:240156]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243957]]</td>&#10;<td>[[item:244010]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部（非输出）</td>&#10;<td>[[item:244009]]</td>&#10;<td>[[item:243953]]</td>&#10;</tr>&#10;</table>

对大多数人来说，你会发现在早期急速触发[[item:243973]]效果很好。一旦你获得可观的急速（至少20-25%），你可能会发现换成[[item:244031]]表现会更好。

在选择三级属性附魔时，我建议作为暗影牧师默认选择速度，因为我们缺乏机动性。闪避或吸血可以提供更多的防御收益，但根据我的经验，能够更容易地躲避事物更有价值。

1.

### 最佳消耗品

3.1.

#### 合剂

在第2赛季中，你应该根据需要更多哪种属性来使用以下之一。

- [[item:241322]] - 精通
- [[item:241325]] - 急速
- [[item:241320]] - 全能（防御选择）

3.2.

#### 药水

我们在所有内容中理论上的最佳战斗药水是[[item:241288]]。然而，这种药水可能取决于装备，甚至更换单件装备都可能导致伤害的巨大变化。因此，这种药水在我们的模拟中默认不使用，但它仍然是一个非常强大的选择。如果你不使用这种药水，[[item:241308]]是一个可靠的替代品。

在第2赛季中，你现在可以使用[[item:271883]]，它明显优于[[item:241305]]。

3.3.

#### 食物增益

作为一名暗影牧师，我们在所有内容中首选的食物是[[item:255845]]或[[item:255846]]大餐。如果你无法获得大餐，我们更喜欢使用[[item:242275]]作为我们的个人食物选择，因为它与那些大餐具有相同的属性。

如果你想要更便宜的个人食物，你也可以使用[[item:242285]]或[[item:242286]]。

根据进度内容的水平，你也可以选择制作大多数食物的丰盛版本，它提供完全相同的效果（尽管有几个错误的提示说明），但现在增益效果在死亡后仍然保留。这需要5份普通食物来生产1份丰盛版本。

3.4.

#### 强化符文

你应该在任何开荒内容中使用强化符文来获得智力加成。这大约能提升1%的DPS。第2赛季可使用以下强化符文：

- [[item:259085]]（消耗品版本）

3.5.

#### 其他消耗品

除了上述物品外，作为一名暗影牧师，你还应始终确保背包中有以下物品，用于团本和大秘境环境。

- [[item:188152]] - 可重复使用的物品，会自动点击附近的 术士 传送门。
- [[item:244639]] - 为团队提供较弱的 [[spell:2825]] 效果，在没有职业能自然提供该效果的史诗钥石地下城中很有用。
- [[item:269586]] - 可在战斗中施放的战斗复活物品，即使不是工程学专业也能使用。
- [[item:241303]] - 隐形药水，可在某些大秘境地下城路线中代替[[item:241308]]来跳过小怪。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月1日：** 默认战斗药水更新及注意事项。
- **2026年8月11日：** 简化戒指附魔说明。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月22日：** 在近期增强后更新戒指附魔。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月23日：** 移除关于茶类消耗品的提及，并添加替代附魔。
- **2026年3月16日：** 换入关于皇家烤肉个人食物的提及。
- **2026年3月2日：** 修正食物消耗品，并添加关于茶类的提及。
- **2026年2月26日：** 为 至暗之夜 上线添加了新的消耗品和附魔。
- **2026年2月10日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 审阅11.1.7补丁的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年5月19日：** 更新腐蚀排名并新增视频攻略。
- **2025年5月5日：** 更新腐蚀部分，提供更多最新信息。
- **2025年4月21日：** 针对11.1.5补丁更新，并新增腐蚀部分。
- **2025年3月28日：** 新增其他消耗品部分。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月4日：** 澄清武器附魔的使用。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 添加关于丰盛大餐的说明。
- **2024年9月6日：** 调整史诗宝石的指导建议以包含狡诈亵渎宝石。
- **2024年9月4日：** 添加AoE武器附魔选项。
- **2024年9月1日：** 添加关于戒指附魔的说明。
- **2024年8月29日：** 添加关于赛季前附魔的说明。
- **2024年8月21日：** 为《地心之战》上线更新附魔和消耗品。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 更新腿部附魔建议并进行第4赛季审查。
- **2024年3月19日：** 对宝石选择的额外说明。
- **2024年1月15日：** 添加提供更高机动性的靴子附魔替代方案。
- **2023年12月13日：** 添加关于炽热精华的部分。
- **2023年11月6日：** 为第3赛季更新所有消耗品。
- **2023年10月3日：** 为第2赛季使用正确的插槽物品名称。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月13日：** 更新视频链接。
- **2023年7月23日：** 已根据近期热修进行审阅。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年6月27日：** 调整关于不使用玛瑙印记的表述。
- **2023年6月1日：** 添加关于插槽大致价值的说明。
- **2023年5月15日：** 愤怒药水已修复，因此调整回建议并添加了腰带扣。
- **2023年5月3日：** 由于狂暴存在错误，将默认药剂改回全能。
- **2023年5月2日：** 添加关于睿智与飘渺的额外说明。
- **2023年5月1日：** 为10.1.0更换建议的药水，并审查其他附魔。
- **2023年3月23日：** 根据最近的热修复更新黑曜石指环建议。
- **2023年3月22日：** 根据最近关于先知的暮色宝石交互的信息更新黑曜石指环建议。
- **2023年3月20日：** 为10.0.7补丁进行审查，并添加关于黑曜石指环的信息。
- **2023年2月15日：** 澄清宝石使用方法。
- **2023年1月24日：** 添加关于急速/精通组合宝石的提及。
- **2022年12月21日：** 添加关于何时使用全能药水的额外说明。
- **2022年12月11日：** 添加关于更多我不建议使用的药水的说明。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的暗影牧师挑战大秘境地下城的技巧和建议。

1.

### 暗影牧师在至暗之夜第2赛季中的大秘境

在本攻略中，我们将讨论如何在《魔兽世界》中充分发挥你的牧师的潜力

大秘境地下城，包括如何最佳地配置你的角色、你的

输出循环可能会变化，以及最有效地使用你的技能的技巧和窍门。

如果你不熟悉大秘境及其相关的一般机制，你可以

在我们下方专门的大秘境页面上阅读更多信息。

1.

### 暗影牧师的最佳天赋

暗影牧师几乎可以使用任意天赋组合完成任何层数的钥匙 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官或

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者。选择哪个对你有意义将取决于你喜欢的

玩法风格以及每种天赋组合的优缺点，但它们

都被认为是可行的。请单独查看每个部分以了解更多信息。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 [[spell:1240401]]

如果你刚开始使用暗影牧师的大秘境之旅，我建议

尝试 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 [[spell:1240401]]的实战体验。该构筑擅长逐个处理每一波怪，这

正是大多数野队最终的打法方式，并且在你获得足够的狂乱值后，依然拥有出色的伤害模式来应对

等级提升时。

**使用下方的复制按钮生成导入代码，在游戏中使用！** 如果你更喜欢

更偏向持续伤害的玩法风格，特别是在目标数量较少或持续时间较长的拉怪中，

你可以改用[[spell:1279350]]而不是[[spell:238558]]。

:::talents 苦难大秘境 - 虚空编织者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents 噩梦召唤 大秘境 - 虚空编织者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYG2mZGzMzYDZGLmpBYmZGAIAz2stAmNGAYwYmZGzGzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx15NRdlkosQ65JU0GoQRRTDA-AAAA-FKmo0AQYcEBTwC-
```

:::

2.1.

#### 优势

- 应对小规模拉怪，更多地逐个处理而不是连锁拉怪。
- 每30秒都有良好的伤害选择，使用[[spell:447444]]。
- [[spell:451840]] 让这套构筑在期间成为一台强力机器 [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>) 周或特定有护盾的地下城中成为强力选择。

2.2.

#### 劣势

- 应对[[spell:447444]]生效期间不断移动的怪群。

2.3.

#### 构筑选择

- [[spell:238558]]是默认选择，但如果你更喜欢更偏向持续伤害的
  
  
  
  
  ```
  playstyle you can use [[spell:1279350]] instead for more damage on low 
  
  target count pulls, or more sustained damage in really long high key pulls.
  ```
- 如果你在充满大量致命魔法伤害的地下城中，你可以
  
  
  
  
  ```
  consider using  [[spell:451569]] over [[spell:451311]].
  ```
- 如果你需要更多的怪物控制，可以尝试使用
  
  
  
  
  ```
  [[spell:451204]] instead of [[spell:451018]]. This might make the tanks
  
  job harder in some cases, so be sure to coordinate with your group on what is
  
  best for that key.
  ```

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者 [[spell:373310]]

当你开始推进更高层数时，可以考虑加入

[[spell:373310]]来获得更高的纯粹AoE伤害。这套构筑依赖于手动

将[[spell:589]]扩散到存活时间较长的目标上，让

[[spell:1279350]]打出最大伤害。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 大秘境高层 - 虚空编织者
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtFwsxAADGzMzY2GzgZGMDGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtFwsxAADGzMzY2GzgZGMDGA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaDT7Uhx15pSMRdpsQ65JD0GoASTDQA-AAAA-FKmo0AQYcEBTwC-
```

:::

2.4.

#### 优势

- 存活时间长的大规模拉怪（如果怪物存活不到10秒就不要扩散[[spell:589]]）。
- 每30秒都有良好的伤害选择，使用[[spell:447444]]。

2.5.

#### 劣势

- 任何存活时间短且目标数量多、你没有时间扩散[[spell:589]]的情况。
- 应对[[spell:447444]]生效期间不断移动的怪群。

2.6.

#### 构筑选择

- 如果你在充满大量致命魔法伤害的地下城中，你可以
  
  
  
  
  ```
  consider using  [[spell:451569]] over [[spell:451311]].
  ```
- 如果你需要更多的怪物控制，可以尝试使用
  
  
  
  
  ```
  [[spell:451204]] instead of [[spell:451018]]. This might make the tanks
  
  job harder in some cases, so be sure to coordinate with your group on what is
  
  best for that key.
  ```

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官

如果你想要一套更依赖[[spell:15407]]和[[spell:120644]]的构筑，

我会尝试 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官大秘境构筑。

**使用下方的复制按钮生成导入代码，在游戏中使用！** 如果你更喜欢

更偏向持续伤害的玩法风格，特别是在目标数量较少或持续时间较长的拉怪中，

你可以改用[[spell:1279350]]而不是[[spell:238558]]。

:::talents 苦难 大秘境 - 执政官
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZWmxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::talents 噩梦召唤 大秘境 - 执政官
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZ2mxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CIQAAAAAAAAAAAAAAAAAAAAAAMMDzAAAAAAAAAAAAwMLmxMbzMmZWmxYG2mZGzMzYDZGLmpBYGgZ2MDzmBgMGLAYGgxMzMmNmZbZAmBDA"
}
```
:::

:::details 来源计算器编码
```
#CE-BQtwQWC04ct1Jqy26+eooohakwwYaeKUEZB-ZaCT7Uhx5NSqMRdZkksQ6GoQRRTDUEA-AAAA-CIMm0Ic4QhBQxS-
```

:::

2.7.

#### 优势

- 比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者构筑有更高的单体伤害。

2.8.

#### 劣势

- 需要更多围绕你冷却时间的协调拉怪。
- 每60秒只有一个伤害窗口。

2.9.

#### 构筑选择

- [[spell:238558]]是默认选择，但如果你更喜欢更偏向持续伤害的
  
  
  
  
  ```
  playstyle you can use [[spell:1279350]] instead for more damage on low 
  
  target count pulls, or more sustained damage.
  ```
- 你可以根据大秘境层数调整你的英雄天赋抉择点：
  
  
  
  
  - [[spell:449874]] - 通用AoE伤害，当前默认选项
  - [[spell:454001]] - 在持续时间较长的战斗中表现更好，并且激活
    
    
    
    
    ```
            the [[spell:228260]] duration pause outside of combat or while stunned. This
    
            pause can be very helpful for lower key levels.
    ```

1.

### 快速循环技巧

暗影在AoE中的玩法风格与单体非常相似，依赖于

通过这些单体技能的相互作用获取顺劈伤害

[[spell:199484]]产生顺劈伤害。诀窍在于用[[spell:1227280]]管理持续伤害，

或用你手动施放的[[spell:34914]]来补充。

没有这些，你的AoE伤害会显著降低。

使用这些技能进行AoE的核心玩法需要你做出

关于如何输出伤害的根本性选择。

- **AoE中更高的优先目标伤害？** 将[[spell:335467]]
  
  
  
  
  倾泻到血量最高/最重要的目标上。
- **更高的整体AoE伤害？** 每次获得足够理智值时，对新目标施放[[spell:335467]]
  
  
  
  
  钥匙层数的提升。

通常带有[[spell:407470]]的构筑只会将[[spell:335467]]

倾泻到主目标上，但有了[[spell:409044]]你可以选择

也这样做。如果你对扩散感兴趣，通常需要点出扭曲现实，

如果你对扩散感兴趣的话。

你会发现大多数暗影牧师玩家会更倾向于偏向更多

优先目标伤害，主要是因为这是一种更不常见的模式，有助于

你更好地融入队伍配置，特别是在高层大秘境中。注意

根据你想要偏向哪种选择，你应该点出相应的

天赋，如上所述。下面的构筑默认偏向更多优先目标

伤害。

3.1.

#### 单体伤害分析

暗影牧师有几套构筑会在不同层级的地下城中使用。

你应该根据队伍的AOE能力选择合适的构筑

或单体伤害来选择合理的构筑。一套构筑增加的单体伤害越多，它的AoE

伤害就越低，但所有地下城构筑都是不错的选择。

下面列出了我们各种构筑单体伤害的大致对比。

我列出这个是为了帮助你在需要单体伤害时

决定使用什么构筑。

<table>&#10;<tr>&#10;<th>英雄天赋</th>&#10;<th>构筑</th>&#10;<th>差异</th>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp"/> 执政官</span></td>&#10;<td>[[spell:1279350]]</td>&#10;<td>0.0% (216k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp"/> 执政官</span></td>&#10;<td>[[spell:238558]]</td>&#10;<td>-2.8% (210k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> 虚空编织者</span></td>&#10;<td>[[spell:1279350]]</td>&#10;<td>-4.0% (207k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> 虚空编织者</span></td>&#10;<td>[[spell:1279350]]（尤格-萨隆）</td>&#10;<td>-6.3% (202k)</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp"/> 虚空编织者</span></td>&#10;<td>[[spell:238558]]</td>&#10;<td>-9.2% (196k)</td>&#10;</tr>&#10;</table>

你应该根据团队的需求在我们的天赋树中做出多种选择，

该层最适合的伤害类型，以及实际的层数和

词缀，在我们的天赋树中做出许多选择。

1.

### 功能技能与能力

### 打断、昏迷和阻止

4.1.

#### 打断

[[spell:15487]]是你作为暗影牧师的打断技能，还可以根据怪物类型

以及之后几秒内无法施法，具体取决于怪物类型。

为了更容易打断目标，强烈建议你使用焦点打断宏

来施放沉默。这让你可以攻击特定的高优先级怪物，但保持你的

焦点在你可能想打断的怪物上。这个宏会优先对你的焦点目标

施放（如果存在），然后是你的鼠标悬停目标，最后是你当前的目标。

#### 沉默

```wow-macro
#showtooltip

/stopcasting

/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 沉默
```

为了在混乱的场景中快速设置焦点目标，我们还推荐使用

**鼠标悬停设为焦点宏**。这会将你的焦点设置为你的

当前鼠标悬停目标。

#### 焦点宏

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示焦点目标的施法，这样你

就能随时在冷却好时打断它，或与你的队友配合

打断。

4.2.

#### 眩晕与"打断"

[[spell:8122]]是你的主要AoE打断技能。恐惧效果在

PvE中没那么重要，但它确实起到了伪AoE打断的作用（也被称为

停手）作用于8码内的所有敌人。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官，你可以点出

[[spell:453918]]来获得额外的停手效果。根据

伤害量的多少，你也可以考虑使用

[[spell:55676]]。不过，如果你能善加利用，可以考虑

使用[[spell:196704]]来在大秘境中获得更多整体停手次数。

[[spell:9484]]允许你每次控制一个亡灵或畸变体敌人。

这在第二赛季中很少使用，不会经常用到。

[[spell:205364]]在一定程度上也可以用作单体停手技能。

虽然这个方法稍显复杂，但它可以用来将一个怪物锁定控制长达30秒。

你随时可以用 **/petdismiss** 宏来提前取消它。另外，有几个地下城中

的怪物在被精神控制时仍然会施放有用的技能。

#### 精神控制

```wow-macro
#showtooltip

/petdismiss

/cast [known:精神控制] 精神控制; 统御意志
```

### 其他功能

4.3.

#### 其他功能

由于该专精在功能性方面拥有大量选择，

在每把大秘境开始前调整职业天赋至关重要，

以确保你在需要时优化功能性，或者在不需要功能性时选择更多

如果你不需要这些功能性技能，可以选择防御性技能。

虽然我们不带战斗复活进入大秘境，但你可以购买

[[item:269586]] 来支援你的队伍。你

不需要是工程师也能使用这件物品。

[[spell:21562]] 为队伍中所有人提供额外5%的

耐力，这提供了一种独特的增益，有助于在面对一些

高伤害技能时存活下来。

[[spell:453]]提供了一个有趣的替代方案

[[spell:114018]] 提供了一个有趣的替代方案，根据可用空间，可能帮助你的队伍跳过更

致命的大秘境怪群，取决于可用空间。这一机制已被更改为

一个范围施法技能，对10码半径内的所有怪物生效，冷却时间

很短。创造性地使用它可以大大简化大秘境的路线规划。

[[spell:586]] 有几个很好的功能性技能值得指出，其中最重要

的是仇恨消除机制。如果你发现自己在开怪时

仇恨超过了坦克，你可以使用[[spell:586]]轻松绕过这一

仇恨掉落并继续大秘境。有了[[spell:373446]]职业

天赋，这还会使渐隐术变成一个小防御技能。有了[[spell:108942]]，

这便成了一个轻松摆脱某些定身效果的工具。

[[spell:373466]] 是职业树中最大的功能性技能，

使用在队友身上时，能有效地为你的队伍提供一次额外的

[[spell:10060]]。虽然关于哪些专精最适合获得它存在

关于哪些专精最适合此情况的讨论，我通常更倾向于

将其给邪恶死亡骑士、法师、术士、湮灭 唤魔师、

增强萨满，或者任何技能冷却时间为2分钟的人。

[[spell:528]] 允许你驱散敌人身上的增益效果。

这在地下城中极其有用，因为许多地下城中的很多

怪群往往会给自己施放某种增益。虽然这在

某些地下城中比其他地下城更重要，但能够做到这一点

依然很宝贵。你也可以用它来进行定点驱散。

[萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>).

[[spell:213634]] 驱散友方目标身上的所有疾病效果。

这相当小众，但在某些情况下仍然极其有用。本赛季最大的

本赛季的使用场景将是驱散掉 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>).

[[spell:32375]] 仍然是我们技能库中一项有益的能力。

驱散非常重要，而群体驱散允许进行进攻性和

防御性驱散。仅用一个公共冷却就能驱散多个敌人或友方

目标，这一点在特定情况下非常强大。然而，群体驱散

确实有相当长的2分钟冷却时间。

你也可以群体驱散 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 同样适用。

[[spell:15286]] 根据你造成的单体

伤害来治疗队友，冷却时间为2分钟。根据

情况，它可以非常强力。注意，

我们的持续伤害技能的伤害也会转化为治疗量。

[[spell:73325]] 将一名友方队伍成员拉向你。它可能

通常更有用，但有时能救下某人。

[[spell:1250691]] 提供范围定身效果。

1.

### 地下城专属技巧

本节重点介绍牧师专属的技巧和窍门，以帮助应对

特定地下城的首领和小怪。

### 天赋选择速查表

关于该使用哪些天赋的快速指南，请查看下表中的地下城和词缀，

并参阅建议的功能性天赋列表，你应该

确保将其纳入你的天赋构建中。你也可以使用

[大秘境功能](<https://www.curseforge.com/wow/addons/mythic-plus-utility-mpu>)

插件来提醒你切换到各种天赋。

<table>&#10;<tr>&#10;<th>地下城</th>&#10;<th>词缀</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=148" rel="noopener noreferrer">萨拉塔斯的交易：扬升</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=158" rel="noopener noreferrer">萨拉塔斯的交易：虚缚</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=162" rel="noopener noreferrer">萨拉塔斯的交易：脉冲</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;<td> <a href="https://www.wowhead.com/mythic-affix=160" rel="noopener noreferrer">萨拉塔斯的交易：吞噬</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;<td></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;<td></td>&#10;</tr>&#10;</table>

基于以上选择，你应该使用以下职业天赋：

![Purify Disease not Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：萨拉塔斯的交易：吞噬（未启用）；毒牙祭坛（未启用）；诸王之眠（未启用）。**

![Purify Disease Talented](<https://static.icy-veins.com/images/wow/classes/priest/purify_disease.jpg>)**适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；诸王之眠（启用）。**

![Mass Dispel not Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：萨拉塔斯的交易：升腾者（未启用）；萨拉塔斯的交易：吞噬（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；红玉新生法池（未启用）；塞塔里斯神庙（未启用）。**

![Mass Dispel Talented](<https://static.icy-veins.com/images/wow/classes/priest/mass_dispel.jpg>)**适用条件：萨拉塔斯的交易：升腾者（启用）；萨拉塔斯的交易：吞噬（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；红玉新生法池（启用）；塞塔里斯神庙（启用）。**

![Phantasm not Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：萨拉塔斯的交易：吞噬（未启用）；毒牙祭坛（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）；致盲之谷（未启用）；虚空之痕竞技场（未启用）。**

![Phantasm Talented](<https://static.icy-veins.com/images/wow/classes/priest/phantasm.jpg>)**适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；致盲之谷（启用）；虚空之痕竞技场（启用）。**

- **适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；诸王之眠（启用）。** [[spell:213634]]
- **适用条件：萨拉塔斯的交易：升腾者（启用）；萨拉塔斯的交易：吞噬（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；红玉新生法池（启用）；塞塔里斯神庙（启用）。** [[spell:32375]]
- **适用条件：萨拉塔斯的交易：吞噬（启用）；毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；致盲之谷（启用）；虚空之痕竞技场（启用）。** [[spell:108942]]
- **适用条件：萨拉塔斯的交易：虚空束缚（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者以获得[[spell:451840]]
- **适用条件：萨拉塔斯的交易：吞噬（未启用）；萨拉塔斯的交易：虚空束缚（未启用）；萨拉塔斯的交易：升腾者（未启用）；毒牙祭坛（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；红玉新生法池（未启用）；塞塔里斯神庙（未启用）；致盲之谷（未启用）；虚空之痕竞技场（未启用）。** 没有特定的天赋建议。

### 毒牙祭坛

5.1.

#### 拉维

- 使用[[spell:213634]]驱散[[spell:1296069]]，从 [拉维](<https://www.wowhead.com/npc=259445>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:1296069]]，从 [拉维](<https://www.wowhead.com/npc=259445>).

5.2.

#### 扭缠盘蛇

- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:1310974]]，从 [扭缠盘蛇](<https://www.wowhead.com/npc=259446>).

5.3.

#### 祖尔加

- 无特殊提示。

5.4.

#### 小怪

- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:1294569]]，从 [双牙劫掠者](<https://www.wowhead.com/npc=261554>).

### 纳洛拉克的洞穴

5.5.

#### 囤宝狂人

- 无特殊提示。

5.6.

#### 寒冬哨兵

- 无特殊提示。

5.7.

#### 纳洛拉克

- 无特殊提示。

5.8.

#### 小怪

- 使用[[spell:32375]]驱散[[spell:1297696]]，从 [低语大地看守者](<https://www.wowhead.com/npc=241814>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:1309919]]，从 [严寒槌手](<https://www.wowhead.com/npc=241872>).

### 诸王之眠

5.9.

#### 黄金风蛇

- 无特殊提示。

5.10.

#### 殓尸者姆沁巴

- 无特殊提示。

5.11.

#### 部族议会

- 无特殊提示。

5.12.

#### 始皇达萨

- 无特殊提示。

5.13.

#### 小怪

- 使用[[spell:32375]]驱散[[spell:270920]]，从 [瓦希女王](<https://www.wowhead.com/npc=137478>).
- 使用[[spell:32375]]驱散[[spell:270901]]，从 [总管姆巴拉](<https://www.wowhead.com/npc=134251>).
- 使用[[spell:32375]]驱散[[spell:269935]]，从 [祖尔的爪牙](<https://www.wowhead.com/npc=133943>).
- 使用[[spell:32375]]驱散[[spell:1296671]]，从 [卫队长阿图](<https://www.wowhead.com/npc=137473>).
- 使用[[spell:213634]]驱散[[spell:267763]]，从 [未完成的木乃伊](<https://www.wowhead.com/npc=136264>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:12548]]，从 [幽灵萨满祭司](<https://www.wowhead.com/npc=135239>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:271564]]，从 [防腐液](<https://www.wowhead.com/npc=137989>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:106823]]，从 [帕特拉女王](<https://www.wowhead.com/npc=137486>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:1294815]]，从 [复苏的巫师](<https://www.wowhead.com/npc=134174>).

### 密谋小径

5.14.

#### 凯斯媞亚·魔力之心

- 无特殊提示。

5.15.

#### 赞恩·刃悲

- 无特殊提示。

5.16.

#### 歼灭者萨祖克斯

- 无特殊提示。

5.17.

#### 利希尔·烬怒

- 无特殊提示。

5.18.

#### 小怪

- 使用[[spell:32375]]驱散[[spell:1229433]]，从 [恶毒的法师](<https://www.wowhead.com/npc=236084>).

### 红玉新生法池

5.19.

#### 梅莉杜莎·寒妆

- 无特殊提示。

5.20.

#### 柯姬雅·焰蹄

- 无特殊提示。

5.21.

#### 基拉卡与厄克哈特·风脉

- 无特殊提示。

5.22.

#### 小怪

- 使用[[spell:32375]]驱散[[spell:373973]]，从 [原始织焰者](<https://www.wowhead.com/npc=190207>).
- 使用[[spell:32375]]驱散[[spell:391031]]，从 [原始雷云](<https://www.wowhead.com/npc=197509>).
- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:373803]]，从 [灌能雏龙](<https://www.wowhead.com/npc=187894>).

### 塞塔里斯神庙

5.23.

#### 阿德里斯和阿斯匹克斯

- 无特殊提示。

5.24.

#### 米利克萨

- 无特殊提示。

5.25.

#### 加瓦兹特

- 无特殊提示。

5.26.

#### 塞塔里斯的化身

- 无特殊提示。

5.27.

#### 小怪

- 使用[[spell:32375]]驱散[[spell:1310739]]，从 [躁动的云雾](<https://www.wowhead.com/npc=136076>).

### 致盲之谷

5.28.

#### 光明众花

- 无特殊提示。

5.29.

#### 圣光猎手伊库兹

- 无特殊提示。

5.30.

#### 护光者鲁伊亚

- 无特殊提示。

5.31.

#### 兹欧凯特

- 无特殊提示。

5.32.

#### 小怪

- 使用[[spell:586]]配合[[spell:108942]]移除[[spell:1238084]]，从 [鞭笞者](<https://www.wowhead.com/npc=245410>).

### 虚空之痕竞技场

5.33.

#### 塔兹拉尔

- 无特殊提示。

5.34.

#### 阿特洛苏斯

- 无特殊提示。

5.35.

#### 煞戎努斯

- 无特殊提示。

5.36.

#### 小怪

- 使用 [[spell:586]] 配合 [[spell:108942]] 从 [[spell:1285066]] 上移除 [[spell:1263983]]。
- 使用 [[spell:586]] 配合 [[spell:108942]] 从目标上移除 [[spell:1249621]] [愤怒的科罗斯克](<https://www.wowhead.com/npc=249590>).

1.

### 应对词缀

### 词缀：升腾

6.1.

#### 暗影牧师的升腾词缀应对

每隔一段时间，宇宙能量球会在你的小队附近生成。

作为一名暗影牧师，你可以使用以下法术来清除这些光球：

- [[spell:8122]]
- [[spell:32375]] - 最多作用于5个目标
- [[spell:15487]] - 通常最好留着用在别处
- [[spell:64044]]
- [[spell:528]]

### 词缀：虚缚

6.2.

#### 暗影牧师的虚空束缚词缀应对

当虚空绑定词缀生成时，你应该立即切换目标到

集火击杀它。如果你是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者，请务必优先使用

施放 [[spell:32379]] 以获得 [[spell:451840]] 的增益。

重要的一点是要认识到 [[spell:451840]] 的额外伤害

会贡献于 [[spell:199484]] 的伤害，因此优先将

[[spell:32379]] 施放在这只怪物身上对我们来说是巨大的伤害提升。

### 词缀：脉冲星

6.3.

#### 暗影牧师的脉冲星词缀应对

作为一名暗影牧师，对于应对脉冲星词缀没有特别的建议。

### 词缀：吞噬

6.4.

#### 暗影牧师的吞噬词缀应对

当 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 存在的那一周，你应该始终

准备好使用 [[spell:32375]] 或 [[spell:213634]] 来驱散

尽可能频繁地对你的队伍使用 [[spell:440313]]。你也可以用

配合点了 [[spell:108942]] 天赋的 [[spell:586]]，或像

[[spell:20594]].

如果你没有驱散减益的手段了，你也可以使用

[[spell:19236]]、[[spell:373481]] 或 [[spell:2061]]

来帮助移除该减益。

1.

### 大秘境深度输出循环提示

单体和多目标循环在大秘境+中都不会改变，

内容。有关 [暗影 牧师](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-guide>) 输出循环的更多信息，

请参阅

[循环、冷却与技能页面](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>).

如果你想要更详细的、使用不同天赋的配置，请

查看循环页面。

[暗影牧师的输出循环与冷却技能](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-rotation-cooldowns-abilities>)

:::details **大秘境+执行清单**
**跟随坦克开怪**

- 提前开始布置持续伤害效果，并使用

[[spell:586]]

在仇恨稳定时安全地预铺伤害。

**爆发式移动**

- 在公共冷却间隙碎步移动，并用瞬发法术如

[[spell:1240401]]

,

[[spell:32379]]

，以及

[[spell:335467]]

.

**不要错过冷却技能的使用**

- 损失

[[spell:228260]]

,

[[spell:10060]]

，或者

[[spell:263165]]

的使用次数通常比微小的装备差距更重要。

:::

:::details 常见问题为什么我在相似层数的大秘境+中伤害不稳定？
大秘境+的战斗记录会因路线、拉怪规模、坦克节奏、目标数量和优先目标分配而有很大差异。请比较特定的首领战斗或单次大型小怪战斗，而不是只看整层的总输出。查看战斗记录时，应首先关注施法次数、冷却时机和持续伤害效果的覆盖率。

:::

:::details 如何有效查看大秘境+战斗记录
- 比较等效的拉怪和首领阶段，而不仅仅是副本结束时的总数据。
- 检查主要冷却技能是否在相同的拉怪窗口内使用，且目标数量相似。
- 确认在小怪群之间移动时 [[spell:589]] 和 [[spell:34914]] 的覆盖率保持在高位。
- 用模拟来决定天赋和装备选择，然后用战斗记录来优化执行和逐波规划。

:::

7.1.

#### 作为暗影牧师制造爆发伤害

偶尔在地下城中，可以值得打破标准循环，

以便快速击杀优先目标。在本节中，我将

讨论作为暗影牧师在这些情况下你所拥有的选择。

在标准天赋配置中，你用于爆发伤害的最佳法术是

[[spell:120644]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官) 或 [[spell:263165]]（尤其是配合

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/voidweaver.webp>) 虚空编织者）。如果有高优先级目标，你要确保

这些法术可用。通常，你会将其与类似以下的连招配合使用：

一起使用：

1. 在你需要爆发的目标生成前积攒满疯狂值。
2. 在其生成时施放 [[spell:34914]]，或让 [[spell:1227280]]
   
   
   
   
   在目标生成时命中（如果可能）。
3. 施放 [[spell:120644]]， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官
4. 将所有疯狂值倾泻到 [[spell:335467]] 上。
5. 如果满足条件，施放 [[spell:391399]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/archon.webp>) 执政官.
6. 施放 [[spell:263165]]。

如果你只是在进行常规输出，你的爆发会更出色

循环（尤其是在冷却开始时配合 [[spell:341240]]），你的爆发会更强，

但如果你准备充分，上述连招也可以在冷却之外执行。

1.

### 防御与生存指南

当你进入更高层数或特别有挑战性的首领时，

如果你没有正确应对机制，可能很难存活下来

准备或没有做出正确反应，可能很难在机制下存活。在本节中，我将

列出作为暗影牧师在大秘境中存活所拥有的所有手段。

在开始大秘境之前，你应该评估你的天赋选择，

为该层数的强度做好准备。对于任何即将到来的机制，

你应该知道是否需要使用

防御技能来减轻伤害以存活，可参考以下列表。

8.1.

#### 天赋选择

在开始大秘境之前，你应该评估该地下城对

你的队伍来说有多难。如果你在冲层，层数对你的队伍相对较高，

你应该认真考虑加入更多防御性天赋，即使这会牺牲

一些伤害。这需要逐层判断，但以下是你的选择。

如果你发现自己想要更多防御点数但已经用完了

点数，你可以选择牺牲各种价值较低的职业天赋。

8.1.1.

##### 职业天赋

- [[spell:390667]]
- [[spell:193063]]
- [[spell:373446]]
- [[spell:238100]]
- [[spell:373450]]
- [[spell:108945]]

8.1.2.

##### 专精天赋

- [[spell:377065]]

8.2.

#### 防御性配装

提高防御能力的一种方法是考虑你可以做出的装备选择。

你有两种主要方式：加入防御性装备或调整

副属性。这对于冲击更高的钥石可能至关重要，因为层数越高越难

存活，甚至可能值得牺牲一些输出以获得更多防御能力。

8.2.1.

##### 副属性

另一件需要考虑的事情是你的副属性。默认情况下，暗影牧师

通常会堆叠大量急速和精通装备，但你也可以将

部分预算直接转向精通以获得更多伤害。将属性转向

精通通常不会损失太多输出，即使在较低装备等级时也是如此。检查

查看属性页面，了解如何将其融入你的装备。

[暗影牧师属性优先级](<https://www.icy-veins.com/wow/shadow-priest-pve-dps-stat-priority>)

8.3.

#### 防御技能

暗影牧师有若干防御性技能，你应该计划好使用并循环轮换

以应对各种机制。你应该根据需要经常使用冷却时间较短的技能

来应对即将到来的机制，并将像[[spell:47585]]这样的大冷却技能

留给大额伤害。

- 在点出[[spell:193063]]天赋时使用[[spell:2061]]。
- 使用[[spell:17]]来获得一个小护盾。
- 在点出[[spell:373446]]天赋时使用[[spell:586]]。
- [[spell:19236]]
- [[spell:47585]]

你也可以使用 [Not Even Close](<https://not-even-close.com/>)

网站来帮助了解你需要多少血量才能在某些机制下存活。

8.3.1.

##### 插件

- [
  
  
  
  
  Deadly Boss Mods - 地下城]([https://www.curseforge.com/wow/addons/deadly-boss-mods-dbm-dungeons](<https://www.curseforge.com/wow/addons/deadly-boss-mods-dbm-dungeons>)）或
  
  
  
  
  [LittleWigs](<https://www.curseforge.com/wow/addons/little-wigs>)

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月25日：** 为虚空编织者添加高层大秘境配装变体。
- **2026年8月17日：** 按天赋配装更新单体伤害分解。
- **2026年8月10日：** 在执政官大秘境配装中重新添加萦绕暗影。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年8月3日：** 为第二赛季效用网格更新循环切换和地下城效用提示。
- **2026年6月15日：** 针对12.0.7版本进行了审阅，包含针对 虚空编织者 的特定尤格-萨隆构筑。
- **2026年5月19日：** 为 虚空编织者 构筑添加关于尤格-萨隆神像的说明。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月6日：** 添加大秘境执行检查清单和实用的日志审阅章节。
- **2026年4月4日：** 更新大秘境构筑。
- **2026年4月1日：** 为虚空触及添加注意事项。
- **2026年3月29日：** 为高层大秘境推荐 执政官，并添加关于获得更多范围伤害的说明。
- **2026年3月18日：** 更新天赋构筑。
- **2026年3月16日：** 已针对第1赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对职业点数门槛的更改更新天赋树。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月26日：** 添加天赋视频指南，并在宏图大道中加入幻象。
- **2025年8月18日：** 在第一周后添加更多地下城技巧。
- **2025年8月7日：** 在殁言先驱漏洞修复后更新 虚空编织者 构筑。
- **2025年8月4日：** 针对11.2.0补丁进行更新。
- **2025年6月15日：** 审阅11.1.7补丁的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月19日：** 新增巢穴的视频链接。
- **2025年3月10日：** 新增更多副本提示，附带视频和WeakAuras链接。
- **2025年3月9日：** 第一周后新增副本提示。
- **2025年3月1日：** 新增心灵鞭笞虚空编织者构建和更多副本提示。
- **2025 年 2 月 24 日：** 更新第二赛季构建，并为每个副本新增提示。
- **2024年12月15日：** 推荐从三重偶像开始。
- **2024年11月4日：** 针对近期热修进行复核。
- **2024年10月21日：** 对于 执政官 配装，已默认改为使用持续效能来处理脱战暂停机制。
- **2024年10月15日：** 从千丝之城中移除幻象。
- **2024年10月10日：** 更新虚空编织者配装。
- **2024年10月9日：** 更新单体目标 + 暗影 Crash 虚空编织者配装。
- **2024 年 10 月 7 日：** 根据最近的热修复更新配装建议。
- **2024年10月1日：** 添加关于迷雾唤灵者使用闪避球击杀小怪的技巧。
- **2024年9月25日：** 为混合配装设置独立章节。
- **2024年9月16日：** 更新天赋章节以提高可读性。
- **2024年9月9日：** 为执政官大秘境配装添加变体以获得更多单体能力。
- **2024年8月31日：** 更新单体目标 + 暗影 崩塌流派以适用于虚空编织者，并将执政官整合为单一构建。
- **2024年8月22日：** 为“地心之战”的上线更新了页面。
- **2024年8月13日：** 更新天赋配装以重新开始使用克苏恩偶像，并针对职业树的改动进行调整。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月13日：** 添加关于高层大秘境防御性配装的章节。
- **2024年5月9日：** 添加关于诺库德阻击战中格拉尼思的心灵控制技巧的说明。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月30日：** 为奥达曼添加幻影建议，并添加关于疯狂之触使用的说明。
- **2024年4月29日：** 修复了在奥达曼中推荐 净化疾病 时切换器的错误。
- **2024年4月28日：** 为注能大厅添加幻影。
- **2024年4月26日：** 为诺库德添加 净化疾病 和精神控制。
- **2024年4月25日：** 移除碧蓝魔馆的幻影建议。
- **2024年4月22日：** 为第4赛季更新天赋配置。
- **2024年3月19日：** 为潮汐王座添加 神圣 新星建议，以及为黑鸦堡垒和迦拉克隆陨落添加新的精神控制技巧。
- **2024年2月19日：** 为幽灵优先级天赋配置添加精神鞭笞心灵之眼变体。
- **2024年2月14日：** 修复幽灵天赋配置中插件的名称，并为心灵之眼版本添加直接天赋字符串。
- **2024年2月13日：** 更新所有天赋配置的默认职业天赋，并将暗影幻象天赋配置更新为幽灵优先级天赋配置版本。
- **2024年2月13日：** 移除关于在永恒绽放中对毒刺使用精神控制的提及。
- **2024年2月9日：** 添加关于对岩脊毒刺使用精神控制的说明。
- **2024年2月8日：** 添加多目标输出循环视频链接。
- **2024年1月28日：** 建议在所有受折磨词缀的钥石副本中使用 群体驱散。
- **2024年1月21日：** 根据近期增益更新虚空爆发大秘境天赋配置的默认设置。
- **2024年1月15日：** 添加视频链接和更多WeakAura。
- **2023年12月23日：** 添加舍弃心灵掌握和无法逃脱的折磨的天赋配置选项。
- **2023年12月18日：** 根据近期心灵链接增益更新大秘境天赋配置。
- **2023年12月13日：** 在钥石天赋配置中，放弃尤格萨隆偶像，改用阴险之怒。
- **2023年12月8日：** 在潮汐王座中默认建议使用 群体驱散。
- **2023年12月3日：** 更新黑暗升华三偶像天赋配置，默认使用精神鞭笞。
- **2023年12月1日：** 添加更多关于何时选择哪种配置的信息。重构暗影幻象配置，使其与第3赛季套装加成配合得更好。
- **2023年11月25日：** 为各副本添加更多驱散建议。
- **2023年11月24日：** 在阿塔达萨建议中添加净化疾病。
- **2023年11月20日：** 将第2赛季构筑更名为暗影化身构筑，并讲解其使用场景。
- **2023年11月17日：** 更新第3赛季的秘境+构筑，使其更加精简。
- **2023年11月16日：** 添加第2赛季套装构筑，供提升装备时使用。
- **2023年11月6日：** 重新调整章节顺序，并更新第3赛季和10.2补丁的信息。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年8月13日：** 更新视频链接，并阐明三神像配置之间的差异。
- **2023年8月9日：** 添加更多关于何时选择哪种构筑的细节，并润色多个章节使内容更清晰。
- **2023年8月8日：** 添加新章节，阐明何时使用各副本构筑。
- **2023年8月7日：** 根据近期对各种法术的热修削弱添加新构筑。
- **2023年7月31日：** 为群体驱散使用场景添加一些缺失的条目。
- **2023年7月23日：** 已根据近期热修进行审阅，并提及新的天赋选项。
- **2023年7月17日：** 重构以使用新的天赋布局。
- **2023年7月10日：** 已更新10.1.5补丁的天赋字符串。
- **2023年6月27日：** 调整构筑以包含扭曲现实、暗影化身和心灵操纵者选项。
- **2023年6月23日：** 更新扭曲现实的一些数据。
- **2023年6月22日：** 修正精神鞭笞与心灵刺的对比问题。
- **2023年6月20日：** 澄清暗影法力值与心灵法力值，以及心灵刺与精神鞭笞的DPS对比。
- **2023年6月16日：** 添加更多关于在大秘境中使用心灵刺的原因细节。
- **2023年6月7日：** 添加爆发伤害章节。
- **2023年5月30日：** 添加几个用于处理第2赛季词缀的鼠标悬停宏。
- **2023年5月28日：** 移除关于注能大厅的净化疾病和精神控制的建议。
- **2023年5月26日：** 调整章节顺序，并添加更多关于防御技能使用的细节。
- **2023年5月24日：** 删除了部分示例起手式，改用循环页面。
- **2023年5月22日：** 为第2赛季添加了更多提示和细节。
- **2023年5月21日：** 添加了按地下城和词缀查看功能选择的简便方法。
- **2023年5月19日：** 添加了精神控制部分，介绍值得控制的有趣小怪。
- **2023年5月6日：** 建议在注能大厅使用群体驱散，并添加了更多关于在大秘境中使用精神鞭笞的细节。
- **2023年5月4日：** 添加第2赛季地下城实用工具部分。
- **2023年5月1日：** 为10.1.0更新天赋配置和建议。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年2月26日：** 修正心能游戏目标上限的错误。
- **2023年2月22日：** 添加关于在大秘境中使用精神灼烧的注意事项。
- **2023年2月17日：** 为示例起手循环添加更多细节。
- **2023年2月4日：** 调整常见天赋配置的单体目标差异。
- **2023年2月2日：** 添加更多关于驱散和群体驱散的用途。
- **2023年1月24日：** 更新10.0.5的天赋构筑和建议。
- **2023年1月12日：** 为怨毒词缀添加虚空触须建议。
- **2023年1月11日：** 根据近期的增益添加新的天赋构筑。
- **2022年12月23日：** 在大秘境中选择两种天赋构筑时添加更多细节。
- **2022年12月11日：** 添加一些第一赛季开局的技巧。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月5日：** 添加了关于大秘境起手式和简化版优先级列表的章节。
- **2022年10月31日：** 更新天赋构筑以不再建议心灵链接，并移除了无偶像构筑。
- **2022年10月26日：** 更新构筑以点出半透明影像。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到大量实用的宏和插件，让你在《魔兽世界》12.1.5补丁中游玩暗影牧师时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件与宏页面。在这里，我们将介绍一些实用的插件，帮助你通过更详尽的界面提升游戏体验，同时提供一些常用的暗影牧师宏。你只需点击每个单独代码块上的"Copy"按钮即可导入这些宏。

1.1.

#### 天堂之羽

#### 天堂之羽

```wow-macro
#showtooltip
/cast [@player] 天堂之羽
```

这是一个简单的宏，它会始终将[[spell:121536]]施放在你的脚下。

1.2.

#### 天堂之羽 + 身心合一

#### 移动功能二合一

```wow-macro
#showtooltip
/cast [known:121536,mod:shift,@player] 天堂之羽; 真言术：盾
```

这个宏简单地将[[spell:121536]]和[[spell:17]]合并为一个宏，这样你就可以用基本相同的键位轻松使用这两个技能。默认按下时施放真言术：盾，而按住变换再按相同键位则施放天堂之羽。

#### 移动技能循环

```wow-macro
#showtooltip
/castsequence [known:121536,@mouseover,help,nodead][known:121536,@player] reset=6 真言术：盾, 天堂之羽, 天堂之羽, 天堂之羽; 真言术：盾
```

这是另一种移动宏版本，让你可以反复按同一个键来施放正确的移动技能，从[[spell:17]]开始。如果你想要更简单的、不需要mod:shift的宏，可以试试这个。

1.3.

#### 能量灌注

#### 基础能量灌注

```wow-macro
#showtooltip
/cast [@INSERTPLAYERNAMEHERE,help,nodead][] 能量灌注
/cast [@player] 能量灌注
```

在使用[[spell:373466]]时，这是一个将[[spell:10060]]施放在队友身上的实用宏，以确保你的团队从中获得最大收益。你需要手动输入你希望给予能量灌注的玩家名字，但如果目标超出你的施法范围，它仍会将技能施放在你自己身上。如果你希望在一场战斗中对不同的玩家施放，我建议将 **@INSERTPLAYERNAMEHERE** 使用 **@mouseover** 替换掉，并在每次施法时将鼠标悬停在你想要施放的目标上。

如果你发现这个宏有时不能正常工作，你应该避免在想施放时疯狂连按宏。如果你在施放其他技能的过程中将宏排入动作队列，它可能会导致技能中断。

1.4.

#### 高级能量灌注宏

如果你发现自己经常编辑宏来更换给予[[spell:10060]]的目标，你可以使用以下宏组合来简化操作。

第一个宏需要你选中你想给予[[spell:10060]]的玩家。点击该宏后，它会自动将目标的名字更新到第二个宏中，这样你就无需手动输入了。

#### 高级能量灌注

```wow-macro
/run local n=UnitName("target") or "player" if not InCombatLockdown() then EditMacro(GetMacroIndexByName("PI"),nil,nil,"#showtooltip\n/use 13\n/cast [@mouseover,help,nodead][@"..n..",exists,nodead][] Power Infusion") print("PI Updated to "..n) end
```

第二个宏会在你点击第一个宏时被自动编辑和覆盖。如果你想修改这个宏中的任何内容，必须在第一个宏中进行修改。你 **必须** 将这第二个宏命名为
<em>PI</em> 才能让它正常工作。

这个宏才是你最终绑定到动作条上并按下的宏。它会将[[spell:10060]]施放在你的 **鼠标悬停目标**
上（如果该目标存在且存活），然后是你用第一个宏选择的玩家，最后如果前两个条件都不满足，则施放在你自己身上。它还会使用你上方饰品栏的饰品，如果你想改用下方饰品栏的饰品，请将最后一行的13改为14。

#### 能量灌注 + 第一饰品

```wow-macro
#showtooltip
/use 13
/cast [@mouseover,help,nodead][@PLAYERNAME] 能量灌注
/cast 能量灌注
```

1.5.

#### 全能驱散宏

#### 驱散二合一

```wow-macro
#showtooltip
/cast [mod:alt,known:32375] !群体驱散; [@mouseover,help,nodead] 净化疾病; [@mouseover,harm,nodead] [harm] 驱散魔法; 净化疾病
```

这为你提供了一个游戏内按钮，可以处理牧师所有专精的驱散需求。Alt用于[[spell:32375]]；如果目标是敌人，则使用[[spell:528]]，默认情况则是[[spell:213634]]或[[spell:527]]。

如果你只是想要其中某个技能的简单鼠标悬停宏，可以改用这个：

#### 净化疾病鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] 净化疾病
```

简单的[[spell:32375]]光标宏：

#### 群体驱散光标

```wow-macro
#showtooltip
/cast [@cursor] 群体驱散
```

1.6.

#### 束缚恐惧宏

#### 束缚恐惧鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] 束缚恐惧
```

这是一个用于[[spell:9484]]的简单鼠标悬停宏，在某些大秘境情况下可能很有用。

1.7.

#### 精神控制宏

这个宏提供了一个一键解决方案，用于[[spell:605]]或[[spell:205364]]。在没有激活宠物的情况下点击它，会将任一技能施放在你的当前目标上。如果你已经通过精神控制激活了一个宠物，它会改为解散该宠物。

#### 精神控制

```wow-macro
#showtooltip
/petdismiss
/cast [known:精神控制] 精神控制; 统御意志
```

你还可以使用以下附加步骤来控制宠物的移动方向：

#### 精神控制移动

```wow-macro
/petmoveto [@cursor]
```

1.

### 暗影牧师宏

2.1.

#### 虚空洪流与光晕

如果你想要一个简单的宏在这两个技能之间切换，可以使用类似这样的写法：

#### 虚空洪流与光晕

```wow-macro
#showtooltip
/cast [known:虚空洪流] 虚空洪流; 光晕
```

2.2.

#### 防打断引导

如果你发现自己按键按得太快，导致像[[spell:263165]]这样的重要技能被打断，你可以这样调整你的技能宏。

#### 心灵震爆

```wow-macro
#showtooltip
/stopmacro [channeling:Void Torrent]
/cast 心灵震爆
```

使用这类宏，只有在你没有引导[[spell:263165]]时，它才会施放[[spell:8092]]。如果你喜欢疯狂连按技能，这会很有用。

2.3.

#### 沉默

#### 焦点沉默

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] 沉默
```

这是我推荐给任何使用有打断技能专精的玩家的基础宏。它优先打断你的焦点目标，如果你没有设置焦点，则默认打断你的当前目标。你也可以添加mod:shift作为额外条件，这样只有在按住shift键时才会打断焦点目标。

2.4.

#### 精神鞭笞镜头旋转

#### 镜头旋转

```wow-macro
/console cameraSmoothTrackingStyle 0
```

这不是一个宏，而是一条控制台命令，可以防止[[spell:15407]]在引导时转动你的镜头。对于觉得镜头干扰很烦人的玩家来说，这非常有帮助。

2.5.

#### 鼠标悬停施放持续伤害技能的宏

#### 暗言术：痛 鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] 暗言术：痛
```

#### 吸血鬼之触 鼠标悬停

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] 吸血鬼之触
```

这些宏可以在不直接点击目标姓名板的情况下，对你当前鼠标悬停的目标施放[[spell:589]]和[[spell:34914]]。在议会型首领战等需要对多个目标上持续伤害的场合中，这尤其有用。

1.

### 最佳插件

在至暗之夜中，有许多插件可以用来自定义你的界面体验。关于我指南的完整讲解，你可以查看
[暗影之书](<https://warcraftpriests.github.io/bookofshadows/guides/ui>).

以下是我建议查看的插件列表。

3.1.

#### 主界面HUD

对于主界面，我使用的是EllesmereUI，然后再添加一些额外的组件。

- [EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
- [Platynator](<https://www.curseforge.com/wow/addons/platynator>)

3.2.

#### 战斗相关插件

- [TargetedSpells](<https://www.curseforge.com/wow/addons/targetedspells>)
- [BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>)

3.3.

#### 通用插件

- [Astral Keys](<https://www.curseforge.com/wow/addons/astral-keys>)
- [Plumber](<https://www.curseforge.com/wow/addons/plumber>)
- [Glider](<https://www.curseforge.com/wow/addons/glider>)
- [MinimapStats](<https://www.curseforge.com/wow/addons/minimapstats>)

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 针对第二赛季和补丁12.1进行更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已针对第一赛季进行审阅。
- **2026年3月6日：** 添加 虚空洪流 + 光晕宏。
- **2026年2月26日：** 更新样式以便于轻松复制宏。
- **2026年2月10日：** 从束缚亡灵换为束缚恐惧。
- **2026年1月19日：** 已针对 至暗之夜 前瞻补丁进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月29日：** 更新 能量灌注 宏，在施放 能量灌注 前使用饰品。
- **2025年8月11日：** 更新全合一的 暗影 冲击宏。
- **2025年8月4日：** 针对11.2.0补丁进行更新，包含一个新宏。
- **2025年6月15日：** 审阅11.1.7补丁的信息。
- **2025年5月25日：** 在近期热修后复核信息，确认仍然准确。
- **2025年4月21日：** 新增关于11.1.5补丁新冷却管理器的说明。
- **2025年3月13日：** 移除不再有用的心灵鞭笞：疯狂宏。
- **2025 年 2 月 24 日：** 已针对 11.1.0 补丁进行审阅。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月16日：** 更新一键驱散宏和停止引导宏，使其更加简洁。
- **2024年11月4日：** 根据近期热修进行复核。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月18日：** 为11.0.5版本进行了更新，移除了旧的宏并添加了新的WeakAuras。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 新增 WeakAura 链接。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月25日：** 调整Plater模块链接并添加个人配置文件。
- **2024年4月22日：** 为第4赛季更新，包括一个新的用于追踪套装奖励的WeakAura。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年3月10日：** 更新 能量灌注 特殊宏，使其在没有设置目标的情况下也能在团本外使用。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月30日：** 添加一些新的WeakAuras和Plater模块。
- **2023年11月6日：** 已针对10.2.0补丁进行审阅。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月23日：** 已根据近期热修进行审阅。
- **2023年7月10日：** 添加了一个新的能量灌注宏。
- **2023年6月1日：** 添加简单的群体驱散宏。
- **2023年5月30日：** 添加几个用于处理第2赛季词缀的鼠标悬停宏。
- **2023年4月25日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年2月3日：** 修正精神控制宏的问题。
- **2023年1月24日：** 添加精神控制宏，并清理其他几个宏。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月30日：** 添加了额外的移动宏。
- **2022年10月27日：** 更新了信仰飞跃宏，并为天赋选择节点添加了新宏。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
