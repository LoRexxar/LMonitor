## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Azortharion。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本生存猎人指南。在这里，你将学习如何在团队副本和大秘境地下城中扮演生存猎人：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

生存大秘境资源

[全新！顶级生存天赋构筑](<https://raider.io/specs/survival-hunter/talents>)

[顶级生存大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/hunter/survival>)

[生存大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=hunter--survival>)

[热门生存队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=hunter--survival>)

1.

### 生存猎人概述

生存猎人是一个非常灵活的近战输出专精，同时也能打出可观的

远程伤害。它是一个样样通的近战职业，拥有强大的单体

和范围伤害选择，通常可以在同一套构筑中兼顾两者。生存猎人在

至暗之夜中获得了大规模重做，这极大地提升了它的地位，现在正是

尝试它的最佳时机！

灵活，但并不出众

生存在所有情况下的伤害都很一般，但良好的灵活性使其能够在范围伤害构筑中打出不错的单体伤害，反之亦然。它的爆发冷却时间非常短，这意味着它能够将爆发压缩在非常短的窗口内，几乎不需要预热时间。

出色的顺劈，一般的强度调整

生存在团队副本中具有良好的灵活性，能够调整其爆发模式，并在同一套构筑中打出不错的单体和范围伤害。它在进行范围输出时牺牲的单体伤害非常少，在低目标数量下的顺劈表现也很出色。第二赛季近战表现不佳，但仍需要一定的近战数量，生存是担任该角色的好选择。每个团队副本都需要一名猎人

[[spell:257284]]

，而生存也是担任该角色的好选择。

样样通

生存是大秘境中一个全面的输出职业，几乎在任何拉怪、Boss或情况下都能提供不错的伤害。它没有明显的弱点，也没有一个能大幅超越其他专精的特定优势领域。在小规模拉怪时它比大规模拉怪时稍好一些。它的伤害模式处于中等水平，以1分钟的爆发周期运转，使其具有中等程度的爆发性，但并不特别依赖于它的爆发。

表现平平

我们为团队带来的是平庸的实用性。1分钟冷却的眩晕/AoE打断，以及

[[spell:19577]]

，以及常规冷却的近战打断。我们的范围控制技能的灵活性和冷却时间都很一般。

[[spell:257284]]

在团队副本中是必备的，但在大秘境中并不特别强。

强力主动防御，脆弱被动防御

生存可以使用几个强大的主动防御技能，使其能够有效减轻大量伤害。然而，它的被动防御相对较弱，使其依赖于时机把握和正确使用冷却技能来在高伤害环境中生存。它在“持续性”伤害环境中表现不佳，即不断跳动的强力持续伤害效果。因此，猎人通常比其他职业需要更多的外部治疗，且技能上限相对较高，而技能下限相对较低。与其他猎人专精相比，它额外减少6%受到的伤害，使其名副其实地成为猎人专精中最能生存的。

非常出色的机动性

生存拥有出色的机动性，拥有与射击和野兽控制完全相同的技能组合，没有站桩施法，甚至

[[spell:1261193]]

，作为我们伤害的很大一部分，其射程远超纯近战范围。

[[spell:186289]]

让我们可以在相当长的时间内几乎完全从远程输出伤害，

[[spell:259495]]

是一个远程范围技能，

[[spell:1250646]]

将我们冲锋到目标身边，而当我们确实需要进入近战范围时，我们有

[[spell:190925]]

帮助我们到达那里。

1.

### 生存猎人在至暗之夜中的变化

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本为第二赛季新增了两个终局内容。

基斯希克斯的解放是一个新的团队副本首领战，而金多詹迷宫

是一个新的巨型地下堡。我们关于这两者的指南链接在下方。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

12.1.5版本是一个赛季中期的内容补丁。它还带来了

[[item:280562]]，一种用于升级你的武器、

饰品和项链至物品等级340的新货币。其他所有新增内容都在下方的

补丁中心页面。

2.3.

#### 职业改动

生存在12.1.5版本中没有实质性职业改动，该专精

的玩法与12.1版本相同。

在我们的 [配装](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>) 页面上，来自基斯希克斯团队副本的

基斯希克斯团队副本掉落的催化锻造[[item:281238]]是我们的

新版毕业手套，并且有一份新的清单，说明如何花费你的第一个

[[item:280562]]花在哪里。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_wildfirebomb_shrapnel.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 12.1版本改动

12.1版本在新赛季之外带来了相当多的内容。

有一个新区域可供探索，新的稀有怪和宝藏可供猎取，以及

大量新的住宅和幻化奖励可供收集。暴风雪还

更新了许多现有系统，并添加了生活质量

方面的改进。

:::details 显示12.1职业改动 隐藏12.1职业改动
2.5.

#### 职业改动

生存现在更加依赖炸弹，这使得哨兵

在大多数内容中脱颖而出。该专精的游戏循环与之前相似，

不过。

该 [全知典籍](<https://www.icy-veins.com/wow/omnium-folio-guide>) 借力系统延续到了第二赛季，并且它

同时影响你的天赋选择和装备。你可以在我们

专门的 [天赋](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>) 和

[配装](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>) 指南中找到详细信息。

- 新天赋：[[spell:1253053]]。[[spell:186270]]/横扫和
  
  
  
  
  [[spell:259489]]获得10%的暴击几率提升和10%的
  
  
  
  
  暴击伤害提升，每点。
- 新天赋：[[spell:389880]]。[[spell:259495]]伤害、暴击
  
  
  
  
  几率和暴击伤害均提高15%。
- [[spell:1251592]]已被移除，相关引用也已
  
  
  
  
  从多个天赋中移除。
- [[spell:459729]]已被移除。
- [[spell:1252943]]现在使[[spell:259495]]有几率
  
  
  
  
  为你的武器注入火焰，使你和你的宠物的自动攻击造成额外
  
  
  
  
  火焰伤害，持续10秒。
- [[spell:459843]]现在使[[spell:1261193]]提高
  
  
  
  
  [[spell:259495]]的冷却恢复速度60%，持续8秒。它现在
  
  
  
  
  也会被冷却管理器追踪。
- [[spell:1261229]]现在会使[[spell:259495]]的冷却时间缩短3
  
  
  
  
  秒，当你的[[spell:1261193]]伤害到一个或多个敌人时。
- [[spell:378934]]现在使你的敏捷提高3%（原为2%），
  
  
  
  
  双持时额外提高1%（原为2%）。
- [[spell:1272154]]已移动到天赋树中更容易
  
  
  
  
  到达的位置。
- **猎群领袖:** [[spell:472639]]现在持续1分钟（原为20
  
  
  
  
  秒），并且在开始团队副本战斗或大秘境
  
  
  
  
  地下城时会被取消。
- **哨兵:** [[spell:1264781]]已更新。你的自动攻击
  
  
  
  
  现在有很高的几率为你和你的宠物恢复3点集中值，而不是
  
  
  
  
  每次自动攻击恢复1点集中值，这消除了之前偏向
  
  
  
  
  双持最快武器的设定。
- **哨兵:** [[spell:1253825]]现在提供6秒的
  
  
  
  
  [[spell:259495]] 施加 [[spell:1253601]] 时的冷却缩减
  
  
  
  
  （原为4秒）。
- **哨兵:** [[spell:1253601]] 持续时间延长至16秒
  
  
  
  
  （原为12秒）。
- **哨兵:** [[spell:1253807]] 已重新设计为固定的5%
  
  
  
  
  的 火焰 伤害加成。
- **哨兵:** [[spell:1253892]] 不再提高潜行
  
  
  
  
  在使用 [[spell:199483]] 时的侦测半径。
- **套装：** **2件套：** [[spell:259388]] 提高
  
  
  
  
  [[spell:259495]] 的伤害10%。 **4件套：** 每次爆炸
  
  
  
  
  [[spell:1261193]] 会使 [[spell:259388]] 的持续时间延长1
  
  
  
  
  秒，且 [[spell:259388]] 效果提高10%。
- **错误修正：** [[spell:1259003]] 不再施加
  
  
  
  
  [[spell:1253601]] 到你当前目标以外的目标，且如果你
  
  
  
  
  没有目标，它会挑选一个猛禽横扫命中的目标。[[spell:1259003]] 不
  
  
  
  
  再从 [[spell:1253053]] 获得两次收益，[[spell:259495]] 不再
  
  
  
  
  从 [[spell:389880]] 获得两次收益，且 [[spell:263135]] 不
  
  
  
  
  再影响某些 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 召唤物两次。[[spell:459939]]
  
  
  
  
  现在已正确地由你、你的宠物和你的周期性效果施加
  
  
  
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 召唤物的周期性效果正确施加。

:::

:::

### 至暗之夜改动概述

2.6.

#### 生存 猎人 在 至暗之夜 中的改动

至暗之夜资料片为所有猎人专精带来了巨大改动，主要

侧重于精简和简化技能体系的各个方面。

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

- 核心机制：消耗 [[spell:260285]] 有几率触发
  
  
  
  
  目标身上的 [[spell:1253601]]，使你的 [[spell:259495]]
  
  
  
  
  对目标造成更高伤害，并使其冷却时间缩短6
  
  
  
  
  秒。
- 集中值上限提高至125。
- 生成 [[spell:1253601]] 触发的几率提高10%
  
  
  
  
  在 [[spell:1250646]] 期间。
- 激活 [[spell:1250646]] 后，猛禽一击按钮变为
  
  
  
  
  [[spell:1264902]]，它会掷出一个发光的飞轮，在敌人之间弹跳时造成大量范围
  
  
  
  
  在敌人之间弹跳时造成的伤害。选择节点可以使这个飞盘
  
  
  
  
  将 [[spell:259495]] 的冷却时间缩短10秒并触发
  
  
  
  
  [[spell:1253601]].

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖

- 熊的伤害被削弱了40%，使其相对于
  
  
  
  
  其他野兽更加平衡。过去，我们经常需要特别注意围绕
  
  
  
  
  围绕熊，但现在，野兽们在强度上要接近得多。
- 我们TWW第三赛季4件套的机制[[spell:201430]]回归了，但它只
  
  
  
  
  在激活后由你的第一个 [[spell:259489]] 触发
  
  
  
  
  [[spell:1250646]]。这意味着每分钟大约有8秒钟，
  
  
  
  
  你最好祈祷怪物不在移动中、不在悬崖上、不在你上方、不在你下方、
  
  
  
  
  不在你侧面，也不在你身后。

2.7.

#### 输出与游戏机制改动

- [[spell:193265]] 取代了 [[spell:185358]]，成为一种较弱的
  
  
  
  
  填充技能。它可能真的只能用来拉怪，更多是风味技能，而不是
  
  
  
  
  真正的循环技能。
- [[spell:1250646]] 是一个新的1分30秒（基础）冷却技能，取代并
  
  
  
  
  旨在将 [[spell:360952]] 和
  
  
  
  
  [[spell:269751]] 的最佳部分合二为一。它造成大量初始伤害，给予
  
  
  
  
  你50点集中值，冲向目标，然后使你和你的宠物的
  
  
  
  
  伤害提高20%，持续8秒。有天赋可以让它造成更高的
  
  
  
  
  范围伤害，并在持续期间提高攻击速度，或将其冷却时间
  
  
  
  
  缩短至1分15秒/1分钟。
- [[spell:259495]] 现在消耗10点集中值。
- [[spell:1251592]] 是一个新的1分钟冷却技能，投掷
  
  
  
  
  一枚类似火焰炸弹的炸弹到地面，对范围内的目标造成伤害。
  
  
  
  
  天赋可以为其提供额外一层充能。
- [[spell:203415]] 已重新设计为 [[spell:1261193]]。
  
  
  
  
  机制上几乎相同，但它发射的是霰弹攻击，而不是用你的长矛快速
  
  
  
  
  攻击，而且它的射程要远得多。它有1分钟的
  
  
  
  
  冷却时间。有天赋可以显著提高它的单体、
  
  
  
  
  随着目标增多而衰减其伤害。
- 技能 [[spell:212436]]、[[spell:269751]]、
  
  
  
  
  [[spell:259387]], [[spell:212431]], [[spell:53351]],
  
  
  
  
  [[spell:360966]] 和 [[spell:360952]] 已被移除。
- 被动天赋 [[spell:269737]]、[[spell:389880]]、
  
  
  
  
  [[spell:1217434]], [[spell:459741]], [[spell:1217429]],
  
  
  
  
  [[spell:459828]], [[spell:378951]],
  
  
  
  
  [[spell:265895]] 和 [[spell:268501]] 已被移除。

2.8.

#### 巅峰天赋

至暗之夜 引入了新的巅峰天赋，在 80 至 90 级之间解锁。

生存 获得：

1. [[spell:1259003]]
2. [[spell:1259017]]
3. [[spell:1259019]]

它们使每隔一次的 [[spell:186270]] 变成

[[spell:1259003]]，造成更高伤害，并使其命中多个

目标。非常简单且被动，但非常强大。

2.9.

#### 生存能力改动

- 猎人的最大生命值比之前提高了2%。
- [[spell:109304]]的冷却时间现在固定为1分钟，不再是可变的
  
  
  
  
  （且通常更短）。
- [[spell:186265]]的冷却时间在天赋支持下现在为2:00，从
  
  
  
  
  2:30.
- [[spell:186265]]在天赋支持下现在可以提供50%的伤害减免，
  
  
  
  
  从30%提高。
- [[spell:53480]]现在是一个外部防御技能，可以对
  
  
  
  
  你自己或任何友方目标使用，使其受到的伤害降低15%，持续10秒，
  
  
  
  
  但他们受到伤害的50%将由你的宠物承担。如果你的宠物
  
  
  
  
  生命值低于25%，它会提前结束。
- [[spell:388035]]现在是3%的被动伤害减免，不再是
  
  
  
  
  一个主动防御冷却技能。

2.10.

#### 功能性改动

- [[spell:257284]]现在是对单体目标的通用3%伤害提升。
  
  
  
  
  这基本上保证了猎人在每个团队副本中的位置。它
  
  
  
  
  在大秘境中也是对团队的增益，尽管效果要弱得多
  
  
  
  
  那里。
- [[spell:187707]] 现在使目标沉默5秒，从
  
  
  
  
  1.
- [[spell:187650]]现在能使目标减速70%，持续4秒，触发时机是在
  
  
  
  
  使目标减速70%，持续4秒。
- [[spell:19577]]现在是我们唯一的眩晕/控制技能。一个抉择节点可以
  
  
  
  
  将其冷却时间缩短至40秒，或使其成为1秒的范围眩晕。
  
  
  
  
  [[spell:462033]]、[[spell:236776]]和[[spell:186387]]
  
  
  
  
  都已移除。
- [[spell:195645]]和[[spell:5116]]的减速效果分别为25%和
  
  
  
  
  提高了25%和10%。
- [[spell:472729]]现在是职业天赋树节点，不再
  
  
  
  
  依附于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖英雄天赋。它是一个抉择节点，与
  
  
  
  
  [[spell:459460]]同为抉择，后者延长[[spell:109248]]的眩晕
  
  
  
  
  1秒。
- [[spell:459466]]已移除。
- [[spell:213691]]已移除。
- [[spell:459533]]已移除。
- [[spell:321468]]已被移除。

2.11.

#### 杂项改动

- [[spell:186257]]的初始"超级"速度爆发现在在天赋影响下
  
  
  
  
  持续时间翻倍。
- [[spell:53351]]已被移除，并成为射击专精独有技能。
- 成功使用 [[spell:187707]] 踢击现在
  
  
  
  
  提供30点集中值，比之前的10点更多，但使用宁神射击进行驱散
  
  
  
  
  [[spell:19801]] 不再提供集中值。

总体而言，我们获得了防御能力和机动性，而在功能性

方面，我们失去了一些东西（比如移动怪物的能力），但

获得了其他东西（更强的标记、更流畅的群体眩晕、更强的打断和

打断时更多的集中值返还）。我们认为这些改动总体上是积极的！

1.

### 生存 猎人 玩法基础

生存 猎人 是一个关于增益和冷却管理的专精。

在大多数技能之间，你想穿插一个 [[spell:259489]] 以

获得它产生的 [[spell:260285]] 层数。目标是让矛尖

覆盖尽可能多的非 杀戮命令 技能，例如

[[spell:259495]] 和 [[spell:186270]]。

循环非常动态、快节奏且繁忙。最优秀的 生存 猎人

对专精的优先级了如指掌，并且总是能够

即时做出正确的技能决策，即使许多机制同时

争夺他们的注意力。为了进一步细分，下面的列表

下文描述了该专精的核心框架。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_bossmannoroth_glaivethrust.jpg>) **为每个技能提供矛尖**
  
  
  
  
  你施放的每一个技能，除了 [[spell:259489]]，都必须
  
  
  
  
  在 [[spell:260285]] 激活时施放。唯一的例外，极其
  
  
  
  
  罕见，就是如果你没有矛尖，可以施放一个 [[spell:186270]]（不是
  
  
  
  
  猛禽横扫）而没有矛尖，或者没有 [[spell:259489]]
  
  
  
  
  充能。没有矛尖时攻击也比挂机好。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_killcommand.jpg>) **不要浪费矛尖层数**
  
  
  
  
  如果你已经有超过一层，永远不要施放 [[spell:259489]]
  
  
  
  
  [[spell:260285]] 层数，因为这会浪费矛尖层数的生成。这是一个
  
  
  
  
  常见的陷阱，过于偏执地要给每个技能都加上矛尖，以至于你过度
  
  
  
  
  施放 [[spell:259489]] 而不需要它，从长远来看会让你
  
  
  
  
  付出代价。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_raptorstrike.jpg>) **保持施法**
  
  
  
  
  尽可能多地施放技能比每次都按出完美技能更重要，
  
  
  
  
  每次点击按钮，而空闲等待时间是阻碍大多数玩家的最关键因素
  
  
  
  
  达成DPS目标的最大因素。

1.

### 如何为 生存 猎人 配装

我们专门的 生存 配装页面涵盖了第2赛季的装备，来自你的

首次升级一直到完整的毕业清单。我们仍然建议

通过模拟自己来获得理想答案。一旦你获得了一些装备，你将

需要相应的消耗品、宝石和附魔来搭配这些新

物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年9月30日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 修复了胸甲工具提示显示两个毒咒效果的问题。
- **2026年9月30日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 哨兵 单体构建现在选择重击而非血腥之爪（+0.15%）。
- **2026年9月15日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 新增了一个团队副本范围伤害/顺劈构建，现在这是我们对任何有小怪或第二目标的团队副本首领的推荐。
- **2026年9月7日（本页）：** 将团队副本评分下调至2.5。
- **2026年9月4日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 在饰品排名中将毒怒之泉提升至S级。
- **2026年8月30日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了 哨兵 针对 Boomstick 和 野火炸弹 的单体优先级，以及其双牙起手式，现在以 Boomstick 开场，在猛禽一击前建立狂怒 狂怒 层数。
- **2026 年 8 月 29 日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 将武器附魔更新为哈什之仪。
- **2026 年 8 月 29 日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 将武器附魔更新为哈什之仪。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了武器附魔为狂暴者的愤怒。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 将制作武器的铭文更正为灼热之泰拉西亚铭文。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔为狂暴者的愤怒。
- **2026年8月22日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 添加了关于制作护腿的说明。
- **2026年8月21日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 将制作的护腕和腰带更新为使用奥术织纹衬里，因为华丽之牙的模拟结果过高。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了虚空核心的额外掉落优先级。
- **2026年8月18日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了团队副本构筑的效用天赋。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了饰品梯队表，并更正了关于盖博的无底背包的备注。
- **2026 年 8 月 17 日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 万卷集配置现在选择虚空污染之壳而非自我修复。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 重做了制造建议，更正了团队副本物品列表中贪婪的 乌拉特克 之心和盖博的无底袋条目，并添加了赛季开始时的虚空核心和纹章建议。
- **2026年8月16日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了哨兵的AoE起手式，现在在天赋双牙时以扑击开怪。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 根据最新的平衡性调整更新了饰品梯级榜。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 将大秘境毕业武器更新为两把来自毒牙祭坛的磨利的轻木劈砍者，并添加了关于双手武器和双持武器的章节。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了虚空星核的额外拾取优先级，并注明迷城之灾、军阀的狂怒目前不在生存的掉落列表中。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 移除了关于迷城之灾、军阀的狂怒不在生存掉落列表中的备注，因为它现在已被添加。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 将团队副本毕业手套更新为来自尼姆瑞莎·唤波者的催化漩涡狂怒之握。
- **2026年8月12日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 添加了催化剂和大秘库常见问题解答及插槽部分，修正了催化剂掉落位置，并更新了团队副本毕业头盔和手套的来源。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 地下堡构筑现在选择紧急药膏而非荒野医术。
- **2026年8月11日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了猎群领袖的天赋构建，将一点从横扫之矛移入锋刃。
- **2026年8月11日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 阐明了野火炸弹在哨兵AoE优先级中的目标选择。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了猎群领袖的天赋构建。单体将龟壳震荡替换为双牙，大秘境将一点从横扫之矛移入锋刃。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年7月16日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 更新了传家宝属性建议和升级提示。
- **2026年7月16日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 更正了熊之坚韧和上升气流的描述，并更新了资料片引用。
- **2026年7月16日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 添加了护腕宝石并修正了毕业靴子的行。
- **2026年7月16日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 修复了附魔提示链接并更新了消耗品备注。
- **2026年7月16日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 阐明了实用技能和词缀备注。
- **2026年7月16日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将扑击的持续时间更正为8秒，突进的长度更正为30码。
- **2026年7月16日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了万世典籍第4周符文和英雄天赋指南。
- **2026年7月16日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 更正了振奋的冷却时间和假死的描述，将掷斧和鹰之灵添加到术语表中，并按字母顺序排列了技能表。
- **2026年7月16日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 从新手优先级列表中移除了月光战刃，并阐明了宠物建议。
- **2026年7月16日（本页）：** 阐明了哨兵的印记和月光战刃的冷却缩减数值。
- **2026年6月17日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 根据实际数据优于模拟结果，更新了推荐的第一周卷集符文。
- **2026年6月16日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 澄清了武器附魔的选择。
- **2026年6月16日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 微小（+0.1%）的大秘境天赋构建变更。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月21日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 修复了双牙循环逻辑顺序颠倒的问题。
- **2026年4月28日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为AoE和单体添加了额外的野火炸弹条件。
- **2026年4月28日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了猎群领袖的实用天赋，选择滑行之靴而非大师召唤。大秘境的职业天赋实用选择有小幅变更。
- **2026年4月27日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新并阐明了关于猛禽一击/横扫的提示措辞。
- **2026年4月25日（本页）：** 更新了生存的性能评估。
- **2026年4月23日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为12.0.7版本更新了专业制作建议。
- **2026年4月23日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了戒指附魔。
- **2026年4月23日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 起手式更新。
- **2026年4月21日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 扩充了关于扑击窗口准备的内容。起手式更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月8日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 毕业装备列表和饰品层级列表更新。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 毕业列表更新。
- **2026年3月27日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 添加了关于双持附魔的信息。
- **2026年3月25日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 扩充了各英雄天赋下的武器制作内容。更新了大秘境装备毕业列表。
- **2026年3月25日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 添加了关于哨兵漏洞的备注，并更新了推荐的英雄天赋/构建。
- **2026年3月22日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了猎群领袖的单体起手式。
- **2026年3月19日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新为推荐吸血附魔而非闪避。
- **2026年3月18日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 微调了哨兵带双牙的单体起手式。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 修复了哨兵大秘境构建中的错误。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 哨兵起手式更新。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 修复了哨兵大秘境构建中的错误。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月4日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了终局内容的专业制造推荐。
- **2026年3月4日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 添加了关于《燃烧的远征》中一些旧磨刀石/平衡石在至暗之夜中达到最优的信息。
- **2026年3月1日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 猎群领袖大秘境构建更新。
- **2026年3月1日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 猎群领袖大秘境构建更新。
- **2026年2月28日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 生存单体天赋更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 添加了猎群领袖武器。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境天赋推荐。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋推荐。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月12日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 添加了关于双手武器与双持的备注。
- **2026年2月12日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境构建推荐。
- **2026年2月12日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 大幅更新了猎群领袖的单体循环。
- **2026年2月12日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 全面更新了英雄天赋推荐。
- **2026年2月11日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在猎群领袖的AoE循环中添加了掷斧的说明。
- **2026年2月11日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了关于大秘境英雄天赋的备注。推荐本身没有变化，只是提供了更多背景信息。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 更新了80级的属性递减收益数值。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为即将到来的12.0.1版本改动进行了小幅循环更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年2月4日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 哨兵大秘境构建的小幅更新。
- **2026年2月4日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 哨兵大秘境构建的小幅更新。
- **2026年1月31日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境构建。木桩测试表明AoE基本持平，单体略有提升，同时从循环中移除了一个按键，并采用与单体构建匹配的1分钟冷却时间轴。
- **2026年1月21日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 哨兵大秘境构建更新。
- **2026 年 1 月 20 日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** AoE循环改进。
- **2026年1月19日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 在模拟工具修复后，将推荐的大秘境英雄天赋更新为哨兵。
- **2025年9月4日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 在模拟工具修复后，将推荐的大秘境英雄天赋更新为哨兵。
- **2025年9月2日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 饰品层级列表和毕业装备更新。
- **2025年8月31日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 微调了大秘境天赋选择的排列。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 根据数值调整更新了饰品梯队表。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月26日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了泰坦圆盘推荐。
- **2025年6月23日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 基于最新的在线修正更新了泰坦圆盘推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月10日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 略微更新了纸牌屋和印记的措辞/代币推荐状态。
- **2025年5月9日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了腐蚀附魔与谜之卡特尔芯片代币部分。
- **2025年5月9日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了腐蚀附魔部分。
- **2025年5月9日（本页）：** 更新了最佳专精部分。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 添加了可用代币购买的物品列表。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔信息。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月30日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 起手式小幅更新。
- **2025年3月29日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了大秘境饰品层级列表中克赞之眼的位置。
- **2025 年 3 月 25 日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对3月25日的在线修正进行更新。
- **2025 年 3 月 25 日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 针对3月25日的更新进行了更新。
- **2025 年 3 月 25 日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对3月25日的更新进行了更新。
- **2025年3月25日（本页）：** 针对3月25日的更新进行了更新。
- **2025年3月18日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了推荐的大秘境模拟路线/大秘境模拟Pastebin。
- **2025年3月16日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 移除了关于毒蛇钉刺多目标DoT的过时说明。
- **2025年3月14日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 在增强后更新了无定形圣物的排名。
- **2025年3月7日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔。
- **2025年3月7日（[解放安德迈页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 根据实际数据更新了构建。
- **2025年3月4日（[解放安德迈页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2024年12月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 重新评估了大量史诗天赋推荐。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了关于瑟尔崔指环现在提升至物品等级658的内容。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年11月23日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 单体起手式的小幅阐明和更正。
- **2024年11月20日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 增加了对多个循环细节“为什么”的更详细说明。
- **2024年11月18日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 扩充了AoE循环并添加了更多细节。
- **2024年11月15日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔。
- **2024年11月13日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了大秘境的哨兵构建，以修正无情掠夺者此前模拟结果偏低的问题。
- **2024年11月13日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了大秘境的哨兵构建，以修正无情掠夺者此前模拟结果偏低的问题。
- **2024年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 添加了大秘境构建，并添加了关于适合新手的天赋替换建议。
- **2024年11月6日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 添加了大秘境构建，并添加了关于适合新手的天赋替换建议。
- **2024年10月30日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 更新了10月29日的热修复内容。
- **2024年10月30日（本页）：** 根据热修复更新了最佳专精部分。
- **2024年10月26日（本页）：** 恢复了最佳专精部分。
- **2024年10月25日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了AoE循环，并在此过程中对其进行了简化。
- **2024年10月23日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了AoE起手式。
- **2024年10月22日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月22日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年10月8日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对10月8日的在线修正进行更新。
- **2024年10月8日（本页）：** 根据更新后的10月8日热修复更新了“最佳猎人专精”部分。
- **2024年10月5日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 扩充了武器附魔选择的内容。
- **2024年10月2日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了纯单体的毕业饰品。
- **2024年10月2日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 新增了更具体的饰品使用信息。
- **2024年9月29日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 默认推荐一套备选单体构建。
- **2024年9月29日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 添加了一套备选单体构建。
- **2024年9月27日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了阿拉卡拉提示。
- **2024年9月21日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 更新了属性优先级。
- **2024年9月20日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 在重新评估和模拟工具成熟后，更新了饰品梯队表和最佳饰品。
- **2024年9月13日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 新增了关于双黎明之线衬里无效及其解决方法的说明。
- **2024年9月13日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 在有了英雄难度经验后，重新审视了每个首领的最佳配置并做出了一些改动。
- **2024年9月13日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新并澄清了一些提示。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为地心之战第1赛季进行了初步更新。
- **2024年9月9日（本页）：** 为地心之战第1赛季进行了初步更新。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 在赛季前毕业列表中新增了关于制造装备的说明。
- **2024年8月27日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 将“短期爆发”AoE构建更新为赛季前的默认构建。
- **2024年8月26日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 小幅的各类修复，主要是针对纯单体构建的起手式。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 新增了地下堡推荐构建。
- **2024年8月23日（本页）：** 重新引入了关于地心之战中最佳猎人专精的部分。
- **2024年8月22日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月22日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对地心之战进行更新。
- **2024年8月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对地心之战进行更新。
- **2024年8月22日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月22日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月22日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月22日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月22日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月22日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月22日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月22日（本页）：** 已针对地心之战进行更新。
- **2024年7月30日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对循环和起手式进行了小幅优化更新，主要是关于为矛尖/协同突袭保留爆炸射击。
- **2024年7月29日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了单体起手式，以便尽早施加毒蛇钉刺来触发外域之毒。
- **2024年7月28日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 根据 生存猎人 Discord 频道的建议，实施了循环输出 DPS 优化。
- **2024年7月26日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为使用第3赛季套装的玩家新增了天赋配点，这是最优选择。
- **2024年7月25日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 更新了最佳饰品、制造品清单、最佳装备清单等内容。
- **2024年7月25日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新并简化了输出循环。
- **2024年7月25日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 鉴于血腥之爪在前夕补丁中的表现与测试服不同，更新了大秘境配点。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月26日（[地心之战](<https://www.icy-veins.com/wow/survival-hunter-the-war-within-pve-guide>)):** 更新了6月25日的改动内容。
- **2024年6月18日（[地心之战](<https://www.icy-veins.com/wow/survival-hunter-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月29日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** 更新了宝石匠宝石推荐。
- **2024年5月20日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** 根据正式服强度等级更新了宝石匠宝石排名。
- **2024年5月17日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** 根据近期改动和新信息更新了宝石匠和齿轮宝石推荐。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/survival-hunter-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月12日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 在大秘境配点中默认加入了 误导。
- **2024年5月12日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 在大秘境配点中默认加入了 误导。
- **2024年5月11日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 新增了关于如何在高层大秘境中利用坦克饰品和美化装备存活的章节。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年5月3日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 新增了奈萨鲁斯副本中 Chargath 的攻略提示。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为第4赛季进行了更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 已针对10.2.6版本更新。
- **2024年1月29日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 将默认大秘境配点更新为无冷却流配点。
- **2024年1月29日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 将默认大秘境配点更新为无冷却流配点。
- **2024年1月29日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 将默认大秘境配点更新为无冷却流配点。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已为10.2.5版本进行更新。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年12月18日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 新增了史诗钥石地下城攻略提示。
- **2023年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了史诗钥石地下城天赋配点。
- **2023年11月28日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了单体输出和史诗钥石地下城天赋配点。
- **2023年11月12日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 新增了T30史诗钥石地下城配点。
- **2023年11月12日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 在单体输出循环中补充了缺失的 野火炸弹 一行。
- **2023年11月12日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 新增了T30史诗钥石地下城配点。
- **2023年11月9日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 对史诗钥石地下城配点进行了小幅调整，以提升单体输出能力。
- **2023年11月9日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 对史诗钥石地下城配点进行了小幅调整，以提升单体输出能力。
- **2023年11月7日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 修复了在AoE配点下单体输出循环中 野火炸弹 不显示的问题。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对10.2版本进行更新
- **2023年11月6日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对10.2版本进行更新
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.2版本进行更新
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对10.2版本进行更新
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.2版本进行更新
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2版本进行更新
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对10.2版本进行更新
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对10.2版本进行更新
- **2023年11月6日（本页）：** 已针对10.2版本进行更新
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 重构了页面并针对10.1.7版本进行了更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 针对 10.1.7 补丁进行了审阅
- **2023年7月17日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的APL更新，对AoE循环和起手式进行了重大更新，并将主动使用类饰品加入循环中。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年6月29日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了单体输出循环中的死亡飞轮一行。
- **2023年6月23日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 根据最新的APL改动，更新了史诗钥石地下城配点。
- **2023年6月23日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 根据最新的APL改动，更新了AoE和AoE无冷却配点。
- **2023年6月16日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 进行了大规模的循环重构，新增了复选框、可选择复选框预设的新功能，以及对单体输出和AoE循环的多项改动。
- **2023年6月15日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 移除了AoE循环的第一行，从而降低了在AoE中维持4件套减益效果的优先级。
- **2023年6月13日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 移除了狂怒之翼下的寻血者宏，因为该错误已修复，不再需要。
- **2023年6月13日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 移除了狂怒之翼下的寻血者宏，因为该错误已修复，不再需要。
- **2023年6月13日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 更新了简易模式的循环和配点，使其更易于理解。
- **2023年6月3日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对AoE起手式进行了小幅调整。
- **2023年6月3日（本页）：** 更新了关于专精可行性的简介，并更新了优势与劣势。
- **2023年6月2日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 对天赋配点进行了重大更新，包括强化/暴虐周的推荐内容，以及天赋配点本身。
- **2023年5月27日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为 生存 大秘境新增了独立的强化周、暴虐周和冷却流配点。
- **2023年5月26日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对AoE起手式进行了重大更新，以更好地反映AoE循环的改动。
- **2023年5月26日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 新增了轰炸机和矛头配点。
- **2023年5月25日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为 狂怒之鹰 新增了一个取消光环的寻血者宏。
- **2023年5月25日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 进行了重要的AoE循环更新，更新了默认复选框，并新增了关于 狂怒之鹰 宏的重要信息。
- **2023年5月22日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的腿部附魔，因为发现微光护甲片并不像之前认为的那样提供耐力。
- **2023年5月19日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了页面布局。
- **2023年5月13日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了推荐的AoE/史诗钥石地下城天赋。
- **2023年5月13日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 对4件套循环行的措辞进行了小幅修改。
- **2023年5月13日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的AoE/史诗钥石地下城天赋。
- **2023年5月12日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的食物和腿部附魔。
- **2023年5月2日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的武器符文/临时附魔。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为10.1补丁进行了复查。
- **2023年5月1日（本页）：** 为10.1补丁进行了复查。
- **2023年4月11日（本页）：** 更新了专精排名以考虑新的削弱。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 在模拟更新以及发现新的强力组合后，更新了推荐的宝石。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 根据一系列热修复再次更新了推荐的宝石。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 根据3月21日的增益更新了黑曜石指环信息。
- **2023年3月21日（本页）：** 更新了不同伤害类型的专精排名。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/survival-hunter-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了推荐的大秘境配点。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 进行了小幅的循环修复。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的大秘境配点。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月8日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了突进的推荐状态，并根据最近的增益效果重新检查了天赋的正确性。
- **2023年1月6日（[宠物页面](<https://www.icy-veins.com/wow/survival-hunter-pets-guide>)):** 添加页面。
- **2023年1月4日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了推荐的药剂。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 更新了最佳药水/药剂的推荐和描述。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对套装奖励的循环更新。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 更新了鱼叉猛刺在循环中的作用。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已针对巨龙时代第1赛季进行更新。
- **2022 年 12 月 11 日（本页）：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月30日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 将优先级中关于 杀戮命令 拥有2层充能的描述更新为“不要让充能溢出”，以涵盖有无顶级掠食者天赋的两种情况。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月29日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 更新了温西尔大秘境配点天赋。
- **2022年10月29日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 进一步更新了推荐的少目标AoE温西尔配点。
- **2022年10月27日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 更新了推荐的少目标AoE配点，并修复了字符串的一个问题。
- **2022年10月26日（[盟约与羁绊](<https://www.icy-veins.com/wow/survival-hunter-best-covenants-soulbinds-and-conduits>)):** 更新了描述。
- **2022年10月26日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 新增了一个基瑞安配点，该配点在大量AoE的大秘境中表现更优。
- **2022年10月26日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 新增了一个基于基瑞安的天赋配点，强调强大的爆发能力，主要用于高层怪物数量多的史诗钥石地下城。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/survival-hunter-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/survival-hunter-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/survival-hunter-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-weak-auras>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/survival-hunter-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** 更新了对所有盟约专属传说装备的看法，并在改动中加入了7月13日的猎人增强。
- **2021年6月10日（[9.1 补丁分析](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** 添加了关于温西尔专属传说装备的信息。
- **2021年5月12日（[9.1 补丁分析](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** 新增了关于4个盟约专属传说物品的信息，并更新了一些“重点”羁绊能力。
- **2021年5月3日（[9.1 补丁分析](<https://www.icy-veins.com/wow/survival-hunter-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年10月25日（[永恒宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 为 生存 新增了史诗难度永恒王宫的Boss攻略提示。感谢 Thyminde 提供了大部分提示！
- **2019年8月23日（[永恒宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 为更多首领添加了提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 为 Uu'nat 新增了 生存 攻略提示。
- **2019年5月1日（[风暴熔渣页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 为不息之议会新增了 生存 攻略提示。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对风暴熔炉进行审查，无需更改。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为达萨罗之战新增了 生存猎人 的Boss攻略提示。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** 为页面新增了内容。
- **2018年8月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页中，你将找到我们的逐级 生存猎人 练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[猎人升级指南](<https://www.icy-veins.com/wow/hunter-leveling-guide>).

1.

### 生存猎人 练级指南：适用于 至暗之夜

生存猎人，得益于可以使用宠物作为坦克

在一定程度上，非常适合做任务和副本练级。生存 拥有

最佳

猎人专精的生存能力，但因为它的宠物不像

[野兽控制 猎人](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-guide>)战士那样结实，它仍然无法应对同样规模的

大规模拉怪。

带上一只狂野系宠物和 [[spell:34477]]，在标记尽可能多的怪物前激活它，

尽可能多地吸引小怪，并注意小怪

蜂拥向你的宠物。接着，用 [[spell:259495]] 解决这些怪物。

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的

装备。此规则的唯一例外是，如果你有一个戒指或项链的

物品等级略低，但有两个副属性而不是一个。

在使用传家宝物品时，以及在其他装备之间做选择时，我们

建议尽可能优先选择精通，然后是暴击。

1.2.

#### 至暗之夜升级实用消耗品

特别是在至暗之夜资料片中从80级升到90级时，

有许多消耗品可以帮助缓解这一过程，除了

“常规”PvE消耗品外，还有很多消耗品可以帮助你更轻松地完成升级过程。

- [[item:132516]] — 巨大的移动速度提升，在
  
  
  
  
  坐骑无法使用时也能使用，并且比地面坐骑快得多。
- [[item:109076]] — 让你从悬崖边滑翔出去并快速
  
  
  
  
  跨越遥远的距离。
- [[item:168412]] — 不要忘记这个坐骑装备，
  
  
  
  
  它能让你的坐骑在地面上更快。
- [[item:172063]] — 一份食物带来的惊人移动速度提升。
  
  
  
  
  食物。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，请随着等级提升，按照

随着你升级，逐点分配下方天赋树。练级

输出循环部分有一个滑块，可以显示你每个等级的输出循环。

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmZmZGDLDAAAAAAzYGzYbGjZMzATGAAAgBAGLbzMzmZmZmxMzMAMjNsMjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-PqBgEESAOMMHYTpCNNLiikeIRRFoWHu1pcE-BFMdDEbIjiZXlOFh6bhlFnmWYVlhwjH-AAAA-ZauYkAQgQJAZ4A-
```

:::

1.

### 升级循环

为了在升级和学习专精时保持简单，请使用滑块

选择你的等级，并观察升级输出循环随每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 46 起：**对你的宠物使用 [[spell:34477]] 以转移仇恨
   
   
   
   
   到它身上。
2. **等级 78 起：**在你的第一个技能之后使用[[spell:1264902]]
   
   
   
   
   在每个 [[spell:1250646]] 窗口内使用 [[spell:259495]]。一旦激活，这个按钮就会
   
   
   
   
   取代你的猛禽一击按钮出现。
3. 使用 [[spell:190925]] 快速接近敌人。
4. **等级 5 起：**在大量拉怪时使用[[spell:136]]来保持你的宠物
   
   
   
   
   健康。
5. **等级 51 起：**卡着冷却时间使用 [[spell:1250646]]，尽量在拥有
   
   
   
   
   至少2层 [[spell:260285]] 时使用。
6. **等级 17 起：**在AOE中，一旦你能命中全部目标就使用[[spell:1261193]]
   
   
   
   
   将小怪群拉入其相当宽长的锥形范围。
7. **等级 13 起：**卡着冷却时间使用 [[spell:259495]]。
8. **等级 11 起：**卡着冷却时间使用 [[spell:259489]]。
   
   
   
   
   **等级 21 起：**这会产生 [[spell:260285]] 层数，这些层数也会强化你的其他技能，所以尽量将这些层数用在你所有的其他技能上。
9. **等级 19 起：**猛按 [[spell:186270]]。
10. **等级 1–10：**连续使用[[spell:185358]]。
11. **等级 1–10：**使用[[spell:56641]]作为填充技能。
12.

### 最佳升级宠物

所有宠物造成相同的伤害，但它们的实用性和特殊

技能。对于练级来说，最好的宠物是任何 **狂野系** 宠物，因为它们

在造成伤害时会治疗自己，让你能够拉更多的怪。

野兽系宠物还自带[[spell:264667]]，这是一个嗜血效果。

当你战斗超过三十秒时，应尽可能频繁地使用此技能

秒时，应尽可能频繁地使用它。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了传家宝属性建议和升级提示。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将讲解如何在魔兽世界12.1.5补丁中轻松游玩生存猎人，使用最简单的循环、天赋树、属性优先级、装备搭配等，且不牺牲输出。

1.

### 生存猎人基础

本节面向刚接触游戏或该职业的玩家，他们

无意参与史诗难度团队副本，或只是希望以更

简单直接的方式进行专精输出，而不被

为追求最优输出所需考虑的众多优先级和主动技能

所淹没。

生存的执行相当简单，对于某人来说是一个理想的专精

刚接触团队副本，或刚接触魔兽世界的人来说，是理想的选择。

生存的核心循环包括施放[[spell:259489]]来给予

自己[[spell:260285]]层数，然后将这些利矛层数用于

其他技能，例如冷却就绪的[[spell:259495]]/[[spell:1261193]]，并以

[[spell:186270]]作为填充技能。

以下是三条快速的经验法则，能帮助你在使用

该专精时得心应手。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_bossmannoroth_glaivethrust.jpg>) **为每个技能提供矛尖**
  
  
  
  
  你施放的每一个技能，除了 [[spell:259489]]，都必须
  
  
  
  
  在 [[spell:260285]] 激活时施放。唯一的例外，极其
  
  
  
  
  罕见，就是如果你没有矛尖，可以施放一个 [[spell:186270]]（不是
  
  
  
  
  猛禽横扫）而没有矛尖，或者没有 [[spell:259489]]
  
  
  
  
  充能。没有矛尖时攻击也比挂机好。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_killcommand.jpg>) **不要浪费矛尖层数**
  
  
  
  
  如果你已经有超过一层，永远不要施放 [[spell:259489]]
  
  
  
  
  [[spell:260285]] 层数，因为这会浪费矛尖层数的生成。这是一个
  
  
  
  
  常见的陷阱，过于偏执地要给每个技能都加上矛尖，以至于你过度
  
  
  
  
  施放 [[spell:259489]] 而不需要它，从长远来看会让你
  
  
  
  
  付出代价。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_raptorstrike.jpg>) **保持施法**
  
  
  
  
  尽可能多地施放技能比每次都按出完美技能更重要，
  
  
  
  
  每次点击按钮，而空闲等待时间是阻碍大多数玩家的最关键因素
  
  
  
  
  达成DPS目标的最大因素。

1.

### 生存猎人在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体天赋

2.1.

#### 猎人生存单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体构筑，适用于大多数

团队副本首领战。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzYmFzYMjZwYaGAAAgBAzYbZmZWMmZmxMzAgZssBjhxmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-ABDEFGIKKLYcceiKZiqqyy6S2GXn3nI-AAAA-BEIMQYcAJRZhpB-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵地下城天赋

2.2.

#### 生存猎人地下城天赋构筑

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵用于大秘境的构筑。它

基于模拟真实大秘境地下城中的条件，并观察

不仅是什么能打出最高DPS，而是什么能真正更快地通关地下城

在队伍中。有些构筑能造成更高的AoE伤害，但它们损失的单体伤害都多于

它们在AoE方面获得的收益，反之亦然。

2.3.

#### 生存猎人功能性天赋考量

- 你的“灵活”天赋点，按我们推荐的“最
  
  
  
  
  可舍弃”顺序为：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGbzYMjZYZMNDAAAwAAjllZGLYmZ8AjxAwM2AjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 生存猎人基础循环

2.4.

#### 生存猎人基础循环

生存的目标主要是最大化你的集中值获取与

消耗。这意味着永远不要溢出你的集中值，始终在

不会让你溢出集中值的前提下冷却就绪就施放[[spell:259489]]，

并将所有这些集中值用于[[spell:186270]]和

[[spell:259495]]s.

[[spell:259489]]还会给予我们两层[[spell:260285]]。

这些层数会强化其他技能，因此你会自然地形成一种“交替”玩法

由[[spell:259489]]同时产生集中值和利矛层数，然后

你将这些集中值和利矛层数用于获得强化的猛禽一击和炸弹。

除此之外，我们还有[[spell:1261193]]，一个极其强力的

小型冷却技能，我们希望在一场战斗中尽可能多地使用它，并打到尽可能多的

尽可能多的目标，进行战斗。我们始终要确保我们

用[[spell:260285]]强化它，并且完整引导它。

因此，基础优先级列表大致如下：

1. 冷却就绪就使用[[spell:1250646]]，并且始终在
   
   
   
   
   ```
   [[spell:260285]].
   ```
2. 冷却就绪就使用[[spell:1261193]]，并且始终在
   
   
   
   
   ```
   [[spell:260285]].
   ```
3. [[spell:259489]] 当我们拥有1层或更少时
   
   
   
   
   ```
   [[spell:260285]] stacks.
   ```
4. [[spell:259495]]，始终与[[spell:260285]]配合使用。它有两个
   
   
   
   
   ```
   charges, so one charge can be held a little bit if there is AoE coming
   
   up.
   ```
5. [[spell:186270]]，始终配合[[spell:260285]]。

2.4.1.

##### 巅峰天赋： ![Raptor Swipe Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_hunter_raptorswipe.jpg>) 猛禽横扫

你的巅峰天赋不会影响你的玩法；它们只会提高你的

被动造成伤害，最佳的利用方式是执行“基线”

循环能最好地利用它们。

2.4.2.

##### 第2赛季套装

至暗之夜第2赛季套装对我们的循环没有影响。2件套使

[[spell:259388]]使[[spell:259495]]的伤害提高10%，而

4件套使[[spell:1261193]]的每一次爆炸将[[spell:259388]]延长1

秒，此外还将狂怒狂怒的效果提高10%。这是一个巨大的

[[spell:259495]]增益，但实际上并没有什么改变，因为炸弹是

已经激进地在冷却就绪时使用了。

### 生存猎人防御技能

2.5.

#### 生存猎人防御技能

[[spell:109304]]是你主要的自我治疗技能，冷却时间为1分钟。

当你的生命值低于50%时使用它，以减轻治疗者的压力！

[[spell:186265]]是你的免疫技能。它可以用来完全

免疫大多数针对你的法术的伤害和效果。当你被指派使用时，

或者在危急时刻，如果你担心即将到来的机制会杀死你，就使用它！

它也能提供30-50%的减伤，尽管它通常不用于

单纯的减伤目的。

[[spell:264735]]是我们除了灵龟守护外最强的防御技能，

提供30-40%的减伤，有2层充能，每层冷却时间为1.5分钟。

用它来减免高伤害机制造成的伤害。要最优地使用这个

技能，就需要 **提前**在大量伤害到来之前使用它。

[[spell:5384]]是一个非常独特的猎人技能。它可以用来消除

仇恨和战斗，也可以用来打断针对你的施法。如果你看起来已经死亡，

怪物通常会在施法中途停止施法！

拥有[[spell:459517]]天赋时，它还会驱散你身上的所有中毒

和疾病效果。

[生存猎人至暗之夜技能词汇表](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spell-summary>)

### 生存猎人最佳宠物

2.6.

#### 生存猎人最佳宠物

关于宠物最重要的一点是，**它们的基础DPS都相同**。

DPS**。唯一的区别在于功能性和防御能力！

首先，你需要弄清楚你是否需要使用

[[spell:2825]]/[[spell:32182]] 在你的队伍中。只有猎人、法师、唤魔师、

和萨满祭司可以使用嗜血，所以如果队伍里没有这些职业的其他人，

那就得靠你了！

如果你确实需要 [[spell:2825]]，你需要使用任意 **狂野**

宠物，因为它们自带 [[spell:264667]] 嗜血能力。使用 [这个网站](<https://www.wow-petopia.com/abilities.php>) 来寻找一只酷炫的

狂野系宠物用于开嗜血！

如果你 **不会** 需要嗜血时，最佳宠物是个人

选择：任何 [坚韧宠物](<https://www.wow-petopia.com/specs.php>)，或者

前述的狂野宠物。坚韧宠物自带

[[spell:388035]]防御技能和5%最大生命值，但你会失去

4%吸血，这对于长时间的自我续航来说更好！

### 生存猎人属性优先级

2.7.

#### 生存猎人属性优先级

生存猎人的一般属性优先级如下所示。

关于本页呈现内容的更多信息，请查看我们的主要

[属性优先级页面](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>).

精通

暴击

急速

全能

### 暴风雪战斗助手

2.8.

#### 战斗助手 & 单键模式

游戏提供了游戏内“战斗助手”的选项，它有两种

模式：一个会建议下一个施放法术的循环助手，以及一个

「一键模式」，它会在你进行时自动为你执行这套输出循环

只是反复按一个键，它会自动为你执行这个循环。

这些工具对于新手来说可能很有价值，因为它们提供了一个合理的

“最低”表现水平。对于生存猎人，仅使用

循环助手相比完美操作大约有2-8%的DPS损失（这

在此基础上再使用单键模式，总损失会达到

损失降至约21%。

显然，使用这些工具无法达到巅峰表现，但如果你愿意为了

操作简便而承受上述 DPS 损失，这值得考虑。

不要让游戏里、论坛上或 Discord 里的任何人

告诉你使用这些工具有什么内在的不对！

暴风雪 创建它们是有原因的，而游戏是为了好玩，无论

对你来说这意味着什么。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 从新手优先级列表中移除了月光战刃，并阐明了宠物建议。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月29日：** 将默认大秘境配点更新为无冷却流配点。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月13日：** 更新了简易模式的循环和配点，使其更易于理解。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到你的生存猎人在魔兽世界12.1.5补丁中的最佳天赋。我们还提供针对不同类型内容（如团队副本或大秘境）的默认天赋构筑。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 生存猎人的最佳至暗之夜天赋

生存在所有内容中都玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖有

对优先目标的伤害略高一些，但 哨兵 在

大波拉怪中造成更高的总体伤害，同时更耐打且更易上手。我们认为这笔交易对

适合几乎所有人，我们在下面提供了猎群领袖配装，供那些偏好的玩家使用

玩法风格。该专精的一大优势是它在单体目标中损失极少

却能打出出色的AoE/顺劈伤害。

因此，除了字面意义上纯 **单体** 目标

首领战之外，生存在所有场景中都使用其AoE构筑的变体。

如果你所在的团队副本首领战中[[spell:1262409]]的

[[spell:1261193]]冷却缩减对你没有任何帮助，那么就改用

改为使用[[spell:1253053]]。

**快速开始导入代码：**

:::talents 生存单体 - 哨兵
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYmgtZMzMGzyAAAAAAwMmxMLmxYGzgx0MAAAADAmx2yMzsYMzMjZmBAzYZDGDjNDAA"
}
```
:::

:::talents 生存团队副本AoE/顺劈 - 哨兵
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYmgNjZmxwyAAAAAAwMmxMLmxYGzgx0MAAAADAmxyyMzswMzMjZmBAzYZDGjZmNDAA"
}
```
:::

:::talents 生存大秘境 - 哨兵
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxYGLDgZGYbmZmZmxsNPAAAAAAgZMzMjtZMmxMsMmmBAAAYAgxyyMjFMzMegxYAYGbgxYmZzAAA"
}
```
:::

:::talents 生存地下堡 - 哨兵
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxYGLDgZGYbmZmZmxsNPAAAAAAgZMzMDGjZMzwYaAAAAAAGLLzMWwMzMzYMAMjNsMjxMzmBAAA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

哨兵

单体目标

推荐

团队副本 AoE/顺劈

推荐

秘境+

推荐

地下堡

推荐

猎群领袖

单体目标

秘境+

地下堡

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵单体构筑，适用于大多数团队副本首领战。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 团队副本AOE/顺劈天赋配置

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵用于具有AoE或顺劈能力的团队副本首领的构筑。它舍弃了单体构筑中的[[spell:389880]]组合，转而将这些天赋点投入到[[spell:259388]]和[[spell:1272139]]中，以极小的单体损失换取大量的顺劈伤害。团队副本中大多数首领都有某种AoE或顺劈能力，因此这是全程最常用的构筑。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 针对大秘境及其他以AOE为核心内容的配置。它基于模拟真实大秘境副本中的条件，不仅看什么能打出最多DPS，更看什么在团队中能真正更快地通关副本。有些配置能打出更多AOE伤害，但它们在AOE上获得的收益都少于在单体上损失的，反之亦然。

1.3.1.

##### 生存猎人功能性天赋考量

- 你的“灵活”天赋点，按我们推荐的最可舍弃顺序排列为：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] 只在某些副本中有用，在其他副本中毫无价值。

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵地下堡天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 针对 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。它与我们的大秘境天赋构筑相似，但在职业天赋树的选择上有所不同，以便更好地适应宠物坦的单人游戏。

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖单体天赋

这套配置是我们 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖单体构筑，适用于大多数团队副本首领战。

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 大秘境天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 大秘境构建。它基于模拟真实大秘境副本中的条件，不仅看什么能打出最高的 DPS，还看在队伍中实际什么能更快地通关副本。有些构建能打出更高的 AoE 伤害，但它们在 AoE 上获得的收益都比不上在单体上损失的，反之亦然。

1.6.1.

##### 生存猎人功能性天赋考量

- 你的“灵活”天赋点，按我们推荐的最可舍弃顺序排列为：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] 只在某些副本中有用，在其他副本中毫无价值。

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 探宝天赋

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 用于 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)的构建。它与我们的大秘境天赋构建类似，但在职业天赋树的选择上有所不同，更适合由宠物坦怪的单人游玩。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MmZGjZZAAAAAAYGzYmFzYMjZwYaGAAAgBAzYbZmZWMmZmxMzAgZssBjhxmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-ABDEFGIKKLYcceiKZiqqyy6S2GXn3nI-AAAA-BEIMQYcAJRZhpB-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGwmxMzYYZAAAAAAYGzYmFzYMjZwYaGAAAgBAzYZZmZWYmZmxMzAgZssBjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-BDEFGILYcceiIZiqqyy6im2GXn3Xo4I-AAAA-BEIMQYcAJRZhpB-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGbzYMjZYZMNDAAAwAAjllZGLYmZ8AjxAwM2AjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGMGzYmhx0AAAAAAMWWmZsgZmZmxYAYGbYZGjZmNDA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIMMNNOPRRSTWWYaeffgiikoSVXD-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgNYGGawyMmZGzMLDAAAAAAzYGzsYGjZMDGTzAAAAMAYGLLzMzCmZmxMzAMzGsBjhxmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFHIJWYYaaceiikssw0268ADFFHLruG-ABDEFGIJKKLYcceiIZiqqyy6yGXn3nI-AAAA-ACEGIU04ARZhpJ-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZmZGLDAAAAAAzYmZGbzYMjZYZMNDAAAwAgZssMzYhZmhHYMGwMbAYMmZ2MAA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-BCDEFGHIJLYcceiIZiqq6im2GX3Xo4I-AAAA-ACEGIUw4ARZhpJ-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZmZGLDAAAAAAzYmZGMGzYmhx0AAAAAAmxyyMjFmZGzMGDYmNALzYMzsZAA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIMMNNOPRRSTWWYaeffgiikoSVXD-BCDEFGHIJLYcceiIZiqq6im2GX3Xo4I-AAAA-ACEGIUw4ARZhpJ-
```

:::

上面列出的构建是热门推荐，

涵盖了适合每种终局内容风格的各种不同配装。

每个天赋构建都会有其自己的循环，并且还可以针对

特定类型的内容进一步调整，以更好地造福你的队伍。

1.

### 全知典籍

万卷典籍是 至暗之夜 中引入的“借用力量”系统，

[12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)在完成一段简短的任务线后，

会提供一些中等强度的自定义选项。

其中一些加成会影响你的伤害输出，但也有防御

和机动性选项可供选择。

你的典籍进度会带入第2赛季。选择这些加成：

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]。这个是最
  
  
  
  
  灵活的，可能会随着你装备的属性需求而改变，就像你的合剂
  
  
  
  
  或武器附魔一样。精通是一个稳妥的“永远不会错”的选择。
- [[spell:1279614]]

1.

### 巅峰天赋： ![Raptor Swipe Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_hunter_raptorswipe.jpg>) 猛禽横扫

至暗之夜 引入了新的巅峰天赋，在 80 至 90 级之间解锁。

生存 获得：

1. [[spell:1259003]]
2. [[spell:1259017]]
3. [[spell:1259019]]

它们使每隔一次的 [[spell:186270]] 变成

[[spell:1259003]]，造成更高伤害，并使其命中多个

目标。非常简单且被动，但非常强大。

1.

### 生存猎人英雄天赋

英雄天赋在71级解锁，是互斥的天赋树，你可以

选择略微调整游戏玩法和视觉效果。生存 猎人 可以选择

之间 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 是我们最简单的英雄天赋，它几乎不改变

专精的玩法。它会定期为你提供

当你消耗 [[spell:260285]] 时触发 [[spell:1253601]]，

大幅提升你下一个 [[spell:259495]] 的伤害。在

此外，当你激活 [[spell:1250646]] 时，Takedown 按钮本身会

变为 [[spell:1264902]]，一个使用时造成大量伤害的技能。

在 Takedown 期间我们只能使用一次，而且它需要一段时间才能造成全部

伤害，所以请在 [[spell:1250646]] 开始时尽早施放它。

在防御方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵 为我们提供 [[spell:450373]]，它几乎

持续触发，并提供大量被动耐打能力。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 对优先目标的伤害略高于

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵，代价是大波次拉怪时的整体伤害降低。

偶尔，你的 [[spell:259489]] 会触发一次

野兽，通过 [[spell:471876]]。这些野兽只是造成伤害，或者

提升你的伤害输出。此外，你的第一个 [[spell:259489]]

掌握

[[spell:1250646]] 会召唤一个 [[spell:201430]]，一列宠物对所有

群体伤害

被其命中的目标造成大量伤害。我们在循环页面中详细介绍了它的使用方法

页面。

在防御方面， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 为我们提供 [[spell:472707]]，它能增强

我们 [[spell:264735]] 的效果。不太好。

1.

### PvP天赋（战争模式）

**这些选择适用于开启战争模式的开放世界PvE内容，不适用于

真正的PvP。**

战争模式为你在开放世界中提供了多项好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式对升级和PvE内容的好处，

建议启用该功能，以在满级时最大化你的升级速度和奖励。

但是，你将被标记为开放世界PvP状态，并且

在升级或进行世界任务时存在被“偷袭”的可能性。

- [[spell:203235]] 是升级和开放世界内容中非常有价值的加速效果。
  
  
  
  
  世界内容。
- [[spell:212640]] 是一个强大的脱战治疗，同时还能清除
  
  
  
  
  残留的减益效果。
- [[spell:202746]] 对于打断小怪的强力施法非常有用，还能
  
  
  
  
  你无法以其他方式打断的其他玩家的强力施法很有用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月30日：** 哨兵 单体构建现在选择重击而非血腥之爪（+0.15%）。
- **2026年9月15日：** 新增了一个团队副本范围伤害/顺劈构建，现在这是我们对任何有小怪或第二目标的团队副本首领的推荐。
- **2026年8月18日：** 更新了团队副本构筑的效用天赋。
- **2026年8月17日：** 万卷集配置现在选择虚空污染之壳而非自我修复。
- **2026年8月12日：** 地下堡构筑现在选择紧急药膏而非荒野医术。
- **2026年8月11日：** 更新了猎群领袖的天赋构建。单体将龟壳震荡替换为双牙，大秘境将一点从横扫之矛移入锋刃。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 更新了万世典籍第4周符文和英雄天赋指南。
- **2026年6月17日：** 根据实际数据优于模拟结果，更新了推荐的第一周卷集符文。
- **2026年6月16日：** 微小（+0.1%）的大秘境天赋构建变更。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月28日：** 更新了猎群领袖的实用天赋，选择滑行之靴而非大师召唤。大秘境的职业天赋实用选择有小幅变更。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月25日：** 添加了关于哨兵漏洞的备注，并更新了推荐的英雄天赋/构建。
- **2026 年 3 月 17 日：** 修复了哨兵大秘境构建中的错误。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月1日：** 猎群领袖大秘境构建更新。
- **2026年2月28日：** 生存单体天赋更新。
- **2026年2月26日：** 更新了大秘境天赋推荐。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月12日：** 全面更新了英雄天赋推荐。
- **2026 年 2 月 11 日：** 更新了关于大秘境英雄天赋的备注。推荐本身没有变化，只是提供了更多背景信息。
- **2026年2月10日：** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月4日：** 哨兵大秘境构建的小幅更新。
- **2026年1月31日：** 更新了大秘境构建。木桩测试表明AoE基本持平，单体略有提升，同时从循环中移除了一个按键，并采用与单体构建匹配的1分钟冷却时间轴。
- **2026年1月21日：** 哨兵大秘境构建更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月4日：** 在模拟工具修复后，将推荐的大秘境英雄天赋更新为哨兵。
- **2025年8月31日：** 微调了大秘境天赋选择的排列。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月13日：** 更新了大秘境的哨兵构建，以修正无情掠夺者此前模拟结果偏低的问题。
- **2024年11月6日：** 添加了大秘境构建，并添加了关于适合新手的天赋替换建议。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月8日：** 已针对10月8日的在线修正进行更新。
- **2024年9月29日：** 添加了一套备选单体构建。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月27日：** 将“短期爆发”AoE构建更新为赛季前的默认构建。
- **2024年8月24日：** 新增了地下堡推荐构建。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月26日：** 为使用第3赛季套装的玩家新增了天赋配点，这是最优选择。
- **2024年7月25日：** 鉴于血腥之爪在前夕补丁中的表现与测试服不同，更新了大秘境配点。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月12日：** 在大秘境配点中默认加入了 误导。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月29日：** 将默认大秘境配点更新为无冷却流配点。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月28日：** 更新了单体输出和史诗钥石地下城天赋配点。
- **2023 年 11 月 12 日：** 新增了T30史诗钥石地下城配点。
- **2023年11月9日：** 对史诗钥石地下城配点进行了小幅调整，以提升单体输出能力。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 重构了页面并针对10.1.7版本进行了更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月23日：** 根据最新的APL改动，更新了AoE和AoE无冷却配点。
- **2023年5月26日：** 新增了轰炸机和矛头配点。
- **2023年5月19日：** 更新了页面布局。
- **2023年5月13日：** 更新了推荐的AoE/史诗钥石地下城天赋。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 更新了推荐的大秘境配点。
- **2023年1月8日：** 更新了突进的推荐状态，并根据最近的增益效果重新检查了天赋的正确性。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月29日：** 进一步更新了推荐的少目标AoE温西尔配点。
- **2022年10月27日：** 更新了推荐的少目标AoE配点，并修复了字符串的一个问题。
- **2022年10月26日：** 新增了一个基于基瑞安的天赋配点，强调强大的爆发能力，主要用于高层怪物数量多的史诗钥石地下城。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何优化你的 生存 猎人 在单体和多目标情况下的循环。我们还提供关于冷却时间、触发效果等的进阶部分，以便最大化你的 DPS。我们的所有内容均已针对《魔兽世界》12.1.5 版本补丁更新。

1.

### 生存 猎人 玩法与循环指南

欢迎来到我们的 生存 猎人循环页面。在本页中，你将找到关于在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

这里的循环，除了更具体的起手式外，是以
**条件优先级列表**。本质上，对于你施放的每一个法术，你都应该施放你能施放的最高优先级法术， **即满足条件的法术。** 施放法术后，你应该从优先级列表顶部重新开始，重复此过程。

下面的按钮可用于在精选的 **单体目标**
和 **AoE/大秘境** 配装之间进行选择。你也可以使用下面的开关来添加或移除你可能也在使用的个别天赋。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖

单体目标

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

被动天赋

[[spell:1272139]]

[[spell:1262409]]

### 单体输出循环

1.1.

#### 生存 猎人 单体起手

确保 [[spell:257284]] 在你的主目标身上生效。

---

**适用条件：猎群领袖（启用）；Twin Fangs（未启用）。**

[[spell:259495]]

1s

拉怪

[[spell:259489]]

[[item:241288]]

[[spell:1250646]]

[[spell:259489]]

[[spell:259495]]

[[spell:259495]]

[[spell:1261193]]

[[spell:186270]]

**适用条件：猎群领袖（启用）；Twin Fangs（启用）。**

[[spell:259495]]

1s

拉怪

[[spell:1250646]]

[[item:241288]]

[[spell:259495]]

[[spell:259489]]

[[spell:1261193]]

[[spell:259495]]

[[spell:186270]]

[[spell:259489]]

[[spell:186270]]

**适用条件：哨兵（启用）；Twin Fangs（未启用）。**

[[spell:259495]]

1s

拉怪

[[spell:259489]]

[[item:241288]]

[[spell:1261193]]

[[spell:259489]]

[[spell:1250646]]

[[spell:259495]]

**适用条件：哨兵（启用）；Twin Fangs（启用）。**

[[spell:259495]]

1s

拉怪

[[spell:1261193]]

[[item:241288]]

[[spell:1250646]]

[[spell:259495]]

---

1. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 在战斗开始前约 1 秒施放 [[spell:259495]]。
2. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:259489]]
3. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 使用你的药水、主动饰品、种族技能等。
4. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
5. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:259489]]
6. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:259495]]
7. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:259495]]
8. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:1261193]]
9. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:186270]]
10. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 继续按照下面描述的优先级列表进行。
11. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** 在战斗开始前约 1 秒施放 [[spell:259495]]。
12. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:1250646]]，同时配合你的药水、使用型饰品、种族技能等。
13. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259495]]
14. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259489]]
15. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:1261193]]
16. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259495]]
17. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:186270]]
18. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259489]]
19. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:186270]]
20. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** 继续按照下面描述的优先级列表进行。
21. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 在战斗开始前约 1 秒施放 [[spell:259495]]。
22. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:259489]]
23. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 使用你的药水、主动饰品、种族技能等。
24. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:1261193]]
25. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:259489]]
26. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
27. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:259495]]
28. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 继续按照下面描述的优先级列表进行。
29. **适用条件：哨兵（启用）；Twin Fangs（启用）。** 在战斗开始前约 1 秒施放 [[spell:259495]]。
30. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:1261193]]，同时配合你的药水、使用型饰品、种族技能等。
31. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:1250646]]
32. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:259495]]
33. **适用条件：哨兵（启用）；Twin Fangs（启用）。** 继续按照下面描述的优先级列表进行。

1.2.

#### 生存 猎人 单体优先级列表

以下是描述 生存 猎人 最优单体循环的优先级系统。

1.3.

#### 利矛之刃

生存 猎人 的黄金法则是每个技能都必须通过 [[spell:260285]] 获得"Tipped"效果，这是一个由 [[spell:259489]] 提供的增益，得益于 [[spell:1272154]] 可提供 2 层效果。该专精的一般流程是 [[spell:259489]] > 根据优先级列表施放 2 个 Tipped 技能 > 重复。有些技能不需要 Tipped，因此请遵循下面的优先级列表。

1. **适用条件：猎群领袖（启用）。** 如果 [[spell:471876]] 已就绪，在少于 2 层 [[spell:260285]] 时施放 [[spell:259489]]。
2. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 如果 [[spell:1250646]] 即将结束冷却，在少于 2 层 [[spell:260285]] 时施放 [[spell:259489]]。
3. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 在拥有至少 2 层 [[spell:260285]] 时施放 [[spell:1250646]]。
4. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** 在没有 [[spell:260285]] 层时施放 [[spell:1250646]]。
5. **适用条件：猎群领袖（启用）；Lethal Calibration（未启用）。** 冷却完毕即施放 [[spell:259495]]。
6. **适用条件：Lethal Calibration（启用）；猎群领袖（启用）。** 如果 [[spell:259495]] 距离达到 2 层充能不足 5 秒，则施放它。
7. **适用条件：猎群领袖（启用）。** 冷却完毕即施放 [[spell:1261193]]。
8. **适用条件：猎群领袖（启用）。** 施放 [[spell:186270]]。如果它是 [[spell:1259003]]，则必须拥有 Tip。如果不是，则是否拥有 Tip 无所谓。每第 2 次猛禽都是横扫。
9. **适用条件：猎群领袖（启用）；Lethal Calibration（启用）。** 冷却完毕即施放 [[spell:259495]]。
10. **适用条件：猎群领袖（启用）。** 如果 [[spell:1250646]] 正在冷却，则施放 [[spell:259489]]。
11. **适用条件：猎群领袖（启用）。** 施放 [[spell:1250646]]。
12. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 如果你没有剩余的 [[spell:260285]]，则施放 [[spell:259489]]。
13. **适用条件：Twin Fangs（启用）；哨兵（启用）。** 如果你没有剩余的 [[spell:260285]] 且 [[spell:1250646]] 正在冷却，则施放 [[spell:259489]]。
14. **适用条件：哨兵（启用）。** 冷却完毕即施放 [[spell:1261193]]。
15. **适用条件：哨兵（启用）。** 如果目标拥有 [[spell:1253601]]，或距离达到 2 层充能不足 4 秒，则施放 [[spell:259495]]。
16. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 如果 [[spell:1250646]] 即将结束冷却，在少于 2 层 [[spell:260285]] 时施放 [[spell:259489]]。
17. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 在拥有至少 2 层 [[spell:260285]] 时施放 [[spell:1250646]]。
18. **适用条件：Twin Fangs（启用）；哨兵（启用）。** 在没有 [[spell:260285]] 层时施放 [[spell:1250646]]。
19. **适用条件：哨兵（启用）。** 施放[[spell:1264902]]。
20. **适用条件：哨兵（启用）。** 施放 [[spell:186270]]。每第 2 次猛禽都是 [[spell:1259003]]。
21. **适用条件：哨兵（启用）。** 施放 [[spell:259489]] 作为填充技能，但如果 [[spell:1250646]] 可用则优先使用。
22. **适用条件：哨兵（启用）。** 施放 [[spell:259495]]。
23. **适用条件：哨兵（启用）。** 施放 [[spell:1250646]]。

### AOE循环

1.4.

#### 生存 猎人 AoE 起手

确保 [[spell:257284]] 在你的主目标身上生效。

---

**适用条件：猎群领袖（启用）。**

**适用条件：Twin Fangs（启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（启用）。**

[[item:241288]]

**适用条件：Twin Fangs（启用）。**

[[spell:259495]]

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[item:241288]]

**适用条件：Twin Fangs（未启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259495]]

[[spell:1261193]]

[[spell:259495]]

**适用条件：Twin Fangs（启用）。**

[[spell:259495]]

[[spell:186270]]

**适用条件：Twin Fangs（启用）。**

[[spell:259489]]

**适用条件：哨兵（启用）。**

**适用条件：Twin Fangs（启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（启用）。**

[[item:241288]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[item:241288]]

[[spell:1261193]]

[[spell:259495]]

[[spell:259489]]

[[spell:259495]]

**适用条件：Twin Fangs（未启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（未启用）。**

[[spell:1250646]]

**适用条件：Twin Fangs（启用）。**

[[spell:1264902]]

**适用条件：Twin Fangs（启用）。**

[[spell:259489]]

**适用条件：Twin Fangs（启用）。**

[[spell:259495]]

---

1. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:1250646]]，同时配合你的药水、使用型饰品、种族技能等。
2. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259495]]
3. **适用条件：猎群领袖（启用）。** [[spell:259489]]
4. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 使用你的药水、主动饰品、种族技能等。
5. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
6. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:259489]]
7. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** [[spell:259495]]
8. **适用条件：猎群领袖（启用）。** [[spell:1261193]]
9. **适用条件：猎群领袖（启用）。** [[spell:259495]]
10. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259495]]
11. **适用条件：猎群领袖（启用）。** [[spell:186270]]
12. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** [[spell:259489]]
13. **适用条件：猎群领袖（启用）。** 继续按照下面描述的优先级列表进行。
14. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:1250646]]，同时配合你的药水、使用型饰品、种族技能等。
15. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:259489]]
16. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 使用你的药水、主动饰品、种族技能等。
17. **适用条件：哨兵（启用）。** [[spell:1261193]]
18. **适用条件：哨兵（启用）。** [[spell:259495]]
19. **适用条件：哨兵（启用）。** [[spell:259489]]
20. **适用条件：哨兵（启用）。** [[spell:259495]]
21. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:259489]]
22. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** [[spell:1250646]]
23. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:1264902]]
24. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:259489]]
25. **适用条件：哨兵（启用）；Twin Fangs（启用）。** [[spell:259495]]
26. **适用条件：哨兵（启用）。** 继续按照下面描述的优先级列表进行。

1.5.

#### 生存 猎人 AoE 优先级列表

以下是描述 生存 猎人 最优 AoE 循环的优先级系统。

1.6.

#### 利矛之刃

生存 猎人 的黄金法则是每个技能都必须通过 [[spell:260285]] 获得"Tipped"效果，这是一个由 [[spell:259489]] 提供的增益，得益于 [[spell:1272154]] 可提供 2 层效果。该专精的一般流程是 [[spell:259489]] > 根据优先级列表施放 2 个 Tipped 技能 > 重复。有些技能不需要 Tipped，这些已在下方明确注明。

1. **适用条件：猎群领袖（启用）。** 如果 [[spell:471876]] 已就绪，在少于 2 层 [[spell:260285]] 时施放 [[spell:259489]]。
2. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 如果 [[spell:1250646]] 即将结束冷却，在少于 2 层 [[spell:260285]] 时施放 [[spell:259489]]。
3. **适用条件：猎群领袖（启用）；Twin Fangs（未启用）。** 在拥有至少 2 层 [[spell:260285]] 时施放 [[spell:1250646]]。
4. **适用条件：猎群领袖（启用）；Twin Fangs（启用）。** 在没有 [[spell:260285]] 层时施放 [[spell:1250646]]。
5. **适用条件：猎群领袖（启用）。** 如果 [[spell:259495]] 即将达到 2 层充能，则施放它。无需 Tipped。
6. **适用条件：猎群领袖（启用）。** 冷却完毕即施放 [[spell:1261193]]。
7. **适用条件：猎群领袖（启用）。** 冷却完毕即施放 [[spell:259495]]。
8. **适用条件：猎群领袖（启用）。** 施放 [[spell:186270]]。如果它是 [[spell:1259003]]，则必须拥有 Tip。如果不是，则是否拥有 Tip 无所谓。每第 2 次猛禽都是横扫。
9. **适用条件：猎群领袖（启用）。** 如果 [[spell:1250646]] 正在冷却，则施放 [[spell:259489]]。
10. **适用条件：猎群领袖（启用）。** 冷却完毕即施放 [[spell:259495]]。无需 Tipped，但这仅在你无法施放其他技能时才会出现。
11. **适用条件：猎群领袖（启用）。** 施放 [[spell:1250646]]。
12. **适用条件：哨兵（启用）。** 如果你没有剩余的 [[spell:260285]]，则施放 [[spell:259489]]。
13. **适用条件：哨兵（启用）。** 冷却完毕即施放 [[spell:1261193]]。
14. **适用条件：哨兵（启用）。** 施放 [[spell:259495]]，优先选择拥有 [[spell:1253601]] 的目标。
15. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 如果 [[spell:1250646]] 即将结束冷却，在少于 2 层 [[spell:260285]] 时施放 [[spell:259489]]。
16. **适用条件：哨兵（启用）；Twin Fangs（未启用）。** 在拥有至少 2 层 [[spell:260285]] 时施放 [[spell:1250646]]。
17. **适用条件：哨兵（启用）；Twin Fangs（启用）。** 在没有 [[spell:260285]] 层时施放 [[spell:1250646]]。
18. **适用条件：哨兵（启用）。** 施放[[spell:1264902]]。
19. **适用条件：哨兵（启用）。** 施放 [[spell:186270]]。如果它是 [[spell:1259003]]，则必须拥有 Tip。如果不是，则是否拥有 Tip 无所谓。每第 2 次猛禽都是横扫。
20. **适用条件：哨兵（启用）。** 施放 [[spell:259489]]。
21.

### 至暗之夜 第2赛季套装

至暗之夜 第 2 赛季团队副本套装对我们的循环没有影响。2 件套使 [[spell:259388]] 提升 [[spell:259495]] 10% 的伤害，4 件套则使 [[spell:1261193]] 的每次爆破将 [[spell:259388]] 延长 1 秒，此外还将 Mongoose 狂怒 的效果提升 10%。这是 [[spell:259495]] 的大幅提升，但实际上没有任何变化，因为炸弹已经积极地在冷却完毕时使用。

1.

### 职业与专精机制详解

为了更好地解释 生存 猎人 技能组合的具体用法和优势，我们汇编了关于循环各个部分的更详细说明，从你需要关注的重要循环机制，到冷却时间及其使用方法，以便你在游玩 生存 猎人 时发挥全部潜力。

### [[spell:259495]]

3.1.

#### 野火炸弹

[[spell:259495]] 是 生存 的核心技能。它的伤害分为"直接"伤害（由 [[spell:260285]] 增强）和一个不受影响的 6 秒持续伤害效果。

关于炸弹需要理解的最关键的一点是它的目标选择方式。你将它投向 **一个目标**，然后炸弹在到达该目标时爆炸。炸弹在目标后方的锥形区域 **和** 以及目标周围的小半径圆形区域内爆炸。换句话说，如果该小怪与其他一群小怪紧密聚集在一起，那么无论你面向哪个方向，炸弹都会命中它们全部。

然而，如果目标分布得稍微分散一些，你就需要依赖目标后方的锥形区域，而"后方"是相对于你的位置而言的。换句话说，你实际上是将炸弹投掷
**穿过** 你的目标，使其命中目标后方的敌人。因此，相对于你想命中的目标适当调整角度和角色位置，对于最大化该技能的效果至关重要，尤其是在大秘境中。

### [[spell:1259019]] Apex 天赋

3.2.

#### 猛禽横扫 Apex 天赋

[[spell:1259019]] 使我们的 [[spell:186270]] 按钮每第二次施放时自动"升级"为该按钮的 AoE 版本，同时造成显著更高的单体伤害。这完全是自动发生的，对我们的循环优先级影响不大。

1.

### 生存 猎人 的重要冷却技能

### [[spell:1250646]]

4.1.

#### 狩魂一击

[[spell:1250646]] 是 生存 的主要冷却技能。它是一个相对简单的 1 分 30 秒冷却技能，投入 [[spell:424557]] 天赋 2 点后可缩短至 1 分钟冷却。使用时造成大量伤害，然后在 8 秒内将你的所有伤害提升 20%，并使你的自动攻击速度翻倍。

这个冷却技能最不寻常的地方在于其极短的持续时间。在 WoW 中，绝大多数 DPS 冷却技能持续 15-20 秒，但 Takedown 仅持续 8 秒。这意味着如果我们想在其持续时间内塞入高伤害技能，我们没有太多时间，这也决定了我们的起手选择，偶尔也影响饰品选择（例如，30 秒使用型饰品就不是很好）。

请注意，除 [[spell:1250646]] 外，1 层 [[spell:260285]] 对所有技能都足够，而 [[spell:1250646]] 在没有 [[spell:1272139]] 时必须在拥有 2 层时施放。Takedown 有两个部分，玩家部分和宠物部分，它们不会同时发生。如果宠物在 1 秒后命中时 Tip 未激活，它将不会获得 Tip 增益。因此，在没有 Twin Fangs 的情况下，Takedown **必须** 必须在至少拥有 2 层 Tip 时施放。始终如此。

4.1.1.

##### Takedown 的英雄天赋影响

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 在 哨兵 中，按下 [[spell:1250646]] 按钮后会变为 [[spell:1264902]]。该技能造成大量伤害，如果选择了 [[spell:1266069]]，甚至可以将 [[spell:259495]] 的冷却时间缩短 10 秒。在我们的 [[spell:1250646]] 中我们只能使用一次，但由于它造成全部伤害需要相当长的时间，我们不想将其留到爆发窗口的最后。如果我们确实使用 [[spell:1266069]]，在使用它之前清空我们的 [[spell:259495]] 也很重要，以免浪费冷却缩减。

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖，[[spell:1250646]]会立即触发[[spell:471876]]，使你的下一个[[spell:259489]]召唤一只野兽。这会与自然触发的、基于冷却时间的嚎叫触发效果"叠加"，你无需担心在激活[[spell:1250646]]之前浪费嚎叫触发效果。此外，你在[[spell:1250646]]内的第一个杀戮命令也会发射一道[[spell:201430]]。这是一条约30码长的"野兽之线"，它们会冲向你的目标，并在你按下杀戮命令时放置。它在7秒内对其中的所有敌人造成大量伤害。

由于该效果在你于[[spell:1250646]]期间施放第一个[[spell:259489]]时就已放置且不会移动，又因为它是一条从你角色位置延伸出去的长直线，因此瞄准并定位这条直线至关重要，尤其是在AOE场合。

你需要放置兽群冲锋，使其尽可能长时间地覆盖尽可能多的目标。调整你角色的位置，使这条直线不仅穿过小怪当前的位置，还要穿过它们移动后的位置， **还要穿过你认为它们可能去往的位置**，这对充分利用兽群冲锋至关重要。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月30日：** 更新了 哨兵 针对 Boomstick 和 野火炸弹 的单体优先级，以及其双牙起手式，现在以 Boomstick 开场，在猛禽一击前建立狂怒 狂怒 层数。
- **2026年8月16日：** 更新了哨兵的AoE起手式，现在在天赋双牙时以扑击开怪。
- **2026年8月11日：** 阐明了野火炸弹在哨兵AoE优先级中的目标选择。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 将扑击的持续时间更正为8秒，突进的长度更正为30码。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026 年 5 月 21 日：** 修复了双牙循环逻辑顺序颠倒的问题。
- **2026年4月28日：** 为AoE和单体添加了额外的野火炸弹条件。
- **2026年4月27日：** 更新并阐明了关于猛禽一击/横扫的提示措辞。
- **2026年4月23日：** 起手式更新。
- **2026年4月21日：** 扩充了关于扑击窗口准备的内容。起手式更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 22 日：** 更新了猎群领袖的单体起手式。
- **2026年3月18日：** 微调了哨兵带双牙的单体起手式。
- **2026 年 3 月 17 日：** 哨兵起手式更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月12日：** 大幅更新了猎群领袖的单体循环。
- **2026 年 2 月 11 日：** 在猎群领袖的AoE循环中添加了掷斧的说明。
- **2026年2月10日：** 为即将到来的12.0.1版本改动进行了小幅循环更新。
- **2026 年 1 月 20 日：** AoE循环改进。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月30日：** 起手式小幅更新。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月16日：** 移除了关于毒蛇钉刺多目标DoT的过时说明。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月23日：** 单体起手式的小幅阐明和更正。
- **2024年11月20日：** 增加了对多个循环细节“为什么”的更详细说明。
- **2024年11月18日：** 扩充了AoE循环并添加了更多细节。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月25日：** 更新了AoE循环，并在此过程中对其进行了简化。
- **2024年10月23日：** 更新了AoE起手式。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月2日：** 新增了更具体的饰品使用信息。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月26日：** 小幅的各类修复，主要是针对纯单体构建的起手式。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月30日：** 对循环和起手式进行了小幅优化更新，主要是关于为矛尖/协同突袭保留爆炸射击。
- **2024年7月29日：** 更新了单体起手式，以便尽早施加毒蛇钉刺来触发外域之毒。
- **2024年7月28日：** 根据 生存猎人 Discord 频道的建议，实施了循环输出 DPS 优化。
- **2024年7月25日：** 更新并简化了输出循环。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023 年 11 月 12 日：** 在单体输出循环中补充了缺失的 野火炸弹 一行。
- **2023年11月7日：** 修复了在AoE配点下单体输出循环中 野火炸弹 不显示的问题。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月17日：** 根据最新的APL更新，对AoE循环和起手式进行了重大更新，并将主动使用类饰品加入循环中。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月29日：** 更新了单体输出循环中的死亡飞轮一行。
- **2023年6月16日：** 进行了大规模的循环重构，新增了复选框、可选择复选框预设的新功能，以及对单体输出和AoE循环的多项改动。
- **2023年6月15日：** 移除了AoE循环的第一行，从而降低了在AoE中维持4件套减益效果的优先级。
- **2023年6月13日：** 移除了狂怒之翼下的寻血者宏，因为该错误已修复，不再需要。
- **2023年6月3日：** 对AoE起手式进行了小幅调整。
- **2023年5月26日：** 对AoE起手式进行了重大更新，以更好地反映AoE循环的改动。
- **2023年5月25日：** 进行了重要的AoE循环更新，更新了默认复选框，并新增了关于 狂怒之鹰 宏的重要信息。
- **2023年5月13日：** 对4件套循环行的措辞进行了小幅修改。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 进行了小幅的循环修复。
- **2022年12月11日：** 更新了鱼叉猛刺在循环中的作用。
- **2022年12月11日：** 针对套装奖励的循环更新。
- **2022年11月30日：** 将优先级中关于 杀戮命令 拥有2层充能的描述更新为“不要让充能溢出”，以涵盖有无顶级掠食者天赋的两种情况。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5中你的生存猎人的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 生存猎人毕业装备指南

欢迎来到我们的生存猎人装备与毕业页面，适用于

至暗之夜第2赛季。查看本页面，了解你需要知道的

了解如何为生存猎人配装，包括毕业装备

配装（来自所有渠道）、团队副本和大秘境，以及最佳饰品、套装

等信息，更多内容。

至暗之夜资料片带来了大规模的属性压缩，降低了

游戏中几乎所有内容的属性和数值，包括物品等级和装备

上的属性。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统

让你

沿着与获取物品来源相关的轨道提升装备物品等级，

物品，更难的内容掉落的装备可以升级到更高的物品

等级。

欲了解更多信息，请阅读我们专门介绍

[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 如何运作以及

在 至暗之夜 资料片中有什么变化的专页。

### 总体

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自所有渠道。

有许多不同的配装方案在误差范围内表现相当。本方案尽可能选择团队副本装备，因为它们比碰运气从 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获取正确的秘境装备更容易获得。当没有同样强力的团队副本替代品时，才会选择秘境装备。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
催化器现在会保留你催化的物品的副属性和任何被动效果，所以你放进去的物品比你用哪个部位来完成套装更重要。你最需要的是精通，然后是暴击和急速。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的转化物品：

- 头部：无需制造，套装件直接掉落 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：[[item:271876@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：[[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题：从宏伟宝库中获取什么？
选择 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 几乎每周都如此。例外情况是当宝库提供了你从某个首领或地下城想要的最后一件装备时，因为在那里拿取意味着你再也不需要对那个渠道使用额外拾取。

虚空核心可以对一个团队副本首领或一个大秘境地下城进行额外拾取，并给你一件你之前从未从中拾取过的物品。英雄难度团队副本首领和大秘境提供1/6神话，史诗团队副本首领提供6/6神话，后期首领提供9/6。

有两点使其比看起来更强大。物品等级在你使用虚空核心时决定，而非在你拾取时决定，因此你可以保留一个直到你遇到值得使用的史诗首领。而且从宝库取出的装备仍留在额外拾取池中，所以一件你本来就要替换的装备可能会在之后浪费你一次拾取。

值得用骰子的Boss列在本页下方的“虚无核心”部分。

:::

:::details 双手武器与双持武器
在第2赛季中，生存并未被锁定于任一武器类型。我们的总体和团队副本列表使用双手武器，而我们的大秘境毕业列表使用双持。本版本双手武器更好的主要原因是存在非常独特的强力双手武器，例如[[item:268213]]。没有这个因素，双手和双持配置的表现相似。

没有那把武器的话，两种配置在团队副本和大秘境中的模拟差距不到1%，因此请根据物品等级和属性装备你拥有的最好武器，而不是追求特定类型。

<table> <tr> <th>毕业列表</th> <th>我们使用的配置</th> <th>相对于另一种配置的优势</th> </tr> <tr> <td>总体和团队副本</td> <td>双手，[[item:268213]]</td> <td>比双持好0.9%</td> </tr> <tr> <td>秘境+</td> <td>双持，两把[[item:275070]]</td> <td>比双手好0.2%</td> </tr> </table>

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自至暗之夜第2赛季大秘境。这适用于不打算过多参与团队副本内容的玩家。

有许多不同的配装方案在误差范围内表现相当。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
催化器现在会保留你催化的物品的副属性和任何被动效果，所以你放进去的物品比你用哪个部位来完成套装更重要。你最需要的是精通，然后是暴击和急速。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的地下城掉落用于转化：

- 头盔：[[item:159374@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 肩膀：[[item:239049@JAACAAgNyA]]，掉落于 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸部：[[item:251233@JAACAAgNyA]]，掉落于 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 手套：[[item:160213@JAACAAgNyA]]，掉落于 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 腿部：[[item:159375@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你游戏时间有限，我们建议刷以下地下城：

- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：毕业项链、戒指和饰品
- [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：毕业披风和饰品
- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：毕业武器
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：毕业靴子
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：毕业戒指

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

本列表包含至暗之夜第2赛季每个部位的最佳装备，来自至暗之夜第2赛季团队副本。它与我们的总体毕业列表非常相似，因为该列表也偏向于团队副本装备，但在这种情况下，完全不包含任何秘境装备。

有许多不同的配装方案在误差范围内表现相当。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题：我在转化器中使用哪些物品？
催化器现在会保留你催化的物品的副属性和任何被动效果，所以你放进去的物品比你用哪个部位来完成套装更重要。你最需要的是精通，然后是暴击和急速。

不要因此拖延套装效果。没有4件套的两周代价远高于稍微错误的副属性，而且你可以在本赛季晚些时候转化一件更好的装备。

以下是最佳的团队副本掉落用于转化。如果你也打秘境，秘境装备可以胜过其中任何一件：

- 头部：无需制造，套装件直接掉落 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 肩膀：[[item:268231@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 胸甲：[[item:271876@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 手套：[[item:281238@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 腿部：[[item:268237@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团长提交一份高优先级装备列表，或只是想专注于最重要的首领和装备，我们已为你准备好！

- [[item:268213]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业武器，与[[item:270173]]搭配以获得套装加成。
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业项链，以及剧毒诅咒。大多数专精都需要它，所以请做好竞争准备。
- [[item:270173]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：毕业饰品。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：毕业饰品。
- [[item:281215]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：大秘境毕业饰品。
- [[item:281238]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业手套。
- [[item:268252]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)：毕业戒指。
- [[item:281029]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)：毕业戒指。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 生存猎人饰品推荐

作为生存，我们的最佳配置是[[item:270175]]搭配

[[item:270173]]。在可能的情况下配合

[[spell:1250646]]使用贪婪之心，但不要为了等它而保留超过20

秒。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **生存猎人饰品**
**最佳——**

[[item:270175]]

- 

[[item:270173]]

:::

还有许多其他有价值的饰品，所以请务必

点击我们的排名图表，看看它们是否值得装备。请注意，你

不希望拥有超过1个使用型饰品。你几乎可以将

“使用时触发”的饰品被单独排名，与其他饰品区分开来。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看生存猎人饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]：使用型</li>&#10;<li>[[item:270173]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]：使用型</li>&#10;<li>[[item:273797]]：使用型</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617]]：使用型</li>&#10;<li>[[item:273796]]：使用型</li>&#10;<li>[[item:281215]]：如果你无法获得344的断头台，这是最佳替代品。</li>&#10;<li>[[item:250225]]：使用型</li>&#10;<li>[[item:270165]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:246304]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>E级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:241340]]</li>&#10;<li>[[item:270168]]：主动使用。在有伤害增幅的战斗中可以超过其原始模拟值。</li>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>F级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

- [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 是一种新的货币，可用于对某些
  
  
  
  
  在特定地下城和物品上使用“骰子”。使用后将会 **保证** 掉落
  
  
  
  
  来自该渠道，但你获得的装备是随机的。不过，你会受到
  
  
  
  
  保护免于重复。在一个首领或地下城上使用足够多次，你就
  
  
  
  
  **保证** 获得你想要的装备。

你通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 获得它们，通过拒绝物品奖励，这

需要从任何渠道解锁三个奖励槽（甚至1层地下堡！）。通过

补丁12.1.5上线时，你还能从奥林处免费获得一个额外的虚空核心

斯特拉维尔，他可以在银月城的转化器旁边找到。

3.1.

#### 生存猎人虚空核心使用建议

显然，这个问题的直接答案就是使用

虚空核心来升级你尚未获得的最佳装备。这取决于

你的角色，但我们会为你列出一些最重要的物品

生存猎人，目标是你能够直接往下

列表往下看，追逐你看到的第一个你还没有的装备。

为一个你可能会从即将到来的团队副本首领那里获得的物品使用额外重掷，可能是一个

坏主意，这取决于你如何权衡"当下的力量"与"未来的力量"。

总的来说，你最好的选择是进行 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 在 **英雄难度**.

它有几件高影响力的毕业物品，所以即使你没有立刻重掷到绝对的毕业装，

你仍然能从这次重掷中获得很好的价值。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于[[item:271876]]，
   
   
   
   
   [[item:268265]]和[[item:270175]]
2. [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 用于[[item:268213]]和
   
   
   
   
   [[item:270173]]
3. [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 用于[[item:281238]]和
   
   
   
   
   [[item:281029]]
4. 此时，赛季已经过去很多周了，你的装备将会
   
   
   
   
   参差不齐。我们建议使用
   
   
   
   
   [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>)
   
   
   
   
   来模拟你的最佳额外拾取。

:::

3.2.

#### 晋升毒液石

[[item:280562]]是一种新的升级货币，随着

补丁12.1.5一同到来。每次升级花费10个，它们只能用于你的武器、你的

饰品和项链，让你将这些装备升级到340物品等级。只有

完全升级的英雄级或史诗级装备，或最高

品质的制造装备，才能用它们升级。使用它们的优先级与

你的纹章类似：

1. 你的武器是最高优先级。
2. 你的[[item:270175]]。
3. 你的另一个饰品。
4. 你的项链。

用其他你不常用的史诗级装备来填充。例外

是你不指望在短期内获得史诗级的装备。如果

你没有在史诗难度击杀 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，那么升级一件英雄级的

[[item:270175]].

1.

### 生存猎人最佳制造物品

你可以拥有两个装饰，它们是来自

制造装备。护甲对是更好的长期选择，因为它是你的

实际毕业装备，而制造武器迟早会被神话品质装备的掉落所

稍后。如果你想要力量，先制作武器仍然是一个可行的选择

第1周，而且这把武器的伤害比大秘境武器高约8%

赛季初期可能使用的大秘境武器多约8%的伤害。

- [[item:237847]]或[[item:245771]]，搭配
  
  
  
  
  [[item:273060]]制造，
  
  
  
  
  [[item:245783]]，获得急速/精通。具体选择哪把
  
  
  
  
  武器纯粹取决于个人喜好；它们完全相同。
- [[item:244581]]或[[item:244584]]，搭配
  
  
  
  
  [[item:240167]]制造，
  
  
  
  
  [[item:245789]]，获得暴击/精通。如果你
  
  
  
  
  制造后物品等级提升了就选腰带，如果降低了就选护腕。
- 第二件护甲，通常在第4周左右。如果你先制造了
  
  
  
  
  武器，到那时你很可能已经用
  
  
  
  
  [[item:268213]]或其他神话武器将其替换，
  
  
  
  
  它之前占用的装饰槽就再次空出来给这件护甲了。

制造[[item:244582]]是一个很好的短期护甲

制造选择，如果你永远不会在史诗难度击杀 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

以获得344腿甲，那它就是永久选择。

:::details **生存猎人制造槽位优先级**
**武器 → 项链/戒指 → 其他所有部位 → 披风/护腕**

:::

理想情况下，你应该模拟你的特定角色的

角色而定，但安全的默认选择是暴击/精通，护甲件上使用

[[item:245789]]，武器上使用急速/精通

并搭配[[item:245783]]。

有关制造装备的更多信息，你可以访问我们的

[专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

头盔、腰带和护腕可以掉落带有插槽的，你也可以自己添加一个

使用[[item:275707]]。它花费六个

[[item:258556]]，这是 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 为通关奖励给你的货币。

只要你解锁了三个奖励栏位，你就可以直接获得六个。

奖励栏位解锁。

把它们留给你不打算更换的装备，比如史诗级装备或你的

两个制造部位，因为制造的腰带或护腕无法通过其他

方式获得插槽。

1.

### 纹章使用

你将能够通过徽章升级你的物品，例如

[秘境雾崖](<https://www.wowhead.com/currency=3446>)。一旦你将某个部位升级到特定物品等级，

**将该栏位的其他物品升级到该物品等级就是免费的**.

当你使用纹章升级时，你应该将其视为升级

**插槽** 而不是物品。

由于纹章是有限的资源，你希望在升级某个部位时获得

尽可能高的物品等级 **之前** ，因为这样

意味着你在该部位总共花费的纹章会更少。如果你完全

有能力打一个+10地下城，例如，那么去升级

一个+9地下城的装备将是一个非常糟糕的主意，因为你刚刚浪费了20个纹章，这些纹章本可以

通过在+10刷该部位来节省下来。

我们看到大量玩家，即使在高水平，也搞错了他们的升级

优先级并过早升级。做对这一点会让你远远领先于

大多数玩家。

以下是你应该升级装备的部位优先级。如果你想要

偏离这一点，你应该有一个非常好的理由。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **生存猎人纹章升级优先级**
**武器**

→

**饰品**

→

**头盔/胸甲/腿甲**

→

**肩部/手套/腰带/靴子**

→

**戒指/项链**

→

**披风/护腕**

:::

请注意，例外是可能的，例如某些特殊装备的物品等级成长

高于其部位所暗示的。

1.

### 评估升级

在本页及我们指南的其他地方，我们经常提到

在Raidbots上模拟自己的重要性。这是因为每个角色都是

独特的，你所拥有的每一件装备都可能改变什么是最好的

现在为你。

虽然我们确实为装备和饰品提供建议，但这些并非完整的

替代品来自模拟你自己。真正优化你角色的唯一方法

达到那种程度的方法就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年9月30日：** 修复了胸甲工具提示显示两个毒咒效果的问题。
- **2026年9月4日：** 在饰品排名中将毒怒之泉提升至S级。
- **2026年8月29日：** 将武器附魔更新为哈什之仪。
- **2026年8月24日：** 将制作武器的铭文更正为灼热之泰拉西亚铭文。
- **2026年8月24日：** 更新了武器附魔为狂暴者的愤怒。
- **2026年8月22日：** 添加了关于制作护腿的说明。
- **2026年8月21日：** 将制作的护腕和腰带更新为使用奥术织纹衬里，因为华丽之牙的模拟结果过高。
- **2026年8月18日：** 更新了虚空核心的额外掉落优先级。
- **2026年8月17日：** 更新了饰品梯队表，并更正了关于盖博的无底背包的备注。
- **2026年8月16日：** 重做了制造建议，更正了团队副本物品列表中贪婪的 乌拉特克 之心和盖博的无底袋条目，并添加了赛季开始时的虚空核心和纹章建议。
- **2026年8月15日：** 将大秘境毕业武器更新为两把来自毒牙祭坛的磨利的轻木劈砍者，并添加了关于双手武器和双持武器的章节。
- **2026年8月15日：** 根据最新的平衡性调整更新了饰品梯级榜。
- **2026年8月14日：** 将团队副本毕业手套更新为来自尼姆瑞莎·唤波者的催化漩涡狂怒之握。
- **2026年8月14日：** 移除了关于迷城之灾、军阀的狂怒不在生存掉落列表中的备注，因为它现在已被添加。
- **2026年8月14日：** 更新了虚空星核的额外拾取优先级，并注明迷城之灾、军阀的狂怒目前不在生存的掉落列表中。
- **2026年8月12日：** 添加了催化剂和大秘库常见问题解答及插槽部分，修正了催化剂掉落位置，并更新了团队副本毕业头盔和手套的来源。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 添加了护腕宝石并修正了毕业靴子的行。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月23日：** 为12.0.7版本更新了专业制作建议。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月8日：** 毕业装备列表和饰品层级列表更新。
- **2026年3月31日：** 毕业列表更新。
- **2026年3月25日：** 扩充了各英雄天赋下的武器制作内容。更新了大秘境装备毕业列表。
- **2026 年 3 月 17 日：** 为至暗之夜第一赛季更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月4日：** 更新了终局内容的专业制造推荐。
- **2026年2月26日：** 添加了猎群领袖武器。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月12日：** 添加了关于双手武器与双持的备注。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年9月2日：** 饰品层级列表和毕业装备更新。
- **2025年8月16日：** 根据数值调整更新了饰品梯队表。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月26日：** 更新了泰坦圆盘推荐。
- **2025年6月23日：** 基于最新的在线修正更新了泰坦圆盘推荐。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月10日：** 略微更新了纸牌屋和印记的措辞/代币推荐状态。
- **2025年5月9日：** 更新了腐蚀附魔与谜之卡特尔芯片代币部分。
- **2025年4月21日：** 添加了可用代币购买的物品列表。
- **2025年3月29日：** 更新了大秘境饰品层级列表中克赞之眼的位置。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月14日：** 在增强后更新了无定形圣物的排名。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 更新了关于瑟尔崔指环现在提升至物品等级658的内容。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月2日：** 更新了纯单体的毕业饰品。
- **2024年9月20日：** 在重新评估和模拟工具成熟后，更新了饰品梯队表和最佳饰品。
- **2024年9月13日：** 新增了关于双黎明之线衬里无效及其解决方法的说明。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月27日：** 在赛季前毕业列表中新增了关于制造装备的说明。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月25日：** 更新了最佳饰品、制造品清单、最佳装备清单等内容。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到生存猎人的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 生存猎人属性优先级

生存猎人所有天赋构建的属性优先级如下

如下：

精通

暴击

急速

全能

请记住，某项属性相对于其他属性越少，它

往往就越强。属性优先级是基于平衡所有属性并考察

各属性从设定起点起的成长强度，同时参考

该专精模拟得分最高的装备配置，以及分析是哪种属性优先级

达到了那个效果。

请注意，在生存上，暴击和急速足够接近，可以视为

可互换，无论你使用哪个英雄天赋。暴击通常更容易在

大多数装备上找到。你更应该关注最大化

精通，而不是你的暴击/急速比例。

1.

### 深入属性解析

**敏捷** 是你的主属性。它为你提供攻击强度，

这决定了你所有技能造成的伤害。

**精通**，通过[[spell:263135]]，提高

你和你的宠物的伤害，并使你受到的伤害固定降低3%。当你

在你的宠物25码范围内时，其效果翻倍。提高精通会

提升伤害，但不会提升减伤效果。

**急速** 提高你和你的宠物的攻击速度和集中值

回复，将你的公共冷却时间从1.5秒缩短至最低

0.75秒，并缩短你许多技能的冷却时间，包括

[[spell:259489]].

:::details 常见问题 生存 猎人有急速上限吗？
生存没有任何急速上限或阈值。

:::

**暴击** 提高你所有法术和技能的

暴击几率。暴击默认造成双倍伤害，但有若干

效果可以提高你的暴击伤害，使暴击更加强力。

**全能** 提高你造成的所有伤害和治疗，并降低

你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个上限，超过该上限后，每点获得的提升

将开始减少；这些被称为收益递减点。一旦你

达到了

这些数值，属性将逐渐变得不那么有价值，并可能落后于

其他选择。当前的阈值如下：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 更新了80级的属性递减收益数值。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 已针对3月25日的在线修正进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月21日：** 更新了属性优先级。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的生存 猎人可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在一个插槽中使用[[item:240983]]，并在

其他所有插槽中使用[[item:240898]]。虽然还有其他

选择适用于

你的海精宝石以及稀有宝石，但这两者将为你提供

最高的

各类内容中的DPS收益。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>双手武器：[[item:243733]]。</li>&#10;<li>双持：两把武器都使用[[item:243733]]。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

消耗品能在有限时间内大幅提升你角色的实力

时间内大幅提升你的角色实力。任何

当你挑战高难度内容时，建议

你给自己加上

合剂、食物、药水和武器油的增益。

3.1.

#### 合剂

最好的药水通常是

[[item:241322]]。话虽如此，最好将合剂视为

另一件容易更换的装备，根据你的具体装备

情况，4种副属性合剂中的任何一种都可能是最优的。要真正做到极致优化

这一点，你需要进行模拟。

3.2.

#### 药水

只有一种输出药水值得使用。

- [[item:241288]]是默认选择，提供大量
  
  
  
  
  你最高的副属性，持续30秒，应与你的爆发技能同步使用。
  
  
  
  
  请注意，该药水的效果取决于你最好的属性（精通）在
  
  
  
  
  你使用药水时是否确实是最高的。如果你在配装过程中的
  
  
  
  
  这一阶段并非如此，请改用[[item:241308]]。它也受益于
  
  
  
  
  你最低的属性（通常是全能）接近于0，因为
  
  
  
  
  这意味着你不会受到任何削减。

确保携带[[item:271883]]。

它有5分钟冷却时间，能恢复你大部分生命值；在万不得已时使用，

尽可能优先使用你的个人减伤技能。

3.3.

#### 食物增益

你能吃到的最佳食物来自

[[item:255846]]或[[item:255845]]盛宴。最佳

非盛宴食物是[[item:242747]]。"丰盛的"这部分很重要，因为

这种食物在死亡后仍然保留，我们强烈建议学习

[烹饪](<https://www.icy-veins.com/wow/professions-cooking>) 来轻松制作你自己的丰盛食物，因为它无法

可在拍卖行直接购买。

3.4.

#### 强化符文

在至暗之夜中，最佳强化符文是

[[item:259085]]，但每次使用可能非常昂贵

开怪或

每个地下城都使用可能非常昂贵，除非你财力雄厚，否则请节约使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月29日：** 将武器附魔更新为哈什之仪。
- **2026年8月24日：** 更新了武器附魔为狂暴者的愤怒。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 修复了附魔提示链接并更新了消耗品备注。
- **2026年6月16日：** 澄清了武器附魔的选择。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月23日：** 更新了戒指附魔。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月27日：** 添加了关于双持附魔的信息。
- **2026年3月19日：** 更新为推荐吸血附魔而非闪避。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月4日：** 添加了关于《燃烧的远征》中一些旧磨刀石/平衡石在至暗之夜中达到最优的信息。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月9日：** 更新了腐蚀附魔部分。
- **2025年4月21日：** 添加了腐蚀附魔信息。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月7日：** 更新了武器附魔。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月15日：** 更新了武器附魔。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年10月5日：** 扩充了武器附魔选择的内容。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月22日：** 更新了推荐的腿部附魔，因为发现微光护甲片并不像之前认为的那样提供耐力。
- **2023年5月12日：** 更新了推荐的食物和腿部附魔。
- **2023年5月2日：** 更新了推荐的武器符文/临时附魔。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月23日：** 根据一系列热修复再次更新了推荐的宝石。
- **2023年3月23日：** 在模拟更新以及发现新的强力组合后，更新了推荐的宝石。
- **2023年3月21日：** 根据3月21日的增益更新了黑曜石指环信息。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了推荐的药剂。
- **2022年12月11日：** 更新了最佳药水/药剂的推荐和描述。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的生存 猎人挑战大秘境地下城的提示和建议。

1.

### 生存 猎人在至暗之夜第2赛季的大秘境中的表现

在本指南中，我们将讨论如何在大秘境中充分利用你的 猎人

大秘境地下城，包括如何最佳地配置你的角色、你的

循环可能会变化，以及在最

优方式使用技能的提示和技巧。

生存 猎人在大秘境中是一个可靠的全能型专精，能够

在一个专精中同时提供可靠的AoE和单体输出，而不需要过多改变其

输出循环。它拥有可靠的实用性，以及最好的生存能力（名副其实！）在所有

（顾名思义！）属于猎人专精。

如果你不熟悉大秘境及其相关的一般机制，你可以

你可以在下方我们专门的大秘境页面上阅读更多相关内容。

1.

### 最佳大秘境天赋配置

生存在所有内容中都玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖有

对优先目标的伤害略高一些，但 哨兵 在

大波次拉怪的同时更耐打且更易上手。我们认为这笔交易对

几乎所有人都值得，我们也为偏好该玩法的玩家提供了猎群领袖的替代方案

玩法。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵大秘境天赋

2.1.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵大秘境天赋构建——生存 猎人

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) 哨兵用于大秘境的构筑。它

基于模拟真实大秘境地下城中的条件，并观察

不仅是什么能打出最高DPS，而是什么能真正更快地通关地下城

在队伍中。有些构筑能造成更高的AoE伤害，但它们损失的单体伤害都多于

它们在AoE方面获得的收益，反之亦然。

2.2.

#### 生存猎人功能性天赋考量

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMWgBmxoxyAYGw2MzMzMjZbeAAAAAAAzYmZGbzYMjZYZMNDAAAwAAjllZGLYmZ8AjxAwM2AjxMzmBA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-ABCDEFGHIKKLZaeiIZiqq6yGXn3Xo4I-AAAA-BEIMQYcAJRZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖 大秘境天赋

2.3.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖大秘境天赋构建——生存 猎人

这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) 猎群领袖的大秘境构建。它

基于模拟真实大秘境地下城中的条件，并观察

不仅是什么能打出最高DPS，而是什么能真正更快地通关地下城

在队伍中。有些构筑能造成更高的AoE伤害，但它们损失的单体伤害都多于

它们在AoE方面获得的收益，反之亦然。

2.4.

#### 生存猎人功能性天赋考量

- 你的'灵活'天赋点，按我们建议的可舍弃顺序为：
  
  
  
  
  可牺牲的：
  
  
  
  
  - [[spell:459983]]
  - [[spell:459517]]只在某些地下城中有用，
    
    
    
    
    在其他地下城中则毫无价值。

**请务必使用'导出天赋'按钮，将最佳

配置直接导入到你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "C8PAAAAAAAAAAAAAAAAAAAAAAMgxMGWgFYGGawiZmZmZGLDAAAAAAzYmZGbzYMjZYZMNDAAAwAgZssMzYhZmhHYMGwMbAYMmZ2MAA"
}
```
:::

:::details 来源计算器编码
```
#:D-ABCEEFGHIKXYYaaceiikqYZhpt19BKKSquG-BCDEFGHIJLYcceiIZiqq6im2GX3Xo4I-AAAA-ACEGIUw4ARZhpJ-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断

[[spell:187707]]是你的"打断"技能，也是你在

大秘境中最重要的功能性技能，用于打断敌人施法以造福团队，尤其是

坦克。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 压制
```

这个宏会打断你的焦点目标（如果你有焦点目标），鼠标指向目标（如果你有

焦点目标），以及你的当前目标（如果两者都没有）。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用

**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面能清晰显示焦点目标的施法，这样你

才能随时在冷却完毕时打断它，或与团队的其他成员配合

打断。

3.2.

#### 眩晕与"打断"

[[spell:19577]] 是你第二重要的功能性技能，是你的

单体“打断”，用于阻止那些通常无法被正常打断的施法。我们

建议以与你的斥责相同的方式使用此宏，使用相同的宏

（当然，将胁迫替换为斥责）。通过天赋，它

也可以是一个群体打断。

[[spell:109248]] 可以在混乱时刻用来拯救你的坦克，通过

帮助他们风筝怪物并拉开距离。

[[spell:187650]] 可以作为额外的打断技能，与

[[spell:19577]] 一起使用，但它的弹道飞行时间较慢，你需要

靠近目标才能在大多数可眩晕的施法结束前命中它。

### 其他功能

3.3.

#### 其他功能

[[spell:5384]] 不仅可以用来脱离仇恨，还可以

使你身上的某些施法和引导失效。在某些情况下，这些机制只会

重新选择团队中的其他人，但偶尔该机制会被

完全消除，并带来巨大收益。如果你注意到有施法或效果作用于你，尝试

用 [[spell:5384]] 应对！点出 [[spell:459517]] 天赋后，它还会

移除你身上所有的中毒和疾病效果。

[[spell:19801]] 可以驱散敌方目标身上有益的激怒和魔法效果

，这经常很有用，而我们的构筑已经点出了

[[spell:459983]]。在某些地下城中，你可能会选择更换

你的默认天赋来获取 [[spell:109248]] 或 [[spell:199483]]。

[[spell:187698]] 可以通过减速怪物来帮助你的坦克风筝。

如果你的坦克死亡，条件反射般地放下一个 焦油陷阱 是很好的，因为它能

让其他人有更好的机会风筝并存活下来。

1.

### 应对词缀

本节包含 猎人 专属的应对各种词缀的技巧

大秘境的。

### 词缀：升腾

4.1.

#### 昇蛇词缀应对——生存 猎人

对密集的球体群使用 [[spell:19577]] 等群体控制技能

宝珠尽可能多地击破。你可以使用[[spell:187650]]和

你的打断技能来处理剩下的单个宝珠。

### 词缀：虚缚

4.2.

#### 虚空束缚词缀应对——生存 猎人

这里没什么特别要说的。利用你扎实的切换目标

能力，尽快集火击杀 虚空大使。

### 词缀：脉冲星

4.3.

#### 脉冲星词缀应对——生存 猎人

开启[[spell:186257]]并四处冲刺，尽可能快地收集

尽可能多的宝珠。

### 词缀：吞噬

4.4.

#### 吞噬词缀应对——生存 猎人

[[spell:5384]] 的中毒/疾病驱散（通过 [[spell:459517]]）是

驱散移除 [[spell:440313]] 所需类型效果的来源。你也可以

用 [[spell:109304]] 治疗掉它，但那会消耗一个GCD。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月11日：** 更新了猎群领袖的天赋构建，将一点从横扫之矛移入锋刃。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年7月16日：** 阐明了实用技能和词缀备注。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 修复了哨兵大秘境构建中的错误。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月1日：** 猎群领袖大秘境构建更新。
- **2026年2月26日：** 更新了大秘境天赋推荐。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月12日：** 更新了大秘境构建推荐。
- **2026年2月10日：** 针对即将到来的12.0.1改动更新了天赋构筑。
- **2026年2月4日：** 哨兵大秘境构建的小幅更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月4日：** 在模拟工具修复后，将推荐的大秘境英雄天赋更新为哨兵。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025年3月18日：** 更新了推荐的大秘境模拟路线/大秘境模拟Pastebin。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月13日：** 更新了大秘境的哨兵构建，以修正无情掠夺者此前模拟结果偏低的问题。
- **2024年11月6日：** 添加了大秘境构建，并添加了关于适合新手的天赋替换建议。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月27日：** 更新了阿拉卡拉提示。
- **2024年9月13日：** 更新并澄清了一些提示。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年5月12日：** 在大秘境配点中默认加入了 误导。
- **2024年5月11日：** 新增了关于如何在高层大秘境中利用坦克饰品和美化装备存活的章节。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年5月3日：** 新增了奈萨鲁斯副本中 Chargath 的攻略提示。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月29日：** 将默认大秘境配点更新为无冷却流配点。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年12月18日：** 新增了史诗钥石地下城攻略提示。
- **2023年11月28日：** 更新了史诗钥石地下城天赋配点。
- **2023 年 11 月 12 日：** 新增了T30史诗钥石地下城配点。
- **2023年11月9日：** 对史诗钥石地下城配点进行了小幅调整，以提升单体输出能力。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月23日：** 根据最新的APL改动，更新了史诗钥石地下城配点。
- **2023年6月2日：** 对天赋配点进行了重大更新，包括强化/暴虐周的推荐内容，以及天赋配点本身。
- **2023年5月27日：** 为 生存 大秘境新增了独立的强化周、暴虐周和冷却流配点。
- **2023年5月13日：** 更新了推荐的AoE/史诗钥石地下城天赋。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 更新了推荐的大秘境配点。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月29日：** 更新了温西尔大秘境配点天赋。
- **2022年10月26日：** 新增了一个基瑞安配点，该配点在大量AoE的大秘境中表现更优。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到许多实用的宏和插件，让你在《魔兽世界》12.1.5补丁中使用你的生存 猎人时更加轻松。

1.

### 最佳宏

1.1.

#### 猎人通用宏

1.1.1.

##### TankMD 插件 + 宏

这会自动为团队中的坦克施放误导，无需

选择目标或设置焦点或任何其他操作。安装插件，设置好宏，你就

万事大吉了。

1. 获取 [TankMD
   
   
   
   
   插件]([https://www.curseforge.com/wow/addons/tankmd](<https://www.curseforge.com/wow/addons/tankmd>)).
2. 设置这个宏：

#### TankMD 误导 宏

```wow-macro
#showtooltip 误导

/click TankMDButton1
```

1.1.2.

##### 焦点鼠标指向宏

严肃大秘境必备的宏。将你的鼠标指向目标设置为

焦点目标，并为其标记绿色标记（除非它已被

其他标记标记过），这样你就可以用下面的宏打断它。

#### 焦点鼠标指向宏

```wow-macro
/focus [@mouseover,harm,exists,nodead][@target,harm,exists,nodead]

/tm [@mouseover,harm,exists,nodead][@target,harm,exists,nodead] 4
```

1.1.3.

##### “自动打断/眩晕”宏

这个宏会自动对随机的正在施法的目标使用你的打断

，无需选择目标、鼠标指向或焦点。我们喜欢它用于

较低层/不协调的钥匙。看到施法？按下宏。第三个宏做同样的

事情，不过是针对 [[spell:19577]]。

#### 自动打断宏（反制射击）

```wow-macro
#showtooltip 反制射击

/cast [@focus,exists,nodead,harm] 反制射击

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 反制射击

/target focus

/clearfocus

/startattack
```

#### 自动打断宏（口袭）

```wow-macro
#showtooltip 压制

/cast [@focus,exists,nodead,harm] 压制

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 压制

/target focus

/clearfocus

/startattack
```

#### 自动眩晕宏（胁迫）

```wow-macro
#showtooltip 

/cast [@focus,exists,nodead,harm] 胁迫

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast 胁迫

/target focus

/clearfocus

/startattack
```

请注意，如果你设置了焦点目标，它会优先打断焦点目标。如果你希望

它优先选择鼠标悬停目标，只需将"focus"替换为"mouseover"即可。

1.1.4.

##### 逃脱停止施法宏

这个宏会打断像[[spell:56641]]这样的施法并强制执行

[[spell:781]]，但它不会取消像[[spell:257044]]或

[[spell:1261193]]这样你可以在中途[[spell:781]]的引导法术。

#### 逃脱停止施法宏

```wow-macro
#showtooltip 逃脱

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/use 逃脱
```

1.1.5.

##### 地面目标技能的光标宏

这些宏跳过了使用时的绿色目标圈放置步骤

我们将其用于从[[spell:1543]]到陷阱的所有技能

再到[[spell:109248]]和[[spell:260243]]。

只需将光标放在你想要的位置即可。

#### 光标宏（冰冻陷阱）

```wow-macro
#showtooltip

/use [@cursor]冰冻陷阱
```

#### 光标宏（焦油陷阱）

```wow-macro
#showtooltip

/use [@cursor]焦油陷阱
```

#### 光标宏（束缚射击）

```wow-macro
#showtooltip

/use [@cursor]束缚射击
```

#### 光标宏（乱射）

```wow-macro
#showtooltip

/use [@cursor]乱射
```

#### 光标宏（照明弹）

```wow-macro
#showtooltip

/use [@cursor]照明弹
```

1.1.6.

##### 宠物"重置"宏

当你从悬崖跳下且确实希望宠物跟随你时，这个宏非常有用。

宠物被动和宠物跟随可以让宠物更快地"瞬移"到你身边。

[[spell:1850]]这行确保你的宠物尽可能快地回到你身边。

怪物。

#### 宠物"重置"宏

```wow-macro
/petpassive

/petfollow

/use 急奔
```

1.1.7.

##### 宠物嘲讽宏

在大秘境中，有时在强力小怪释放坦克大招之前嘲讽它们很有用，

这可以帮助保住坦克的性命。你需要使用

甲虫、野猪、Carapid（仅野兽控制）、熔火犬（仅野兽控制）、机械、鳞蜥、

可选择页岩兽（仅限野兽控制）或海龟，因为它们拥有50%减伤，其冷却时间为1分钟

50%伤害减免。

#### 宠物嘲讽宏

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][@focus,exists,harm]低吼

/use 鳞墙

/use Harden Carapace

/use Bristle

/use Bulwark

/use Obsidian Skin

/use Defense Matrix

/use Solid Shell

/use Shell Shield
```

1.1.8.

##### 鼠标悬停宁神射击

对鼠标悬停的敌人使用宁神射击，如果没有有效的悬停目标

则对当前目标使用。

#### 鼠标悬停宁神射击

```wow-macro
#showtooltip

/use [@mouseover,exists,harm,nodead][]宁神射击
```

1.1.9.

##### 灵龟守护取消光环宏

默认游戏中你可以再次按下灵龟守护来取消它，但

其中内置了一个"宽限"期。这个宏跳过宽限期，让你

可以立即激活然后取消灵龟守护。如果你是

那种狂按灵龟守护的玩家，请不要使用这个宏，此宏需要你

用一次按键来有意地激活/取消！

#### 灵龟守护取消光环宏

```wow-macro
#showtooltip 灵龟守护

/stopcasting

/stopcasting

/use 灵龟守护

/cancelaura 灵龟守护
```

1.1.10.

##### 鼠标悬停多重射击

主要用于射击，该专精希望对目标使用[[spell:2643]]

目标使用[[spell:257621]]来激活技巧射击，或者

分散其标记。它没有nochanneling条目，因为射击

专精会故意用[[spell:2643]]来截断[[spell:257044]]的末尾。

#### 鼠标悬停多重射击

```wow-macro
#showtooltip 多重射击

/use [@mouseover,exists,harm,nodead][]多重射击

/petattack

/petassist
```

1.2.

#### 生存宏

1.2.1.

##### 自动召唤宠物杀戮命令宏

如果你没有召唤宠物，这个宏会召唤/复活你的宠物，否则

否则只是一个普通的[[spell:259489]]宏。将召唤宠物X

编号

到你默认使用的宠物上。当我们团队中使用嗜血时，我们进去并

修改

宏为嗜血宠物的编号，这样如果我们死在大秘境中并按下杀戮命令，它

就会召唤正确的宠物。省去了思考的麻烦。请注意，复活部分

在你的宠物单位实际不存在时并不100%可靠，这可能发生在

你尝试复活然后取消施法的情况下。因此，你仍然应该有

[[spell:982]]单独绑定。

#### 自动召唤宠物杀戮命令宏

```wow-macro
#showtooltip 杀戮命令

/petassist

/petattack

/cast [@pet,dead] 复活宠物;

/cast [@pet,noexists,mod:shift] 复活宠物; 

/cast [@pet,noexists] 召唤宠物 1;

/cast 杀戮命令
```

1.2.2.

##### 野火炸弹鼠标指向宏

[[spell:259495]]既是目标身后的锥形区域也是围绕目标的圆形区域，

但在分散的AoE场景中，你可能完全依赖锥形区域，

鼠标指向投弹在这里极其有效，可确保最大覆盖范围。

#### 野火炸弹鼠标指向宏

```wow-macro
#showtooltip 野火炸弹

/petattack

/use [@mouseover,harm,nodead,exists][]野火炸弹
```

1.2.3.

##### 鱼叉鼠标指向宏

用于快速位移到特定目标，而不一定

改变你的输出目标。而且感觉非常酷。

#### 鱼叉鼠标指向宏

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][]鱼叉猛刺

/cancelaura Updraft
```

1.

### 最佳插件

2.1.

#### 猎人通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可能值得看看在没有任何额外插件的情况下你能走多远，也许你甚至会享受不必每个补丁都花数小时更新和重新配置界面的感觉。

2.2.

#### 用户界面

2.2.1.

##### EllesmereUI

[EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
是对默认用户界面的完整替换。它极其用户友好，设置和掌握所需时间非常少。它还已经配备了几乎你需要的一切：单位框体、团队框体、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，使你的界面完全按照你想要的样式呈现。EllesmereUI简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松追踪基础减益效果和在战斗中快速选择新目标至关重要。虽然一些界面替换自带姓名板，但它们通常功能有限且偶尔有故障。下面列出了一些不错的替代方案。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是由
[plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发的插件，该作者以众多超级有用的插件闻名，例如
[Auctionator](<https://www.curseforge.com/wow/addons/auctionator>),
[Baganator](<https://www.curseforge.com/wow/addons/baganator>),
[Chattynator](<https://www.curseforge.com/wow/addons/chattynator>)等等。他们现在已经开发了一款非常可定制的姓名板插件，提供了大量关于减益效果、状态颜色、图标、材质等的选项。它绝对值得一看，尤其是如果你因为任何原因在使用Plater时遇到问题的话。

2.5.

#### 伤害统计插件

2.5.1.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.6.

#### 生存猎人专用插件

目前，我们认为没有必要使用额外的插件来玩

生存 猎人的全部潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月25日：** 针对3月25日的更新进行了更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 更新了10月29日的热修复内容。
- **2024年10月22日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 为地心之战第1赛季进行了初步更新。
- **2024年8月22日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已为10.2.5版本进行更新。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年6月13日：** 移除了狂怒之翼下的寻血者宏，因为该错误已修复，不再需要。
- **2023年5月25日：** 为 狂怒之鹰 新增了一个取消光环的寻血者宏。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
