## 专精概览

欢迎阅读我们的 鲜血 死亡骑士 指南，适用于《魔兽世界》12.1.5 补丁。在这里，你将学习如何在团队副本和大秘境中担任 鲜血 死亡骑士 坦克。我们涵盖了从基础到极限优化手法的所有内容，帮助你最大化生存能力。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

鲜血 大秘境资源

[全新！顶级 鲜血 天赋构筑](<https://raider.io/specs/blood-death-knight/talents>)

[顶级 鲜血 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/death-knight/blood>)

[鲜血 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=death-knight--blood>)

[热门 鲜血 队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=death-knight--blood>)

1.

### 鲜血 死亡骑士 概述

鲜血 死亡骑士 是《魔兽世界》中六个可选坦克专精之一，其核心在于精准高效地运用资源，通过[[spell:49998]]以反应式地治疗所承受的大部分伤害。

鲜血 拥有大量冷却技能，包括游戏中最强大的魔法防御冷却技能之一（[[spell:48707]]）、一个无上限的免死天赋（[[spell:114556]]），以及种类繁多且冷却时间极短的防御增益。

本指南专注于 鲜血 死亡骑士的专属内容，通用的坦克策略不在其讨论范围之内。如果你想了解更多关于坦克职责以及如何提升自己，我们建议你阅读我们的 [坦克指南](<https://www.icy-veins.com/wow/tanking-guide>).

表现超出预期

鲜血 目前略微超模，尤其是在群体伤害和顺劈伤害方面，这源于对所有技能的刻意加强，以及一个影响[[spell:434260]]的 [堕落的 鲜血](<https://www.wowhead.com/npc=53889>) 伤害脉冲的意外改动。

我们预计在赛季正式开始后，鲜血 的伤害构成将得到一些直接调整。

在团队副本中是非常稳健的选择。

新的 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 团队副本中有不少战斗非常适合[[spell:49576]]和[[spell:383269]]发挥。加上鲜血近期的伤害加强，以及其独特的功能性工具，几乎可以保证你的团队中至少有一个该专精。

在最高层之前都非常出色

鲜血 的表现很可能与第一赛季几乎相同，即使有天赋改动（例如为[[spell:391398]]增加减伤效果）以及对[[spell:1264405]]的修复。它的问题依旧：没有突出的功能性、没有团队增益、承受伤害的构成难以预测，而且 <em>尤其是</em> 在最高层也是如此。

对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 的加强使其成为一个更具争议性的选择，因为它在群体伤害和单体伤害方面都能输出夸张的伤害，但代价是开怪准备难度远高于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者。我们新的套装四件套效果在这方面有所帮助，但问题基本上与之前相同。

最糟糕的是，针对[[spell:1264405]]的特定修复影响的正是 鲜血 已经很强的时刻：即[[spell:49028]]激活期间。

独特……在关键时刻

鲜血 的功能性在起作用并产生影响时非常出色，但在其他时候则毫无用处。[[spell:48707]]、[[spell:108199]]和[[spell:49576]]都可以被很好地利用，但只有当战斗机制围绕它们设计时才值得关注。

除此之外，[[spell:51052]]已被彻底削弱，现在严格弱于其他职业的许多同类选择，而鲜血同样没有提供任何值得注意的团队增益。

可接受

第二赛季天赋大改和所有属性25%的重新调整对 鲜血 并不完全到位。特别是自动攻击伤害没有得到调整（[[spell:207200]]），而[[spell:374598]]的直接伤害也没有得到调整。这造成了轻微的影响。

除此之外，对核心天赋的加强、对[[spell:1264405]]的修复与加强，以及一套既提供免费资源又提供极高叠加力量增益的套装，在生存方面带来了不错的提升，至少总体上是如此。顶峰天赋仍然是随机的，但至少你现在也可以将[[spell:49028]]视为一个针对不可招架伤害的12%减伤冷却技能。

勉强合格

鲜血 的所有机动性都很容易在职业天赋树上获得，表现为两个“免费”的[[spell:343257]]充能，你还可以通过[[spell:391546]]或[[spell:212552]]进一步增强它们。[[spell:343257]]还兼具击退免疫效果。

不幸的是，也仅此而已。除了这两个循环使用的充能之外，没有任何加速效果。

1.

### 鲜血 死亡骑士 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.5 补丁对 鲜血 死亡骑士没有带来值得注意的改动，除了来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
的一些有趣新物品，以及通过新的地下堡功能——金度之迷宫非常轻松地获取大秘境级装备的能力。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要改动将来自基斯希克斯团队副本的新物品。最值得注意的是一个饰品、一个戒指和一个头盔。此外，你将能够从10月20日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

12.1.5 补丁中 鲜血 死亡骑士 没有改动，但来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 足够强大，能够改变我们在我们的
[装备](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>) 页面上总体和团队副本的装备推荐。我们还列出了一份高价值物品清单，供你将第一个[[item:280562]]花费在其上，以防你对这个系统还不熟悉。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_bloodpresence.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 职业改动

12.1 补丁伴随着针对 鲜血 死亡骑士 专精天赋树的定向改动，以及对[[spell:1264405]]的重大修复、[[spell:391398]]额外4%的伤害减免、
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 更多的直接伤害以及 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 更多的群体伤害（这以通过轻微削弱[[spell:434075]]为代价牺牲了一些单体伤害）。

请务必查看我们专门页面上的相关信息，了解这两者的详细内容 [天赋](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>) 和
[配装](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>) 指南！

2.5.

#### 修复与漏洞

唯一值得注意的修复影响了[[spell:1264405]]，尽管它发生在12.1之前，我们还是将其列在这里。此前，它导致你承受额外伤害；现已修复为正确地降低所受伤害，并加强为每个激活的[[spell:49028]]提供6%的减伤。

目前有两个重大漏洞影响着 鲜血，且都对英雄天赋选择产生了积极影响：

- 暴风雪 本打算将[[spell:434260]]的自动攻击伤害提高1400%，结果却提高了
  **其全部伤害** 1400%。这包括 [堕落的 鲜血](<https://www.wowhead.com/npc=53889>)，而它原本就已经在打出合理的伤害了。

这使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 在群体伤害中更上一层楼，而最近对[[spell:1265855]]的修复则将
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 整体拉低了。

2.6.

#### 天赋改动

以下重要的天赋改动将与12.1一同上线：

- [[spell:391398]]现在使[[spell:77535]]在激活期间还会使你受到的所有伤害降低4%。这不是部分效果。
- [[spell:374747]]已从6%全能改为4%的伤害减免
- [[spell:49028]]的基础招架几率已提高至30%
- 非[[spell:49998]]的小幅续航加强：[[spell:273953]]在激活期间现在提供15%的吸血，[[spell:194662]]的吸血现在使[[spell:55078]]和[[spell:274156]]的治疗转化率提高85%，[[spell:1263781]]的治疗转化率现在为所造成伤害的18%，[[spell:391517]]现在累计[[spell:55078]]伤害的600%。这些效果很可能会抵消敌人25%的生命值和伤害提升。
- [[spell:434157]]从12%额外力量显著降低至10%。这产生了意想不到的积极效果，即进一步降低了[[spell:144758]]的价值。
- [[spell:434075]]现在每层只提供5%的额外[[spell:49998]]伤害，从6%下调。听起来不多，但在[[spell:434152]]中相当于[[spell:49998]]伤害降低了21%。
- 最后——伤害。[[spell:195182]]伤害提高50%，[[spell:206930]]和[[spell:433901]]提高25%，自动攻击伤害提高20%（因此[[spell:207200]]的价值也略高一些）。

在第一赛季中期还发生了一些额外的在线修正和计划中的改动。你可以在下方查看回顾：

2.7.

### 坦克平衡在线修正

作为5月12日每周更新的一部分，一些小的防御性改动被在线修正：

- [[spell:374721]]现在提供40%的额外耐力
- [[spell:1264351]]的持续时间增加至8秒，每个符文的触发几率提高至12.5%
- [[spell:49028]]的基础招架几率提高了5%至25%；这适用于[[spell:1264351]]的触发以及手动施放的[[spell:49028]]
- [[spell:374277]]的治疗加成已恢复至其在 至暗之夜 之前的15%数值

这旨在撤销之前的一些削弱，虽然这些改动总体上是积极的，但提高顶峰[[spell:49028]]的相对强度，加剧了其作为触发效果的可靠性问题。

这些改动在进攻端也并非完全中性。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 因[[spell:1264506]]和[[spell:1264405]]从这些改动中获益略多，同时在[[spell:49028]]期间通常能从复制的法术中获得更多价值。

:::

### 至暗之夜改动概述

2.8.

#### 至暗之夜 对 鲜血 死亡骑士 的改动

至暗之夜 上线为 鲜血 死亡骑士带来了漏洞修复，以及总共10个新的天赋点；职业天赋树上三个，英雄天赋树上三个（这意味着你终于可以全部点出，而不用被迫做出艰难取舍），专精天赋树上剩余四个点数可用于 **巅峰天赋**.

除此之外，对某些技能随意的数值在线修正，相比补丁前对优先级产生了影响：

- [[spell:206930]]获得20%的加强，而[[spell:433901]]却没有获得补偿性加强，这实际上拉低了两个 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 天赋，并削弱了[[spell:434152]]的价值，同时也增强了顶峰天赋和[[spell:458753]]的强度。
- 对[[spell:274156]]直接（非强化）伤害的基础加强，却没有加强与[[spell:55078]]相关的强化伤害，结果就是你永远不会想要强化[[spell:274156]]。干得漂亮，我猜。

顶峰天赋的加入以及对 鲜血 基础技能的最新加强，足以推动 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因重新在单体和稳定三目标顺劈中占据优势。介于其间的目标数量或范围伤害场景中的表现可能不同，因为这完全取决于[[spell:439843]]的可用时机（45秒的窗口，对比下述构筑90秒的窗口：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因).

2.9.

#### 巅峰天赋

鲜血 的顶峰天赋设计很简单。

- 第一个天赋在[[spell:49028]]激活期间，下一次招架必定触发，使你的下一次[[spell:206930]]免费，同时仍然产生符文能量。这受到3秒内在冷却时间的限制
- 第二个节点（2点）根据每个激活的[[spell:49028]]提高你造成的伤害并降低你受到的伤害。
- 最后，终极天赋使你在消耗符文时有10%的几率生成一个[[spell:49028]]。

顶峰天赋的触发是常规的[[spell:49028]]——一次只能存在一个，仅持续六秒，如果你已经有一个[[spell:49028]]激活，其提供的增益持续时间将简单地重新计算为任意一个[[spell:49028]]的最长存续时间。由于同时存在的数量限制，这存在一些注意事项，但这真正只在单体伤害且处于[[spell:2825]]效果下时才适用。

说这令人失望是轻描淡写，尤其是当你考虑到他们为了适应更高的覆盖率，将[[spell:49028]]削弱得多么厉害，而不是真正区分手动施放和顶峰天赋的触发。随着[[spell:49028]]的额外符文能量生成、招架几率和持续时间都为此被砍，很难对此感到乐观。

尽管如此，这就是我们所拥有的，除了[[spell:206930]]偶尔发光以及在群体伤害中稍微延迟[[spell:49028]]以优化第一个节点的激励之外，这些天赋大部分是被动的。

2.10.

#### 英雄天赋改动

两棵英雄天赋树都增加了三个新节点，等你达到90级时，你将能够选择其中每一个。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 失去了[[spell:434143]]在[[spell:49028]]结束时的爆发伤害，但重新设计的[[spell:274156]]带回了一些复杂性，它强制你在[[spell:49028]]结束后施放它，而不是之前。因此，说实话，复杂性基本保持不变。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 在 [[spell:1265855]] 中获得了一层机制复杂度。直接移除 [[spell:343294]] 也在一定程度上帮助移除了某些最笨拙的方面，但没有任何伤害档位数值或相关法术效果针对其直接损失或 [[spell:439843]] 不再触发 [[spell:194844]] 而进行调整。

从数值上来说， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 在关键方面遥遥领先，而开发团队一再选择持续增强 [[spell:206930]] 却不对 [[spell:433901]] 施加同样的增益，只会把 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 推得越来越强，每一次仓促的在线修正都是如此。

2.11.

#### 生存能力

鲜血 失去了以下内容：

- [[spell:374277]] 从 15% 额外治疗削弱为 5% 额外治疗
- [[spell:49998]] 的基础减伤窗口从所受全部伤害的 25% 削弱为 20%
- [[spell:219809]]、[[spell:194844]]、[[spell:49039]] 的伤害减免，[[spell:194679]] 被彻底移除。
- [[spell:49028]] 的持续时间缩短至 12 秒（原为 14 秒），额外招架  
  
  从 35% 降至 20%
- [[spell:377637]] 改为固定的 30 秒冷却时间缩减
- 由于移除了 [[spell:374737]]，[[spell:195181]] 的护甲值减少了 10%
- 彻底且已确认地移除了 [[spell:45902]]（激活 [[spell:49028]] 时每次 [[spell:206930]] 提供的 3 点符文能量加成）

作为对这一大堆技能和效果的交换，它获得了以下内容：

- 来自装备的 35% 额外基础护甲（约等于 [[spell:195181]] 额外护甲的一半）
- 与 11.2 相比，[[spell:195181]] 从力量中获得的护甲总共增加了 12%（已将 [[spell:374737]] 计算在内）。
- [[spell:1264296]]，其位置使其不是必选天赋
- [[spell:1279633]] 位于第二道门下方——换句话说，点数成本高昂
- [[spell:1263743]]，其作用是在你最不需要的时候提供少量额外的符文能量

称这是一次削弱甚至都不足以描述这种毁灭程度。

2.12.

#### 实用技能

唯一值得注意的功能性改动源于专精天赋树布局的调整。[[spell:108199]] 现在与 [[spell:383269]] 同为抉择节点，而在当前布局下，两者中几乎必须投入一点。

这很棒，虽然两者在实际场景中都有用武之地，但你通常会默认选择 [[spell:108199]]。

1.

### 鲜血 死亡骑士 基础玩法

鲜血 死亡骑士 拥有引人入胜的玩法风格，通过 [[spell:49998]] 的自我治疗作为主要的伤害减免手段。由于 [[spell:49998]] 依赖于受限资源（符文能量），巧妙地优化所有产生该资源的方式变得至关重要。鲜血 还拥有全面且高效的防御与进攻工具组，其中包含比其他坦克更多的小型防御冷却技能，旨在应对特定场景。这些技能在战斗中可以按需串联使用，但我们强烈建议尽可能让它们接近冷却完毕就使用。鲜血 死亡骑士 的特点可由以下三点更清晰地概括。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_butcher2.jpg>) **生成并消耗符文能量**
  
  
  
  
  符文能量是你的核心资源。通过消耗符文并最大化 [[spell:206930]] 的使用来生成它，并将其用于 [[spell:49998]]，不要浪费任何一点。即使你处于满血状态，[[spell:77513]] 依然会生效，其伤害同样如此。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_sword_07.jpg>) **循环使用技能冷却**
  
  
  
  
  [[spell:49028]]，以及额外的 [[spell:439843]] 是你的两个主要进攻冷却技能。你应该尽可能让它们接近冷却完毕就使用。除了它们提供的直接伤害外，它们还会带来许多重要的进攻和防御增益效果！
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_deathwing_bloodcorruption_earth.jpg>) **管理增益与减益效果**
  
  
  
  
  保持 [[spell:195181]] 高于 5 层，在 [[spell:273946]] 超过 5 层之前记得按下 [[spell:49998]]，当 [[spell:81136]] 触发时或需要顺劈 4 个以上目标时按下 [[spell:43265]]。

综合来看，只要管理得当，该专精在当前全部内容中都行之有效。本质上，只要你能扛住一击，之后你就会变得更强。

1.

### 如何为 鲜血 死亡骑士 配装

虽然我们始终建议你自行使用模拟工具以获得理想结果，但我们确实提供了一个专门的 鲜血 配装页面。我们目前涵盖了第二赛季装备的推荐，以便在 至暗之夜 终局内容发布时有一个良好的开端。在你获取了一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了至高毒石的使用信息。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 添加了基斯提克斯、迷宫，并注明目前 鲜血 尚未有任何改动。
- **2026年8月21日（本页）：** 针对回响狂怒修复进行调整
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 更新至 12.1 补丁。由于部分美化效果无法测试，BiS 列表部分为占位内容。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 移除了狂热（它未获得增强，且仅在第一赛季早期的单体环境中表现良好），添加了 12.1 版本的新治疗药水。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 更新了 12.1 补丁的所有配装方案。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 更新至 12.1 补丁上线。
- **2026年6月19日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 装备更新——暂时移除 死亡使者 列表。
- **2026年6月19日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 非常小的符文锻造目标数量调整。
- **2026年6月19日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 全能属性变更。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月21日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 细化/澄清额外奖励掷骰。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了虚空核心及其优先级。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为 12.0.5 版本以及亵渎的改动准备了配装方案。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 更新了 12.0.5 版本的亵渎。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 添加了 12.0.5 补丁关于鲜血、虚空核心和额外奖励掷骰的改动。
- **2026年3月24日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 从消耗品中移除了茶类。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 添加了传家宝信息和升级通用指南。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 更新至第一赛季，包括 BiS 列表和饰品列表
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 非常小的表述调整。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对第1赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 澄清冷却时间。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** PvP 天赋和吞噬改动。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 添加了一个关于套装的小提示。
- **2026年3月16日（本页面）：** 已调整以考虑 3 月 17 日的平衡性调整。
- **2026年3月11日（本页）：** 更新至赛季上线。
- **2026年3月4日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 澄清了屠杀。
- **2026年3月4日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 澄清了屠杀。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为 至暗之夜 的上线做准备。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了美化、饰品、装备以及关于 至暗之夜 的信息。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 新的宏格式。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 添加了附魔、消耗品、合剂和药水。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 至暗之夜 团本前上线的改动。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 添加了巅峰信息。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 添加了巅峰天赋
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 添加了巅峰天赋及其影响。
- **2026年2月26日（本页）：** 为 至暗之夜 的上线做准备。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 更新了 至暗之夜 预补丁的配装方案。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 更改了所有物品等级、套装信息和几个饰品。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 为 至暗之夜 添加了几个插件推荐。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 为预补丁做好准备。将所有附魔换为速度，为升级做准备。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 针对 至暗之夜 的小幅编辑。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 为预补丁做好准备。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 至暗之夜 预补丁的初步整理。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 更新至 至暗之夜 预补丁。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 为 至暗之夜 预补丁做好准备。
- **2026年2月10日（本页面）：** 为 至暗之夜 预补丁做准备。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为11.2.7补丁更新。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 暂时在此处添加模拟常见问题解答作为占位内容。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 为11.2.7补丁更新。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 为11.2.7补丁更新。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 小幅更新，将常见问题解答内容包含到页面中。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为11.2.7补丁更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 为11.2.7补丁更新。
- **2025年11月30日（本页面）：** 添加了表现标签页，对页面进行了小幅修改。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 重新添加了谜之纸牌筹码，澄清了美化和制作订单，移除了 DISC。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月7日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已调整为假设死亡使者两件套可用。
- **2025年9月1日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 澄清了开关选项。
- **2025年9月1日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 澄清了几个条目。
- **2025年8月20日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 添加了大秘境提示。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 根据在线修正进行更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 更改了配装方案并更新至 11.2 补丁。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 更新至 11.2，包括所有饰品。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 更新至 11.2，移除了 Limb，并注明本页假设无套装。
- **2025年8月4日（本页面）：** 添加了关于 11.2 的信息。
- **2025年6月25日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 热修后更新 D.I.S.C. 推荐。
- **2025年6月25日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为 11.2 补丁进行了审阅；删除了所有肢体相关引用并调整了天赋配装。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为11.1.7补丁更新。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加 11.1.7 补丁的 D.I.S.C. 推荐。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 为11.1.7补丁更新。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 添加战斗助手章节，并列出其存在的最大问题。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 添加了战斗助手模式信息及其预估的性能损失。
- **2025年6月15日（本页）：** 添加了关于 11.1.7 和战斗助手的信息。
- **2025 年 5 月 19 日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 略微简化了 萨莱因 起手式。
- **2025年5月13日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 优化了代币推荐。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 移除了恭喜章节。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 添加了惊魂幻象附魔，并简述其与之前并不完全相同。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 大秘境提示。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 添加了 11.1.5 补丁的信息。
- **2025 年 3 月 25 日（[解放安德迈页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** 添加了额外的防御提示和史诗难度提示。
- **2025年3月18日（[解放安德迈页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** 添加了加里维克斯提示。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 为 11.1 补丁做准备。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 为 11.1 澄清了第二套起手式。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 为 11.1 补丁做准备。
- **2025年2月24日（本页面）：** 为 11.1 进行了重做。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了塞雷斯的指环。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 添加了塞雷斯的指环。
- **2024年10月30日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 添加了循环章节。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 提示已上线！
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 重做了整个萨莱因的起手式和循环，澄清了所有内容，添加了死亡打击灵魂收割，并澄清了页面其余部分。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 添加了所有萨莱因配装，并为 11.0.5 清理了页面。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已更新以考虑 死亡使者 在 11.0.5 的整体重做。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 已更新以添加 死亡使者 和 萨莱因 在 11.0.5 的改动。
- **2024年9月16日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** 更新了安苏雷克的提示。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为地心之战第一赛季更新，添加了所有毕业列表和所有饰品评级。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** 页面已创建。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 正在为地心之战第一赛季上线做准备。除副本提示外，所有内容均已就位。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 删除了传奇斧头推荐，因为新的模拟显示其在装等上存在 DPS 损失。
- **2024年8月27日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 添加了说明，大秘境天赋同样适用于地下堡。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为地心之战上线更新，为你的 80 级旅程添加了英雄天赋的新内容。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为地心之战上线更新，附带赛季前毕业装备。请留意第一赛季的更新！
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 为地心之战上线进行了审核。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已为地心之战上线更新，带来新的消耗品和附魔！
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已为地心之战上线更新。为不同的英雄天赋树分别列出了属性优先级。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为地心之战上线更新，添加了英雄天赋的内容。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已为地心之战上线更新。添加了英雄天赋。配装已更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已为地心之战上线更新。添加了英雄天赋。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已为地心之战上线更新。添加了新天赋并更新了循环。
- **2024年8月21日（本页）：** 已针对《地心之战》上线进行更新。
- **2024年8月19日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已为地心之战上线更新天赋树。
- **2024年7月24日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/blood-death-knight-mists-of-pandaria-remix-guide>)):** 修正天赋代码。
- **2024年7月24日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 修正天赋代码。
- **2024年7月24日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 修正天赋代码。
- **2024年7月24日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 修正天赋代码。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/blood-death-knight-mists-of-pandaria-remix-guide>)):** 更新了幻化天赋和循环。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为地心之战前夕进行了重做。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 删除了铸币章节以备战前夕。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对地心之战前夕进行调整，并更新了昨日的热修内容。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为地心之战做准备，包括影响前夕的循环改动（尚无英雄天赋）。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已为地心之战做准备。添加了新天赋，更改了配装。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 为预补丁做好准备。
- **2024年7月23日（本页面）：** 添加了免责声明，并为地心之战前夕进行了重做。
- **2024 年 7 月 18 日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 为地心之战前夕调整了配装。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/blood-death-knight-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/blood-death-knight-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 略微更新天赋。对新手来说，鲜血 tap 可能有点太复杂了。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为第四赛季做准备。包含带有所有第四赛季装备、咒语、饰品、铸币等的新毕业列表。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 澄清了开钥前、开怪前、波次间提示，词缀提示，整理了配装并添加了路线提示。已为第四赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 已为 10.2.6 补丁更新。在没有改动的同时预告第二赛季套装。
- **2024年3月18日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 删除了关于天赋在 15 级解锁的过时引用。
- **2024年3月18日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 与属性页面同步。已为 10.2.6 补丁更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 澄清毕业列表，从大秘境/团队副本表格中移除制造装备。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 添加了一条简短说明，解释 10.2.5 的改动。
- **2024 年 1 月 3 日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 移除平衡性免责声明，添加菲莱克拉斯。
- **2024 年 1 月 3 日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 全面改版，所有内容改用复选框，并添加了如何正确使用菲莱克拉斯的说明。
- **2023 年 11 月 27 日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加穆佐恩的崛起/迦拉克隆的陨落的单独链接。
- **2023年11月9日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 删除了 鲜血 中关于 鲜血 的过时引用。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 孢子披风被移除了，所以我们更新了相关内容。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为 10.2 做准备，所有饰品已加入，所有装备套装已加入。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 添加了头盔附魔，将治疗药水更换为 10.2 版本。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已为 10.2 做准备。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 替换了一处第二赛季的引用。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.2版本进行更新
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 调整了配装顺序，将灵魂收割设为团队副本中的默认选择。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 进行了细微的清晰度调整。
- **2023年11月6日（本页）：** 10.2 改动。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 新格式——以及 10.1.7 的一些澄清和毕业列表！
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 澄清了属性。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 10.1.7 的新模板。同时添加了灵魂收割配装。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 为 10.1.7 进行了清理。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了关于 10.1.5 大型地下城和开放世界饰品的信息。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 添加了 10.1.5 信息，解释了灵魂收割和专精光环相关的内容。
- **2023年5月24日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了时光漫游章节。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为第二赛季上线更新。将玛瑙印记章节移至页面底部（它对伤害依然有效！）
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 更新并澄清了玛瑙印记章节，添加了 10.1 腰带附魔，澄清了宝石，澄清了药水和药剂。已为 10.1 做好准备。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 移除了雷鸣，添加了关于新词缀的信息，以及 鲜血 无法以任何方式协助应对它们。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 优化了天赋和循环法术描述。
- **2023年5月1日（本页）：** 为10.1补丁进行了复查。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 澄清了 控制亡灵 及其在第二赛季中的使用。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/blood-death-knight-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 添加了玛瑙印记并澄清了其在内容中的使用。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 添加了玛瑙印记并澄清了 10.0.7 的相关信息。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 澄清了天赋。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 澄清了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月3日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 理清了碎骨打击与抚慰之触的区别。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 修复了天赋树显示错误天赋选择顺序的问题。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 为所有选项添加了最高等级括号。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为第一赛季上线更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代第一赛季上线更新。由于套装效果，添加了一个非常小的循环改动。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已为大秘境的首次发布做准备。深入、扩展的法术信息将在上线后跟进。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/blood-death-knight-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/blood-death-knight-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/blood-death-knight-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022 年 4 月 10 日（[9.2版本分析](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-2-changes-analysis>)):** 已更新以考虑热修，添加了关于传说、新传说、哈尔东德鲁斯和墓碑的信息。
- **2022 年 2 月 12 日（[9.2版本分析](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-2-changes-analysis>)):** 已根据当前测试服数据进行调整，澄清了一些要点。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-1-changes-analysis>)):** 补充了关于AoE上限解除的信息，并澄清了9.1.5版本信息的介绍部分。
- **2021年7月18日（[9.1 补丁分析](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-1-changes-analysis>)):** 移除了PTR相关内容；更新了关于索利塔尔和织梦者的信息。
- **2021年4月29日（[9.1 补丁分析](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-1-changes-analysis>)):** 添加了初始内容。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年12月20日（[永恒宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** 更新了精华选择。
- **2019年7月23日（[永恒宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** 补充了第1周的史诗难度信息。
- **2019年7月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** 进一步更新了职业提示。
- **2019年7月11日（[永恒宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** 补充了额外信息和最新的精华推荐。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月21日（[风暴熔渣页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月22日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 更新了介绍部分的措辞。
- **2019年1月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-battle-of-dazar-alor-raid-guide>)):** 为第2赛季创建了攻略。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 更新了关于腐臭的噬灭、维克提斯、祖尔、米斯拉克斯和戈霍恩的推荐。
- **2018年9月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 更新了对多个首领的推荐。
- **2018年9月6日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 更新了MOTHER和腐臭的噬灭的推荐。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 添加了奥迪尔首领推荐。
- **2018年8月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 更新了艾泽里特特质和装备推荐。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页中，你可以找到我们的鲜血死亡骑士逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[死亡骑士升级指南](<https://www.icy-veins.com/wow/death-knight-leveling-guide>).

1.

### 鲜血死亡骑士 至暗之夜练级指南

鲜血死亡骑士凭借其坦克定位以及专精中内置的相当强大的自我续航能力，在练级方面表现出色。练级时你可以轻松拉取整个区域的怪物，并依靠[[spell:55078]]和[[spell:49998]]毫不费力地维持生存。

厌倦了刷怪？组队查找器中坦克的排队是瞬时的！

1.1.

#### 升级装备选择

升级时，你应该始终选择物品等级最高的那件战利品。

你的目标显然是尽可能快地穿越各个区域和等级，而实现这一目标的最佳方式是在不耽误正事的前提下获得尽可能好的装备。

传家宝是练级时获取额外属性的特别强力来源。它们提供的套装效果对坦克来说尤其值得注意，特别是如果你在战斗中升级的话。我们已在专属的传家宝指南中记录了所有信息。5件套套装效果才是真正的力量所在，但让你的双倍休息经验发挥更大作用也非常棒！

如果你不确定，或者想要一份简短的装备清单，以下是解锁6件套套装效果影响最大的传家宝；我们精选了这份清单，因为它们不需要任何声望或其他解锁机制即可获得。别忘了升级它们！

<table>&#10;<thead>&#10;<tr>&#10;<th>部位</th>&#10;<th>传家宝</th>&#10;</tr>&#10;</thead>&#10;<tbody>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:122263]]</td>&#10;</tr>&#10;<tr>&#10;<td>项链</td>&#10;<td>[[item:122668]]</td>&#10;</tr>&#10;<tr>&#10;<td>披风</td>&#10;<td>[[item:122266]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:122388]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:122387]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:122264]]</td>&#10;</tr>&#10;</tbody>&#10;</table>

[[item:105691]]是你所能装备的最佳传家宝武器，但[[item:122349]]也相差不远。

1.2.

#### 至暗之夜升级实用消耗品

我们建议在至暗之夜中练级角色之前囤积以下物品，以简化练级过程，因为它们能提供相当可观的收益：

- [[spell:1246966]]的用法与[[spell:58984]]类似，可用于脱离战斗，在收集完所需物品后高效地退出遭遇或区域时尤为有用。处于潜行状态时你可以立即上坐骑。
- 我们建议至少购买一组[[item:225592]]。这种食物提供的速度加成在练级时特别有价值。
- 如果你不介意使用战斗药水，可以多准备几组[[item:221874]]。
- 将你的符文熔铸更换为[[spell:326977]]。击杀敌人时提供的速度加成累积起来能节省相当可观的时间。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

2.1.

#### 升级用战争模式天赋

在开启战争模式练级时，你可以获得三个额外的PVP天赋。它们的效果对开放世界中的敌人同样有效，虽然其中大多数效果平平，但有几个可以 <em>显著</em> 加快你的练级过程。我们在下方突出了它们。

- [[spell:203173]]使你能够经常（50%的覆盖率）将一名敌人与附近的两个敌对目标锁链在一起。被锁链期间，对一名敌人造成的伤害会部分复制到另外两个目标身上。这实际上奖励你拉取多于一个目标（无论如何你都应该这样做，你是个坦克），使你的有效伤害提高30%。
- [[spell:199720]]使敌人的最大生命值每2秒降低3%，最多降低15%。
- [[spell:207018]]为一个目标提供3-15%的伤害加成，由你的自动攻击刷新。在选择了另外两个之后，这是我们能获得的最不差的选项。

1.

### 升级循环

作为鲜血死亡骑士，基础循环基于此优先级。我们根据你获得它们的等级来显示/隐藏元素；请使用页面最顶部的滑块选择你当前的等级。

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–10：**在10级之前，如果你是传统种族，你的[[spell:206930]]将被其通用替代技能[[spell:316239]]取代。

1. 在你打算战斗的地点使用[[spell:43265]]，当站在其中为你施加的增益效果消失时刷新它。不要被它的视觉效果所迷惑，因为[[spell:316916]]会使其中的增益效果持续时间延长四秒。
2. 如果你的生命值较低或符能超过75点，使用[[spell:49998]]。
3. 如果附近有敌人没有你的[[spell:55078]]疾病，或者你即将拥有2层[[spell:50842]]层数，使用[[spell:50842]]。
4. **等级 71–90：**如果[[spell:439843]]可用，将其施放在任何附近的敌人身上。
5. **等级 75–90：**通过施放[[spell:195182]]来消耗[[spell:441378]]层数。
6. **等级 27–90：**使用[[spell:49028]]，冷却好就用。
7. 如果你的[[spell:195181]]即将到期，使用[[spell:195182]]（如果你不在近战范围内则使用[[spell:195292]]）。
8. 如果你的[[spell:195181]]层数为6层或更少，使用[[spell:195182]]。
9. 如果你拥有2个或更多符文，使用[[spell:206930]]。
10. 使用[[spell:50842]]。
11.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了传家宝信息和升级通用指南。
- **2026年2月26日：** 为 至暗之夜 的上线做准备。
- **2026年2月10日：** 更新了 至暗之夜 预补丁的配装方案。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 更改了配装方案并更新至 11.2 补丁。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 移除了恭喜章节。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024 年 10 月 30 日：** 添加了循环章节。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为地心之战上线更新，为你的 80 级旅程添加了英雄天赋的新内容。
- **2024年7月23日：** 为地心之战前夕进行了重做。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 略微更新天赋。对新手来说，鲜血 tap 可能有点太复杂了。
- **2024年3月18日：** 删除了关于天赋在 15 级解锁的过时引用。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月9日：** 删除了 鲜血 中关于 鲜血 的过时引用。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 为所有选项添加了最高等级括号。
- **2022年12月11日：** 修复了天赋树显示错误天赋选择顺序的问题。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩鲜血死亡骑士，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 鲜血死亡骑士基础指南

本页面面向刚接触游戏或该职业的玩家、不打算参与史诗难度团队副本的玩家，或是只想用更简单直接的方式进行专精游玩、而不想被大量细节和需要考虑的主动技能所淹没的玩家。鲜血可以归结为三个简单的概念：

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_butcher2.jpg>) **生成并消耗符文能量**
  
  
  
  
  符文能量是你的核心资源。通过消耗符文并最大化 [[spell:206930]] 的使用来生成它，并将其用于 [[spell:49998]]，不要浪费任何一点。即使你处于满血状态，[[spell:77513]] 依然会生效，其伤害同样如此。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_sword_07.jpg>) **循环使用技能冷却**
  
  
  
  
  [[spell:49028]]，以及额外的 [[spell:439843]] 是你的两个主要进攻冷却技能。你应该尽可能让它们接近冷却完毕就使用。除了它们提供的直接伤害外，它们还会带来许多重要的进攻和防御增益效果！
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_deathwing_bloodcorruption_earth.jpg>) **管理增益与减益效果**
  
  
  
  
  保持 [[spell:195181]] 高于 5 层，在 [[spell:273946]] 超过 5 层之前记得按下 [[spell:49998]]，当 [[spell:81136]] 触发时或需要顺劈 4 个以上目标时按下 [[spell:43265]]。

1.

### 至暗之夜版本鲜血死亡骑士新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者天赋

2.1.

#### 鲜血死亡骑士新手天赋

以下配装旨在提供尽可能简单的输出循环；它以牺牲部分伤害输出为代价，提供了更便捷的选择，所有这些都是为了让鲜血死亡骑士的上手过程更加顺畅。

从技术上讲，这也是鲜血死亡骑士可以使用的核心配装之一，并且通常适用于所有内容。此配装与本指南中其他地方展示的实际配装之间的主要区别在于移除了一个主动技能：[[spell:274156]]。

我们向所有内容中的新手推荐此配置，因为其他选择将包括基于不太可能适用于新手的标准的非常具体的游戏调整。

使用计算器上的'导出天赋'功能，轻松将配置复制到游戏中。

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

### 鲜血死亡骑士基础循环

2.2.

#### 鲜血死亡骑士基础循环

作为鲜血死亡骑士，基础循环基于此优先级。它包含了单体和范围伤害的推荐。一如既往，深入循环页面上有更多信息！

1. 在你打算战斗的地点使用[[spell:43265]]，当站在其中为你施加的增益效果消失时刷新它。不要被它的视觉效果所迷惑，因为[[spell:316916]]会使其中的增益效果持续时间延长四秒。
2. 如果你的生命值较低或符能超过75点，使用[[spell:49998]]。
3. 如果附近有敌人没有你的[[spell:55078]]疾病、你有[[spell:1265790]]触发效果、或者你即将拥有2层[[spell:50842]]充能，则使用[[spell:50842]]。
4. **等级 71–80：**如果[[spell:439843]]可用，将其施放在任何附近的敌人身上。
5. **等级 75–80：**通过施放[[spell:195182]]来消耗[[spell:441378]]层数。
6. **等级 27–80：**使用[[spell:49028]]，冷却好就用。
7. 如果你的[[spell:195181]]即将到期，使用[[spell:195182]]（如果你不在近战范围内则使用[[spell:195292]]）。
8. 如果你的[[spell:195181]]层数为6层或更少，使用[[spell:195182]]。
9. 如果你拥有2个或更多符文，使用[[spell:206930]]。
10. 使用[[spell:50842]]。

2.2.1.

##### 巅峰天赋： ![Dance of Midnight Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_bladedance.jpg>) 至暗之夜之舞

鲜血的顶点天赋提供了一个触发效果：当你在[[spell:49028]]激活时招架攻击后，可以降低[[spell:206930]]的消耗并大幅提升其伤害；以及在你消耗符文时有10%的几率生成一个[[spell:49028]]。

总体而言，鲜血的顶点天赋几乎完全是被动的。它们带来的唯一真正的优先级变化是，在范围伤害战斗中一旦触发[[spell:1264506]]就立即消耗，因为其内置冷却时间足够短，可能会导致触发效果被覆盖。

由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者是本页的默认选择，关于你当前是否有硬读的[[spell:49028]]激活的大多数复杂情况变得不那么相关，这也使这整套四个天赋简化为“当[[spell:206930]]发光时按下它”。

2.2.2.

##### 第2赛季套装

第2赛季套装， **阴森墓穴骑士的哀歌**，会非常轻微地改变你的输出循环。当你叠满10层[[spell:1310372]]时，你应该通过施放[[spell:195182]]来消耗它们。当 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因，你特别想要这样做 **之前**
[[spell:49028]]，如果可能的话。

### 鲜血死亡骑士防御法术

2.3.

#### 鲜血死亡骑士主动减伤与冷却技能

你有两个主动减伤技能需要用来保命，不过单纯地运用上述优先级就能在很大程度上确保你在这样做。

[[spell:49998]]是你保持自身存活的主要手段，只要你能从其提供的治疗中受益就应该使用它，尤其是在承受高伤害之后（因为其治疗量基于前5秒内承受的伤害量）。

[[spell:195181]]（由你的[[spell:195182]]施加）应始终保持在5层以上。

除了主动减伤技能外，你还必须根据需要使用你的防御性冷却技能：

- [[spell:48707]]可在5秒内吸收相当于你最大生命值30%的魔法伤害，应用来减免魔法伤害并产生符文能量。
- [[spell:55233]]在10秒内将你的最大生命值和所受治疗量提高30%。应在预期承受大量伤害时主动使用，或在生命值低下、面临死亡危险时作为应急使用。
- [[spell:48792]]使你受到的所有伤害降低30%，持续8秒。它应当主要在你预判会承受高额伤害时主动使用，例如应对特定首领技能。
- [[spell:49039]]使用后在10秒内提供可观的生命汲取。虽然其影响力远不及之前的资料片，但它不占用公共冷却时间且不消耗资源——尽可能接近冷却完毕就使用它。
- [[spell:49028]]使你的招架几率提高20%，同时显著提高你的伤害输出和资源生成。你应该在开怪时使用，然后通常一可用就立刻使用，因为它兼具资源生成冷却技能的功能，同时还提供5层[[spell:195181]]充能。

要更好地了解上述技能以及更多技能的工作原理，你可以查看我们的法术总结指南。

### 鲜血 死亡骑士属性优先级

2.4.

#### 鲜血 死亡骑士的属性优先级

除了饰品和珠宝外，优先考虑物品等级而非副属性分配。如果你使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者。有关本页所呈现内容的更多信息，请查看我们的主页面
[属性优先级页面](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>).

力量

暴击

精通

全能

急速

在某些情况下，这种通用的配装建议会有所欠缺。这只会发生在可以通过其他方式减少机制的遭遇战中，例如装备带有 **闪避** 的物品。

### 暴风雪战斗助手

2.5.

#### 鲜血 死亡骑士战斗助手可行性

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 一键循环模式是一种降级，但还不足以成为避免使用它的理由。

尽管为 至暗之夜 所做的改动 <em>稍低的</em> 优于其历史上的同类技能，以及 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 又进一步有所帮助，但它在进攻和防御方面仍然远远落后。

这个新版本也会施放 <em>一些</em> 冷却技能——它会尝试将 [[spell:49028]] 作为最高优先级之一来施放，连同 [[spell:439843]]，但会颠倒它们的优先级。

尽管如此，它是可行的，而且确实能做 <em>一些</em> 出正确的事：它会在危险时反应性地施放 [[spell:49998]]，这是一个令人欣慰的景象。因此，虽然我们不能向资深玩家推荐它，但我们现在至少可以在升级过程中推荐它。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了一个关于套装的小提示。
- **2026年2月26日：** 添加了巅峰天赋及其影响。
- **2026年2月10日：** 为 至暗之夜 预补丁做好准备。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月7日：** 已调整为假设死亡使者两件套可用。
- **2025年8月4日：** 更新至 11.2，移除了 Limb，并注明本页假设无套装。
- **2025年6月15日：** 添加了战斗助手模式信息及其预估的性能损失。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 为 11.1 补丁做准备。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已为地心之战上线更新。添加了新天赋并更新了循环。
- **2024年7月24日：** 修正天赋代码。
- **2024年7月23日：** 为预补丁做好准备。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 针对10.2.6补丁进行了审查。
- **2024年3月18日：** 与属性页面同步。已为 10.2.6 补丁更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 进行了细微的清晰度调整。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 优化了天赋和循环法术描述。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到《魔兽世界》12.1.5补丁中你的 鲜血 死亡骑士 的最佳天赋。我们还为团队副本或大秘境等各类内容提供了默认天赋构建。如果你开启了战争模式进行游戏，我们也为你提供了PvP天赋的建议。

1.

### 鲜血 死亡骑士 的最佳 至暗之夜 天赋

至暗之夜 第二赛季为 鲜血 死亡骑士带来了一些小的变动。在单体目标方面，由于影响 [[spell:1265855]] 的一个漏洞，目前，两者 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 和
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 不相上下。一旦有第二个目标进入战斗的时间长于 [[spell:439843]] 引爆所需的时间， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 就开始占据主导地位。在防御方面，对 [[spell:434033]] 的增益也缩小了两个英雄天赋之间的差距。

- **单体目标——** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 和
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 各以自己的方式闪耀。这很可能会改变，但就目前而言，根据你的装备和战斗场景，任何一个都可能胜出。
- **范围输出——** 如果AoE是持续性的，或者集中在战斗中的1:30间隔点，
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 就会闪耀。如果AoE是间歇性的，其时机就很重要：它是否大致在 [[spell:439843]] 可用的时候？如果是，
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 就有可能缩小差距。
- **大秘境——** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 造成 **荒谬的**
  伤害，因为你是坦克，可以围绕你的1:30 [[spell:434152]] 窗口来优化你的路线和拉怪模式。

我们大致推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 作为本层级一个合理的默认选择，因为真正的单体目标战斗非常少。随着团队副本的开放，我们将微调推荐，并根据每场战斗提供额外的冷却计划和建议。

对于大秘境，选择变得更加不确定： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 具有明显的进攻优势，虽然由于新套装，拉怪前的准备压力有所减轻，但仍然存在。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 仍然更简单，但在AoE和优先目标伤害方面落后。

**快速导入代码**:

:::talents 鲜血 单体目标 - 萨莱因
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMDAMzMzAAAYgBmxiGLLAWGwGgZMDAAYmBwA"
}
```
:::

:::talents 鲜血 大秘境 - 萨莱因
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmxMGAAAAwMmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::talents 鲜血 探宝 - 死亡使者
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmZmxAAAAAmxMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

萨莱因

团队副本

推荐

√

秘境+

每周大秘境钥匙

高层大秘境

死亡使者

入门级构建

新手友好

团队副本构建

大秘境/探宝构建

每周大秘境钥匙

高层大秘境

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 团队副本构建

专精树上有两个灵活点：[[spell:458753]] 和 [[spell:1264235]]。由于
[剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 大部分战斗遭遇为 <em>非</em> 单体目标，我们选择这套天赋作为合理的默认方案。如果需要，你可以将 [[spell:458753]] 换成 [[spell:274156]]，或将 [[spell:1264235]] 换成 [[spell:195679]] 以应对纯单体目标。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 大秘境构建

我们的大秘境构建点出了 [[spell:391517]] 和 [[spell:1264235]]，并将剩余的灵活点投入 [[spell:458753]]。

在 [[spell:391517]] 中投入的点纯粹是为了方便，可以将其投入到 [[spell:1263781]] 中，在爆发期间为每个目标造成额外约400%的攻击强度伤害。这发生在 [[spell:49028]] 的中段，因此它提供的治疗价值相对较低。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 新手友好构建

我们选择的入门级天赋构筑是以下构筑的简化版本
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 的简化版本，避开了所有它能避免的主动技能。

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 团队副本构建

这个构建是一个合理的团队副本默认方案，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者.

### 天赋方案 1-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 探宝和大秘境构建

从根本上说， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 存在一个核心问题：虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 能够充分利用，因为其技能体系增强了 [[spell:49998]] 和 [[spell:206930]]，但 [[spell:55078]] 在整个测试服期间都未被改动，[[spell:441378]] 的AoE伤害部分也是如此。最糟糕的是，[[spell:434260]] 目前由于一个非预期的漏洞，造成的伤害远超应有水平。

然而，情况并非全然悲观；虽然AoE伤害的差距 <em>非常</em> 是显著的，而且 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 再次提供了显著更多的优先目标伤害， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 保留了其易用性。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::details 来源计算器编码
```
#6D-TVVXYZ+CMMeko2CFVBEWYgERWko015diigA-efgHHZdiQRUVXbEKLPDAEaCJLNSYcQA-AAAA-JgIhCTDQgwgxhF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmxMGAAAAwMmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::details 来源计算器编码
```
#6D-TVVXYZ+CMMeko2CFVBEWYgERWko015diigA-efgHHZdiQRUVXbEKLPDAEaCJLDMSYcA-AAAA-JgIhCTDQgwgxhF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAIyKTQCZcEMI3aA-AAAA-GQAUIOCM2wsIsA-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmZmxAAAAAmxMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAIyKTCZcEMI3aCA-AAAA-GQAUIOCM2wsIsA-
```

:::

### 天赋方案 0-1

如果你想获得更多的防御价值，可以将 [[spell:317610]] 换成 [[spell:206974]]，将 [[spell:458753]] 换成 [[spell:317133]]。

:::talents 鲜血 - 防御型 萨莱因
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmxMGAAAAwMmZmZmZ8AzYAAzMzMzAAAYgBmxiGLLAWGwGgZYAAAzMwwA"
}
```
:::

### 天赋方案 1-1

专精树上有两个灵活点：[[spell:458753]] 和 [[spell:1264235]]。由于
[剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 大部分战斗遭遇为 <em>非</em> 单体目标，我们选择这套天赋作为默认方案。如果需要，你可以将 [[spell:458753]] 换成 [[spell:274156]]，或将 [[spell:1264235]] 换成 [[spell:195679]] 以应对纯单体目标。

### 天赋方案 1-2

对于这个特定构建，我们已经将 [[spell:1263781]] 换成了 [[spell:391517]]。你已经在承受输出上的损失了——为什么不默认将这个次要的填充点投入到比作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因?

如果你想获得更多的防御价值，可以将 [[spell:317610]] 换成 [[spell:206974]]，将 [[spell:458753]] 换成 [[spell:317133]]。

:::talents 鲜血 - 防御型 死亡使者
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmZmxAAAAAmxMzMzMjHYGDAYmZmZGAAgxsNwAWAbDTghFAzwAAwMDAMA"
}
```
:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万世典籍在 至暗之夜 的 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)中引入。该系统为你提供总共五项额外的力量，旨在提供直接伤害、实用性和纯粹属性的混合效果。

我们的建议是，对于游戏中的大多数内容，选择以下选项。你可以根据特定内容自由切换每一行中的选项。例如，第四行节点可能会根据你当时的特定装备情况而变化：

- 节点1：[[spell:1279599]]
- 节点 2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点 4：[[spell:1279609]]
- 节点5：[[spell:1279614]]

1.

### 巅峰天赋： ![Dance of Midnight Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_bladedance.jpg>) 至暗之夜之舞

鲜血 的巅峰天赋将一个主题概念与两个额外的触发效果结合起来，赋予你（随机）生成额外 [[spell:49028]] 的能力。这在消耗符文时自然发生。

从主题上讲，这很巧妙；但在实践中，它导致 [[spell:49028]] 被削弱以适应这种更高的正常运作时间，并且在用户体验方面存在明显问题，因为这些 [[spell:49028]] 副本不会触发实际的 [[spell:49028]] 天赋，也不会以任何方式与它们互动。

尽管如此，你可以预期至少有一个 [[spell:49028]] 有50%的综合正常运作时间，而初始巅峰天赋节点——[[spell:1264506]]——会让你偶尔强化你的下一个 [[spell:206930]]。

1.

### 英雄天赋

从71级开始，英雄天赋让 鲜血 死亡骑士通过选择两个互斥选项中的一个来塑造和聚焦他们的游戏玩法。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 都为专精添加了一个全新的机制，但它们以截然不同的方式做到这一点。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 的设计围绕一个维护型增益——[[spell:433925]]。它显著增强你的急速、精通和 [[spell:49998]] 伤害，并且只能通过施放 [[spell:433901]] 来叠加——这是 [[spell:49998]] 的一个罕见触发效果。

当你 **施放** [[spell:49028]] 时，[[spell:433901]] 在其整个持续时间内持续可用，并且 [[spell:433925]] 的所有益处都会变为三倍。

核心游戏循环分为两个阶段：每90秒在 [[spell:49028]] 期间有一个极端的爆发窗口，以及在它们之间你通过触发效果来维持 [[spell:433925]] 层数的时期。它在循环上要求很高，但回报是显著的。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 添加了一个全新的技能：[[spell:439843]]。它造成少量的初始伤害，并累计目标身上随后的每一层 <em>效果</em> 暗影伤害；当它完成叠加（或过期）时，印记引爆，对目标造成极高额的伤害。

这个英雄天赋最显眼和最令人难忘的特征是它的终极天赋，[[spell:441378]]。这是对 [[spell:195182]] 一个非常华丽、非常有效的补充，这个触发效果使其造成非常大量的额外伤害并降低其消耗。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 追求的是简单——它将整个 [[spell:195181]] 管理的琐事变得微不足道，并让你在此过程中获得大量益处。

1.

### PvP天赋（战争模式）

在升级过程中，玩家可以选择进入“战争模式”。启用战争模式提供以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以最大化你的升级效率和满级后的奖励。然而，你将使自己成为开放世界PvP的目标，并且在升级或进行世界任务时存在被“偷袭”的可能性。

在下面，我们将对最适合用于升级以及进行单人或小队PvE内容的PvP天赋进行排名。

1. [[spell:203173]] 在拉3个或更多敌人时是一个不错的伤害提升，不过30秒的冷却时间使其无法用于每一次拉怪。
2. [[spell:199642]] 和 [[spell:207018]] 在组队完成开放世界内容时可能非常强大，但在单人游戏中价值非常有限。

[[spell:77606]]、[[spell:199720]]、[[spell:47476]] 和 [[spell:202731]] 在PvE内容中价值都非常有限。

[[spell:233412]] 大幅缩短 [[spell:49028]] 的持续时间和冷却时间。在开放世界内容中玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 时，它可以帮助维持 [[spell:433925]]，但我们通常建议避免使用这个天赋。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了 12.1 补丁的所有配装方案。
- **2026年6月19日：** 全能属性变更。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 为 12.0.5 版本以及亵渎的改动准备了配装方案。
- **2026年3月16日：** PvP 天赋和吞噬改动。
- **2026年3月4日：** 澄清了屠杀。
- **2026年2月26日：** 添加了巅峰信息。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月1日：** 澄清了几个条目。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月25日：** 为 11.2 补丁进行了审阅；删除了所有肢体相关引用并调整了天赋配装。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 添加了所有萨莱因配装，并为 11.0.5 清理了页面。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月27日：** 添加了说明，大秘境天赋同样适用于地下堡。
- **2024年8月21日：** 已为地心之战上线更新。添加了英雄天赋。配装已更新。
- **2024年7月24日：** 修正天赋代码。
- **2024年7月23日：** 已为地心之战做准备。添加了新天赋，更改了配装。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 调整了配装顺序，将灵魂收割设为团队副本中的默认选择。
- **2023年9月4日：** 10.1.7 的新模板。同时添加了灵魂收割配装。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 澄清了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何根据你将要承受的伤害类型来优化你的 鲜血 死亡骑士 的循环。我们还提供了关于冷却技能、触发效果等的进阶章节，以最大化你的生存能力和DPS。我们的所有内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 鲜血 死亡骑士 游戏玩法和循环指南

一般来说，你在每场战斗中的目标是使用你的资源（符文和符文能量）来制造仇恨并保持存活。鲜血 死亡骑士 是一个非常典型的 builder-spender 专精，触发效果和互动数量有限，并且有多种方式会让你因为失去冷静而使用了错误的技能受到惩罚。

:::details 常见问题：我应该以防御还是进攻的方式游戏？
这是大多数人在坦克职责中会问的主要问题。基本答案是，除了使用减伤技能之外，你的大部分技能库并没有防御与进攻之间的取舍。无论你是选择进攻性还是防御性打法，你仍然需要保持 [[spell:195181]] 维持在5层以上，仍然需要最优地消耗符文和符文能量，并且仍然要确保不让 [[spell:50842]] 的层数溢出。

主要区别在于减伤技能的使用。在实践中，我们建议玩家在进入一场新战斗时，确保规划好自己的减伤技能，以便 <em>不要死</em>。这可以通过查看其他已经攻略过该Boss的玩家的日志来轻松完成（或者你自己盲目地直接进本！），然后规划出你将为哪个机制使用哪些减伤技能。

如果需要更多情境性的防御手段，最常见的调整如下所列：

1. 如果你的减伤规划仍然需要比你现在拥有的更多，评估一下你是否可以分配一个团队外部减伤技能给它（比如圣骑士的 [[spell:6940]]）。如果不行，或者如果敌人的攻击频率太高或伤害太重，超出了你当前技能组的应对能力，你可以考虑使用一个防御性饰品来填补你减伤规划中的缺口，或者让一名小队成员提供外部减伤。不要忘记 [[spell:51052]] —— 大多数 鲜血 死亡骑士都忘了，它对你来说在技术上是一个15%的魔法伤害减免效果，而不仅仅是给你的团队的！
2. 如果你仍然不足，饰品可以派上用场，特别是使用后提供吸收效果的饰品，例如[[item:252421@JAAEAAgsSYgM]]。你应该留意那些效果对你的情况直接有用的饰品，以填补剩余的空缺。
3. 因为有效生命值（EHP）仍然不足？你可以 <em>在非常特定的情况下</em> 通过更换你的首饰装备（戒指、项链）为全能加成更高的替代品，来改变一些战斗规划的结果。 **这是最后的手段**，而且当你这样做时，如果这些替换导致物品等级下降，那么所有的收益都会被抵消。

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者

单体目标

AOE/大秘境，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因

单体目标

AOE/大秘境，

主动天赋

被动天赋

[[spell:1263824]]

[[spell:469870]]

[[spell:436687]]

### 起手式

[[spell:43265]]

[[spell:195292]]

[[spell:195181]]

[[spell:55078]]

**适用条件：死亡使者（启用）。**

[[spell:439843]]

[[spell:46585]]

**适用条件：死亡使者（启用）。**

[[spell:49028]]

**适用条件：萨莱因（启用）。**

[[spell:49028]]

[[spell:46585]]

**适用条件：死亡使者（启用）。**

[[spell:50842]]

[[spell:55078]]

**适用条件：萨莱因（启用）。**

[[spell:50842]]

[[spell:55078]]

**适用条件：死亡使者（启用）。**

[[spell:195182]]

[[spell:441378]]

1.1.

#### 起手式

1. 在你预计会进行战斗的位置预先放置 [[spell:43265]]。 **执行此操作时不要选中任何敌人作为目标** （如果 [[spell:1264351]] 触发，它将自动生成并吸引你当前目标的仇恨）
2. 在开怪前，对你的目标施放 [[spell:195292]]。这会为你提供两层 [[spell:195181]] 充能，并立即施加 [[spell:55078]]。
3. **适用条件：死亡使者（启用）。** 施放 [[spell:439843]] 和 [[spell:46585]]。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者，你可以将这两个技能绑定在一个宏里。
4. **适用条件：死亡使者（启用）。** 施放 [[spell:49028]]。
5. **适用条件：萨莱因（启用）。** 施放 [[spell:49028]] 和 [[spell:46585]]。
6. **适用条件：死亡使者（启用）。** 施放 [[spell:50842]] 来刷新 [[spell:55078]] 的持续时间，并施加来自你符文之刃的两份疾病复制体。
7. **适用条件：萨莱因（启用）。** 施放 [[spell:50842]] 来刷新 [[spell:55078]] 的持续时间，并施加来自你符文之刃的两份疾病复制体。这些与 [[spell:434143]] 没有交互作用。
8. **适用条件：死亡使者（启用）。** 施放 [[spell:195182]] 来消耗 [[spell:49028]] 给你的 [[spell:441378]] 充能。
9. **适用条件：死亡使者（启用）。** 继续施放 [[spell:49998]]、[[spell:50842]] 和 [[spell:206930]]，直到 [[spell:49028]] 消失。
10. **适用条件：萨莱因（启用）。** 继续按照以下优先级施放，直到 [[spell:434152]] 消失：
    
    
    
    
    - 如果你需要治疗或者你的符文能量超过75点，则施放 [[spell:49998]]
    - [[spell:50842]] **当且仅当** 你将用它命中7个以上目标并且你有一个 [[spell:1265790]] 触发时
    - 否则施放 [[spell:433901]]

### 循环

**适用条件：萨莱因（启用）；死亡使者（未启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 对你的 [[spell:49028]] 窗口有着非常严格的强调——无论是它即将冷却完毕时，还是它激活期间。我们选择将循环拆分为两个不同的优先级，以界定并阐明其区别。

**适用条件：萨莱因（启用）；死亡使者（未启用）。** 1.2.

#### **适用条件：萨莱因（启用）；死亡使者（未启用）。** 在 萨莱因 之赐期间

**适用条件：萨莱因（启用）；死亡使者（未启用）。** [[spell:434152]] 会极大地强化 [[spell:49998]] 并永久解锁 [[spell:433901]]。因此，除非你能在AOE中通过 [[spell:273946]] 在 [[spell:49998]] 上获得大量免费的额外伤害，或者通过 [[spell:434157]] 获得12%的力量增益，否则你的目标是施放 <em>除了</em> 一次 [[spell:50842]] 之外的任何技能，然后连续施放 [[spell:433901]] 和 [[spell:49998]]，直到 [[spell:434152]] 结束。

1. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果你即将死亡、你的符文能量超过70点，或者 [[spell:391477]] 即将消失，则施放 [[spell:49998]]。
2. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 施放 [[spell:50842]] **一次** 在 [[spell:49028]] 期间，如果疾病复制体现在没有在你的目标身上，则施放它来施加疾病复制体，并在用 [[spell:433901]] 延长之前，将 [[spell:55078]] 刷新到其最高可能值。
3. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 在AOE（5个或更多目标）中施放 [[spell:50842]] 以保持其层数不断。
4. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果你有一个 [[spell:81136]] 触发且 [[spell:434157]] 当前未激活，则施放 [[spell:43265]]。
5. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 保持你自己有1层以上 [[spell:266201]] 充能。如果你正确规划了 [[spell:49028]]，这应该是自动完成的；如果你犯了错误，使用 [[spell:195182]]。
6. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 使用 [[spell:433901]] 作为填充技能来消耗符文。

**适用条件：萨莱因（启用）；死亡使者（未启用）。** 1.3.

#### **适用条件：萨莱因（启用）；死亡使者（未启用）。** 在 萨莱因 之赐之外

**适用条件：萨莱因（启用）；死亡使者（未启用）。** 在 [[spell:434152]] 之外，规则要宽松得多。你只需要保持 鲜血 固有的增益效果，保持 [[spell:433925]] 不断，并为你的下一个 [[spell:49028]] 做准备。

1. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果你即将死亡、你的符文能量超过70点，或者 [[spell:391477]] 即将消失，则施放 [[spell:49998]]。
2. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 冷却完毕就施放 [[spell:49028]]。
3. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果你有一个 [[spell:81136]] 触发，或者你正在与4个以上目标战斗且 [[spell:43265]] 的增益当前未激活，则施放 [[spell:43265]]。
4. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果可用，则施放 [[spell:433901]]。
5. **适用条件：萨莱因（启用）；吞噬（启用）；死亡使者（未启用）。** 将 [[spell:274156]] 强化至1级，除非 [[spell:55078]] 的剩余持续时间大于40秒且你当前没有激活 [[spell:1264351]] 触发。
6. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果你有一个 [[spell:1265790]] 触发，则施放 [[spell:50842]]。
7. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 如果 [[spell:195181]] 即将过期，或者你在重新进入敌人的近战范围之前无法够到任何目标，则使用 [[spell:49576]] 或 [[spell:195292]]。
8. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 策略性地使用 [[spell:195182]]：
   
   
   
   
   - 在你拥有5层或更少的 [[spell:195181]] 充能，并且有一个巅峰 [[spell:49028]] 触发激活时使用它
   - 如果你无法等待巅峰触发，无论如何都要使用它。
   
   
   
   
   你应该尽量从 [[spell:1264351]] 触发中获取额外的 [[spell:195181]] 充能，同时避免任何溢出。
9. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 施放 [[spell:50842]] 以保持其层数不断。
10. **适用条件：萨莱因（启用）；死亡使者（未启用）。** 使用 [[spell:206930]] 作为填充技能来消耗符文。你应该始终保持有三个符文在恢复中。

**适用条件：死亡使者（启用）；萨莱因（未启用）。** 1.4.

#### **适用条件：死亡使者（启用）；萨莱因（未启用）。** 循环

**适用条件：死亡使者（启用）；萨莱因（未启用）。** 每90秒，[[spell:439843]] 和 [[spell:49028]] 的冷却时间会对齐。我们提供的起手式和这个循环优先级都假设你按照正确的顺序施放它们（先 [[spell:439843]]，然后 [[spell:49028]]），以避免浪费重复的施放。  

除此之外，循环是一个非常简单的优先级——消耗触发，维持增益，然后享受收益。

1. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 如果你即将死亡、你的符文能量超过70点，或者 [[spell:391477]] 即将消失，则施放 [[spell:49998]]。
2. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 如果你有一个 [[spell:441378]] 触发可用且它即将过期（少于3秒），则施放 [[spell:195182]]。
3. **适用条件：死亡使者（启用）；吞噬（启用）；萨莱因（未启用）。** 当 [[spell:49028]] 不在时，冷却完毕就将 [[spell:1263824]] 强化至1级。
4. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 冷却完毕就施放 [[spell:439843]]。
5. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 冷却完毕就施放 [[spell:49028]]。
6. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 在单体目标上，如果你有一个 [[spell:441378]] 触发可用且 [[spell:49028]] 不在，则施放 [[spell:195182]]。破灭规则
   
   
   
   
   [[spell:441378]]的镰刀不会被[[spell:49028]]复制，它们也不会通过它们施加[[spell:55078]]。在实践中，这意味着在你处于[[spell:49028]]时使用它们 **非** 避免溢出资源归根结底在于一个艰难的平衡：[[spell:206930]]与[[spell:195182]]的即时伤害，以及[[spell:1264405]]的层数，因为它们会强化镰刀的初始命中。
   
   
   
   
   简单的规则集如下：
   
   
   
   
   - 在单体目标上，无论 [[spell:49028]] 是否激活都可以自由使用 [[spell:441378]] 充能，但将它们视为类似 [[spell:50842]] 的低优先级填充技能。
   - 在AOE中，如果可能的话，严格在 [[spell:49028]] 之外使用 [[spell:441378]]
7. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 在AOE中，如果你有一个 [[spell:441378]] 触发可用，则施放 [[spell:195182]]。破灭规则
   
   
   
   
   [[spell:441378]]的镰刀不会被[[spell:49028]]复制，它们也不会通过它们施加[[spell:55078]]。在实践中，这意味着在你处于[[spell:49028]]时使用它们 **非** 避免溢出资源归根结底在于一个艰难的平衡：[[spell:206930]]与[[spell:195182]]的即时伤害，以及[[spell:1264405]]的层数，因为它们会强化镰刀的初始命中。
   
   
   
   
   简单的规则集如下：
   
   
   
   
   - 在单体目标上，无论 [[spell:49028]] 是否激活都可以自由使用 [[spell:441378]] 充能，但将它们视为类似 [[spell:50842]] 的低优先级填充技能。
   - 在AOE中，如果可能的话，严格在 [[spell:49028]] 之外使用 [[spell:441378]]
8. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 如果你有一个 [[spell:1265790]] 触发，则施放 [[spell:50842]]。
9. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 如果 [[spell:195181]] 即将过期，或者你在重新进入敌人的近战范围之前无法够到任何目标，则使用 [[spell:49576]] 或 [[spell:195292]]。
10. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 如果它提供的增益当前不在，则施放 [[spell:43265]]。
11. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 施放 [[spell:50842]] 以防止其层数溢出。
12. **适用条件：死亡使者（启用）；萨莱因（未启用）。** 使用 [[spell:206930]] 作为填充技能来消耗符文。你应该始终保持有三个符文在恢复中。

1.5.

#### 为死神印记做准备

如果你遵循上面概述的循环优先级，只要注意 <em>一个小细节</em>，你就应该能够在最大层数下轻松引爆 [[spell:439843]]。说来有些反直觉，保证层数的最大来源是 [[spell:43265]]，你应该在 [[spell:439843]] 之前预先施放 [[spell:43265]]，如果它还没有在你的目标脚下生效的话。

1.

### 至暗之夜 第2赛季套装

鲜血 第2赛季的套装， **阴森墓穴骑士的哀歌**，增加了两个力量叠加增益，以及一个由玩家驱动的效果来转换第一个——同时在此过程中造成大量的直接AOE伤害。

两件套奖励 [[spell:1296650]]，在你施放 [[spell:49998]] 时为你提供一个叠加的力量增益。这个增益最多叠加10层，每层提供总共0.5%的额外力量。这些层数无限期持续。当你达到10层时，你的下一个 [[spell:195182]] 会消耗所有层数，为你提供持续10秒的10%力量；在这个强化效果激活期间，你仍然可以获得常规的由 [[spell:49998]] 驱动的层数。

四件套奖励 [[spell:1296651]]，在转换 [[spell:1310372]] 层数时锦上添花，使消耗层数的 [[spell:195182]] 额外提供三层 [[spell:195181]] 充能，并对你的目标附近的所有敌人造成大量的AOE伤害。

1.

### 职业与专精机制详解

鲜血 死亡骑士 的游戏玩法中剩下的技能优化已经非常少了，这主要归功于移除了以冷却缩减和额外爆发伤害为中心的额外机制。话虽如此，作为坦克，还有许多额外的游戏机制值得了解。我们在下面详细说明。

### 仇恨

3.1.

#### 仇恨

作为坦克，你最大的职责之一是拉住仇恨并针对其他DPS（以及副坦克，如果有的话）产生威胁值。

3.1.1.

##### 仇恨列表的工作原理

当你与敌人进入战斗的那一刻，你就会被放置在它们的 **仇恨列表**中。这对每个敌人都是独立的，它会统计每个玩家在战斗中产生的威胁值总量。威胁值不会衰减，条目只在死亡时被移除；它们可以被 [[spell:1022]] 之类的免疫效果所掩盖，但这是一种边缘情况。

如果战斗刚刚开始，仇恨列表上的第一个人将获得初始仇恨。从那里开始，敌人需要一个 **10%**
时间差才能将目标切换到8码内的某人，以及
**30%** 如果目标在远处。这意味着如果你有100点“威胁单位”，第二高的威胁条目必须达到110才能超过你。

3.1.2.

##### 威胁值就是伤害

从根本上说，产生威胁值意味着造成伤害，每个敌人会根据击中它们的内容单独统计。这意味着在AOE中，总伤害在很大程度上是一个无关紧要的指标，特别是如果某个专精有一个目标数量上限的法术（对我们来说，[[spell:206930]] 就是最好的例子，这也是为什么作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 打大秘境时，即使 [[spell:49028]] 激活，也经常使用 [[spell:50842]] 的原因）。

所有坦克的职业光环上都有+950%的威胁值倍率。

:::details 那治疗呢？
<em>部分</em> 治疗会被计入威胁值。规则快速而宽松，但一般来说，自我治疗（治疗药水除外）不会被计入威胁值。

如果一次治疗被计入威胁值，它会增加等于治疗量的等量威胁，并均匀分配给你正在交战的每一个敌人。换句话说，如果你在与10个敌人战斗时使用治疗药水恢复100点生命值，每个敌人都会获得相当于10次治疗量的威胁值。

:::

鲜血 死亡骑士也没有任何带有独特威胁加成的技能。这意味着，除了嘲讽窗口期之外，对我们来说，
<em>威胁值就是伤害</em>.

3.1.3.

##### 嘲讽

嘲讽有三个作用：

- 它使敌人锁定在你身上，持续 **6秒**，受递减效果影响。当该减益效果存在于目标身上时，目标 <em>无法</em> 切换目标，并且你会成为其威胁列表上第一名的伪装者。一旦减益效果消失，一切规则恢复正常。
- 它使你达到该敌人威胁列表上第一名实体的 **完全相同的数值** 。如果你自己就是第一名，这显然毫无作用。
- 在减益效果存在于目标身上期间，它使你在该目标上的威胁值产生提高 **800%** 。对同一目标使用越来越多的嘲讽不会叠加此效果，而是将每次后续嘲讽的持续时间减少35%，最低降至1.1秒。

[[spell:49576]]同样具有嘲讽效果，并且还有一个额外的好处：强制移动你的目标（如果目标可以被移动）。这会软打断一些法术，但对首领很少有效。

### 灵界打击和鲜血之盾

3.2.

#### 灵界打击和鲜血之盾

[[spell:49998]]是你最重要的自我治疗技能。它也是你在战斗中常规技能循环的一部分。为了充分利用灵界打击和你的精通（[[spell:77513]]），你不能一有灵界打击就使用它。

灵界打击最直接明显的效果是它能治疗你，所以在你受到伤害后使用它来恢复一些生命值并帮助治疗者总是明智的。要聪明地选择使用灵界打击的时机。由于它取决于你在过去5秒内承受的伤害，所以应该在承受大量伤害后使用。当然，也要避免在不使用灵界打击的情况下符文能量溢出。

请注意，[[spell:77513]]只吸收物理伤害；不要依赖它来减轻一次巨大的魔法攻击。

### 白骨之盾

3.3.

#### 白骨之盾

你的[[spell:195182]]技能会施加3层[[spell:195181]]，而你的[[spell:195292]]技能每次使用时会施加2层[[spell:195181]]，最多可叠加10层。只要你身上至少有1层白骨之盾激活，你的护甲就会提高你力量值的一定百分比，并且在拥有[[spell:374715]]天赋的情况下，你的急速也会提高10%。每次成功对你进行的近战攻击都会消耗一层白骨之盾。白骨之盾的持续时间为30秒，之后层数会直接消失。在正常的首领战中主动坦怪时这不太可能发生，但在没有近战攻击或有长时间空档的战斗中，你应该注意观察你的[[spell:195181]]增益的持续时间。

白骨之盾层数消耗有2.5秒的内置冷却时间。

保持白骨之盾常驻是正确游玩鲜血的关键。急速加成对符文回复至关重要，而伤害减免对生存能力至关重要。此外，如果你拥有[[spell:219786]]天赋，那么在拥有五层或更多白骨之盾层数时，[[spell:49998]]的消耗会减少5点符文能量，这使你能更频繁地使用它。

实际上，你总是需要明智地优先保持高层数的[[spell:195181]]；你应该在白骨之盾层数为七层或更少时使用[[spell:195182]]（除非你需要通过使用[[spell:206930]]来获得额外的符文能量）。鲜血优化的支柱之一就在于设法在白骨之盾管理上花费尽可能少的符文。

### 符文与符文能量

3.4.

#### 符文与符文能量

死亡骑士使用符文和符文能量的双重资源系统。虽然其运作方式相当简单明了，但为了完整性，我们仍在此进行说明。

3.4.1.

##### 符文

你总共有6个符文，默认情况下可用。你的一些技能有符文消耗，每当你使用消耗一个或多个符文的技能时，那些符文会立即开始充能。符文充能所需的确切时间取决于你拥有多少急速。

每当消耗一个符文时，你会获得10点符文能量（下文详述）。

最多可以有3个符文同时处于充能状态。因此，最好让至少3个符文处于冷却状态，以在整场战斗中最大化充能速率。

3.4.2.

##### 符文能量

符文能量是一种类似于怒气的资源，其特点是脱离战斗时会衰减，但在战斗中不会衰减。如上所述，消耗符文每消耗一个符文会产生10点符文能量，这是产生符文能量的主要方式，尽管一些技能也有助于此。你最多可以拥有125点符文能量，如果使用[[spell:326911]]符文锻造，则提高到145点。

1.

### 鲜血 死亡骑士的重要冷却技能

### [[spell:49028]]

4.1.

#### 符文刃舞

在选择[[spell:377668]]的情况下，[[spell:49028]]使你在12秒内获得20%的招架几率。此外，在持续期间，你还获得以下几个好处：

- 使用[[spell:206930]]会使你的符文武器攻击，并额外获得3点符文能量。
- 使用[[spell:195182]]会使你的符文武器叠加[[spell:195181]]，其方式与你自己使用精髓分裂完全相同，使得在符文刃舞期间使用精髓分裂会获得6层额外的[[spell:195181]]层数。避免在[[spell:49028]]期间过多使用[[spell:195182]]，因为使用它实际上会让你达到最大层数。
- 使用[[spell:50842]]会根据每个激活的符文武器，在你的目标身上额外留下一个[[spell:55078]]减益效果。你的符文武器的鲜血疫病减益效果不会直接归于你，也不会治疗你，并且在武器消失后仍然存在。

你的符文武器的攻击造成的伤害大约是你所造成伤害的33%，这使得[[spell:49028]]成为一个强大的DPS冷却技能。在有易伤阶段（首领承受额外伤害）的战斗中，你应该确保你有[[spell:49028]]来配合这些阶段，同时使用某种药水。但是，不要将这个冷却技能积攒太久。

避免为了从招架价值上获得防御收益这一错误的企图，而将[[spell:49028]]留在冷却中超过15秒。[[spell:49028]]主要是一个资源和治疗量冷却技能，因为它会放大你在持续期间的符文能量产生（通过给予你额外的[[spell:195181]]层数，并将从[[spell:206930]]产生的符文能量大致翻倍）。招架部分只是锦上添花，而不是这场戏的主角。

### [[spell:48707]]

4.2.

#### 反魔法护罩

[[spell:48707]]最强大的效果是其防止施加减益效果的能力。如果一个魔法技能会施加减益效果，并且该技能造成的任何伤害都被[[spell:48707]]完全吸收，那么该减益效果就不会被施加。

把握使用[[spell:48707]]的时机至关重要，特别是当你从你打算防护的技能之外的来源承受魔法伤害时。大量的魔法伤害很容易在预定的攻击到来之前就穿透护盾，使你易受减益效果影响。

提高你最大生命值的效果，包括[[spell:55233]]，即使在这些技能消退后也会提高你反魔法护罩的数值。围绕这一点进行规划，可能会决定反魔法护罩是能够完全吸收一次攻击（从而免疫减益效果），还是不能。

[[spell:205727]]几乎在所有方面都能让你更有效地使用[[spell:48707]]，包括缩短冷却时间、增加范围和延长持续时间。

### [[spell:55233]]

4.3.

#### 吸血鬼之血

[[spell:55233]]是你最全面的冷却技能。它使你在10秒内获得30%的额外生命值，并提高你受到的治疗量（来自所有来源，包括自我治疗）30%。它可以被反应性地使用；然而，主动使用它你会获得更多收益，并且你应该有一个具体的计划，明确你要用它来减轻哪些技能。

值得注意的是，这种提高的治疗量可以用来利用某些技能或机制。例如，某些效果即使在吸血鬼之鲜血消退后也会大30%——比如[[spell:48707]]和[[spell:219809]]的护盾。

[[spell:55233]]的一个特殊之处在于，它被特别标记为在激活期间不会提高[[spell:77513]]的上限。

### [[spell:48792]]

4.4.

#### 冰封之韧

[[spell:48792]]是一个直接的减伤冷却技能，持续8秒，使你受到的所有伤害降低30%。一般来说，你应该在即将承受来自预定首领技能的大量伤害时使用它，或者在你其他时候比较脆弱时（因为治疗者够不到你，或者因为你的其他冷却技能不可用）。

[[spell:48792]]还可以解除昏迷效果，并使你在增益持续期间免疫昏迷效果。在对坦克施加昏迷效果的战斗中，你应该考虑是否能将冰封之韧纳入你的冷却计划中，既能减轻威胁性的伤害，又能利用昏迷免疫。

鲜血死亡骑士很难应对那些在计算护盾吸收和自我治疗之前就考虑原始伤害量的技能（考虑到他们数量很少的减伤技能）。那些将你承受的伤害反弹给其他玩家，或者根据你承受多少伤害来决定其效果的技能，对于鲜血死亡骑士来说可能特别难以应对；[[spell:48792]]应该在那些情况下留给那些技能使用。

### [[spell:49039]]

4.5.

#### 巫妖之躯

[[spell:49039]]是我们情境防御工具库中的另一个工具，使你在10秒内获得15%的吸血和对魅惑、恐惧和睡眠效果的完全免疫。它的另一个好处是能够对自己使用[[spell:47541]]，在没有其他目标在范围内、你处于即刻的致命危险、生命药水和治疗石都已用尽且没有任何其他生存希望的情况下，给自己一个基于攻强的廉价治疗——换句话说，实际上永远不会用到。

### [[spell:114556]]

4.6.

#### 炼狱

虽然它本身不是冷却技能，但[[spell:114556]]值得一提，因为它有一些与之相关的怪癖。

首先，它是游戏中唯一一个 <em>完全</em>
没有上限的免死技能。只要你能把自己治疗出免死状态，你就能活下来。显然，难的是把自己治疗出免死状态。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 澄清冷却时间。
- **2026年2月26日：** 至暗之夜 团本前上线的改动。
- **2026年2月10日：** 至暗之夜 预补丁的初步整理。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月1日：** 澄清了开关选项。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加战斗助手章节，并列出其存在的最大问题。
- **2025年5月19日：** 略微简化了 萨莱因 起手式。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 为 11.1 澄清了第二套起手式。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 重做了整个萨莱因的起手式和循环，澄清了所有内容，添加了死亡打击灵魂收割，并澄清了页面其余部分。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为地心之战上线更新，添加了英雄天赋的内容。
- **2024年7月23日：** 已为地心之战做准备，包括影响前夕的循环改动（尚无英雄天赋）。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 针对10.2.6补丁进行了审查。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024年1月3日：** 全面改版，所有内容改用复选框，并添加了如何正确使用菲莱克拉斯的说明。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月3日：** 理清了碎骨打击与抚慰之触的区别。
- **2022年12月11日：** 已为巨龙时代第一赛季上线更新。由于套装效果，添加了一个非常小的循环改动。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到魔兽世界12.1.5版本中鲜血 死亡骑士的最佳装备、饰品和毕业（BiS）物品推荐。从制造物品到关于如何使用你的纹章来升级装备的建议，我们应有尽有！

1.

### 鲜血 死亡骑士毕业装备指南

欢迎来到我们的鲜血 死亡骑士装备页面，适用于至暗之夜第2赛季。查看此页面，了解关于为鲜血 死亡骑士配装你需要知道的一切，包括来自所有来源的毕业装备，团本和大秘境，关于最佳饰品、套装等信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

12.1.5更新带来了[[item:280562]]的发布，允许你将武器、饰品和项链再升级两次，最高达到物品等级340。此外，基斯伊克斯的解封作为团本首领开放，带来了一些非常强大的奇物物品。

### 总体

此列表包含至暗之夜团本中来自任何来源的毕业装备。它作为参考，列出目前玩家可获得的最高性能装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。目前的毕业装备可能与下面不同，因为这将是一个终局配置的示例，并作为你应追求哪些物品的指南。

:::details 常见问题我需要哪些套装部件？
如果你打团本，你的四件套装中的三件将被锁定：你的胸甲和腿甲将来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)，因为它们比竞争对手有10个物品等级的优势，且腿甲带有奇物效果。你的头盔将来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) ，因为它的奇物效果。

最后一件将取决于属性；与之前的赛季不同，催化一件装备会使其保留其属性，使得任何套装组合都成为可能。表现较高的组合之一如下：

- **头部**：[[item:281239]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **护肩**：[[item:239037]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **胸部**：[[item:268222]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **腿部**：[[item:271878]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 常见问题我应该优先选择哪些物品？
[剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 有许多物品以提高的物品等级掉落，或带有非常吸引人的奇物效果。你会想要优先从你的宏伟宝库中获取它们，或者在击杀对应首领时花费虚空核心：

- [[item:268213]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：奇物武器
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：带有额外插槽和非常有趣的奇物效果的奇物项链。
- [[item:270173]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：武器的配套物品，一个物品等级提高的饰品，其效果强大到足以证明值得单独装备。套装只是让它在2个或更多目标时更好。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：更高物品等级的毕业主动使用饰品。
- [[item:271878]]来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：带有10个额外物品等级的奇物腿甲。

:::

12.1版本新增了四种新的美化效果，但只有一种可以测试。另外三种已经遭受了大幅削弱，但由于我们不知道它们的确切行为，而且它们提供的力量水平大致在你对美化效果的预期范围内，请对此列表持保留态度。

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271474@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAAEAAgsSYgM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAAGAAAG24VN2WD]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAAGAAgf1EYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271878@JAAIAAgsScBNMWDG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>脚部</th><td>[[item:273777@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAAGAAge1IYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244017]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:240949]]&#10;&#10;<div>[[item:240906]][[item:251487]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">珠宝加工</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAAEAAwTSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAQAAgtvwgN3WzmlYbNAMCx1glI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[spell:326805]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

此列表包含大秘境中每个部位可获得的最佳物品。它的作用是为你提供一个快速列表，列出易于刷取的装备，以备你在特定部位需要某件物品时使用。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。目前的毕业装备可能与下面不同，因为这将是一个终局配置的示例，并作为你应追求哪些物品的指南。

:::details 常见问题我需要哪些套装部件？
如果你完全通过大秘境配装，以下部件是当前实现你的四件套套装奖励的最强组合之一，使用 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>):

- **头部**：[[item:239050]]，来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **护肩**：[[item:239037]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **胸部**：[[item:239036]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **腿部**：[[item:273776]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

我们建议尽快获得四件套套装奖励。解锁它还使得从所有赛季内容中随机获得额外的催化剂充能成为可能。不要等待理想的部件！

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：掉落种类繁多的战利品，包括三件可能的套装部件、两枚不错的戒指和[[item:158367]]。如果你不打团本，这很可能是你的首选主动使用饰品。
- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落一些散件和两件有价值的饰品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271474@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:251197@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>项链</th><td>[[item:251173@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>腰部</th><td>[[item:159442@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271473@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:273777@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:159459@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:158367@JAAEAAgsSYjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>护腕</th><td>[[item:159409@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>饰品</th><td>[[item:250259@JAAEAAgsSYjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251181@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[spell:326805]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表作为“我的团长需要我提供一个愿望清单，这是愿望清单”的物品列表。如果你专门从剧毒深渊组装最好的装备套装，而不考虑其他来源，这就是你会穿戴的装备。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。目前的毕业装备可能与下面不同，因为这将是一个终局配置的示例，并作为你应追求哪些物品的指南。

实际上，这些物品中有很大一部分由于其奇物效果或大幅提高的物品等级而被锁定。我们建议核实你 <em>能</em> 在9/6史诗难度下获得这些物品（通过从宝库获取或对这些首领进行额外拾取），并据此进行规划。

:::details 常见问题我需要哪些套装部件？
如果你打团本，将有三件被锁定：你的胸甲和腿甲将来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)，因为它们比竞争对手有10个物品等级的优势，且腿甲带有奇物效果。你的头盔将来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) ，因为它的奇物效果。

最后一件将取决于属性；与之前的赛季不同，催化一件装备会使其保留其属性，使得任何套装组合都成为可能。表现较高的组合之一如下：

- **头部**: [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) [[item:281239]]的持续治疗部分来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **护肩**：套装代币来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **胸部**: [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) [[item:268222]]来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **手套**：套装代币来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)

:::

:::details 常见问题我应该优先选择哪些物品？
[剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 有许多物品以提高的物品等级掉落，或带有非常吸引人的奇物效果。你会想要优先从你的宏伟宝库中获取它们，或者在击杀对应首领时花费虚空核心：

- [[item:268213]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：奇物武器
- [[item:268265]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：带有额外插槽和非常有趣的奇物效果的奇物项链。
- [[item:270173]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)：武器的配套物品，一个物品等级提高的饰品，其效果强大到足以证明值得单独装备。套装只是让它在2个或更多目标时更好。
- [[item:270175]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：更高物品等级的毕业主动使用饰品。
- [[item:271878]]来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)：带有10个额外物品等级的奇物腿甲。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271474@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271475@JAAEAAgsSYgM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAAGAAAG24VN2WD]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>护肩</th><td>[[item:271472@JAAGAAgf1EYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271878@JAAIAAgsScBNMWDG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>脚部</th><td>[[item:268260@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271477@JAAGAAge1IYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAAEAAwTSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>护腕</th><td>[[item:268239@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> 位于 <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></span><span>[[spell:326805]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 鲜血 死亡骑士在至暗之夜第2赛季最佳饰品

一般而言，我们建议如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **鲜血 死亡骑士饰品**
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因：[[item:270175]] + [[item:270173]]（有[[item:268213]]时）/[[item:270164]]（无时）/[[item:158367]]（技能冷却期间的AOE补充）
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者：[[item:270175]] + [[item:270173]]（有[[item:268213]]时）/[[item:270164]]（无时）/[[item:158367]]（技能冷却期间的AOE补充）

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>)    点击查看鲜血 死亡骑士饰品排名
<table>&#10;<thead>&#10;<tr>&#10;<th>排名</th>&#10;<th>团队副本</th>&#10;<th>秘境+</th>&#10;</tr>&#10;</thead>&#10;<tbody>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;[[item:270175]] - <span><em>点击查看详情</em></span>&#10;<p>掉落时物品等级加成10级 <strong>和</strong> 与[[spell:439843]]和[[spell:434152]]完美配合。</p>&#10;</li>&#10;<li>&#10;&#10;[[item:158367]] - <span><em>点击查看详情</em></span>&#10;	  得益于[[spell:343257]]，你可以在引导期间移动，使其使用起来比其他职业安全得多。造成 <i>非常</i> 即使在单体目标上也有可观的伤害，而且其伤害完全不会被分摊。&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;[[item:270175]] - <span><em>点击查看详情</em></span>&#10;<p>掉落时物品等级加成10级 <strong>和</strong> 与[[spell:439843]]和[[spell:434152]]完美配合。</p>&#10;</li>&#10;<li>&#10;&#10;[[item:158367]] - <span><em>点击查看详情</em></span>&#10;	  得益于[[spell:343257]]，你可以在引导期间移动，使其使用起来比其他职业安全得多。造成 <i>非常</i> 即使在单体目标上也有可观的伤害，而且其伤害完全不会被分摊。&#10;</li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270163]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]（点出天赋时）</li>&#10;<li>[[item:250226@JAAGAAgsSYgMWVD]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]（点出天赋时）</li>&#10;<li>[[item:250226@JAAGAAgsSYgMWVD]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<i>其他所有饰品</i>&#10;</td>&#10;<td>&#10;<i>其他所有饰品</i>&#10;</td>&#10;</tr>&#10;</tbody>&#10;</table>

2.1.

#### 防御饰品

本赛季理论上你可以为许多直接吸收类饰品找到理由，具体取决于你需要怎样的减伤技能来配合你的减伤规划和战斗模式。以下是一些值得注意的饰品。

- **90s**：[[item:270160]]（40%部分吸收，生命值低于40%时为80%）
- **60s**: [[item:159618]]

我们强烈建议将其视为 **应急方案**，尤其是[[item:159618]]。它们不应被默认使用。

:::

1.

### 虚空核心（额外拾取）

至暗之夜的12.1补丁正式确立了 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)。现在可以通过大宝库获得这些，可用于对你选择的Boss进行额外拾取，并且在你做出选择之前可以看到可能掉落的物品。你获得的物品是随机的，但每件物品只能通过这些额外拾取获得一次。对同一目标进行后续额外拾取将从剩余物品池中随机获得一件，直到没有可用物品。

这些额外拾取可在史诗钥石地下城和团队副本中使用，获得的物品等级等同于在对应难度下从大宝库获得的物品。

3.1.

#### 鲜血 死亡骑士推荐虚空核心使用建议

由于存在大量极其强大的魔铸装备以及来自
[剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)的物品等级提升装备，我们强烈建议将额外拾取用在那里。史诗钥石地下城的额外拾取应被视为 **最后手段**，尤其是因为本赛季没有哪件史诗钥石地下城物品是特别值得追求的。

以下目标应是你的优先选择对象 **英雄难度** （用于Myth 1/6物品）或 **史诗难度**
（用于Myth 9/6物品）上的优先选择：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 用于[[item:268213]]、[[item:270173]]、[[item:268259]]和[[item:268253]]
2. [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 用于[[item:270175]]、[[item:268265]]、[[item:271878]]

:::

如果你不在竞争性史诗团队副本队伍中，我们建议在英雄难度上对完全相同的Boss进行额外拾取。

3.2.

#### 晋升毒液石

随着12.1.5补丁的发布，你现在可以获得[[item:280562]]，允许你将任何武器、项链或饰品升级到340，制造物品升级到338。我们建议按以下顺序升级你的物品：

1. **武器** 首先，特别是如果你从英雄难度额外拾取了[[item:268213]]。
2. **饰品** 其次和第三。
3. **项链** 最后。

你还应优先考虑Myth路线物品而非Hero路线物品，除非你不期望获得你正在升级的物品的Myth路线版本，如果你通过在英雄难度额外拾取获得了盘绕祭坛和乌拉特克的魔铸物品，这一点尤其重要。

1.

### 鲜血 死亡骑士最佳制造物品

至暗之夜第2赛季带来了四种新的镶嵌，即使按最保守的方式解读工具提示，它们也比之前的套装强得多。遗憾的是，由于配方掉落自PTR上无法进入的内容，且无法以其他方式学习，因此它们在PTR上都无法测试。

因此，你应该对以下列表持 **极大怀疑**态度，并预期一旦有人在正式服上获得配方，这些镶嵌就会被削弱。

我们建议以下早期制造选择：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **鲜血早期制造顺序**
**[[item:240949]]**

→

**[[item:237834@JAAQAAgtvwgN3WzmlYbNAMCx1glI]]**

→

**可选制造**

:::

如果你不是史诗 **或** 英雄团队副本玩家，且没有其他方式击败
[盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 以获得其魔铸武器，我们建议使用[[item:273060]]或[[item:245876]]制造一把双手武器，但这应被视为最后手段/小号专用的选择。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

我们建议 **非** 在至暗之夜的前几周使用Myth纹章升级装备。原因在于纹章升级系统需要显著  

更多的纹章才能升级。由于Hero和Myth路线之间有部分重叠，你也可以通过先升级Hero路线装备来节省少量Myth纹章。

因此，如果可能的话，你会有动力策略性地安排升级，并优先制造Myth路线的镶嵌物品。

如果你打算玩多个角色，你也可以策略性地在你的小号上进行游戏和升级物品，通过先在小号上达到物品等级阈值来让主号获得纹章折扣效果。

使用以下优先级列表来指导你的升级。这些按相对强度表示物品栏位优先级：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **鲜血 死亡骑士纹章升级优先级**
**武器**

→

**饰品**

→

**头盔/胸甲/腿甲**

→

**肩部/手套/腰带/靴子**

:::

一旦你将某个栏位升级到一定物品等级，无论原物品在什么路线上，
**将该栏位的其他物品升级到该物品等级就是免费的**。这包括制造物品；这些限制及更多内容详见： [装备升级系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>).

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 添加了至高毒石的使用信息。
- **2026年8月10日：** 更新至 12.1 补丁。由于部分美化效果无法测试，BiS 列表部分为占位内容。
- **2026年6月19日：** 装备更新——暂时移除 死亡使者 列表。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月21日：** 细化/澄清额外奖励掷骰。
- **2026年4月20日：** 添加了虚空核心及其优先级。
- **2026年3月16日：** 更新至第一赛季，包括 BiS 列表和饰品列表
- **2026年2月26日：** 添加了美化、饰品、装备以及关于 至暗之夜 的信息。
- **2026年2月10日：** 更改了所有物品等级、套装信息和几个饰品。
- **2025年11月30日：** 暂时在此处添加模拟常见问题解答作为占位内容。
- **2025 年 10 月 5 日：** 重新添加了谜之纸牌筹码，澄清了美化和制作订单，移除了 DISC。
- **2025年8月16日：** 根据在线修正进行更新。
- **2025年8月4日：** 更新至 11.2，包括所有饰品。
- **2025年6月25日：** 热修后更新 D.I.S.C. 推荐。
- **2025年6月15日：** 添加 11.1.7 补丁的 D.I.S.C. 推荐。
- **2025年5月13日：** 优化了代币推荐。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 添加了塞雷斯的指环。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为地心之战第一赛季更新，添加了所有毕业列表和所有饰品评级。
- **2024年8月27日：** 删除了传奇斧头推荐，因为新的模拟显示其在装等上存在 DPS 损失。
- **2024年8月21日：** 已为地心之战上线更新，附带赛季前毕业装备。请留意第一赛季的更新！
- **2024年7月23日：** 删除了铸币章节以备战前夕。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为第四赛季做准备。包含带有所有第四赛季装备、咒语、饰品、铸币等的新毕业列表。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 澄清毕业列表，从大秘境/团队副本表格中移除制造装备。
- **2024年1月3日：** 移除平衡性免责声明，添加菲莱克拉斯。
- **2023年11月27日：** 添加穆佐恩的崛起/迦拉克隆的陨落的单独链接。
- **2023年11月7日：** 孢子披风被移除了，所以我们更新了相关内容。
- **2023年11月6日：** 已为 10.2 做准备，所有饰品已加入，所有装备套装已加入。
- **2023年9月4日：** 新格式——以及 10.1.7 的一些澄清和毕业列表！
- **2023年7月10日：** 添加了关于 10.1.5 大型地下城和开放世界饰品的信息。
- **2023年5月24日：** 添加了时光漫游章节。
- **2023年5月1日：** 已为第二赛季上线更新。将玛瑙印记章节移至页面底部（它对伤害依然有效！）
- **2023年3月20日：** 添加了玛瑙印记并澄清了其在内容中的使用。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已为第一赛季上线更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的鲜血 死亡骑士的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法相互作用。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 鲜血 死亡骑士属性优先级

虽然属性不会决定你角色的成败，但它们可以影响你的表现并影响战斗的许多方面。鲜血在这方面值得注意，因为两种英雄天赋都需要不同的副属性。

以下内容旨在作为副属性的指南，涵盖防御和进攻两方面。

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因属性优先级

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因时，基本推荐的属性优先级如下：

力量

急速

暴击

精通

全能

主属性是鲜血 死亡骑士的立身之本，因此，在带力量的装备上，物品等级通常优先于任何副属性选择。力量为你提供 **护甲加成** （来自[[spell:195181]]）和少量招架几率加成，此外还能提高你的攻击强度。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因非常偏好急速，直到无增益急速约为30%，这得益于[[spell:433925]]以及[[spell:434152]]期间每个额外的公共冷却时间的价值不断提升。确切阈值因你的其余装备、饰品和使用的魔铸装备而异。模拟总能将其平衡。

其次是暴击，精通和全能在进攻方面通常每点价值最低。

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者属性优先级

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者，基本推荐的属性优先级如下：

力量

暴击

精通

全能

急速

主属性是鲜血 死亡骑士的立身之本，因此，在带力量的装备上，物品等级通常优先于任何副属性选择。力量为你提供 **护甲加成** （来自[[spell:195181]]）和少量招架几率加成，此外还能提高你的攻击强度。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者避免急速并强烈偏好暴击，因为其大部分伤害来自两个偶尔出现的来源（每30秒或45秒，取决于天赋）：[[spell:441378]]和[[spell:439843]]。虽然由于其交互不受急速影响而避免急速，但与其他属性相比，它仍然具有相对较好的价值。

:::details 常见问题：我可以模拟自己吗？应该模拟吗？
SimulationCraft的鲜血 死亡骑士模块维护良好，通常可以信赖它来帮助了解 **伤害** 输出的影响，你的装备、天赋和圣物选择可能会产生这些影响。

话虽如此， **SimulationCraft不能用于评估防御选择。** 不要孤立地看待模拟结果；选择伤害潜力最高的并不意味着它就是最佳选择，减伤规划始终优先。

还值得注意的是，模拟假设的是最优操作；不正确的循环优先级或防御游戏中的失误，比调整几个属性重要得多。

:::

1.

### 深入属性解析

**力量** 是你作为死亡骑士的主要属性。它增加[[spell:195181]]提供的护甲，增加你的伤害，提高你招架攻击的几率，并通过鲜血死亡骑士可用的几种吸血能力小幅提升你的自我治疗。

**精通** 被动提高你的攻击强度，并增加使用[[spell:49998]]时产生的[[spell:77535]]（以及点出[[spell:458752]]天赋时的[[spell:274156]]）。

:::details 常见问题：精通如何与其他天赋和伤害类型互动？
[[spell:77535]]的主要驱动因素是你承受的伤害，因为[[spell:77535]]的产生价值直接与每次施放[[spell:49998]]提供的治疗量挂钩。

[[spell:77535]]有上限，为最大生命值的一定百分比，但此上限忽略[[spell:55233]]提供的临时生命值加成。

这些互动带来了一个不幸的效果，即 <em>降低</em> 了随着承受伤害增加，每点精通的相对价值，主要是因为很容易超过上限。

:::

**暴击** 提高你技能造成100%额外伤害的几率，并通过[[spell:161797]]提供等量的招架等级。

:::details 常见问题：招架可靠吗？
简短的回答是 <em>取决于你如何表述</em>。你能保证在任何一次攻击中招架吗？不能。你能通过统计上平滑AOE中承受的伤害吗，当你承受伤害的主要来源是自动攻击时？绝对可以。事实上，在使用[[spell:49028]]时可以直接看到这一点。

许多额外效果和特性使得这个属性在至暗之夜中更具吸引力：

- [[spell:1264506]]在[[spell:49028]]期间通过招架触发；每次触发都会带来完全免费的额外符文能量和伤害，这使得不放弃暴击更具诱惑力，至少在合理范围内是这样。
- 虽然招架等级有陡峭的递减收益，但[[spell:49028]]提供的招架加成完全不受影响。结合你角色拥有的基础闪避，这使得招架比角色面板上看起来要吸引人得多。

:::

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

**急速** 提高你的攻击速度和符文恢复速度，同时降低你的公共冷却时间。这两种效果都很小，只有在长时间的战斗中才能提供额外的价值。

大多数战斗都有一些无法被减免或躲避的技能。此外，你需要有相当数量的生命值，以便在后续攻击杀死你之前有机会获得治疗。因此，你需要 **最低耐力值**。在大多数情况下，这个数值将简单地来自你装备上自带的耐力。因此，物品等级是保持你生命值持续增长的决定性因素。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 非常小的表述调整。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 针对 至暗之夜 的小幅编辑。
- **2025年11月30日：** 小幅更新，将常见问题解答内容包含到页面中。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为地心之战上线更新。为不同的英雄天赋树分别列出了属性优先级。
- **2024年7月23日：** 已针对地心之战前夕进行调整，并更新了昨日的热修内容。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 针对10.2.6补丁进行了审查。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已为 10.2 做准备。
- **2023年9月4日：** 澄清了属性。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的 鲜血 死亡骑士 能获得的最佳宝石、附魔、合剂、药水和食物，这些基于你的 [属性优先级](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该默认使用[[item:240983]]作为你的独特永歌钻石宝石，因为至暗之夜的其他选择非常少。[[item:240967]]的属性不够高，不值得使用。

对于稀有宝石来说，一个合理的默认选择是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 使用[[item:240908]]，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 偏好[[item:240906]]。你可以通过模拟自己来获得潜在的低于1%的收益，但使用这些推荐的宝石不会出错。

1.

### 最佳附魔和武器强化

至暗之夜 扩展了油和武器附魔的种类，但其中大多数的效果充其量只是中等水平。当你装备毕业时，你的武器灌注选择通常默认为[[item:243733]]，适用于所有内容。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:244641]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp"/> 死亡使者</span>: [[item:244017]]</li>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp"/> 萨莱因</span>: [[item:243986]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp"/> 死亡使者</span> （最高10层）：[[spell:326805]]</li>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp"/> 死亡使者</span> (10T+): [[spell:53344]]</li>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp"/> 萨莱因</span>: [[spell:326805]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

最适合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 的合剂是[[item:241326]]或[[item:241325]]，具体取决于你当前的属性。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者，最佳合剂将是[[item:241326]]或[[item:241320]]。

你应该模拟自己来确定是哪一个；这很可能取决于误差范围。

3.2.

#### 药水

你的默认药水是[[item:241288]]，[[item:241308]]稍差一些。在你不需要担心输出表现的情况下，如果圣光潜力的制作/购买成本要便宜得多，你可以使用圣光潜力。

不要被[[item:241292]]所诱惑。它提供的力量比[[item:241308]]略多，但其副作用会在你身上留下一个持续到药水效果结束的12码沉默区域。作为坦克，你的主要职责之一是控制敌人的位置，没有什么比迫使你随时移动的区域封锁更糟糕的了。

你应该使用[[item:271883]]进行战斗中治疗。治疗药水与[[item:5512]]不共享冷却时间，所以如果你与术士一起游戏，你可以独立使用两者。

3.3.

#### 食物增益

宴席是至暗之夜中唯一能在提供主属性或副属性的同时提供耐力的食物。使用[[item:255846]]（主属性）或[[item:242273]]（副属性）；两种选择都可以，它们为你提供相当的好处，所以这很可能取决于你的团队放置的是哪种宴席。

与两者相对应的个人食物是[[item:242275]]（主属性）或[[item:242274]]（副属性）。如前所述，由于不提供耐力，它们稍差一些。

3.4.

#### 强化符文

至暗之夜 随之带来了一种新的强化符文，这是每个资料片的惯例。在整个资料片期间，你都将使用[[item:259085]]。

由于这些将会 <em>非常</em> 供应有限，因此相当昂贵，我们建议从卡雷什获取永久的[[item:243191]]作为过渡。这是非常少量的主属性，但在所有[[item:259085]]超出经济承受能力的情况下，总比没有强。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 移除了狂热（它未获得增强，且仅在第一赛季早期的单体环境中表现良好），添加了 12.1 版本的新治疗药水。
- **2026年6月19日：** 非常小的符文锻造目标数量调整。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月24日：** 从消耗品中移除了茶类。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 添加了附魔、消耗品、合剂和药水。
- **2026年2月10日：** 为预补丁做好准备。将所有附魔换为速度，为升级做准备。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 添加了惊魂幻象附魔，并简述其与之前并不完全相同。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已为地心之战上线更新，带来新的消耗品和附魔！
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 添加了头盔附魔，将治疗药水更换为 10.2 版本。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 更新并澄清了玛瑙印记章节，添加了 10.1 腰带附魔，澄清了宝石，澄清了药水和药剂。已为 10.1 做好准备。
- **2023年3月20日：** 添加了玛瑙印记并澄清了 10.0.7 的相关信息。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的鲜血 死亡骑士应对大秘境地下城的技巧和建议。

1.

### 鲜血 死亡骑士 在 至暗之夜 第2赛季中的大秘境

在本指南中，我们将讨论如何在大秘境地下城中充分发挥你的死亡骑士的潜力，包括最佳的角色配置方式、你的循环可能如何变化，以及最优化使用技能的技巧和窍门。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

鲜血 死亡骑士 是一个多功能的坦克，拥有大量可用于在大秘境中控制敌人的技能，同时在熟练玩家手中基本可以自给自足。这种组合使我们在几乎任何层数中都是一个很好的选择，并且也是一个既容易上手又真正 <em>有趣</em> 并能看到成果的职业。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者 大秘境天赋构筑

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) 萨莱因 大秘境天赋构筑

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDzEVoggc21hmAo6B-edfgHHiXRKLPVQUDAIy2KTQEaCZcMIB-AAAA-TAIQQJwAxwBmmF-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和控制

3.1.

#### 打断、昏迷和控制

[[spell:47528]]是你的打断技能；它是一个天赋技能，射程15码，冷却时间为标准的近战冷却。你可以选择点出[[spell:378848]]将其减少到12秒，如果你成功打断了一个法术，但我们通常不建议这样做，除非你特别需要它来减少对某个敌人的打断任务分配。

你应该使用类似于下面的宏，以便在没有设置焦点目标时，能够轻松地在打断你的焦点目标和当前目标之间切换。这通常允许你预先确定要打断的目标，即使它不是你的当前目标：

#### 心灵冰冻宏

```wow-macro
/cast [@focus,exists,nodead] [] 心灵冰冻
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

3.2.

#### 其他群体停止技能

[[spell:221562]]位于职业树上；它是一个相对较长冷却时间（45秒）的远程昏迷技能，并且需要消耗一个完整的GCD来施放。使用时，你的目标会被昏迷5秒。

[[spell:207167]]使你面前的所有目标迷惑，直到它们受到少量伤害或持续5秒。当迷惑效果被打断时，它们会被减速50%，持续6秒。

[[spell:49576]]的主要用途是作为施法的软打断；拥有两层充能，配合[[spell:356367]]有滚动的15秒充能时间，且只消耗1/3个GCD，它对于迫使某些敌人重新开始施法非常有用。不幸的是，大多数法术的默认行为只是在被打断时尝试重新施放，因此，这只能为你争取很短的时间。

最后，[[spell:108199]]可以在专精树上点出；它作为一个定向的群体位移工具。它需要一个目标来施放，使用时，目标15码范围内的所有敌对目标都会被拉到目标的碰撞箱中心。这是 **极其**
危险的对自己施放；你应该始终对其他人（或其他东西）施放。还值得注意的是，你施放它的目标不会被移动，因此，如果他们正在施法，也不会被打断施法。它试图拉拽的所有敌人都会被沉默3秒，包括你施放它的目标。

### [[spell:111673]]

3.3.

#### 控制亡灵

这个技能允许你控制一个敌人并将其作为宠物使用，直到取消为止。在被控制期间，它的伤害比平时低得多，并且通常保留一些独特的法术，这些法术随后可以由你使用。

以下宏允许你轻松地控制和重新控制你的宠物：

#### 控制亡灵

```wow-macro
#showtooltip 控制亡灵
/target pet
/run PetDismiss()
/use 控制亡灵
/petassist
```

这会在你的宠物身上重新施放[[spell:111673]]，让你不必重新选择目标、寻找法术并使用它。它还会重新启用宠物战斗协助，以防你将其设置为被动。

### 其他功能

3.4.

#### 其他功能

[[spell:43265]]与[[spell:273952]]天赋搭配时，成为一个非常有效的工具，用于减速和控制敌人的移动。它既在敌人低血量逃跑时有用，也用于控制战斗的流程，还可以让你用它来错开近战自动攻击。虽然它是你默认循环中的循环优先级，但可以保留一层充能用于这些目的。

[[spell:61999]]是死亡骑士的战斗复活技能。虽然在团队副本环境中，你通常不会想依赖坦克进行战斗复活，但在大秘境地下城中，你可能是唯一拥有这种功能的玩家。此外，[[spell:61999]]的瞬发性质使其在某些情况下比其他战斗复活更可取，而天赋[[spell:1266819]]实际上消除了它的成本。如果你需要复活一个盟友，请务必考虑时机和位置——避免将新复活的玩家放置在危险的首领顺劈攻击路径上，或在全本伤害事件之前。

[[spell:51052]]为死亡骑士提供了一种帮助团队承受大量魔法伤害爆发的方法。它的射程和持续时间有限，但在大秘境中基本足够。通过[[spell:374383]]，它的冷却时间可以降低到3分钟，但与[[spell:378848]]非常相似，我们建议评估这对你来说是否是切实的收益，而不是盲目点出它却从不加以利用。

1.

### 应对词缀

本节包含针对鲜血 死亡骑士处理大秘境各种词缀的特定技巧。

### 词缀：升腾

4.1.

#### 鲜血 死亡骑士 的强能词缀处理

我们的默认构筑已经包含了[[spell:207167]]和[[spell:47528]]。注意宝珠的生成计时器，并调整好你的位置，以便能用冰霜之镰同时阻止多个宝珠！

### 词缀：脉冲星

4.2.

#### 鲜血 死亡骑士 的脉冲词缀处理

周期性地，一个巨大的蓝色宝珠会在所有玩家周围生成并缓慢环绕他们。需要另一名玩家与其接触以消除它，每层提供4%精通和2%吸血。

如果在15秒内未能完成，100码范围内的所有小怪都会获得增益，每层提供10%伤害和20%伤害减免。

从天赋或专精的角度来看，对此无能为力——只需帮助分担宝珠即可！

### 词缀：虚缚

4.3.

#### 鲜血 死亡骑士 的虚空使者词缀处理

虚空使者是一个直接的DPS检测。如果你玩的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) 死亡使者，我们建议尝试保留一到两层[[spell:441378]]来协助处理它。

它们拥有1%的生命值和一个巨大的护盾，使其成为[[spell:343294]]的理想目标。

### 词缀：吞噬

4.4.

#### 鲜血 死亡骑士 的吞噬词缀处理

你可以先发制人地[[spell:48707]]这个词缀，但这会牺牲整个团队的伤害。相反，你应该简单地用[[spell:49998]]将其驱散掉！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对第1赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为预补丁做好准备。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月20日：** 添加了大秘境提示。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 大秘境提示。
- **2025 年 2 月 24 日：** 为 11.1 补丁做准备。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 提示已上线！
- **2024年9月9日：** 正在为地心之战第一赛季上线做准备。除副本提示外，所有内容均已就位。
- **2024年8月19日：** 已为地心之战上线更新天赋树。
- **2024年7月24日：** 修正天赋代码。
- **2024年7月18日：** 为地心之战前夕调整了配装。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 澄清了开钥前、开怪前、波次间提示，词缀提示，整理了配装并添加了路线提示。已为第四赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 替换了一处第二赛季的引用。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 移除了雷鸣，添加了关于新词缀的信息，以及 鲜血 无法以任何方式协助应对它们。
- **2023年3月20日：** 澄清了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为大秘境的首次发布做准备。深入、扩展的法术信息将在上线后跟进。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些有用的宏和插件，以便在《魔兽世界》12.1.5补丁中使用你的鲜血 死亡骑士时让你的生活更轻松。

1.

### 最佳宏

1.1.

#### 死亡骑士通用宏

1.1.1.

##### 复活盟友

#### 复活盟友

```wow-macro
#showtooltip 复活盟友
/cast [@mouseover,help][@target]复活盟友
```

如果你的鼠标悬停目标是一名友方玩家，此宏会对其施放[[spell:61999]]。否则，它会对你的当前目标施放复活盟友。

1.1.2.

##### 心灵冰冻

#### 心灵冰冻

```wow-macro
#showtooltip 心灵冰冻
/cast [@focus,harm,nodead][] 心灵冰冻
```

此宏允许你打断你的焦点目标（如果你有的话），如果没有，则简单地打断你的当前目标。

1.2.

#### 鲜血死亡骑士专用宏

1.2.1.

##### 血魔之握

#### 血魔之握

```wow-macro
#showtooltip 血魔之握
/cast [mod:shift,@focus,exists][@mouseover,exists,nodead][@player] 血魔之握
```

如果你将光标悬停在有效的目标上以将[[spell:108199]]居中，此宏将把血魔之握施放在你的光标位置。按住shift键，则改为对你的焦点目标施放[[spell:108199]]。否则，它会将你的血魔之握居中在你自己身上。

1.2.2.

##### 枯萎凋零

#### 枯萎凋零

```wow-macro
#showtooltip 枯萎凋零
/cast [@cursor] 枯萎凋零; [mod:ctrl, @player] 枯萎凋零
```

这会在你的光标位置放下[[spell:43265]]，在此过程中跳过整个目标选择圈，并为你节省200-500毫秒。按住CTRL键则改为将其放在你的脚下。

1.2.3.

##### 保护祝福取消光环宏

#### 保护祝福取消光环

```wow-macro
/cancelaura 保护祝福
```

这个宏非常有用。它允许你取消可能施放在你身上的[[spell:1022]]。这很重要，因为在保护祝福效果期间，小怪不会攻击你，而会转而攻击仇恨列表中的下一个人（通常是DPS玩家），不过嘲讽小怪仍会迫使它攻击你3秒。

1.2.4.

##### 重新控制亡灵

#### 重新控制亡灵

```wow-macro
/target pet
/run PetDismiss()
/use 控制亡灵
/petassist
```

1.

### 最佳插件

2.1.

#### 死亡骑士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) 是一个有用的插件，可以让你追踪其他团队成员的冷却时间，并为你提供大量其他有用的团队信息。

2.4.5.

##### Clique

[Clique](<https://www.curseforge.com/wow/addons/clique>) 允许你绑定特定法术，以便在单位框架上以鼠标悬停方式施放。这对于在不切换目标的情况下施放[[spell:61999]]非常有用。

2.4.6.

##### Compact Runes

[Compact Runes](<https://www.curseforge.com/wow/addons/compact-runes>)
是一个追踪符文冷却时间的绝佳插件，它还拥有许多其他死亡骑士特定模块，用于追踪你的增益、减益和冷却时间。

2.5.

#### 鲜血死亡骑士专用插件

[ArcUI](<https://www.curseforge.com/wow/addons/arc-ui>) 有助于弥补至暗之夜中增益/减益追踪器和冷却管理器的一些最大问题。它非常流畅地展示了[[spell:195181]]的层数和少量额外的资源。

特别是对于大秘境，以下插件值得拥有：

- [TargetedSpells](<https://www.curseforge.com/wow/addons/targetedspells>)
  在小队框架上高亮敌方施法者的目标，让你能够注意到并做出相应反应

最后， [Nerveless](<https://www.curseforge.com/wow/addons/nerveless>)
为冷却管理器添加了多个自定义选项。

目前，我们认为你不需要任何额外的插件来充分发挥你专精的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 新的宏格式。
- **2026年2月10日：** 为 至暗之夜 添加了几个插件推荐。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战上线进行了审核。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 针对10.2.6补丁进行了审查。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月29日：** 澄清了 控制亡灵 及其在第二赛季中的使用。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
