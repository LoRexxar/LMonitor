## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5补丁德鲁伊恢复指南。在这里，你将学习如何在团队副本和大秘境中扮演德鲁伊恢复进行治疗。我们涵盖从基础知识到极限化手法等一切内容，以优化你的治疗输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

恢复大秘境资源

[全新！顶级恢复天赋构筑](<https://raider.io/specs/restoration-druid/talents>)

[顶级恢复大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/restoration>)

[恢复大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--restoration>)

[热门恢复队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--restoration>)

1.

### 德鲁伊恢复概览

恢复德鲁伊擅长在团队副本中使用冷却技能后进行强力的爆发治疗。恢复德鲁伊在长时间治疗少量目标时也表现出色（例如在地下城中）。

要正确地扮演治疗角色，你需要的不仅仅是职业专属信息。为了更好地理解治疗的通用知识，我们建议你阅读我们的 [治疗指南](<https://www.icy-veins.com/wow/healing-guide>).

强势

德鲁伊恢复在赛季初期表现尚可但被其他专精所掩盖，但随着赛季推进，凭借几次不错的增益以及对新输出循环的日益熟悉，已经绽放光彩。

更一般地说，我们在团队副本环境中的地位往往每个赛季都有很大变化——通常是基于其他德鲁伊专精的强度，因为[[spell:1126]]是团队必备增益。从治疗角度来看，我们非常全面，拥有持续治疗与爆发治疗的出色结合，并且可以通过天赋选择进一步偏向其中一方。

历史霸主

恢复 恢复 是一位著名的大秘境强力治疗者，并且在多个赛季中一直是主流选择，包括至暗之夜 至暗之夜 的最初几个月。该专精在治疗小型队伍内容方面设计得尤为出色，这意味着我们也是那些第一次尝试治疗的人的绝佳选择。在顶尖水平上，恢复 恢复 德鲁伊 德鲁伊 目前并不是“版本答案”之一。

我们的精通（[[spell:77495]]）实际上是专为地下城内容设计的，因为你将在目标身上拥有更高浓度的持续治疗效果。当我们适应后，我们还可以通过在猎豹形态中穿插近战技能来带来可观的伤害，我们还拥有最强的增益之一和不错的控制能力（参见功能部分）。

强大的团队增益；不错的控制能力

恢复带来了游戏中最强大的团队增益，即

[[spell:1126]]

以及大量控制技能，例如

[[spell:102793]]

,

[[spell:132469]]

,

[[spell:33786]]

和

[[spell:102359]]

这些都很有用，尽管有时是特定情况下的有用。它们往往是你在大秘境等地下城内容中比团队副本更核心的游戏部分。作为治疗专精，我们还带来了

[[spell:88423]]

这是一个驱散技能。

充足的被动和主动防御手段

德鲁伊恢复是游戏中最坚韧的治疗专精之一。它通过诸如

[[spell:377847]]

和

[[spell:474750]]

等天赋提供了优秀的自我治疗，结合

[[spell:22812]]

等低冷却防御技能。你还有

[[spell:5487]]

以及相关天赋如

[[spell:377842]]

来应对巨大的伤害。此外，当你处于危险时，也很容易在自己身上放置持续治疗效果，例如

[[spell:774]]

。作为德鲁伊恢复，你对每种类型的伤害都有多种解决方案。

移动治疗

恢复还拥有非常强大的机动性，我们的许多技能都是瞬发的，因此可以在移动中施放。我们还拥有许多机动性天赋和技能，例如

[[spell:131768]]

,

[[spell:102401]]

,

[[spell:1850]]

,

[[spell:106898]]

等等。我们唯一的缺点是目前依赖

[[spell:8936]]

来应对艰难的治疗时刻，因为我们需要站定在原地施放。作为德鲁伊，如果你愿意，你甚至可以放弃坐骑，因为

[[spell:783]]

一样快！

尚可但耗时。被动输出较差。

在团队副本中，德鲁伊恢复是输出较低的治疗专精之一，因为我们没有太多的被动伤害选项。值得庆幸的是，治疗的输出在当前游戏中并不是特别重要。在大秘境中，我们有更多的输出选项，因为我们的治疗循环需要较少的时间投入，我们可以弥补队伍伤害的更大部分。我们仍然缺乏被动伤害，所以你会花时间在

[[spell:768]]

中来最大化伤害。这可能需要一些时间来适应，但当你掌握它时会很有成就感。

1.

### 德鲁伊恢复在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁对[[spell:1263879]]天赋进行了小幅度的改动，使其使用起来明显更容易。它还带来了两个新的重要内容：一个名为迷宫的全新巨型地下城，以及一个你将面对基斯希克斯的新团队副本！

你还将能够通过天界毒石系统升级完全升级的神话或英雄项链、饰品和武器（包括副手），该系统在补丁上线一周后回归。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

主要改动将来自基斯提克斯团队副本战斗的新物品。最值得注意的是一个饰品、一个戒指和一件胸甲。此外，你将能够从 10 月 20 日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

2.3.

#### 职业改动

遗憾的是，12.1.5补丁中德鲁伊恢复没有任何改动。我们已经更新了我们的
[装备](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>) 包含新信息的页面，关于来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 团队副本遭遇的装备新信息，以及如何花费你的第一个[[item:280562]]的建议。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_treeoflife.jpg>)点击查看上赛季第二赛季的改动
2.4.

#### 第2赛季职业改动

德鲁伊恢复在12.1补丁第2赛季开始时获得了一次小型重做。对[[spell:207383]]的重大改动  

极大地改变了你每个技能的施放次数。如果你是回归玩家，可以预期德鲁伊恢复会比过去稍微简单一些，但仍有足够的深度让你保持兴趣。以下是主要改动：

- [[spell:207383]]重做。现在当你拥有5个活跃的[[spell:774]]时激活，而不是随数量扩展。暴击和法力消耗降低固定为60%，不再随数量扩展。
- [[spell:29166]]重做。现在恢复你25%的最大法力值，而不是让你的技能在八秒内免费施放。这个版本使用起来会容易得多，而且更强。
- [[spell:392410]]不再延长你的[[spell:18562]]目标身上的持续治疗效果。
- [[spell:48438]]治疗量提高20%。法力消耗提高15%。
- [[spell:774]]、[[spell:8936]]、[[spell:18562]]法力消耗降低。
- [[spell:740]]在引导期间现在会为你提供一个相当于最大生命值60%的护盾。
- [[spell:33891]]现在会对3名受伤的盟友施放[[spell:8936]]。
- 若干天赋在天赋树中互换了位置，例如[[spell:155675]]与[[spell:392325]]互换了位置。

:::

### 至暗之夜改动概述

2.5.

#### 至暗之夜中恢复 德鲁伊的改动

至暗之夜对恢复 德鲁伊以及治疗职业整体进行了大规模的改版。它还包含了全面的用户界面改动，这些改动对恢复 德鲁伊的影响比对许多其他专精的影响都要大。总体目标是通过移除你想要有竞争力地进行游戏所需的插件数量，以及让专精本身更容易上手，使游戏更具可及性。他们确实成功地让专精更容易上手了，不过用户界面改动至今为止的推出过程是灾难性的。

2.6.

#### 新顶点天赋

至暗之夜中新增的天赋是“顶点节点”。它相当于一个第三层专精天赋节点，但你最多可以在其中投入4点。我们的顶点节点叫做常青之花，效果如下：

- 第1点（[[spell:392167]]）：[[spell:33763]]可叠加最多3层，每5秒叠加一层。
- 第2点和第3点（[[spell:1244331]]）：[[spell:33763]]“绽放”的20/40%治疗量会溅射至多6名附近的盟友。
- 第4点（[[spell:1244470]]）：当你施放[[spell:18562]]时，你的[[spell:33763]]会连续快速绽放3次。

我们的顶点节点在大秘境中极其强大，但在团队副本中仅勉强可用。它擅长让单个目标（任何身上有你[[spell:33763]]的目标）接近无敌，这在你只需要治疗五个人时非常有用。

2.6.1.

##### 英雄天赋改动

两棵英雄天赋树在新资料片中都获得了三个新节点，并且你可以在90级时点出全部节点。

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者天赋树的玩法与地心之战非常相似。它仍然专注于施放[[spell:439530]]，并为拥有该增益的盟友同时提供治疗和受到的治疗量加成。[[spell:439530]]的触发几率被略微削弱，并且出现了一些新的通用持续治疗加成，例如[[spell:1270592]]。它在大秘境中仍然是一棵极其强大的天赋树，但在团队副本中预计会稍弱一些。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者的变化较大，因为[[spell:102693]]技能现在是被动效果，而不是一个主动按钮。[[spell:102693]]现在会在你施放[[spell:18562]]和[[spell:48438]]时触发。这简化了丛林守护者的玩法，移除了需要叠加充能并在爆发期一次性倾泻的需求。该天赋树的特色得以保留，但现在它应该会让你感觉它是在提供更直接的治疗量提升，而不再需要特定的玩法来最大化收益。总体而言，你获得的[[spell:102693]]比以前多得多。至暗之夜中的新英雄天赋树还会让你获得更多的[[spell:18562]]施放次数，考虑到现在有如此多的效果与其挂钩，这将会表现出色。

2.6.2.

##### 治疗改动

至暗之夜中对恢复 德鲁伊有两项重大改动：

- 许多小型持续治疗效果被移除了，例如春花烂漫和栽培。随着用户界面的改动，同时追踪多个持续治疗效果变得繁琐，因此他们移除了一堆较小的效果。这些效果通常本来也没有什么玩法上的互动。我们的精通效果（[[spell:77495]]）得到了显著增强，以补偿持续治疗效果的损失。
- 我们常用的冷却技能现在可用的频率变低了。[[spell:197721]]变成了一个被动效果，会在你施放宁静时触发，从而将其原来的一分钟冷却时间变成了三分钟。这看起来可能相当糟糕，但暴风雪已经精简了所有专精的治疗冷却技能。目标是让治疗基于你按下的轮转按钮，而不是用一个大型治疗冷却技能来应对每一个机制。

尽管有所有这些改动，你的输出循环不会有太大不同。你仍然会用[[spell:774]]来为即将到来的伤害做准备，并且仍然会在伤害到来时施放愈合来兑现你的铺垫（以利用[[spell:207383]]）。你会继续维持[[spell:33763]]和[[spell:145205]]（虽然[[spell:1217941]]让后者更容易维持），而[[spell:18562]]和[[spell:48438]]仍然是关键的轮转施法。

2.6.3.

##### 至暗之夜用户界面改动

至暗之夜通过对大量插件施加严格限制，彻底改革了游戏的用户界面。这意味着你可能已经使用了数十年的插件，如Grid2、Cell或Weak Auras，可能不再可用，即使可用，它们也会受到更多限制。作为失去大量战斗插件的补偿，暴风雪一直在改进基础用户界面。尽管如此，它仍有许多不尽如人意之处。

1.

### 恢复 德鲁伊玩法基础

恢复 德鲁伊的核心在于策略性地使用你的技能。你不会使用固定的输出循环，而是会使用你灵活的法术组合来适应并克服游戏抛给你的任何挑战。

有两个技能需要在整个战斗中持续维护：[[spell:145205]]和[[spell:33763]]。[[spell:48438]]冷却时间相对较短，法力效率高，且有很高的群体治疗量。[[spell:18562]]提供中等的治疗量，但也会触发许多其他天赋，例如[[spell:158478]]。经常使用这四个法术对于良好的恢复 德鲁伊玩法至关重要。[[spell:774]]将作为填充法术使用，只要你的法力允许，但最好集中在大量群体伤害期间，并与你的冷却技能如[[spell:33891]]、[[spell:29166]]配合使用。伤害到来后，你会使用[[spell:8936]]来治疗任何仍然受伤的人。要进一步了解该专精，请参考以下要点。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_empoweredrejuvination.jpg>) **保持丰饶激活**
  
  
  
  
  你的[[spell:207383]]天赋通过大幅提高[[spell:8936]]的暴击几率并降低其法力消耗，使其得到极大强化。许多恢复 德鲁伊的玩法都围绕着利用这些廉价的施放。保持五个[[spell:774]]增益应该相当简单——尤其是考虑到你可以使用[[spell:158478]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_herb_felblossom.jpg>) **保持生命绽放激活**
  
  
  
  
  你的[[spell:33763]]持续15秒，且一次只能施放在一个目标身上。要时刻保持它激活，因为我们的“顶点天赋”[[spell:1244470]]依赖于它的激活状态。在[[spell:33763]]激活的情况下，每次施放[[spell:18562]]都会造成大量范围治疗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_relics_idolofrejuvenation.jpg>) **卡冷却施放迅捷治愈**
  
  
  
  
  [[spell:18562]]附带了大量效果，如[[spell:158478]]和[[spell:1244470]]。这意味着你应该尽可能频繁地施放它。在团队副本中，你主要会对自己施放；在大秘境中，你可以对任何受伤的人施放，但无论如何都要确保卡冷却施放。

1.

### 如何为恢复 德鲁伊配装

由于变量众多且可用的团队规模多样，治疗者的配装可能会很复杂。你可以在配装页面上找到有关如何为恢复 德鲁伊进行最佳配装的信息，其中包含该赛季的毕业装备推荐。获得装备后，你需要确保拥有最好的消耗品、宝石和附魔。两份指南都可以在下方找到，并将为你提供最新的信息。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已为12.1补丁更新。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对至暗之夜发布更新。
- **2026年2月26日（本页）：** 已针对至暗之夜发布更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对11.2.5版本的改动进行更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为11.2.5补丁更新。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 为11.2.5补丁更新。
- **2025年10月5日（本页）：** 已针对11.2.5版本进行审查。
- **2025年8月26日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 更新了天赋推荐。
- **2025年8月20日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已更新饰品推荐。
- **2025年8月12日（本页）：** 已针对赛季开赛的在线修正进行更新。
- **2025年8月6日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了一些装备推荐。
- **2025年8月6日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 以列表形式展示属性优先级。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已为11.2.0版本进行审查。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已为11.2.0版本进行审查。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对11.2.0版本进行更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对11.2.0版本进行更新。
- **2025年8月4日（本页面）：** 已针对11.2.0版本进行更新。
- **2025年7月24日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** 已为11.2.0版本进行审查。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对11.1.5进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月23日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 因套装改动而更改了天赋推荐。
- **2025年3月23日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 因套装改动而更改了天赋推荐。
- **2025年3月16日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更改了团队副本饰品推荐。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** 更新了英雄和史诗难度的首领推荐。
- **2025年3月3日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** 添加了一些普通和英雄难度的首领推荐。
- **2025年3月3日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 添加了第2赛季推荐和新套装分析。
- **2025年2月25日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了饰品排名。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** 更新了一些首领的冷却技能推荐。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 更新了低目标数量时的法术优先级。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** 更新了一些首领推荐和天赋构建。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年9月18日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** 为指南添加了冷却技能建议。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已为地心之战第1赛季进行审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已为地心之战第1赛季进行审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（本页）：** 已为地心之战第1赛季进行审查。
- **2024年8月29日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 小幅更新。
- **2024年8月29日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 添加了荒野追猎者地下城构建，并对一些天赋添加了说明。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年8月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/restoration-druid-mists-of-pandaria-remix-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月20日（[地心之战](<https://www.icy-veins.com/wow/restoration-druid-the-war-within-pve-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年6月19日（[地心之战](<https://www.icy-veins.com/wow/restoration-druid-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/restoration-druid-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月14日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了大秘境、装饰和饰品推荐。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月26日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对10.2.6版本更新。
- **2024年3月20日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对10.2.6版本更新。
- **2024年3月20日（本页）：** 已针对10.2.6版本更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 在饰品列表中添加了希望之光，并针对10.2.5版本进行了更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行审核。
- **2023年12月2日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 更新了天赋树。
- **2023年11月26日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了毕业装备列表和团队副本饰品推荐。
- **2023年11月21日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 添加了百花齐放 WeakAura。
- **2023年11月21日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 更新了天赋推荐。
- **2023年11月21日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 更新了天赋推荐。
- **2023年11月11日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了阿梅达希尔的装备推荐。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了装饰和饰品推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对10.2版本进行更新
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对10.2版本进行更新
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对10.1.7补丁进行更新。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年8月31日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.7补丁进行更新。
- **2023年7月12日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已更新饰品推荐。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 更新了10.1.5版本的路径和天赋选择推荐。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月7日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已更新饰品推荐。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 更新了10.1.0版本的吸血数值。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 为10.1.0补丁进行了更新。
- **2023年5月1日（本页）：** 为10.1.0补丁进行了更新。
- **2023年4月28日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 为10.1.0补丁进行了更新。
- **2023年4月28日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已为10.1.0版本进行审查。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 更新了奥妮克希亚的纪念指环推荐。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 更新了奥妮克希亚的纪念指环推荐。
- **2023年3月24日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 更改了团队副本的输出循环推荐。
- **2023年3月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 更新了团队副本天赋推荐。
- **2023年3月24日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 更改了构建推荐。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/restoration-druid-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已为10.0.7补丁更新。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已更新至10.0.5补丁。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月29日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 调整了一些附魔和消耗品建议。
- **2022年12月29日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 更改了天赋构建建议。
- **2022年12月29日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 更改了法术优先级和万灵之召建议。
- **2022年12月29日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 小修复。
- **2022年12月29日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 调整了大秘境和团队副本的天赋建议。
- **2022年12月29日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 调整了推荐天赋构建。
- **2022年12月12日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 修正了食物和宝石建议。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已根据化身密库和大秘境掉落进行更新。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已根据专业制造推荐和套装分析进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 添加了鞋子附魔建议。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 调整了DPS输出循环。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 对大秘境输出循环和套装建议进行了小幅更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 添加了更多大秘境构建选项。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月30日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 更改了天赋构建推荐。
- **2022年10月30日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 更新了创生建议。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/restoration-druid-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/restoration-druid-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/restoration-druid-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年5月31日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对 9.2.5 补丁审核本页面。
- **2022年4月23日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** 已使用正式服数据更新。
- **2022年2月18日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已更新至9.2补丁。
- **2022年2月10日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** 已针对最新 PTR 版本更新。
- **2022年1月21日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** 已根据最新 PTR 版本的改动进行更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** 为9.1.5进行了更新。
- **2021年10月29日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 针对9.1.5补丁更新。
- **2021年8月8日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** 更新了信息。
- **2021年6月28日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对 9.1 补丁审核并通过。
- **2021年5月21日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** 在最近的 PTR 补丁后更新了部分信息。
- **2021年5月19日（[9.1 补丁分析](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2021年3月9日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已针对 9.0.5 补丁审核。
- **2020年11月23日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 已添加 平衡亲和循环。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年10月12日（[DPS指南](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年9月17日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** 更新了推荐内容。。
- **2019年8月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** 已更新推荐。
- **2019年7月25日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** 更新了前3个首领的推荐内容。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月18日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-crucible-of-storms-raid-guide>)):** 更新了两个首领的技巧。。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月23日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** 添加了史诗吉安娜的建议，明确了风暴之墙阻截战第二阶段。。
- **2019年2月7日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** 为所有遭遇战添加了一些说明。。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** 页面已创建。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 针对8.1补丁进行了更新。
- **2018年9月21日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 为史诗难度的首领添加了一些建议。。
- **2018年9月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 更新了腐蚀吞噬者噬灭的推荐内容。。
- **2018年9月1日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 更新了天赋。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页，你将找到我们的恢复 恢复 德鲁伊 德鲁伊 逐级升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[德鲁伊 升级指南](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### 至暗之夜 至暗之夜 的恢复 恢复 德鲁伊 德鲁伊 升级指南

作为治疗者升级比输出或坦克专精慢得多，因为我们杀怪速度不快。请做好长途跋涉的准备。你也可以利用地下城内容来施展你的治疗能力。以德鲁伊 德鲁伊 的输出专精平衡 LinkEngineering 平衡 或野性 野性 升级，然后在满级后换回恢复 恢复 是很常见的，但这由你决定。

如果你坚持作为治疗者，那么你会想利用你惊人的生存能力，一次拉很多敌人——尤其是在你点出了一些天赋点之后。作为德鲁伊 德鲁伊，你还可以使用潜行 [[spell:5215]]，它可以让你完全跳过一些敌人，因为它会使你进入“潜行”状态，在这种状态下敌人发现你的几率要小得多。你可以使用这个能力跳过棘手的怪物去获取任务物品。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 至暗之夜升级实用消耗品

为了快速练级，你需要专注于最大限度地减少非战斗时间并尽可能提高伤害。你还应该利用你强大的治疗能力，一次拉尽可能多的敌人。你不需要任何特殊物品来练级，但提前准备几件以下物品可能会加快你的旅程：

- 淬炼迅捷药剂：药剂是一种不用花大价钱就能增加伤害的好方法。急速是一个很好的选择。
- 淬炼药水：战斗药水可以加快大规模拉怪或对付棘手怪物的速度。
- 银月城生命药水 银月城生命药水：作为治疗专精升级时，你其实不太需要治疗药水，但这些药水非常好，可以从81级开始使用。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 至暗之夜 至暗之夜 80级恢复 恢复 德鲁伊 德鲁伊 升级
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNzMglZsYbGAAAAAAAAAAsNoZjxkhZmxsZmZmZZGYAAAAAAAwAAAAAghZrZZsYDmZgZWAZAAmZAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNzMglZsYbGAAAAAAAAAAsNoZjxkhZmxsZmZmZZGmZAAAAAAAwAAAAAgZZmtmlZWsBzMwMLgMAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BRQNKKTTA7kyALiUxRsu+ZdTTrFWq6onwQR-FDhWWLNO0AQRO+BKV50zpzUJrKkP1rL-AAAA-RGUAQ8gRDziQgE-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将重点介绍最实用的战争模式PvP天赋，以加快你的练级过程。不幸的是，其他天赋在伤害输出方面没有任何帮助。

- [[spell:305497]] 对任何近战攻击你的敌人都能造成惊人的伤害。
- [[spell:377801]] 在练级时略微提高你的移动速度。
- [[spell:233755]] 可以与[[spell:102359]]配合使用，拉大量怪物并给它们全部挂上持续伤害效果。
- 如果你是组队练级，[[spell:1217474]] 可以提供不错的治疗加成。

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**从1级开始，你只有一个主要攻击技能：[[spell:190984]]。

- **等级 53 起：**[[spell:391528]] 是一个极好的法术，可以对敌人造成伤害并快速治疗你的队伍。尽可能经常使用它。
- **等级 2 起：**[[spell:8921]] 是一个持续伤害法术，你应该对你正在战斗的任何敌人使用它。它特别适合将新敌人拉入与你的战斗。
- **等级 7 起：**[[spell:22568]]根据消耗的连击点数造成伤害。除了基础的25点能量之外，每额外消耗一点能量都会进一步提高伤害，最多可额外消耗25点。
- **等级 20 起：**如果预期敌人存活时间足够长，能让持续伤害打满伤害，则使用割裂 [[spell:1079]] 而不是撕咬 撕咬。
- **等级 10 起：**你获得第一个天赋点，把它花在[[spell:1822]]上。使用斜掠和月火术给多个敌人挂上持续伤害效果。
- **等级 5 起：**[[spell:768]]。你在 猎豹形态 中的移动速度提高30%。这还会解锁 [[spell:5221]]，一个仅能在 猎豹形态 中使用的单体攻击，产生1个连击点数。大多数情况下请改用 [[spell:1822]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为地心之战第1赛季进行审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月26日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年12月2日：** 更新了天赋树。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页面中，我们将讲解如何在《魔兽世界》12.1.5补丁中轻松游玩 恢复 德鲁伊，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 恢复 德鲁伊基础

本页面适用于刚接触游戏或该职业的玩家，不打算参与史诗难度团队副本的玩家，或者想要以更直接的方式游玩其专精而不想被大量需要考虑的细节和主动技能所淹没的玩家。

恢复 德鲁伊在团队副本中依赖持续治疗效果来为使用 [[spell:391528]] 的强力爆发做铺垫，同时在地下城中也拥有强大而稳定的治疗输出。他们在单体治疗方面表现出色，但需要一些时间来铺设持续治疗效果。他们需要了解战斗机制，以便为即将到来的伤害做好准备。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_empoweredrejuvination.jpg>) **保持丰饶激活**
  
  
  
  
  你的[[spell:207383]]天赋通过大幅提高[[spell:8936]]的暴击几率并降低其法力消耗，使其得到极大强化。许多恢复 德鲁伊的玩法都围绕着利用这些廉价的施放。保持五个[[spell:774]]增益应该相当简单——尤其是考虑到你可以使用[[spell:158478]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_herb_felblossom.jpg>) **保持生命绽放激活**
  
  
  
  
  你的[[spell:33763]]持续15秒，且一次只能施放在一个目标身上。要时刻保持它激活，因为我们的“顶点天赋”[[spell:1244470]]依赖于它的激活状态。在[[spell:33763]]激活的情况下，每次施放[[spell:18562]]都会造成大量范围治疗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_relics_idolofrejuvenation.jpg>) **卡冷却施放迅捷治愈**
  
  
  
  
  [[spell:18562]]附带了大量效果，如[[spell:158478]]和[[spell:1244470]]。这意味着你应该尽可能频繁地施放它。在团队副本中，你主要会对自己施放；在大秘境中，你可以对任何受伤的人施放，但无论如何都要确保卡冷却施放。

1.

### 至暗之夜中 恢复 德鲁伊新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者团队副本天赋

2.1.

#### 恢复 德鲁伊新手团队副本治疗天赋

使用我们计算器的“导出天赋”功能快速导入我们的配置！

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsZsNmBAAAAAAAAAAbDa2YMNzY4BMLzMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQTzEIMVWy2AXXZBWkrLVNWTLMU88CD-FGHWWHCXq08ARmGk4QhM96qrqEno4nG-AAAA-BEIcEpJ4gRiSmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者地下城天赋

2.2.

#### 恢复 德鲁伊新手地下城与掘地战治疗天赋

使用我们计算器的“导出天赋”功能快速导入我们的配置！

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8AMzsMjFbzAAAAAAAAAAgNDNLjx0MDwsZmZmZxwMAAAAAMAAzAAAAAgZZmtmlZWsxYmBmZD0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-NzKKMOkCIEVA74WtuBmVY1wUTrNmaq4ZYoH-FGrDhOUu0oQO2LF4Bi60pD3UJkPVttL-AAAA-REAaYIGYQRyhFD-
```

:::

### 恢复 德鲁伊基础输出循环

2.3.

#### 团队副本输出循环

以下输出循环是一个大致的思路，说明你在游玩时应该优先做什么。它不包括更深入的细节，你有很多小方法可以提升你的操作水平，但它会给你一个总体的概念。

- 在近战组脚下保持 [[spell:145205]]。如果使用了 [[spell:1217941]] 则忽略此条。
- 在自己身上保持 [[spell:33763]]。
- 使用 [[spell:18562]]，冷却完毕即用。随后接上 [[spell:774]]。
- 当团队大量掉血时使用 [[spell:48438]]。它消耗较高但治疗量很大。
- 施放 [[spell:774]] 以保持你的 [[spell:207383]] 处于激活状态（保持5层激活）。
- 在 [[spell:207383]] 激活时施放 [[spell:8936]]。这将是你最常见的施法。
- 施放 [[spell:5176]] 来恢复法力值（通过 [[spell:289237]]）。

恢复 德鲁伊的套装效果完全是被动的，会提高你的持续治疗效果的治疗量。该增益在施放 [[spell:774]] 时为低概率触发，而在施放 [[spell:740]]、[[spell:391528]] 和 [[spell:132158]] 时必定获得一层。

2.4.

#### 地下城输出循环

- 在坦克和近战脚下保持 [[spell:145205]]。如果使用了 [[spell:1217941]]（它在默认构筑中），则忽略此条。
- 在坦克身上保持 [[spell:33763]]。如果他们远离人群，也可以把它放在一个输出职业身上。
- 使用 [[spell:18562]]，随后根据你是需要立即治疗还是未来20秒内的治疗，接上 [[spell:8936]] 或 [[spell:774]]。
- 在轻度到中度伤害期间施放 [[spell:48438]]。
- 在坦克以及刚刚受到伤害或即将受到伤害的小队成员身上保持 [[spell:774]]。
- 在空闲时间，对敌人使用 [[spell:8921]]、[[spell:93402]] 和 [[spell:5176]] 来帮助贡献伤害。

2.4.1.

##### 巅峰天赋： ![Everbloom Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_focusedgrowth.jpg>) 繁盛

在至暗之夜中新增的天赋是“巅峰天赋”节点。它相当于第三层专精天赋节点，但最多可以投入4点。我们的巅峰天赋名为“生生不息”，具有以下效果。

- 第1点（[[spell:392167]]）：[[spell:33763]]可叠加最多3层，每5秒叠加一层。
- 第2和第3点（[[spell:1244331]]）：你的[[spell:33763]]会将20/40%的“绽放”治疗效果溅射给最多6名附近的盟友。这包括能产生更多绽放效果的天赋，例如[[spell:274902]]。
- 第4点（[[spell:1244470]]）：当你施放[[spell:18562]]时，你的[[spell:33763]]会连续快速绽放3次。

我们的所有配装都会点出巅峰天赋，因此你需要特别注意始终保持目标身上的[[spell:33763]]。

2.4.2.

##### 冷却技能

- [[spell:740]]应在团队承受大量伤害时使用，或在团队领袖安排你使用时使用。请确保提前施放[[spell:774]]，因为[[spell:740]]会延长它们的持续时间。
- [[spell:29166]]应在战斗中尽可能频繁地使用。第一次使用应在你的法力值约为75%时。
- [[spell:391528]]在团队副本中应频繁使用。提前施放一些[[spell:774]]，并尽量将其与战斗中最危险的时刻对齐。
- [[spell:102342]]应用于在关键时刻降低坦克承受的伤害（例如当重要首领技能即将施放时）。在没有此类情况时，你应对承受伤害的玩家使用它。你可能会被安排在特定时间使用它，作为与其他治疗者和坦克减伤技能轮转的一部分。

### 恢复德鲁伊属性优先级

2.5.

#### 恢复德鲁伊属性优先级

智力

急速

精通

全能

暴击

智力强于所有副属性，使大多数装等提升都是升级。唯一的例外是戒指和项链。你通常应该装备装等更高的，但在5个装等以内的可能会有小的例外。

急速和精通是纯治疗最强的副属性。如果你的优先级是治疗，那么就装备精通和急速，因为它们在小型队伍内容中是最强的治疗属性。这也使你的团队副本和地下城属性优先级保持一致，这可能非常有用。

关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>).

### 暴风雪战斗助手

2.6.

#### 战斗助手

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 11.1.7版本引入的功能对治疗无效。战斗助手和一键施法都只会让你使用伤害法术，而你最好直接施放[[spell:5176]]。当你处于[[spell:5487]]时，它们也完全无法工作。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月6日：** 以列表形式展示属性优先级。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月20日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月24日：** 更改了构建推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月29日：** 调整了推荐天赋构建。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界12.1.5版本中你的恢复德鲁伊的最佳天赋。我们还提供适用于不同类型内容（如团队副本或大秘境）的默认天赋配装。如果你开启了战争模式进行游戏，我们也涵盖了你的PvP天赋。

1.

### 恢复德鲁伊在至暗之夜中的最佳天赋

在第2赛季中，得益于第1赛季末期的几项改动延续到了12.1版本，恢复德鲁伊现在在所有内容中都使用荒野追猎者英雄天赋。虽然有许多小幅度的替代选择可用，但以下几套天赋将为你提供非常出色的表现：

- **团队副本 -** 虽然丛林守护者并非不可用，但团本玩法将充分利用荒野追猎者的多重治疗增益，极大地强化我们的巅峰天赋。它还提供无与伦比的生存能力，你会持续且自动地回复满生命值。
- **大秘境 -** 荒野追猎者也将是我们在大秘境中的首选，尽管不要将其视为以猎豹形态为主的天赋树；它更偏向于治疗。认为选择荒野追猎者就必须使用猎豹形态是一种常见的误解，实际上我们会选择强化治疗和施法者DPS的天赋。

虽然你可以在不同场景中为几种小幅度的天赋替换提出理由，但你不必觉得需要频繁更换天赋。下面的构建可以从绝对新手一直到名人堂/头衔级别的大秘境层数，在所有内容中通用。

**快速开始导入代码：**

:::talents 荒野追猎者团本
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthBzsZsNmBAAAAAAAAAAbDa2YMNzY4BMLzMzMDDzAAAAAAAAAAIAAgZbmlmtZ2sxYmZwMwoZAAmZAYA"
}
```
:::

:::talents 荒野追猎者大秘境+
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZzw0MjZwsYmZmZZGegZAAAAAAAwAAQAAAz2MbNbzsYjxMDMzCoZAAmZAYA"
}
```
:::

:::talents 荒野追猎者地下堡
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmxYGzMjZbmZYYhZx2MAAAAAAAAAAYbQzmhpZMzYMLmZmZWmhxAAAAAAAYMAAEAAwsMzWzyML2gZeAMjFQzAAMzAwA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

荒野追猎者

团队副本

秘境+

地下堡

丛林守护者

替代团本

替代大秘境+

### 天赋方案 0-0

1.1.

#### 团本治疗构建

这是我们推荐的第2赛季至暗之夜团本构建。

### 天赋方案 0-1

1.2.

#### 地下城治疗构建

这是我们推荐的大秘境天赋构建。我们推荐荒野追猎者，因为它的治疗量最高。

### 天赋方案 0-2

1.3.

#### 地下堡构建

这是我们推荐的地下堡构建，专注于在保持恢复专精的同时最大化你的伤害输出。如果你想了解更多关于地下堡的信息，请查看我们的专属地下堡指南： [地下堡](<https://www.icy-veins.com/wow/delves-guide>)

### 天赋方案 1-0

1.4.

#### 团本治疗构建

这是一个使用丛林守护者代替荒野追猎者的替代方案。不推荐使用。

### 天赋方案 1-1

1.5.

#### 替代方案 - 丛林守护者大秘境天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者是一个替代的大秘境天赋树，功能较少，但仍然可用。它的总体伤害也比荒野追猎者更高。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthHYYmNjtxMAAAAAAAAAAYbQzGjpZGDPgZZmZmZYYGAAAAAAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQTzEIMVWy2AXXZBWkrLVNWTLMU88CD-FGHWWHCXq08ARmGk4QhM9arrqEno4HG-AAAA-BEIcEpJ4gRiSmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZzw0MjZwsYmZmZZGegZAAAAAAAwAAAAAgZbmtmtZWsxYmBmZB0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQRfzEMVWy2AXXBU8grLVVTzTo44ZLM-FGHWWHCXq08ARmC4QN+0DZ61lWHVJuP-AAAA-BEIeEpJ4gRiCmF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNzMgFzsZbGAAAAAAAAAAsNoZzw0MmZMmFzMzMLzwYAAAAAAAwAAAAAgZZmtmlZWsBz8AYGLgmBAYmBgB"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNQRTTVWy2+AXnBSU8g5hrLVVTzTY4YLM-FGHWWHCXq08ARmC4QN+EFZq11VnPpKQ-AAAA-BEIeApJwgRiCmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMjxMLzMjZmxsN8ADzsZsxMAAAAAAAAAAYbQzGjpZGDPgZZmZmZYYGAAAAAAAAYbbshpZmlBAAAwCjZmhZGY0MAYmBAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQTzEIMVWy2AXXZBWkrLVNWTLMU88CD-FGHWWHCXq08ARmGk4QhM9qrqE3HA6GG-AAAA-IOEaGygkAoSQjF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNMMmtZsZbGAAAAAAAAAAsYoZbmxkZAmFzMzMLGGAAAAAMAAzA2WGLYamZZAAAAswYmZwMbgmBAzMAgB"
}
```
:::

:::details 来源计算器编码
```
#pB-KKNOzEVWy2AXXBU8grLVVTzTY4ZbSBEWDTM-FGHWWHCXq08ARmC4QN+07DZ61lWXVJO-AAAA-EGQYcgkQpBYAmF-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在完成一系列任务后提供一些小幅的性能增强自定义选项。这些总体上是小幅加成，但仍值得获取。

- 节点1：[[spell:1279599]]
- 节点2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点4：[[spell:1279610]]
- 节点5：[[spell:1279614]]

卷宗的大部分威力来自属性节点（4），我们将选择[[spell:1279599]]来更频繁地触发它。

第5个节点也非常灵活。每个都以相同的幅度提升你核心符文（节点1）的威力，所以你基本上只是在选择治疗 <em>形式</em> 你偏好的那种。

1.

### 巅峰天赋： ![Everbloom Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_focusedgrowth.jpg>) 繁盛

巅峰天赋是至暗之夜新增的内容。它们是恢复专精天赋树中的新节点，最多可以投入四点。我们的巅峰天赋叫做[[spell:392167]]，其设计围绕着强化[[spell:33763]]。

投入点数将解锁以下效果：

- 第一点：你的[[spell:33763]]最多可叠加3层，每5秒自动叠加一次。它的治疗量变为3倍，但你获得的精通加成与没有该天赋时相同。
- 第二和第三点：你的[[spell:33763]]会将20/40%的“绽放”治疗效果溅射给最多6名附近的盟友。这包括能产生更多绽放效果的天赋，例如[[spell:274902]]。
- 第四点：当你施放[[spell:18562]]时，你的[[spell:33763]]会快速连续绽放3次。

在地下城内容中，我们的巅峰节点极其强大，因为它使你的[[spell:33763]]目标几乎不死。对队伍其他成员的溅射治疗也非常有价值，而且每次你按下[[spell:18562]]都能获得大量收益。你不仅会在所有场景中选择它，还会选择进一步增强[[spell:33763]]的配套节点，如[[spell:274902]]。

在团本中，让一个人不死的价值没那么高，因为他们只占团队的一小部分。但在12.1版本之前的赛季中期加强已经足以使其成为一个不错的天赋，你仍应期望在所有内容中使用它。

1.

### 英雄天赋

恢复德鲁伊可以在英雄天赋之间选择 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者，两者提供相似的游戏体验，但各有优势。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者专注于其独特的[[spell:439530]]持续治疗效果，能大幅增强目标受到的治疗量并增加一层精通加成。它与猎豹玩法有特殊协同，但其DPS和治疗能力完全独立，不需要[[spell:768]]即可使用该天赋树。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者基本上是一个被动天赋树，你不需要特意围绕它来发挥其优势。 **这将是我们大秘境和其他小队内容中的默认天赋树。它在团本中同样具有竞争力。**

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者天赋树则侧重于爆发治疗和我们的[[spell:102693]]机制。每次我们施放[[spell:18562]]或[[spell:48438]]，我们将在8+秒内获得更强的治疗效果。[[spell:391528]]会大量施放这两个技能，这意味着当我们最需要治疗时，可以同时拥有4-5个[[spell:102693]]，大幅提升我们的治疗量。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者也是一个相当被动的天赋树。它在两种内容中都只是表现一般，但受[[spell:48438]]的高消耗所制约。

1.

### PvP天赋（战争模式）

你可以进入“战争模式”。开启战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10-30%。
- 升级时获得的经验值提高10-30%。
- 赚取征服点数，每周可兑换装备。

如果你喜欢PvP，或者想要更快的升级体验，可以启用战争模式。但你会使自己暴露在开放世界PvP中，偶尔可能会卷入冲突。

在本节中，我们将为升级和进行单人/小队PvE内容排列PvP天赋的优先级。以下是通用PvP天赋和恢复德鲁伊专属PvE天赋的排名。

1. [[spell:305497]]是一个不错的选择，提供直接的伤害加成。它可以在任何形态下使用，并能为大型拉怪提供可观的伤害。

[[spell:233673]]、[[spell:247543]]、[[spell:233755]]、[[spell:203553]]、[[spell:428937]]在PvE内容中，无论是在开放世界增加伤害还是在小队中进行治疗，效果都有限。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月26日：** 更新了天赋推荐。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月23日：** 因套装改动而更改了天赋推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月29日：** 添加了荒野追猎者地下城构建，并对一些天赋添加了说明。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月20日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月21日：** 更新了天赋推荐。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 更新了10.1.5版本的路径和天赋选择推荐。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月24日：** 更新了团队副本天赋推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月29日：** 调整了大秘境和团队副本的天赋建议。
- **2022年12月11日：** 添加了更多大秘境构建选项。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月30日：** 更新了创生建议。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据你的队伍承受的伤害类型来优化恢复德鲁伊的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以最大化你的治疗输出和法力效率。我们的所有内容均已更新至《魔兽世界》12.1.5版本补丁。

1.

### 恢复德鲁伊玩法与循环指南

欢迎来到恢复德鲁伊的循环页面。在本页中，你将找到关于在团本和大秘境场景中游玩该专精所需了解的一切。

作为恢复德鲁伊，你的具体治疗玩法将取决于你需要治疗多少个目标。主要区别在于团本和地下城内容之间。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

丛林守护者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者

荒野追猎者

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

### 团队副本

1.1.

#### 恢复德鲁伊团本循环

恢复德鲁伊治疗中有两个关键概念你需要熟悉才能精通该专精：高效的维持性施法，以及[[spell:207383]]循环。 **请注意，我们的循环在丛林守护者和荒野追猎者之间没有实质性变化。你接下来读到的一切都适用于两者。**

1.2.

#### 维持性施法

尽量在整场战斗中始终遵循此列表。这些大多是高效的施法，通常只需更可靠地完成本节中的所有事项就能大幅提升你的治疗量。

- 在自己身上保持[[spell:33763]]。我们给自己施放是因为我们会在自己身上叠加治疗增益，这意味着我们的巅峰治疗（[[spell:1244331]]）也会更大。你还应该在自己身上保持1-2个[[spell:774]]来触发[[spell:274902]]。
- 在一组玩家下方保持[[spell:145205]]。由于[[spell:1217941]]天赋，我们的[[spell:145205]]会跟随我们[[spell:33763]]的目标（那就是我们自己！）
- 在冷却好时对自己施放[[spell:18562]]，然后接上[[spell:774]]。由于[[spell:392302]]天赋，这将给3个目标施加[[spell:774]]。自我施放还会附加一个强大的[[spell:439530]]持续治疗效果，使我们受到的治疗量提高20%，从而使我们的巅峰治疗也提高同样的幅度。
- 在高压伤害期间施放[[spell:48438]]。它非常消耗法力，将是你主要花费法力的技能。如果你经常法力不足，就少放一些[[spell:48438]]。

1.3.

#### 丰饶

[[spell:207383]]天赋会在你的队伍或团队身上有5个[[spell:774]]增益时，大幅提高[[spell:8936]]的暴击几率并降低其法力消耗。该天赋鼓励你始终保持5个活跃效果，以便随后利用强大且廉价的[[spell:8936]]施放。[[spell:392302]]也可以帮你解决大量[[spell:774]]数量的问题。

我们还有两种（及半种）不同的方式来延长我们的持续治疗效果，从而打开一个更长的窗口期，让我们可以连续施放[[spell:8936]]：

- [[spell:740]]将所有持续治疗效果延长10秒（通过[[spell:197721]]天赋）。
- [[spell:391528]]有45%的几率将所有持续治疗效果延长2秒（通过[[spell:197721]]天赋）。

**你本赛季的循环将以[[spell:8936]]为核心。** 特别注意不要施放超出需要的[[spell:774]]。如果战斗需要大量移动，那么预计需要更多手动施放[[spell:774]]，这将让你把更多[[spell:158478]]触发效果用在[[spell:8936]]上。

1.4.

#### 额外技能

除了上面的核心循环外，你还可以使用一些具有各种功能的额外技能。我们将在此介绍它们各自的作用。我们还有许多非常强大的冷却技能，你可以在本页下方了解更多。

- [[spell:29166]]：恢复你最大法力值的25%。在法力值约75%时施放第一次，并尽量在整场战斗中最大化施放次数。
- [[spell:102342]]：使目标受到的伤害降低20%。养成经常使用的习惯，因为它的冷却时间相当短，且不占用全局冷却。
- [[spell:1126]]：这是我们的“团队增益”，非常强大。在每次首领战前施放它。
- [[spell:106898]]：群体移动速度增益，你可能在特定的首领机制中使用。
- [[spell:22812]]：你的个人防御技能。冷却时间很短，所以当你处于危险中时随时使用。
- [[spell:20484]]：战斗复活技能。战斗复活使用共享次数池，并会在首领战期间随时间恢复。

:::details 常见问题：我有法力问题。如何解决？
确保你没有在没有

[[spell:8936]]

活跃的情况下

[[spell:207383]]

施放。你可以调整施放的

[[spell:5176]]

数量，而不是治疗法术，如果你需要更多法力，但大多数法力问题是由过少的

[[spell:8936]]

施放造成的。记得在战斗中尽可能多地施放

[[spell:29166]]

。在承受的伤害较低时

[[spell:48438]]

少放一些。

:::

### 地下城治疗

1.5.

#### 恢复德鲁伊地下城治疗

地下城包含两种主要类型的伤害：不可避免的和可避免的。你在每一层钥匙中都会遇到前者，而一旦你掌握了首领战，就可以轻松重复。后者来自于玩家被机制击中、打断失败等等。它会因地下城而有很大差异。你需要处理地下城中所有不可避免的伤害，并对可避免的伤害尽力而为。

1.6.

#### 维持性施法

与团本类似，你会有一些需要始终维持的维持性施法。作为新手，即使当时伤害不高也应该执行这些操作，然后当你对地下城非常熟悉后，就可以开始减少施法。

- 在尽可能多的玩家身上保持[[spell:145205]]。如果你有[[spell:1217941]]天赋，它会自动跟随你[[spell:33763]]的目标。
- 在坦克或承受大量伤害的玩家身上保持[[spell:33763]]。如果坦克不在队伍附近，而你正在使用[[spell:1217941]]，那么把它放在更靠中心的玩家身上，这样你就不会损失[[spell:145205]]的价值。记住，该玩家将通过[[spell:392167]]获得大量治疗。
- 在冷却好时施放[[spell:18562]]，如果队伍血量健康则接上[[spell:774]]，如果他们难以存活则接上[[spell:8936]]。选择在于为后续做好铺垫，还是现在就获得更多治疗 **现在**无论哪种方式，你都会触发你的[[spell:1244470]]天赋，并为所有队友恢复大量生命值。
- 卡着冷却时间施放[[spell:48438]]，以应对轻度到中度的团队伤害。
- 当没有人受伤，且你预计这种情况短期内不会改变时，你可以施放输出法术来加快副本进度。我们将在“输出循环”标签中介绍这一点，因为我们在如何操作上有几种选择。

1.7.

#### 应对危险的范围伤害

上面的维持循环将处理你约75%的副本流程。剩下的25%中，你将面临对全队的危险范围伤害和对单个目标的爆发伤害的混合情况。

- 确保在伤害到来之前，[[spell:33763]]和[[spell:145205]]已经生效。
- 提前为伤害做准备，对团队中的输出职业施放[[spell:774]]。你希望在所有危险伤害期间有五个回春术激活，以获得[[spell:207383]]增益效果。
- 在伤害到来时施放[[spell:18562]] -> [[spell:8936]]。你的[[spell:8936]]将命中三个目标。
- 继续施放更多[[spell:8936]]，直到危险过去。

这些范围伤害检查点大多内置在副本中，并会在固定时间发生，你可以预测并提前准备。

1.8.

#### 应对危险的单体目标伤害

单体目标伤害有几种形式。它可能是一个需要你在5-10秒内治疗的危险持续伤害效果，也可能是一次漏打断导致某人瞬间损失80%生命值。我们对两者的应对方式会略有不同。

- 如果伤害是爆发性且瞬时的，那么对目标施放[[spell:8936]]。如果可用，这是一个将施法与[[spell:132158]]配合使用的绝佳时机。继续施放[[spell:8936]]，直到他们安全为止。
- 对于半危险的持续伤害效果，你应该在开始施放[[spell:8936]]之前，对目标施放1-2个[[spell:774]]。如果伤害非常危险，还要将[[spell:33763]]转移过去。拥有[[spell:33763]]的目标要安全得多，几乎不死。这对于提前预告目标的机制特别有用——因为这给了你更多的准备时间，转移[[spell:33763]]也变得更容易。

关于在大秘境中法术使用的更具体信息，请查看我们的恢复德鲁伊大秘境页面：

### 输出

1.9.

#### 如何作为恢复德鲁伊进行输出

作为恢复德鲁伊，你有两种增加伤害的选择：施法形态的法术如[[spell:5176]]，或者切换到[[spell:768]]并使用近战技能。后者更高级，通常伤害更高，尽管目前并非如此。无论你如何输出，在施放[[spell:319454]]时，你仍应进入猎豹形态。

**你首先是一名治疗者，你的伤害优先级非常低** 不做这些也完全可以，但至少要施放[[spell:5176]]，因为养成将多余的公共冷却时间用于有价值的事情的习惯是好的。

1.10.

#### 如何在施法形态下输出

大多数玩家觉得在施法形态下输出比猎豹形态更容易，而且目前它的平衡性非常好。

- **单体目标：** 卡着冷却时间施放[[spell:78674]]，然后施放[[spell:5176]]。如果[[spell:78674]]在冷却中，你可以在移动时施放[[spell:8921]]。
- **范围伤害：** 施放[[spell:194153]]。如果你在移动，可以施放[[spell:93402]]。

1.11.

#### 如何进行猫闪

在为猫闪设置快捷键时，你应该在施法形态的快捷栏上为[[spell:1822]]找到一个键位，如果可能的话，也为[[spell:5221]]找一个。我们将选择[[spell:449193]]天赋，它会在我们施放这些技能时自动将我们切换到[[spell:768]]——为我们节省一个公共冷却时间，并大大改善猫闪的体验。

- （可选）在开怪前[[spell:5215]]。它会增加你下一个技能的伤害。
- 对怪群中最大的敌人施放[[spell:1822]]，以进入[[spell:768]]并施加一个强力的持续伤害效果。
- 如果你有五个连击点数，则施放[[spell:1079]]，否则切换目标施加[[spell:1822]]。
- 如果怪群中所有敌人都有[[spell:1822]]，则使用[[spell:5221]]（1-2个目标）或[[spell:213764]]（3个以上目标）。请注意，你的大部分伤害将来自上面的流血效果。
- 如果你在与单个目标战斗，并且它身上已经有一个新鲜的[[spell:1079]]，则施放[[spell:22568]]。
- 你也可以在[[spell:768]]形态下使用[[spell:391528]]，使其主要施放伤害法术。如果其他事情不多，这是一个相当好的主意。

猫闪一开始可能会让人感到害怕，但你会很快习惯的。

1.

### 至暗之夜 第2赛季套装

我们第二赛季的套装提供以下加成：

- **两件套加成：** [[spell:774]]有15%的几率获得[[spell:1302255]]，使所有持续治疗效果在8秒内治疗量提高15%。可叠加。
- **四件套加成：** [[spell:1302255]]持续时间延长8秒。[[spell:132158]]、[[spell:740]]、[[spell:391528]]和[[spell:33891]]有100%的几率获得它。

我们的套装对游戏风格没有很大影响，但它确实奖励我们经常使用我们的大型冷却技能。

1.

### 职业与专精机制详解

为了更好地解释恢复德鲁伊技能包的具体用法和好处，我们编写了关于我们循环各个部分的更详细说明，包括你需要注意的重要循环机制、如何使用我们的主要冷却技能等等！

### 巅峰：永茂

3.1.

#### 巅峰：永茂

巅峰天赋是至暗之夜中的新内容。它们是一种特殊的专精天赋，你最多可以投入四点。我们的叫做[[spell:392167]]，它专注于增强[[spell:33763]]。

在该节点投入点数将解锁以下好处：

- 第一点：你的[[spell:33763]]最多可叠加3次，每5秒自动叠加一次。
- 第二和第三点：你的[[spell:33763]]的“绽放”治疗量将溅射20%/40%给最多6名附近的盟友。
- 第四点：当你按下[[spell:18562]]时，你的[[spell:33763]]会快速连续绽放3次。

我们的巅峰节点非常强大，为一个目标提供近乎不死的能力，并为团队其余成员提供非常体面的溅射治疗。它非常值得投入，你甚至会选择像[[spell:274902]]这样具有协同效应的天赋来进一步增强它。

### 精通

3.2.

#### 精通

你的精通，[[spell:77495]]，会根据你在施法时目标身上的持续治疗效果数量来增加你对该目标的治疗量。每个持续治疗效果的治疗量会在你施加另一个时立即动态更新，并且从你的第一个持续治疗效果开始计算。以20%精通为例，单个[[spell:774]]将多治疗20%。持续治疗效果越多，精通的价值就越低。第二个持续治疗效果只提供70%，第三个60%，第四个50%，以此类推。无论如何，你平均拥有的持续治疗效果越多，精通就越好。

目前有7种持续治疗效果计入我们的精通：

- [[spell:774]]
- [[spell:155675]]
- [[spell:48438]]
- [[spell:8936]]的持续治疗部分
- [[spell:33763]]
- [[spell:22842]]
- [[spell:439530]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者持续治疗效果）

需要注意的是，此列表是详尽无遗的。没有饰品效果与精通互动、贡献或以其他方式从中受益。

### 大流行

3.3.

#### 大流行

“大流行”是玩家对一种游戏内机制的称呼，即对已经拥有某个持续治疗效果的玩家施放该效果，会同时刷新其持续时间并将部分剩余持续时间添加到新的持续治疗效果中。一般规则是你可以添加最多相当于原持续治疗效果持续时间30%的时长。

1.

### 恢复德鲁伊的重要冷却技能

### 宁静

4.1.

#### 宁静

[[spell:740]]应在团队承受大量伤害时或被团队领袖指派使用时使用。[[spell:740]]将团队中所有持续治疗效果的持续时间大幅延长10秒，这意味着它最好在每场战斗最危险的时刻使用。我们在上面简要提到了这一点，但围绕[[spell:740]]的循环大致如下：

![Tranquility Ramp](<https://static.icy-veins.com/images/wow/classes/druid/restoration/RestoTranqRamp.webp>)

你需要施放多个[[spell:774]]增益效果、一个[[spell:48438]]和几个[[spell:8936]]持续治疗效果，以最大化[[spell:740]]延长效果的价值。这能实现一个非常长的[[spell:207383]]窗口，而持久的[[spell:774]]持续治疗效果将通过[[spell:1263879]]天赋，使我们从后续的[[spell:8936]]施放中获得更多价值。

这个我们称之为[[spell:740]]“预铺”的流程是游戏中最强大的治疗冷却技能之一。最好在每场战斗前计划好它的使用，因为正如你所见，如果你能在按下它之前施放很多法术，它的效果会强大得多。

在大秘境等内容中，[[spell:740]]同样强大，你可以保持与上面预铺相同的概念，但过程会更快。你只需尽可能多地施放[[spell:774]]，但数量会接近5-6个，而不是你在团队副本中可以瞄准的12个以上。[[spell:740]]的治疗本身在副本内容中也更加强力。

### 万灵之召

4.2.

#### 万灵之召

[[spell:391528]]是一个冷却时间很短的强大治疗冷却技能。它在3-4秒内施放随机的德鲁伊法术。它施放的法术大多是随机的，但在施放多少治疗和伤害法术上有一些逻辑。如果你拥有[[spell:393371]]天赋（Icy Veins 构建中的默认选择），大约50%的施放会包含一个迷你[[spell:740]]。

你通常也会获得0-2次[[spell:48438]]施放、2-4次[[spell:18562]]和几个[[spell:774]]。它通常会施放2-4次[[spell:5176]]，这些可以触发相关天赋，如[[spell:289237]]。

[[spell:391528]]应在每场战斗最危险的时刻频繁使用。

### 化身：生命之树

4.3.

#### 化身：生命之树

[[spell:33891]]是[[spell:391528]]的选择节点替代方案。它专注于在更长的时间内进行治疗。它对于团队副本中较长的治疗阶段很有用，比如战斗结束附近30秒的爆发阶段。它的冷却时间比[[spell:391528]]长，但总体覆盖率非常高（60-70%）。

![Incarnation: Tree of Life](<https://static.icy-veins.com/images/wow/classes/druid/restoration/DruidTreeForm.webp>)

当[[spell:33891]]激活时，你将获得以下加成 <em>激活</em>:

- 你所有的治疗效果增强10%。
- [[spell:48438]]额外治疗2个目标。
- [[spell:8936]]施法时间缩短至0（但它仍然消耗你一个公共冷却时间）。
- [[spell:5176]]的伤害提高20%。

在[[spell:33891]]激活期间，你的[[spell:774]]施放成本极低，且非常强大。[[spell:48438]]也成为一个优先级更高的法术。它的另一个好处是让你能够在移动中施放[[spell:8936]]。对于超高移动战来说，它是一个强力的选择。

### 激活

4.4.

#### 激活

[[spell:29166]]在3分钟的冷却时间内恢复你25%的法力值。它可以施放在自己或其他治疗专精身上，不过，我建议在大多数情况下对自己施放。你应该在战斗中尽可能频繁地使用[[spell:29166]]，从大约75%法力值时开始。

### 自然迅捷

4.5.

#### 自然迅捷

[[spell:132158]]使你的下一个[[spell:8936]]变为瞬发并增加其治疗量。你主要会在人们生命值低时使用它来拯救他们。

### 铁木树皮

4.6.

#### 铁木树皮

[[spell:102342]]使目标在12秒内受到的伤害降低20%。你应该对任何即将承受大量伤害的人使用它。它可用的频率很高，所以你通常最好频繁使用它，而不是为特殊场合节省它。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年8月31日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月24日：** 更改了团队副本的输出循环推荐。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月29日：** 小修复。
- **2022年12月11日：** 对大秘境输出循环和套装建议进行了小幅更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面中，你将找到魔兽世界12.1.5版本中你的恢复德鲁伊的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们都为你准备好了！

1.

### 恢复德鲁伊毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级。更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

:::details ![](<https://static.icy-veins.com/images/wow/tools/recommended.png>) **小心早期制造！**
请务必回来查看此警告是否已被移除。

:::

### 总体

此列表包含你在游戏中所有内容（包括团队副本、地下城等）中的理论毕业装备。毕业列表对于寻找目标装备很有用，但请使用 [QE Live](<https://questionablyepic.com/live>) 来确定你实际应该装备哪些现有物品。

除了下面的列表外，你还将装备两件带有特殊“美化”效果的制造物品。你佩戴哪些美化以及将它们放在哪些制造部件上，取决于你当前所处的装备阶段，因此我们将在下面的制造部分深入介绍。 **下面列表中的制造物品不一定是你应该首先制造的。**

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，你可以将任何物品转化为套装部件，并且它将保留其原始属性和效果！这意味着我们将寻找一些非常特定的部件来催化——主要是急速/精通物品。

- **头部：** [[item:271875]]（关键物品）
- **肩部：**  没有好的选择。不要催化。这是你的散件，你将在这里制造。
- **胸部：** [[item:268235]]
- **手部：** 穿戴普通套装部件。如果你无法获得普通部件，[[item:159337]]也可以。
- **腿部：** [[item:268225]]（关键物品）

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:244572@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAGAAAD2cbNRDD]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含你仅来自地下城内容的理论毕业装备。毕业列表对于寻找目标装备很有用，但请使用 [QE Live](<https://questionablyepic.com/live>) 来确定你实际应该装备哪些物品。

除了下面的列表外，你还将装备两件带有特殊“美化”效果的制造物品。你佩戴哪些美化以及将它们放在哪些制造部件上，取决于你当前所处的装备阶段，因此我们将在下面的制造部分深入介绍。 **下面列表中的制造物品不一定是你应该首先制造的。**

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，你可以将任何物品转化为套装部件，并且它将保留其原始属性和效果！这意味着我们将寻找一些非常特定的部件来催化——主要是急速/精通物品。不幸的是，本赛季最好的物品掉落于团队副本中，不过即使是英雄难度的团队副本也足以获得神话级别的奇物装备。下面的列表适用于你完全不打算打团队副本的情况。

- **头部：** [[item:251140]].
- **肩部：**  没有好的选择。不要催化。这是你的散件，你将在这里制造。
- **胸部：** [[item:251159]].
- **手部：** [[item:159337]].
- **腿部：** [[item:159313]].

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：你的毕业戒指掉落于此（[[item:252258]]）。
- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：这里会掉落一件属性优秀的双手武器，这在赛季初期是必备的（[[item:251156]]）。
- [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：强力的前期饰品（[[item:250214]]），不错的腿甲和披风。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:159317@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:159304@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>护腕</th><td>[[item:251183@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:159636@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

此列表包含你仅从团队副本内容中获得的理论最佳装备（BiS）。最佳装备列表有助于确定目标装备，但请使用 [QE Live](<https://questionablyepic.com/live>) 来确定你实际应该装备哪些物品。

除了下面的列表外，你还将装备两件带有特殊“美化”效果的制造物品。你佩戴哪些美化以及将它们放在哪些制造部件上，取决于你当前所处的装备阶段，因此我们将在下面的制造部分深入介绍。 **下面列表中的制造物品不一定是你应该首先制造的。**

:::details 常见问题我需要哪些套装部件？
在至暗之夜第二赛季中，你可以将任何物品转化为套装部件，并且它将保留其原始属性和效果！这意味着我们将寻找一些非常特定的部件来催化——主要是急速/精通物品。

- **头部：** [[item:271875]]（关键物品）
- **肩部：**  没有好的选择。不要催化。这是你的散件，你将在这里制造。
- **胸部：** [[item:268235]]
- **手部：** 穿戴普通套装部件。如果你无法获得普通部件，[[item:159337]]也可以。
- **腿部：** [[item:268225]]（关键物品）

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:244572@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:240949@JAAGAAAD2cbNRDD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">珠宝加工</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAGAAAD2cbNRDD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 饰品推荐：恢复 德鲁伊

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **恢复 德鲁伊 BiS 饰品**
**毕业装备 -**

[[item:270162]]

和

[[item:270167]]

.

**荣誉提名 - [[item:270164]]**

.

:::

如需直接对比饰品，我们建议使用
[QELive](<https://questionablyepic.com/live/>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 恢复 德鲁伊 饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]]</li>&#10;<li>[[item:280835]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:251792]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:250255]]</li>&#10;<li>[[item:270171]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250254]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:264507]]</li>&#10;<li>[[item:264701]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>F- 级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193748@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

总体而言，有相当多的饰品强度相近。同一层级中的任何饰品彼此之间大致相当。这意味着饰品的物品等级相当重要。F 级饰品之所以在此，是因为它们只比空饰品栏位好一点。

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可用于从特定首领或副本获取特定物品，通过让你从特定掉落位置获得一件保证的战利品。获得的物品是随机的，但一旦通过这种方式获得了一件物品，你下一次使用虚空核心将获得你尚未获得的剩余物品之一。

**请注意，通过掉落或大秘库获得某件物品并不会将其从你的额外拾取池中移除。**

3.1.

#### 推荐的朦胧虚空核心使用方式：恢复 德鲁伊

对于你的虚空核心和制造，你可以采取几种不同的路线。这些主要是赛季初期的问题，如果你在赛季后期才选择这个专精，那么你在两者的选择上都会有更大的自由度。 **在赛季初期对大秘境使用额外奖励次数是一个巨大的战力损失。**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **团队副本虚空核心优先级**
- **理想情况：** 英雄难度 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 直到你获得 [[item:271875]] 和 [[item:271092]]。
- **次优选择：** 史诗难度 [盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 直到你获得 [[item:268235]] 和 [[item:270162]]。
- **然后：** 填补你尚未拥有神话级追踪物品的栏位。你可以使用 QE Live 来获取每个首领和地下城的平均额外拾取价值。

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **大秘境虚空核心优先级**
- [夺目谷](<https://www.wowhead.com/achievement=61641>) - [[item:250214]]（好），[[item:251190]]（好）。
- [虚空之痕竞技场](<https://www.wowhead.com/achievement=61508>) - [[item:252258]]（毕业装备）

:::

3.1.1.

##### 理解额外拾取策略

恢复 德鲁伊 在额外拾取方面处境艰难，因为两件物品 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 的掉落好得离谱，而第三个选择（[[item:268265]]）只是还可以。然而，在对该首领进行三次额外拾取后，我们保证能获得全部三件物品。

如果你提前通过额外拾取获得了两件物品，那么可以跳过第三件。三分之一的玩家会如此幸运。

:::details 常见问题解答：如果我在前几周无法击杀英雄难度的尤塔泰克怎么办？
如果你预计能击杀该首领但可能需要额外一两周，那么请继续执行上述策略。你每周可以对同一首领进行多次额外拾取，因此能够很快赶上进度。如果你对团队副本没有兴趣，或者永远不会打通英雄难度，那么请转到上面的地下城列表。希望在未来的赛季中，装备获取不会如此复杂和棘手。

:::

3.2.

#### 晋升毒液石

[[item:280562]] 的优先级与你的纹章类似：

1. 你的武器是最高优先级
2. 如果你使用单手武器，副手是接下来最重要的部位。
3. 如果你拥有上面列表中的 S 级饰品，请在项链之前升级它。
4. 项链

优先选择神话级追踪物品而非英雄级追踪物品，除非你预计无法获得神话级追踪物品。升华之毒石对来自史诗盘绕祭坛和尤拉泰克的 344 物品等级装备无效。

1.

### 恢复德鲁伊最佳专业制造装备

制造是获取高物品等级装备的重要途径。你每两周可以制造一件物品。通常你需要非常谨慎地选择制造什么。你还可以在两件制造的物品上附加“美化”。它们各自提供约 1% 的治疗效果。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **恢复 制造装备优先级**
- [[item:245769]] 搭配 [[item:245876]]。
- [[item:244572]] 或 [[item:244569]] 搭配 [[item:240167]]。
- 任何你尚未获得神话级的物品。

:::

- 如果你在前几个团队副本首领处获得了神话级追踪副手，那么可以跳过那一步。
- 皮甲两件套美化套装效果不好，请避免使用。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 恢复 德鲁伊 最佳美化

你的两件制造装备中最多可以有两件被 **美化**。美化为你的物品添加特殊效果，一旦你步入正轨，你会希望拥有两个美化。

由于你只能选择两个，因此选择正确的美化很重要，因为有些美化效果相当差。这方面最好的两个选择是：

- [[item:240167]] 附在两个护甲栏位上。

建议使用 QE Live 来找出最适合你特定装备组合的选择，如果你还玩其他 德鲁伊 专精，你可能希望选择对所有专精都适用的美化。

4.2.

#### 为装备添加插槽

你可以使用 [[item:275707]] 消耗品为头盔、腰带和护腕添加插槽，你可以在大秘库物品之外选择该物品。在赛季后期之前，你通常不会拥有这些物品，因为选择一件装备或一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>).

1.

### 纹章使用

在角色装备获取的早期阶段，你能获得的纹章有限，这些纹章可以 [ 提升你装备的等级](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) （例如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)）。由于纹章每周有限，且升级不同物品消耗的纹章数量相同，因此你应优先将纹章用于属性加成最高且短期内不会更换的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **恢复 德鲁伊 纹章升级优先级**
**武器栏位**

➜

**特效栏位**

➜

**头盔/胸甲/腿甲**

➜

**饰品**

➜

**肩部/手套/腰带/靴子**

➜

**其余部位**

:::

最终你将能够升级所有物品，此优先级顺序仅适用于纹章有限时。

1.

### 评估升级

在本页面和我们指南的其他地方，我们经常提到在 QE Live 上进行自我模拟的重要性。这是因为每个角色都是独一无二的，你能获得的每件装备都可能改变你现在最适合的装备搭配。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本的改动进行更新。
- **2025年8月20日：** 已更新饰品推荐。
- **2025年8月6日：** 更新了一些装备推荐。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月16日：** 更改了团队副本饰品推荐。
- **2025年2月25日：** 更新了饰品排名。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月14日：** 更新了大秘境、装饰和饰品推荐。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月20日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 在饰品列表中添加了希望之光，并针对10.2.5版本进行了更新。
- **2023年11月26日：** 更新了毕业装备列表和团队副本饰品推荐。
- **2023年11月11日：** 更新了阿梅达希尔的装备推荐。
- **2023年11月7日：** 更新了装饰和饰品推荐。
- **2023年11月6日：** 已针对10.2版本进行更新
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月12日：** 已更新饰品推荐。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月7日：** 已更新饰品推荐。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月24日：** 更新了奥妮克希亚的纪念指环推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 已根据专业制造推荐和套装分析进行更新。
- **2022年12月11日：** 已根据化身密库和大秘境掉落进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将找到 恢复 德鲁伊 的最佳属性优先级。我们首先展示属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已针对《魔兽世界》12.1.5 补丁进行更新。

1.

### 恢复德鲁伊属性优先级

恢复 德鲁伊 的属性优先级取决于你计划在团队副本还是地下城环境中进行治疗，不过同一套装备在两种环境中都相当有效。

属性价值会根据你的装备、你正在进行的内容以及你的法术选择而变化。没有通用的权重。每次你更换一件装备，它们都会改变。

话虽如此，物品等级提升很少会不是真正的提升。插槽通常价值约10个物品等级，前2-3件装备上的吸血价值约6个物品等级，闪避价值约5个。

1.1.

#### 团队治疗

你的属性优先级看起来会像这样。

智力

急速

精通

全能

暴击

:::details 常见问题解答：有急速上限吗？
通常不建议超过第二个递减断点，因为你会开始损失太多属性。你可以使用

[Questionably Epic Live](<https://questionablyepic.com/>)

应用来围绕断点微调你的属性。现代游戏中没有急速断点。

:::

:::details 常见问题解答：为什么暴击对 恢复 德鲁伊 是如此糟糕的属性？
不推荐暴击，因为

[[spell:8936]]

由于已经具有非常高的暴击几率

[[spell:207383]]

，已经拥有非常高的暴击几率，这意味着其他每个属性都能为你提供更高的整体价值。

:::

1.2.

#### 地下城治疗

你可以在团队副本和地下城内容中穿戴大致相同的装备。精通价值在地下城中更高，因为你可以对每个玩家拥有更多的持续治疗效果，但急速仍然非常好。在非常高的大秘境层数中，玩家可能会装备一定量的全能来提高生存能力和承受严重爆发伤害的能力——但所需的数量因地下城而异，且仅与世界上正在进行的最高层数相关。

智力

精通

急速

全能

暴击

1.

### 深入属性解析

**智力** 是你的主要属性。你应该在所有升级中寻找此属性。它为你提供法术强度，从而增强你的治疗效果。

**急速** 减少你的法术施法时间，通过使持续治疗效果跳动更快来增加其治疗量，并减少全局冷却时间。

**精通** （[[spell:77495]]）会根据你拥有的每个活跃持续治疗效果（由你的精通等级决定）增加你对受其影响目标的治疗量。第一个持续治疗效果获得全额收益，随后的持续治疗效果收益递减。

**暴击** 增加你所有法术和技能的暴击几率。暴击默认造成双倍治疗，但有几种效果可以增加你的暴击治疗量。

**全能** 增加你造成的所有伤害和治疗，并减少你受到的所有伤害。

2.1.

#### 次要属性的递减收益

所有次要属性（暴击、急速、精通、全能）都具有
**递减收益**。在达到特定的等级值后，你将因进一步获取等级而受到惩罚。不同属性的惩罚不同，且仅影响以原始等级表示的收益。

因此，像 [[spell:32182]] / [[spell:2825]]、[[spell:10060]]、[[spell:378988]] 之类的效果不会计入递减收益。[[spell:378988]] 是一个重要的例子，因为我们在所有天赋中都会使用它，而且它对你的急速是乘法提升。其他一些职业会在30%时开始出现递减收益，但 恢复 德鲁伊 需要注意属性等级。不同属性的断点如下：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">-10%</th>&#10;<th style="text-align: left">-20%</th>&#10;<th style="text-align: left">-30%</th>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>暴击与精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为地心之战第1赛季进行审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 更新了10.1.0版本的吸血数值。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的 恢复 德鲁伊 能获得的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你可以在你的装备中镶嵌一颗 **永歌钻石** 。它提供智力，有时还会提供一个不太重要的次要效果。四种可能的选项是：

- [[item:240967]]（暴击效果）
- [[item:240970]]（护甲）
- [[item:240968]]（最大法力值）
- [[item:240983]]（无效果，更多智力）

暴击效果宝石对治疗只提供一半的收益；最大法力值没有用处，因为我们完全没有法力值缩放。因此，我们推荐使用 [[item:240983]]。

对于其他宝石插槽，你可以在每个插槽中镶嵌我们首选的宝石，因为镶嵌唯一宝石类型不会带来任何额外收益。因此，每个插槽都镶嵌 [[item:240892]]（急速/精通）。

1.

### 最佳附魔和武器强化

确保在所有内容中都为你的武器附上 [[item:243733]]。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;[[item:243951]]&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:244021]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240155]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:243983]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243959]]</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:244029]]</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

- **团队副本：** [[item:241325]]
- **大秘境：** [[item:241322]]

3.2.

#### 药水

你还将使用 [[item:241288]] 作为你的默认药水。目前法力药水非常弱，而爆发性治疗冷却技能也比以前的资料片弱，因此建议使用属性药水，将其与你的冷却技能配合使用，以更好地应对战斗中最困难的部分。

对于治疗药水，使用 [[item:271883]] - **这是12.1版本的新内容！**。另外，别忘了设置快捷键并使用 [[item:5512]]。每次战斗你都可以使用一个。

3.3.

#### 食物增益

不同的智力盛宴选择都非常好（[[item:255845]]、[[item:242272]]、[[item:255846]]）。如果没有盛宴可用，[[item:255847]]是一个不错的个人食物选择。次要属性食物选项不可行。

3.4.

#### 强化符文

[[item:259085]]是唯一值得一提的其他消耗品。尽可能使用它以获得额外属性，尽管它们可能很贵。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月29日：** 小幅更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月20日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月24日：** 更新了奥妮克希亚的纪念指环推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月29日：** 调整了一些附魔和消耗品建议。
- **2022年12月12日：** 修正了食物和宝石建议。
- **2022年12月11日：** 添加了鞋子附魔建议。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，您将找到在《魔兽世界》12.1.5补丁中使用恢复德鲁伊挑战大秘境地下城的提示和建议。

1.

### 恢复德鲁伊在至暗之夜第2赛季大秘境中的表现

恢复德鲁伊拥有足够的治疗量来应对几乎任何治疗情况，具备良好的控制能力，以及游戏中最好的坦克减伤技能之一。恢复德鲁伊擅长稳定的群体治疗、爆发性的单体治疗，以及高伤害输出（作为治疗专精而言）。

如果你对史诗钥石地下城及其相关的一般机制不熟悉，可以在下方的专用史诗钥石页面阅读更多信息。

1.

### 最佳大秘境天赋配置

两个英雄天赋树的实力比上个资料片接近得多，虽然我们下面会推荐荒野追猎者，但你可以自由选择其中任何一个。请注意 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者 **非** 并不要求你在猎豹形态（或“猫形态输出”）中输出伤害。它是以其治疗能力而被使用的。同样，如果你想在施法者形态下输出伤害，你也不必是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者.

专精天赋树中推荐的构筑围绕[[spell:33763]]和[[spell:8936]]展开。这两个技能及其后续效果将占你治疗量的很大一部分，但请准备好使用所有技能。

### 大秘境最优构筑   ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者

2.1.

#### 推荐 - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者主要推荐用于治疗目的。如果你不关心伤害，你仍然会选择这个英雄天赋树。

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8AMzsNjFbzAAAAAAAAAAgFDNbzw0MAmFzMzMLGGAAAAAMAAzAAAAAgZbmtmtZWsxMzMDmZD0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-KKNkzCGMVWy2ANXXZBQU8grLVVTzTY4JabM-FGHWWHCVq08ARmC4QN+07DZ6l2WXVJO-AAAA-BEIeEpJ4gRiCmF-
```

:::

### 备选大秘境构筑   ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者

2.2.

#### 备选 - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 丛林守护者天赋

我们不推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) 对大多数玩家来说都不推荐选择丛林守护者，因为它的治疗量少得多，而玩法上的差异也很小。但是，如果你更喜欢这个英雄天赋背后的主题，你就需要确保使用下面的构筑。

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8AMzsNjFbzAAAAAAAAAAgFDNbzw0MAmFzMzMLGGAAAAAMAAzA22GLYamZZAAAAswMzMDmZD0MAYmBAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-KKNkzCGMVWy2ANXXZBQU8grLVVTzTY4JabM-FGHWWHCVq08ARmC4QN+07DZ6l2WXVJO-AAAA-EGQYcgkQpBYQmF-
```

:::

1.

### 大秘境深度输出循环提示

虽然在大秘境内容中没有必须遵循的固定循环，但了解哪些法术施放效率最高或治疗量最大是很重要的，这样你才能做出更明智的决策。

1. 保持[[spell:145205]]覆盖。这是一个强大而高效的治疗来源，并且是[[spell:392325]]所必需的。如果你有[[spell:1217941]]天赋，那么保持[[spell:33763]]激活就能为你做到这一点。
2. 默认情况下将[[spell:33763]]保持在坦克身上。如果你有[[spell:1217941]]，当坦克站得太远时，考虑将其保持在自己或远程输出玩家身上。
3. 配合[[spell:404521]]天赋使用[[spell:8936]]来施加三个愈合持续治疗效果。
4. 使用[[spell:18562]]来激活[[spell:158478]]和[[spell:102693]]。如果队伍受到轻度伤害或即将受到伤害，施放后接[[spell:774]]；如果团队需要立即治疗，则接[[spell:8936]]。
5. 经常使用[[spell:48438]]，因为它能触发多个天赋并处理轻度到中度的群体伤害。
6. 将[[spell:774]]保持在活跃的坦克和任何有减益效果的玩家身上。避免施放过多不必要的回春术。很多小伤害可以通过你的群体治疗被动恢复，甚至玩家可以自己恢复。
7. 使用[[spell:8936]]来清理任何伤害或应对危险的群体或单体治疗挑战。

如果你看优先级，你应该注意到[[spell:774]]和[[spell:8936]]排得有多靠后。在大多数情况下，你的第一反应应该是使用更高效的治疗法术，它们列在最上面。一旦它们都在冷却中，你可以回到回春术和愈合。

在治疗间隙，你应该积极寻找机会输出尽可能多的伤害。这个输出循环可能很复杂，难以完全掌握，但你仍然应该学习哪些法术优先使用，以便更顺利地完成更多钥石。我们在循环页面中对此进行了详细介绍。

1.

### 功能技能与能力

恢复德鲁伊为团队提供的不仅仅是治疗。由于地下城内容的性质，你将被期望同时进行输出、控制和治疗。

### 打断、昏迷和控制

4.1.

#### 眩晕与"打断"

大多数治疗专精不再拥有打断或“踢”技能，但我们有相当不错的眩晕和其他阻止怪物的手段。[[spell:99]]是我们的“群体控制”。你需要离怪物稍近才能使用它，所以请记住这一点并相应地调整站位。

你可以使用[[spell:132469]]来达到类似效果，但请记住它会位移怪物，并可能将它们推出伤害区域。我们建议尽可能将其与[[spell:102793]]配合使用。

[[spell:2637]]可以让敌方野兽或龙类沉睡最多40秒。任何伤害都会唤醒目标。休眠与[[spell:339]]的作用方式相同，可以在不引到仇恨的情况下阻止地下城中的巡逻怪群。它也可以用来打断NPC的施法，而不会移除目标身上的持续伤害效果。

[[spell:33786]]可以用来让某些敌人在6秒内免疫所有效果。请确保谨慎使用，因为你也会让它们免疫受到伤害，这可能会拖慢你的团队而不是提供帮助。我们很少选择这个天赋。

### 其他功能

4.2.

#### 其他功能

[[spell:2908]]可能是我们群体控制之外最显著的实用技能。它将移除目标的所有激怒效果。

[[spell:106898]]可以让你们的团队在怪群之间移动得更快，或帮助一些较慢的玩家躲避危险的机制。[[spell:288826]]会让你更频繁地使用它。

[[spell:339]]可以用来定身巡逻怪。如果你对队伍中的领头怪施放，整个巡逻队都会停止移动。这在狭窄区域或跳过某些怪群时很有用。

[[spell:102793]]会召唤一个持续10秒的地面区域，使其中的所有敌人减速50%。当敌人第一次试图离开该区域时，还会将他们拉回中心。这是一个极其强大的风筝工具。你可以将乌索尔旋风与[[spell:132469]]配合使用，将多波怪聚在一起，以获得更好的AOE效果。

1.

### 应对词缀

### 词缀：升腾

5.1.

#### 升腾者处理

这个词缀会生成10个NPC（小光球）并开始施法。思路是使用群体控制来打断施法并获得增益。[[spell:99]]或[[spell:132469]]非常适合这个用途。

### 词缀：虚缚

5.2.

#### 虚空束缚处理

这不一定是治疗者的词缀，因为它只是你们团队需要尽快击杀的一个NPC。你至少可以对它施加持续伤害效果，甚至可能使用[[spell:22568]]，但你的输出玩家应该负责处理它。

### 词缀：脉冲星

5.3.

#### 脉冲星处理

每个玩家周围会生成一个持续15秒的旋转光球。当其他玩家接触到这个光球时，他们会获得叠加的精通和吸血增益。如果15秒内没有玩家拾取光球，敌人将根据光球数量获得+10%伤害和+20%伤害减免的增益。相当直接。

### 词缀：吞噬

5.4.

#### 吞噬处理

这个词缀会生成一个裂隙，你必须驱散并治疗掉它。驱散那些无法自行驱散的玩家，或那些没有你的[[spell:33763]]的玩家。这是使用[[spell:158478]]配合[[spell:132158]]和[[spell:8936]]的绝佳时机。

如果你在效果施加时立即驱散，你将能够在接近结束时再驱散一次。记住这一点，不要无谓地治疗你计划驱散的第二个目标。现在也可以通过变形来移除它，这意味着你可以非常轻松地移除自己的效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2.0版本进行更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月23日：** 因套装改动而更改了天赋推荐。
- **2025年3月3日：** 添加了第2赛季推荐和新套装分析。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年8月20日：** 已针对地心之战进行更新。
- **2024年7月20日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月20日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月21日：** 更新了天赋推荐。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7补丁进行更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月29日：** 更改了天赋构建建议。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月30日：** 更改了天赋构建推荐。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你可以找到一些实用的宏和插件，让你在《魔兽世界》12.1.5补丁中游玩恢复德鲁伊时更加轻松。

1.

### 最佳宏

以下列出了游玩恢复德鲁伊时最有用的宏。

1.1.

#### 复生

#### 鼠标悬停：复生

```wow-macro
#showtooltip 复生
/cast [@mouseover,help]复生;复生
```

此宏对你的鼠标悬停目标施放[[spell:20484]]，前提是他们是友方玩家。否则，它会对你的当前目标施放复生。

1.2.

#### 变形形态

#### 熊形态宏

```wow-macro
#showtooltip 熊形态
/cast [noform:1] 熊形态
```

#### 猎豹形态宏

```wow-macro
#showtooltip 猎豹形态
/cast [noform:2] 猎豹形态
```

#### 旅行形态宏

```wow-macro
#showtooltip 旅行形态
/cast [noform:3] 旅行形态
```

#### 树形形态宏

```wow-macro
#showtooltip 化身：生命之树
/cast !化身：生命之树
```

这些宏会将你变形为相应的形态。连按按钮不会让你退出形态。

1.3.

#### 取消形态

#### 取消形态宏

```wow-macro
/cancelform
```

此宏会将你退出当前任何形态。

1.

### 恢复德鲁伊专用宏

以下列出了游玩恢复德鲁伊时，你需要设置的一些更具专精针对性的宏。

2.1.

#### 鼠标悬停宏

除非你使用能执行相同功能的特定插件，否则对于你所有的治疗和实用法术，我们建议你使用鼠标悬停宏，例如：

#### 鼠标悬停宏

```wow-macro
#showtooltip
/cast [@mouseover] 回春术;回春术
```

1.

### 最佳插件

3.1.

#### 团队框架

要成为一名出色的恢复德鲁伊，你需要一种清晰的方式来查看团队的状态，包括你对每个目标施加了哪些持续治疗效果。不幸的是，在12.0版本中，暴风雪禁用了大多数现有的实现方式，现在你需要结合使用多个插件来恢复之前的部分功能。

目前最好的解决方案是选择下面的一个团队框架，并将其与出色的Harreks Advanced Raid Frames插件结合使用，该插件将允许你自定义特定持续治疗效果的显示位置。如果你喜欢默认框架，它也可以与默认框架配合使用。

- [Harreks高级团队框架](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>)
- [Grid 2](<https://www.curseforge.com/wow/addons/grid2>)
- [ElvUI（功能远不止框架）](<https://www.tukui.org/welcome.php>)
- [Ellesmere UI（功能远不止框架）](<https://www.curseforge.com/wow/addons/ellesmereui>)

为了补充你的团队框架，你应该制作如上所示的鼠标悬停宏或安装
[Clicked](<https://www.curseforge.com/wow/addons/clicked>)。另一个类似的选择是 [
Clique](<https://www.curseforge.com/wow/addons/clique>).

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜发布更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已为11.2.0版本进行审查。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月20日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月21日：** 添加了百花齐放 WeakAura。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年4月28日：** 为10.1.0补丁进行了更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
