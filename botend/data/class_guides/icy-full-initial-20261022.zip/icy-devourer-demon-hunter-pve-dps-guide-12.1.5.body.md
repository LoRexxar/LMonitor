## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5 补丁 噬灭 恶魔猎手 指南。在这里，你将学习如何在团队副本和大秘境中玩好 噬灭 恶魔猎手：从入门到最大化你的 DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

噬灭 大秘境资源

[全新！顶级 噬灭 天赋构筑](<https://raider.io/specs/devourer-demon-hunter/talents>)

[顶级 噬灭 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/demon-hunter/devourer>)

[噬灭 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=demon-hunter--devourer>)

[热门 噬灭 队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=demon-hunter--devourer>)

1.

### 噬灭 恶魔猎手 概述

噬灭 在 至暗之夜 中推出，引入了一个中距离 DPS 专精

作为恶魔猎手的第三个选择。它释放虚空强化的法术，造成

宇宙伤害，并吞噬敌人的灵魂。

噬灭 的玩法融合了一种 <em>资源积累与消耗</em> 循环，并在

其变身阶段 [[spell:471306]] 时带有独特的转折。此技能没有

基于计时器的冷却时间，而是通过收集 **灵魂残片**

你的技能产生的资源来进入。噬灭 利用冷却时间较短的技能来积累

做好准备，并获得良好的规划和执行奖励

[[spell:471306]]窗口。它主要作为一个25码施法者

（很像唤魔师），但也融入了一些鼓励进入

近战范围的天赋，为战斗带来独特的节奏。作为 恶魔猎手，它还拥有

丰富的移动工具，并为团队提供 [[spell:255260]] 减益效果以提供

辅助。

1.

### 噬灭 恶魔猎手 表现分析

与任何专精一样，尽管 噬灭 是新的，但它也有一些优势和

劣势。下面我们根据一些关键类别对其进行了评估。

**灵活的伤害**

噬灭 拥有非常强大的伤害构成。在单体战斗中，它能够预热施放大型 [[spell:1221167]] 以利用叠加的顺劈伤害，并且可以调整冷却时间，使其最大的星辰施放与伤害增益重叠。在群体伤害场景中，随着敌人数量的增加，它的伤害扩展性很好，并且可以随时调整冷却时间以适应。不幸的是，本赛季的团队副本并不适合吞噬者的优势，因为它往往无法以适合部分现有战斗的方式运用其分散顺劈和爆发工具。

**伤害强大但构成较弱**

噬灭 带来了强大的伤害构成，其独特能力在于可以根据 <em>时使用</em> 需要调整冷却时间的使用，这非常有价值。除此之外，它还提供 [[spell:255260]]，这是每个团队副本都需要至少一个的。不幸的是，噬灭 并不适合这个团队副本，因为它的分散顺劈、双目标顺劈和短窗口爆发不如其他职业强大。虽然它确实提供了 [[spell:196718]] 和其他实用技能，但 浩劫 处于相对较好的位置，进一步削弱了 噬灭 的地位。

**强力的优先目标和群体伤害**

在大秘境中，噬灭 拥有强大的伤害构成，在拥有强力优先目标伤害的同时能够预热打出大量群体伤害。它的爆发比其他专精低，但每波怪都可以有冷却时间可用，并且随着波次规模和持续时间的增加获得更多伤害。它的伤害虽然没有达到第一赛季的高度，但仍然非常强大。除了其出色的伤害工具包外，它还为团队提供 [[spell:255260]]，使其成为第二赛季大秘境中的绝佳选择。

**多样的实用技能**

噬灭 的实用技能工具包很扎实，带来了各种不同的能力来应对不同情况——特别是 恶魔猎手 团队增益 [[spell:255260]]。在它远程群体眩晕 [[spell:1234195]]、[[spell:207684]] 和 [[spell:217832]] 提供的控制之间，它的控制工具也很稳健。[[spell:196718]] 在危险时刻为团队提供一些防御，同时还有一些根据情况而定的其他实用工具。独特的是，与其他 恶魔猎手 专精相比，它还改进了 [[spell:183752]]，拥有30码的射程，同时保持15秒的冷却时间。

**非常耐打**

与其姊妹专精一样，噬灭 拥有出色的防御能力。拥有 [[spell:198589]] 1分钟的冷却时间和两层充能，可以应对战斗中的大多数致命机制。它还通过 [[spell:389696]]、[[spell:320382]] 和 [[spell:1266497]] 提供被动减伤。除此之外，它拥有被动吸血，并在战斗中持续自我治疗，每消耗一个灵魂碎片恢复1%的生命值，并通过 [[spell:1241937]] 治疗。它唯一真正的弱点是频繁的一击必杀机制，即便如此也只有在耗尽应对手段时才会出现问题。

**卓越的机动性**

与所有 恶魔猎手 专精一样，恶魔猎手 也带来了令人难以置信的移动工具包。这尤其重要，因为它必须在战斗中同时应对近战 <em>和</em> 和远程的战场。[[spell:1234796]] 是它版本的 [[spell:344865]]，提供近乎瞬移的位移到目标位置，最多 **3** 层充能。它还通过 [[spell:320654]]、[[spell:389846]] 和 [[spell:131347]] 拥有大量额外的移动工具。除此之外，它的主要填充技能 [[spell:473662]] 可以在移动中施放，这意味着无论战斗变得多么混乱，它都能始终保持活跃。

1.

### 噬灭 恶魔猎手 在 至暗之夜 中

### **第2赛季**   改动

3.1.

#### 至暗之夜 12.1.5版本内容指南

虽然大多数赛季中期的补丁通常不会带来重大的职业改动，

噬灭 在12.1.5中进行了一次大规模的重做。它专注于更新 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄's

游戏风格，为 [[spell:1221167]] 带来大量生活质量改进，

以及天赋树的重新调整，开启了新的构筑机会！暴风雪

还引入了新的K'ithix团队副本，为

吞噬者带来了三件强力装备，以及新的迷宫巨型地下堡，作为单人

内容玩家的挑战！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### 12.1.5版本改动

主要的改动将来自Kith'ix团队副本遭遇的新物品。最值得注意的是

一件饰品、一个戒指和一件胸甲。此外，你将能够使用

[[item:280562]] 从10月20日开始升级物品。武器、项链和饰品都可以

被升级。

3.3.

#### 职业改动

暴风雪 对 噬灭 进行了大量改动，核心在于解放

天赋选择，并修复玩家遇到的许多反复出现的问题，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 关于 虚痕枭雄 游戏风格。请阅读下方的完整改动列表，以及

它们的影响。暴风雪 提供了关于改动内容和

原因的详细分析，你可以在

此处]（[https://worldofwarcraft.blizzard.com/en-us/news/24304162](<https://worldofwarcraft.blizzard.com/en-us/news/24304162>)] 阅读，下面我们将内容精简为关键要点：

[12.1.5内容更新说明](<https://us.forums.blizzard.com/en/wow/t/1215-content-update-notes/2368213>)

**噬灭 恶魔猎手**

<em>开发者说明：坍缩星辰的施放被取消一直是</em>

```
pain point since Devourer’s introduction, and the changes in this update are

aimed at alleviating some of that frustration. We’re giving Collapsing Star

more wiggle room to finish its cast by giving it extra range after its cast

begins.</em>
```

- [[spell:1221167]] 在开始施放后现在拥有增加的射程。
- [[spell:1221167]] 在施放被取消时不再进入5秒的冷却时间。
- [[spell:1221167]] 现在只会在有限的时间内在施放期间减缓 狂怒 的消耗。
- [[spell:1272432]] 使 [[spell:1239519]] 和 [[spell:1245412]] 的暴击几率提高18%（原为15%）。
- [[spell:1244220]] 在 [[spell:471306]] 期间使 [[spell:473728]] 的冷却时间缩短2.5秒（原为2秒）。
- 许多天赋改变了位置。
  
  
  
  
  - <em>开发者说明：我们正在调整一些天赋的位置，以便</em>
    
    
    
    
    ```
        it a little easier for builds to access core functional effects.</em>
    ```
- **虚痕枭雄**
  
  
  
  
  - <em>开发者说明：虚痕枭雄 天赋树有多个强大的</em>
    
    
    
    
    ```
    	bonuses that all centered around entering Void Metamorphosis, which was
    
    	discouraging players from casting Collapsing Star. Some of Void-scarrd's
    
    	bonuses will now be granted by casting Collapsing Star instead.</em>
    ```
  - [[spell:452415]] 现在改为使 [[spell:1221167]] 重置 [[spell:1246167]] 的冷却时间。
  - [[spell:452415]] 现在使 [[spell:1246167]] 的伤害提高30%（原为25%）。
  - [[spell:452409]] 现在重置 [[spell:1241937]] 的冷却时间，而不是 [[spell:1246167]]。
  - [[spell:452414]] 使智力提高10%（原为15%），[[spell:1221167]] 的伤害提高20%（原为15%）。

这些改动影响深远，并将 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 推向一种

更类似于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 的游戏风格。它现在还着眼于

延长其 [[spell:471306]] 窗口，尽可能多地施放 [[spell:1221167]]，

同时穿插 [[spell:1245412]] 和 [[spell:1246167]]。

坍缩星辰提供的重置和冷却缩减现在使其处于

冷却期间连招的核心位置。

天赋树结构的变化现在也使得更容易同时获取

[[spell:1226033]] 和 [[spell:1246167]]，为

无论是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 还是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 都开辟了更多构筑选择。最后，

对 [[spell:1221167]] 做出的一系列改进还消除了一些

在连招期间被打断时最令人沮丧的方面，大多数玩家应该很少会注意到

它造成的消耗速率降低的差异。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_demonhunter_void.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示补丁12.1热修调整 隐藏补丁12.1热修调整
3.4.

#### 8月18日 噬灭 改动

暴风雪 进行了一系列针对 噬灭 套装和我们整体单体强度的调整改动：

[8月18日职业调整说明](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-18/2336820>)

**噬灭 恶魔猎手**

<em>开发者说明：噬灭 的4件套套装加成表现显著超出预期，</em>

```
 so we are reducing its power. To compensate for this set bonus reduction, we are increasing all ability damage. 

 Additionally, Devourer has been overperforming, 

mostly in single target, so we are reducing the damage of Reap/Cull/Eradicate while 

increasing the AoE damage portion of Eradicate to reduce the impact of the change in AoE combat</em>
```

- 所有技能伤害提高14%。不影响PvP战斗。
- [[spell:1226019]]/[[spell:1245453]]/[[spell:1226033]] 伤害降低12%。
- [[spell:1226033]] 群体伤害提高至基础伤害的90%（原为85%）。
- 剧毒深渊4件套套装加成已更新——现在生成2个灵魂碎片（原为8个）
  
  
  
  
  ```
    and increases [[spell:1226019]] damage by 10% (was 20%).
  ```

这些改动整体削弱了我们套装的威力，使我们更少地按下 [[spell:1226019]]。

这些改动对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 的影响大于

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，并且不会改变本赛季的推荐。

:::

3.5.

#### 补丁12.1 噬灭 改动

第二赛季为 噬灭 带来了一系列针对性改动，旨在

将部分威力从冷却时间转移到其工具包的其他部分。这些

改动对其许多构筑都产生了重大影响：

[6月18日开发说明](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**噬灭 恶魔猎手**

<em>开发者说明：我们正在降低 噬灭 的 [[spell:1238855]] 的缩放，</em>

```
to help other stats to compete and compensating with an overall ability damage buff.

Between that and a few more targeted changes, we expect damage during

[[spell:471306]] to be slightly reduced, while damage outside of

Metamorphosis is significantly increased.</em>
```

- 恶魔猎手现在可以装备匕首
  
  
  
  
  - <em>这使得 噬灭 可以装备并使用智力匕首武器</em>
  
  
  
  
  [[spell:1238855]] 在 [[spell:471306]] 期间的加成伤害降低66%。所有技能伤害提高32%。[[spell:1221167]] 伤害提高12%。[[spell:1226033]] 主目标伤害降低6%，次要目标伤害降低15%。[[spell:473662]] 伤害提高60%（不影响 [[spell:1217610]]）。[[spell:471306]] 现在使 [[spell:473728]] 的伤害提高40%（原为67%）。[[spell:1227707]] 现在使后续的 [[spell:1221167]] 伤害提高20%（原为30%）。[[spell:1239519]] 现在正确地提供一个 [[spell:198793]] 的临时充能。
  **歼灭者**
  
  
  
  
  - [[spell:1253817]] 使 [[spell:1221167]] 和 [[spell:1253304]] 对单个目标的伤害提高30%（原为35%）。
  - [[spell:1253805]] 现在使 [[spell:1253304]] 的加成持续6秒（原为8秒）。

结合所有这些改动，这确实成功地将大量

威力移出 [[spell:471306]]，并将其转移到在

其之外施放的技能上。将这些改动与新的第二赛季套装结合后，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者已经略微落后（很大程度上是由于

对[[spell:1221167]]的严重影响），而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 则获得了显著

方面的改进。

:::

### 噬灭 概述

3.6.

#### 噬灭 恶魔猎手 概述

噬灭 是 至暗之夜 中的全新专精，其玩法风格与

近战对应专精 浩劫 有着明显区别。它是一个施法者/近战混合专精，融合了近距离

技能和射程为25码的法术。它以独特的冷却机制

[[spell:471306]] 作为循环的核心，生成并消耗

灵魂碎片来释放 [[spell:1221167]]。

由于该专精随着 至暗之夜 的发布而全新登场，以下我们提供了一些

快速须知内容。这将帮助你从 浩劫 或 复仇 转型，

或让你为开启新的 噬灭 之旅做好准备！

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_arcane_mindmastery.jpg>) **主属性**
  
  
  
  
  噬灭 是 <em>智力</em> 智力属性专精，与其他施法者共享装备、武器和饰品。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_weapon_glave_01.jpg>) **武器类型**
  
  
  
  
  噬灭 使用战刃、拳套、斧头、匕首和剑。其中，
  
  
  
  
  战刃是独一无二的；在游玩 噬灭 时，它们的主要属性会变为智力。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_socererking_arcanewrath.jpg>) **射程**
  
  
  
  
  <em>大多数</em> 法术的最大射程为25码。它还拥有少数
  
  
  
  
  特定技能，使用时会将你带入或带出近战范围，
  
  
  
  
  使其在某种程度上成为远程/近战混合专精。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_soulgem.jpg>)
  **资源** – **狂怒 / 灵魂**
  
  
  
  
  **狂怒** 能量施放时 <em>在</em> [[spell:471306]] 内时则会消耗， <em>进入</em>;
  
  
  
  
  **灵魂残片** 授予你 [[spell:471306]] 的使用权限，并允许你施放 [[spell:1221167]]。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) **英雄天赋** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>)
  
  
  
  
  噬灭 的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 与 浩劫 共享，以及新增的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 与 复仇 共享。
  
  
  
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 专注于在 [[spell:471306]] 窗口期间打出爆发性伤害。
  
  
  
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 积累 [[spell:1253304]]，对敌人释放虚空流星。

3.7.

#### 噬灭 恶魔猎手 天赋巅峰 - 至暗之夜

至暗之夜 中新增了天赋巅峰系统，这是一组在你从80级升到90级时依次解锁的天赋。

随着你从80级升至90级逐步解锁。这些天赋分成4组，各组在不同

效果。与其他天赋不同，它们都位于同一个节点中，每投入

一点都会增强效果。噬灭 恶魔猎手 的天赋巅峰是

[[spell:1242486]]，为 [[spell:1221167]] 提供显著加成：

1. [[spell:1242486]] — 你的 [[spell:1221167]] 将必定造成暴击。
2. [[spell:1250088]] — 拥有两个点数，每点使你造成的所有宇宙伤害
   
   
   
   
   提高3%，并使[[spell:1221167]]的暴击伤害提高50%
   
   
   
   
   按你暴击几率的50%提升。该加成与 [[spell:1242495]] 为加法叠加。
3. [[spell:1250094]] — 进入 [[spell:471306]] 时，立即
   
   
   
   
   生成5个灵魂碎片，并立即获得一次 [[spell:1221167]] 的施放机会。

天赋巅峰显著

增强了 [[spell:1221167]] 的威力，使其成为我们

最强的伤害来源之一。最后一点尤其还能增加

直接施放的机会，使每次 [[spell:471306]] 的施放都更具影响力。

### **关键技能**

3.8.

#### 噬灭 恶魔猎手 关键技能

由于噬灭是一个全新的专精，所以没有关于

的真正比较对象，随着至暗之夜的发布。相反，这里我们将采取

快速概览其技能库中最重要的技能。它

几乎将所有基础的 恶魔猎手 技能替换为虚空主题的

替代技能，更契合其施法者混合玩法风格，但功能

相似：

3.9.

#### 进攻技能

虽然 恶魔猎手 的伤害技能库相对精简，但它们在循环中

都有各自的定位。因此，了解每个技能的衔接位置非常重要，

以便最大化地发挥该专精的威力。

<table>&#10;<tr>&#10;<th>技能</th>&#10;<th>描述/效果</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:473662]]</td>&#10;<td>这是你的 <strong>主要填充技能</strong>，对目标造成宇宙伤害，基础施法时间为2秒。每次施放通过 [[spell:1215617]] 生成 狂怒 和两个灵魂碎片，且可以在移动中施放。当你变身为 [[spell:471306]] 时，该技能会被 [[spell:1217610]] 替代。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:473728]]</td>&#10;<td>在3秒引导期间对面前的目标造成大量宇宙伤害。在 <em>在</em> [[spell:471306]]，此技能消耗100点狂怒且无冷却时间，但当 <em>进入</em> 它不消耗任何资源，冷却时间为14秒，会短暂暂停狂怒的消耗。这是你的 <strong>主要消耗技能</strong>.</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:471306]]</td>&#10;<td>你的 <strong>主要冷却技能</strong>。与大多数职业不同，该技能没有固定的冷却时间。相反，在收集50个灵魂后（受天赋影响）即可施放。激活后，你的伤害会显著提高，可以施放 [[spell:1221167]]，部分技能得到强化，并且你的 狂怒 开始快速消耗。当能量耗尽时，你会被迫退出该形态。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1221167]]</td>&#10;<td>只能在 [[spell:471306]] 期间使用。在变身状态下每收集30个灵魂（或通过天赋以其他方式获得），你就可以施放 <em>单</em>&#10;&#10;   星星对你的目标和附近敌人造成巨额宇宙伤害，并短暂暂停你的 狂怒 消耗。在变身期间的每次施放都会通过 [[spell:1227707]] 变得更强。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1226019]]</td>&#10;<td>对目标造成瞬发宇宙伤害，冷却时间为8秒。施放时，该技能会拉取最多4个灵魂（在此过程中生成 狂怒），因此可用于收集那些距离太远无法手动拾取的灵魂。当你变身为 [[spell:471306]] 时，该技能会被 [[spell:1245453]] 替代。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1245412]]</td>&#10;<td>冲向你的目标，造成宇宙伤害，冷却时间为30秒。该技能拥有大量配套天赋，使其在某些构建中更为重要，并且是近战混合构建的核心。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1241937]]</td>&#10;<td>生成3个灵魂、30点 狂怒，并在5秒内为你治疗。冷却时间为1分钟，但后续天赋会改变你使用它的频率。这作为按需资源生成的小幅补充手段。</td>&#10;</tr>&#10;</table>

3.10.

#### 机动性、实用性与防御

除了进攻手段外，它还配备了各种生存

和功能手段，其他恶魔猎手也拥有这些手段，但带有一些独特的变化。

<table>&#10;<tr>&#10;<th>技能</th>&#10;<th>描述/效果</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1234796]]</td>&#10;<td>噬灭 对 浩劫 的 [[spell:344865]] 的回应，该技能可让你在30码范围内近乎瞬时地传送到光标位置。冷却时间为20秒，基础拥有1层充能，天赋可增加该上限。这是一个极其强大的移动工具，但请注意它是 <em>非</em> 一次传送——你仍会穿过路径上的任何环境效果。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:198589]]</td>&#10;<td>噬灭 的防御技能，提供10秒内25%的伤害减免，冷却时间为1分钟。使用 [[spell:1266307]] 天赋时，还可在职业树上获得第二层充能。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1241937]]</td>&#10;<td>噬灭 的额外防御工具，在5秒内为你恢复最大生命值的24%，冷却时间为1分钟。在 噬灭 天赋树中可进一步强化以获得额外一层充能。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:198793]]</td>&#10;<td>使你向后跃起，冷却时间为25秒。噬灭 天赋树中的一些天赋可以将其强化为进攻循环的一部分，但其基础效果仅是一个移动工具。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:183752]]</td>&#10;<td>噬灭 的打断技能，冷却时间为15秒，封锁时间为5秒，射程30码。这使其相比大多数其他打断技能具有优势，尤其是对其他施法者而言。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1234195]]</td>&#10;<td>击晕你的目标及附近敌人3秒，造成少量宇宙伤害。没有消耗，射程30码，冷却时间45秒，使其成为一个灵活的控制工具。</td>&#10;</tr>&#10;</table>

1.

### 噬灭 恶魔猎手 游戏基础

噬灭 的核心法术相对精简，天赋树中提供了一些

额外选择，为你的技能组合增添特色，或改变冷却技能的运作方式。

该专精上手即玩，手感流畅，但深度却出乎意料地丰富

在规划和管理冷却窗口方面出人意料地丰富。为了拆解该专精的

基础，有几点需要记住：

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_dh_void_ability_firstofsouls.jpg>)
  **构建与消耗资源**
  
  
  
  
  噬灭通过[[spell:473662]]产生狂怒和灵魂碎片
  
  
  
  
  [[spell:1241937]]，然后通过踩上去或者
  
  
  
  
  施放 [[spell:1226019]] 来收集它们。狂怒 为 [[spell:473728]] 提供燃料，而灵魂碎片则赋予
  
  
  
  
  使用你的[[spell:471306]]的能力。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_112_ability_demonhunter_metamorphasisvoid.jpg>)
  **最大化虚空蜕变**
  
  
  
  
  [[spell:471306]]是你的主要冷却技能，提高你所有技能的
  
  
  
  
  伤害。更重要的是，它让你能够使用[[spell:1221167]]，
  
  
  
  
  前提是你收集了足够的灵魂。在该形态下，狂怒会迅速消耗，
  
  
  
  
  因此你生成的狂怒和灵魂越多，你就能在其中停留越久，
  
  
  
  
  并施放更多[[spell:1221167]]！
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_voiddh_ability_demonsurge.jpg>)
  **利用你的英雄天赋**
  
  
  
  
  噬灭的每个英雄天赋树都会增加一项额外机制。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者
  
  
  
  
  拥有一个强力触发效果[[spell:1253304]]，通过[[spell:1226019]]消耗，
  
  
  
  
  在叠满三层后，从天空降下流星。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄
  
  
  
  
  则会在特定技能施放时释放[[spell:1246160]]，
  
  
  
  
  [[spell:471306]].

这三个方面构成了噬灭循环的核心，其节奏

会让你在时间形态之间切换， <em>进入</em> 和 <em>在</em> 你转换的

[[spell:471306]]。当你选择某些天赋时，节奏会发生变化，但

这些规则始终是应对战斗的核心。在准备和优化你的

[[spell:471306]]窗口时，还有很多额外的深度可以挖掘，

但基础专精非常直观，很容易上手。噬灭与它的两个姊妹专精一样，

与它的两个姊妹专精一样，也拥有极其强大的机动性工具包，通过

[[spell:1234796]]和[[spell:198793]]拥有极其强大的机动能力，同时还能

移动施放[[spell:473662]]。这赋予了它比许多其他远程专精更出色的

与许多其他远程专精相比。

1.

### 如何为噬灭恶魔猎手配装

虽然我们始终建议你自己进行模拟以获得最佳结果，但我们也提供了一个

专门的噬灭配装页面。我们目前涵盖了

第二赛季装备的推荐，以便在终局

至暗之夜内容发布时有个良好的开端。在你获取了一些装备后，你需要相应的消耗品、

宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 针对12.1.5补丁进行审查
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新至8月18日的职业调整。
- **2026年8月18日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至8月18日的职业调整。
- **2026年8月18日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至8月18日的职业调整。
- **2026年8月18日（本页）：** 已更新至8月18日的职业调整。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月5日（本页面）：** 已更新至5月5日的职业调整。
- **2026年4月24日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 更改了戒指附魔推荐。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月7日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 添加了关于早期制作以优化破晓冠使用的常见问题解答说明。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月17日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 页面已根据在线修复进行更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 页面已根据在线修复进行更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已根据在线修复进行更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已根据在线修复进行更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日（本页面）：** 页面已更新至至暗之夜第一赛季。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 页面已更新至至暗之夜上线。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 页面已更新至至暗之夜上线。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 页面已更新至至暗之夜上线。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 页面已更新至至暗之夜上线。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 页面已更新至至暗之夜上线。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（本页）：** 为至暗之夜上线进行了更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 已针对12.0.1补丁进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot>)):** 页面已创建。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)):** 页面已创建。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gems-enchants-consumables>)):** 页面已创建。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)):** 页面已创建。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 已针对12.0.1补丁进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至至暗之夜前夕补丁的在线修复。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已针对12.0.1补丁进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)):** 页面已创建。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 已更新至12.0.1补丁
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月31日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜前夕补丁的在线修复。
- **2026年1月31日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至至暗之夜前夕补丁的在线修复。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/devourer-demon-hunter-leveling-guide>)):** 页面已创建。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-mythic-plus-tips>)):** 页面已创建。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2025年12月13日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至最新的测试服改动。
- **2025年12月13日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至最新的测试服改动。
- **2025年12月13日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 已更新至最新的测试服改动。
- **2025年12月13日（本页面）：** 已更新至最新的测试服改动。
- **2025年12月6日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 已更新至最新的测试服改动。
- **2025年12月6日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 已更新至最新的测试服改动。
- **2025年12月6日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 已更新至最新的测试服改动。
- **2025年12月6日（本页面）：** 已更新至最新的测试服改动。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 针对11.2.7补丁进行了审查。
- **2025年11月15日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 页面已更新至测试服发布改动。默认构筑切换为歼灭者（施法者）。
- **2025年11月15日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 页面已更新至测试服发布改动。默认的歼灭者构筑切换为施法者变体。
- **2025年11月15日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 页面已更新至测试服发布改动。单体目标构筑切换为歼灭者（施法者）。
- **2025年11月15日（本页面）：** 页面已更新至测试服发布改动。
- **2025年11月10日（[简单模式页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-easy-mode>)):** 为至暗之夜测试服创建页面。
- **2025年11月9日（[循环页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜测试服创建页面
- **2025年11月9日（[天赋页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>)):** 为至暗之夜测试服创建页面
- **2025年11月9日（本页面）：** 为至暗之夜测试服创建页面

显示更多

显示更少

:::

## 练级

在本页面中，你将找到我们的逐级噬灭恶魔猎手练级指南， [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[恶魔猎手 练级指南](<https://www.icy-veins.com/wow/demon-hunter-leveling-guide>).

1.

### 噬灭恶魔猎手练级指南 —— 至暗之夜

欢迎来到我们的至暗之夜练级指南。它将帮助你在

作为噬灭恶魔猎手的满级之旅中，涵盖天赋和

你应该了解的技能。

噬灭恶魔猎手的伤害在部分时段较低，但在每次

可用[[spell:471306]]时都会爆发出大量AOE伤害。

噬灭还拥有极高的机动性和出色的自我续航能力，可以

拉相对较多的敌人。其AOE具有递增伤害

机制，这在练级副本的闪电般快速节奏中

会造成一些问题。如果你主要通过副本练级，可能会发现以浩劫或复仇

如果地下城是你升级时首选的内容类型。

如果你玩的是噬灭，你的目标是围绕[[spell:471306]]来规划，

在技能冷却可用时拉一大群敌人，并使用它

迅速击败它们。在冷却不可用时，应该拉较小的

敌人组，因为你的击杀时间会更长。

1.1.

#### 升级装备选择

练级时，物品等级始终比单项属性更重要。始终

选择物品等级最高的装备。带有速度副属性的

物品可以帮助加快你的练级速度，尤其是在长时间待在室内的

部分。传家宝装备在练级时也很有用，让你在练级旅程的大部分时间里可以忽略大量

在你升级旅程的大部分时间里，装备的提升都需要依靠它。

1.2.

#### 至暗之夜升级实用消耗品

随着 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)的发布，这意味着

是时候让每个人都重新升到90级了。为了加快这一进程，你可以使用一些

<em>可选的</em> 你可以拾取的消耗品，用来加快进度。

为了尽可能做好准备，请设法获取以下至少部分

物品和附魔。

- [[item:191348]] —— 一瓶药水，来自 [巨龙时代](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  
  
  
  
  死亡后依然存在，提供30分钟的额外速度加成。如果你的装备已经
  
  
  
  
  很好，关键往往在于拉怪之间的移动速度，而非多一点伤害。
- [[item:225592]] —— 一种食物，来自 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  
  
  
  
  提供持续1小时的大量速度加成，但死亡后会消失。
- [[item:213746]] —— 如果你的装备有大量插槽，请切换到
  
  
  
  
  这颗阿拉里钻石，将每个 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)宝石颜色
  
  
  
  
  以获得额外速度。
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —
  
  
  
  
  如果你之前使用的是闪避或吸血，将所有护甲附魔都换成额外速度效果。
  
  
  
  
  如果你之前使用的是闪避或吸血。
- [[item:132516]] —— 练级时屡试不爽的选择，总是
  
  
  
  
  很值得拥有，可以穿过无法骑乘的区域，甚至可以在水面上使用。
  
  
  
  
  这些 <em>无法</em> 不能在战斗中激活，并且在
  
  
  
  
  受到伤害时会被取消。
- [[item:154168]] / [[item:154169]] —— 这些
  
  
  
  
  来自争霸艾泽拉斯的消耗品可以帮助应对任何涉及进入
  
  
  
  
  水下的环节——尽管在至暗之夜的区域中这种情况并不常见。

1.

### 升级天赋

只要脱离战斗，你的天赋可以在世界任何地方更改。

升级时请务必随意尝试各种天赋组合，

以感受游戏玩法的节奏。我们在下方提供了一条升级路线示例，

它会在你的旅程中介绍核心的噬灭概念。

:::talents 噬灭升级 - 80级起始天赋
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBMAAAAAAAbDDYGAAAAAAAAmxMMmZmZmZmZGzsNzgNtsBAADgZGjtZmpZbGPwMjxMA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAYbGDYGAAAAAAAAmxMMmZmZmZmZGzsNzgNtsBAADgZmZmtZmpZbmtHYmxYGD"
}
```
:::

:::details 来源计算器编码
```
#IX-NUEmKfeOVZQQOOCXKLAmllQaYZhOmKAONdB-AKHXNSGsgUg58oFtIIOxIJRAFcsjzbD-AAAA-VeUwksMMgwopAA-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将对PvP天赋进行排名，

用于升级以及进行单人或小队PvE内容。以下是通用

PvP天赋和噬灭恶魔猎手专属PvE天赋的排名。

1. [[spell:1261414]]能显著提升你的护甲，这在升级过程中对抗所有近战伤害
   
   
   
   
   都非常有效。此外，它能产生大量免费的灵魂碎片，使其成为极佳的选择
2. [[spell:1261697]]使你在[[spell:1226019]]之后的下一个[[spell:473662]]变为瞬发，并额外产生一个灵魂碎片。
   
   
   
   
   这大大提升了循环速度，并会让你在冷却就绪时使用[[spell:1226019]]
3. [[spell:1261409]]使[[spell:1221167]]的伤害提高25%，并使其无法被打断。虽然用途较为小众，但它
   
   
   
   
   仍能带来小幅伤害提升，并且偶尔可以防止你的[[spell:1221167]]被敌方技能打断。

[[spell:205596]], [[spell:357419]],

[[spell:205625]]和[[spell:354489]]在PvE中的用途非常有限，

因为它们非常专注于控制技能或压制敌方玩家。

不过，关于[[spell:1261423]]需要特别说明。这个天赋

使[[spell:471306]]消耗100个灵魂碎片，但会提升你的

20%的伤害，并使变形期间获得的所有狂怒

提高100%。这个天赋 <em>绝对不要</em> 在任何情况下都应该点出，因为它使

[[spell:471306]]的成本翻倍还多（对升级构筑而言），

但由于战斗时间很短，收益非常有限。

1.

### 升级循环

为了帮助你理解随着等级提升和天赋树推进，你的专精会有哪些变化，

请使用下方的滑块选择你当前的等级。每次你

升级时，就移动它，这一部分也会随你一同升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 71 起：**达到71级并解锁英雄天赋后，我们

推荐使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄来强化你的[[spell:471306]]

搭配[[spell:1246160]]。

**等级 81 起：**达到81级后，巅峰天赋解锁。然而，我们选择在满级之前不投入点数，

因为升级过程中[[spell:1221167]]的使用频率并不高。

3.1.

#### 核心概念

随着你升级并填充天赋树，噬灭将获得更多

用于在循环之外探索世界的工具。这一部分将

随着滑块在每次升级时一同成长。

- **记得恢复！** - 每次拉怪之间血量偏低时，
  
  
  
  
  你可以使用所有职业都拥有的[[spell:1231418]]技能来
  
  
  
  
  快速恢复。
- **等级 1–9：****善用您的移动能力！** - 恶魔猎手可以使用[[spell:344865]]，
  
  
  
  
  让你能够快速跨越距离，持续作战。
- **等级 10 起：****善用您的移动能力！** - 噬灭可以使用[[spell:1234796]]、
  
  
  
  
  [[spell:198793]]和[[spell:1245412]]，为你提供多种在战场上快速移动的方式。
- **等级 1–27：****利用您的治疗能力** - 噬灭会从每个被消耗的[[spell:1227619]]球体中获得治疗！
- **等级 28 起：****利用您的治疗能力** - 噬灭会从每个被消耗的[[spell:1227619]]球体中获得治疗！
  
  
  
  
  [[spell:204909]]还能提供可观的吸血（尤其是在[[spell:471306]]期间），所以
  
  
  
  
  大胆拉怪吧！
- **等级 18 起：****记住您的防御手段** - [[spell:198589]]是一个强力
  
  
  
  
  的防御技能，尤其对抗经常进行普通攻击的敌人时。请频繁使用它！

**等级 10 起：**3.2.

#### **等级 10 起：**动态优先级列表

以下是需要关注使用哪些技能的优先级列表示例：

1. **等级 45 起：**可用时施放[[spell:1221167]]。
2. **等级 27 起：**可用时施放[[spell:1226033]]。
3. **等级 29 起：**冷却就绪时施放[[spell:370965]]。
4. **等级 21 起：**施放[[spell:1245412]]以产生狂怒。
5. **等级 39 起：**可用时施放[[spell:1239519]]。
6. **等级 39 起：**获得[[spell:1239520]]增益时施放[[spell:198793]]。
7. **等级 10 起：**当拥有足够的狂怒时施放[[spell:473728]]。
8. **等级 15 起：**当你有足够灵魂碎片施放时，尽可能频繁地使用[[spell:471306]]。
9. **等级 17 起：**施放[[spell:1241937]]以产生狂怒和灵魂碎片。
10. **等级 10 起：**施放[[spell:473662]]以产生狂怒和灵魂碎片。
11. **等级 10 起：**根据需要施放[[spell:1226019]]以收集你无法触及的灵魂碎片。
12. **等级 16 起：**当你需要从远处拉怪时，施放 [[spell:185123]]。

**等级 10 起：**3.2.

#### **等级 10 起：**生存工具

**等级 10 起：**噬灭有拉大和陷入危险的习惯

局面的习惯，但幸运的是它配备了多种工具来帮助应对：

- **等级 10 起：**[[spell:178940]]在造成伤害时有几率生成，并且会通过
  
  
  
  
  各种天赋和技能生成。每消耗一个灵魂碎片会为你恢复1%的最大生命值。
- **等级 16 起：**如果你发现自己被困住或陷入危险
  
  
  
  
  局面，[[spell:1234796]]的传送和[[spell:198793]]几乎总能
  
  
  
  
  把你解救出来。
- **等级 18 起：**[[spell:198589]]持续时间长且冷却时间短，
  
  
  
  
  所以如果你感到不安全，不要害怕使用它。
- **等级 14 起：**[[spell:1234195]]能为你提供紧急的范围眩晕，如果
  
  
  
  
  你陷入糟糕的局面。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对12.0.1补丁进行更新。
- **2026年1月19日：** 页面已创建。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将讲解如何在《魔兽世界》12.1.5补丁中轻松游玩噬灭恶魔猎手，使用最简单的输出循环、天赋树、属性优先级、装备配置等，且不牺牲性能。

1.

### 噬灭恶魔猎手基础指南

欢迎来到我们的噬灭快速入门指南！本页面向那些

希望直接上手而不想深入了解的玩家。它将涵盖一些快速

的构筑配置，为你提供关键的循环构建模块，以及一些额外的

技巧，帮助你轻松上手至暗之夜全新的恶魔猎手内容。

噬灭的输出循环表面上很简单，但在管理其核心机制——

[[spell:471306]]时有一些隐藏的深度。作为一名

施法者，至关重要的是 **始终在施法**，充分利用其高机动性的

工具组。涵盖核心支柱的三条简单规则是：

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_dh_void_ability_consume.jpg>)
  **积攒狂怒**
  
  
  
  
  噬灭有两种资源，两者都很重要。狂怒由
  
  
  
  
  [[spell:473662]]和许多天赋产生，或通过收集[[spell:178940]]获得。
  
  
  
  
  这用于施放[[spell:473728]]，同时 <em>在</em> 的[[spell:471306]]，
  
  
  
  
  但在 <em>进入</em> 以维持你的变形时会快速消耗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_dh_void_ability_firstofsouls.jpg>)
  **消耗灵魂**
  
  
  
  
  灵魂通过天赋或施放[[spell:473662]]生成。
  
  
  
  
  你可以通过走过去拾取，或使用[[spell:1226019]]来
  
  
  
  
  远程收集。达到50个后，你可以变身为[[spell:471306]]，
  
  
  
  
  强化你的技能。变形期间，每收集30个灵魂
  
  
  
  
  允许你施放 <em>单</em> [[spell:1221167]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_112_ability_demonhunter_metamorphasisvoid.jpg>)
  **最大化虚空蜕变**
  
  
  
  
  在变形期间，狂怒会快速消耗。你在此形态下的目标
  
  
  
  
  会根据所选的英雄天赋略有不同。
  
  
  
  
  对于两个英雄天赋树，我们的目标都是施放
  
  
  
  
  尽可能多的[[spell:1221167]]。对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，你应设法使用
  
  
  
  
  每当[[spell:1253304]]触发时使用[[spell:1226019]]。对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，应设法在
  
  
  
  
  [[spell:1221167]]的施放之间穿插施放[[spell:1245412]]和[[spell:1246167]]，
  
  
  
  
  以利用其提供的重置和冷却缩减效果。

噬灭的构建围绕平衡两种不同的玩法风格。在 <em>在</em>
[[spell:471306]]期间，你循环使用狂怒来施放[[spell:473728]]，生成

灵魂以积累你的变形进度。在 <em>进入</em> 恶魔形态下，你需要

谨慎平衡狂怒以维持你的形态，同时尽可能多地施放

[[spell:1221167]]，在时间耗尽之前。你最终会

对流程产生直觉，并在即将退出形态之前知道时机，

在你的下一个[[spell:1221167]]之前，从而积累一些储备灵魂。

一旦你习惯了资源的推拉节奏，它会以

令人满足的积累过程作为回报，最终带来巨大的爆发，并具有令人惊讶的深度。

1.

### 噬灭 恶魔猎手 至暗之夜 快速入门指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者单体天赋

2.1.

#### 噬灭 恶魔猎手单体天赋

我们在此推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，因为其执行要求更简单

要求，因为它不涉及近战技能的使用。其单体目标

围绕尽可能频繁地用[[spell:1226019]]触发[[spell:1253304]]，

并在[[spell:471306]]期间施放大量连续的[[spell:1221167]]，

利用[[spell:1250094]]巅峰天赋。

它采用经典的积攒与消耗循环，奖励良好的资源

管理能力，并具有相当精简的施法者玩法循环。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAY5BGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGAzYAAwYGGzA"
}
```
:::

:::details 来源计算器编码
```
#IX-NOUfEKemFJVCJBigswklVecAOmKYMNZdtpF-AHKXGMSEKQceqqEDCWmyy8+Ilk4IgoB-AAAA-UWYaKMiMJQYgAA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者AoE天赋

2.2.

#### 噬灭 恶魔猎手AoE天赋

在AoE中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者尽可能频繁地循环使用狂怒来施放[[spell:473728]]，

同时进入[[spell:471306]]以触发[[spell:1253304]]，通过

[[spell:1256295]]和[[spell:1250094]]。它保持使用

[[spell:1242492]]以获得更长的冷却窗口，但若特定副本需要，可换为[[spell:1247534]]，

视副本需求而定。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGADDAAPwYGGzA"
}
```
:::

:::details 来源计算器编码
```
#IX-NOQUfEKehmFIIJVILBecwklBOmKYMNdtFoF-AHKXGMSEKQceqqEDCWmyy28+Ilk4IgA-AAAA-UWYaKMiMJQYgAA-
```

:::

### 噬灭 恶魔猎手循环详解

2.3.

#### 单体输出详解

在单体战斗中，使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者时，一切围绕

积累并有效执行你的[[spell:471306]]窗口

这些窗口相当频繁，你应设法尽可能延长它们以施放大量[[spell:1221167]]。

以下是入门时关键步骤的简要分解：

- **积攒与消耗狂怒**
  
  
  
  
  这通过[[spell:473662]]、[[spell:1241937]]或收集[[spell:178940]]来生成。
  
  
  
  
  虽然 <em>在</em> 的[[spell:471306]]，当你达到时施放[[spell:473728]] **100** 狂怒.
  
  
  
  
  虽然 <em>在</em> 在[[spell:471306]]期间，每当[[spell:1241937]]冷却完毕且你的下一个施放将是[[spell:473662]]时，就施放它。
  
  
  
  
  虽然 <em>进入</em>，尽可能多地生成以维持变形。
- **生成与收集灵魂**
  
  
  
  
  你造成的任何伤害都有小几率在你的角色周围生成一个灵魂。
  
  
  
  
  [[spell:473662]]生成2个，[[spell:1241937]]生成3个，而[[spell:473728]]通过[[spell:1223918]]生成许多。
  
  
  
  
  这些通过接触收集，或通过施放[[spell:1226019]]从远处收集。
- **斩杀虚空蜕变**
  
  
  
  
  这可以在你收集后立即且应该被施放 **50** 灵魂后立即施放，也应该立即施放。
  
  
  
  
  尽可能多地使用[[spell:1221167]]。
  
  
  
  
  在进入[[spell:471306]]之前，使用[[spell:1226019]]触发[[spell:1253304]]。
  
  
  
  
  当你即将取消形态时，使用[[spell:473728]]来暂停你的狂怒消耗。
- **消耗虚空坠落 -**
  
  
  
  
  每三层[[spell:1253304]]，施放[[spell:1226019]]。
  
  
  
  
  [[spell:473662]]有35%几率，[[spell:473728]]有100%几率生成一层。
  
  
  
  
  [[spell:471306]]生成三层，所以[[spell:1226019]] <em>之前</em> 在进入时若你有三层。

在学习流程时，最好将其分解为步骤。我们建议按以下顺序关注：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_demonhunter_void.jpg>) **噬灭单体**
**狂怒/灵魂管理**

➜

**[[spell:471306]]时机**

➜

**[[spell:1221167]]施放**

:::

2.4.

#### 范围输出详解

在AoE中，它仍然遵循在单体中学到的许多相同规则，但

由于灵魂碎片生成增加，会施放更多[[spell:1221167]]。

AoE中改变的关键事项有：

- **斩杀虚空蜕变**
  
  
  
  
  一旦你聚集了就施放这个技能，这是可以做到的，也应该这样做 **35** 灵魂后立即施放，也应该立即施放。
  
  
  
  
  每 **30** 收集到的灵魂 <em>在激活期间</em> 允许你施放[[spell:1221167]]。
  
  
  
  
  在拉怪之间管理你的窗口，力求施放尽可能多的星辰。
- **利用抹杀**
  
  
  
  
  [[spell:1226033]]在[[spell:473728]]施放后替换[[spell:1226019]]。
  
  
  
  
  [[spell:1226019]]是 <em>只能</em> 在AoE中，当[[spell:1226033]]或[[spell:1253304]]激活时施放。
  
  
  
  
  [[spell:473728]]施放频繁，因此几乎总是可用的。

核心AoE原则可以在单体中学习。我们建议按以下顺序关注：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/classicon_demonhunter_void.jpg>) **噬灭 AoE**
**学习单体目标**

➜

**调整[[spell:1253304]]消耗**

➜

**[[spell:1226033]]管理**

:::

2.5.

#### 巅峰天赋使用 - 至暗之夜

我们的巅峰天赋[[spell:1242486]]，

简单地提升[[spell:1221167]]施放的伤害

在使用时。有了最后一个点数 - [[spell:1250094]] - 这意味着你的第一次施放

在进入[[spell:471306]]时应该是[[spell:1221167]]，以便

获得起手爆发。

2.6.

#### 第二赛季套装

噬灭的第二赛季套装， **深渊末日猎犬的追击**，提供

以下两个加成：

- [[spell:1296615]] — 收获4个或更多灵魂碎片
  
  
  
  
  与 [[spell:1226019]] 一起使用时，有20%几率使你的下一个 [[spell:473662]] 变为瞬发
  
  
  
  
  施放并在 [[spell:1297433]] 中爆炸，造成（法术强度的600%）宇宙
  
  
  
  
  伤害，作用于附近的敌人。
- [[spell:1296616]] — [[spell:1297433]]
  
  
  
  
  产生2个灵魂碎片并获得 [[spell:1238488]]。[[spell:1226019]] 造成的伤害提高10%

这些加成对循环有巨大影响，促使我们更积极地利用 [[spell:1226019]]

更加激进地获取尽可能多的 [[spell:1297433]] 触发。

尽量在 [[spell:1226019]] 能收集4个或更多灵魂碎片时使用它！

### 噬灭 恶魔猎手 防御与功能法术

2.7.

#### 噬灭 恶魔猎手 的防御与功能法术

虽然 至暗之夜 中的精简影响了许多专精，但 噬灭 被

被引入时带着许多技巧来应对不同的

情况的手段。它拥有一套不错的防御手段，以及一个 <em>出色的</em>

机动工具组。

2.8.

#### 防御手段

<table>&#10;<tr>&#10;<th>技能</th>&#10;<th>描述/效果</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:198589]]</td>&#10;<td>噬灭 的防御工具，提供25%的伤害减免，持续10秒，冷却时间为1分钟。可通过 [[spell:1266307]] 天赋获得第二层充能。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:196718]]</td>&#10;<td>使你和站在所创造的8码范围内的任何盟友有15%的几率（在队伍中提高至30%）躲避任何一次伤害。持续8秒，冷却时间较长，为5分钟（可通过天赋缩短），但这是一个将防御和功能冷却合二为一的优秀技能。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1241937]]</td>&#10;<td>在其持续时间内为你恢复最大生命值的24%。这可以通过 [[spell:1246556]] 进一步提升至30%。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1266497]]</td>&#10;<td>施放 [[spell:1234796]] 后提供一个非常短暂的6%生命值护盾。在面临致命伤害时可能派上用场。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:204909]]</td>&#10;<td>虽然不是一个主动工具，但 噬灭 拥有不错的固有吸血，并且在 [[spell:471306]] 期间会变得更强。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1266329]]</td>&#10;<td>打断敌人后提供15%的魔法伤害减免，持续12秒。</td>&#10;</tr>&#10;</table>

2.9.

#### 机动工具

<table>&#10;<tr>&#10;<th>技能</th>&#10;<th>描述/效果</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1234796]]</td>&#10;<td>噬灭 对 浩劫 的 [[spell:344865]] 的回应，该技能可让你在30码范围内近乎瞬时地传送到光标位置。冷却时间为20秒，基础拥有1层充能，天赋可增加该上限。这是一个极其强大的移动工具，但请注意它是 <em>非</em> 一个传送——你仍然会穿过路径上的任何环境效果。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:198793]]</td>&#10;<td>使你向后跃起，冷却时间为25秒。噬灭 天赋树中的一些天赋可以将其强化为进攻循环的一部分，但其基础效果仅是一个移动工具。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:131347]]</td>&#10;<td>二段跳会使你向前推进的速度快于标准移动速度，这意味着你始终有可用的工具。配合新的 [[spell:1266493]]，这还会稍微快一些。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:320654]]</td>&#10;<td>虽然不是一个主动工具，但你拥有的任何精通等级也会提高你的移动速度。</td>&#10;</tr>&#10;</table>

2.10.

#### 功能工具

<table>&#10;<tr>&#10;<th>技能</th>&#10;<th>描述/效果</th>&#10;</tr>&#10;<tr>&#10;<td>[[spell:183752]]</td>&#10;<td>噬灭 的打断技能，冷却时间为15秒，封锁时间为5秒。与其他 恶魔猎手 打断技能相比，它独特地拥有30码的射程。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:1234195]]</td>&#10;<td>造成轻微的宇宙伤害并使附近的敌人昏迷2秒，冷却时间为45秒。非常灵活的范围控制工具。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:207684]]</td>&#10;<td>在短暂延迟后使目标区域内的敌人瘫痪15秒，冷却时间为2分钟。虽然不如你的范围昏迷灵活，但仍然是一个额外有用的控制技能。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:278326]]</td>&#10;<td>驱散目标的一个魔法效果，冷却时间为10秒。与所有 恶魔猎手 专精一样，它可以使用进攻性驱散。</td>&#10;</tr>&#10;<tr>&#10;<td>[[spell:217832]]</td>&#10;<td>使目标恶魔、野兽或人形生物瘫痪1分钟。虽然这有数量限制，但它作为对敌人的硬控制，在敌人处于该效果期间不会从附近的玩家身上吸引仇恨。</td>&#10;</tr>&#10;</table>

### 噬灭 恶魔猎手 属性优先级

2.11.

#### 噬灭 恶魔猎手 属性优先级

当前的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 噬灭 属性优先级如下。有关更多信息

关于本页呈现的内容，请查看我们的主要 [属性优先级页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>).

智力

精通

急速

暴击

全能

主属性重新变得极其有价值，因此根据物品等级选择装备

是 <em>通常</em> 提升你智力的稳妥选择。

目前，精通是你当前的 <em>最佳</em> 属性，因为我们希望它是最高的

属性，用于触发 [[item:241288]]。急速紧随其后，通过平滑

我们的循环，使我们能在 [[spell:471306]] 中停留更久，并在掉出后

更快地回到其中。由于本赛季急速触发的泛滥，它的价值

比之前几个赛季稍低一些。

由于 [[spell:1238855]] 被削弱，暴击的属性价值有所提升，

它仍然落后于其他两个选项，但现在比以前接近得多。

全能仍然是最弱的，尽管它确实提供了额外的防御能力。

### 暴风雪循环助手

2.12.

#### 暴风雪 循环助手：噬灭 恶魔猎手

循环助手工具由 暴风雪 策划，于《地心之战》中加入，

它有两种模式：第一种会以推荐的优先级高亮动作条按钮，

第二种则提供一个单一的快捷键，自动按下

同一列表中最高优先级的技能，但施法之间会有25%的公共冷却时间惩罚，

施法。

与许多职业一样，它不会使用重大冷却技能或会位移

你角色的技能，这对 噬灭 来说是个大问题。因为该专精

严重依赖利用 [[spell:471306]]，而一键

工具不会使用它，所以循环助手处于 <em>巨大的</em> 劣势。除此之外，

它也不会使用任何种族技能、饰品、防御技能或控制技能，

也不会使用任何会位移你角色的技能。这包括：

- **冷却技能 -** [[spell:471306]], [[spell:1221167]], [[spell:1246167]].
- **移动/位移技能 -** [[spell:1245412]], [[spell:198793]], [[spell:1234796]].

如果你点了增强它们的天赋，所有这些都需要手动使用。

它们。这也适用于防御和控制技能，

也能获得。

<table>&#10;<tr>&#10;<th>英雄天赋</th>&#10;<th>单体目标</th>&#10;<th>群体伤害</th>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp"/> 歼灭者</span> 助手</td>&#10;<td style="text-align: center">-53%</td>&#10;<td style="text-align: center">-44%</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp"/> 歼灭者</span> 一键</td>&#10;<td style="text-align: center">-60%</td>&#10;<td style="text-align: center">-62%</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp"/> 虚痕枭雄</span> 助手</td>&#10;<td style="text-align: center">-58%</td>&#10;<td style="text-align: center">-47%</td>&#10;</tr>&#10;<tr>&#10;<td><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp"/> 虚痕枭雄</span> 一键</td>&#10;<td style="text-align: center">-62%</td>&#10;<td style="text-align: center">-67%</td>&#10;</tr>&#10;</table>

由于这些重大限制，很难推荐这个工具。虽然

希望它未来能有所改进，但在它支持 噬灭 所围绕的效果之前，

应该避免使用它。

如果你必须使用循环工具，我们推荐使用以下 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 构建，

因为它受该工具缺点的影响最小。

:::talents 噬灭 单体目标 - 歼灭者 助手
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAY5BGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGAzYAAwYGGzA"
}
```
:::

:::talents 噬灭 多目标 - 歼灭者 助手
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGADDAAPwYGGzA"
}
```
:::

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 页面已更新至至暗之夜第一赛季。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已更新至12.0.1补丁
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年12月13日：** 已更新至最新的测试服改动。
- **2025年12月6日：** 已更新至最新的测试服改动。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年11月15日：** 页面已更新至测试服发布改动。单体目标构筑切换为歼灭者（施法者）。
- **2025年11月10日：** 为至暗之夜测试服创建页面。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将找到《魔兽世界》12.1.5补丁中你的 噬灭 恶魔猎手 的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋构建。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 至暗之夜 噬灭 恶魔猎手 最佳天赋

噬灭 在12.1.5补丁中经历了重大变化，其中一些重大的

```
shake ups in its preferred builds. While both Hero Talents are viable, in-game

scenarios may limit the output of some builds. Our current recommendations are as follows:
```

- **单体目标 -** 在12.1.5的改动之后， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 是
  
  
  
  
  ```
  recommended over ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) Void-Scarred in all Season 2 encounters. Despite
  
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) Void-Scarred's higher potential throughput, it's prone to disruption
  
  and puts itself in unnecessary danger.
  ```
- **AoE -** 同样在多目标情况下， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 也是
  
  
  
  
  ```
  recommended choice. While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) Void-Scarred does have the potential for both
  
  strong single-target and burst AoE, it runs into the same issues with disruption
  
  alongside falling behind in larger pulls commonly found in Mythic+.
  ```

总的来说， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 的伤害很高，而且更容易执行

```
than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) Void-Scarred in practice. While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) Void-Scarred theoretically

offers the highest potential when playing Devourer, the long periods with no

control over your character and the heavy impact mechanics have on your combos

make it far less reliable. This is such a disadvantage in both Raids and Mythic+

that, unless you enjoy the playstyle, we'd recommend sticking with the more

consistent ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator in endgame content.
```

**快速开始导入代码：**

:::talents 噬灭 单体目标 - 歼灭者
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAALPwY2GMDAAAAAAAAzYwMzMzMmZmZMziZMW0yCzMzMbtNzMDgZMAA8AjBDD"
}
```
:::

:::talents 噬灭 多目标 - 歼灭者
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGADDABegxMMmB"
}
```
:::

:::talents 噬灭 探究 - 虚痕枭雄
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmxwMAAAAAAAmxAmBAAAAAAAgZMDjZmZmZmZGmZbmxYTbbAIgBwMzMz2Mz0sNzmZGjZMA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

歼灭者

单体目标

推荐

团本顺劈

推荐

秘境+

推荐

地下堡

虚痕枭雄

单体目标

团本顺劈

秘境+

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 单体构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 在12.1.5补丁中因 [[spell:1221167]] 的反复加强而有了显著提升。它拥有强大的单体目标伤害，并且有能力提升其爆发以配合优先目标或伤害增幅窗口。与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 相比，其循环也更不易被打断，因此是我们的推荐选择：

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 团本顺劈构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 因 [[spell:1221167]] 和 [[spell:1226033]] 而拥有强大的爆发顺劈能力，同时保持着强大的单体潜力，随着第2赛季期间坍缩之星的加强而进一步提升。虽然它的伤害需要较长的预热时间，但与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 相比，只要你提前规划好施法，它就更不容易被打断，因此是我们的推荐选择：

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 多目标构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者在第二赛季中最大的弱点是其单体伤害和优先目标伤害的不足。然而，在12.1.5中经过多次增强、天赋树调整以及一些生活质量的改进后，这些痛点已被解决。它仍然保留了之前强大的范围伤害能力，但现在也能在需要时击穿关键目标和首领战。再加上其更简单的操作，使其成为我们的推荐选择：

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者地下堡天赋

在 [地下堡](<https://www.icy-veins.com/wow/delves-guide>), ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者非常适合地下堡频繁停停走走的拉怪玩法，允许你根据自己的[[spell:471306]]状态来调整节奏。[[spell:1253676]]也使其能够在每个区域之间快速准备，同时还能利用噬灭出色的防御工具。不幸的是，它只是比竞争对手的通用性稍差一些，因此作为备选方案：

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄单体天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄在进入12.1.5时经历了大幅改动。它不再采用频繁循环[[spell:471306]]以利用近战工具重置的玩法，而是转而采用与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者相似的玩法。现在，每次施放[[spell:1221167]]都会重置[[spell:1246167]]，两者共同构成一个核心循环，用于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄的虚空变形窗口，鼓励你尽可能延长它。但值得注意的是，虽然其伤害潜力非常高，但这些连招带来的高打断风险使其在当前内容中的吸引力下降：

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄团队顺劈天赋

当切换到顺劈天赋时， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄为多目标战斗加入了强大的[[spell:1226033]]，并将其与[[spell:1239519]]和[[spell:1246160]]已经提供的高顺劈吞吐量相结合：

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄范围伤害天赋

12.1.5中的改动使 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄的玩法更接近
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，通过循环积累来打出大范围的[[spell:1221167]]，但它仍然保留了利用频繁的[[spell:1246167]]重置在近战中进进出出的玩法。它拥有来自[[spell:1246160]]和[[spell:1239519]]的强力爆发，以及更强的[[spell:1226033]]。尽管技能组非常强大，但狩猎和坍缩之星的高频率使用经常会将角色控制权从你手中夺走，并使天赋树更容易被打断。除非你喜欢这种玩法，否则目前不推荐：

### 天赋方案 1-3

1.8.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄地下堡天赋

在 [地下堡](<https://www.icy-veins.com/wow/delves-guide>), ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄完全适合地下堡的拉怪节奏，并允许你根据自己的[[spell:471306]]状态调整每次拉多少怪。其高机动性、频繁的伤害爆发以及标准配置中内置的强力单体伤害使其成为理想选择。再加上噬灭强大的防御工具，它就成为了
**推荐选择**:

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmxwMAAAAAAALPwY2GMDAAAAAAAAzYwMzMzMmZmZMziZMW0yCzMzMbtNzMDgZMAA8AjBDD"
}
```
:::

:::details 来源计算器编码
```
#IX-NOQUfEKehmFIIJLVKBecwklBOmKYMNZdtpF-AHKXGMSsIKUw48MVVllptFEsIJx5RAB-AAAA-UWYaKMiMJQYgAA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZmZmBmBAAAAAAY5BGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGAzYAAwYGGzA"
}
```
:::

:::details 来源计算器编码
```
#IX-NOUfEKemFJVCJBigswklVecAOmKYMNZdtpF-AHKXGMSEKQceqqEDCWmyy8+Ilk4IgoB-AAAA-UWYaKMiMJQYgAA-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGADDAAPwYGGzA"
}
```
:::

:::details 来源计算器编码
```
#IX-NOQUfEKehmFIIJVILBecwklBOmKYMNdtFoF-AHKXGMSEKQceqqEDCWmyy28+Ilk4IgA-AAAA-UWYaKMiMJQYgAA-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAA2MmZmZGzMGmBAAAAAAYZGDYGAAAAAAAAmxMMzMzMzMzMDzsZGjFZjZmZmtWmZmBwYGAAegxMMmB"
}
```
:::

:::details 来源计算器编码
```
#IX-NOQUfEKehmFIIJVILBecwklBOmKYMNZZdhC-AHKXHMSEKQceqqEDCWmyy28+Ilk4IgC-AAAA-UWYaKMiIJQYgAA-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmZmZmZmZmBmBAAAAAAYxY2GMDAAAAAAAAzYwYmZmxMzMMzyMjxm2WAAgBwYmZ2mZmmtZ2mZYMjB"
}
```
:::

:::details 来源计算器编码
```
#IX-NOUfDEKehmFIIJLVKBccwklBOmKYMNdtpNA-AHKXGMSsiJKU48MVVptEJJttxBOSApD-AAAA-DIMSUuw0UY4BQB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMzMzMzMzMwMAAAAAAALPwY2GMDAAAAAAAAzYwYmZmZmZmhZWmhxmWWAAgBwYmZWmZmmtZ2mZGMjB"
}
```
:::

:::details 来源计算器编码
```
#IX-NOUfDEKehmFIIJLVAccwklVaYNmupVAca6C-AHKXGMSsgJKUg48UVptEJJttx5NSApD-AAAA-DIMSUuw0UYwBQB-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwYmZmZmZmhZWmZM20yCAAMAGzMzyMz0sNzmZGjZMA"
}
```
:::

:::details 来源计算器编码
```
#IX-NOUfEKehmFIIJVIBccwklVCZMmupVIAca6C-AHKXGMSsgJKUg48MVVptEJJx5BOSApD-AAAA-DIMSUuw0UYwBQB-
```

:::

### 天赋方案 1-3

:::talents 天赋构筑
```json
{
  "code": "CgcBAAAAAAAAAAAAAAAAAAAAAAAWMmZmZmZmxwMAAAAAAAmxAmBAAAAAAAgZMDjZmZmZmZGmZbmxYTbbAAwAYmZmZbmZa2mZzMjxMGA"
}
```
:::

:::details 来源计算器编码
```
#IX-NOQUfEKehmFIIJLklAOOYyyAHTFMmmssuQB-AHKXHMSsiJKUg48MVVptEJJx5BOSAtD-AAAA-DIMSUuw0UY4BQB-
```

:::

### 天赋方案 0-0

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者的天赋在单体和范围伤害中玩法非常相似，共享许多相同的技能和优先级。其目标是尽快循环狂怒和灵魂，以获取[[spell:471306]]。当与[[spell:1242492]]搭配时，这可以实现更长的窗口期来利用[[spell:1227707]]，从而带来巨大的[[spell:1221167]]收益。一些额外的注意事项：

- [[spell:1242492]]在单体天赋中始终在最终选择节点上点出。其提供的渐进急速是尽可能延长[[spell:471306]]的关键。
- [[spell:1246555]]始终优先于[[spell:1246556]]，因为两次充能可以提供更流畅的循环和更短的预热时间。
- 由于[[spell:1253676]]在单体战斗中只会激活一次，因此选择[[spell:1279247]]提供的纯粹[[spell:1253304]]吞吐量。

### 天赋方案 0-1

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者的天赋在单体和范围伤害中玩法非常相似，共享许多相同的技能和优先级。其目标是尽快循环狂怒和灵魂，以获取[[spell:471306]]。当与[[spell:1242492]]搭配时，这可以实现更长的窗口期来利用[[spell:1227707]]，从而带来巨大的[[spell:1221167]]收益。一些额外的注意事项：

- [[spell:1242492]]在单体天赋中始终在最终选择节点上点出。其提供的渐进急速是尽可能延长[[spell:471306]]的关键。
- [[spell:1246555]]始终优先于[[spell:1246556]]，因为两次充能可以提供更流畅的循环和更短的预热时间。
- 此天赋可灵活切换为[[spell:1226033]]以获得额外的顺劈伤害。
- 如果面对的是持续多目标且纯单体伤害极少的战斗，可以放弃[[spell:1239537]]，在[[spell:1247538]]上投入一点。

### 天赋方案 0-2

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者的范围伤害天赋与其单体配置非常相似，仍然会点出[[spell:1242492]]以延长[[spell:471306]]窗口。一些额外的注意事项：

- 选择[[spell:1279247]]而非[[spell:1253676]]，是因为其稳定的伤害收益以及对首领伤害的提升。在较低层数的秘钥或频繁脱离战斗的情况下，末日使者则值得切换。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者点出整个右侧的基石区域以达到[[spell:1226033]]。这有助于在引导[[spell:473728]]后将[[spell:1226019]]转化为范围伤害工具，使你能够施加来自[[spell:1238488]]和[[spell:1238739]]的伤害加成以获得额外价值。

### 天赋方案 1-0

的身份是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄更侧重于噬灭的近战工具，赋予其一种在近战范围内进进出出的独特玩法。因此，基石区域左侧的整个部分是获取其大部分伤害所必需的。一些额外的注意事项：

- [[spell:1245453]]和[[spell:1226019]]是循环的核心部分，大多数增强它们的天赋（[[spell:1239537]]、[[spell:1238739]]、[[spell:1238488]]、[[spell:1244222]]）都被点出以强化它们。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 由于12.1.5的改动，虚痕枭雄现在点出了巅峰天赋[[spell:1242486]]。[[spell:1221167]]现在是
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄的强大工具，并重置[[spell:1246167]]，使你能够为后续的坍缩之星施加[[spell:1240201]]。

### 天赋方案 1-1

的身份是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄更侧重于噬灭的近战工具，赋予其一种在近战范围内进进出出的独特玩法。因此，左侧贯穿了大量关键天赋——最值得注意的是[[spell:1246167]]（现已移至天赋树的中间部分）和基石区域的[[spell:1239519]]。一些额外的注意事项：

- 在顺劈中，[[spell:1226019]]很少使用，更偏向单体。在持续多目标的战斗中，放弃[[spell:1239537]]，在[[spell:1244295]]上投入一点。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 由于12.1.5的改动，虚痕枭雄现在点出了巅峰天赋[[spell:1242486]]。除了[[spell:1221167]]现在造成的高伤害外，它还通过[[spell:1246167]]的重置得到进一步提升，而重置又会为你的下一个坍缩之星施加[[spell:1240201]]。

### 天赋方案 1-2

大部分 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄的技能组非常适合范围伤害场景，因为当与[[spell:1246160]]搭配时，噬灭天赋树左侧的近战天赋能很好地扩展到范围伤害。由于12.1.5的改动，它转向了[[spell:1242492]]，以积累并打出爆发性的[[spell:1221167]] / [[spell:1246167]]连招，旨在尽可能延长[[spell:471306]]。一些额外的注意事项：

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 由于[[spell:1221167]]重新回归其玩法，虚痕枭雄现在重新点出了巅峰天赋[[spell:1242486]]。
- [[spell:1226033]]和[[spell:1246167]]现已移至天赋树中部，并且始终点出。前者通过[[spell:1226019]]的范围伤害转化提供极高效率的顺劈，而后者是你[[spell:1246160]]连招的核心组成部分。
- 虽然使用[[spell:198793]]是正确的，但其整体伤害贡献很小，如果使用它会让你陷入危险情况，可以跳过。

以上列出的天赋是基于强度和流行度的推荐，

```
covering each area of content in endgame PvE. Each build has its own rotation to

execute, with unique aspects to master, with their own tricks up their sleeve to

assist your group in different encounters.
```

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)万世卷册是一个玩家强度系统，

```
that provides a small number of performance boosting effects, unlocked through a

series of quests. These bonuses aren't related to any gear pieces, and are

always active on your character. Some provide additional damage, while others

grant some healing and extra defensive tools.
```

下面，我们列出了五个符文的推荐，它们会随着你的

```
complete the Folio quest:
```

- 符文1：[[spell:1279599]]
- 符文2：[[spell:1279604]]
- 符文3：[[spell:1287555]]
- 符文4：[[spell:1279612]]
- 符文5：[[spell:1279614]]

值得注意的是，这些效果之间的差异非常

```
minor. The fourth stat boosting Rune is relevant, however, providing a solid

amount of your chosen secondary through regular procs.
```

1.

### 巅峰天赋： ![Midnight Icon](<https://static.icy-veins.com/images/wow/large_icons/artifactability_balancedruid_newmoon.jpg>) 至暗之夜

至暗之夜 中新增了天赋巅峰系统，这是一组在你从80级升到90级时依次解锁的天赋。

```
unlock as you acquire each specialization tree talent point on the journey from 80

to 90. These are grouped together in 4, with different effects at each level.

Unlike other talents, they are all in one node, with each point invested enhancing

the effect. The Devourer Demon Hunter Apex is [[spell:1242486]],

providing significant benefits to [[spell:1221167]]:
```

1. [[spell:1242486]] — 你的 [[spell:1221167]] 将必定造成暴击。
2. [[spell:1250088]] — 拥有两个点数，每点使你造成的所有宇宙伤害
   
   
   
   
   提高3%，并使[[spell:1221167]]的暴击伤害提高50%
   
   
   
   
   按你暴击几率的50%提升。该加成与 [[spell:1242495]] 为加法叠加。
3. [[spell:1250094]] — 进入 [[spell:471306]] 时，立即
   
   
   
   
   生成5个灵魂碎片，并立即获得一次 [[spell:1221167]] 的施放机会。

巅峰天赋显著增强了[[spell:1221167]]的威力，

```
turning it into one of our strongest damage sources. The final point in particular

also provides access to an immediate cast, making each [[spell:471306]]

entry impactful.
```

1.

### 英雄天赋

除了是一个全新的专精之外，噬灭还带来了

```
with it a new Hero tree, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator. This is shared with Vengeance,

while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) Void-Scarred is functionally equivalent to Havoc's

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred. In the two tabs below we've covered the major talents and

key effects that influence your build depending on your selection.
```

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者侧重于其基石效果[[spell:1253304]]。各种

```
of Devourer abilities (most importantly [[spell:473662]] and [[spell:473728]])

grant a stack, and upon reaching three, your next [[spell:1226019]] cast will consume

them. Each stack consumed calls down a powerful Void Meteor, dealing heavy Cosmic

damage to targets and generating 2 Soul Fragments. The playstyle is relatively

simple, only requiring you to slot in additional Reap casts to consume

stacks as they cap out.
```

对于进攻性选择节点，[[spell:1279247]]

```
provides a more general throughput increase to [[spell:1253304]], while

[[spell:1253676]] is tailored to Mythic+ and situations where you can

consistently leave combat to refresh the effect.
```

对于防御和机动性，[[spell:1256245]]每层提供2%的伤害减免

```
of [[spell:1253304]] present, with [[spell:1253805]] allowing it to persist after

you consume them. [[spell:1253399]] adds 3% movement speed on top of that,

though adding a third charge to [[spell:1234796]] with [[spell:1253402]] is

generally preferable.
```

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄在你的[[spell:471306]]期间提供各种好处

```
effect. Most importantly, [[spell:1245412]], [[spell:1239519]], and [[spell:1246167]]

are upgraded into more powerful versions while active. Additionally, the first

cast of each of these trigger a [[spell:1246160]] for extra AoE Cosmic damage.

This slots in over the regular Devourer playstyle, but <em>heavily</em>

encourages using a hybrid melee approach, leaping in and out of range to activate

these effects.
```

天赋树上的三个选择节点有以下选项：

- [[spell:452403]] 对比 [[spell:452404]] - 两者都是小众选择
  
  
  
  
  ```
  effects, with [[spell:452404]] generally being better for the small
  
  amount of extra mobility vs. the extra CC utility of [[spell:452403]].
  ```
- [[spell:452406]] 对比 [[spell:452407]] - 这是一个选择
  
  
  
  
  ```
  between passive damage reduction or self sustain. Generally speaking, staggering some
  
  damage with [[spell:452406]] so you can leech it back up is the preferred
  
  choice, but it's quite minor.
  ```
- [[spell:452412]] 对比 [[spell:452413]] - 这两者
  
  
  
  
  ```
  options are powerful, with [[spell:452413]] being stronger for Single
  
  Target and low cleave scenarios, while [[spell:452412]] edges it out
  
  in AoE situations.
  ```

1.

### PvP天赋（战争模式）

"战争模式"是一个可选功能，可开启开放世界PvP

```
encounters that confer some benefits when active:
```

- 在开放世界中获得使用PvP天赋的权限。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可以获得装备奖励。

鉴于战争模式对练级和PvE内容的益处，它是一个可选

```
way to maximize your leveling speed and reward potential. However, you will open

yourself up to open-world PvP, so be aware of hostile enemy players who could

interfere with you; this is a risk you will have to decide on your own if you want

to take.
```

在这里，我们只关注那些在协助地下堡方面有实际用途的PvP天赋

```
leveling or open-world PvE scenarios, as their PvP benefits are discussed on our

PvP page. Generally, the selections are made to optimize your ability to kill

enemies faster, increasing your pace when moving through content.
```

1. [[spell:1261414]]在你受到攻击时提供额外的灵魂生成，
   
   
   
   
   受到攻击后，会加快你进入 [[spell:471306]] 的速度。
2. [[spell:1261409]]增加[[spell:1221167]]的伤害，并且，
   
   
   
   
   更重要的是，使其不会被任何效果打断。
3. [[spell:1261697]]允许你在每次施放[[spell:1226019]]后立即接上一个瞬发
   
   
   
   
   [[spell:473662]]，从而更快地在目标身上进行准备。

然而[[spell:1261423]]对减缓消耗速度有巨大影响

```
at which you can enter [[spell:471306]]. While it does make these

windows more explosive, the hit to frequency means it's not worth using.
```

[[spell:205596]]、[[spell:357419]]、[[spell:205625]]和

```
[[spell:354489]] all have minimal uses in PvE, due to being more focused on

crowd control tools, or pressuring enemy players, so aren't worth considering.
```

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月18日：** 已更新至8月18日的职业调整。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日：** 已根据在线修复进行更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对12.0.1补丁进行更新。
- **2026年1月31日：** 已更新至至暗之夜前夕补丁的在线修复。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年12月13日：** 已更新至最新的测试服改动。
- **2025年12月6日：** 已更新至最新的测试服改动。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年11月15日：** 页面已更新至测试服发布改动。默认的歼灭者构筑切换为施法者变体。
- **2025年11月9日：** 为至暗之夜测试服创建页面

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标情况下优化你的噬灭 恶魔猎手的循环。我们还有关于冷却时间、触发效果等方面的进阶章节，以最大化你的DPS。我们所有的内容均已针对魔兽世界12.1.5补丁更新。

1.

### 噬灭 恶魔猎手玩法与循环指南

欢迎来到我们《至暗之夜》中的噬灭 恶魔猎手指南的循环部分。

至暗之夜！在这里，我们介绍《魔兽世界》的全部玩法细节

最新专精的所有玩法细节，涵盖单体和范围伤害两种战斗风格。

由于噬灭是一个新专精——包括新的英雄天赋树——我们已经在我们的

页面上介绍了它们各自的工作原理。如果 [天赋](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spec-builds-talents>) 你想直接开始，下面是关于它们

如果你想直接上手，下面是关于它们如何的一些快速上手细节

工作：

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 –
  
  
  
  
  更偏向于纯施法者玩法，它积累[[spell:1253304]]层数，
  
  
  
  
  在消耗层数时通过[[spell:1226019]]造成爆发性的额外伤害。在
  
  
  
  
  12.1.5补丁中，此天赋树推荐用于所有情况。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 –
  
  
  
  
  更侧重于在[[spell:471306]]期间打出快速的伤害爆发，
  
  
  
  
  每次你变身时，通过各种噬灭法术触发[[spell:1246160]]。
  
  
  
  
  独特的是，这涉及一些近战技能，鼓励你
  
  
  
  
  在与目标的近战中进进出出。虽然此天赋树伤害潜力很高，
  
  
  
  
  但很容易被打断，因此目前不推荐。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者

团队副本 / 单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境 / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄

团队副本 / 单体目标

大秘境 / AoE

主动天赋

被动天赋

[[spell:1226033]]

[[spell:1239519]]

[[spell:1246167]]

[[spell:1242492]]

[[spell:1247534]]

[[spell:1240201]]

[[spell:1239537]]

### 单体目标

1.1.

#### 噬灭 恶魔猎手单体循环

**适用条件：歼灭者（启用）。** 特别是在单目标战斗中，管理[[spell:471306]]至关重要。因此，我们将输出循环分为两个部分——第一个是它未激活时，第二个是它激活时。作为的[[spell:471306]]目标是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，目标是尽可能延长它，叠加[[spell:1242492]]以强化重复的[[spell:1221167]]施放。

**适用条件：虚痕枭雄（启用）。** 特别是在单目标战斗中，管理[[spell:471306]]至关重要。因此，我们将输出循环分为两个部分——第一个是它未激活时，第二个是它激活时。当玩时[[spell:471306]]的目标是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄时，目标是尽可能延长它，最大化[[spell:1221167]]的施放次数，以利用[[spell:1246167]]的重置和[[spell:1245412]]的冷却缩减。

---

1.2.

#### 虚空变形循环之外

1. 在有[[spell:1297433]]触发时施放[[spell:473662]]
2. 在有4个以上灵魂激活时施放[[spell:1226019]]
3. 如果当前未激活，则施放[[spell:1241937]]
4. **适用条件：噬灭's 撕咬（启用）；歼灭者（未启用）。** 施放[[spell:1245412]]，如果它将在10个灵魂内就绪，在进入[[spell:471306]]之前使用。
5. **适用条件：狩猎（启用）；歼灭者（未启用）。** 在[[spell:1245412]]之后施放[[spell:198793]]，如果即将进入[[spell:471306]]且[[spell:1246167]]可用。
6. **适用条件：狩猎（启用）；歼灭者（未启用）。** 如果即将进入[[spell:471306]]，施放[[spell:1246167]]
7. 在拥有足够灵魂时施放 [[spell:471306]]，如有可用的使用型饰品和药水则一并使用
8. **适用条件：Hungering Slash（启用）；歼灭者（未启用）。** 施放 [[spell:1239519]]
9. **适用条件：Hungering Slash（启用）；歼灭者（未启用）。** 在受到 [[spell:1239520]] 增益时施放 [[spell:198793]]
10. 在拥有 100 点或更多 狂怒 时施放 [[spell:473728]]
11. 施放 [[spell:473662]] 以产生 狂怒

---

1.3.

#### 虚空变形循环内部

1. 在触发 [[spell:1297433]] 时施放 [[spell:1217610]]
2. 施放 [[spell:473728]]
3. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245470]]
4. **适用条件：虚痕枭雄（启用）。** 在 [[spell:1239520]] 激活时施放 [[spell:198793]]
5. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245483]]
6. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1259431]]
7. 在拥有 30 个灵魂时施放 [[spell:1221167]]
8. **适用条件：Second Helping（未启用）。** 在拥有 4 个灵魂碎片时施放 [[spell:1245453]]
9. **适用条件：Second Helping（启用）。** 在拥有 4 个灵魂碎片或拥有两层充能时施放 [[spell:1245453]]
10. 施放 [[spell:1217610]]
11. 在脱离 [[spell:471306]] 时施放 [[spell:1241937]]

1.4.

#### 噬灭 单体目标注意事项

噬灭 的玩法循环完全围绕其 狂怒 和灵魂生成循环构建，为你的 [[spell:473728]] 和 [[spell:471306]] 窗口提供资源。快速循环以使用更多这些技能是关键。根据所选天赋的一些具体注意事项如下：

- **适用条件：歼灭者（启用）。** [[spell:1242492]] 在所有天赋中都会点出，因此延长 [[spell:471306]] 是目标。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，目标是每个窗口打出 4-5 次 [[spell:1221167]]。
- **适用条件：歼灭者（未启用）。** [[spell:1242492]] 在所有天赋中都会点出，因此延长 [[spell:471306]] 是目标。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，目标是每个窗口打出施放次数。
- 由于你可以在移动时施放 [[spell:473662]] / [[spell:1217610]]，你可以在移动过程中收集附近灵魂以积累 [[spell:471306]] 和 [[spell:1221167]]。理想情况下，使用 [[spell:1226019]] 和 [[spell:1245453]] 来实现这一点，但这可以在这些技能处于冷却时让你获得使用机会。这在长时间 [[spell:471306]] 结束时非常强大，可以延长它并达到另一个 [[spell:1221167]]。
- 由于新的套装效果，[[spell:1226019]] 在整个循环中被频繁使用。只要能收集 4 个或更多灵魂时就使用它。
- **适用条件：歼灭者（启用）；噬灭's 撕咬（启用）。** 对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，使用 [[spell:1245412]] 来触发 [[spell:1240201]] 的伤害增益。只要能增强 [[spell:1221167]] 和/或被 [[spell:1238488]] 强化的 [[spell:1245453]] 施放，就使用这个技能。
- [[spell:473728]] 被积极使用。在 [[spell:471306]] 之外，应在达到 100+ 狂怒 时使用，变形期间则按冷却使用以暂停 狂怒 的消耗。
- **适用条件：虚痕枭雄（启用）。** 尽量在进入 [[spell:471306]] 之前施放 [[spell:1245412]] 或 [[spell:1246167]]，以偷入一层 [[spell:1239519]] 充能。
- **适用条件：虚痕枭雄（启用）。** 对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，在施放 [[spell:1221167]] 之前使用 [[spell:1245412]] 和 [[spell:1246167]]，以利用其提供的冷却缩减和重置效果。

### 群体伤害

1.5.

#### 噬灭 恶魔猎手 AoE优先级

**适用条件：歼灭者（启用）。** 与单目标类似，管理[[spell:471306]]对AOE玩法至关重要。因此，我们将输出循环分为两个部分——第一个是它未激活时，第二个是它激活时。当玩时[[spell:471306]]的目标是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 时，目标是尽可能延长它，同时叠加 [[spell:1242492]]，尽可能多地施放 [[spell:1221167]]。

**适用条件：虚痕枭雄（启用）。** 与单目标类似，管理[[spell:471306]]对AOE玩法至关重要。因此，我们将输出循环分为两个部分——第一个是它未激活时，第二个是它激活时。当玩时[[spell:471306]]的目标是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 时，目标是尽可能延长它，同时叠加 [[spell:1242492]]，尽可能多地施放 [[spell:1221167]]、[[spell:1246167]] 和 [[spell:1245412]]。

---

1.6.

#### 虚空变形循环外：

1. 在有[[spell:1297433]]触发时施放[[spell:473662]]
2. 在地面上有 10 个灵魂时，或 [[spell:1238488]] 即将结束时，施放 [[spell:1226033]]
3. 在拥有 100 狂怒 时施放 [[spell:473728]]
4. **适用条件：虚痕枭雄（启用）；噬灭's 撕咬（启用）。** 施放 [[spell:1245412]]。
5. 在拥有足够灵魂时施放 [[spell:471306]]，如有可用的使用型饰品和药水则一并使用
6. **适用条件：虚痕枭雄（启用）；Hungering Slash（启用）。** 施放 [[spell:1239519]]
7. **适用条件：虚痕枭雄（启用）；Hungering Slash（启用）。** 在拥有 [[spell:1239520]] 时施放 [[spell:198793]]
8. **适用条件：歼灭者（启用）。** 在拥有 3 层 [[spell:1253304]] 时施放 [[spell:1226019]]/[[spell:1226033]]。
9. **适用条件：虚痕枭雄（启用）。** 在拥有 4 个或更多灵魂时施放 [[spell:1226019]]。
10. 如果当前未激活，则施放[[spell:1241937]]
11. 施放 [[spell:473662]]

---

1.7.

#### 虚空变形循环内：

1. **适用条件：歼灭者（启用）。** 如果即将超过 40 个收集的灵魂，则施放 [[spell:1221167]]。
2. **适用条件：歼灭者（启用）。** 在拥有 3 层 [[spell:1253304]] 时施放 [[spell:1245453]]/[[spell:1226033]]。
3. **适用条件：Eradicate（启用）；虚痕枭雄（启用）。** 施放 [[spell:1226033]]
4. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:473728]]
5. **适用条件：Eradicate（启用）；歼灭者（启用）。** 施放 [[spell:1226033]]
6. **适用条件：歼灭者（启用）。** 施放 [[spell:473728]]。
7. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245470]]
8. **适用条件：虚痕枭雄（启用）。** 在拥有 [[spell:1239520]] 时施放 [[spell:198793]]
9. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245483]]
10. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1259431]]
11. 施放 [[spell:1221167]]。
12. 施放 [[spell:1217610]]。
13. 在脱离 [[spell:471306]] 时施放 [[spell:1241937]]。

1.8.

#### 噬灭 恶魔猎手 AoE注意事项

- 目标是尽可能多地施放 [[spell:1221167]]。这个数量取决于你的天赋选择，以及面对的目标数量。
- 由于你可以在移动时施放 [[spell:473662]] / [[spell:1217610]]，如果发现自己 **几乎** 能够施放 [[spell:473728]]、[[spell:471306]] 或 [[spell:1221167]]，就收集一个灵魂。
- 在 AoE 中，[[spell:1226019]] / [[spell:1245453]] 的施放会通过 [[spell:1226033]] 触发获得强化，无论你处于哪种形态。这会在 [[spell:473728]] 之后立即触发，因此与 [[spell:1238488]] 对齐。目标是在能提供足够 狂怒 或灵魂以施放 [[spell:473728]] 时使用，或在 [[spell:1238488]] 即将结束时使用。
- **适用条件：歼灭者（启用）。** 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，[[spell:1226019]] / [[spell:1245453]] 和 [[spell:1226033]] 也被用来触发 [[spell:1253304]]。唯一的例外是在使用 [[spell:471306]] 之前，我们选择不消耗可用的 [[spell:1253304]]，以便将 [[spell:1226033]] 带入 [[spell:471306]]。
- **适用条件：歼灭者（启用）。** 尽量将一个 [[spell:1226033]] "偷入" 每次 [[spell:471306]] 中。目标是在 [[spell:471306]] 之前使用 [[spell:473728]]，然后将 [[spell:1226033]] 的触发带入其中。
- **适用条件：虚痕枭雄（启用）。** 尽量将一个 [[spell:1226033]] "偷入" 每次 [[spell:471306]] 中。目标是在 [[spell:471306]] 之前使用 [[spell:473728]]，然后将 [[spell:1226033]] 的触发带入其中。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，也尽量通过 [[spell:1245412]] / [[spell:1246167]] 对 [[spell:1239519]] 做同样的事，前提是这不会过多延迟进入时间。
- **适用条件：虚痕枭雄（启用）。** 虽然 [[spell:198793]] 是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 循环的一部分，但它只是次要的，所以只有在能保证安全站位时才使用它。
- **适用条件：虚痕枭雄（启用）。** 对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，近战连招有几个顺序步骤。根据你当前的形态，顺序是：
  
  
  
  
  <em>外部：</em> [[spell:1246167]] / [[spell:1245412]] ➜ [[spell:1239519]] ➜ [[spell:198793]]
  
  
  
  
  <em>内部：</em> [[spell:1259431]] / [[spell:1245483]] ➜ [[spell:1245470]] ➜ [[spell:198793]]
  
  
  
  
  这些可以作为独立的三段连招施放，或者作为更长的六段循环。

### 单体起手

1.9.

#### 噬灭 恶魔猎手 单体目标起手式

**适用条件：歼灭者（启用）。** 由于 [[spell:1253304]]， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 的起手式可以是动态的。以下是一个建议，但如果 [[spell:1253304]] 触发，应在施放另一个 [[spell:473662]] 之前使用 [[spell:1226019]] 来消耗它。

**适用条件：虚痕枭雄（启用）。** 该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 的起手式因触发而可以是动态的。以下是一个建议，但 [[spell:1241937]] 和额外的灵魂触发可以加快循环速度。其目标是尽快进入 [[spell:471306]]

---

**适用条件：虚痕枭雄（启用）。**

[[spell:1241937]]

2s

拉怪

[[spell:473662]]

x2

[[spell:1226019]]

[[spell:1246555]]

[[spell:1226019]]

[[spell:473728]]

**适用条件：Eradicate（启用）；Emptiness（启用）。**

**适用条件：Eradicate（启用）；Emptiness（启用）。**

[[spell:1226033]]

**适用条件：Eradicate（启用）；Emptiness（启用）。**

[[spell:473662]]

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:1226019]]

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:473662]]

**适用条件：Emptiness（启用）。**

**适用条件：Emptiness（启用）。**

[[spell:473728]]

**适用条件：Emptiness（启用）。**

[[spell:473662]]

[[spell:1245412]]

[[spell:1246167]]

[[spell:198793]]

[[spell:471306]]

[[item:250215]]

[[item:241288]]

[[spell:473728]]

[[spell:1245470]]

[[spell:1245483]]

[[spell:198793]]

[[spell:1221167]]

[[spell:1245470]]

[[spell:1259431]]

[[spell:198793]]

[[spell:1245470]]

[[spell:1245453]]

[[spell:198793]]

[[spell:473728]]

**适用条件：歼灭者（启用）。**

[[spell:1241937]]

2s

拉怪

[[spell:473662]]

x2

[[spell:1226019]]

[[spell:1241937]]

[[spell:473662]]

x2

[[spell:1226019]]

[[spell:473728]]

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:473662]]

x2

**适用条件：Eradicate（未启用）。**

[[spell:1226019]]

**适用条件：Eradicate（启用）。**

**适用条件：Eradicate（启用）。**

[[spell:473662]]

**适用条件：Eradicate（启用）。**

[[spell:1226033]]

**适用条件：Emptiness（启用）。**

[[spell:473728]]

**适用条件：Emptiness（启用）。**

[[spell:473662]]

[[spell:471306]]

[[item:250215]]

[[item:241288]]

[[spell:473728]]

**适用条件：Eradicate（启用）。**

**适用条件：Eradicate（启用）。**

[[spell:1221167]]

**适用条件：Eradicate（启用）。**

[[spell:1226033]]

**适用条件：Eradicate（未启用）。**

[[spell:1221167]]

---

1. 在开怪前 2 秒预读 [[spell:1241937]]
2. 施放两次 [[spell:473662]] 然后施放 [[spell:1226019]]
3. 施放 [[spell:1241937]]
4. 施放两次 [[spell:473662]] 然后施放 [[spell:1226019]]
5. 施放 [[spell:473728]]
6. **适用条件：Emptiness（启用）；Eradicate（未启用）。** 施放两次 [[spell:473662]] 然后施放 [[spell:1226019]]
7. **适用条件：Emptiness（启用）；Eradicate（启用）。** 施放两次 [[spell:473662]] 然后施放 [[spell:1226033]]
8. **适用条件：Emptiness（启用）。** 施放 [[spell:473728]]
9. **适用条件：Emptiness（启用）。** 施放 [[spell:473662]]
10. **适用条件：虚痕枭雄（启用）；噬灭的撕咬（启用）；The Hunt（未启用）。** 施放 [[spell:1245412]]
11. **适用条件：虚痕枭雄（启用）；The Hunt（启用）。** 施放 [[spell:1245412]] 然后接 [[spell:198793]]
12. **适用条件：虚痕枭雄（启用）；The Hunt（启用）。** 施放 [[spell:1246167]]
13. 施放 [[spell:471306]]
    
    
    
    
    - 使用你的 [[item:241288]]
    - 使用使用型饰品，例如 [[item:250215]]
14. 施放 [[spell:473728]]
15. **适用条件：歼灭者（启用）；Eradicate（启用）。** 施放 [[spell:1221167]] 然后接 [[spell:1226033]]
16. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245470]] 然后接 [[spell:198793]]
17. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245483]]
18. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1221167]] 然后接 [[spell:1245470]]
19. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:198793]]
20. **适用条件：虚痕枭雄（启用）；The Hunt（启用）。** 施放 [[spell:1259431]]，然后施放 [[spell:1245470]]
21. **适用条件：歼灭者（启用）；Eradicate（未启用）。** 施放 [[spell:1221167]]
22. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:198793]] 接 [[spell:1245453]]
23. **适用条件：虚痕枭雄（启用）；Eradicate（未启用）。** 施放 [[spell:1245453]]
24. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:473728]]
25. 继续按照正常的技能优先级。

---

噬灭 的启动较慢，需要与 [[spell:1242492]] 配合才能打出第一个 [[spell:471306]]，因此通常需要经历两个资源循环才能开始第一轮冷却技能序列。

### AoE起手

1.10.

#### 噬灭 恶魔猎手 AOE起手

**适用条件：歼灭者（启用）。** 由于 [[spell:1253304]]， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 的起手式可以是动态的。以下是一个建议，但如果 [[spell:1253304]] 触发，应在施放另一个 [[spell:473662]] 之前使用 [[spell:1226019]] 来消耗它。

**适用条件：虚痕枭雄（启用）。** 该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 的起手会因触发效果而有所不同。以下是一个建议方案，但 [[spell:1241937]] 和额外的灵魂触发可以加快循环。目标是尽快进入 [[spell:471306]]。

---

**适用条件：歼灭者（启用）。**

[[spell:1241937]]

2s

拉怪

[[spell:473662]]

x2

[[spell:1241937]]

[[spell:473662]]

x2

[[spell:473728]]

**适用条件：Emptiness（启用）；Eradicate（启用）。**

**适用条件：Emptiness（启用）；Eradicate（启用）。**

[[spell:473662]]

x2

**适用条件：Eradicate（启用）。**

[[spell:1226033]]

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:473662]]

x2

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:1226019]]

**适用条件：Emptiness（启用）。**

[[spell:473728]]

**适用条件：Emptiness（启用）；Eradicate（启用）。**

[[spell:473662]]

[[spell:471306]]

[[item:250215]]

[[item:241288]]

**适用条件：Eradicate（未启用）。**

[[spell:1221167]]

**适用条件：Eradicate（启用）。**

**适用条件：Eradicate（启用）。**

[[spell:1221167]]

**适用条件：Eradicate（启用）。**

[[spell:1226033]]

**适用条件：Eradicate（启用）。**

**适用条件：Eradicate（启用）。**

[[spell:473728]]

**适用条件：Eradicate（启用）。**

[[spell:1226033]]

**适用条件：Eradicate（未启用）。**

[[spell:473728]]

**适用条件：Eradicate（启用）。**

[[spell:1221167]]

**适用条件：虚痕枭雄（启用）。**

[[spell:1241937]]

2s

拉怪

[[spell:473662]]

x2

[[spell:1241937]]

[[spell:1226019]]

[[spell:473662]]

x2

[[spell:473728]]

[[spell:1245412]]

[[spell:1239519]]

[[spell:198793]]

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:473662]]

x2

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:1226033]]

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:473662]]

x2

**适用条件：Emptiness（启用）；Eradicate（未启用）。**

[[spell:1226019]]

**适用条件：Emptiness（启用）。**

[[spell:473728]]

**适用条件：Emptiness（启用）；Eradicate（启用）。**

[[spell:1226033]]

[[spell:473662]]

x2

**适用条件：Emptiness（启用）；Eradicate（启用）。**

[[spell:473728]]

[[spell:471306]]

[[item:250215]]

[[item:241288]]

**适用条件：Eradicate（启用）。**

**适用条件：Eradicate（启用）。**

[[spell:473728]]

[[spell:1226033]]

**适用条件：Eradicate（未启用）。**

[[spell:473728]]

[[spell:1259431]]

[[spell:1245470]]

[[spell:1245483]]

[[spell:198793]]

[[spell:1221167]]

[[spell:1245470]]

[[spell:198793]]

**适用条件：Eradicate（启用）。**

[[spell:1226033]]

[[spell:1217610]]

[[spell:1217610]]

---

1. 在开怪前 2 秒预读 [[spell:1241937]]
2. 施放两次 [[spell:473662]]
3. 施放 [[spell:473662]]
4. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1226019]]
5. 施放 [[spell:1241937]]
6. 施放 [[spell:473728]]
7. **适用条件：虚痕枭雄（启用）；Hungering Slash（启用）。** 施放 [[spell:1245412]]
8. **适用条件：虚痕枭雄（启用）；Hungering Slash（启用）。** 施放 [[spell:1239519]] 接 [[spell:198793]]。
9. **适用条件：Eradicate（启用）；Emptiness（启用）。** 施放两次 [[spell:473662]] 然后施放 [[spell:1226033]]
10. **适用条件：Emptiness（启用）；Eradicate（未启用）。** 施放两次 [[spell:473662]]
11. **适用条件：Emptiness（启用）。** 施放 [[spell:473728]]
12. **适用条件：Emptiness（启用）。** 施放 [[spell:473662]]
13. 施放 [[spell:471306]]
    
    
    
    
    - 使用你的 [[item:241288]]
    - 使用使用型饰品，例如 [[item:250215]]
14. **适用条件：虚痕枭雄（启用）；Eradicate（启用）。** 施放 [[spell:1226033]]
15. **适用条件：虚痕枭雄（启用）；Eradicate（启用）。** 施放 [[spell:473728]]
16. **适用条件：歼灭者（启用）；Eradicate（启用）。** 施放 [[spell:1221167]] 然后接 [[spell:1226033]]
17. **适用条件：Eradicate（启用）；歼灭者（启用）。** 施放 [[spell:473728]] 接 [[spell:1226033]]
18. **适用条件：虚痕枭雄（启用）；Eradicate（未启用）。** 施放 [[spell:473728]]
19. **适用条件：虚痕枭雄（启用）；Hungering Slash（启用）；The Hunt（启用）。** 施放 [[spell:1259431]]，然后施放 [[spell:1245470]] 接 [[spell:198793]]
20. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:1245483]]。
21. 施放 [[spell:1221167]]
22. **适用条件：虚痕枭雄（启用）；Hungering Slash（启用）。** 施放 [[spell:1245470]] 然后接 [[spell:198793]]
23. **适用条件：歼灭者（启用）；Eradicate（未启用）。** 施放 [[spell:473728]]
24. **适用条件：虚痕枭雄（启用）。** 施放 [[spell:473728]]
25. 继续按照正常的技能优先级。

---

噬灭 的起手相当长，因为它需要积累大量灵魂才能打出 [[spell:471306]]。由于它使用 [[spell:1242492]]，从零开始意味着你需要经历几个资源循环才能到达第一个爆发窗口。

**适用条件：虚痕枭雄（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 的起手可能看起来有些混乱，因为进入 [[spell:471306]] 时你有很多按钮可用。与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 不同，在窗口开始时灵魂溢出是可以接受的，可以选择在施放 [[spell:1221167]] 之前使用 [[spell:1226033]]、[[spell:473728]]、[[spell:1259431]] 和 [[spell:1245483]]。

1.

### 至暗之夜 第2赛季套装

至暗之夜第2赛季引入了 **深渊末日猎犬的追击**，可获得

来自不同终局内容。这提供以下加成：

- [[spell:1296615]]——收割4个或更多灵魂
  
  
  
  
  碎片时使用[[spell:1226019]]有20%几率使你的下一个[[spell:473662]]
  
  
  
  
  变为瞬发并在 [[spell:1297433]] 中爆炸，对
  
  
  
  
  附近敌人造成大量宇宙伤害。
- [[spell:1296616]] — [[spell:1297433]]
  
  
  
  
  触发时产生2个灵魂碎片，并获得 [[spell:1238488]]。
  
  
  
  
  此外，[[spell:1226019]] 的伤害提高10%。

第2赛季套装引入了一个新的触发效果 [[spell:1297433]]，

产生资源并造成伤害。在赛季中期削弱

套装强度后，它只在单体战斗中被主动围绕使用。在

此之外，在AOE时正常施放 [[spell:1226019]] 即可，让触发效果

被动提供额外资源和伤害。

请注意，此效果 <em>确实</em> 同样会从 [[spell:1245453]] 和

[[spell:1226033]] 以相同的几率触发。

2.1.

#### 噬灭 恶魔猎手 机制详解

噬灭 是恶魔猎手最新的专精，并且

拥有一些非常独特的机制可供利用。下面我们将逐一介绍

每个关键组成部分，它们如何运作，并帮助你理解 <em>为什么</em> 你在

按下每个按钮时的意图。

1.

### 噬灭 机制详解

### 巅峰天赋：至暗之夜

3.1.

#### 巅峰天赋：至暗之夜

至暗之夜 引入了巅峰天赋，它们是位于

专精天赋树底部的四阶天赋节点，在从80级升到90级的过程中解锁。

独特的是，它们是顺序节点，每投入一点额外

点数都会添加不同的效果。要访问下一级天赋，你 <em>必须</em> 必须投入点数

到上一个节点，不能直接跳到强大的终点。对于 噬灭，

巅峰天赋完全专注于 [[spell:1221167]]，大幅提升其

伤害！

- **第1点：[[spell:1242486]] -** 第一个巅峰节点，使你的
  
  
  
  
  [[spell:1221167]] 总是暴击。这大大提高了该
  
  
  
  
  技能的伤害，并与已经很强大的天赋
  
  
  
  
  [[spell:1242495]] 产生协同效应，进一步提升坍缩之星的伤害。
- **第2和第3点：[[spell:1250088]] -** 使你造成的
  
  
  
  
  所有 噬灭 技能的宇宙伤害每点提高3%。此外，它还提高
  
  
  
  
  使[[spell:1221167]]的暴击伤害提高，增幅为你暴击数值的50%
  
  
  
  
  几率的50%，这是 <em>加法</em>计算的。例如，如果你有20%
  
  
  
  
  暴击几率，你的坍缩之星将暴击造成220%
  
  
  
  
  伤害（有 [[spell:1242495]] 时为260%伤害）。
- **第4点：[[spell:1250094]] -** 投入所有点数后解锁的
  
  
  
  
  对循环影响最大的节点。点出后，每次你进入
  
  
  
  
  [[spell:471306]] 时，你会产生五个灵魂碎片，并立即
  
  
  
  
  获得 [[spell:1221167]] 的使用权。这实际上意味着一颗免费的星星，以及
  
  
  
  
  朝向第二次施放的8个灵魂（因为 [[spell:1240204]] 提供的额外三个），
  
  
  
  
  同时也提升了 [[spell:1227707]]。

虽然 噬灭 的英雄天赋没有与之产生

巅峰天赋没有特定的互动，但它们各自都有利用这个即时施放的方式。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 允许你在变形后立即触发 [[spell:1256307]]，

而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 可以利用快速访问来重置

[[spell:1246167]] / [[spell:1259431]].

### 资源管理

3.2.

#### 噬灭 资源管理

噬灭 是一个 **双资源** 专精，需要平衡

其 狂怒 和灵魂碎片作为技能的燃料。取决于你

当前是否处于 [[spell:471306]]，它们各自发挥双重

作用。

3.2.1.

##### 狂怒

狂怒 是你的主要资源， <em>在</em> [[spell:471306]],

用于施放 [[spell:473728]]。其上限为120（ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者,

或140（ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄），你应该始终避免

溢出浪费。它通过施放 [[spell:473662]]、

[[spell:1245412]] / [[spell:1239519]]（当 [[spell:1241937]] 处于

激活状态时），或收集灵魂碎片来产生。虚空射线在引导结束后也会产生10点，

通过 [[spell:1240202]]。

虽然 <em>进入</em> [[spell:471306]] 期间，你的技能不再消耗

狂怒，而是在变形期间被动流失。当你完全耗尽

出，该效果结束，因此产生对于维持收益仍然至关重要

你的冷却时间。

3.2.2.

##### 灵魂残片

灵魂在收集时提供4点狂怒，并填满你的副资源条。

当你达到50（或在使用[[spell:1247534]]时达到35）时，你就能获得

你的[[spell:471306]]形态。在变形期间，每产生30个灵魂

也会允许你施放[[spell:1221167]] **一次**。灵魂由

各种技能和天赋产生，列举如下：

- [[spell:473662]]通过[[spell:1215617]]生成1个灵魂
- [[spell:178940]]使你所有的技能伤害都有几率生成一个灵魂
- [[spell:1261684]]每12秒被动生成1个灵魂
- [[spell:1241937]]在其持续时间内生成3个灵魂
- [[spell:473728]]通过[[spell:1223918]]生成大量灵魂
- [[spell:1221167]]通过[[spell:1240204]]生成3个灵魂
- [[spell:471306]]在进入时通过[[spell:1250094]]生成5个灵魂

你最多只能同时拥有 **10** 个地上的灵魂。之后的任何灵魂

在生成新的灵魂时会被自动收集。此外，任何

在达到50个上限后收集的灵魂，在 <em>在</em> [[spell:471306]]

（使用[[spell:1247534]]时为35）或变形期间为40时，都会被浪费。这意味着

你要尽量避免收集任何灵魂，直到你激活了你的

窗口，或在可用时施放[[spell:1221167]]。

3.2.3.

##### 管理技巧

由于两种资源的重要性会根据你的

[[spell:471306]]状态而波动，所以可能需要一点时间来适应。

刚开始时的一些快速提示：

- **不要浪费狂怒或灵魂 -** 注意两个上限，并始终努力
  
  
  
  
  保持在这些限制以下。两者都有一个小缓冲，所以好好利用它。
- **收割前先检查 -** 请记住[[spell:1226019]]会收集
  
  
  
  
  灵魂并为每个灵魂生成4点狂怒，所以如果会显著
  
  
  
  
  超出你的资源上限，请考虑暂缓使用。
- **囤积灵魂 -** 灵魂是非常重要的资源，所以尽量在
  
  
  
  
  进入和离开[[spell:471306]]时，让地面上留有一些灵魂。
- **积极使用消耗技能 -** 两种资源的产生速度可以非常
  
  
  
  
  快，所以一旦[[spell:473728]]和[[spell:1221167]]激活就
  
  
  
  
  尽快使用。

### 虚空射线

3.3.

#### 虚空射线

[[spell:473728]]是噬灭的主要 <em>消耗技能</em> ，在[[spell:471306]]之外，

而在其内部则是一个关键的冷却技能。这相当于该专精的

浩劫的[[spell:198013]]和复仇的[[spell:212084]]，拥有

25码射程。它可以引导最多3秒（受急速影响而缩短），

并在持续期间造成大量宇宙伤害，同时使你定身在原地。

独特的是，它具有双重功能，取决于你当前的[[spell:471306]]状态。

虽然 <em>在</em> 该形态下，它没有冷却时间，但施放需要消耗100点狂怒。

虽然 <em>进入</em>，它有16秒的急速冷却（被缩短至14秒，

[[spell:1244220]]），并且会暂停你的恶魔之怒流失，无论是在引导期间还是

结束后短暂。由于是噬灭的核心部分，它拥有许多

天赋可以增强它：

- **[[spell:1223918]] —** 显著增加其产生的灵魂
  
  
  
  
  数量，使其成为你最可靠的灵魂来源之一。
- **完整引导奖励 ——** 四个天赋选项为完成引导
  
  
  
  
  提供回报。[[spell:1240202]]提供10点狂怒，[[spell:1226033]]
  
  
  
  
  和[[spell:1238488]]强化你随后的[[spell:1226019]]施放，而
  
  
  
  
  [[spell:1266500]]将最后一跳的伤害提高300%。
- **伤害增幅器 ——** [[spell:1240203]]在[[spell:473728]]
  
  
  
  
  击中三个或更少目标时，使其伤害提高80%，而[[spell:1247538]]
  
  
  
  
  每点使其造成的所有伤害提高10%。

由于其原始伤害以及与之相关的效果，尽可能多地施放

[[spell:473728]]是理想的，最好是一可用就施放。这意味着

在[[spell:471306]]之外，避免狂怒浪费尤其重要，

因为这直接导致虚空射线施放次数减少。

### 近战技能

3.4.

#### 近战技能

独特的是，噬灭带有若干天赋选项，鼓励

你短暂跳入近战范围使用几个全局冷却，然后再快速跳回

出。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄尤其强调这种玩法，其核心

天赋为：

- **[[spell:1245412]] —** 30秒冷却的技能，跳向
  
  
  
  
  你的目标，造成大量宇宙伤害并产生狂怒。拥有
  
  
  
  
  若干天赋可以强化它，例如[[spell:1246562]]，
  
  
  
  
  [[spell:1240201]]、[[spell:1272770]]和[[spell:1272432]]。
- **[[spell:1246167]] —** 90秒冷却，冲锋至你的目标，
  
  
  
  
  造成宇宙伤害，并对该目标和路径上最多5个敌人
  
  
  
  
  施加持续伤害效果。你的碰撞箱在此之后仍会保持几秒，允许
  
  
  
  
  你对错过的任何目标施加持续伤害效果。
- **[[spell:1239519]] —** “近战组合技”的核心。使用
  
  
  
  
  [[spell:1245412]]或[[spell:1246167]]后，它们会被替换为
  
  
  
  
  动作条上的此技能，使你在周围进行弧形挥砍。此技能
  
  
  
  
  击碎2个灵魂，产生10点狂怒，并可被[[spell:1272432]]进一步增强，
  
  
  
  
  [[spell:1272770]]和[[spell:1247538]]。此外，
  
  
  
  
  使用时会触发[[spell:1239520]]，获得一次免费施放
  
  
  
  
  [[spell:198793]]的机会，施放时对附近敌人造成宇宙伤害。
  
  
  
  
  这使你可以跳入、完成连招，然后快速返回远程位置。
- **[[spell:1272422]] —** 为[[spell:1245412]]增加额外价值
  
  
  
  
  在[[spell:471306]]期间。这使它和[[spell:1246167]]
  
  
  
  
  在施放时短暂暂停狂怒消耗，同时还将虚空之刃的
  
  
  
  
  冷却时间在每次[[spell:1221167]]施放后减少10秒。这使得
  
  
  
  
  它们对于进一步延长你的变形时间非常有用！

所有这些天赋结合在一起，强烈鼓励你穿插一些快速的

近战连击以获得巨大回报，尤其是对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄。虽然

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者目前并未利用它，但它们仍然是强大的

独立天赋。

3.4.1.

##### 虚痕枭雄协同

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄尤其与近战工具包相协同。

进入你的[[spell:471306]]形态后，所有这些技能都会

得到强化——就像[[spell:473662]]转化为[[spell:1217610]]一样：

- [[spell:1245412]]变为[[spell:1245483]]
- [[spell:1246167]]变为[[spell:1259431]]
- [[spell:1239519]]变为[[spell:1245470]]

这些强化形态造成的伤害都显著更高，此外，

进入[[spell:471306]]后每个技能的首次施放将触发

一次[[spell:1246160]]以造成额外的宇宙伤害。最后， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄

同样也有办法增加你在整个过程中每个技能的施放次数

战斗中每个技能的施放次数。[[spell:1245412]]在进入虚空变形时重置，且

[[spell:1246167]]在你每次施放[[spell:1221167]]时重置，

显著增加每场战斗中可用的施放次数

变形窗口期间可用的施放次数！

### 收割的使用

3.5.

#### 收割的使用

[[spell:1226019]] 是 噬灭 的核心部分

输出循环的核心部分。它有8秒的基础冷却时间，立即对你的

目标造成宇宙伤害，并消耗最多4个灵魂碎片。各种效果和天赋

也会以不同方式对其进行修改：

- [[spell:471306]]——将[[spell:1226019]]转化为
  
  
  
  
  [[spell:1245453]]，持续期间显著提高其伤害。其冷却时间
  
  
  
  
  每次施放[[spell:1217610]]时还会缩短1秒（它取代了
  
  
  
  
  [[spell:473662]]).
- [[spell:1246558]]——使[[spell:1226019]]还能
  
  
  
  
  产生10点狂怒。
- [[spell:1239537]]——使[[spell:1226019]]获得第二层充能。
- [[spell:1272842]]——使[[spell:1226019]]的冷却时间受急速影响。
- [[spell:1238739]]与[[spell:1238488]]——灵魂塑形者使其
  
  
  
  
  每消耗一个灵魂，造成的伤害提高8%。渴望之刻重置[[spell:1226019]]的
  
  
  
  
  冷却时间，并使你在完整引导[[spell:473728]]之后的下一次收割
  
  
  
  
  可以消耗最多10个灵魂。这些效果大幅增加了收割的施放次数，
  
  
  
  
  并大幅提升其伤害。
- [[spell:1226033]]——将[[spell:1226019]]升级为抹除
  
  
  
  
  在完全引导完[[spell:473728]]后。这会使其以一种
  
  
  
  
  25码锥形区域内造成伤害，并获得普通收割
  
  
  
  
  施放所能获得的所有加成。这是一个非常强大的AOE技能。

3.5.1.

##### 虚痕枭雄与收割的协同

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 在虚痕枭雄中，[[spell:1226019]]非常强大，应尽可能

多地使用。第2赛季套装进一步强化了这一点，你应该

在单体目标中，每当收割（或[[spell:1245453]]）能收集到

四个或更多灵魂碎片时就施放它。[[spell:1226033]]在AOE中遵循类似的规则，

不过理想情况下它应消耗十个灵魂。

3.5.2.

##### 歼灭者协同

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者直接挂钩于[[spell:1226019]]，并将其作为

激活其众多英雄天赋的方式。关键效果——[[spell:1253304]]——是

通过[[spell:473662]]/[[spell:1217610]]施放和[[spell:473728]]触发的。

达到3层后，你的下一次收割将在目标处召唤虚空流星。

此外，进入[[spell:471306]]时， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者

会重置收割的冷却时间，同时立即产生3层

虚空坠落。这为该天赋树提供了强大的开场爆发，同时

为你关键的伤害窗口准备好所有重要的英雄天赋树效果。

对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 在歼灭者中，套装大幅强化了[[spell:1226019]]，尽管

它本身已是输出循环的核心部分。类似于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄,

在单体目标战斗中，只要你拥有（该状态），你就应该尽量施放Reap（或[[spell:1245453]]）

四个灵魂碎片同时激活供你收集，以最大化[[spell:1297433]]的数量

次数。由于第2赛季收割的使用频率大幅提高，

对手动触发[[spell:1253304]]的关注就少了很多，因为它通常会在

输出循环中自然被消耗。

### 灵魂献祭

3.6.

#### 灵魂献祭

[[spell:1241937]]在几乎所有情况下都配合

[[spell:1246555]]使用。虽然灵魂献祭本身不是一个强力的按键，但它

<em>是</em> 是一个比[[spell:473662]]更强大的产生技能。它也可以在

无目标的情况下施放，允许你在移动间隙产生额外的狂怒或灵魂，

大规模拉怪。

但请记住，由于[[spell:1217610]]强得多，我们 **不会**

希望在[[spell:471306]]内使用[[spell:1241937]]。它

在需要治疗时也可以使用，但这应被视为一种

被动收益，而不是你专门留着用的技能。

3.7.

#### 噬灭恶魔猎手恶魔猎手主要冷却技能

噬灭拥有独特的冷却机制，与[[spell:471306]]，限制

并非由计时器决定，而是由资源决定。使用它是玩法风格

不可或缺的一部分，因此在本节中我们将介绍其背后的机制，帮助你

更好地理解如何正确执行这些窗口期。由于

涉及的机制众多，我们将主要技能与它所启用的关键效果

分成了下面不同的章节：

1.

### 噬灭恶魔猎手恶魔猎手的重要冷却技能

### 虚空变形

4.1.

#### 虚空变形

噬灭的主要冷却技能是[[spell:471306]]。与许多其他专精不同，

它 <em>非</em> 没有固定的冷却时间或持续时间，而是只能

在收集50个灵魂后使用（玩[[spell:1247534]]时减少到35个）。

使用后，它会保持激活，直到你的狂怒被消耗到 **零**，以及

在变形期间，你获得以下好处：

- [[spell:1238855]] 的收益大幅提高。
- [[spell:473662]]变为[[spell:1217610]]，造成显著更高的伤害，且施法时间更短。
- [[spell:1226019]]变为[[spell:1245453]]，造成显著更高的伤害。
- [[spell:473728]]的伤害显著增加，且不再消耗狂怒，
  
  
  
  
  改为拥有受急速影响的冷却时间。引导时还会暂停狂怒的消耗。
- 收集30个灵魂后，你可以使用[[spell:1221167]]。
- 你的狂怒条完全回满。
- 拥有[[spell:1242492]]——你每消耗一个灵魂获得0.25%急速。
- 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者——你获得3层[[spell:1253304]]
  
  
  
  
  并刷新[[spell:1226019]]的冷却时间。
- 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 – [[spell:1245412]]与
  
  
  
  
  [[spell:1241937]]的冷却时间在进入时重置。
- 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 – [[spell:1245412]], [[spell:1246167]]
  
  
  
  
  和[[spell:1239519]]会被升级为[[spell:1245483]]、[[spell:1259431]]
  
  
  
  
  以及[[spell:1245470]]。
- 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 – [[spell:1221167]]重置
  
  
  
  
  [[spell:1246167]]的冷却时间。

在[[spell:471306]]期间，你的狂怒会以越来越快的

速度消耗，随着时间的推移，维持形态的难度会逐渐增加。

值得庆幸的是，少数几个技能可以在使用后短暂暂停这种消耗：

[[spell:473728]]和[[spell:1221167]]，以及[[spell:1245412]]

与[[spell:1272422]]天赋配合时的[[spell:1246167]]。

由于这些因素， <em>极</em> 围绕你的

[[spell:471306]]窗口进行规划非常重要，最好在地面上已经生成了一些灵魂

以便利用 <em>掌握</em> 进入时机。在变形期间，之后收集的任何灵魂

在40个消失后，因此避免囤积 [[spell:1221167]] 施放

太久 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者.

### 坍缩之星

4.2.

#### 坍缩之星

在你的[[spell:471306]]形态下，你所有的技能造成的

伤害都会显著提高，但最重要的是，你可以施放你最强的

法术——[[spell:1221167]]。这只能在变形状态下施放，需满足

以下任一条件：

- 你总共收集了 **30** 个灵魂碎片。
- 通过 **一次** [[spell:1250094]]巅峰天赋进入时。

施放时，此技能会对你的目标造成 <em>巨大的</em> 宇宙伤害，并波及附近的

敌人（8个目标之后伤害降低），并重置资源条上显示的灵魂计数。

资源条。通过[[spell:1227707]]天赋，每随后的

在每个[[spell:471306]]中施放的后续星辰将变得更强20%；这意味着

你能维持变形的时间越长，每次施放就变得越强

变得。

由于第二赛季早期阶段的大量增益，以及

12.1.5中对专精的改动，噬灭现在大量使用

[[spell:1221167]]，无论使用哪种英雄天赋。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者

的好处是每次[[spell:471306]]窗口内可以施放更多坍缩星辰

，从而提升其伤害。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄则使用

坍缩星辰来同时重置[[spell:1246167]]的冷却时间并提供

[[spell:1245412]]的冷却缩减。这使其成为近战循环的核心部分

，你希望在每次变形期间尽可能多地循环这个连招

每次变形。

### 翻滚折磨

4.3.

#### 翻滚折磨

[[spell:1244237]]作为变形期间收集的多余灵魂的冗余工具

。这会在变形结束时，根据存在的每个灵魂奖励你5点狂怒和0.5%的伤害提高，持续12

秒 <em>变形结束时在场的每个灵魂</em>这意味着

在[[spell:1221167]]未施放的情况下收集灵魂的惩罚会降低

，在[[spell:471306]]中也能获得不错的资源

返还。这在你离开后达到第一个[[spell:473728]]时尤其有帮助

，让你能更快地重新开始循环。

在第二赛季期间对[[spell:1221167]]的改进，以及

生活质量的提升，现在意味着[[spell:1244237]]变得更加

健康了。它不再需要扭曲输出循环，现在是一个很好的增益

，帮助你更无缝地循环冷却时间。

### 恶魔变形走私

4.4.

#### 恶魔变形走私

走私是指将来自[[spell:471306]]外部的触发效果带入其中

在其中，利用精通带来的伤害提升，以及

虚空恶魔变形为技能提供的伤害加成。这主要通过

几个技能来完成：

- [[spell:1226033]]（在AOE中）。
- [[spell:1239519]].
- [[spell:1246167]].

在AOE中，两条英雄天赋树都希望总是走私一个[[spell:1226033]]

，因为[[spell:471306]]为其提供30%的升级。这是一个硬性

规则，也是你每次都应该走私的唯一技能 **每** 对于

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄来说，另外两个技能也很重要，但没有重要到

需要你刻意去实现的程度。走私一层

[[spell:1239519]]会将其升级为[[spell:1245470]]，这相当容易

，只需在激活前施放[[spell:1245412]]即可

虚空恶魔变形。

对于[[spell:1246167]]来说，情况稍微复杂一些，使用一种

称为Huggling（猎人走私）的技巧。要进行Huggling，需要大约

15%急速的基础水平（尽管噬灭追求更多），以及与目标保持

至少15码的距离。设置这一点最简单的方法是使用

[[spell:198793]]，然后在施放狩猎之前

，在你冲向目标时激活[[spell:471306]]。这

会在冲锋中途触发形态切换，导致伤害

事件切换为[[spell:1259431]]，既提高了其伤害

，又为你提供一层[[spell:1245470]]。稍加练习就能轻松做到

，不过动画锁定可能让你难以注意到何时

成功了。

但请注意，虽然走私对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄在追求

最大吞吐量优化时很重要，但循环穿越[[spell:471306]]

仍然更强大。不要为了走私增益而延迟激活任何有意义的时间

，除了在AOE中的[[spell:1226033]]。

4.5.

#### 管理噬灭恶魔猎手的移动

与其近战等效专精浩劫不同，噬灭是一名施法者，因此它在

应对战斗时面临独特的挑战。由于其混合了25码射程

法术和近战技能，了解你能使用什么 <em>非常</em>

非常重要。值得庆幸的是，噬灭拥有一些

出色的移动工具：

- [[spell:473662]]和[[spell:1226019]] – [[spell:473662]] / [[spell:1217610]]
  
  
  
  
  是你的主要填充法术，并且可以随时在移动中施放。这
  
  
  
  
  意味着你可以 <em>始终施放某些技能</em> 在任意遭遇战中的任何时刻。
  
  
  
  
  [[spell:1226019]]同样是瞬发的，为你提供了一些选择！
- [[spell:1234796]] – 这是噬灭独有的技能，冷却时间为20秒
  
  
  
  
  可对目标使用冲刺，最多有3层充能，具体取决于天赋。它近乎瞬发，
  
  
  
  
  将你传送到光标位置，范围最远30码，包括可以向上传送以获得
  
  
  
  
  高度优势。但重要的是，这是 <em>非</em> 一次传送 – 这意味着
  
  
  
  
  你在途中穿过的效果仍然会命中你。
- [[spell:131347]]和[[spell:198793]] – 如果你曾经玩过
  
  
  
  
  恶魔猎手，这些应该很熟悉！[[spell:198793]]
  
  
  
  
  会迅速将你向后发射20码，冷却时间为25秒。在战斗中作为近战连招的一部分使用时，
  
  
  
  
  这是免费使用的，所以如果需要的话不要害怕使用
  
  
  
  
  它。[[spell:131347]]可以在二段跳之后的任何时候使用，
  
  
  
  
  提供少量移动速度加成。与[[spell:1266493]]搭配使用时
  
  
  
  
  在至暗之夜中，这变成了一种极其高效的移动工具，始终可用
  
  
  
  
  手段。

当这些工具组合在一起时，它们创造了一个极其强大的移动体系。这

对于噬灭来说尤其重要，因为你在两种形态下的主要伤害技能都

[[spell:473728]]和[[spell:1221167]]中的主要伤害技能都有很长的施法时间，同时还

会在你试图移动时被打断。因此，使用其他工具如

[[spell:1234796]]移动到安全位置至关重要，这样你才有空间释放最强

法术！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月18日：** 已更新至8月18日的职业调整。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日：** 已根据在线修复进行更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已更新至至暗之夜前夕补丁的在线修复。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年12月13日：** 已更新至最新的测试服改动。
- **2025年12月6日：** 已更新至最新的测试服改动。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年11月15日：** 页面已更新至测试服发布改动。默认构筑切换为歼灭者（施法者）。
- **2025年11月9日：** 为至暗之夜测试服创建页面

显示更多

显示更少

:::

## 装备选择

在本页面上，你将找到魔兽世界12.1.5版本中你的噬灭 恶魔猎手的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们一应俱全！

1.

### 噬灭 恶魔猎手毕业装备指南

欢迎来到我们的至暗之夜中噬灭 恶魔猎手的装备和毕业页面！查看本页面，了解关于为噬灭 恶魔猎手配装的一切信息，包括来自所有来源的毕业装备、团本和大秘境、关于最佳饰品、套装等更多信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，允许你沿着与获取内容等级相关的轨道提升装备物品等级。更难的内容掉落更高轨道的装备，从而达到更高的物品等级。欲了解更多信息，请阅读我们关于 [配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 在至暗之夜中的运作方式。

12.1.5更新带来了至尊毒石，允许334的武器、饰品和项链一直升级到340物品等级。此外，它还带来了新首领基希克斯，掉落强大的新战利品，包括三件对噬灭非常强力的装备！

### 总体

以下列表包含来自 <em>所有可能的终局内容来源</em>的装备，包括团本、大秘境、制造、地下宝库和大宝库。它旨在提供绝对最佳的配置，但请记住，每个 **单件** 在你特定的配装中，某件装备在任何给定时间可能不是最强的。套装件如果比标准版本更强，则会列出理想的转化器装备位置。

这套配装旨在尽可能堆叠急速和精通，同时避免急速过高导致[[item:241288]]转而提供急速。之后，它会尽量最大化暴击。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

目前每个部位可供转化的最佳物品为：

- **头盔 –** [[item:271875@JAAEAAAG2chN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **肩膀 –** [[item:268246@JAACAAgNyA]] 来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- **胸甲 –** [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **手套 –** [[item:271538@JAACAAgNyA]] 来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **腿部 –** [[item:268225@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 常见问题：有哪些需要留意的高优先级大宝库或虚空核心物品吗？
毒瘴深渊中提供的任何咒术物品都极具价值，即使它们不是来自史诗难度的344物品等级。[[item:270164]]也极其强大，值得为噬灭获取。以下物品即使来自英雄难度的宝库也强烈值得考虑，如果你不打算快速推进史诗难度，甚至值得使用虚空核心来获取：

1. [[item:271092@JAACAAAG2A]] - [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
2. [[item:268265@JAAEAAAG2wYN]] - [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:271875@JAAEAAAG2chN]] - [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
4. [[item:270164@JAACAAAOyA]] - [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
5. [[item:281215@JAACAAAOyA]] - [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

这些足够强大，如果你 <em>没有</em> 击杀任何史诗首领以获得更高的宝库奖励，如果这些物品都没有出现，你总是可以选择从大宝库中获取一个虚空核心。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271537@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 秘境+

以下套装包含来自大秘境的最佳物品，仅使用第2赛季副本池中的装备，以及你理想的套装转化器位置和用于装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 来自大秘境地下城的 **非** 并非你在大秘境内容中应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限地下城** 的各部位转化件为：

- **头盔 –** [[item:159318@JAACAAgNyA]] 来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **肩膀 –** [[item:251223@JAACAAgNyA]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **胸甲 –** [[item:251159@JAACAAgNyA]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **手套 –** [[item:159312@JAACAAgNyA]] 来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **腿部 –** [[item:251130@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 提示我应该刷哪些地下城？
噬灭的大部分重要物品来自第2赛季的团本，但在你等待获取它们期间，有一些值得追求的替代品。以下是值得获取的可靠选择：

1. [[item:250215@JAACAAAOyA]] - [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
2. [[item:250224@JAACAAAOyA]] - [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
3. [[item:251159@JAACAAgNyA]] - [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
4. [[item:251223@JAACAAgNyA]] - [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271537@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271536@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271540@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240917]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:273778@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

以下套装是你的 **团本** 毕业列表，使用来自 **只能** 团本掉落的装备，以及理想的套装件（或用于转化器的物品）和用于激活装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 团本内部的 **非** 并非你在团本内部应使用的严格列表。

:::details 小贴士：我最应该追求哪些物品？
噬灭本赛季可用的许多最强物品来自毒瘴深渊的最后两个首领，以及

[Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

，在12.1.5补丁中加入。它们提供强大的咒术效果，几乎所有都值得获取：

1. [[item:271092@JAACAAAG2A]] - [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
2. [[item:268211@JAACAAAG2A]] - [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
3. [[item:268265@JAAEAAAG2wYN]] - [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
4. [[item:271875@JAAEAAAG2chN]] - [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:281215@JAACAAAOyA]] - [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限团本** 的各部位转化件为：

- **头盔 –** [[item:271875@JAAEAAAG2chN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **肩膀 –** [[item:268246@JAACAAgNyA]] 来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- **胸甲 –** [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **手套 –** [[item:271538@JAACAAgNyA]] 来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **腿部 –** [[item:268225@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271537@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240967]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240917]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 噬灭 恶魔猎手饰品推荐

在第2赛季较弱的主动饰品和强大的被动饰品之间，噬灭在12.1.5补丁中理想情况下使用两个被动饰品。虽然主动饰品在大秘境中当你需要更多爆发控制时是可行的，但用途较为小众。

目标是获取以下两个被动饰品中的两个。如果你需要，也提供了主动饰品：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **至暗之夜 第2赛季值得追求的饰品**
**第一个被动 –**

[[item:281215@JAACAAAOyA]]

**第二个被动 –**

[[item:270164@JAACAAAOyA]]

，或者

[[item:270167@JAACAAAOyA]]

**主动（大秘境）–**

[[item:250215@JAACAAAOyA]]

，或者

[[item:273796@JAACAAAOyA]]

:::

你可以点击下方打开其他饰品的排名图表，以防你捡到了别的东西并想看看它与其他饰品相比如何。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看噬灭第2赛季饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   在12.1.5补丁中加入，这是一个极其强大的被动饰品，提供大量暴击，对频繁刷新的小怪给予更多奖励。是本赛季最强组合的一部分。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   这是我们毒瘴深渊中可用的最佳饰品，也是两个最佳选择之一。在各种属性增益上提供非常高的覆盖率，由于噬灭的冷却时间频率，这尤其有用。&#10;		   </p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   这是我们本赛季最佳的主动饰品，增强我们在[[spell:471306]]开始时的爆发。由于大部分伤害都集中在这些窗口期，应该留着与你的冷却时间配合使用。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270167@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   本赛季一个强大的被动饰品。被动属性预算分配给急速而不是智力，在与理想选择相比时略有不足。&#10;		   </p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270161@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   一个强大的被动伤害效果，由于噬灭施放的法术数量，触发频繁。不如我们最好的选择强大，但仍然是一个很棒的获取。</p>&#10;</li>&#10;<li>[[item:250224@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:273796@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   我们第二好的主动饰品。较长的冷却时间和轻微的缺点使它略逊于[[item:250215]]，但它仍然相当强大。尝试将其与[[spell:471306]]搭配。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:193757@JAAKAAQkCYHKvbRLfgjM]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   一个强大的副本触发饰品。尝试在暴击增益中训练四次（独自站立时使用），在急速增益中训练两次（站在盟友群体中使用）。 </p>&#10;</li>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   前往 祖尔'Aman 中的 Jan'alai 祭坛，将其设置为 <strong>精通</strong>，或阿基尔宗祭坛将其重置为 <strong>暴击</strong>，取决于你的装备配置。</p>&#10;</li>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:273649@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]]<strong>*</strong> - <span><em>点击查看详情</em></span>&#10;<span>&#10;		   这会造成一个 <em>极</em> 大量的爆发伤害到你的主要目标上，同时附带一些额外的群体伤害。虽然由于它是引导技能且冷却时间长，在与其他选项竞争时有些吃力，但它在处理关键敌人方面的独特潜力意味着在第二赛季的某些边缘情况下值得一看。</span>&#10;</li>&#10;<li>[[item:270170@JAACAAAOyA]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;<li>[[item:251786@JAACAAAMyA]]</li>&#10;<li>[[item:273794@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;<li>[[item:251784@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]]<strong>*</strong> - <span><em>制造饰品详情</em></span>&#10;<span>&#10;		   虽然这些饰品选项并不 <em>差</em>，但第二赛季的装饰比以前更强了。这意味着使用它们的机会成本太高，它们比原本就已经落后的地位更加落后了。</span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   虽然这个饰品调整得很好，但停留在触发区域内极其受限，尤其是对于噬灭这种频繁移动的职业。再加上团本遭遇中的大型场地和副本中混乱的移动，实际使用时效果可能因情况而异。</p>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;<li>[[item:251787@JAACAAAMyA]]</li>&#10;<li>[[item:274495@JAACAAAMyA]]</li>&#10;<li>[[item:280123@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外拾取）

第二赛季沿用了第一赛季推出的额外奖励骰系统，提供了一种获取重要装备的途径：

**[混沌虚空核心](<https://www.wowhead.com/currency=3418>)s** 可在完成终局地下城或击败团队副本首领后使用，从相应的掉落表中随机获得一件物品。一旦通过虚无核心骰获得过某件物品，它就不会再次出现。在第二赛季， **单** 虚无核心用于对地下城掉落进行掷骰 <em>或</em> 单个团队副本首领，获得相当于你每周宏伟宝库奖励装等的掉落。

每周可从 **奥琳·微光** 获得一个，该物品位于催化剂旁边，随12.1.5补丁发布后开放。此外，如果你解锁了总共三个奖励，也可以从宏伟宝库中选择一个虚无核心而非一件物品。

3.1.

#### 噬灭 恶魔猎手推荐虚空核心使用指南

你应该优先获取哪件物品，很大程度上取决于你已经拥有的装备、可通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获得的物品，以及你目前已击杀的首领。虽然随着12.1.5补丁加入每周奖励，它们现在更容易获得，但从宏伟宝库中拿一个应被视为 <em>安慰奖</em> ，在没有更好选择的情况下。

关于 <em>以及</em> 当你确实拿到一个虚无核心后，应该在哪里使用它，答案很简单：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **第二赛季虚无核心用途**
1. **乌拉特克** （英雄/史诗） <em>噬灭拾取专精</em>
   
   
   
   
   - [[item:271092@JAACAAAG2A]]
   - [[item:268265@JAAEAAAG2wYN]]
   - [[item:271875@JAAEAAAG2chN]]
2. **迷失的探险者** （史诗） <em>噬灭拾取专精</em>
   
   
   
   
   - [[item:270164@JAACAAAOyA]]
3. **基希克斯** （史诗） <em>噬灭拾取专精</em>
   
   
   
   
   - [[item:281215@JAACAAAOyA]]
   - [[item:281029@JAACAAgNyA]]
   - [[item:281236@JAAEAAgNyEuN]]

:::

:::details 常见问题：我何时应该考虑从宏伟宝库中选择虚无核心？
随着赛季推进，虚无核心更容易获得，推荐也更加具体。虽然你现在拥有更多掷骰机会，但仍需记住一些可能让你觉得拿一个不太划算的情况：

- 如果你尚未解锁你的四件套效果，获取它应优先考虑。
- 如果 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 或 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
  中的关键追求装备被提供，就选它。
- 留意早期史诗首领击杀提供的关键物品（例如来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)的饰品），因为它们以6/6史诗难度提供，节省纹章并省去对该物品本身的额外拾取。
- 如果大秘境中提供了理想的转化器装备，而这原本需要在整个掉落表上掷骰（例如[[item:251159@JAACAAgNyA]]），请记住原本需要多少次掷骰才能保证获得这些。

对于噬灭来说，最终首领提供的物品如此强大，以至于除了获取你的套装加成外，即使在英雄难度的最终首领上额外拾取以获取其独特战利品也是值得的。必须指出的是，最终首领确实有一个较弱的饰品，[[item:270168]]。与浩劫不同，我们无法更改拾取专精来避免这个 – [[item:271092]]是掉落表上最强的装备，但它对复仇不可用。因此，在这个首领上掷骰要谨慎，虽然它可以提供本赛季最好的物品，但也混入了一件较弱的装备。

:::

3.2.

#### 晋升毒液石

使用你的[[item:280562]]遵循与使用你的纹章类似的优先级列表：

1. 主手/副手武器。两个槽位相等，但如果你额外拾取了[[item:271092@JAACAAgNyA]]，请优先选择它！
2. 两个饰品。根据排名列表优先选择你最强的饰品。
3. 你的项链。

你还应该优先考虑神话级装备而非英雄级装备，除非你不打算获得该物品的神话级版本。例如，如果你不打算击败史诗难度的，那么升级一个6/6神话级的[[item:271092]]是可以的 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 以尽快获得344装等的版本。

1.

### 噬灭 恶魔猎手最佳制造物品

制造装备提供了在赛季中获取高价值物品最简单的方式之一，让你能够定向获取关键装备来完善你的配装。随着第二赛季发布，每次制造需要两个 [[item:274476]]。

除非物品已指定副属性，否则你应该在制造时使用[[item:245789]]来获得暴击和精通，尽管模拟结果可能因你的角色而异。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **噬灭制造订单**
**[[item:237840@JAAKAAwt1ENMMYzy1clI]]**

➜

**[[item:244576@JAAKAAwt1ENMMYDYwclI]]**

➜

[[item:244569@JAAKAAwt1ENMMYDYwclI]]

➜

**可选制造**

:::

**制造说明：**

- 首先制造一把 **武器**，因为它在早期影响最大。战刃最佳，因为它允许你切换专精。为你的第一个美化附上[[item:273060]]。
- 制造 **一件散件** - 我们推荐在手腕槽位使用[[item:244576@JAAMAAwt1ENMMYDYwclIcYD]]。附加[[item:240167]]作为你的第二个装饰。
- 一旦你获得第二把344武器，制造 **另一件散件**  - 我们推荐在靴子槽位使用[[item:244569@JAAMAAwt1ENMMYDYwclIcYD]]。附加[[item:240167]]。从你的武器上移除[[item:273060]]。
- 之后，根据你当前装备的空缺来制造物品。

:::details 常见问题：我可以在赛季开始时优化我的制造吗？
由于第2赛季中许多重要物品都是锁定槽位的独特咒术效果，将制造投入这些槽位比第1赛季要不灵活得多。虽然你仍然想要最大化制造的物品等级，但你不希望被某些东西卡住，导致你无法在获得这些物品时切换过去。

话虽如此，几乎不存在武器 **不是** 最佳首选制造的情况，因为[[item:237840@JAAKAAwt1ENMMYzy1clI]]一开始就提供了大量战力。由于噬灭本赛季可以获取两把更高物品等级的武器，它不在我们的毕业配装中，但作为你配装旅程中的一件装备，或者如果你不期望在史诗难度击败最后两个首领时，它可能非常强大。

:::

一旦你完成了两个主要装饰的制造，你的配置应该就相当扎实了。进一步优化装备时，你的优先级应该是制造高装等的装备来填补你配装中的漏洞。高优先级候选是珠宝首饰，虽然有强力的独特选择，但它们 <em>极</em>
在这个赛季竞争激烈。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

1.

### 纹章使用

赛季初期，或者如果你刚开始玩一个副角色，你获得升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 以提升装等）的机会有限。纹章每周上限为100个，升级无论哪个栏位都花费20个纹章。因此，你应该优先将这些纹章用在你短期内不打算更换的物品上，或者能提供更大属性收益的特定栏位：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **噬灭 恶魔猎手纹章升级优先级**
**武器（主手和副手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些不是唯一值得升级的物品。它们只是在赛季初期你的升级货币有限时提供最高的DPS提升。注意可能存在例外，例如附带额外触发效果的特殊咒术物品，如[[item:268265@JAAEAAAG2wYN]]。

5.1.

#### 为装备添加插槽

虽然所有戒指和项链默认带有一个插槽，但头盔、腰带和护腕槽位在掉落时可以作为奖励获得三个额外插槽。这些也可以使用[[item:275707]]消耗品手动添加，该消耗品可以用6个[[item:258556]]购买，这是来自大秘境宝库的保底货币。

使用这些时，最好将它们放在你预计永远不会更换的装备上。这意味着史诗物品，或这些槽位中的任何制造装备，因为它们无法通过其他方式添加插槽。由于它们是非常有限的货币，如果你有这些，最好在花费之前做好长期规划。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月18日：** 已更新至8月18日的职业调整。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月7日：** 添加了关于早期制作以优化破晓冠使用的常见问题解答说明。
- **2026 年 3 月 17 日：** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日：** 页面已根据在线修复进行更新。
- **2026年2月26日：** 页面已更新至至暗之夜上线。
- **2026年2月10日：** 页面已创建。

显示更多

显示更少

:::

## 属性优先级

在本页面上，你将找到你的噬灭 恶魔猎手的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已更新至魔兽世界12.1.5补丁。

1.

### 噬灭 恶魔猎手 属性优先级

欢迎来到我们的噬灭 恶魔猎手属性优先级页面，

在至暗之夜第二赛季中。在这里我们将快速介绍你应该

在装备上追求的属性，以及根据你的天赋选择的任何特殊考虑。

噬灭 恶魔猎手 的属性优先级略有不同，取决于

你的英雄天赋选择有略微不同的属性优先级，但它们的差异并不大到

你需要完全不同的配装来使用它们。

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者属性优先级

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 对于歼灭者，基本的推荐属性优先级

如下：

智力

精通

急速

暴击

全能

在至暗之夜中，主属性重新变得极其有价值，因此根据物品等级

选择物品是 <em>通常</em> 提升你智力的稳妥选择。

由于有许多免费的急速来源，精通是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者

的首选属性。急速有助于平滑你的循环，延长你的[[spell:471306]]窗口并减少

它们之间的间隔时间，但由于[[item:241288]]，我们不希望它成为我们最高的属性。

在[[spell:1238855]]被削弱之后，暴击变得非常强大，

由于[[spell:1242495]]，一旦你获得，它会出现在你的几件装备上

大量急速后，它会出现在你的几件装备上。精通降至最后一名，尽管它

确实提供了一些防御性收益。

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 属性优先级

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 对于 虚痕枭雄，一个基本的推荐属性优先级是

如下：

智力

精通

急速

暴击

全能

在至暗之夜中，主属性重新变得极其有价值，因此根据物品等级

选择物品是 <em>通常</em> 提升你智力的稳妥选择。

在转向尽可能延长 [[spell:471306]] 之后，

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 的属性优先级与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 非常相似，寻求堆叠

精通。急速对于平滑输出循环很有价值，但我们本赛季的咒术提供了

会提供大量免费的它。最后，在削弱之后暴击的收益提升了

[[spell:1238855]]，而你的装备上会带有一些。

全能则远远落后，几乎没有

理由去主动追求它。它确实带来一些防御性收益，

这可能有用。

:::details 常见问题解答 我需要多少急速？
两者皆有 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 需要急速来延长 [[spell:471306]]，但由于 [[item:271092]]、[[item:271875]] 和 [[item:268265]] 提供的免费触发，它的整体价值被削弱了。理想情况下，你应尽可能多地拥有急速，同时尽量减少 [[item:241288]] 使用时提供急速的几率。

:::

:::details 常见问题解答 你说暴击更好，但我看到有的玩家精通更高？
虽然暴击是 <em>是</em> 一个不错的属性，但通过我们拥有的少数暴击来源，即 [[item:268265]] 和 [[item:281215]]，它的价值相对被削弱了。在获得这两件物品之前，暴击对你的价值可能更高。

:::

1.

### 深入属性解析

作为一名 噬灭 恶魔猎手， **智力** 智力是你的主属性，

所以你需要在所有装备上都有它。各个

属性提供以下收益：

- **智力 -** 为你提供法术强度，提高你
  
  
  
  
  的 噬灭 技能和攻击的伤害。
- **暴击 -** 提高你的攻击造成暴击的几率，
  
  
  
  
  造成双倍伤害。此外：
  
  
  
  
  - [[spell:1242495]] 将暴击伤害提高到 240%，
    
    
    
    
    ```
    up from the original 200% multiplier.
    ```
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄：[[spell:452413]] 使 [[spell:1239519]] 获得 125%
    
    
    
    
    额外的暴击伤害，并且还将其半径增加 2 码。
  - [[spell:1250088]] 使 [[spell:1221167]] 获得等于你 50% 暴击等级的
    
    
    
    
    伤害。这是为了抵消 [[spell:1242486]] 带来的 100% 暴击几率。
- **精通 -** 通过提升你造成的所有宇宙伤害
  
  
  
  
  [[spell:1238855]]。此外：
  
  
  
  
  - 加成在 [[spell:471306]] 期间提高 33%。
  - 同时通过[[spell:320654]]提高你的基础移动速度。
- **急速 -** 提高法术的施法速度，并提高你在近战范围内的
  
  
  
  
  近战范围内的速度。此外：
  
  
  
  
  - 将你的全局冷却时间降低至最低 0.75 秒。
  - 在 [[spell:471306]] 期间降低 [[spell:473728]] 的冷却时间。
    
    
    
    
    ```
    form.
    ```
  - 通过 [[spell:1272842]] 降低 [[spell:1226019]] 的冷却时间。
- **全能 -** 按固定数值提高你造成的所有伤害和治疗（包括饰品
  
  
  
  
  和触发效果）。此外，将你受到的所有伤害降低
  
  
  
  
  该数值的一半。

2.1.

#### 属性递减收益

每种属性都有一个上限，在该上限之后每点属性获得的提升会减少，

这就是已知的收益递减点。一旦你达到

这些数值，属性将逐渐变得不那么有价值，并可能落后于

其他选择。当前的阈值如下：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 页面已更新至至暗之夜第一赛季。
- **2026年2月26日：** 页面已更新至至暗之夜上线。
- **2026年2月10日：** 页面已创建。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了根据你的属性，为你的 噬灭 恶魔猎手 能获得的最佳宝石、附魔、合剂、药水和食物， [属性优先级](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

所有内容的推荐选择为：

- 在你的第一个插槽使用 [[item:240967]]。
- 每种颜色的宝石各放置一颗（[[item:240917]]、[[item:240908]]、[[item:240892]]、[[item:240898]]）。
- 用 [[item:240908]] 填充任何剩余的插槽。

不过，通常建议你为宝石进行角色模拟，因为单件装备对哪颗宝石可能是你最佳选择有很大影响。上述的一刀切方法在所有类型的内容中都能很好地为你服务。

1.

### 最佳附魔和武器强化

你的武器强化消耗品选择是 [[item:243733]]，以提供额外的暴击和急速。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td><strong>主手</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>副手</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>头部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>胸部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>护肩</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>腿部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>靴子</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>戒指</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

头盔、肩膀和靴子的附魔是个人喜好，因为它们对性能没有直接影响，但我们推荐闪避和耐力以获得额外的生存能力。

1.

### 最佳消耗品

消耗品能在有限时间内大幅提升你的角色实力。任何时候当你挑战困难内容时，建议你使用药剂、食物、药水和武器油来增益自己。

3.1.

#### 合剂

在 12.1.5 中，合剂只有一个真正的选择，即 [[item:241322]]，虽然如果你的急速极低，可以使用 [[item:241325]]。

你也可以从炼金术士提供的[[item:241319]]中获得你选择的合剂。

3.2.

#### 药水

[[item:241288]] 是你的最佳选择，并且应该与主要冷却技能和 [[spell:2825]] / [[spell:32182]] 搭配使用。你也可以从炼金术士提供的 [[item:241285]] 获得临时的 [[item:241288]]。

[[item:271883]]是目前最好的治疗药水。使用后有5分钟冷却时间，但如果首领战持续足够长，可以消耗多个。此外，术士的[[item:5512]]与其他治疗消耗品不共享冷却时间。如果你持有一个，记得也要使用它！

3.3.

#### 食物增益

在第二赛季，食物提供的次要属性开始超过智力的价值。因此，当 [[item:275266]] 可用时，尽量食用它，否则食用 [[item:242274]]。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用 [[item:259085]] 来提高你的主属性。这些可以通过每周的家园任务获得，但请记住：强化符文很贵且死亡后会消失，所以明智地使用它们！

3.5.

#### 其他消耗品

除了标准的增益消耗品外，还有少数其他物品值得保留——尤其是在大秘境中：

- [[item:188152]]——让你自动与附近的术士[[spell:111771]]互动。
- [[item:244639]]——使用时为你的小队提供较弱的15%急速[[spell:2825]]效果。这些仍会受到[[spell:57724]]的影响，所以只应在你没有小队成员自然提供该效果时使用。
- [[item:269586]] —— 可以对你的目标用作战斗复活，并且 <em>不会</em> 需要工程学。
- [[item:241303]]——至暗之夜的隐身药水，可用于在大秘境中跳过某些小怪战斗。请注意，这 <em>确实</em>
  与你的进攻性药水 [[item:241308]] 共享冷却时间。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月24日：** 更改了戒指附魔推荐。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026 年 3 月 17 日：** 页面已更新至至暗之夜第一赛季。
- **2026年3月16日：** 页面已根据在线修复进行更新。
- **2026年2月26日：** 页面已更新至至暗之夜上线。
- **2026年2月10日：** 页面已创建。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5 补丁中使用你的 噬灭 恶魔猎手 挑战大秘境地下城的提示和建议。

1.

### 噬灭 恶魔猎手 在 至暗之夜 第二赛季的大秘境中

在本页，我们将介绍如何在大秘境地下城中最大限度地发挥你的 恶魔猎手 的作用，包括构建天赋的最佳方式、你需要了解的任何循环变化，以及在钥石中脱颖而出的提示和技巧。

如果你不熟悉大秘境及其相关的一般机制，你可以在下面我们专门的大秘境页面上了解更多信息。你也可以在我们的层级列表页面上了解更多关于大秘境环境的内容。

噬灭 恶魔猎手 的伤害类型提供强大的单体输出，同时能够迅速处理优先目标。在 12.1.5 中，它回到了带有 [[spell:1242492]] 的预热玩法，旨在延长 [[spell:471306]] 并施放巨大的 [[spell:1221167]]。噬灭 也能极好地过渡到更多目标的范围伤害，随着新目标的加入获得额外的灵魂碎片生成，增加 [[spell:207697]] 的层数。

噬灭 总是拥有预热伤害，但额外的价值将取决于你选择的构筑。你可以转向更多的优先伤害，或进一步转向范围伤害和顺劈。在第二赛季的两个选择之间，我们目前推荐 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者，虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 如果你更喜欢它的玩法，虚痕枭雄 也是可行的。

1.

## 最佳大秘境天赋配置

在 至暗之夜 12.1.5 补丁中，对专精的改动推动了 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 领先于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄，提供强大的优先伤害和范围伤害，且随着目标增多而增加。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 可以输出高伤害，但很容易被打断，导致在此过程中损失大量伤害。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者  

推荐选择
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄  

备选构筑

2.1.

### 最佳 噬灭 大秘境构筑 - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 在 12.1.5 中获得了一些价值，这得益于 [[spell:1244220]] 的增强和 [[spell:1221167]] 的生活质量改进。加上 [[spell:1221167]] 在整个 12.1 期间频繁获得的增益，它现在是大秘境的最佳选择。它拥有一个极其强大的冷却技能，你可以频繁使用，并且随着拉怪规模增大和拉怪变大，它的伤害也会提高。[[spell:1253304]] 和 [[spell:1279247]] 在拉怪过程中也能提供稳定的伤害，但它非常侧重于管理和延长你的冷却技能。

大秘境天赋构筑与其单体构筑非常相似，在损失极少单体和优先伤害的同时，获得了启用范围伤害的工具。

2.1.1.

#### 天赋更换选项

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 有几个天赋替换选项需要记住：

- 如果你发现自己处于战斗持续时间不长的低钥石等级，可以将 [[spell:1247534]] 替换为 [[spell:1242492]]。同样，在类似情况下，可以选择 [[spell:1253676]] 而不是 [[spell:1279247]]。
- [[spell:1266496]] 和 [[spell:1266316]] 都是取决于地下城的按情况使用的工具。根据地下城中是否存在诅咒或疾病选择合适的选项。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

大秘境 / 范围伤害 - 歼灭者

CgcBAAAAAAAAAAAAAAAAAAAAAAA2mxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwMzMzMzMzMMziZMWkFmZmZ2abmZGADDAAPwYGGzA

2.2.

### 备选 噬灭 大秘境构筑 - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 在进入 12.1.5 时经历了重大变化，从频繁进入 [[spell:471306]] 转向更类似于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者 的玩法，寻求尽可能延长 [[spell:471306]] 以施放多个 [[spell:1221167]]。这些现在会重置 [[spell:1246167]] 的冷却时间，其本身就能提供稳定的范围伤害。不幸的是，这种玩法意味着由于其漫长的施法时间和强制移动，你会频繁失去对角色的控制，而且由于想要延长 [[spell:471306]]，你的循环非常容易被打断并损失大量 DPS。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 的理论最高输出很高，但在当前的地下城池中不太可能达到那个潜力，因此它不 <em>非</em> 被推荐。

2.2.1.

#### 天赋更换选项

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄 有几个天赋替换选项需要记住：

- [[spell:1266496]] 和 [[spell:1266316]] 都是取决于地下城的按情况使用的工具。根据地下城中是否存在诅咒或疾病选择合适的选项。
- 如果你发现自己处于战斗持续时间不长的低钥石等级，可以将 [[spell:1247534]] 替换为 [[spell:1242492]]。
- 可以将 [[spell:452412]] 替换为 [[spell:452413]] 以提高单体伤害，但会大幅损失你的范围伤害潜力。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

大秘境 / 范围伤害 - 虚痕枭雄

CgcBAAAAAAAAAAAAAAAAAAAAAAAWmxMzMzYmxwMAAAAAAALGz2gZAAAAAAAAYGzwYmZmZmZmhZWmZM20yCAAMAGzMzyMz0sNzmZGjZMA

1.

## 地下城天赋切换速查表

为了快速参考你的 噬灭 实用天赋的额外用途，请使用下面的工具选择一个地下城。下方会突出显示相关选项及其用于克制的目标。

<table>&#10;<tr>&#10;<th colspan="2">地下城</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;</table>

基于上述选择，以下职业天赋有独特的用例：

![Consume Magic not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/consume.jpg>)**适用条件：纳洛拉克的洞穴（未启用）；密谋小径（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）。**
![Consume Magic Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/consume.jpg>)**适用条件：纳洛拉克的洞穴（启用）；密谋小径（启用）；诸王之眠（启用）；红玉新生法池（启用）。**
‌
![Burn It Out not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/burnitout.jpg>)**适用条件：毒牙祭坛（未启用）；诸王之眠（未启用）。**
![Burn It Out Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/burnitout.jpg>)**适用条件：毒牙祭坛（启用）；诸王之眠（启用）。**
‌
![Soul Cleanse Not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/cleanse.jpg>)**适用条件：纳洛拉克的洞穴（未启用）；密谋小径（未启用）。**
![Soul Cleanse Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/cleanse.jpg>)**适用条件：纳洛拉克的洞穴（启用）；密谋小径（启用）。**
‌
![Vengeful Retreat Not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/retreat.jpg>)**适用条件：毒牙祭坛（未启用）；Blinding Vale（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）；虚空之痕竞技场（未启用）。**
![Vengeful Retreat Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/retreat.jpg>)**适用条件：毒牙祭坛（启用）；Blinding Vale（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；虚空之痕竞技场（启用）。**
‌

- **适用条件：毒牙祭坛（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 清除 [[spell:1296069]]，在 **拉维** 首领战斗中。
  - 从 [[spell:1310974]] 中清除 **扭缠盘蛇**.
  - 从 [[spell:1294569]] 中清除 **双牙折磨者**.
- **适用条件：毒牙祭坛（启用）。** [[spell:1266316]]用途：
  
  
  
  
  - 驱散 [[spell:1296069]] 来自 **拉维**.
- **适用条件：Blinding Vale（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 从 [[spell:1238084]] 中清除 **鞭笞者** 如果你在近战中被击中。
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 从 [[spell:1309919]] 中清除 **严寒殴斗者**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散 [[spell:1297696]] 来自 **地语看护者**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:1266496]]用途：
  
  
  
  
  - 驱散 [[spell:1238760]]，由召唤的雕像施加 **猎人之魂**.
- **适用条件：诸王之眠（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 从 [[spell:1294815]] 中清除 **复苏的咒术师**.
  - 清除由施加的 [[spell:106823]] **帕特拉女王**.
  - 清除由施加的 [[spell:271563]] **防腐液**.
  - 驱散[[spell:196840]]施加的 **幽灵萨满祭司**.
- **适用条件：诸王之眠（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散作用于的[[spell:269935]] **祖尔的爪牙**.
  - 驱散[[spell:1296671]]施加的 **卫队长阿图**.
  - 驱散来自的[[spell:270901]] **总管姆巴拉**.
- **适用条件：诸王之眠（启用）。** [[spell:1266316]]用途：
  
  
  
  
  - 驱散来自的[[spell:267763]] **未完成的木乃伊**.
  - <em>注意：</em> 虽然[[spell:1266496]]可以驱散来自的[[spell:269972]] **复生巫师** 在这个节点上，如果打断失败，这些施法对团队的致命性要高得多。在这里你更有可能存活下来并驱散疾病。
- **适用条件：密谋小径（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散[[spell:1229433]]施加的 **恶棍法师**.
- **适用条件：密谋小径（启用）。** [[spell:1266496]]用途：
  
  
  
  
  - 驱散[[spell:1217973]]施加的 **被腐化的术士**.
- **适用条件：红玉新生法池（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 从 [[spell:373803]] 中清除 **灌能雏龙** 如果你在近战中被击中。
- **适用条件：红玉新生法池（启用）。** [[spell:278326]]用途：
  
  
  
  
  - 驱散[[spell:373973]]施加的 **灰烬先知燃鞭者** 在低血量时。
  - 驱散作用于的[[spell:391031]] **原始雷云**.
- **适用条件：塞塔里斯神庙（启用）。** 当前 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) 没有通过天赋替换获得的驱散实用用途。
- **适用条件：虚空之痕竞技场（启用）。** [[spell:198793]]用途：
  
  
  
  
  - 在 [[spell:1263982]] 层数中清除 **煞戎努斯** 首领战斗中。
  - 从 [[spell:1249621]] 中清除 **愤怒的克洛斯克**.

1.

## 功能技能与能力

本节介绍噬灭可以使用的、能在大秘境中发挥作用的关键天赋和技能。

控制防御与其它功能

4.1.

### 打断与控制

噬灭有多种阻止敌人施法的手段。由于用途不同，我们将它们分为单体情况下的工具和更适合群体的工具。

4.1.1.

#### 单体控制

[[spell:183752]]是噬灭的打断技能，冷却时间为15秒。应积极使用它来阻止危险的敌方施法（参见我们的[[spell:183752]]宏，位于 [噬灭恶魔猎手宏页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-macros-addons>)).

[[spell:217832]]是冷却时间为45秒的硬控制，但受到伤害会被打破。它既可以在战斗中作为打断手段，也可以用来锁定你想要跳过的目标。[[spell:217832]]的独特之处在于，受其影响的敌人在你或你的队伍跑过时不会进入战斗。

4.1.2.

#### 群体控制

[[spell:1234195]]是噬灭的群体眩晕技能，可眩晕你的目标及附近的敌人3秒，冷却时间为45秒，射程30码。这非常适合打断大群敌人，而且由于是瞬发，当多个目标同时施法时，可以成为强大的群体打断手段。点出[[spell:1266296]]后，还会将当前目标的眩晕时间延长至5秒，使其成为更出色的锁定工具。重要的是，这是一个 <em>远程</em> 对噬灭来说是远程眩晕，意味着你不必像使用[[spell:1234195]]那样必须贴近需要眩晕的敌人。

[[spell:207684]]是一个冷却时间为2分钟（点出[[spell:320418]]后减少至1.5分钟）的群体迷惑，延迟2秒后迷惑范围内目标15秒。该效果受到伤害会被打破，因此更偏向于打断工具，但需要把握好时机才能作为群体打断使用。它也可以用来跳怪，因为受影响的敌人不会攻击队友（但会攻击你），不过需要使用[[spell:58984]]在越过之后脱离战斗。

4.2.

### 防御手段

[[spell:198589]]是噬灭的主要主动防御技能，可将受到的伤害降低25%，持续10秒，冷却时间为1分钟。点出[[spell:389590]]天赋可以获得额外一层充能，由于冷却时间短，应在任何危险情况下积极使用。

[[spell:196718]]提供15%的几率（在地下城中提高到30%）为你或站在范围内的队友闪避任何伤害事件。持续8秒，冷却时间5分钟。持续时间可通过[[spell:389781]]延长至11秒，或者冷却时间可通过[[spell:389783]]缩短至3分钟。对团队生存很有帮助的额外效果， <em>尤其是</em>
用于持续性伤害事件（如持续伤害效果），以帮助你的治疗者跟上节奏。由于冷却时间较长，你应该提前规划何时使用它来应对高强度的拉怪。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) 歼灭者还可以获得[[spell:1256245]]，它根据你拥有的每层[[spell:1253304]]提供2%的伤害减免。根据你当前拥有的层数，减伤效果会在0%到8%之间波动。

[[spell:1241937]]还提供可观的治疗，在持续时间内恢复你24%的生命值。虽然你很少会为了治疗而施放它，但由于它是循环中使用的技能，它为这个已经很健康的专精提供了更多的续航能力。

4.3.

### 其他功能

[[spell:255260]]是噬灭被带去打团本的最主要原因，在大秘境中也是如此。 <em>根据团队阵容</em>，这会非常有益，因为游戏中目前有大量职业至少造成 <em>一些</em> 造成魔法伤害供其放大。这通常会在你自己造成的伤害之外，额外提供可观的伤害。

[[spell:278326]]是噬灭的进攻性驱散技能，冷却时间为10秒。它的优势是射程30码，可用于移除敌方目标身上的增益效果。不过它的冷却时间意味着你必须谨慎选择驱散什么，尤其是当多个敌人同时有增益效果时。

[[spell:198793]] 虽然用途有限，但在施放时可以打破定身效果。这在某些地下城中会很有用。

[[spell:1266496]] / [[spell:1266316]]允许你将[[spell:1241937]]用作自我驱散。前者移除诅咒，后者移除疾病，因此在生存方面有一些特殊用途。不过有了[[spell:1246556]]，这变得不那么可靠了。根据驱散的重要性，可能值得切换到[[spell:1246555]]来利用它。

1.

## 应对词缀

本节介绍噬灭可以使用的、能在大秘境中发挥作用的关键天赋和技能。

词缀：升腾 词缀：虚空 词缀：脉冲星 词缀：吞噬

5.1.

### 噬灭 恶魔猎手的升腾词缀应对

**萨拉塔斯的交易：升腾** 会定期生成一波波的光球，需要以某种方式对其进行群体控制，阻止它们完成施法。每成功阻止一个光球，团队就会获得急速加成，因此处理它们是高度优先事项。

噬灭可以也应该利用[[spell:1234195]]和[[spell:207684]]来阻止一波怪，同时以[[spell:183752]]和[[spell:278326]]作为后备，以防队伍难以清理所有漏网之鱼。

5.2.

### 噬灭 恶魔猎手的虚空词缀应对

**萨拉塔斯的交易：虚缚** 会周期性地召唤一个大型的虚空大使，它将开始施放[[spell:462508]]。这个敌人 **必须** 在施法完成前被击杀以阻止它，否则它会为附近的敌人提供显著的减伤。如果成功阻止，队伍将获得大量的全能和冷却缩减。

这个必须快速击杀，所以尽量留好像[[spell:473728]]、[[spell:1246167]]或[[spell:1221167]]这样短而爆发性的冷却技能来快速转火。然而，由于这些技能是你的群体循环的关键，这并不总是可行，所以只要注意它的刷新并相应切换目标即可。

5.3.

### 噬灭 恶魔猎手的脉冲星词缀应对

**萨拉塔斯的交易：脉冲星** 会生成一个围绕每个玩家旋转的光球，需要由另一名玩家在光球消失前分担。每个光球将为队伍提供4%精通和2%吸血，可叠加，持续30秒。未被分担的光球会增加附近敌人的伤害输出，并降低他们受到的伤害。

噬灭没有专门的工具来应对这个，相反，你需要注意自己的站位，既要确保其他玩家能接住绕着你转的光球，也要让你能接住附近玩家的光球。

5.4.

### 噬灭 恶魔猎手的吞噬词缀应对

**萨拉塔斯的交易：吞噬** 会对每名队伍成员施加一个减益效果，必须通过驱散或治疗来消除（但请记住这个 <em>不会</em>
吸收即将到来的治疗）。每驱散一个减益效果都会为队伍提供最大生命值和暴击，可叠加，持续30秒。任何被 <em>非</em>
清除的减益效果都会为附近的敌人恢复大量生命值。

在至暗之夜中新增，吞噬现在会为你的角色增加10%的减速。这意味着[[spell:198793]]可以驱散它。或者，[[spell:1241937]]在激活时会移除它 <em>无论是</em> [[spell:1266316]]或[[spell:1266496]]。如果这些选项不可用，考虑使用治疗药水或治疗石来帮助你的治疗者，如果他们感到吃力的话。

1.

## 更新日志

- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 页面已更新至至暗之夜第一赛季。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对12.0.1补丁进行更新。
- **2026年1月31日：** 已更新至至暗之夜前夕补丁的在线修复。
- **2026年1月19日：** 页面已创建。

显示更多

显示更少

## 宏与插件

在本页中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5补丁中游玩你的噬灭 恶魔猎手时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件和宏页面。在这里我们将介绍有用的插件

你可以使用它们通过更信息化的界面来提升你的游戏体验，以及

提供一些常用的噬灭 恶魔猎手宏。

1.

### 噬灭 恶魔猎手宏

宏可以通过游戏内的/macro命令访问，它们允许你

创建在你按下按键绑定时执行的小脚本。这些

对于将多个操作组合成一个非常有用，一个常见的例子是

在一次按键中将非公共冷却饰品与冷却技能组合在一起。

2.1.

#### 瓦解 焦点打断宏

#### 焦点打断

```wow-macro
#showtooltip

/stopcasting

/cast [@focus,exists][@target] 瓦解
```

此宏将中断你当前的施法，并对你的目标施放[[spell:183752]]。

焦点目标（如果可用）；否则，它将施放在你的目标上

（关于瓦解的更多信息，请见我们的 [法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)).

2.2.

#### 吞噬魔法

#### 焦点驱散

```wow-macro
#showtooltip

/stopcasting

/cast [@focus,exists][@target] 吞噬魔法
```

此宏会停止你当前的施法，并将[[spell:278326]]施放于

你的焦点目标，如果可用，否则将施放在你的目标上（更多

关于Consume Magic的信息，请见我们的 [法术页面](<https://www.icy-veins.com/wow/devourer-demon-hunter-pve-dps-spell-summary>)).

2.3.

#### 悲苦咒符 目标选择宏

[[spell:207684]]可以修改为瞬发施放，无需

使用目标圈并减少一次输入。这可以通过两种

不同的方式实现，以下方式将其放置在你的鼠标光标处：

#### 光标处符咒

```wow-macro
#showtooltip

/stopcasting

/cast [@cursor] 悲苦咒符
```

或者，如果你已经站位良好，

可以在自己脚下施放：

#### 自身处符咒

```wow-macro
#showtooltip

/stopcasting

/cast [@player] 悲苦咒符
```

2.4.

#### 防引导宏

由于完整引导[[spell:473728]]对噬灭很重要，

防引导宏可以用来防止你过早打断它。

只需将下面的Ability_Name替换为你想要

不打断[[spell:473728]]的技能。请注意这些 **不会** 目前有效

使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/void-scarred.webp>) 虚痕枭雄.

#### 防引导模板宏

```wow-macro
#showtooltip Ability_Name

/stopmacro [channeling:Void Ray]

/cast Ability_Name
```

1.

### 最佳插件

3.1.

#### 恶魔猎手 通用插件

你的大部分界面需求可以通过一些努力使用新的暴风雪界面

在至暗之夜中的选项来满足，但如果你正在寻找一些额外的自定义，以下是

一些热门选择。

3.1.1.

##### 首领模块插件：Deadly Boss Mods 或 Bigwigs

首领模块插件会警告你首领的技能，并就如何处理某些机制提供实时建议。我们强烈建议你安装这样一个插件。在Icy Veins，我们主要使用
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>)，这是最受欢迎的首领模块插件。一个不错的替代选择是
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

3.2.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) 是对默认用户界面的完整替代。它包含了你正常发挥所需的几乎所有功能：动作条、单位框体、冷却计时器、触发提示等。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 针对12.1.5补丁进行审查
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 页面已更新至至暗之夜第一赛季。
- **2026年2月26日：** 页面已更新至至暗之夜上线。
- **2026年2月10日：** 页面已创建。

显示更多

显示更少

:::
