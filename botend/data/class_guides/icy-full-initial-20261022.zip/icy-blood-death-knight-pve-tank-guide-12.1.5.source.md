## 专精概览

Welcome to our Blood Death Knight guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to tank as a Blood Death Knight in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your survivability.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Blood Mythic+ Resources

[NEW! Top Blood Talent Builds](<https://raider.io/specs/blood-death-knight/talents>)

[Top Blood Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/death-knight/blood>)

[Blood Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=death-knight--blood>)

[Popular Blood Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=death-knight--blood>)

1.

### Blood Death Knight Overview

Blood Death Knight is one of the six available tanking
specializations within World of Warcraft, and is centered around clear
and precise usage of resources to reactively heal a large part of
the damage taken using [[spell:49998]].

Blood's large array of cooldowns include one of the most potent magical 
defense cooldowns in the game ([[spell:48707]]), an uncapped cheat 
death talent ([[spell:114556]]) and a spectacularly large array of defensive 
buffs on very short cooldowns.

This guide focuses on aspects that are specific to Blood Death
Knights and general tanking strategies are beyond its scope. If you wish to
know more about the tanking role and what you can do to improve, we recommend
that you read our [tanking guide](<https://www.icy-veins.com/wow/tanking-guide>).

Overperforming

Blood is currently slightly overtuned, particularly in AoE and cleave, and this stems from a
combination of deliberate buffs to all abilities and one unintended change affecting
[[spell:434260]]'s [Corrupted Blood](<https://www.wowhead.com/npc=53889>) damage pulse.

We expect a couple of direct changes to Blood's damage profile once the season
rolls around.

A very solid choice in raid.

The new [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) raid provides no shortage of fights where [[spell:49576]]
and [[spell:383269]] shine. This, Blood's recent damage buffs, and its peculiar utility
toolkit pretty much guarantee at least one in your raid.

Great until the top

Blood will very likely fare in almost the same way as in Season 1, even with the
talent changes (such as adding a damage reduction element to [[spell:391398]]) and the
bugfix to [[spell:1264405]]. Its problem remains the same: no defining utility,
no group buffs, a damage taken profile that is difficult to predict and this is <em>especially</em> true
with the apex.

The buffs to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn make it an even more contentious proposition, as it is
capable of dishing out absurd damage in both AoE and single target, but comes at the cost of a notoriously
harder pull set-up than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer. Our new tier set's 4-piece bonus helps slightly on this,
but the problem is largely the same as before.

The worst in all this is that the specific bugfix to [[spell:1264405]] impacts a moment in time
at which Blood is already strong: while [[spell:49028]] is active.

Unique... When It Matters

Blood's utility is amazing when it works and makes a difference, and completely useless otherwise. Both
[[spell:48707]], [[spell:108199]], and [[spell:49576]] can be put to good use,
but they are only noteworthy when the encounter is designed around it.

Outside of that, [[spell:51052]] has been thoroughly obliterated and is now strictly worse than
a number of competing options from other classes, all while Blood also brings no
noteworthy group buff to the table.

Acceptable

The talent overhaul in season 2 and the 25% rescaling of everything was not completely done for
Blood. In particular, auto-attack damage was not adjusted ([[spell:207200]]), and [[spell:374598]]'s
direct damage was also not adjusted. This leads to a minor impact.

Beyond this, however, buffs to mandatory talents, a bugfix and buff to [[spell:1264405]] and
a tier set that provides both free resources and a very large stacking Strength buff provide a nice
push forward in the survivability department, at least in general. The apex is still random, but at least,
you can now consider [[spell:49028]] as a 12% damage reduction cooldown against non-parryable
damage as well.

Passable

All of Blood's mobility is easily accessible on the class tree in the form of two "free"
[[spell:343257]] charges that you can augment further with [[spell:391546]]
or [[spell:212552]]. [[spell:343257]] also doubles as a knockback immunity.

Unfortunately, that is as far as it goes. Beyond those two rolling charges, speed
boosts are non-existent.

2.

### Blood Death Knight in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.5. brings no noteworthy change for Blood Death Knights, 
beyond a couple of interesting new items from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 
and the ability to very easily get Myth-track pieces from the new 
delve feature, the Labyrinth of Kindo'jan.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Helmet. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

2.3.

#### Class Changes

There are no changes to Blood Death Knight in Patch 12.1.5, but two 
items from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) are strong enough to change our 
Overall and Raid-based gear recommendations on our 
[gear](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>) page. We also have a list of 
high-value items to spend your first [[item:280562]] on it, just in 
case you are new to this system.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_bloodpresence.jpg>) Click for Previous Season 2 Changes
2.4.

#### Class Changes

Patch 12.1 is accompanied with targeted changes to the Blood Death Knight spec tree, along with a large 
bugfix to [[spell:1264405]], 4% bonus damage reduction on [[spell:391398]], more direct damage for 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer and more AoE damage for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn (this one comes at the cost of some single-target 
damage through a slight [[spell:434075]] nerf).

Make sure to check out the relevant information about both
on our dedicated [Talents](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>) and 
[Gear](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>) Guides!

2.5.

#### Bugfixes and Bugs

The only noticeable bugfix affects [[spell:1264405]], and even though it occurred before 12.1, 
we are bundling it here. Previously, it caused you to take extra damage; this has been fixed to properly 
reduce damage taken and buffed to 6% per [[spell:49028]] active.

Two major bugs currently affect Blood, both positively affecting hero talent choice:

- Blizzard intended to buff [[spell:434260]]'s auto-attack damage by 1400% and instead buffed 
    **all its damage** by 1400%. This includes [Corrupted Blood](<https://www.wowhead.com/npc=53889>), which was already doing sensible 
    damage.

This pushes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn further up in AoE, and the recent fix to [[spell:1265855]] has pushed 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer down across the board.

2.6.

#### Talent Changes

The following impactful talent changes land alongside 12.1:

- [[spell:391398]] now causes [[spell:77535]] to also reduce all damage taken by 4% while it is 
    active. This is not a partial effect.
- [[spell:374747]] has been changed from 6% versatility to a 4% reduction in damage 
    taken
- [[spell:49028]]'s base parry value has been increased to 30%
- Minor non-[[spell:49998]] sustain buffs: [[spell:273953]] now grants 15% leech while it is active, 
    [[spell:194662]]'s leech now grants 85% more conversion on [[spell:55078]]'s and [[spell:274156]]'s 
    healing, [[spell:1263781]]'s healing conversion is now 18% of damage dealt and [[spell:391517]] now tallies 
    600% of [[spell:55078]] damage. These effects are likely to counteract the 25% health and damage increase from enemies.
- A noteworthy reduction of [[spell:434157]] from 12% bonus Strength to 10%. This has the unintended positive effect of 
    reducing the value of [[spell:144758]] even further.
- [[spell:434075]] now only grants 5% bonus [[spell:49998]] damage per stack, down from 6%. This sounds small, but 
    amounts to a 21% reduction in [[spell:49998]] damage in [[spell:434152]].
- Finally - damage. 50% more damage on [[spell:195182]], 25% on [[spell:206930]] and [[spell:433901]], 20% more 
    auto-attack damage (and thus a tiny bit more [[spell:207200]] value).

A number of additional hotfixes and planned changes happened mid-way through Season 1. You can see a recap of them below:

2.7. 

### Tank Balancing Hotfixes

A small number of defensive changes were hotfixed as part of the weekly release of May 12th:

- [[spell:374721]] now grants 40% bonus stamina
- [[spell:1264351]]'s duration was increased to 8 seconds, and its proc chance per rune to 
    12.5%
- [[spell:49028]]'s base parry rate was shifted up by 5% to 25%; this applies to both 
    [[spell:1264351]] procs and hard-casted [[spell:49028]]
- [[spell:374277]]'s healing increase was reverted back to its pre-Midnight value 
    of 15%

This aims to undo some of the previous nerfs, and while these changes are broadly positive, increasing 
the relative strength of the apex [[spell:49028]]s accentuates the reliability issue with it 
being a proc.

These changes are also not entirely neutral offensively. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn benefits very slightly 
more from these changes thanks to [[spell:1264506]] and [[spell:1264405]], along with 
being able to generally have more value out of copied spells 
during [[spell:49028]].

:::

### Midnight   Changes Overview

2.8.

#### Midnight Changes for Blood Death Knight

The Midnight launch brings bugfixes to Blood Death Knights, and the addition of 
a total of 10 new talent points; three on the class tree, three on the Hero Talent tree (which 
means you can finally just take everything instead of being limited by a hard choice), 
and four remaining points on the spec tree to spend on **Apex Talents**.

Beyond this, haphazard numerical hotfixes to certain abilities have had 
priority implications compared to the pre-patch:

- A 20% buff to [[spell:206930]] without a compensation buff to 
    [[spell:433901]] effectively pushed two ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn talents 
    down and tapered the value of [[spell:434152]] while also feeding into 
    both the strength of apex talents and [[spell:458753]].
- A base buff to the direct (non-empowered) damage of [[spell:274156]] without 
    buffing the empowered [[spell:55078]]-specific damage results in never 
    actually wanting to empower [[spell:274156]]. Great job, I guess.

The addition of Apex talents and the most recent buffs to Blood's base kit were 
enough to propel ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn back to the fore on single target and consistent 
three-target cleave. Your mileage may vary in between or in AoE, as this depends entirely 
on the availability of [[spell:439843]] (45 second window vs. 90 second window for 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn).

2.9.

#### Apex Talents

Blood's Apex Talents are simple in design.

- The first has a guaranteed chance on next 
  parry while [[spell:49028]] is active to make your 
  next [[spell:206930]] free, while still generating runic power. This is gated 
  behind a 3 second internal cooldown
- The second node (2 points) increases your damage done and reduces 
    your damage taken for every [[spell:49028]] active.
- Finally, the capstone grants you a 10% chance to spawn a [[spell:49028]] 
    when you spend a rune.

The procs from the apex talent are regular [[spell:49028]]s - only one at a time, 
for six seconds only, and if you already have a [[spell:49028]] active, the duration 
of the buff it provides is simply re-calculated to be the longest lifetime of any 
[[spell:49028]]. There are some caveats to this due to a limit on how many you can have up 
at any time, but this only really applies in single target under the effect of [[spell:2825]].

To call this disappointing is an understatement, especially when you consider how 
hard they nerfed [[spell:49028]] to accommodate for the increased uptime rather 
than actually differentiating a hard-cast of it or a proc from the apex talents. With 
[[spell:49028]]'s bonus RP generating, parry rate and duration all having been 
on the chopping block to accommodate these, it is hard to be positive about it.

Nevertheless, it is what we are stuck with, and beyond [[spell:206930]] occasionally 
glowing and an incentive to slightly delay [[spell:49028]] in AoE to optimize 
the first point, these talents are mostly passive.

2.10.

#### Hero Talent Changes

Both Hero talent trees have picked up three new nodes, and you will be able to 
select every single one of them by the time you reach 90.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn has lost its end-of-[[spell:49028]] burst of 
damage from [[spell:434143]], but the newly redesigned 
[[spell:274156]] brings some of the complexity back by forcing you to 
cast it once [[spell:49028]] ends instead of just before it. As such, 
the complexity is, frankly, mostly the same.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer picks up an element of complexity in 
[[spell:1265855]]. The outright removal of [[spell:343294]] also helps a 
bit in removing some of the most clunky aspects, but no damage profile values or 
related spell effects have been adjusted to account for either the direct loss of it, 
or the loss of the [[spell:194844]] procs from [[spell:439843]].

Numerically, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer is ahead where it matters, and the compounding 
choices from the dev team to keep buffing [[spell:206930]] without applying 
the same buffs to [[spell:433901]] simply push ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn further and 
further with every hasty hotfix.

2.11.

#### Survivability

Blood lost the following:

- [[spell:374277]] nerfed from 15% bonus to 5% bonus healing
- [[spell:49998]]'s base window nerfed from 25% of all damage taken to 20%
- [[spell:219809]], [[spell:194844]], [[spell:49039]]'s damage reduction, 
    [[spell:194679]] outright removed.
- [[spell:49028]]'s duration reduced to 12 seconds (from 14) and bonus parry  
    from 35% to 20%
- [[spell:377637]] changed to flat 30 second cooldown reduction
- 10% less armor from [[spell:195181]] from the removal of [[spell:374737]]
- The outright and confirmed removal of [[spell:45902]] (the 3 RP bonus from every 
    [[spell:206930]] when [[spell:49028]] is active)

And in exchange for this hoard of abilities and effects, it picked up the following:

- 35% bonus base armor from items (equivalent to roughly half of [[spell:195181]]'s bonus armor)
- A total of 12% more armor from strength on [[spell:195181]] compared to 11.2 (factoring in 
    [[spell:374737]]).
- [[spell:1264296]], located in such a way that it is not a mandatory talent
- [[spell:1279633]], located below the second gate - in other words, costly
- [[spell:1263743]], acting as a small amount of bonus Runic Power when you need it 
    the least

Calling this a negative change does not even begin to describe this level of decimation.

2.12.

#### Utility

The only noteworthy change in utility stems from a change in the layout of the spec tree. 
[[spell:108199]] is now a choice node with [[spell:383269]], and either point 
is almost mandatory in the current layout.

This is great, and while there are practical use-cases for both, you will most often default 
to picking [[spell:108199]].

3.

### Basics of Blood Death Knight Gameplay

Blood Death Knight has an engaging play style, using self-healing
through [[spell:49998]] as a primary source of damage mitigation. As
[[spell:49998]] works off a constrained resource (Runic Power), clever
optimization of all the ways to generate it becomes paramount. Blood also
features a versatile and effective defensive and offensive toolkit,
which comprises numerous smaller defensive cooldowns than other
tanks, aimed at countering certain scenarios. These can be chained as
needed during a fight, although we strongly recommend using them as close
to on cooldown as possible. Blood Death Knight is more clearly defined 
by the following three points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_butcher2.jpg>) **Generate and Spend Runic Power**  
  
    Runic Power is your bread and butter. Generate it by spending runes and maximizing [[spell:206930]] usage, and spend it on [[spell:49998]] without 
    wasting any. Even if you are at maximum health, [[spell:77513]] still applies, as does its damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_sword_07.jpg>) **Cycle Ability Cooldowns**  
  
  [[spell:49028]], and additionally [[spell:439843]] are your two main offensive cooldowns. You should keep those as close to on cooldown as possible. In addition to the direct damage they provide, 
    they also grant a number of significant offensive and defensive buffs!
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_deathwing_bloodcorruption_earth.jpg>) **Manage Buffs and Debuffs**  
  
    Keep [[spell:195181]] above 5 stacks, remember to press [[spell:49998]] before [[spell:273946]] reaches beyond 5 stacks, press [[spell:43265]] when [[spell:81136]] procs or if you need to cleave 
    4+ targets.

Put together, this specialization is effective in the full range of
current content with proper management. Essentially, if you can survive
a hit, you will come out stronger after it.

4.

### How to Gear Up as a Blood Death Knight

While we always recommend simming yourself for ideal results, we do provide a
dedicated Blood gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Added ascendant venomstone usage.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Added Kith'ix, labyrinth and a note that no changes applied to Blood so far.
- **21 Aug. 2026 (this page):** Adjusting for Echoing fury fix
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.1. BiS lists are partially placeholder due to untestable embellishments.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Removed Zealotry (it has not been buffed and it was only good in early S1 on ST), added new health potion for 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated all the builds for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1 launch.
- **19 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Gear update - removing the Deathbringer list for now.
- **19 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Very small runeforge target count change.
- **19 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Omnium changes.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **21 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Refining/clarifying bonus rolls.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Adding voidcores and their priorities.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Prepared the builds for 12.0.5 and the change on Desecrate.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated Desecrate for 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Added patch 12.0.5 changes for blood, voidcores and bonus rolls.
- **24 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Removing teas from consumables.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Adding heirloom info and general levelling guidance.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Season 1, including BiS lists and trinket lists
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Very small clarity change.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Clarifying cooldowns.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** PvP talent and Consumption changes.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Adding a tiny tier set disclaimer.
- **16 Mar. 2026 (this page):** Adjusted to take into account the March 17 tuning pass.
- **11 Mar. 2026 (this page):** Updated for season launch.
- **04 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Clarified Carnage.
- **04 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Clarified Carnage.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Preparing for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Added embellishments, trinkets, gear and information about Midnight.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** New macro format.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Enchants, consumables, flasks and pots are added.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Changes for the Midnight pre-raid launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Added Apex info.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Added apex talents
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Adding apex talents and their impact.
- **26 Feb. 2026 (this page):** Preparing for Midnight launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated build for Midnight pre-patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Changed all item levels, tier set information and a couple of trinkets.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Added a handful of add-on suggestions for Midnight.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Prepared for pre-patch. Swapped all enchants to speed in preparation for levelling.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Small edits for Midnight.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Prepared for pre-patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** First pass at Midnight pre-patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for the Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Prepared for Midnight pre-patch.
- **10 Feb. 2026 (this page):** Preparing for Midnight pre-patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Adding simming FAQ temporarily here as a placeholder.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Small update to include the FAQ elements in the page.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Added performance tabs, small page changes.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Added back Puzzling Cartel Chips, clarified embellishments and crafting order, removed DISC.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Adjusted to assume the deathbringer 2-piece is available.
- **01 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Clarified toggles.
- **01 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Clarified a few entries.
- **20 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Adding M+ tips.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updating for hotfixes.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Changed builds and updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for 11.2, including all trinkets.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for 11.2, removed Limb, and prefaced that this page assumed no tier set.
- **04 Aug. 2025 (this page):** Added information about 11.2.
- **25 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updating D.I.S.C. recommendations after hotfix.
- **25 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2; removed all limb references and adjusted talent buids.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Adding D.I.S.C. recommendations for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Adding combat assistant section and listing the biggest problems with it.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Added combat assistant mode info and estimated performance losses from it.
- **15 Jun. 2025 (this page):** Added information about 11.1.7 and the combat assistant.
- **19 May 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Simplifying the San'layn opener slightly.
- **13 May 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Refining dinar recommendations.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Removed Congratulations! section.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Added horrific visions enchants and a blurb on how they are not quite the same as before.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Mythic+ tips.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added information on Patch 11.1.5.
- **25 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** Added additional defensive tips and tips for Mythic.
- **18 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** Gallywix tips added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Prepared for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Clarified second opener, primed for 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Prepared for Patch 11.1.
- **24 Feb. 2025 (this page):** Reworked for 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Adding Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Adding Cyrce's Circlet.
- **30 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Added the rotation section.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** The tips are in!
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Re-worked the entirety of the san'layn opener and rotation, clarified all of it, added the DB soul reaper and clarified the rest of the page.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Added all the san'layn builds and cleaned up the page for 11.0.5
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated to account for the entire Deathbringer rework of 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated to add the 11.0.5 changes to Deathbringer and San'layn.
- **16 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** Updated tips for Ansurek.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for TWW S1, added all BiS lists and all trinket ratings.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-nerub-ar-palace-raid-guide>)):** Page created.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Preparing for TWW S1 launch. Everything except dungeon tips are in place.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Removed legendary axe recommendation as new sims show this to be a DPS loss over item level.
- **27 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Added description for M+ talents to also be used for Delves.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for The War Within Launch with new additions for Hero Talents on your journey to level 80.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for The War Within Launch with Pre-Season BiS. Stay tuned for Season 1 Updates!
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for The War Within Launch.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for The War Within Launch with new consumables and enchants!
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Updated for The War Within Launch. Seperated out stat priorities for the different Hero Talent Trees.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within Launch with additions for Hero Talents.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for The War Within Launch. Hero Talents added. Builds updated.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for The War Within Launch. Added Hero Talents.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for the War Within Launch. New Talents added and rotation updates.
- **21 Aug. 2024 (this page):** Updated for The War Within Launch.
- **19 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated talent tree for The War Within Launch.
- **24 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/blood-death-knight-mists-of-pandaria-remix-guide>)):** Correcting talent hashes.
- **24 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Correcting talent hashes.
- **24 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Correcting talent hashes.
- **24 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Correcting talent hashes.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/blood-death-knight-mists-of-pandaria-remix-guide>)):** Updated remix talents and rotation.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reworked for TWW pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Removed bullion section to prepare for pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Adjusted for TWW pre-patch, updated with yesterday's hotfixes.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Prepared for TWW, including rotational changes affecting pre-patch (no hero talents yet).
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Prepared for War Within. New talents added, builds changed.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Prepared for pre-patch.
- **23 Jul. 2024 (this page):** Added disclaimers and reworked for TWW pre-patch.
- **18 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Adjusted builds for TWW pre-patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/blood-death-knight-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/blood-death-knight-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updating talents slightly. Blood tap is probably a bit too complicated for starters.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Prepared for Season 4. Contains new BiS with all the S4 gear, cantrips, trinkets, bullions etc.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.6.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.6.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Clarified pre-key, pre-pull, between-pull tips, affix tips, sorted out builds and added routing tips. Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.6.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Updated for Patch 10.2.6. Teasing the s2 set along with no changes.
- **18 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Removed outdated reference to talents unlocking at level 15.
- **18 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Syncing up with stats page. Updated for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Clarifying BiS lists, removing crafted from M+/raid tables.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Added a quick note explaining the 10.2.5 changes.
- **03 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Removing tuning disclaimers, adding Fyr'alath.
- **03 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Overhauled, moved to checkboxes for everything and added how to use fyralath correctly.
- **27 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Adding in murozond's rise/galakrond's fall separate links.
- **09 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Removed outdated reference to Blood for Blood.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Sporecloak got taken out back, so we update that.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Prepared for 10.2, all trinkets are in, all gear sets are in.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Added helm enchant, changed health pots to 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Prepared for 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Swapped a season 2 reference.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Swapped build orders to suggest Soul Reaper as default in raid.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Minor clarity changes.
- **06 Nov. 2023 (this page):** 10.2 changes.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** New format - and some clarifications + BiS lists for 10.1.7!
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Clarified stats.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** New template for 10.1.7. Also added SR build.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Cleaned up for 10.1.7.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Added 10.1.5 info about mega dungeon and open world trinkets.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added 10.1.5 info, explained the soul reaper and spec aura stuff.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Added timewalking section.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Season 2 launch. Moved Onyx Annulet section to the bottom of the page (It's still good for damage!)
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated and clarified Onyx annulet section, added 10.1 Belt enchant, clarified gems, clarified potions and phials. Ready for 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Removed thundering, added info about new affixes and how Blood has no way to help with them.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Refined talents and rotation spell descriptions.
- **01 May 2023 (this page):** Reviewed for Patch 10.1.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Clarified control undead and its use in Season 2.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/blood-death-knight-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Added Onyx Annulet and clarified its use in content.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Added Onyx Annulet and clarified info for 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Clarified talents.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Clarified talents.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **03 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Clearing up Marrowrend vs. Caress.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Fixes for Talent Tree displaying wrong order to pick talents.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Adding max level brackets to all options.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Season 1 launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1 launch. Added a very small rotational change due to the Tier set.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Prepared for the initial release of Mythic+. In-depth, expanded spell information will follow after launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/blood-death-knight-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/blood-death-knight-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/blood-death-knight-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/blood-death-knight-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **10 Apr. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-2-changes-analysis>)):** Updated to account for hotfixes, added info on Legendaries, new Legendaries, Halondrus, and Tombstone.
- **12 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-2-changes-analysis>)):** Adjusted for current PTR data, clarified some points.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-1-changes-analysis>)):** Added info about AoE uncapping, and clarified the intro for 9.1.5 info.
- **18 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-1-changes-analysis>)):** Removed PTR references; updated information for Theotar and Dreamweaver.
- **29 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/blood-death-knight-patch-9-1-changes-analysis>)):** Added initial content.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **20 Dec. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** Updated essence choices.
- **23 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** Updated with Mythic information from Week 1.
- **13 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** Further updates to class tips.
- **11 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** Updated with additional information and up-to-date Essence recommendations.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-the-eternal-palace-raid-guide>)):** Guide added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **21 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-crucible-of-storms-raid-guide>)):** Guide added.
- **22 Jan. 2019 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Updated wording in the introduction.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-battle-of-dazar-alor-raid-guide>)):** Guide created for Season 2.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Updated recommendations for Fetid Devourer, Vectis, Zul, Mythrax, and G'huun.
- **24 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Updated recommendations for several bosses.
- **06 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Updated MOTHER and Fetid Devourer recommendations.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Added Uldir boss recommendations.
- **24 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Updated Azerite Trait and Gear recommendations.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-uldir-raid-guide>)):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Blood Death Knight leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Death Knight leveling guide](<https://www.icy-veins.com/wow/death-knight-leveling-guide>).

1.

### Blood Death Knight Leveling Guide for Midnight

Blood Death Knight excels at levelling by virtue of being a tank, 
and thanks to pretty impressive self-sustain built into the spec. You can effortlessly 
pull entire zones while levelling and sustain effortlessly thanks to [[spell:55078]] 
and [[spell:49998]].

Tired of grinding? Tank queues in group finder are instantaneous!

1.1.

#### Leveling Gear Options

When leveling up, you should always choose the piece of loot with the
highest item level.

Your goal is, evidently, to go as quickly as possible throughout the
zones and levels, and the best way to do this is to get the best possible gear
without getting out of your way while doing so.

Heirlooms are a particularly potent source of bonus power while leveling. The set bonus 
effects they confer is particularly noteworthy as a tank, especially if you manage to gain 
a level while in combat. We have documented all of them on our dedicated 
//www.icy-veins.com/wow/heirlooms-guide, Heirlooms Guide. The 5-piece set bonus 
is where the true power lies, but getting even more out of your rested experience is 
also great!

If you are not sure, or would like a short list of what to equip, 
the following are the highest impact heirlooms 
to unlock the 6-piece set bonus they confer; we have also curated this list 
because they do not require any reputation or other unlocking mechanism to acquire. 
Don't forget to upgrade them!

<table>&#10;<thead>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Heirloom</th>&#10;</tr>&#10;</thead>&#10;<tbody>&#10;<tr>&#10;<td>Helm</td>&#10;<td>[[item:122263]]</td>&#10;</tr>&#10;<tr>&#10;<td>Neck</td>&#10;<td>[[item:122668]]</td>&#10;</tr>&#10;<tr>&#10;<td>Cloak</td>&#10;<td>[[item:122266]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:122388]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:122387]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:122264]]</td>&#10;</tr>&#10;</tbody>&#10;</table>

[[item:105691]] is the best heirloom weapon you 
can have equipped, but [[item:122349]] is not far behind.

1.2.

#### Useful Leveling Consumables for Midnight

We recommend stocking up on the following to ease leveling before 
levelling a character in Midnight, as the gain they provide can be significant:

- [[spell:1246966]] can be used in a similar fashion to [[spell:58984]]
      to drop combat, which is particularly useful to efficiently dip out of an encounter or 
      area after you have collected what you need. You can immediately get on your mount 
      while hidden from sight.
- We recommend buying at least one stack of [[item:225592]]. 
      The speed boost from this food is particularly valuable when leveling.
- If you are okay with using combat potions, multiple stacks of 
      [[item:221874]]
- Swap your runeforge to [[spell:326977]]. The 
      speed boost it provides when you slay an enemy quickly adds up to a noticeable amount 
      of time saved.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

2.1.

#### War Mode Talents for Leveling

While leveling with War Mode enabled, you gain access to three additional
PvP talents. Their effects also work on enemies in the open-world, and while
most of them are lackluster, a couple of them can <em>significantly</em> speed
up your leveling process. We have highlighted them below.

- [[spell:203173]] allows you to frequently (50% uptime) chain an enemy
  with two nearby hostile targets. While chained, damage done to one enemy is
  partially copied over to the other two. This effectively rewards you for
  pulling more than one target (which you should do, anyway. You are a tank) by
  allowing you to increase your effective damage by 30%.
- [[spell:199720]] causes enemies to have their maximum Health reduced by 
  3% every 2 seconds, up to a maximum of 15%.
- [[spell:207018]] is a 3-15% damage increase on a target, refreshed
  by your auto-attacks. This is the least bad option we have access to after
  picking the other two.

3.

### Leveling Rotation

The basic rotation as a Blood Death Knight is based on this
priority. We have shown/hidden elements based on the level at which you 
acquire them; please use the slider at the very top of the page to select 
what level you are at.

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–10：**Until level 10, if you are an old-school race, your
[[spell:206930]] will be replaced by its generic alternative,
[[spell:316239]].

1. Use [[spell:43265]] where you intend to fight, and refresh it when 
   the buff it applies to you when standing in it fades. Do not get fooled by its 
   visual presence, as [[spell:316916]] causes the buff from it to last four 
   seconds longer.
2. Use [[spell:49998]] if your health is low or if you are above 
   75 Runic Power.
3. Use [[spell:50842]] if any nearby enemies do not have your
   [[spell:55078]] disease, or you are close to having 2 charges of 
   [[spell:50842]].
4. **等级 71–90：**If [[spell:439843]] is available, cast it on any 
   nearby enemy.
5. **等级 75–90：**Spend [[spell:441378]] charges by casting [[spell:195182]].
6. **等级 27–90：**Use [[spell:49028]] on cooldown.
7. Use [[spell:195182]] 
   (or [[spell:195292]] if you are out of melee range) if
   your [[spell:195181]] is about to expire.
8. Use [[spell:195182]] if you have 6 or fewer stacks of
   [[spell:195181]].
9. Use [[spell:206930]] if you have 2 or more Runes.
10. Use [[spell:50842]].

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Adding heirloom info and general levelling guidance.
- **26 Feb. 2026:** Preparing for Midnight launch.
- **10 Feb. 2026:** Updated build for Midnight pre-patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Changed builds and updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Removed Congratulations! section.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Added the rotation section.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch with new additions for Hero Talents on your journey to level 80.
- **23 Jul. 2024:** Reworked for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updating talents slightly. Blood tap is probably a bit too complicated for starters.
- **18 Mar. 2024:** Removed outdated reference to talents unlocking at level 15.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **09 Nov. 2023:** Removed outdated reference to Blood for Blood.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Adding max level brackets to all options.
- **11 Dec. 2022:** Fixes for Talent Tree displaying wrong order to pick talents.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Blood Death Knight in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Blood Death Knight

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play. Blood boils down to three simple concepts:

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_deathknight_butcher2.jpg>) **Generate and Spend Runic Power**  
  
    Runic Power is your bread and butter. Generate it by spending runes and maximizing [[spell:206930]] usage, and spend it on [[spell:49998]] without 
    wasting any. Even if you are at maximum health, [[spell:77513]] still applies, as does its damage.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_sword_07.jpg>) **Cycle Ability Cooldowns**  
  
  [[spell:49028]], and additionally [[spell:439843]] are your two main offensive cooldowns. You should keep those as close to on cooldown as possible. In addition to the direct damage they provide, 
    they also grant a number of significant offensive and defensive buffs!
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_deathwing_bloodcorruption_earth.jpg>) **Manage Buffs and Debuffs**  
  
    Keep [[spell:195181]] above 5 stacks, remember to press [[spell:49998]] before [[spell:273946]] reaches beyond 5 stacks, press [[spell:43265]] when [[spell:81136]] procs or if you need to cleave 
    4+ targets.

2.

### Beginner's Guide to Blood Death Knight in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer   Talents

2.1.

#### Beginner Talents for Blood Death Knight

The following build has been designed to provide as simple a rotation as
possible; it brings convenient choices at the loss of some throughput, all
with the goal of making starting out as a Blood Death Knight more seamless.

It is technically also one of the core builds Blood Death Knights can use 
and is usually the most applicable to all content. The main difference between 
this build and actual builds presented elsewhere in the guide is the removal of a single 
active ability: [[spell:274156]].

We recommend this build for beginners in all content, as the choices otherwise 
would include very specific gameplay-specific tweaks based on criteria that are unlikely 
to apply to newcomers.

Use the 'Export Talents' on the calculator to easily copy the build in-game.

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

### Blood Death Knight   Basic Rotation

2.2.

#### Basic Rotation for Blood Death Knight

The basic rotation as a Blood Death Knight is based on this
priority. It includes both single-target and AoE recommendations. As usual, more
information is available on the in-depth rotation page!

1. Use [[spell:43265]] where you intend to fight, and refresh it when 
   the buff it applies to you when standing in it fades. Do not get fooled by its 
   visual presence, as [[spell:316916]] causes the buff from it to last four 
   seconds longer.
2. Use [[spell:49998]] if your health is low or if you are above 
   75 Runic Power.
3. Use [[spell:50842]] if any nearby enemies do not have your
   [[spell:55078]] disease, if you have a [[spell:1265790]] proc, 
   or you are close to having 2 charges of 
   [[spell:50842]].
4. **等级 71–80：**If [[spell:439843]] is available, cast it on any 
   nearby enemy.
5. **等级 75–80：**Spend [[spell:441378]] charges by casting [[spell:195182]].
6. **等级 27–80：**Use [[spell:49028]] on cooldown.
7. Use [[spell:195182]] 
   (or [[spell:195292]] if you are out of melee range) if
   your [[spell:195181]] is about to expire.
8. Use [[spell:195182]] if you have 6 or fewer stacks of
   [[spell:195181]].
9. Use [[spell:206930]] if you have 2 or more Runes.
10. Use [[spell:50842]].

2.2.1.

##### Apex Talent: ![Dance of Midnight Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_bladedance.jpg>) Dance of Midnight

Blood's Apex Talents provide a proc reducing the cost of [[spell:206930]] and 
amplifying its damage significantly after you parry an attack when 
[[spell:49028]] is active, and a 10% chance whenever you spend a rune to 
spawn a [[spell:49028]].

As a general note, Blood's Apex Talents are almost completely passive. The only 
real priority change from them is to consume [[spell:1264506]] procs as 
soon as they come up in AoE, as the internal cooldown on it is short enough that 
it is possible to overwrite procs.

Since ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer is the default choice for this page, most of 
the intricacies regarding whether you currently have a hard-casted [[spell:49028]] 
active is less relevant, which also boils this entire set of four talents down to 
"press [[spell:206930]] when it glows".

2.2.2.

##### Season 2 Tier Set

The Season 2 Tier Set, **Baleful Grave-Knight's Lament**, modifies your rotation 
very slightly. When you reach 10 stacks of [[spell:1310372]], you should aim to consume them by 
casting [[spell:195182]]. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn, you specifically want to do this **before**
[[spell:49028]] if at all possible.

### Blood Death Knight   Defensive Spells

2.3.

#### Active Mitigation and Cooldowns for Blood Death Knight

You have two active mitigation abilities that you need to use to keep yourself
alive, although simply making use of the above priority will ensure you are
doing this to a great degree.

[[spell:49998]] is your primary means of keeping yourself alive, and
you should use it whenever you can benefit from the healing it provides,
particularly after you have sustained high damage (since its healing is based
on the amount of damage taken in the preceding 5 seconds).

[[spell:195181]] (applied by your [[spell:195182]]) should be
kept above 5 stacks at all times.

In addition to the active mitigation abilities, you must also use your
defensive cooldowns as necessary:

- [[spell:48707]] absorbs up to 30% of your maximum health in magic
  damage over 5 seconds, and should be used to mitigate magic damage and generate
  Runic Power.
- [[spell:55233]] increases your maximum health and the amount of
  healing you receive by 30% for 10 seconds. It should be used either proactively
  in anticipation of high amounts of damage or reactively when low on health
  and in danger of dying.
- [[spell:48792]] reduces all damage taken by 30% for 8
  seconds. It should mostly be used proactively when you anticipate taking
  high damage, such as from specific boss abilities.
- [[spell:49039]] provides a decent amount of leech for 10 seconds on use. While it is 
  nowhere near as impactful as in prior expansions, it is off the global cooldown and costs 
  no resources — send it as close to on cooldown as possible.
- [[spell:49028]] increases your Parry chance by 20% and also
  increases your damage dealt and resource generation significantly. You should
  use it on the pull, and then generally as soon as it is available, as it doubles
  up as a resource-generation cooldown and also provides 5 [[spell:195181]]
  charges

To get a better understanding of how the abilities mentioned above,
as well as many more, work, you can look into our Spells Summary guide.

### Blood Death Knight   Stat Priority

2.4.

#### Stat Priority for Blood Death Knight

Other than trinkets and jewelry, prioritize item level over second stat
itemization. Prioritize stats as follows if you are using ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>).

Strength

Critical Strike

Mastery

Versatility

Haste

There are situations where this generic gearing advice falls short. This 
will only occur in encounters with mechanics that can be reduced 
through other means, such as by equipping items with **Avoidance** on 
them.

### Blizzard   Combat Assistant

2.5.

#### Combat Assistant Viability for Blood Death Knight

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) one-button rotation mode is a downgrade, but not 
enough to warrant avoiding its use anymore.

While the changes made to it for Midnight are <em>slightly</em> better than its historic 
counterpart, and the dominance of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer helps a bit further, it is still 
woefully behind offensively and defensively.

This new version also casts <em>some</em> cooldowns — it attempts to cast 
[[spell:49028]] as one of its highest priority items, along with 
[[spell:439843]], but reverses their priority.

Nevertheless, it is viable, and does do <em>some</em> things right: it reactively 
casts [[spell:49998]] while in danger, which is a welcome sight. As such, while 
we cannot recommend it for veteran players, we can now at least recommend it 
while levelling.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Adding a tiny tier set disclaimer.
- **26 Feb. 2026:** Adding apex talents and their impact.
- **10 Feb. 2026:** Prepared for Midnight pre-patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Sep. 2025:** Adjusted to assume the deathbringer 2-piece is available.
- **04 Aug. 2025:** Updated for 11.2, removed Limb, and prefaced that this page assumed no tier set.
- **15 Jun. 2025:** Added combat assistant mode info and estimated performance losses from it.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Prepared for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for the War Within Launch. New Talents added and rotation updates.
- **24 Jul. 2024:** Correcting talent hashes.
- **23 Jul. 2024:** Prepared for pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Patch 10.2.6.
- **18 Mar. 2024:** Syncing up with stats page. Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Minor clarity changes.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Refined talents and rotation spell descriptions.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Blood Death Knight in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Blood Death Knight

Season 2 of Midnight brings a small shake-up for Blood DK. On single-target and due to a 
bug affecting [[spell:1265855]], currently, both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer and 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn are close together. The moment a second target enters the 
encounter for a longer period of time than the time it takes for 
[[spell:439843]] to detonate, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn starts to dominate. Defensively, a buff to 
[[spell:434033]] has also reduced the gap between the two hero talents.

- **Single Target —** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn and 
  	![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer both shine in their respective 
  	ways. This is likely to change, but for now, depending on 
  	your gear and encounter, either may win out.
- **AoE —** If the AoE is sustained, or 
  	centered around the 1:30 interval mark in a fight,
  	![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn shines. If the AoE is intermittent, 
  	the timing of it will matter: is it roughly when 
  	[[spell:439843]] is available? If so, 
  	![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer can potentially close the gap.
- **Mythic+ —** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn does **absurd** 
  	damage, as you are the tank and can optimize your route and pull-patterns around 
  	your 1:30 [[spell:434152]] window.

We broadly recommend ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn as a sensible default 
this tier, as there are very few true single-target 
fights. As the raid launches, we will fine-tune recommendations and provide 
additional cooldown plans and recommendations on a fight by fight basis.

For Mythic+, the choice becomes more tenuous: ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn has a 
distinct offensive advantage, and while the pull-setup pressure has been reduced 
thanks to the new tier set, it still exists. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer is still 
simpler but falls behind in AoE and on priority target damage.

**Quick Start Import Codes**:

:::talents Blood Single Target - San'layn
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMDAMzMzAAAYgBmxiGLLAWGwGgZMDAAYmBwA"
}
```
:::

:::talents Blood Mythic+ - San'layn
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmxMGAAAAwMmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::talents Blood Delves - Deathbringer
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmZmxAAAAAmxMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

San'layn

Raid

Recommended

√

Mythic+

weekly-keys

high-keys

Deathbringer

Entry-Level Build

Beginner-friendly

Raid Build

Mythic+/Delve Build

weekly-keys

high-keys

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Raid Build

There are two flex points on the spec tree: [[spell:458753]] and [[spell:1264235]]. As
[Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) has a majority of encounters that are <em>not</em> single-target, we opted for this talent set
as the sensible default. If needed, you can move [[spell:458753]] to [[spell:274156]], or [[spell:1264235]]
to [[spell:195679]] for pure single-target.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Mythic+ Build

Our Mythic+ build picks up [[spell:391517]] and [[spell:1264235]] while
putting the remaining flex point into [[spell:458753]].

The point in [[spell:391517]] is put in purely for convenience and can be put
into [[spell:1263781]] for an additional ~400% AP damage per target at time of burst.
This occurs mid-way through [[spell:49028]], so the value of the healing it provides
is relatively low.

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Beginner-Friendly Build

The entry-level talent build we have opted for is a simplified version of
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer that eschews all of the active abilities it can avoid.

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Raid Build

This build is a sensible raid default for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer.

### 天赋方案 1-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Delve and Mythic+ Build

Fundamentally, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer suffers a core issue: while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn is
able to fully capitalize due to its kit amplifying [[spell:49998]] and [[spell:206930]],
[[spell:55078]] was left untouched for all of beta, along with [[spell:441378]]'s
AoE damage component. To top it all off, [[spell:434260]] is currently dealing way more
damage than it should due to an unintended bug.

It is not all doom and gloom, however; while the AoE damage difference is <em>very</em> significant,
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn once again provides significantly more priority damage, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer
retains its ease of use.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::details 来源计算器编码
```
#6D-TVVXYZ+CMMeko2CFVBEWYgERWko015diigA-efgHHZdiQRUVXbEKLPDAEaCJLNSYcQA-AAAA-JgIhCTDQgwgxhF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmxMGAAAAwMmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::details 来源计算器编码
```
#6D-TVVXYZ+CMMeko2CFVBEWYgERWko015diigA-efgHHZdiQRUVXbEKLPDAEaCJLDMSYcA-AAAA-JgIhCTDQgwgxhF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAIyKTQCZcEMI3aA-AAAA-GQAUIOCM2wsIsA-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmZmxAAAAAmxMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAIyKTCZcEMI3aCA-AAAA-GQAUIOCM2wsIsA-
```

:::

### 天赋方案 0-1

If you want to have even more defensive value, swap [[spell:317610]] to [[spell:206974]]
and [[spell:458753]] to [[spell:317133]].

:::talents Blood - Defensive San'layn
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmxMGAAAAwMmZmZmZ8AzYAAzMzMzAAAYgBmxiGLLAWGwGgZYAAAzMwwA"
}
```
:::

### 天赋方案 1-1

There are two flex points on the spec tree: [[spell:458753]] and [[spell:1264235]]. As
[Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) has a majority of encounters that are <em>not</em> single-target, we opted for this talent set
as the default. If needed, you can move [[spell:458753]] to [[spell:274156]], or [[spell:1264235]]
to [[spell:195679]] for pure single-target.

### 天赋方案 1-2

For this specific build, we have already moved [[spell:1263781]] to [[spell:391517]].
You are already taking a throughput hit - why not default to putting a minor pad point into something
that provides more value than as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn?

If you want to have even more defensive value, swap [[spell:317610]] to [[spell:206974]]
and [[spell:458753]] to [[spell:317133]].

:::talents Blood - Defensive Deathbringer
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwMzyMzwMmZmhZZmZmmZxYmZmxAAAAAmxMzMzMjHYGDAYmZmZGAAgxsNwAWAbDTghFAzwAAwMDAMA"
}
```
:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio was introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>). This system 
grants you a total of five additional powers designed around providing a mix of direct 
damage, utility and raw stats.

Our recommendation would be the below options for most content in game. You can freely 
swap between the options on each row for specific pieces of content. For example the fourth node row may 
change based on your specific gear situation at the time:

- Node 1:[[spell:1279599]]
- Node 2:[[spell:1279603]]
- Node 3:[[spell:1287555]]
- Node 4:[[spell:1279609]]
- Node 5:[[spell:1279614]]

3.

### Apex Talent: ![Dance of Midnight Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_bladedance.jpg>) Dance of Midnight

Blood's Apex Talents combine a thematic concept with two additional procs by 
granting you the ability to (randomly) spawn additional [[spell:49028]]s. 
This happens naturally while spending Runes.

Thematically, it is neat; in practice, it has led to [[spell:49028]] 
getting nerfed to accommodate this increased uptime, and has glaring problems 
in terms of user experience, in that these [[spell:49028]] copies do not 
trigger actual [[spell:49028]] talents and do not interact 
with them in any way.

Still, you can expect a 50% combined uptime on at least one [[spell:49028]], 
and the initial apex talent node - [[spell:1264506]] - causes you 
to occasionally amp up your next [[spell:206930]].

4.

### Hero Talents

Starting at level 71, Hero Talents let Blood Death Knights shape and focus their 
gameplay by picking one of two mutually exclusive options. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer 
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn both add a completely new mechanic to the specialization, but they 
do so in a radically different way.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn's design revolves around a maintenance buff — 
[[spell:433925]]. This significantly amplifies your Haste, Mastery and 
[[spell:49998]] damage, and can only be stacked by casting [[spell:433901]] — 
a rare proc off of [[spell:49998]].

When you **cast** [[spell:49028]], [[spell:433901]] is continuously 
available for its entire duration, and all benefits from [[spell:433925]] are 
tripled.

The core gameplay loop operates in two phases: an extreme power window every 90 seconds during 
[[spell:49028]], and a period where you game procs to maintain your stacks of 
[[spell:433925]] between them. It is punishing rotationally, but the payoff is 
significant.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer adds a brand new ability: [[spell:439843]]. This deals 
a small amount of upfront damage and tallies up every subsequent <em>instance</em> of 
shadow damage on the target; when it is done ramping (or expires), the mark detonates, 
dealing an extreme amount of damage to the target.

The most visible and memorable feature of this Hero Talent is its capstone, 
[[spell:441378]]. A very flashy, very effective addition to [[spell:195182]], 
this proc causes it to deal a very large amount of bonus damage and reduces its cost.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer is about simplicity — it trivializes the entire 
[[spell:195181]] management chore, and allows you reap a lot of benefits along 
the way.

5.

### PvP Talents (War Mode)

While leveling, players have the option to go into "War Mode".
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP, and
the possibility of being "ganked" while leveling or doing World Quests exists.

Below, we will rank the PvP talents best used for leveling and doing solo or 
small group PvE content.

1. [[spell:203173]] is a nice damage increase when pulling 3 or more
   enemies, though the 30-second cooldown prevents it from being used on every
   pull.
2. [[spell:199642]] and [[spell:207018]] can be very strong
   when completing open-world content in a group but have very limited value in
   solo play.

[[spell:77606]],
[[spell:199720]], [[spell:47476]],
and [[spell:202731]] all have limited value in PvE content.

[[spell:233412]] drastically reduces the duration and cooldown of 
[[spell:49028]]. When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn in open world content, 
it can help with maintaining [[spell:433925]], but we generally recommend 
avoiding this talent.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated all the builds for Patch 12.1.
- **19 Jun. 2026:** Omnium changes.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Prepared the builds for 12.0.5 and the change on Desecrate.
- **16 Mar. 2026:** PvP talent and Consumption changes.
- **04 Mar. 2026:** Clarified Carnage.
- **26 Feb. 2026:** Added Apex info.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **01 Sep. 2025:** Clarified a few entries.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **25 Jun. 2025:** Reviewed for Patch 11.2; removed all limb references and adjusted talent buids.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Added all the san'layn builds and cleaned up the page for 11.0.5
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **27 Aug. 2024:** Added description for M+ talents to also be used for Delves.
- **21 Aug. 2024:** Updated for The War Within Launch. Hero Talents added. Builds updated.
- **24 Jul. 2024:** Correcting talent hashes.
- **23 Jul. 2024:** Prepared for War Within. New talents added, builds changed.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Swapped build orders to suggest Soul Reaper as default in raid.
- **04 Sep. 2023:** New template for 10.1.7. Also added SR build.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Clarified talents.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Blood Death Knight, depending on the type of damage you will be tanking.
We also have advanced sections about cooldowns, procs, etc. in order to maximize your
survivability and DPS. All our content is updated for World of Warcraft Patch
12.1.5.

1.

### Blood Death Knight Gameplay and Rotation Guide

Generally speaking, your goal during each fight is to use your resources
(Runes and Runic Power) to generate threat and to stay alive. Blood Death
Knight is very much a builder-spender spec, with a limited number of procs and
interactions and a number of ways in which you can get punished for losing
your cool and deciding to use the wrong ability.

:::details FAQShould I Play Defensively or Offensively?
This is the main question most people will ask with tanking. The basic answer is
that, outside of cooldown usage, most of your toolkit does not have defense vs.
offense trade-offs. Whether you play offensively or defensively, you will still
maintain [[spell:195181]] at 5+ stacks, you will still spend both Runes and
Runic Power optimally, and you will still make sure not to cap [[spell:50842]]
charges.

The major difference lies in cooldown usage. In
practice, we recommend people to go into a new encounter making sure to plan their
cooldowns in order to <em>not die</em>. This can be easily done by checking logs of
other players having progressed a fight (or just going blindly in by yourself!),
and mapping out what cooldowns you will use for which mechanic.

The most common changes if more situational defensiveness is necessary are
listed below:

1. If your cooldown plan still necessitates more than you currently have, evaluate
     whether you can allocate a group external cooldown to it (something like
     [[spell:6940]] from a paladin). If you cannot, or if things hit
     too frequently or too hard for your current kit, you can consider a defensive
     trinket to fill a gap in you cooldown plan, or an external from a party member.
     Don't forget [[spell:51052]] - most Blood Death Knights tend to forget that
     it is technically a 15% damage reduction effect against magic damage for you, not
     just for your group!
2. If you still fall short, trinkets can come in handy, particularly on-use absorbs such as
     [[item:252421@JAAEAAgsSYgM]]. You should be on the lookout for trinkets whose
     effects are directly useful for your case, and fill what remaining gap.
3. Still falling short due to EHP? You can <em>very situationally</em> change the outcome of
     some encounter plans by changing your jewelry items (Rings, Neck) for versatility-heavy
     alternatives. **This is a last resort**, and when you do so, dropping item level on these
     swaps nullifies all of the gains.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer

Single Target

AoE/M+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn

Single Target

AoE/M+

Active Talents

Passive Talents

[[spell:1263824]]

[[spell:469870]]

[[spell:436687]]

### Opener

[[spell:43265]]

[[spell:195292]]

[[spell:195181]]

[[spell:55078]]

**适用条件：Deathbringer（启用）。**

[[spell:439843]]

[[spell:46585]]

**适用条件：Deathbringer（启用）。**

[[spell:49028]]

**适用条件：San'layn（启用）。**

[[spell:49028]]

[[spell:46585]]

**适用条件：Deathbringer（启用）。**

[[spell:50842]]

[[spell:55078]]

**适用条件：San'layn（启用）。**

[[spell:50842]]

[[spell:55078]]

**适用条件：Deathbringer（启用）。**

[[spell:195182]]

[[spell:441378]]

1.1.

#### Opener

1. Pre-place [[spell:43265]] where you expect to be fighting. **Do not target an enemy when doing this** (if [[spell:1264351]] procs, it will automatically spawn and aggro your current target)
2. Just before pull, cast [[spell:195292]] at your target. This grants you two [[spell:195181]] charges and immediately applies [[spell:55078]].
3. **适用条件：Deathbringer（启用）。** Cast [[spell:439843]] and [[spell:46585]]. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer, you can macro these together.
4. **适用条件：Deathbringer（启用）。** Cast [[spell:49028]].
5. **适用条件：San'layn（启用）。** Cast [[spell:49028]] and [[spell:46585]].
6. **适用条件：Deathbringer（启用）。** Cast [[spell:50842]] to pandemic [[spell:55078]] and apply the two copies from your Rune Weapons.
7. **适用条件：San'layn（启用）。** Cast [[spell:50842]] to pandemic [[spell:55078]] and apply the two copies from your Rune Weapons. These do not interact with [[spell:434143]].
8. **适用条件：Deathbringer（启用）。** Cast [[spell:195182]] to consume the [[spell:441378]] charge [[spell:49028]] gave you.
9. **适用条件：Deathbringer（启用）。** Continue casting [[spell:49998]], [[spell:50842]] and [[spell:206930]] until [[spell:49028]] fades.
10. **适用条件：San'layn（启用）。** Continue with the following priority until [[spell:434152]] fades:
    
    
    - [[spell:49998]] if you need to heal or you are above 75 RP
    - [[spell:50842]] **if and only if** you will hit 7+ targets with it and you have a [[spell:1265790]]proc
    - [[spell:433901]] otherwise

### Rotation

**适用条件：San'layn（启用）；Deathbringer（未启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn places a very strict emphasis on your [[spell:49028]] window – both when it is about to come off cooldown, and while it is active. We opted to split the rotation into two distinct priorities to delineate and clarify the difference.

**适用条件：San'layn（启用）；Deathbringer（未启用）。** 1.2.

#### **适用条件：San'layn（启用）；Deathbringer（未启用）。** During Gift of the San'layn

**适用条件：San'layn（启用）；Deathbringer（未启用）。** [[spell:434152]] massively amplifies [[spell:49998]] and grants permanent access to [[spell:433901]]. As a result, unless you can game a large amount of free bonus damage on [[spell:49998]] from [[spell:273946]] in AoE, or a 12% strength buff from [[spell:434157]], your goal is to cast <em>nothing</em> but a single [[spell:50842]] and then chain [[spell:433901]] and [[spell:49998]] until [[spell:434152]] runs out.

1. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:49998]] if you are about to die, you have more than 70 Runic Power, or [[spell:391477]] is about to fade.
2. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:50842]] **once** in [[spell:49028]] to apply the plague copies if they are not currently on your target, and to pandemic [[spell:55078]] to its highest possible value before extending it with [[spell:433901]].
3. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:50842]] in AoE (5 or more targets) to keep its charges rolling.
4. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:43265]] if you have a [[spell:81136]] proc and [[spell:434157]] is not currently active.
5. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Maintain yourself at 1+ [[spell:266201]] charges. If you planned for [[spell:49028]] properly, this should be automatic; if you made a mistake, use [[spell:195182]].
6. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Use [[spell:433901]] as your filler to consume runes.

**适用条件：San'layn（启用）；Deathbringer（未启用）。** 1.3.

#### **适用条件：San'layn（启用）；Deathbringer（未启用）。** Outside Gift of the San'layn

**适用条件：San'layn（启用）；Deathbringer（未启用）。** The rules are a lot more lenient outside [[spell:434152]]. You simply maintain the buffs innate to Blood, keep [[spell:433925]] rolling and prepare for your next [[spell:49028]].

1. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:49998]] if you are about to die, you have more than 70 Runic Power, or [[spell:391477]] is about to fade.
2. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:49028]] on cooldown.
3. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:43265]] if you have a [[spell:81136]] proc, or you are fighting 4+ targets and [[spell:43265]]'s buff is not currently active.
4. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:433901]] if it is available.
5. **适用条件：San'layn（启用）；Consumption（启用）；Deathbringer（未启用）。** Empower [[spell:274156]] to rank 1, unless [[spell:55078]]'s remaining duration is > 40s and you do not have a [[spell:1264351]] proc currently active.
6. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:50842]] if you have a [[spell:1265790]] proc.
7. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Use [[spell:49576]] or [[spell:195292]] if [[spell:195181]] is about to expire, or if you will not be in range of a target before you get back in melee range of an enemy.
8. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:195182]] strategically:
   
   
   - Use it while at 5+ or fewer [[spell:195181]] charges and when an apex [[spell:49028]] proc is active
   - If you cannot wait for an apex proc, use it either way.
   
   
   You should aim to game bonus [[spell:195181]] charges from [[spell:1264351]] procs as much as possible without overcapping any.
9. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Cast [[spell:50842]] to keep its charges rolling.
10. **适用条件：San'layn（启用）；Deathbringer（未启用）。** Use [[spell:206930]] as a filler to consume runes. You should aim to have three recharging at all times.

**适用条件：Deathbringer（启用）；San'layn（未启用）。** 1.4.

#### **适用条件：Deathbringer（启用）；San'layn（未启用）。** Rotation

**适用条件：Deathbringer（启用）；San'layn（未启用）。** Every 90 seconds, [[spell:439843]] and [[spell:49028]] align. Both the opener we provided and this rotation priority assumes that you cast them in the correct sequence ([[spell:439843]] first, then [[spell:49028]]) in order not to waste duplicated casts.  
Outside of that, the rotation is a very simple priority - spend the procs, maintain the buffs, profit.

1. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:49998]] if you are about to die, you have more than 70 Runic Power, or [[spell:391477]] is about to fade.
2. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:195182]] if you have an [[spell:441378]] proc available and it is about to expire (< 3s).
3. **适用条件：Deathbringer（启用）；Consumption（启用）；San'layn（未启用）。** Empower [[spell:1263824]] to rank 1 on cooldown when [[spell:49028]] is not up.
4. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:439843]] on cooldown.
5. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:49028]] on cooldown.
6. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:195182]] on single target if you have an [[spell:441378]] proc available and [[spell:49028]] is not up.
   Exterminate rules
   
   
   [[spell:441378]]'s scythes are not copied by [[spell:49028]] and they do not cause [[spell:55078]] to be applied by them either. In practice, this means that using them in [[spell:49028]] when you are **not** going to overcap them boils down to a difficult balance between the upfront damage of [[spell:206930]] vs. [[spell:195182]] and the number of [[spell:1264405]] stacks, since they will buff the upfront scythe hits.
   
   
   
   
   A simple ruleset is as follows:
   
   
   
   
   - On single target, use [[spell:441378]] charges freely in or out of [[spell:49028]] but treat them as a low-priority filler similar to [[spell:50842]].
   - In AoE, use [[spell:441378]] strictly outside of [[spell:49028]] where possible
7. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:195182]] in AoE if you have an [[spell:441378]] proc available.
   Exterminate rules
   
   
   [[spell:441378]]'s scythes are not copied by [[spell:49028]] and they do not cause [[spell:55078]] to be applied by them either. In practice, this means that using them in [[spell:49028]] when you are **not** going to overcap them boils down to a difficult balance between the upfront damage of [[spell:206930]] vs. [[spell:195182]] and the number of [[spell:1264405]] stacks, since they will buff the upfront scythe hits.
   
   
   
   
   A simple ruleset is as follows:
   
   
   
   
   - On single target, use [[spell:441378]] charges freely in or out of [[spell:49028]] but treat them as a low-priority filler similar to [[spell:50842]].
   - In AoE, use [[spell:441378]] strictly outside of [[spell:49028]] where possible
8. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:50842]] if you have a [[spell:1265790]] proc.
9. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Use [[spell:49576]] or [[spell:195292]] if [[spell:195181]] is about to expire, or if you will not be in range of a target before you get back in melee range of an enemy.
10. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:43265]] if the buff it provides is not currently up.
11. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Cast [[spell:50842]] to keep its charges from capping.
12. **适用条件：Deathbringer（启用）；San'layn（未启用）。** Use [[spell:206930]] as your filler to consume Runes. You should have three recharging at all times.

1.5.

#### Preparing for Reaper's Mark

If you follow the rotation priority outlined above, with <em>one small detail</em>, you should be able to effortlessly detonate [[spell:439843]] at maximum stacks. Counterintuitively enough, the biggest source of guaranteed stacks is [[spell:43265]], and you should aim to pre-cast [[spell:43265]] before [[spell:439843]] if it is not already ticking under your target.

2.

### Midnight Season 2 Tier Set

Blood's Season 2 tier set, **Baleful Grave-Knight's Lament**, adds two strength stacking 
buffs, and a player-driven effect to convert the first - all while dealing a large amount of 
upfront AoE damage in the process.

The 2-piece bonus, [[spell:1296650]], grants you a stacking Strength 
buff whenever you [[spell:49998]]. This stacks up to 10, and grants 0.5% total bonus Strength 
per stack. These stacks persist indefinitely. When you reach 10 stacks, your next [[spell:195182]]
consumes all of them to grant you 10% Strength for 10 seconds; you can still acquire the regular 
[[spell:49998]]-driven stacks while this empowered effect is active.

The 4-piece bonus, [[spell:1296651]], sweetens the deal when converting 
between [[spell:1310372]] stacks by causing the [[spell:195182]] that consumed them to grant three 
extra [[spell:195181]] charges and dealing a very large amount of AoE damage to all enemies near your target.

3.

### Class and Spec Mechanics Explained

Blood Death Knight has very few skill optimizations left in 
its gameplay, mostly thanks to the removal of additional mechanics 
centered on cooldown reduction and additional burst damage. That said, 
a number of additional gameplay mechanics are worth knowing about as a 
tank. We have detailed them below.

### Threat

3.1.

#### Threat

One of your biggest duties as a tank consists of holding 
aggro and generating threat against other DPS, and your 
co-tank if there is one.

3.1.1.

##### How Threat Tables Works

The moment you enter combat with an enemy, you are placed on 
their **threat table**. This is unique to each enemy, and 
it tallies up the amount of threat each player has generated 
throughout combat. This does not decay, and entries are only 
removed on death; they can be masked by immunities such as 
[[spell:1022]], but this is an edge case.

If combat has just started, the first person on the threat 
table will have initial aggro. From there, it takes a **10%** 
gap for an enemy to swap targets to somebody within 8 yards, and 
**30%** if at range. This means that if you have 100 
"threat units", the second highest threat entry must get to 110 
to overtake you.

3.1.2.

##### Threat Is Damage

Fundamentally, generating threat means dealing damage, and 
each enemy tallies this individually depending on what hit them. This means 
that overall damage is mostly an irrelevant metric in AoE, particularly if 
a specialization has a target-capped spell (for us, [[spell:206930]] is 
the best example, and it is why playing Mythic+ as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn frequently 
involves using [[spell:50842]] even if [[spell:49028]] is active).

All tanks have a +950% threat multiplier on their spec aura.

:::details TCWhat About Healing?
<em>Some</em> healing is tallied. The rules are fast and loose, but
generally, self-healing with the exception of healing potions is not tallied.

If a heal is tallied, it adds an even amount of threat equal to the value of
the heal, split evenly across every enemy you are in combat with. In other words,
if you use a healing potion and heal for 100 HP when fighting 10 enemies, each
enemy would get 10 healing's worth of threat.

:::

Blood Death Knight also possesses no abilities with a unique threat bonus 
of any sort. This means that, outside of taunt windows, for us, 
<em>threat is damage</em>.

3.1.3.

##### Taunting

Taunting does three things:

- It fixates the enemy on you for **6 seconds**, affected by diminishing 
    returns. While the debuff is on a target, it <em>cannot</em> swap target, and you 
    mask the #1 person on their threat table. The moment the debuff fades, the rules 
    go back to normal.
- It puts you at the **exact same value** as the #1 entity on the threat 
    table of the enemy. If this was you, it evidently does nothing.
- It increases your threat generation by **800%** on this target while 
    the debuff is on target. Increasing numbers of taunt on a target do not stack this 
    up, and instead reduce the duration of each subsequent taunt by 35%, up to a minimum 
    of 1.1 second.

[[spell:49576]] also functions as a taunt, and has the additional perk of forcefully 
relocating your target (if they can be relocated). This soft-interrupts a number of spells, 
but rarely works against bosses.

### Death Strike and Blood Shield

3.2.

#### Death Strike and Blood Shield

[[spell:49998]] is your most important self-healing ability. It is
also part of your regular ability rotation during combat. Tomake the
most out of Death Strike and your Mastery ([[spell:77513]]),
you cannot simply use Death Strike whenever it is available.

The most immediately apparent effect of Death Strike is that it heals you,
so it is always well used after you have taken damage to heal yourself back
up a bit and help the healers. Be smart about when you are using Death Strike.
As it depends on your damage taken in the previous 5 seconds, it should be
used after taking high damage. Of course, capping your Runic Power while not
using Death Strike should also be avoided.

Note that [[spell:77513]] only absorbs physical damage; do not
rely on it to mitigate a large magical attack.

### Bone Shield

3.3.

#### Bone Shield

Your [[spell:195182]] ability applies 3 stacks of [[spell:195181]],
and your [[spell:195292]] ability applies 2 stacks of [[spell:195181]]
each time you use it, up to a maximum of 10 stacks. 
As long as you have at least 1 Bone Shield stack active, your Armor is increased by a percentage of your
Strength and with the [[spell:374715]] talent, your Haste is
also increased by 10%. Each successful melee attack made
against you consumes a Bone Shield charge. Bone Shield has a duration of 30
seconds, after which the stacks simply drop off you. This is unlikely to occur
while actively tanking in a normal boss encounter, but you should take care to
watch the duration of your [[spell:195181]] buff on encounters with no
melee attacks or with long periods of downtime.

There is an internal cooldown of 2.5 seconds for Bone Shield charges being
consumed.

Keeping Bone Shield up is pivotal to playing Blood properly. The Haste
increase is essential for Rune regeneration, and the damage reduction is
essential for survivability. Moreover, if you have the [[spell:219786]] talent,
then with five or more stacks of Bone Shield, the cost
of [[spell:49998]] is reduced by 5 Runic Power, which allows you to use
it more frequently.

Effectively, you will always want to prioritize maintaining high amounts of
[[spell:195181]] stacks smartly; you should use [[spell:195182]] when you
have seven or fewer stacks of Bone Shield (unless you need the additional Runic
Power from
using [[spell:206930]]). One of the pillars of optimization of Blood consists in 
managing to spend as few runes as possible on Bone Shield management.

### Runes and Runic Power

3.4.

#### Runes and Runic Power

Death Knights use a dual resource system of runes and Runic Power. While it
is quite straightforward in how it works, we will explain it here for the
sake of completion.

3.4.1.

##### Runes

You have a total of 6 Runes, which are available by default. Some of your
abilities have Rune costs, and whenever you use an ability that consumes one
or more Runes, those Runes will immediately begin recharging. The exact amount
of time it takes a Rune to recharge depends on how much Haste you have.

Whenever a Rune is consumed, you gain 10 Runic Power (more on that
below).

At most, 3 of your runes can be charging up at the same time. It is
therefore optimal to keep at least 3 runes on cooldown to maximise
the recharge rate over the course of the fight.

3.4.2.

##### Runic Power

Runic Power is a resource that resembles Rage, in the sense that it
decays when out of combat, but does not decay during combat. As mentioned
above, consuming Runes generates 10 Runic Power per Rune spent, and this is
the primary means of generating Runic Power, although some abilities also
help with this. You can have a maximum of 125 Runic Power, increased to 145 if
using the [[spell:326911]] Runeforge.

4.

### Important Cooldowns for Blood Death Knight

### [[spell:49028]]

4.1.

#### Dancing Rune Weapon

[[spell:49028]] grants you a 20% chance to parry for 12 seconds 
with [[spell:377668]] selected.
Moreover, for the duration, there are several other benefits that you gain:

- Uses of [[spell:206930]] will cause your rune weapon to strike and
  grant 3 additional Runic Power.
- Uses of [[spell:195182]] will cause your rune weapon to stack
  [[spell:195181]] exactly like using your own Marrowrend, making Marrowrend
  during Dancing Rune Weapon yield 6 bonus [[spell:195181]] charges. Avoid using
  [[spell:195182]] during [[spell:49028]] too much, since using it 
  effectively brings you to maximum stacks.
- Using [[spell:50842]] will leave an additional [[spell:55078]]
  debuff on your target per active Rune Weapon. Your rune weapon's Blood Plague 
  debuff is not attributed directly to you and does not heal you, and persists 
  after the weapon despawns.

Your rune weapon's attacks deal approximately 33% of the damage you deal,
making [[spell:49028]] a potent DPS cooldown. On encounters with
burn phases where the boss takes additional damage, you should make sure you
have [[spell:49028]] to line up with those phases, along with a
potion of some sort. Do not, however, sit on this cooldown for too long.

Avoid holding [[spell:49028]] on cooldown for longer than 15
seconds in a misguided attempt to benefit from its parry value defensively.
[[spell:49028]] is primarily a resource and throughput cooldown,
as it amplifies your Runic Power generation during it (by granting you
bonus [[spell:195181]] charges and roughly doubling the RP generated from
[[spell:206930]]). The parry part is the cherry on top, not the main
actor of the show.

### [[spell:48707]]

4.2.

#### Anti-Magic Shell

[[spell:48707]]'s most powerful effect is its ability to prevent
the application of debuffs. If a magical ability would apply a debuff and any
damage the ability causes is fully absorbed by [[spell:48707]], the
debuff is not applied.

Timing the use of [[spell:48707]] is critical, particularly when
you are taking magical damage from sources other than the ability you intend to
protect against. Heavy magic damage can easily eat through the shield before
the intended attack, leaving you vulnerable to the debuff.

Effects that increase your maximum health, to include [[spell:55233]],
will increase the value of your Anti-Magic Shell even after those abilities
fade.
Planning around this can make the difference in Anti-Magic Shell being
able to completely absorb an attack and, therefore, immune a debuff.

[[spell:205727]] can allow for more effective use of
[[spell:48707]] in nearly every way, with a reduced cooldown,
increased size, and increased duration.

### [[spell:55233]]

4.3.

#### Vampiric Blood

[[spell:55233]] is your most versatile cooldown. It grants you
30% extra health for 10 seconds and increases your healing received (from all
sources, including self-heals) by 30%. It can be used reactively; however, you
will gain more benefit from using this proactively, and you should have a
specific plan for what abilities you will mitigate with it.

It is worth noting that this increased healing can be used to game certain
abilities or mechanics. For instance, certain effects will be 30% larger even
after Vampiric Blood fades - such as [[spell:48707]] and
[[spell:219809]]'s shield.

One peculiarity of [[spell:55233]] is that it specifically has 
been flagged to not increase the cap on [[spell:77513]] while it 
is active.

### [[spell:48792]]

4.4.

#### Icebound Fortitude

[[spell:48792]] is a straightforward damage-reduction cooldown
that lasts for 8 seconds, reducing all damage taken by 30%. Generally, you
should use this when you are about to take high damage from pre-determined
boss abilities, or when you are otherwise vulnerable (because the healers
cannot reach you or because your other cooldowns are unavailable).

[[spell:48792]] also clears stuns and makes you immune to stun
effects for the duration of the buff. In encounters where stun effects are
applied to the tank, you should consider whether you can incorporate Icebound
Fortitude into your cooldown plan in a way that both mitigates threatening
damage while leveraging the stun immunity.

Blood Death Knights deal very poorly with abilities that take into account
raw damage amounts before absorbs and self-healing (given their low number of
damage reduction abilities). Abilities that mirror damage dealt to you onto
other players or otherwise determine their effect based on how much damage you
take can be particularly difficult for Blood Death Knights to manage;
[[spell:48792]] should be saved for those abilities in those
situations.

### [[spell:49039]]

4.5.

#### Lichborne

[[spell:49039]] is another tool in our
arsenal of situational defensives, granting 15% leech and total immunity to
Charm, Fear, and Sleep effects for 10 seconds. An additional benefit of it is
the ability to use [[spell:47541]] on yourself to give yourself a poor man's
AP-based healing should nothing else be in range and should you be in immediate,
lethal danger, be out of both health potions and healthstones and without any other 
hope to survive - in other words, never practically.

### [[spell:114556]]

4.6.

#### Purgatory

While it is not a cooldown per se, [[spell:114556]] deserves a mention 
as it has a few quirks related to it.

For starters, it is the only cheat death in the game that is <em>completely</em> 
uncapped. As long as you are able to heal out of it, you can survive it. The hard part, 
evidently, is healing yourself out of it.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Clarifying cooldowns.
- **26 Feb. 2026:** Changes for the Midnight pre-raid launch.
- **10 Feb. 2026:** First pass at Midnight pre-patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **01 Sep. 2025:** Clarified toggles.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Adding combat assistant section and listing the biggest problems with it.
- **19 May 2025:** Simplifying the San'layn opener slightly.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Clarified second opener, primed for 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Re-worked the entirety of the san'layn opener and rotation, clarified all of it, added the DB soul reaper and clarified the rest of the page.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch with additions for Hero Talents.
- **23 Jul. 2024:** Prepared for TWW, including rotational changes affecting pre-patch (no hero talents yet).
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Patch 10.2.6.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **03 Jan. 2024:** Overhauled, moved to checkboxes for everything and added how to use fyralath correctly.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **03 Jan. 2023:** Clearing up Marrowrend vs. Caress.
- **11 Dec. 2022:** Updated for Dragonflight Season 1 launch. Added a very small rotational change due to the Tier set.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Blood Death Knight in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Blood Death Knight

Welcome to our Blood Death Knight Gear Page for
Midnight Season 2. Check this page to learn everything
you need to know about gearing a Blood Death Knight, including the
BiS Gear from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier Sets, and
much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

The 12.1.5 update brings with it the release of [[item:280562]],
allowing you to upgrade Weapons, Trinkets and Neclaces two more times, to 
a maximum of item level 340. Additionally, the Unbinding of Kith'ix is 
available as a raid encounter, bringing with it some very powerful cantrip 
items.

### Overall

This list contains the Best in Slot Gear from any source for Midnight raids. It is there as a reference to what is currently the highest performing gear available to players.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). What is BiS right now may not be the same as the below as this would be an example of an end game setup, and serve as guidance of what items to target.

:::details FAQWhich Tier Set Pieces Do I Want?
If you raid, three of your four tier pieces will be locked: your chest and legs will come from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>), as they come with a 10 ilvl advantage on the competition and a cantrip effect on the legs. Your headpiece will be from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) due to its cantrip.

The last piece will be up to itemization; unlike prior seasons, Catalyzing a piece of gear causes it to retain its stats, making potentially any combination of tier pieces possible. One of the higher-performing combinations is as follows:

- **Helm**: [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Shoulders**: [[item:239037]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Chest**: [[item:268222]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Legs**: [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details FAQWhich Items Should I Prioritise?
[Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) features a number of items dropping at an increased item level or with very appealing cantrip effects. You will want to prioritise taking them from your Great Vault or spending Voidcores when you kill their respective bosses:

- [[item:268213]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): Cantrip weapon
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): Cantrip neck with a bonus socket and a very interesting cantrip effect.
- [[item:270173]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): The pair for the weapon, an increased item level trinket with an effect strong enough to justify being equipped on its own. The set just makes it better on 2+ targets.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS on-use trinket with a higher ilvl.
- [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): Cantrip legs with 10 bonus item levels.

:::

Four new embellishments were added in 12.1, but only one of them was testable. The other three have already seen heavy nerfs, but because we do not know their exact behavior, and the level of power they provide is roughly within what you would expect of an embellishment, take this list with a pinch of salt.

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271474@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAAEAAgsSYgM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAAGAAAG24VN2WD]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAAGAAgf1EYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271878@JAAIAAgsScBNMWDG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Feet</th><td>[[item:273777@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAAGAAge1IYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244017]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:240949]]&#10;&#10;<div>[[item:240906]][[item:251487]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAAEAAwTSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAQAAgtvwgN3WzmlYbNAMCx1glI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[spell:326805]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the best items available per slot from Mythic+. It is there to provide you with a quick list of easily farmable gear if you need something in a specific slot.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). What is BiS right now may not be the same as the below as this would be an example of an end game setup, and serve as guidance of what items to target.

:::details FAQWhich Tier Set Pieces Do I Want?
If you are strictly gearing through Mythic+, the following pieces are one of the strongest current combinations to achieve your 4-piece set bonus by using the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>):

- **Helm**: [[item:239050]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **Shoulders**: [[item:239037]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Chest**: [[item:239036]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Legs**: [[item:273776]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

We recommend getting the 4-piece set bonus as soon as possible. Unlocking it also makes it possible to randomly gain additional catalyst charges from all seasonal content. Don't wait for an ideal piece!

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): Drops a wide variety of loot, including three possible tier pieces, two decent rings, and [[item:158367]]. If you do not raid, this will likely be your go-to on-use trinket.
- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops a number of off-pieces and two valuable trinkets.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271474@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:251197@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Neck</th><td>[[item:251173@JAAEAAgsSYjM]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:159442@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271473@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:273777@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:159459@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:158367@JAAEAAgsSYjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Bracers</th><td>[[item:159409@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Trinket</th><td>[[item:250259@JAAEAAgsSYjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251181@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[spell:326805]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list serves as a "My raid leader needs me to provide a wishlist, here is the wishlist" item list. If you were to assemble the best gear set from Venomous Abyss specifically, and no other source, this is what you would wear.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). What is BiS right now may not be the same as the below as this would be an example of an end game setup, and serve as guidance of what items to target.

In practice, a large number of these items are locked in due to their cantrip effects or drastically increased item level. We recommend verifying that you <em>can</em> get these at 9/6 Myth (by getting them from the vault or bonus rolling these bosses), and planning accordingly.

:::details FAQWhich Tier Set Pieces Do I Want?
If you raid, at three pieces will be locked: your chest and legs will come from [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>), as they come with a 10 ilvl advantage on the competition and a cantrip effect on the legs. Your headpiece will be from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) due to its cantrip effect.

The last piece will be up to itemization; unlike prior seasons, Catalyzing a piece of gear causes it to retain its stats, making potentially any combination of tier pieces possible. One of the higher-performing combinations is as follows:

- **Helm**: [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) [[item:281239]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Shoulders**: Tier token from [The Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **Chest**: [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) [[item:268222]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **Gloves**: Tier token from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)

:::

:::details FAQWhich Items Should I Prioritise?
[Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) features a number of items dropping at an increased item level or with very appealing cantrip effects. You will want to prioritise taking them from your Great Vault or spending Voidcores when you kill their respective bosses:

- [[item:268213]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): Cantrip weapon
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): Cantrip neck with a bonus socket and a very interesting cantrip effect.
- [[item:270173]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>): The pair for the weapon, an increased item level trinket with an effect strong enough to justify being equipped on its own. The set just makes it better on 2+ targets.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS on-use trinket with a higher ilvl.
- [[item:271878]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): Cantrip legs with 10 bonus item levels.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271474@JAAIAAAf1IYN2WjNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271475@JAAEAAgsSYgM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAIAAAj1QWNYYjX1A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAAGAAAG24VN2WD]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271472@JAAGAAgf1EYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271878@JAAIAAgsScBNMWDG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Feet</th><td>[[item:268260@JAAEAAgsSYjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271477@JAAGAAge1IYN2ID]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268249@JAAGAAgt1IrE2ID]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik the Malignant</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAAEAAwTSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Bracers</th><td>[[item:268239@JAAEAAgsSYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">The Lost Explorers</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAAEAAgsSghN]]&#10;&#10;<a href="https://www.icy-veins.com/wow/blood-death-knight-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAAEAAgsSghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[spell:326805]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Best Trinkets for Blood Death Knight in Midnight Season 2

As a general rule of thumb, we recommend the following:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Blood Death Knight Trinkets**
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn: [[item:270175]] + [[item:270173]] (with [[item:268213]])/[[item:270164]] (without)/[[item:158367]] (AoE pad outside of CDs)
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer: [[item:270175]] + [[item:270173]] (with [[item:268213]])/[[item:270164]] (without)/[[item:158367]] (AoE pad outside of CDs)

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>)    Click for Blood Death Knight Trinket Rankings
<table>&#10;<thead>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Raid</th>&#10;<th>Mythic+</th>&#10;</tr>&#10;</thead>&#10;<tbody>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;[[item:270175]] - <span><em>Click for Details</em></span>&#10;<p>Drops at a 10 item level bonus <strong>and</strong> lines up perfectly with [[spell:439843]] and [[spell:434152]].</p>&#10;</li>&#10;<li>&#10;&#10;[[item:158367]] - <span><em>Click for Details</em></span>&#10;	  You can walk during the channel thanks to [[spell:343257]], making it a lot less dangerous to use than for other classes. Deals <i>very</i> competitive &#10;	  damage even on single-target, and its damage is not split at all.&#10;</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;[[item:270175]] - <span><em>Click for Details</em></span>&#10;<p>Drops at a 10 item level bonus <strong>and</strong> lines up perfectly with [[spell:439843]] and [[spell:434152]].</p>&#10;</li>&#10;<li>&#10;&#10;[[item:158367]] - <span><em>Click for Details</em></span>&#10;	  You can walk during the channel thanks to [[spell:343257]], making it a lot less dangerous to use than for other classes. Deals <i>very</i> competitive &#10;	  damage even on single-target, and its damage is not split at all.&#10;</li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:281215]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270163]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]] (when trained)</li>&#10;<li>[[item:250226@JAAGAAgsSYgMWVD]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]] (when trained)</li>&#10;<li>[[item:250226@JAAGAAgsSYgMWVD]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<i>Everything else</i>&#10;</td>&#10;<td>&#10;<i>Everything else</i>&#10;</td>&#10;</tr>&#10;</tbody>&#10;</table>

2.1.

#### Defensive Trinkets

You can theoretically justify a lot of direct absorb trinkets this season, depending on 
your need for a cooldown to fit your cooldown plan and fight profile Here are a few of the 
noteworthy ones.

- **90s**: [[item:270160]] (40% partial, 80% while below 40% HP)
- **60s**: [[item:159618]]

We strongly recommend treating these as **emergency solutions**, particularly 
[[item:159618]]. They should not be used by default.

:::

3.

### Nebulous Voidcores (Bonus Rolls)

Midnight's patch 12.1 formalizes [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>). These can now be 
acquired through the great vault and can be used to Bonus Roll a boss of your choice, and 
  the possible drops from it are visible before you commit to this choice. The item you 
  receive is random, but each item can only be acquired once from these bonus rolls. Subsequent 
  bonus rolls on the same target will yield one of the remaining items from the pool, until 
  none are available.

These Bonus Rolls are usable in Mythic+ and in raids, and yield items that have an item 
  level equivalent to receiving them from the great vault at the given difficulty.

3.1.

#### Recommended Nebulous Voidcore Usage for Blood Death Knight

Due to the number of extremely strong cantrips and items with increased item level from 
[Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>), we strongly recommend spending bonus rolls there. Mythic+ bonus rolls 
should be treated as a **last resort**, particularly as no item from Mythic+ is uniquely 
desirable this tier.

The following targets should be your priority on **Heroic** (for Myth 1/6 items) or **Mythic** 
(for Myth 9/6 items):

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for [[item:268213]], [[item:270173]], [[item:268259]] and [[item:268253]]
2. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:270175]], [[item:268265]], [[item:271878]]

:::

If you do not raid in a competitive Mythic raid team, we recommend bonus rolling the exact same bosses on Heroic.

3.2.

#### Ascendant Venomstones

Following the release of Patch 12.1.5, you can now acquire [[item:280562]],
allowing you to upgrade any Weapon, Necklace or Trinket to 340, and crafted items to 
338. We recommend upgrading your items in the following order:

1. **Weapon** first, particularly if you bonus rolled 
     [[item:268213]] from Heroic.
2. **Trinkets** second & third.
3. **Necklace** last.

You also want to prioritize Myth track items over Hero track pieces, unless you
don't expect to acquire a Myth track variant of the piece you're upgrading, and this is 
especially true if you acquired the cantrip items from Coiled Altar and Ula'tek by 
bonus rolling them on Heroic.

4.

### Best Crafted Items for Blood Death Knight

Midnight Season 2 brings four new embellishments, and even in the worst possible reading of the tooltips, 
they are wildly stronger than the previous set. Sadly, none of them were testable on PTR as the recipes 
dropped from content inaccessible on PTR, and there was no way to learn them in any other way.

As a result, you should take the following list with a **huge grain of salt**, and expect 
the embellishments to get nerfed the moment somebody acquires the recipe on live realms.

We recommend the following early crafting choices:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Blood Early Crafting Order**
**[[item:240949]]**

→

**[[item:237834@JAAQAAgtvwgN3WzmlYbNAMCx1glI]]**

→

**Optional Crafts**

:::

If you are not a Mythic **or** Heroic raider and have no other option to defeat 
[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for its cantrip weapon, we recommend crafting a 2H weapon with [[item:273060]] or 
[[item:245876]], but this should 
be treated as a last resort/alt-only perspective.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

We recommend **not** upgrading pieces using Myth crests in the first few weeks of 
Midnight. The reason for this is due to the crest upgrade system requiring significantly  
more crests per upgrade level. Due to the partial overlap between Hero and Myth tracks, you can also 
save a handful of Myth crests by upgrading Hero pieces first.

As a result, if at all possible, you have an incentive to 
strategically game your upgrades, and craft Myth-track embellishment items first.

If you intend on playing more than one character, you can also strategically play 
and upgrade items on your alt to gain the crest discount effect on your main by reaching 
item level thresholds on it first.

Use the following priority list to target your upgrades. These denote the 
item slot priority by its relative power:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Blood Death Knight Crest Upgrade Priority**
**Weapon**

→

**Trinkets**

→

**Helmet/Chest/Legs**

→

**Shoulders/Gloves/Belt/Boots**

:::

Once you have upgraded a slot to a certain item
level, irrespective of the item track the original item was on, 
**upgrading other items of that slot to that item level is free**. This includes crafted items; these restrictions, and more, 
are detailed here: [Gear Upgrade System](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>).

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Added ascendant venomstone usage.
- **10 Aug. 2026:** Updated for Patch 12.1. BiS lists are partially placeholder due to untestable embellishments.
- **19 Jun. 2026:** Gear update - removing the Deathbringer list for now.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **21 Apr. 2026:** Refining/clarifying bonus rolls.
- **20 Apr. 2026:** Adding voidcores and their priorities.
- **16 Mar. 2026:** Updated for Season 1, including BiS lists and trinket lists
- **26 Feb. 2026:** Added embellishments, trinkets, gear and information about Midnight.
- **10 Feb. 2026:** Changed all item levels, tier set information and a couple of trinkets.
- **30 Nov. 2025:** Adding simming FAQ temporarily here as a placeholder.
- **05 Oct. 2025:** Added back Puzzling Cartel Chips, clarified embellishments and crafting order, removed DISC.
- **16 Aug. 2025:** Updating for hotfixes.
- **04 Aug. 2025:** Updated for 11.2, including all trinkets.
- **25 Jun. 2025:** Updating D.I.S.C. recommendations after hotfix.
- **15 Jun. 2025:** Adding D.I.S.C. recommendations for Patch 11.1.7.
- **13 May 2025:** Refining dinar recommendations.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Adding Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW S1, added all BiS lists and all trinket ratings.
- **27 Aug. 2024:** Removed legendary axe recommendation as new sims show this to be a DPS loss over item level.
- **21 Aug. 2024:** Updated for The War Within Launch with Pre-Season BiS. Stay tuned for Season 1 Updates!
- **23 Jul. 2024:** Removed bullion section to prepare for pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Prepared for Season 4. Contains new BiS with all the S4 gear, cantrips, trinkets, bullions etc.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Clarifying BiS lists, removing crafted from M+/raid tables.
- **03 Jan. 2024:** Removing tuning disclaimers, adding Fyr'alath.
- **27 Nov. 2023:** Adding in murozond's rise/galakrond's fall separate links.
- **07 Nov. 2023:** Sporecloak got taken out back, so we update that.
- **06 Nov. 2023:** Prepared for 10.2, all trinkets are in, all gear sets are in.
- **04 Sep. 2023:** New format - and some clarifications + BiS lists for 10.1.7!
- **10 Jul. 2023:** Added 10.1.5 info about mega dungeon and open world trinkets.
- **24 May 2023:** Added timewalking section.
- **01 May 2023:** Updated for Season 2 launch. Moved Onyx Annulet section to the bottom of the page (It's still good for damage!)
- **20 Mar. 2023:** Added Onyx Annulet and clarified its use in content.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Season 1 launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Blood Death Knight. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Blood Death Knight Stat Priority

Whilst stats do not make or break your character, they can influence 
your performance and impact a number of aspects of combat. Blood is 
noteworthy on this, as both hero talents want different secondary stats.

The following aims to act as a guide for secondaries, both defensively 
and offensively.

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn Stat Priority

While playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn, a basic recommended stat priority is
as follows:

Strength

Haste

Critical Strike

Mastery

Versatility

Primary stat is the bread and butter for Blood Death Knight, and as a result, item level 
tends to generally trump any secondary choice on pieces with Strength on them. Strength provides 
you with **bonus armor** (from [[spell:195181]]) and a small amount of bonus parry chance, 
in addition to increasing your attack power.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn very strongly prefers haste up to ～30% unbuffed haste thanks to 
[[spell:433925]] and the increasing value of 
every bonus global cooldown during [[spell:434152]].
exact threshold varies based on the rest of your gear, your trinkets 
and any cantrips in play. Simulations will always balance it out.

This is followed by Critical Strike, with Mastery and Versatility typically being the lowest 
value per point offensively.

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer Stat Priority

While playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer, a basic recommended stat priority is
as follows:

Strength

Critical Strike

Mastery

Versatility

Haste

Primary stat is the bread and butter for Blood Death Knight, and as a result, item level 
tends to generally trump any secondary choice on pieces with Strength on them. Strength provides 
you with **bonus armor** (from [[spell:195181]]) and a small amount of bonus parry chance, 
in addition to increasing your attack power.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer avoids haste and strongly favors Critical Strike thanks to the bulk of 
its damage being two sources occuring sporadically (every 30s or 45s depending on talents): 
[[spell:441378]] and [[spell:439843]]. While haste is avoided due to none of its 
interactions being affected by haste in any way, it still has relatively 
good value compared to the other stats.

:::details FAQCan I Sim Myself and Should I?
The Blood Death Knight module for SimulationCraft is well-maintained and can
generally be relied upon to help understand the effect to the **damage** output your
gear, talent, and Conduit choices can have.

That having been said, **SimulationCraft cannot be used to evaluate
defensive choices.** Do not consider simulations in a vacuum; a choice having
the highest damage potential does not make it the best choice, and cooldown
planning always takes precedence.

It is also worth noting that simulations assume optimal play; improper rotational priorities
or mistakes in your defensive gameplay are significantly more important to fix than shuffling
a few stats around.

:::

2.

### In-Depth Stat Breakdown

**Strength** is your primary statistic as a Death Knight. It increases
the armor granted by [[spell:195181]] increases your damage, increases your
chance to parry attacks, and provides a small increase to your self-healing
through several Leech abilities available to Blood Death Knights.

**Mastery** passively increases your attack power and 
increases the amount of [[spell:77535]] you generate 
when using [[spell:49998]] (and [[spell:274156]] if 
talented into [[spell:458752]]).

:::details FAQHow Does Mastery Interact with Other Talents and Damage Profiles?
The primary driver in [[spell:77535]] is your damage taken, since
[[spell:77535]]'s generated value is directly tied to the raw amount of
healing provided by each cast of [[spell:49998]].

[[spell:77535]] is capped at a percentage of your maximum health, but this
cap ignores the temporary health increase provided by [[spell:55233]].

These interactions have the unfortunate effect of <em>reducing</em> the
relative value of each point of Mastery as damage taken increases, primarily
due to how easy it is to go over the cap.

:::

**Critical Strike** increases your chance for your abilities to deal
100% more damage, and grants an equal amount of parry rating through 
[[spell:161797]].

:::details FAQIs Parry Reliable?
The short answer is <em>it depends on how you phrase it</em>. Will you
be able to guarantee a parry on any individual hit? No. Will you
be able to statistically smooth damage in AoE where your main source
of damage taken is auto-attacks? Absolutely. And, in fact, it is directly
visible when using [[spell:49028]].

A number of additional effects and quirks make this stat even more appealing
in Midnight:

- [[spell:1264506]] procs off parries during [[spell:49028]];
    each proc results in a completely free amount of bonus Runic Power and damage, making
    it more of an incentive to not forego critical strike, at least within sensible
    margins.
- Whilst parry rating has steep diminishing returns, the parry bonus granted
    by [[spell:49028]] is completely unaffected. Coupled with the
    amount of base avoidance your character has, it makes parry much more
    appealing than it initially looks on your character sheet.

:::

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

**Haste** increases your attack speed and Rune regeneration while 
also reducing your Global Cooldown. Both of these effects are small, 
and only provide additional value over the course of encounters.

Most encounters have abilities that cannot be
mitigated or avoided. Also, you need to have a decent amount of health, in
order to give yourself the chance to be healed before a subsequent attack
kills you. As such, you need a **minimum amount of Stamina**. This amount
will, in most cases, simply come from the Stamina found innately on your
gear. Therefore, item level is the determining factor in keeping your health
pool growing.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Very small clarity change.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Small edits for Midnight.
- **30 Nov. 2025:** Small update to include the FAQ elements in the page.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch. Seperated out stat priorities for the different Hero Talent Trees.
- **23 Jul. 2024:** Adjusted for TWW pre-patch, updated with yesterday's hotfixes.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Patch 10.2.6.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Prepared for 10.2.
- **04 Sep. 2023:** Clarified stats.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Blood Death Knight, based on your [stat priority](<https://www.icy-veins.com/wow/blood-death-knight-pve-tank-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should default to [[item:240983]] as your 
unique Thalassian Diamond gem, as Midnight has very few other options. 
[[item:240967]] is not tuned highly enough to warrant 
using.

For rare gems, a sensible default for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer is [[item:240908]], 
while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn prefers [[item:240906]]. You may get more mileage out
of simming yourself for a potential sub 1% gain, but you can't go wrong with these suggested gems.

2.

### Best Enchants and Weapon Augments

Midnight expanded the array of oils and weapon enchants, but the power of most of
them is middling at best. When you are fully geared, your choice of weapon imbuement will
generally be [[item:243733]] as a default for all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:244641]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp"/> Deathbringer</span>: [[item:244017]]</li>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp"/> San'layn</span>: [[item:243986]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp"/> Deathbringer</span> (up to 10T): [[spell:326805]]</li>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp"/> Deathbringer</span> (10T+): [[spell:53344]]</li>&#10;<li><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp"/> San'layn</span>: [[spell:326805]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

The best Flask for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn is [[item:241326]] or 
[[item:241325]], depending on your current stats. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer, 
the best flask will be either [[item:241326]] or [[item:241320]].

You should sim yourself to identify which one it is; it will very likely come down to 
margin of error.

3.2.

#### Potions

Your default potion is [[item:241288]], with [[item:241308]]
being slightly worse. In situations where you do not have to worry about performance, you
can play Light's Potential if it is a lot cheaper to craft/buy.

Do not get baited by [[item:241292]]. It provides slightly more strength than 
[[item:241308]], but its downside-effect drops a 12 yard silence zone on you 
that persists until the potion is over. As a tank, one of your main responsibilities is
positioning enemies, and there are very few things worse than an AoE 
denial that forces you to move at a moment's notice.

You should use [[item:271883]] for in-combat healing.
Healing potions do not share a cooldown with [[item:5512]]s, so you can use both
independently if you play with a Warlock.

3.3.

#### Food Buff

Feasts are the only food in Midnight to grant stamina alongside primary or secondary
stats. Use [[item:255846]] (primary) or [[item:242273]] (secondary
stats); either option is fine and they provide comparable benefits to you, so it will likely
be down to which feast your raid is placing.

The personal food equivalents to both is [[item:242275]] (primary stat) 
or [[item:242274]] (secondary stat). As mentioned, they are slightly worse due to
not providing Stamina.

3.4.

#### Augment Rune

Midnight brings with it a new augment rune, as is the custom for every expansion. For the 
entirety of the expansion, you will be using [[item:259085]].

Since these will be <em>very</em> limited in supply and thus quite expensive, we
recommend getting the permanent [[item:243191]] from K'aresh as a stopgap.
It is a very small amount of primary stats, but it is more than zero in all of the
cases where [[item:259085]] is out of financial reach.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Removed Zealotry (it has not been buffed and it was only good in early S1 on ST), added new health potion for 12.1.
- **19 Jun. 2026:** Very small runeforge target count change.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **24 Mar. 2026:** Removing teas from consumables.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Enchants, consumables, flasks and pots are added.
- **10 Feb. 2026:** Prepared for pre-patch. Swapped all enchants to speed in preparation for levelling.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Added horrific visions enchants and a blurb on how they are not quite the same as before.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Launch with new consumables and enchants!
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Added helm enchant, changed health pots to 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated and clarified Onyx annulet section, added 10.1 Belt enchant, clarified gems, clarified potions and phials. Ready for 10.1.
- **20 Mar. 2023:** Added Onyx Annulet and clarified info for 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Blood Death Knight in World of Warcraft Patch 12.1.5.

1.

### Blood Death Knight in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Death Knight in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Blood Death Knight is a versatile tank packed to the brim with a
wide array of abilities that can be used to control enemies in Mythic+, all while
being largely self-sufficient when in expert hands. This combination makes us both
a great choice at almost any key level, and a spec that is both easy to get into and
actually <em>fun</em> to see results with.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer     Mythic+ Talent Build

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMzMGAAAAwMzMzMzMDzYMAYMzMzAAAMmtBGwCYbYCMsAYGzAAwMDAMA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDBzEVoggc21h6lAA-edfgHHiXRKLPVQUDAI2yKTQCZcMEaIB-AAAA-GQAUIOCM2wsIsA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/san-layn.webp>) San'layn     Mythic+ Talent Build

:::talents 天赋构筑
```json
{
  "code": "CoPAAAAAAAAAAAAAAAAAAAAAAwYWmZGmxMzMMLzMz0MLGzMmxAAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZBwyA2AMjZAAAzMwwA"
}
```
:::

:::details 来源计算器编码
```
#6D-TfBGGUSXYVVPbLCMiQIDzEVoggc21hmAo6B-edfgHHiXRKLPVQUDAIy2KTQEaCZcMIB-AAAA-TAIQQJwAxwBmmF-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts, Stuns and Stops

[[spell:47528]] is your kick; it is a talented ability, has a 15-yard range
and is on a standard melee cooldown. You can choose to spec into [[spell:378848]]
to reduce this to 12 seconds if you manage to successfully interrupt a spell, but we
generally recommend against it unless you specifically need this to reduce the number
of kick assignments on an enemy.

You should use a macro similar to the one below in order to be able to easily
transition between kicking your focus or your current target if you do not have
a focus target set. This generally allows you to pre-identify what you will kick,
even if it is not your current target:

#### Mind Freeze Macro

```wow-macro
/cast [@focus,exists,nodead] [] Mind Freeze
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2.

#### Other Group Stops

[[spell:221562]] is available on the class tree; it is a relatively long cooldown (45s),
ranged stun, and costs an entire GCD to cast. When used, your target is stunned for 5 seconds.

[[spell:207167]] disorients all targets in front of you until they take a small amount
of damage, or for 5 seconds. When the disorient breaks, they are slowed by 50% for 6 seconds.

[[spell:49576]]'s primary utility is as a soft stop on casts; with two charges on a rolling
15-second recharge timer with [[spell:356367]], and only costing 1/3 of a GCD, it is very
useful to force certain enemies to restart their cast. Unfortunately for us, 
the default behavior of most spells is to just attempt to recast if stopped, and as a result, this
only buys you a short amount of time.

Finally, [[spell:108199]] can be picked on the spec tree; it functions as a targeted
AoE displacement tool. It requires a target to cast, and when used, all hostile targets within 15
yards of the target are pulled to the center of that target's hitbox. This is **incredibly**
dangerous to cast on yourself; you should always cast on somebody (or something) else. It is also
worth noting that the target you cast it on is not moved, and thus, no cast is stopped if they were
casting. All enemies it attempts to grip are silenced for 3 seconds, including the target you 
casted it on.

### [[spell:111673]]

3.3.

#### Control Undead

This ability allows you to control an enemy and use it as a pet until cancelled. While it is 
controlled, it deals substantially less damage than normally, and often retains some unique 
spells that then become usable by you.

The following macro allows you to easily control and re-control your pet:

#### Control Undead

```wow-macro
#showtooltip Control Undead
/target pet
/run PetDismiss()
/use Control Undead
/petassist
```

This recasts [[spell:111673]] on your pet, allowing you to not have to re-target, find the spell, 
and use it. It also re-enables pet combat assist in case you had it on passive.

### Other Utility

3.4.

#### Other Utility

[[spell:43265]], when paired with the [[spell:273952]]
talent becomes a highly effective tool to snare and control enemies' movement. It is both useful 
in cases where enemies run away at low health, as it is to control the 
flow of encounters, and also allows you to 
use it to desync melee auto-attacks. While it is a rotational priority in your default rotation, an extra 
charge of it can be kept for these purposes.

[[spell:61999]] is the Death Knight combat resurrection spell. While
in a raid environment, you would not normally want to rely on the tank for
combat resurrection, in a Mythic+ dungeon, you may be the only player to bring
this utility. Additionally, the instant-cast nature of [[spell:61999]] will make it
preferable to other combat resurrections in some circumstances, and the talent 
[[spell:1266819]] practically removes its cost. If you need to resurrect an ally, be sure to consider
both timing and positioning — avoid placing the newly resurrected player
in the path of a dangerous boss cleave or immediately before a dungeon-wide
damage event.

[[spell:51052]] provides
Death Knights with a way to help the group survive large bursts of magic
damage. Its range and duration are limited, but mostly sufficient in Mythic+.
Its cooldown can be brought down to 3 minutes seconds with [[spell:374383]], but
much like [[spell:378848]], we recommend evaluating whether this is a
concrete gain for you instead of just blindly picking it and never leveraging it.

4.

### Dealing with Affixes

This section has Blood Death Knight-specific tips for dealing 
with the various affixes of Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Blood Death Knight

Our default builds already include [[spell:207167]] and [[spell:47528]].
Be aware of the orb spawn timer, and position yourself so you can stop multiple with sleet!

### Affix: Pulsar

4.2.

#### Pulsar Affix Management for Blood Death Knight

Periodically, a large blue orb will spawn around all players and slowly orbit them. Another
player needs to come in contact with it to remove it, granting 4% mastery and 2% leech per stack.

Failure to do this within 15 seconds buffs all mobs within 100 yards, granting them 10% damage
and 20% damage reduction per stack.

There is nothing to do about this from a talent or spec perspective - just help soak the orbs!

### Affix: Voidbound

4.3.

#### Voidbound Affix Management for Blood Death Knight

Voidbound emissaries are a straightforward DPS check. If you are playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/deathbringer.webp>) Deathbringer, we
recommend trying to save either an [[spell:441378]] stack or two to assist in dealing with it.

They have 1% health and a large shield, making them ideal targets for [[spell:343294]].

### Affix: Devour

4.4.

#### Devour Affix Management for Blood Death Knight

You can pre-emptively [[spell:48707]] this affix, but this costs your entire team damage. Instead,
you should simply [[spell:49998]] it away!

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Prepared for pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **20 Aug. 2025:** Adding M+ tips.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Mythic+ tips.
- **24 Feb. 2025:** Prepared for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** The tips are in!
- **09 Sep. 2024:** Preparing for TWW S1 launch. Everything except dungeon tips are in place.
- **19 Aug. 2024:** Updated talent tree for The War Within Launch.
- **24 Jul. 2024:** Correcting talent hashes.
- **18 Jul. 2024:** Adjusted builds for TWW pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Clarified pre-key, pre-pull, between-pull tips, affix tips, sorted out builds and added routing tips. Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Swapped a season 2 reference.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Removed thundering, added info about new affixes and how Blood has no way to help with them.
- **20 Mar. 2023:** Clarified talents.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Prepared for the initial release of Mythic+. In-depth, expanded spell information will follow after launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Blood Death Knight in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Generic Macros for Death Knights

1.1.1.

##### Raise Ally

#### Raise Ally

```wow-macro
#showtooltip Raise Ally
/cast [@mouseover,help][@target]Raise Ally
```

This macro casts [[spell:61999]] on your mouseover target, if they are a
friendly player. Otherwise, it casts Raise Ally on your current target.

1.1.2.

##### Mind Freeze

#### Mind Freeze

```wow-macro
#showtooltip Mind Freeze
/cast [@focus,harm,nodead][] Mind Freeze
```

This macro allows you to interrupt your focus target, if you have one, and
if not to simply interrupt your current target.

1.2.

#### Specific Macros for Blood Death Knights

1.2.1.

##### Gorefiend's Grasp

#### Gorefiend's Grasp

```wow-macro
#showtooltip Gorefiend's Grasp
/cast [mod:shift,@focus,exists][@mouseover,exists,nodead][@player] Gorefiend's Grasp
```

If you hover your cursor over a valid target to center
[[spell:108199]] on, this macro will cast Gorefiend's Grasp at your
cursor. By holding shift, it will instead cast [[spell:108199]] on your focus target. 
Otherwise, it will center your Gorefiend's Grasp on yourself.

1.2.2.

##### Death and Decay

#### Death and Decay

```wow-macro
#showtooltip Death and Decay
/cast [@cursor] Death and Decay; [mod:ctrl, @player] Death and Decay
```

This will drop [[spell:43265]] where your cursor is at, skipping the entire 
targeting reticule in the process and saving you 200-500ms in the process. Holding down 
CTRL will instead drop it at your feet.

1.2.3.

##### Blessing of Protection Cancelaura Macro

#### Blessing of Protection Cancelaura

```wow-macro
/cancelaura Blessing of Protection
```

This macro is very useful to have. It allows you to cancel a
[[spell:1022]] that may have been cast on you. It is 
important because while you are under the
effect of Blessing of Protection, mobs will not attack you and instead will just
attack the next person on the aggro list (often a DPS player), though taunting
a mob will still force it to attack you for 3 seconds.

1.2.4.

##### Re-Control Undead

#### Re-Control Undead

```wow-macro
/target pet
/run PetDismiss()
/use Control Undead
/petassist
```

2.

### Best Addons

2.1.

#### Generic Addons for Death Knights

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) is a useful addon that allows you to track the cooldowns of other raid
members, as well as providing you with a wealth of other useful raid information.

2.4.5.

##### Clique

[Clique](<https://www.curseforge.com/wow/addons/clique>) allows you to
bind specific spells to be cast as mouseover casts on unit frames. This can be
very useful for casting [[spell:61999]] without changing your target.

2.4.6.

##### Compact Runes

[Compact Runes](<https://www.curseforge.com/wow/addons/compact-runes>)
is a great addon for tracking Rune cooldowns, and it also has a number of other
Death Knight-specific modules to track your buffs, debuffs, and cooldowns.

2.5.

#### Specific Addons for Blood Death Knights

[ArcUI](<https://www.curseforge.com/wow/addons/arc-ui>) helps shore up some of the biggest problems of the 
buff/debuff tracker and cooldown manager present in Midnight. It streamlines 
the display of [[spell:195181]] charges and a handful of additional resources 
very nicely.

For Mythic+ specifically, the following add-ons are worth having:

- [TargetedSpells](<https://www.curseforge.com/wow/addons/targetedspells>) 
    highlights the targets of enemy casters on party frames, allowing you to notice 
    and react accordingly

Finally, [Nerveless](<https://www.curseforge.com/wow/addons/nerveless>) 
adds multiple customization options to the cooldown manager.

Currently, we do not believe that you need any additional addons to play your
specialisation to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** New macro format.
- **10 Feb. 2026:** Added a handful of add-on suggestions for Midnight.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within Launch.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Patch 10.2.6.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **29 Apr. 2023:** Clarified control undead and its use in Season 2.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
