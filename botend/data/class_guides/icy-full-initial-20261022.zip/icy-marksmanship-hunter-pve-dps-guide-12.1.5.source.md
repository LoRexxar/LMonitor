## 专精概览

Welcome to our Marksmanship Hunter guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Marksmanship Hunter in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Marksmanship Mythic+ Resources

[NEW! Top Marksmanship Talent Builds](<https://raider.io/specs/marksmanship-hunter/talents>)

[Top Marksmanship Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/hunter/marksmanship>)

[Marksmanship Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=hunter--marksmanship>)

[Popular Marksmanship Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=hunter--marksmanship>)

1.

### Marksmanship Hunter Overview

Marksmanship Hunter is a relatively mobile ranged DPS spec that is focused on

slow-casting, but hard-hitting cooldown-limited abilities like

[[spell:19434]] and [[spell:257044]]. Marksmanship Hunters are

damage-focused snipers with excellent burst damage, mobility, and

flexibility.

Strong Cleave, Steep Drop-Off

Marksmanship is excellent at single-target raid cleave, delivering powerful burst on
1-4 targets. The
more targets you add, the worse it gets, and its damage drops off a cliff once you go
past 8 targets due to its hard target cap, which is bad for Mythic+.

Excellent for this Raid

Marksmanship has excellent single-target, 2-4-target cleave, burst, and execute.
Almost all things that are very important in this raid, making it one of the best
raiding specs.

Capped AoE, Weak Priority Damage

Marksmanship's damage gets worse the more targets you add, and it drops off a cliff once
you go past 8 targets, which is common in Mythic+. Even at exactly 8 targets, where the cap
should make it strongest, its AoE is not ahead of the other specs. Its single-target and
low-target cleave are solid, but its priority damage is awful, and large pulls are where
Mythic+ is played, making it one of the weaker specs for general Mythic+.

Unremarkable

We bring mediocre utility to the
group. A 1-minute stun/AoE stop in

[[spell:474421]]

,
and a regular cooldown ranged kick. The flexibility and cooldown of our AoE stops are
mediocre.

[[spell:257284]]

is mandatory in raids, but it is not particularly
strong in Mythic+.

Strong Active Defenses, Weak Passives

Marksmanship has access to several strong active defensive abilities,
allowing it to mitigate heavy damage effectively. However, its passive defenses
are relatively weak, making it reliant on timing and proper use of cooldowns to
survive in high-damage situations. It suffers in "rot" damage situations, with
constantly ticking hard DoTs. As a result, Hunters often require more external
healing than other classes, and the skill ceiling is relatively high, while the
skill floor is relatively low.

High potential, but high skill floor

While Marksmanship spends around 40% of its time casting spells that render
you immobile, it is reasonably flexible in when you
cast these spells. Because

[[spell:19434]]

has two charges, it can be delayed
while you are moving, and as long as you never cap on charges, you are not losing
anything. Taking advantage of this can make Marksmanship a fairly mobile spec in
practice.

2.

### Marksmanship Hunter in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 adds two new pieces of endgame content to Season 2. The

Unbinding of Kith'ix is a new raid encounter, and the Labyrinth of Kindo'jan

is a new Mega-Delve. Our guides to both are linked below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Patch 12.1.5 is a mid-season content patch. It also brings

[[item:280562]], a new currency for upgrading your Weapon,

Trinkets and Neck up to iLvl 340. Everything else that is new is in the

Patch Hub below.

2.3.

#### Class Changes

Patch 12.1.5 removes [[spell:1277548]] and puts a new talent,

[[spell:1319016]], in its place. Practically speaking, the primary

difference is that [[spell:257044]] no longer spends [[spell:260240]] for

you, so as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel you once again need to spend the proc before you

cast [[spell:257044]] like in Season 1, unless [[spell:288613]] is up, while

as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger you simply cast [[spell:257044]] on cooldown.

[[spell:1319016]] changes nothing about your rotation and is a purely

passive benefit.

- New Talent: [[spell:1319016]]. [[spell:19434]] critical strikes
  
    now cause the [[spell:260309]] bleed at 20% of the damage dealt
  
    instead of 10%. For 4 seconds after a critical [[spell:19434]], the
  
    target also takes extra bleed damage every time one of your abilities
  
    damages it.
- [[spell:1277548]] has been removed. [[spell:257044]] no longer fires an
  
    [[spell:185358]] at the start and end of its channel, so it no longer
  
    spends [[spell:260240]] on its own. This has significant rotational
  
    implications which are detailed on our Rotation page.

Our [Rotation](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>) page has

been updated for Patch 12.1.5. On our

[Gear](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>) page, the Catalyzed

[[item:281238]] from the Kith'ix raid are our new BiS

Gloves, and there is a new list of what to spend your first

[[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_marksmanship.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Changes

Patch 12.1 brings a fair bit of content outside of the new Season.

There is a new zone to explore, new rares and treasures to hunt down, and

plenty of new housing and transmog rewards to collect. Blizzard has also

updated a number of existing systems and added quality of life

improvements.

:::details Show Patch 12.1 Class ChangesHide Patch 12.1 Class Changes
2.5.

#### Class Changes

Marksmanship got by far the largest rework of the three Hunter

specializations

in Season 2. [[spell:212431]] is back as a wholly different spell,

[[spell:257044]] deals significant damage again while [[spell:19434]] has

been nerfed.

The [Omnium Folio](<https://www.icy-veins.com/wow/omnium-folio-guide>) borrowed-power system carries into Season 2, and it

affects both your talent choices and your gear. You can find the details on our

dedicated [Talents](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>) and

[Gear](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>) Guides.

- [[spell:212431]] now lasts for 3 seconds, and every 1 second the
  
    target explodes for Fire damage, dealing 50% of that damage to all enemies
  
    within 8 yards. Deals reduced damage beyond 5 targets.
- New Talent: [[spell:473520]]. [[spell:212431]] can now be
  
    used a second time if cast within 3 seconds, and it incorporates any remaining
  
    damage from previous [[spell:212431]]s on your target. It is a choice
  
    node with [[spell:1301406]].
- [[spell:473520]] is now [[spell:1301406]], and causes
  
    [[spell:212431]] to grant [[spell:194595]].
- Incendiary Ammunition is now Accuracy By Volume, and makes
  
    [[spell:389019]] affect 1 additional [[spell:19434]].
- [[spell:471369]] now makes [[spell:212431]] last 1
  
    second longer, which means it will explode for an extra tick of damage.
- [[spell:389019]] now makes [[spell:257044]] increase the damage of
  
    your next [[spell:19434]] by 20%.
- [[spell:473523]] now increases [[spell:257044]] damage by 10%
  
    and gives it a 30% chance to grant [[spell:194595]].
- [[spell:378769]] now gives [[spell:19434]] a 10% chance to
  
    **cause your next [[spell:19434]] to grant [[spell:378769]].**
- [[spell:470945]] no longer affects [[spell:185358]].
- The following talents have been removed: [[spell:473370]] and
  
    [[spell:471363]].
- [[spell:473369]] is now a 1-point talent that increases the damage
  
    of [[spell:19434]] by 5% (was 10%) and [[spell:257044]] by 10% (was 20%).
  
    [[spell:378767]] now reduces the cooldown of [[spell:19434]] by 1 second
  
    (was 2 seconds). [[spell:459802]] is now a 2-point talent.
- Some talents moved in the second gate of the tree to make
  
    [[spell:212431]] easier to obtain, and the
  
    [[spell:474456]]/[[spell:474440]] node is no
  
    longer required pathing to reach [[spell:288613]].
- **Apex Talents:** [[spell:1273129]] (Rank 2) now increases the critical
  
    damage of your abilities by 5%/10% and the damage of your ranged abilities by
  
    3%/6%. [[spell:1273128]] (Rank 3) now causes [[spell:466872]] to also
  
    increase the damage of your next [[spell:257044]] against the target by 20%,
  
    on top of the [[spell:19434]] bonus.
- **Dark Ranger:** [[spell:1277565]] has been redesigned to a flat
  
    10% [[spell:53351]] and [[spell:466932]] damage increase, and it now
  
    correctly increases [[spell:430715]]'s damage
- **Dark Ranger:** [[spell:466932]] no longer highlights itself when
  
    usable
- **Dark Ranger:** [[spell:466932]]'s direct damage was reduced by
  
    40%, then increased by 25%
- **Dark Ranger:** [[spell:467749]] damage increased by 300%, and
  
    [[spell:430715]]'s [[spell:466932]] damage reduced by 40%
- **Dark Ranger:** Dark Minion summons can now be tracked on the Cooldown
  
    Manager.
- **Sentinel:** [[spell:1253825]] now only causes 1 second of cooldown
  
    reduction to [[spell:19434]] (was 2 seconds). [[spell:1253601]]
  
    duration increased to 16 seconds (was 12 seconds).
- **Tuning:** [[spell:19434]], [[spell:257044]],
  
    [[spell:185358]], [[spell:257620]] and [[spell:53351]]
  
    damage were all increased by 20%, with further passes since:
  
    [[spell:257044]] +20%, [[spell:185358]] +15%, [[spell:53351]] +25%,
  
    [[spell:56641]] +50%, [[spell:260243]] +20%, [[spell:257620]]
  
    +80% then -20%, and all damage +5%. Auto Shot damage increased by 20%, and
  
    ranged auto-shot damage increased by 600%. [[spell:212431]] was retuned
  
    twice after its redesign, by 15% and then by 100%, and it now only explodes
  
    for 50% of its damage to other nearby enemies.
- **Tier Set:** **2-Set:** [[spell:212431]] lasts 1 second
  
    longer and deals 5% increased damage. **4-Set:** [[spell:19434]] and
  
    [[spell:257044]] damage increased by 5%. Each time [[spell:212431]]
  
    causes a burst of damage, the cooldown of [[spell:19434]] and
  
    [[spell:257044]] is reduced by 0.5 seconds.
- **Bug Fixes:** [[spell:459802]] now correctly increases
  
    [[spell:212431]]'s damage. [[spell:212431]]'s area damage no
  
    longer benefits twice from Mastery, critical damage bonuses and Take Aim, no
  
    longer hits its own primary target, and still goes off if the primary target
  
    dies to it. [[spell:378769]] now procs at the expected rate from
  
    [[spell:19434]], and [[spell:470945]] no longer blocks or consumes
  
    those procs.

:::

:::

### Midnight   Changes Overview

2.6.

#### Marksmanship Hunter Changes in Midnight

The Midnight Expansion brings huge changes for all Hunter specs, primarily

focused on streamlining and simplifying aspects of the kit.

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

- No more [[spell:378769]] procs from Auto-Shots.
- [[spell:257044]] is now guaranteed to grant
  
  [[spell:378769]].
- After you activate [[spell:288613]], the Trueshot button itself turns
  
  into [[spell:392060]], a powerful cast that activates
  
  [[spell:378769]] and also kicks/silences all targets hit for 1 sec.

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

- [[spell:466872]] is replaced by [[spell:1253601]] and is much
  
  stronger.
- [[spell:450373]] is now a flat 10% absorb shield that you get
  
  whenever you get a [[spell:1253601]] proc.
- Maximum Focus increased to 125.
- Like ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger, after activating [[spell:288613]], the
  
  Trueshot button becomes [[spell:1264902]] which sends a glowy
  
  chakram that deals heavy AoE damage as it bounces between enemies. A choice node
  
  can cause this Chakram to give us [[spell:194595]].

2.7.

#### DPS & Gameplay Changes

- [[spell:260367]] is gone and as a result, [[spell:19434]]'s
  
  cast time is much longer at a baseline of 2.5 sec. During [[spell:288613]],
  
  this is reduced to 1.5 sec. Its damage has been buffed to compensate, but
  
  overall, expect a slower-playing, more sniper-focused and deliberate
  
  Marksmanship "feel" in Midnight.
- All of the [[spell:212431]]-related Talents are gone. We do keep
  
  [[spell:1301406]], which now triggers off [[spell:260243]].
- Other removed talents include [[spell:384790]],
  
  [[spell:474296]], and of course,
  
  [[spell:471427]].

2.8.

#### Apex Talents

Midnight introduces new Apex Talents, unlocked between Level 80 and 90.

Marksmanship receives:

1. [[spell:1273132]]
2. [[spell:1273129]]
3. [[spell:1273128]]

They cause [[spell:257044]] to reduce [[spell:19434]]'s cooldown by 5

sec over its channel.

2.9.

#### Survivability Changes

- Hunters have +2% higher max HP than previously.
- [[spell:109304]]'s cooldown is now a 1-minute flat, instead of variable
  
  (and often lower).
- [[spell:186265]]'s cooldown is now 2:00 with talents, down from
  
  2:30.
- [[spell:186265]] can now be a 50% damage reduction with talents,
  
  up from 30%.
- [[spell:53480]] is now an external defensive that can be used on
  
  yourself or any friendly target to reduce their damage taken by 15% for 10 sec,
  
  but 50% of their damage taken will be taken by your pet. For Marksmanship, the
  
  pet part just disappears if you have no pet.
- [[spell:388035]] is now 3% passive damage reduction, instead of
  
  being an active defensive cooldown.

2.10.

#### Utility Changes

- [[spell:257284]] is now a universal 3% damage increase against a
  
  single-target. This essentially guarantees Hunter a raid spot in every raid. It
  
  is also a boost to the group in Mythic+, though it is much less potent
  
  there.
- [[spell:147362]] now spell-locks the target for 5 seconds, up from
  
  3.
- [[spell:187650]] can now slow the target by 70% for 4 sec after the
  
  trap breaks.
- [[spell:474421]] is now our sole stun/stop. A choice node either
  
  reduces its cooldown to 40 sec, or makes it a 1-second AoE stun.
  
  [[spell:462033]], [[spell:236776]], and [[spell:186387]]
  
  are all gone.
- The slows from [[spell:195645]] and [[spell:5116]] are 25% and
  
  10% stronger, respectively.
- [[spell:472729]] is now a Class Tree node and not attached to
  
  the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Hero Talent. It is a choice node with
  
  [[spell:459460]], which extends [[spell:109248]]'s stun by
  
  1 sec.
- [[spell:459466]] is gone.
- [[spell:213691]] is gone.
- [[spell:459533]] is gone.
- [[spell:321468]] is gone.

2.11.

#### Miscellaneous Changes

- [[spell:186257]]'s initial "super" speed burst is now twice as
  
  long with talents.
- [[spell:53351]] is now exclusive to the Marksmanship tree.
- Successfully kicking with [[spell:147362]]/[[spell:187707]] now
  
  grants 30 Focus, up from 10, but soothing/purging with
  
  [[spell:19801]] no longer grants Focus.

Overall, we are gaining defensiveness and mobility, while in the utility

department, we are losing some things (like the ability to move mobs) but

gaining others (stronger Mark, streamlined AoE stun, stronger kick and more

Focus return on kicking). We think the changes are broadly positive!

3.

### Basics of Marksmanship Hunter Gameplay

Marksmanship Hunter is a spec about cooldown management, uptime, and flow.

You want to cast your hard-hitter abilities like [[spell:19434]],

[[spell:257044]], and [[spell:53351]] as often as possible. In-between these

abilities, which all have independent cooldowns, you are managing your Focus by

using [[spell:185358]] as a spender and [[spell:56641]] as a filler and

builder. When you cast [[spell:19434]], your next

[[spell:185358]]/[[spell:257620]] will do significantly increased 

damage, and so you have a fairly consistent flow where a 

[[spell:260240]]-generator is immediately followed by a spender.

During [[spell:288613]], your exciting main cooldown, everything

dramatically speeds up and you will be spamming both [[spell:19434]] and

[[spell:257044]] with their reduced cooldown. The main benefit conferred by

this cooldown is significantly increased Crit Chance (more Crits) and Crit

Damage (stronger Crits). Crit is a huge stat for Marksmanship due to these and

other mechanics.

On AoE, you want to activate the [[spell:257621]] buff for all of your

Aimed and Rapid Fire casts. This is done by simply weaving at least one

[[spell:257620]] in-between every single cast of

[[spell:19434]] and [[spell:257044]], even during [[spell:288613]].

The best Marksmanship Hunters are excellent at doing these things on the fly

and during hectic movement (which prevents [[spell:19434]] casting) and

mechanics. They always know what to cast next and they have a great awareness of

their Focus levels and the status of their cooldowns at all times. To condense 

things further, Marksmanship can be described briefly with the following bullet points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_snipertraining.jpg>) **Spend All of Your Precise Shots**  
  
  
    Every single [[spell:19434]] and [[spell:257044]] is going to grant
  
    [[spell:260240]], and we want to spend all of these Precise Shots procs
  
    before we cast another Aimed Shot. Do not cast Aimed Shot if you have a
  
    Precise Shots unspent. As Sentinel, spend them before Rapid Fire too, unless
  
    Trueshot is up.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_steadyshot.jpg>) **Always be Casting**  
  
  
    Casting as many abilities as possible matters more than pressing the perfect
  
    button every time, and dead time is the single biggest thing holding most
  
    players back from their DPS goals. [[spell:56641]] is how you fill it, and
  
    it is castable while moving, so there is no excuse for a dead global.

4.

### How to Gear Up as a Marksmanship Hunter

Our dedicated Marksmanship gearing page covers Season 2 gear from your

first upgrades through to the full best-in-slot list. We still recommend

simming yourself for the ideal answer. Once you've picked up some gear, you'll

need the appropriate consumables, gems, and enchants to go with those new

items.

5.

### Changelog

:::details 历史更新记录
- **14 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** With Aspect of the Hydra on two or more targets, Sentinel now casts Rapid Fire on cooldown even with Precise Shots up.
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **30 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Fixed the Chest tooltips showing two Venomcursed effects.
- **07 Sep. 2026 (this page):** Raised the Damage rating to 3.5 and the Raid rating to 4, and rewrote both sections.
- **02 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall and Raid BiS List Trinket to the Font of Venomous Rage.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall BiS List Ring to the Charged Sandstone Band.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall and Raid BiS List Boots to the Boots of the Reckless Wayfarer.
- **31 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Replaced the Auto-TargetSwap Multi-Shot macro with the Mouseover Multi-Shot macro.
- **31 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Clarified mouseover Multi-Shotting and clipping.
- **31 Aug. 2026 (this page):** Clarified the Precise Shots spending advice for Rapid Fire.
- **29 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Moved the Font of Venomous Rage up to S Tier, as it was undersimming.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Added Liquid Luster as the second Potion of a long fight, for execute.
- **24 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added Liquid Luster as the second Potion of the fight, popped around 10 seconds before Trueshot in the execute phase.
- **24 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Moonlight Chakram now goes out with around 5 seconds of Trueshot left on single target, so that all 7 bounces land inside the Trueshot.
- **24 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Moved Rapid Fire above the Precise Shots spenders in the Sentinel single-target priority list. Same fundamental rotation, but easier to parse/read.
- **22 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Added a note on crafting Legs.
- **22 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Noted the one Rapid Fire clip that is still worth doing.
- **22 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Rapid Fire advice for the recent hotfix. Only Sentinel still clips the channel, and only on AoE.
- **22 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Arcane Shot no longer has a separate rule during Trueshot.
- **22 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Mythic+ and Delves Sentinel builds now take Open Fire over Stargazer.
- **22 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Mythic+ and Delves Sentinel builds now take On Target over Obsidian Arrowhead.
- **22 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Rapid Fire no longer needs Precise Shots spent first.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Nebulous Voidcore bonus roll priorities following the Gebbo's Bottomless Bag nerf.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall BiS List Boots to the Sabatons of Coruscating Energy.
- **18 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Added a Target Swap Multi-Shot macro.
- **18 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added holding Trueshot for up to 15 seconds to line it up with Explosive Shot.
- **18 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added swapping to a target without a Mark before pressing Trueshot.
- **18 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added target selection by Sentinel's Mark and Spotter's Mark to the Rapid Fire, Aimed Shot and Precise Shots spender priorities.
- **18 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Linked the Target Swap Multi-Shot macro from the Multi-Shot priority entries.
- **18 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Utility Talents for Raid builds.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket tier list, and changed the alternative passive Trinket to Keeper's Seething Core.
- **17 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** The Omnium Folio setup now takes Void-Tainted Shell over Self-Mending.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Reworked the crafting advice, corrected the Voracious Heart of Ula'tek and Gebbo's Bottomless Bag entries in the raid-items list, and added start of season Voidcore and Crest advice.
- **16 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added clipping the end of Rapid Fire with Multi-Shot to the Sentinel AoE opener.
- **16 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Removed spreading Explosive Shot across two targets from the AoE priorities and opener if a priority target is up. It was found to not speed up M+ keys due to its prio damage loss, though it is a small AoE/2T DPS gain.
- **16 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Mythic+ and Delves Sentinel builds now take Stargazer over Open Fire, a small gain now that Rapid Fire clipping consumes Precise Shots more often.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket tier list following the latest tuning.
- **15 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added clipping the end of Rapid Fire to the single-target priorities, and clarified that both shots benefit from Precise Shots.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Nebulous Voidcore bonus roll priorities.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Raid BiS Gloves to the Catalyzed Grips of Swirling Fury from Nymrissa Wavecaller.
- **13 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added clipping the end of Rapid Fire to the AoE priorities.
- **12 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Added Catalyst and Great Vault FAQs and a socket section, fixed Catalyst drop locations, and updated sources of the Raid BiS Helm and Gloves.
- **12 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Clarified that Rapid Fire needs Trick Shots up in the AoE priority.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Delve builds now take Emergency Salve over Wilderness Medicine.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Delve build Class Tree to pick up Unbreakable Bond (for a pet).
- **11 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Clarified Explosive Shot targeting in the AoE priority.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **16 Jul. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated Heirloom stat advice.
- **16 Jul. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Corrected Fortitude of the Bear and Updraft descriptions, removed the exotic pet table, and updated expansion references.
- **16 Jul. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Fixed Tier Set FAQ pieces and updated the Neck recommendation notes.
- **16 Jul. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated Weapon enchant recommendations, and fixed enchant tooltip links.
- **16 Jul. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Clarified burst profile and utility notes.
- **16 Jul. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Corrected Volley's cooldown and clarified Double Tap usage.
- **16 Jul. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Clarified Hero Talent build guidance.
- **16 Jul. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Corrected Aimed Shot's cast time, added Explosive Shot, Wailing Arrow, and Moonlight Chakram to the glossary, and alphabetized the ability tables.
- **16 Jul. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Added Trueshot to the beginner priority list.
- **16 Jul. 2026 (this page):** Reworked the performance overview.
- **17 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated BiS Neck
- **17 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated recommended week 1 Folio Rune based on real-world data trumping sims.
- **16 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Clarified Weapon Enchant choice.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **29 May 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added note of high-prio Aimed at 2 charges for DR ST.
- **21 May 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated guidance on the Sentinel Raid AoE Build.
- **07 May 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Sentinel Raid AoE Build.
- **06 May 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Sentinel M+ Build. Still very bad in all M+ situations.
- **04 May 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for tuning.
- **27 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotation updates and simplifications. Opener updates.
- **25 Apr. 2026 (this page):** Updated Beast Mastery performance evaluation.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **09 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Dark Ranger Opener fix.
- **07 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Light Company Guidon Tier List position.
- **31 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Talent build note for Vaelgor and Ezzorak.
- **25 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Mythic+ Gear BiS List.
- **25 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the baseline Raid AOE build.
- **22 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Added Haste breakpoint information.
- **22 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Swapped Sentinel M+ Build to Stalk and Strike over Twilight Requiem in the Sentinel Tree, for identical sim performance but a microscopic mobility benefit.
- **22 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Swapped Sentinel M+ Build to Stalk and Strike over Twilight Requiem in the Sentinel Tree, for identical sim performance but a microscopic mobility benefit.
- **21 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Mythic+ Gear BiS List.
- **19 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated to recommend Leech Enchants over Avoidance. Updated Gems advice.
- **19 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Delve build.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Fixed error causing Volley not to appear in the opener under some conditions. Small updates to Sentinel AoE Rotation.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added simple explainer for the Hydra Build. Updated the Hydra Build for a bit more AoE. Fixed single-target build error.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Sentinel Mythic+ Build.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **04 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Crafting recommendation for endgame.
- **03 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Opener clarifications for Moonlight Chakram.
- **03 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Talent Builds and added Dark Ranger builds.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated Talent Builds for the upcoming 12.0.1 changes.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Talent Builds for the upcoming 12.0.1 changes.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **23 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Stat Diminishing Returns values for Level 80.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **14 Sep. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated Stat Priorities, specifically formalizing a point of Crit where it tends to become inferior.
- **02 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Trinket Tier List and BiS updates.
- **02 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated DR M+ Talent Build, specifically utility picks.
- **02 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated DR M+ Talent Build, specifically utility picks.
- **28 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Single-Target rotation update surrounding ES usage.
- **27 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated stat priority for Dark Ranger AoE.
- **27 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Expanded on reasoning for 1.5-min and 1-min builds.
- **27 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Minor rotational clarifications and edits on AoE.
- **27 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Expanded on reasoning for 1.5-min and 1-min builds.
- **27 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Simplified the Rotation further.
- **26 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated note on swapping between Unerring Vision and Calling the Shots for Dark Ranger M+.
- **26 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated note on swapping between Unerring Vision and Calling the Shots for Dark Ranger M+. Removed note on Focused Aim as Improved Streamline is equal, even on paper, and better in practice. Update Raid AoE build.
- **25 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added information about rotational bugs.
- **25 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Explosive Shot usage on single-target to be more accomodating of Improved Streamline setups.
- **25 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated single-target talent default to Improved Streamline rather than Focused Aim.
- **20 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added note on swapping Focused Aim to Improved Streamline for movement concerns.
- **19 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Removed filler-Multi Shot from Dark Ranger AoE.
- **18 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Minor Dark Ranger Single-Target Opener update (make it more explicit to spend PS stacks before entering Trueshot).
- **17 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Minor Dark Ranger Single-Target Rotation clarifications/simplifications. Minor Sentinel AoE clarification.
- **15 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Trinket Tier List for tuning. Simplified into one list.
- **15 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE Rotation(s).
- **13 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small Dark Ranger Single-Target opener change.
- **12 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Added preliminary, guesswork-based Cursed Stone Idol Trinket in the Tier List, as it cannot be simmed yet.
- **12 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Single-Target Rotations.
- **12 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Microscopic single-target talent update for Dark Ranger.
- **11 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated M+ Trinket Tier List.
- **11 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the Mythic+ Build Recommendation.
- **11 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Substantial Rotational Updates for Dark Ranger on Single-Target, worth quite a bit of extra DPS.
- **11 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Mythic+ Talent Build recommendation.
- **09 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Trinket Tier Lists and BiS Lists.
- **09 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated Stat Priority.
- **08 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Mythic+ Gear BiS List.
- **08 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Update default Dark Ranger Single-Target talent picks.
- **08 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated single-target rotation default utility picks for the Raid.
- **07 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Further opener update iteration.
- **07 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the S3 Single-Target build to be the same as the S2 4PC one!
- **06 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Sent M+ Class Tree talent update.
- **06 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Substantial AoE Rotation updates, particularly Sentinel AoE Opener.
- **06 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Dark Ranger S2 4PC Talents and Sent M+ Class Tree talent update.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **23 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Titan Disc recommendation based on the latest hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **26 May 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added note on Salvo vs Ohn'ahran Winds.
- **17 May 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Raid AoE Build to grab Volley, since most AoE in the Raid is very short-term.
- **15 May 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the Sentinel Mythic+ build to grab Ohn'ahran Winds, as evidence suggests that it has been fixed and now works properly in Mythic+ keys.
- **15 May 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Dark Ranger AoE Opener.
- **15 May 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Sentinel Mythic+ build to grab Ohn'ahran Winds, as evidence suggests that it has been fixed and now works properly in Mythic+ keys.
- **14 May 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the purchasing order of Jastor Diamond and added more context to its "BiS"-ness.
- **09 May 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Corruption Enchants & Puzzling Cartel Chip Dinar section.
- **09 May 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated Corruption Enchants section.
- **09 May 2025 (this page):** Updated Best Spec section.
- **07 May 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the wording of the 4PC Doubledip in the rotation to make it clearer what it does and how it works.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Add list of Dinar-purchasable items.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Added Corruption Enchants information.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the default Dark Ranger M+ Build on the Talents Page, mostly to stem confusion.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **04 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Very small rotation updates and clarifications.
- **04 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Sentinel Mythic+ Build to account for Ohn'ahran Winds being bugged.
- **02 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the Mythic+ Talent Builds.
- **02 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the Sentinel Mythic+ Talent Build, adding a note about Ohn'ahran Winds being bugged.
- **02 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reverted yesterday's change on ST Build. Updated with new M+ Build.
- **01 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Single-Target Talent Builds in light of recent simulation updates.
- **30 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Added note on Small Game Hunter viability.
- **30 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added note on Small Game Hunter viability.
- **29 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the position of Eye of Kezan in the Mythic+ Trinket Tier List.
- **25 Mar. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added a fall-back line to Explosive Shot regardless of other statuses, as a low priority.
- **25 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for the March 25th Hotfixes.
- **25 Mar. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for March 25 Updates.
- **25 Mar. 2025 (this page):** Updated for March 25 Updates.
- **18 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the recommended MDT Sim/Mythic+ Simulation Route Pastebin. Updated the Mythic+ Talent Build. Added a note about Volley to it.
- **18 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated rotational details regarding 4PC and Precision Detonation. Updated wording to be clearer in places.
- **18 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Mythic+ Talent Build. Added a note about Volley to it.
- **14 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated defaults to assume 4PC.
- **14 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated defaults to assume 4PC.
- **13 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated Trinket Tier List and BiS List with fresh simulations based on latest changes and APL improvements.
- **07 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds based on real-world data.
- **04 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **04 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotation improvements. Removed Kill Shot from AoE Priority, and Single-Target priority unless certain talents are chosen.
- **04 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added note on M+ Talent changes with and without 4PC, and updated the default temporarily.
- **27 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the Sentinel Mythic+ Talent Build in light of recent simulation tool developments.
- **27 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Significant rotational updates relating to Arcane Shot, Aimed Shot, and Explosive Shot usage.
- **27 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Sentinel Mythic+ Talent Build in light of recent simulation tool developments.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **13 Jan. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Further separated Dark Ranger and Sentinel Single-Target Rotation differences.
- **08 Jan. 2025 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small opener addition.
- **27 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated to take Dark Ranger bugs and the resulting power spike into account.
- **27 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small Dark Ranger Opener and Rotation updates.
- **27 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated to take Dark Ranger bugs and the resulting power spike into account.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for the Cyrce's Circlet now going to Item Level 658.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **31 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotation overhaul, particularly for Dark Ranger.
- **30 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 (this page):** Updated Best Spec Section for hotfixes.
- **26 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Significant single-target rotation update.
- **26 Oct. 2024 (this page):** Reinstated the Best Spec section.
- **23 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated to Dark Ranger default recommendation while everything is in a bugged state.
- **22 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **10 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket Tier List slightly.
- **10 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Mad Queen's Mandate usage.
- **08 Oct. 2024 (this page):** Updated the "Best Hunter Spec" section for the updated October 8th Hotfixes.
- **07 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Marksmanship Dark Ranger Single-Target Build.
- **02 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added more specific Trinket usage information.
- **28 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated the M+ Talent Build - one-point swap.
- **28 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the M+ Talent Build - one-point swap.
- **27 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated Ara-Kara Tips.
- **24 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added Lunar Storm Rapid Fire-holding to AoE Rotation.
- **17 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the BiS List Trinket selections.
- **17 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added opener note about on-use Trinkets.
- **15 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated the MM Trinket Tier Lists based on new methodology, and in the case of the Raiding Tier List, a new preferred single-target build discussed on other pages of the guide.
- **15 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added note about on-use trinkets.
- **14 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated the Raid AoE build, and swapped the ST recommendation to Dark Ranger for a couple of bosses.
- **14 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Simplified the single-target rotation, specifically Aimed Shot usage.
- **14 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added the Raid AoE build to the page. Updated the single-target builds.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Added note about double-Dawnthread Lining not working and how to fix it.
- **13 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Re-visited the best builds on every boss after Heroic experience and made some changes.
- **13 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Updated and clarified some tips.
- **13 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added note about Wailing Arrow resetting the cooldown of Rapid Fire, updated opener.
- **10 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Added note about Movement Speed Gem, and also updated the Gem setup recommendation in general.
- **10 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Clarified that Multi-Shot takes over from Arcane Shot at just 2 targets. Simplified the Steady Focus Rotation.
- **10 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the single-target talents slightly (one-point change for 0.2% DPS).
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-mythic-plus-tips>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Opener with Wailing Arrow specced.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Preliminary updates for The War Within Season 1.
- **09 Sep. 2024 (this page):** Preliminary updates for The War Within Season 1.
- **03 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Preliminary updates for The War Within Season 1.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Added a note about Crafted gear to the Pre-Season BiS List.
- **23 Aug. 2024 (this page):** Re-introduced a section talking about the Best Hunter Specs in the War Within.
- **22 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for The War Within.
- **22 Aug. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for The War Within.
- **22 Aug. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for The War Within.
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **22 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for The War Within.
- **22 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **22 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for The War Within.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **22 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for The War Within.
- **22 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for The War Within.
- **22 Aug. 2024 (this page):** Updated for The War Within.
- **31 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Simplified Steady Focus optimization. This affects the single-target opener, rotation, and AoE rotation.
- **25 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Single-Target Talent Build.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **26 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/marksmanship-hunter-the-war-within-pve-guide>)):** Updated for the June 25th changes.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/marksmanship-hunter-the-war-within-pve-guide>)):** Page added.
- **29 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker Gem recommendations.
- **20 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker Gem rankings based on live server power levels.
- **17 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker and Cogwheel Gem recommendations in light of recent changes and new information.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/marksmanship-hunter-mists-of-pandaria-remix-guide>)):** Page added.
- **11 May 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Added a Nochanneling Rapid Fire Macro.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **14 Feb. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended default Mythic+ Talent Build.
- **14 Feb. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated the recommended default Mythic+ Talent Build.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5
- **04 Dec. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Talents for Mythic+.
- **27 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated Talents for Mythic+.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.2
- **06 Nov. 2023 (this page):** Updated for Patch 10.2
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Restructured the page and updated for Patch 10.1.7
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **27 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Additional Talent Change, and moved Steel Trap to be default for single-target.
- **27 Jun. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated the Talent Builds.
- **26 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the single-target build to account for new tuning.
- **03 Jun. 2023 (this page):** Updated the blurb about spec viability, and updated the Strengths and Weaknesses.
- **25 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended builds to assume the set bonus as default.
- **22 May 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Leg Enchant, as it was found that the Lambent Armor Kit does not provide Stamina as it was assumed.
- **19 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the layout of the page and added an alternative, cooldown-less build.
- **15 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added note on Steel Trap and when you might want to use it.
- **12 May 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended food and Leg enchant.
- **12 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Clarified talent changes for AoE as well as single-target with the 4PC Bonus.
- **09 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added note of how the build changes with the 4PC Set Bonus.
- **08 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended single-target talent build to pick Steady Focus.
- **04 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended AoE/M+ Talent Build. This is likely a temporary change, until the new Tier Set becomes more widespread.
- **04 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated the recommended AoE Talent Build. This is likely a temporary change, until the new Tier Set becomes more widespread.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.
- **01 May 2023 (this page):** Reviewed for Patch 10.1.
- **11 Apr. 2023 (this page):** Updated the spec rankings to account for new nerfs.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Gemstones after sim updates, and the discovery of a new, powerful combination.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Yet another update to the recommended Gemstones based on a slew of hotfixes.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Onyx Annulet Information in light of the March 21st buff.
- **21 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the talents for the 10.0.7 talent reshuffle.
- **21 Mar. 2023 (this page):** Updated with spec rankings for different types of damage.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/marksmanship-hunter-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **16 Feb. 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Fixed an issue with the talent order.
- **15 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the utility talents in the M+ Build.
- **30 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Small updates to talent swaps.
- **25 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Added a Salvo Volley Macro.
- **25 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the Talent Builds again after the discovery of a sim bug. Added alternative to Steady Focus. Changed the "swap" talent for Wailing Arrow to Bullseye.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the page for relevant changes in Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated the page for relevant changes in Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated the page for relevant changes in Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **21 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Fixed a wrong note about which talent to swap for Ammo Talents.
- **17 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended Single-Target Talent Build.
- **17 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated the recommended Single-Target Talent Build.
- **06 Jan. 2023 ([pets page](<https://www.icy-veins.com/wow/marksmanship-hunter-pets-guide>)):** Added page.
- **04 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Phial.
- **23 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended builds to reflect that Unerring Vision is fixed and worth using again.
- **23 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Talent updates.
- **18 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended talent builds to reflect that Unerring Vision is bugged.
- **16 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Added note that you do not need to use Serpent Sting manually with Hydra's Bite.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommendation and description of the optimal Flasks/Phials.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended single-target talent build in light of recent buffs.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Updated Spec Viability for the latest buffs.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/marksmanship-hunter-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/marksmanship-hunter-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/marksmanship-hunter-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/marksmanship-hunter-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-weak-auras>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **12 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** Updated thoughts on all of the Covenant-specific Legendaries, and added the July 13th Hunter Buffs to the changes.
- **10 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** Added information about the Venthyr-specific Legendary.
- **12 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** Added information about 4 new Covenant-specific Legendaries.
- **25 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/marksmanship-hunter-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **23 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for more bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **13 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Added Marksmanship tips for Uu'nat.
- **01 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Added Marksmanship tips for The Restless Cabal.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **22 Mar. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added tips for Jaina on Mythic Difficulty.
- **20 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for multiple bosses on Mythic.
  
  - Added tips for Stormwall Blockade (Mythic).
  - Added tips for King Rastakhan (Mythic).
  - Added tips for High Tinker Mekkatorque (Mythic).
  - Added tips for Opulence (Mythic).
  - Added tips for Conclave of the Chosen (Mythic).
- **05 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for Jadefire Masters (Mythic) and altered the talent recommendations.
- **03 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for Champion of the Light and Grong (Mythic).
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for Marksmanship Hunter in Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** Added more specifically useful tips for Marksmanship on each boss in Uldir Mythic.
- **03 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-uldir-raid-guide>)):** Added additional content for Uldir's release.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Marksmanship Hunter leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Hunter leveling guide](<https://www.icy-veins.com/wow/hunter-leveling-guide>).

1.

### Marksmanship Hunter Leveling Guide for Midnight

Marksmanship Hunter is defined by its front-loaded damage and

solid AoE

capability. It excels the most in dungeons, but can also be a decent questing

leveler, based around killing enemies before they can reach you, usually with a

strong [[spell:19434]] into [[spell:257044]] into [[spell:53351]]

combo.

Grab a Ferocity (ideally a [Scalehide](<https://www.wow-petopia.com/family.php?id=scalehide>)) pet

to use with [[spell:34477]] and [[spell:263865]]. Activate them before

tagging

as many mobs as possible, usually with [[spell:185358]] and

[[spell:257620]], and watch the mobs flock to your pet. Make use

of the pet

damage reduction from [[spell:263865]] and use Marksmanship's strong burst

damage to kill the mobs before they kill your pet.

Here is a neat macro you can use for your [[spell:34477]]. You can make

a macro by typing '/m' in your chat box. Make a Macro, call it "MD", and put

this in it:

```wow-macro
#showtooltip
/use Misdirection
/use Scale Shield
```

If you are using another pet with a defensive ability other than Scale Shield,

just replace 'Scale Shield' with the appropriate ability name.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the highest item

level. The only exception to this rule is if you have a Ring or Necklace with a

slightly lower item level, but two secondary stats on it instead of one.

When using Heirloom items, and when choosing between other pieces of gear, we

recommend prioritizing Critical Strike wherever possible, as it is our strongest

stat.

1.2.

#### Useful Leveling Consumables for Midnight

When Leveling up from 80-90 in the Midnight Expansion in particular, there

are a lot of consumables that can help ease the process, aside from the

"regular" PvE consumables mentioned further below.

- [[item:132516]] — Massive movement speed boost that works when
  
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  
  distances quickly.
- [[item:168412]] — Do not forget this Mount Equipment to
  
  make your mounts faster on the ground.
- [[item:172063]] — An incredible amount of movement speed from a
  
  Food.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), follow the

point-by-point allocation of the below tree as you gain levels. The Leveling

Rotation section below has a slider that shows your rotation at each level.

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwGMwMGNWGAzgNAAAAAAAAwMmxM2mxMzYmBmMGmZbxMzMzMzMzsxMbDzMAAgxMzMAMjNsMDwGzsMDA"
}
```
:::

:::details 来源计算器编码
```
#+D-PqAgDDSNOLLGYTpBMMKiikeHRREoWHu1lcE-SJPOZYXqKCK8bro2AQzElBCEIooLGFO-AAAA-ZauYkAUgQJAZ4A-
```

:::

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider to

select your level, and watch as the leveling rotation grows with each level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 46 起：**Use [[spell:34477]] liberally to transfer all the
   
   threat you generate to your Pet.
2. **等级 78 起：**Use [[spell:1264902]] after your very first
   
   [[spell:19434]] inside each [[spell:288613]] window. This button appears in
   
   place of your Trueshot button once it is activated.
3. **等级 53 起：**Use [[spell:260243]] when available. Place it on the
   
   ground on top of as many enemies as possible!
4. **等级 43 起：**Use [[spell:288613]] for large pulls or difficult elite
   
   mobs.
5. **等级 5 起：**Use [[spell:136]] for large pulls to keep your pet
   
   healthy.
6. **等级 27 起：**Use [[spell:212431]] on cooldown.
7. **等级 13 起：**Use [[spell:257044]] when available.
8. **等级 11 起：**Use [[spell:19434]] when available. **等级 15 起：**Make sure to spend your [[spell:260240]] stacks on
   
   [[spell:185358]]/[[spell:257620]] first!
9. Spam [[spell:185358]].
   
   **等级 10 起：**Use [[spell:257620]]
   
   instead if there are 4 or more targets!
10. **等级 1 起：**Use [[spell:56641]] as a filler, and to generate
    
    Focus.

4.

### Best Leveling Pet

All pets do the same damage, but they vary in their utility and special

abilities. For Marksmanship Hunters, pets are quite weak, and we mostly use them

as an "anchor" to gather mobs onto instead of ourselves. The best pet for this

purpose is a [Scalehide](<https://www.wow-petopia.com/family.php?id=scalehide>). They

have a 1-minute damage reduction ability, [[spell:263865]], that you should

macro into your [[spell:34477]].

Ferocity pets also come with [[spell:264667]], which is a Bloodlust effect.

This should be used as often as possible when you are fighting for over thirty

seconds.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated Heirloom stat advice.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **16 Feb. 2023:** Fixed an issue with the talent order.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Marksmanship Hunter in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Marksmanship Hunter

This section is intended for players who are new to the game or class, have

no intentions of raiding Mythic difficulty, or simply want a more

straightforward way to play their specialization without being overwhelmed by

the numerous priorities and active abilities that need to be taken into

consideration for optimal play.

Marksmanship is perfect for those who enjoy the sniper playstyle, equipped

with a longer range than most specs and tons of bursty AoE damage.

Marksmanship's core loop is to generate [[spell:260240]] via your

primary, hard-hitting abilities like [[spell:19434]] and [[spell:257044]], 

and then spending those [[spell:260240]] on either [[spell:185358]]

(single-target), [[spell:257620]] (3+ targets, or 2+ with

[[spell:470945]]), or [[spell:466932]] 

(constantly when playing the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Hero Talent). Aside from this

loop, you have a filler for Focus and Aimed Shot cooldown reduction in 

[[spell:56641]], and other abilities that are basically just used on

cooldown like [[spell:212431]] and [[spell:260243]].

Here are two quick rules of thumb that will help you when navigating the

spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_snipertraining.jpg>) **Spend All of Your Precise Shots**  
  
  
    Every single [[spell:19434]] and [[spell:257044]] is going to grant
  
    [[spell:260240]], and we want to spend all of these Precise Shots procs
  
    before we cast another Aimed Shot. Spend them on Arcane Shot, or on
  
    Multi-Shot when you have more than one target. Spend them before Rapid Fire
  
    as well, unless Trueshot is up.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_steadyshot.jpg>) **Always be Casting**  
  
  
    Casting as many abilities as possible matters more than pressing the perfect
  
    button every time, and dead time is the single biggest thing holding most
  
    players back from their DPS goals. [[spell:56641]] is how you fill it, and
  
    it is castable while moving, so there is no excuse for a dead global.

2.

### Beginner's Guide to Marksmanship Hunter in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel   Single-Target Talents

2.1.

#### Single-Target Talents for Marksmanship Hunter

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel single-target build.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgx2yMzMzMzMzswMLDmBAAMmZGDgZstBDwGzsNjB"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEGPgkosw048ABFJNRV5CT2GX3H4QRS-AAAA-BEIMQYcAJRZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel   Dungeon Talents

2.2.

#### Dungeon Talent Build for Marksmanship Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for Mythic+, and

other AoE-focused content. It is based on simulating the conditions found in

real Mythic+ dungeons and seeing not just what does the most DPS, but what

actually clears the dungeon quicker in a group. There are builds that do more

AoE, but they all lose more single-target than they gain in terms of AoE, and

vice versa.

2.3.

#### Marksmanship Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzwyYaGDmlttZmZmZmZmZhZWGmBAAwDMGDAzYDMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### Marksmanship Hunter   Basic Rotation

2.4.

#### Basic Rotation for Marksmanship Hunter

Treat this as a priority list of the most important spells to cast. When in

doubt, simply cast the highest priority spell. You should aim to have no

"downtime" in your rotation. It is better to cast the wrong spell immediately

than to "think" for 1 second and then cast the right spell. As you improve, this

priority should become second nature to you.

1. Cast [[spell:212431]].
2. Cast [[spell:260243]]. Make sure to place it
   
   well for optimal AoE coverage.
3. Cast [[spell:288613]] whenever available. It is your primary cooldown,
   
   and it primarily increases the damage of your abilities, specifically
   
   the number of [[spell:19434]]s and [[spell:257044]]s you can cast while
   
   it is active. Use it right before you intend to cast [[spell:257044]]. When
   
   the [[spell:204089]] Talent is used, which is basically all the time, try to
   
   save your last Trueshot of the fight for when the target is below 20% HP.
4. Cast [[spell:53351]] to spend [[spell:260240]] below 20% target
   
   health.
5. Cast [[spell:185358]] with [[spell:260240]]. This is indicated by
   
   the blue arrow graphic around your character, and always procs after every 
   
   single [[spell:19434]] and [[spell:257044]]. On 3 targets and above, cast
   
   [[spell:257620]] instead, or on 2 and above with
   
   [[spell:470945]].
6. Cast [[spell:257044]].
7. Cast [[spell:1264902]]. This ability replaces your [[spell:288613]]
   
   button once Trueshot is activated, and can be used once. It grants you an
   
   instant [[spell:19434]], generally fired right afterwards.
8. Cast [[spell:19434]].
9. Cast [[spell:56641]] as a filler when you can do none of the above.

2.4.1.

##### Apex Talent: ![Take Aim Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_efficiency.jpg>) Take Aim

Your Apex Talents have no impact on how you play. They just increase your

damage passively and are best taken advantage of by doing the "baseline"

rotation as described above.

2.4.2.

##### Season 2 Tier Set

The Midnight Season 2 Tier Set has a subtle impact on our rotation. It will

extend the duration (and therefore the damage) of your [[spell:212431]],

and cause those ticks to reduce the cooldown of [[spell:19434]] and

[[spell:257044]] by 0.5s per tick. On two or more targets, since

[[spell:473520]] gives you two [[spell:212431]]s back-to-back, we prefer to

cast them on two different targets (unless there is a priority target up),

because we want to maximize this cooldown reduction effect. The damage is the

same as if we cast both on 1 target, but because the cooldown reduction scales

with the <em>number of ticks</em>, it is better to spread them out.

### Marksmanship Hunter   Defensive Spells

2.5.

#### Defensive Spells for Marksmanship Hunter

[[spell:109304]] is your primary self-heal with a 1-minute cooldown. Use

this when you drop below 50% HP to help out your Healer!

[[spell:186265]] is your immunity. It can be used to completely

negate the damage and effects of most spells targeted on you. Use it if you are

assigned to, or in a pinch if you worry that an upcoming mechanic will kill you!

It is also a 30-50% damage reduction, though it is not so commonly used for

simple damage reduction purposes.

[[spell:264735]] is our most powerful defensive besides

Turtle, a 30-40% damage reduction with 2 charges on a 1.5-minute cooldown each.

Use it to reduce damage taken from hard-hitting mechanics. Optimal use of this

ability entails using it **proactively**, before heavy incoming damage.

[[spell:5384]] is a very unique Hunter ability. It can be used to drop

aggro and combat, and it can also be used to stop casts on you. Mobs will

usually stop casting mid-cast if you appear to be dead! With the

[[spell:459517]] Talent, it will also dispel all Poison and Disease

effects from you.

### Marksmanship Hunter   Stat Priority

2.6.

#### Stat Priority for Marksmanship Hunter

The general stat priority for a Marksmanship Hunter is seen below.

For more information on what's presented on this page, check out our main 

[Stat Priority page](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>).

Critical Strike

Mastery

Versatility

Haste

Crit is our strongest stat, with Mastery close behind. In a perfect world,

every item you own has Crit on it, with Mastery as its second stat.

Versatility is clearly behind Mastery.

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant & One-Button Mode

The game offers the option of an in-game "Combat Assistant", which has two 

modes: a Rotation Helper that will suggest spells to cast next, and a 

"One-Button Mode", that automatically performs this rotation for you if you 

simply press one button repeatedly.

These tools can be worthwhile for beginners, as they provide a reasonable 

"minimum" level of performance. For Marksmanship Hunter, using just 

the Rotation Helper is a ~6-10% DPS loss compared to playing perfectly (which 

almost nobody does). Using the one-button mode on top of it takes the total 

loss to ~13-15%.

Obviously, peak performance cannot be obtained using these tools, but it is 

something worth considering if you are happy to take the DPS losses above for 

the sake of ease of play. Do not let anyone in-game or on a forum or Discord 

tell you that there is something inherently wrong with using these tools! 

Blizzard created them for a reason, and the game is about having fun, whatever 

that means for you.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **22 Aug. 2026:** Rapid Fire no longer needs Precise Shots spent first.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Added Trueshot to the beginner priority list.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **27 Aug. 2025:** Simplified the Rotation further.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **14 Feb. 2024:** Updated the recommended default Mythic+ Talent Build.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **27 Jun. 2023:** Updated the Talent Builds.
- **04 May 2023:** Updated the recommended AoE Talent Build. This is likely a temporary change, until the new Tier Set becomes more widespread.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated the page for relevant changes in Patch 10.0.5.
- **17 Jan. 2023:** Updated the recommended Single-Target Talent Build.
- **23 Dec. 2022:** Talent updates.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Marksmanship Hunter in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Marksmanship Hunter

Marksmanship plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel in all content, with no exceptions.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger is a bit tankier, but Sentinel does more damage and is far

easier to play. We provide Dark Ranger builds below for those who prefer the

playstyle or thematic fantasy.

- Single-Target: ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel is played in all situations, even though it
  
    is slightly less tanky than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger. It simply performs better on
  
    every metric, and is also easier to play.
- AoE: Just like in single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel is the go-to choice everywhere.
  
    It has the best DPS on every target count, while being easier to play. While it has
  
    slightly worse survivability than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger, that does not come into play
  
    until pushing the absolute top keys, and even then you are typically able to rely on your
  
    teammates to help you survive, so you can unload Sentinel's superior DPS.

1.1.

#### Fitting in Tenacious

[[spell:474456]] and Cunning are our version of having a pet. You pick

between 5% extra health with 3% damage reduction, or 8% Movement Speed with

[[spell:53271]], which is a freedom effect you can use on yourself or on

anyone else. Neither of them do anything for your damage.

Our builds run [[spell:474456]] by default. In Patch 12.1.5, it is a DPS

loss to take Tenacious or Cunning, anywhere from 0.6% to 1.7% depending on

the exact scenario. If you are doing anything considered "competitive"

content, which in our opinion is anything that you find to be challenging,

the loss is worth taking. That said, if you just want to deal the max damage

possible, here are the talents you would swap to for each build:

- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Single Target -** Swap to [[spell:378769]] to
  
    gain around 0.6% DPS.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Raid Cleave -** Swap to
  
    [[spell:471428]] to gain around 1.3% DPS.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ and Delves -** Swap to
  
    [[spell:471428]] to gain around 1.4% DPS.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Single Target -** Swap to
  
    [[spell:389019]] to gain around 1.4% DPS.
- **![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ and Delves -** Swap to
  
    [[spell:389019]] to gain around 1.7% DPS.

**Quick Start Import Codes:**

:::talents Marksmanship Single-Target - Sentinel
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGzYZAjZwGAAAAAAAAYGzYmFzYmZMDGTzYwYbZmZmZmZmZWYmlBzAAAGzMjBwM22gBYjZ2mxAA"
}
```
:::

:::talents Marksmanship Raid AoE/Cleave - Sentinel
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz222MzMzMzMzswMLDzAAAMmZGAMjtNYA2YmtZMA"
}
```
:::

:::talents Marksmanship Mythic+ - Sentinel
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGQmBbAAAAAAAAgZMzMjtZMzMmhlx0MGMLbbzMzMzMzMzCzsMMDAAgHYMGAmxGYA2YmtZMA"
}
```
:::

:::talents Marksmanship Delves - Sentinel
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGzYZAjZwGAAAAAAAAYGzMzgxMzYmhx0wgZZbbmZmZmZmZWwsNMDAAwMjxAwM2wyMAbMz2MG"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Sentinel

Single-Target

recommended

Raid AoE/Cleave

recommended

Mythic+

recommended

Delves

recommended

Dark Ranger

Single-Target

Mythic+

Delves

### 天赋方案 0-0

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Single-Target Talents

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel single-target build. It keeps
[[spell:260243]] and [[spell:212431]], which the Season 2 tier set is built
around, and focuses on generating and spending [[spell:260240]]. While raiding,
we recommend playing this build any time pure single-target is called for.

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Raid AoE/Cleave Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for cleave-heavy fights. It is
built around [[spell:470945]], grabbing efficient AoE talents like Hydra
and [[spell:378913]] to dish out excellent cleave damage while essentially just
performing a single-target rotation. Since the raid is so heavy on cleave, this
is the build you will use throughout most of it.

### 天赋方案 0-2

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for Mythic+, and
other AoE-focused content. It is based on simulating the conditions found in
real Mythic+ dungeons and seeing not just what does the most DPS, but what
actually clears the dungeon quicker in a group. There are builds that do more
AoE damage, but they all lose more single-target than they gain in terms of AoE,
and vice versa.

We run [[spell:257621]] in AoE, swapping out [[spell:185358]] for
[[spell:257620]] to make our abilities do AoE damage. You can also
play this build on raid fights that are overwhelmingly single-target but still
have occasional bouts of cleave and burst AoE, though that is not a decision to
take lightly, as padding AoE is rarely the most effective way to improve your
group's chances of success.

1.5.

#### Marksmanship Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of "most
  disposable":
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    in others.

### 天赋方案 0-3

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Delve Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is
similar to our Mythic+ Talent build, but differs on the Class Tree picks to be
more suitable for solo play with a pet tanking.

### 天赋方案 1-0

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Single-Target Talents

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger single-target build, used for
bosses that are overwhelmingly pure single-target with no stacked adds or AoE
opportunities.

### 天赋方案 1-1

1.8.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger build for Mythic+, and
other AoE-focused content. It is based on simulating the conditions found in
real Mythic+ dungeons and seeing not just what does the most DPS, but what
actually clears the dungeon quicker in a group. There are builds that do more
AoE damage, but they all lose more single-target than they gain in terms of AoE,
and vice versa.

1.9.

#### Marksmanship Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of "most
  disposable":
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    in others.

### 天赋方案 1-2

1.10.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Delve Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is
similar to our Mythic+ Talent build, but differs on the Class Tree picks to be
more suitable for solo play with a pet tanking.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgx2yMzMzMzMzswMLDmBAAMmZGDgZstBDwGzsNjB"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEGPgkosw048ABFJNRV5CT2GX3H4QRS-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmxMLmxMzYGMmmxgZbbbmZmZmZmZWYmlhZAAAGzMDAmx2GMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEFNeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzwyYaGDmlttZmZmZmZmZhZWGmBAAwDMGDAzYDMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmBjZmxMDjphBzy22MzMzMzMzsgZbYGAAgZGjBgZshlZA2YmtZMA"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHLLMMNOPRRSTWWYaeffgiikoSVXD-AEFMeEJRZhpx5BCKSaiqyF2MttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYGzsYGzMjZwYaGDGbLzYmZmZmZWYmlBDAAwYmZMzMDIbwAsxMbzMD"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEGHIUWWYYaceiikssw0268ADFFHLruG-AEGPgksw048ABFJNRV5CT2Wn3H4QxRS-AAAA-AGIYgow4ApyCTD-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYmZGbzYmZMDLjpZMYW2MjZmZmZmZhZWGmBAAwDMGzMzMgAGgNmZZGD"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMiksw048ABFJNRV5CTm2Wn3HoQRS-AAAA-AGIYgow4ApyCTD-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYmZGMmZGzMMmGGMLbmxMzMzMzsgZbYGAAgZGjZmZGQwyMAbMzyMG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHLLMMNOPRRSTWWYaeffgiikoSVXD-AEFMiksw048ABFJNRV5Cbm2Wn3HoQRS-AAAA-AGIYgow4ApyCTD-
```

:::

The builds listed above are popular recommendations,

covering various different loadouts suited to each style of endgame content.

Each Talent Build will have its own rotation, and can also be manipulated 

further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is the "borrowed power" system introduced in Midnight's

[Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers

some moderately strong customization options after a short questline.

Some of these bonuses affect your damage output, but there are also defensive

and mobility options to choose from.

Your Folio progress carries over into Season 2. Take these bonuses:

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279609]]. This one is the most 
  
    flexible and may change as your gear's stat demands do, just like your Flask 
  
    or Weapon Enchant. Crit is a safe "never bad" pick, but if you have lots
  
    (1300+) of 
  
    it, you may consider Mastery instead (or sim it).
- [[spell:1279614]]

3.

### Apex Talent: ![Take Aim Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_efficiency.jpg>) Take Aim

Midnight introduces new Apex Talents, unlocked between Level 80 and 90.

Marksmanship gets:

1. [[spell:1273132]]
2. [[spell:1273129]]
3. [[spell:1273128]]

[[spell:1273132]] increases [[spell:257044]] damage by 25%, and each shot

it fires reduces the cooldown of [[spell:19434]] by 0.5 seconds, which comes

to 5 seconds over a full channel. [[spell:1273129]] increases the critical

damage of your abilities by 5% and the damage of your ranged abilities by 3%,

rising to 10% and 6% at its second point. [[spell:1273128]] makes

[[spell:466872]] also increase the damage of your next [[spell:257044]]

against the target by 20%.

4.

### Hero Talents for Marksmanship Hunter

Available at level 71, Hero talents are mutually exclusive trees you can

choose to slightly alter gameplay and visuals. Marksmanship Hunter can choose

between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger replaces your talented [[spell:53351]] ability with 

[[spell:466932]], which deals heavy damage. In addition to being freely 

usable (with a 10-second cooldown) on targets above 80% or below 20% HP, you 

will regularly get [[spell:378769]] procs that let you use it on any target

at any time. [[spell:257044]] gives a guaranteed proc, and [[spell:19434]]

has a 20% chance to make your next [[spell:19434]] grant one.

When you pop [[spell:288613]], the Trueshot button will turn into

[[spell:392060]], a very powerful ability that also gives us a free 

[[spell:466932]] proc on use. We cast it as soon as we have no 

[[spell:466932]] proc coming up, usually after a

[[spell:257044]] → [[spell:466932]] combo.

Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger offers [[spell:430709]], which is 

simply amazing, as it gives us extremely easy access to our 

[[spell:264735]] nearly all the time.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel is our simplest Hero Talent, adding almost nothing in terms 

of gameplay intrigue or complexity, replacing [[spell:466872]] with 

[[spell:1253601]], which is simply more powerful in every way. In 

addition, when you activate [[spell:288613]], the Trueshot button itself will 

turn into [[spell:1264902]], a filler ability that does heavy damage on 

use. We only get one use of it, so on single-target we cast it with around 5 

seconds left on [[spell:288613]] (since its bounces take a long time to finish on single-target), and on AoE right before Trueshot expires (as its bounces are over quickly on AoE).

Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel gives us [[spell:450373]], which procs 

nearly constantly and offers a great deal of passive tankiness.

5.

### PvP Talents (War Mode)

**These picks are for open world PvE content with War Mode enabled, not for

actual PvP.**

War Mode offers several benefits for you in the open world.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is

recommended to enable the feature to maximize your leveling and rewards at

maximum level. However, you will be flagged for open-world PvP, and the

possibility of being "ganked" while leveling or doing World Quests exists.

- [[spell:1219162]] lets you cast [[spell:19434]] while moving
  
  during [[spell:186257]], and it extends the slower second half of
  
  that sprint by 4 seconds.
- [[spell:203235]] is a valuable speed increase for leveling and open
  
  world content.
- [[spell:1217102]] increases the range of all your shots by 30%
  
  during [[spell:288613]] and [[spell:260243]], which can be useful for big elites
  
  especially.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **22 Aug. 2026:** Mythic+ and Delves Sentinel builds now take On Target over Obsidian Arrowhead.
- **22 Aug. 2026:** Mythic+ and Delves Sentinel builds now take Open Fire over Stargazer.
- **18 Aug. 2026:** Updated the Utility Talents for Raid builds.
- **17 Aug. 2026:** The Omnium Folio setup now takes Void-Tainted Shell over Self-Mending.
- **16 Aug. 2026:** Mythic+ and Delves Sentinel builds now take Stargazer over Open Fire, a small gain now that Rapid Fire clipping consumes Precise Shots more often.
- **12 Aug. 2026:** Updated Delve build Class Tree to pick up Unbreakable Bond (for a pet).
- **12 Aug. 2026:** Delve builds now take Emergency Salve over Wilderness Medicine.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Clarified Hero Talent build guidance.
- **17 Jun. 2026:** Updated recommended week 1 Folio Rune based on real-world data trumping sims.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **21 May 2026:** Updated guidance on the Sentinel Raid AoE Build.
- **07 May 2026:** Updated Sentinel Raid AoE Build.
- **06 May 2026:** Updated Sentinel M+ Build. Still very bad in all M+ situations.
- **04 May 2026:** Updated for tuning.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated Talent build note for Vaelgor and Ezzorak.
- **25 Mar. 2026:** Updated the baseline Raid AOE build.
- **22 Mar. 2026:** Swapped Sentinel M+ Build to Stalk and Strike over Twilight Requiem in the Sentinel Tree, for identical sim performance but a microscopic mobility benefit.
- **19 Mar. 2026:** Updated Delve build.
- **17 Mar. 2026:** Added simple explainer for the Hydra Build. Updated the Hydra Build for a bit more AoE. Fixed single-target build error.
- **16 Mar. 2026:** Updated Sentinel Mythic+ Build.
- **03 Mar. 2026:** Updated Talent Builds and added Dark Ranger builds.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Builds for the upcoming 12.0.1 changes.
- **23 Jan. 2026:** Updated Stat Diminishing Returns values for Level 80.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **02 Sep. 2025:** Updated DR M+ Talent Build, specifically utility picks.
- **27 Aug. 2025:** Expanded on reasoning for 1.5-min and 1-min builds.
- **26 Aug. 2025:** Updated note on swapping between Unerring Vision and Calling the Shots for Dark Ranger M+. Removed note on Focused Aim as Improved Streamline is equal, even on paper, and better in practice. Update Raid AoE build.
- **25 Aug. 2025:** Updated single-target talent default to Improved Streamline rather than Focused Aim.
- **12 Aug. 2025:** Microscopic single-target talent update for Dark Ranger.
- **11 Aug. 2025:** Updated Mythic+ Talent Build recommendation.
- **08 Aug. 2025:** Updated single-target rotation default utility picks for the Raid.
- **07 Aug. 2025:** Updated the S3 Single-Target build to be the same as the S2 4PC one!
- **06 Aug. 2025:** Dark Ranger S2 4PC Talents and Sent M+ Class Tree talent update.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **26 May 2025:** Added note on Salvo vs Ohn'ahran Winds.
- **17 May 2025:** Updated the Raid AoE Build to grab Volley, since most AoE in the Raid is very short-term.
- **15 May 2025:** Updated the Sentinel Mythic+ build to grab Ohn'ahran Winds, as evidence suggests that it has been fixed and now works properly in Mythic+ keys.
- **21 Apr. 2025:** Updated the default Dark Ranger M+ Build on the Talents Page, mostly to stem confusion.
- **04 Apr. 2025:** Updated the Sentinel Mythic+ Build to account for Ohn'ahran Winds being bugged.
- **02 Apr. 2025:** Reverted yesterday's change on ST Build. Updated with new M+ Build.
- **01 Apr. 2025:** Updated the Single-Target Talent Builds in light of recent simulation updates.
- **30 Mar. 2025:** Added note on Small Game Hunter viability.
- **25 Mar. 2025:** Updated for the March 25th Hotfixes.
- **18 Mar. 2025:** Updated the Mythic+ Talent Build. Added a note about Volley to it.
- **14 Mar. 2025:** Updated defaults to assume 4PC.
- **04 Mar. 2025:** Added note on M+ Talent changes with and without 4PC, and updated the default temporarily.
- **27 Feb. 2025:** Updated the Sentinel Mythic+ Talent Build in light of recent simulation tool developments.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **27 Dec. 2024:** Updated to take Dark Ranger bugs and the resulting power spike into account.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **23 Oct. 2024:** Updated to Dark Ranger default recommendation while everything is in a bugged state.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **07 Oct. 2024:** Updated the Marksmanship Dark Ranger Single-Target Build.
- **28 Sep. 2024:** Updated the M+ Talent Build - one-point swap.
- **14 Sep. 2024:** Added the Raid AoE build to the page. Updated the single-target builds.
- **10 Sep. 2024:** Updated the single-target talents slightly (one-point change for 0.2% DPS).
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **25 Jul. 2024:** Updated the Single-Target Talent Build.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **14 Feb. 2024:** Updated the recommended default Mythic+ Talent Build.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **04 Dec. 2023:** Updated Talents for Mythic+.
- **27 Nov. 2023:** Updated Talents for Mythic+.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Restructured the page and updated for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **27 Jun. 2023:** Additional Talent Change, and moved Steel Trap to be default for single-target.
- **26 Jun. 2023:** Updated the single-target build to account for new tuning.
- **25 May 2023:** Updated the recommended builds to assume the set bonus as default.
- **19 May 2023:** Updated the layout of the page and added an alternative, cooldown-less build.
- **15 May 2023:** Added note on Steel Trap and when you might want to use it.
- **12 May 2023:** Clarified talent changes for AoE as well as single-target with the 4PC Bonus.
- **09 May 2023:** Added note of how the build changes with the 4PC Set Bonus.
- **08 May 2023:** Updated the recommended single-target talent build to pick Steady Focus.
- **04 May 2023:** Updated the recommended AoE/M+ Talent Build. This is likely a temporary change, until the new Tier Set becomes more widespread.
- **01 May 2023:** Reviewed for Patch 10.1.
- **21 Mar. 2023:** Updated the talents for the 10.0.7 talent reshuffle.
- **15 Feb. 2023:** Updated the utility talents in the M+ Build.
- **30 Jan. 2023:** Small updates to talent swaps.
- **25 Jan. 2023:** Updated the Talent Builds again after the discovery of a sim bug. Added alternative to Steady Focus. Changed the "swap" talent for Wailing Arrow to Bullseye.
- **24 Jan. 2023:** Updated the page for relevant changes in Patch 10.0.5.
- **21 Jan. 2023:** Fixed a wrong note about which talent to swap for Ammo Talents.
- **17 Jan. 2023:** Updated the recommended Single-Target Talent Build.
- **23 Dec. 2022:** Updated the recommended builds to reflect that Unerring Vision is fixed and worth using again.
- **18 Dec. 2022:** Updated the recommended talent builds to reflect that Unerring Vision is bugged.
- **16 Dec. 2022:** Added note that you do not need to use Serpent Sting manually with Hydra's Bite.
- **11 Dec. 2022:** Updated the recommended single-target talent build in light of recent buffs.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Marksmanship Hunter in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Marksmanship Hunter Gameplay and Rotation Guide

Welcome to our Rotation page for Marksmanship Hunters. On this

page, you will find everything you need to know about actually playing the spec

in Raiding and Mythic+ scenarios.

The rotation here, aside from the more concrete openers, is laid out in a

**conditional priority list**. Essentially, for every single spell that you

cast, you should cast the highest-priority spell you can, **for which the

conditions are met.** After the spell is cast, you should start over from the

top of the priority list, and repeat the process.

The buttons below can be used to select between curated **Single-Target**

and **AoE/Mythic+** loadouts, with an extra **Hydra Cleave** loadout under

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel. You can also use the switches below to add or remove

individual talents you may also be using.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

Single Target

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Hydra Cleave

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:212431]]

[[spell:53351]]

[[spell:260243]]

[[spell:473520]]

[[spell:1301406]]

[[spell:257621]]

[[spell:470945]]

[[spell:1296634]]

[[spell:378769]]

### Single-Target Rotation

1.1.

#### Single-Target Opener for Marksmanship Hunter

Ensure [[spell:257284]] is active on your primary target.

---

**适用条件：Dark Ranger（启用）。**

[[spell:19434]]

2.5s

Pull

[[spell:466932]]

**适用条件：Explosive Shot（启用）。**

[[spell:212431]]

**适用条件：Explosive Shot（启用）；Unstable Trigger（启用）。**

[[spell:212431]]

**适用条件：Volley（启用）。**

[[spell:260243]]

[[spell:288613]]

[[item:241288]]

[[spell:19434]]

[[spell:466932]]

**适用条件：Sentinel（启用）。**

[[spell:19434]]

2.5s

Pull

**适用条件：Explosive Shot（启用）。**

[[spell:212431]]

**适用条件：Explosive Shot（启用）；Unstable Trigger（启用）。**

[[spell:212431]]

**适用条件：Volley（启用）。**

[[spell:260243]]

[[spell:288613]]

[[item:241288]]

[[spell:257044]]

[[spell:185358]]

[[spell:19434]]

[[spell:185358]]

---

1. **适用条件：Dark Ranger（启用）。** [[spell:19434]] around 2.5 seconds before combat begins.
2. **适用条件：Dark Ranger（启用）。** [[spell:466932]]
3. **适用条件：Dark Ranger（启用）；Explosive Shot（启用）。** [[spell:212431]]
4. **适用条件：Dark Ranger（启用）；Explosive Shot（启用）；Unstable Trigger（启用）。** [[spell:212431]]
5. **适用条件：Dark Ranger（启用）；Volley（启用）。** [[spell:260243]]
6. **适用条件：Dark Ranger（启用）。** [[spell:288613]], alongside your Potion, on-use Trinket, Racials, etc.
7. **适用条件：Dark Ranger（启用）。** [[spell:19434]]
8. **适用条件：Dark Ranger（启用）。** [[spell:466932]]
9. **适用条件：Dark Ranger（启用）。** Continue with the priority list as described below.
10. **适用条件：Sentinel（启用）。** [[spell:19434]] around 2.5 seconds before combat begins.
11. **适用条件：Sentinel（启用）；Explosive Shot（启用）。** [[spell:212431]]
12. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Unstable Trigger（启用）。** [[spell:212431]]
13. **适用条件：Sentinel（启用）；Volley（启用）。** [[spell:260243]]
14. **适用条件：Sentinel（启用）。** [[spell:288613]], alongside your Potion, on-use Trinket, Racials, etc.
15. **适用条件：Sentinel（启用）。** [[spell:257044]]
16. **适用条件：Sentinel（启用）。** [[spell:185358]]
17. **适用条件：Sentinel（启用）。** [[spell:19434]]
18. **适用条件：Sentinel（启用）。** [[spell:185358]]
19. **适用条件：Sentinel（启用）。** Continue with the priority list as described below.

1.2.

#### Single-Target Priority List for Marksmanship Hunter

Below is the priority system that describes the optimal single-target rotation for Marksmanship Hunter.

1. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Unstable Trigger（启用）。** Cast [[spell:212431]] on cooldown. Thanks to [[spell:473520]], you can cast it twice in a row and should do so.
2. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Tactical Reload（启用）。** Cast [[spell:212431]] on cooldown, unless [[spell:194595]] is already up.
3. **适用条件：Sentinel（启用）；Volley（启用）。** Cast [[spell:260243]] on cooldown.
4. **适用条件：Sentinel（启用）。** Cast [[spell:288613]] on cooldown, holding the last one of the fight for 30 stacks of [[spell:204089]]. Delay it by up to 15 seconds if [[spell:212431]] is about to come off cooldown, so that you can send the Explos right before entering [[spell:288613]].
5. **适用条件：Sentinel（启用）。** Before you press [[spell:288613]], swap to a target that does not already have [[spell:1253601]] - <em>Click for Details</em>
   
   
   [[spell:470943]] makes [[spell:288613]] apply [[spell:1253601]] to whatever you have targeted when you press it, so pressing [[spell:288613]] on a target that is already marked wastes it.
6. **适用条件：Sentinel（启用）。** Cast [[spell:1264902]] with around 5 seconds left on [[spell:288613]].
7. **适用条件：Sentinel（启用）；Aspect of the Hydra（未启用）。** Cast [[spell:19434]] during [[spell:288613]] when you have no [[spell:260240]].
8. **适用条件：Sentinel（启用）；Aspect of the Hydra（启用）。** Cast [[spell:19434]] during [[spell:288613]] when you have no [[spell:260240]] and only one target is up.
9. **适用条件：Sentinel（启用）；Aspect of the Hydra（未启用）。** Cast [[spell:257044]] on cooldown if you have no [[spell:260240]] to spend, or if [[spell:288613]] is up.
10. **适用条件：Sentinel（启用）；Aspect of the Hydra（启用）。** Cast [[spell:257044]] on cooldown if you have no [[spell:260240]] to spend, if [[spell:288613]] is up, or if more than one target is up.
11. **适用条件：Kill Shot（启用）；Sentinel（启用）。** Cast [[spell:53351]] to spend [[spell:260240]].
12. **适用条件：Deathblow（启用）；Kill Shot（启用）；Sentinel（启用）。** Cast [[spell:53351]] to spend [[spell:260240]] whenever [[spell:378769]] procs.
13. **适用条件：Sentinel（启用）；Aspect of the Hydra（启用）。** Cast [[spell:257620]] instead of [[spell:185358]] to spend [[spell:260240]] on more than one target, unless you are focusing a priority target.
14. **适用条件：Sentinel（启用）。** Cast [[spell:185358]] to spend [[spell:260240]].
15. **适用条件：Sentinel（启用）。** Cast [[spell:19434]] on cooldown, preferring targets with [[spell:1253601]] unless you are focusing a priority target.
16. **适用条件：Sentinel（启用）。** Cast [[spell:1264902]].
17. **适用条件：Sentinel（启用）。** Cast [[spell:56641]].
18. **适用条件：Dark Ranger（启用）。** Cast [[spell:466932]] if you have [[spell:260240]].
19. **适用条件：Explosive Shot（启用）；Dark Ranger（启用）；Unstable Trigger（启用）。** Cast [[spell:212431]] on cooldown. Thanks to [[spell:473520]], you can cast it twice in a row and should do so.
20. **适用条件：Explosive Shot（启用）；Dark Ranger（启用）；Tactical Reload（启用）。** Cast [[spell:212431]] on cooldown, unless [[spell:194595]] is already up.
21. **适用条件：Dark Ranger（启用）；Volley（启用）。** Cast [[spell:260243]] on cooldown.
22. **适用条件：Dark Ranger（启用）。** Cast [[spell:19434]] during [[spell:288613]] with no [[spell:260240]] if [[spell:466932]] is ready, or if [[spell:19434]] is about to reach 2 charges.
23. **适用条件：Dark Ranger（启用）。** Cast [[spell:288613]] on cooldown, holding the last one of the fight for 30 stacks of [[spell:204089]]. Delay it by up to 15 seconds if [[spell:212431]] is about to come off cooldown, so that you can send the Explos right before entering [[spell:288613]].
24. **适用条件：Dark Ranger（启用）。** Before you press [[spell:288613]], swap to a target that does not already have [[spell:466872]] - <em>Click for Details</em>
    
    
    [[spell:470943]] makes [[spell:288613]] apply [[spell:466872]] to whatever you have targeted when you press it, so pressing [[spell:288613]] on a target that is already marked wastes it.
25. **适用条件：Dark Ranger（启用）。** Cast [[spell:257044]] on cooldown.
26. **适用条件：Dark Ranger（启用）。** Cast [[spell:392060]] on cooldown.
27. **适用条件：Dark Ranger（启用）；Aspect of the Hydra（启用）。** Cast [[spell:257620]] instead of [[spell:185358]] to spend [[spell:260240]] on more than one target, unless you are focusing a priority target.
28. **适用条件：Dark Ranger（启用）。** Cast [[spell:185358]] to spend [[spell:260240]].
29. **适用条件：Dark Ranger（启用）。** Cast [[spell:19434]] on cooldown.
30. **适用条件：Dark Ranger（启用）。** Cast [[spell:466932]].
31. **适用条件：Dark Ranger（启用）。** Cast [[spell:56641]].

### AoE Rotation

1.3.

#### AoE Opener for Marksmanship Hunter

Ensure [[spell:257284]] is active on your primary target.

**适用条件：Trick Shots（启用）。**

---

**适用条件：Dark Ranger（启用）；Trick Shots（启用）。**

[[spell:19434]]

2.5s

Pull

**适用条件：Explosive Shot（启用）。**

[[spell:212431]]

**适用条件：Volley（启用）。**

[[spell:260243]]

[[spell:19434]]

[[spell:466932]]

[[spell:288613]]

[[item:241288]]

[[spell:257044]]

[[spell:19434]]

[[spell:466932]]

**适用条件：Sentinel（启用）；Trick Shots（启用）。**

[[spell:19434]]

2.5s

Pull

**适用条件：Explosive Shot（启用）。**

[[spell:212431]]

**适用条件：Explosive Shot（启用）；Hunter Marksmanship 12.1 Class Set 4pc（启用）；Unstable Trigger（启用）。**

[[spell:212431]]

**适用条件：Volley（启用）。**

[[spell:260243]]

[[spell:288613]]

[[item:241288]]

[[spell:257620]]

[[spell:257044]]

[[spell:257620]]

[[spell:19434]]

**适用条件：Trick Shots（启用）。**

---

1. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:19434]] around 2.5 seconds before combat begins.
2. **适用条件：Dark Ranger（启用）；Explosive Shot（启用）；Trick Shots（启用）。** [[spell:212431]]
3. **适用条件：Dark Ranger（启用）；Volley（启用）；Trick Shots（启用）。** [[spell:260243]]
4. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:19434]]
5. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:466932]]
6. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:288613]], alongside your Potion, on-use Trinket, Racials, etc.
7. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:257044]]
8. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:19434]]
9. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** [[spell:466932]]
10. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Continue with the priority list as described below.
11. **适用条件：Sentinel（启用）；Trick Shots（启用）。** [[spell:19434]] around 2.5 seconds before combat begins.
12. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Trick Shots（启用）。** [[spell:212431]]
13. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Hunter Marksmanship 12.1 Class Set 4pc（启用）；Unstable Trigger（启用）；Trick Shots（启用）。** [[spell:212431]] on a second target
14. **适用条件：Sentinel（启用）；Volley（启用）；Trick Shots（启用）。** [[spell:260243]]
15. **适用条件：Sentinel（启用）；Trick Shots（启用）。** [[spell:288613]], alongside your Potion, on-use Trinket, Racials, etc.
16. **适用条件：Sentinel（启用）；Trick Shots（启用）。** [[spell:257620]]
17. **适用条件：Sentinel（启用）；Trick Shots（启用）。** [[spell:257044]]
18. **适用条件：Sentinel（启用）；Trick Shots（启用）。** [[spell:257620]]
19. **适用条件：Sentinel（启用）；Trick Shots（启用）。** [[spell:19434]]
20. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Continue with the priority list as described below.

**适用条件：Trick Shots（未启用）。** Without [[spell:257621]], the single-target and AoE opener are the same, so please refer to the single-target section for more information!

1.4.

#### AoE Priority List for Marksmanship Hunter

**适用条件：Trick Shots（启用）。** Below is the priority system that describes the optimal AoE rotation for Marksmanship Hunter.

**适用条件：Trick Shots（未启用）。** Without [[spell:257621]], the single-target and AoE rotation are the same, so please refer to the single-target section for more information!

**适用条件：Aspect of the Hydra（启用）。** Hydra Cleave is the raid cleave build: it grabs efficient AoE talents and performs a single-target rotation, spending [[spell:260240]] on [[spell:257620]] from 2 targets up.

1. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Trick Shots（启用）；Unstable Trigger（启用）。** Cast [[spell:212431]]. With [[spell:473520]], you can cast two in a row. Spread them across two targets unless there is a priority target up.
2. **适用条件：Sentinel（启用）；Explosive Shot（启用）；Tactical Reload（启用）；Trick Shots（启用）。** Cast [[spell:212431]], unless [[spell:194595]] is already up.
3. **适用条件：Sentinel（启用）；Volley（启用）；Trick Shots（启用）。** Cast [[spell:260243]] on cooldown.
4. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:288613]] on cooldown, holding the last one of the fight for 30 stacks of [[spell:204089]]. Delay it by up to 15 seconds if [[spell:212431]] is about to come off cooldown, so that you can send the Explos right before entering [[spell:288613]].
5. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Before you press [[spell:288613]], swap to a target that does not already have [[spell:1253601]] - <em>Click for Details</em>
   
   
   [[spell:470943]] makes [[spell:288613]] apply [[spell:1253601]] to whatever you have targeted when you press it, so pressing [[spell:288613]] on a target that is already marked wastes it.
6. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:1264902]] if [[spell:288613]] is about to expire.
7. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:257620]] to spend [[spell:260240]], or to activate [[spell:257621]] if it is down. Use the Mouseover Multi-Shot macro on the Macros page for it. Always prefer to use it on targets that do not already have [[spell:1253601]].
8. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:257044]] on cooldown with [[spell:257621]] up.
9. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:19434]] on cooldown with [[spell:257621]] up, preferring targets with [[spell:1253601]] unless you are focusing a priority target. The [[spell:257621]] bounces only consume [[spell:1253601]] if your primary target is marked as well.
10. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:1264902]].
11. **适用条件：Sentinel（启用）；Trick Shots（启用）。** Cast [[spell:56641]].
12. **适用条件：Dark Ranger（启用）；Explosive Shot（启用）；Trick Shots（启用）；Unstable Trigger（启用）。** Cast [[spell:212431]]. With [[spell:473520]], you can cast two in a row. Spread them across two targets unless there is a priority target up.
13. **适用条件：Dark Ranger（启用）；Explosive Shot（启用）；Tactical Reload（启用）；Trick Shots（启用）。** Cast [[spell:212431]], unless [[spell:194595]] is already up.
14. **适用条件：Dark Ranger（启用）；Volley（启用）；Trick Shots（启用）。** Cast [[spell:260243]] on cooldown.
15. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:19434]] with [[spell:257621]] up if it is about to reach 2 charges.
16. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:466932]] if you have [[spell:260240]].
17. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:257620]] to activate [[spell:257621]] if it is down.
18. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:288613]] on cooldown, holding the last one of the fight for 30 stacks of [[spell:204089]]. Delay it by up to 15 seconds if [[spell:212431]] is about to come off cooldown, so that you can send the Explos right before entering [[spell:288613]].
19. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Before you press [[spell:288613]], swap to a target that does not already have [[spell:466872]] - <em>Click for Details</em>
    
    
    [[spell:470943]] makes [[spell:288613]] apply [[spell:466872]] to whatever you have targeted when you press it, so pressing [[spell:288613]] on a target that is already marked wastes it.
20. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:257044]] with [[spell:257621]] up.
21. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:392060]] if [[spell:466932]] is not ready.
22. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:257620]] to spend [[spell:260240]].
23. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:19434]] on cooldown with [[spell:257621]] up.
24. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:466932]].
25. **适用条件：Dark Ranger（启用）；Trick Shots（启用）。** Cast [[spell:56641]].

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier Set has a subtle impact on our rotation. It will

extend the duration (and therefore the damage) of your [[spell:212431]],

and cause those ticks to reduce the cooldown of [[spell:19434]] and

[[spell:257044]] by 0.5s per tick. On two or more targets, since

[[spell:473520]] gives you two [[spell:212431]]s back-to-back, we prefer to

cast them on two different targets (unless there is a priority target up),

because we want to maximize this cooldown reduction effect. The damage is the

same as if we cast both on 1 target, but because the cooldown reduction scales

with the <em>number of ticks</em>, it is better to spread them out.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the

Marksmanship Hunter kit, we have compiled a more detailed explanation on

individual parts of our rotation, from important rotational mechanics that you

need to pay attention to, to cooldowns and how to use them, so you can reach

your full potential when playing Marksmanship Hunter.

### Precise Shots

3.1.

#### Precise Shots

[[spell:260240]] is a buff that you get after casting

[[spell:19434]], and, via the [[spell:473385]] talent, [[spell:257044]] as

well.

It makes [[spell:185358]] and [[spell:257620]] deal 50% more

damage

and cost 60% less Focus.

Aside from wanting the damage and resource boosts, spending

[[spell:260240]] fuels our [[spell:466872]], which

massively buffs [[spell:19434]] and [[spell:257044]] depending on talents,

and even more so with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel

which has an empowered [[spell:1253601]].

Because [[spell:260240]] does not stack (or, more precisely, you cannot

generate it twice without wasting some of it), we **always** want to spend

our [[spell:260240]] Spenders (henceforth called PS Spenders) before our

next [[spell:19434]]. The easiest way to do this is simply to follow up

every [[spell:19434]] with a PS Spender.

[[spell:257044]] grants [[spell:260240]], so

follow every [[spell:257044]] with a PS Spender as well. As

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel, also spend your [[spell:260240]] before you cast

[[spell:257044]], unless [[spell:288613]] is up. As

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger, simply cast [[spell:257044]] on cooldown regardless.

On AoE, this has the added convenience of activating [[spell:257621]]

right after spending it with those Aimeds and Rapids. By simply following up

every single [[spell:19434]] and [[spell:257044]] with a

[[spell:257620]]

on AoE, we knock off two birds with one stone: [[spell:260240]] is spent,

and [[spell:257621]] is activated.

### "Take Aim" Apex Talents

3.2.

#### "Take Aim" Apex Talents

[[spell:1273132]] makes [[spell:257044]] shave 5 seconds off

[[spell:19434]]'s cooldown over its channel time. With

[[spell:470945]] and a second target in range, that doubles to 10

seconds. [[spell:1273128]] adds a second effect on top. Your

[[spell:466872]] now also increases the damage of your next

[[spell:257044]] against the target by 20%, not just your next

[[spell:19434]]. Neither one asks anything new of you. Both are "baked in"

to the listed rotation above.

4.

### Important Cooldowns for Marksmanship Hunter

### [[spell:288613]]

4.1.

#### Trueshot

[[spell:288613]] is our main cooldown. It has either a 90-second or 2-minute

cooldown, depending on whether you choose [[spell:260404]] or

[[spell:474738]]. It lasts 17 seconds. While active, it increases your

critical strike chance by 10% and your critical strike damage by 20%, doubled if

you took [[spell:474738]], and it speeds up how fast your primary

[[spell:19434]] and [[spell:257044]] cooldowns recover, while also

quickening the cast time of the former.

It also massively increases the chance of generating [[spell:466872]]

procs when we consume [[spell:260240]], and even activates

[[spell:466872]] for free when you press it.

[[spell:288613]] simply makes us better at everything, and because the thing

we do best is "lots of damage with [[spell:19434]]/[[spell:257044]]", a

very good rule of

thumb is to always try to cast [[spell:288613]] right before a

[[spell:257044]]. This ensures that we are spending as much time as possible

in [[spell:288613]] casting our most powerful ability.

On 5+ minute fights, you get to use two Potions, and they should not necessarily be the same one.

[[item:241288]] is your go-to/standard Potion. However, once [[spell:204089]] is

stacking up in the execute phase of a fight, you already have a large amount of Critical

Strike, so a second [[item:241288]] is worth much less, and

[[item:271886]] is used instead. It ramps its Versatility effect over its duration, so to

reach peak Versatility at the right time, pop it around 10 seconds before your

execute-[[spell:288613]].

4.1.1.

##### Hero Talent Impacts of Trueshot

For both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger, [[spell:288613]]'s

button will turn into a different button once pressed; [[spell:1264902]]

or [[spell:392060]] for Sentinel and Dark Ranger respectively. In addition,

for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger, activating [[spell:288613]] also gives you a free

[[spell:466932]] proc.

[[spell:1264902]] is a filler that gives us a [[spell:194595]] proc and does a ton of damage. 

Notably, its bouncing effect is much slower to do damage on single-target than on AoE. So, on single-target we 

prefer to cast it with around 5 seconds left on [[spell:288613]]. On AoE, we just send it right before 

[[spell:288613]] expires.

[[spell:392060]] is a little more complicated. Because both

[[spell:288613]] and [[spell:392060]] give you a [[spell:466932]]

proc, and because we do not want to overwrite these procs, we want to cast 

both when we do not already have a proc coming up. In practice, this means we 

will usually use [[spell:392060]] as soon as we run out of other ways of 

generating it in a guaranteed way (such as [[spell:257044]]).

### [[spell:260243]]

4.2.

#### Volley

[[spell:260243]] is a talented 45-second cooldown mostly

associated with AoE. It is actually a fairly simple button, but there are common

misconceptions about its use and value.

Essentially, because of the nature of the [[spell:260240]] mechanic we

explained in the previous section, even though [[spell:260243]] gives us

[[spell:257621]], it is actually relatively uncommon for us to make any use

of this "free" [[spell:257621]] whatsoever. Because we tend to run talents

where [[spell:19434]] and [[spell:257044]] both give [[spell:260240]],

we **have** to use a PS Spender in-between all such casts. Because of this,

even if [[spell:257621]] was permanently active, we would actually play more

or less the same; the need to spend [[spell:260240]] is so pressing, and

all of the [[spell:257621]] that [[spell:257620]] also gives

are sort of a

happy accident.

5.

### Changelog

:::details 历史更新记录
- **14 Oct. 2026:** With Aspect of the Hydra on two or more targets, Sentinel now casts Rapid Fire on cooldown even with Precise Shots up.
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **31 Aug. 2026:** Clarified mouseover Multi-Shotting and clipping.
- **24 Aug. 2026:** Moved Rapid Fire above the Precise Shots spenders in the Sentinel single-target priority list. Same fundamental rotation, but easier to parse/read.
- **24 Aug. 2026:** Moonlight Chakram now goes out with around 5 seconds of Trueshot left on single target, so that all 7 bounces land inside the Trueshot.
- **24 Aug. 2026:** Added Liquid Luster as the second Potion of the fight, popped around 10 seconds before Trueshot in the execute phase.
- **22 Aug. 2026:** Arcane Shot no longer has a separate rule during Trueshot.
- **22 Aug. 2026:** Updated the Rapid Fire advice for the recent hotfix. Only Sentinel still clips the channel, and only on AoE.
- **18 Aug. 2026:** Linked the Target Swap Multi-Shot macro from the Multi-Shot priority entries.
- **18 Aug. 2026:** Added target selection by Sentinel's Mark and Spotter's Mark to the Rapid Fire, Aimed Shot and Precise Shots spender priorities.
- **18 Aug. 2026:** Added swapping to a target without a Mark before pressing Trueshot.
- **18 Aug. 2026:** Added holding Trueshot for up to 15 seconds to line it up with Explosive Shot.
- **16 Aug. 2026:** Removed spreading Explosive Shot across two targets from the AoE priorities and opener if a priority target is up. It was found to not speed up M+ keys due to its prio damage loss, though it is a small AoE/2T DPS gain.
- **16 Aug. 2026:** Added clipping the end of Rapid Fire with Multi-Shot to the Sentinel AoE opener.
- **15 Aug. 2026:** Added clipping the end of Rapid Fire to the single-target priorities, and clarified that both shots benefit from Precise Shots.
- **13 Aug. 2026:** Added clipping the end of Rapid Fire to the AoE priorities.
- **12 Aug. 2026:** Clarified that Rapid Fire needs Trick Shots up in the AoE priority.
- **11 Aug. 2026:** Clarified Explosive Shot targeting in the AoE priority.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Corrected Volley's cooldown and clarified Double Tap usage.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **29 May 2026:** Added note of high-prio Aimed at 2 charges for DR ST.
- **27 Apr. 2026:** Rotation updates and simplifications. Opener updates.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **09 Apr. 2026:** Dark Ranger Opener fix.
- **17 Mar. 2026:** Fixed error causing Volley not to appear in the opener under some conditions. Small updates to Sentinel AoE Rotation.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **03 Mar. 2026:** Opener clarifications for Moonlight Chakram.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **28 Aug. 2025:** Single-Target rotation update surrounding ES usage.
- **27 Aug. 2025:** Minor rotational clarifications and edits on AoE.
- **25 Aug. 2025:** Updated Explosive Shot usage on single-target to be more accomodating of Improved Streamline setups.
- **25 Aug. 2025:** Added information about rotational bugs.
- **20 Aug. 2025:** Added note on swapping Focused Aim to Improved Streamline for movement concerns.
- **19 Aug. 2025:** Removed filler-Multi Shot from Dark Ranger AoE.
- **18 Aug. 2025:** Minor Dark Ranger Single-Target Opener update (make it more explicit to spend PS stacks before entering Trueshot).
- **17 Aug. 2025:** Minor Dark Ranger Single-Target Rotation clarifications/simplifications. Minor Sentinel AoE clarification.
- **15 Aug. 2025:** Updated AoE Rotation(s).
- **13 Aug. 2025:** Small Dark Ranger Single-Target opener change.
- **12 Aug. 2025:** Updated Single-Target Rotations.
- **11 Aug. 2025:** Substantial Rotational Updates for Dark Ranger on Single-Target, worth quite a bit of extra DPS.
- **08 Aug. 2025:** Update default Dark Ranger Single-Target talent picks.
- **07 Aug. 2025:** Further opener update iteration.
- **06 Aug. 2025:** Substantial AoE Rotation updates, particularly Sentinel AoE Opener.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **15 May 2025:** Updated the Dark Ranger AoE Opener.
- **07 May 2025:** Updated the wording of the 4PC Doubledip in the rotation to make it clearer what it does and how it works.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **04 Apr. 2025:** Very small rotation updates and clarifications.
- **25 Mar. 2025:** Added a fall-back line to Explosive Shot regardless of other statuses, as a low priority.
- **18 Mar. 2025:** Updated rotational details regarding 4PC and Precision Detonation. Updated wording to be clearer in places.
- **14 Mar. 2025:** Updated defaults to assume 4PC.
- **04 Mar. 2025:** Rotation improvements. Removed Kill Shot from AoE Priority, and Single-Target priority unless certain talents are chosen.
- **27 Feb. 2025:** Significant rotational updates relating to Arcane Shot, Aimed Shot, and Explosive Shot usage.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **13 Jan. 2025:** Further separated Dark Ranger and Sentinel Single-Target Rotation differences.
- **08 Jan. 2025:** Small opener addition.
- **27 Dec. 2024:** Small Dark Ranger Opener and Rotation updates.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **31 Oct. 2024:** Rotation overhaul, particularly for Dark Ranger.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **26 Oct. 2024:** Significant single-target rotation update.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **10 Oct. 2024:** Updated Mad Queen's Mandate usage.
- **02 Oct. 2024:** Added more specific Trinket usage information.
- **24 Sep. 2024:** Added Lunar Storm Rapid Fire-holding to AoE Rotation.
- **17 Sep. 2024:** Added opener note about on-use Trinkets.
- **15 Sep. 2024:** Added note about on-use trinkets.
- **14 Sep. 2024:** Simplified the single-target rotation, specifically Aimed Shot usage.
- **13 Sep. 2024:** Added note about Wailing Arrow resetting the cooldown of Rapid Fire, updated opener.
- **10 Sep. 2024:** Clarified that Multi-Shot takes over from Arcane Shot at just 2 targets. Simplified the Steady Focus Rotation.
- **09 Sep. 2024:** Updated the Opener with Wailing Arrow specced.
- **03 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **31 Jul. 2024:** Simplified Steady Focus optimization. This affects the single-target opener, rotation, and AoE rotation.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Marksmanship Hunter in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Marksmanship Hunter

Welcome to our Gear and BiS Page for Marksmanship Hunter for

Midnight Season 2. Check this page to learn everything you need

to know about gearing a Marksmanship Hunter, including the BiS Gear

from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier

Sets, and much more.

The Midnight Expansion brought a major stat squish, reducing the stats and

numbers of virtually everything in the game, including Item Levels and the stats

on gear.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which

lets you

increase the item level of gear along tracks that relate to where you obtained the

item, with harder content dropping gear that can be upgraded to higher Item

Levels.

For more information, read up on our dedicated page on how the 

[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 

changed in the Midnight expansion.

### Overall

This list contains the best gear in every slot for Season 2 of Midnight, from all sources.

There are many different setups that perform within the margin of error. This one chooses as many Raid items as possible, since they are easier to obtain than hoping for the right Mythic+ item from your [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). Mythic+ items are chosen when there is no equally strong Raid alternative. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Critical Strike and Mastery are what you want most.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best items to Catalyze:

- Helmet: [[item:268230@JAACAAgNyA]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQWhat to Get From The Great Vault?
Take the [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) almost every week. The exception is when the Vault offers the last thing you wanted from a boss or dungeon, because taking it there means you never have to bonus roll that source again.

A Voidcore bonus rolls one raid boss or one Mythic+ dungeon and gives you something you have not rolled from it before. Heroic raid bosses and Mythic+ give 1/6 Myth, Mythic raid bosses give 6/6 Myth, and late-raid bosses give 9/6.

Two things make this stronger than it looks. The item level is decided when you spend the Voidcore rather than when you take it, so you can sit on one until you have a Mythic boss worth rolling on. And gear you take out of the Vault stays in the bonus roll pool, so a piece you were going to replace anyway can cost you a roll later.

The bosses worth rolling on are listed under Nebulous Voidcores further down this page.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240914]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the best gear in every slot for Season 2 of Midnight, from Midnight Season 2 Mythic+. This is aimed at people who do not intend to engage much with Raid content.

There are many different setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Critical Strike and Mastery are what you want most.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best dungeon drops to Catalyze:

- Helmet: [[item:159374@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Shoulders: [[item:251131@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Chest: [[item:158355@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Gloves: [[item:193752@JAAKAAQkCYHKvbRLfYjM]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- Legs: [[item:159375@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend farming the following dungeons:

- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): BiS Helm, Legs, Boots and Ring
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): BiS Weapon, Shoulders, Cloak, Ring and Trinket
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): BiS Chest and Trinket
- [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>): BiS Hands
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): BiS Neck

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271680@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the best gear in every slot for Season 2 of Midnight, from the Midnight Season 2 Raids. It is very similar to our Overall BiS List, since that is biased towards Raid Gear as well, but in this case, absolutely no Mythic+ items are included.

There are many different setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Critical Strike and Mastery are what you want most.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best raid drops to Catalyze. A Mythic+ item can beat any of them if you run keys as well:

- Helmet: [[item:268230@JAACAAgNyA]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raid leader, or simply want to focus on the most important bosses and items, we have you covered!

- [[item:268207]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Weapon, and Venomcursed.
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Neck, and Venomcursed. Most specs want it, so expect competition.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS on-use Trinket.
- [[item:270168]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Trinket.
- [[item:281215]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): Best Trinket until you have Font 344.
- [[item:281238]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Gloves.
- [[item:268252]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>): BiS Ring.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Ring.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240914]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Marksmanship Hunter

As Marksmanship, we want a powerful on-use Trinket to pair with our

[[spell:288613]], which is [[item:270175]]. In addition, we pick [[item:270168]].

Despite Font technically being an on-use, it does not especially benefit from being cast with

[[spell:288613]] as

it does damage on its own, which allows it to pair up with Heart. Font, properly used on specific fights, can far outperform its sim, especially with damage amps.

Until you have Font on 344 iLvl, use [[item:281215]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Marksmanship Hunter Trinkets**
**BiS Pairing -**

[[item:270175]]

and

[[item:270168]]

**Alternatives -**

[[item:281215]]

and

[[item:270173]]

:::

There are quite a few other valuable trinkets out there, so make sure to

click on our ranking chart to see if they are worth equipping. Doubling up on on-use Trinkets is normally bad, but Font is not a stat-boosting on-use, which means it does not care much about being stacked with our [[spell:288613]] and can be safely used afterwards.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Marksmanship Hunter Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]: On-Use</li>&#10;<li>[[item:270168]]: On-Use. BiS alongside Heart.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]]: Best Font alternative if you cannot get a 344 Font.</li>&#10;<li>[[item:270173]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:159617]]: On-Use, best Heart alternative if you are not killing Mythic Ula'tek.</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:273796]]: On-Use</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250225]]: On-Use</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:250259]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]: On-Use</li>&#10;<li>[[item:273797]]: On-Use</li>&#10;<li>[[item:241340]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

- [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is a new currency that can be used to "Bonus 
  
    Roll" on certain dungeons and items. Using it will **guarantee** a drop 
  
    from that source, but the item you get is random. However, you are protected 
  
    from repeats. Use this enough times on a boss or dungeon, and you are
  
    **guaranteed** your desired item.

You get them from [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) by rejecting the item rewards, which

needs three reward slots unlocked from any source (even Tier 1 Delves!). With

the launch of Patch 12.1.5, you also get one extra Voidcore for free from Orin

Straylight, who can be found next to the Catalyst in Silvermoon.

3.1.

#### Recommended Nebulous Voidcore Usage for Marksmanship Hunter

Obviously, the straightforward answer to this question is to use the 

Voidcores on the best upgrade that you have not yet gotten. This is unique to 

your character, but we will offer a list of some of the most important items for 

Marksmanship Hunter, with the goal being that you can just go down 

the list and chase the #1 thing you see that you do not already have.

Bonus Rolling for an item you may get from an upcoming raid boss can be a bad

idea, depending on how you value "power now" versus "power later".

Generally speaking, your best bet is to roll [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on **Heroic**. It has several high-impact BiS items and so even if you do not 

roll your BiS weapon right away, you will still extract good value.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:268207]],
   
   [[item:268265]], [[item:271876]],
   
   [[item:270175]], and [[item:270168]]
2. [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) for [[item:281238]],
   
   [[item:281029]], and [[item:281215]]
3. At this point, it has been many weeks of the Season and your gear will 
   
   be all over the place. We recommend using 
   
   [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>) 
   
   to sim your optimal bonus rolls.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] are a new upgrade currency that arrives with

Patch 12.1.5. Each upgrade costs 10, and they only work on your Weapon, your

Trinkets and your Neck, letting you upgrade those items up to 340 iLvl. Only

fully upgraded Hero Track or Myth Track items, or crafted items at maximum

quality, can be upgraded with them. Spending them follows a similar priority to

your Crests:

1. Your Weapon is the highest priority.
2. Your [[item:270175]].
3. Your other Trinket.
4. Your Neck.

Fill in with other Myth Track items that you do not use as often. The

exception is an item you do not expect to get at Myth Track any time soon. If

you are not killing Mythic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), it is fine to upgrade a Hero Track

[[item:270175]].

4.

### Best Crafted Items for Marksmanship Hunter

You can have two Embellishments, which are special effects that come from

crafted gear. Which to craft first depends on how much you value power in the

opening weeks of the season.

Crafting a Weapon such as [[item:265337]] with 

[[item:273060]] and Crit/Mastery is an excellent boost of 

short-term power. The downside is that even if you do craft it, your best bonus 

roll target is still likely to be Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), which has a decent 

chance of giving you a Mythic Track [[item:268207]] which would 

invalidate your Crafted weapon.

The alternative is to craft your actual BiS, the 

[[item:244581]] and [[item:244584]] with 

[[item:240167]] and Crit/Mastery. If you get very unlucky and do not 

Bonus Roll a Mythic 

Weapon in a reasonable

time, you may regret this choice as you will be stuck with a 321 iLvl Weapon

for weeks.

The armor pair is the better longer-term play, since it is your actual BiS

and a crafted Weapon gets replaced by a Mythic Track drop sooner or later.

Crafting the Weapon first is still a real option if you want the power in

week 1.

Crafting [[item:244582]] is a good short-term armor

craft, and a permanent one if you are never going to kill [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

on Mythic for the 344 Legs.

:::details **Marksmanship Hunter Crafting Slot Priority**
**Weapon → Neck/Rings → Everything Else → Cloak/Wrist**

:::

You should ideally sim the optimal stats to craft for your particular

character, but Crit/Mastery is most likely your best option with a

[[item:245789]].

For more information about crafting gear you can visit our

[Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

Helmets, Belts and Bracers can drop with a socket, and you can also add one

yourself with [[item:275707]]. It costs six

[[item:258556]], the currency [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) gives you for

passing on its rewards. You get six of them directly as long as you have three

reward slots unlocked.

Save them for pieces you do not expect to replace, so Mythic items or your

two crafted slots, since a crafted Belt or Bracer cannot get a socket any other

way.

5.

### Crest Usage

You will be able to upgrade your items via Crests such as

[Myth Mistcrest](<https://www.wowhead.com/currency=3446>). Once you have upgraded a slot to a certain item level,

**upgrading other items of that slot to that item level is free**.

When you upgrade with Crests, you should think of it as upgrading

**slots** and not items.

Since Crests are a limited resource, you will want to obtain

the highest item-level possible **before** upgrading a given slot, as this

means you will spend fewer Crests on that slot in total. If you are at all

capable of doing a +10 Dungeon, for example, it would be a very bad idea to

upgrade an item from a +9 Dungeon, because you just wasted 20 Crests that could

have been saved by just farming the slot on a +10.

We see a ton of players, even at a high level, mess up their upgrade

priorities and upgrade prematurely. Getting this right will put you far ahead

of most players.

Below is the slot priority you should upgrade your items in. If you ever want

to deviate from this, you should have a very good reason.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Marksmanship Hunter Crest Upgrade Priority**
**Weapon**

→

**Trinkets**

→

**Helmet/Chest/Legs**

→

**Shoulder/Gloves/Belt/Boots**

→

**Rings/Neck**

→

**Cloak/Bracer**

:::

Note that exceptions are possible, such as special items that have more Item

Level scaling than their slot would imply.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the

importance of simming yourself on Raidbots. This is because every character is

unique, and each gear piece you have access to can change what is best

right now for you.

While we do offer recommendations for gear and trinkets, these are not complete

replacements for simming yourself. The only way to truly optimize your character

to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **30 Sep. 2026:** Fixed the Chest tooltips showing two Venomcursed effects.
- **02 Sep. 2026:** Updated the Overall and Raid BiS List Trinket to the Font of Venomous Rage.
- **31 Aug. 2026:** Updated the Overall and Raid BiS List Boots to the Boots of the Reckless Wayfarer.
- **31 Aug. 2026:** Updated the Overall BiS List Ring to the Charged Sandstone Band.
- **29 Aug. 2026:** Moved the Font of Venomous Rage up to S Tier, as it was undersimming.
- **24 Aug. 2026:** Updated the Weapon enchant to Rite of the Hash'ey.
- **22 Aug. 2026:** Added a note on crafting Legs.
- **18 Aug. 2026:** Updated the Overall BiS List Boots to the Sabatons of Coruscating Energy.
- **18 Aug. 2026:** Updated the Nebulous Voidcore bonus roll priorities following the Gebbo's Bottomless Bag nerf.
- **17 Aug. 2026:** Updated the Trinket tier list, and changed the alternative passive Trinket to Keeper's Seething Core.
- **16 Aug. 2026:** Reworked the crafting advice, corrected the Voracious Heart of Ula'tek and Gebbo's Bottomless Bag entries in the raid-items list, and added start of season Voidcore and Crest advice.
- **15 Aug. 2026:** Updated the Trinket tier list following the latest tuning.
- **14 Aug. 2026:** Updated the Raid BiS Gloves to the Catalyzed Grips of Swirling Fury from Nymrissa Wavecaller.
- **14 Aug. 2026:** Updated the Nebulous Voidcore bonus roll priorities.
- **12 Aug. 2026:** Added Catalyst and Great Vault FAQs and a socket section, fixed Catalyst drop locations, and updated sources of the Raid BiS Helm and Gloves.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Fixed Tier Set FAQ pieces and updated the Neck recommendation notes.
- **17 Jun. 2026:** Updated BiS Neck
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **07 Apr. 2026:** Updated Light Company Guidon Tier List position.
- **25 Mar. 2026:** Updated Mythic+ Gear BiS List.
- **21 Mar. 2026:** Updated Mythic+ Gear BiS List.
- **17 Mar. 2026:** Updated for Midnight Season 1.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **04 Mar. 2026:** Updated Crafting recommendation for endgame.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **02 Sep. 2025:** Trinket Tier List and BiS updates.
- **15 Aug. 2025:** Updated Trinket Tier List for tuning. Simplified into one list.
- **12 Aug. 2025:** Added preliminary, guesswork-based Cursed Stone Idol Trinket in the Tier List, as it cannot be simmed yet.
- **11 Aug. 2025:** Updated M+ Trinket Tier List.
- **09 Aug. 2025:** Updated Trinket Tier Lists and BiS Lists.
- **08 Aug. 2025:** Updated Mythic+ Gear BiS List.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **23 Jun. 2025:** Updated the Titan Disc recommendation based on the latest hotfixes.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **14 May 2025:** Updated the purchasing order of Jastor Diamond and added more context to its "BiS"-ness.
- **09 May 2025:** Updated Corruption Enchants & Puzzling Cartel Chip Dinar section.
- **21 Apr. 2025:** Add list of Dinar-purchasable items.
- **29 Mar. 2025:** Updated the position of Eye of Kezan in the Mythic+ Trinket Tier List.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **13 Mar. 2025:** Updated Trinket Tier List and BiS List with fresh simulations based on latest changes and APL improvements.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated for the Cyrce's Circlet now going to Item Level 658.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **10 Oct. 2024:** Updated the Trinket Tier List slightly.
- **17 Sep. 2024:** Updated the BiS List Trinket selections.
- **15 Sep. 2024:** Updated the MM Trinket Tier Lists based on new methodology, and in the case of the Raiding Tier List, a new preferred single-target build discussed on other pages of the guide.
- **13 Sep. 2024:** Added note about double-Dawnthread Lining not working and how to fix it.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **27 Aug. 2024:** Added a note about Crafted gear to the Pre-Season BiS List.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Marksmanship Hunter. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Marksmanship Hunter Stat Priority

The stat priority across all builds for Marksmanship Hunter is as 

follows:

Critical Strike

Mastery

Versatility

Haste

Crit is king, with Mastery pretty close behind. Versatility is a chunk behind

that, and Haste is your worst stat by some margin.

Remember that the less you have of a stat relative to others, the stronger it

tends to become. Stat priorities are based on equalizing all stats and looking

at how powerfully stats scale from a set point, as well as looking at the

highest-simming gear setups for the spec and looking at what stat priority got

it there.

2.

### In-Depth Stat Breakdown

**Agility** is your primary stat. It provides you with Attack Power, which

determines the damage your abilities do across the board.

**Mastery**, through [[spell:193468]], grants you increased

damage on all your abilities and increases your maximum shot range.

**Haste** increases your auto attack speed and Focus regeneration, reduces

your Global Cooldown from 1.5 seconds to a minimum of 0.75 seconds, and reduces

the cooldown on your [[spell:19434]] ability.

:::details FAQIs There a Haste Cap for Marksmanship Hunter?
There are no Haste caps for Marksmanship Hunter.

:::

**Critical Strike** increases your chance to critically hit with

all spells and abilities. Crits deal double damage by default, but several 

effects can increase your crit damage, and make crits even stronger.

**Versatility** increases all your damage and healing done, and decreases

all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit past which it will begin to offer less increase per

point gained; these are known as the points of diminishing returns. Once you

have reached

these amounts, stats will become progressively less valuable and may fall behind

other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **22 Mar. 2026:** Added Haste breakpoint information.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **14 Sep. 2025:** Updated Stat Priorities, specifically formalizing a point of Crit where it tends to become inferior.
- **27 Aug. 2025:** Updated stat priority for Dark Ranger AoE.
- **09 Aug. 2025:** Updated Stat Priority.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Marksmanship Hunter, based on your [stat priority](<https://www.icy-veins.com/wow/marksmanship-hunter-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

If you have 5+ sockets in your gear, you should use 

    [[item:240967]] in one socket. Then, you

should ensure you have one gem of each type in other sockets to max out the 

Crit effect, ideally 

[[item:240890]]/[[item:240898]]/

[[item:240914]]/

[[item:240908]]. Fill in remaining sockets with 

[[item:240908]].

If you do not have 5+ sockets in your gear, you should use 

[[item:240983]] in one socket, and 

[[item:240908]] in the rest.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchant</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

3.1.

#### Flask

The best flask is generally going to be

[[item:241326]]. That said, it is best to think of Flasks as just

another piece of gear that is easily swappable, and depending on your exact gear

situation, any of the 4 secondary stat flasks can be optimal. To really minmax

on this point, you would need to simulate it.

3.2.

#### Potions

Marksmanship uses two different DPS Potions in most 5+ minute fights.

- [[item:241288]] is the default option, offering a huge amount
  
  of your highest secondary stat for 30 sec, to be synced with your cooldowns.
  
  Note that this Potion is sensitive to your best stat (Critical Strike) actually
  
  being your highest when you pop the Potion. If that is not the case at this
  
  point in your gearing process, use [[item:241308]] instead. It also
  
  benefits greatly from your lowest stat (usually Versatility) being very near-0,
  
  since that means you suffer none of the reduction.
- [[item:271886]] is the second Potion of the fight, for the execute
  
  phase. By then [[spell:204089]] has given you so much Critical Strike that
  
  another [[item:241288]] does far less for you. Luster builds its
  
  Versatility up over 30 sec, so drink it around 10 sec before you pop your execute-[[spell:288613]].

Make sure to carry [[item:271883]] as well.

It has a 5-minute cooldown and heals most of your health; use it as a last

resort, preferring your personal defensives wherever possible.

3.3.

#### Food Buff

The best Food you can eat is from a

[[item:255846]] or [[item:255845]] feast. The best

non-feast food is [[item:242747]]. The "Hearty" part is important, as

this food persists through death, and we highly recommend grabbing

[Cooking](<https://www.icy-veins.com/wow/professions-cooking>) to easily make your own Hearty Food, as it cannot be

straightforwardly purchased on the Auction House.

3.4.

#### Augment Rune

The best Augment Rune in Midnight is

[[item:259085]], but it might be very expensive to use on every

pull or

every dungeon, so use it sparingly unless your wallet is deep.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **24 Aug. 2026:** Added Liquid Luster as the second Potion of a long fight, for execute.
- **24 Aug. 2026:** Updated the Weapon enchant to Rite of the Hash'ey.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated Weapon enchant recommendations, and fixed enchant tooltip links.
- **16 Jun. 2026:** Clarified Weapon Enchant choice.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **19 Mar. 2026:** Updated to recommend Leech Enchants over Avoidance. Updated Gems advice.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **09 May 2025:** Updated Corruption Enchants section.
- **21 Apr. 2025:** Added Corruption Enchants information.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **10 Sep. 2024:** Added note about Movement Speed Gem, and also updated the Gem setup recommendation in general.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **22 May 2023:** Updated the recommended Leg Enchant, as it was found that the Lambent Armor Kit does not provide Stamina as it was assumed.
- **12 May 2023:** Updated the recommended food and Leg enchant.
- **01 May 2023:** Reviewed for Patch 10.1.
- **23 Mar. 2023:** Yet another update to the recommended Gemstones based on a slew of hotfixes.
- **23 Mar. 2023:** Updated the recommended Gemstones after sim updates, and the discovery of a new, powerful combination.
- **21 Mar. 2023:** Updated the Onyx Annulet Information in light of the March 21st buff.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated the recommended Phial.
- **11 Dec. 2022:** Updated the recommendation and description of the optimal Flasks/Phials.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Marksmanship Hunter in World of Warcraft Patch 12.1.5.

1.

### Marksmanship Hunter in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Hunter in

Mythic+ dungeons, including the best way to set up your character, how your

rotation may change, and tips and tricks for using your abilities in the most

optimal way.

Marksmanship Hunter has extremely powerful burst damage on a

90-second or 2-minute timer via [[spell:288613]], depending on your talents,

and can dominate the pulls where this cooldown is available. Between these

cooldowns, its damage is on the lower side, so

optimizing Marksmanship in Mythic+ is very much about timing and playing

perfectly during those cooldown windows.

If you are unfamiliar with Mythic+ and its associated general mechanics, you

can read more about it on our dedicated Mythic+ page below.

2.

### Best Mythic+ Talent Builds

Marksmanship plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel in Mythic+, with no exceptions.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger is a bit tankier, but Sentinel does more damage and is far

easier to play. We provide a Dark Ranger build for those who prefer the

playstyle or thematic fantasy.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ Talents

2.1.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel Mythic+ Talent Build for Marksmanship Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel build for Mythic+, and

other AoE-focused content. It is based on simulating the conditions found in

real Mythic+ dungeons and seeing not just what does the most DPS, but what

actually clears the dungeon quicker in a group. There are builds that do more

AoE, but they all lose more single-target than they gain in terms of AoE, and

vice versa.

We run [[spell:257621]] in AoE, swapping out [[spell:185358]] for

[[spell:257620]] to make our abilities do AoE damage.

2.2.

#### Marksmanship Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAwCMwMGNWGAzgNAAAAAAAAwMmZmx2MmZGzwyYaGDmlttZmZmZmZmZhZWGmBAAwDMGDAzYDMAbMz2MG"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMeEJRZhpx5BCKSaiqyFmMttPwhik-AAAA-BEIMQYcAJRZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ Talents

2.3.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ Talent Build for Marksmanship Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger build for Mythic+, and

other AoE-focused content. It is based on simulating the conditions found in

real Mythic+ dungeons and seeing not just what does the most DPS, but what

actually clears the dungeon quicker in a group. There are builds that do more

AoE, but they all lose more single-target than they gain in terms of AoE, and

vice versa.

2.4.

#### Marksmanship Hunter Utility Talent Considerations

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C4PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYWAAAAAAAAAzYmZGbzYmZMDLjpZMYW2MjZmZmZmZhZWGmBAAwDMGzMzMgAGgNmZZGD"
}
```
:::

:::details 来源计算器编码
```
#+D-ABDDEFGHJVWWYYaceiikqYZhpt19BKKSquG-AEFMiksw048ABFJNRV5CTm2Wn3HoQRS-AAAA-AGIYgow4ApyCTD-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts

[[spell:147362]] is your "kick" and your most important bit of utility in

Mythic+, used to stop enemy casts for the benefit of the group and especially

the tank. It is **highly recommended** to use a Focus Kick macro for this.

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Counter Shot
```

This macro will kick your focus target if you have one, mouseover if you have

no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a

**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly, so that you

are always able to kick it on cooldown, or in coordination with the rest of your

group.

3.2.

#### Stunning and "Stops"

[[spell:474421]] is your second-most important utility and is your

single-target "stop" for negating casts that cannot be normally interrupted. We

recommend using this in the same way as your Counter Shot, with the same macro

(with Intimidation swapped in for Counter Shot, of course). With a talent, it

can also be an AoE stop.

[[spell:109248]] can be used to save your tank in hectic moments by

helping them kite mobs and generate some range.

[[spell:187650]] can be used as an additional stop alongside

[[spell:474421]], but it has a slow travel time and you will need to be

close to land it before most stunnable casts are finished.

### Other Utility

3.3.

#### Other Utility

[[spell:5384]] can not only be used to drop aggro, but also negate

certain casts and channels on you. In some cases, these mechanics will simply

re-target someone else in the group, but occasionally the mechanic will be

entirely negated with huge benefits. If you notice a cast or effect on you, try

to [[spell:5384]] it! With [[spell:459517]] talented, it will also

remove all Poisons and Diseases on you.

[[spell:19801]] can dispel beneficial Enrage and Magic effects

from enemy targets, which is regularly useful, and our builds already take

[[spell:459983]] for it. In some dungeons, you may choose to change

your default talents to grab [[spell:109248]] or [[spell:199483]].

[[spell:187698]] can be used to aid your tank in kiting by slowing mobs. It

is good to reflexively throw down a Tar Trap if your Tank dies, as it gives

everyone else a better chance at kiting and surviving.

4.

### Dealing with Affixes

This section has Hunter-specific tips for dealing with the various affixes of

Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Marksmanship Hunter

Use AoE Crowd Control tools like [[spell:474421]] on dense clusters of

Orbs to take out as many as possible. You can use [[spell:187650]] for the

remaining, singular ones.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Marksmanship Hunter

Nothing specific to say here. Use your solid target-swapping

capabilities to focus the Void Emissary down as quickly as possible.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Marksmanship Hunter

Pop [[spell:186257]] and dash around with your excellent mobility

to grab as many orbs as quickly as possible.

### Affix: Devour

4.4.

#### Devour Affix Management for Marksmanship Hunter

[[spell:5384]]'s Poison/Disease dispel (via [[spell:459517]]) is

a source of the dispel type needed for removing [[spell:440313]]. You can also

[[spell:109304]] to heal it off, but that costs a GCD.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Clarified burst profile and utility notes.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **22 Mar. 2026:** Swapped Sentinel M+ Build to Stalk and Strike over Twilight Requiem in the Sentinel Tree, for identical sim performance but a microscopic mobility benefit.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Builds for the upcoming 12.0.1 changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **02 Sep. 2025:** Updated DR M+ Talent Build, specifically utility picks.
- **27 Aug. 2025:** Expanded on reasoning for 1.5-min and 1-min builds.
- **26 Aug. 2025:** Updated note on swapping between Unerring Vision and Calling the Shots for Dark Ranger M+.
- **11 Aug. 2025:** Updated the Mythic+ Build Recommendation.
- **06 Aug. 2025:** Sent M+ Class Tree talent update.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **15 May 2025:** Updated the Sentinel Mythic+ build to grab Ohn'ahran Winds, as evidence suggests that it has been fixed and now works properly in Mythic+ keys.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **02 Apr. 2025:** Updated the Sentinel Mythic+ Talent Build, adding a note about Ohn'ahran Winds being bugged.
- **02 Apr. 2025:** Updated the Mythic+ Talent Builds.
- **30 Mar. 2025:** Added note on Small Game Hunter viability.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **18 Mar. 2025:** Updated the recommended MDT Sim/Mythic+ Simulation Route Pastebin. Updated the Mythic+ Talent Build. Added a note about Volley to it.
- **27 Feb. 2025:** Updated the Sentinel Mythic+ Talent Build in light of recent simulation tool developments.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **28 Sep. 2024:** Updated the M+ Talent Build - one-point swap.
- **27 Sep. 2024:** Updated Ara-Kara Tips.
- **13 Sep. 2024:** Updated and clarified some tips.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Marksmanship Hunter in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Generic Macros for Hunters

1.1.1.

##### TankMD AddOn + Macro

This automatically MD's your tank in the group with no need for targeting

or focusing or anything. Install the AddOn, set up the macro, and you are

golden.

1. Grab the [TankMD
   
   AddOn](<https://www.curseforge.com/wow/addons/tankmd>).
2. Set up this Macro:

#### TankMD Misdirection Macro

```wow-macro
#showtooltip Misdirection

/click TankMDButton1
```

1.1.2.

##### Focus Mouseover Macro

An essential macro for serious Mythic+. Sets your mouseover to be your

focus target and marks it with a Green marker (unless it is already marked with

something else), letting you kick it with the macros below.

#### Focus Mouseover Macro

```wow-macro
/focus [@mouseover,harm,exists,nodead][@target,harm,exists,nodead]

/tm [@mouseover,harm,exists,nodead][@target,harm,exists,nodead] 4
```

1.1.3.

##### "Auto Kick/Stun" Macro

This Macro will automatically use your Kick on a random, casting target

with no need for targeting or mouseover or focus. We like it for

lower/uncoordinated keys. See a cast? Hit the macro. The third macro does the

same concept but for [[spell:19577]].

#### Auto Kick Macro (Counter Shot)

```wow-macro
#showtooltip Counter Shot

/cast [@focus,exists,nodead,harm] Counter Shot

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Counter Shot

/target focus

/clearfocus

/startattack
```

#### Auto Kick Macro (Muzzle)

```wow-macro
#showtooltip Muzzle

/cast [@focus,exists,nodead,harm] Muzzle

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Muzzle

/target focus

/clearfocus

/startattack
```

#### Auto Stun Macro (Intimidation)

```wow-macro
#showtooltip 

/cast [@focus,exists,nodead,harm] Intimidation

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Intimidation

/target focus

/clearfocus

/startattack
```

Note that it will prefer kicking your focus if you have one. If you want

it to prefer your mouseover, just swap out "focus" with "mouseover".

1.1.4.

##### Disengage StopCasting Macro

This macro will stop casts like [[spell:56641]] and force a

[[spell:781]], but it will not cancel channels like [[spell:257044]] or

[[spell:1261193]] that you can actually [[spell:781]] in the middle of.

#### Disengage StopCasting Macro

```wow-macro
#showtooltip Disengage

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/use Disengage
```

1.1.5.

##### Cursor Macros for Ground-Targeted Abilities

These macros skip the green target circle placement step of using

ground-targeted abilities. We use it for everything from [[spell:1543]] to Traps

to [[spell:109248]] to [[spell:260243]].

Just place your cursor where you want it to go.

#### Cursor Macro (Freezing Trap)

```wow-macro
#showtooltip

/use [@cursor]Freezing Trap
```

#### Cursor Macro (Tar Trap)

```wow-macro
#showtooltip

/use [@cursor]Tar Trap
```

#### Cursor Macro (Binding Shot)

```wow-macro
#showtooltip

/use [@cursor]Binding Shot
```

#### Cursor Macro (Volley)

```wow-macro
#showtooltip

/use [@cursor]Volley
```

#### Cursor Macro (Flare)

```wow-macro
#showtooltip

/use [@cursor]Flare
```

1.1.6.

##### Pet "Reset" Macro

This macro is useful when jumping off ledges where you really want your

pet to follow you. Petpassive and Petfollow can make the pet "snap" to you more

readily. The [[spell:1850]] line ensures your pet gets back to you as quickly as

possible.

#### Pet "Reset" Macro

```wow-macro
/petpassive

/petfollow

/use Dash
```

1.1.7.

##### Pet Taunt Macro

In Mythic+ it is sometimes useful to taunt powerful mobs right before

their tank busters which can help save your tank's life. You will want to use a

Beetle, Boar, Carapid (BM only), Core Hound (BM only), Mechanical, Scalehide,

Shale Beast (BM only), or Turtle for this as they have a 50% DR on a 1-min

CD.

#### Pet Taunt Macro

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][@focus,exists,harm]Growl

/use Scale Shield

/use Harden Carapace

/use Bristle

/use Bulwark

/use Obsidian Skin

/use Defense Matrix

/use Solid Shell

/use Shell Shield
```

1.1.8.

##### Mouseover Tranq Shot

Simply Tranqs your mouseover enemy, or your target if there is no valid

mouseover.

#### Mouseover Tranq Shot

```wow-macro
#showtooltip

/use [@mouseover,exists,harm,nodead][]Tranquilizing Shot
```

1.1.9.

##### Aspect of the Turtle Cancelaura Macro

The default game lets you cancel Turtle by pressing it again but there is

a "grace" period built into this. This macro skips the grace period and lets you

activate and then cancel Turtle immediately. Do not use this if you are the

kind of person who spams Turtle, this macro requires you to be deliberate with

a single key press to activate/deactivate!

#### Aspect of the Turtle Cancelaura Macro

```wow-macro
#showtooltip Aspect of the Turtle

/stopcasting

/stopcasting

/use Aspect of the Turtle

/cancelaura Aspect of the Turtle
```

1.1.10.

##### Mouseover Multi-Shot

Mainly useful for Marksmanship, which wants to put [[spell:2643]] on a

target separate from its main target to activate [[spell:257621]] or to

spread its Marks around. It has no nochanneling entry, since Marksmanship

deliberately clips the end of [[spell:257044]] with [[spell:2643]].

#### Mouseover Multi-Shot

```wow-macro
#showtooltip Multi-Shot

/use [@mouseover,exists,harm,nodead][]Multi-Shot

/petattack

/petassist
```

1.2.

#### Marksmanship Macros

1.2.1.

##### Nochanneling Ability Macros

We should have a nochanneling [[spell:257044]] entry in most of our
offensive ability macros to ensure that no matter how much we spam our buttons,
we will never clip/cancel our [[spell:257044]] channel. The one exception is
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sentinel.webp>) Sentinel's [[spell:257620]] on AoE, which we clip with
on purpose. So, here comes a bunch of
ability macros showing how to do this in different ways.

#### Nochanneling Aimed Shot

```wow-macro
#showtooltip
/petattack
/use [nochanneling:Rapid Fire]Aimed Shot
```

#### Nochanneling Arcane Shot

```wow-macro
#showtooltip
/petattack
/use [nochanneling:Rapid Fire]Arcane Shot
```

#### Nochanneling Kill Shot + Mouseover

```wow-macro
#showtooltip Kill Shot
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,exists,harm][]Kill Shot
```

#### Nochanneling Explosive Shot + Mouseover

```wow-macro
#showtooltip Explosive Shot
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,exists,harm][]Explosive Shot
```

#### Nochanneling Black Arrow + Mouseover

```wow-macro
#showtooltip Black Arrow
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,exists,harm][]Black Arrow
```

#### Nochanneling Rapid Fire

```wow-macro
#showtooltip
/use [nochanneling:Rapid Fire]Rapid Fire
```

#### Nochanneling Steady Shot

```wow-macro
#showtooltip Steady Shot
/use [nochanneling:Rapid Fire]Steady Shot
```

#### Nochanneling Volley + Cursor

```wow-macro
#showtooltip Volley
/stopmacro [channeling:Rapid Fire]
/use [@cursor]Volley
```

#### Nochanneling Hunter's Mark + Mouseover

```wow-macro
#showtooltip
/stopmacro [channeling:Rapid Fire]
/use [@mouseover,harm,exists,nodead][]Hunter's Mark
```

#### Nochanneling Trueshot + Racials

```wow-macro
#showtooltip
/stopmacro [channeling:Rapid Fire]
/use Trueshot
/use Blood Fury
/use Berserking
/use Ancestral Call(Racial)
```

2.

### Best Addons

2.1.

#### Generic Addons for Hunters

Before you go downloading a bunch of different Addons, we recommend you set
up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many
Addons you may think you
cannot do without, are now available through the standard interface. Once you've
set up your UI, we
recommend thinking about which aspects or customization layers you would like to
add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of
Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional
Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and
reconfiguring your UI.

2.2.

#### User Interface

2.2.1.

##### EllesmereUI

[EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
is a complete replacement for the default User Interface.
It is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need: unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. EllesmereUI is
clean, easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the
best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same
customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a
great tool to help
you focus more on your own character, instead of having to worry about keeping
track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While some UI replacements
come with their own nameplates, those are often limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to
enlarge
and change color in certain circumstances, and it might help you keep track of
important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some
setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
an Addon developed by
[plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like
[Auctionator](<https://www.curseforge.com/wow/addons/auctionator>),
[Baganator](<https://www.curseforge.com/wow/addons/baganator>),
[Chattynator](<https://www.curseforge.com/wow/addons/chattynator>),
and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures,
and much more.
It is definitely worth checking out, especially if you end up having any issues
with Plater for
any reason.

2.5.

#### Damage Meters

2.5.1.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still
around
as the #1 Addon to customize damage and healing meters. While it may not offer
as many tracking
options as before due to the limits imposed by Blizzard, it is still around and
kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.6.

#### Specific Addons for Marksmanship Hunters

Currently, we feel that there is no need for additional addons to play a
Marksmanship Hunter to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **31 Aug. 2026:** Replaced the Auto-TargetSwap Multi-Shot macro with the Mouseover Multi-Shot macro.
- **22 Aug. 2026:** Noted the one Rapid Fire clip that is still worth doing.
- **18 Aug. 2026:** Added a Target Swap Multi-Shot macro.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary updates for The War Within Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **11 May 2024:** Added a Nochanneling Rapid Fire Macro.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **25 Jan. 2023:** Added a Salvo Volley Macro.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
