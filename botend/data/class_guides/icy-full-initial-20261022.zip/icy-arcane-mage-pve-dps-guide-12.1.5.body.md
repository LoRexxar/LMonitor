## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本奥术 法师指南。在这里，你将学习如何在团队副本和大秘境地下城中扮演好奥术 法师：从入门到最大化你的伤害输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

奥术大秘境资源

[全新！顶级奥术天赋配置](<https://raider.io/specs/arcane-mage/talents>)

[顶尖奥术大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/mage/arcane>)

[奥术 史诗钥石地下城热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=mage--arcane>)

[热门奥术队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=mage--arcane>)

1.

### 奥术 法师概览

奥术法师是一个非常偏向爆发的职业专精，在DPS专精中拥有各种独特的机制。奥术在冷却期间造成非常高的爆发伤害，随后是伤害较低的阶段，等待冷却时间恢复。与游戏中其他DPS专精不同，奥术有一个需要注意的法力池。它的许多法术消耗大量法力，你必须通过像[[spell:12051]]和[[spell:365350]]这样的冷却技能来小心维护你的法力，以充分利用你的技能工具箱。

非常强力

奥术 法师配备了一套非常强大的伤害技能。它在单体和范围伤害上都具有很高的爆发伤害，这通常比持续伤害更受青睐。此外，每当有额外目标时，其单体伤害会进一步增加（“漏斗DPS”），这也是非常有价值的。

奥术法师在进行单体输出循环时能够“免费”造成一定的范围伤害，这同样非常有价值，尤其是在团队副本中。不幸的是，奥术没有能力对不聚集在一起的目标造成范围伤害，且其范围伤害相当依赖触发效果，这在快速死亡的小怪群中可能是个问题，但在任何长于单次爆发阶段的战斗中，其表现会趋于平稳。

强力机制 — 优秀调整

奥术 法师可以快速击杀优先目标，而无需牺牲整体伤害。将其与漏斗DPS结合，这在团队副本中非常有价值，并且拥有团队增益（

[[spell:1459]]

）以及不错的生存能力，它在团队副本中有真正大放异彩的潜力。然而，在某些战斗中生存能力可能是个问题，这使得攻克某些首领相当困难。不过，以目前的数值调整来看，伤害足够高，这点额外的治疗需求是完全值得的。

非常强力

奥术 是大秘境的绝佳选择。它可以非常快速地清理怪物群，拥有多层AoE打断，并以

[[spell:1459]]

和

[[spell:80353]]

。然而，它确实需要一点协调，因为在一小波怪上用掉所有冷却技能后，在冷却未就绪时又去打一大波怪，会严重损害你的总体伤害。在非常高的层数中，奥术在防御方面比较吃力，由于防御技能很快耗尽，通常需要治疗者密切关注才能存活。然而，目前奥术的DPS使治疗者的额外关注完全值得。

出色的实用功能，尤其在小型队伍中

奥术法师拥有多种实用技能，例如其团队增益

[[spell:1459]]

，或者至关重要的

[[spell:80353]]

，强大的控制能力比如

[[spell:157980]]

，通过

[[spell:475]]

移除负面效果，以及通过

[[spell:30449]]

。话虽如此，这些功能中的大部分对团队副本来说并不那么有用（或者也能由其他职业提供），因此在团队副本中重要性较低，但在大秘境中这些功能非常强大。

良好的防御能力，但高度依赖几个强力冷却技能，这些技能可能很快用尽

作为奥术法师，你在应对高额爆发伤害时有很强的生存能力，尤其是这类伤害并不频繁时；但面对持续不断的伤害，你的防御手段较为不足。[[spell:45438]]和[[spell:414659]]等技能是整个游戏中最强的防御技能之一，但冷却时间较长；而[[spell:235450]]和[[spell:342245]]是冷却较短、用于应对较低单次伤害的防御技能。因此，你的生存能力取决于正在挑战的具体首领或地下城。

通常来说，如果你正在挑战的内容中伤害频率足够低，奥术 在防御端可以表现良好，但在大多数内容中，你都面临着迅速耗尽冷却技能的风险。

为了充分利用奥术的生存能力，你需要做好充分准备，因为它的几乎所有减伤技能都要求你在伤害到来之前提前开启，因为它自身的治疗能力或被动减伤非常有限。

极高机动性

奥术拥有游戏中最好的即时机动性之一，这得益于其使用双

[[spell:212653]]

或

[[spell:1953]]

，甚至可以通过某些天赋选项重置一次充能。因此，它通常几乎可以立即到达首领战中的任何位置。你甚至可以获得以

[[spell:382293]]

。其机动性唯一的缺点是持续移动速度，因为它的所有机动性都是爆发式的。奥术可以在移动中完成其循环的很大一部分，并且有很多选择来根据机制需要重新定位自己，使其在战斗中具有高度机动性。

1.

### 奥术法师在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本是第二赛季的季中更新。它增加了两个新的终局内容：一个全新的单Boss团队副本——基希克斯的解放，以及金多詹迷宫——一个全新的巨型地下堡， [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请查看下面两者的指南！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

除了新的团队副本和迷宫之外，该补丁还通过 [[item:280562]] 带来了物品等级升级等内容。请查看我们的 12.1.5 补丁中心以获取完整概述。

2.3.

#### 职业改动

12.1.5补丁未对法师的奥术专精带来任何玩法改动。唯一的改动是视觉方面的：若干奥术法术被添加到法术密度系统中，这为非法师玩家提供了更多控制我们法术可见性的选项。

新团队副本和迷宫带来了新物品，所以请务必查看我们的
[配装](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>) 页面，其中还介绍了[[item:280562]]如何升级你的现有装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_arcanesalvo.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1职业改动 隐藏12.1职业改动
在12.1版本中，奥术获得了大量的机制改动。巅峰天赋已被完全替换，[[spell:1241462]]是一个完全不同的法术，[[spell:1243435]]被重做，职业天赋树也获得了一些防御性改动和提升。

2.3.1.

##### 新增巅峰天赋：棱彩箭

[[spell:1257942]] 已被移除，并替换为新的巅峰天赋——棱彩箭：

- [[spell:1295923]]：[[spell:44425]]每消耗一层[[spell:384452]]，就有1%的几率将你的下一个[[spell:30451]]替换为[[spell:1295924]]。它会对你的目标和附近的敌人造成伤害，超过5个目标后伤害降低，并生成4层[[spell:36032]]。它的伤害和法力消耗不会随奥术充能而扩大，也不受任何修改奥术 Blast的东西影响。你可以将这个触发效果保留最多一分钟。
- [[spell:1295944]]：棱彩飞弹有50%/100%的几率触发[[spell:79684]]，且[[spell:5143]]的伤害提高15%/30%。
- [[spell:1295946]]：每消耗一层[[spell:384452]]额外增加1%的几率，使每层总计达到2%，并使[[spell:44425]]的伤害提高15%。

完全投入天赋后，消耗 20 层 [[spell:384452]] 的 [[spell:44425]] 有 40% 的几率为你触发 [[spell:1295924]]（最多 25 层时为 50% 日怒），这使其成为一种相对频繁的触发效果，而非罕见触发。返还的 4 个 [[spell:36032]] 大大提升了在倾泻至 0 后重新获得 4 层 奥术 充能的能力，从而在棱彩飞弹未触发时，你可以节省其他产生充能的方式。

[[spell:1295924]]本身也造成非常高的伤害，输出循环很大程度上围绕它展开。请务必查看更新的
[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>) 关于如何应对其。

2.3.2.

##### 奥术脉冲重做

[[spell:1241462]]已重做：

- 2秒施法时间，8码半径，15秒冷却时间。
- 每击中一个敌人生成1个[[spell:36032]]。
- [[spell:36032]]不再影响它。
- [[spell:383676]] 和 [[spell:384612]] 不再影响它。

这使奥术脉冲从一个AoE填充技能变成了一个冷却技能，并且撤销了12.0.5版本中使其施法时间与[[spell:30451]]对齐的改动。每个目标产生一层充能意味着在AoE中一次施放就能让你从零获得4个[[spell:36032]]，这对于开怪和在[[spell:44425]]之后重建资源都非常重要。代价是[[spell:1449]]重新回到填充脉冲之间空隙的角色，因此在AoE中意味着需要更频繁地进入近战范围。

2.3.3.

##### 宝珠精通重做

[[spell:1243435]]已被重新设计。[[spell:153626]]现在总是以50%的效果额外发射2个宝珠，并且不再需要或消耗[[spell:79684]]。以前它消耗一次节能施法触发来以全部强度发射2个额外宝珠。

[[spell:1243435]] 不再与 [[spell:5143]] 争夺 [[spell:79684]]，意味着所有构筑现在都重新使用 奥术 飞弹作为其终结技，而不是存在基于奥术飞弹的构筑。新的套装（见下文）进一步强调了这一点。

2.3.4.

##### 奥术 齐射生成

[[spell:1243557]]已针对新的巅峰天赋进行了调整：棱彩箭矢授予4层[[spell:384452]]，而[[spell:153626]]现在只授予1层而非2层。

2.3.5.

##### 第2赛季套装

第二赛季带来了一套新的套装：

- [[spell:1296581]]：[[spell:5143]] 额外发射一道波，并造成提高 5% 的伤害。
- [[spell:1296582]]：每层[[spell:5143]]波纹会使你的下一个[[spell:30451]]、[[spell:1241462]]或[[spell:1295924]]的伤害提高3%，最多叠加24%。

这两个增益都高度依赖[[spell:5143]]，这使得[[spell:79684]]的价值比现在要高得多。这与本次补丁的其他改动相契合，因为巅峰天赋的2级会提供节能施法，而[[spell:1243435]]不再消耗它。叠到24%然后将其用于一次强力一击是显而易见的目标，但在实践中如何最佳地消耗这些层数，我们将在
[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>).

2.3.6.

##### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师进行了一些平衡性调整：

- [[spell:1261082]]现在在你拥有20层或更多层时施放齐射会返还3层[[spell:384452]]（原为5层）。
- [[spell:444256]]对[[spell:153626]]的伤害加成提高至50%（原为10%）。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒获得了更大的重做，主要围绕光球和[[spell:449293]]：

- [[spell:448601]] 基础生成量从12%降低至6%，且[[spell:449596]]不再将上限提高至5个宝珠。取而代之的是，它会额外提供6%的生成量（总计12%），并使每个宝珠额外提供1%的法术伤害。
- [[spell:449412]]现在每个球体延长[[spell:365350]]0.8秒（原为0.4秒），最多延长2.4秒（原为2秒）。由于你恢复到最多三个球体，三个球体即可达到完全延长效果。
- [[spell:1260272]]已被重新设计。当你的奥术凤凰到期时，它不再提供[[spell:1236231]]，取而代之的是，凤凰施放的每个法术都会提供一层[[spell:449293]]，而Exceptional法术则提供两层。
- [[spell:449293]]的10层上限已被移除，[[spell:1241462]]和棱彩箭现在也能产生层数。
- [[spell:449619]]不再在[[spell:365350]]期间使[[spell:449293]]的生成翻倍。
- [[spell:449394]] 每消耗 5 层 [[spell:384452]] 召唤一个 [[spell:449569]]（原为 6 层）。

2.3.7.

##### 防御与功能

总体而言，奥术在12.1中变得稍微坚固了一些，但整体防御属性变化不大。最重要的是，奥术获得了第二个[[spell:235450]]充能，这在应对相对较低但更频繁的伤害时帮助很大。展开下方章节查看完整的防御和功能改动。

:::details **点击查看所有防御和功能性改动**
- [[spell:321745]]现在额外提供一层[[spell:235450]]充能。作为交换，其额外的魔法伤害减免从10%降至5%，并且额外15%的有害魔法效果持续时间减免被移除。
- 新天赋：[[spell:1309497]]——你受到的伤害有10%改为在8秒内结算，而不是立即结算，施放[[spell:55342]]会将此比例提高到30%，持续15秒。
- 新天赋：[[spell:1297073]]——使你受到的范围攻击伤害降低4%。
- [[spell:1244090]]仍然恢复你50%的生命值，但立即给予20%，其余30%在6秒内恢复。
- [[spell:2139]]现在在你对未在施法的目标使用时有独特的未命中视觉和音效。打断本身未变。

:::

在新的巅峰天赋、奥术脉冲重设计和套装之间，最佳天赋和输出循环都有了相当大的变化，所以请务必查看我们的
[天赋](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>),
[循环](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>) 和
[配装](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>) 页面了解详情。

:::

:::details 显示第2赛季热修隐藏第2赛季热修
2.3.8.

##### 8月18日热修复

补丁发布一周后，随着第2赛季的开始，奥术进行了一些小幅削弱，主要针对其套装：

- [[spell:1296581]]：将[[spell:5143]]的伤害加成从20%削弱到5%。
- [[spell:1296582]]：每层 [[spell:1296930]] 伤害加成由 5% 削弱至 3%，上限由 40% 降至 24%。
- 为了补偿这些削弱，所有伤害提高了3%。

套装削弱和全技能伤害增强的总体影响大约是单体目标削弱约4-5%，AOE削弱约2-3%，具体取决于所使用的装备。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜中奥术法师的改动

至暗之夜已经到来，奥术法师接受了重大重做，影响了法师职业树和奥术专精本身。在其核心，奥术仍然是关于高爆发和法力管理，但其实现方式大不相同。奥术将其许多不同的增益合并为一个单一的新资源：[[spell:384452]]，以减少需要追踪的不同资源和增益的数量。

2.4.1.

##### 顶点天赋

至暗之夜引入了一种新型天赋，称为巅峰天赋。它出现在天赋树的底部，共有四个等级。它的功能与其他天赋类似，像往常一样消耗天赋点。

对于奥术，我们获得以下巅峰天赋：

- [[spell:1257942]]：[[spell:321507]]使你的目标从你这里受到的伤害提高15%。
- [[spell:1257947]]：奥术充能会进一步提高[[spell:30451]]、[[spell:1241462]]和[[spell:44425]]的伤害。还会提高[[spell:5143]]的伤害。有2个等级。注意：这始终有效，不仅限于[[spell:321507]]期间。
- [[spell:1257950]]：当[[spell:321507]]爆炸时，会在其目标身上留下一个脉动的符文，在6秒内对附近敌人造成其伤害的75%。对最初的大法师之触目标，此伤害提高50%。

2.4.2.

##### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师没有收到重大改动，但由于专精天赋树的改动，进行了更有针对性的调整。之前提到的任何影响[[spell:44425]]的增益效果，现已改为使用新的[[spell:384452]]增益。而[[spell:443739]]现在直接由[[spell:30451]]和[[spell:1241462]]触发，而不再通过已被移除的[[spell:383782]]。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒获得的改动相对较少，主要集中在减少增益追踪上。最主要的是，[[spell:451035]]已被简化，现在只是让[[spell:30451]]和[[spell:1241462]]被动地造成更多伤害，而不是作为我们需要围绕其运作的核心触发效果。[[spell:449394]]也是如此，它过去也是一个需要围绕其运作的核心触发效果。现在它在你消耗[[spell:384452]]时降下陨石，这些陨石只是造成伤害，而不再与奥术的任何资源产生互动。

2.4.3.

##### 核心输出循环改动

主要改动之一是移除了许多不同的增益效果，如 [[spell:384452]]、[[spell:1223798]]（改为被动而非触发）、[[spell:383980]]（现在也改为被动而非触发）等，合并为一个单独的增益：[[spell:384452]]。奥术 齐射是对 [[spell:44425]] 的可叠加伤害增益，默认通过 [[spell:5143]] 叠加，但许多天赋与其互动，要么通过其他法术生成它，如 [[spell:1243557]] 让 [[spell:30451]] 和 [[spell:1241462]] 也能生成它，要么 [[spell:384858]] 根据齐射层数而非 奥术 充能来提高触发几率。

这一切意味着，你几乎所有的循环决策都将围绕[[spell:384452]]、你的奥术充能层数以及你的法力值展开，而无需追踪多个不同的增益效果。唯一剩下的例外是[[spell:79684]]，它像以前一样在循环中扮演关键角色，因为它是施放[[spell:5143]]的唯一途径。

在实际调校的情况下，这个专精变得关于尽可能快地生成最大数量的[[spell:384452]]层数，然后立即消耗它们以开始重新积累。

最后一个重要的变化是引入了[[spell:1241462]]，这是一个新的远程范围伤害技能。它的运作方式与[[spell:30451]]非常相似，因为伤害和法力值消耗会随奥术充能层数变化，只是它造成的是范围伤害。它不能完全取代[[spell:1449]]，因为两者都可以使用，但在大多数实际情况下，它确实成为了你在范围伤害场景中的主要填充技能。由于它是远程的，这是一个极大的生活质量改善，因为这意味着你不再需要近身才能造成范围伤害。

2.4.4.

##### 其他改动

- 法师的防御技能已整合并简化：
  
  
  
  
  ►
  **点击展开**
  
  
  
  
  - [[spell:235450]] 现在变得更强了。当点出所有相关天赋时，它现在提供更多的吸收量（最大生命值的30%），以及更多的受到的魔法伤害和减益持续时间降低。它的公共冷却时间也更短，让你能更快回到输出中。
  - [[spell:110959]]和[[spell:55342]]不再降低受到的伤害——它们现在是纯粹的功能性法术。
  - [[spell:414660]]已被移除。
  - [[spell:1244090]]已加入，使你能在生命值降低后自我治疗，代价是对[[spell:342245]]的部分手动控制。操控时间通常主要用于应对高爆发伤害，但通过时间调整，它在因持续性伤害导致生命值偏低时也能用于自我恢复。
- 法师的机动性略有降低，现在需要做出一些取舍：
  
  
  
  
  ►
  **点击展开**
  
  
  
  
  - [[spell:212653]]现在基础只有1层充能（原为2层）和30秒冷却时间（原为25秒）。你可以找回失去的充能层，但现在这需要在[[spell:1270829]]和额外充能层之间取舍。
  - [[spell:1953]]现在可以通过天赋强化：[[spell:1244031]]提供额外充能层，[[spell:1244340]]缩短其冷却时间。
  - [[spell:108839]]已被移除。
- 各种功能性天赋已被削弱或改为抉择节点：
  
  
  
  
  ►
  **点击展开**
  
  
  
  
  - [[spell:382440]]已被完全移除。
  - [[spell:157981]]已从基础技能中移除（仅能通过日怒天赋获取，但非常依赖情境）。
  - [[spell:157997]]和[[spell:120]]现在互斥。
  - [[spell:383121]]和[[spell:113724]]现在互斥。
  - [[spell:2139]]现在打断持续7秒（原为5秒）。

1.

### 奥术法师玩法基础

奥术 法师是一个高度依赖冷却时间的专精。在[[spell:365350]]和类似冷却期间它可以造成大量伤害，而在冷却期间之外伤害相当低。作为一名奥术 法师，你还需要考虑你的法力值，因为你威力最大的法术消耗大量法力值。这进一步凸显了妥善使用冷却时间的重要性，因为你的冷却时间是管理法力值的主要方式。[[spell:12051]]（如果点了天赋）会在几秒钟内为你回复全部法力值，而奥术 Surge在激活期间为你提供的法力回复速度超过你的消耗速度。

你大部分时间将用于施放[[spell:30451]]，因为这是你的主要法力消耗法术。此外，奥术会使用各种冷却技能，如[[spell:365350]]来提升你在耗尽法力值期间造成的伤害。在执行输出循环时，你会积累[[spell:384452]]层数，以大幅增加你下一个[[spell:44425]]的伤害，最终消耗它们以造成一次巨大伤害，重置你的奥术充能和奥术齐射层数，重新开始这个过程。

为了进一步精简，以下要点拆解了奥术法师的核心思路。

- ![](<https://static.icy-veins.com/images/wow/large_icons/8026694.jpg>) **不要浪费棱彩箭矢**
  
  
  
  
  [[spell:1295924]]是一个伤害非常高的法术，它还会为你提供4层[[spell:36032]]。因此，如果你施放[[spell:44425]]并触发了棱彩飞弹，你应该立即接着施放它，这一点非常重要。这需要相对快速的反应时间，但正确做到是非常值得的。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_arcanesurge.jpg>) **奥术涌动至关重要**
  
  
  
  
  当你法力值耗尽时，整个循环就会停止运作，你基本上就无法再造成伤害了。除了被动恢复之外，你最大的法力值来源是 [[spell:365350]]，它本身也是一个巨大的 DPS 提升。因此，你绝不能长时间保留 奥术 激涌去等待一个完美的时机。即使使用时机不完美，也比延迟使用要好。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_arcanesalvo.jpg>) **避免溢出 奥术 齐射**
  
  
  
  
  [[spell:384452]]能极大提升你的[[spell:44425]]伤害，优化这一点是你输出循环的重要部分。然而，很容易浪费奥术齐射层数，例如在接近25层上限时使用[[spell:5143]]。在这种情况下，你实际上应该使用[[spell:30451]]来补足到25层，然后再用奥术弹幕，这样就不会溢出齐射层数。

1.

### 如何为 奥术 法师 配装

虽然我们始终建议你使用模拟来获得理想的结果，但我们确实提供了专门的奥术配装页面。我们目前涵盖了第2赛季装备的推荐，以便在终局至暗之夜内容发布时有一个良好的开端。一旦你获得了一些装备，你就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为催化物品列表添加了掉落位置。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 已针对12.1.5补丁进行更新（新增团队副本和迷宫链接、法术密度调整），将12.1补丁和第2赛季的热修复移入下拉菜单，并移除了第1赛季的变更。
- **2026年10月9日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了毕业装备以显示升腾毒石的升级物品等级，并添加了升腾毒石升级指南，以及添加了基斯希克斯掉落。
- **2026年9月3日（本页面）：** 根据史诗进度和早期大秘境冲层更新了强度评估部分。
- **2026年9月1日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了一些增益ID，以确保它们正确显示毒咒效果的提示信息。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 在制造物品的提示中添加了制造属性。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已更正为正确的团队副本名称。
- **2026年8月23日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了制作优先级，以更清楚地解释双手武器与副手制作的利弊。
- **2026 年 8 月 17 日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 更新了最佳药水。
- **2026年8月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了毕业装备和专业制作建议，使用猎人的仪式石和其他小优化。
- **2026年8月15日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对赛季开始时的职业削弱进行更新。
- **2026年8月15日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对赛季开始时的职业削弱进行更新。
- **2026年8月15日（本页面）：** 已针对赛季开始时的职业削弱进行更新。
- **2026年8月12日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 将起手式更新为新的起手式，效果提升0.5%，并微调了循环的其余部分。
- **2026年8月12日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 修复了在日怒下显示疾咒师而不是日怒的问题。
- **2026年8月10日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 为12.1的改动更新了法术，包括新的棱彩飞弹顶峰天赋。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 添加了12.1补丁和第2赛季的改动，包括新的巅峰天赋和套装，并将第1赛季的改动总结到了一个下拉菜单中。
- **2026 年 6 月 30 日（本页）：** 添加了6月30日/7月1日每周重置后带来的改动。
- **2026年6月17日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据补丁后更新的理论计算更新了毕业列表和最佳饰品。
- **2026年6月15日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据新的孢子融合装备更新了毕业列表和饰品推荐。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 添加了关于万世卷册的部分。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 添加了12.0.7的改动。
- **2026年5月23日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 根据5月26日/27日的改动更新了天赋选择及说明。
- **2026年5月23日（本页）：** 添加了5月26日/27日的补丁说明及其影响的快速解释+由于增强更新了可行性。
- **2026年4月20日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 新增了幽邃虚空核心和升腾虚空核心部分，并根据武器/饰品的新物品等级上限更新了最佳装备列表。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 更新了功能部分的布局，并为打断和功能添加了一些额外的说明。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为12.0.5的奥术脉冲改动更新了输出循环。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 添加了12.0.5的更改。
- **2026年4月4日（本页面）：** 根据最新的调整和史诗难度数据更新了可行性部分。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 将无常能量熔炉饰品添加到饰品层级列表中。
- **2026年3月26日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 更正了奥术宝珠的使用等级，从21级改为23级。
- **2026年3月24日（本页）：** 移除了关于史诗周即将到来的改动的部分，因为奥术在史诗周开始时没有收到任何改动。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 移除了茶的提及，因为它在副本中不起作用。
- **2026年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 添加了优先DPS与最大AoE DPS部分。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据天赋页面的更新更新了默认天赋选择。
- **2026年3月17日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了大秘境天赋以加入 奥术 脉冲，从而最大化AoE伤害输出，因为其对单体伤害的降低非常有限。
- **2026年3月17日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 重新添加了 奥术 脉冲在AOE中用于AOE，以获得更好的AOE输出。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 添加了一些关于传家宝装备和一般练级建议的有用链接，并添加了关于练级时使用哪些传家宝的部分。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 将赛季前毕业装备列表替换为3个不同的第1赛季毕业装备列表（总体、团本、大秘境），更新了第1赛季的制造信息，添加了第1赛季饰品天梯榜。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 更新了奥术涌动宏，默认包含所有相关种族技能/饰品栏位。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 将戒指附魔更新为使用鹰眼而非属性附魔，因为它在几乎所有情况下都稍微好一点。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 更新了急速常见问题，补充了更多背景信息。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜第1赛季更新：更新了最佳天赋、灵活天赋，添加了赛季词缀等。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为第1赛季开始添加了套装部分。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了推荐天赋配置，以区分史诗钥石每周钥匙和冲层，并更新了第1赛季调整后的最佳天赋。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为第1赛季开始添加了套装章节。
- **2026年3月16日（本页面）：** 增加了第1赛季的改动+新内容，并更新了第1赛季开始时的表现。
- **2026年3月9日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 修复了指向 解除诅咒 的鼠标悬停宏。
- **2026年3月8日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 在最新的理论计算更新后，完全将奥术脉冲从单体输出循环中移除。
- **2026年3月5日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 由于热修复移除了回响触发双层 奥术 弹幕层数的效果，更新了 奥术 脉冲的使用说明。
- **2026年3月5日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为3月5日的在线修复更新了天赋树（修复/削弱了奥术脉冲，使其在配合回响时不再提供双倍的齐射层数）
- **2026年3月5日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为3月5日的在线修复更新了天赋树（修复/削弱了奥术脉冲，使其在配合回响时不再提供双倍的齐射层数）
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 加入了80级天赋树，以便在开始至暗之夜练级时轻松导入。
- **2026年3月1日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 在食物部分添加了茶类及其移动速度加成。
- **2026年2月27日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了关于奥术 Salvo使用的措辞，使其更加具体。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了至暗之夜上线的构筑和循环。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 根据预补丁的平衡性调整更新了天赋树。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 针对前夕补丁平衡性调整更新了天赋树和循环。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为12.0.1天赋树改动更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为 日怒 和 疾咒师 优化了 奥术 激涌序列。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为12.0.1天赋树改动更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为12.0.1天赋树改动更新了天赋树。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已针对至暗之夜前夕进行审查。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 将优劣势更新为更具信息量的格式 + 为11.2.7进行了更新。
- **2025年10月5日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为11.2.5更新了物品等级（涡轮加速物品等级），添加了谜之帮派章节，并针对无限徽记更新了制造推荐。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为确保对所有配装方案的准确性，为纤维推荐添加了更多说明。
- **2025年9月5日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为 疾咒师 稍微更新了默认天赋开关。
- **2025年9月5日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 更新了套装免责声明，表明此页面在有无套装的情况下均适用，因为针对推荐的英雄天赋，推荐的循环和天赋不会改变。
- **2025年8月25日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 改进了法师天赋树的升级路线，以修复一个小问题，并在前期获得更多机动性，从而更快地穿越世界。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据饰品调整和新发现更新了最佳饰品。
- **2025年8月15日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 略微更新了 日怒 的单体和顺劈天赋，由于各种bug不再选择魔息之光，且时间循环的DPS相同且更易操作。
- **2025年8月15日（本页）：** 根据PTR调整后的数据和实际游戏活动更新了可行性章节。
- **2025年8月15日（本页）：** 略微更新了天赋，不再选择巫师之火，原因是各种bug，而时间循环DPS相同且更容易操作。
- **2025 年 8 月 10 日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了基础输出循环，使其更简单且DPS略有提升。
- **2025 年 8 月 10 日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 更新了基础输出循环，使其更简单且DPS略有提升。
- **2025年8月5日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 在饰品列表中添加了更多饰品，并略微更新了大秘境毕业装备。
- **2025 年 8 月 4 日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 针对11.2进行了审阅。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 针对11.2.0更新了毕业列表、饰品推荐、制作顺序，添加了Reshii章节
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.2.0进行更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 更新了11.2的最佳构筑，新增了第三赛季实用法术部分。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据11.2版本的改动，更新了单体和AoE的最优输出循环，并添加了套装循环改动章节。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为11.2.0更新了所有天赋配置，并根据改动更新了推荐天赋。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 根据11.2.0的改动更新了法术。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 根据11.2的改动和套装奖励，更新了最佳循环、天赋和英雄天赋。
- **2025年8月4日（本页面）：** 新增了11.2版本信息，并移除了一些旧版本改动。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已更新关于随重置而来的改动的DISC腰带信息。
- **2025年6月17日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 略微更新了持久信息保障容器腰带的信息，以显示不同加成的百分比收益。
- **2025年6月17日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月17日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月15日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已为 11.1.7 进行审查。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 添加了持久信息保密容器腰带信息和最佳奖励，并为新腰带更新了毕业列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了战斗助手信息和提示。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 添加了战斗助手信息和提示。
- **2025年6月15日（本页）：** 添加了11.1.7补丁信息。
- **2025年5月20日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为没有神经突触增强器的人添加了 House of Cards 作为潜在的 Puzzling Chips 选项。
- **2025年5月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 将物品等级更新为涡轮增压物品等级，更新了推荐饰品并提供了更多背景信息和选项，更新了财团芯片并提供了更多背景信息和不同的路线推荐。
- **2025年4月27日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 用最新信息更新了谜之卡特皮尔代币部分。
- **2025年4月21日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已针对11.1.5进行审查。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已更新至11.1.5版本。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 添加了赝品经销商芯片部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 添加了腐蚀附魔章节。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 添加了11.1至11.1.5之间的改动。
- **2025年3月22日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 移除了起手打断提示，因为它们无法被迷惑打断。
- **2025年3月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 移除了不需要的章节。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 根据操控时间治疗改动，更新了操控时间在应对治疗吸收时的使用说明。
- **2025年3月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了制作顺序，以更清晰地划分早期制作与毕业制作。
- **2025年3月14日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为所有地下城添加了提示。
- **2025年3月13日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 添加了加里维克斯的提示，并根据实际击杀更新了一些首领提示。
- **2025年3月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了制作选项，突出了在拥有多个插槽之前的更好前期配置。
- **2025年3月10日（本页）：** 根据第1周的表现更新了可行性章节。
- **2025年3月2日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 微调了奥术弹幕的触发条件，使高压使用更容易理解，并在不同天赋配置下更加一致。
- **2025年3月1日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 基于测试服添加了提示。
- **2025年2月26日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 略微更新了奥术弹幕的使用，以确保不丢失直觉/奥术节奏，并使范围伤害循环在集中输出与纯范围伤害之间更清晰。
- **2025年2月25日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了最佳饰品，同时推荐将协同酿造器作为卡赞之眼的潜在替代品。
- **2025年2月24日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 针对11.1.0进行了审查。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为11.1的改动更新了天赋和输出循环。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了第2赛季/11.1版本的毕业装备，根据新的毕业物品更新了制造推荐，根据新饰品更新了饰品推荐。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 由于 11.1 的改动，将全能列为第二好的副属性。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 根据11.1的改动更新了最佳天赋，并针对新的词缀更新了词缀提示。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对11.1的改动进行了更新：新的默认设置设定为疾咒师，根据改动更新了新的最优输出循环，并将输出循环分为基础 - 中级 - 高级。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了11.1版本的最佳天赋：为重新调整后的天赋树提供了新的最优天赋树，并更换了 疾咒师 的整体推荐天赋。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 根据11.1的改动更新了法术。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已为11.1更新：针对11.1的改动和套装奖励，更新了最优输出循环、属性、天赋和英雄天赋。
- **2025年2月24日（本页面）：** 增加了11.1版本最重要的改动概述，更新了11.1版本的可行性，进一步精简了页面内容以聚焦于攻略中最重要的方面。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 在增强后更新了Cyrce的指环建议，并在它变得更好后更新了毕业装备以包含它。
- **2024年12月15日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 为11.0.7进行了审阅。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 添加了Cyrce's Circlet章节。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了页面布局，将不同的英雄天赋拆分到各自的部分，并添加了推荐标签以便更快地找到最佳构筑。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 略微更新了输出循环。
- **2024年12月15日（本页）：** 为11.0.7补丁增加了说明，并更新了11.0.7版本的可行性。
- **2024年10月30日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了日怒天赋以选择挫志之课而非重力坠落。
- **2024年10月27日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的理论计算发现更新了循环，主要简化了法术迸发的使用方式，同时略微提升了DPS。
- **2024年10月23日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 对法术飞弹的AoE循环进行了小幅修改，并在进阶章节下为单体循环添加了奥术节奏条件。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 根据最后时刻的削弱更新了天赋。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 将输出循环的各个部分移到进阶部分，以提供更易上手的默认输出循环，并修复了法术射手输出循环显示部分日怒行的问题。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 根据最后一刻的削弱更新了天赋。添加了单体法术射击配置。
- **2024年10月22日（本页）：** 由于法力涌流在测试服被削弱回了出bug前的数值，已从ptr中移除了关于其改动的说明。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 针对11.0.5重做进行了更新，并稍微简化了输出循环。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了毕业装备和饰品梯队列表，将发射器列为第二佳饰品。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为11.0.5改动更新了最佳天赋。添加了疾咒师与日怒的对比信息。添加了副本专属提示。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了两种英雄天赋的单目标和AOE循环以适应11.0.5变更。添加了疾咒师预设，因为现在它是一个更可行的英雄天赋配置。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了11.0.5的最佳天赋。为疾咒师和日怒添加了多个AOE构筑。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 为11.0.5改动更新了法术。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 针对11.0.5的重做更新了天赋和输出循环。
- **2024年10月21日（本页）：** 添加了11.0.5改动及其对指南的影响。为11.0.5更新了可行性部分。
- **2024年9月25日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了AoE输出循环以列出目标数量。
- **2024年9月24日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 修正了副手制造错误关联的专业。
- **2024年9月21日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 更新了属性权重的描述，更清楚地解释了使用最优装备（Top Gear）模拟更好。
- **2024年9月20日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 为多个首领添加了更多提示，为各个首领添加了精确的冷却使用说明，并为安苏雷克女王添加了冷却大纲。
- **2024年9月16日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的改进略微更新了输出循环。
- **2024年9月14日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了地下堡天赋，使其造成略高的范围伤害。
- **2024年9月14日（本页面）：** 在最新削弱后更新了可行性章节。
- **2024年9月11日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 新增了武器消耗品（油）。
- **2024年9月11日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 略微更新AOE循环，将ToTM期间的奥术冲击行移至法术投射循环，因为日怒已经自动执行了。
- **2024年9月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 补充说明：你可以在非火花装备上制作装饰品。
- **2024年9月9日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 更新了输出循环，由于【能量之负】被移除，不再重复触发其效果。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 从不同来源添加了3份毕业列表：团队副本、大秘境、综合。添加了饰品梯队列表。从制造文本中移除了免责声明。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 添加了幻影亵渎宝石作为选项，以牺牲少量伤害为代价换取更高的移动速度。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 由于第1赛季装备解锁更好，已更新属性优先级，使急速优于精通。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已更新至地心之战第1赛季。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 分离了英雄天赋选择器，并将循环更新为以可选复选框的形式包含更多进阶内容。重写了奥术弹幕的使用方式，使其更易于理解。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 移除了赛季前天赋。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 由于游戏中移除了力量的重担，删除了其双重受益的提及，并在漏洞修复后删除了点燃未来的漏洞提及。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 更新了输出循环，使其略优但难度相当，并更新了第1赛季的属性优先级。
- **2024年9月9日（本页）：** 更新了基础部分和可行性部分。
- **2024年9月5日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 对AOE/顺劈天赋进行了小幅改进。
- **2024年9月3日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了专业制作建议和毕业装备列表。
- **2024年9月2日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新循环以移除力量重担的双重加成。
- **2024年9月2日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 修复了地下堡英雄树中缺失的一个点。
- **2024年8月28日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 更新了一些法术说明。
- **2024年8月27日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了关于更新后的装饰的制作建议，并更新了毕业列表。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 添加了地下堡天赋树。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了AoE输出循环，以阐明单体输出循环与AoE输出循环的使用区别。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 略微调整了单体循环的优先级，以明确如果你拥有力量重负，应先使用飞弹再倾泻它，并对 AOE 做了一些小的可读性改进。
- **2024年8月21日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月30日（[外观](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** 页面已添加。
- **2024年7月30日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 修正了整体毕业列表中缺少4件套的问题。
- **2024年7月26日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 奥术 在 奥术 Tempo 行中，并稍微更新了 AoE 输出循环，以更清楚地表明在拥有 4 层充能时，始终在 奥术 飞弹之前使用 奥术 弹幕。进一步改进了虚空精准的说明，以应用更多优化。
- **2024年7月25日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 在输出循环中加入 奥术 飞弹的打断条件，将爆发阶段重新组织为 2 个独立的部分，初始爆发阶段序列，纳入优先级列表。
- **2024年7月24日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 节能施法触发率在正式服上发生了变化，导致奥术冲击的触发率比奥术弹幕高5%。更新了循环以纳入这一变化，移除了奥术弹幕的斩杀玩法。
- **2024年7月24日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 根据正式服服务器的bug对建议天赋进行了小幅更新。
- **2024年7月24日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 由于启迪之思在正式服务器上已修复，使其明显强于测试服和 ptr，更新了推荐天赋。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/arcane-mage-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/arcane-mage-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/arcane-mage-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月12日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 略微更新了天赋和输出循环。
- **2024年5月10日（本页面）：** 更新了强度评估部分。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为第4赛季更新：更新了毕业列表，添加了铸币物品，更新了推荐的专业制造。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 新增了头部附魔（灼热精华）并更新了药剂建议
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 添加了第4赛季的变更并更新了可用性章节。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 为10.2.6进行了复查，移除了一个已不再相关的插件包链接，并为奥术弹幕 + TOTM添加了新的宏。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.6补丁进行审阅，并添加了关于最佳宝石的说明。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 针对 10.2.6 补丁进行了审阅，并更新了天赋选择信息。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6版本进行审查，修正了一些错别字，并删除了“安静移动”部分，因为它与其他部分重复。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查，修复了一些拼写错误并更新了一些缩写。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对10.2.6进行审查。
- **2024年3月19日（本页面）：** 针对10.2.6进行了审阅，并对可行性部分进行了一些小幅更新。
- **2024年3月15日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 移除了不再相关的奥术飞弹取消后摇部分。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新循环并加入已发现的优化。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 更新了输出循环，使其更简单且伤害略高。
- **2024年1月15日（本页）：** 用10.2.5版本的改动替换了10.2版本的改动。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年12月16日（本页）：** 根据12月19日的增益更新了可行性部分。
- **2023年11月24日（本页）：** 根据正式服数据更新了可行性部分。
- **2023年11月13日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据不同的大秘境掉落更新了毕业装备，并更新了仅限团本的毕业装备。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 由于孢子披风削弱，更新了毕业装备和纹章。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 为10.2更新了毕业装备、美化及其他相关部分。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对10.2补丁进行审核。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 移除了关于奥妮克希亚的回忆和原始宝石的参考，因为它们在10.2版本中已不再相关。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对10.2补丁进行审核。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 更新了10.2版本的天赋。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为10.2更新了基础循环，添加了第3赛季套装循环、第3赛季饰品和其他物品到循环中。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了10.2版本的最佳天赋。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对10.2补丁进行审核。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为10.2改动更新了天赋和输出循环。
- **2023年11月6日（本页）：** 添加了10.2版本改动章节，移除了旧的改动章节，更新了可行性章节。
- **2023年10月1日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 更新了食物增益建议。
- **2023年9月26日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更改了布局。
- **2023年9月7日（本页）：** 更新了可行性部分，添加了更多细节。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 添加了3种不同的毕业配装。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已为10.1.7版本审核。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更改了天赋布局，使其更易于浏览。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 添加了10.1.7指南变动。
- **2023年8月9日（本页）：** 在 火焰 和 冰霜 削弱后更新了可行性。
- **2023年7月15日（本页）：** 针对平衡性补丁更新了可行性。
- **2023年7月11日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为新的天赋树更新了升级天赋树。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 因重做而更新了新最优装备的毕业装，并更新了奥妮克希亚的紫晶指环部分以反映削弱后的版本。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5版本的削弱更新了Onyx Annulet部分，并审核了其余部分以配合10.1.5版本中奥术的重做
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对10.1.5版本的奥术重做进行审核。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为重做的奥术更新了推荐天赋和输出循环。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了重做后的奥术的输出循环。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了10.1.5 奥术改动后的推荐天赋。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 根据10.1.5版本的奥术法师重做更新了所有法术和天赋
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为 10.1.5 的 奥术 重做更新了输出循环和天赋
- **2023年7月10日（本页）：** 添加了10.1.5改动章节，并针对10.1.5更新了可行性章节。
- **2023年5月25日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 添加了时光漫游部分。
- **2023年5月10日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据进一步的改进更新了饰品建议。
- **2023年5月9日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了输出循环，加入了进一步的4件套优化。
- **2023年5月8日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据改进的模拟和进一步的理论计算更新了饰品建议。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了10.1版本的毕业装备、制造建议和其他配装建议。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 移动了原始石信息，并根据10.1的改动更新了建议。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 由于10.1的改动更新了属性优先级。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 移除了关于雷鸣的提及，并针对10.1的改动进行了审查。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 更新了输出循环，加入了第2赛季套装优化。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 更新了一些描述使其更清晰，并清理了一些重复的法术。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为10.1补丁进行了复查。
- **2023年5月1日（本页）：** 添加了 10.1 变更，添加了一个部分指出为 10.1 制作的指南主要变更，并为 10.1 调整更新了可行性部分。
- **2023年4月28日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 添加了一个通用WeakAuras包，包含所有专精所需的全部WeakAuras。
- **2023年3月25日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据在线修复更新了Onyx戒指建议。
- **2023年3月25日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 根据热修复更新了原始石宝石建议。
- **2023年3月22日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 更新了最佳装备以包含昂赛恩戒指，因为发现了新的宝石组合。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 由于 Desirious Blood Stone（渴血之石）的组合非常强大，更新了始源之石的宝石建议。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 根据晦暗粉彩石在正式服务器上是奥术而非暗影，更新了原始石宝石建议。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/arcane-mage-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 添加了奥妮克希亚的指环信息，并针对 10.0.7 补丁进行了审阅。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 添加了原初之石宝石建议，并针对10.0.7补丁进行了审核。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审阅并提供了一些小的措辞调整。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 为原始宝石添加了附魔和宝石页面的链接。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 将虚空缝补者的暗影宝石添加到饰品列表中。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月20日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 修正了错别字。
- **2023年1月18日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据最新的理论分析更新了爆发循环，并扩展了AoE循环。
- **2023年1月16日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 将推荐天赋更新为法力宝石构建，并进行了一些小的提示更改。
- **2023年1月16日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 添加了关于法力宝石配装以及何时选择和谐或法力宝石配装的信息。
- **2023年1月13日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 改进了法力宝石输出循环并添加了爪击的使用。
- **2023年1月12日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 新增了法术线建议。
- **2022年12月17日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 由于青铜护手的改动，更新了制造装备信息。
- **2022 年 12 月 14 日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 添加了武器灌注建议。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据最新的理论计算知识进一步更新了制造装备信息。
- **2022年12月13日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 更新了药水建议。
- **2022年12月13日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 略微改进了燃烧阶段的循环，并在燃烧阶段结束时增加了更多说明。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 对升级天赋树的细微改动。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 根据第1赛季可用装备和制作装备更新了装备建议。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 补充了制造装备的相关信息。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 更新了药水建议。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 根据更好的模拟结果更新了宝石建议。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 添加了解释因套装而导致的输出循环变化的章节。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 对推荐天赋树进行了小幅调整，将其更多地分为团队副本与地下城两套，而非单体目标与AoE两套。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月30日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 根据新的理论计算略微更新了爆发输出循环。
- **2022年11月30日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 更新了时间扭曲与时间异常的描述，使其更具信息量。
- **2022年11月30日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 根据时间扭曲功能的改动更新了时空扭曲的描述。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/arcane-mage-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/arcane-mage-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/arcane-mage-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022 年 1 月 22 日（[9.2版本分析](<https://www.icy-veins.com/wow/arcane-mage-patch-9-2-changes-analysis>)):** 已更新至9.2补丁。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/arcane-mage-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/arcane-mage-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/arcane-mage-patch-9-1-changes-analysis>)):** 已针对9.1补丁团队副本发布进行更新。
- **2021年4月25日（[9.1 补丁分析](<https://www.icy-veins.com/wow/arcane-mage-patch-9-1-changes-analysis>)):** 页面创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2019年7月20日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** 新增了阿扎莎的技巧。
- **2019年7月16日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** 移除了免责声明。
- **2019年7月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** 添加了首领提示。
- **2019年7月10日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** 添加了初始天赋建议。
- **2019年7月7日（[永恒宫殿页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月12日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** 添加了更多提示。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 2 月 3 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了财富战利品的提示。
- **2019年1月30日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 已针对吉安娜昏迷热修复进行更新。
- **2019年1月28日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 添加了更多吉安娜信息和建议。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为奥术法师添加了达萨罗之战指南。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年8月30日（[奥杜尔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** 为英雄和普通难度添加了攻略和天赋推荐。
- **2018年8月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** 添加了奥术 法师首领逐个页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页面，你将找到我们的逐级奥术法师练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[法师升级指南](<https://www.icy-veins.com/wow/mage-leveling-guide>).

1.

### 法师 奥术练级指南——至暗之夜

奥术 法师在户外内容中非常强大，因为在进行户外内容时由于有大量的空闲时间，基本上拥有无限的法力值。因此，只需始终保持4层奥术充能，就能有效地秒杀大多数户外敌人。所以，单纯做任务就是一种非常高效的升级方式。它还不时可以使用[[spell:66]]，让你绕过敌人来加快任务进度！

话虽如此，奥术在地下城内容中也非常强大，能打出惊人的伤害输出，尤其是在40级左右你开始解锁大部分技能之后。如果你有一些朋友（尤其是坦克或治疗），组队刷地下城非常高效。如果你是单人游玩，作为输出职业排地下城的等待时间会让这种方式变得不切实际。

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的战利品。这条规则唯一的例外是，如果你有一个物品等级稍低的戒指或项链，但它有两个副属性而不是一个。

使用传家宝物品时，我们通常推荐一个 [[item:122362]] 饰品来提供续航，以避免在敌人之间需要吃喝，但另一个饰品栏位通常应该是任何提供属性加成的主动使用饰品，这些属性来自地下城或任务，或者干脆装备第二个敏锐的比斯巨兽之眼，以避免需要考虑更换饰品。

对于其他传家宝，我们建议尽可能使用带有精通和暴击属性的装备，但由于所有属性的价值都非常接近，实际上使用任何属性都不会出错。

1.2.

#### 至暗之夜中实用的升级消耗品

在本节中，我将重点介绍一些在至暗之夜升级时有用的消耗品。这些将主要专注于速度，包括你的移动速度，当然还有你实际的伤害输出。

- [[item:223653]]——靴子速度附魔。需要等级70。
- [[item:223800]] — 披风速度附魔。需要等级70。
- [[item:223725]] — 护腕速度附魔。需要等级70。
- [[item:225592]] — 提供大量移动速度。需要等级75。
- [[item:172063]]或[[item:133576]]——较旧的加速增益，如果它们便宜得多或者你恰好有之前资料片的存货，可能会有用。其中大多数需要等级55。

1.

### 升级天赋

在下面，你可以看到推荐的练级天赋方案以及练级时选择天赋的顺序。下面的天赋方案在地下城和户外内容中都非常出色。

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 奥术 80级 至暗之夜升级
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFegZGamZGAAAGAwMzkFmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMgZAAGzA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFbzMDNzMDAAADAYmZaWWWmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMwMDAGGzA"
}
```
:::

:::details 来源计算器编码
```
#+A-VSdXWCji4aZdJmkB0gBbCxrg8bQwGEE65TT-NcRkGXbEKdG7YghRBWImd8FCZZJRTbC-AAAA-DSEAGaYWUMcARB-
```

:::

**等级 20 起：**2.1.

#### **等级 20 起：**升级用战争模式天赋

**等级 20 起：**在本节中，我们将对最适合升级以及进行单人/小队PVE内容的PVP天赋进行排名。

1. [[spell:235711]]是巨大的机动性提升，在开放世界中对风筝敌人非常有帮助。
2. [[spell:198111]]可以说是游戏中最好的防御技能，因为它不占用全局冷却，且冷却时间相对较短，可以让你在面对大多数敌人时规避伤害。
3. [[spell:210476]]和[[spell:414664]]都是你可以选择用来帮助你在穿越怪物密集区域时跳过更多怪物的法术。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 8 起：**确保你始终保持[[spell:1459]]。请记住，如果你死了，你必须重新施放它。否则每小时施放一次即可。
2. **等级 49 起：**在你即将进行大规模拉怪或首领战时施放[[spell:80353]]。请记住，即使冷却时间是5分钟，你也只能每10分钟获得一次增益效果。
3. **等级 2–9：**卡冷却时间使用[[spell:319836]]。
4. **等级 11–78：**当你拥有 [[spell:79684]] 且少于20层 [[spell:384452]] 时，施放 [[spell:5143]]。
5. **等级 79 起：**当你拥有[[spell:79684]]且[[spell:384452]]层数少于25层时，施放[[spell:5143]]。
6. **等级 81 起：**可用时施放 [[spell:1295924]]。
7. **等级 75 起：**当 [[spell:451038]] 激活时施放 [[spell:44425]]。
8. **等级 13–77：**当你有4层奥术充能和20层[[spell:384452]]层数时，或者当敌人生命值较低且奥术弹幕能终结他们时，施放[[spell:44425]]。
9. **等级 78 起：**当你拥有4个 奥术 充能和25层 [[spell:384452]] 时，或当敌人生命值较低且 奥术 弹幕能将其击杀时，施放 [[spell:44425]]。
10. **等级 23 起：**当你没有4层奥术充能时，施放[[spell:153626]]。
11. **等级 19 起：**一旦 [[spell:365350]] 就绪并且你有4个 奥术 充能时就施放它。
    **等级 29 起：**确保在使用奥术涌动之前准备好[[spell:321507]]。
12. **等级 29 起：**如果 [[spell:321507]] 已就绪并且你拥有 4 层 奥术 充能，施放 [[spell:44425]]，紧接着使用大法师之触。确保在 奥术 弹幕落地之前施放大法师之触。
13. **等级 10 起：**施放[[spell:30451]]作为你的填充技能。
14.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月26日：** 更正了奥术宝珠的使用等级，从21级改为23级。
- **2026年3月16日：** 添加了一些关于传家宝装备和一般练级建议的有用链接，并添加了关于练级时使用哪些传家宝的部分。
- **2026年3月2日：** 加入了80级天赋树，以便在开始至暗之夜练级时轻松导入。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025 年 8 月 25 日：** 改进了法师天赋树的升级路线，以修复一个小问题，并在前期获得更多机动性，从而更快地穿越世界。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已更新至11.1.5版本。
- **2025 年 2 月 24 日：** 为11.1的改动更新了天赋和输出循环。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5重做进行了更新，并稍微简化了输出循环。
- **2024年9月9日：** 更新了输出循环，由于【能量之负】被移除，不再重复触发其效果。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月12日：** 略微更新了天赋和输出循环。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023 年 7 月 11 日：** 为新的天赋树更新了升级天赋树。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 对升级天赋树的细微改动。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页面中，我们将讲解如何在《魔兽世界》12.1.5补丁中轻松游玩奥术法师，使用最简单的输出循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 奥术法师基础篇

本章节适用于对游戏或职业不熟悉的玩家，没有打史诗难度团本的打算，或者只是想以更直接的方式进行游戏，而不会被为实现最优操作所需考虑的众多优先级和主动技能所淹没。

奥术是一把出色的瑞士军刀，拥有应对任何情况的完整工具箱。它提供强大的爆发以及令人印象深刻的AOE能力。它还具备极高的机动性，并配备各种减伤法术和冷却技能。在本节中，我们将专注于一种在不过度损害整体输出的前提下，最大限度减少所需按键数量和反应速度的配置。学习该专精时需要遵循的三条快速规则是：

- ![](<https://static.icy-veins.com/images/wow/large_icons/8026694.jpg>) **不要浪费棱彩箭矢**
  
  
  
  
  [[spell:1295924]]是一个伤害非常高的法术，它还会为你提供4层[[spell:36032]]。因此，如果你施放[[spell:44425]]并触发了棱彩飞弹，你应该立即接着施放它，这一点非常重要。这需要相对快速的反应时间，但正确做到是非常值得的。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_arcanesurge.jpg>) **奥术涌动至关重要**
  
  
  
  
  当你法力值耗尽时，整个循环就会停止运作，你基本上就无法再造成伤害了。除了被动恢复之外，你最大的法力值来源是 [[spell:365350]]，它本身也是一个巨大的 DPS 提升。因此，你绝不能长时间保留 奥术 激涌去等待一个完美的时机。即使使用时机不完美，也比延迟使用要好。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_arcanesalvo.jpg>) **避免溢出 奥术 齐射**
  
  
  
  
  [[spell:384452]]能极大提升你的[[spell:44425]]伤害，优化这一点是你输出循环的重要部分。然而，很容易浪费奥术齐射层数，例如在接近25层上限时使用[[spell:5143]]。在这种情况下，你实际上应该使用[[spell:30451]]来补足到25层，然后再用奥术弹幕，这样就不会溢出齐射层数。

1.

### 至暗之夜中法师的奥术专精新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒团队副本天赋

2.1.

#### 奥术法师新手团本天赋

此构筑是首选的团本构筑，因为它有出色的单体伤害，同时在需要时也能打出非常高的AOE和顺劈伤害，而几乎不牺牲单体伤害。

你可以通过下面的"复制导出字符串"按钮，轻松地将下方的天赋树导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMmZmBAYAAAGgZGwMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYcsgECC-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒地下城天赋

2.2.

#### 奥术法师新手地下城天赋

这个构建与团本构建非常相似，只是调整了功能技能以提供你在大秘境中关键的功能性，比如 [[spell:157980]] 和 [[spell:30449]]。

你可以通过下面的"复制导出字符串"按钮，轻松地将下方的天赋树导入游戏中。

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYCgbhJJ-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 奥术法师基础循环

2.3.

#### 新手 奥术 法师 输出循环

奥术主要围绕几个关键概念展开。

- 尽快使用冷却技能。这对游戏中几乎所有专精都很重要，但如果你长时间捏着冷却技能不放，奥术会受到非常大的影响。你不仅会因为没有获得像[[spell:365350]]这样的冷却技能带来的伤害加成而损失伤害，而且你的法力值生成也直接与冷却技能挂钩，这会进一步降低你的伤害，并使你更难维持4层奥术充能。
- 不浪费 [[spell:384452]] 层数。奥术 齐射为 [[spell:44425]] 提供巨大的伤害提升，所以我们要确保不在超过 奥术 齐射层数上限的同时，确保在达到 奥术 齐射层数上限时我们有4个 奥术 充能准备就绪，这样我们可以立即使用 奥术 弹幕。
- 在奥术充能较低时减少施法。由于我们的两个主要技能的伤害都随奥术充能而扩展，因此我们应尽量避免在充能较低时施放这些技能（[[spell:30451]]和[[spell:44425]]），这一点很重要。我们避免这种情况的主要方法是使用[[spell:153626]]。由于奥术非常消耗法力值，这并不总是可以避免的，但仍然值得牢记。

这引导我们得出以下基本优先级列表。

- 当[[spell:365350]]和[[spell:321507]]都就绪时施放它们。同时激活任何提供伤害加成或属性提升的使用型饰品或种族技能。
- 如果只有[[spell:321507]]就绪，但[[spell:365350]]未就绪，则施放大法师之触。你可以在每次奥术涌动使用之间进行一次此操作。
- 当你拥有[[spell:79684]]且[[spell:384452]]层数少于12层时，施放[[spell:5143]]。
- 在[[spell:1295924]]可用时施放。
- 在[[spell:451038]]期间，施放[[spell:44425]]。
- 当你有25层[[spell:384452]]和4个[[spell:36032]]时，施放[[spell:44425]]。
- 当你少于 4 个 [[spell:36032]] 时施放 [[spell:153626]]。
- 施放[[spell:30451]]作为填充技能。即使在AOE中也是！（所以不用[[spell:1449]]）
- 当因法力值不足而无法施放[[spell:30451]]时，施放[[spell:44425]]。

注意：这是简化版输出循环。完整优化的循环请参阅 [循环页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>).

2.3.1.

##### 巅峰天赋： ![Prismatic Bolt Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_mage_touchofthearchmage.jpg>) 棱彩飞弹

奥术拥有以下巅峰天赋。

- [[spell:1295923]]：[[spell:44425]]每消耗一层[[spell:384452]]，就有1%的几率将你的下一个[[spell:30451]]替换为[[spell:1295924]]。它会对你的目标和附近的敌人造成伤害，超过5个目标后伤害降低，并生成4层[[spell:36032]]。它的伤害和法力消耗不会随奥术充能而扩大，也不受任何修改奥术 Blast的东西影响。你可以将这个触发效果保留最多一分钟。
- [[spell:1295944]]：棱彩飞弹有50%/100%的几率触发[[spell:79684]]，且[[spell:5143]]的伤害提高15%/30%。
- [[spell:1295946]]：每消耗一层[[spell:384452]]额外增加1%的几率，使每层总计达到2%，并使[[spell:44425]]的伤害提高15%。

顶点天赋对两种英雄天赋都非常强力，几乎总是会被点出。[[spell:1295924]]本身就是一个伤害极高的法术，你会围绕它进行输出。此外，返还4个[[spell:36032]]极大地提升了在倾泻至0后恢复到4个奥术充能的能力，让你可以节省其他产生充能的方式。

2.4.

#### 第2赛季套装

我们第2赛季的套装为：

- [[spell:1296581]]：[[spell:5143]] 额外发射一道波，并造成提高 5% 的伤害。
- [[spell:1296582]]：每层[[spell:5143]]波纹会使你的下一个[[spell:30451]]、[[spell:1241462]]或[[spell:1295924]]的伤害提高3%，最多叠加24%。

这两个套装效果都非常强力，因为它们不仅使 [[spell:5143]] 更加强大，从而使 [[spell:79684]] 更具价值，它们还对该专精的其他方面产生连锁影响，例如提供更多 [[spell:384452]] 层数以及提高其他法术的伤害。这使得它是一套非常强力的套装，你会希望尽快获得，无论物品等级如何。

### 奥术 法师 属性优先级

2.5.

#### 奥术 法师 属性优先级

你应该按以下优先级选择次要属性。有关本页所呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>).

智力

急速

暴击

精通

全能

我们建议你优先考虑物品等级而非特定属性，因为它们都是 **非常接近** 的价值，而且它们会根据你当前拥有的装备而大幅波动。

### 奥术法师战斗助手

2.6.

#### 奥术 法师 战斗助手

11.1.7补丁引入了两个与战斗相关的新功能：辅助高亮和单键助手。有关如何启用这些功能及其所有细节的完整概述，请查看我们的
[战斗助手页面](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>).

辅助高亮输出循环是一个相对不错的循环，所以遵循它可以是学习循环的好方法，但是，这样做会让你损失约20-25%的伤害，具体取决于你的天赋和英雄天赋。

单键助手的惩罚更大，与辅助高亮相比额外损失5%的伤害，总计约25-30%。然而，它让你能够完全专注于地下城/首领机制，这非常有价值。

请注意，单键循环和辅助高亮循环都不会施放/高亮 [[spell:365350]]、种族冷却技能或物品（如饰品），因此你必须手动使用这些技能。

2.7.

#### 作为 奥术 法师 使用战斗助手的技巧

- 尽可能让[[spell:365350]]接近冷却完毕就使用，同时确保在使用它时[[spell:321507]]已经准备好或即将准备好。
- 在[[spell:365350]]期间使用你的饰品、药水、种族冷却技能（如[[spell:26297]]）或其他使用型冷却技能。
- 单键循环会在你与3个或更多目标战斗时施放[[spell:1449]]，所以请确保你的站位正确，以便用它击中所有目标。
- 它也会在循环中施放[[spell:153626]]，所以请确保你的朝向能够击中所有目标，并且不会意外地用它引到其他目标。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月15日：** 已针对赛季开始时的职业削弱进行更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026 年 3 月 17 日：** 重新添加了 奥术 脉冲在AOE中用于AOE，以获得更好的AOE输出。
- **2026年3月16日：** 为第1赛季开始添加了套装章节。
- **2026年3月5日：** 为3月5日的在线修复更新了天赋树（修复/削弱了奥术脉冲，使其在配合回响时不再提供双倍的齐射层数）
- **2026年2月26日：** 针对前夕补丁平衡性调整更新了天赋树和循环。
- **2026年2月10日：** 为12.0.1天赋树改动更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月5日：** 更新了套装免责声明，表明此页面在有无套装的情况下均适用，因为针对推荐的英雄天赋，推荐的循环和天赋不会改变。
- **2025年8月10日：** 更新了基础输出循环，使其更简单且DPS略有提升。
- **2025年8月4日：** 根据11.2的改动和套装奖励，更新了最佳循环、天赋和英雄天赋。
- **2025年6月17日：** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月15日：** 添加了战斗助手信息和提示。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已为11.1更新：针对11.1的改动和套装奖励，更新了最优输出循环、属性、天赋和英雄天赋。
- **2024年12月15日：** 略微更新了输出循环。
- **2024年10月21日：** 针对11.0.5的重做更新了天赋和输出循环。
- **2024年9月9日：** 更新了输出循环，使其略优但难度相当，并更新了第1赛季的属性优先级。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 更新了输出循环，使其更简单且伤害略高。
- **2023年11月6日：** 为10.2改动更新了天赋和输出循环。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为 10.1.5 的 奥术 重做更新了输出循环和天赋
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界12.1.5版本中你的奥术法师的最佳天赋。我们还提供了适用于各种内容类型的默认天赋配置，例如团队副本或大秘境。如果你开启了战争模式，我们也为你提供了PvP天赋的选择。

1.

### 奥术 法师 最佳 至暗之夜 天赋

对于第2赛季， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒看起来是最强的英雄天赋树，在AoE和单体目标中皆是如此。它的DPS simply 就比
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师，且没有任何缺点。

此外，日怒 的优势在于可以切换到AOE天赋，同时几乎不牺牲单体DPS，这使得它在AOE和单体同样重要的战斗中更加灵活，比如团队副本中的大多数首领战，以及所有大秘境地下城。

- **团队副本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 在单体和顺劈DPS方面都明显领先，是团队副本的明显首选。
- **大秘境 -** 在范围伤害中，两个英雄天赋树相对接近，但是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒确实略占优势，其AoE天赋构建在单体目标上的DPS远高于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师做到了，使其成为显而易见的选择。

由于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师在所有内容中都不需要牺牲任何东西，因此除了日怒之外，没有真正的理由去玩其他英雄天赋，除非你非常喜欢疾咒师的玩法风格。

**快速开始导入代码：**

:::talents 奥术团队副本 - 日怒
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMmZmBAYAAAGgZGwMAYYmZA"
}
```
:::

:::talents 奥术 Mythic+ - 日怒
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::talents 奥术 地下堡 - 日怒
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZGzsYzMDNzYGAAADAYmZaWWWmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMwMDAGmZG"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

日怒

纯单体目标

团队副本

推荐

秘境+

每周大秘境钥匙

高层大秘境

地下堡

推荐

疾咒师

纯单体目标

团队副本

秘境+

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 纯单体目标配装

此构筑目前表现最佳 **纯单体目标**
构建。这对于在整个战斗过程中只会与单个敌人战斗的战斗场景效果很好。
**如果战斗中有额外的目标，即使只占相对较小的一部分，我也推荐顺劈/团本构筑。**

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 团本构建

此构筑在单体上做出了一些非常小的牺牲（约1%），以造成显著更多的顺劈和AOE伤害，使其成为任何有小怪的团本战斗的首选构筑，而这几乎是所有战斗。

根据战斗情况，你可以将像 [[spell:382293]] 这样的实用技能换成像 [[spell:30449]] 这样的实用技能，如果需要的话。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒大秘境构建

这是首选的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 大秘境配装，在AOE DPS和单体DPS方面都表现出色，两者几乎没有牺牲。

此构筑在DPS天赋方面与团本构筑相同，但为了大秘境调整了功能性天赋，例如[[spell:157980]]和[[spell:475]]。

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 地下堡配装

这套构筑专注于使 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 尽可能流畅的体验。它专注于通过点出更多机动性和控制能力来最大化你的生存和风筝能力，同时只牺牲极少的输出。这个构建对于户外内容也非常出色。

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师纯单目标构筑

这是 **纯单体目标** 用于……的配装 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师。对于任何有额外目标的内容（几乎所有团队副本战斗都是如此！），请务必查看团队副本配装方案。

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师 团本构筑

这是首选的团队副本天赋方案，适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师，仍然专注于单体伤害，但也使你能够对出现的小怪造成适当的顺劈伤害。

根据战斗情况，你可以将像[[spell:382293]]这样的功能性技能换成其他有用的工具，如[[spell:30449]]，如果你需要的话。

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师大秘境构筑

这个构建比团队副本构建牺牲了更多的单体输出，以最大化AoE伤害。它还点出了大秘境实用技能，比如 [[spell:157980]]。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAgZmZGbWmZmZZGjxMzgNmxMzMAADAAwAMzAmBADzMD"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJOOqms59diKUgoABRGcA-NbckEGRXKdeoAHHKQYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMmZmBAYAAAGgZGwMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYcsgECC-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYCgbhJJ-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZGzsYzMDNzYGAAADAYmZaWWWmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMwMDAGmZG"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYakJqms59diKgEMxtwk8ZUEg2B-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAAAYmZmllZmYBAAYmZmxmlZmZWmxYMzMYjZMzMDAwAAAMzsAAmBADzMD"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJOOqms59diKUgoABRGcA-NbckEGRXKdeoAHHKQYkJeAZZpp9FKZC-AAAA-OQSaIMUwADQAxC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAAAYmZmllZmYBAAwMzwmlZMzyMGzMzMDbMjZmZAAGAAgZmNAwMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJOOqms59diKUgoABRGcA-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-OQSaKMUwADQAxC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAAAzMzssMzELAAsNYmZYzyMmxMGzMzMDbMjZMDAwAAAMzsBAzMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYirZBAJ-NbckEGRXKdoww6AHLYkJeAZZpp9FCMB-AAAA-OQSaKMUwADQAxC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并提供了一些轻微的性能增强自定义选项。其中一些增益会影响你的伤害输出，而另一些则更偏向防御性质。

你可以自由更换它们，不会受到任何惩罚，所以尽管按照自己的喜好进行尝试吧！以下是我列出的默认推荐：

- 要点 1：[[spell:1279596]]
- 第2点：组队时使用 [[spell:1279604]]，单人时使用 [[spell:1279603]]
- 要点3：[[spell:1287555]]
- 第4点：[[spell:1279609]]
- 第 5 点：[[spell:1279616]]

1.

### 巅峰天赋： ![Prismatic Bolt Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_mage_touchofthearchmage.jpg>) 棱彩飞弹

奥术拥有以下巅峰天赋：

- [[spell:1295923]]：[[spell:44425]]每消耗一层[[spell:384452]]，就有1%的几率将你的下一个[[spell:30451]]替换为[[spell:1295924]]。它会对你的目标和附近的敌人造成伤害，超过5个目标后伤害降低，并生成4层[[spell:36032]]。它的伤害和法力消耗不会随奥术充能而扩大，也不受任何修改奥术 Blast的东西影响。你可以将这个触发效果保留最多一分钟。
- [[spell:1295944]]：棱彩飞弹有50%/100%的几率触发[[spell:79684]]，且[[spell:5143]]的伤害提高15%/30%。
- [[spell:1295946]]：每消耗一层[[spell:384452]]额外增加1%的几率，使每层总计达到2%，并使[[spell:44425]]的伤害提高15%。

顶点天赋对两种英雄天赋都非常强力，几乎总是会被点出。[[spell:1295924]]本身就是一个伤害极高的法术，你会围绕它进行输出。此外，返还4个[[spell:36032]]极大地提升了在倾泻至0后恢复到4个奥术充能的能力，让你可以节省其他产生充能的方式。

1.

### 奥术法师的英雄天赋

奥术 可以使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师 英雄天赋树。

目前， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒在几乎所有内容中的DPS都领先，而且它在不牺牲实用性或生存能力的情况下做到这一点，使其成为所有情况下的首选。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒在[[spell:365350]]期间召唤一只伴随你的奥术凤凰，施放它自己的法术提供伤害和一些功能性。在玩法上，主要变化是在奥术涌动结束后，你会获得非常强大的[[spell:451038]]增益，它使[[spell:44425]]提供[[spell:79684]]，生成四个奥术充能，生成五个[[spell:384452]]充能，并且施放它不会消耗任何奥术齐射充能。这在实践中的意义是，在奥术之魂期间，你可以简单地疯狂连发高伤害的奥术弹幕。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师旨在为你所有的法术提供大量小型被动加成，并对你的目标施加许多[[spell:443763]]。在玩法上，该天赋树相当被动，然而，所有被动效果加在一起为你提供了相当多的额外[[spell:384452]]层数，这反过来使你能够施放更多[[spell:44425]]。

1.

### PvP天赋（战争模式）

自争霸艾泽拉斯以来，可以启用“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式在升级和PvE内容中的好处，建议开启该功能以最大化你的升级速度和满级后的奖励。然而，这样做会开启PvP战斗，在升级或进行世界任务时存在被对立阵营成员攻击的可能性。

在本章节中，我们将对战争模式天赋在升级和户外内容中的表现进行排名。

1. [[spell:198111]]不属于公共冷却时间，因此它可以在不牺牲任何伤害的情况下使用，并且在你知道即将到来的伤害时非常强大。你可以直接承受伤害，并在护盾结束时将生命值恢复满。
2. [[spell:353082]]是野外AoE伤害的绝佳工具，尤其对高生命值目标而言。
3. [[spell:235711]]是一个极佳的野外风筝和机动工具。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月12日：** 修复了在日怒下显示疾咒师而不是日怒的问题。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 添加了关于万世卷册的部分。
- **2026年5月23日：** 根据5月26日/27日的改动更新了天赋选择及说明。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 更新了大秘境天赋以加入 奥术 脉冲，从而最大化AoE伤害输出，因为其对单体伤害的降低非常有限。
- **2026年3月16日：** 更新了推荐天赋配置，以区分史诗钥石每周钥匙和冲层，并更新了第1赛季调整后的最佳天赋。
- **2026年3月5日：** 为3月5日的在线修复更新了天赋树（修复/削弱了奥术脉冲，使其在配合回响时不再提供双倍的齐射层数）
- **2026年2月26日：** 根据预补丁的平衡性调整更新了天赋树。
- **2026年2月10日：** 为12.0.1天赋树改动更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月15日：** 略微更新了 日怒 的单体和顺劈天赋，由于各种bug不再选择魔息之光，且时间循环的DPS相同且更易操作。
- **2025年8月4日：** 为11.2.0更新了所有天赋配置，并根据改动更新了推荐天赋。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 更新了11.1版本的最佳天赋：为重新调整后的天赋树提供了新的最优天赋树，并更换了 疾咒师 的整体推荐天赋。
- **2024年12月15日：** 更新了页面布局，将不同的英雄天赋拆分到各自的部分，并添加了推荐标签以便更快地找到最佳构筑。
- **2024 年 10 月 30 日：** 更新了日怒天赋以选择挫志之课而非重力坠落。
- **2024年10月22日：** 根据最后一刻的削弱更新了天赋。添加了单体法术射击配置。
- **2024年10月21日：** 更新了11.0.5的最佳天赋。为疾咒师和日怒添加了多个AOE构筑。
- **2024年9月14日：** 更新了地下堡天赋，使其造成略高的范围伤害。
- **2024年9月9日：** 移除了赛季前天赋。
- **2024年9月5日：** 对AOE/顺劈天赋进行了小幅改进。
- **2024年9月2日：** 修复了地下堡英雄树中缺失的一个点。
- **2024年8月24日：** 添加了地下堡天赋树。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月24日：** 由于启迪之思在正式服务器上已修复，使其明显强于测试服和 ptr，更新了推荐天赋。
- **2024年7月24日：** 根据正式服服务器的bug对建议天赋进行了小幅更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了10.2版本的最佳天赋。
- **2023年9月4日：** 更改了天赋布局，使其更易于浏览。
- **2023年7月10日：** 更新了10.1.5 奥术改动后的推荐天赋。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月16日：** 添加了关于法力宝石配装以及何时选择和谐或法力宝石配装的信息。
- **2022年12月11日：** 对推荐天赋树进行了小幅调整，将其更多地分为团队副本与地下城两套，而非单体目标与AoE两套。
- **2022年11月30日：** 更新了时间扭曲与时间异常的描述，使其更具信息量。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面，你将学习如何在单体和多目标情况下优化你的 奥术 法师 循环。我们还提供了关于冷却时间、触发效果等方面的进阶章节，以便你最大化你的DPS。我们所有的内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 奥术 法师玩法与输出循环指南

欢迎来到我们的奥术法师循环页面。在这个页面上，你将找到关于在PvE场景中实际游玩该专精所需了解的一切信息。

以下各部分分别讲解不同环境下的输出循环。点击方框可切换到所需场景。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师

单体目标

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:1241462]]

[[spell:205025]]

[[spell:12051]]

[[spell:1243435]]

[[spell:461248]]

[[spell:1244329]]

[[spell:1296582]]

### 单体目标循环

1.1.

#### 起手式与冷却技能使用

奥术的冷却技能使用非常重要，因为它们不仅提供巨大的伤害提升，还带来大量法力回复，并大幅增加你的增益获取。

下面我们列出了起手顺序，以及当 [[spell:365350]] 和 [[spell:321507]] 都就绪时你应该遵循的法术顺序：

[[spell:365350]]

预读

拉怪

[[spell:5143]]

[[item:241308]]

[[spell:26297]]

[[spell:44425]]

[[spell:321507]]

1. 在开怪前，或在你即将使用冷却技能的任何时候，使用任何持续15秒或更长时间的饰品或药水，以便它们在[[spell:365350]]阶段生效。
2. 起手时预读[[spell:365350]]。
3. 使用任何持续时间少于15秒的药水、种族技能或属性加成饰品。
4. 施放 [[spell:5143]]。
5. 施放[[spell:44425]]
6. 在奥术弹幕落在目标上之前施放[[spell:321507]]。
7. 45秒后，当[[spell:321507]]就绪时施放它。你可以在两次[[spell:365350]]之间使用一次。它的冷却时间正好是奥术涌动的一半，所以尽量不要延迟太多，否则会迫使你延迟下一个奥术涌动。
8. 只需在[[spell:365350]] / [[spell:321507]]激活期间，遵循下面列出的单目标循环即可。

1.2.

#### 单体目标循环

奥术 输出循环遵循优先级系统。下面我们列出这个优先级系统。你应该从上到下阅读，然后执行第一个满足所有条件的操作。

1. **适用条件：疾咒师（启用）；奥术 法师 12.1职业套装4件套（启用）。** 当它可用且你拥有6层或更多[[spell:1296930]]时，施放[[spell:1295924]]。（4件套奖励增益，如果你还没有4件套，只需在棱彩飞弹可用时施放它）
2. **适用条件：疾咒师（启用）；奥术 法师 12.1职业套装4件套（未启用）。** 可用时施放 [[spell:1295924]]。
3. **适用条件：疾咒师（启用）。** 当你拥有4层[[spell:36032]]和20层[[spell:384452]]时，施放[[spell:44425]]。
4. **适用条件：疾咒师（启用）。** 当你拥有[[spell:79684]]且[[spell:384452]]层数少于15层时，施放[[spell:5143]]。
5. **适用条件：疾咒师（启用）；奥术 法师 12.1职业套装4件套（启用）。** 可用时施放 [[spell:1295924]]。
6. **适用条件：日怒（启用）。** 当你有[[spell:79684]]且[[spell:384452]]层数少于12层时，施放[[spell:5143]]。
7. **适用条件：日怒（启用）。** 当 [[spell:451038]] 激活时施放 [[spell:44425]]。
8. **适用条件：日怒（启用）；法师 奥术 12.1职业套装4件套（启用）。** 当[[spell:1295924]]可用且你拥有8层[[spell:1296930]]时，施放它。（4件套增益BUFF，如果你还没有4件套，只需在棱彩飞弹可用时施放即可）
9. **适用条件：日怒（启用）；法师 奥术 12.1 职业套装4件套（未启用）。** 可用时施放 [[spell:1295924]]。
10. **适用条件：日怒（启用）。** 如果你有4层[[spell:36032]]和25层[[spell:384452]]，施放[[spell:44425]]。
11. **适用条件：日怒（启用）；High Voltage（启用）。** 如果你有4个[[spell:36032]]、12个或更多[[spell:384452]]以及一个[[spell:79684]]触发，则施放[[spell:44425]]，
12. **适用条件：法师 奥术 12.1职业套装4件套（启用）；日怒（启用）。** 只要它可用就施放[[spell:1295924]]。
13. 当你没有[[spell:36032]]时，施放[[spell:153626]]。
14. **适用条件：Presence of Mind（启用）。** 当你需要移动且需要施放 [[spell:30451]] 时，使用 [[spell:205025]]
15. **适用条件：唤醒（启用）。** 当法力值耗尽且当前不在[[spell:321507]]或[[spell:365350]]期间时，使用[[spell:12051]]。
16. 施放[[spell:30451]]作为你的填充技能。
17. 如果你没有足够的法力值施放[[spell:30451]]，则施放[[spell:44425]]。

### AOE循环

1.3.

#### AOE循环

目前，奥术的处境有点奇怪，单体和范围输出循环几乎完全相同，只有非常细微的变化，而且仅在某些天赋配置下如此。这主要是因为范围伤害高度依赖[[spell:44425]]和[[spell:1295924]]，而单体循环也已经将它们最大化了。

下面我列出了 **你应该应用到单体目标循环中的差异** 基于不同的目标数量。

1. **适用条件：奥术 Pulse（启用）。** 当[[spell:1241462]]就绪且你没有4层[[spell:36032]]时，在[[spell:30451]]上使用它。
2. 如果你有12层或更多[[spell:384452]]，且[[spell:153626]]就绪或有[[spell:79684]]，则施放[[spell:44425]]，而不仅仅是在节能施法时施放。
3. **适用条件：Orb Mastery（启用）。** 可用时立即施放 [[spell:153626]]。
4. 就这些了！
5.

### 至暗之夜 第2赛季套装

我们第2赛季的套装为：

- [[spell:1296581]]：[[spell:5143]] 额外发射一道波，并造成提高 5% 的伤害。
- [[spell:1296582]]：每层[[spell:5143]]波纹会使你的下一个[[spell:30451]]、[[spell:1241462]]或[[spell:1295924]]的伤害提高3%，最多叠加24%。

该循环略微影响奥术的玩法风格。对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒，无论是否有套装，循环都是相同的，但对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师，4件套的效果使你只应在拥有6层或更多 [[spell:1296930]]（4件套提供的增益）时才使用 [[spell:1295924]]，至少作为最高优先级。如果没有这些层数，它在优先级列表中的位置会降低。

1.

### 职业与专精机制详解

为了更好地解释奥术 法师技能体系的具体用法和优势，我们编写了关于输出循环各个部分的更详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方法，以便你在游玩奥术 法师时能发挥全部潜力。

### 奥术齐射

3.1.

#### 奥术齐射

[[spell:384452]]是一个叠加型增益，默认通过使用[[spell:5143]]获得，它大幅增加[[spell:44425]]的伤害。在点出[[spell:1243557]]后，它也可以通过[[spell:30451]]、[[spell:1295924]]和[[spell:153626]]产生，由于齐射层数的重要性，通常总是会点出该天赋。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 作为疾咒师，你还有机会从[[spell:443763]]中产生它们。

不仅奥术齐射本身能大幅提升奥术弹幕的伤害，加上[[spell:1223798]]，拥有满层的奥术齐射层数（20层，如 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师，25级作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒）变得更加重要，因为伤害加成仅在你使用奥术 Barrage达到最大层数时才生效。

因此，奥术弹幕和直觉对输出循环影响很大（与[[spell:1295924]]一起），主要专注于尽可能高效地积累两种奥术弹幕充能，同时尽量最大化棱彩飞弹的使用。

### 法力管理与奥术充能

3.2.

#### 法力管理与奥术充能

奥术是少数几个需要关注法力值的输出专精之一，这主要由[[spell:36032]]驱动。奥术充能是一种特殊的资源，最多可叠加4层，每层都大幅增加[[spell:30451]]和[[spell:1241462]]的伤害和法力消耗，同时也会大幅增加[[spell:44425]]的伤害（但不会增加法力消耗）。奥术充能主要通过在单体目标上使用奥术 Blast，或在AOE中使用[[spell:1449]]和[[spell:1241462]]来叠加，但各种其他法术和天赋也能产生它们。

由于奥术充能会大幅提升你核心伤害技能的伤害，你通常应该尽可能多地在4层奥术充能时施放技能，尽量减少在低充能时施法的时间。然而，只在4层奥术充能时施放奥术冲击会非常快地耗尽你的法力值。

为了应对这一点，奥术有各种工具。奥术弹幕是主要的，因为它将奥术充能重置为0，重置法力消耗增加以及伤害，同时自身造成巨大伤害，如果与高[[spell:384452]]层数一起使用的话。

这形成了核心循环：积累至4层奥术充能 -> 获得最大奥术弹幕层数 -> 施放一记高伤害、可重置层数的奥术 Barrage。

奥术确实有其他几种管理法力的工具，特别是[[spell:365350]]。虽然奥术涌动本身会耗尽你的法力，但它也提供了如此多的法力生成，以至于施放它后实际上会让你恢复到满法力。虽然奥术涌动的伤害会随着你施放时的法力值而变化，但你实际上从不关心这一点，因为额外的伤害很小。所以你实际上将奥术涌动用作一种通过在低法力时施放来恢复满法力的方法。

此外，还有几种其他不太常见的法力生成方式，例如使用[[spell:12051]]（仅在部分天赋下点出）或被动技能[[spell:321526]]（如果点出）。

最后，可以说是恢复法力值最重要的方法：被动法力值恢复。奥术 拥有很高的法力值恢复速度，因为你的精通不仅会提高你的伤害，还会提高你的被动法力值恢复，这在整场战斗中实际上会累积成非常可观的法力值总量。

:::details 常见问题解答：为什么我的[[spell:153626]]在开怪时不产生[[spell:36032]]？
不过它确实会为你提供一层充能，然而，进入团队副本战斗时，所有 奥术 充能会被重置为 0，所以你要确保在团队副本战斗开始后施放 奥术 宝珠。这对于任何其他 奥术 充能生成来源也同样适用，比如如果你是第一个用该技能命中团队副本首领的

[[spell:30451]]

，由它提供的初始充能被重置为0。

:::

### 终极天赋（棱彩箭矢）

3.3.

#### 法师的奥术专精终极天赋

奥术拥有以下巅峰天赋：

- [[spell:1295923]]：[[spell:44425]]每消耗一层[[spell:384452]]，就有1%的几率将你的下一个[[spell:30451]]替换为[[spell:1295924]]。它会对你的目标和附近的敌人造成伤害，超过5个目标后伤害降低，并生成4层[[spell:36032]]。它的伤害和法力消耗不会随奥术充能而扩大，也不受任何修改奥术 Blast的东西影响。你可以将这个触发效果保留最多一分钟。
- [[spell:1295944]]：棱彩飞弹有50%/100%的几率触发[[spell:79684]]，且[[spell:5143]]的伤害提高15%/30%。
- [[spell:1295946]]：每消耗一层[[spell:384452]]额外增加1%的几率，使每层总计达到2%，并使[[spell:44425]]的伤害提高15%。

顶峰天赋非常强力。以至于大部分输出循环都围绕着尽可能多地打出 [[spell:1295924]]，很大程度上是因为棱彩飞弹本身伤害极高。

这主要是通过尽可能快地获得尽可能多的[[spell:384452]]层数来实现的，而不是把有限的时间浪费在其他事情上。这也是为什么例如选择[[spell:461248]]和[[spell:1244329]]的原因，因为它们同时结合了生成奥术齐射层数和[[spell:36032]]，使你能够生成更多的棱彩弹幕。

在实际玩法风格上为了最大化这一点，我们围绕它的主要方式是，当获得更多层数相对低效时，我们并不总是试图获得最大层数的[[spell:384452]]。例如，当你拥有12层或更多层的[[spell:384452]]，并且有办法生成[[spell:36032]]（例如通过[[spell:153626]]），你已经可以使用[[spell:44425]]来尝试触发棱彩箭矢。这平均来说比通过[[spell:30451]]达到25层齐射层数能产生更多次棱彩箭矢触发。

1.

### 奥术法师的重要冷却技能

### 奥术涌动

4.1.

#### 奥术涌动

[[spell:365350]]是奥术的主要DPS冷却技能。它有90秒冷却时间，使用时会消耗你所有的法力值，对你的目标和附近的敌人造成一次巨大的打击，伤害基于消耗的法力值。然而，真正的收益来自初始施放之后，它将你所有的法术伤害提高35%，持续15秒，同时大幅提高你的法力回复，这基本上会在其持续时间内将你的法力值回满。

通常情况下，你会希望在奥术涌动就绪后立即使用，但在某些情况下延迟使用可能更有利，例如你的团队即将使用[[spell:80353]]或类似效果，或者一个需要高DPS的团队副本重要机制即将到来，又或者出现了额外的目标等。

### 大法师之触

4.2.

#### 大法师之触

[[spell:321507]]是一个45秒冷却的技能，它会给你的目标施加一个减益效果，在12秒内累积你对目标造成的所有伤害的20%，然后对目标及附近敌人造成所有累积的伤害。它还会提供4层奥术充能，使你可以在开怪时立即使用它，而无需提前积累层数。

魔息之触和 [[spell:365350]] 的时间轴非常紧凑，魔息之触的冷却时间恰好是 奥术 涌动的一半。由于时间轴如此接近，你必须在魔息之触可用时立即使用，以免出现魔息之触未就绪而 奥术 涌动已就绪的情况。

### 时间扭曲

4.3.

#### 时间扭曲

[[spell:80353]]是一项能为100码范围内的整个小队或团队提供30%急速、持续40秒增益的技能。该增益与[[spell:2825]]和[[spell:32182]]等多个其他法术共享。这些法术都会在所有团队成员身上施加一个减益效果，使其在10分钟内无法再次获得该效果，因此你无法从多个来源多次获得相同的增益。

由于时间扭曲作用于整个团队，通常由团队或小队领袖决定何时使用，以优化整个团队的使用效果，而不是只在对你个人使用最佳时才使用。然而，如果没有指定时间，或者你所在的野团在战术方面没有真正的领导，通常的安全做法是在战斗开始后立即使用时间扭曲，这样在所有人都准备好所有输出冷却技能时它就已生效。当然，请确保只有在开怪后的整个40秒增益持续时间内敌人都保持活跃时才这样做，因为在某些战斗中，首领可能会在战斗早期进入非活动状态或进行某种阶段转换。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月15日：** 已针对赛季开始时的职业削弱进行更新。
- **2026年8月12日：** 将起手式更新为新的起手式，效果提升0.5%，并微调了循环的其余部分。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 为12.0.5的奥术脉冲改动更新了输出循环。
- **2026 年 3 月 17 日：** 根据天赋页面的更新更新了默认天赋选择。
- **2026年3月16日：** 为第1赛季开始添加了套装部分。
- **2026年3月8日：** 在最新的理论计算更新后，完全将奥术脉冲从单体输出循环中移除。
- **2026年3月5日：** 由于热修复移除了回响触发双层 奥术 弹幕层数的效果，更新了 奥术 脉冲的使用说明。
- **2026年2月27日：** 更新了关于奥术 Salvo使用的措辞，使其更加具体。
- **2026年2月26日：** 更新了至暗之夜上线的构筑和循环。
- **2026年2月10日：** 为 日怒 和 疾咒师 优化了 奥术 激涌序列。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月5日：** 为 疾咒师 稍微更新了默认天赋开关。
- **2025年8月10日：** 更新了基础输出循环，使其更简单且DPS略有提升。
- **2025年8月4日：** 根据11.2版本的改动，更新了单体和AoE的最优输出循环，并添加了套装循环改动章节。
- **2025年6月17日：** 根据最新更新的数据，更新了战斗助手的伤害增益/损失。
- **2025年6月15日：** 添加了战斗助手信息和提示。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 3 月 2 日：** 微调了奥术弹幕的触发条件，使高压使用更容易理解，并在不同天赋配置下更加一致。
- **2025年2月26日：** 略微更新了奥术弹幕的使用，以确保不丢失直觉/奥术节奏，并使范围伤害循环在集中输出与纯范围伤害之间更清晰。
- **2025 年 2 月 24 日：** 针对11.1的改动进行了更新：新的默认设置设定为疾咒师，根据改动更新了新的最优输出循环，并将输出循环分为基础 - 中级 - 高级。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月27日：** 根据最新的理论计算发现更新了循环，主要简化了法术迸发的使用方式，同时略微提升了DPS。
- **2024年10月23日：** 对法术飞弹的AoE循环进行了小幅修改，并在进阶章节下为单体循环添加了奥术节奏条件。
- **2024年10月22日：** 将输出循环的各个部分移到进阶部分，以提供更易上手的默认输出循环，并修复了法术射手输出循环显示部分日怒行的问题。
- **2024年10月21日：** 更新了两种英雄天赋的单目标和AOE循环以适应11.0.5变更。添加了疾咒师预设，因为现在它是一个更可行的英雄天赋配置。
- **2024年9月25日：** 更新了AoE输出循环以列出目标数量。
- **2024年9月16日：** 根据最新的改进略微更新了输出循环。
- **2024年9月11日：** 略微更新AOE循环，将ToTM期间的奥术冲击行移至法术投射循环，因为日怒已经自动执行了。
- **2024年9月9日：** 分离了英雄天赋选择器，并将循环更新为以可选复选框的形式包含更多进阶内容。重写了奥术弹幕的使用方式，使其更易于理解。
- **2024年9月2日：** 更新循环以移除力量重担的双重加成。
- **2024年8月22日：** 略微调整了单体循环的优先级，以明确如果你拥有力量重负，应先使用飞弹再倾泻它，并对 AOE 做了一些小的可读性改进。
- **2024年8月22日：** 更新了AoE输出循环，以阐明单体输出循环与AoE输出循环的使用区别。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月26日：** 奥术 在 奥术 Tempo 行中，并稍微更新了 AoE 输出循环，以更清楚地表明在拥有 4 层充能时，始终在 奥术 飞弹之前使用 奥术 弹幕。进一步改进了虚空精准的说明，以应用更多优化。
- **2024年7月25日：** 在输出循环中加入 奥术 飞弹的打断条件，将爆发阶段重新组织为 2 个独立的部分，初始爆发阶段序列，纳入优先级列表。
- **2024年7月24日：** 节能施法触发率在正式服上发生了变化，导致奥术冲击的触发率比奥术弹幕高5%。更新了循环以纳入这一变化，移除了奥术弹幕的斩杀玩法。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6版本进行审查，修正了一些错别字，并删除了“安静移动”部分，因为它与其他部分重复。
- **2024年3月15日：** 移除了不再相关的奥术飞弹取消后摇部分。
- **2024年1月15日：** 更新循环并加入已发现的优化。
- **2023年11月6日：** 为10.2更新了基础循环，添加了第3赛季套装循环、第3赛季饰品和其他物品到循环中。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 更新了重做后的奥术的输出循环。
- **2023年5月9日：** 更新了输出循环，加入了进一步的4件套优化。
- **2023年5月1日：** 更新了输出循环，加入了第2赛季套装优化。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023 年 1 月 18 日：** 根据最新的理论分析更新了爆发循环，并扩展了AoE循环。
- **2023年1月13日：** 改进了法力宝石输出循环并添加了爪击的使用。
- **2022年12月13日：** 略微改进了燃烧阶段的循环，并在燃烧阶段结束时增加了更多说明。
- **2022年12月11日：** 添加了解释因套装而导致的输出循环变化的章节。
- **2022年11月30日：** 根据新的理论计算略微更新了爆发输出循环。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5版本中奥术法师的最佳装备、饰品以及毕业装备推荐。从制作装备到如何使用你的纹章来升级装备的建议，我们都为你准备好了！

1.

### 奥术 法师 毕业装备攻略

欢迎来到我们的 奥术法师配装页面。本

部分将涵盖你正确为角色配装所需了解的一切

正确使用。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 中升级装备继续使用纹章系统，该系统让你

沿着与获取物品来源相关的轨道提升装备物品等级，

更难的内容掉落的装备可以升级到更高的物品等级。

欲了解更多信息，请阅读我们专门介绍

[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 如何运作以及

在 至暗之夜 资料片中有什么变化的专页。

### 总体

本列表包含来自所有来源的奥术 法师最高DPS配置。对于单个部位，通常有许多物品的DPS非常接近甚至完全相同，特别是如果你只是在不同部位之间调整副属性。因此，你应该仅将下面的列表作为一套毕业装备大致样貌的一般指南，而不是用来立即做出装备选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

<em>在几个部位中，我列出了来自大秘境的物品，这些物品只能从 [大宝库](<https://www.icy-veins.com/wow/great-vault-guide>)。通常这些物品只有在史诗难度掉落等级下才是最佳选择，而不是在英雄难度掉落等级的变体中。如果你无法获得史诗难度掉落等级的物品，通常使用物品等级更高的装备比最佳选择的装备更好。</em>

:::details 常见问题我需要哪些套装部件？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

会保留物品的物品等级、属性和任何特殊奖励，因此你催化5个部位中的哪4个并不重要。从下方列出的5个部位中，任选你已经拥有的4个：

- 头部 — [[item:271874]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 护肩——来自的[[item:268241]] [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 胸部 — 来自[[item:273785]] [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手部 — 来自[[item:268243]] [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部 — 来自[[item:281235]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

注意：无论用什么方式获得 4 件套都比在正确的（催化出来的）部位上获得要重要得多，所以永远优先考虑获得 4 件套而不是正确的部位。

:::

:::details 常见问题我应该从大宝库中选择哪些物品？
通常，你应该通过模拟来专注于选择对你提升最大的装备。

[最佳装备](<https://www.raidbots.com/simbot/topgear>)

。不过，总体上也有一些物品非常有价值，如果你看到它们，几乎总是值得拾取的：

- [[item:271092]]：遥遥领先的毕业武器，非常稀有且被所有施法者所渴望，因此如果它出现在你的英雄难度或更高的宝箱中，一定要拿取。
- 以下列出的任何9/6神话品质物品：它们对于奥术法师以及通常所有其他布甲职业来说都是毕业装备，因此很难通过其他方式获得。
- [[item:250215]]：毕业饰品，只能从宏伟宝库以史诗品质获得。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240892]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271563@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYDYwslI]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含使用可刷取装备的最高DPS配置 **来自** 第2赛季史诗钥石地下城。这包括套装部件和2件美化物品，因为它们很重要，尽管它们在技术上并非来自史诗钥石地下城，因为它们可以通过 [大宝库](<https://www.icy-veins.com/wow/great-vault-guide>) / [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) / 制造。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

会保留物品的物品等级、属性和任何特殊奖励，因此你催化5个部位中的哪4个并不重要。从下方列出的5个部位中，任选你已经拥有的4个：

- 头部 — 来自的[[item:251232]] [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 肩部 — 来自[[item:239045]] [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- 胸部——来自的[[item:251147]] [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 手套 — 来自的[[item:251129]] [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部 — 来自[[item:193750@JAAIAAQkCYHKvbRLfA]] [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)

注意：无论用什么方式获得 4 件套都比在正确的（催化出来的）部位上获得要重要得多，所以永远优先考虑获得 4 件套而不是正确的部位。

:::

:::details 提示我应该刷哪些地下城？
有几个特别出色的地下城，因为其中有特定物品掉落，使得它们成为非常值得刷的地下城：

- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：掉落毕业使用型饰品，同时还掉落强力的项链、手套和鞋子。
- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落两件非常强力的被动饰品，包括最佳的非团队副本饰品，同时还掉落一件出色的披风和多件其他有用装备。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271564@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAAEAAgNygjM]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:239649@JAAKAAwt1ENMMYDYwYlI]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYDYwslI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:250214@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:159667@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含最高DPS配置，仅使用 **来自** 剧毒深渊团队副本。这包括2件美化装备，因为它们很重要。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

会保留物品的物品等级、属性和任何特殊加成，所以你催化5个栏位中的哪4个并不重要。在团队副本中，唯一可获得的胸甲是

[[item:271567@JAACAAgNyA]]

（来自

[Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)

），它是一件套装物品，所以你总是会选择那一件。然后，从下面列表中你可选的4件物品中任选3件进行转化：

- 头部 — [[item:271874]] 来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 护肩——来自的[[item:268241]] [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 手部 — 来自[[item:268243]] [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部 — 来自[[item:281235]] [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

注意：无论用什么方式获得 4 件套都比在正确的（催化出来的）部位上获得要重要得多，所以永远优先考虑获得 4 件套而不是正确的部位。

:::

:::details 提示哪些团队副本装备最重要？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271092@JAACAAAG2A]]：凭借其更高的物品等级和次要效果，以较大优势成为最佳武器。
- [[item:271874@JAAEAAAG2YhN]]：凭借其更高的物品等级和毒咒效果，成为遥遥领先的最佳头盔。
- [[item:270164@JAACAAgNyA]]：最好的被动饰品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240892]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271563@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">潮缚石窟</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270170@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAKAAwt1ENMMYDYwslI]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 第2赛季中奥术法师的饰品推荐

奥术有许多饰品可供选择。

通常，你会想要使用一个强力的主动使用饰品来搭配

用[[spell:365350]]它，然后是一个强力的被动饰品

作为你的第二个饰品。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **奥术 法师 饰品**
**使用型 -**

[[item:250215]]

，或者，另外

[[item:273796]]

（稍弱）

**被动 -**

[[item:270164]]

，或者，另外

[[item:270167]]

（稍弱）

:::

还有不少其他有价值的饰品，所以请务必点击我们的

排名图表来看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击此处查看奥术法师饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]] —— 最佳主动使用饰品</li>&#10;<li>[[item:281215]] — 最佳被动饰品</li>&#10;<li>[[item:270164]] — 非常接近第二名的最佳被动饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270170]] — 在单目标上并列最佳主动饰品，但在AOE上价值降低。</li>&#10;<li>[[item:273796]]——强大的使用型饰品</li>&#10;<li>[[item:250214]]——强力被动饰品</li>&#10;<li>[[item:270167]] — 强力被动饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] — 数值上相当强力的主动饰品，但需要监控增益效果</li>&#10;<li>[[item:250259]] — 在单目标中是强大的被动饰品，在AoE中价值降低</li>&#10;<li>[[item:250224]] — 相当强力的被动饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:273794]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可以用来保证获得特定

```
boss or dungeon. Each time you use it, you are guaranteed to obtain one

item from that boss or dungeon, and that item is then removed from the

pool of possible items. Then the next time you use it, you are guaranteed

any of the remaining items, which means that you will

obtain the item you are after from that boss or dungeon within a few uses.
```

随着12.1.5补丁的发布，你还将获得一个

```
additional Voidcore for free from

**Orin Straylight** in Silvermoon, next to The Catalyst.
```

此外，12.1.5版本带来（回归）了[[item:280562]]，它将会

```
allow you to upgrade the item level of a fully upgraded Season 2 Hero,

Mythic, or Crafted weapon, trinket, or necklace.
```

注意：史诗难度 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 和 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 装备无法再进一步

```
upgraded since they already surpass the normal maximum item level.
```

3.1.

#### 奥术法师的推荐虚空核心使用方式

**要追求的最佳物品完全取决于你已经拥有的物品

```
obtained so far, and which content you are clearing.** For example,

if you have not yet cleared a specific boss on Mythic, but expect to do

so soon, you should not use the Voidcore on the Heroic version of that boss.

Below I list a generic priority list of Voidcore items, but for the best

results tailored to your own character, you should use

[Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>).
```

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 英雄或更高难度的[[item:271092]] — 最佳武器，
   
   
   
   
   ```
       by a large margin, due to its higher item level and bonus effect. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
   
       also drops many other strong items, making it a very valuable bonus roll boss.
   ```
2. 史诗[[item:271874]]——最佳头盔，因为它的
   
   
   
   
   ```
       higher item level and Venomcursed bonus effect.
   ```
3. 神话[[item:268265]] — 由于其……而成为最佳项链
   
   
   
   
   ```
       higher item level and Venomcursed bonus effect.
   ```
4. 任何神话级轨道武器——它们都无法超越
   
   
   
   
   ```
       [[item:271092]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), but if you are not
   
       planning / expecting to kill Heroic Ulatek, getting a Myth track weapon
   
       from other sources is important, especially if you did not craft one.
   ```
5. 来自更高物品等级的装备 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)，尤其是
   
   
   
   
   ```
       [[item:268243]].
   ```
6. 剩余的毕业装备列表物品

:::

3.2.

#### 晋升毒液石

你需要以这样的方式使用你的 [[item:280562]]，即你

```
get the most amount of power per spent Venomstone:
```

1. 主手武器 / 双手武器
2. 主动使用型饰品
3. 被动饰品
4. 副手
5. 项链

在几乎所有情况下，你只会在神话轨迹装备上使用毒石，

```
unless you are not expecting to get a Myth track item in the same slot, or

if you otherwise would not have anything to spend Venomstones on.
```

一个例外是[[item:271092]]：如果你拥有这个

```
at Heroic track, and are unlikely to get it on Mythic track, upgrading it

is a great choice as the cantrip makes it better than any

Myth track weapon, especially when upgraded to 340 item level via Venomstones.
```

1.

### 奥术 法师 最佳打造物品

**制作什么很大程度上取决于你自己的个人目标，

你正在玩的内容，以及你迄今为止获得的物品。**

我们强烈建议你使用以下方式在 Raidbots 上运行你自己的模拟

droptimizer 来找出你个人最佳的制作选择。

4.1.

#### 奥术 法师最佳纹章

下面我们列出了最佳的制造美化物品，但**请务必查看

```
crafting order below for more context, since the best Embellishments are

not always the best to craft first!**
```

- [[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]] 搭配 [[item:273060]]
- [[item:239648@JAAMAAwt1ENMMYDYwslIcYD]] 搭配 [[item:240167]]

4.2.

#### 奥术 法师制造订单

由于在初期阶段你制造物品的能力将受到时间限制，

本赛季，我们强烈建议获取一个 **武器** ，尽快，除非

你可以在其他地方可靠地获得一个。一旦你有了好武器，就开始处理你的其他美化

接下来是物品，然后制作你没有高品质版本的装备部位

还没有。

下面的优先级列表可能有点令人困惑，但归根结底

```
comes down to this: You want one item with a [[item:273060]]

and one with [[item:240167]]. Hunter's Ritual Stone can only

go on Weapons, and [[item:271092]] is extremely strong, so

if you are able to get Janthrazet the Soul Fang, (or a Myth track weapon)

you will want the weapon Embellishment on an off-hand, otherwise,

you just want to stick to a 2-handed crafted weapon.
```

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **奥术 法师 打造装备优先级**
1. [[item:245770]]搭配[[item:273060]]：获取武器
   
   
   
   
   ```
       craft early provides an immense amount of power. If you expect to get a
   
       a Heroic (or better) [[item:271092]], you should skip this step.
   ```
2. 如果你跳过了上面的步骤，制造
   
   
   
   
   ```
       [[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]
   
       with [[item:273060]]
   ```
3. [[item:239648@JAAMAAwt1ENMMYDYwslIcYD]]搭配
   
   
   
   
   ```
       [[item:240167]]: Can also craft any other slot,
   
       the important part is getting Arcanoweave Lining on a piece of gear,
   
       and replacing a low item level piece. Wrist is best-in-slot, but
   
       you can re-craft later anyway.
   ```
4. 任何你尚未获得神话级的物品。
5. 如果可能，你希望替换掉制造的[[item:245770]]
   
   
   
   
   ```
       for [[item:271092]] (Heroic or higher), and then
   
       craft [[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]
   
       with [[item:273060]]. If you are not clearing
   
       Heroic, you will instead want to stick with the crafted staff
   
       [[item:245770]] with Hunter's Ritual Stone. If you are
   
       not clearing Heroic but get lucky and find a Myth track
   
       weapon in your Vault, you should use that instead and
   
       craft the off-hand with Hunter's Ritual Stone.
   ```

:::

关于如何自己制造装备的更多信息，你

可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.3.

#### 为装备添加插槽

你可以用它为头盔、腰带和护腕添加插槽

的[[item:275707]]消耗品，如果你没有在中选择任何选项，你就可以获得它。

你的宏伟宝库。不选择奖励会给你代币，其中六个可以

兑换成[[item:275707]]物品，该物品允许你为上述装备添加插槽

装备，如果你是在第2赛季获得的话。

1.

### 纹章使用

赛季初期，或如果你刚刚开始玩一个副角色，你将拥有有限的

获取升级纹章的途径，例如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)

更高的物品等级。由于纹章每周有限，升级不同装备

无论花费多少纹章，你都应该优先考虑

将它们用在你短期内不打算替换的物品上，或者那些能提供

最大的收益。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **奥术 法师 铭刻升级优先级**
**武器（选择法杖以节省纹章）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

这个顺序由升级这些部位所获得的强度决定。

当然，升级什么是最好的可能很大程度上取决于

取决于你拾取了什么，因为你可以通过拾取

这些部位物品等级更高的装备，所以请

确保你不要盲目遵循提供的升级顺序！

1.

### 评估升级

在本页及我们指南的其他地方，我们经常提到

在Raidbots上模拟自己的重要性。这是因为每个角色都是

独特的，你所拥有的每一件装备都可能改变什么是最好的

现在为你。

虽然我们确实为装备和饰品提供建议，但这些并非完整的

替代品来自模拟你自己。真正优化你角色的唯一方法

达到那种程度的方法就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为催化物品列表添加了掉落位置。
- **2026年10月9日：** 更新了毕业装备以显示升腾毒石的升级物品等级，并添加了升腾毒石升级指南，以及添加了基斯希克斯掉落。
- **2026年9月1日：** 更新了一些增益ID，以确保它们正确显示毒咒效果的提示信息。
- **2026年8月31日：** 在制造物品的提示中添加了制造属性。
- **2026年8月24日：** 已更正为正确的团队副本名称。
- **2026年8月23日：** 更新了制作优先级，以更清楚地解释双手武器与副手制作的利弊。
- **2026年8月15日：** 更新了毕业装备和专业制作建议，使用猎人的仪式石和其他小优化。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月17日：** 根据补丁后更新的理论计算更新了毕业列表和最佳饰品。
- **2026年6月15日：** 根据新的孢子融合装备更新了毕业列表和饰品推荐。
- **2026年4月20日：** 新增了幽邃虚空核心和升腾虚空核心部分，并根据武器/饰品的新物品等级上限更新了最佳装备列表。
- **2026年3月31日：** 将无常能量熔炉饰品添加到饰品层级列表中。
- **2026年3月16日：** 将赛季前毕业装备列表替换为3个不同的第1赛季毕业装备列表（总体、团本、大秘境），更新了第1赛季的制造信息，添加了第1赛季饰品天梯榜。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5更新了物品等级（涡轮加速物品等级），添加了谜之帮派章节，并针对无限徽记更新了制造推荐。
- **2025年9月10日：** 为确保对所有配装方案的准确性，为纤维推荐添加了更多说明。
- **2025年8月16日：** 根据饰品调整和新发现更新了最佳饰品。
- **2025年8月5日：** 在饰品列表中添加了更多饰品，并略微更新了大秘境毕业装备。
- **2025年8月4日：** 针对11.2.0更新了毕业列表、饰品推荐、制作顺序，添加了Reshii章节
- **2025年6月24日：** 已更新关于随重置而来的改动的DISC腰带信息。
- **2025年6月17日：** 略微更新了持久信息保障容器腰带的信息，以显示不同加成的百分比收益。
- **2025年6月15日：** 添加了持久信息保密容器腰带信息和最佳奖励，并为新腰带更新了毕业列表。
- **2025年5月20日：** 为没有神经突触增强器的人添加了 House of Cards 作为潜在的 Puzzling Chips 选项。
- **2025年5月15日：** 将物品等级更新为涡轮增压物品等级，更新了推荐饰品并提供了更多背景信息和选项，更新了财团芯片并提供了更多背景信息和不同的路线推荐。
- **2025年4月27日：** 用最新信息更新了谜之卡特皮尔代币部分。
- **2025年4月21日：** 添加了赝品经销商芯片部分。
- **2025年3月15日：** 更新了制作顺序，以更清晰地划分早期制作与毕业制作。
- **2025年3月10日：** 更新了制作选项，突出了在拥有多个插槽之前的更好前期配置。
- **2025年2月25日：** 更新了最佳饰品，同时推荐将协同酿造器作为卡赞之眼的潜在替代品。
- **2025 年 2 月 24 日：** 更新了第2赛季/11.1版本的毕业装备，根据新的毕业物品更新了制造推荐，根据新饰品更新了饰品推荐。
- **2024年12月17日：** 在增强后更新了Cyrce的指环建议，并在它变得更好后更新了毕业装备以包含它。
- **2024年12月15日：** 添加了Cyrce's Circlet章节。
- **2024年10月21日：** 更新了毕业装备和饰品梯队列表，将发射器列为第二佳饰品。
- **2024年9月24日：** 修正了副手制造错误关联的专业。
- **2024年9月10日：** 补充说明：你可以在非火花装备上制作装饰品。
- **2024年9月9日：** 从不同来源添加了3份毕业列表：团队副本、大秘境、综合。添加了饰品梯队列表。从制造文本中移除了免责声明。
- **2024年9月3日：** 更新了专业制作建议和毕业装备列表。
- **2024年8月27日：** 更新了关于更新后的装饰的制作建议，并更新了毕业列表。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月30日：** 修正了整体毕业列表中缺少4件套的问题。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季更新：更新了毕业列表，添加了铸币物品，更新了推荐的专业制造。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月13日：** 根据不同的大秘境掉落更新了毕业装备，并更新了仅限团本的毕业装备。
- **2023年11月7日：** 由于孢子披风削弱，更新了毕业装备和纹章。
- **2023年11月6日：** 为10.2更新了毕业装备、美化及其他相关部分。
- **2023年9月26日：** 更改了布局。
- **2023年9月4日：** 添加了3种不同的毕业配装。
- **2023年7月10日：** 因重做而更新了新最优装备的毕业装，并更新了奥妮克希亚的紫晶指环部分以反映削弱后的版本。
- **2023年5月25日：** 添加了时光漫游部分。
- **2023年5月10日：** 根据进一步的改进更新了饰品建议。
- **2023年5月8日：** 根据改进的模拟和进一步的理论计算更新了饰品建议。
- **2023年5月1日：** 更新了10.1版本的毕业装备、制造建议和其他配装建议。
- **2023年3月25日：** 根据在线修复更新了Onyx戒指建议。
- **2023年3月22日：** 更新了最佳装备以包含昂赛恩戒指，因为发现了新的宝石组合。
- **2023年3月20日：** 添加了奥妮克希亚的指环信息，并针对 10.0.7 补丁进行了审阅。
- **2023年1月24日：** 将虚空缝补者的暗影宝石添加到饰品列表中。
- **2023年1月20日：** 修正了错别字。
- **2022年12月17日：** 由于青铜护手的改动，更新了制造装备信息。
- **2022年12月13日：** 根据最新的理论计算知识进一步更新了制造装备信息。
- **2022年12月11日：** 补充了制造装备的相关信息。
- **2022年12月11日：** 根据第1赛季可用装备和制作装备更新了装备建议。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面，你将找到你的 奥术 法师 的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已更新至《魔兽世界》12.1.5补丁。

1.

### 奥术 法师 属性优先级

以下是奥术法师属性选择的良好准则：

智力

急速

暴击

精通

全能

**尽管在列表上的排序如此，所有次要属性（智力以外）的价值都非常接近。**
我们鼓励玩家尽可能自己进行模拟，以根据你当前的属性分布确定应该追求哪些属性，因为这可能会根据你当前的数值而变化。这是因为某一项属性的匮乏往往会导致其相对其他属性的价值升高，直到你达到一个“均衡”值。因此， **我们强烈建议使用 [Raidbots 最佳装备](<https://www.raidbots.com/simbot/topgear>)**
来处理你的装备需求（参见我们的 [Raidbots指南](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)).

1.

### 深入属性解析

**智力** 是你的主属性。它为你提供法术强度，增加你法术的伤害。

**精通**，多亏了[[spell:190740]]，增加了你的法力值和法力回复，使你能够在[[spell:12051]]之间施放更多具有最大奥术充能的法术。Savant还增加了奥术充能的伤害增益，并且还增加了所有其他法术的伤害。

**急速** 提高你法术的施法速度。

:::details 常见问题奥术 法师有急速上限吗？
奥术法师没有急速的阈值或上限。不过，所有属性都有边际收益递减，获取更多属性会降低其价值，所以通常进行一些平衡是有价值的。此外，如果你只堆急速而不怎么堆精通，你会非常快地耗尽法力值，这使得属性平衡变得更加重要。

:::

**暴击** 提高你所有法术和技能的暴击几率。暴击默认造成双倍伤害，但有多种效果可以提高你的暴击伤害，使暴击更加强力。

**全能** 是纯粹的造成伤害提升和承受伤害降低。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 更新了急速常见问题，补充了更多背景信息。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 由于 11.1 的改动，将全能列为第二好的副属性。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月21日：** 更新了属性权重的描述，更清楚地解释了使用最优装备（Top Gear）模拟更好。
- **2024年9月9日：** 由于第1赛季装备解锁更好，已更新属性优先级，使急速优于精通。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审核。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本的奥术重做进行审核。
- **2023年5月1日：** 由于10.1的改动更新了属性优先级。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的奥术法师可以获取的最佳宝石、附魔、药剂、药水和食物，这些基于你的 [属性优先级](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

有史诗和稀有宝石两种，史诗宝石明显更强。然而，你只能装备一颗史诗宝石，因此其余插槽需要用稀有宝石填满。

有两种史诗宝石，根据情况不同，其中一种可能为最佳选择。如果你有5个或更多宝石插槽，[[item:240967]]是最佳的史诗宝石。然而，如果你的插槽少于5个，请使用[[item:240983]]。

**稀有宝石的强度都非常接近，最好的一颗会根据你具体的属性分配而变化。**
如果你有5个或更多宝石插槽，因此使用[[item:240967]]，你应该每种颜色各使用一个。否则，你可以使用任何模拟结果最好的宝石，或者使用[[item:240900]]作为安全的默认选择。完整详情请参见下面的列表。

- 史诗：
  
  
  
  
  - 拥有5个或更多插槽时：[[item:240967]]
  - 少于5个插槽时：[[item:240983]]
- 稀有品质，5个或更多插槽：
  
  
  
  
  - 1x [[item:240892]]
  - 1x [[item:240906]]
  - 1x [[item:240900]]
  - 1x [[item:240916]]
  - 其余插槽[[item:240900]]
- 稀有品质且插槽少于5个：所有插槽使用[[item:240900]]

<em>我们强烈建议使用 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来模拟你角色的理想宝石和附魔，因为它们可能与我们的一般推荐不同。</em>

1.

### 最佳附魔和武器强化

你应该在所有内容中使用[[item:243733]]作为武器油。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头盔（非伤害）</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>肩部（非伤害）</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240155]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>[[item:243957]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部（非伤害属性）</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>[[item:244029]] </td>&#10;</tr>&#10;</table>

并非所有附魔都提供伤害，比如头部、肩膀和脚部，你可以在这些部位选择速度、闪避或吸血。速度通常是一个稳妥的选择，因为你在所有瞬发法术如[[spell:44425]]或[[spell:153626]]，以及引导法术如[[spell:5143]]期间可以移动更远。这使你可以将快速移动技能如[[spell:212653]]/[[spell:1953]]留到你需要因机制而突然移动的时候使用。然而，闪避附魔也是这些部位的绝佳选择，可以简单地减少你从各种敌人技能中受到的伤害。我通常不推荐在组队内容中使用吸血附魔，但在单人内容中可能相当不错。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

在第2赛季中，所有副属性药水的伤害输出都非常接近，最佳药水会根据你的装备而有所不同。[[item:241325]]通常是一个安全的选择，要么是最好的，要么接近最好。

3.2.

#### 药水

[[item:241308]] 是所有内容中最佳的输出药水，而 [[item:271883]] 是我们首选的治疗药水。

3.3.

#### 食物增益

[[item:255845]]，或者如果你在进行经常死亡的内容（如开荒团队副本首领），则使用[[spell:1278895]]。

3.4.

#### 强化符文

强化符文通常相当昂贵，但使用时确实能提供大约1%的DPS提升，所以在进行最难的内容时它们可能相当重要。[[item:259085]]是目前唯一可用的强化符文。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月17日：** 更新了最佳药水。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 移除了茶的提及，因为它在副本中不起作用。
- **2026年3月16日：** 将戒指附魔更新为使用鹰眼而非属性附魔，因为它在几乎所有情况下都稍微好一点。
- **2026年3月1日：** 在食物部分添加了茶类及其移动速度加成。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2.0进行更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 添加了腐蚀附魔章节。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月11日：** 新增了武器消耗品（油）。
- **2024年9月9日：** 添加了幻影亵渎宝石作为选项，以牺牲少量伤害为代价换取更高的移动速度。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 新增了头部附魔（灼热精华）并更新了药剂建议
- **2024年3月19日：** 已针对10.2.6补丁进行审阅，并添加了关于最佳宝石的说明。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 移除了关于奥妮克希亚的回忆和原始宝石的参考，因为它们在10.2版本中已不再相关。
- **2023年10月1日：** 更新了食物增益建议。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5版本的削弱更新了Onyx Annulet部分，并审核了其余部分以配合10.1.5版本中奥术的重做
- **2023年5月1日：** 移动了原始石信息，并根据10.1的改动更新了建议。
- **2023年3月25日：** 根据热修复更新了原始石宝石建议。
- **2023年3月22日：** 由于 Desirious Blood Stone（渴血之石）的组合非常强大，更新了始源之石的宝石建议。
- **2023年3月21日：** 根据晦暗粉彩石在正式服务器上是奥术而非暗影，更新了原始石宝石建议。
- **2023年3月20日：** 添加了原初之石宝石建议，并针对10.0.7补丁进行了审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月12日：** 新增了法术线建议。
- **2022年12月14日：** 添加了武器灌注建议。
- **2022年12月13日：** 更新了药水建议。
- **2022年12月11日：** 根据更好的模拟结果更新了宝石建议。
- **2022年12月11日：** 更新了药水建议。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本攻略中，你将找到在《魔兽世界》12.1.5补丁中使用你的奥术法师挑战大秘境地下城的技巧与建议。

1.

### 奥术 法师在至暗之夜第2赛季大秘境中的表现

奥术 法师 近年来一直是强力的大秘境专精，第2赛季也不例外。它拥有出色的范围伤害能力，同时能造成非常高的优先目标伤害，比游戏中几乎所有其他专精都要好。它还具备出色的实用性和生存能力，使其成为任何大秘境队伍都非常理想的专精。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

在大秘境中，你作为奥术法师的角色是专注于快速击杀高优先级目标，同时仍然保持出色的总体伤害。这通常使得奥术在任何大秘境队伍中都非常有价值。

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒大秘境构建

2.1.

#### 日怒大秘境构建

这是首选的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒 大秘境配装，也是 奥术 总体上可用的最强配装。它结合了出色的范围伤害输出和出色的首领伤害输出，而无需在任何一方做出实质性妥协，使其成为大秘境的绝佳选择。

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYCgbhJJ-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师大秘境构筑

2.2.

#### 疾咒师大秘境构筑

这是首选的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) 疾咒师 大秘境配装。它目前比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) 日怒变体，但仍然表现得相对不错，尤其是在范围伤害上，差距相当小。

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAAAzMzssMzELAAsNYmZYzyMmxMGzMzMDbMjZMDAwAAAMzsBAzMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYirZBAJ-NbckEGRXKdoww6AHLYkJeAZZpp9FCMB-AAAA-OQSaKMUwADQAxC-
```

:::

### 灵活天赋 / 副本专属天赋

2.3.

#### 灵活天赋 / 副本专属天赋

根据地下城不同，天赋方面有很大的灵活性。法师职业树拥有大量实用技能，根据地下城的不同，这些技能可能非常有用，也可能完全没用，这让你可以根据需要在这些实用法术或防御天赋之间进行切换。

- 根据个人喜好在[[spell:1244090]]或[[spell:1244087]]之间切换。时光重组是一个非常简单的被动治疗，当你血量低时触发，而时空漫步如果你擅长主动使用[[spell:342245]]则更好。
- 根据是否需要跳过小怪，切换 [[spell:414664]] 的学习与取消。
- 根据你是否需要解除任何诅咒来决定是否专精[[spell:475]]。
- 根据是否需要移除任何敌人增益效果，切换[[spell:30449]]的使用。
- 根据你正在攻略的地下城是否需要 [[spell:45438]] 的免疫效果，切换 [[spell:414659]]（及通往它的节点）的学习与取消。
- 如果你从上面列出的任何节点中退出专精，你可以使用这些点来专精以下一个或多个：
  
  
  
  
  - [[spell:1270827]]：如果你经常需要对同一目标连续驱散多次，但又不想为此牺牲太多公共冷却时间，这个天赋很有用。
  - [[spell:1270847]]：如果你经常需要同时驱散自己和另一个人，但不需要驱散其他人，这很有用。通常只有当队伍中有第二个诅咒驱散者时才推荐。在 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>) 周，快速驱散自己和另一个人。
  - [[spell:386763]]：如果你需要风筝敌方怪物群。
  - [[spell:382293]]：用于速通内容。
  - [[spell:210476]]：如果你需要更高的移动速度加成或想在全潜行队伍中跳过敌人，可以与 [[spell:382293]] 搭配使用。

1.

### 大秘境深度输出循环提示

以下列出了一些特定的大秘境技巧，一旦你已经熟悉了我们循环页面中的常规循环，这些技巧可以进一步提升你的游戏水平。

3.1.

#### 在大秘境中优化移动与空闲时间

在大秘境中，你的伤害输出最重要的部分之一将取决于你如何高效地在怪物群之间移动，以及如何利用怪物群之间的空闲时间。下面，我们提供了一些关于如何管理这一点的提示。

- 确保你在开始副本时带些水，以便在需要时脱战恢复法力值。
- 如果你在前往下一波怪物的路上法力值偏低，记得喝点水。最简单的方法是在一波怪物死后立刻[[spell:1953]]或[[spell:212653]]到前方，争取喝上2到3秒的水。

1.

### 功能技能与能力

### 打断、昏迷和控制

4.1.

#### 打断

[[spell:2139]]是我们大多数情况下的首选打断技能。它不仅会打断一个法术，还会根据天赋使敌人在7-8秒内无法施放同系法术。

为了避免不得不切换目标，我强烈建议使用鼠标悬停或焦点目标宏。下面的宏会打断你的焦点或鼠标悬停目标（如果你有的话），或者在你没有的情况下打断你当前的目标。

#### 鼠标悬停反制

```wow-macro
#showtooltip
/cast [target=mouseover,exists] 法术反制; 法术反制
```

#### 焦点打断

```wow-macro
#showtooltip
/cast [target=focus,exists] 法术反制; 法术反制
```

4.2.

#### 眩晕与"打断"

[[spell:157980]]和[[spell:31661]]是对敌人进行范围打断的主要方法。你只能选择其中一个，选择哪一个取决于情况。它们通常都能打断敌人的施法，但与[[spell:2139]]不同的是，它们无法阻止敌人立即重新施放相同或不同的法术。

一般来说，新星更容易使用，因为它可以在不靠近敌人的情况下使用，但两者都是不错的选择。

此外，[[spell:118]]、[[spell:113724]] 和 [[spell:383121]] 也可以用来打断敌人（如果点了天赋），但在大多数情况下敌人会立即重新开始施法，所以这只应作为最后的手段。变形术还有一个缺点，就是会治疗敌人。

### 其他功能

4.3.

#### 其他功能

[[spell:1459]] 为全队提供智力加成，提高你自己和其他施法者的 DPS，以及治疗者的治疗量。

[[spell:80353]]对于任何大秘境队伍来说都是一个关键的冷却技能。每10分钟它就能为队伍提供一个巨大的急速增益。

[[spell:475]]在某些地下城中可用于驱散诅咒。它也应该被用来驱散 [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)
如果它是一个生效的词缀。

[[spell:30449]]可用于移除敌人身上的魔法增益效果并转而施加给你。尽管在许多情况下，出于平衡原因这些增益实际上并不会转移给你，因此它主要作为进攻性驱散使用。

[[spell:110959]]可以用来完全脱离仇恨，同时它有时还能完全取消某些减益效果、对你施放的定向法术或取消各种机制。

[[spell:386828]]允许你移除定身/减速效果。它通过完全移除造成减速的减益来实现，这意味着它有时可以用来完全移除危险的减益，如果这些减益同时也施加减速的话。

[[spell:414664]] 偶尔可用于跳过某些怪群。

1.

### 应对词缀

至暗之夜 第2赛季有四个轮换的 词缀 需要主动应对，称为萨拉塔斯的交易。这些每周轮换，同一时间只有一个处于激活状态。大多数其他大秘境词缀，如残暴或强韧，只是为钥石添加一个被动效果，而这四个例外是以萨拉塔斯为主题：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将出现三波需要被打断或驱散的宝珠。你有多种方式来处理它们：如果它们聚集在一起，用 [[spell:157980]] 进行 AOE 打断，用 [[spell:2139]] 进行单体打断，用 [[spell:30449]] 处理剩余的。由于法术偷取没有冷却时间（除非点出 [[spell:1270827]]），理论上你可以清除所有宝珠，但这会花费大量时间。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：生成一个虚空大使敌人，需要快速将其击杀。它死亡后，你会获得一个强力的技能冷却和全能增益。注意：如果它生成在你已经点燃的敌人附近，你可以将[[spell:12846]]扩散到该目标上，从而为这个小怪提供大量免费伤害。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：宝珠会在玩家周围生成并环绕他们旋转。你有15秒的时间吸收所有这些宝珠来为你的小队提供增益。只需跑过去吸收它们即可。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有小队成员都会受到一个治疗吸收效果的影响。你可以用[[spell:475]]移除这些效果。[[spell:1270847]]对于快速驱散你自己和另一名玩家非常有用。如果你的治疗者资源耗尽，治疗药水或治疗石也能很好地发挥作用。

当你成功应对这些词缀时，它们会授予你一个增益效果，不同词缀效果不同。这些效果通常相当强大，但玩家们并没有真正围绕它们进行规划。然而，正确应对它们非常重要，因为失败会给敌人带来增益，这可能很快导致队伍灭团。

注意：这些词缀在进行史诗钥石等级12或以上的地下城时会消失（正面和负面效果均消失），取而代之的是死亡会使计时器减少15秒。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 更新了功能部分的布局，并为打断和功能添加了一些额外的说明。
- **2026 年 3 月 17 日：** 添加了优先DPS与最大AoE DPS部分。
- **2026年3月16日：** 已针对至暗之夜第1赛季更新：更新了最佳天赋、灵活天赋，添加了赛季词缀等。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为12.0.1天赋树改动更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 更新了11.2的最佳构筑，新增了第三赛季实用法术部分。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月22日：** 移除了起手打断提示，因为它们无法被迷惑打断。
- **2025年3月14日：** 为所有地下城添加了提示。
- **2025 年 2 月 24 日：** 根据11.1的改动更新了最佳天赋，并针对新的词缀更新了词缀提示。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 根据最后时刻的削弱更新了天赋。
- **2024年10月21日：** 为11.0.5改动更新了最佳天赋。添加了疾咒师与日怒的对比信息。添加了副本专属提示。
- **2024年9月9日：** 已更新至地心之战第1赛季。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对 10.2.6 补丁进行了审阅，并更新了天赋选择信息。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了10.2版本的天赋。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为重做的奥术更新了推荐天赋和输出循环。
- **2023年5月1日：** 移除了关于雷鸣的提及，并针对10.1的改动进行了审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审阅并提供了一些小的措辞调整。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月16日：** 将推荐天赋更新为法力宝石构建，并进行了一些小的提示更改。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5版本中游玩奥术 法师时更加轻松。

1.

### 最佳宏

以下是法师，特别是奥术法师的实用宏合集，其中一些可用于所有三个专精，另一些仅在你玩奥术法师时有用。

1.1.

#### 奥术 Mages 专用宏

1.1.1.

##### 一键奥术涌动

#### 一键奥术涌动

```wow-macro
#showtooltip 奥术涌动
/cast 先祖召唤
/cast 狂暴
/cast 血性狂怒
/cast 奥术涌动
/use 13
/use 14
/use 16
```

这将施放[[spell:365350]]并激活任何提供伤害的饰品或种族效果。

1.2.

#### 法师通用宏

请记住，使用任何停止施法宏时，它们不会打断全局冷却。如果你仍处于全局冷却中，你的施法会被取消，但在脱离全局冷却之前，下一个技能不会施放。

1.2.1.

##### 打断闪现

#### 瞬发闪现

```wow-macro
#showtooltip
/stopcasting
/cast 闪现术
```

按下[[spell:1953]]现在会取消你当前的法术施放并使你立即闪现。注意，这不应该与[[spell:212653]]一起使用，因为它会不必要地取消你当前的施法，也不应该在你施放某个法术时使用，如果你可以等待完成施法再需要闪现的话

1.2.2.

##### 一键格挡

#### 一键 寒冰屏障

```wow-macro
#showtooltip
/stopcasting
/cancelaura 寒冰屏障
/cast 寒冰屏障
```

取消你当前的施法并立即进入 [[spell:45438]]。再次按下 寒冰屏障 会取消该效果。如果你习惯狂按技能键，不推荐使用。

1.2.3.

##### 格挡取消

#### 取消光环寒冰屏障

```wow-macro
/cancelaura 寒冰屏障
```

如果你是狂按按钮的玩家，可以将其放在单独的快捷键上作为你的[[spell:45438]]，让你能够提前取消你的寒冰屏障。

1.2.4.

##### 操控时间 取消

#### 取消光环 操控时间

```wow-macro
/cancelaura 操控时间
```

你可以使用上面的宏来取消 [[spell:342245]]，如果你不想被传送回最初施放 操控时间 时的位置/生命值。

1.2.5.

##### 鼠标悬停驱散

#### 鼠标悬停解除诅咒

```wow-macro
#showtooltip
/cast [target=mouseover,exists] 解除诅咒; 解除诅咒
```

这将解除你鼠标悬停的任何单位身上的诅咒。你可以将解除诅咒替换为你想在鼠标悬停时施放的任何其他法术，比如[[spell:30449]]。如果你没有鼠标悬停目标，它将对你的当前目标施放，或者如果你既没有悬停目标也没有选中目标，则对你自己施放。

1.

### 最佳插件

2.1.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) 是对默认用户界面的完整替代。它包含了你正常发挥所需的几乎所有功能：动作条、单位框体、冷却计时器、触发提示等。

2.1.1.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) 是一个有用的插件，可以让你追踪其他团队成员的冷却时间，并为你提供大量其他有用的团队信息。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 更新了奥术涌动宏，默认包含所有相关种族技能/饰品栏位。
- **2026年3月9日：** 修复了指向 解除诅咒 的鼠标悬停宏。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 为10.2.6进行了复查，移除了一个已不再相关的插件包链接，并为奥术弹幕 + TOTM添加了新的宏。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审核。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月28日：** 添加了一个通用WeakAuras包，包含所有专精所需的全部WeakAuras。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
