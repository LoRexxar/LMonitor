## 专精概览

Welcome to our Elemental Shaman guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Elemental Shaman in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Elemental Mythic+ Resources

[NEW! Top Elemental Talent Builds](<https://raider.io/specs/elemental-shaman/talents>)

[Top Elemental Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/shaman/elemental>)

[Elemental Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=shaman--elemental>)

[Popular Elemental Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=shaman--elemental>)

1.

### Elemental Shaman Overview

Elemental Shaman is a damage-dealing spellcaster with a rich and flexible
toolkit. Elemental Shamans can approach a multitude of environments without
feeling compromised. The specialization has unmatched utility in many scenarios and
can be customized to adapt to a variety of damage profiles. Overall, this
specialization has a tool or talent for most scenarios.

Solid Across the Board

Elemental Shaman has a very uneven damage profile, struggling with 2/3 target cleave,
 with two significant "cooldowns" that are useful in every situation, and good
 sustained damage in both single-target and AoE. It is very simple rotationally
 but has mediocre mobility. The nerf to burst cooldowns hit Elemental more than
 most however, and it now has a fairly flat damage profile, hindering its actual
 performance.

Good Single-Target, Low Utility and Mobility

Elemental Shaman has strong numbers for single-target but suffers from a relative
lack of burst and is very weak on 2 targets, which is a common profile in the raid.
It has mediocre mobility outside of

[[spell:79206]]

and while it has few active defensives, its passive survivability is solid for
a ranged DPS. It also suffer from a lack of unique utility options in raids.

Strong Across the Board

Elemental Shamans are in high demand in Mythic+, having strong, reliable AoE damage,
while also doing high single-target DPS. Pulling additional trash on top of bosses
 is excellent for Elemental.

Shamans also bring an incredible utility and crowd-control arsenal that
can be tailored even more to each dungeon. Our passive survivability in dungeons is
excellent thanks to several talents and most notably

[[spell:355630]]

whenever
there are targets to interrupt.

Great in Dungeons, Mediocre in Raids

Shamans have access to wide arsenal of utility, however many of them are niche and
some simply do not get used at all, particularly in a raid environment. Other abilities
are simply worse than other classes' and Shamans suffer as a result. In raids,
the Shaman kit is not very useful outside of their treasured buff

[[spell:462854]]

, but
it is in Mythic+ that their flexible toolkit really shines, with unique boons such as

[[spell:383013]]

,

[[spell:8143]]

or

[[spell:378075]]

. A spammable

[[spell:370]]

removing nasty buffs from enemies is also quite potent if the situation
asks for it.

Strong Passives, Weak Actives

Elemental Shamans trade strong passive survivability for a lack of active defensives.
They simply lack the powerful tools that many other classes have, instead relying on
significant passive damage reduction and healing. Outside of your personal defensive,
you only have access to your

[[spell:198103]]

every 3 minutes and,
when all is lost,

[[spell:20608]]

on a 30-minute CD. This last ability however remains the one
ability in the game that does not reset on pull, so you cannot rely on it strategically.
There is one situation where Shamans become remarkably tanky however, which is when
you can reliably gain

[[spell:355630]]

, which is whenever there are interruptible
casters around.

Highly Dependent on One Cooldown

Elemental has mediocre mobility outside of

[[spell:79206]]

which must
under no circumstance be misused. It has few instant casts in general, particularly
in AoE situations, making smart use of your few soft movement windows particularly
important. When necessary, you do however have multiple ways of getting to places
 in a hurry, between

[[spell:192077]]

,

[[spell:192063]]

and

[[spell:2645]]

,
 but those all come at a cost damage-wise and are not particularly strong.

2.

### Elemental Shaman in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 introduces one new Raid encounter, [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>), and a new and
exciting type of [Delves](<https://www.icy-veins.com/wow/delves-guide>): the Labyrinth of Kindo'jan!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

There are no changes to Elemental Shaman in Patch 12.1.5., but you can find 
updated recommendations on our [gear](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>) 
page regarding new item drops from the new Raid as well as how to spend your 
[[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_lavaburst.jpg>) Click for Previous Season 2 Changes
- Show Patch 12.1 changesHide Patch 12.1 changes
  
  
  2.4. 
  
  ### Patch 12.1 Class Changes
  
  
  
  
  This patch brings signficant changes to Elemental:
  
  
  
  
  First, most notably, Elemental was hit harder than most with regards to the global
  "burst nerfs" brought by the patch.
  
  
  
  
  - [[spell:114050]] now increases the damage of Elemental Overload by 
    30% (was 75%). Bonus [[spell:51505]]s when activating Ascendance are now 50% 
    of their normal value (was 100%)
  - [[spell:191634]] no longer causes [[spell:188196]] to generate 
    an additional Elemental Overload.
  
  
  
  
  Then come more general changes, mostly buffs to direct builder damage and nerfs 
  to overloads. Note that these nerfs compound the nerfs to [[spell:114050]] 
  and [[spell:191634]], as they are largely dependant on overloads:
  
  
  
  
  - [[spell:191861]] has been redesigned: [[spell:188196]] and 
    [[spell:188443]] have a 15% chance to cause your next [[spell:51505]] 
    to deal 20% increased damage, stacking up to 2 times. [[spell:51505]] consumes 
    one stack at a time.
  - [[spell:51505]] damage increased by 30%. This does not apply to PvP combat.
  - [[spell:188196]] damage increased by 30%. This does not apply to PvP combat.
  - [[spell:188443]] damage increased by 60%.
  - [[spell:188389]] damage increased by 60%.
  - [[spell:454009]] damage reduced by 20%.
  - [[spell:1258843]] now increases the damage of [[spell:51505]] by 10% (was 15%).
  - [[spell:1270061]] now increases Elemental Overload damage by 10% (was 35%) 
    and also increases Elemental damage done by 10%.
  - [[spell:1270062]] now grants 15/30% critical damage bonus (was 25/50%).
  - [[spell:117014]] casts from [[spell:462840]] now only grant 40% 
    of the normal duration of the Elemental Blast stat buffs (was 100%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:455110]] has been redesigned and now makes
    [[spell:188196]], [[spell:188443]] and [[spell:454009]] Elemental
     Overloads deal 10% additional damage.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestor [[spell:51505]]s now also increase damage by a percent equal 
    to your critical strike chance (note that in the last patch they also were made to 
    scale with [[spell:60188]]).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestor [[spell:51505]] damage reduced by 20%.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestor [[spell:188443]]s now hit up to 5 targets (was 3).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestor [[spell:188443]] damage reduced by 20%.
  - [[spell:8004]] healing increased by 25%.
  - [[spell:974]] healing increased by 25%.
  - [[spell:5394]] healing increased by 25%.
  - [[spell:462477]] healing increased by 25%.
  - Fixed an issue that caused [[spell:470057]] to not be properly affected by 
    [[spell:60188]]'s critical damage bonus.
  - Fixed an issue that caused [[spell:1258895]] to not affected periodic 
    Elemental damage.
  - Fixed an issue where [[spell:1270062]] did not properly increase the critical 
    damage of several Elemental Shaman spells.
  
  
  
  
  Note that the healing changes are just to keep up with the global 25% Health 
  increase brought by the patch.
  
  
  
  
  2.5. 
  
  ### New Season 2 Tier Set
  
  
  
  
  Elemental is receiving a powerful new Tier Set in Midnight Season 2:
  
  
  
  
  - 2-Set Bonus: [[spell:8042]], [[spell:117014]] and [[spell:61882]] 
    damage increased by 25%.
  - 4-Set Bonus: When [[spell:191634]] or [[spell:114050]] 
    fade, your next 2 [[spell:188196]]s, [[spell:188443]]s, or [[spell:51505]]s 
    deal 25% increased damage and cause your next [[spell:61882]], [[spell:8042]], 
    or [[spell:117014]]to cost 100% less Maelstrom.
  
  
  
  
  The 2-Set Bonus is straightforward: beefier spenders! This is both strong and nice, 
  as Elemental's "spenders" always felt like they did not quite hit hard enough.
  
  
  
  
  The 4-Set bonus is a bit stranger and currently has several bugs or seemingly 
  unintended issues. The damage to builders stacks, but not the "free" spender charges. 
  More importantly, when using both our cooldowns together, as we usually do, the tier 
  only procs when both cooldowns have faded, giving 4 stacks of the builder buff.
   Generally it is very easy to waste value with the spender charge and we hope
   Blizzard will allow for those to stack as well. [[spell:1259471]] also
   consumes multiple stacks of the builder buff at once. All that being said, 
   it is a pretty strong bonus, particularly if the above issues 
  end up fixed.

:::

### Midnight   Changes Overview

2.6.

#### Midnight Changes Summarized

[Midnight Alpha Test Development Notes](<https://eu.forums.blizzard.com/en/wow/t/midnight-alpha-test-development-notes/590289>)

Developers’ notes: Our goals with Elemental for Midnight are to reduce
	the number of rotational abilities and auras tracked, make it simpler to engage
	with Stormbringer talents, and add new gameplay for using fire spells in AoE.
	Flame Shock can now be replaced with an upgraded ability, Voltaic Blaze,
	that applies 6 Flame Shocks and causes your next Lava Burst to hit all Flame Shocked
	targets, similar to previous designs for Primordial Wave. With this version,
	we’re looking to allow a quick transition from Flame Shock application to the
	AoE Lava Burst for simplicity and keeping up with the demands of AoE against
	short-lived creatures. This is an optional talent path, so for players who
	want to focus on lightning and maelstrom spenders that’s still intended
	to be a viable playstyle.

2.6.1.

##### Most Impactful Changes

- [[spell:378270]] is gone.
- [[spell:210714]] is gone.
- [[spell:108270]] and [[spell:108285]] are gone.
- [[spell:192222]] and [[spell:375982]] are gone and have been
  consolidated into [[spell:470057]].
- [[spell:198067]] does not exist anymore as a talent or an ability you can use.
- [[spell:114050]] now gets a talent that makes Ascendance spawn a Fire Elemental.
- [[spell:192249]] now only exists via [[spell:191717]].
- [[spell:378779]] is gone.
- [[spell:462840]] now procs from [[spell:191861]].
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:454009]] now procs from casting [[spell:114050]] and randomly
  from spending Maelstrom.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: Casting [[spell:454009]] now grants a charge of [[spell:191634]].
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestors now spawn from [[spell:191634]]
  (and still spawn from [[spell:443454]]) instead of [[spell:375982]].

2.6.2.

##### How Elemental Was "Pruned"

Elemental, like most specializations, is getting “pruned” in World of 
Warcraft: Midnight. This means a number of abilities, both actives and passives, are getting cut, 
in order to simplify the gameplay, making it more accessible to new players and
not requiring the until now expected level of UI customization via addons such as WeakAuras.

Most notably for Elemental: [[spell:210714]], [[spell:375982]], [[spell:192222]],
 [[spell:378270]] and [[spell:108270]] are gone and you do
 not need to summon an Elemental pet manually anymore. Several abilities from 
 the Stormbringer hero talents have also been simplified. Altogether, you will 
 need 5 or 6 fewer binds compared to the current version of Elemental, 
 and will have few things you need to track.

There is much more to it however, as while many talents were removed, some were 
added, and while most of the class tree additions are underwhelming to say the least, 
there are some interesting things in there. Moreover, many talents have been reworked 
or significantly adjusted. Once Midnight launches on March 2nd, three Apex Talents will 
also be available in the Elemental tree, and each Hero talent will receive three 
new nodes (and you get 3 more points so they will still be fully filled).

2.6.3.

##### Hero Talent Changes

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer changes are mainly targeted at dropping the necessity 
(or at least the feeling of it) of tracking many different Stormbringer related 
procs and resources. This achieves that goal, at the cost of significantly increasing 
the RNG involved, although adjusting the old [[spell:454026]] effect into
 instead making [[spell:454009]] grant a charge of [[spell:191634]]
 will feel nice. The loss of [[spell:470532]]'s original damage increase will 
 significantly lower the power of the Hero tree unfortunately. Notably, the changes
 and loss of the TWW tier will lead to far fewer Tempest procs and generally
 "chain" procs, making the spec more manageable but less exciting.

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer change making [[spell:191634]] generate your 
ancestors was inevitable following the removal of [[spell:375982]],
with another source of ancestors being added to [[spell:443445]] to
 make up for [[spell:191634]]'s cooldown being higher. The other changes
 seem to further solidify Farseer as being focused on single-target and 2-3 targets cleave.

All in all, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer's main appeal is being more mobile largely due
 to not needing [[spell:117014]],  while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer really wants it. 
 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer now does much more damage in most situations if you can
 handle the mobility and added complexity, and will be the go-to Hero Talent
 for most content for advanced players.

2.6.4.

##### Rotational Aspects

Elemental has a lot fewer buttons and the complexity of the rotation has been gutted.
 While it may sound good to new players, alts or people who generally prefer simpler 
 rotations, people who enjoy current elemental will likely be disappointed. In 
 single-target we are back to [[spell:188196]], [[spell:51505]],
 a spender and refreshing [[spell:188389]] and that is it.

In multi-target, [[spell:470057]] with [[spell:1259471]] will emulate 
 the previous Liquid Magma Totem + Primordial Wave combo with one fewer buttons, and 
 the loss of Echoes of Great Sundering and Icefury means we are back to spamming 
 [[spell:188443]] and spenders between [[spell:470057]] casts (though 
 you add [[spell:454009]] for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer and [[spell:51505]]
 for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer to proc [[spell:1259471]]).

Our damage profile will be flatter with the removal of [[spell:378270]],
 a significant nerf to [[spell:114050]] and losing [[spell:192249]].

2.6.5.

##### Class Tree Changes

With all the talents being removed without any being added, our class tree becomes
quite small, and while we already had enough points to get everything we wanted in any raid,
you now can get pretty much all you could need for dungeons and even PvP and should
not need to change your class tree much aside from choice nodes.

[[spell:355630]] is in most cases a welcome survivability buff although it
not stacking anymore does mean we are not unkillable on certain packs anymore.
The [[spell:198103]] changes are fairly neutral overall though in practice
are probably a slight buff on most encounters, though it does not make up for the
loss of [[spell:108270]].

The new [[spell:1217622]] is quite good and will allow ourselves and
a designated ally to get significant free healing over a raid encounter or a dungeon. 
Its sister talent [[spell:462477]] could potentially be used but will require 
tracking more things and the benefit is small.

2.7.

#### Apex Talents for Elemental Shaman: Feedback Loop

Midnight introduces "Apex" talents, which are supposed to be different than 
regular talents, but for Elemental they're basically just "more damage" and do not 
really influence your gameplay in any way, you just gain slightly more Maelstrom, 
and they make Mastery more valuable. For the most part, they are "do more damage" 
talents, but since they are tuned very high, they are absolutely mandatory picks 
in every circumstance.

- **Apex talent:**[[spell:1270061]] — Elemental
  	Overload damage	increased by 35%.
- **Apex talent:**[[spell:1270062]] — Spell critical
  	strike chance increased by 5%/10%. [[spell:60188]] increases spell critical
  	strike damage by an additional 25%/50%.
- **Apex talent:**[[spell:1270064]] — Elemental
  	Overloads have a 25% chance to cause an additional Elemental Overload.
  	This can only occur once per cast.

2.8.

#### Shaman Class Tree Changes

Each specialization now automatically learns one spell instead of two through the Shaman talent tree,
meaning you now need to spend a point to learn [[spell:188443]].

[[spell:51505]] base damage reduced by 20%, but its damage is now increased
by its critical strike chance.

The healing of some abilities have been increased:

- [[spell:8004]] healing increased by 130%
- [[spell:5394]] healing increased by 50%.
- [[spell:974]] healing increased by 50%
- [[spell:30884]] healing increased by 100% (40% of max life from 20%)

- New talents being added:
  		
  
  - [[spell:1270375]] — Mastery increased by 3%.
  - [[spell:1270350]] — [[spell:192106]]
    increases your Intellect by 3%. Casting Lightning Shield also applies [[spell:974]]
    to yourself and any weapon imbuements if known.
  - Previously exclusive to Restoration: [[spell:1217622]]
    			— [[spell:974]] no longer loses charges and is 115% effective
    			(Choice node with [[spell:462477]])
  - Previously exclusive to Restoration: [[spell:462477]]
    			— When refreshing [[spell:974]], your target is healed
    			for each stack of Earth Shield they are missing. Additionally, Earth Shield
    			can consume charges 1.0 sec faster. (Choice node with [[spell:1217622]])
- Talents being moved elsewhere or removed:
  		
  
  - Several talents have changed positions in the talent tree.
  - [[spell:51490]] is now a base ability learned by all Elemental Shamans at level 30.
  - [[spell:305483]] is now a PvP talent.
  - [[spell:108270]] has been removed.
  - [[spell:108285]] has been removed.
  - [[spell:381819]] has been removed.
  - [[spell:383011]] has been removed.
  - [[spell:383012]] has been removed.
  - [[spell:108285]] has been removed.
- Modified talents:
  		
  
  - [[spell:57994]] interrupt duration increased to 4 seconds (was 2 seconds),
    does not affect PvP combat.
  - [[spell:1064]] cast time is now 2 seconds (was 2.5), jump range is now 20 yards (was 15).
  - [[spell:383013]] is now a choice talent against [[spell:8143]]
  - [[spell:355630]] renamed to [[spell:355630]] and redesigned —
    			Interrupting a spell with [[spell:57994]] reduces all spell damage
    			taken by 15% for 12 seconds
  - [[spell:382215]] is now a 2-point talent — Increases your
    movement speed by 3%/6% and the movement speed bonus of [[spell:2645]] by an
    additional 5%/10%.
  - [[spell:381655]] is now a 2-point talent, increasing Nature
    			critical strike chance by 2% per rank.
  - [[spell:198103]] now lasts 30 seconds (was 1 minute) and has
    			a 3 minute cooldown (was 5 minutes).
  - [[spell:381689]] is now a 2-point talent — Stamina
    			increased by 8/15%. While you are at full health, [[spell:20608]]
    			cools down 50%/100% fater.
  - [[spell:30884]] healing increased to 40% of maximum life (from 20%).
  - [[spell:381650]] now reduces Magic damage taken by 8% (was 6%).
  - [[spell:265046]] is now a 2-point talent — Reduces
    			the cooldown of [[spell:192058]] by 8 seconds/15 seconds.
  - [[spell:462762]] has been redesigned - Now increases the cooldown
    			of [[spell:196840]] by 15 seconds and causes Frost Shock to freeze
    			its target in place for 4 seconds.
  - [[spell:381867]] reduces the cooldown of most totems by 5
    			seconds (was 6), no longer works on [[spell:192077]] or [[spell:355580]].
  - [[spell:1279819]] has been redesigned – Your [[spell:198103]]
    			no longer taunts nearby enemies or generates threat and instead increases 
    			your maximum health by 15% while active. Earth Elemental no longer increases
    			the maximum health of the Shaman. This effect has been moved to Primordial Bond.

With all the talents being removed without any being added, our class tree becomes
quite small, and while we already had enough points to get everything we wanted in any raid,
you now can get pretty much all you could need for dungeons and even PvP and should
not need to change your class tree much aside from choice nodes.

[[spell:355630]] is in most cases a welcome survivability buff although it
not stacking anymore does mean we are not unkillable on certain packs anymore.
The [[spell:198103]] changes are fairly neutral overall though in practice
are probably a slight buff on most encounters, though it does not make up for the
loss of [[spell:108270]].

The new [[spell:1217622]] is quite good and will allow ourselves and
a designated ally to get significant free healing over a raid encounter or a dungeon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_lavaburst.jpg>) Click for More Detailed Patch Notes
2.9.

#### Elemental Spec Tree Changes

Elemental damage gain from Mastery reduced by 10%.

- New talents being added:
  		
  
  - **Apex talent:**[[spell:1270061]] — Elemental
    			Overload damage	increased by 35%.
  - **Apex talent:**[[spell:1270062]] — Spell critical
    strike chance increased by 5%/10%. [[spell:60188]] increases spell critical
    strike damage by an additional 25%/50%.
  - **Apex talent:**[[spell:1270064]] — Elemental
    			Overloads have a 25% chance to cause an additional Elemental Overload.
    			This can only occur once per cast.
  - [[spell:1273485]] — [[spell:51505]] damage increased 
    			by 5%. Lava Burst and Lava Burst Overload generate 1 additional Maelstrom.
  - [[spell:1258899]] — [[spell:8042]], [[spell:117014]],
    and [[spell:61882]] deal 20% additional damage. Choice against [[spell:273221]].
  - [[spell:1258843]] — [[spell:51505]] deals 15% additional
    			damage. Choice against [[spell:16166]]
  - [[spell:1258895]] — All Elemental damage increased
    by 3%. Choice against [[spell:462742]].
  - [[spell:1258889]] — Increases the effect of [[spell:1258895]],
    by 2%, increases the chance for Thunderstrikes to occur by 30%, and increases Thunderstrike
    damage by 75%.
  - [[spell:1259047]] — [[spell:188196]], [[spell:454009]],
    [[spell:188443]], [[spell:8042]], [[spell:117014]] and [[spell:61882]]
    deal 15% increased damage to targets affected by [[spell:188389]].
  - [[spell:470057]] — Instantly Shocks the target and 5
    enemies within 10 yards with blazing thunder, applying [[spell:188389]] and dealing
    significant Nature damage. Always critically strikes. Replaces Flame Shock.
  - [[spell:1259471]] — [[spell:470057]] unleashed volcanic
    rage, causing your next [[spell:51505]] cast to hit all [[spell:188389]]ed targets
    at 80% effectiveness with reduced Maelstrom generation. Lava Burst damage increased by 10%.
  - [[spell:378255]] — [[spell:114050]] summons
    			your [[spell:198067]] when used.
  - [[spell:1269215]] — [[spell:470057]]'s cooldown
    is reduced by 3 seconds/6 seconds and its Nature damage is increased by 50%/100%.
  - [[spell:1269364]] — Intellect increased by 3%.
  - [[spell:1269360]] — Haste increased by 3%.
  - [[spell:381784]] — [[spell:188389]]
    			damage increased by 100%.
- Talents being removed
  		
  
  - [[spell:384087]]
  - [[spell:198067]] no longer exists as a talent and now 
    			only appears when pressing [[spell:114050]] when using the 
    			[[spell:378255]] talent
  - [[spell:378270]]
  - [[spell:192222]]
  - [[spell:375982]]
  - [[spell:210714]]
  - [[spell:192249]]
  - [[spell:468574]]
  - [[spell:382042]]
  - [[spell:378271]]
  - [[spell:381776]]
  - [[spell:381932]]
  - [[spell:462865]]
- Modified talents:
  		
  
  - Several talents have changed positions in the talent tree.
  - [[spell:318038]] now replaces [[spell:382027]] and
    does not exist anymore without the talent, preventing new elementals from using
    the old base ability when it did nothing for Elemental.
  - [[spell:462695]] has been redesigned — Now reduces the
    cast time of [[spell:188196]], [[spell:454009]] and [[spell:188443]]
    by 15%.
  - [[spell:114050]] now increases the damage of Elemental
    	Overloads by 75% while Ascendance is active (was 150%). Remains 25% in PvP combat.
  - [[spell:462840]] has been updated — Consuming [[spell:191861]]
    additionally fires an [[spell:117014]] at your target at 40% effectiveness.
  - [[spell:462866]] now increases damage dealt by 6% (was 10%).
  - [[spell:191861]]'s chance to trigger was reduced
    			to 15% (was 60%).
  - [[spell:61882]] now does Nature damage (was Physical).
  - [[spell:191717]] now summons a Greater Storm Elemental
    			(was a Greater Lightning Elemental).
  - [[spell:468571]] has been redesigned — Now reduces
    			the cooldown of [[spell:191634]] by 15 seconds.
  - [[spell:188389]] application logic has been updated for [[spell:470057]]
    to prioritize enemy players and ignore enemies in breakable crowd control.
  - [[spell:382032]] now increases Elemental Overload damage by 25% (was 40%).
  - Primal [[spell:192249]]’s [[spell:269005]] now deals its full damage over 4 seconds (was 8 seconds).
  - [[spell:198067]]’s [[spell:319836]] damage increased by 500%.
  - Primal [[spell:198067]]’s [[spell:118297]] damage increased by 500%.
  - Primal [[spell:198067]] [[spell:117588]] damage increased by 300%.
  - [[spell:192249]] [[spell:157331]] damage increased by 100%.
  - [[spell:192249]] [[spell:157348]] damage increased by 100%.
  - Primal [[spell:192249]]’s [[spell:269005]] damage increased by ​100%.
  - Fixed an issue causing [[spell:191717]] to not summon a Primal
    			[[spell:192249]] with [[spell:117013]] talented.
  - [[spell:117013]] now only grants direct control over your
    			Primal [[spell:198067]] (was all 3 elementals).
  - Removed the activation overlays that appear when you have enough
    Maelstrom to cast [[spell:8042]], [[spell:117014]], or [[spell:61882]].
  - A sound now plays when [[spell:273221]] refunds Maelstrom.

The obvious immediate consequences of these changes are that you have a lot fewer
buttons and the complexity of the rotation has been gutted. While it may sound
good to new players, alts or people who generally prefer simpler rotations, people who
enjoy current elemental will likely be disappointed. In single-target we are back
to [[spell:188196]], [[spell:51505]], a spender and [[spell:188389]]
and that is it.

Our damage profile will be much flatter with the removal of [[spell:378270]],
 a significant nerf to [[spell:114050]] and losing [[spell:192249]].

2.10.

#### Hero Talent Changes

- New talents being added:
  		
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:1264691]] — Nature damage is increased by 2%
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:1264688]] — [[spell:114050]]
    upgrades your next [[spell:188196]] to [[spell:454009]]
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:1264762]] — [[spell:192249]]
    			lasts 2 seconds longer and [[spell:191634]] generates 10 Maelstrom.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:1270446]] — Your Intellect
    			is increased by 1% for each Ancestor active.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:1270447]] — The cast times of
    			[[spell:8004]], [[spell:1064]] and [[spell:51505]]
    are reduced by 10%.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:1270450]] — For 8 seconds
    after casting [[spell:443454]], increases the chance for [[spell:77756]]
    to occur by 20%.
- Modified Talents:
  		
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:454009]] no longer triggers based on
    			total Maelstrom spent and now has a 0.3% chance to occur per Maelstrom spent.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:455129]] has been redesigned —
    Now increases the chance to gain [[spell:454009]] by an additional 0.3% per Maelstrom spent.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:454026]] has been redesigned —
    Now reduces the cooldown of [[spell:191634]] by 15 seconds.
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer: [[spell:470532]] has been redesigned —
    Now causes [[spell:454009]] to grant a stack of [[spell:191634]].
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:467646]] has been updated —
    [[spell:191634]] calls an Ancestor to your side for 8 seconds (was
     6 seconds and [[spell:375982]])
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:443445]] can now also trigger
    			from [[spell:188389]] and [[spell:470057]].
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:443418]] increases [[spell:51505]]
    			damage by 10% (was 20%).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: [[spell:443451]] now reduces the
    cooldown of [[spell:191634]] by 3 seconds when an Ancestor is called
    (was reduces the cooldown of [[spell:198067]]/[[spell:192249]]
    by 5 seconds).
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer: Ancestors now last 8 seconds (was 6 seconds).

These ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer changes are mainly targeted at dropping the necessity (or at least the feeling
of it) of tracking many different Stormbringer related procs and resources. This
achieves that goal, at the cost of significantly increasing the RNG involved, although
adjusting the old [[spell:454026]] effect into instead making [[spell:454009]]
grant a charge of [[spell:191634]] will feel nice. The loss of [[spell:470532]]'s
original damage increase will significantly lower the power of the Hero tree unfortunately.
Notably, the changes and loss of the TWW tier will lead to far fewer Tempest procs and
generally "chain" procs, making the spec more manageable but less exciting.

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer change is inevitable following the removal of [[spell:375982]],
with another source of ancestors being added to [[spell:443445]] to
 make up for [[spell:191634]]'s cooldown being higher. The other changes
 seem to further solidify Farseer as being focused on single-target and 2-3 targets cleave.

:::

3.

### Basics of Elemental Shaman Gameplay

Elemental Shaman is a spec with simple fundamentals for both single-target
and AoE, with a wide array of customization available from your talents. Some
talents allow for Elemental to be very easy to play or very complex and
rewarding.

Most of your time in single-target will be spent casting [[spell:51505]] and
[[spell:188196]], while maintaining [[spell:188389]] and casting [[spell:8042]]
or [[spell:117014]] once you have enough Maelstrom. Beyond these fundamentals,
gameplay largely depends on your talent choices. With this in mind, the specialization will 
still boil down to these three main concepts.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_lightning.jpg>) **ABC: Always Be Casting**  
  
    This is the bread and butter of most casters but is particularly true for Elemental. 
    Hesitating is always bad. When in doubt, press something, do not just stand there. 
    Unlike other specializations, there is no mistake you can do that risk crippling
    your damage. This also means you should always be ABLE to cast. Make sure you 
    stay within range and regularly move so you are in the best position to keep 
    pumping damage spells.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritwalkersgrace.jpg>) **Use Your Cooldowns**  
   
    Do not sit on [[spell:114050]] or [[spell:191634]] for long. 
    When in doubt, use them! This goes for non-damage cooldowns as well. You need to move? 
    Press [[spell:79206]]. You are going to take damage? Press [[spell:108271]]! 
    One of the biggest mistakes new Elementals make is underusing their cooldowns.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_flameshock.jpg>) **Keep Flame Shock Up and Maelstrom Down!**  
  
    In single-target in particular, you should always have [[spell:188389]] up
    on your target as it enables [[spell:51505]] to automatically crit. If you have 
    [[spell:470057]], press it whenever available in almost all circumstances. 
    Conversely, make sure you spend your Maelstrom by casting spenders, it can be 
    very easy to "overcap" and lose a lot of damage by not paying attention!

4.

### How to Gear Up as a Elemental Shaman

While we always recommend simming yourself for ideal results, we do provide a
dedicated Elemental gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5, added Ascendant Venomstone section, updated BiS with Ki'thix items.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **02 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated Raid-only BiS list helmet catalyst source to Nek'Zali.
- **26 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated best weapon enchant to Rite of the Hash'ey.
- **26 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated best weapon enchant to Rite of the Hash'ey.
- **19 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated crafting advice following hotfixes, updated trinket section.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added warning about not crafting the offhand with Hunter's Ritual Stone early, rephrased Great Vault FAQ.
- **17 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated recommended gems to maximize the value of Power Everong Diamond.
- **17 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 2, added cheatsheet of recommended utility talents for each dungeon.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated BiS and recommended crafted gear with crafted offhand with Hunter's Ritual Stone.
- **11 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated recommended gems.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Patch 12.1, added "core ideas" bullet points.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added Sporefused items to Best in Slots lists, Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Added Omnium Folio section.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 May 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated Purge/Cleanse macro.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **10 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated crafting section adding a paragraph about the Novice Combatant's Necklace.
- **07 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated trinket section.
- **03 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Rephrased the sentence on Elemental Blast on 4+ targets to make it clearer you want to have at least one Buff from it at all times.
- **01 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated crafting options with Crafted Legs, Belt or Boots.
- **01 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated recommended enchant to Eyes of the Eagle.
- **28 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Put correct link to the recommended Weapon Enchant.
- **28 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated talentts used in the Farseer Raid build.
- **24 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Removed unnecesssary line from 4+ target rotation.
- **23 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added more trinkets and updated trinket rankings.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Removed mention of Teas as they were hotfixed not to work in instances anymore, added personal food recommendation.
- **23 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Added additional information for each dungeon about specific uses for utility spells, updated utility cheatsheet.
- **23 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation advice on Stormkeeper so people do not delay it for too long.
- **21 Mar. 2026 (this page):** Updated with latest balance tuning.
- **20 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated Farseer Raid build, recommended it against Lightblinded Vanguard in The Voidspire.
- **20 Mar. 2026 (this page):** Updated Performance Overview due to underperformance in raid encounters.
- **19 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated trinket rankings and BiS, added Forgotten Farstrider's Insignia.
- **19 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Swapped in Charged Conduit instead of Storm Infusion for raid talents due to preponderance of cleave and target swapping.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Recommended second craft changed to Legs. Added mention of the equivalent two-handed Mace craft as alternative to the Staff.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Split AoE section into 3 and 4+ targets for better readability. Adjusted a things in AoE rotation. Put Stormbringer as Default check.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed multitarget opener to show Voltaic Blaze when Purging Flames is checked, not VB. Clarified/adjusted a sentence in 3/4+t rotation sections.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Added additional links to general leveling information and Heirlooms, reviewed for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated and reorganized for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Midnight Launch.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added a mention of the Teas Cooking Items giving Speed buffs that stack with Well Fed from stat food, adjusted weapon enchant and gem recommendation.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1, Added Season 1 image block.
- **04 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Removed part of a sentence that was mostly meaningful for the Midnight pre-patch.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Reorganized and updated for Midnight launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Added ability to copy entire macros with one click. Updated for Midnight launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Midnight launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Midnight launch.
- **26 Feb. 2026 (this page):** Reorganized and updated for Midnight launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated Talent tree for changes to class-gate unlock.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Midnight pre-patch. Added section on useful leveling gear for Midnight.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Adjusted section on weapon oils.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed inverted conditional switches for Voltaic Blaze and Master of the Elements.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated Talent trees for changes to class-gate unlock.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Midnight pre-patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated Talent tree for changes to class-gate unlock.
- **10 Feb. 2026 (this page):** Fixed inverted class and spec changes image block titles.
- **22 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated raiding build for the new short duration fights in the Midnight pre-patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Midnight pre-patch. Added section on leveling consumables.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Midnight pre-patch.
- **19 Jan. 2026 (this page):** Updated for Midnight pre-patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5, added FAQ blocks.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7, added FAQ blocks.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7, added FAQ blocks.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7, revamped Strength and Weaknesses into Performance Review.
- **27 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated cartel chip section to say you only need to do a +12 of the specific dungeon you want the item from. Removed jewelry mention.
- **06 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fixed High Nerubian Signet origin, it is from Dawnbreaker and not Ara-kara.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated recommended crafts and embellishment, added Puzzling Cartel Chips section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5, added sections on Legion Remix and Turbo Mode.
- **18 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Fixed a copypaste error in talents that showed raid build with tier still using Primal Elementalist over Liquid Magma totem and the Ancient Fellowship hero talent instead of Latent Wisdom.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Removed disclaimer about the page being built around not having any tier.
- **02 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated recommendations to assume new tier set.
- **02 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Changed build to a "universal" Farseer setup, more sensible with new tier.
- **20 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added to Multitarget rotation a Primordial Wave use without LMT, and maintaining a Flame Shock on 3 targets or fewer.
- **17 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated to reflect the fact that Voidglass weapons do not grant shields to Elemental after a hotfix. Consequently knocked Diamantine Voidcore down a tier for M+.
- **15 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Added a sentence regarding the Farseer 2-piece bonus favoring Versatility.
- **15 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated recommendation on Farseer M+ build.
- **15 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated recommendation on Farseer M+ build.
- **14 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Further updated trinket rankings.
- **14 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Added a choice of WeakAura packages as well as Stormbringer specific WeakAuras and an optional one for Fusion. Fixed Ancestral Swiftness macro being doubled up.
- **12 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated Trinket rankings following latest hotfixes.
- **12 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Added more dungeons tips.
- **12 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Simplified Chain Lightning use in 2 target situations for SB (was a wash).
- **10 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Fixed Farseer M+ build not using Earth Shock.
- **10 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Optimized Storm Elemental use in single-target, Flame Shock / Liquid Magma Totem use.
- **10 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Fixed Farseer M+ build not using Earth Shock.
- **09 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Swapped recommended Cloak Fiber to Mastery to avoid misleading people into specifically targeting Versatility.
- **08 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added some more trinkets to our rankings and reordered a couple.
- **07 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated Ancestral Swiftness macro section.
- **05 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fixed "immediate power option for early m+ focused players" recommendation to be a dagger and not a staff.
- **05 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Added an explanation on Haste / Versatility volatility.
- **05 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Following APL optimizations, updated Frost Shock and Earthquake use.
- **05 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Fixed a typo on the Raid talent reccommendation: you drop Primal Elementalist for Liquid Magma Totem with the new 4-piece, not 2-piece.
- **05 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Removed Tempest Macro as it is sometimes buggy and a bad habit. Updated stat priority.
- **05 Aug. 2025 (this page):** Adjusted some commentary on Frost Shock and Earthquake use following to APL improvements.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2. and Season 3.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated and reviewed for Patch 11.2. Removed Tempest/CL macro (unreliable and suboptimal).
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated and reviewed for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated and reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated and reviewed for Patch 11.2 and Season 3.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated and Reviewed for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated and reviewed for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated and reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Added mention that this section is meant for people with no Tier set. Reviewed for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **08 Jul. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated "DISC" Belt section and added best default option on the BiS lists.
- **08 Jul. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Repaired the Farseer Raid build which had a broken tree.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added a new section about the new "DISC" Belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added section on the new Combat Assistant system.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Added section on the new Combat Assistant system.
- **15 Jun. 2025 (this page):** Updated with information on Patch 11.1.7.
- **27 May 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Swapped Power of the Maelstrom for Liquid Magma Totem on Mythic One-Armed Bandit and Gallywix.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated section on Puzzling Cartel Chips.
- **25 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated section on Puzzling Cartel Chips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted BiS trinkets, added section on Counterfeit Dealer's Chips.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added Corruption Enchant section for Horrific Visions.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Removed Earthquake use in single-target builds using both Elemental Blast and Echoes of Great Sundering.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Added an image block, Farseer mention, Primordial Wave option on the single-target rotation. Picked Earthgrab Totem instead of Jet Stream.
- **21 Apr. 2025 (this page):** Updated and reviewed for Patch 11.1.5.
- **29 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted Overall BiS ring and trinket.
- **29 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Re-added Elemental Blast talent choice line that was munched by mistake.
- **29 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed a typo that broke a line, adjusted conditions for Fusion of the Element usage in AoE.
- **29 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Re-added Elemental Blast talent choice line that was munched by mistake for the Stormbringer build. Added a Liquid Magma Totem option for Farseer builds. Added a mention of Stix Bunkjunker as a boss where Stormbringer can be used.
- **18 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated Brewterializer macro to be more reliable.
- **18 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Adjusted some talent choices, defensive uses for Gallywix, added a Stormbringer build option for Stix.
- **18 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Changed default check to Farseer.
- **07 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated Cyrce's Circlet information, added tier set upgrade recommendation.
- **07 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Added Tempest + Chain Lightning macro for Stormbringer users.
- **07 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated recommendations to be less focused on pure single-target.
- **07 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Updated Chrome King Gallywix recommendations.
- **07 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed some oversights, clarified several options/situations.
- **07 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Rephrased commentary on the possibility of using Erupting Lava.
- **07 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Added a recommended macro.
- **03 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated with a more universal build.
- **01 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Added additional recommended utilities for several dungeons.
- **01 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** More precision regarding mandatory/optional talent. Added Echoes of Great Sundering to M+ Farseer build.
- **01 Mar. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Added a few more abbreviations that are in use, updated Arc Discharge description.
- **01 Mar. 2025 (this page):** Updated Tier Set section following changes.
- **28 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted trinket rankings.
- **27 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Adjusted recommended War Mode Talents.
- **27 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added One-handed weapon and Shield options. Added more information regarding Synergistic Brewterializer.
- **27 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added specific information when fighting exactly 2 targets, added many conditionals for proper Icefury use in AoE.
- **25 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted Trinket ranking. Added Catalyst as a source for Tier pieces.
- **25 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Added detail for more builds.
- **25 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **25 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed a few issues with the rotation/opener conditionals.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Fully updated and reviewed for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Added Time Spiral "abuse" macro. Reviewed for Patch 11.1.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated and reviewed for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 2.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated and reviewed for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated and reviewed for Patch 11.1.
- **20 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fully updated for Patch 11.1 and Season 2.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated section on Cyrcle's Circlet, added it to all BiS lists.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added a section on Cyrce's Circlet and added it to BiS list.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Adjusted recommended talent builds after more Farseer practice.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Added "Recommended" tags.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated and reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated and reviewed for Patch 11.0.7.
- **26 Nov. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Adjusted recommended talent builds due to Farseer buffs (Farseer now recommended on pure single-target.)
- **26 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Adjusted Farseer rotation following November 26th buffs.
- **26 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for November 26th Farseer buffs, Farseer is now recommended for single-target encounters.
- **26 Nov. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for November 26th hotfixes.
- **26 Nov. 2024 (this page):** Updated for November 26th Farseer buffs.
- **23 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed redundant Tempest line in single-target rotation.
- **04 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Rephrased sentence about double Tempest use in single-target.
- **02 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed an accidentally duplicated line in multi-target opener.
- **31 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Put Tempest higher in ST priority. Added more detailed Flame Shock use for some builds.
- **31 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Re-added a dedicated Delve build. Adjusted Farseer build. Added a dedicated pure single-target build.
- **30 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for recent Elemental adjustments, fixed some typos.
- **29 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed some Earth Shock and Elemental Blast lines. Fixed EoGS-related lines in the multi-target rotation.
- **26 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Emphasized how important having ANY Spymaster's Web trinket is.
- **26 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Adjusted recommended talent builds.
- **26 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Put openers and rotations in an image block, Added rotation switches for Farseer/Stormbringer, Elemental Blast/Earth Shock, Surge of Power, Echoes of Great Sundering, Primordial Wave and Liquid Magma Totem.
- **26 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Adjusted some wording on flexible talents section.
- **25 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fully updated Mythic+ only BiS list. Added more alternatives.
- **25 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added notes for Farseer users. Adjusted rotations to better stack cooldowns to optimize Ascendance. Optimized double Tempest usage in single-target.
- **25 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Adjusted Farseer build to Erupting Lava variant, added "Smooth Brain" easy Mythic+ build.
- **23 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated Unbound Changeling recommendation to use different stats. Added Treacherous Transmitter to S tier for people without Spymaster's Web. Added a warning on using Gale of Shadows without Primordial Wave.
- **23 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Replaced Stormrider's Fury with Stonebound Artistry as a weapon enchant option.
- **23 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added regular Flame Shock option to single-target priority list. Added Lava Burst to consume Primordial Wave to priority lists. Clarified Icefury line in single-target priority list.
- **23 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Small talent adjustments. Replaced Eye of the Storm by Swelling Maelstrom in Universal build. Added alternative build not using Primordial Wave.
- **22 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated and reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated and reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **01 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added neck, ring and weapon embellishment alternatives on the overall BiS list.
- **01 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Adjusted some dungeon-specific talent recommendations.
- **23 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Added additional tips for Queen Ansurek.
- **23 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Adjusted a line in the multi-target lightning rotation to be clearer. Added a Farseer-specific line.
- **16 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added more detailed information on crafting and embellishments. Adjusted trinket recommendations, added more trinkets. Adjusted Mythic+ only Shoulder recommendation.
- **16 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Adjusted some talent recommendations. Adjusted some tips for Queen Ansurek and other bosses.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Removed Pre-Season BiS list.
- **13 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Added some tips for Queen Ansurek.
- **10 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added additional weapon enchant options.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Reorganized the page, added 3 different BiS lists, updated for The War Within Season 1, adjusted embellishment recommendations.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Removed unnecessary macros, added Ancestral Swiftness macros.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Adjusted Blasphemite, cloak enchant, bracer enchant recommendation. Rephrased a sentence to be clearer.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated some wording, removed unnecessary sentence.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Fully updated and reorganized the page, added multiple builds with their purpose, specific dungeon builds and information, additional ability and affix recommendations.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Removed mentions of "hybrid" builds.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Added a Farseer Lightning M+ build, reordered talent builds and adjusted recommendations, removed mentions of Hybrid builds.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Slight adjustement to the recommended Talent Tree.
- **09 Sep. 2024 (this page):** Updated for The War Within Season 1.
- **06 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Removed a sentence that should not be necessary anymore.
- **30 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted BiS list to clarify stats on Helm and that Sacbrood is our best trinket. Adjusted trinket and embellishment recommendations.
- **30 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Fixed Lightning ST hero talents using Routine Communication instead of Heed my Call.
- **30 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Fixed talent recommendation, accidentally had the wrong Elemental there.
- **28 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated embellishment and trinket recommendations.
- **28 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Adjusted Delve and AoE/M+ build, added explanation on Elemental Equilibrium versus Magma Chamber.
- **25 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Added a dedicated Delve build.
- **23 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Rephrased a line in the Lightning ST rotation that was less clear than intended.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Slight adjustment to Lightning ST Opener.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated with recommended Hero Talent tree.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for The War Within's Pre-Season.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Added cancelaura macros, added Liquid Magma Totem to the @cursor macros.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Split stat priorities between builds. Added some words to make the relative value of stats clearer.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reorganized the page with image blocks for openers and rotations.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated talent builds, added a redirect to pages giving information on Hero Talents.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated with Hero Talent abilities.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated with Lightning Build and Farseer Hero Talent.
- **21 Aug. 2024 (this page):** Reorganized and consolidated the changes to Elemental. Updated Viability section and strength/weaknesses
- **19 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated with some preliminary information.
- **14 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated single-target Lightning rotation.
- **14 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Added Single-Target Lightning talents.
- **12 Aug. 2024 ([The War Within](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** Updated for Patch 11.0.2.
- **12 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.2 with new Hybrid Mythic+ build.
- **12 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.2, added rotations for the new Hybrid Mythic+ build.
- **12 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.2, added a Hybrid Mythic+ build.
- **12 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Patch 11.0.2.
- **12 Aug. 2024 (this page):** Updated for Patch 11.0.2.
- **23 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** Added tags to section 2.3, updated core changes section to reflect undocumented hotfixes.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/elemental-shaman-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated Leveling Tree + adjusted one talent choice.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Added a variety of helpful macros, removed a couple that are becoming obsolete.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Fixed a typo in the Gust of Wind/Spirit Walk macro.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Adjusted rotation following undocumented hotfixes.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Fixed some talent tree bugs, fixed information on a couple talents.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for the Shaman rework.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Fixed some talent tree bugs, updated stat priority.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Added tags to section 2.3, updated core changes section to reflect undocumented hotfixes.
- **20 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **17 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** Added breakdown and immediate playstyle changes from the Shaman rework.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** Page added.
- **15 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/elemental-shaman-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **30 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted trinket recommendations.
- **29 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added Vakash to Bullion section.
- **23 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added Sizzling Seafood Medley as an option.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added a section on Antiquated Bronze Bullions, updated all BiS sections, Tier Set, Crafting, Gear Upgrade, Weapons, Trinkets, Jewelry and Embellishment sections.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **17 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **17 Mar. 2024 (this page):** Updated for Patch 10.2.6
- **05 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated Fire Builds AoE priority.
- **06 Feb. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Fixed an oversight.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5
- **25 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Put Legguards of Sansok Khan in overall BiS. Adjusted Trinket recommendations, added disclaimer regarding Balefire Branch. Reworded Lariat's description, fixed Mythic+ BiS list origins and removed a couple items that are not in the season 3 version of the dungeon.
- **25 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added Helm enchant and Tiered Medallion Setting as a reminder. Added an unlikely case use of using Hissing Rune, reworded a couple sentences regarding Decayology Flasks.
- **22 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added Witherrot Tome to embellishment recommendation.
- **11 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Adjusted general trinket recommendations. Adjustments to embellishment recommendations.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fixed bis, crafting and embellishment recommendation after Sporecloak got nerfed into oblivion.
- **07 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed a couple missing lines from the T31 action priority lists.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Removed Dawn of the Infinite and Onyx annulet sections, added an additional paragraph regarding secondary stats, added a section on crafting priority, overhauled embellishment section, updated all BiS lists for 10.2 and added an additional disclaimer, updated weapon, jewelry and trinket sections for 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added a disclaimer about mastery caps. Updated with new optimal enchants and gems, added enchant options, added some occasionally useful special potions, updated phial section, mentioned the reusable augment rune.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated with the new stat priority for 10.2 builds.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated with 10.2 builds, put Fire on top as it is most relevant with T31.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added new sections emphasizing the recommended action priority lists for T31-recommended builds. Added T31 section, removed T29 section.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated with 10.2 builds, emphasizing T31 recommended builds.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated with 10.2 spell and talent changes.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 (this page):** Added 10.2 changes, removed 10.1.7 changes, updated Strength and Weaknesses sections.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Re-added rotation tool, added PvP talents.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Removed Cataclysm Timewalking section, added BiS gear lists, added Bloodmallet trinket sims.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed default checked talents to assume T30 raid talent recommendation.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated the page with new templates.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Added PvP hotfixes and note that there are no Elemental changes in 10.1.7.
- **12 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added an additional bit to the single-target rotation for lightning builds that do not use Windspeaker's Lava Resurgence.
- **11 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Fixed some links that still led to season 1 pages.
- **11 Jul. 2023 (this page):** Reworded some sentences to clarify the mana changes, fixed a number typo.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added Dawn of the Infinite section, and added relevant items to the Weapons/Trinkets sections. Removed a warning about trinket hotfixes.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Removed Earth Elemental from the single-target priority list.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated wording on Brimming With Life's recommendation.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated Nature's Guidance and Brimming with Life with 10.1.5 changes. Updated utility and healing spells with their new base mana cost.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5. Removed Pending changes section. Added patch 10.1.5 changes. Updated viability section.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fixed a couple BiS weapon recommendation, added temporary recommendation for Timewalking trinkets, updated some trinket rankings.
- **24 May 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed some typos, adjusted 4PC opener.
- **12 May 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Adjusted recommended phial.
- **10 May 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Some adjustments to multi-target rotation.
- **09 May 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Fixed swapped out ring descriptions, added a reminder about Alchemical Flavor Pocket, updated trinket list to reflect recent changes
- **09 May 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Small fix to Lava Burst usage in single-target for some fire builds.
- **06 May 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated recommended weapons and trinkets following the latest changes. Removed outdated paragraph on the Eranog ring. Updated Onyx annulet section to recommend it for fresh characters.
- **06 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Added some more advice regarding talent/build choice.
- **06 May 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Removed an outdated sentence, added a specific recommendation for Wildfire use and advice regarding whether you want to pick Elemental Blast or not.
- **02 May 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Modified a setting to make things clearer for people leveling from 60.
- **02 May 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated recommended embellishments and trinkets, added recommendation on what to craft first, updated which tier piece to skip.
- **02 May 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Added Deviously Deviled Eggs to the food recommendation and a warning about Fated Fortune Cookies.
- **02 May 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Simplified into two main builds, added commentary.
- **02 May 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated Stormkeeper setups with Surge of Power and description of 4PT30 usage.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated section about Onyx Annulets and added information on its viability in Season 2, added a section on Gear Upgrades in Season 2, updated the recommended trinkets and weapons list and the jewelry and embellishment sections. Updated the Tier Set Section with the T30 set.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated with T30 recommendations, updated Onyx Annulet section.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Patch 10.1 and added priorities for builds using the T30 tier set.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Removed mentions of non-Season-2 affixes. Added tips on how to deal with the 3 new Season 2 affixes, adjusted default talent recommendations. Adjusted some wording.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added default checkmarks to indicate the most likely default build people will use, added 2 openers, one for people with 2P T30 without 4P and one for people with 4P T30.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Removed the Swelling Waves, Control of Lava and Spectral Recovery PvP talents, added the Volcanic Surge and Burrow PvP talents. Updated the default talent recommendations with T30. Updated commentary on talents and reordered them to align with the reworked class talent tree.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated the description of Power of the Maelstrom, Earthgrab Totem to reflect the 10.1 changes.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Changed some wording.
- **01 May 2023 (this page):** Updated for Patch 10.1.
- **27 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated the Primordial Gems section.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** updated the Primordial Gems section following new hotfixes.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated the Primordial Stone Gems section following a last minute buff on the gems.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for the class talent overhaul of Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/elemental-shaman-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added a section about Onyx Annulets.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated recommended phial for M+ and added a warning on gem socketing with Elemental Lariat, added a section on Primordial Stone Gems.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7 changes. .
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated many talents descriptions for the Patch 10.0.7 changes.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated talent tree for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated trinket section, updated info on Voidmender's Shadowgem.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated commentary on Mana Spring (Totem).
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated Mana Spring and Totemic Surge descriptions for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated for patch 10.0.5.
- **05 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Overhauled several parts of the single-target priority list to be more precise, fixed a couple of oversights.
- **29 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated embellishment section.
- **21 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated trinket & jewelry sections.
- **21 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated Runes not stacking with Improved Flametongue Weapon anymore.
- **21 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added dedicated lines for Lava Surge and Windspeaker's Lava Resurgence. Adjusted a couple other lines.
- **15 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Removed a duplicate line from the multi-target rotation.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Added a couple trinkets to the trinket section, updated the section about Elemental Lariat.
- **13 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added checkboxes to the opener section.
- **13 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated Electrified Shocks blurb.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1 launch.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for week 3. Added a note on Tiered Medallion Settings.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Adjusted recommended fire build for dungeons for more AoE burst.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Small fix to multitarget rotation.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Adjusted some wording on multitarget rotation.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Adjusted recommended fire build for dungeons for more AoE burst.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **18 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated with a new build order. People who want to know in advance where to go from level 60 to 70 can now see my recommendations.
- **18 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated with a disclaimer on the new fire builds.
- **18 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated a few things, removed unnecessary export strings, removed a fire build embedded calculator to lessen clutter.
- **18 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated with a new build.
- **07 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Talent pick order in calculator should be fixed. .
- **07 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Added Lightning Bolt with Surge of Power to multi-target rotation (2 targets only).
- **03 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Further fixes to several talent toggle issues, modification in the Master of the Elements section.
- **02 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Fixed a variety of issues, mostly with talent toggles, improved several lists, added some information on build viability.
- **31 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Removed the obsolete Harden Skin macro, updated a couple others to be more useful.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/elemental-shaman-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/elemental-shaman-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/elemental-shaman-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **07 Mar. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-2-changes-analysis>)):** Removed mentions of the now defunct "machine gun" build.
- **19 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-2-changes-analysis>)):** Updated for the latest PTR changes.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** Removed PTR mentions, all 9.1 changes are now live.
- **03 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** Updated with 9.1 live information.
- **25 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviwed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviwed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviwed for the release of Patch 8.3 and no changes are necessary.
- **15 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-the-eternal-palace-raid-guide>)):** Filled guide with boss by boss recommendations.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-the-eternal-palace-raid-guide>)):** Guide added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **31 Jan. 2019 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** Updated talent recommendations.
- **31 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated talent recommendations, added a couple more tips.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor advice for Elemental Shaman.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** Updated talent recommendations for 8.1 changes.
- **31 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** Added Uldir guide.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** Added placeholder page for now.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Elemental Shaman leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Shaman leveling guide](<https://www.icy-veins.com/wow/shaman-leveling-guide>).

1.

### Elemental Shaman Leveling Guide for Midnight

Elemental Shaman is excellent at questing when your cooldowns 
are up, much less so when they are not. Generally, you will be slower than many 
other specs at pure questing leveling because your raw burst, multidotting, or ability 
to reliably pull half a zone is not as good as many other specializations. That
being said, with smart cooldown use, you can pull just about anything, especially
when your trusty [[spell:198103]] and [[spell:2825]]/[[spell:32182]] 
are available. In a way, this favors taking breaks, appreciating the new zones, 
and reading quest text and not speedrunning as fast as possible, which is what we would recommend!

Elemental Shaman is well suited to dungeons as well, with their
wide toolkit allowing them to help get any group out of almost any bad situation
and their AoE damage being extra powerful when using a dedicated dungeon build.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level but two secondary stats on it
instead of one.

If you are using Heirloom items, we recommend using those with Mastery
and Haste, as they will slightly improve the gameplay flow while leveling.

1.2.

#### Useful Leveling Consumables in Midnight

There are several consumable items that can be
purchased that will help you with your leveling speed.

- Ideally you want to have useful flasks buffing you at all times, you can buy 
  various level-appropriate ones for cheap. [[item:191348]] (from level 61) 
  needs refreshing often but gives Speed, which is typically more useful than
  combat stats for leveling. If you prefer combat stats, you can use flasks such 
  as [[item:212277]] from level 71, or [[item:212283]] 
  since it gives you slightly more secondaries overall.
- Food buffs are not as good if only because you need to waste time to eat, but 
  it can still be useful, particularly when you have to wait for an NPC or for a mob 
  to spawn. [[item:172063]] or [[item:133576]] will give you speed after 
  killing an enemy.
- Healing potions will help minimize downtime by allowing you to play more aggressively 
  without having to heal yourself as much. Use level-appropriate ones, such as [[item:244835]] 
  from level 71.
- The [[item:60854]] toy can be used to retrieve loot from a nearby corpse.
- [[item:109076]] is very useful for covering long distances from
  high places.
- [[item:132516]] are an Engineering item that increase your movement
  speed by 200% for 25 seconds. These will make you almost as fast as a Flying
  mount. We recommend having a lot of these, and using them whenever you are
  traveling more than ~250 yards.

The Gunshoes will not let you stop moving as long
as they are active. Using this macro twice will click the buff off and allow
you to stop.

```wow-macro
#showtooltip
/use Gunshoes
/cancelaura Gunshoes
```

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Elemental Level 80 Midnight Leveling
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMGzMLLLjxMMAAAAgNzsADYAzCTgZBAmtZmZMz2yMhZmF2MzMjZYWmxywMzMLAADAMzYYYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMGzMLLLjxMMAAAAgNzsADYAzCTgZBAmtZmZMz2yMhZmF2MzMjZYWmxywMzMLAADAMzYYYA"
}
```
:::

:::details 来源计算器编码
```
#GE-BHQakm046OFEUidbLsFogxsinHhxiSpgUJk-DIc0EI8AyE4YxCjDOhknZGJRWlAq66EB-AAAA-GQcABYgQhhSDzC-
```

:::

2.1.

#### War Mode Talents for Leveling

If you are willing to take the risk and
utilize War Mode, the following PvP talents are recommended during leveling
or for other open-world content. There may be times when you would like
to use other options and are encouraged to experiment! PvP talents can
be freely changed at any time.

Your first PvP talent slot will unlock at Level
20, your second at Level 30, and the final at Level 40. The following is a curated
list of PvP talents that we consider good for leveling.

- <em>Level 20:</em> [[spell:1217092]] or [[spell:305483]]
- <em>Level 30:</em> [[spell:305483]] or [[spell:1217092]]
- <em>Level 40:</em>[[spell:204331]] or [[spell:409293]], depending
  on personal preference.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

Remember to keep the following buffs up at all times!

- **等级 9 起：**[[spell:192106]]**等级 27 起：**,
   mostly important after talenting [[spell:462862]].
- **等级 16 起：**[[spell:462854]]
- **等级 38 起：**[[spell:974]]
- **等级 49 起：**[[spell:318038]]

Use the following spells in this order of priority.

1. **等级 19 起：**Cast [[spell:191634]] whenever it is available.
2. **等级 74 起：**Use [[spell:443454]] whenever available.
3. **等级 3 起：**Cast [[spell:188389]] when engaging enemies**等级 55 起：**
   , with [[spell:470057]] when it is available..
4. **等级 51 起：**Cast [[spell:114050]] whenever you need the burst.
5. **等级 1 起：**Cast [[spell:51505]] whenever it is available.
6. **等级 10 起：**Cast [[spell:8042]]/[[spell:117014]]**等级 23 起：**
   or [[spell:61882]] if multiple enemies will be hit by for its whole duration.
7. **等级 1 起：**Cast [[spell:188196]]**等级 10 起：**
   or [[spell:188443]] if multiple enemies will be hit by it.
8. **等级 3 起：**Cast [[spell:188389]] when you need to move, and the 
   enemy will live for a while yet.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Added additional links to general leveling information and Heirlooms, reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated Talent tree for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **27 Feb. 2025:** Adjusted recommended War Mode Talents.
- **24 Feb. 2025:** Fully updated and reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated and reviewed for Patch 11.0.7.
- **22 Oct. 2024:** Updated and reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated with recommended Hero Talent tree.
- **23 Jul. 2024:** Updated Leveling Tree + adjusted one talent choice.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **06 Feb. 2024:** Fixed an oversight.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Re-added rotation tool, added PvP talents.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **02 May 2023:** Modified a setting to make things clearer for people leveling from 60.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for the class talent overhaul of Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Updated with a new build order. People who want to know in advance where to go from level 60 to 70 can now see my recommendations.
- **07 Nov. 2022:** Talent pick order in calculator should be fixed. .
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Elemental Shaman in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Elemental Shaman

**This section is intended for players who are new to the game or class**,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Elemental is a specific specialization that can easily adapt
to most situations comfortably. The amount of keybinds required to play this 
specialization effectively is relatively low, making it a great choice for less 
seasoned players. This section will focus on a setup that is universally strong
 and should function adequately in every situation. Minimizing the number of
buttons and reactivity was the original goal of this page, but with the Shaman 
rework, it is unfortunately very difficult to drop active abilities without 
severely compromising your overall damage output.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_lightning.jpg>) **ABC: Always Be Casting**  
  
    This is the bread and butter of most casters but is particularly true for Elemental. 
    Hesitating is always bad. When in doubt, press something, do not just stand there. 
    Unlike other specializations, there is no mistake you can do that risk crippling
    your damage. This also means you should always be ABLE to cast. Make sure you 
    stay within range and regularly move so you are in the best position to keep 
    pumping damage spells.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritwalkersgrace.jpg>) **Use Your Cooldowns**  
   
    Do not sit on [[spell:114050]] or [[spell:191634]] for long. 
    When in doubt, use them! This goes for non-damage cooldowns as well. You need to move? 
    Press [[spell:79206]]. You are going to take damage? Press [[spell:108271]]! 
    One of the biggest mistakes new Elementals make is underusing their cooldowns.
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_flameshock.jpg>) **Keep Flame Shock Up and Maelstrom Down!**  
  
    In single-target in particular, you should always have [[spell:188389]] up
    on your target as it enables [[spell:51505]] to automatically crit. If you have 
    [[spell:470057]], press it whenever available in almost all circumstances. 
    Conversely, make sure you spend your Maelstrom by casting spenders, it can be 
    very easy to "overcap" and lose a lot of damage by not paying attention!

2.

### Beginner's Guide to Elemental Shaman in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Elemental Shaman

Once you are comfortable with the playstyle, we recommend you switch from [[spell:8042]] 
to [[spell:117014]], which is notably more damage if you can handle the loss 
of mobility.

Be sure to use the 'Export Talents' button to import our build in game!

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAgtZmZMz2yMhZmNWmZmZMDzyMWMzwMLDAYAgZGDDD"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzrqG352WIjBRJwFkpZJ-DIc0EI8EyEYxiDSvvrzMOjMKGJAWmRlA-AAAA-GeEJAgBRDziQhC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer   Multi-Target Talents

2.2.

#### Multi-Target Talents

For Delves, swap to [[spell:462791]] and drop [[spell:1279819]] for
 [[spell:192058]].

Once you are comfortable with the playstyle, we recommend you switch from [[spell:8042]] 
to [[spell:117014]], which is notably more damage if you can handle the loss 
of mobility.

Be sure to use the 'Export Talents' button to import our build in game!

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAgtZmZMz2yMhZmNWmZmZMDzyMjZmxMzCAwAAzMGGGA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzrqG352WIjBRJwFkpJZ-DECIc0A5x0WBpjTPwxlsPLjokSAVddi-AAAA-GeEJAgBRDziQhC-
```

:::

### Elemental Shaman   Basic Rotation

2.3.

#### Single Target Rotation

1. Cast [[spell:191634]]
2. Cast [[spell:114050]], sync it with on-use trinkets, [[spell:2825]], [[item:241308]]
3. Cast [[spell:443454]]
4. Keep [[spell:188389]]
5. Cast [[spell:8042]]
6. Cast [[spell:51505]]
7. Cast [[spell:188196]]

2.4.

#### Multi-Target Rotation

1. Cast [[spell:191634]]
2. Cast [[spell:443454]]
3. Cast [[spell:470057]]
4. Cast [[spell:467263]], sync it with on-use trinkets, [[spell:2825]], [[item:241308]]
5. Cast [[spell:61882]]
6. Cast [[spell:188443]]

2.4.1.

##### Apex Talent: ![Feedback Loop Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_shaman_primordialwave.jpg>) Feedback Loop

Elemental Shaman's Apex Talents, while powerful, have no effect on their gameplay,
they simply provide a large passive damage increase.

2.4.2.

##### Season 2 Tier Set

While The Midnight Season 2-Set Bonus [[spell:1296625]] has 
no effect on our rotation, the 4-Set-Bonus [[spell:1296626]] 
wants us to ideally keep track of the 2 different buffs. In practice however, we 
recommend you simply use a spender as soon as possible after [[spell:191634]] 
or [[spell:114050]] fades so you do not waste the spender buff or Maelstrom.

### Elemental Shaman   Stat Priority

2.5.

#### Stat Priority for Elemental Shaman Build

You will want to follow the stat priority presented below 
for general use. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>).

- Mastery
- Haste = Critical Strike
- Versatility

### Blizzard   Combat Assistant

2.6.

#### Should I Use The Combat Assistant Feature?

For basic information on how this new feature works, please visit our [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) guide.

Keep in mind, this tool has very limited uses as a new Elemental player.

We recommend against using the Single-button Rotation feature except maybe if 
you have never played Elemental at all and are off-speccing it for the first time, 
or are using a level boosted Shaman. In those cases only, it can initially help giving 
you an idea of the "rhythm" of how Elemental plays, but the built-in GCD penalty 
is a massive DPS loss. Beyond those basics relying on that button will prevent 
you from learning how to actually play the specialization, and your damage will be 
lower.

The Button Highlight feature does not incur a built-in GCD penalty, and is a 
more reasonable in-between, especially as a fresh Elemental practicing on target 
dummies or in trivial content. That being said, it is also worse than doing 
a "proper" rotation, as it will regularly give you bad advice. Finally, it requires 
you to stare at your action bar and lose focus on your combat environment, which can 
lead to many mistakes.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1, added "core ideas" bullet points.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated Talent tree for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Sep. 2025:** Removed disclaimer about the page being built around not having any tier.
- **02 Sep. 2025:** Changed build to a "universal" Farseer setup, more sensible with new tier.
- **05 Aug. 2025:** Removed Tempest Macro as it is sometimes buggy and a bad habit. Updated stat priority.
- **04 Aug. 2025:** Added mention that this section is meant for people with no Tier set. Reviewed for Patch 11.2.
- **15 Jun. 2025:** Added section on the new Combat Assistant system.
- **21 Apr. 2025:** Added an image block, Farseer mention, Primordial Wave option on the single-target rotation. Picked Earthgrab Totem instead of Jet Stream.
- **07 Mar. 2025:** Added a recommended macro.
- **03 Mar. 2025:** Updated with a more universal build.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Slight adjustement to the recommended Talent Tree.
- **30 Aug. 2024:** Fixed talent recommendation, accidentally had the wrong Elemental there.
- **21 Aug. 2024:** Updated with Lightning Build and Farseer Hero Talent.
- **23 Jul. 2024:** Fixed some talent tree bugs, updated stat priority.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Changed some wording.
- **20 Mar. 2023:** Updated talent tree for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Updated with a new build.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Elemental Shaman in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Elemental Shaman

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer is the uncontested Hero Talent for Elemental in Season 2,
 with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer generally lagging behind for pure single-target and AoE, 
 although it is still usable in general. Our current recommendations are as follows:

- **Raid -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer on everything. It is simply performing much better
    than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer.
- **Mythic+ -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer is generally ahead, particularly at 
    lower key levels and when doing smaller pulls. If you are doing relatively easy 
    content, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is perfectly fine, it will just almost always
    do less damage, unless there is a lot of mass AoE.

Note that our class trees purposefully ignore some utility talents, such as [[spell:370]].
You should adjust this recommendation depending on what utility will be needed in
each encounter. There is a reasonable amount of flexibility in our class tree,
you can and should adapt your utility toolkit to the content you intend on doing.

**Quick Start Import Codes:**

:::talents Elemental Single Target - Farseer
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzsxyMzMjZwyMWMzwMLDAYAgZGDDD"
}
```
:::

:::talents Elemental Mythic+ - Farseer
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMjFLzMmZGzMLAADAMzYYYA"
}
```
:::

:::talents Elemental Delves - Farseer
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzYsYmZGzYxyMjZmxMzCAwAAzMGGGA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Farseer

Raid

recommended

Mythic+

recommended

Delves

recommended

Stormbringer

Raid Alternative

Mythic+ Alternative

### 天赋方案 0-0

1.1.

#### Raid ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Talents

This ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer build offers significantly more single-target and
sustained AoE damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer, and is also easier to play.

**It is much more damage to play [[spell:117014]], but the mobility
loss is significant. You should use it if you can, but if you are having more
success and fun with [[spell:8042]], it is "only" a ~5% loss at most.**

### 天赋方案 0-1

1.2.

#### Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Talents

This is our recommended build for Mythic+. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer offers significantly
more reliable damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer across the board, and is also easier
to play optimally.

### 天赋方案 0-2

1.3.

#### Delve Talent Build

This build leans into solo play, leaving out [[spell:1279819]] so our [[spell:198103]]
can tank for us, and increasing our self-healing with [[spell:5394]],
while picking up [[spell:192058]] and [[spell:57994]] to control your enemies.
Note that you can play a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer if you prefer, particularly if you
are confident in your abilities and knowledge, and are ready to chain-pull.

Some general information on Delves can be found here: [Delves](<https://www.icy-veins.com/wow/delves-guide>)

### 天赋方案 1-0

1.4.

#### Raid ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Talents

This is an alternative build for Raiding if you want to play ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer,
but it is notably behind ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer builds.

### 天赋方案 1-1

1.5.

#### Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Talents

This is an alternative build for Mythic+ if you prefer playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer,
but it is notably behind ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer builds.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzsxyMzMjZwyMWMzwMLDAYAgZGDDD"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKARJwEmsq-DFCIc0A55UBpjTPwxlsPLjokSAXmMKcA-AAAA-GeEJAgBRDziQhC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMjFLzMLDzMzsAAMAwMjhhB"
}
```
:::

:::details 来源计算器编码
```
#GE-BHQakm046OFEUShZbLsFowyzbkJhxiSpgZVB-DJe0EI8Ay0G4YxiDOhknZGJRWlAq66EB-AAAA-GScEpBQgQhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzYsYmZGzYxyMjZmxMzCAwAAzMGGGA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKg1IiSgJM-DFCIc0A5x0WBpjTPwxlsPLjokSAVddi-AAAA-GeEJAgBRDziQhC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMzMzMLbLDMmZAAAAAwmZMsBLwMM0YDAsNzMjZ2WmJMzsxyMzMjZYWmxiZGmZBAYAMzADDD"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKRJwEmsqk-DFCIc0Apg0xpH44S2nlRUSJAOaPZUwQA-AAAA-VOMaYWAiIEQcoA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMzYMLWmhZMzAAAAAgNzYYDWgZYoxGAMbzMzYmtlZCzMbsMzMzYGsMjFzMjZWAAGAzMwwwA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKARJwEmsq-DFCIc0Apg0xpH44S2nlRUSJAOahSYIV-AAAA-VOMaYWAiIEQcoA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a mechanic introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>) 
which gives you a few choices of small boosts. Some are offensive, some are defensive.
 Overall, they are fairly weak.

We recommend the following choices. You are not locked into any option and can 
freely swap at any time so do not worry about making a mistake:

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279609]]
- [[spell:1279614]]

3.

### Apex Talent: ![Feedback Loop Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_shaman_primordialwave.jpg>) Feedback Loop

Midnight introduces "Apex" talents, which are a change-up compared to 
regular talents by providing multiple different bonuses depending on how many points you
allocate in them. Elemental Shamans gain [[spell:1270061]], which while being 
a powerful damage increase has no influence your gameplay in any way.
You simply gain slightly more Maelstrom, and Mastery becomes more valuable. 
For the most part, Feedback Loop is just a "do more damage" alent, but since the
bonuses are tuned very high, they are absolutely mandatory picks in every circumstance.

- **Apex talent:**[[spell:1270061]] — Elemental
  Overload damage	increased by 35%.
- **Apex talent:**[[spell:1270062]] — Spell critical
  strike chance increased by 5%/10%. [[spell:60188]] increases spell critical
  strike damage by an additional 25%/50%.
- **Apex talent:**[[spell:1270064]] — Elemental
  Overloads have a 25% chance to cause an additional Elemental Overload.
  This can only occur once per cast.

4.

### Hero Talents

Upon reaching Level 71 on any specialization, players will gain access to one 
of two unique talent trees called Hero Talents. Elemental Shaman has the choice 
between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer's  appeal is its ease of use thanks to significantly better 
mobility and less rotational complexity. It is also significantly ahead of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer 
on most content, so unless you favor the Stormbringer playstyle, you should stick to 
Farseer in all content.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is more complex, less mobile, and does less damage across 
the board. Only play it if you enjoy the playstyle more.

:::details FAQWhich [[spell:61882]] Talent Should I Pick?
Unless you really hate placing

[[spell:61882]]

even with a cursor macro,
the "area-targeted" version is generally superior, though it does take more work.
We would recommend using the @cursor Macro from our

[Macros & Addons section](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)

.

:::

:::details FAQShould I Play the Fire or Lightning Build ?
All Elemental builds now mix Elements, although it is still possible to ignore
fire abilities in some builds in AoE.

:::

5.

### PvP Talents (War Mode)

In the open world, you can go into "War Mode."
Enabling War Mode provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

Keep in mind that turning this on you will make yourself available for open-world PvP,
and the possibility to be "ganked" while leveling or doing World Quests
exists.

In this section, we will rank the PvP talents best for leveling and doing
solo or small-group PvE content. Below is a ranking of Elemental Shaman-specific
PvP talents to aid in PvE.

1. [[spell:1217092]] reduces the cooldown of [[spell:108271]], [[spell:192063]], 
   [[spell:57994]] and Nature Totems by 1 second every time you cast [[spell:188196]] 
   or [[spell:188443]]. It also reduces the time you are interrupted by 30% when 
   casting those two spells.
2. [[spell:305483]] is a channeled ability that grips the target in lightning, 
   stunning it and dealing moderate Nature damage over 5 seconds while the lasso lasts. 
   It also lets you move while channeling.
3. [[spell:204331]] replicates and reflects damage you take for
   15 seconds on a 40-second cooldown. This can be really strong when in a high-damage
   area to deal some chip damage to targets around you and convert your
   health pool into additional damage.
4. [[spell:409293]] Burrow beneath the ground, becoming un-attackable, removing
   movement-impairing effects, and increasing your movement speed by 50% for 5 seconds.
   When the effect ends, enemies within 6 yards are knocked into the air and take 
   a moderate amount of Physical Damage. This ability has a 2-minute cooldown.
5. [[spell:460697]] increases the critical effect of spells of allies
   within 40 yards by 15% for 15 seconds after casting [[spell:191634]]. Good for solo play
   and excellent if you are doing outdoor content with others.
6. [[spell:355580]] summons a totem at a target location that creates
   a circle of terrain that enemies cannot move through. It is extremely handy,
   versatile crowd control with a 1-minute cooldown.
7. [[spell:193876]] transforms [[spell:2825]]/[[spell:32182]] into a weaker,
   shorter duration cooldown that is up every minute. It lasts 10 seconds and, only
   increases Haste by 20%, and does not apply Sated/Exhaustion. It is certainly an
   okay choice, but I much prefer the stronger, rarer cooldown.
8. [[spell:204336]] can be handy in PvE but is mostly strong in PvP-exclusive
   activities.
9. [[spell:206642]] is mostly useful against players and requires talenting and 
   binding either [[spell:370]] or [[spell:378773]]. Only take this if you are 
   actively heading into PvP.

We recommend choosing [[spell:1217092]], [[spell:204331]], 
and [[spell:305483]] or [[spell:409293]] by default, but ultimately 
it's your choice in what you value the most.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Omnium Folio section.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **28 Mar. 2026:** Updated talentts used in the Farseer Raid build.
- **20 Mar. 2026:** Updated Farseer Raid build, recommended it against Lightblinded Vanguard in The Voidspire.
- **19 Mar. 2026:** Swapped in Charged Conduit instead of Storm Infusion for raid talents due to preponderance of cleave and target swapping.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **04 Mar. 2026:** Removed part of a sentence that was mostly meaningful for the Midnight pre-patch.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **22 Jan. 2026:** Updated raiding build for the new short duration fights in the Midnight pre-patch.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, added FAQ blocks.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **18 Sep. 2025:** Fixed a copypaste error in talents that showed raid build with tier still using Primal Elementalist over Liquid Magma totem and the Ancient Fellowship hero talent instead of Latent Wisdom.
- **02 Sep. 2025:** Updated recommendations to assume new tier set.
- **15 Aug. 2025:** Updated recommendation on Farseer M+ build.
- **10 Aug. 2025:** Fixed Farseer M+ build not using Earth Shock.
- **05 Aug. 2025:** Fixed a typo on the Raid talent reccommendation: you drop Primal Elementalist for Liquid Magma Totem with the new 4-piece, not 2-piece.
- **04 Aug. 2025:** Updated and reviewed for Patch 11.2.
- **08 Jul. 2025:** Repaired the Farseer Raid build which had a broken tree.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **29 Mar. 2025:** Re-added Elemental Blast talent choice line that was munched by mistake for the Stormbringer build. Added a Liquid Magma Totem option for Farseer builds. Added a mention of Stix Bunkjunker as a boss where Stormbringer can be used.
- **07 Mar. 2025:** Rephrased commentary on the possibility of using Erupting Lava.
- **01 Mar. 2025:** More precision regarding mandatory/optional talent. Added Echoes of Great Sundering to M+ Farseer build.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Added "Recommended" tags.
- **26 Nov. 2024:** Updated for November 26th Farseer buffs, Farseer is now recommended for single-target encounters.
- **31 Oct. 2024:** Re-added a dedicated Delve build. Adjusted Farseer build. Added a dedicated pure single-target build.
- **26 Oct. 2024:** Adjusted some wording on flexible talents section.
- **25 Oct. 2024:** Adjusted Farseer build to Erupting Lava variant, added "Smooth Brain" easy Mythic+ build.
- **23 Oct. 2024:** Small talent adjustments. Replaced Eye of the Storm by Swelling Maelstrom in Universal build. Added alternative build not using Primordial Wave.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Added a Farseer Lightning M+ build, reordered talent builds and adjusted recommendations, removed mentions of Hybrid builds.
- **30 Aug. 2024:** Fixed Lightning ST hero talents using Routine Communication instead of Heed my Call.
- **28 Aug. 2024:** Adjusted Delve and AoE/M+ build, added explanation on Elemental Equilibrium versus Magma Chamber.
- **25 Aug. 2024:** Added a dedicated Delve build.
- **21 Aug. 2024:** Updated talent builds, added a redirect to pages giving information on Hero Talents.
- **14 Aug. 2024:** Added Single-Target Lightning talents.
- **12 Aug. 2024:** Updated for Patch 11.0.2, added a Hybrid Mythic+ build.
- **23 Jul. 2024:** Fixed some talent tree bugs, fixed information on a couple talents.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated with 10.2 builds, emphasizing T31 recommended builds.
- **04 Sep. 2023:** Updated the page with new templates.
- **10 Jul. 2023:** Updated wording on Brimming With Life's recommendation.
- **06 May 2023:** Removed an outdated sentence, added a specific recommendation for Wildfire use and advice regarding whether you want to pick Elemental Blast or not.
- **01 May 2023:** Removed the Swelling Waves, Control of Lava and Spectral Recovery PvP talents, added the Volcanic Surge and Burrow PvP talents. Updated the default talent recommendations with T30. Updated commentary on talents and reordered them to align with the reworked class talent tree.
- **20 Mar. 2023:** Updated for Patch 10.0.7 changes. .
- **24 Jan. 2023:** Updated commentary on Mana Spring (Totem).
- **13 Dec. 2022:** Updated Electrified Shocks blurb.
- **11 Dec. 2022:** Adjusted recommended fire build for dungeons for more AoE burst.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Updated a few things, removed unnecessary export strings, removed a fire build embedded calculator to lessen clutter.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Elemental Shaman in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Elemental Shaman Gameplay and Rotation Guide

Welcome to our Rotation page for Elemental Shaman. On this page, you will
find everything you need to know about actually playing the spec in Raiding and
Mythic+ scenarios.

The buttons below can be used to select between curated **Raiding** and
**Mythic+** loadouts. You can also use the switches below to add or remove
individual talents you may also be using.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

Raid / Single-Target (not recommended)

Mythic+ / AoE (not recommended)

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

Raid / Single-Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+ / AoE / Delve

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:8042]]

[[spell:117014]]

[[spell:470057]]

[[spell:16166]]

[[spell:1259471]]

### Openers

[[spell:191634]]

[[spell:51505]]

**适用条件：Farseer（启用）。**

[[spell:443454]]

[[spell:114050]]

[[item:241308]]

[[item:250144]]

**适用条件：Farseer（启用）。**

[[spell:188196]]

**适用条件：Stormbringer（启用）。**

[[spell:454009]]

[[spell:51505]]

1.1.

#### Single-Target Opener

1. Cast [[spell:191634]] ~3 seconds before the pull.
2. Cast [[spell:51505]] ~1.5 second before the pull so it lands right after the pull.
3. **适用条件：Farseer（启用）。** Use  [[spell:443454]].
4. Cast [[spell:114050]] with on-use trinkets and [[item:241308]].
5. **适用条件：Farseer（启用）。** Cast [[spell:188196]].
6. **适用条件：Stormbringer（启用）。** Cast [[spell:454009]].
7. Cast [[spell:51505]].
8. **适用条件：Elemental Blast（启用）。** Proceed with regular rotation. Cast [[spell:117014]] as early as possible
9. **适用条件：Earth Shock（启用）。** Proceed with regular rotation.

1.2.

#### Multi-Target Opener

1. Cast [[spell:191634]].
2. **适用条件：Farseer（启用）。** Use  [[spell:443454]].
3. **适用条件：Voltaic Blaze（启用）。** Cast [[spell:470057]]
4. Cast [[spell:114050]] with on-use trinkets and [[item:241308]].
5. **适用条件：Elemental Blast（启用）。** Proceed with regular rotation.
6. **适用条件：Earth Shock（启用）。** Proceed with regular rotation.

### Single-Target Rotation

1.3.

#### Single-Target Action Priority List / "Rotation"

1. Cast [[spell:191634]]. Hold if [[spell:114050]] will be available shortly and cast it one or two GCDs before it. You should generally not delay Stormkeeper for longer than 10 seconds.
2. **适用条件：Farseer（启用）。** Use [[spell:443454]].
3. Cast [[spell:114050]], sync it with on-use trinkets, [[spell:2825]] and [[item:241308]].
4. **适用条件：Voltaic Blaze（未启用）。** Refresh [[spell:188389]] 
   if [[spell:198067]] will fade within the next 3 seconds.
5. **适用条件：Voltaic Blaze（未启用）。** Refresh [[spell:188389]] 
   when it has 6 seconds or less remaining, use the window 
   you have to optimize your movement with this flexible instant cast.
6. **适用条件：Voltaic Blaze（启用）。** Cast [[spell:470057]] when [[spell:188389]] has 6 seconds or less remaining, use the window 
   you have to optimize your movement with this flexible instant cast.
7. **适用条件：Elemental Blast（启用）。** Cast [[spell:117014]] if you have both buffs from the 4p tier set :Flowing Elements and Overcharge!
8. **适用条件：Earth Shock（启用）。** Cast [[spell:8042]] if you have both buffs from the 4p tier set : Flowing Elements and Overcharge!
9. **适用条件：Master of the Elements（启用）。** Cast
    [[spell:51505]] if [[spell:188389]] is up and it will not cause you to overcap Maelstrom and [[spell:16166]] 
    is not up.
10. **适用条件：Master of the Elements（启用）；Stormbringer（启用）。** Cast [[spell:454009]] or [[spell:191634]]-empowered [[spell:188196]] 
    if [[spell:16166]] is up.
11. **适用条件：Earth Shock（启用）。** Cast [[spell:8042]].
12. **适用条件：Elemental Blast（启用）；Master of the Elements（未启用）。** Cast [[spell:117014]].
13. **适用条件：Elemental Blast（启用）；Master of the Elements（启用）。** Cast [[spell:117014]] if [[spell:16166]] is up or would otherwise overcap Maelstrom.
14. **适用条件：Stormbringer（启用）；Master of the Elements（未启用）。** Cast [[spell:454009]].
15. **适用条件：Farseer（启用）；Master of the Elements（未启用）。** Cast
     [[spell:51505]] if [[spell:188389]] is up.
16. **适用条件：Stormbringer（启用）；Master of the Elements（未启用）。** Cast
     [[spell:51505]] ONLY when you have [[spell:77756]]. Never "hardcast" Lava Burst.
17. **适用条件：Stormbringer（启用）。** Cast [[spell:454009]] / [[spell:188196]] as filler.
18. **适用条件：Farseer（启用）。** Cast [[spell:188196]] as filler.

### Multi-Target Rotation

1.4.

#### Multi-Target Action Priority List / "Rotation"

If you are fighting 4 or more targets:

1. Cast [[spell:191634]]. Hold if [[spell:114050]] will be available shortly and cast it one or two GCDs before it. You should generally not delay Stormkeeper for longer than 10 seconds.
2. **适用条件：Farseer（启用）。** Use [[spell:443454]].
3. **适用条件：Voltaic Blaze（启用）。** Cast [[spell:470057]] 
   on cooldown.
4. Cast [[spell:114050]], sync it with on-use trinkets, [[spell:2825]] and [[item:241308]].
5. **适用条件：Stormbringer（启用）；Elemental Blast（启用）。** If you have no Buff from [[spell:117014]] and at most 1 stack of [[spell:454009]],
    Cast [[spell:117014]] on any target without [[spell:210689]].
6. **适用条件：Stormbringer（启用）；Elemental Blast（启用）。** Cast [[spell:61882]] if you have at most 1 stack of [[spell:454009]].
7. **适用条件：Stormbringer（启用）。** If you have 2 stacks
   of [[spell:454009]] and less than 4 stacks of [[spell:191634]], 
   Cast [[spell:454009]].
8. **适用条件：Stormbringer（启用）。** Cast [[spell:188443]] 
   with [[spell:191634]] if you will not overcap on Maelstrom.
9. **适用条件：Farseer（启用）；Elemental Blast（启用）。** Cast [[spell:117014]] if no Ancestors are up and fighting at most 5 targets.
10. **适用条件：Farseer（启用）；Elemental Blast（启用）。** Cast [[spell:61882]] if any Ancestors are up OR when fighting more than 5 targets.
11. **适用条件：Earth Shock（启用）；Farseer（未启用）。** Cast [[spell:61882]].
12. **适用条件：Stormbringer（启用）。** Cast [[spell:454009]].
13. **适用条件：Purging Flames（启用）。** Cast 
    [[spell:51505]] (ideally with a [[spell:77756]] proc) to consume [[spell:1259471]].
14. Cast [[spell:188443]].
15. Use [[spell:77756]] for movement.

---

If you are fighting EXACTLY 3 targets:

1. Cast [[spell:191634]]. Hold if [[spell:114050]] will be 
   available shortly and cast it one or two GCDs before it. You should generally not 
   delay Stormkeeper for longer than 10 seconds.
2. **适用条件：Farseer（启用）。** Use [[spell:443454]].
3. **适用条件：Voltaic Blaze（启用）。** Cast [[spell:470057]] 
   on cooldown.
4. Cast [[spell:114050]], sync it with on-use trinkets, [[spell:2825]], [[item:241308]].
5. **适用条件：Master of the Elements（启用）；Voltaic Blaze（未启用）。** Keep one [[spell:188389]] up.
6. **适用条件：Stormbringer（启用）；Elemental Blast（启用）。** Cast [[spell:117014]] on any target without [[spell:210689]] if you 
     have at most 1 stack of [[spell:454009]].
7. **适用条件：Purging Flames（启用）。** Cast 
   [[spell:51505]] (ideally with a [[spell:77756]] proc) to consume [[spell:1259471]].
8. **适用条件：Stormbringer（启用）；Master of the Elements（启用）。** When 
   [[spell:77756]] is available, cast [[spell:51505]] if your next cast can be [[spell:454009]].
9. **适用条件：Stormbringer（启用）；Master of the Elements（启用）。** If [[spell:16166]] is available, cast [[spell:454009]].
10. **适用条件：Stormbringer（启用）。** If you have 2 stacks
    of [[spell:454009]] and less than 4 stacks of [[spell:191634]], 
    Cast [[spell:454009]].
11. Cast [[spell:188443]] 
    with [[spell:191634]] if you will not overcap on Maelstrom.
12. **适用条件：Farseer（启用）；Elemental Blast（启用）。** Cast [[spell:61882]] if any Ancestors are up.
13. **适用条件：Farseer（启用）；Elemental Blast（启用）。** Cast [[spell:117014]] if no Ancestors are up.
14. **适用条件：Earth Shock（启用）。** Cast [[spell:61882]].
15. **适用条件：Stormbringer（启用）；Elemental Blast（启用）。**  Cast [[spell:117014]].
16. **适用条件：Stormbringer（启用）；Elemental Blast（启用）。** Cast [[spell:454009]].
17. Cast [[spell:188443]].

---

If you are fighting EXACTLY 2 targets:

1. Cast [[spell:191634]]. Hold if [[spell:114050]] will be available shortly and cast it one or two GCDs before it. You should generally not delay Stormkeeper for longer than 10 seconds.
2. **适用条件：Farseer（启用）。** Use [[spell:443454]].
3. **适用条件：Voltaic Blaze（启用）。** Cast [[spell:470057]] 
   on cooldown.
4. Cast [[spell:114050]], sync it with on-use trinkets, [[spell:2825]] and [[item:241308]].
5. **适用条件：Voltaic Blaze（未启用）。** Refresh [[spell:188389]] on both targets
   when [[spell:198067]] will fade within the next 5 seconds.
6. **适用条件：Voltaic Blaze（未启用）。** Refresh [[spell:188389]] 
   when it has 6 seconds or less remaining, use the window 
   you have to optimize your movement with this flexible instant cast.
7. **适用条件：Master of the Elements（启用）。** Cast
    [[spell:51505]] if [[spell:188389]] is up and [[spell:16166]] 
    is not up.
8. **适用条件：Stormbringer（启用）；Master of the Elements（启用）。** Cast [[spell:454009]] or [[spell:191634]]-empowered [[spell:188196]] 
   if [[spell:16166]] is up.
9. **适用条件：Earth Shock（启用）；Farseer（启用）。** Cast [[spell:61882]] if any ancestors are up.
10. **适用条件：Earth Shock（启用）；Farseer（启用）。** Cast [[spell:8042]] if no ancestors are up.
11. **适用条件：Earth Shock（启用）；Stormbringer（启用）。** Cast [[spell:8042]].
12. **适用条件：Elemental Blast（启用）。** Cast [[spell:117014]]. If using [[spell:210689]], switch targets between each spender.
13. **适用条件：Stormbringer（启用）；Master of the Elements（未启用）。** Cast [[spell:454009]].
14. **适用条件：Stormbringer（启用）；Master of the Elements（未启用）。** Cast [[spell:191634]]-empowered [[spell:188196]].
15. **适用条件：Master of the Elements（启用）；Farseer（启用）。**  If you would otherwise expend [[spell:16166]] on an unbuffed [[spell:188196]], cast [[spell:188389]] on the 2nd target if it will live for the duration.
16. **适用条件：Farseer（启用）；Master of the Elements（未启用）。** Cast
     [[spell:51505]] if [[spell:188389]] is up.
17. **适用条件：Stormbringer（启用）；Master of the Elements（未启用）。** Cast
     [[spell:51505]] ONLY when you have [[spell:77756]]. Never "hardcast" Lava Burst.
18. Cast [[spell:188443]].

:::details FAQHow many targets should I cast Flame Shock on ?
In multi-target you will usually just use

[[spell:470057]]

on cooldown.
If you are not using this talent, you only want to keep

[[spell:188389]]

on one
target if there are at most 3 cleavable targets. The one exception is when fighting 2 targets it is a small gain to recast it on both targets after

[[spell:114050]]

ends but before

[[spell:198067]]

fades.

:::

:::details FAQHow many targets make Chain Lightning worth using over Lightning Bolt?
You should always use

[[spell:188443]]

in multi-target with one exception for

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

when there are only two cleavable targets you want to use

[[spell:188196]]

when they are empowered by

[[spell:191634]]

.

:::

:::details FAQHow many targets make Earthquake worth using over Earth Shock or Elemental Blast?
If you use a

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

build with

[[spell:8042]]

, it is a small increase to use

[[spell:61882]]

with as few as 2 stacked
targets that will live for its full duration IF any Ancestors are up at the moment of the cast.
When using

[[spell:117014]]

, it is a small gain to use it when no Ancestors are up if there are 5 targets or fewer. On 6 targets or more you stop using it entirely.
If you use a

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer

build with

[[spell:117014]]

,
 you want a minimum of FOUR targets for

[[spell:61882]]

to be worth using. and

:::

:::details FAQDo multiple Earthquakes stack ?
Yes. Each Earthquake will deal damage individually for its duration, so
stacking multiple on top of each other will deal a lot of AoE damage.

:::

2.

### Midnight Season 2 Tier Set

The 2-Set Bonus [[spell:1296625]] is straightforward:
 beefier spenders! This is both strong and nice, as Elemental's "spenders" always 
 felt like they did not quite hit hard enough. It does not alter our rotation.

The 4-Set bonus [[spell:1296626]] is a bit stranger and
 currently has several bugs or seemingly unintended issues. The damage to builders
 stacks, but not the "free" spender charges. More importantly, when using both our
 cooldowns together, as we usually do, the tier only procs when both cooldowns have 
 faded, giving 4 stacks of the builder buff.
 Generally it is very easy to waste value with the spender charge and we hope 
 Blizzard will allow for those to stack as well. [[spell:1259471]] also
 consumes multiple stacks of the builder buff at once. All that being said, 
 it is a pretty strong bonus, particularly if the above issues end up fixed.

This Set bonus makes it quite important to not waste either the builder or 
 spender stacks. The builder charges stacking to 4 makes it fairly easy to use 
 them up by playing as normal, but the spender charges can be overwritten pretty 
 easily, causing a significant damage loss. In practice, this means you should focus 
 on using up your "free" spender as soon as you get it unless you are sure it will 
 not be overwritten.

3.

### Class and Spec Mechanics Explained

We have compiled more detailed explanations on individual mechanics within our 
rotation so you can reach your full potential when playing Elemental.

### Apex Talent

3.1.

#### Apex Talent for Elemental Shaman: Feedback Loop

Midnight introduces "Apex" talents, which are a change-up compared to 
regular talents by providing multiple different bonuses depending on how many points you
allocate in them. Elemental Shamans gain [[spell:1270061]], which while being 
a powerful damage increase has no influence your gameplay in any way.
 You simply gain slightly more Maelstrom, and Mastery becomes more valuable. 
 For the most part, Feedback Loop is just a "do more damage" alent, but since the
 bonuses are tuned very high, they are absolutely mandatory picks in every circumstance.

### Maelstrom Management

3.2.

#### Maelstrom Management

You should avoid casting Maelstrom-generating spells above a certain Maelstrom
threshold that would make you go over the Maelstrom cap. Because of all the talents
and procs interacting with that threshold, it is difficult to give exact numbers
without making a detailed list that would be very impractical to use. Instead,
 we simply recommend you follow our recommended rotation priorities in order
 to never overcap. Keep this in mind when pooling Maelstrom as well. It is
 likely these spells will overload. Therefore, if you cast
[[spell:51505]] and would go over your Maelstrom cap if you gained more than 8
Maelstrom, it is likely you will overcap Maelstrom and waste valuable resources.
In practice, it is safer to cast these spells at lower Maelstrom than their limits
 to avoid wasting your overload procs. The key to success is managing all of
 your separate procs without overcapping Maelstrom too often.

Note that for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer builds in AoE, particularly when using [[spell:273221]],
 you may overcap regularly and sometimes it will be correct to cast a generator
 even when at the cap. This is one of the reasons Stormbringer is more difficult to handle.

### Flame Shock & Pandemic

3.3.

#### Lava Burst and Flame Shock/Voltaic Blaze

The reason why [[spell:188389]] should always be up on your target is
because:

- It increases most of your damage by 10% thanks to [[spell:1259047]]
- Each tick has a chance to proc [[spell:77756]], which resets the
  cooldown of [[spell:51505]]
- Your Lava Burst will always critically hit if Flame Shock is on the
  target. This is very important due to [[spell:60188]] and our multiple
  other sources of Critical Strike Damage

You should only cast [[spell:51505]] when [[spell:188389]]
is active on the target.

[[spell:188389]]/[[spell:470057]] benefits from Pandemic, meaning that you can
refresh it any time that it has less than 30% of its original maximum duration
remaining, and the remaining duration will be added to the new debuff.
Therefore, you are able to refresh Flame Shocks without wasting any duration
when it has 5 seconds or less remaining, and it will be extended by 18 seconds.
For example, if your Flame Shock has 5 seconds left and you refresh it, your new
Flame Shock would last 23 seconds. Note that these numbers are all doubled if
you have a [[spell:198067]] in play.

### Managing Movement

3.4.

#### Managing Movement for Elemental Shaman

Elemental is relatively mobile thanks to its active abilities: between [[spell:58875]]
or [[spell:192063]], [[spell:79206]], [[spell:2645]] form and its
many instant rotational spells. Outside of these however, you have few instant spells 
to adjust your positioning, making it more important to do so properly.
 Proactively position yourself to reduce potential movement from mechanics. Keep 
 careful track of boss timers and mechanics, as they can spell
 disaster for your damage if you are targeted when all your cooldowns are out.

### AoE Target Caps

3.5.

#### AoE Target Caps

- [[spell:269005]] (from [[spell:191717]] with [[spell:117013]])
   has no target limit but does reduced damage beyond 5 targets.
- [[spell:117588]] is limited to 8 targets.
- [[spell:61882]] has a soft-cap at 20 targets.
  This cap is high enough that it should rarely matter.

4.

### Important Cooldowns for Elemental Shaman

Before using each of your cooldowns, you should take special care to consider
several factors. Some of our offensive cooldowns have lengthy recharge times, but
 when correctly utilized, they can be responsible for a large percentage of our
 damage output. You should always take into account:

- Your raid's [[spell:2825]]/[[spell:32182]]/[[spell:80353]] usage.
- The mechanics of the current boss, including intermissions and abilities
  that necessitate movement.
- The spawn timers of any adds that might be present, as we may want to use
  or delay certain cooldowns with respect to cleave and AoE.

### [[spell:191634]]

4.1.

#### Stormkeeper

[[spell:191634]] is used more or less on cooldown on pure single-target encounters.

On multiple-target fights or fights with intermittent cleave and AoE, it
can be a good idea to delay your [[spell:191634]] until you are able to
[[spell:188443]] 5 targets.

### [[spell:114050]]

4.2.

#### Ascendance

Make sure you have as many things as possible lined up with [[spell:114050]]:

- [[spell:2825]]/[[spell:32182]]/[[spell:80353]].
- [[item:241308]].
- The [[spell:1259471]] buff from casting [[spell:470057]] in 
  multi-target situations.
- [[spell:191634]] cast before Ascendance preferably.
- On-use trinkets.

Before each [[spell:114050]] use, ensure no boss mechanics will interfere,
 such as intermissions, boss movement, or mechanics that will force you to move.
 It can be a good idea to use [[spell:79206]] to ensure full DPS uptime.
If using this talent, try casting [[spell:117014]] immediately before
activating Ascendance.

Do not let yourself Maelstrom cap; be sure to cast your spender when
or before your next cast would cause you to go above maximum Maelstrom.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **03 Apr. 2026:** Rephrased the sentence on Elemental Blast on 4+ targets to make it clearer you want to have at least one Buff from it at all times.
- **24 Mar. 2026:** Removed unnecesssary line from 4+ target rotation.
- **23 Mar. 2026:** Updated rotation advice on Stormkeeper so people do not delay it for too long.
- **17 Mar. 2026:** Fixed multitarget opener to show Voltaic Blaze when Purging Flames is checked, not VB. Clarified/adjusted a sentence in 3/4+t rotation sections.
- **17 Mar. 2026:** Split AoE section into 3 and 4+ targets for better readability. Adjusted a things in AoE rotation. Put Stormbringer as Default check.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight launch.
- **10 Feb. 2026:** Fixed inverted conditional switches for Voltaic Blaze and Master of the Elements.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, added FAQ blocks.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **20 Aug. 2025:** Added to Multitarget rotation a Primordial Wave use without LMT, and maintaining a Flame Shock on 3 targets or fewer.
- **12 Aug. 2025:** Simplified Chain Lightning use in 2 target situations for SB (was a wash).
- **10 Aug. 2025:** Optimized Storm Elemental use in single-target, Flame Shock / Liquid Magma Totem use.
- **05 Aug. 2025:** Following APL optimizations, updated Frost Shock and Earthquake use.
- **04 Aug. 2025:** Updated and Reviewed for Patch 11.2.
- **15 Jun. 2025:** Added section on the new Combat Assistant system.
- **21 Apr. 2025:** Removed Earthquake use in single-target builds using both Elemental Blast and Echoes of Great Sundering.
- **29 Mar. 2025:** Fixed a typo that broke a line, adjusted conditions for Fusion of the Element usage in AoE.
- **18 Mar. 2025:** Changed default check to Farseer.
- **07 Mar. 2025:** Fixed some oversights, clarified several options/situations.
- **27 Feb. 2025:** Added specific information when fighting exactly 2 targets, added many conditionals for proper Icefury use in AoE.
- **25 Feb. 2025:** Fixed a few issues with the rotation/opener conditionals.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated and reviewed for Patch 11.0.7.
- **26 Nov. 2024:** Adjusted Farseer rotation following November 26th buffs.
- **23 Nov. 2024:** Fixed redundant Tempest line in single-target rotation.
- **04 Nov. 2024:** Rephrased sentence about double Tempest use in single-target.
- **02 Nov. 2024:** Fixed an accidentally duplicated line in multi-target opener.
- **31 Oct. 2024:** Put Tempest higher in ST priority. Added more detailed Flame Shock use for some builds.
- **30 Oct. 2024:** Updated for recent Elemental adjustments, fixed some typos.
- **29 Oct. 2024:** Fixed some Earth Shock and Elemental Blast lines. Fixed EoGS-related lines in the multi-target rotation.
- **26 Oct. 2024:** Put openers and rotations in an image block, Added rotation switches for Farseer/Stormbringer, Elemental Blast/Earth Shock, Surge of Power, Echoes of Great Sundering, Primordial Wave and Liquid Magma Totem.
- **25 Oct. 2024:** Added notes for Farseer users. Adjusted rotations to better stack cooldowns to optimize Ascendance. Optimized double Tempest usage in single-target.
- **23 Oct. 2024:** Added regular Flame Shock option to single-target priority list. Added Lava Burst to consume Primordial Wave to priority lists. Clarified Icefury line in single-target priority list.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **23 Sep. 2024:** Adjusted a line in the multi-target lightning rotation to be clearer. Added a Farseer-specific line.
- **09 Sep. 2024:** Removed mentions of "hybrid" builds.
- **23 Aug. 2024:** Rephrased a line in the Lightning ST rotation that was less clear than intended.
- **22 Aug. 2024:** Slight adjustment to Lightning ST Opener.
- **21 Aug. 2024:** Reorganized the page with image blocks for openers and rotations.
- **14 Aug. 2024:** Updated single-target Lightning rotation.
- **12 Aug. 2024:** Updated for Patch 11.0.2, added rotations for the new Hybrid Mythic+ build.
- **23 Jul. 2024:** Adjusted rotation following undocumented hotfixes.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **07 Nov. 2023:** Fixed a couple missing lines from the T31 action priority lists.
- **06 Nov. 2023:** Added new sections emphasizing the recommended action priority lists for T31-recommended builds. Added T31 section, removed T29 section.
- **04 Sep. 2023:** Fixed default checked talents to assume T30 raid talent recommendation.
- **12 Jul. 2023:** Added an additional bit to the single-target rotation for lightning builds that do not use Windspeaker's Lava Resurgence.
- **10 Jul. 2023:** Removed Earth Elemental from the single-target priority list.
- **24 May 2023:** Fixed some typos, adjusted 4PC opener.
- **10 May 2023:** Some adjustments to multi-target rotation.
- **09 May 2023:** Small fix to Lava Burst usage in single-target for some fire builds.
- **02 May 2023:** Updated Stormkeeper setups with Surge of Power and description of 4PT30 usage.
- **01 May 2023:** Added default checkmarks to indicate the most likely default build people will use, added 2 openers, one for people with 2P T30 without 4P and one for people with 4P T30.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **05 Jan. 2023:** Overhauled several parts of the single-target priority list to be more precise, fixed a couple of oversights.
- **21 Dec. 2022:** Added dedicated lines for Lava Surge and Windspeaker's Lava Resurgence. Adjusted a couple other lines.
- **15 Dec. 2022:** Removed a duplicate line from the multi-target rotation.
- **13 Dec. 2022:** Added checkboxes to the opener section.
- **11 Dec. 2022:** Adjusted some wording on multitarget rotation.
- **11 Dec. 2022:** Small fix to multitarget rotation.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Updated with a disclaimer on the new fire builds.
- **07 Nov. 2022:** Added Lightning Bolt with Surge of Power to multi-target rotation (2 targets only).
- **03 Nov. 2022:** Further fixes to several talent toggle issues, modification in the Master of the Elements section.
- **02 Nov. 2022:** Fixed a variety of issues, mostly with talent toggles, improved several lists, added some information on build viability.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Elemental Shaman in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Elemental Shaman

Welcome to our Gearing Page for Elemental Shaman. This
section will cover everything you need to know about equipping your character
correctly.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup across all sources for Elemental Shaman. Remember that while this is the best possible setup, you could end up doing similar damage with very different items in practice.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, the "natural" tier piece you would want to skip are the pants, but because you want use catalyst charges on a piece with good secondaries and keep those secondaries, it will depend on what you obtain. Keep in mind you will want to use

[[item:271876]]

, because catalysts also keep cantrip effect! You do not want to use a "natural" Tier chest. This cuts both ways, you do not want to catalyze any regular armor item that has Versatility, as it would carry over to the tier piece! You ideally want to catalyse those pieces into tier, but keep in mind your secondary values will shift depending on what you already have:

- Helm: [[item:251220@JAACAAgNyA]]
- Shoulders: use the regular set item or [[item:268231@JAACAAAG2A]]
- Chest: [[item:271876@JAAEAAAj1ghN]] **This one is very important!**
- Hands: [[item:281238@JAAEAAwF0YjM]]
- Legs: [[item:268237@JAACAAAG2A]]

:::

:::details FAQWhat to Get From The Great Vault?
This season you can now get a[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) as an alternative Vault reward starting with the 2nd Vault of the season, which lets you bonus roll on any dungeon or boss, and receive a 1/6 Myth track version of the item. This is optimal for Elemental, and we HIGHLY recommend everyone does that for the first 3 weeks on Heroic  [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), setting your Loot Specialization to Restoration in order to remove the mediocre trinket from the pool, and guaranteeing 3 very powerful Best-in-Slot items. The only downside is that dropped items from Mythic will be at 9/6 Mythic , whereas bonus-rolled items cap out at 6/6, but this is not really relevant for drops from the last boss.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:281238@JAAEAAwF0YjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAj1ghNTpC]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAAEAAAj1ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list only contains items available in Mythic+ dungeons as well as the Tier set and embellished crafted items.

The main focus of this list is targetting the best pieces that have Mastery and either Critical Strike or Haste. It is not meant as an "equip all these items together" list. Remember when using [[spell:117014]] there is a soft cap at 86% Mastery.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, the "natural" tier piece you would want to skip are the pants, but because you want use catalyst charges on a piece with good secondaries and keep those secondaries, it will depend on what you obtain. Keep in mind you will want to use

[[item:271876]]

, because catalysts also keepo cantrip effect! You do not want to use a "natural" Tier chest. This cuts both ways, you do not want to catalyze any regular armor item that has Versatility, as it would carry over to the tier piece! You ideally want to catalyse those pieces into tier:

- Helm: [[item:251220@JAACAAgNyA]] or [[item:159374@JAACAAgNyA]]
- Shoulders:  [[item:239049@JAACAAgNyA]]
- Chest: [[item:273789@JAACAAgNyA]]
- Hands: [[item:160213@JAACAAgNyA]]
- Legs: [[item:159375@JAACAAgNyA]]

:::

:::details TipsWhich Dungeons Should I Farm?
We recommend you farm the following dungeon:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): has two good weapons and your best trinket options
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): has one of the best trinkets and good jewelry
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>) and [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): have some good items

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:251228@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273794@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Raid

This list only contains items from the Midnight Season 2 raids and embellished crafted items.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, the "natural" tier piece you would want to skip are the pants, but because you want use catalyst charges on a piece with good secondaries and keep those secondaries, it will depend on what you obtain. Keep in mind you will want to use

[[item:271876]]

, because catalysts also keep their cantrip effect! You do not want to use a "natural" Tier chest. This cuts both ways, you do not want to catalyze any regular armor item that has Versatility, as it would carry over to the tier piece! You ideally want to catalyse those pieces into tier:

- Helm: [[item:268230@JAACAAgNyA]]
- Shoulders: use the regular set item or [[item:268231@JAACAAAG2A]]
- Chest: [[item:271876@JAAEAAAj1ghN]]
- Hands: use the regular set item
- Legs: [[item:268237@JAACAAAG2A]]

:::

:::details TipsWhich Raid Items Do I Want Most?
If you need to submit a list of highly-important items to your raid leader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:268265@JAAEAAAj1ghN]].
- [[item:271876@JAAEAAAj1ghN]]
- [[item:281215@JAACAAAOyA]]
- [[item:270164@JAACAAgNyA]]

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:281238@JAAEAAwF0YjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAj1ghNTpC]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271486@JAAEAAAj1ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> on the item from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:240917]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Elemental Shaman

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Elemental Shaman Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Elemental Shaman</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>Any combination of the S-tier trinkets except double on-use is of similar value.</li>&#10;<li>[[item:281215@JAACAAgNyA]] : Great passive trinket, &#10;	 particularly for Mythic+ or encounters where you will target many adds.</li>&#10;<li>[[item:270164@JAACAAgNyA]] : Great passive trinket &#10;	 but somewhat RNG dependent, one of the procs even reduces our stats.</li>&#10;<li>[[item:250215@JAACAAgNyA]] : Very solid but unexciting on-use.</li>&#10;<li>[[item:270167@JAACAAgNyA]] : Very solid trinket, could be used instead of &#10;	 an on-use due to our lack of great options.</li>&#10;<li>[[item:273796@JAACAAgNyA]] : On-par with [[item:250215@JAACAAgNyA]] &#10;but the RNG aspect is unfortunate.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161@JAACAAgNyA]] shines only when killing&#10;	 stacked adds on top of a boss, potentially S tier in some circumstances.</li>&#10;<li>[[item:270170@JAACAAgNyA]] is a good Mythic+ option but otherwise &#10;	 unimpressive.</li>&#10;<li>[[item:250214@JAACAAgNyA]] is strong if you can stand in the light beam reliably, &#10;but that is such a big downside we cannot recommend using it on any difficult content.</li>&#10;<li>[[item:273649@JAACAAgNyA]] gives a lot of Haste but &#10;	 is inferior to the A-tier options in all circumstances, unless you have very &#10;     little Haste.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] is not worth the bother in most circumstances, &#10;	 though it does offer the largest burst potential when using its mostly or fully &#10;	 stacked effect and could be used when you need fewer, larger damage bursts.</li>&#10;<li>[[item:251792@JAACAAgMyA]] is your best option from Delves.</li>&#10;<li>[[item:248583@JAACAAgMyA]] if obtained at a competitive item level, make sure &#10;	   you adapt it to the secondary you need most.</li>&#10;<li>[[item:273794]] is okay, nothing special. </li>&#10;<li>[[item:245752]] is a very reasonable though &#10;		unexciting option.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]] : use it on yourself when not surrounded by allies&#10;	   to make it give a Critical Strike buff, or have at least 3 allies next to you &#10;	   to gain a Haste buff instead. The proc is strong but happens very infrequently, &#10;	   making it very unreliable.</li>&#10;<li>[[item:270168@JAACAAgNyA]] gives a good bit of burst particularly if you &#10;	 can cleave things, but it is hard to justify its massive cooldown.</li>&#10;<li>[[item:250259]] is just okay in single-target and bad&#10;	 in other circumstances. </li>&#10;<li>[[item:250224]] has an annoying downside but is a reasonable &#10;	 option.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>Every trinket not yet listed belongs into D Tier or below.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) are used to obtain items from specific bosses or dungeons,
 by letting you gain a guaranteed piece of loot from a specific drop-location. 
 You still roll within the pool available there, but the next time you use a Voidcore 
 in this location/boss on that difficulty, you will gain one of the items you did not 
 get the previous time(s).

They are obtained from the Great Vault as an alternative reward choice (NOT bought 
with tokens), and are in practice a must pick in this patch once they are available 
starting with the second Vault of the season.

**Orin Straylight** who stands near The Catalyst in Silvermoon will give you 
an extra Voidcore for free every week, starting with the launch of Patch 12.1.5.

3.1.

#### Recommended Nebulous Voidcore Usage for Elemental Shaman

You should use your bonus rolls on Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for the first 3 weeks, 
 guaranteeing you get all 3 Best-in-Slot items from the boss. **In order for those
 to be guaranteed, set your loot spec to Restoration to remove a mediocre trinket 
 from the pool.**. Similarly, you should then set your loot spec to Enhancement 
 for the best chance to coin the trinket from [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [[item:271092@JAACAAAG2A]]
2. Venomcursed items: [[item:268265@JAAEAAAj1ghN]] and [[item:271876@JAAEAAAj1ghN]]
3. [[item:281215@JAACAAAOyA]] or [[item:270164@JAACAAgNyA]]
4. Remaining BiS List items, starting Helm and Legs.

:::

3.2.

#### Ascendant Venomstones

Upgrading items with [[item:280562]] follows a similar priority 
list to using Crests:

1. Weapon
2. On-use trinket
3. Passive trinket
4. Necklace

Note that these upgrade items to a maximum of Item Level 344. If you are using 
special items such as Venomcursed items or items from the last 2 Mythic bosses, they 
cannot be further upgraded with Venomstones. Of course this also depends on what 
you have at Mythic track or not. You want to prioritize those, though your Weapon should 
remain your first upgrade no matter what.

4.

### Best Crafted Items for Elemental Shaman

What you want to craft not only depends on loot/vault RNG, but also
on your progression level and whether you want immediate power to blast now, or
want to maximize the medium/long term effectiveness of your character. In all likelihood,
you will not fail to clear a raid encounter just because you're missing
a little potential DPS on your character, you will do so because of mechanical errors.

This tier, you have many options depending on your progression level and willingness 
to sacrifice early power for long-term value. It mostly comes down to whether you 
craft a 2-handed weapon or not:

- Option 1: Short Term Power: [[item:245770@JAAIAAwt1ENMMYjlGA]] with [[item:273060]]. 
  Despite the nerf to the new Embellishment it remains very strong, and this gives you a 
  lot of immediate power, at the cost of having to replace it within weeks, and you will 
  be sad if your first coin gives you [[item:271092@JAACAAAG2A]], 
  particularly when mythic shields are particularly accessible this season from [Tidebound Grotto](<https://www.icy-veins.com/wow/midnight-world-bosses-guide>)
  and [Lost Explorers](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).
- Option 2: The Longer View: if you will not absolutely need the immediate power boost, 
  and instead aim for long-term efficiency, you should instead craft armor pieces with 
  [[item:240167]]. The best long-term option is to craft [[item:244584@JAAIAAwt1ENMMYjlGA]] 
  along with either Belt or Boots, though you could compromise and instead craft a 
  higher value slot like Legs or Helm, though that comes with its own downsides.

Note that any combination of Critical Strike / Haste / Mastery is viable depending 
on your current gear. Use simulations and recraft as needed. If you have already 
crafted something else, do not worry, the actual power difference between options 
is small and will only get smaller every week.

Eventually you may want to use [[item:245770@JAAIAAwt1ENMMYjlGA]] 
with [[item:273060]] to edge out the maximum possible dps, but it is only 
about 300 dps above using a second [[item:240167]] slot with a regular mythic 
shield, and the shield comes with its own advantages particularly outside of raids 
or if you want to play Restoration.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Elemental Crafted Gear Priority**
- Immediate Power Burst [[item:245770@JAAIAAwt1ENMMYjlGA]] **(Not the Pikestaff!)** with [[item:273060]]
- [[item:244584@JAAIAAwt1ENMMYjlGA]] and whatever armor slot you lack with [[item:240167]]

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Crest Usage

Unsurprisingly, you should sim your character to determine which upgrades give
the most bang for your buck at any point in time. Beyond that, you generally want
to maximize your weapon (and offhand), then your jewelry, and after that it is generally best
to upgrade the armor slots that give the most stats: First Chest (particularly if you have [[item:271876@JAAEAAAj1ghN]], Helm or Pants, then
Gloves, Shoulders, Boots and Belt.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Elemental Shaman Crest Upgrade Priority**
**Weapon (Mainhand)**

➜

**Offhand**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5, added Ascendant Venomstone section, updated BiS with Ki'thix items.
- **02 Oct. 2026:** Updated Raid-only BiS list helmet catalyst source to Nek'Zali.
- **26 Aug. 2026:** Updated best weapon enchant to Rite of the Hash'ey.
- **19 Aug. 2026:** Updated crafting advice following hotfixes, updated trinket section.
- **18 Aug. 2026:** Added warning about not crafting the offhand with Hunter's Ritual Stone early, rephrased Great Vault FAQ.
- **14 Aug. 2026:** Updated BiS and recommended crafted gear with crafted offhand with Hunter's Ritual Stone.
- **11 Aug. 2026:** Updated recommended gems.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Sporefused items to Best in Slots lists, Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **10 Apr. 2026:** Updated crafting section adding a paragraph about the Novice Combatant's Necklace.
- **07 Apr. 2026:** Updated trinket section.
- **01 Apr. 2026:** Updated crafting options with Crafted Legs, Belt or Boots.
- **23 Mar. 2026:** Added more trinkets and updated trinket rankings.
- **19 Mar. 2026:** Updated trinket rankings and BiS, added Forgotten Farstrider's Insignia.
- **17 Mar. 2026:** Recommended second craft changed to Legs. Added mention of the equivalent two-handed Mace craft as alternative to the Staff.
- **16 Mar. 2026:** Updated and reorganized for Midnight Season 1.
- **26 Feb. 2026:** Reorganized and updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch. Added section on useful leveling gear for Midnight.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **27 Oct. 2025:** Updated cartel chip section to say you only need to do a +12 of the specific dungeon you want the item from. Removed jewelry mention.
- **06 Oct. 2025:** Fixed High Nerubian Signet origin, it is from Dawnbreaker and not Ara-kara.
- **05 Oct. 2025:** Updated recommended crafts and embellishment, added Puzzling Cartel Chips section.
- **17 Aug. 2025:** Updated to reflect the fact that Voidglass weapons do not grant shields to Elemental after a hotfix. Consequently knocked Diamantine Voidcore down a tier for M+.
- **14 Aug. 2025:** Further updated trinket rankings.
- **12 Aug. 2025:** Updated Trinket rankings following latest hotfixes.
- **09 Aug. 2025:** Swapped recommended Cloak Fiber to Mastery to avoid misleading people into specifically targeting Versatility.
- **08 Aug. 2025:** Added some more trinkets to our rankings and reordered a couple.
- **05 Aug. 2025:** Fixed "immediate power option for early m+ focused players" recommendation to be a dagger and not a staff.
- **04 Aug. 2025:** Updated for Patch 11.2. and Season 3.
- **08 Jul. 2025:** Updated "DISC" Belt section and added best default option on the BiS lists.
- **15 Jun. 2025:** Added a new section about the new "DISC" Belt.
- **12 May 2025:** Updated section on Puzzling Cartel Chips.
- **25 Apr. 2025:** Updated section on Puzzling Cartel Chips.
- **21 Apr. 2025:** Adjusted BiS trinkets, added section on Counterfeit Dealer's Chips.
- **29 Mar. 2025:** Adjusted Overall BiS ring and trinket.
- **18 Mar. 2025:** Updated Brewterializer macro to be more reliable.
- **07 Mar. 2025:** Updated Cyrce's Circlet information, added tier set upgrade recommendation.
- **28 Feb. 2025:** Adjusted trinket rankings.
- **27 Feb. 2025:** Added One-handed weapon and Shield options. Added more information regarding Synergistic Brewterializer.
- **25 Feb. 2025:** Adjusted Trinket ranking. Added Catalyst as a source for Tier pieces.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **20 Feb. 2025:** Fully updated for Patch 11.1 and Season 2.
- **17 Dec. 2024:** Updated section on Cyrcle's Circlet, added it to all BiS lists.
- **15 Dec. 2024:** Added a section on Cyrce's Circlet and added it to BiS list.
- **26 Oct. 2024:** Emphasized how important having ANY Spymaster's Web trinket is.
- **25 Oct. 2024:** Fully updated Mythic+ only BiS list. Added more alternatives.
- **23 Oct. 2024:** Updated Unbound Changeling recommendation to use different stats. Added Treacherous Transmitter to S tier for people without Spymaster's Web. Added a warning on using Gale of Shadows without Primordial Wave.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **01 Oct. 2024:** Added neck, ring and weapon embellishment alternatives on the overall BiS list.
- **16 Sep. 2024:** Added more detailed information on crafting and embellishments. Adjusted trinket recommendations, added more trinkets. Adjusted Mythic+ only Shoulder recommendation.
- **13 Sep. 2024:** Removed Pre-Season BiS list.
- **09 Sep. 2024:** Reorganized the page, added 3 different BiS lists, updated for The War Within Season 1, adjusted embellishment recommendations.
- **30 Aug. 2024:** Adjusted BiS list to clarify stats on Helm and that Sacbrood is our best trinket. Adjusted trinket and embellishment recommendations.
- **28 Aug. 2024:** Updated embellishment and trinket recommendations.
- **21 Aug. 2024:** Updated for The War Within's Pre-Season.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **30 Apr. 2024:** Adjusted trinket recommendations.
- **29 Apr. 2024:** Added Vakash to Bullion section.
- **22 Apr. 2024:** Added a section on Antiquated Bronze Bullions, updated all BiS sections, Tier Set, Crafting, Gear Upgrade, Weapons, Trinkets, Jewelry and Embellishment sections.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **25 Nov. 2023:** Put Legguards of Sansok Khan in overall BiS. Adjusted Trinket recommendations, added disclaimer regarding Balefire Branch. Reworded Lariat's description, fixed Mythic+ BiS list origins and removed a couple items that are not in the season 3 version of the dungeon.
- **22 Nov. 2023:** Added Witherrot Tome to embellishment recommendation.
- **11 Nov. 2023:** Adjusted general trinket recommendations. Adjustments to embellishment recommendations.
- **07 Nov. 2023:** Fixed bis, crafting and embellishment recommendation after Sporecloak got nerfed into oblivion.
- **06 Nov. 2023:** Removed Dawn of the Infinite and Onyx annulet sections, added an additional paragraph regarding secondary stats, added a section on crafting priority, overhauled embellishment section, updated all BiS lists for 10.2 and added an additional disclaimer, updated weapon, jewelry and trinket sections for 10.2.
- **04 Sep. 2023:** Removed Cataclysm Timewalking section, added BiS gear lists, added Bloodmallet trinket sims.
- **10 Jul. 2023:** Added Dawn of the Infinite section, and added relevant items to the Weapons/Trinkets sections. Removed a warning about trinket hotfixes.
- **24 May 2023:** Fixed a couple BiS weapon recommendation, added temporary recommendation for Timewalking trinkets, updated some trinket rankings.
- **09 May 2023:** Fixed swapped out ring descriptions, added a reminder about Alchemical Flavor Pocket, updated trinket list to reflect recent changes
- **06 May 2023:** Updated recommended weapons and trinkets following the latest changes. Removed outdated paragraph on the Eranog ring. Updated Onyx annulet section to recommend it for fresh characters.
- **02 May 2023:** Updated recommended embellishments and trinkets, added recommendation on what to craft first, updated which tier piece to skip.
- **01 May 2023:** Updated section about Onyx Annulets and added information on its viability in Season 2, added a section on Gear Upgrades in Season 2, updated the recommended trinkets and weapons list and the jewelry and embellishment sections. Updated the Tier Set Section with the T30 set.
- **20 Mar. 2023:** Added a section about Onyx Annulets.
- **24 Jan. 2023:** Updated trinket section, updated info on Voidmender's Shadowgem.
- **29 Dec. 2022:** Updated embellishment section.
- **21 Dec. 2022:** Updated trinket & jewelry sections.
- **13 Dec. 2022:** Added a couple trinkets to the trinket section, updated the section about Elemental Lariat.
- **11 Dec. 2022:** Updated for Dragonflight Season 1 launch.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Elemental Shaman. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Elemental Shaman Stat Priority

Mastery

Haste

Critical Strike

Versatility

Intelligence is your most important stat. This
means you should most of the time equip your highest item level gear and sim
yourself from there for adjustments that will be specific to your gear.

2.

### In-Depth Stat Breakdown

**Mastery**, through [[spell:168534]], increases all your
Elemental and Physical damage done and causes some of your spells to have a
chance to deal additional damage and generate extra Maelstrom. Note that with
the [[spell:381726]] talent, your Mastery will apply to your spenders,
making Mastery more valuable.

:::details FAQIs There a Mastery Cap for Elemental Shaman?
Mastery has a hard cap when you reach 100% Mastery. When using [[spell:117014]],
you should consider a "soft" cap of 86%, as Elemental Blast could bring you to 100%.
Note that when using the Mail set Root Warden's Regalia there is a "softer" cap of 76%.

Mastery is currently highly desirable and your best overall secondary. That
being said, it is very common for people to overestimate the importance of having
the "right" secondaries when, in reality, having a higher quantity of stats will
usually beat having "better" stats. Having 150 of your worst stat is often better
than having 100 of your best stat, as the differences in value between stats are not that big.

:::

**Haste** increases the speed of your casts as well as the tick rate of
your damage-over-time effects.

:::details FAQIs There a Haste Cap for Elemental Shaman?
You want a good amount of Haste, it is your second best secondary. There is no
specific cap you want for any secondary stat. It is very common for people to
overestimate the importance of having the "right" secondaries when, in reality,
having a higher quantity of stats will usually beat having "better" stats. Having
150 of your worst stat is often better than having 100 of your best stat, as the
differences are not as big as many people think.

:::

**Critical Strike** increases the damage of your spells. Worth noting that
Elemental Shaman has multiple talents increasing their Critical Strike damage.

**Versatility** increases all damage done increase and reduces all damage
taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.5, added FAQ blocks.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **15 Aug. 2025:** Added a sentence regarding the Farseer 2-piece bonus favoring Versatility.
- **05 Aug. 2025:** Added an explanation on Haste / Versatility volatility.
- **04 Aug. 2025:** Updated and reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **07 Mar. 2025:** Updated recommendations to be less focused on pure single-target.
- **25 Feb. 2025:** Added detail for more builds.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated and reviewed for Patch 11.0.7.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated some wording, removed unnecessary sentence.
- **21 Aug. 2024:** Split stat priorities between builds. Added some words to make the relative value of stats clearer.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **05 Mar. 2024:** Updated Fire Builds AoE priority.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated with the new stat priority for 10.2 builds.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **02 May 2023:** Simplified into two main builds, added commentary.
- **01 May 2023:** Updated for Patch 10.1 and added priorities for builds using the T30 tier set.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Elemental Shaman, based on your [stat priority](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

The best stat for Elemental Shamans is Mastery, followed by Haste.
You should therefore be gemming for Mastery, unless you already have loads of Mastery
on every single gear-piece.

You should first put [[item:240967]] in one of your sockets.
Then, you should put one dual-stat gem of each color except stamina in your available 
sockets, **adapting to the secondary stats you lack the most**. By default or 
if you are unsure, we recommend slotting in:

- One [[item:240900]]
- One [[item:240908]]
- One [[item:240917]]
- Then fill all your remaining sockets with [[item:240892]]

Note that all jewelry items come with one socket, and you cannot add any more. The 
only items with 2 sockets are very rare jewelry items from raids. Tokens of Merit 
from the Vault can only add sockets to Helm/Belt/Bracers.

2.

### Best Enchants and Weapon Augments

If you are not using the [[spell:318038]] weapon imbue talent, 
you should apply [[item:243733]] on your weapon every couple of hours. 
They do not stack.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]] (Speed)</li>&#10;<li>[[item:244007]] (Avoidance)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]] (Movement Speed)</li>&#10;<li>[[item:243991]] (Avoidance)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]] (Movement Speed)</li>&#10;<li>[[item:243953]] (Avoidance)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]].</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

3.1.

#### Flask

You should be drinking a secondary stat flask: [[item:241322]] if
you lack Mastery, or [[item:241326]] if you lack Critical Strike.

3.2.

#### Potions

There are a few different potions that all provide similar DPS benefits, but we
recommend using [[item:241308]] or potentially [[item:241288]]. You should 
use them during [[spell:2825]]/[[spell:32182]] along with [[spell:114050]] 
and [[spell:191634]].

It might be worth it to use [[item:241292]], but beware of the void
zone which silences you!

You should keep a stock of [[item:271883]]s to use when at low 
health, and if you have a Warlock in the group, grab their [[item:5512]]s 
and use them as well. Do not macro these together, they are best used separately!

3.3.

#### Food Buff

You want to use [[item:255845]] or [[item:255846]] to gain 
50 Intelligence. When you need to buy personal food, use [[item:242275]] or
[[item:255847]] instead.

3.4.

#### Augmentation and Vantus Rune

When you truly think it is worth to gain just a tiny extra bit of damage, you can 
use [[item:259085]]. You should probably sell those instead for a bit
of extra gold though, unless you are raiding Cutting Edge!

When your group is struggling on a boss, you can use a [[item:245879]] 
on the boss to gain a good amount of Versatility which only works against this boss. You
can only do this once per week on one boss, but it works across difficulties, 
does not go away on death, and lasts until the weekly reset.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **26 Aug. 2026:** Updated best weapon enchant to Rite of the Hash'ey.
- **17 Aug. 2026:** Updated recommended gems to maximize the value of Power Everong Diamond.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **01 Apr. 2026:** Updated recommended enchant to Eyes of the Eagle.
- **28 Mar. 2026:** Put correct link to the recommended Weapon Enchant.
- **23 Mar. 2026:** Removed mention of Teas as they were hotfixed not to work in instances anymore, added personal food recommendation.
- **16 Mar. 2026:** Added a mention of the Teas Cooking Items giving Speed buffs that stack with Well Fed from stat food, adjusted weapon enchant and gem recommendation.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Adjusted section on weapon oils.
- **19 Jan. 2026:** Updated for Midnight pre-patch. Added section on leveling consumables.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated and reviewed for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Added Corruption Enchant section for Horrific Visions.
- **24 Feb. 2025:** Updated and reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated and reviewed for Patch 11.0.7.
- **23 Oct. 2024:** Replaced Stormrider's Fury with Stonebound Artistry as a weapon enchant option.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **10 Sep. 2024:** Added additional weapon enchant options.
- **09 Sep. 2024:** Adjusted Blasphemite, cloak enchant, bracer enchant recommendation. Rephrased a sentence to be clearer.
- **06 Sep. 2024:** Removed a sentence that should not be necessary anymore.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **23 Apr. 2024:** Added Sizzling Seafood Medley as an option.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **25 Nov. 2023:** Added Helm enchant and Tiered Medallion Setting as a reminder. Added an unlikely case use of using Hissing Rune, reworded a couple sentences regarding Decayology Flasks.
- **06 Nov. 2023:** Added a disclaimer about mastery caps. Updated with new optimal enchants and gems, added enchant options, added some occasionally useful special potions, updated phial section, mentioned the reusable augment rune.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **12 May 2023:** Adjusted recommended phial.
- **02 May 2023:** Added Deviously Deviled Eggs to the food recommendation and a warning about Fated Fortune Cookies.
- **01 May 2023:** Updated with T30 recommendations, updated Onyx Annulet section.
- **27 Mar. 2023:** Updated the Primordial Gems section.
- **23 Mar. 2023:** updated the Primordial Gems section following new hotfixes.
- **21 Mar. 2023:** Updated the Primordial Stone Gems section following a last minute buff on the gems.
- **20 Mar. 2023:** Updated recommended phial for M+ and added a warning on gem socketing with Elemental Lariat, added a section on Primordial Stone Gems.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **21 Dec. 2022:** Updated Runes not stacking with Improved Flametongue Weapon anymore.
- **11 Dec. 2022:** Updated for week 3. Added a note on Tiered Medallion Settings.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Elemental Shaman in World of Warcraft Patch 12.1.5.

1.

### Elemental Shaman in Mythic+ in Midnight Season 2

Elemental Shaman is currently an above-average ranged-DPS specialization for
Mythic+ in Midnight. It can provide strong multi-target burst and sustained
damage, as well as a lot of utility.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

First and foremost, there are multiple viable variants for Mythic+, and listing every
one here would be counterproductive. There is some room for different variants in
certain dungeons or for certain compositions or key levels.

If you are a beginner Elemental Shaman, we recommend switching to [[spell:8042]]
until you have a better understanding of both the dungeons and the spec, as with correct play,
[[spell:117014]] will end up significantly ahead, but it is much less forgiving
with movement, casting, and Maelstrom management.

2.

### Best Midnight Talent Builds

We currently have a build for each of the 2 Hero Talents. 
 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer gives you top-tier single-target and cleave damage and is very 
 straightforward to play.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer is behind across the board and is harder to play and less 
mobile.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer Mythic+ Build

2.1.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer build for Elemental Shaman

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMjFLzMLDzMzsAAMAwMjhhB"
}
```
:::

:::details 来源计算器编码
```
#GE-BHQakm046OFEUShZbLsFowyzbkJhxiSpgZVB-DJe0EI8Ay0G4YxiDOhknZGJRWlAq66EB-AAAA-GScEpBQgQhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer Mythic+ Build

2.2.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer build for Elemental Shaman

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMzYMLWmhZMzAAAAAgNzYYDWgZYoxGAMbzMzYmtlZCzMbsMzMzYGsMjFzMjZWAAGAzMwwwA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKARJwEmsq-DFCIc0Apg0xpH44S2nlRUSJAOahSYIV-AAAA-VOMaYWAiIEQcoA-
```

:::

3.

### In-Depth Rotation Tips for Mythic+

A couple additional habits you should practice in Mythic+:

- It can be a good idea to pool Maelstrom toward the end of every trash pull
   in order to reduce the ramp-up time needed to reach your maximum output on the next pull.
- Keep in mind that efficiency is important and that you should not waste
  spells that do damage over time on enemies that will die within the next few seconds. This 
  is particularly important for [[spell:61882]] casts. This, of course, also 
  goes for cooldowns. Do not waste cooldowns on packs that are about to die.
- Damage is not all there is in Mythic+, so you will often want to weave in
  crowd control abilities such as [[spell:192058]] between your highest-damaging abilities.

4.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

4.1.

#### Interrupts

[[spell:57994]] is your "kick" and your most important bit of utility in
Mythic+, used to stop enemy casts for the benefit of the group and especially
the tank. It is **highly recommended** to use a Focus Kick macro for this.

#### Focus Kick Macro

```wow-macro
#showtooltip
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Wind Shear
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

#### Focus Macro

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

4.2.

#### Stuns and "Stops"

Elemental Shamans have a large variety of "hard" crowd-control abilities available
to them, but they all work in different ways.

[[spell:61882]] will "naturally" knock enemies down from time to time, giving
you free stops, though its unpredictability makes it so you should never count on it
to reliably interrupt any cast. Think of it as a bonus.

[[spell:192058]] is delayed but reliable, and you can potentially reduce 
its cooldown by almost half with several talents, although it comes at a significant 
opportunity cost.

[[spell:51490]] will interrupt enemies and knock them away. Be very careful 
of the direction you will knock enemies towards as you may slow down your group's 
damage, worsen your crowd control or even worse, pull additional packs.

[[spell:51514]] is meant as a long-duration crowd-control but can serve as a stop
in a pinch, though it is rarely practical or efficient. You do not really have the 
points to spare unless you really want it for a particular mob.

Note that [[spell:51485]] "roots" a target but is not a "stop"; it
only prevents movement.

Technically, [[spell:198103]] with [[spell:117013]] also
will stun their target shortly after you summon it, so it can be used to interrupt an enemy 
in a pinch.

### Movement

4.3.

#### Movement

Elemental has mediocre mobility:

Few instant spells:

- We have few instant abilities in our rotation: [[spell:470057]] (or [[spell:188389]]), 
  [[spell:8042]]/[[spell:61882]], [[spell:188196]] and [[spell:188443]] buffed by [[spell:191634]].
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) Stormbringer users can use [[spell:378081]] as a reactive
  instant.

But powerful mobility tools:

- [[spell:192077]], especially boosted by [[spell:462820]] or [[spell:462791]],
  and potentially by [[spell:382201]], is a powerful ability that is useful
  for any content, having a powerful effect. Moreover, you  can extend its benefits by using
   [[spell:108287]] to reposition it!
- [[spell:79206]] not only gives you full mobility while casting for
  15 seconds (19 for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer users), it also gives you 20% movement speed
  and has fairly short cooldown thanks to [[spell:192088]] .
- [[spell:192063]] is fantastically versatile burst mobility, while our other
  choice [[spell:58875]] has a much higher cooldown but gets rid of root and snare effects.
- [[spell:2645]] form needs to be used sparingly in combat but is very useful, 
  especially due to [[spell:378075]] or potentially [[spell:260878]] in higher keys.

### Other Utility

4.4.

#### Other Utility

Shamans have an excellent toolkit that greatly benefits from being tailored
to each dungeon:

Off-healing:

- [[spell:974]], especially when also cast on your tank or a character with 
  weak self-sustain can add up to very significant healing almost for free,
   especially when paired with [[spell:1217622]].
- [[spell:8004]] is a generic fast heal that only really shines when you
  are healing yourself and have [[spell:974]] and [[spell:337974]]
  talented, but does not heal for much.
- [[spell:5394]] is one of those abilities you drop when you have
  nothing else you can do; it helps a little bit, and [[spell:462368]]
  can potentially help surviving one-shots. It is hard to justify the talent points
  for it however.

Many kinds of "opt-in" dispells Typically you should know in advance whether
 those will be needed for a particular dungeon or not, and otherwise should not 
 have them talented:

- [[spell:370]] can remove scary magic buffs on enemies, as well as help deal with
  the Ascendant Affix. Typically you should know in advance whether it will be needed 
  for a particular dungeon or not.
- [[spell:51886]] removes curses and can help deal with the Devour Affix. 
  Typically you should know in advance whether it will be needed 
  for a particular dungeon or not.
- [[spell:383013]] removes all poison effects on your entire party
  every 1.5 seconds for up to 9 seconds. When it is useful, you most likely want to have
  [[spell:382201]] as it increases its duration by 50%. Typically you should 
  know in advance whether it will be needed for a particular dungeon or not.
- [[spell:8143]] removes Charm, Fear, and Sleep effects. It is rarely useful,
  but is the best tool in the game to deal with these debuffs when they happen.

5.

### Dungeon Talent Swap Cheat Sheet

For a quick guide of which utility talents are needed in each dungeon, use
the tool below to select a dungeon. Any relevant utility talents will be
highlighted below.

<table>&#10;<tr>&#10;<th colspan="2" style="text-align: center">Dungeons</th>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;</table>

Based on the selections above, you should run the following class talents:

- **适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Murder Row（启用）；Temple of Sethraliss（启用）。** [[spell:51886]]
- **适用条件：King's Rest（启用）；Temple of Sethraliss（启用）。** [[spell:51485]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；Ruby Life Pools（启用）。** [[spell:462820]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）；Murder Row（启用）；Temple of Sethraliss（启用）；Blinding Vale（启用）；Voidscar Arena（启用）。** [[spell:383013]]
- **适用条件：Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）。** [[spell:370]]
- **适用条件：Den of Nalorakk（启用）；Blinding Vale（启用）。** [[spell:58875]]
- **适用条件：Altar of Fangs（启用）；Den of Nalorakk（启用）。** [[spell:378075]]
- **适用条件：Murder Row（启用）。** [[spell:8143]]

- **适用条件：Altar of Fangs（启用）。** 
  
  
  - Use [[spell:383013]] to dispel the [[spell:1307567]] from 
    **Ula'tek's Chosen**. Note that you can and should interrupt this cast instead when possible.
  - Use [[spell:192077]] with [[spell:462820]] to remove the [[spell:1294569]] 
    inflicted by **Twinfang Harrower**. You can also use [[spell:378075]] or 
    [[spell:58875]] to remove it from yourself.
- **适用条件：Den of Nalorakk（启用）。** 
  
  
  - Use [[spell:58875]] to get rid of [[spell:1241463]] inflicted by 
    	  **Avatar of Determination**.
  - Use [[spell:51886]] to dispel [[spell:1238801]] caused 
    		by **Spirit of Hunger**'s **Starvation Effigy**.
  - Use [[spell:383013]] to remove [[spell:1234846]] during 
    the **The Hoardmonger** boss encounter.
  - Use [[spell:370]] to remove [[spell:1297696]] used by **Earthwhisper Tender**. 
    Note that you can and should interrupt this cast instead when possible.
  - Use [[spell:192077]] with [[spell:462820]] to dispel the [[spell:1309919]] 
    		applied by **Frigid Mauler**. Note that you can and should interrupt this 
    		cast when possible. You can also use [[spell:378075]] or [[spell:58875]] 
    		to remove it from yourself.
  -
- **适用条件：King's Rest（启用）。** 
  
  
  - Use [[spell:370]] to remove the "mind control" [[spell:270920]] 
    		 caused by **Queen Wasi** in the "gauntlet" corridor before **Mchimba the Embalmer**.
  - Use [[spell:370]] to remove [[spell:270901]] cast by 
    		 **Seneschal M'bara** in the "gauntlet" corridor before **Mchimba the Embalmer**.
  - Use [[spell:51485]] to root and slow **Animated Gold** so they do 
    not reach the boss during **The Golden Serpent** boss encounter.
  - Use [[spell:51886]] to dispel [[spell:269972]] cast by 
    		 **Shadow-Borne Witch Doctor** and [[spell:270492]] cast by **Spectral Hex Priest**. 
    		 Note that both of these are casts that you can and should interrupt when possible.
- **适用条件：Murder Row（启用）。** 
  
  
  - Use [[spell:51886]] to dispel the [[spell:1217973]] cast by 
    		**Corrupted Warlock**
  - Use [[spell:383013]] to remove [[spell:474515]] 
    		during the first boss encounter against **Zaen Bladesorrow**
  - Use [[spell:8143]] to remove [[spell:1201554]] channeled by 
    		**Seductive Sayaad**. Note that this should be a last resort as it can 
    		and should be interrupted instead, and that [[spell:51490]] also stops it.
- **适用条件：Ruby Life Pools（启用）。** 
  
  
  - You can use [[spell:370]] to remove [[spell:373973]] from
    		**Primalist Flamedancer** to finish them off, or to remove [[spell:391031]] 
    		from **Primal Thundercloud**.
  - If necessary [[spell:192077]] with [[spell:462820]] can be used to remove stacks of 
    		[[spell:373803]] applied by **Infused Whelps** to prevent [[spell:373593]] 
    		from occuring.
- **适用条件：Temple of Sethraliss（启用）。** 
  
  
  - [[spell:51490]] is quite useful in this dungeon to stop the [[spell:1290031]]
    		and [[spell:1308113]] channels, and to prevent **Faithless Tormentor** 
    		from reaching the boss during the **Avatar of Sethraliss** final boss encounter. 
    		For this last case you can also use [[spell:51485]].
  - Use [[spell:383013]] to remove [[spell:267027]] caused 
    		by **Venomous Ophidian** during the second boss encounter **Merektha**. 
    		Note that this can and should instead be interrupted when possible.
  - Use [[spell:51886]] to dispel [[spell:1293307]] inflicted by 
    		**Faithles Tender**. Note that this can and should instead by interrupted 
    		when possible.
- **适用条件：Blinding Vale（启用）。** 
  
  
  - Use [[spell:58875]] to remove [[spell:1236658]] during 
    		the second boss encounter **Ikuzz the Light Hunter**.
  - Use [[spell:383013]] to remove [[spell:1250937]] caused 
    		by **Potatoad Matriarch**.
- **适用条件：Voidscar Arena（启用）。** 
  
  
  - Use [[spell:383013]] to remove [[spell:1226120]] 
    		during the second boss encounter **Atroxus**.

6.

### Dealing with Affixes

Season 2 of Midnight only has four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Each bargain provides a unique set of beneficial
effects once it is dealt with, and while they are powerful, they are not something you
play around in a specific way. The important part is to not let any of them buff the enemy
trash or bosses.

### Ascendant

6.1.

#### Xal'atath's Bargain: Ascendant Management for Elemental Shaman

Elemental has quite a few ways to deal with this affix:

- [[spell:370]]
- [[spell:51490]]
- [[spell:192058]]

### Pulsar

6.2.

#### Xal'atath's Bargain: Pulsar Management for Elemental Shaman

Nothing special here beyond making sure to soak them when you are not in danger
of killing yourself, as it deals significant damage. Remain close at least one
other party member so your pulsar gets soaked.

### Devour

6.3.

#### Xal'atath's Bargain: Devour Management for Elemental Shaman

[[spell:383013]] or [[spell:192077]] with [[spell:462820]]
 immediately dispel everything. Pretty strong!

You can use [[spell:378075]] or [[spell:58875]] to remove it from yourself.

You can also spec into [[spell:51886]], but unless it is good in that
particular dungeon, it should not be necessary.

### Voidbound

6.4.

#### Xal'atath's Bargain: Voidbound Management for Elemental Shaman

Kill the Void Emissary fast. That is all. It is not worth holding onto cooldowns
for it however, unless they are somehow not dying in time.

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **17 Aug. 2026:** Updated for Midnight Season 2, added cheatsheet of recommended utility talents for each dungeon.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Added additional information for each dungeon about specific uses for utility spells, updated utility cheatsheet.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent trees for changes to class-gate unlock.
- **19 Jan. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **15 Aug. 2025:** Updated recommendation on Farseer M+ build.
- **12 Aug. 2025:** Added more dungeons tips.
- **10 Aug. 2025:** Fixed Farseer M+ build not using Earth Shock.
- **04 Aug. 2025:** Updated and reviewed for Patch 11.2 and Season 3.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **29 Mar. 2025:** Re-added Elemental Blast talent choice line that was munched by mistake.
- **01 Mar. 2025:** Added additional recommended utilities for several dungeons.
- **24 Feb. 2025:** Updated for The War Within Season 2.
- **15 Dec. 2024:** Updated and reviewed for Patch 11.0.7.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **01 Oct. 2024:** Adjusted some dungeon-specific talent recommendations.
- **09 Sep. 2024:** Fully updated and reorganized the page, added multiple builds with their purpose, specific dungeon builds and information, additional ability and affix recommendations.
- **19 Aug. 2024:** Updated with some preliminary information.
- **12 Aug. 2024:** Updated for Patch 11.0.2 with new Hybrid Mythic+ build.
- **20 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated with 10.2 builds, put Fire on top as it is most relevant with T31.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **11 Jul. 2023:** Fixed some links that still led to season 1 pages.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **06 May 2023:** Added some more advice regarding talent/build choice.
- **01 May 2023:** Removed mentions of non-Season-2 affixes. Added tips on how to deal with the 3 new Season 2 affixes, adjusted default talent recommendations. Adjusted some wording.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Adjusted recommended fire build for dungeons for more AoE burst.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Elemental Shaman in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Elemental Shaman macros. You can import
these by simply clicking the "Copy" button on each individual block.

1.1.

#### Wind Shear

#### Focus Interrupt

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Wind Shear
```

This macro will stop your current cast and cast [[spell:57994]] on your
focus if available, otherwise it will be cast on your target.

1.2.

#### Purge

#### Focus Purge

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Purge
```

This macro will stop your current cast and cast [[spell:370]] on your
focus if available, otherwise it will be cast on your target.

1.3.

#### Wind Rush Totem

Two options are available, allowing you to either instantly cast
[[spell:192077]] at your feet:

#### Wind Rush at Feet

```wow-macro
#showtooltip
/stopcasting
/cast [@player] Wind Rush Totem
```

Or at your current cursor location:

#### Wind Rush at Cursor

```wow-macro
#showtooltip
/stopcasting
/cast [@cursor] Wind Rush Totem
```

These remove an input and allow you to activate the totem much quicker than usual 
to get the movement speed rolling quickly.

1.4.

#### Ancestral Swiftness Macro for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) Farseer

In order to maintain maximum uptime and keep the ability as easy to use as possible,
we recommend macroing [[spell:443454]] to at least [[spell:51505]] 
in order to maximize uptime without having to think about it. Replace your Lava Burst
 bind with this macro, you can also do the same with [[spell:188196]] and 
 [[spell:188443]]:

#### Ancestral Swiftness on Lava Burst

```wow-macro
#showtooltip Lava Burst
/use Ancestral Swiftness
/cast Lava Burst
```

1.5.

#### Maintenance Buffs Castsequence Macro

This macro will cast your two maintenance buffs in sequence with one button. 
Thanks to [[spell:1270350]] you only 
need two GCDs to apply all your buffs, as applying [[spell:192106]] will 
apply [[spell:974]], [[spell:318038]] and [[spell:462742]] 
for free if talented. Note that you probably want a separate [[spell:974]] 
bind at least so you can put it on others and refresh it during a dungeon or in combat.

#### Maintenance Buffs Castsequence

```wow-macro
#showtooltip
/castsequence reset=10 Skyfury, Lightning Shield
```

1.6.

#### Totemic Projection Castsequence Macro

This casts [[spell:192077]] then [[spell:108287]] at your cursor.
It can be adapted to be used with any totem.

#### Wind Rush + Totemic Projection

```wow-macro
#showtooltip
/castsequence [@cursor] reset=20 Wind Rush Totem, Totemic Projection, Totemic Projection
```

1.7.

#### Cursor/Mouseover Earthquake, Capacitor Totem & Flame Shock

This casts [[spell:61882]] at your cursor's current location,
eliminating the target reticle. Be careful with this macro, as it can
easily lead to mistakes, but some players prefer the speed and
convenience that it can provide. You can replace Earthquake with or Capacitor Totem.

#### Earthquake at Cursor

```wow-macro
#showtooltip
/cast [@cursor] Earthquake
```

The following macro will cast [[spell:188389]] on the target your cursor is on. If your
cursor is not on any enemy, it will instead cast it on your selected target.

#### Flame Shock at Cursor

```wow-macro
#showtooltip
/cast [@mouseover,exists]Flame Shock;Flame Shock
```

1.8.

#### Spirit Walk + Time Spiral Abuse Macro

This macro takes advantage of the off-the-global-cooldown nature of [[spell:58875]]
and [[spell:79206]] and allows us to "double dip" from [[spell:374968]]
by getting the benefit of both abilities.

#### Double Dip on Time Spiral

```wow-macro
#showtooltip
/stopcasting
/cast Spirit Walk
/cast Spiritwalker's Grace
```

1.9.

#### Focus Target Macro

This designates a target as your focus and optionally immediately uses a spell at it.
Generally used with [[spell:57994]], but works with most spells.

#### Focus Target

```wow-macro
/focus [@focus,noexists]
/cast [@focus] Wind Shear
```

1.10.

#### Primal Fire Elemental Meteor Macro

This macro allows you to manually cast your Primal [[spell:198067]]'s 
[[spell:117588]] ability. Note that now that the Elemental can auto-cast this
 ability unless you specifically want to use them manually, this macro is not useful
 in most situations.

#### Manual Meteor

```wow-macro
#showtooltip
/use [pet:primal fire elemental]meteor
```

Similar macros can be used when a talent choice between two active abilities
is available. In Midnight, there are only 2 additional uses:
[[spell:192063]] vs. [[spell:58875]] and [[spell:8042]] vs.
[[spell:117014]]. For example:

#### Shared Button Movement

```wow-macro
#showtooltip
/use [known:gust of wind]gust of wind;[known:spirit walk]spirit walk
```

This next macro allows you to cast [[spell:974]] on an ally on mouseover if
the [[spell:383010]] talent is used. If your cursor is not on an ally or
the previous talent was not taken, it will cast Earth Shield on yourself.

#### Earth Shield on Mouseover

```wow-macro
#showtooltip
/use [@mouseover,help,nodead,known:383010]Earth Shield;[@player]Earth Shield
```

1.11.

#### Goblin Only! Gust of Wind and Rocket Jump Macro

Fellow goblins can also use a castsequence macro, making them use
[[spell:69070]] when [[spell:192063]] is on cooldown.

#### Goblin Jumps

```wow-macro
#showtooltip
/castsequence reset=14 Gust of Wind, Rocket Jump
```

1.12.

#### Healing or Raising an Ally

This macro mostly will raise your ally if they are dead or heal them if they are alive.

#### Header Text

```wow-macro
#showtooltip
/use [@mouseover,help,dead]Ancestral Spirit;[@mouseover,help,nodead]Healing Surge;[dead]Ancestral Spirit;Healing Surge
```

1.13.

#### Friend or Foe Adaptive Macros

The following macro will cast [[spell:370]] or [[spell:51886]] depending
 on whether you are targeting an enemy or an ally:

#### Purge and Cleanse Shared Button

```wow-macro
#showtooltip
/use [@mouseover,harm,nodead,known:purge]Purge;[@mouseover,help,nodead]Cleanse Spirit;[harm,known:purge]Purge;Cleanse Spirit
```

The following macro will cast [[spell:188443]] or [[spell:1064]]
depending on whether you are targeting an enemy or an ally. Note that you should 
not really be using Chain Heal ever.

#### Chain Spells Shared Button

```wow-macro
#showtooltip
/use [@mouseover,harm,nodead]Chain Lightning;[@mouseover,help,nodead]Chain Heal;[harm]Chain Lightning;[]Chain Heal
```

You can choose to remove individual elements from this macro.
If, for example, you never want Chain Heal to be cast on mouseover, remove:

#### Adjustable Element

```wow-macro
[@mouseover,help,nodead]Chain Heal;
```

2.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.

#### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 May 2026:** Updated Purge/Cleanse macro.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Launch.
- **26 Feb. 2026:** Added ability to copy entire macros with one click. Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight pre-patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **14 Aug. 2025:** Added a choice of WeakAura packages as well as Stormbringer specific WeakAuras and an optional one for Fusion. Fixed Ancestral Swiftness macro being doubled up.
- **07 Aug. 2025:** Updated Ancestral Swiftness macro section.
- **04 Aug. 2025:** Updated and reviewed for Patch 11.2. Removed Tempest/CL macro (unreliable and suboptimal).
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **07 Mar. 2025:** Added Tempest + Chain Lightning macro for Stormbringer users.
- **24 Feb. 2025:** Added Time Spiral "abuse" macro. Reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated and reviewed for Patch 11.0.7.
- **22 Oct. 2024:** Updated and reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Removed unnecessary macros, added Ancestral Swiftness macros.
- **21 Aug. 2024:** Added cancelaura macros, added Liquid Magma Totem to the @cursor macros.
- **23 Jul. 2024:** Fixed a typo in the Gust of Wind/Spirit Walk macro.
- **23 Jul. 2024:** Added a variety of helpful macros, removed a couple that are becoming obsolete.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **17 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **31 Oct. 2022:** Removed the obsolete Harden Skin macro, updated a couple others to be more useful.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
