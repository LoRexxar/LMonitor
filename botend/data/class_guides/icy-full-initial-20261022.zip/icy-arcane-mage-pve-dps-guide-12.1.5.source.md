## 专精概览

Welcome to our Arcane Mage guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as an Arcane Mage in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Arcane Mythic+ Resources

[NEW! Top Arcane Talent Builds](<https://raider.io/specs/arcane-mage/talents>)

[Top Arcane Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/mage/arcane>)

[Arcane Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=mage--arcane>)

[Popular Arcane Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=mage--arcane>)

1.

### Arcane Mage Overview

Arcane Mage is a very burst oriented specialization that has various
unique mechanics amongst DPS specs. Arcane does very high burst damage during
its cooldowns, followed by a lower damage phase, biding time until the cooldowns
come back up. Unlike other DPS specs in the game, Arcane
has a mana pool it has to pay attention to. Many of its spells cost very large
amounts of mana, and you will have to carefully maintain your mana, via cooldowns
like [[spell:12051]] and [[spell:365350]] to get the most of your toolkit.

Very Strong

Arcane Mage comes equipped a very strong damage kit. It has
high burst damage on both single-target and AoE, which is generally preferred over sustained damage.
Additionally, its single-target damage increases further
whenever there are additional targets ("funnel DPS"), which is also very valuable.

Arcane Mage is capable of dealing AoE damage partially for "free" while doing its single-target
rotation, which is also very valuable, especially in raids.
Unfortunately Arcane has no ability to deal AoE damage to targets that are not
close together, and its AoE damage is quite reliant on procs, which can be a
problem on packs that die very quickly, but on any encounter longer than a
single burst phase, it averages out well.

Strong Kit — Great Tuning

Arcane Mage can quickly burst down
priority targets, without having to give up overall damage. Combine this
with its funnel DPS, which is incredibly valuable in raids, and having a raid buff
(

[[spell:1459]]

) and decent survivability, it has the potential to truly
shine in raids. However, survivability can be a problem on some encounters,
which makes progressing some bosses rather difficult. However, with current tuning,
the damage is high enough that this potential extra healing required is easily
worth it.

Very Strong

Arcane is a great choice for Mythic+. It can blow up packs very quickly,
comes with multiple layers of AoE interrupts, and provides important buffs
and utility to the group in the form of

[[spell:1459]]

and

[[spell:80353]]

.
It does however require a little bit of coordination, as blowing all cooldowns on
a small pull into doing a big pull while cooldowns are not ready will severely
hurt your overall damage. In very high keys, Arcane struggles defensively and
often needs a close eye from the healer to stay alive, due to running out of
defensives quickly. However, current Arcane DPS makes this extra attention
from the healer more than worth it.

Great utility, especially in smaller groups

Arcane Mages come with many forms of utility, like its raid buff

[[spell:1459]]

,
or the ever important

[[spell:80353]]

, strong crowd-control like

[[spell:157980]]

,
debuff removal via

[[spell:475]]

and enemy buff removal via

[[spell:30449]]

.
Having said that, much of this utility is not that useful for raid groups (or also brought by other classes),
making it less important in raids, but in Mythic+ the utility is very strong.

Good defenses, but highly reliant on a few strong cooldowns that can run out quickly

As an Arcane Mage, you have great survival against high burst damage,
especially if it is infrequent, while lacking defensives against consistent damage
over time. Spells like [[spell:45438]] or [[spell:414659]] are some of the best
defensives in the entire game, but have a long cooldown, while [[spell:235450]]
and [[spell:342245]] are low cooldown defensives used against lower damage
hits.
Due to this, the survivability depends on the specific boss or dungeon you are doing.

Generally, if the damage of the content you are doing is infrequent enough,
Arcane can do well defensively, but in most content you risk running
out of cooldowns quickly.

To make the most of Arcane's survivability,
you need to be well prepared, as almost all of its defensives require you
to press the defensive before damage comes in, as it has limited self-healing or passive
damage reduction.

Very Mobile

Arcane has some of the best on-demand mobility in the game, due to its ability
to use double

[[spell:212653]]

or

[[spell:1953]]

, and even resetting a charge via some talent options.
Due to this, it can generally get anywhere on a boss fight almost immediately.
You can even get a sprint-like option in the form of

[[spell:382293]]

.
The only downside to its mobility is sustained movement speed, as all of its
mobility is burst-oriented mobility. Arcane can do a large chunk of its
rotation on the move, and has lots of options to reposition itself as needed
for mechanics, making it highly mobile in encounters.

2.

### Arcane Mage in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 is a mid-season patch for Season 2. It adds two new pieces of
endgame content: a new single-boss raid, the Unbinding of Kith'ix, and the
Labyrinth of Kindo'jan, a new Mega-Delve for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Check out our
guides for both below!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Aside from the new raid and the Labyrinth, the patch brings
item level upgrades through [[item:280562]], and more.
Check out our 12.1.5 Patch Hub for a full overview.

2.3.

#### Class Changes

Patch 12.1.5 brings no gameplay changes to Arcane Mage. The only change is
visual: several Arcane spells have been added to the Spell Density system, which
gives non-Mage players more options to control the visibility of our spells.

The new raid and the Labyrinth do bring new items, so make sure to check out our
[Gear](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>) page, which also covers how
[[item:280562]] can upgrade your existing equipment.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_arcanesalvo.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class ChangesHide Patch 12.1 Class Changes
In 12.1, Arcane gets a lot of mechanical
changes. The Apex Talent has been replaced entirely, [[spell:1241462]] is a
completely different spell, [[spell:1243435]] is reworked, and the class tree
picks up some defensive changes and improvements.

2.3.1.

##### New Apex Talent: Prismatic Bolt

[[spell:1257942]] has been removed and replaced with a new Apex
Talent, Prismatic Bolt:

- [[spell:1295923]]: [[spell:44425]] gains a 1% chance per
          [[spell:384452]] stack consumed to replace your next
          [[spell:30451]] with a [[spell:1295924]]. It damages your target
          and nearby enemies, with reduced damage beyond 5 targets, and generates 4
          [[spell:36032]]s. It does not scale its damage or mana cost with
          Arcane Charges, and is not affected by anything that modifies Arcane
          Blast. You can hold the proc for up to a minute.
- [[spell:1295944]]: Prismatic Bolt has a 50%/100% chance to grant
          [[spell:79684]], and [[spell:5143]] damage is increased
          by 15%/30%.
- [[spell:1295946]]: Adds another 1% chance per [[spell:384452]]
          stack consumed, bringing it to 2% per stack in total, and increases
          [[spell:44425]] damage by 15%.

Fully invested, an [[spell:44425]] spending 20 stacks of
[[spell:384452]] has a 40% chance to hand you a [[spell:1295924]],
(up to 25 stacks -> 50% as Sunfury) making this is a relatively frequent proc rather
than a rare one. The 4 [[spell:36032]]s being refunded greatly improves
the ability to get back to 4 Arcane Charges after dumping to 0, allowing you to
save on other methods of charge generation for when Prismatic Bolt does not proc.

[[spell:1295924]] itself also does very high damage, which the rotation
    greatly revolves around. Make sure to check out the updated
    [Rotation Page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>) for how to play around it.

2.3.2.

##### Arcane Pulse Rework

[[spell:1241462]] has been reworked:

- 2 second cast time, 8 yard radius, and a 15 second cooldown.
- It generates 1 [[spell:36032]] per enemy struck.
- [[spell:36032]]s no longer affect it.
- [[spell:383676]] and [[spell:384612]] no longer affect it.

This turns Arcane Pulse from an AoE filler into a cooldown,
and it undoes the 12.0.5 change that lined its cast time up with
[[spell:30451]]. Generating a charge per target means a single cast can take
you from empty to 4 [[spell:36032]]s in AoE, which is a big
deal both for opening on a pack and for rebuilding after a
[[spell:44425]]. The trade-off is that [[spell:1449]] goes back to
filling the gaps between Pulses, so AoE means being in melee range more often
again.

2.3.3.

##### Orb Mastery Redesign

[[spell:1243435]] has been redesigned. [[spell:153626]] now always
launches 2 additional orbs at 50% effectiveness, and it no longer requires
or consumes [[spell:79684]]. Previously it consumed a Clearcasting
proc to launch 2 extra orbs at full strength.

[[spell:1243435]] no longer competing with [[spell:5143]] over
[[spell:79684]] means all builds now use Arcane Missiles again
as its spender, instead of Orb-based builds existing. The new Tier Set (see below)
further emphasizes this.

2.3.4.

##### Arcane Salvo Generation

[[spell:1243557]] has been adjusted for the new Apex Talent: Prismatic Bolt
grants 4 [[spell:384452]] stacks, while [[spell:153626]] now grants 1 stack
instead of 2.

2.3.5.

##### Season 2 Tier Set

Season 2 comes with a new Tier Set:

- [[spell:1296581]]: [[spell:5143]] fires one
          additional wave and deals 5% increased damage.
- [[spell:1296582]]: Each [[spell:5143]] wave
          increases the damage of your next [[spell:30451]],
          [[spell:1241462]] or [[spell:1295924]] by 3%, stacking up to 24%.

Both bonuses lean hard on [[spell:5143]], which makes
[[spell:79684]] worth considerably more than it is now. That lines up
with the rest of the patch, since Rank 2 of the Apex Talent hands out
Clearcasting and [[spell:1243435]] no longer consumes it. Getting to 24% and then
spending it on a big hit is the obvious thing to aim for, but how the stacks are
best spent in practice is something we will cover on the
[Rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>).

2.3.6.

##### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger got some tuning changes:

- [[spell:1261082]] now refunds 3 [[spell:384452]] stacks when you
          Barrage at 20 or more stacks (was 5).
- [[spell:444256]]'s damage bonus to [[spell:153626]]
          increased to 50% (was 10%).

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury got the bigger rework, mostly around Spheres and
[[spell:449293]]:

- [[spell:448601]] base generation reduced from 12% to 6%, and
          [[spell:449596]] no longer raises the maximum to 5 Spheres. Instead it
          adds 6% of generation back (12% in total) and gives every
          Sphere an additional 1% spell damage.
- [[spell:449412]] now extends [[spell:365350]] by 0.8 seconds per
          Sphere (was 0.4), up to a maximum of 2.4 seconds (was 2). Since you are back
          to a three-Sphere maximum, three Spheres reach the full extension.
- [[spell:1260272]] has been redesigned. It no longer grants
          [[spell:1236231]] when your Arcane Phoenix expires, instead,
          every spell the Phoenix casts grants a [[spell:449293]] stack, and
          Exceptional spells grant two.
- [[spell:449293]]'s 10 stack cap has been removed, and
          [[spell:1241462]] and Prismatic Bolt now generate stacks as
          well.
- [[spell:449619]] no longer doubles [[spell:449293]] generation
          during [[spell:365350]].
- [[spell:449394]] summons a [[spell:449569]] per 5
          [[spell:384452]] stacks consumed (was 6).

2.3.7.

##### Defensives and Utility

Overall, Arcane became slightly sturdier in 12.1, but the
overall defensive profile does not move much. Most importantly, Arcane gets a
second [[spell:235450]] charge, which helps a lot with dealing with
relatively low but more frequent damage. Expand the section below for
the full defensive and utility changes.

:::details **Click for all Defensive and Utility changes**
- [[spell:321745]] now grants an additional
          [[spell:235450]] charge. In exchange, its extra magic damage
          reduction drops from 10% to 5%, and the extra 15% reduction to harmful
          Magic effect duration is gone.
- New talent: [[spell:1309497]] — 10% of the damage you take is
          dealt to you over 8 seconds instead of immediately, and casting
          [[spell:55342]] raises that to 30% for 15 seconds.
- New talent: [[spell:1297073]] — reduces damage taken from
          area-of-effect attacks by 4%.
- [[spell:1244090]] still restores 50% of your health, but gives
          20% immediately and the remaining 30% over 6 seconds.
- [[spell:2139]] now has a distinct missed visual and sound when you
          use it on a target that is not casting. The interrupt itself is
          unchanged.

:::

Between the new Apex Talent, the Arcane Pulse redesign and the tier set, both
the best Talents and the rotation change quite a bit, so make sure to check out our
[Talents](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>),
[Rotation](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>) and
[Gear](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>) pages for the details.

:::

:::details Show Season 2 HotfixesHide Season 2 Hotfixes
2.3.8.

##### August 18 Hotfix

One week after the Patch launch, with the start of Season 2, Arcane received
    some minor nerfs, mostly aimed at its tier-set:

- [[spell:1296581]]: Nerfed [[spell:5143]]
          damage bonus from 20% to 5%.
- [[spell:1296582]]: Nerfed [[spell:1296930]]
          damage bonus per stack from 5% to 3%, capping at 24% instead of 40%.
- To compensate for these nerfs, all damage was buffed by 3%.

The total impact of both the Tier nerf and the all ability damage buff is
    roughly a ~4-5% nerf on single-target and ~2-3% on AoE, depending
    on the exact gear used.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes for Arcane Mage

Midnight has arrived, and Arcane Mage has received a substantial rework
affecting both the Mage class tree and the Arcane spec itself. 
At its core, Arcane is still about high burst and mana management, but the way
it does this is quite different. Arcane had many of its different
buffs consolidated into a single new resource: [[spell:384452]], to reduce
the amount of different resources and buffs to track.

2.4.1.

##### Apex Talent

Midnight introduced a new type of talent, called Apex Talent.
It shows up at the bottom of your talent tree, and has four ranks.
It functions similar to other talents, costing talent points like usual.

For Arcane, we get the following Apex Talent:

- [[spell:1257942]]: [[spell:321507]] increases
          the damage your target receives from you by 15%.
- [[spell:1257947]]: Arcane Charges further increase the damage
          of [[spell:30451]], [[spell:1241462]], and [[spell:44425]].
          Also increases [[spell:5143]] damage. Has 2 ranks.
          Note: This always counts, not just during [[spell:321507]].
- [[spell:1257950]]: When [[spell:321507]] explodes,
          it leaves behind a pulsing rune on its target, dealing 75%
          of its damage over 6 seconds to nearby enemies. This damage
          is increased by 50% on the initial Touch of the Magi target.

2.4.2.

##### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger has not received major changes, but more targeted
    tuning due to the changes to the spec tree. Anything previously
    referring to a buff affecting [[spell:44425]] has been changed to use
    the new [[spell:384452]] buff. And [[spell:443739]] now just
    procs directly from [[spell:30451]] and [[spell:1241462]] instead of
    [[spell:383782]] due to its removal.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury has received relatively few changes, mostly
    focusing on reducing buff tracking. Primarily, [[spell:451035]] 
    has been simplified so that it just makes [[spell:30451]] and
    [[spell:1241462]] passively do more damage, instead of being a core
    proc we played around. The same goes for [[spell:449394]],
    which used to be a core proc to play around. It now drops
    Meteors when you consume [[spell:384452]] which simply do damage,
    instead of interacting with any of Arcane's resources.

2.4.3.

##### Core Rotational Changes

One of the primary changes is the removal of many different buffs,
    like [[spell:384452]], [[spell:1223798]] (changed to be
    passive instead of a proc), [[spell:383980]] (also now passive instead
    of a proc), etc, into a singular buff: [[spell:384452]]. Arcane Salvo
    is a stacking damage buff to [[spell:44425]], stacked via
    [[spell:5143]] by default, but many talents interact with it to
    either generate it via other spells, like [[spell:1243557]] giving
    [[spell:30451]] and [[spell:1241462]] the ability to generate it as
    well, or [[spell:384858]] increasing the chance to proc based on Salvo
    stacks instead of Arcane Charges.

What all of this means, is that instead of tracking multiple different
    buffs, almost all of your rotation decisions will be based around
    [[spell:384452]], your Arcane Charges, and your mana level. The only
    remaining exception is [[spell:79684]], which still plays
    a critical part in the rotation like before, being the only way to cast
    [[spell:5143]].

In practice with the way things are tuned, the spec becomes about
    generating the maximum [[spell:384452]] stacks as quickly as possible,
    and then immediately spending them to start building them up again.

One final meaningful change is the introduction of [[spell:1241462]],
    which is a new ranged AoE ability. It functions very similar to
    [[spell:30451]], since the damage and mana scales with Arcane Charges,
    except it does AoE damage. It does not fully replace [[spell:1449]],
    as you can use both, but in most circumstances in practice it does
    become your main filler ability in AoE scenarios. Since this is ranged,
    this is a great quality of life improvement, as it means you will no longer
    need to be in melee to do AoE damage.

2.4.4.

##### Other Changes

- Mage defensives have been consolidated and simplified:  
  
  
   ►
                  **Click to expand**
  
  
  - [[spell:235450]] is now even stronger. When fully
                        talented into all supported talents it now provides more
                        absorption (30% max HP), and even more magic damage taken
                        and debuff duration reduction. It also has a lower global
                        cooldown, allowing you to go back to DPSing quicker.
  - [[spell:110959]] and [[spell:55342]] no
                        longer reduce damage taken — they are now purely
                        utility spells.
  - [[spell:414660]] has been removed.
  - [[spell:1244090]] has been added, which allows
                        you to self-heal after dropping to low health, at the cost
                        of some manual control over [[spell:342245]]. Alter Time
                        is normally mostly used for dealing with high burst damage,
                        but via Temporal Realignment, it can also be useful for
                        healing yourself up when you get low health from chip
                        damage.
- Mage Mobility has been slightly reduced and has a few tradeoffs to make
          now:  
  
  
   ►
                  **Click to expand**
  
  
  - [[spell:212653]] now has only 1 charge base (was 2) and a 30
                        second cooldown (was 25) baseline. You can gain back the
                        lost charge, but it is now a trade-off between
                        [[spell:1270829]] and the extra
                        charge.
  - [[spell:1953]] can now be improved via talents:
                        [[spell:1244031]] grants an extra charge,
                        [[spell:1244340]] reduces its cooldown.
  - [[spell:108839]] has been removed.
- Various utility talents have been nerfed or changed into
          choice-nodes:  
  
  
   ►
                  **Click to expand**
  
  
  - [[spell:382440]] has been removed entirely.
  - [[spell:157981]] has been removed from baseline (only
                        accessible via Sunfury talent, but very situational).
  - [[spell:157997]] and [[spell:120]] are now mutually
                        exclusive.
  - [[spell:383121]] and [[spell:113724]] are now
                        mutually exclusive.
  - [[spell:2139]] now interrupts for 7 seconds (was 5).

3.

### Basics of Arcane Mage Gameplay

Arcane Mage is a spec highly dependent on its cooldowns. It can do large
amounts of damage during [[spell:365350]] and similar cooldowns while doing
pretty low damage outside of them. As an Arcane Mage, you also have your Mana
to consider, as your hardest-hitting spells cost a lot of Mana. This further
highlights the importance of using your cooldowns well, as your cooldowns
are the primary way to handle your Mana. [[spell:12051]] (if talented)
provides you all of your Mana back over a couple of seconds, and Arcane Surge
gives you more mana regeneration than you can spend while it is active.

Most of your time will be spent casting [[spell:30451]] as this is your
main Mana expenditure spell. Additionally, Arcane uses various cooldowns, like
[[spell:365350]] to boost the damage you do while burning through your Mana.
While doing your rotation, you will build up [[spell:384452]] stacks
to greatly increase the damage of your next [[spell:44425]], 
consuming them eventually for a massive hit, resetting your Arcane Charges 
and Arcane Salvo stacks, restarting the process.

To condense things further, these bullet points break down the backbone of 
Arcane Mage.

- ![](<https://static.icy-veins.com/images/wow/large_icons/8026694.jpg>) **Don't Waste Prismatic Bolt**  
  
  [[spell:1295924]] is a very hard-hitting spell, which also grants you 4
    [[spell:36032]]s. Due to this, it is very important that if you cast
    [[spell:44425]] and it procs Prismatic Bolt, you should immediately
    cast it afterwards. This requires relatively quick reaction time, but is
    very worth doing correctly.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_arcanesurge.jpg>) **Arcane Surge is Critical**  
  
    When you are out of mana, your entire rotation stops functioning and you
    basically cease dealing damage. Your biggest source of mana, aside from passive generation,
    is [[spell:365350]], which is also a massive DPS boost on its own.
    Due to this, it is incredibly important that you do not sit on Arcane Surge
    for prolonged periods of time, trying to get the perfect window.
    It is better to use it suboptimally than to delay it.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_arcanesalvo.jpg>) **Avoid Overcapping Arcane Salvo**  
  
  [[spell:384452]] massively buffs your [[spell:44425]] damage,
    and optimizing this is a huge part of your rotation. However, it is very easy
    to waste Arcane Salvo stacks by for example using [[spell:5143]]
    while near the cap of 25. In these situations, you actually want to
    use [[spell:30451]] to finish off building to 25 stacks and then
    Arcane Barrage, so that you do not overcap Salvo stacks.

4.

### How to Gear Up as a Arcane Mage

While we always recommend simming yourself for ideal results, we do provide a
dedicated Arcane gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added drop location to list of items to catalyze.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5 (new raid and Labyrinth links, Spell Density change), moved Patch 12.1 and Season 2 hotfixes into a dropdown, and removed the Season 1 changes.
- **09 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated bis gear to show Ascendant Venomstones upgraded item levels, and added Ascendant Venomstones upgrade guidance, and added Kith'ix loot.
- **03 Sep. 2026 (this page):** Updated viability section based on Mythic progress and early Mythic+ pushing.
- **01 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated some bonus IDs to ensure they correct tooltips for Venomcursed effects.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added the crafted stats to the tooltips of crafted items.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Corrected to the correct raid name for a ring drop.
- **23 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated crafting priority to more clearly explain the pros and cons of 2h vs off-hand crafts.
- **17 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated best Flask.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated best-in-slot and crafting recommendations to use Hunter's Ritual Stone and other small optimizations.
- **15 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season start tier nerfs.
- **15 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for Season start tier nerfs.
- **15 Aug. 2026 (this page):** Updated for Season start tier nerfs.
- **12 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated opener to new opener that is 0.5% better and slightly tweaked rest of rotation.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Fixed showing Spellslinger instead of Sunfury under Sunfury.
- **10 Aug. 2026 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated spells for the 12.1 changes, including the new Prismatic Bolt Apex Talent.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Added Patch 12.1 and Season 2 changes, including the new Apex Talent and tier set, and summarized the Season 1 changes into a single dropdown.
- **30 Jun. 2026 (this page):** Added changes coming with weekly reset of June 30th/July 1st.
- **17 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated bis lists and best trinkets based on updated theorycrafting post-patch.
- **15 Jun. 2026 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated bis lists and trinket recommendations for the new Sporefused gear
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Added section for Omnium Folio.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Added 12.0.7. changes.
- **23 May 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated talent choices & context based on the May 26th/27th changes.
- **23 May 2026 (this page):** Added May 26th/27th patch notes and quick explanation of the impact it has + updated viability due to the buffs.
- **20 Apr. 2026 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Nebulous Voidcore and Ascendant Voidcore sections and update bis lists for new item level cap on weapons/trinkets.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated utility section layout and added some additional context for interrupts and utility.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Rotation for 12.0.5 Arcane Pulse changes.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Added changes for 12.0.5.
- **04 Apr. 2026 (this page):** Updated viability section based on latest tuning and Mythic numbers.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Crucible of Erratic Energies trinket to trinket tier list.
- **26 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Corrected Arcane Orb usage from lvl 21 to lvl 23.
- **24 Mar. 2026 (this page):** Removed section about upcoming changes with Mythic week as Arcane received no changes at the start of Mythic week.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Removed Tea mention since it does not work in instances.
- **17 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Added priority DPS vs max AoE DPS section.
- **17 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated default talent picks based on updates to talents page.
- **17 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated M+ talents to include Arcane Pulse to maximize AoE DPS due to very limited single-target DPS decrease.
- **17 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Re-added Arcane Pulse AoE usage for AoE for better AoE DPS.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Added some useful links to Heirloom gear and general level advice, and added section for what Heirlooms to use when leveling.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Replaced pre-season BiS list for 3 different season 1 bis lists (overall, raid, m+), updated crafting info for season 1, added trinkets tier list for season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated Arcane Surge Macro to have all relevant racials/trinket slots by default.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated ring enchants to use Eye of the Eagle instead of stat enchants as it is slightly better in almost all situations.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated Haste FAQ with slightly more context.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Season 1 of Midnight: Updated best talents, flexible talents, added seasonal affixes, etc.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Added Tier-set section for season 1 start.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated recommended talent builds to specify mythic+ weekly keys vs pushing keys and updated best talents for season 1 tuning.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Added tier set section for season 1 start.
- **16 Mar. 2026 (this page):** Added Season 1 changes + new content, and updated performance for season 1 start.
- **09 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Fixed mouseover macro for remove curse.
- **08 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Removed Arcane Pulse from single-target rotation altogether after latest theorycrafting updates.
- **05 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Arcane Pulse usage because of the hotfix removing Reverberate applying double Arcane Salvo stacks.
- **05 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated Talent Trees for the March 5th hotfixes (fixing/nerfing Arcane Pulse to no longer grant double Salvo stacks with Reverberate)
- **05 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated Talent Trees for the March 5th hotfixes (fixing/nerfing Arcane Pulse to no longer grant double Salvo stacks with Reverberate)
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Added level 80 tree for easy importing when starting Midnight leveling.
- **01 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added Teas for their movement speed bonus to food section.
- **27 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Arcane Salvo usage phrasing to be more specific.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated builds and rotation for Midnight launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated Talent trees for prepatch tuning changes.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated Talent tree and rotation for prepatch tuning changes.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **10 Feb. 2026 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated Talent Trees for 12.0.1 tree changes.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Optimized Arcane Surge sequences for Sunfury and Spellslinger.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated Talent Trees for 12.0.1 tree changes.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated Talent Trees for 12.0.1 tree changes.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated strengths and weaknesses to a more informative format + updated for 11.2.7.
- **05 Oct. 2025 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated item levels for 11.2.5 (Turbo boost item levels) and added puzzling cartel section and updated crafting recommendations for unlimited crests.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **10 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated Fiber recommendation with more context to ensure accuracy for all gearing profiles.
- **05 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated default talent toggles slightly for Spellslinger.
- **05 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated tier set disclaimer to indicate this page works both with and without tier set since the recommended rotation and talents do not change for the recommended Hero Talents.
- **25 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Improved Mage tree levelling path to fix a small issue and get more mobility early on to speed through the world faster.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated best trinkets based on trinket tuning and new findings.
- **15 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Slightly updated Sunfury single-target and cleave talents to no longer pick Magi's Spark due to various bugs, and Time Loop being equal DPS and easier to play.
- **15 Aug. 2025 (this page):** Updated viability section based on post PTR tuning and actual in-game activity.
- **15 Aug. 2025 (this page):** Slightly updated talents to no longer pick Magi's Spark due to various bugs, and Time Loop being equal DPS and easier to play.
- **10 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated basic rotation to be more simple and slightly better DPS.
- **10 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated basic rotation to be more simple and slightly better DPS.
- **05 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added more trinkets to the list of trinkets, and updated Mythic+ bis gear slightly.
- **04 Aug. 2025 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for 11.2.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated best in slot lists, trinket recommendations, crafting order, added Reshii section, for 11.2.0
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for 11.2.0.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated best builds for 11.2, added section for season 3 utility spells.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated best rotation based on 11.2 changes for both single-target and AoE, added tier rotation changes section.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated all talent builds for 11.2.0, and updated recommended talents based on the changes.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated spells for the 11.2.0 changes.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated optimal rotation, talents, hero talents for 11.2 changes and tier bonus.
- **04 Aug. 2025 (this page):** Added patch 11.2 information and removed some of the older patch changes.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated DISC Belt information for the changes coming with the reset.
- **17 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Slightly update Durable Information Securing Container Belt information to show % gains for the different bonuses.
- **17 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **17 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **15 Jun. 2025 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for 11.1.7.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Durable Information Securing Container Belt information and best bonuses, and updated BiS lists for new belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Added Combat Assistant information and tips.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Added Combat Assistant information and tips.
- **15 Jun. 2025 (this page):** Added Patch 11.1.7 information.
- **20 May 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added House of Cards as potential Puzzling Chips option for people without Neural Synapse Enhancer.
- **15 May 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated item levels to turbo item levels, and updated recommended trinkets with more context and options, and updated cartel chips with more context and different track recommendations.
- **27 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated Puzzling Cartel Chips section with latest information.
- **21 Apr. 2025 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for 11.1.5.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Counterfeit Dealer's Chips section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added Corruption Enchants section.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added changes from between 11.1 and 11.1.5.
- **22 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Removed wind up interrupt tip as they cannot be interrupted by disorients.
- **20 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Removed unneeded sections.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Updated alter Time usage on healing absorbs due to Alter Time healing changes.
- **15 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated crafting order to more clearly split the early crafts versus best-in-slot crafts.
- **14 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Added tips for all dungeons.
- **13 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Added Gallywix tips and updated some boss tips based on live kills.
- **10 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated crafting options to highlight a better early setup before having multiple sockets in your gear.
- **10 Mar. 2025 (this page):** Updated viability section based on week 1 performance.
- **02 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Arcane Barrage conditions slightly for High Voltage usage to be easier to understand and more consistent across different talent setups.
- **01 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Added tips based on PTR.
- **26 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Arcane Barrage usage slightly to ensure no dropping intuition/arcane tempo and make aoe rotation clearer on funnel vs pure aoe.
- **25 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated best trinkets to also recommend Synergistic Brewterializer as a potential Eye of Kezan alternative.
- **24 Feb. 2025 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for 11.1.0.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated talents and rotation for 11.1 changes.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated best in slot for season 2 / 11.1 gear, updated crafting recommendations due to new bis items, updated trinkets for new trinkets.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Put versatility as second best secondary stat due to changes in 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated best talents for 11.1 changes, updated affix tips for new affixes.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for 11.1 changes: New default setup set to Spellslinger, updated rotation for new optimal rotation due to changes, split rotation into basic - medium - advanced.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated best talents for 11.1: New optimal trees for the new reworked talent trees, and switched overall recommended talents for Spellslinger.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated spells for changes in 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for 11.1: Updated optimal rotation, stats, talents and hero talents for 11.1 changes and tier bonus.
- **24 Feb. 2025 (this page):** Added overview of most important 11.1 changes, updated viability for 11.1, streamlined page further to focus on most important aspects of the guide.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated Cyrce's Circlet suggestions after buffs, and updated BiS to include it now that it's better.
- **15 Dec. 2024 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Cyrce's Circlet section.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated page layout to split the different Hero Talents into their own sections, and added recommended tags to more quickly spot the best builds.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Slightly updated rotation.
- **15 Dec. 2024 (this page):** Added note for 11.0.7 patch and updated viability for 11.0.7.
- **30 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated sunfury talents to pick Lessons in Debilitation instead of Gravity Lapse.
- **27 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation based on latest theorycrafting findings, primarily simplifying barrage usage for spellslinger, while being slightly more DPS.
- **23 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Small modification to AoE rotation for spellslinger and added arcane tempo conditions to single-target rotation under advanced section.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated talents based on last minute nerfs.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Moved various parts of the rotation to advanced to provide a more approachable default rotation and fixed spellslinger rotation showing some sunfury lines.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated talents based on last minute nerfs. Added single-target spellslinger build.
- **22 Oct. 2024 (this page):** Removed Mana cascade change from ptr since it was nerfed to the pre-bugged amount.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for 11.0.5 rework and slightly simplified rotation.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated bis + trinket tier lists to list Transmitter as second best trinket.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated best talents for 11.0.5 rework. Added Spellslinger vs Sunfury information. Added dungeon specific tips.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated single-target and AoE rotations for both hero talents 11.0.5 changes. Added Spellslinger presets now that it is a more viable hero talent setup.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated best talents for 11.0.5. Added multiple AoE builds for Spellslinger and Sunfury.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated spells for 11.0.5 changes.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated talents and rotation for the 11.0.5 rework.
- **21 Oct. 2024 (this page):** Added 11.0.5 changes and how they impacted the guide. Updated viability section for 11.0.5.
- **25 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE rotation to list target counts.
- **24 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Fixed incorrect profession linked for off-hand craft.
- **21 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated stat weights description to more clearly explain that using top gear is better.
- **20 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Added more tips to multiple bosses, added exact cooldown usage to various bosses and added cooldowns outline for Queen Ansurek.
- **16 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation slightly for latest improvements.
- **14 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated Delve talents to do slightly more AoE damage.
- **14 Sep. 2024 (this page):** Updated viability section after latest nerfs.
- **11 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added weapon consumable (oil).
- **11 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Update AoE rotation slightly to move the Arcane Blast line during ToTM to spellslinger rotation, as Sunfury automatically does it already.
- **10 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added note that you can craft embellishments on non spark items.
- **09 Sep. 2024 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated rotation to no longer double-dip Burden of Power due to removal.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added 3 bis lists from different sources: Raiding, Mythic+, Overall. Added trinket tier list. Removed disclaimer from crafting text.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added Elusive Blasphemite as an option for more movement speed at the cost of a small amount of DPS.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated stats to favour haste over mastery due to better gear unlocking in Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Separated the hero talent selector and updated the rotation to include more advanced lines as an optional checkbox. Rewrote arcane barrage usage to be easier to understand.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Removed pre-season talents.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Removed double-dipping mention for Burden of Power due to removal in-game, and removed bug mention of Ignite the future after the bug fix.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated Rotation to be slightly better but similar difficulty level, and update stat priority for Season 1.
- **09 Sep. 2024 (this page):** Updated basics section and viability section.
- **05 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Small improvements to aoe/cleave talents.
- **03 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated crafting recommendations and bis lists.
- **02 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for the removal of Burden of Power double-dipping.
- **02 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Fixed a missing point in the Delve hero tree.
- **28 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated some spell descriptions.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated crafting suggestions on updated Embellishments and updated bis lists.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Added Delve Talent Tree.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Update AoE rotation to clarify funnel vs AoE rotation usage.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Slightly change priority on single target rotation to clarify you should use missiles before dumping Burden of Power if you have it, and some small readability improvements on AoE.
- **21 Aug. 2024 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **30 Jul. 2024 ([cosmetics](<https://www.icy-veins.com/wow/arcane-mage-cosmetics>)):** Page added.
- **30 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Fixed not having 4 piece in the overall bis list.
- **26 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Arcane in Arcane Tempo lines and slightly updated AoE rotation to make it more clear you always Arcane Barrage before Arcane Missiles with 4 charges. Further improved Nether Precision notes to apply more optimisations.
- **25 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Add in Arcane Missiels interrupt conditions to the rotation, reorganized the burn phase into 2 separate parts, the initial burn phase sequence, into the priority list.
- **24 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Clearcasting proc rates were changed on live, causing Arcane Blast to have 5% higher proc rate than Arcane Barrage. Updated rotation to incorporate this by removing the Arcane Barrage execute playstyle.
- **24 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Minor update to suggested talents based on bugs on live servers.
- **24 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated suggested talents due to Illuminated Thoughts being fixed on live servers, causing it to be significantly better than on beta & ptr.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/arcane-mage-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/arcane-mage-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/arcane-mage-mists-of-pandaria-remix-guide>)):** Page added.
- **12 May 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated talents and rotation slightly.
- **10 May 2024 (this page):** Updated viability section.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for Season 4: updated bis lists, added bullion items, updated suggested crafting.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added new head enchant (Incandescent Essence) and updated Phial suggestions
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Season 4.
- **22 Apr. 2024 (this page):** Added changes for Season 4 and updated viability section.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for 10.2.6, removed link to a no longer relevant pack and added new macro for Arcane Barrage + TOTM.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6. and added explanation for best gems.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6. and updated talent choice information.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6. and fixed some typos and removed the "quiet movement" section as it was rather duplicate with other sections.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6. and fixed some typos and updated some abbreviations.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for 10.2.6 and updated viability section with some minor changes.
- **15 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Remove no longer relevant Arcane Missiles clipping section.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation with optimisations found.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated rotation to be easier and slightly more DPS.
- **15 Jan. 2024 (this page):** Replaced 10.2 changes for 10.2.5 changes.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **16 Dec. 2023 (this page):** Updated viability section based on December 19th buffs.
- **24 Nov. 2023 (this page):** Updated viability section based on live data.
- **13 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated BiS to account for different M+ loot and updated raid only bis.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated BiS and embellishments due to sporecloak nerf.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated BiS, embellishments and other relevant sections for 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Removed references to Onyx Annulet and Primordial gems as they are no longer relevant for 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated talents for 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated base rotation for 10.2, added season 3 tier set rotation, season 3 trinkets and other items to the rotation.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated optimal talents for 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated talents and rotation for 10.2 changes.
- **06 Nov. 2023 (this page):** Added 10.2 changes section, removed old changes sections, updated viability section.
- **01 Oct. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated food buff suggestion.
- **26 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Changed layout.
- **07 Sep. 2023 (this page):** Updated viability section with more details.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added 3 different best-in-slot builds.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Changed talent layout to be easier to navigate.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Added 10.1.7 guide changes.
- **09 Aug. 2023 (this page):** Updated viability for after the Fire and Frost nerfs.
- **15 Jul. 2023 (this page):** Updated viability for the balance patch.
- **11 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Upated levelling tree for the new talent trees.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated BiS for new optimal gear due to rework, and updated Onyx Annulet section for nerfed version.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated Onyx Annulet section for the 10.1.5 nerf and reviewed the rest for the Arcane rework in 10.1.5
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for the Arcane rework of 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated suggested talents and rotation for reworked Arcane.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for the reworked Arcane.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated suggested talents for after the 10.1.5 Arcane rework.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated all spells and talents for the Arcane Mage rework of 10.1.5
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated Rotation and Talents for the Arcane rework for 10.1.5
- **10 Jul. 2023 (this page):** Added 10.1.5 changes section and updated viability section for 10.1.5.
- **25 May 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Timwalking section.
- **10 May 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated trinket suggestions based on further improvements.
- **09 May 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation to include further 4-set optimisations.
- **08 May 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated trinket suggestions based on improved sims and further theorycrafting.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated best-in-slot items, crafting suggestions and other gearing advice for 10.1.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Moved Primordial Stone information and updated advice based on 10.1 changes.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated stat priotiy due to 10.1 changes.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Removed mentions about thundering and reviewed for 10.1 changes.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation to include Season 2 tier optimisations.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated some descriptions to be more clear and cleaned up some duplicate spells.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.
- **01 May 2023 (this page):** Added 10.1 changes, added a section pointing out the major changes to the guide made for 10.1 and updated viability section for 10.1 tuning.
- **28 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Added a generic weakaura pack containing all neccesary WeakAuras for all specs.
- **25 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated Onyx ring suggestions based on hotfixes.
- **25 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stone Gem suggestions based on hotfixes.
- **22 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated bis to include Onyx Annulet due to new gem combinations being found.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Update Primordial Stone Gem suggestions due to Desirious Blood Stone combinations being very strong.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stone gem suggestions based on Obscure Pastel Stone being Arcane instead of Shadow on live servers.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/arcane-mage-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Onyx Annulet information and reviewed for patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added Primordial Stone gem suggestions and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7 and provided some small phrasing tweaks.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added link to enchants and gems page for primordial gems.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added Voidmenders Shadowgem to list of trinkets.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **20 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Fixed typo.
- **18 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated burst rotation based on latest theorycrafting and expanded on the AoE rotation.
- **16 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated suggested talents to Mana Gem build and some minor tip changes.
- **16 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Added information about the mana gem build and when to pick Harmony or Mana gem builds.
- **13 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Improve mana gem rotation and added talon usage.
- **12 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added spellthreads advice.
- **17 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated crafted gear due to bronzed grip changes.
- **14 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Added weapon imbuement advice.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Further updated crafted gear info with latest theorycrafting knowledge.
- **13 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated phial advice.
- **13 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Improve burn rotation slightly and add more clarity to end of the burn phase.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Minor changes to levelling tree.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated gear advice based on season 1 available gear and crafted gear.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Added more info for crafted gear.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated phial advice.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated gems advice based on better simulations.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Added section explaining rotational changes due to the tier set.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Minor change to the suggested talent trees to split them more into raiding vs dungeons instead of single target vs aoe.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Updated for Dragonflight Season 1.
- **30 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated burst rotation slightly based on new theorycrafting.
- **30 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated Temporal Warp vs Time Anomaly description to be more informative.
- **30 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated Temporal Warp description for changed time warp functionality.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/arcane-mage-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/arcane-mage-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/arcane-mage-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/arcane-mage-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **22 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/arcane-mage-patch-9-2-changes-analysis>)):** Updated for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/arcane-mage-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/arcane-mage-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/arcane-mage-patch-9-1-changes-analysis>)):** Updated for Patch 9.1 raid release.
- **25 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/arcane-mage-patch-9-1-changes-analysis>)):** Page Created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **20 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added Azshara tips.
- **16 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** Removed disclaimer.
- **14 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added boss tips.
- **10 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added initial talent suggestions.
- **07 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **12 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** Added more tips.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **03 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added tips for Opulence.
- **30 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated for Jaina stun hotfixes.
- **28 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added more Jaina info and suggestions.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor guide for Arcane Mages.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **30 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** Added guides and talent recommedations for Heroic and Normal modes.
- **10 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-uldir-raid-guide>)):** Added Arcane Mage Boss by Boss page (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Arcane Mage leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Mage leveling guide](<https://www.icy-veins.com/wow/mage-leveling-guide>).

1.

### Arcane Mage Leveling Guide for Midnight

Arcane Mage, is very strong at outdoor content
due to having basically infinite mana due to the downtime while doing
outdoor content. Due to this, it can effectively 1 shot most outdoor enemies
by simply staying at 4 Arcane Charges all the time. Due to this, simply questing
is a very effective way of leveling. It also has access to [[spell:66]]
every now and then, allowing you to skip past enemies to speed up quests!

Having said that, Arcane is also very strong at dungeon content, doing incredible
DPS, especially starting around level 40 when you start getting most of
the kit unlocked. If you have some friends (especially a tank or healer)
to queue up with, spamming dungeons is very efficient. If you are playing solo,
the queue time for dungeons as a DPS makes it impractical.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level, but two secondary stats on it
instead of one.

When using Heirloom items, we generally recommend one [[item:122362]]
trinket for the sustain it provides to avoid having to eat/drink in-between enemies,
but the other trinket slot should usually be any on-use trinket that provides
you with stat bonuses obtained from dungeons or questing, or simply
equip a second Discerning Eye of the Beast to avoid having to think about replacing
trinkets.

For the other Heirlooms, we recommend using the items with Mastery and Crit where
possible, but you really cannot go wrong with any stat as they are all very
close in value.

1.2.

#### Useful Leveling Consumables in Midnight

In this section I highlight some consumables that can be useful when leveling
in Midnight. These will focus primarily on speed. Both your movement speed,
and of course your actual DPS.

- [[item:223653]] — Boots Speed Enchant. Requires
  level 70.
- [[item:223800]] — Cloak Speed Enchant.
  Requires level 70.
- [[item:223725]] — Bracers Speed Enchant.
  Requires level 70.

- [[item:225592]] — Provides a large amount of
  speed. Requires level 75.
- [[item:172063]] or [[item:133576]] — Older speed buffs,
  which might be useful if they are much cheaper or you happen to have
  them leftover from previous expansions. Most of these require level 55.

2.

### Leveling Talents

Below, you can see the suggested levelling talent build and the order in
which to pick the talents while levelling. The below build is 
incredible for both dungeons and outdoor content.

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Arcane Level 80 Midnight Leveling
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFegZGamZGAAAGAwMzkFmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMgZAAGzA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFbzMDNzMDAAADAYmZaWWWmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMwMDAGGzA"
}
```
:::

:::details 来源计算器编码
```
#+A-VSdXWCji4aZdJmkB0gBbCxrg8bQwGEE65TT-NcRkGXbEKdG7YghRBWImd8FCZZJRTbC-AAAA-DSEAGaYWUMcARB-
```

:::

**等级 20 起：**2.1.

#### **等级 20 起：**War Mode Talents for Leveling

**等级 20 起：**In this section we will rank the PvP talents best for
leveling and doing solo / small group PvE content.

1. [[spell:235711]] is a huge mobility increase and helps a lot with
   kiting enemies in the open world.
2. [[spell:198111]] is arguably the best defensive tool in the game,
   as it is off the global cooldown, and has a relatively short cooldown, allowing
   you
   to avoid damage against most enemies you face.
3. [[spell:210476]] and [[spell:414664]] are both spells that
   you can pick to help you skip more mobs when going through crowded areas.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 8 起：**Make sure you keep [[spell:1459]] up at all times.
   Keep in mind, if you die, you have to re-cast it. Otherwise just cast it once per hour.
2. **等级 49 起：**Cast [[spell:80353]] when you are about to go into a big
   pull or boss fight. Keep in mind, you can only gain the benefit once every 10 minutes,
   even though the cooldown is 5 minutes.
3. **等级 2–9：**Cast [[spell:319836]] on cooldown.
4. **等级 11–78：**Cast [[spell:5143]] when you have
   [[spell:79684]] and fewer than 20 [[spell:384452]] stacks.
5. **等级 79 起：**Cast [[spell:5143]] when you have
   [[spell:79684]] and fewer than 25 [[spell:384452]] stacks.
6. **等级 81 起：**Cast [[spell:1295924]] when it is available.
7. **等级 75 起：**Cast [[spell:44425]] when [[spell:451038]] is up.
8. **等级 13–77：**Cast [[spell:44425]] whenever you have 4 Arcane
   Charges and 20 [[spell:384452]] stacks, or if enemies are low and
   Arcane Barrage will finish them off.
9. **等级 78 起：**Cast [[spell:44425]] whenever you have 4 Arcane
   Charges and 25 [[spell:384452]] stacks, or if enemies are low and
   Arcane Barrage will finish them off.
10. **等级 23 起：**Cast [[spell:153626]] when you do not have 4 Arcane
    Charges.
11. **等级 19 起：**Cast [[spell:365350]] whenever it is ready and
    you have 4 Arcane Charges.
    **等级 29 起：**Make sure [[spell:321507]] is ready before using Arcane Surge.
12. **等级 29 起：**If [[spell:321507]] is ready and you have 4 Arcane
    Charges, Cast [[spell:44425]], immediately followed by Touch of the Magi.
    Ensure you cast Touch of the Magi before Arcane Barrage lands.
13. **等级 10 起：**Cast [[spell:30451]] as your filler.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **26 Mar. 2026:** Corrected Arcane Orb usage from lvl 21 to lvl 23.
- **16 Mar. 2026:** Added some useful links to Heirloom gear and general level advice, and added section for what Heirlooms to use when leveling.
- **02 Mar. 2026:** Added level 80 tree for easy importing when starting Midnight leveling.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **25 Aug. 2025:** Improved Mage tree levelling path to fix a small issue and get more mobility early on to speed through the world faster.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for 11.1.5.
- **24 Feb. 2025:** Updated talents and rotation for 11.1 changes.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for 11.0.5 rework and slightly simplified rotation.
- **09 Sep. 2024:** Updated rotation to no longer double-dip Burden of Power due to removal.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **12 May 2024:** Updated talents and rotation slightly.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **11 Jul. 2023:** Upated levelling tree for the new talent trees.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Minor changes to levelling tree.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Arcane Mage in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics for Arcane Mage

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Arcane is a great Swiss Army Knife that has a complete toolkit to
approach any situation. It provides great burst as well as impressive
AoE. It is also hypermobile and comes equipped with a
variety of defensive spells and cooldowns. In this section, we will be
focusing on a setup that minimizes the number of buttons and reactivity
necessary without unduly compromising overall damage output.
three quick rules to follow when learning the spec are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/8026694.jpg>) **Don't Waste Prismatic Bolt**  
  
  [[spell:1295924]] is a very hard-hitting spell, which also grants you 4
    [[spell:36032]]s. Due to this, it is very important that if you cast
    [[spell:44425]] and it procs Prismatic Bolt, you should immediately
    cast it afterwards. This requires relatively quick reaction time, but is
    very worth doing correctly.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_arcanesurge.jpg>) **Arcane Surge is Critical**  
  
    When you are out of mana, your entire rotation stops functioning and you
    basically cease dealing damage. Your biggest source of mana, aside from passive generation,
    is [[spell:365350]], which is also a massive DPS boost on its own.
    Due to this, it is incredibly important that you do not sit on Arcane Surge
    for prolonged periods of time, trying to get the perfect window.
    It is better to use it suboptimally than to delay it.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_mage_arcanesalvo.jpg>) **Avoid Overcapping Arcane Salvo**  
  
  [[spell:384452]] massively buffs your [[spell:44425]] damage,
    and optimizing this is a huge part of your rotation. However, it is very easy
    to waste Arcane Salvo stacks by for example using [[spell:5143]]
    while near the cap of 25. In these situations, you actually want to
    use [[spell:30451]] to finish off building to 25 stacks and then
    Arcane Barrage, so that you do not overcap Salvo stacks.

2.

### Beginner's Guide to Arcane Mage in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury   Raid Talents

2.1.

#### Beginner Raid Talents for Arcane Mage

This build is the go-to Raid build, as it does great single-target DPS,
    while also being able to do very high AoE and Cleave DPS for encounters
    that need it, while giving up almost no single-target DPS for doing so.

You can easily import the talent tree below into the game by using the "copy
export string" button below.

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMmZmBAYAAAGgZGwMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYcsgECC-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury   Dungeon Talents

2.2.

#### Beginner Dungeon Talents for Arcane Mage

This build is very similar to the Raid build, only swapping utility
    around to provide you critical utility for Mythic+, like [[spell:157980]]
    and [[spell:30449]].

You can easily import the talent tree below into the game by using the "copy
export string" button below.

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYCgbhJJ-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### Arcane Mage   Basic Rotation

2.3.

#### Beginner Arcane Mage Rotation

Arcane is largely focused around a couple of key concepts.

- Use cooldowns quickly. This is important for almost all specs in the
  game, but Arcane really suffers when you sit on your cooldowns for a long time.
  Not only are you losing damage from not gaining the damage benefits from your
  cooldowns like [[spell:365350]], but your mana generation is directly tied
  to your cooldowns, further lowering your damage and making it much harder
  to remain at 4 Arcane Charges.
- Not wasting [[spell:384452]] stacks. Arcane Salvo provides a massive
  damage increase to [[spell:44425]], so we want to make sure
  we do not overcap Arcane Salvo stacks while also making sure we have
  4 Arcane Charges ready when we cap Arcane Salvo so we can immediately
  use Arcane Barrage.
- Minimizing casts while on low Arcane Charges. Since our primary
  abilities both scale their damage with Arcane Charges, it is important
  we try to avoid casting these ([[spell:30451]] and [[spell:44425]])
  while on low charges as much as possible. The main methods we avoid this
  is by using [[spell:153626]]. Since Arcane
  is very mana hungry, this is not always avoidable, but it is still
  important to keep in mind.

This leads us to the following basic priority list.

- Cast [[spell:365350]] and [[spell:321507]] when both are
          ready. Also activate any on-use
          trinkets or racials that provide damage bonuses or stat increases.
- If only [[spell:321507]] is ready, but not [[spell:365350]],
          cast Touch of the Magi. You can do this once in-between each Arcane
          Surge usage.
- Cast [[spell:5143]] when you have [[spell:79684]] and
          have fewer than 12 [[spell:384452]] stacks.
- Cast [[spell:1295924]] when it is up.
- During [[spell:451038]], cast [[spell:44425]].
- Cast [[spell:44425]] when you have 25 [[spell:384452]]
          stacks and 4 [[spell:36032]]s.
- Cast [[spell:153626]] when you have fewer than 4 [[spell:36032]]s.
- Cast [[spell:30451]] as your filler. Even in AoE!
          (so no [[spell:1449]])
- Cast [[spell:44425]] when unable to cast [[spell:30451]]
          due to being out of mana.

Note: this is a simplified rotation. For the fully optimized rotation,
    check out the [Rotation page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-rotation-cooldowns-abilities>).

2.3.1.

##### Apex Talent: ![Prismatic Bolt Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_mage_touchofthearchmage.jpg>) Prismatic Bolt

Arcane has the following Apex Talent.

- [[spell:1295923]]: [[spell:44425]] gains a 1% chance per
          [[spell:384452]] stack consumed to replace your next
          [[spell:30451]] with a [[spell:1295924]]. It damages your target
          and nearby enemies, with reduced damage beyond 5 targets, and generates 4
          [[spell:36032]]s. It does not scale its damage or mana cost with
          Arcane Charges, and is not affected by anything that modifies Arcane
          Blast. You can hold the proc for up to a minute.
- [[spell:1295944]]: Prismatic Bolt has a 50%/100% chance to grant
          [[spell:79684]], and [[spell:5143]] damage is increased
          by 15%/30%.
- [[spell:1295946]]: Adds another 1% chance per [[spell:384452]]
          stack consumed, bringing it to 2% per stack in total, and increases
          [[spell:44425]] damage by 15%.

The Apex Talent is very strong for both Hero specs,
    and is virtually always taken. [[spell:1295924]] itself
    is a very hard-hitting spell, which you play around specifically.
    Additionally, the 4 [[spell:36032]]s being refunded greatly improves
    the ability to get back to 4 Arcane Charges after dumping to 0, allowing you to
    save on other methods of charge generation.

2.4.

#### Season 2 Tier Set

Our Tier Sets for Season 2 are:

- [[spell:1296581]]: [[spell:5143]] fires one
          additional wave and deals 5% increased damage.
- [[spell:1296582]]: Each [[spell:5143]] wave
          increases the damage of your next [[spell:30451]],
          [[spell:1241462]] or [[spell:1295924]] by 3%, stacking up to 24%.

The set bonuses are both very strong, as they not only make
    [[spell:5143]] more powerful, which makes
    [[spell:79684]] even more valuable, they also have knock-on
    effects for the rest of the spec, like providing more [[spell:384452]]
    stacks and increasing the damage of other spells.
    This makes it a very strong tier set and something you will want to obtain
    quickly, at any item level.

### Arcane Mage   Stat Priority

2.5.

#### Stat Priority for Arcane Mage

You will want to prioritize secondary stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>).

Intellect

Haste

Critical Strike

Mastery

Versatility

We recommend you prioritize item levels over specific stats,
as they are all **very close** in value, and they fluctuate greatly
based on the gear you currently have.

### Arcane Mage   Combat Assistant

2.6.

#### Combat Assistant For Arcane Mage

Patch 11.1.7 introduced two new combat related functionalities,
the Assisted Highlight, and the Single-Button Assistant. For a full
overview on how to enable these features and
all of their details, check out our
[Combat Assistant page](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>).

The Assisted Highlight rotation is a relatively decent rotation, so following it
can be a good way to learn the rotation, however, you are giving up around 20-25%
damage to do so depending on your talents and hero talents.

The Single-Button assistant is more punishing, giving up an additional 5% damage
compared to the Assisted Highlight, for a total of around 25-30%.
However, it allows you to focus entirely on the dungeon / boss mechanics,
which is very valuable.

Note that neither the Single-Button rotation nor the Assisted Highlight rotation
will cast/highlight [[spell:365350]], racial cooldowns, or
items, like trinkets, so you will have to use these manually.

2.7.

#### Tips for using the Combat Assistant as Arcane Mage

- Make sure to use [[spell:365350]] as
  close to on-cooldown as possible, while making sure
  [[spell:321507]] is ready or nearly ready when you use it.
- Use your trinkets, potions, racial cooldowns (like [[spell:26297]])
  or other on-use cooldowns during [[spell:365350]].
- The Single-Button rotation will cast [[spell:1449]]
  when you are fighting 3 or more targets, so make sure you are positioning
  yourself correctly to hit all targets with it.
- It will also cast [[spell:153626]] as part of its rotation,
  so make sure that you are facing in a way that will hit all targets,
  and not accidentally pull other targets with it.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **15 Aug. 2026:** Updated for Season start tier nerfs.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **17 Mar. 2026:** Re-added Arcane Pulse AoE usage for AoE for better AoE DPS.
- **16 Mar. 2026:** Added tier set section for season 1 start.
- **05 Mar. 2026:** Updated Talent Trees for the March 5th hotfixes (fixing/nerfing Arcane Pulse to no longer grant double Salvo stacks with Reverberate)
- **26 Feb. 2026:** Updated Talent tree and rotation for prepatch tuning changes.
- **10 Feb. 2026:** Updated Talent Trees for 12.0.1 tree changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **05 Sep. 2025:** Updated tier set disclaimer to indicate this page works both with and without tier set since the recommended rotation and talents do not change for the recommended Hero Talents.
- **10 Aug. 2025:** Updated basic rotation to be more simple and slightly better DPS.
- **04 Aug. 2025:** Updated optimal rotation, talents, hero talents for 11.2 changes and tier bonus.
- **17 Jun. 2025:** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **15 Jun. 2025:** Added Combat Assistant information and tips.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for 11.1: Updated optimal rotation, stats, talents and hero talents for 11.1 changes and tier bonus.
- **15 Dec. 2024:** Slightly updated rotation.
- **21 Oct. 2024:** Updated talents and rotation for the 11.0.5 rework.
- **09 Sep. 2024:** Updated Rotation to be slightly better but similar difficulty level, and update stat priority for Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6.
- **15 Jan. 2024:** Updated rotation to be easier and slightly more DPS.
- **06 Nov. 2023:** Updated talents and rotation for 10.2 changes.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated Rotation and Talents for the Arcane rework for 10.1.5
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Arcane Mage in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Arcane Mage

For Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is looking to be the strongest Hero Talent
    tree, in both AoE and single-target. It simply does more DPS than
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger, and without any downsides.

Additionally, Sunfury has the luxury of being able to spec into AoE
    while giving up very little single-target DPS, making it much more flexible
    for encounters where both are important, like most boss encounters in raids, and all
    Mythic+ dungeons.

- **Raid -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is significantly ahead in terms of
      DPS on both single-target and cleave DPS, making it the obvious choice
      for Raiding.
- **Mythic+ -** In AoE, both hero trees are relatively close,
      but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury does win out slightly, while doing much more
      single-target DPS with its AoE build than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger does,
      making it the obvious choice.

Since ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury does more DPS than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger in all
    content without having to give up anything in return, there is no real reason to play anything
    other than Sunfury, unless you greatly prefer the Spellslinger playstyle.

**Quick Start Import Codes:**

:::talents Arcane Raid - Sunfury
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMmZmBAYAAAGgZGwMAYYmZA"
}
```
:::

:::talents Arcane Mythic+ - Sunfury
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::talents Arcane Delves - Sunfury
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZGzsYzMDNzYGAAADAYmZaWWWmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMwMDAGmZG"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Sunfury

Pure Single-Target

Raid

recommended

Mythic+

weekly-keys

high-keys

Delves

recommended

Spellslinger

Pure Single-Target

Raid

Mythic+

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Pure Single-Target Build

This build is currently the best performing **pure single-target**
    build. This works great for encounters
    where you will only fight a single enemy throughout the entire encounter.
    **If there are additional targets during the fight, even if only for a
        relatively small portion, I recommend the Cleave / Raid build.**

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Raid Build

This build makes some very small single-target sacrifices (~1%) to do
    significantly more cleave and AoE damage, making it the go-to build
    for any Raid encounter with adds, which is practically all of them.

Depending on the encounter, you can swap out of utility like
    [[spell:382293]] into utility like [[spell:30449]]
    if you need it.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Mythic+ Build

This is the go-to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Mythic+ build, doing both great
    AoE DPS and great single-target DPS, barely sacrificing on either.

This build is the same as the Raid build in terms of DPS talents, but
    it swaps utility around for Mythic+, like [[spell:157980]] and [[spell:475]].

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Delve Build

This build is focused on making [Delves](<https://www.icy-veins.com/wow/delves-guide>) as smooth of an experience
as possible. It focuses on maximizing your survival and kiting capabilities by
speccing into more mobility and crowd-control, while giving up very minimal DPS.
This build is also excellent for outdoor content.

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger Pure Single-Target Build

This is the **pure single-target** build for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger.
For any content which has any additional targets (practically all Raid
encounters do!), make sure to check out the Raid build instead.

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger Raid Build

This is the go-to Raid build for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger, still focusing on
    single-target damage, but also enabling you to do proper cleave damage
    for adds that show up.

Depending on the encounter, you can swap out of utility like
    [[spell:382293]] into other useful tools like [[spell:30449]],
    if you need it.

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger Mythic+ Build

This build gives up more single-target DPS than the Raid build, to maximize
    AoE damage. It also specs into Mythic+ utility, like [[spell:157980]].

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAgZmZGbWmZmZZGjxMzgNmxMzMAADAAwAMzAmBADzMD"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJOOqms59diKUgoABRGcA-NbckEGRXKdeoAHHKQYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMsxMmZmBAYAAAGgZGwMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYcsgECC-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYCgbhJJ-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZGzsYzMDNzYGAAADAYmZaWWWmBAwGAAbwMzwmlZMzyMGzMzMDbMjZMDAwAAAMAzMwMDAGmZG"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYakJqms59diKgEMxtwk8ZUEg2B-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAAAYmZmllZmYBAAYmZmxmlZmZWmxYMzMYjZMzMDAwAAAMzsAAmBADzMD"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJOOqms59diKUgoABRGcA-NbckEGRXKdeoAHHKQYkJeAZZpp9FKZC-AAAA-OQSaIMUwADQAxC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAAAYmZmllZmYBAAwMzwmlZMzyMGzMzMDbMjZmZAAGAAgZmNAwMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJOOqms59diKUgoABRGcA-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-OQSaKMUwADQAxC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAAAzMzssMzELAAsNYmZYzyMmxMGzMzMDbMjZMDAwAAAMzsBAzMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYirZBAJ-NbckEGRXKdoww6AHLYkJeAZZpp9FCMB-AAAA-OQSaKMUwADQAxC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options.
Some of these bonuses affect your damage output, while others are more defensive in nature.

You can change them freely without any penalty, so feel free to experiment with
them to your liking! Below I list the default recommendations:

- Point 1: [[spell:1279596]]
- Point 2: [[spell:1279604]] for group play, or [[spell:1279603]] for solo play
- Point 3: [[spell:1287555]]
- Point 4: [[spell:1279609]]
- Point 5: [[spell:1279616]]

3.

### Apex Talent: ![Prismatic Bolt Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_mage_touchofthearchmage.jpg>) Prismatic Bolt

Arcane has the following Apex Talent:

- [[spell:1295923]]: [[spell:44425]] gains a 1% chance per
          [[spell:384452]] stack consumed to replace your next
          [[spell:30451]] with a [[spell:1295924]]. It damages your target
          and nearby enemies, with reduced damage beyond 5 targets, and generates 4
          [[spell:36032]]s. It does not scale its damage or mana cost with
          Arcane Charges, and is not affected by anything that modifies Arcane
          Blast. You can hold the proc for up to a minute.
- [[spell:1295944]]: Prismatic Bolt has a 50%/100% chance to grant
          [[spell:79684]], and [[spell:5143]] damage is increased
          by 15%/30%.
- [[spell:1295946]]: Adds another 1% chance per [[spell:384452]]
          stack consumed, bringing it to 2% per stack in total, and increases
          [[spell:44425]] damage by 15%.

The Apex Talent is very strong for both Hero specs,
    and is virtually always taken. [[spell:1295924]] itself
    is a very hard-hitting spell, which you play around specifically.
    Additionally, the 4 [[spell:36032]]s being refunded greatly improves
    the ability to get back to 4 Arcane Charges after dumping to 0, allowing you to
    save on other methods of charge generation.

4.

### Hero Talents for Arcane Mage

Arcane has access to the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger
Hero Talent trees.

Currently, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is ahead in DPS in practically all content,
and it does this without sacrificing utility or survivability, making it
the go-to for all situations.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury spawns an Arcane Phoenix alongside you during
[[spell:365350]], throwing out spells of its own providing damage and some utility.
Gameplay wise, the primary change is that after Arcane Surge ends,
you get the very powerful [[spell:451038]] buff, which makes
[[spell:44425]] grant [[spell:79684]], generate four Arcane
Charges, generate five [[spell:384452]] charges, and casting it does not
consume any Arcane Salvo charges. What this means in practice is that
during Arcane Soul, you can simply spam very hard hitting Arcane Barrages.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger is all about providing you lots of small
passive bonuses to all your spells and applying many [[spell:443763]]s
to your target. Gameplay wise, the tree is fairly passive, however,
all of the passive effects together grant you quite a few extra
[[spell:384452]] stacks, which in turn enables you to cast more [[spell:44425]]s.

5.

### PvP Talents (War Mode)

Since Battle for Azeroth, there is the option to enable "War Mode."
Enabling War Mode grants the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at max
level. However, doing so will enable PvP combat and the possibility of being
attacked by members of the opposite faction while leveling or doing World
Quests exists.

In this section, we will rank the War Mode talents for leveling and outdoor
content.

1. [[spell:198111]] is off the Global Cooldown, so it can be used
   without sacrificing any damage and is very strong for when you know damage is
   incoming. You can simply tank the damage and heal back to full Health when the
   shield ends.
2. [[spell:353082]] is a great tool for AoE damage in the open world,
   especially on high-health targets.
3. [[spell:235711]] is an incredible open-world kiting and mobility tool.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **12 Aug. 2026:** Fixed showing Spellslinger instead of Sunfury under Sunfury.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added section for Omnium Folio.
- **23 May 2026:** Updated talent choices & context based on the May 26th/27th changes.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **17 Mar. 2026:** Updated M+ talents to include Arcane Pulse to maximize AoE DPS due to very limited single-target DPS decrease.
- **16 Mar. 2026:** Updated recommended talent builds to specify mythic+ weekly keys vs pushing keys and updated best talents for season 1 tuning.
- **05 Mar. 2026:** Updated Talent Trees for the March 5th hotfixes (fixing/nerfing Arcane Pulse to no longer grant double Salvo stacks with Reverberate)
- **26 Feb. 2026:** Updated Talent trees for prepatch tuning changes.
- **10 Feb. 2026:** Updated Talent Trees for 12.0.1 tree changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **15 Aug. 2025:** Slightly updated Sunfury single-target and cleave talents to no longer pick Magi's Spark due to various bugs, and Time Loop being equal DPS and easier to play.
- **04 Aug. 2025:** Updated all talent builds for 11.2.0, and updated recommended talents based on the changes.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated best talents for 11.1: New optimal trees for the new reworked talent trees, and switched overall recommended talents for Spellslinger.
- **15 Dec. 2024:** Updated page layout to split the different Hero Talents into their own sections, and added recommended tags to more quickly spot the best builds.
- **30 Oct. 2024:** Updated sunfury talents to pick Lessons in Debilitation instead of Gravity Lapse.
- **22 Oct. 2024:** Updated talents based on last minute nerfs. Added single-target spellslinger build.
- **21 Oct. 2024:** Updated best talents for 11.0.5. Added multiple AoE builds for Spellslinger and Sunfury.
- **14 Sep. 2024:** Updated Delve talents to do slightly more AoE damage.
- **09 Sep. 2024:** Removed pre-season talents.
- **05 Sep. 2024:** Small improvements to aoe/cleave talents.
- **02 Sep. 2024:** Fixed a missing point in the Delve hero tree.
- **24 Aug. 2024:** Added Delve Talent Tree.
- **21 Aug. 2024:** Updated for The War Within.
- **24 Jul. 2024:** Updated suggested talents due to Illuminated Thoughts being fixed on live servers, causing it to be significantly better than on beta & ptr.
- **24 Jul. 2024:** Minor update to suggested talents based on bugs on live servers.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated optimal talents for 10.2.
- **04 Sep. 2023:** Changed talent layout to be easier to navigate.
- **10 Jul. 2023:** Updated suggested talents for after the 10.1.5 Arcane rework.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **16 Jan. 2023:** Added information about the mana gem build and when to pick Harmony or Mana gem builds.
- **11 Dec. 2022:** Minor change to the suggested talent trees to split them more into raiding vs dungeons instead of single target vs aoe.
- **30 Nov. 2022:** Updated Temporal Warp vs Time Anomaly description to be more informative.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Arcane Mage in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Arcane Mage Gameplay and Rotation Guide

Welcome to our Rotation page for Arcane Mages. On this
page you will find everything you need to know about actually playing the 
spec in PvE scenarios.

Each of the sections below explain the rotation for different environments.
Click the boxes to switch to the desired situation.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger

Single Target

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:1241462]]

[[spell:205025]]

[[spell:12051]]

[[spell:1243435]]

[[spell:461248]]

[[spell:1244329]]

[[spell:1296582]]

### Single Target Rotation

1.1.

#### Opener & Cooldown Usage

Cooldown usage for Arcane is very important, as not only do they provide huge damage increases, they also grant massive mana generation and greatly increase your buff generation.

Below we list the opener sequence and the sequence of spells you should follow when both [[spell:365350]] and [[spell:321507]] are ready:

[[spell:365350]]

Pre-cast

Pull

[[spell:5143]]

[[item:241308]]

[[spell:26297]]

[[spell:44425]]

[[spell:321507]]

1. Before the pull, or any time you are about to use your cooldowns, use any trinkets or potions that last 15 seconds or longer, so they are active for the [[spell:365350]] step.
2. On the opener, pre-cast [[spell:365350]].
3. Use any potions, racials, or stat-boosting trinkets with a duration of less than 15 seconds.
4. Cast [[spell:5143]].
5. Cast [[spell:44425]]
6. Cast [[spell:321507]] before Arcane Barrage lands on the target.
7. 45 seconds later, cast [[spell:321507]] when it is ready. You can do this once in-between [[spell:365350]] uses. It has exactly half the cooldown of Arcane Surge, so try not to delay it much, as it will force you to delay your next Arcane Surge as well.
8. Simply follow the single-target rotation listed below while [[spell:365350]] / [[spell:321507]] are active.

1.2.

#### Single Target Rotation

The Arcane rotation follows a priority system. Below we list this priority system. You should read from the top to the bottom, and then execute the first action where all conditions match.

1. **适用条件：Spellslinger（启用）；Mage Arcane 12.1 Class Set 4pc（启用）。** Cast [[spell:1295924]] when it is available and you have 6 or more stacks of [[spell:1296930]]. (the 4-set bonus buff, if you do not yet have the 4-set, simply cast it whenever Prismatic Bolt is available)
2. **适用条件：Spellslinger（启用）；Mage Arcane 12.1 Class Set 4pc（未启用）。** Cast [[spell:1295924]] when it is available.
3. **适用条件：Spellslinger（启用）。** Cast [[spell:44425]] when you have 4 [[spell:36032]]s and 20 [[spell:384452]].
4. **适用条件：Spellslinger（启用）。** Cast [[spell:5143]] when you have [[spell:79684]] and fewer than 15 [[spell:384452]] stacks.
5. **适用条件：Spellslinger（启用）；Mage Arcane 12.1 Class Set 4pc（启用）。** Cast [[spell:1295924]] when it is available.
6. **适用条件：Sunfury（启用）。** Cast [[spell:5143]] when you have [[spell:79684]] and fewer than 12 [[spell:384452]] stacks.
7. **适用条件：Sunfury（启用）。** Cast [[spell:44425]] when [[spell:451038]] is up.
8. **适用条件：Sunfury（启用）；Mage Arcane 12.1 Class Set 4pc（启用）。** Cast [[spell:1295924]] when it is available and you have 8 stacks of [[spell:1296930]]. (the 4-set bonus buff, if you do not yet have the 4-set, simply cast it whenever Prismatic Bolt is available)
9. **适用条件：Sunfury（启用）；Mage Arcane 12.1 Class Set 4pc（未启用）。** Cast [[spell:1295924]] when it is available.
10. **适用条件：Sunfury（启用）。** Cast [[spell:44425]] if you have 4 [[spell:36032]]s and 25 [[spell:384452]].
11. **适用条件：Sunfury（启用）；High Voltage（启用）。** Cast [[spell:44425]] if you have 4 [[spell:36032]]s and 12 or more [[spell:384452]], and a [[spell:79684]] proc,
12. **适用条件：Mage Arcane 12.1 Class Set 4pc（启用）；Sunfury（启用）。** Cast [[spell:1295924]] whenever it is up.
13. Cast [[spell:153626]] when you have no [[spell:36032]]s.
14. **适用条件：Presence of Mind（启用）。** Use [[spell:205025]] for when you need to move and need to cast [[spell:30451]]
15. **适用条件：Evocation（启用）。** Cast [[spell:12051]] when out of mana and you are not currently during [[spell:321507]] or [[spell:365350]].
16. Cast [[spell:30451]] as your filler.
17. Cast [[spell:44425]] if you do not have enough mana for [[spell:30451]].

### AoE Rotation

1.3.

#### AoE Rotation

Currently, Arcane is in a bit of a weird situation, where the single-target and AoE rotation are practically identical, with only very minor changes, and only with some talent loadouts. This is mostly because AoE damage highly revolves around [[spell:44425]] and [[spell:1295924]], which the single-target rotation also already maximizes.

Below I list the **differences you should apply to the single-target rotation** based on various target counts.

1. **适用条件：Arcane Pulse（启用）。** Cast [[spell:1241462]] over [[spell:30451]] when it is ready and you have no 4 [[spell:36032]]s.
2. Cast [[spell:44425]] if you have 12 or more [[spell:384452]], and either [[spell:153626]] ready or [[spell:79684]] instead of only with Clearcasting.
3. **适用条件：Orb Mastery（启用）。** Cast [[spell:153626]] whenever it is available.
4. That's all!

2.

### Midnight Season 2 Tier Set

Our Tier Sets for Season 2 are:

- [[spell:1296581]]: [[spell:5143]] fires one
          additional wave and deals 5% increased damage.
- [[spell:1296582]]: Each [[spell:5143]] wave
          increases the damage of your next [[spell:30451]],
          [[spell:1241462]] or [[spell:1295924]] by 3%, stacking up to 24%.

The rotation impacts the playstyle of Arcane slightly. For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury,
    the rotation with or without tier set is the same, however, for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger,
    the 4-set makes it so that you will want to only use [[spell:1295924]]
    when you have 6 or more stacks of [[spell:1296930]] (the buff the 4-set gives),
    at least as the top priority. Without those stacks, it drops to a lower
    priority in the priority list.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Arcane Mage
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them, so you can
reach your full potential when playing Arcane Mage.

### Arcane Salvo

3.1.

#### Arcane Salvo

[[spell:384452]] is a stacking buff which is granted by using
    [[spell:5143]], by default, which greatly increases
    [[spell:44425]]
    damage. It can also be generated with [[spell:30451]],
    [[spell:1295924]] and [[spell:153626]]
    when specced into [[spell:1243557]], which is generally always done
    due to how important Salvo stacks are. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger,
    you also have a chance to generate them from [[spell:443763]]s.

Not only does Arcane Salvo itself greatly increase the damage of
    Arcane Barrage, with the addition of [[spell:1223798]], having maximum
    Arcane Salvo stacks (20 as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger, 25 as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury)
    becomes even more important, as the damage bonus only applies when you
    use Arcane Barrage on maximum stacks.

Due to this, Arcane Salvo and Intuition have a high impact
    on the rotation (alongside [[spell:1295924]]), focusing primarily
    on building both Arcane Salvo charges as efficiently as possible while
    also trying to maximize Prismatic Bolt usages.

### Mana Management and Arcane Charges

3.2.

#### Mana Management and Arcane Charges

Arcane is one of the few DPS specs that cares about its mana,
    which is primarily driven by [[spell:36032]]s.
    Arcane Charges are a special resource that stack up to 4 times,
    each stack greatly increasing the damage and mana cost of
    [[spell:30451]] and [[spell:1241462]], while also greatly increasing the damage of
    [[spell:44425]]. (but not the mana cost) Arcane Charges
    are mainly stacked by Arcane Blast on single-target, or [[spell:1449]] and
    [[spell:1241462]] in AoE, but various other spells and talents also
    generate them.

Since Arcane Charges massively increase the damage of your core damaging
    abilities, you will generally want to spend as much time as possible
    casting abilities on 4 Arcane Charges, minimizing time spent casting
    spells on low Charges. However, only casting Arcane Blast while on 4
    Arcane Charges will very quickly run you out of mana.

To handle this, Arcane has various tools. Arcane Barrage being the main one,
    as it resets Arcane Charges back to 0, resetting the mana cost increase
    as well as the damage, while itself doing massive damage, if used with
    high [[spell:384452]] stacks.

This creates the core rotation of building up to 4 Arcane Charges -> getting
    max Arcane Salvo stacks -> casting a hard-hitting, stack resetting Arcane
    Barrage.

Arcane does have a few other tools to manage mana, notably
    [[spell:365350]]. Although Arcane Surge itself fully drains your mana,
    it
    also grants so much mana generation, that it actually causes you to
    regenerate to full mana after casting it. Although Arcane Surge damage
    scales with your mana when you cast it, you practically never care
    about this, because the extra damage is minor. So you actually use Arcane
    Surge instead as a method to regenerate back to full mana by casting it when you
    are low.

Then, there are a few other less common ways to generate mana, like
    using [[spell:12051]] (only sometimes talented) or the passive
    [[spell:321526]] (if talented).

Finally, arguably the most important method of regenerating your mana:
    Passive mana generation. Arcane has high mana generation, because
    your Mastery not only increases your damage, but also increases your
    passive mana generation, which throughout the entire fight actually adds up
    to a very large amount of total mana gained.

:::details FAQWhy Is My [[spell:153626]] Not Generating an [[spell:36032]] on Pull?
It does grant you a Charge, however, when entering Raid combat,
all Arcane Charges are reset to 0, so you want to make sure you cast
Arcane Orb after Raid combat started. This goes for any other source of
Arcane Charge generation as well, like if you are the first to hit a Raid
boss with

[[spell:30451]]

, the initial charge provided by it is reset to 0.

:::

### Apex Talent (Prismatic Bolt)

3.3.

#### Apex Talent for Arcane Mage

Arcane has the following Apex Talent:

- [[spell:1295923]]: [[spell:44425]] gains a 1% chance per
          [[spell:384452]] stack consumed to replace your next
          [[spell:30451]] with a [[spell:1295924]]. It damages your target
          and nearby enemies, with reduced damage beyond 5 targets, and generates 4
          [[spell:36032]]s. It does not scale its damage or mana cost with
          Arcane Charges, and is not affected by anything that modifies Arcane
          Blast. You can hold the proc for up to a minute.
- [[spell:1295944]]: Prismatic Bolt has a 50%/100% chance to grant
          [[spell:79684]], and [[spell:5143]] damage is increased
          by 15%/30%.
- [[spell:1295946]]: Adds another 1% chance per [[spell:384452]]
          stack consumed, bringing it to 2% per stack in total, and increases
          [[spell:44425]] damage by 15%.

The Apex talent is incredibly strong. So much so, that most of the
    rotation revolves around trying to get out as many [[spell:1295924]]s
    as possible, large because Prismatic Bolt itself hits incredibly hard.

This is primarily done by trying to get as many [[spell:384452]]
    stacks as quickly as possible, wasting limited time on other things.
    This is also why for example [[spell:461248]] and [[spell:1244329]]
    are taken, as these combine both generating Arcane Salvo stacks and
    [[spell:36032]]s at the same time, allowing you to generate more
    Prismatic Bolts.

In terms of actual playstyle changes to maximize this, the main way
    we play around it, is that we do not always try to get maximum [[spell:384452]]
    stacks, when gaining more stacks would be relatively inefficient. For example,
    When you have 12 or more [[spell:384452]] stacks, and a way to generate
    [[spell:36032]]s (for example via [[spell:153626]]), you can
    already use [[spell:44425]] to try to generate a Prismatic Bolt proc.
    This on average generates more Prismatic Bolt procs than getting
    to 25 Salvo stacks via [[spell:30451]].

4.

### Important Cooldowns for Arcane Mage

### Arcane Surge

4.1.

#### Arcane Surge

[[spell:365350]] is Arcane's primary DPS cooldown. It has a 90 second
    cooldown, and when used drains all of your mana for one big hit
    on your target and nearby enemies, dealing damage based on the mana spent.
    However, the real benefit comes after the initial cast, where it increases
    all your spell damage by a massive 35% for 15 seconds, while also greatly
    increasing your mana regeneration, which basically regenerates your mana
    to full mana during its duration.

Generally, you will want to use Arcane Surge immediately as it comes up,
    but it can be beneficial to delay it in certain cases, for example if your
    group is about to use [[spell:80353]] or a similar effect soon, or an
    important raid mechanic that needs high DPS is coming soon, or additional
    targets that come up, etc.

### Touch of the Magi

4.2.

#### Touch of the Magi

[[spell:321507]] is a 45 second cooldown, which applies a debuff
    to your target, which accumulates 20% of all damage you deal
    to the target for 12 seconds, and then exploding for all of the accumulated
    damage to the target and nearby enemies. It also grants 4 Arcane Charges,
    making it so that you can use it immediately on the pull without needing
    to build up stacks.

Touch of the Magi and [[spell:365350]] have very tight timings, with
    Touch of the Magi having exactly half the cooldown of Arcane Surge.
    Since the timing is so close, it is critical you use Touch of the Magi
    as soon as it comes up, so you do not run into a situation
    where Touch of the Magi is not ready when Arcane Surge is.

### Time Warp

4.3.

#### Time Warp

[[spell:80353]] is an ability which buffs your entire party or raid group
    within 100 yards with 30% haste for 40 seconds. This buff is shared
    with multiple other spells like [[spell:2825]] and [[spell:32182]].
    These all put a debuff on all your group members which blocks them from
    getting the effect again for 10 minutes, so you cannot get this same
    effect from multiple sources multiple times.

As Time Warp applies to the whole group, it is generally decided by the raid
    or party leader when it is used, to optimize usage for the whole group,
    instead of just using it when it is best for your personal usage. However,
    if there is no assigned time or you are in a pick up group without any real
    leadership in terms of strategy, it is generally a safe practice to use
    Time Warp right after combat starts so it is up while everyone has all of
    their DPS cooldowns ready. Of course make sure to only do this
    if there will be enemies active for the entire 40 second duration
    of the buff on the pull, as on some fights bosses might go inactive
    or do some kind of phase change early on in the fight.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **15 Aug. 2026:** Updated for Season start tier nerfs.
- **12 Aug. 2026:** Updated opener to new opener that is 0.5% better and slightly tweaked rest of rotation.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated Rotation for 12.0.5 Arcane Pulse changes.
- **17 Mar. 2026:** Updated default talent picks based on updates to talents page.
- **16 Mar. 2026:** Added Tier-set section for season 1 start.
- **08 Mar. 2026:** Removed Arcane Pulse from single-target rotation altogether after latest theorycrafting updates.
- **05 Mar. 2026:** Updated Arcane Pulse usage because of the hotfix removing Reverberate applying double Arcane Salvo stacks.
- **27 Feb. 2026:** Updated Arcane Salvo usage phrasing to be more specific.
- **26 Feb. 2026:** Updated builds and rotation for Midnight launch.
- **10 Feb. 2026:** Optimized Arcane Surge sequences for Sunfury and Spellslinger.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **05 Sep. 2025:** Updated default talent toggles slightly for Spellslinger.
- **10 Aug. 2025:** Updated basic rotation to be more simple and slightly better DPS.
- **04 Aug. 2025:** Updated best rotation based on 11.2 changes for both single-target and AoE, added tier rotation changes section.
- **17 Jun. 2025:** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **15 Jun. 2025:** Added Combat Assistant information and tips.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **02 Mar. 2025:** Updated Arcane Barrage conditions slightly for High Voltage usage to be easier to understand and more consistent across different talent setups.
- **26 Feb. 2025:** Updated Arcane Barrage usage slightly to ensure no dropping intuition/arcane tempo and make aoe rotation clearer on funnel vs pure aoe.
- **24 Feb. 2025:** Updated for 11.1 changes: New default setup set to Spellslinger, updated rotation for new optimal rotation due to changes, split rotation into basic - medium - advanced.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **27 Oct. 2024:** Updated rotation based on latest theorycrafting findings, primarily simplifying barrage usage for spellslinger, while being slightly more DPS.
- **23 Oct. 2024:** Small modification to AoE rotation for spellslinger and added arcane tempo conditions to single-target rotation under advanced section.
- **22 Oct. 2024:** Moved various parts of the rotation to advanced to provide a more approachable default rotation and fixed spellslinger rotation showing some sunfury lines.
- **21 Oct. 2024:** Updated single-target and AoE rotations for both hero talents 11.0.5 changes. Added Spellslinger presets now that it is a more viable hero talent setup.
- **25 Sep. 2024:** Updated AoE rotation to list target counts.
- **16 Sep. 2024:** Updated rotation slightly for latest improvements.
- **11 Sep. 2024:** Update AoE rotation slightly to move the Arcane Blast line during ToTM to spellslinger rotation, as Sunfury automatically does it already.
- **09 Sep. 2024:** Separated the hero talent selector and updated the rotation to include more advanced lines as an optional checkbox. Rewrote arcane barrage usage to be easier to understand.
- **02 Sep. 2024:** Updated rotation for the removal of Burden of Power double-dipping.
- **22 Aug. 2024:** Slightly change priority on single target rotation to clarify you should use missiles before dumping Burden of Power if you have it, and some small readability improvements on AoE.
- **22 Aug. 2024:** Update AoE rotation to clarify funnel vs AoE rotation usage.
- **21 Aug. 2024:** Updated for The War Within.
- **26 Jul. 2024:** Arcane in Arcane Tempo lines and slightly updated AoE rotation to make it more clear you always Arcane Barrage before Arcane Missiles with 4 charges. Further improved Nether Precision notes to apply more optimisations.
- **25 Jul. 2024:** Add in Arcane Missiels interrupt conditions to the rotation, reorganized the burn phase into 2 separate parts, the initial burn phase sequence, into the priority list.
- **24 Jul. 2024:** Clearcasting proc rates were changed on live, causing Arcane Blast to have 5% higher proc rate than Arcane Barrage. Updated rotation to incorporate this by removing the Arcane Barrage execute playstyle.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6. and fixed some typos and removed the "quiet movement" section as it was rather duplicate with other sections.
- **15 Mar. 2024:** Remove no longer relevant Arcane Missiles clipping section.
- **15 Jan. 2024:** Updated rotation with optimisations found.
- **06 Nov. 2023:** Updated base rotation for 10.2, added season 3 tier set rotation, season 3 trinkets and other items to the rotation.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated rotation for the reworked Arcane.
- **09 May 2023:** Updated rotation to include further 4-set optimisations.
- **01 May 2023:** Updated rotation to include Season 2 tier optimisations.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **18 Jan. 2023:** Updated burst rotation based on latest theorycrafting and expanded on the AoE rotation.
- **13 Jan. 2023:** Improve mana gem rotation and added talon usage.
- **13 Dec. 2022:** Improve burn rotation slightly and add more clarity to end of the burn phase.
- **11 Dec. 2022:** Added section explaining rotational changes due to the tier set.
- **30 Nov. 2022:** Updated burst rotation slightly based on new theorycrafting.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Arcane Mage in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Arcane Mage

Welcome to our Gearing Page for Arcane Mage. This

section will cover everything you need to know about equipping your character

correctly.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you

increase the item level of gear along tracks that relate to where you obtained the

item, which harder content dropping gear that can be upgraded to higher Item Levels.

For more information, read up on our dedicated page on how the 

[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 

changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Arcane Mage. There are often many items for a single slot that are very close or even identical DPS, especially if you simply shuffle secondary stats around between different slots. Due to this, you should only use the list below as a general guideline of what a set of end-game gear looks like, not to make immediate gearing choices.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

<em>In a few slots, I list items from Mythic+, which can only be obtained at Mythic track from [The Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). Generally these items are only best-in-slot at Mythic track, not in their Heroic track variants. You are usually better off using a higher item level piece than the best-in-slot piece if you cannot obtain it at Mythic track.</em>

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

keeps the item level, stats and any special bonuses of an item, so it does not matter which 4 out of 5 slots you catalyze. Pick any 4 out of 5 you have available from the list below:

- Head — [[item:271874]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders — [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Chest — [[item:273785]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Hands — [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs — [[item:281235]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

Note: getting 4-set in any capacity is much more important than getting them on the correct (catalyzed) pieces, so always prioritize getting 4-set over the right pieces.

:::

:::details FAQWhat Items From the Great Vault Should I Pick?
Generally, you will want to focus on picking items that are the biggest upgrade for you by simming

[Top Gear](<https://www.raidbots.com/simbot/topgear>)

. However, there are also some items in general that are very valuable and almost always worth picking up if you see them:

- [[item:271092]]: Best-in-slot Weapon by a large margin and very rare and wanted by all casters, so always pick this up if it is in your vault on Heroic or higher.
- Any of the 9/6 Myth track items listed below: All of them are best-in-slot for both Arcane Mage and generally all other cloth wearers, so very difficult to obtain otherwise.
- [[item:250215]]: Best-in-slot Trinket which can only be obtained at Myth track from The Great Vault.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240892]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271563@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYDYwslI]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear **from** Season 2 Mythic+ Dungeons. This includes Tier pieces and 2 Embellished items due to their importance, even though they are not technically from Mythic+ Dungeons, since they are obtainable via [The Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) / [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) / Crafting.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

keeps the item level, stats and any special bonuses of an item, so it does not matter which 4 out of 5 slots you catalyze. Pick any 4 out of 5 you have available from the list below:

- Head — [[item:251232]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Shoulders — [[item:239045]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest — [[item:251147]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Hands — [[item:251129]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs — [[item:193750@JAAIAAQkCYHKvbRLfA]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)

Note: getting 4-set in any capacity is much more important than getting them on the correct (catalyzed) pieces, so always prioritize getting 4-set over the right pieces.

:::

:::details TipsWhich Dungeons Should I Farm?
There are a few outstanding dungeons due to specific items dropping in them making them very good dungeons to farm:

- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Drops best-in-slot on-use trinket, while also dropping a strong Neck, Hands and Feet.
- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops two very strong passive trinkets, including the best non-raid trinket, while also dropping a great Cloak and multiple other useful pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271564@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAAEAAgNygjM]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAKAAwt1ENMMYDYwYlI]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYDYwslI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:159667@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, only using gear **from** the Venomous Abyss Raid. This includes 2 Embellished items as well due to their importance.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

keeps the item level, stats and any special bonuses of an item, so it does not matter which 4 out of 5 slots you catalyze. From Raid, the only chest piece available is

[[item:271567@JAACAAgNyA]]

(from

[Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)

), which is a tier item, so you would always take that one. Then, pick any 3 out of 4 you have available from the list below to catalyze:

- Head — [[item:271874]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders — [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Hands — [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs — [[item:281235]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

Note: getting 4-set in any capacity is much more important than getting them on the correct (catalyzed) pieces, so always prioritize getting 4-set over the right pieces.

:::

:::details TipsWhat Raid Items Are Most Important?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271092@JAACAAAG2A]]: The best weapon by a large margin, due to its higher item level and secondary effect.
- [[item:271874@JAAEAAAG2YhN]]: The best helm by a large margin, due to its higher item level and Venomcursed effect.
- [[item:270164@JAACAAgNyA]]: The best passive trinket.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240892]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271563@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240916]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270170@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYDYwslI]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/arcane-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Arcane Mage in Season 2

There are a great number of Trinkets available for Arcane.

Generally, you will want to use a strong on-use Trinket to pair

it with [[spell:365350]], and then a strong passive Trinket

as your second Trinket.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Arcane Mage Trinkets**
**On-Use -**

[[item:250215]]

, or, alternatively

[[item:273796]]

(slightly weaker)

**Passive -**

[[item:270164]]

, or, alternatively

[[item:270167]]

(slightly weaker)

:::

There are quite a few other valuable trinkets out there, so make sure to click on our

  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Arcane Mage Trinket          Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]] — Best on-use Trinket</li>&#10;<li>[[item:281215]] — Best passive Trinket</li>&#10;<li>[[item:270164]] — Very Close Second-Best passive Trinket</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270170]] — Tied as best&#10;&#10;                        on-use Trinket on single-target, but loses value on AoE.</li>&#10;<li>[[item:273796]] — Strong on-use Trinket</li>&#10;<li>[[item:250214]] — Strong passive Trinket</li>&#10;<li>[[item:270167]] — Strong passive Trinket</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] — Numerically quite strong on-use Trinket, but requires tracking the buff</li>&#10;<li>[[item:250259]] — Strong passive Trinket on single-target, loses value on AoE</li>&#10;<li>[[item:250224]] — Decently strong passive Trinket</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:273794]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be used to guarantee items from a specific

    boss or dungeon. Each time you use it, you are guaranteed to obtain one

    item from that boss or dungeon, and that item is then removed from the

    pool of possible items. Then the next time you use it, you are guaranteed

    any of the remaining items, which means that you will

    obtain the item you are after from that boss or dungeon within a few uses.

With the launch of Patch 12.1.5, you will also be granted one

    additional Voidcore for free from

    **Orin Straylight** in Silvermoon, next to The Catalyst.

Additionally, 12.1.5 brings (back) [[item:280562]], which will

    allow you to upgrade the item level of a fully upgraded Season 2 Hero,

    Mythic, or Crafted weapon, trinket, or necklace.

Note: Mythic [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) and [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) gear cannot be further

    upgraded since they already surpass the normal maximum item level.

3.1.

#### Recommended Nebulous Voidcore Usage for Arcane Mage

**The best items to chase after depend entirely on what items you have already

    obtained so far, and which content you are clearing.** For example,

    if you have not yet cleared a specific boss on Mythic, but expect to do

    so soon, you should not use the Voidcore on the Heroic version of that boss.

    Below I list a generic priority list of Voidcore items, but for the best

    results tailored to your own character, you should use

    [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Heroic or higher [[item:271092]] — Best Weapon,
   
           by a large margin, due to its higher item level and bonus effect. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
   
           also drops many other strong items, making it a very valuable bonus roll boss.
2. Mythic [[item:271874]] — Best helm due to its
   
           higher item level and Venomcursed bonus effect.
3. Mythic [[item:268265]] — Best neck due to its
   
           higher item level and Venomcursed bonus effect.
4. Any Myth Track Weapon — None of them will beat
   
           [[item:271092]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), but if you are not
   
           planning / expecting to kill Heroic Ulatek, getting a Myth track weapon
   
           from other sources is important, especially if you did not craft one.
5. Higher item level items from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>), especially
   
           [[item:268243]].
6. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstones

You will want to use your [[item:280562]] in such a way that you

    get the most amount of power per spent Venomstone:

1. Main-hand Weapon / 2-Handed Weapon
2. On-use Trinket
3. Passive Trinket
4. Off-hand
5. Necklace

In almost all cases, you will only want to use Venomstones on Myth track items,

    unless you are not expecting to get a Myth track item in the same slot, or

    if you otherwise would not have anything to spend Venomstones on.

One exception being [[item:271092]]: If you have this

    at Heroic track, and are unlikely to get it on Mythic track, upgrading it

    is a great choice as the cantrip makes it better than any

    Myth track weapon, especially when upgraded to 340 item level via Venomstones.

4.

### Best Crafted Items for Arcane Mage

**What to craft is highly dependent on your own personal goals,

what content you are doing, and what items you have looted so far.**

We strongly suggest you run your own simulations on raidbots by using

droptimizer to figure out your personal best crafting options.

4.1.

#### Best Embellishments for Arcane Mage

Below we list the best crafted Embellished items, but **make sure to check the

    crafting order below for more context, since the best Embellishments are

    not always the best to craft first!**

- [[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]] with [[item:273060]]
- [[item:239648@JAAMAAwt1ENMMYDYwslIcYD]] with [[item:240167]]

4.2.

#### Crafting Order for Arcane Mage

As your ability to craft items will be time-gated in the initial stages of

the season, we highly recommend getting a **Weapon** as soon as possible, unless

you can reliably get one elsewhere. Once you have a good weapon, work on your other Embellished

Item next, and then craft whichever pieces you do not have high-item-level versions

of yet.

The below list of priorities can be a bit confusing, but it ultimately

    comes down to this: You want one item with a [[item:273060]]

    and one with [[item:240167]]. Hunter's Ritual Stone can only

    go on Weapons, and [[item:271092]] is extremely strong, so

    if you are able to get Janthrazet the Soul Fang, (or a Myth track weapon)

    you will want the weapon Embellishment on an off-hand, otherwise,

    you just want to stick to a 2-handed crafted weapon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Arcane Mage Crafted Gear Priority**
1. [[item:245770]] with [[item:273060]]: Getting a weapon
   
           craft early provides an immense amount of power. If you expect to get a
   
           a Heroic (or better) [[item:271092]], you should skip this step.
2. If you skipped the above step, craft
   
           [[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]
   
           with [[item:273060]]
3. [[item:239648@JAAMAAwt1ENMMYDYwslIcYD]] with
   
           [[item:240167]]: Can also craft any other slot,
   
           the important part is getting Arcanoweave Lining on a piece of gear,
   
           and replacing a low item level piece. Wrist is best-in-slot, but
   
           you can re-craft later anyway.
4. Any item you do not have on Myth track yet.
5. When possible, you will want to replace the crafted [[item:245770]]
   
           for [[item:271092]] (Heroic or higher), and then
   
           craft [[item:245769@JAAMAAwt1ENMMYzy1YlIcYD]]
   
           with [[item:273060]]. If you are not clearing
   
           Heroic, you will instead want to stick with the crafted staff
   
           [[item:245770]] with Hunter's Ritual Stone. If you are
   
           not clearing Heroic but get lucky and find a Myth track
   
           weapon in your Vault, you should use that instead and
   
           craft the off-hand with Hunter's Ritual Stone.

:::

For more information on how you can craft your own gear, you

can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.3.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with

the [[item:275707]] consumable that you can get if you do not select any of the choices in

your Great Vault. Not picking a choice will grant you tokens, six of which can be

traded in for the [[item:275707]] item that allows you to add a socket to the above piece

of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited

access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)

to higher item levels. Since crests are limited each week and upgrading different items

costs the same amount of crests regardless, you will want to prioritize

your usage of them on items you plan on not replacing anytime soon, or that offer the

biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Arcane Mage Crest Upgrade Priority**
**Weapon (Staff to save crests)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

This order is determined by the power you get from upgrading these slots.

Of course, which is best to upgrade can be heavily influenced based

on what you loot, as you can avoid using Crests altogether by looting

higher item level items in those slots, so make

sure that you do not blindly follow the provided upgrade order!

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the

importance of simming yourself on Raidbots. This is because every character is

unique, and each gear piece you have access to can change what is best

right now for you.

While we do offer recommendations for gear and trinkets, these are not complete

replacements for simming yourself. The only way to truly optimize your character

to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Added drop location to list of items to catalyze.
- **09 Oct. 2026:** Updated bis gear to show Ascendant Venomstones upgraded item levels, and added Ascendant Venomstones upgrade guidance, and added Kith'ix loot.
- **01 Sep. 2026:** Updated some bonus IDs to ensure they correct tooltips for Venomcursed effects.
- **31 Aug. 2026:** Added the crafted stats to the tooltips of crafted items.
- **24 Aug. 2026:** Corrected to the correct raid name for a ring drop.
- **23 Aug. 2026:** Updated crafting priority to more clearly explain the pros and cons of 2h vs off-hand crafts.
- **15 Aug. 2026:** Updated best-in-slot and crafting recommendations to use Hunter's Ritual Stone and other small optimizations.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **17 Jun. 2026:** Updated bis lists and best trinkets based on updated theorycrafting post-patch.
- **15 Jun. 2026:** Updated bis lists and trinket recommendations for the new Sporefused gear
- **20 Apr. 2026:** Added Nebulous Voidcore and Ascendant Voidcore sections and update bis lists for new item level cap on weapons/trinkets.
- **31 Mar. 2026:** Added Crucible of Erratic Energies trinket to trinket tier list.
- **16 Mar. 2026:** Replaced pre-season BiS list for 3 different season 1 bis lists (overall, raid, m+), updated crafting info for season 1, added trinkets tier list for season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated item levels for 11.2.5 (Turbo boost item levels) and added puzzling cartel section and updated crafting recommendations for unlimited crests.
- **10 Sep. 2025:** Updated Fiber recommendation with more context to ensure accuracy for all gearing profiles.
- **16 Aug. 2025:** Updated best trinkets based on trinket tuning and new findings.
- **05 Aug. 2025:** Added more trinkets to the list of trinkets, and updated Mythic+ bis gear slightly.
- **04 Aug. 2025:** Updated best in slot lists, trinket recommendations, crafting order, added Reshii section, for 11.2.0
- **24 Jun. 2025:** Updated DISC Belt information for the changes coming with the reset.
- **17 Jun. 2025:** Slightly update Durable Information Securing Container Belt information to show % gains for the different bonuses.
- **15 Jun. 2025:** Added Durable Information Securing Container Belt information and best bonuses, and updated BiS lists for new belt.
- **20 May 2025:** Added House of Cards as potential Puzzling Chips option for people without Neural Synapse Enhancer.
- **15 May 2025:** Updated item levels to turbo item levels, and updated recommended trinkets with more context and options, and updated cartel chips with more context and different track recommendations.
- **27 Apr. 2025:** Updated Puzzling Cartel Chips section with latest information.
- **21 Apr. 2025:** Added Counterfeit Dealer's Chips section.
- **15 Mar. 2025:** Updated crafting order to more clearly split the early crafts versus best-in-slot crafts.
- **10 Mar. 2025:** Updated crafting options to highlight a better early setup before having multiple sockets in your gear.
- **25 Feb. 2025:** Updated best trinkets to also recommend Synergistic Brewterializer as a potential Eye of Kezan alternative.
- **24 Feb. 2025:** Updated best in slot for season 2 / 11.1 gear, updated crafting recommendations due to new bis items, updated trinkets for new trinkets.
- **17 Dec. 2024:** Updated Cyrce's Circlet suggestions after buffs, and updated BiS to include it now that it's better.
- **15 Dec. 2024:** Added Cyrce's Circlet section.
- **21 Oct. 2024:** Updated bis + trinket tier lists to list Transmitter as second best trinket.
- **24 Sep. 2024:** Fixed incorrect profession linked for off-hand craft.
- **10 Sep. 2024:** Added note that you can craft embellishments on non spark items.
- **09 Sep. 2024:** Added 3 bis lists from different sources: Raiding, Mythic+, Overall. Added trinket tier list. Removed disclaimer from crafting text.
- **03 Sep. 2024:** Updated crafting recommendations and bis lists.
- **27 Aug. 2024:** Updated crafting suggestions on updated Embellishments and updated bis lists.
- **21 Aug. 2024:** Updated for The War Within.
- **30 Jul. 2024:** Fixed not having 4 piece in the overall bis list.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4: updated bis lists, added bullion items, updated suggested crafting.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **13 Nov. 2023:** Updated BiS to account for different M+ loot and updated raid only bis.
- **07 Nov. 2023:** Updated BiS and embellishments due to sporecloak nerf.
- **06 Nov. 2023:** Updated BiS, embellishments and other relevant sections for 10.2.
- **26 Sep. 2023:** Changed layout.
- **04 Sep. 2023:** Added 3 different best-in-slot builds.
- **10 Jul. 2023:** Updated BiS for new optimal gear due to rework, and updated Onyx Annulet section for nerfed version.
- **25 May 2023:** Added Timwalking section.
- **10 May 2023:** Updated trinket suggestions based on further improvements.
- **08 May 2023:** Updated trinket suggestions based on improved sims and further theorycrafting.
- **01 May 2023:** Updated best-in-slot items, crafting suggestions and other gearing advice for 10.1.
- **25 Mar. 2023:** Updated Onyx ring suggestions based on hotfixes.
- **22 Mar. 2023:** Updated bis to include Onyx Annulet due to new gem combinations being found.
- **20 Mar. 2023:** Added Onyx Annulet information and reviewed for patch 10.0.7.
- **24 Jan. 2023:** Added Voidmenders Shadowgem to list of trinkets.
- **20 Jan. 2023:** Fixed typo.
- **17 Dec. 2022:** Updated crafted gear due to bronzed grip changes.
- **13 Dec. 2022:** Further updated crafted gear info with latest theorycrafting knowledge.
- **11 Dec. 2022:** Added more info for crafted gear.
- **11 Dec. 2022:** Updated gear advice based on season 1 available gear and crafted gear.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Arcane Mage. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Arcane Mage Stat Priority

The following is a good guideline for stats for Arcane Mages:

Intellect

Haste

Critical Strike

Mastery

Versatility

**All of the secondary (non-Intellect) stats are very close in value despite
the way they are ordered on our list.**
We encourage players to sim themselves, if possible, to determine what stats you
should aim for according to your current distribution, as this may change
depending on your current values. This is because a deficiency of one stat will
often cause it to become high in value relative to the others until you
reach a "normalized" value. Due to this, **we strongly recommend
using [Raidbots Top Gear](<https://www.raidbots.com/simbot/topgear>)** 
instead to handle your gearing needs (see our [Raidbots guide](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)).

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. It provides you with Spell Power, which
increases the damage of your spells.

**Mastery**, thanks to [[spell:190740]], increases your Mana pool
and Mana regeneration, allowing you to cast more spells at maximum
Arcane Charges between [[spell:12051]]s. Savant also
increases the damage buff of Arcane Charges, and additionally increases the damage
of all other spells as well.

**Haste** increases the cast speed of your spells.

:::details FAQIs There a Haste Cap for Arcane Mage?
There are no breakpoints or caps for Haste for Arcane Mage.
However, there are diminishing returns on all stats, where acquiring more of them
reduces the value, so generally a bit of balancing is valuable.
Additionally, if you stack Haste without going much into Mastery as well,
you will run out of mana very quickly, making a balance of stats even more important.

:::

**Critical Strike** increases your chance to critically hit with
all spells and abilities. Crits deal double damage by default, but several 
effects can increase your crit damage, and make crits even stronger.

**Versatility** is a flat-out damage done increase and damage taken
reduction.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated Haste FAQ with slightly more context.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Put versatility as second best secondary stat due to changes in 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **21 Sep. 2024:** Updated stat weights description to more clearly explain that using top gear is better.
- **09 Sep. 2024:** Updated stats to favour haste over mastery due to better gear unlocking in Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for the Arcane rework of 10.1.5.
- **01 May 2023:** Updated stat priotiy due to 10.1 changes.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Arcane Mage, based on your [stat priority](<https://www.icy-veins.com/wow/arcane-mage-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

There are both Epic and Rare gems, with Epic gems being
  significantly more powerful. However, you can only equip a single epic gem,
  so you will have to fill out the rest of your slots with rare gems.

There are two epic gems, either of which can be best depending on
  the situation. If you have 5 gem slots or more,
  [[item:240967]] is the best epic gem. However, if you have
  fewer than 5, use [[item:240983]].

**Rare gems are all very close in power, and the best one will
    fluctuate depending on your exact stat distribution.**
  If you have 5 gem slots or more
  and thus using [[item:240967]], you should use one of
  each color. Otherwise, you can just use any gem that sims best, or go
  [[item:240900]] as a safe default. See the list below
  for full details.

- Epic: 
  
  - With 5 sockets or more: [[item:240967]]
  - With fewer than 5 sockets: [[item:240983]]
- Rare with 5 sockets or more: 
  
  - 1x [[item:240892]]
  - 1x [[item:240906]]
  - 1x [[item:240900]]
  - 1x [[item:240916]]
  - Rest of slots [[item:240900]]
- Rare with fewer than 5 sockets: [[item:240900]] in all
      slots

<em>We highly recommend using [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to sim your character's
ideal gems and enchants, as they might differ from our general
recommendations.</em>

2.

### Best Enchants and Weapon Augments

You should be using [[item:243733]] as your weapon augment in all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm (non damage)</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders (non damage)</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240155]]</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>[[item:243957]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet (non damage)</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:244029]] </td>&#10;</tr>&#10;</table>

Not all enchants provide damage, like Helm, Shoulders and Feet, and instead you can
    choose between Speed, Avoidance or Leech for these slots. Speed
    is usually a solid choice, as you can move further during all of
    the instant cast spells like [[spell:44425]] or [[spell:153626]],
    and channeled spells like [[spell:5143]]. This allows you to save
    your quick mobility spells like [[spell:212653]] / [[spell:1953]]
    for when you need to move very suddenly due to a mechanic.
    However, Avoidance enchants are also a great option for
    these slots to simply reduce the damage you take from various enemy
    abilities. I generally do not recommend the Leech enchants for group content,
    but it can be quite nice for solo content.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

For Season 2, all secondary stat flasks are very close in DPS
  and the exact best Flask will differ based on your gear.
  [[item:241325]] is usually a safe choice to be best or close
  to best.

3.2.

#### Potions

[[item:241308]] is the best DPS potion for all content, while
[[item:271883]] is our healing potion of choice.

3.3.

#### Food Buff

[[item:255845]], or [[spell:1278895]] if you are doing
  content with frequent dying, like progressing a raid boss.

3.4.

#### Augment Rune

Augment Runes are often quite expensive, but do provide roughly a 1% DPS increase
  when used so they can be quite important when doing the hardest content.
  [[item:259085]] is the only available Augment Rune currently.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **17 Aug. 2026:** Updated best Flask.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Removed Tea mention since it does not work in instances.
- **16 Mar. 2026:** Updated ring enchants to use Eye of the Eagle instead of stat enchants as it is slightly better in almost all situations.
- **01 Mar. 2026:** Added Teas for their movement speed bonus to food section.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for 11.2.0.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Added Corruption Enchants section.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **11 Sep. 2024:** Added weapon consumable (oil).
- **09 Sep. 2024:** Added Elusive Blasphemite as an option for more movement speed at the cost of a small amount of DPS.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Added new head enchant (Incandescent Essence) and updated Phial suggestions
- **19 Mar. 2024:** Reviewed for Patch 10.2.6. and added explanation for best gems.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Removed references to Onyx Annulet and Primordial gems as they are no longer relevant for 10.2.
- **01 Oct. 2023:** Updated food buff suggestion.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated Onyx Annulet section for the 10.1.5 nerf and reviewed the rest for the Arcane rework in 10.1.5
- **01 May 2023:** Moved Primordial Stone information and updated advice based on 10.1 changes.
- **25 Mar. 2023:** Updated Primordial Stone Gem suggestions based on hotfixes.
- **22 Mar. 2023:** Update Primordial Stone Gem suggestions due to Desirious Blood Stone combinations being very strong.
- **21 Mar. 2023:** Updated Primordial Stone gem suggestions based on Obscure Pastel Stone being Arcane instead of Shadow on live servers.
- **20 Mar. 2023:** Added Primordial Stone gem suggestions and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **12 Jan. 2023:** Added spellthreads advice.
- **14 Dec. 2022:** Added weapon imbuement advice.
- **13 Dec. 2022:** Updated phial advice.
- **11 Dec. 2022:** Updated gems advice based on better simulations.
- **11 Dec. 2022:** Updated phial advice.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Arcane Mage in World of Warcraft Patch 12.1.5.

1.

### Arcane Mage in Mythic+ in Midnight Season 2

Arcane Mage has been a strong Mythic+ spec in recent years, and
    that is no different in Season 2.
    It has great AoE damage, while able to do very high priority target damage,
    better than almost any other spec in the game. It also
    comes with great utility and survivability, making it a very desirable
    spec to bring to any Mythic+ group.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

In Mythic+, your role as an Arcane Mage is to focus on killing high priority
    targets very quickly, while still doing great overall damage at
    the same time. This generally makes Arcane very valuable in any
    Mythic+ group.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury    Mythic+ Build

2.1.

#### Sunfury Mythic+ Build

This is the go-to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Mythic+ build, and also
    the strongest build available for Arcane in general. It combines
    both great AoE DPS with great boss DPS, without meaningfully having
    to compromise on either, making it a great Mythic+ pick.

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAmZmmlllZAAsBAwGMzMsZZGzsMjxMzMzwGzYGzAAMAAADwMDMzAghZmB"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYCgbhJJ-NbckEGRXKdoww6AHLYkJeAZZpp9FKZC-AAAA-DQko0IUY4ADwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger    Mythic+ Build

2.2.

#### Spellslinger Mythic+ Build

This is the go-to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/spellslinger.webp>) Spellslinger build for Mythic+. It is currently
    a bit weaker than the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury variant, but can still do relatively
    well, especially on AoE, where the difference is quite small.

:::talents 天赋构筑
```json
{
  "code": "C4DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzQzMzAAAwAAAAzMzssMzELAAsNYmZYzyMmxMGzMzMDbMjZMDAwAAAMzsBAzMAYYmZA"
}
```
:::

:::details 来源计算器编码
```
#+A-SVWWXdDXWYaEFhlJqms59diKgoEcYirZBAJ-NbckEGRXKdoww6AHLYkJeAZZpp9FCMB-AAAA-OQSaKMUwADQAxC-
```

:::

### Flexible Talents / Dungeon Specific Talents

2.3.

#### Flexible Talents / Dungeon Specific Talents

Depending on the Dungeon, there is a lot of flexibility when it comes to
    talents. The Mage tree has a lot of utility which
    can be either very good or completely useless depending on the dungeon,
    which allows you to switch between those utility spells or defensive talents as needed.

- Swap between [[spell:1244090]] or [[spell:1244087]]
          based on personal preference. Temporal Alignment a very simple passive
          heal when you get low, while Time Walk is better if you
          are good at proactively using [[spell:342245]].
- Spec in/out of [[spell:414664]] depending on if you need it to
          skip any packs.
- Spec in/out of [[spell:475]] depending on if you need to dispell
          any curses.
- Spec in/out of [[spell:30449]] depending on if you need to remove
          any enemy buffs.
- Spec in/out of [[spell:414659]] (and the nodes leading to it) depending
          on if you need the immunity of [[spell:45438]] for the dungeon you are
          doing.
- If you specced out of any of the nodes listed above, you can use the
          points to spec into one or some of the following: 
  
  - [[spell:1270827]]: Useful if you often need to
                    dispell the same target multiple times in a row but do not
                    want to give up too many global cooldowns on it.
  - [[spell:1270847]]: Useful if you often need
                    to dispell yourself and someone else at the same time,
                    but no one else. This is generally only recommended if there
                    is a second Curse dispeller in the group. Can be very
                    useful during [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) weeks
                    to quickly dispell yourself and one other person.
  - [[spell:386763]]: If you need to kite enemy packs.
  - [[spell:382293]]: For speedrunning content.
  - [[spell:210476]]: Can be combined with
                    [[spell:382293]] if you need even more movement
                    speed increases or enemy pack skips with full stealth groups.

3.

### In-Depth Rotation Tips for Mythic+

Listed below are some specific Mythic+ tips that can elevate your gameplay even further,
once you're already familiar with the regular Rotation from our Rotation section.

3.1.

#### Optimizing Movement and Downtime in Mythic+

One of the most important parts of your damage in Mythic+ will come from how
efficiently you move between packs and how you use the downtime between packs.
Below, we have some tips on how to manage this.

- Make sure you start the run with some water so you can generate mana out of combat if needed.
- Make sure you drink some water if you are low on mana while moving to the next
  pack. The easiest way to do this is to [[spell:1953]] or [[spell:212653]]
  ahead right after a pack dies and getting in 2 or 3 seconds of drinking.

4.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

4.1.

#### Interrupts

[[spell:2139]] is our go-to interrupt for most situations. Not only
    does it interrupt a spell, it also locks the enemy out of casting
    spells of the same school for 7-8 seconds, depending on talents.

To avoid having to switch targets, I highly recommend using either a mouseover
    or focus target macro. The macros below will kick your focus or mouseover
    target if you have one, or your current target if you do not.

#### Mouseover Counterspell

```wow-macro
#showtooltip
/cast [target=mouseover,exists] Counterspell; Counterspell
```

#### Focus Counterspell

```wow-macro
#showtooltip
/cast [target=focus,exists] Counterspell; Counterspell
```

4.2.

#### Stunning and "Stops"

[[spell:157980]] and [[spell:31661]] are the primary method of AoE
    interrupting enemies. You can only pick one, and which one you pick
    depends on the situation. Both of them will usually stop the enemy casts,
    but unlike [[spell:2139]], it will not stop them from immediately
    re-casting the same or a different spell.

Generally, Supernova is easier to use since it can be used without being near
    the enemies, but both are fine choices.

Additionally, [[spell:118]], [[spell:113724]] and [[spell:383121]]
    can be used to interrupt enemies as well (if talented), but in
    most cases the enemies will just immediately start casting again afterwards,
    so it should only be used as a last ditch effort. Polymorph also has the
    downside of it healing enemies.

### Other Utility

4.3.

#### Other Utility

[[spell:1459]] provides the whole group with bonus Intellect,
    increasing the DPS of yourself and other casters, as well as the healing
    of the healer.

[[spell:80353]] is a critical cooldown for any Mythic+ group. Every 10
    minutes
    it allows you to provide a massive haste buff to the group.

[[spell:475]] can be useful to dispel Curses in some
    dungeons. It should also be used to dispel [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>)
    if it is an active affix.

[[spell:30449]] can be used to remove magic buffs on enemies and
    grant them to you instead. Although in many cases, the buffs are not
    actually
    granted to you due to balancing reasons, so it is primarily used as an
    offensive dispel.

[[spell:110959]] can be used to completely drop aggro, while
    additionally it can sometimes completely cancel certain debuffs, targeted
    casts
    on you, or cancel various mechanics.

[[spell:386828]] allows you to remove snare/slow effects. It does
    this by entirely removing the debuff that causes the slow, which means
    it can occasionally be used to completely remove dangerous debuffs,
    if they also apply a slow.

[[spell:414664]] can occasionally be useful to skip certain packs.

5.

### Dealing with Affixes

Season 2 of Midnight has four rotating Affixes which require active play
    to deal with, called Xal'ataths Bargains. These rotate every week, with only
    one of them being active at a time. Most other Mythic+ affixes, like
    Fortified or Tyrannical, simply add a passive effect to the keystone, with
    these four exceptions that are themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that
          need to be interrupted or disrupted. You have multiple ways of dealing
          with these: [[spell:157980]] for AoE interrupt if they are close
          together, [[spell:2139]] for singular interrupts, and
          [[spell:30449]] for any remaining ones.
          Since Spellsteal has no cooldown (unless talented into
          [[spell:1270827]]), you can theoretically get rid of all of
          them, but this will take up a lot of time.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): Spawns a Void Emissary enemy which
          needs to be quickly killed. After it dies, you get a strong ability
          cooldowns and Versatility buff. Note: You can spread [[spell:12846]]
          to this target if it spawns close to the enemies you already have
          Ignite on, which can provide a lot of free damage to the add.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and
          circle around them. You have 15 seconds to soak all of these to buff
          your group. Simply run into them to soak them.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
          healing absorb. You can remove these with [[spell:475]].
          [[spell:1270847]] is very useful to quickly dispell yourself
          and one other player. Health potions or Healthstones also work well if
          your healer is out of resources.

When you successfully deal with these affixes, they grant you a beneficial
    buff, which differs per affix. These effects are usually quite strong, but
    not really played around. It is however very important to deal with them
    correctly, as failing to do so will buff the enemies which can very quickly
    wipe a group.

Note: These affixes go away when doing dungeons of a Keystone level of 12 or
    higher (both the positive and negative effects), instead causing deaths to
    deduct 15 seconds from the timer.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated utility section layout and added some additional context for interrupts and utility.
- **17 Mar. 2026:** Added priority DPS vs max AoE DPS section.
- **16 Mar. 2026:** Updated for Season 1 of Midnight: Updated best talents, flexible talents, added seasonal affixes, etc.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Trees for 12.0.1 tree changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated best builds for 11.2, added section for season 3 utility spells.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **22 Mar. 2025:** Removed wind up interrupt tip as they cannot be interrupted by disorients.
- **14 Mar. 2025:** Added tips for all dungeons.
- **24 Feb. 2025:** Updated best talents for 11.1 changes, updated affix tips for new affixes.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **22 Oct. 2024:** Updated talents based on last minute nerfs.
- **21 Oct. 2024:** Updated best talents for 11.0.5 rework. Added Spellslinger vs Sunfury information. Added dungeon specific tips.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6. and updated talent choice information.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated talents for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated suggested talents and rotation for reworked Arcane.
- **01 May 2023:** Removed mentions about thundering and reviewed for 10.1 changes.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7 and provided some small phrasing tweaks.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **16 Jan. 2023:** Updated suggested talents to Mana Gem build and some minor tip changes.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Arcane Mage in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Listed below is a collection of useful Macros for Mage, and Arcane Mage specifically, with
some of them being usable on all three specs, while others are only useful if you're playing
Arcane Mage.

1.1.

#### Specific Macros for Arcane Mages

1.1.1.

##### 1-Button Arcane Surge

#### 1-Button Arcane Surge

```wow-macro
#showtooltip Arcane Surge
/cast Ancestral Call
/cast Berserking
/cast Blood Fury
/cast Arcane Surge
/use 13
/use 14
/use 16
```

This will cast [[spell:365350]] and activate any Trinkets or Racial
    effects that provide damage.

1.2.

#### Generic Macros for Mages

Bear in mind when using any of the stopcasting macros that they will not
interrupt the Global Cooldown. If you are still on GCD your cast will be
canceled but the next ability will not go off until you are off GCD.

1.2.1.

##### Stopcast Blink

#### Instant Blink

```wow-macro
#showtooltip
/stopcasting
/cast Blink
```

Pressing [[spell:1953]] will now cancel your current spellcast and
causes you to immediately Blink. Note that this should not be used with 
[[spell:212653]] as it will unnecessarily cancel your current cast, nor should
it be used if you are casting something that you can wait to finish casting
before needing to Blink

1.2.2.

##### 1-Button Block

#### 1-Button Ice Block

```wow-macro
#showtooltip
/stopcasting
/cancelaura Ice Block
/cast Ice Block
```

Cancels your current cast and immediately puts you in [[spell:45438]].
Pressing Ice Block again will cancel the effect. Not recommended if you spam your
buttons.

1.2.3.

##### Block Cancel

#### Cancel Aura Ice Block

```wow-macro
/cancelaura Ice Block
```

If you are a button spammer, you can put this on a separate keybind as your 
[[spell:45438]], allowing you to cancel your Ice Block early if you so
desire.

1.2.4.

##### Alter Time Cancel

#### Cancel Aura Alter Time

```wow-macro
/cancelaura Alter Time
```

You can use the above macro to cancel [[spell:342245]] if you do not want to
be teleported back to the location/health where you were when you initially cast
Alter Time.

1.2.5.

##### Mouseover Decurse

#### Mouseover Remove Curse

```wow-macro
#showtooltip
/cast [target=mouseover,exists] Remove Curse; Remove Curse
```

This will remove curses on whatever unit you are mousing over. You can replace
Remove Curse for any other spells you might want to do on mouseover,
like [[spell:30449]]. If you have no mouseover target, it will cast it
on your current target, or yourself if you have neither a mouseover or selected
target.

2.

### Best Addons

2.1.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) is a complete replacement of the default
User Interface. It comes with almost everything you need to perform properly:
action bars, unit frames, cooldown timers, proc displays, etc.

2.1.1.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) is a useful addon that allows you to track the cooldowns of other raid
members, as well as providing you with a wealth of other useful raid information.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated Arcane Surge Macro to have all relevant racials/trinket slots by default.
- **09 Mar. 2026:** Fixed mouseover macro for remove curse.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for 10.2.6, removed link to a no longer relevant pack and added new macro for Arcane Barrage + TOTM.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **28 Apr. 2023:** Added a generic weakaura pack containing all neccesary WeakAuras for all specs.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
