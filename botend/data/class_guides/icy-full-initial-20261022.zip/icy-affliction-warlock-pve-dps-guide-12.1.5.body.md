## 专精概览

欢迎来到我们的 痛苦 术士 攻略，适用于魔兽世界12.1.5版本。在这里，你将学习如何在团队副本和大秘境中游玩 痛苦 术士：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

痛苦 大秘境资源

[全新！顶级 痛苦 天赋构建](<https://raider.io/specs/affliction-warlock/talents>)

[顶级 痛苦 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warlock/affliction>)

[痛苦 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warlock--affliction>)

[热门 痛苦 团队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warlock--affliction>)

1.

### 痛苦 术士 概述

痛苦 术士 擅长维持单体和多目标伤害。你的大部分伤害来自施加有害的持续伤害效果（DoT）。这使他们能够有效地对分散在区域内的目标进行顺劈输出，而这是许多专精难以做到或无法做到的。与其他 术士 专精一样，痛苦 术士为团队带来了 [[spell:111771]] 技能，这是一个非常有价值的机动性冷却技能。

灵活的伤害输出

痛苦 术士 的伤害可以适应大多数战斗，拥有斩杀、快速转火、爆发和聚焦输出能力，冷却时间相对较短——通常为一分钟。小缺点是必须在第三道门的任一侧重投入单体或AoE天赋。

可靠的团队副本选择

在 至暗之夜 中，痛苦 术士 拥有更高的机动性和整体平衡的天赋配置，可以应对除了大量多目标以外的所有情况。预热时间已大幅缩短，快速转火能力现在与 毁灭 不相上下，同时通常拥有更好的冷却时间。

大秘境中表现全面

痛苦 在大秘境中是一个非常灵活的专精，在不同目标数量之间切换自如，拥有足够好的爆发和聚焦输出潜力。该专精拥有平衡的技能组合，介于 恶魔学识 更强的单体和 毁灭 在11个以上目标时更强的AoE之间，同时不存在任何地面目标AoE的缺点。

除此之外，至暗之夜 为 术士 职业带来了很多实用性，包括诅咒和AoE诅咒，以及所有职业中最高的生存能力之一。

高功能性

[[spell:111771]] 在团队副本环境中通常是必备的，而 [[spell:20707]] 和 [[item:5512]] 则为整个团队提供了不错的便利性收益。

然而在地下城中情况有所不同，传送门只用于偶尔的跳怪，灵魂石是需要施法时间的战斗复活，治疗石只是稍微好一点的药水。

诅咒的情况要好得多，提供AoE应用以及更强但有持续时间的瘟疫变体。宠物也可以被视为实用性的一部分，但实际上，这只是为了对目标使用地狱猎犬的 法术封锁 和 吞噬魔法，除非急需小鬼的驱散。

良好的机动性

痛苦 在冷却技能之外是一个相当灵活的专精，对于 术士 来说尤其如此。根据天赋配置，有多个触发效果可以留到移动间隙使用，同时刷新你的DoT。

名列前茅

术士 在 至暗之夜 中的生存能力非常出色。虽然该职业缺乏免疫或伤害反转工具，但主要机制是通过 [[spell:108370]] 的过量护盾、[[spell:108415]] 的减伤，以及 [[spell:108416]] 和 [[spell:104773]] 等主动防御法术来缓冲现有的生命值上限。

1.

### 痛苦 术士 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

本次补丁没有术士的改动，而是专注于两个新的终局内容：一个新团队副本和备受期待的迷宫巨型地下堡。请查看以下链接获取更多详情：

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

本次补丁延续了第2赛季的剧情和装备进度，专注于游戏体验优化、新的单人向内容，以及 [安其拉入侵](<https://www.icy-veins.com/wow/aqir-invasions-guide>)，还有更多！如果你对12.1.5版本及之后还有什么在等着你感到好奇，请务必访问我们的专题页面。

2.3.

#### 职业改动

12.1.5补丁中痛苦 术士没有改动，因此该专精最近的改动发生在第2赛季初期。装备页面已更新，加入了所有来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)的新物品，以及关于一旦[[item:280562]]可用后如何使用的建议。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1补丁改动 隐藏12.1补丁改动
8月25日的热修为痛苦带来了多项增强，使其更接近毁灭的正常水平，特别是在单体目标和团队副本场景中。虽然持续伤害也得到了提升，但痛苦在范围伤害方面目前仍是第三位。

[至暗之夜 8月25日热修](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-august-25/2336376/68>)

**术士**

<em>开发者说明：我们正在提升痛苦和恶魔学识的输出能力，主要专注于它们的单体目标技能，次要关注它们的多目标技能。此外，我们还大幅提升了术士恶魔的伤害，使它们对整体输出的贡献更大。这也有助于在单人游玩时减轻一些仇恨问题。</em>

- 小鬼、虚空行者、萨亚德和地狱猎犬的伤害提高350%。

**痛苦**

- 痛苦无常伤害提高15%。不适用于PvP战斗。
- 地狱召唤者 – 焦黑之魂伤害提高20%。不适用于PvP战斗。
- 纳特拉萨之怒伤害提高35%。不适用于PvP战斗。
- 纳特拉萨的暗影伤害提高25%。不适用于PvP战斗。
- 痛楚伤害提高20%。不适用于PvP战斗。
- 腐蚀术伤害提高15%。不适用于PvP战斗。
- 地狱召唤者 – 枯萎伤害提高10%。不适用于PvP战斗。

在12.1补丁到来之前，痛苦 术士收到了多项改动，影响了英雄和专精天赋树，并对专精和基础技能[[spell:108370]]进行了修复，现在它提供了一层更实质性的防御能力。

相对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者将使用场景转向带有优先伤害的单体目标，但在撰写本文时完全未达到目标，导致单体目标输出低于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者，并且按设计来说范围伤害和顺劈伤害严重更差。

[乌拉特克之诅咒 补丁说明](<https://us.forums.blizzard.com/en/wow/t/2317811>)

**地狱召唤者**

<em>开发者说明：我们正在更新焦黑之魂，为地狱召唤者提供一个更好的工具来将伤害集中到优先目标上，从而提升英雄天赋树的整体灵活性，而不是让它仅在多目标场景中表现出色。然而，我们保持了恶意的功能不变，使其仍然是地狱召唤者工具箱中一个很酷且有影响力的工具。</em>

- 焦黑之魂已被重新设计：如果目标受到你的枯萎影响，施放痛苦无常会使其层数增加1层。每次枯萎获得一层时，它都有机会坍缩，每1秒消耗一层对宿主造成暗影烈焰伤害，直到剩余1层。
- 佩洛萨恩之印已被重新设计：枯萎造成的伤害性暴击伤害为215%，而不是通常的200%。焦黑之魂造成的伤害性暴击伤害为225%，而不是通常的200%。
- 焦黑之魂伤害提高45%。
- 枯萎伤害提高25%。

天赋树的改动成功解决了与至暗之夜相关的两个主要问题：多目标场景中的碎片溢出，通过对[[spell:1260264]]的改动以及移除[[spell:1260271]]；以及第三层天赋中不对称的价值主张，其中右侧和[[spell:27243]]节点明显比[[spell:1259790]]选项更受欢迎。

[乌拉特克之诅咒 补丁说明](<https://us.forums.blizzard.com/en/wow/t/2317811/16>)

**痛苦**

<em>开发者说明：零号病人严重扭曲了腐蚀之种的伤害构成。腐蚀之种作为工具的具体使用场景是在多目标场景中提供伤害，而拥有增加优先目标伤害的能力会稀释其定位。享乐暴食是一个新天赋，它与吸取生命、生命虹吸和黑暗收割之间的生命汲取共同主题相连接。这个天赋的意图是让大部分输出来自生命虹吸和黑暗收割，而对吸取生命的提升则较小，带有一点风味性。</em>

- 新天赋：享乐暴食 – 召唤黑眼的伤害提高10%，生命虹吸现在额外使腐蚀术的伤害提高10%。黑暗收割引导速度提高10%，伤害提高15%。
- 零号病人已被移除。

<em>开发者说明：夜幕馈赠在术士如何使用其暗影之怒方面并没有提供太多选择。相反，无论目标数量如何，通常最好将其用于腐蚀之种。这对受益于暗影箭或吸取灵魂的天赋可能产生不利影响。不过我们喜欢偶尔免费获得腐蚀之种的感觉，并将该功能合并到碎片动荡中。我们用一个名为暴怒的新天赋取代了夜幕馈赠，它将成为痛苦获取额外优先目标伤害的另一种手段。</em>

- 新天赋暴怒：暗影箭、吸取灵魂和邪恶缠握的伤害提高10%，如果目标受到鬼影缠身影响则提高20%。黑暗收割的伤害提高10%，如果目标受到鬼影缠身影响则提高20%。
- 碎片动荡已被重新设计 – 暗影箭或吸取灵魂造成的伤害有20%的几率使你的下一个痛苦无常或腐蚀之种不消耗灵魂碎片并瞬发。
- 夜幕馈赠已被移除。
- 鬼影缠身现在使你对目标造成的伤害提高16%，持续18秒（原为12%）。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜 概述 痛苦 术士

资料片最突出的特点是巅峰天赋，它们将在升级过程中逐渐可用。这些点独立于天赋树存在，必须按顺序投入才能解锁后续的点。

1. [[spell:1261984]]
2. [[spell:1261990]]
3. [[spell:1261992]]

这些天赋主要提供背景力量，不影响输出循环本身。然而，它们在很大程度上是痛苦在短时间内硬切换目标能力的关键，从而帮助完善了该专精的工具箱。

2.5.

#### 改动总结

- **英雄天赋** 获得了基础的小幅改动，并新增了第四列。
  
  
  
  
  ► **点击展开**
  
  
  
  
  2.5.1.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者
  
  
  
  
  - [[spell:440055]]被改为支持[[spell:1260264]]天赋
  - 新天赋：[[spell:1266799]]提高基础碎片消耗技能的伤害，在[[spell:430014]]期间效果翻倍
  - 新天赋：[[spell:1266805]] [[spell:445465]]有几率触发[[spell:430014]]
  - 新天赋：[[spell:1266803]] [[spell:430014]]提供额外的急速，施放该技能会叠加更多[[spell:445465]]层数
  
  
  
  
  2.5.2.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者
  
  
  
  
  - [[spell:449638]]现在从[[spell:1257052]]触发，因为灵魂腐化已被弃用
  - 新天赋：[[spell:1268884]] 每消耗一个甘露之魂，都有几率触发[[spell:1239714]]对10码范围内的所有目标造成额外伤害
  - 新天赋：[[spell:1268889]]按百分比提高精通，当[[spell:449614]]触发时效果翻倍
  - 新天赋：[[spell:1268903]]提高[[spell:1268884]]的持续时间和伤害
- 核心/循环技能发生了重大改动 **痛苦 术士** 法术进行了几项改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:1259790]]是基础的单体目标碎片消耗技能
  - [[spell:324536]]已被移除
  - [[spell:386997]]、[[spell:278350]]和[[spell:205179]]因此已被移除
  - [[spell:1257052]]是一个新的1分钟冷却技能，对每个受到至少1个基础持续伤害效果影响的目标造成伤害
  - [[spell:980]]现在最多6层，通过[[spell:1260209]]预热时间大幅降低
  - 为了在每次施放时叠加超过1层[[spell:980]]，引入了[[spell:1259825]]
  - [[spell:205180]]是一个基础的单体目标法术，作为伤害放大使用，现在有[[spell:1261149]]和[[spell:1280733]]等支持天赋
  - [[spell:27243]]是主要的范围碎片消耗技能，并获得了[[spell:196226]]、[[spell:1260285]]和[[spell:1260271]]等支持天赋来提升其输出
  - [[spell:234876]]的伤害加成提高了三倍
- 术士的辅助法术也发生了一些值得注意的改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:1714]]和[[spell:334275]]现在是独立的天赋
  - [[spell:1265813]]已被添加，使每个诅咒也能影响主目标周围10码内的敌人
  - 引入了灾祸，提供了比诅咒更强大的版本，持续时间和冷却时间更短
  - [[spell:5484]]现在是与[[spell:30283]]的选择节点，并有[[spell:1270255]]这个新的支持天赋，减少其冷却时间并影响最多10个目标
  - [[spell:755]]已被移除，其治疗效果被添加到[[spell:234153]]并配合[[spell:1265810]]

1.

### 痛苦 术士游戏基础

痛苦 术士是一个以持续伤害效果、需要预热才能最大化收益的冷却技能，以及一定量的宠物管理为核心的专精。其核心玩法围绕着生成和消耗术士的标志性资源：灵魂碎片。

基本原理很简单：在目标身上保持[[spell:172]]和[[spell:980]]，将你的灵魂碎片用于[[spell:1259790]]或[[spell:27243]]，并在空闲时间施放[[spell:232670]]。这三个概念以精炼的形式概括了一切。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_curseofsargeras.jpg>) **保持痛楚滚动**
  
  
  
  
  [[spell:980]]是痛苦灵魂碎片的主要来源，因此根据目标数量尽量保持4-5个痛楚在滚动非常重要，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **消耗那些灵魂碎片**
  
  
  
  
  术士是一个围绕生成和消耗资源理念设计的职业。作为痛苦，消耗灵魂碎片还能通过[[spell:453056]]减少[[spell:1257052]]的冷却时间。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) **使用你的短冷却技能**
  
  
  
  
  [[spell:48181]]和[[spell:1257052]]冷却时间很短，应尽可能多地施放，因为它们是带有重置或冷却缩减机制的强大法术。

1.

### 如何为痛苦 术士配装

虽然我们始终建议你自己进行模拟以获得理想结果，但我们确实提供了一个专门的痛苦配装页面。我们目前涵盖了当前赛季装备的建议，以便在至暗之夜终局内容发布时有一个良好的开端。在你获得一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了饰品列表。
- **2026年8月31日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 更新了地狱召唤者天赋。
- **2026年8月31日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新循环章节。
- **2026年8月31日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 更新了地下城天赋建议。
- **2026年8月25日（本页）：** 已更新至8月25日热修。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了最佳配装列表、美化和饰品，以适应新的属性配置和饰品调整。
- **2026年8月16日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了消耗品以反映新的最佳配装列表。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了宝石和常见问题解答部分。
- **2026年8月11日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更换了药剂并更新了宝石。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 更新了天赋选择。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为12.0.7补丁添加了全知卷册。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年3月30日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 更新了单体目标天赋建议。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了茶部分。
- **2026 年 3 月 23 日（本页）：** 更新了大秘境可行性部分。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了饰品排名以考虑凝视的削弱。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 扩展了套装奖励部分。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 添加了一个用于升级到至暗之夜的80级导入方案。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为至暗之夜的发布更新了天赋树。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为 至暗之夜 发布进行了更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜的发布更新了输出循环并添加了巅峰部分。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜的发布更新了天赋树并添加了巅峰部分。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 为 至暗之夜 版本添加了巅峰天赋。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为 至暗之夜 版本添加了巅峰天赋部分并更新了天赋。
- **2026年2月26日（本页）：** 为 至暗之夜 版本更新了性能和巅峰天赋部分。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为 11.2.7 补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月22日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对11.2补丁进行审阅。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 根据调整更新了暗影牧师的插槽推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为 11.1.7 补丁和暗影牧师进行了更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了战斗助手部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 添加了战斗助手部分。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月4日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2025年3月19日（[解放安德迈页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了天赋推荐。
- **2025年3月4日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表和饰品排行。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为 11.0.7 补丁和赛尔西的指环进行了更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了天赋推荐。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 重新制作了页面布局，并相应地更新了各部分。
- **2024年9月19日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为 11.0.5 补丁进行了更新，并添加了地下城提示部分。
- **2024年9月12日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔和磨刀石。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 添加了第1赛季毕业装备列表，更新了饰品部分。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了宝石部分，因为策略发生了变化。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 针对第1赛季上线更新了天赋选择。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 更新了第1赛季天赋推荐。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 更新了强度评估以反映第1赛季状况。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 添加了探宝地下城天赋推荐。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 添加了升级玩法风格部分。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 添加了赛季前毕业装备列表部分。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了英雄天赋部分和选择器。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 更新了推荐以包含英雄天赋树。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 更新了各部分以考虑英雄天赋。
- **2024年8月21日（本页）：** 更新了优劣势和强度评估部分。
- **2024年8月1日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 添加了无湮灭天赋变体。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/affliction-warlock-mists-of-pandaria-remix-guide>)):** 页面已针对《地心之战》前夕补丁进行更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月19日（[地心之战](<https://www.icy-veins.com/wow/affliction-warlock-the-war-within-pve-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月19日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年6月19日（[地心之战](<https://www.icy-veins.com/wow/affliction-warlock-the-war-within-pve-guide>)):** 页面创建。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/affliction-warlock-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 为 10.2.7 补丁进行了更新。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为第4赛季上线进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对10.2.6进行审查。
- **2024年3月19日（本页面）：** 已针对10.2.6进行审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为 10.2.5 补丁更新了饰品部分。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年11月28日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 在4件套修复后更新了多目标部分。
- **2023年11月24日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 移除了过时的内容。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 在波纹孢子斗篷被削弱后更新了美化推荐。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为10.2版本进行了审查。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为 10.2 补丁和第3赛季更新了装备推荐。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为 10.2 补丁更新了天赋。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为10.2版本进行了审查。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 重新格式化了页面，包含毕业装备表格和部分更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 重构了天赋部分。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7补丁更新
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 针对10.1.5补丁更新了天赋。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为 10.1.5 补丁更新了选择器。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为 10.1.5 补丁更新了天赋。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对 10.1.5 补丁的天赋变更进行了更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为 10.1.5 补丁更新了天赋。
- **2023年7月10日（本页）：** 添加了 10.1.5 补丁并更新了强度评估部分。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已更新至10.1补丁。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 在腐化之怒增益后更新了药水推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为 10.1 补丁审查了天赋。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为 10.1 补丁进行了审查。
- **2023年5月1日（本页）：** 为 10.1 补丁添加了新部分并更新了强度评估部分。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了黑龙戒指部分以考虑正式服的在线修复。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐以考虑额外的正式服在线修复。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐以考虑25%增益的在线修复。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 针对10.0.7补丁更新了天赋树。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/affliction-warlock-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 添加了 10.0.7 补丁新戒指部分。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 为 10.0.7 补丁添加了原始宝石部分。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为 10.0.7 补丁更新了天赋。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 更新了天赋树以反映 10.0.7 补丁的职业和专精变更。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（本页）：** 添加了 10.0.7 补丁并更新了强度评估部分。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 为 10.0.5 补丁更新了天赋。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 为 10.0.5 补丁更新了天赋。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对 10.0.5 补丁的天赋变更进行了更新。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 已更新至10.0.5补丁。
- **2023年1月11日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式和黑暗猎犬部分。
- **2023年1月7日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 将地下城药水更新为更可靠的微温全能药水。
- **2022年12月23日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 更新了天赋树。
- **2022 年 12 月 14 日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器符文。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 更新了美化推荐。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已为第一赛季上线更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式和优先级列表的选择器。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/affliction-warlock-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/affliction-warlock-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/affliction-warlock-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/affliction-warlock-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年3月10日（[9.2版本分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-2-changes-analysis>)):** 更新以反映套装奖励增益。
- **2022年2月22日（[9.2版本分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-2-changes-analysis>)):** 更新以反映 9.2 补丁上线。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** 针对9.1.5补丁更新。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** 移除了PTR免责声明。
- **2021年6月27日（[9.1 补丁分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** 基础变更，更新了传说装备和盟约推荐。
- **2021年5月5日（[9.1 补丁分析](<https://www.icy-veins.com/wow/affliction-warlock-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** 更新了首领提示和天赋/精华选择。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 在最近的团队副本削弱后进行了更新。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月11日（[达萨罗之战页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了更好的天赋选择和更多提示。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** 为 8.1 补丁进行了更新。审查了所有天赋建议。
- **2018年10月30日（[奥杜尔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** 更新了奥迪尔首领建议。
- **2018年9月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-uldir-raid-guide>)):** 为奥迪尔进行了更新。

显示更多

显示更少

:::

## 练级

在此页面上，您将找到我们的逐级 痛苦 术士 升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[术士 升级指南](<https://www.icy-veins.com/wow/warlock-leveling-guide>).

1.

### 痛苦 术士 升级指南，适用于 至暗之夜

痛苦 术士 作为持续伤害专精，提供了非常高效的升级体验：在移动到下一个目标或区域的同时，使用 [[spell:980]] 或 [[spell:172]] 为多个怪物上标记。持续伤害加上宠物，通常足以让目标在能够被范围法术终结之前就已身受重伤，甚至直接死亡。

诅咒、群体控制和宠物副坦克可以大幅减少受到的伤害，从而促进激进的打法，而所有的个人防御性冷却技能即使在拉多怪时也能提供一定程度的安全保障。

面对更大的敌人，例如精英或稀有怪，维持虚空行者的生命通常是首要任务，同时慢慢削减它们的血量，因为宠物产生的仇恨无法与重消耗技能的爆发伤害相匹配。

1.1.

#### 升级装备选择

升级时，应始终选择物品等级最高的装备。如果物品等级相同，则应选择属性最有利于你专精的装备。如果你当前的装备是传家宝，则不应更换。

虽然传家宝最重要的方面是经验加成，但为了最大化其属性收益，你应该优先考虑智力，然后是急速，然后是暴击。其原因在于，急速通常能提供更流畅的战斗体验，并以均匀的方式提升你的DPS，而暴击虽然同样重要，但本质上不够稳定。

能够更快施法提供了更快标记怪物的优势，而且当大多数动作都更快完成时，整体感觉会更好。

1.2.

#### 至暗之夜升级实用消耗品

以下列出了几种可以用来加快升级进程的消耗品，无论数值调整如何，它们通常都是有益的。

《地心之战》的附魔在升级过程中仍然有效，并可以帮助提升角色速度。优先考虑以下附魔：

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

战斗药水能提供爆发性的力量，如果有什么区别的话，最好在它们于满级变得无关紧要之前使用它们。

这些消耗品主要用于加快穿越和导航速度。

- [[item:109076]]
- [[item:132516]]或[[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]]或[[item:133576]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 痛苦 80级 至暗之夜 升级
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAYMjZGNLmx2MzYWGAAwMzsMbzMzyYAgx2yADYAzwWghtBAAADAAAMmZYMzYGMzMzYYGjBAMAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZxM2mZGzyAAAmZmlZbmZWGDAM2WGYADYG2CMsNAAAYAAAMzMmZYWmhZMmZmZMMjxAAGwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITVVUUHDPfiklbLMOJSD80kw01ZkdF1ZURB-JdKBIcLMy44spNQQCQM6wDS4DLMsyqA-AAAA-JEUocE0YAJQDzC-
```

:::

2.1.

#### 升级用战争模式天赋

1. [[spell:221711]]会在受到你[[spell:234153]]伤害的敌人身上叠加一个减伤效果。你可以使其伤害降低最多25%，这将大幅提升你的生存和续航能力。
2. [[spell:234877]]激活时，会使持续伤害效果额外触发一次，造成其原始伤害的20%。这能在短冷却时间内提供少量额外的爆发伤害。
3. **等级 30 起：**[[spell:335052]]在多目标战斗中非常出色，因为[[spell:1259790]]现在是我们伤害最高的持续伤害技能。
4. **等级 49 起：**在无法使用坐骑的封闭空间中，应始终考虑使用[[spell:248855]]来加快你的移动速度。
5. **等级 55 起：**在风筝目标时，[[spell:353753]]可以提供额外的范围爆发伤害。
6.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1 起：**从1级开始，你只有一个主要攻击技能：[[spell:232670]]。

1. **等级 11 起：**保持目标身上的[[spell:980]]。在给怪物上标记时，优先使用它而不是[[spell:172]]。
2. **等级 17 起：**对主要目标施放[[spell:48181]]。
3. **等级 13 起：**如果有1到2个目标，将灵魂碎片用在[[spell:1259790]]上。考虑对濒死的敌人施放它，以在此过程中获得1个灵魂碎片。
4. **等级 33 起：**在与你交战的每个目标身上都至少有一个持续伤害效果后，施放[[spell:1257052]]。
5. **等级 2 起：**当连发几发暗影箭无法更快地击杀它们时，使用[[spell:172]]来标记并削弱多个敌人。
6. **等级 37 起：**在尽可能多地施加持续伤害效果后，施放[[spell:205180]]。
7. **等级 15 起：**当有3个或更多目标时，施放[[spell:27243]]。

:::details 小贴士：治疗你的恶魔
不要忘记在战斗中使用[[spell:234153]]配合[[spell:1265810]]来保持你的恶魔的生命值。

:::

:::details 小贴士：不要低估诅咒！
随着[[spell:1265813]]的引入，诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

1.

### 升级时的宠物选择

[[spell:688]]是你第一个可用的恶魔，但最适合团队副本环境。这个宠物对升级来说不是特别有用，但在早期等级你别无选择。

如果你是单人升级，[[spell:697]]在升级过程中是一个不错的选择，因为它能为你分担很多压力。避免施法被打断也能提高升级速度。

如果你在组队升级或进入地下城，[[spell:691]]可能是一个不错的选择。额外的打断技能对于处理麻烦的施法怪物很有帮助。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月2日：** 添加了一个用于升级到至暗之夜的80级导入方案。
- **2026年2月26日：** 为至暗之夜的发布更新了天赋树。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为 11.2.7 补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 添加了升级玩法风格部分。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月24日：** 移除了过时的内容。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 针对10.0.7补丁更新了天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5补丁中，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，轻松游玩痛苦术士，同时不牺牲性能。

1.

### 痛苦术士基础

本节面向游戏或职业新手、无意参与史诗难度团队副本，或希望以更直接的方式游玩其专精的玩家，而无需被优化输出所需的众多优先级和主动技能所淹没。

痛苦是一个围绕在活跃目标身上维持持续伤害效果的专精。虽然它可能按键不多，但需要密切关注冷却时间和覆盖率，且复杂程度会随目标数量增加。尽管如此，它适合所有水平的玩家，你可以将其简化为一套简单的优先级。以下列出了三条简单规则，帮助你理解该专精。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_curseofsargeras.jpg>) **保持痛楚滚动**
  
  
  
  
  [[spell:980]]是痛苦灵魂碎片的主要来源，因此根据目标数量尽量保持4-5个痛楚在滚动非常重要，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **消耗那些灵魂碎片**
  
  
  
  
  术士是一个围绕生成和消耗资源理念设计的职业。作为痛苦，消耗灵魂碎片还能通过[[spell:453056]]减少[[spell:1257052]]的冷却时间。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) **使用你的短冷却技能**
  
  
  
  
  [[spell:48181]]和[[spell:1257052]]冷却时间很短，应尽可能多地施放，因为它们是带有重置或冷却缩减机制的强大法术。

1.

### 痛苦 术士在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者新手天赋

2.1.

#### 痛苦 术士新手全能天赋

此构建针对易用性进行了优化，同时提供了一个适用于任何情况、无需调整的配置，包括团队副本、大秘境甚至地下城。就输出而言，这并非单体或多目标的最优选择，但它作为一个构建，可以帮助玩家在转向我们天赋页面中更专精的构建之前，先熟悉专精的核心。

[痛苦 术士天赋与专精页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spec-builds-talents>)

要直接在游戏中导入这个全能构建，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAgZmZGNLmxiZGzyAAAMjlZbmZWGDAM22GYADYGWCMsNAAAMDAAgZmxMjZ2mZMjxMzMjhZmxAAGwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPfhiklnELM028MTjchprrowwJbM-JKcdBILMy44sJS4ISSbCz7LMEqyS4pA-AAAA-HIOQ0AEUYhhCzC-
```

:::

### 痛苦 术士基础循环

2.2.

#### 单体输出循环

1. 保持[[spell:980]]持续伤害效果。
2. 保持[[spell:172]]持续伤害效果。
3. 冷却完毕时施放[[spell:48181]]。
4. 当你拥有5个灵魂碎片时施放[[spell:1259790]]（以避免浪费碎片）。
5. 冷却完毕时施放[[spell:1257052]]。
6. 将[[spell:198590]]作为填充技能使用。

:::details 常见问题：我应该使用什么宠物/恶魔？
在地下城和大秘境中，我们推荐使用/牺牲地狱猎犬，因为打断技能在这样的环境中非常宝贵。这在高层大秘境中尤为重要，因为某些法术可能导致团队灭团。

在团队副本环境中，如果战斗要求使用[[spell:89808]]或需要频繁切换目标，我们推荐使用小鬼。

虚空行者推荐用于升级，或在你计划使用[[spell:108503]]但不需要地狱猎犬打断技能的环境中使用。牺牲虚空行者会为玩家授予[[spell:17767]]技能，这是一个防御性冷却技能，能提高玩家的生存能力。

魅魔通常比小鬼或地狱猎犬提供略高的伤害，如果你喜欢其视觉效果，或需要对单个目标施加永久的50%减速，可以使用它。

:::

2.3.

#### 多目标循环

当至少两个目标聚在一起时，你应始终使用[[spell:27243]]作为主要的碎片消耗技能，并配合[[spell:108558]]触发效果。对所有目标（最多5个）保持[[spell:980]]，以产生灵魂碎片并造成伤害。

尽量对[[spell:1260264]]触发效果做出反应，以便利用免费的[[spell:1259790]]。

记得在大流行窗口内刷新[[spell:980]]，以尽可能提高效率。

如果目标即将死亡，使用[[spell:198590]]来轻松地从它们身上获得一个碎片。

:::details 小贴士：治疗你的恶魔
不要忘记在战斗中使用以下技能保持你的恶魔的健康

[[spell:234153]]

使用

[[spell:1265810]]

.

:::

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

2.3.1.

##### 巅峰天赋： ![Shadow of Nathreza Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_raidtrinkets_blobofswirlingvoid_gold.jpg>) 暗影之纳特雷扎

[[spell:1261984]]的任何等级都会直接和间接地提高[[spell:48181]]的伤害，无需额外考虑，因为它已经是应该冷却完毕就施放的最有价值的法术之一。

2.3.2.

##### 第2赛季套装

第2赛季的套装奖励提供被动伤害提升，并在范围伤害中提供更多的优先伤害。

### 痛苦 术士属性优先级

2.4.

#### 痛苦术士属性优先级

目前，你应按以下顺序优先考虑次要属性。关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>).

装备等级

急速

暴击

精通

全能

### 暴风雪战斗助手

2.5.

#### 痛苦术士战斗助手

该 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 包含两个主要功能：

- **辅助高亮：** 显示下一个要排队的法术，在单体目标上提供足够准确的输出循环，在多目标上功能有限，最适合用来熟悉专精的流程和节奏。
- **单键助手：** 允许使用单个输入来执行辅助高亮提示的多个技能序列，代价是更长的基础公共冷却时间（这会导致额外5%到10%的每秒伤害损失）。

**值得指出的是，这些工具首先是辅助功能，不应被视为学习专精及其背后逻辑的直接替代品。**

战斗助手在痛苦术士方面表现最吃力的场景有：

- 持续伤害覆盖率，因为没有支持大流行机制的逻辑，在多目标中尤其令人烦恼。
- 多目标，因为它无论情况如何都考虑所有目标聚在一起。
- 冷却时间使用，因为它要么缺失，要么在进入特定冷却时没有准备工作。

2.6.

#### 战斗助手小贴士

- 冷却时间对齐必须手动完成，特别是考虑到种族技能、药水和主动使用装备。
- 持续伤害效果应在大流行范围内刷新，因为盲目遵循战斗助手会导致覆盖率大大降低。
- 在多个目标距离较远的情况下，考虑手动施加[[spell:172]]或[[spell:445465]]，而不是在建议时使用[[spell:27243]]。
- 一般来说，尽量最大化施法时间，特别是在使用单键助手时，因为停机时间是游戏任何阶段的改进领域之一。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为 至暗之夜 版本添加了巅峰天赋部分并更新了天赋。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 更新了各部分以考虑英雄天赋。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为 10.1.5 补丁更新了天赋。
- **2023年5月1日：** 为 10.1 补丁进行了审查。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月23日：** 更新了天赋树。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到魔兽世界12.1.5版本中痛苦术士的最佳天赋。我们还提供了适用于团队副本或大秘境等不同类型内容的默认天赋配置。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 痛苦术士最佳至暗之夜天赋

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者是首选的主流选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者的重做遗憾地伴随着较差的数值调整，因此对于痛苦来说并不是一个真正有吸引力的选择。虽然仍有一些根据个人偏好和具体情况调整的空间，但以下是我们目前的推荐：

- **单体目标**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者的单体伤害高出约2%，当顺劈少量目标或战斗中需要快速AoE爆发时，其优势会进一步扩大。
- **群体伤害**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者在任何地下城环境中都更优，因为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者的重做严重削弱了其AoE能力。

**快速开始导入代码：**

:::talents 痛苦单体 - 灵魂收割者
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZ2mZmlxAAjllBGwEMDbBG2GAAAmBAAwMDzMjBzwMzMzMGMzMzAAmBG"
}
```
:::

:::talents 痛苦AoE - 灵魂收割者
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYCmhtADbDAAAzAAAYmZMzwsxwYmZmZYYmZmBAMDMA"
}
```
:::

:::talents 痛苦地下堡 - 灵魂收割者
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgxyyADYAzwWghtBAAgZAAAMzMmZY2GjZwMzMMMzMzAAmBG"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

灵魂收割者

单体目标

推荐

秘境+

推荐

地下堡

地狱召唤者

秘境+

### 天赋方案 0-0

1.1.

#### 单体目标天赋

作为痛苦的单体 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者的核心思路是积极消耗灵魂碎片以缩短[[spell:1257052]]的冷却时间，同时尽量保持[[spell:1261124]]的高覆盖率。

### 天赋方案 0-1

1.2.

#### AoE/大秘境 灵魂收割者天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 在大秘境中，灵魂收割者能提供更好的整体伤害和更快的游戏节奏。

英雄天赋鼓励玩家快速且频繁地消耗碎片，以尽可能多地利用[[spell:1257052]]施放。

由于碎片充足，[[spell:198590]]的碎片补刀不再那么重要，转而使用[[spell:686]]可以提供更好的机动性。

### 天赋方案 0-2

1.3.

#### 地下堡天赋

英雄天赋不会有太大区别，但是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者拥有更好的防御技能，操作更流畅，并且凭借[[spell:449637]]、[[spell:449634]]和[[spell:449631]]均可由[[spell:48181]]触发，从而拥有更优秀的短爆发循环。

### 天赋方案 1-0

1.4.

#### AoE/大秘境 地狱召唤者天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者在地下城中是以[[spell:430014]]为核心的1分钟伤害循环，具有更高的爆发潜力，并强调尽可能让尽可能多的目标保持[[spell:980]]的覆盖，因为碎片的生成速度相对较慢。

可以将[[spell:1279521]]换成[[spell:1260209]]，以更容易地维持[[spell:980]]的覆盖，但会牺牲一些整体伤害。

可以将[[spell:453080]]换成[[spell:198590]]，以便更多地进行碎片斩杀。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZhhZmZmlBAAYmZZ2mZmlxAAjllBGwAmhtADbDAAAzAAAYmhZmxgZYmZmZGDmZmZAAzAD"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfgiklnoELM08MTtuw01JUUYkB-JKcdBILe2IUYkxxRTc4IzDEcEai6CTA-AAAA-HIOQ2AEQQhhCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYAzwWghtBAAgZAAAMzMmZY2YYMzMzMMMzMzAAmBG"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-JKcdBILe2IUYgxxRTc4IzbEAaCLMUwC-AAAA-HIOQ2AEUQhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgxyyADYAzwWghtBAAgZAAAMzMmZY2GjZwMzMMMzMzAAmBG"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-JKcdBILe2IUYgxxRTc4IayLMcEAqySA-AAAA-HIOQ2AEQQhhCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAmxsMLzMzyYAALwAziRjZAMbglBAAgBAAMzgxMzY2YYmZMzMmhZmZGAwMwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPfgiklnoELM028MTjehprTwwJbM-JKcdBILe2IUYgxxRc4IbEYCzDEMM06C-AAAA-IQSU2AIQYgxBzC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)万卷书是一种新的玩家力量来源，会在数周内逐步解锁，并提供一系列小而灵活的加成选择，可随时更换以匹配所需的内容。符文的选择可以量身定制以提供输出，也可以转向生存能力和实用性。

以下是推荐的指南，逐点列出：

1. [[spell:1279599]]
2. [[spell:1279603]]或[[spell:1279604]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279615]]和[[spell:1279614]]提供相似的输出

:::details 常见问题：哪个副属性符文最好？
术士的默认选择是

[[spell:1279609]]

。如果你不知怎么设法让暴击几率超过35%而忽视了精通，可以考虑使用

[[spell:1279612]]

.

:::

1.

### 巅峰天赋： ![Shadow of Nathreza Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_raidtrinkets_blobofswirlingvoid_gold.jpg>) 暗影之纳特雷扎

在至暗之夜练级期间可用，这些天赋与专精树的其余部分分开，需要后续投入点数才能解锁更高的等级。

1. [[spell:1261984]]
2. [[spell:1261990]]
3. [[spell:1261992]]

这些天赋增强了鬼影缠身的伤害和伤害增幅，但不会改变该法术的使用方式，因此按冷却时间施放该法术的标准行为不受影响。

1.

### 英雄天赋

英雄天赋在71级可用，是互斥的天赋树，你可以选择它们来略微改变游戏方式和视觉效果。痛苦术士可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者围绕暗影烈焰伤害和更强力的持续伤害效果设计。[[spell:445465]]取代了[[spell:172]]，并能在[[spell:440043]]中产生第二个暗影烈焰持续伤害效果。该英雄天赋树提供了一种更有条理的碎片消耗方式，[[spell:430014]]每分钟强化一次爆发窗口。

在实用性方面，[[spell:440057]]提供一个对近战和施法者敌人都有效的减益效果，无需进行选择，并且在12.0版本中加入[[spell:1265813]]后尤其重要。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者的核心理念是极具侵略性地消耗碎片，以从触发的各种持续伤害效果中获益，并通过[[spell:449637]]产生更多[[spell:108558]]触发。

在实用性方面，[[spell:449701]]保证了更强的治疗石而无需灵魂燃烧碎片，[[spell:449703]]增强了主动减伤能力，[[spell:389623]]使[[spell:20707]]与其他复活法术持平。

1.

### PvP天赋（战争模式）

在我们的天赋部分，有一个启用“战争模式”的选项。启用战争模式可提供以下好处：

- 在户外世界启用PvP天赋
- 在最高等级时，世界任务奖励提高10%
- 升级时获得的经验值提高10%
- 赚取征服点数，每周可兑换装备奖励

鉴于启用战争模式对练级和PvE内容的好处，你应该启用此功能。在大多数情况下，尽管存在风险，这将让你获得最大收益。你会使自己可以被开放世界PvP，而在练级或做世界任务时存在被“偷袭”的可能。

5.1.

#### 最佳战争模式天赋

在本节中，我们将对最适合练级和进行单人/小队PvE内容的PvP天赋进行排名。以下是通用PvP天赋和痛苦术士专属PvP天赋的排名。

1. [[spell:221711]]在被你的[[spell:234153]]伤害的敌人身上叠加一个减伤效果。你可以将它们的伤害降低最多25%，这大大提高了你的生存和续航能力。
2. [[spell:353753]]允许你将目标从标记位置拖走来进行爆发。
3. [[spell:248855]]将你的传送门射程增加20码，并将使用它的玩家身上的减益效果持续时间缩短15秒，使其成为需要更高机动性时的良好选择。
4. [[spell:212295]]召唤一个持续3秒的护盾，反射所有以你为目标的有害法术。
5. [[spell:201996]]只在应对大量施法小怪时才有意义。
6. [[spell:335052]]将[[spell:1259790]]的目标上限提高到3个。
7. [[spell:201996]]守护一个位置20秒；在范围内施法的敌人将受到最多相当于其最大生命值5%的伤害。这在大多数情况下的用途更为有限，但在特定情况下可能具有极高的价值。
8. [[spell:212371]]在承受高额持续伤害的情况下会很方便。将其与[[spell:221711]]结合使用，可显著提高你的生存能力和续航能力，并为单刷困难内容打开许多大门。
9.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月31日：** 更新了地下城天赋建议。
- **2026年8月11日：** 更新了天赋选择。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 为12.0.7补丁添加了全知卷册。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月30日：** 更新了单体目标天赋建议。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜的发布更新了天赋树并添加了巅峰部分。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 更新了第1赛季天赋推荐。
- **2024年8月26日：** 添加了探宝地下城天赋推荐。
- **2024年8月21日：** 更新了推荐以包含英雄天赋树。
- **2024年8月1日：** 添加了无湮灭天赋变体。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为 10.2 补丁更新了天赋。
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月10日：** 为 10.1.5 补丁更新了天赋。
- **2023年5月1日：** 为 10.1 补丁审查了天赋。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为 10.0.5 补丁更新了天赋。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标情况下优化你的痛苦术士的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以使你的DPS最大化。我们的所有内容均已针对《魔兽世界》12.1.5版本更新。

1.

### 痛苦术士手法与循环指南

欢迎来到我们的痛苦术士循环页面。在本页中，你将找到关于在团队副本和大秘境场景中实际操作该专精所需了解的一切。

如果你还没有，请阅读
[法术总结页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-spell-summary>)。详细了解每个法术/技能的工作方式，将极大地增进你对本页所述主题的理解。

1.

### 痛苦术士输出循环

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者

单体目标

群体伤害

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:453080]]

[[spell:198590]]

[[spell:48181]]

[[spell:1257052]]

[[spell:205180]]

[[spell:1260264]]

[[spell:1261149]]

[[spell:196226]]

### 单体目标

2.1.

#### 单体目标优先级

痛苦术士的目标是将一系列持续伤害效果施加到目标身上，穿插触发效果并将碎片作为资源进行管理。大部分优化围绕着在保持你激活效果的同时，确保正确消耗灵魂碎片。

1. **适用条件：灵魂收割者（启用）。** 始终维持你的[[spell:980]]和[[spell:172]]效果。
2. **适用条件：地狱召唤者（启用）。** 始终维持你的[[spell:980]]和[[spell:445465]]效果。
3. 如果你的灵魂碎片已满，则施放[[spell:1259790]]。
4. **适用条件：鬼影缠身（启用）。** 可用时立即施放[[spell:48181]]。
5. **适用条件：地狱召唤者（启用）。** 按冷却时间施放[[spell:430014]]。
6. **适用条件：灵魂收割者（启用）。** 施放[[spell:1257052]]前确保你拥有2个或更少的灵魂碎片。
7. 当目标身上有任何周期性效果（如[[spell:172]]、[[spell:980]]或[[spell:1259790]]）激活时，可用时立即施放[[spell:1257052]]。
8. **适用条件：碎片动荡（启用）。** 在增益窗口内使用[[spell:1260264]]提供的免费[[spell:1259790]]。
9. 施放[[spell:1259790]]以避免碎片溢出。
10. **适用条件：吸取灵魂（启用）。** 将[[spell:198590]]作为填充技能使用。
11. **适用条件：强化暗影箭（启用）。** 作为填充技能施放[[spell:232670]]。

### 群体伤害

2.2.

#### 多目标优先级

1. **适用条件：灵魂收割者（启用）。** 在最多10个目标上维持[[spell:980]]。
2. **适用条件：地狱召唤者（启用）。** 在最多14个目标上维持[[spell:980]]。
3. **适用条件：灵魂收割者（启用）。** 维持[[spell:172]]。如果有3个或更多目标聚集在一起，使用[[spell:27243]]来施加并维持腐蚀术。
4. **适用条件：地狱召唤者（启用）。** 维持[[spell:445465]]。如果有3个或更多目标聚集在一起，使用[[spell:27243]]来施加并维持枯萎。
5. **适用条件：鬼影缠身（启用）。** 在主目标上可用时立即施放[[spell:48181]]。
6. **适用条件：地狱召唤者（启用）。** 按冷却时间施放[[spell:430014]]。
7. **适用条件：播种（启用）；召唤黑眼（启用）；灵魂收割者（启用）。** 在2个目标时，在[[spell:205180]]期间的第2秒，当你拥有2个饱满碎片时施放[[spell:1259790]]。
8. **适用条件：召唤黑眼（启用）。** 如果只有2个目标，在[[spell:205180]]期间施放[[spell:1259790]]。
9. 当每个目标身上都有任何周期性效果（如[[spell:172]]、[[spell:980]]或[[spell:1259790]]）激活时，可用时立即施放[[spell:1257052]]。
10. **适用条件：播种（启用）；灵魂收割者（启用）。** 如果已经拥有5个灵魂碎片且有3个目标靠近，则施放[[spell:27243]]。
11. **适用条件：播种（启用）；地狱召唤者（启用）。** 如果已经拥有5个灵魂碎片且有3个目标靠近，则施放[[spell:27243]]。
12. **适用条件：灵魂收割者（启用）；播种（未启用）。** 如果已经拥有5个灵魂碎片且至少有6个目标靠近，则施放[[spell:27243]]。
13. **适用条件：地狱召唤者（启用）；播种（未启用）。** 如果已经拥有5个灵魂碎片且至少有6个目标靠近，则施放[[spell:27243]]。
14. **适用条件：灵魂收割者（启用）；播种（启用）。** 如果在[[spell:1257052]]冷却结束前碎片超过2个且有2个目标，则施放[[spell:27243]]。
15. **适用条件：灵魂收割者（启用）；播种（未启用）。** 如果在[[spell:1257052]]冷却结束前碎片超过2个且有6个目标，则施放[[spell:27243]]。
16. **适用条件：碎片动荡（启用）。** 如果碎片少于4个，对濒死目标使用[[spell:1260264]]提供的免费[[spell:1259790]]。
17. **适用条件：碎片动荡（启用）。** 在主目标上使用[[spell:1260264]]提供的免费[[spell:1259790]]。
18. **适用条件：吸取灵魂（启用）。** 将[[spell:198590]]作为填充技能使用。
19. **适用条件：强化暗影箭（启用）。** 作为填充技能施放[[spell:232670]]。

### 起手序列

**适用条件：鬼影缠身（启用）。**

[[spell:48181]]

**适用条件：鬼影缠身（未启用）；吸取灵魂（未启用）。**

[[spell:232670]]

[[spell:980]]

**适用条件：灵魂收割者（启用）。**

[[spell:172]]

**适用条件：地狱召唤者（启用）。**

[[spell:445465]]

**适用条件：地狱召唤者（启用）。**

[[spell:430014]]

**适用条件：灵魂收割者（启用）。**

[[spell:1259790]]

[[spell:246985]]

[[spell:246985]]

**适用条件：地狱召唤者（启用）；邪恶掌控（启用）。**

[[spell:1259790]]

**适用条件：灵魂收割者（启用）。**

[[spell:1257052]]

**适用条件：地狱召唤者（启用）；邪恶掌控（未启用）。**

[[spell:1257052]]

**适用条件：召唤黑眼（启用）。**

[[spell:205180]]

[[item:270169]]

[[item:271886]]

[[spell:1259790]]

**适用条件：邪恶掌控（启用）；地狱召唤者（启用）。**

[[spell:1257052]]

**适用条件：邪恶掌控（启用）；地狱召唤者（启用）。**

[[spell:1259790]]

**适用条件：灵魂收割者（启用）；吸取灵魂（启用）。**

[[spell:108558]]

[[spell:198590]]

**适用条件：灵魂收割者（启用）；强化暗影箭（启用）。**

[[spell:108558]]

[[spell:232670]]

**适用条件：邪恶掌控（启用）。**

[[spell:1261149]]

[[spell:1259790]]

2.3.

#### 起手序列

1. **适用条件：鬼影缠身（启用）。** 预读[[spell:48181]]。
2. **适用条件：鬼影缠身（未启用）；吸取灵魂（未启用）。** 预读[[spell:232670]]。
3. 施加[[spell:980]]。
4. **适用条件：灵魂收割者（启用）。** 施加[[spell:172]]。
5. **适用条件：地狱召唤者（启用）。** 施加[[spell:445465]]。
6. **适用条件：地狱召唤者（启用）。** 施放[[spell:430014]]。
7. **适用条件：灵魂收割者（启用）。** 施放[[spell:1259790]]直到获得2个[[spell:246985]]。
8. **适用条件：碎片动荡（启用）；地狱召唤者（启用）。** 施放[[spell:1259790]]，消耗所有[[spell:246985]]
9. **适用条件：灵魂收割者（启用）。** 施放[[spell:1257052]]。
10. **适用条件：地狱召唤者（启用）；碎片动荡（未启用）。** 施放[[spell:1257052]]。
11. **适用条件：召唤黑眼（启用）。** 施放[[spell:205180]]
12. 使用你的饰品和种族技能。
13. 将所有碎片用于[[spell:1259790]]。
14. **适用条件：邪恶掌控（启用）；地狱召唤者（启用）。** 施放[[spell:1257052]]。
15. **适用条件：邪恶掌控（启用）；地狱召唤者（启用）。** 将所有碎片用于[[spell:1259790]]。
16. **适用条件：灵魂收割者（启用）；吸取灵魂（启用）。** 施放[[spell:108558]][[spell:198590]]。
17. **适用条件：灵魂收割者（启用）；强化暗影箭（启用）。** 施放[[spell:108558]][[spell:232670]]。
18. **适用条件：邪恶掌控（启用）。** 持续施放[[spell:1261149]]，直到最近一次的[[spell:1259790]]过期

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

1.

### 至暗之夜 第2赛季套装

第2赛季套装加成如下：

- [[spell:1296568]]会同时提高[[spell:172]]和[[spell:980]]的伤害。
- [[spell:1296569]]在AoE期间消耗灵魂碎片施放[[spell:27243]]时，能够激活与[[spell:1259790]]相关的若干天赋和效果。

这两个套装加成都不是特别强，其设计目的是提供被动的伤害提升，不会改变游戏中的优先级或决策。

1.

### 职业与专精机制详解

以下章节介绍了与痛苦和术士相关的各种机制，以及技能以特定方式使用的原因。

### 快照机制

4.1.

#### 快照与高效刷新持续伤害效果

快照是一种隐藏机制，允许你提前刷新某些限时效果而不会受到惩罚。当你的持续伤害效果剩余时间少于其最大持续时间的30%时，你就可以刷新它。这会将新持续伤害效果的最大持续时间与当前持续伤害效果的剩余时间相加。

例如，如果你在一个当前剩余持续时间为3.5秒的痛楚上刷新一个新的[[spell:980]]，你的新痛楚将拥有21.5秒的持续时间。

其他持续伤害效果的安全刷新快照时间如下：

- [[spell:980]]：5.4秒
- [[spell:172]]：4.2秒

当点出[[spell:264000]]天赋时，时间变化如下：

- [[spell:980]]：4.5秒
- [[spell:172]]：3.5秒

### 邪恶贪欲

4.2.

#### 邪恶贪欲

[[spell:1261149]]可能是最难优化的机会窗口。其前提是最大化在拥有[[spell:1261149]]期间所花费的公共冷却时间数量，同时使[[spell:1259790]]的命中次数达到最大。

为了达到这一目标，应尽可能减少其他公共冷却时间（GCD）的使用，这意味着除非绝对必要否则不要移动，并将刷新[[spell:980]]的次数降到最低。因此，建议在进入[[spell:205180]]之前，通过大灾变（pandemic）机制使[[spell:980]]获得完整持续时间，这样可以确保在[[spell:205180]]持续期间不需要消耗任何GCD（如果点了[[spell:1279521]]天赋，则只需一次刷新）。

值得注意的是，最好在[[spell:205180]]剩余8秒之前消耗掉所有可用的[[spell:1259790]]，以最大化从[[spell:1261149]]和[[spell:205180]]伤害加成中获得的收益。

### 顶点天赋

4.3.

#### 暗影之纳特雷扎

痛苦术士的顶峰天赋[[spell:1261984]]的设计理念是从多个方面增强[[spell:48181]]。第1层和第4层提供直接的伤害贡献，并允许该法术溅射到多个附近目标，进一步巩固了其在AOE场景中的重要性。第2层和第3层则提高对主目标的伤害加成效果。

因此，天赋本身并不会改变在循环中与[[spell:48181]]的交互方式，因为在几乎所有场景中它都是卡着冷却时间施放的。

1.

### 痛苦术士的重要冷却技能

### 黑眼

5.1.

#### 黑眼

[[spell:205180]]是该专精的主要冷却技能，具有基础的持续伤害（DoT）加成效果，鼓励在进入该窗口前积攒资源。像[[spell:1261149]]这样的辅助天赋的存在，进一步强调了将GCD严格用于[[spell:1259790]]和[[spell:1261149]]的重要性，并相应减少重新施放[[spell:48181]]或[[spell:980]]所花费的时间。

因此，最好在施放[[spell:205180]]之前，确保[[spell:980]]获得大灾变（pandemic）延长的持续时间。

[[spell:205180]]基础效果为单目标持续施法，需要[[spell:1280733]]才能启用5目标溅射。

### 幽冥收割

5.2.

#### 幽冥收割

[[spell:1257052]]默认应卡着冷却时间施放，并确保在[[spell:205180]]之前对齐使用。点出[[spell:453056]]会增加其使用频率，尤其是在AOE场景中配合不断施放的[[spell:27243]]时，但将其与[[spell:205180]]同步仍然有益。

虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者不会直接影响[[spell:1257052]]的行为， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者[[spell:449638]]要求在施放[[spell:1257052]]之前灵魂碎片降至2个，以避免灵魂碎片溢出浪费。

### 怨毒

5.3.

#### 怨毒

[[spell:430014]]是一个相当直接的冷却技能，与痛苦的伤害曲线自然契合，因此在点了天赋的情况下，应与[[spell:205180]]和[[spell:1257052]]配合使用。

1.

### 痛苦术士重要注意事项

### 灵魂碎片

6.1.

#### 灵魂碎片

所有术士都使用灵魂碎片作为主要资源。正确管理你的碎片对成功至关重要，因为溢出会导致潜在的伤害损失。

虽然从设计上来说，玩家不应过多思考何时花费新获得的碎片，但同样可以说花费它们并没有严格的紧迫性，除非接近5个，因此使用场景相当灵活。

天赋选择和战斗设计等因素会影响何时使用灵魂碎片以及如何使用它们的决定。囤积资源在以下情况下可能有利：

- 进入像[[spell:205180]]或[[spell:430014]]这样的冷却阶段
- 额外目标即将进入战斗时
- 优先目标出现或爆发阶段即将开始时

### 痛楚

6.2.

#### 痛楚

[[spell:980]]是你目前最重要的法术，因为它是常规循环中灵魂碎片的唯一来源。它还造成严重的持续伤害。然而，代价是[[spell:980]]在达到完全效果之前有一个预热期。这意味着如果你因任何原因让主要目标身上的[[spell:980]]断掉，你将会大量损失DPS。仔细跟踪你活跃的[[spell:980]]施放是一个重要的优先事项，也是搞砸后惩罚最重的失误。

### 恶魔选择

6.3.

#### 恶魔选择

在9.2版本改动之后，萨亚德（魅魔或欲魔）在单体伤害方面有明显优势，前提是不存在频繁的远距离目标切换。然而，宠物的选择往往取决于每个宠物提供的独特实用性：对于防御驱散，以及如果存在远距离目标之间的频繁切换，小鬼将提供最高的正常运行时间。每当需要打断或驱散效果时使用地狱猎犬。虚空行者可以通过其折磨技能提供一些额外的AoE，但其最重要的实用性来自嘲讽。魅魔提供进一步的控制和对单个目标的永久减速，这在某些情况下可能有用。

### 移动能力

6.4.

#### 移动管理

虽然很难描述在地下城或团队副本战斗中最佳的站位和移动方式，但这对作为一名痛苦术士的成功至关重要。[[spell:111771]]在许多战斗中可以非常有效，但被许多玩家和团队低估了。把[[spell:111771]]想象成一个可以将整个团队传送40码的团队冷却技能。这项技能的潜力很快就会显现出来。询问你的团队他们是否希望[[spell:111771]]放置在特定位置；如果战术不需要，就把它当作个人冷却技能使用。

当需要移动时，可以刷新[[spell:980]]和[[spell:172]]来争取掩护。[[spell:108558]]在移动较多的战斗中有一定潜力，尤其是在有溅射的情况下，因为瞬发的[[spell:232670]]触发提供了另一个可以在移动时不损失DPS的公共冷却时间。

你可以通过站在战斗移动的中心位置来减少移动需求。例如，如果首领被风筝绕圈跑，你应该待在风筝路径内侧以确保移动距离最小。你还应该确定你的[[spell:268358]]如何让战斗对你来说更容易。一个巧妙的传送门可以让你轻松应对许多首领机制，从而让你腾出手来输出更多伤害。

[[spell:385899]]与[[spell:111771]]配合使用提供了一种快速覆盖长距离的方法，并在需要立即重新定位时可以用于冲刺。

6.4.1.

##### 静默移动

许多玩家会在战斗中无意识地移动，尽管这并无必要。例如，有时首领或小怪会被坦克移动几码。虽然你仍在施法距离内，但你会下意识地跟随移动，从而浪费公共冷却时间。有意识地努力让你的移动“安静”下来，将不必要的移动降到最低。观察这一点的最佳方式是录制你的团队副本视频，然后观看自己的操作。大多数玩家会对自己浪费的移动量感到惊讶。当你被迫移动时，让你的路径尽可能直接和果断。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月31日：** 已更新循环章节。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026 年 3 月 17 日：** 扩展了套装奖励部分。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜的发布更新了输出循环并添加了巅峰部分。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日：** 重新制作了页面布局，并相应地更新了各部分。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 添加了英雄天赋部分和选择器。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月28日：** 在4件套修复后更新了多目标部分。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为 10.1.5 补丁更新了选择器。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月11日：** 更新了起手式和黑暗猎犬部分。
- **2022年12月11日：** 更新了起手式和优先级列表的选择器。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页中，你将找到《魔兽世界》12.1.5中你的痛苦术士的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章升级装备的建议，我们都为你准备好了！

1.

### 痛苦术士毕业装备指南

欢迎来到我们的痛苦术士配装页面。本节将涵盖你需要了解的关于正确装备角色的所有内容。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含痛苦术士来自所有来源的最高DPS配置。请记住，还有许多其他配置的性能在误差范围内。此列表 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:239031@JAACAAAG2A]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸甲：[[item:271549@JAACAAgNyA]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：[[item:268243]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿部：[[item:251160@JAACAAgNyA]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 常见问题我应该从大宝库中选择哪些物品？
团队副本中的稀有掉落以及在模拟中

[最佳装备](<https://www.raidbots.com/simbot/topgear>)

能带来最高提升的物品应优先追求。以下是值得追逐的部分物品：

- [[item:271092]]：仅凭物品等级就是最佳的施法者武器
- [[item:271874@JAACAAAG2A]] 和 [[item:268265@JAACAAAG2A]]，高物品等级且带有强力咒术效果的物品
- [[item:270170@JAACAAgNyA]] 是本赛季最好的饰品

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240898]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

本列表包含地下城中 痛苦 术士 的最高 DPS 配置。请注意，还有许多其他配置的表现处于误差范围内。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:251199@JAACAAgNyA]]，来自 [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- 肩部：[[item:239031@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸部：[[item:273785@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手部：来自的[[item:159247@JAACAAgNyA]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 腿部：[[item:251160@JAACAAgNyA]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 小贴士：应该优先刷哪些地下城？
如果你的游戏时间有限，可以考虑刷以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：两把武器和一枚戒指
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：饰品、腰带和项链
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：你的第二个饰品

:::

:::details 常见问题：双手法杖和单手武器+副手之间有区别吗？
只要物品等级相同，两者在总属性值上就没有区别。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:251199@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

本列表包含团队副本中 痛苦 术士 的最高 DPS 配置。请注意，还有许多其他配置的表现处于误差范围内。本列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩膀：[[item:268241]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 胸甲：[[item:271549@JAACAAgNyA]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：[[item:268243]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿甲：[[item:271545@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 小贴士：团队副本中最重要的掉落是什么？
以下是值得优先获取的最重要掉落。

- [[item:281215@JAACAAgNyA]]：综合最佳饰品。掉落自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).
- [[item:271092@JAACAAAG2A]]：物品等级最高的武器。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:271874@JAACAAAG2A]]：在属性预算较高的部位中物品等级最高且属性优秀。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240898]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270170@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/affliction-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 痛苦术士饰品推荐

以下列表提供了所有可供玩家获取的饰品的综合排名，以便更好地了解哪些饰品可能更具吸引力。这些排名假设每件物品都处于其最高可能的物品等级，因此若要进行直接或即时的装备提升，最好还是对自己的角色进行模拟。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **痛苦 术士饰品**
**毕业 -**

[[item:273649@JAACAAgNyA]]

和

[[item:281215@JAACAAgNyA]]

**次选被动饰品——**

[[item:270164@JAACAAgNyA]]

或

[[item:250224@JAACAAgNyA]]

**次选主动饰品——**

[[item:270170@JAACAAgNyA]]

或

[[item:273796@JAACAAgNyA]]

:::

任何未在此列表上显示的饰品，通常都被认为比此列表上所有其他饰品都要差。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看痛苦 术士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:158368@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 作为额外战利品使用，可保证从首领或地下城的掉落列表中掉落一件物品。虽然掉落本身是随机的，但每额外消耗一个虚空核心，都会保证在掉落列表全部掉落完之前不会出现重复物品。

3.1.

#### 痛苦术士的模糊虚空核心使用建议

朦胧虚空核心是一种宝贵但有限的资源，虽然通常应用于填补玩家当前装备的空缺，但重要的是要记住，能多快保证获得一件物品，取决于该来源已经掉落了多少件其他物品。

并非所有掉落都同样重要，以下是应优先关注的通用优先级列表：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心定向优先级**
1. 史诗级路线的[[item:271092@JAACAAAG2A]]
2. 史诗级 [[item:271874@JAACAAAG2A]]
3. 史诗级武器（单手或双手）；
4. 史诗级饰品（尤其是[[item:281215@JAACAAgNyA]]）；
5. 缺少2件套或4件套加成的套装部件；
6. 你BiS列表中影响最大的部位。

:::

3.2.

#### 晋升毒液石

[[item:280562]]作为第2赛季中升级装备的方式回归。以下是各装备部位的升级优先顺序：

1. 主手武器最为重要
2. 副手武器
3. 主动使用饰品
4. 被动饰品
5. 项链。

[[item:280562]]也可用于将后2个首领掉落的英雄难度命运骰子物品升级至340物品等级。

1.

### 痛苦 术士最佳制造装备

制造装备的主要限制因素仍然是每周发放的火花，这是制作高端装备所必需的，因此了解如何处理这个问题很重要。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **痛苦 术士制造装备优先级**
1. 总体最佳组合是手腕部位使用[[item:240167]]，副手饰品使用[[item:273059]]，但这适用于装备已毕业的角色，因此应被视为长期策略，更适合那些不需要立即获得最高战力提升，而是选择最少重铸次数和资源投入的玩家。
2. 如果重点是立即获得战力提升，那么使用4个火花制作带有[[item:273060]]的[[item:245770@JAAGAAwt1ENMMYD]]，并以较低物品等级制作带有[[item:240167]]的手腕，能提供最大的DPS提升。

:::

每次制造所使用的公函如下：

- 武器和手腕使用[[item:245786]]
- 其他任何部位使用[[item:245783]]

:::details 常见问题：为什么先制作武器，即使它不是毕业装备？
武器提供最高额的主属性，尤其是在前期，这是非常珍贵的资源。然而制造物品的物品等级上限比完全升级的史诗级替代品低4个物品等级，因此在高端装备方面有所限制，前提是玩家能够获得那种级别的装备。

:::

:::details 常见问题：是否值得为更换公函而重铸？
如果相关的重铸成本不是问题，可以随时对自己的角色进行模拟，以获得当前最佳的公函。

**然而**

请记住，除非是副属性分布极度偏斜的非常特殊的情况，否则更换属性不会带来显著的收益。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

在第2赛季中，[[item:275707]]可在宏伟宝库中以6个代币兑换，可用于为任意头部、腰部或手腕物品添加插槽。

1.

### 纹章使用

迷雾纹章是一种有每周上限的赛季限定货币，上限每周增加，用于将物品升级至各自奖励路线中的最高等级。

由于每个装备部位的设计不同，其战力也存在差异，这与特定效果或更高的属性有关。因此，以下是投资迷雾纹章最有价值的部位顺序：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **痛苦 术士纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**项链**

➜

**副手**

➜

**肩部/手套/腰带/靴子**

➜

**戒指**

➜

**手腕/披风**

:::

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月31日：** 更新了饰品列表。
- **2026年8月16日：** 更新了最佳配装列表、美化和饰品，以适应新的属性配置和饰品调整。
- **2026年8月11日：** 更新了宝石和常见问题解答部分。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 更新了饰品排名以考虑凝视的削弱。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为 至暗之夜 发布进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 根据调整更新了暗影牧师的插槽推荐。
- **2025年6月15日：** 为 11.1.7 补丁和暗影牧师进行了更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月4日：** 已更新饰品推荐。
- **2025年3月4日：** 更新了毕业装备列表和饰品排行。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为 11.0.7 补丁和赛尔西的指环进行了更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 添加了第1赛季毕业装备列表，更新了饰品部分。
- **2024年8月21日：** 添加了赛季前毕业装备列表部分。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季上线进行了更新。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 为 10.2.5 补丁更新了饰品部分。
- **2023年11月7日：** 在波纹孢子斗篷被削弱后更新了美化推荐。
- **2023年11月6日：** 为 10.2 补丁和第3赛季更新了装备推荐。
- **2023年9月4日：** 重新格式化了页面，包含毕业装备表格和部分更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月24日：** 更新了黑龙戒指部分以考虑正式服的在线修复。
- **2023年3月20日：** 添加了 10.0.7 补丁新戒指部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 更新了美化推荐。
- **2022年12月11日：** 已为第一赛季上线更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将找到痛苦 术士的属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 痛苦 术士属性优先级

痛苦 术士的属性优先级如下：

装备等级

急速

暴击

精通

全能

值得注意的是，我们的副属性在价值上相对接近，因此通常认为优先考虑物品等级是最好的方法，尤其是当你接近属性收益递减时。更均衡的属性分配优于将两个最佳属性堆叠到收益递减的程度。

1.

### 深入属性解析

**智力** 是你的主属性。你应该在所有升级中寻找该属性。它为你提供法术强度，增加你法术的伤害。

**精通**通过[[spell:77215]]，精通会提高你的持续伤害技能（[[spell:980]]、[[spell:172]]、[[spell:27243]]和[[spell:1259790]]）以及[[spell:324536]]的伤害。精通完全不影响你的宠物或灵魂碎片的生成。

**急速** 影响你法术的施法速度并增加你持续伤害技能的跳数。这也会减少[[spell:980]]的预热伤害。急速还会降低公共冷却时间并与你的宠物同步。由于持续伤害技能跳数的增加也会带来更多灵魂碎片，我们可以将急速视为对资源生成影响最大的属性。

**暴击** 提高你所有法术和技能的暴击几率。

**全能** 是纯粹的造成伤害提升和承受伤害降低。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的痛苦 术士所能获得的最佳宝石、附魔、药剂、药水和食物，这些基于你的 [属性优先级](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

可镶嵌宝石分为两类：史诗和稀有。前者提供强大的效果但只能装备1个，后者包括单属性或双副属性组合的宝石。

宝石可以通过来自宝库的[[item:275707]]物品镶嵌到头盔、护腕或腰带上。

闪耀钻石史诗宝石的选择是[[item:240983]]或[[item:240967]]。在获得史诗级装备之前前者更优，之后后者表现更好。

在物品属性方面，选择暴击宝石能获得最佳效果，因为该副属性对术士总体而言非常强大。[[item:240898]]是你与[[item:240983]]搭配的最佳宝石，而通过装备4个不同颜色的稀有宝石来激活[[item:240967]]的完整收益也非常重要。

你应该装备的四种稀有宝石是：

- 橄榄石：[[item:240890]]
- 青金石：[[item:240914]]
- 紫水晶：[[item:240898]]
- 石榴石：[[item:240906]]

<em>强烈建议使用 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来模拟你角色的理想宝石和附魔，因为它们可能与一般推荐不同。</em>

**确保在选项中勾选"Always use"和"Only 4+ Colors"复选框。**

1.

### 最佳附魔和武器强化

使用[[item:243733]]作为武器油。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

2.1.

#### 武器附魔选择

副属性武器附魔可能比[[item:244029]]提供更好的价值，但哪一个最适合你很大程度上取决于你其余的装备。因此，根据你当前的属性分配，你可能需要 [模拟自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 因为你最好的副属性附魔可能与上面列出的不同。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

在第2赛季中，[[item:241325]]是默认选择。

3.2.

#### 药水

如果你的装备几乎没有全能，那么[[item:241288]]应该是首选，否则使用[[item:241308]]。

获得[[item:270168]]后，[[item:271886]]成为更强的选择，尤其是在最后5秒。

[[item:271883]]是治疗药水的选择。

3.3.

#### 食物

[[item:242275]]和[[item:255846]]是推荐的食物。你可以直接购买最便宜的那种，或者在团队提供盛宴时食用。

在灭团/死亡相当频繁的情况下，应考虑丰盛版本的食物，因为它们在死亡后仍然存在。

3.4.

#### 强化符文

[[item:259085]]提供约1%的DPS提升，应在开荒期间评估，尤其是在接近关键击杀时。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月16日：** 更新了消耗品以反映新的最佳配装列表。
- **2026年8月11日：** 更换了药剂并更新了宝石。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 更新了茶部分。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月22日：** 更新了武器附魔。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月12日：** 更新了武器附魔和磨刀石。
- **2024年9月9日：** 更新了宝石部分，因为策略发生了变化。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 在腐化之怒增益后更新了药水推荐。
- **2023年3月24日：** 更新了原始宝石推荐以考虑额外的正式服在线修复。
- **2023年3月22日：** 更新了原始宝石推荐以考虑25%增益的在线修复。
- **2023年3月20日：** 为 10.0.7 补丁添加了原始宝石部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月7日：** 将地下城药水更新为更可靠的微温全能药水。
- **2022年12月14日：** 更新了武器符文。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的痛苦 术士挑战大秘境地下城的技巧和建议。

1.

### 痛苦 术士在至暗之夜第2赛季中的大秘境

大秘境已成为《魔兽世界》终局内容的重要组成部分。尽管如此，大量不同的变量让许多玩家感到不知所措。队伍构成、每周词缀、队伍的物品等级、钥石等级以及队伍的经验和舒适度，都是影响你如何应对每个地下城的因素。本页面的目的是让你做好准备，了解大秘境与典型《魔兽世界》终局体验的关键差异，包括可能乍看之下不明显的天赋和循环异常。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

[痛苦 术士](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-guide>)是一个扎实的远程DPS专精，提供频繁爆发周期的持续伤害。虽然该专精缺乏免疫技能，但可靠的减伤和自我治疗使其成为一个多才多艺的选择，拥有独特的工具包，包括治疗石、灵魂石、诅咒、用于跳怪的[[spell:111771]]、以及[[spell:30283]]和[[spell:5484]]等群体控制技能。

1.

### 最佳大秘境天赋配置

### 大秘境天赋

2.1.

#### 痛苦 术士的大秘境天赋

以下构筑提供更多的前置伤害、更快达到最大伤害的能力以及更好的整体AOE。

要直接在游戏内导入构筑，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYAzwWghtBAAgZAAAMzMmZY2YYMzMzMMMzMzAAmBG"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPSfiklnoELM028MTjchprTwwJbM-JKcdBILe2IUYgxxRTc4IzbEAaCLMUwC-AAAA-HIOQ2AEUQhhCzC-
```

:::

### 地狱召唤者变体

2.2.

#### 地狱召唤者的痛苦 术士大秘境天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者提供了一个围绕[[spell:430014]]构建的、灵活性较低的1分钟爆发伤害模式，以及相对更好的单体伤害。

要直接在游戏内导入构筑，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CkQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAmxsMLzMzyYAALwAziRjZAMbglBAAgBAAMzgxMzY2YYmZMzMmhZmZGAwMwA"
}
```
:::

:::details 来源计算器编码
```
#JE-ITUUVVDHPfgiklnoELM028MTjehprTwwJbM-JKcdBILe2IUYgxxRc4IbEYCzDEMM06C-AAAA-IQSU2AIQYgxBzC-
```

:::

1.

### 痛苦 术士的大秘境灵活天赋

### 功能/防御天赋替换

3.1.

#### 功能/防御灵活天赋

关于AOE打断，[[spell:30283]]和[[spell:5484]]通常可以互换，应在存在免疫眩晕或恐惧的目标时，以及更快的冷却时间是否更重要时进行评估。

[[spell:710]]是一个更加小众的工具，可以将畸变怪、恶魔或元素目标从战斗中移除长达30秒。它对首领无效，在首领战斗中大多数时候主要机制通常会出现免疫该法术的目标。

[[spell:268358]]和[[spell:111771]]可以被视为重新定位工具，后者通常允许特定路线的跳怪，前者则用于个人处理那些会迫使长时间移动的机制。

对于[[spell:108416]]的辅助天赋，[[spell:386664]]减少生命值损失，主要用于需要保持在一定生命值阈值以上的场合，但总体而言不如其替代选择[[spell:386686]]适用，后者冷却时间更快，因此有更多机会减免伤害。

反过来，对于[[spell:104773]]，选择[[spell:317138]]使伤害减免更为显著，通常是首选，因为基础冷却时间足够长，只有在特定战斗需要在3分钟内进行两次减伤时，才应考虑使用[[spell:386659]]。

### 伤害天赋替换

3.2.

#### DPS灵活天赋

以下替代选项代表了更多单体和更多AOE之间的渐变，可用于在两者之间调整伤害模式：

- 在使用[[spell:196103]]时，[[spell:1311969]]可以与[[spell:1279521]]互换，获得3%更好的单体和1%更多的AOE

[[spell:198590]]和[[spell:453080]]之间的选择通常由所选英雄天赋树决定。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者碎片生成较慢，更多低优先级公共冷却时间，单体较弱，因此从[[spell:198590]]中获益更多，这要归功于更有影响力的[[spell:108558]]窗口以及从濒死目标身上偷取碎片的能力。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者则有更简单的方式生成碎片并保证免费消耗技能的施放，因此更忙碌且经常需要对抗资源溢出意味着[[spell:453080]]更适合。

1.

### 大秘境深度输出循环提示

虽然单体和多目标循环与中概述的标准优先级没有实质性差异
[循环、冷却与技能页面](<https://www.icy-veins.com/wow/affliction-warlock-pve-dps-rotation-cooldowns-abilities>)
但有几点值得注意：

- 由于小怪不断死亡的战斗性质，痛苦可以在天赋支持下使用[[spell:1259790]]和[[spell:198590]]进行灵魂碎片偷取，在整个过程中榨取额外伤害。
- 最大化冷却效率，争取最高施放次数，同时不要在即将死亡的小怪身上浪费激活。在这种情况下，攒到5个碎片并以最大资源开始下一波小怪更好。
- [[spell:48181]]在天赋支持下，在任何情况下都值得施放，最好施放在受到[[spell:1259790]]影响的目标上。
- [[spell:980]]的碎片生成在超过4个目标后收益递减，这意味着让它覆盖最多4个目标至关重要。超过该数值后，伤害收益仍然值得消耗公共冷却时间。但是，你不应将其优先于消耗碎片或准备/使用冷却技能。

1.

### 功能技能与能力

虽然伤害是带痛苦 术士的更重要原因，但该职业本身提供了大量控制和各种辅助能力：

- 诅咒最近回归，可以针对特定危险敌人提供一些优势：[[spell:1714]]可以降低团队的打断需求。同时，[[spell:702]]减轻坦克受到的普通攻击伤害。最后但同样重要的是，[[spell:334275]]可以在需要风筝时减速目标。
- [[item:5512]]冷却时间为1分钟，恢复25%最大生命值，允许每位玩家进行一次紧急治疗。
- [[spell:20707]]提供战斗复活，你可以在死亡跑尸的情况下主动和预防性地使用。
- [[spell:111771]]提供了独特的能力，可以根据地下城跳过地图的某些部分，避免特定的小怪。
- [[spell:30283]]是一个3秒的AOE眩晕，有助于在大型拉怪时减轻坦克的压力。
- [[spell:5484]]在当前版本中，点出[[spell:1270255]]后，作为短冷却时间的群体打断技能尤其强大。
- [[spell:5782]]和[[spell:710]]都是可重复施放的控制技能，可在紧急情况下打断施法或暂时移除目标的战斗能力。

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

:::details 常见问题 如何最佳使用灾厄？
灾厄是诅咒的强化版本，但代价是绑定2分钟冷却时间且仅持续12秒。因此应将其视为队伍的防御性冷却技能，以便在适用时减轻即将到来的伤害。每个灾厄遵循与其对应诅咒相同的规则：

- [[spell:1271748]]适用于任何攻击，降低攻击频率和暴击几率
- [[spell:1271802]]适用于任何可被打断的施法

:::

1.

### 应对词缀

### 词缀：升腾

6.1.

#### 痛苦术士的升腾词缀应对

大约每分钟一次，萨拉塔斯会出现并召唤总共10个升腾宝珠，其施法需要被打断。任何控制或打断法术均可生效：

- [[spell:30283]];
- [[spell:5484]]（上限为10个）；
- [[spell:5782]];
- [[spell:6789]];
- 宠物打断。

### 词缀：虚缚

6.2.

#### 痛苦术士的虚空束缚词缀应对

战斗中，萨拉塔斯会召唤一个虚空大使来强化附近的敌人，它成为优先目标，最好集火击杀。

### 词缀：脉冲星

6.3.

#### 痛苦术士的脉冲星词缀应对

战斗中，萨拉塔斯会显现脉冲星宝珠，缠绕并环绕玩家15秒。对于该机制没有特别的建议，只需承受这些宝珠即可，虽然移动速度降低可以用[[spell:111400]]来抵消。

### 词缀：吞噬

6.4.

#### 痛苦术士的吞噬词缀应对

周期性地，萨拉塔斯会对所有5名玩家施加护盾减益，可以通过治疗量或驱散来移除。诸如[[spell:6789]]和[[item:5512]]之类的治疗技能可以在没有其他驱散手段时帮助移除护盾。

- [[spell:688]][[spell:89808]]可以驱散一个护盾。

1.

### 痛苦术士的宠物选择

地狱猎犬提供相当的单体伤害以及打断或净化，但如果你需要驱散，请考虑换用小鬼。

如果你使用[[spell:108503]]，我们建议牺牲地狱猎犬为你的队伍提供额外的打断。假设你需要额外的冷却技能来生存。在这种情况下，你也可以在困难的首领前牺牲虚空行者以获得[[spell:17767]]冷却技能。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月31日：** 更新了地狱召唤者天赋。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月19日：** 为 11.0.5 补丁进行了更新，并添加了地下城提示部分。
- **2024年9月9日：** 针对第1赛季上线更新了天赋选择。
- **2024年7月19日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 重构了天赋部分。
- **2023年7月10日：** 针对10.1.5补丁更新了天赋。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 为 10.0.7 补丁更新了天赋。
- **2023年1月24日：** 为 10.0.5 补丁更新了天赋。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页，你将找到许多有用的宏和插件，以便在《魔兽世界》12.1.5补丁中使用你的痛苦术士时更加轻松。

1.

### 最佳宏

以下是常用宏的示例；你可以根据需要将其调整为任何法术。

1.1.

#### 宠物宏

这些宏允许你管理你的恶魔，因为将宠物姿态设置为协助是首选的游玩方式。

#### 宠物攻击

```wow-macro
/petattack
```

这会命令你的恶魔攻击你的目标。

#### 宠物跟随

```wow-macro
/petfollow
```

这会命令你的恶魔跟随你。

#### 宠物移动

```wow-macro
/petmoveto
```

这会命令你的恶魔移动到你指定的位置。此宏在需要让宠物处于预定位置以完成特定任务时特别有用——例如打断一个原本超出范围的目标——但也可用于最大化恶魔卫士的顺劈/[[spell:89751]]伤害，不过要注意任何下达的命令也会使你的恐惧猎犬、邪犬（如果点了天赋）和暴君移动，如果使用不当会造成更大的损失。

1.1.1.

##### 鼠标指向持续伤害技能

#### 鼠标指向腐蚀术

```wow-macro
#showtooltip 腐蚀术
/use [@mouseover,harm] [harm] 腐蚀术
```

如果鼠标指向的目标是敌对且存活的，则对其施放[[spell:172]]，否则对当前目标施放。

值得一提的是，暴风雪在控制设置中增加了将所有施法切换为鼠标指向逻辑的功能，不过某些技能可能无法正常运作，因此仍然建议花点时间为任何需要鼠标指向用例的技能制作一个宏。

1.1.2.

##### 放逐焦点

#### 放逐焦点

```wow-macro
#showtooltip 放逐术
/use [mod:shift,@focus] [] 放逐术
```

按住Shift同时对焦点目标施放[[spell:710]]，否则对当前目标施放。

1.1.3.

##### 灵魂石鼠标指向

#### 灵魂石鼠标指向

```wow-macro
#showtooltip 灵魂石
/target [@mouseover] 灵魂石
/use 灵魂石
/targetlasttarget
```

针对当前与鼠标指向已死亡盟友相关的bug的变通宏。该宏会先选中鼠标指向的目标以施放[[spell:20707]]，然后切换回之前的目标。

1.1.4.

##### 恶魔法阵

#### 恶魔法阵

```wow-macro
#showtooltip
/stopcasting
/use [mod:shift] 恶魔法阵; [nomod] 恶魔法阵：传送
```

按住Shift放置恶魔之环，或不使用修饰键传送到法阵，同时取消任何正在进行的施法。这样你就省去了手动打断施法的麻烦（以及时间！）。

1.1.5.

##### 暗影之怒/恐惧嚎叫

#### 暗影之怒/恐惧嚎叫

```wow-macro
#showtooltip
/use [known:暗影之怒,@cursor] 暗影之怒; [known:恐惧嚎叫] 恐惧嚎叫
```

根据所选天赋，在光标处施放[[spell:30283]]或改为施放[[spell:5484]]。

1.2.

#### 痛楚

#### 痛楚

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] 痛楚
```

对鼠标指向的存活敌方目标施放[[spell:980]]，否则对当前目标施放。

1.3.

#### 鬼影缠身

#### 鬼影缠身

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead] [] 鬼影缠身
```

对符合条件的鼠标指向目标施放[[spell:48181]]，否则对当前目标施放。

1.

### 最佳插件

2.1.

#### 术士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
