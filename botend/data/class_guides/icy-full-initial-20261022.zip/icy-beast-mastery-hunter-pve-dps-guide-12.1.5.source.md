## 专精概览

Welcome to our Beast Mastery Hunter guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Beast Mastery Hunter in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Beast Mastery Mythic+ Resources

[NEW! Top Beast Mastery Talent Builds](<https://raider.io/specs/beast-mastery-hunter/talents>)

[Top Beast Mastery Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/hunter/beast-mastery>)

[Beast Mastery Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=hunter--beast-mastery>)

[Popular Beast Mastery Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=hunter--beast-mastery>)

1.

### Beast Mastery Hunter Overview

Beast Mastery Hunter is a highly mobile ranged DPS spec. It is the only

Ranged spec in the game that is able to fully execute its rotation while moving.

This makes it incredibly useful for dealing with mechanics in raids and

dungeons, as it can do these things with no damage penalty. It is also

relatively easy to pick up and play. If you enjoy a simple but effective ranged

playstyle that is virtually unrestricted on movement, you will probably find

Beast Mastery fun!

A Solid Baseline

Beast Mastery has good single-target and mass AoE, but poor cleave, and it
struggles to do single-target and AoE well in the same build. Its 30-second burst
profile (or rather, lack of burst) holds it back for many fights in the Raid
especially, but it works out fine in Mythic+.

Unremarkable

Beast Mastery has a 30-second burst profile in Midnight, and loses
quite a bit of single-target DPS in order to deal decent AoE DPS. Its overall tuning
is mediocre, and while a Hunter is required in any raid comp due to

[[spell:257284]]

, Beast Mastery is not fantastic on its own.

Needs Big Pulls

Beast Mastery has very strong AoE damage, but it requires very large pulls to
really shine. Its single-target and priority-target damage are just "okay", but
if built around, it is quite a good spec for Mythic+ overall.

Unremarkable

We bring mediocre utility to the
group. A 1-minute stun/AoE stop in

[[spell:19577]]

,
and a regular cooldown ranged kick. The flexibility and cooldown of our AoE stops are mediocre.

[[spell:257284]]

is mandatory in raids, but it is not particularly
strong in Mythic+ outside of bosses.

Strong Active Defenses, Weak Passives

Beast Mastery has access to several strong active defensive abilities,
allowing it to mitigate heavy damage effectively. However, its passive defenses
are relatively weak, making it reliant on timing and proper use of cooldowns to
survive in high-damage situations. It suffers in "rot" damage situations, with
constantly ticking hard DoTs. As a result, Hunters often require more external
healing than other classes. The skill ceiling is relatively high, while the
skill floor is relatively low. Pack Leader in particular is weak defensively.

Best Ranged Mobility in WoW

We are the only ranged spec in the entire
game that has near-complete unconstrained movement and DPS at the same time. The
outlier is that

[[spell:392060]]

does require us to stand still for 1 second
every 30 seconds, as

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

. We can use Pets that grant upwards of
8% increased passive movement speed, we have

[[spell:781]]

/

[[spell:109215]]

to cover long distances quickly, and

[[spell:186257]]

can be utilized
as an additional bit of mobility.

2.

### Beast Mastery Hunter in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 adds two new pieces of endgame content to Season 2. The

Unbinding of Kith'ix is a new raid encounter, and the Labyrinth of Kindo'jan

is a new Mega-Delve. Our guides to both are linked below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Patch 12.1.5 is a mid-season content patch. It also brings

[[item:280562]], a new currency for upgrading your Weapon,

Trinkets and Neck up to iLvl 340. Everything else that is new is in the

Patch Hub below.

2.3.

#### Class Changes

Beast Mastery has no meaningful class changes in Patch 12.1.5, and the spec

plays the exact same as it did in Patch 12.1.

On our [Gear](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>) page, the

Catalyzed [[item:281238]] from the Kith'ix raid are our new

BiS Gloves, and there is a new list of what to spend your first

[[item:280562]] on.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_beastmastery.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Changes

Patch 12.1 brings a fair bit of content outside of the new Season.

There is a new zone to explore, new rares and treasures to hunt down, and

plenty of new housing and transmog rewards to collect. Blizzard has also

updated a number of existing systems and added quality of life

improvements.

:::details Show Patch 12.1 Class ChangesHide Patch 12.1 Class Changes
2.5.

#### Class Changes

Beast Mastery is broadly the same in Season 2. Its burst was nerfed, while

its flat damage was increased. [[spell:115939]] was made more forgiving, and

[[spell:193455]], via the Tier Set, is now a more powerful button even on

AoE.

The [Omnium Folio](<https://www.icy-veins.com/wow/omnium-folio-guide>) borrowed-power system carries into Season 2, and it

affects both your talent choices and your gear. You can find the details on our

dedicated [Talents](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>) and

[Gear](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>) Guides.

- [[spell:378442]] has been removed.
- [[spell:1265052]] renamed to [[spell:1265052]] and redesigned.
  
    Damage dealt by your pet's [[spell:17253]], [[spell:16827]], and [[spell:49966]]
  
    increased by 100%.
- [[spell:392053]] has been redesigned. [[spell:34026]]
  
    critical damage increased by 15%. This is a huge nerf to
  
    [[spell:19574]]-driven burst, as it used to increase ALL pet critical
  
    strike damage by 35%.
- [[spell:407412]] now reduces [[spell:217200]]'s periodic rate
  
    increase by 33% (was 50%).
- [[spell:378207]] damage has been halved.
- [[spell:115939]] duration increased to 10 seconds (was 8 seconds), now
  
    causes your pets to strike nearby enemies for 55% of the damage dealt (was
  
    40%), and can no longer be cancelled.
- [[spell:468701]] now increases [[spell:193455]]'s critical
  
    strike damage by 20% (was 50%).
- [[spell:378244]] now increases [[spell:193455]]'s damage by 10%
  
    (was 35%).
- [[spell:120679]] summons can now be tracked on the Cooldown
  
    Manager.
- [[spell:217200]] damage increased by 25%, then reduced by 12%.
  
    [[spell:34026]] damage increased by 20%. [[spell:193455]] damage
  
    increased by 20%, then by a further 30%. Auto Shot damage increased by 20%,
  
    and ranged auto-shot damage increased by 600%.
- **Pack Leader:** [[spell:472639]] now increases the damage of your
  
    next [[spell:193455]] by 100% (was 200%), and now lasts for 1 minute (was 20
  
    seconds). It is cancelled when you start a raid encounter or a Mythic+
  
    dungeon. [[spell:1264797]] now increases the [[spell:193455]] bonus by
  
    25% (was 50%).
- **Dark Ranger:** [[spell:467749]] damage increased by 300%.
  
    [[spell:430715]]'s [[spell:466930]] damage reduced by 40%, and
  
    [[spell:1277565]] now correctly increases [[spell:430715]]'s
  
    damage. [[spell:442419]] summons can now be tracked on the Cooldown
  
    Manager.
- **Tier Set:** **2-Set:** [[spell:217200]] causes your pets to
  
    [[spell:199530]] 1 additional time at 50% effectiveness. **4-Set:**
  [[spell:199530]] causes your next [[spell:193455]] to either benefit
  
    from [[spell:115939]] at 30% effectiveness per stack, or strike your
  
    target for an additional 20% damage per stack, stacking up to 4 times.

:::

:::

### Midnight   Changes Overview

2.6.

#### Beast Mastery Hunter Changes in Midnight

The Midnight Expansion brings huge changes for all Hunter specs, primarily

focused on streamlining and simplifying aspects of the kit.

2.6.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

- No more [[spell:378769]] procs from Auto-Shots.
- [[spell:217200]] has a 50% chance to grant
  
  [[spell:378769]], and [[spell:34026]] has a 20% chance.
- After you activate [[spell:19574]], the Bestial Wrath button itself
  
  turns
  
  into [[spell:392060]], a powerful cast that activates
  
  [[spell:378769]] and also kicks/silences all targets hit for 1 sec.

2.6.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader

- Increased Focus regen with each auto-attack granting 2 Focus.
- The Bear has been nerfed by 40%, making it more balanced relative to the
  
  other Beasts. In the past, we often had to pay special attention to optimizing
  
  around the Bear. Now, Beasts are more balanced which means that you do not tend
  
  to worry too much about which one you have coming up.
- Our TWW S3 4PC mechanic, [[spell:201430]], is back, but it only
  
  triggers from your first [[spell:34026]] after activating
  
  [[spell:19574]]. Which means that every 30 seconds, for around 8
  
  seconds, you best hope that the mobs are not either moving, on a ledge, above
  
  you, below you, to the side of you, or behind you.

2.7.

#### DPS & Gameplay Changes

- [[spell:272795]] is entirely gone as a mechanic.
  
  [[spell:257944]] is now just flat crit as well. In other words, no
  
  more buff maintenance using [[spell:217200]].
- [[spell:1264359]] is a new talented ability that deals heavy AoE
  
  damage and activates [[spell:115939]] for 10 seconds. Since it has an
  
  8-second cooldown, pressing it whenever it is available keeps
  
  [[spell:115939]] up permanently.
- [[spell:19574]] is now a flat 30-second cooldown. Its initial
  
  damage is increased, while its damage buff component is lowered to 20% from
  
  30%.
- [[spell:378442]] has been redesigned and can now use pet
  
  [[spell:199530]]s to help spread your [[spell:217200]] DoT on
  
  AoE.
- The new Apex Talents,
  
  [[spell:1273043]],
  
  [[spell:1273065]], and [[spell:1273145]] (all three talents
  
  share a name), aside from some passive damage, cause [[spell:217200]]/
  
  [[spell:193455]], and [[spell:466930]] to buff the damage of your next 
  
  [[spell:34026]], encouraging you to weave a "filler" between each KC.

2.8.

#### Apex Talents

Midnight introduces new Apex Talents, unlocked between Level 80 and 90. Beast

Mastery gets:

1. [[spell:1273043]]
2. [[spell:1273065]]
3. [[spell:1273145]]

They make [[spell:19574]] do a significant chunk of damage, instead of

just being a passive damage buff. The last point also incentivizes never using

[[spell:34026]] twice in a row; you should always use a filler ability

like [[spell:217200]] or [[spell:193455]] in between.

2.9.

#### Survivability Changes

- Hunters have +2% higher max HP than previously.
- [[spell:109304]]'s cooldown is now a 1-minute flat, instead of variable
  
  (and often lower).
- [[spell:186265]]'s cooldown is now 2:00 with talents, down from
  
  2:30.
- [[spell:186265]] can now be a 50% damage reduction with talents,
  
  up from 30%.
- [[spell:53480]] is now an external defensive that can be used on
  
  yourself or any friendly target to reduce their damage taken by 15% for 10 sec,
  
  but 50% of their damage taken will be taken by your pet. It will end prematurely
  
  if your pet drops below 25% health.
- [[spell:388035]] is now 3% passive damage reduction, instead of
  
  being an active defensive cooldown.

2.10.

#### Utility Changes

- [[spell:257284]] is now a universal 3% damage increase against a
  
  single-target. This essentially guarantees Hunter a raid spot in every raid. It
  
  is also a boost to the group in Mythic+, though it is much less potent
  
  there.
- [[spell:147362]] now spell-locks the target for 5 seconds, up from
  
  3.
- [[spell:187650]] can now slow the target by 70% for 4 sec after the
  
  trap breaks.
- [[spell:19577]] is now our sole stun/stop. A choice node either
  
  reduces its cooldown to 40 sec, or makes it a 1-second AoE stun.
  
  [[spell:462033]], [[spell:236776]], and [[spell:186387]]
  
  are all gone.
- The slows from [[spell:195645]] and [[spell:5116]] are 25% and
  
  10% stronger, respectively.
- [[spell:472729]] is now a Class Tree node and not attached to
  
  the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Hero Talent. It is a choice node with
  
  [[spell:459460]], which extends [[spell:109248]]'s stun by
  
  1 sec.
- [[spell:459466]] is gone.
- [[spell:213691]] is gone.
- [[spell:459533]] is gone.
- [[spell:321468]] is gone.

2.11.

#### Miscellaneous Changes

- [[spell:186257]]'s initial "super" speed burst is now twice as
  
  long with talents.
- [[spell:53351]] is gone and is a Marksmanship-tree exclusive.
- Successfully kicking with [[spell:147362]]/[[spell:187707]] now
  
  grants 30 Focus, up from 10, but soothing/purging with
  
  [[spell:19801]] no longer grants Focus.

Overall, we are gaining defensiveness and mobility, while in the utility

department, we are losing some things (like the ability to move mobs) but

gaining others (stronger Mark, streamlined AoE stun, stronger kick and more

Focus return on kicking). We think the changes are broadly positive!

3.

### Basics of Beast Mastery Hunter Gameplay

Beast Mastery Hunter is a spec about buff, cooldown, and pet management all

at the same time. The fundamental rotation is simple, focused on spending Focus

exclusively, since you have no active Focus generators.

Most of your time will be spent casting [[spell:34026]] and

[[spell:217200]], juggling them, and ensuring neither reaches two charges, while

filling in with [[spell:193455]]. A quick breakdown of the spec can be found in 

the list below.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_bestialdiscipline.jpg>) **Always be Casting**  
  
  
    Casting as many abilities as possible matters more than pressing the perfect
  
    button every time, and dead time is the single biggest thing holding most
  
    players back from their DPS goals.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_beastmastery.jpg>) **Put a Shot Between Your Kill Commands**  
  
  [[spell:217200]] and [[spell:193455]] (and [[spell:466930]], as
  
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger) each buff your next [[spell:34026]] by 30%
  
    through [[spell:1273145]]. Taking advantage of this for every Kill Command
  
    is mandatory, on single-target and on AoE alike.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_sickem.jpg>) **Keep Wild Thrash on Cooldown in AoE**  
  
  
    Aside from being your source of [[spell:115939]], which causes all of your
  
    pet abilities to deal AoE damage, the button itself also does a ton of damage.
  
    Use it exactly on cooldown with no delay as long as there is more than 1
  
    target up.

4.

### How to Gear Up as a Beast Mastery Hunter

Our dedicated Beast Mastery gearing page covers Season 2 gear from your

first upgrades through to the full best-in-slot list. We still recommend

simming yourself for the ideal answer. Once you've picked up some gear, you'll

need the appropriate consumables, gems, and enchants to go with those new

items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **30 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Moved the Resonant Bellowstone up to B Tier, the Vashnik's Sanguine Rancor and Void Execution Mandate down to C Tier, and the Sapling of the Dawnroot down to D Tier in the Trinket Rankings.
- **30 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Fixed the Chest tooltips showing two Venomcursed effects.
- **15 Sep. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Clarified that Liquid Luster is the Mythic+ Potion, while Potion of Recklessness remains the pick everywhere else.
- **07 Sep. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Added Liquid Luster pre-pot timing.
- **07 Sep. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Split the Pack Leader AoE opener into Mythic+ and Raid versions.
- **07 Sep. 2026 (this page):** Raised the Damage rating to 3 and the Mythic+ rating to 4, and rewrote both sections.
- **04 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Moved the Font of Venomous Rage to S Tier in the Trinket Rankings.
- **04 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall BiS List Trinket to the Keeper's Seething Core.
- **04 Sep. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Removed the Barbed Shot Mouseover macro.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Raid BiS List Boots to the Boots of the Reckless Wayfarer and the Ring to the Apex Brute's Claw Ring.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Mythic+ BiS List Weapon to the Sinseared Repeater and the Ring to the Charged Sandstone Band.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall BiS List to Catalyze the Crown of the Eternal Fang and the Galerattle Gauntlets.
- **30 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Mythic+ and Delves Pack Leader builds now take Thrill of the Hunt over Bloody Frenzy. The performance is the same, but Focus regen is higher leading to a smoother rotation.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Weapon enchant to Rite of the Hash'ey.
- **24 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added holding Wild Thrash when Bestial Wrath will be ready before Beast Cleave expires.
- **24 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Wild Thrash is now the first cast of the Pack Leader AoE opener and the top entry of its priority list, ahead of Barbed Shot. The Apex pet that Bestial Wrath spawns casts its own Bestial Wrath 1.5 seconds later and does not inherit the Beast Cleave that was up before it, so Wild Thrash has to follow Bestial Wrath for that hit to cleave.
- **22 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Added a note on crafting Legs.
- **22 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Added a Pack Leader Raid AoE/Cleave build, which takes Thrill of the Hunt over Training Expert.
- **21 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated the Pack Leader Single-Target Build in light of recent hotfixes.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Nebulous Voidcore bonus roll priorities following the Gebbo's Bottomless Bag nerf.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Overall BiS List Ring and Boots to match the Mythic+ setup, since the raid has enough cleave that gearing for single target does not make sense.
- **18 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated the Utility Talents for Raid builds.
- **17 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket tier list.
- **17 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** The Omnium Folio setup now takes Void-Tainted Shell over Self-Mending.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Reworked the crafting advice, corrected the Voracious Heart of Ula'tek and Gebbo's Bottomless Bag entries in the raid-items list, and added start of season Voidcore and Crest advice.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Trinket tier list and the Raid BiS Trinkets following the latest tuning.
- **15 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** The Dark Ranger Mythic+ build now takes Kill Cleave over Razor Sharp.
- **15 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Tier Set section for the 4-set buff.
- **15 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** The Dark Ranger Mythic+ build now takes Kill Cleave over Razor Sharp.
- **15 Aug. 2026 (this page):** Updated the 4-set bonus for its buff to 30% Beast Cleave effectiveness and 20% damage per stack.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Nebulous Voidcore bonus roll priorities.
- **14 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Raid BiS Gloves to the Catalyzed Grips of Swirling Fury from Nymrissa Wavecaller.
- **12 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Added Catalyst and Great Vault FAQs and a socket section, fixed Catalyst drop locations, and updated sources of the Raid BiS Helm and Gloves.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Delve builds now take Emergency Salve over Wilderness Medicine.
- **12 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Fixed the Dark Ranger Delve build's talent link.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **16 Jul. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated Heirloom stat advice.
- **16 Jul. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Corrected Fortitude of the Bear and Updraft descriptions, removed the Beast Mastery-only exotic pet table, and updated expansion references.
- **16 Jul. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Added a trinket quick-reference and clarified crafting guidance.
- **16 Jul. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated Weapon and Boots enchant recommendations, and fixed enchant tooltip links.
- **16 Jul. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Clarified the Crit vs Haste rule of thumb.
- **16 Jul. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated the Pack Leader Mythic+ talent build.
- **16 Jul. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Corrected Stampede's length to 30 yards.
- **16 Jul. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Clarified Hero Talent guidance and Raid AoE build notes.
- **16 Jul. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Added Wild Thrash and Wailing Arrow to the ability glossary, and alphabetized the ability tables.
- **16 Jul. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated the Pack Leader Mythic+ talent build.
- **16 Jul. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated the recommended non-Bloodlust pet to Aqiri.
- **16 Jul. 2026 (this page):** Clarified Deathblow sources and the performance overview.
- **17 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated recommended week 1 Folio Rune based on real-world data trumping sims.
- **16 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Fixed boots in M+ BiS List.
- **16 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Clarified Weapon Enchant choice.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **21 May 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Simplified Barbed Shot priority nuances for Pack Leader single-target, as playing around Focus levels was found to not be a consistent DPS increase to be worth the hassle of keeping track of it.
- **29 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** In Dark Ranger AoE, added note of Black Arrow being a top prio to activate Beast Cleave if it is down prior to a Bestial Wrath.
- **28 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated wording around Wailing Arrow usage, clarifying that it is worth using in every Bestial Wrath, even if you miss the optimal window by mistake.
- **27 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotation updates.
- **27 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Dark Ranger single-target build.
- **25 Apr. 2026 (this page):** Updated Beast Mastery performance evaluation.
- **23 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated Ring Enchant.
- **23 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Fixed issue with Pack Leader M+ Build.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **10 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Pack Leader Rotations.
- **08 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** BiS List and Trinket Tier List update.
- **05 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Beast Mastery Dark Ranger rotation and opener slightly.
- **04 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added Puzzle Box to opener.
- **03 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated Pack Leader Mythic+ Build.
- **03 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Pack Leader Mythic+ Build.
- **02 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small Dark Ranger AoE Rotation Update.
- **31 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Minor update to the BM Dark Ranger AoE Opener.
- **25 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated Mythic+ Gear BiS List.
- **24 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Dark Ranger Rotation.
- **23 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Update Hero Talent description.
- **22 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated both Mythic+ Builds.
- **22 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated both single-target builds, and both Mythic+ Builds.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **04 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated Crafting recommendation for endgame.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated for Midnight 12.0.1.
- **11 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Dark Ranger opener update.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated Stat Diminishing Returns values for Level 80.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated Talent Builds for the upcoming 12.0.1 changes.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Talent Builds for the upcoming 12.0.1 changes.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **04 Dec. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Added a Call of the Wild Araz/Prism Macro.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Clarified optimal Potion and Prism usage for Dark Ranger.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **22 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated Dark Ranger M+ Build, swapping War Orders to Wild Call to smooth out Frenzy management further, gaining ~2.5% AoE, ~2% Prio, but losing ~1% single-target in the process.
- **22 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Expanded on the value of Multidotting as BM Dark Ranger and clarified that it is actually not that hard to do you guys.
- **22 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Dark Ranger M+ Build, swapping War Orders to Wild Call to smooth out Frenzy management further, gaining ~2.5% AoE, ~2% Prio, but losing ~1% single-target in the process.
- **21 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Dark Ranger AoE Rotation updates concerning Barbed Shot and Kill Command priorities.
- **17 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated M+ Hero Talent recommendation.
- **17 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small Dark Ranger rotation updates.
- **17 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Mythic+ Hero Talent recommendation.
- **13 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated BM Dark Ranger Mythic+ Build.
- **13 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated BM Dark Ranger Mythic+ Build.
- **12 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated Trinket Tier List and BiS List.
- **12 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated/Simplified Barbed Shot usage on single-target significantly.
- **10 Sep. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated stat priority for Dark Ranger.
- **10 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotational updates with small gains found in being less aggressive with Bestial Wrath usage. Single-target talent build is also updated with this playstyle.
- **10 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated single-target build and added Raid AoE Build.
- **09 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Further rotational updates for Dark Ranger.
- **09 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Officially swap over recommended single-target build to Dark Ranger.
- **08 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added a small minmax around Barbed Shot, Call of the Wild, and trinket usage for Dark Ranger.
- **07 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated BiS Ring.
- **07 Sep. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Stat Priority wording update.
- **07 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Dark Ranger AoE Rotation and Opener fixes.
- **06 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated BiS Lists and Trinket Tier Lists to include Dark Ranger-specifics.
- **06 Sep. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Small stat priority updates and rearranged the page.
- **06 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated verbiage slightly on NoMulti versus Multi builds and Dark Ranger.
- **06 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Dark Ranger opener and made Dark Ranger single-target show as the default, though it should not be played until September 9th.
- **06 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Dark Ranger builds and recommendations for builds and verbiage of Mythic+ build descriptions. This page will shift to recommend Dark Ranger for single-target on September 9th.
- **06 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated the recommended single-target build. This will not be correct until September 9th.
- **03 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** 1-point swap in the NoMulti build, 0.2% loss but I believe it feels a lot nicer to play and leaves less room for error.
- **03 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** 1-point swap in the NoMulti build, 0.2% loss but I believe it feels a lot nicer to play and leaves less room for error.
- **02 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Trinket Tier List and BiS updates.
- **31 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Opener updates and clarifications around Double Stampede/Bestial Wrath holding.
- **17 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rotational updates and clarifications.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Update Trinket Tier list for tuning,
- **16 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added info on DPS gain from holding Bestial Wrath.
- **08 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added a note on Kill Command-holding for Howl during Lead from the Front with 4PC.
- **06 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** No-Multi Talent update.
- **05 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** AoE Rotation and opener changes.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **25 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated instructions for swapping to the 1-minute Bloodshed build, found listed under the baseline single-target build.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Titan Disc recommendation again based on further analysis into Static Charge oversimulating its actual performance.
- **24 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated the Single-Target Talent Build. Long story short, the new Static Charge optimal Titan Disc has powerful negative scaling with A Murder of Crows. It is a smaller DPS loss to drop A Murder of Crows for Serpentine Rhythm, than it is to drop Static Charge for another Titan Disc.
- **23 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the Titan Disc recommendation based on the latest hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **20 May 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added a small rotational minmax to the single-target rotation worth ~+0.3% DPS.
- **13 May 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the ordering of Dinar recommendations.
- **10 May 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the wording/Dinar recommendation status for House of Cards and Signet slightly.
- **09 May 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated Corruption Enchants & Puzzling Cartel Chip Dinar section.
- **09 May 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated Corruption Enchants section.
- **09 May 2025 (this page):** Updated Best Spec section.
- **29 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Put the Barbed Shot Helper in a more obvious place.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Add list of Dinar-purchasable items.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Added Corruption Enchants information.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **29 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated the position of Eye of Kezan in the Mythic+ Trinket Tier List.
- **25 Mar. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for March 25 Updates.
- **25 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for March 25 Updates.
- **25 Mar. 2025 (this page):** Updated for March 25 Updates.
- **18 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated the recommended MDT Sim/Mythic+ Simulation Route Pastebin.
- **18 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the rotation defaults for new Talents.
- **18 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated note on viability of the Bloodshed/1-minute ST variant build.
- **17 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated wording on Improvised Seaforium Pacemaker.
- **17 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated the recommended Talent Build for Mythic+.
- **17 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated the recommended Talent Build for Mythic+ and Raid AoE.
- **14 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Single-Target opener change.
- **09 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Rewrote and simplified the Rotation significantly.
- **09 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Dark Ranger Single-Target Talent Build.
- **07 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Updated builds based on real-world data.
- **04 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **29 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated Queen Ansurek Build.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for the Cyrce's Circlet now going to Item Level 658.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **04 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Removed Withering Fire holding for Bestial Wrath.
- **31 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated note on what talents you could be flexible with for Beast Mastery Dark Ranger M+.
- **31 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated note on what talents you could be flexible with for Beast Mastery Dark Ranger M+.
- **30 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Small Barbed Shot AoE Priority change.
- **30 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Added Dark Ranger Single-Target Build and re-tested all builds for latest hotfixes.
- **30 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for October 29 Hotfixes.
- **30 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for the latest hotfixes.
- **30 Oct. 2024 (this page):** Updated Best Spec Section for hotfixes.
- **26 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated Talent Builds per Boss.
- **26 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated Hero Talent Order.
- **26 Oct. 2024 (this page):** Reinstated the Best Spec section.
- **25 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated Hero Talent recommendation and information.
- **25 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated both rotations slightly.
- **25 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated the single-target build slightly for a ~0.5% DPS gain.
- **22 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **22 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.0.5.
- **22 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **09 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Further updated Talent Builds for the October 8th Hotfixes.
- **08 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated Talent Builds for the October 8th Hotfixes.
- **08 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated default talent selections.
- **08 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated Talent Builds for the October 8th Hotfixes.
- **08 Oct. 2024 (this page):** Updated the "Best Hunter Spec" section for the updated October 8th Hotfixes.
- **02 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added more specific Trinket usage information.
- **27 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated Ara-Kara Tips.
- **24 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated a BiS Ring.
- **13 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Added note about double-Dawnthread Lining not working and how to fix it.
- **13 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated and clarified some tips.
- **10 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Streamlined Crafting recommendations, split them by Raiding and Mythic+, and reformatted. Removed Disclaimer. Fixed some BiS List discrepancies.
- **10 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Dark Ranger Single-Target Opener slightly.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Added separate Stat Priorities for Pack Leader on AoE and Single-Target.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Single-Target Opener update.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Preliminary update for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **30 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-mythic-plus-tips>)):** Preliminary update pass in preparation for The War Within Season 1.
- **30 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Preliminary update pass in preparation for Season 1.
- **30 Aug. 2024 (this page):** Preliminary update pass in preparation for Season 1.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Added a note about Crafted gear to the Pre-Season BiS List.
- **26 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the Kill Shot priorities in the Single-Target Rotation based on APL updates by Yanix, +0.5% DPS.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Added a recommended Delves build.
- **23 Aug. 2024 (this page):** Re-introduced a section talking about the Best Hunter Specs in the War Within.
- **22 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for The War Within.
- **22 Aug. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Updated for The War Within.
- **22 Aug. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Updated for The War Within.
- **22 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **22 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for The War Within.
- **22 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **22 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for The War Within.
- **22 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **22 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **22 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for The War Within.
- **22 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for The War Within.
- **22 Aug. 2024 (this page):** Updated for The War Within.
- **01 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Simplified Dire Beast rotation use. Small opener changes.
- **24 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated the rotation and openers based on the latest APL updates.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/beast-mastery-hunter-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([pets page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pets-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-weak-auras>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spec-builds-talents>)):** Updated the M+ Talent Build.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **26 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/beast-mastery-hunter-the-war-within-pve-guide>)):** Updated for the June 25th changes.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/beast-mastery-hunter-the-war-within-pve-guide>)):** Page added.
- **29 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker Gem recommendations.
- **20 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker Gem rankings based on live server power levels.
- **17 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** Updated Tinker and Cogwheel Gem recommendations in light of recent changes and new information.
- **16 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** Updated recommendations in light of recent nerfs to some Tinker Gems.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/beast-mastery-hunter-mists-of-pandaria-remix-guide>)):** Page added.
- **11 May 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Added a macro to assist when you have forgotten, or simply need to summon your pet on the fly.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Season 4.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.5
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **06 Dec. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated the Mythic+ build.
- **04 Dec. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated with new builds accounting for recent changes.
- **18 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Small update to the AoE/Mythic+ Build. Same DPS, but nicer to play.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.2
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.1.7
- **16 Aug. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Restructured the page.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5.
- **22 May 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Leg Enchant, as it was found that the Lambent Armor Kit does not provide Stamina as it was assumed.
- **13 May 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended food and Leg enchant.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Gemstones after sim updates, and the discovery of a new, powerful combination.
- **23 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Yet another update to the recommended Gemstones based on a slew of hotfixes.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the Onyx Annulet Information in light of the March 21st buff.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **22 Feb. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated and clarified optimal Gems and Enchants.
- **20 Feb. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Added information about a DPS-increasing Glyph for Beast Mastery Hunters.
- **24 Jan. 2023 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-2-changes-analysis>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Added Barbed Shot Mouseover Macro.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **04 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommended Phial.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated the recommendation and description of the optimal Flasks/Phials.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight Season 1.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **04 Nov. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** Updated the optimal Conduits back again, due to APL updates and the Alpha Predator bugfix.
- **03 Nov. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** Updated the optimal Conduits.
- **27 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** Updated the general Covenant recommendation.
- **27 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated recommended Covenant and Soulbinds.
- **27 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Updated recommended Covenant and Soulbinds.
- **27 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated recommended Covenant and Soulbinds.
- **26 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-legendaries-shadowlands>)):** Updated the BiS Single-Target Legendary.
- **26 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** Updated Kyrian's description and competitiveness level.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/beast-mastery-hunter-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/beast-mastery-hunter-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-2-changes-analysis>)):** Added information about how the set bonus affects the Ferocious Appetite Conduit.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** Updated thoughts on all of the Covenant-specific Legendaries, and added the July 13th Hunter Buffs to the changes.
- **10 Jun. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** Added information about the Venthyr-specific Legendary.
- **12 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** Added information about 4 new Covenant-specific Legendaries.
- **10 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/beast-mastery-hunter-patch-9-1-changes-analysis>)):** Page created with initial information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **23 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for more bosses.
- **10 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Updated some tips and added two very important ones for Orgozoa and Queen's Court.
- **13 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for most bosses on Heroic difficulty.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **13 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Added Beast Mastery tips for Uu'nat.
- **01 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Added Beast Mastery tips for The Restless Cabal.
- **14 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **14 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for Crucible of Storms and no changes are necessary.
- **14 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added boss tips for Beast Mastery Hunter in Battle of Dazar'alor.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** Added tips for Mythic G'huun.
- **18 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** Added more tips for the first 5 bosses, now with a Mythic focus for some of them.
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** Added much more specific content to all bosses except for G'huun.
- **02 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** Added content.
- **12 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-uldir-raid-guide>)):** Empty page for now.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Beast Mastery Hunter leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Hunter leveling guide](<https://www.icy-veins.com/wow/hunter-leveling-guide>).

1.

### Beast Mastery Hunter Leveling Guide for Midnight

Beast Mastery Hunter, thanks to being able to use its pet as a

tank, is an excellent questing leveler. This spec is able to do large pulls

regularly like a

tank thanks to [[spell:34477]]/[[spell:459546]], while doing much

more damage than a tank.

Grab a Ferocity pet and pull mobs with

[[spell:217200]]/[[spell:193455]].

Once they are stacked up, use the combo of [[spell:1264359]] → 

[[spell:19574]] → [[spell:34026]] to burst them down!

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the highest item

level. The only exception to this rule is if you have a Ring or Necklace with a

slightly lower item level, but two secondary stats on it instead of one.

When using Heirloom items, and when choosing between other pieces of gear, we

recommend prioritizing Mastery, then Critical Strike, wherever possible.

1.2.

#### Useful Leveling Consumables for Midnight

When Leveling up from 80-90 in the Midnight Expansion in particular, there

are a lot of consumables that can help ease the process, aside from the

"regular" PvE consumables mentioned further below.

- [[item:132516]] — Massive movement speed boost that works when
  
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  
  distances quickly.
- [[item:168412]] — Do not forget this Mount Equipment to
  
  make your mounts faster on the ground.
- [[item:172063]] — An incredible amount of movement speed from a
  
  Food.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), follow the

point-by-point allocation of the below tree as you gain levels. The Leveling

Rotation section below has a slider that shows your rotation at each level.

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsBzwQDbAAYGmZmlHYGzMzMjZGMzYmxMzYGzYbmZMjZGYyAAAAAAAAgxMzMgZWAsMzCYbAYA"
}
```
:::

:::details 来源计算器编码
```
#9D-QqBgEETAPMMHZUpCOOLiikeISSFoWHy1ocE-JmGNc0sUIiaOAOU8x5J9AAUdSBJuxgA-AAAA-PIMEAg0QxQoIzC-
```

:::

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider to

select your level, and watch as the leveling rotation grows with each level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 46 起：**[[spell:34477]] redirects all the aggro/threat 
   
   generated by your [[spell:217200]], [[spell:193455]], etc. to 
   
   your pet. So you can activate it, hit a few mobs with Barbeds and Cobras, and 
   
   watch them flock to your pet for AoE damage. From Level 48, it will also reduce 
   
   your pet's damage taken and double as a defensive for your pet. This ability is
   
   a big part of why leveling as Beast Mastery is considered so good!
2. **等级 5 起：**Use [[spell:136]] for large pulls to keep your pet
   
   healthy.
3. **等级 23 起：**On AoE, use [[spell:1264359]] to maintain
   
   [[spell:115939]] on your pet.
4. **等级 37 起：**Use [[spell:19574]] on pulls and mobs that will
   
   survive most of its 15-second duration.
5. **等级 11 起：**Use [[spell:34026]] on cooldown.
6. **等级 15 起：**Use [[spell:217200]] to keep it from hitting 2
   
   charges.
7. **等级 19 起：**Use [[spell:193455]] as a filler.
8. **等级 1–10：**Spam [[spell:185358]].
9. **等级 1–10：**Use [[spell:56641]] as a filler.

4.

### Best Leveling Pet

All pets do the same damage, but they vary in their utility and special

abilities. The absolute best Leveling Pet is a

[Clefthoof](<https://www.wow-petopia.com/family.php?id=clefthoof>).

They take both less Physical damage

and more healing than any other pet. We recommend you keep their spec

set as **Ferocity** to fully utilize this extra healing. Any Clefthoof will

do, and there are tons available from when you reach Level 10, so check out the

link, find your favorite, and get hunting!

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated Heirloom stat advice.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Beast Mastery Hunter in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Beast Mastery Hunter

This section is intended for players who are new to the game or class, have

no intentions of raiding Mythic difficulty, or simply want a more

straightforward way to play their specialization without being overwhelmed by

the numerous priorities and active abilities that need to be taken into

consideration for optimal play.

Beast Mastery is quite simple in its execution and it is an ideal spec for

someone new to raiding, or just WoW in general. It is one of the most popular

specs in the game, and has seen use in many World First kills.

Beast Mastery is mostly just about pressing your [[spell:34026]] and

[[spell:217200]] on cooldown, and filling with [[spell:193455]] otherwise.

On AoE, you add in [[spell:1264359]] on cooldown as well, and your primary

cooldown [[spell:19574]] is also used aggressively on cooldown. The only

real nuance here is that you must never cast 2 [[spell:34026]]s

back-to-back on single-target.

Here are three quick rules of thumb that will help you when navigating the

spec.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_bestialdiscipline.jpg>) **Always be Casting**  
  
  
    Casting as many abilities as possible matters more than pressing the perfect
  
    button every time, and dead time is the single biggest thing holding most
  
    players back from their DPS goals.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_beastmastery.jpg>) **Put a Shot Between Your Kill Commands**  
  
  [[spell:217200]] and [[spell:193455]] (and [[spell:466930]], as
  
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger) each buff your next [[spell:34026]] by 30%
  
    through [[spell:1273145]]. Taking advantage of this for every Kill Command
  
    is mandatory, on single-target and on AoE alike.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_hunter_sickem.jpg>) **Keep Wild Thrash on Cooldown in AoE**  
  
  
    Aside from being your source of [[spell:115939]], which causes all of your
  
    pet abilities to deal AoE damage, the button itself also does a ton of damage.
  
    Use it exactly on cooldown with no delay as long as there is more than 1
  
    target up.

2.

### Beginner's Guide to Beast Mastery Hunter in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader   Single-Target Talents

2.1.

#### Single-Target Talents for Beast Mastery Hunter

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader single-target build, used for

most raid encounters.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzsYmZMjZwYaGAAAAwMAAAMmZGgZ2gNYWAbDAD"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AADFGHQQSUacgikqwyy048+AFHJLNdC-AAAA-BCEGIUw4ARZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader   AoE Talents

2.2.

#### Dungeon Talents for Beast Mastery Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for Mythic+, and

other AoE-focused content. It is based on simulating the conditions found in

real Mythic+ dungeons and seeing not just what does the most DPS, but what

actually clears the dungeon quicker in a group. There are builds that do more

AoE damage, but they all lose more single-target than they gain in terms of AoE,

and vice versa.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

2.3.

#### Beast Mastery Hunter Utility Talent Considerations

Not all Utility Talents are relevant for every dungeon. We have created these

Talent builds under the assumption that you are not going to be very diligent

about swapping talents on a per-dungeon basis. However, the goal is to never

be left at a disadvantage by lacking a super impactful Talent for a particular

dungeon. This means we do omit some occasionally useful picks.

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  - [[spell:34477]] only affects your personal threat, so it is quite weak
    
    for us.
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

### Beast Mastery   Basic Rotation

2.4.

#### Basic Rotation for Beast Mastery Hunter

Treat this as a priority list of the most important spells to cast. When in

doubt, simply cast the highest priority spell. You should aim to have no

"downtime" in your rotation. It is better to cast the wrong spell immediately

than to hesitate for 1 second and then cast the right spell. As you improve, this

priority should become second nature to you.

1. Cast [[spell:19574]] whenever possible. It buffs all your damage
   
   massively and does good damage on its own, too.
2. On two targets and up, use [[spell:1264359]] whenever possible. Never use it
   
   on just a single target.
3. Cast [[spell:34026]] whenever possible.
4. Cast [[spell:217200]] whenever possible.
5. Cast [[spell:193455]] as a "filler", an ability you only use when none of
   
   the more important things are available.

2.4.1.

##### Apex Talent: Nature's Ally

Your Apex Talents add one rule to how you play. You should try not to cast

2 [[spell:34026]]s in a row, always weaving a [[spell:217200]] or

[[spell:193455]] between them. This holds on AoE as well as single-target.

2.4.2.

##### Season 2 Tier Set

The 2-set makes [[spell:217200]] cause an extra [[spell:199530]], and

the 4-set makes each [[spell:199530]] build up the [[spell:1299389]] on

your next

[[spell:193455]], up to 4 stacks. When you have 3+ stacks, you should

prioritize Cobra over [[spell:217200]].

### Beast Mastery   Defensives

2.5.

#### Defensive Spells for Beast Mastery Hunter

[[spell:109304]] is your primary self-heal with a 1-minute cooldown. Use

this when you drop below 50% HP to help out your Healer!

[[spell:186265]] is your immunity. It can be used to completely

negate the damage and effects of most spells targeted on you. Use it if you are

assigned to, or in a pinch if you worry that an upcoming mechanic will kill you!

It is also a 30-50% damage reduction, though it is not so commonly used for

simple damage reduction purposes.

[[spell:264735]] is our most powerful defensive besides

Turtle, a 30-40% damage reduction with 2 charges on a 1.5-minute cooldown each.

Use it to reduce damage taken from hard-hitting mechanics. Optimal use of this

ability entails using it **proactively**, before heavy incoming damage.

[[spell:5384]] is a very unique Hunter ability. It can be used to drop

aggro and combat, and it can also be used to stop casts on you. Mobs will

usually stop casting mid-cast if you appear to be dead! With the

[[spell:459517]] Talent, it will also dispel all Poison and Disease

effects from you.

### Beast Mastery   Best Pets

2.6.

#### Best Pets for Beast Mastery Hunter

The most important thing to say about Pets is that **they all deal the same

base DPS**. The differences come from utility, defensive capabilities, and how

quickly they reach a moving target.

First of all, you need to find out if you need to be using

[[spell:2825]]/[[spell:32182]] in your group. Only Hunters, Mages, Evokers,

and Shamans can use Bloodlust, so if there is no one else of those classes in

your group, then it is on you!

If you do need to [[spell:2825]], you need to use any **Ferocity**

Pet, since these come with the [[spell:264667]] Bloodlust ability. Use [this website](<https://www.wow-petopia.com/abilities.php>) to find a cool

Ferocity Pet for Lusting purposes!

If you **do not** need to Bloodlust, then the best Pet is an [Aqiri](<https://www.wow-petopia.com/family.php?id=aqiri>) set to

**Tenacity**. Their +30% passive movement speed means they spend less time

chasing moving targets, which is a small DPS gain over other pets.

With that said, this is a pretty small bonus and if you do not need to

Bloodlust, you can basically use any kind of pet that you want. Tenacity is

ideal as your default Pet Spec for its survivability.

### Beast Mastery   Stat Priority

2.7.

#### Stat Priority for Beast Mastery Hunter

The general stat priority for a Beast Mastery Hunter is seen below.

This is very much a rough guideline, and is designed for players who do not wish

to sim their character. If you are simming your character, please disregard this

stat priority completely and follow your sim!

For more information on what's presented on this page, check out our main 

[Stat Priority page](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>).

Item Level tends to beat out better secondary stats on gear.

Mastery

Critical Strike

Haste

Versatility

### Blizzard   Combat Assistant

2.8.

#### Combat Assistant & One-Button Mode

The game offers the option of an in-game "Combat Assistant", which has two 

modes: a Rotation Helper that will suggest spells to cast next, and a 

"One-Button Mode", that automatically performs this rotation for you if you 

simply press one button repeatedly.

These tools can be worthwhile for beginners, as they provide a reasonable 

"minimum" level of performance. For Beast Mastery Hunter, using just 

the Rotation Helper is a ~1-2% DPS loss compared to playing perfectly (which 

almost nobody does). Using the one-button mode on top of it takes the total 

loss to ~9-12%.

Obviously, peak performance cannot be obtained using these tools, but it is 

something worth considering if you are happy to take the DPS losses above for 

the sake of ease of play. Do not let anyone in-game or on a forum or Discord 

tell you that there is something inherently wrong with using these tools! 

Blizzard created them for a reason, and the game is about having fun, whatever 

that means for you.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated the recommended non-Bloodlust pet to Aqiri.
- **16 Jul. 2026:** Updated the Pack Leader Mythic+ talent build.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **06 Sep. 2025:** Updated the recommended single-target build. This will not be correct until September 9th.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for the latest hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **08 Oct. 2024:** Updated Talent Builds for the October 8th Hotfixes.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Dec. 2023:** Updated the Mythic+ build.
- **04 Dec. 2023:** Updated with new builds accounting for recent changes.
- **18 Nov. 2023:** Small update to the AoE/Mythic+ Build. Same DPS, but nicer to play.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Updated for Patch 10.1.7
- **16 Aug. 2023:** Restructured the page.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Beast Mastery Hunter in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Beast Mastery Hunter

Beast Mastery plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader in all content.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger is tankier, but it is far behind on damage in all situations, and

it is also a lot more effort to play optimally. We provide Dark Ranger builds below

for those who prefer the playstyle, but we do not recommend you playing it.

- **Single Target -** For anything pure single-target,
  
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader is our choice.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader again. It has the best damage across
  
    the board, and while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger is notably tankier, it is not
  
    enough to justify the DPS cost and rotational complexity it adds.

**Quick Start Import Codes:**

:::talents Beast Mastery Single-Target - Pack Leader
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwwMsBAgZYMzyMDzYmhhZGjZGzMjZMziZmxMmBjpZAAAAAzAAAwYmZAmZjxGMLgtBgB"
}
```
:::

:::talents Beast Mastery Raid AoE/Cleave - Pack Leader
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGmZmlZGzMzMjZGMzYmhZGzYmFzMjZMDGTzAAAAAAAAgxMzAMzGZDmFw2AwA"
}
```
:::

:::talents Beast Mastery Mythic+ - Pack Leader
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbEwsA2GAA"
}
```
:::

:::talents Beast Mastery Delves - Pack Leader
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGMGzYmhx0AAAAAAAAAzMGDYmNCWmZBsNAA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Pack Leader

Single-Target

recommended

Raid AoE/Cleave

recommended

Mythic+

recommended

Delves

recommended

Dark Ranger

Single-Target

Mythic+

Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Single-Target Talents

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader single-target build, used
for pure single-target scenarios.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Raid AoE/Cleave Talent Build

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for raid bosses with adds or a
second target. It keeps the full [[spell:115939]] package from our Mythic+
build and takes [[spell:257944]] over Training Expert, gaining single-target while keeping 2-target the same. Most of the raid
has something to cleave onto, so this is the build you will use for the bulk of
it.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Mythic+ Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for Mythic+.
It is based on simulating the conditions found in
real Mythic+ dungeons and seeing not just what does the most DPS, but what
actually clears the dungeon quicker in a group. There are builds that do more
AoE damage, but they all lose more single-target than they gain in terms of AoE, and
vice versa.

1.3.1.

##### Beast Mastery Hunter Utility Talent Considerations

Not all Utility Talents are relevant for every dungeon. We have created these
Talent builds under the assumption that you are not going to be very diligent
about swapping talents on a per-dungeon basis. However, the goal is to never
be left at a disadvantage by lacking a super impactful Talent for a particular
dungeon. This means we do omit some occasionally useful picks.

- Your "flexible" Talent points are, in our recommended order of most
  disposable:
  
  
  - [[spell:34477]] only affects your personal threat, so it is quite weak
    for us.
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    in others.

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Delve Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is
similar to our Mythic+ Talent build, but differs on the Class Tree picks to be
more suitable for solo play with a pet tanking.

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Single-Target Talents

This build is our best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger single-target build, used for
most raid encounters.

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger build for Mythic+, and
other AoE-focused content. It is based on simulating the conditions found in
real Mythic+ dungeons and seeing not just what does the most DPS, but what
actually clears the dungeon quicker in a group. There are builds that do more
AoE damage, but they all lose more single-target than they gain in terms of AoE, and
vice versa.

1.6.1.

##### Beast Mastery Hunter Utility Talent Considerations

Not all Utility Talents are relevant for every dungeon. We have created these
Talent builds under the assumption that you are not going to be very diligent
about swapping talents on a per-dungeon basis. However, the goal is to never
be left at a disadvantage by lacking a super impactful Talent for a particular
dungeon. This means we do omit some occasionally useful picks.

- Your "flexible" Talent points are, in our recommended order of most
  disposable:
  
  
  - [[spell:34477]] only affects your personal threat, so it is quite weak
    for us.
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    in others.

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Delve Talents

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger build for [Delves](<https://www.icy-veins.com/wow/delves-guide>). It is
similar to our Mythic+ Talent build, but differs on the Class Tree picks to be
more suitable for solo play with a pet tanking.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGGzsMzwMmZYYmxYmxMzYGzsYmZMjZwYaGAAAAwMAAAMmZGgZ2gNYWAbDAD"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AADFGHQQSUacgikqwyy048+AFHJLNdC-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGmZmlZGzMzMjZGMzYmhZGzYmFzMjZMDGTzAAAAAAAAgxMzAMzGsBzCYbAYA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AADEFGHQQSUYacegikoqs0248+AHNdC-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGMGzYmhx0AAAAAAAAAzMGDYmNALzsA2GAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIMMOOPQSSTUXXZbeffgiikoSVXD-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsMwAGwMsFYsAAgZ8AjZWegZYGzMmhZGDzYmZMjZWMzMmxMYMNDAAAAYGAAAGzMDmZAZDmFw2AwA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFHIJWYYaccegkkmuuy248ADFFHLruG-AACDFGHQSUacgikoqwyy04+AFHJLNdC-AAAA-AGIYgow4ApyCTD-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsFYsAAgZGzMziZYmZGMjZmZYGzMjZmZsNzMmxMsMmmBAAAAMDAAAegxYYmBEwsA2GAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AABDEFGHSUacegiqswyy024+AFHJLNB-AAAA-AGIcgow4ApyCTD-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsFYsAAgZGzMziZYGzwMjZmZYGzMjZmZwYMjZGGTDAAAAwMAAAMzYMMzACWmZBsNAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIMMOOPQSSTUXXZbeffgiikoSVXD-AABDEFGHSUacgioqswyy024+AFHJLNB-AAAA-AGIcgow4ApyCTD-
```

:::

The builds listed above are popular recommendations,

covering various different loadouts suited to each style of endgame content.

Each Talent Build will have its own rotation, and can also be manipulated 

further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is the "borrowed power" system introduced in Midnight's

[Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers

some moderately strong customization options after a short questline.

Some of these bonuses affect your damage output, but there are also defensive

and mobility options to choose from.

Your Folio progress carries over into Season 2. Take these bonuses:

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]. This one is the most 
  
    flexible and may change as your gear's stat demands do, just like your Flask 
  
    or Weapon Enchant. Mastery is a safe "never bad" pick.
- [[spell:1279614]]

3.

### Apex Talent: Nature's Ally

Midnight introduces new Apex Talents, unlocked between Level 80 and 90. Beast

Mastery gets:

1. [[spell:1273043]]
2. [[spell:1273065]]
3. [[spell:1273145]]

These make [[spell:19574]] deal a significant chunk of damage, instead of

just being a passive damage buff. The last point also incentivizes never using

[[spell:34026]] twice in a row; you should always use a filler ability

like [[spell:217200]] or [[spell:193455]] in between.

4.

### Hero Talents for Beast Mastery Hunter

Available at level 71, Hero talents are mutually exclusive trees you can

choose to slightly alter gameplay and visuals. Beast Mastery Hunter can choose

between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger gives you 

[[spell:466930]], which deals heavy damage. You will regularly get procs 

from it from [[spell:34026]] and

[[spell:217200]] 

that allow it to be used on any target at any time. These procs are not an 

especially high priority, falling between [[spell:34026]] and 

[[spell:217200]] for the most part. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger can be thought of 

as "Beast Mastery with an extra button" for the most part. When you activate 

[[spell:19574]], the button itself will turn into [[spell:392060]], 

which does heavy damage and gives you a [[spell:466930]] proc.

Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger offers [[spell:430709]], which is 

simply amazing, as it gives us extremely easy access to

[[spell:264735]] nearly all the time.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader is our simplest Hero Talent, adding almost nothing in

terms 

of gameplay intrigue. Occasionally, your [[spell:34026]] will trigger a 

Beast via [[spell:471876]]. These Beasts simply do damage, or 

increase your damage done. In addition, your first [[spell:34026]] after 

[[spell:19574]] will summon a [[spell:201430]], a line of pets that do

heavy AoE 

damage to all targets caught within. We detail its usage more on our rotation 

page.

Defensively, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader gives us [[spell:472707]], which buffs 

the effectiveness of our [[spell:264735]]. Not great.

5.

### PvP Talents (War Mode)

**These picks are for open world PvE content with War Mode enabled, not for

actual PvP.**

War Mode offers several benefits for you in the open world.

- PvP talents enabled in the outdoor world.
- At least 10% increase in World Quest rewards at maximum level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is

recommended to enable the feature to maximize your leveling and rewards at

maximum level. However, you will be flagged for open-world PvP, and the

possibility of being "ganked" while leveling or doing World Quests exists.

- [[spell:356976]] makes you and your pet immune to Fear and Horror
  
  effects while [[spell:19574]] is active, and nearby allied pets gain 10%
  
  attack speed.
- [[spell:203235]] is a valuable speed increase for leveling and open
  
  world content.
- [[spell:356707]] swaps in one of your stabled Tenacity or Cunning pets
  
  and sends your current pet away to heal 30% of its maximum health, which saves
  
  it when a pull goes badly.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **30 Aug. 2026:** Mythic+ and Delves Pack Leader builds now take Thrill of the Hunt over Bloody Frenzy. The performance is the same, but Focus regen is higher leading to a smoother rotation.
- **22 Aug. 2026:** Added a Pack Leader Raid AoE/Cleave build, which takes Thrill of the Hunt over Training Expert.
- **21 Aug. 2026:** Updated the Pack Leader Single-Target Build in light of recent hotfixes.
- **18 Aug. 2026:** Updated the Utility Talents for Raid builds.
- **17 Aug. 2026:** The Omnium Folio setup now takes Void-Tainted Shell over Self-Mending.
- **15 Aug. 2026:** The Dark Ranger Mythic+ build now takes Kill Cleave over Razor Sharp.
- **12 Aug. 2026:** Fixed the Dark Ranger Delve build's talent link.
- **12 Aug. 2026:** Delve builds now take Emergency Salve over Wilderness Medicine.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Clarified Hero Talent guidance and Raid AoE build notes.
- **17 Jun. 2026:** Updated recommended week 1 Folio Rune based on real-world data trumping sims.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **27 Apr. 2026:** Updated Dark Ranger single-target build.
- **23 Apr. 2026:** Fixed issue with Pack Leader M+ Build.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **03 Apr. 2026:** Updated Pack Leader Mythic+ Build.
- **23 Mar. 2026:** Update Hero Talent description.
- **22 Mar. 2026:** Updated both single-target builds, and both Mythic+ Builds.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Builds for the upcoming 12.0.1 changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **22 Sep. 2025:** Updated Dark Ranger M+ Build, swapping War Orders to Wild Call to smooth out Frenzy management further, gaining ~2.5% AoE, ~2% Prio, but losing ~1% single-target in the process.
- **17 Sep. 2025:** Updated Mythic+ Hero Talent recommendation.
- **13 Sep. 2025:** Updated BM Dark Ranger Mythic+ Build.
- **10 Sep. 2025:** Updated single-target build and added Raid AoE Build.
- **09 Sep. 2025:** Officially swap over recommended single-target build to Dark Ranger.
- **07 Sep. 2025:** Dark Ranger AoE Rotation and Opener fixes.
- **06 Sep. 2025:** Updated Dark Ranger builds and recommendations for builds and verbiage of Mythic+ build descriptions. This page will shift to recommend Dark Ranger for single-target on September 9th.
- **03 Sep. 2025:** 1-point swap in the NoMulti build, 0.2% loss but I believe it feels a lot nicer to play and leaves less room for error.
- **06 Aug. 2025:** No-Multi Talent update.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **25 Jun. 2025:** Updated instructions for swapping to the 1-minute Bloodshed build, found listed under the baseline single-target build.
- **24 Jun. 2025:** Updated the Single-Target Talent Build. Long story short, the new Static Charge optimal Titan Disc has powerful negative scaling with A Murder of Crows. It is a smaller DPS loss to drop A Murder of Crows for Serpentine Rhythm, than it is to drop Static Charge for another Titan Disc.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **18 Mar. 2025:** Updated note on viability of the Bloodshed/1-minute ST variant build.
- **17 Mar. 2025:** Updated the recommended Talent Build for Mythic+ and Raid AoE.
- **09 Mar. 2025:** Updated Dark Ranger Single-Target Talent Build.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **31 Oct. 2024:** Updated note on what talents you could be flexible with for Beast Mastery Dark Ranger M+.
- **30 Oct. 2024:** Added Dark Ranger Single-Target Build and re-tested all builds for latest hotfixes.
- **26 Oct. 2024:** Updated Hero Talent Order.
- **25 Oct. 2024:** Updated the single-target build slightly for a ~0.5% DPS gain.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Oct. 2024:** Further updated Talent Builds for the October 8th Hotfixes.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **24 Aug. 2024:** Added a recommended Delves build.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated the M+ Talent Build.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Beast Mastery Hunter in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Beast Mastery Hunter Gameplay and Rotation Guide

Welcome to our Rotation page for Beast Mastery Hunter. On this

page, you will find everything you need to know about actually playing the spec

in Raiding and Mythic+ scenarios.

The rotation here, aside from the more concrete openers, is laid out in a

**conditional priority list**. Essentially, for every single spell that you

cast, you should cast the highest-priority spell you can, **for which the

conditions are met.** After the spell is cast, you should start over from the

top of the priority list, and repeat the process.

The buttons below can be used to select between curated **Single-Target**

and **AoE/Mythic+** loadouts. You can also use the switches below to add or

remove individual talents you may also be using.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger

Single Target

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:1264359]]

[[spell:468701]]

[[spell:115939]]

[[spell:424558]]

[[spell:199532]]

[[spell:407412]]

[[spell:468695]]

[[spell:1265044]]

[[spell:1296632]]

### Single-Target Rotation

1.1.

#### Single-Target Opener for Beast Mastery Hunter

Ensure [[spell:257284]] is active on your primary target.

---

**适用条件：Dark Ranger（启用）。**

[[spell:217200]]

[[item:241288]]

[[spell:217200]]

[[spell:19574]]

[[spell:34026]]

[[spell:466930]]

[[spell:34026]]

**适用条件：Pack Leader（启用）。**

[[spell:217200]]

[[item:241288]]

[[spell:217200]]

[[spell:19574]]

[[spell:34026]]

**适用条件：Hunter Beast Mastery 12.1 Class Set 4pc（启用）。**

[[spell:193455]]

[[spell:217200]]

[[spell:34026]]

---

1. **适用条件：Dark Ranger（启用）。** [[spell:217200]]
2. **适用条件：Dark Ranger（启用）。** Use your Potion, on-use Trinket, Racials, etc.
3. **适用条件：Dark Ranger（启用）。** [[spell:217200]]
4. **适用条件：Dark Ranger（启用）。** [[spell:19574]]
5. **适用条件：Dark Ranger（启用）。** [[spell:34026]]
6. **适用条件：Dark Ranger（启用）。** [[spell:466930]]
7. **适用条件：Dark Ranger（启用）。** [[spell:34026]]
8. **适用条件：Dark Ranger（启用）。** Continue with the priority list as described below.
9. **适用条件：Pack Leader（启用）。** [[spell:217200]]
10. **适用条件：Pack Leader（启用）。** Use your Potion, on-use Trinket, Racials, etc.
11. **适用条件：Pack Leader（启用）。** [[spell:217200]]
12. **适用条件：Pack Leader（启用）。** [[spell:19574]]
13. **适用条件：Pack Leader（启用）。** [[spell:34026]]
14. **适用条件：Pack Leader（启用）；Hunter Beast Mastery 12.1 Class Set 4pc（启用）。** [[spell:193455]]
15. **适用条件：Pack Leader（启用）。** [[spell:217200]]
16. **适用条件：Pack Leader（启用）。** [[spell:34026]]
17. **适用条件：Pack Leader（启用）。** Continue with the priority list as described below.

1.2.

#### Single-Target Priority List for Beast Mastery Hunter

Below is the priority system that describes the optimal single-target rotation for Beast Mastery Hunter.

1. **适用条件：Pack Leader（启用）。** Cast [[spell:217200]] if [[spell:19574]] is about to come off cooldown, or if it is about to reach 2 charges.
2. **适用条件：Pack Leader（启用）。** Cast [[spell:19574]] on cooldown.
3. **适用条件：Wild Thrash（启用）；Pack Leader（启用）。** Cast [[spell:1264359]] if there is more than 1 target.
4. **适用条件：Pack Leader（启用）。** Cast [[spell:34026]] if [[spell:471876]] is ready.
5. **适用条件：Pack Leader（启用）。** Cast [[spell:34026]] with the [[spell:1273145]] buff, but bank a charge if [[spell:19574]] is up within 3 seconds, or if [[spell:471876]] is up within 4 seconds and you only have one charge left.
6. **适用条件：Pack Leader（启用）；Hunter Beast Mastery 12.1 Class Set 4pc（启用）。** Cast [[spell:193455]] at 4 stacks of [[spell:1299389]].
7. **适用条件：Pack Leader（启用）；Serpentine Strikes（启用）。** Cast [[spell:217200]] on cooldown.
8. **适用条件：Pack Leader（启用）；Serpentine Strikes（未启用）。** Cast [[spell:217200]] below 75 Focus, or if it is about to reach 2 charges.
9. **适用条件：Pack Leader（启用）。** Cast [[spell:193455]] unless [[spell:19574]] is less than one global cooldown away.
10. **适用条件：Snakeskin Quiver（启用）；Jagged Wounds（启用）；Bloody Frenzy（启用）；Dark Ranger（启用）。** Cast [[spell:217200]] if [[spell:19574]] is about to come off cooldown.
11. **适用条件：Dark Ranger（启用）。** Cast [[spell:19574]] on cooldown.
12. **适用条件：Dark Ranger（启用）。** Cast [[spell:466930]] during [[spell:430715]] (the first 10 seconds of [[spell:19574]]), unless [[spell:34026]] is about to reach 2 charges.
13. **适用条件：Dark Ranger（启用）。** Cast [[spell:34026]] with the [[spell:1273145]] buff, but bank a charge if [[spell:19574]] is up within 4 seconds.
14. **适用条件：Dark Ranger（启用）。** Cast [[spell:392060]] when [[spell:430715]] is within 2 global cooldowns of expiring.
15. **适用条件：Dark Ranger（启用）；Hunter Beast Mastery 12.1 Class Set 4pc（启用）。** Cast [[spell:193455]] at 4 stacks of [[spell:1299389]].
16. **适用条件：Dark Ranger（启用）；Killer Cobra（启用）。** Cast [[spell:193455]] during [[spell:19574]] unless [[spell:217200]] is close to 2 charges.
17. **适用条件：Dark Ranger（启用）。** Cast [[spell:466930]].
18. **适用条件：Dark Ranger（启用）。** Cast [[spell:217200]] on cooldown.
19. **适用条件：Dark Ranger（启用）。** Cast [[spell:193455]] unless [[spell:19574]] is less than one global cooldown away.

### AoE Rotation

**适用条件：Dark Ranger（启用）。** 1.3.

#### **适用条件：Dark Ranger（启用）。** AoE Opener for Beast Mastery Hunter

**适用条件：Dark Ranger（启用）。** Ensure [[spell:257284]] is active on your primary target.

**适用条件：Dark Ranger（启用）。**

---

**适用条件：Dark Ranger（启用）。**

[[spell:466930]]

[[item:241288]]

[[spell:19574]]

**适用条件：Wild Thrash（启用）。**

[[spell:1264359]]

[[spell:34026]]

[[spell:217200]]

[[spell:34026]]

[[spell:466930]]

[[spell:34026]]

**适用条件：Dark Ranger（启用）。**

---

1. **适用条件：Dark Ranger（启用）。** [[spell:466930]]
2. **适用条件：Dark Ranger（启用）。** Use your Potion, on-use Trinket, Racials, etc.
3. **适用条件：Dark Ranger（启用）。** [[spell:19574]], if the previous [[spell:466930]] activated [[spell:115939]]. If it did not, [[spell:1264359]] first.
4. **适用条件：Dark Ranger（启用）；Wild Thrash（启用）。** [[spell:1264359]]
5. **适用条件：Dark Ranger（启用）。** [[spell:34026]]
6. **适用条件：Dark Ranger（启用）。** [[spell:217200]]
7. **适用条件：Dark Ranger（启用）。** [[spell:34026]]
8. **适用条件：Dark Ranger（启用）。** [[spell:466930]]
9. **适用条件：Dark Ranger（启用）。** [[spell:34026]]
10. **适用条件：Dark Ranger（启用）。** Continue with the priority list as described below.

**适用条件：Pack Leader（启用）。** 1.4.

#### **适用条件：Pack Leader（启用）。** Mythic+ AoE Opener for Beast Mastery Hunter

**适用条件：Pack Leader（启用）。** Ensure [[spell:257284]] is active on your primary target.

**适用条件：Pack Leader（启用）。** For our Mythic+ AoE opener, we want to press [[spell:1264359]] almost immediately as the pull begins, while ensuring our pets do not get too much aggro. Then, we kick into our normal baseline rotation until [[spell:1264359]] is around 1.5 seconds (1 global cooldown) from coming off cooldown. At that point, we [[spell:19574]] into [[spell:1264359]] for a massive 2-second burst of AoE damage. We want this to happen around halfway through the [[item:271886]] Potion that we popped a few seconds before the pull. When exactly you pre-pot depends on the length of the pull gather, but in practice, just potting as you are running up to the pull works fine.

**适用条件：Pack Leader（启用）。**

---

**适用条件：Pack Leader（启用）。**

[[item:271886]]

6s

Pull

**适用条件：Wild Thrash（启用）。**

[[spell:1264359]]

[[spell:217200]]

[[spell:34026]]

[[spell:193455]]

[[spell:34026]]

[[spell:19574]]

**适用条件：Wild Thrash（启用）。**

[[spell:1264359]]

**适用条件：Pack Leader（启用）。**

---

1. **适用条件：Pack Leader（启用）；Wild Thrash（启用）。** [[spell:1264359]]
2. **适用条件：Pack Leader（启用）。** [[spell:217200]]
3. **适用条件：Pack Leader（启用）。** [[spell:34026]]
4. **适用条件：Pack Leader（启用）。** [[spell:193455]]
5. **适用条件：Pack Leader（启用）。** [[spell:34026]]
6. **适用条件：Pack Leader（启用）。** [[spell:19574]]
7. **适用条件：Pack Leader（启用）；Wild Thrash（启用）。** [[spell:1264359]]
8. **适用条件：Pack Leader（启用）。** Continue with the priority list as described below.

**适用条件：Pack Leader（启用）。** 1.5.

#### **适用条件：Pack Leader（启用）。** Raid AoE Opener for Beast Mastery Hunter

**适用条件：Pack Leader（启用）。** On a raid fight, there is a pull timer and there is no pack that needs to be gathered before we can burst properly, so we open normally and send our potion right before our [[spell:1264359]].

**适用条件：Pack Leader（启用）。**

---

**适用条件：Pack Leader（启用）。**

[[spell:217200]]

[[spell:217200]]

[[item:241288]]

**适用条件：Wild Thrash（启用）。**

[[spell:1264359]]

[[spell:19574]]

[[spell:34026]]

[[spell:193455]]

[[spell:34026]]

**适用条件：Pack Leader（启用）。**

---

1. **适用条件：Pack Leader（启用）。** [[spell:217200]]
2. **适用条件：Pack Leader（启用）。** [[spell:217200]]
3. **适用条件：Pack Leader（启用）。** Use your Potion, on-use Trinket, Racials, etc.
4. **适用条件：Pack Leader（启用）；Wild Thrash（启用）。** [[spell:1264359]]
5. **适用条件：Pack Leader（启用）。** [[spell:19574]]
6. **适用条件：Pack Leader（启用）。** [[spell:34026]]
7. **适用条件：Pack Leader（启用）。** [[spell:193455]]
8. **适用条件：Pack Leader（启用）。** [[spell:34026]]
9. **适用条件：Pack Leader（启用）。** Continue with the priority list as described below.

1.6.

#### AoE Priority List for Beast Mastery Hunter

Below is the priority system that describes the optimal AoE rotation for Beast Mastery Hunter.

1. **适用条件：Pack Leader（启用）；Wild Thrash（启用）；Beast Cleave（启用）。** Cast [[spell:1264359]] immediately after [[spell:19574]], or any time [[spell:115939]] is down.
2. **适用条件：Pack Leader（启用）。** Cast [[spell:217200]] if it is about to reach 2 charges.
3. **适用条件：Pack Leader（启用）；Wild Thrash（启用）。** Cast [[spell:19574]] on cooldown, with [[spell:115939]] active.
4. **适用条件：Pack Leader（启用）；Wild Thrash（未启用）。** Cast [[spell:19574]] on cooldown.
5. **适用条件：Pack Leader（启用）；Wild Thrash（启用）。** Cast [[spell:1264359]] on cooldown, but hold it if [[spell:19574]] becomes ready before [[spell:115939]] expires.
6. **适用条件：Pack Leader（启用）；Master Handler（启用）。** Cast [[spell:34026]] on cooldown, ignoring [[spell:1273145]] on 4 or more targets or when [[spell:471876]] is ready.
7. **适用条件：Pack Leader（启用）；Master Handler（未启用）。** Cast [[spell:34026]] with the [[spell:1273145]] buff.
8. **适用条件：Pack Leader（启用）；Hunter Beast Mastery 12.1 Class Set 4pc（启用）；Beast Cleave（启用）。** Cast [[spell:193455]] with [[spell:1299389]] and [[spell:115939]] both active.
9. **适用条件：Pack Leader（启用）。** Cast [[spell:217200]] on cooldown.
10. **适用条件：Pack Leader（启用）；Wild Thrash（启用）。** Cast [[spell:193455]] unless [[spell:1264359]] is less than one global cooldown away.
11. **适用条件：Pack Leader（启用）；Wild Thrash（未启用）。** Cast [[spell:193455]].
12. **适用条件：Dark Ranger（启用）；Beast Cleave（启用）。** Cast [[spell:466930]] when [[spell:115939]] is about to expire and [[spell:19574]] is about to come off cooldown. If it hits 3 or more targets, it will grant [[spell:115939]].
13. **适用条件：Dark Ranger（启用）；Beast Cleave（未启用）。** Cast [[spell:466930]] on 3 or more targets when [[spell:19574]] is about to come off cooldown.
14. **适用条件：Dark Ranger（启用）；Beast Cleave（启用）。** Cast [[spell:19574]] with [[spell:115939]] active.
15. **适用条件：Dark Ranger（启用）；Beast Cleave（未启用）。** Cast [[spell:19574]] on cooldown.
16. **适用条件：Dark Ranger（启用）；Wild Thrash（启用）；Beast Cleave（启用）。** Cast [[spell:1264359]] right after [[spell:19574]], or any time [[spell:115939]] is not active. Otherwise hold it if [[spell:19574]] becomes ready before [[spell:115939]] expires.
17. **适用条件：Dark Ranger（启用）；Wild Thrash（启用）；Beast Cleave（未启用）。** Cast [[spell:1264359]] on cooldown.
18. **适用条件：Dark Ranger（启用）。** Cast [[spell:34026]] with the [[spell:1273145]] buff, but bank a charge if [[spell:19574]] is up within 5 seconds.
19. **适用条件：Dark Ranger（启用）。** Cast [[spell:217200]] if it is about to reach 2 charges.
20. **适用条件：Dark Ranger（启用）。** Cast [[spell:466930]] during [[spell:430715]].
21. **适用条件：Dark Ranger（启用）。** Cast [[spell:392060]] when [[spell:430715]] is within one global cooldown of expiring.
22. **适用条件：Dark Ranger（启用）。** Cast [[spell:217200]].
23. **适用条件：Dark Ranger（启用）。** Cast [[spell:466930]].
24. **适用条件：Dark Ranger（启用）。** Cast [[spell:392060]].
25. **适用条件：Dark Ranger（启用）。** Cast [[spell:193455]].

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier Set does affect our rotation. The 2-set makes

[[spell:217200]] cause one extra [[spell:199530]] at 50% effectiveness. The

4-set makes each [[spell:199530]] add a stack of [[spell:1299389]], up to 4

stacks.

On single-target every stack gives 20% extra Cobra Shot damage, and with

[[spell:115939]] active, that Cobra Shot instead benefits from Beast Cleave

at 30% effectiveness.

Cast [[spell:193455]] ahead of [[spell:217200]] once you are at 3 stacks

with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader, or at 4 stacks with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Beast

Mastery Hunter kit, we have compiled a more detailed explanation on individual

parts of our rotation, from important rotational mechanics that you need to pay

attention to, to cooldowns and how to use them, so you can reach your full

potential when playing Beast Mastery Hunter.

### [[spell:201430]]

3.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Stampede

When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Beast Mastery Hunter, your first

[[spell:34026]] cast after every [[spell:19574]] will spawn a

Stampede, a 30-ish-yard long "line" of beasts that charge at your target. It

deals heavy damage to all enemies inside it over 7 sec. Aiming and positioning

this is key in many situations. Firstly, you should position your character so

that the line extends through not just where the mobs currently are, but if they

are moving, **where you think they might be going**. This is essential to

making

optimal use of Stampede. Think of it as you getting a single stroke with a paint

brush, and you need this single brush to cover as many of the mobs as

possible.

### Apex Talents

3.2.

#### Nature's Ally Apex Talents

The final node of our Apex Talents does have some rotational aspects you

should know. It incentivizes you to never cast two [[spell:34026]]s

back-to-back. Instead, you should always try to weave another ability in between

them to maximize coverage of that 30% buff.

In addition to this, the initial tiers of [[spell:1273145]] cause

[[spell:19574]] to do a significant amount of damage. This does not change

our rotational priorities, but is worth knowing.

4.

### Important Cooldowns for Beast Mastery Hunter

### [[spell:19574]]

4.1.

#### Bestial Wrath

[[spell:19574]] is our only cooldown. It has a 30-second cooldown and

15-second duration, and it is the vehicle of many of our Hero Talent

mechanics.

It does heavy damage on its own, and buffs all of your damage by 20% for its

duration. In addition to this, several talents like [[spell:199532]],

[[spell:1232739]], [[spell:321530]], [[spell:459693]] and

[[spell:193532]] amplify it further. The

vast majority of your damage is done in these [[spell:19574]] windows.

4.2.

#### Hero Talent Impacts of Bestial Wrath

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader, [[spell:19574]] activates your

[[spell:471876]], causing your next [[spell:34026]] to summon

a Beast. In addition, your first Kill Command inside [[spell:19574]] will

also launch a [[spell:201430]]. This is a roughly 30 yards long "line" of

beasts that charge at your target, and it gets placed when you press the Kill

Command.

Because this effect is placed the moment you cast your first

[[spell:34026]] in [[spell:19574]] and does not move, and because

it is a long line that originates from your character position, aiming and

positioning this line is essential, particularly in AoE situations.

You want to place Stampede in such a way that it will cover as many

targets as possible, for as long as possible.

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger, the [[spell:19574]] button gives you a

[[spell:466930]] proc, and turns into [[spell:392060]] once activated.

You get one use of Wailing Arrow, which deals heavy damage and gives you a

[[spell:466930]] proc. We want to use this when the [[spell:430715]]

buff (the

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger capstone talent) is about to end, to sneak another

[[spell:466930]] into that window.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **07 Sep. 2026:** Split the Pack Leader AoE opener into Mythic+ and Raid versions.
- **24 Aug. 2026:** Wild Thrash is now the first cast of the Pack Leader AoE opener and the top entry of its priority list, ahead of Barbed Shot. The Apex pet that Bestial Wrath spawns casts its own Bestial Wrath 1.5 seconds later and does not inherit the Beast Cleave that was up before it, so Wild Thrash has to follow Bestial Wrath for that hit to cleave.
- **24 Aug. 2026:** Added holding Wild Thrash when Bestial Wrath will be ready before Beast Cleave expires.
- **15 Aug. 2026:** Updated the Tier Set section for the 4-set buff.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Corrected Stampede's length to 30 yards.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **21 May 2026:** Simplified Barbed Shot priority nuances for Pack Leader single-target, as playing around Focus levels was found to not be a consistent DPS increase to be worth the hassle of keeping track of it.
- **29 Apr. 2026:** In Dark Ranger AoE, added note of Black Arrow being a top prio to activate Beast Cleave if it is down prior to a Bestial Wrath.
- **28 Apr. 2026:** Updated wording around Wailing Arrow usage, clarifying that it is worth using in every Bestial Wrath, even if you miss the optimal window by mistake.
- **27 Apr. 2026:** Rotation updates.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **10 Apr. 2026:** Updated Pack Leader Rotations.
- **05 Apr. 2026:** Updated Beast Mastery Dark Ranger rotation and opener slightly.
- **04 Apr. 2026:** Added Puzzle Box to opener.
- **02 Apr. 2026:** Small Dark Ranger AoE Rotation Update.
- **31 Mar. 2026:** Minor update to the BM Dark Ranger AoE Opener.
- **24 Mar. 2026:** Updated the Dark Ranger Rotation.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **11 Feb. 2026:** Dark Ranger opener update.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Clarified optimal Potion and Prism usage for Dark Ranger.
- **22 Sep. 2025:** Expanded on the value of Multidotting as BM Dark Ranger and clarified that it is actually not that hard to do you guys.
- **21 Sep. 2025:** Dark Ranger AoE Rotation updates concerning Barbed Shot and Kill Command priorities.
- **17 Sep. 2025:** Small Dark Ranger rotation updates.
- **12 Sep. 2025:** Updated/Simplified Barbed Shot usage on single-target significantly.
- **10 Sep. 2025:** Rotational updates with small gains found in being less aggressive with Bestial Wrath usage. Single-target talent build is also updated with this playstyle.
- **09 Sep. 2025:** Further rotational updates for Dark Ranger.
- **08 Sep. 2025:** Added a small minmax around Barbed Shot, Call of the Wild, and trinket usage for Dark Ranger.
- **06 Sep. 2025:** Updated Dark Ranger opener and made Dark Ranger single-target show as the default, though it should not be played until September 9th.
- **31 Aug. 2025:** Opener updates and clarifications around Double Stampede/Bestial Wrath holding.
- **17 Aug. 2025:** Rotational updates and clarifications.
- **16 Aug. 2025:** Added info on DPS gain from holding Bestial Wrath.
- **08 Aug. 2025:** Added a note on Kill Command-holding for Howl during Lead from the Front with 4PC.
- **05 Aug. 2025:** AoE Rotation and opener changes.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **20 May 2025:** Added a small rotational minmax to the single-target rotation worth ~+0.3% DPS.
- **29 Apr. 2025:** Put the Barbed Shot Helper in a more obvious place.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **18 Mar. 2025:** Updated the rotation defaults for new Talents.
- **14 Mar. 2025:** Single-Target opener change.
- **09 Mar. 2025:** Rewrote and simplified the Rotation significantly.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **04 Nov. 2024:** Removed Withering Fire holding for Bestial Wrath.
- **30 Oct. 2024:** Small Barbed Shot AoE Priority change.
- **25 Oct. 2024:** Updated both rotations slightly.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **08 Oct. 2024:** Updated default talent selections.
- **02 Oct. 2024:** Added more specific Trinket usage information.
- **10 Sep. 2024:** Updated the Dark Ranger Single-Target Opener slightly.
- **09 Sep. 2024:** Single-Target Opener update.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **26 Aug. 2024:** Updated the Kill Shot priorities in the Single-Target Rotation based on APL updates by Yanix, +0.5% DPS.
- **22 Aug. 2024:** Updated for The War Within.
- **01 Aug. 2024:** Simplified Dire Beast rotation use. Small opener changes.
- **24 Jul. 2024:** Updated the rotation and openers based on the latest APL updates.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Beast Mastery Hunter in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Beast Mastery Hunter

Welcome to our Gear and BiS Page for Beast Mastery Hunter for

Midnight Season 2. Check this page to learn everything you need

to know about gearing a Beast Mastery Hunter, including the BiS Gear

from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier

Sets, and much more.

The Midnight Expansion brought a major stat squish, reducing the stats and

numbers of virtually everything in the game, including Item Levels and the stats

on gear.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which

lets you

increase the item level of gear along tracks that relate to where you obtained the

item, with harder content dropping gear that can be upgraded to higher Item

Levels.

For more information, read up on our dedicated page on how the 

[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 

changed in the Midnight expansion.

### Overall

This list contains the best gear in every slot for Season 2 of Midnight, from all sources.

There are many different setups that perform within the margin of error. This one chooses as many Raid items as possible, since they are easier to obtain than hoping for the right Mythic+ item from your [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). Mythic+ items are chosen when there is no equally strong Raid alternative. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Mastery is what you want most, then Haste for single target or Critical Strike for Mythic+.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best items to Catalyze:

- Helmet: [[item:268230@JAACAAgNyA]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details FAQWhat to Get From The Great Vault?
Take the [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) almost every week. The exception is when the Vault offers the last thing you wanted from a boss or dungeon, because taking it there means you never have to bonus roll that source again.

A Voidcore bonus rolls one raid boss or one Mythic+ dungeon and gives you something you have not rolled from it before. Heroic raid bosses and Mythic+ give 1/6 Myth, Mythic raid bosses give 6/6 Myth, and late-raid bosses give 9/6.

Two things make this stronger than it looks. The item level is decided when you spend the Voidcore rather than when you take it, so you can sit on one until you have a Mythic boss worth rolling on. And gear you take out of the Vault stays in the bonus roll pool, so a piece you were going to replace anyway can cost you a roll later.

The bosses worth rolling on are listed under Nebulous Voidcores further down this page.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Mythic+

This list contains the best gear in every slot for Season 2 of Midnight, from Midnight Season 2 Mythic+. This is aimed at people who do not intend to engage much with Raid content.

There are many different setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Mastery is what you want most, then Haste for single target or Critical Strike for Mythic+.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best dungeon drops to Catalyze:

- Helmet: [[item:159374@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- Shoulders: [[item:251131@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Chest: [[item:158355@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Gloves: [[item:193752@JAAKAAQkCYHKvbRLfYjM]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- Legs: [[item:159375@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend farming the following dungeons:

- [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): BiS Trinket
- [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>): BiS Boots and Ring
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): BiS Weapon, Cloak and Ring
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): BiS Trinket
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): BiS Neck

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">The Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271680@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the best gear in every slot for Season 2 of Midnight, from the Midnight Season 2 Raids. It is very similar to our Overall BiS List, since that is biased towards Raid Gear as well, but in this case, absolutely no Mythic+ items are included.

There are many different setups that perform within the margin of error. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Items Do I Use in the Catalyst?
The Catalyst now keeps the secondary stats and any passive effects of the item you Catalyze, so what you put in matters more than which slot you use to complete the set. Mastery is what you want most, then Haste for single target or Critical Strike for Mythic+.

Do not hold the set bonus back over this. Two weeks without your 4-piece costs far more than slightly wrong secondaries, and you can Catalyze a better item later in the season.

These are the best raid drops to Catalyze. A Mythic+ item can beat any of them if you run keys as well:

- Helmet: [[item:268230@JAACAAgNyA]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)
- Shoulders: [[item:268231@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Chest: [[item:271876@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Gloves: [[item:281238@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Legs: [[item:268237@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raid leader, or simply want to focus on the most important bosses and items, we have you covered!

- [[item:268207]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Weapon, and Venomcursed.
- [[item:268265]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Neck, and Venomcursed. Most specs want it, so expect competition.
- [[item:281215]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Trinket.
- [[item:270175]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>): BiS Trinket.
- [[item:281238]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Gloves.
- [[item:281029]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>): BiS Ring.
- [[item:268252]] from [Sszorak](<https://www.icy-veins.com/wow/sszorak-raid-guide>): BiS Ring.
- [[item:268249]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>): BiS Ring on the Overall list.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271492@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271493@JAAEAAgNyEuN]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240898]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:244581@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271490@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271491@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268258@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271495@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>Bracers</th><td>[[item:244584@JAAOAAwt1ENMMYDYwclIAMCEHA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268207@JAAEAAAG2wYN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Beast Mastery Hunter

We are fairly flexible in the trinkets we like.

[[item:281215]] paired with [[item:270175]] is

our optimal setup, however.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Beast Mastery Hunter Trinkets**
**Optimal -**

[[item:281215]]

+

[[item:270175]]

:::

There are quite a few other valuable trinkets out there, so make sure to

click on our ranking chart to see if they are worth equipping. Note that you do

not want to have more than 1 on-use Trinket. You can almost think of the

"On-Use" Trinkets ranked as being separate from the others.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Beast Mastery Hunter Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]]: On-Use</li>&#10;<li>[[item:281215]]</li>&#10;<li>[[item:159617]]: On-Use</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:250215]]: On-Use</li>&#10;<li>[[item:273796]]: On-Use</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:250225]]: On-Use</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]: On-Use</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:246304]]</li>&#10;<li>[[item:241340]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:158374]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]: On-Use. Regularly outperforms its raw sim due to its immense burst which, placed properly, can beat other Trinkets. Think of damage amps, priority targets, and so on.</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

- [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is a new currency that can be used to "Bonus 
  
    Roll" on certain dungeons and items. Using it will **guarantee** a drop 
  
    from that source, but the item you get is random. However, you are protected 
  
    from repeats. Use this enough times on a boss or dungeon, and you are
  
    **guaranteed** your desired item.

You get them from [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) by rejecting the item rewards, which

needs three reward slots unlocked from any source (even Tier 1 Delves!). With

the launch of Patch 12.1.5, you also get one extra Voidcore for free from Orin

Straylight, who can be found next to the Catalyst in Silvermoon.

3.1.

#### Recommended Nebulous Voidcore Usage for Beast Mastery Hunter

Obviously, the straightforward answer to this question is to use the 

Voidcores on the best upgrade that you have not yet gotten. This is unique to 

your character, but we will offer a list of some of the most important items for 

Beast Mastery Hunter, with the goal being that you can just go down 

the list and chase the #1 thing you see that you do not already have.

Bonus Rolling for an item you may get from an upcoming raid boss can be a bad

idea, depending on how you value "power now" versus "power later".

Generally speaking, your best bet is to roll [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on **Heroic**. It has several high-impact BiS items and so even if you do not 

roll your BiS weapon right away, you will still extract good value.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:268207]],
   
   [[item:271876]], [[item:268265]], and
   
   [[item:270175]]
2. [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) for [[item:281238]],
   
   [[item:281215]], and [[item:281029]]
3. At this point, it has been many weeks of the Season and your gear will 
   
   be all over the place. We recommend using 
   
   [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>) 
   
   to sim your optimal bonus rolls.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] are a new upgrade currency that arrives with

Patch 12.1.5. Each upgrade costs 10, and they only work on your Weapon, your

Trinkets and your Neck, letting you upgrade those items up to 340 iLvl. Only

fully upgraded Hero Track or Myth Track items, or crafted items at maximum

quality, can be upgraded with them. Spending them follows a similar priority to

your Crests:

1. Your Weapon is the highest priority.
2. Your Trinkets.
3. Your Neck.

Fill in with other Myth Track items that you do not use as often. The

exception is an item you do not expect to get at Myth Track any time soon. If

you are not killing Mythic [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>), it is fine to upgrade a Hero Track

[[item:281215]], for example.

4.

### Best Crafted Items for Beast Mastery Hunter

You can have two Embellishments, which are special effects that come from

crafted gear. Which to craft first depends on how much you value power in the

opening weeks of the season.

Crafting a Weapon such as [[item:265337]] with 

[[item:273060]] and Crit/Mastery is an excellent boost of 

short-term power. The downside is that even if you do craft it, your best bonus 

roll target is still likely to be Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), which has a decent 

chance of giving you a Mythic Track [[item:268207]] which would 

invalidate your Crafted weapon eventually.

The alternative is to craft your actual BiS, the 

[[item:244581]] and [[item:244584]] with 

[[item:240167]] and Crit/Mastery. If you get very unlucky and do not 

Bonus Roll a Mythic Weapon in a reasonable time, you may regret this choice as you will

be stuck with a 321 iLvl Weapon for weeks.

The armor pair is the better longer-term play, since it is your actual BiS

and a crafted Weapon gets replaced by a Mythic Track drop sooner or later.

Crafting the Weapon first is still a real option if you want the power in

week 1.

Crafting [[item:244582]] is a good short-term armor

craft, and a permanent one if you are never going to kill [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

on Mythic for the 344 Legs.

:::details **Beast Mastery Hunter Crafting Slot Priority**
**Weapon → Neck/Rings → Everything Else → Cloak/Wrist**

:::

You should ideally sim the optimal stats to craft for your particular

character, but Crit/Mastery is most likely your best option with a

[[item:245789]].

For more information about crafting gear you can visit our

[Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

Helmets, Belts and Bracers can drop with a socket, and you can also add one

yourself with [[item:275707]]. It costs six

[[item:258556]], the currency [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) gives you for

passing on its rewards. You get six of them directly as long as you have three

reward slots unlocked.

Save them for pieces you do not expect to replace, so Mythic items or your

two crafted slots, since a crafted Belt or Bracer cannot get a socket any other

way.

5.

### Crest Usage

You will be able to upgrade your items via Crests such as

[Myth Mistcrest](<https://www.wowhead.com/currency=3446>). Once you have upgraded a slot to a certain item level,

**upgrading other items of that slot to that item level is free**.

When you upgrade with Crests, you should think of it as upgrading

**slots** and not items.

Since Crests are a limited resource, you will want to obtain

the highest item-level possible **before** upgrading a given slot, as this

means you will spend fewer Crests on that slot in total. If you are at all

capable of doing a +10 Dungeon, for example, it would be a very bad idea to

upgrade an item from a +9 Dungeon, because you just wasted 20 Crests that could

have been saved by just farming the slot on a +10.

We see a ton of players, even at a high level, mess up their upgrade

priorities and upgrade prematurely. Getting this right will put you far ahead

of most players.

Below is the slot priority you should upgrade your items in. If you ever want

to deviate from this, you should have a very good reason.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Beast Mastery Hunter Crest Upgrade Priority**
**Weapon**

→

**Trinkets**

→

**Helmet/Chest/Legs**

→

**Shoulder/Gloves/Belt/Boots**

→

**Rings/Neck**

→

**Cloak/Bracer**

:::

Note that exceptions are possible, such as special items that have more Item

Level scaling than their slot would imply.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the

importance of simming yourself on Raidbots. This is because every character is

unique, and each gear piece you have access to can change what is best

right now for you.

While we do offer recommendations for gear and trinkets, these are not complete

replacements for simming yourself. The only way to truly optimize your character

to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **30 Sep. 2026:** Fixed the Chest tooltips showing two Venomcursed effects.
- **30 Sep. 2026:** Moved the Resonant Bellowstone up to B Tier, the Vashnik's Sanguine Rancor and Void Execution Mandate down to C Tier, and the Sapling of the Dawnroot down to D Tier in the Trinket Rankings.
- **04 Sep. 2026:** Updated the Overall BiS List Trinket to the Keeper's Seething Core.
- **04 Sep. 2026:** Moved the Font of Venomous Rage to S Tier in the Trinket Rankings.
- **31 Aug. 2026:** Updated the Overall BiS List to Catalyze the Crown of the Eternal Fang and the Galerattle Gauntlets.
- **31 Aug. 2026:** Updated the Mythic+ BiS List Weapon to the Sinseared Repeater and the Ring to the Charged Sandstone Band.
- **31 Aug. 2026:** Updated the Raid BiS List Boots to the Boots of the Reckless Wayfarer and the Ring to the Apex Brute's Claw Ring.
- **24 Aug. 2026:** Updated the Weapon enchant to Rite of the Hash'ey.
- **22 Aug. 2026:** Added a note on crafting Legs.
- **18 Aug. 2026:** Updated the Overall BiS List Ring and Boots to match the Mythic+ setup, since the raid has enough cleave that gearing for single target does not make sense.
- **18 Aug. 2026:** Updated the Nebulous Voidcore bonus roll priorities following the Gebbo's Bottomless Bag nerf.
- **17 Aug. 2026:** Updated the Trinket tier list.
- **16 Aug. 2026:** Reworked the crafting advice, corrected the Voracious Heart of Ula'tek and Gebbo's Bottomless Bag entries in the raid-items list, and added start of season Voidcore and Crest advice.
- **15 Aug. 2026:** Updated the Trinket tier list and the Raid BiS Trinkets following the latest tuning.
- **14 Aug. 2026:** Updated the Raid BiS Gloves to the Catalyzed Grips of Swirling Fury from Nymrissa Wavecaller.
- **14 Aug. 2026:** Updated the Nebulous Voidcore bonus roll priorities.
- **12 Aug. 2026:** Added Catalyst and Great Vault FAQs and a socket section, fixed Catalyst drop locations, and updated sources of the Raid BiS Helm and Gloves.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Added a trinket quick-reference and clarified crafting guidance.
- **16 Jun. 2026:** Fixed boots in M+ BiS List.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **08 Apr. 2026:** BiS List and Trinket Tier List update.
- **25 Mar. 2026:** Updated Mythic+ Gear BiS List.
- **17 Mar. 2026:** Updated for Midnight Season 1.
- **04 Mar. 2026:** Updated Crafting recommendation for endgame.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **12 Sep. 2025:** Updated Trinket Tier List and BiS List.
- **07 Sep. 2025:** Updated BiS Ring.
- **06 Sep. 2025:** Updated BiS Lists and Trinket Tier Lists to include Dark Ranger-specifics.
- **02 Sep. 2025:** Trinket Tier List and BiS updates.
- **16 Aug. 2025:** Update Trinket Tier list for tuning,
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated the Titan Disc recommendation again based on further analysis into Static Charge oversimulating its actual performance.
- **23 Jun. 2025:** Updated the Titan Disc recommendation based on the latest hotfixes.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **13 May 2025:** Updated the ordering of Dinar recommendations.
- **10 May 2025:** Updated the wording/Dinar recommendation status for House of Cards and Signet slightly.
- **09 May 2025:** Updated Corruption Enchants & Puzzling Cartel Chip Dinar section.
- **21 Apr. 2025:** Add list of Dinar-purchasable items.
- **29 Mar. 2025:** Updated the position of Eye of Kezan in the Mythic+ Trinket Tier List.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **17 Mar. 2025:** Updated wording on Improvised Seaforium Pacemaker.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated for the Cyrce's Circlet now going to Item Level 658.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **24 Sep. 2024:** Updated a BiS Ring.
- **13 Sep. 2024:** Added note about double-Dawnthread Lining not working and how to fix it.
- **10 Sep. 2024:** Streamlined Crafting recommendations, split them by Raiding and Mythic+, and reformatted. Removed Disclaimer. Fixed some BiS List discrepancies.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **27 Aug. 2024:** Added a note about Crafted gear to the Pre-Season BiS List.
- **22 Aug. 2024:** Updated for The War Within.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Beast Mastery Hunter. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Beast Mastery Hunter Stat Priority

The stat priority for Beast Mastery Hunter splits between pure

single-target and Mythic+, as follows:

1.1.

#### Single-Target Stat Priority

Mastery

Haste

Critical Strike

Versatility

On pure single-target, Haste is better than Crit by a small margin. However, for

all-around purposes, Crit is stronger than Haste by a significant amount.

1.2.

#### Mythic+ Stat Priority

Mastery

Critical Strike

Versatility

Haste

Remember that the less you have of a stat relative to others, the stronger it

tends to become. Stat priorities are based on equalizing all stats and looking

at how powerfully stats scale from a set point, as well as looking at the

highest-simming gear setups for the spec and looking at what stat priority got

it there.

2.

### In-Depth Stat Breakdown

**Agility** is your primary stat. It provides you with Attack Power, which

determines the damage your abilities do across the board.

**Mastery**, through [[spell:76657]], increases the damage

done by yourself and, to a greater extent, all the pets and creatures that you

summon. This includes your main pet, Dire Beasts and more.

**Haste** increases your attack speed and Focus regeneration, reduces your

Global Cooldown from 1.5 seconds to a minimum of 0.75 seconds, and reduces the

cooldown on your [[spell:34026]] and [[spell:217200]] abilities.

:::details FAQIs There a Haste Cap for Beast Mastery Hunter?
There are no Haste breakpoints for Beast Mastery. Haste is absolutely worthless
on AoE, and while it is a little better than Crit on pure single-target, we recommend
Crit → Haste as a rule of thumb for general, all-content play.

:::

**Critical Strike** increases your chance to critically hit with all

spells and abilities, causing them to deal double damage. Lots of Beast Mastery

Talents work off of critical strike, including but not limited to

[[spell:459552]] and [[spell:392053]].

**Versatility** increases all your damage and healing done, and decreases

all damage taken.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit past which it will begin to offer less increase per

point gained; these are known as the points of diminishing returns. Once you

have reached

these amounts, stats will become progressively less valuable and may fall behind

other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Clarified the Crit vs Haste rule of thumb.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Stat Diminishing Returns values for Level 80.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Sep. 2025:** Updated stat priority for Dark Ranger.
- **07 Sep. 2025:** Stat Priority wording update.
- **06 Sep. 2025:** Small stat priority updates and rearranged the page.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Added separate Stat Priorities for Pack Leader on AoE and Single-Target.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Beast Mastery Hunter, based on your [stat priority](<https://www.icy-veins.com/wow/beast-mastery-hunter-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You should use a [[item:240983]] in one socket, and 

[[item:240898]] in every other socket. While there are other

options for

both your Thalassian gem as well as rare gems, these two will provide you with

the highest

DPS gains in all content types.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchant</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

You can consume a number of temporary items to increase your power in dungeons

and raids.

3.1.

#### Flask

The best flask is generally going to be

[[item:241322]]. That said, it is best to think of Flasks as just

another piece of gear that is easily swappable, and depending on your exact gear

situation, any of the 4 secondary stat flasks can be optimal. To really minmax

on this point, you would need to simulate it.

3.2.

#### Potions

Which DPS Potion you want depends on the content you are doing.

- [[item:241288]] is the default option, offering a huge amount
  
  of your highest secondary stat for 30 sec, to be synced with your cooldowns.
  
  Note that this Potion is sensitive to your best stat (Mastery) actually being
  
  your highest when you pop the Potion. If that is not the case at this point in
  
  your gearing process, use [[item:241308]] instead. It also benefits
  
  greatly from your lowest stat (usually Versatility) being very near-0, since
  
  that means you suffer none of the reduction.
- [[item:271886]] is the pick for Mythic+, where you pre-pot before the
  
  pull. Its Versatility ramps over the duration, so it is at its strongest when
  
  your opening burst begins after the pack is gathered. See the Mythic+ page for
  
  the exact timing.

Make sure to carry [[item:271883]] as well.

It has a 5-minute cooldown and heals most of your health; use it as a last

resort, preferring your personal defensives wherever possible.

3.3.

#### Food Buff

The best Food you can eat is from a

[[item:255846]] or [[item:255845]] feast. The best

non-feast food is [[item:242747]]. The "Hearty" part is important, as

this food persists through death, and we highly recommend grabbing

[Cooking](<https://www.icy-veins.com/wow/professions-cooking>) to easily make your own Hearty Food, as it cannot be

straightforwardly purchased on the Auction House.

3.4.

#### Augment Rune

The best Augment Rune in Midnight is

[[item:259085]], but it might be very expensive to use on every

pull or

every dungeon, so use it sparingly unless your wallet is deep.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **15 Sep. 2026:** Clarified that Liquid Luster is the Mythic+ Potion, while Potion of Recklessness remains the pick everywhere else.
- **24 Aug. 2026:** Updated the Weapon enchant to Rite of the Hash'ey.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated Weapon and Boots enchant recommendations, and fixed enchant tooltip links.
- **16 Jun. 2026:** Clarified Weapon Enchant choice.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **23 Apr. 2026:** Updated Ring Enchant.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **09 May 2025:** Updated Corruption Enchants section.
- **21 Apr. 2025:** Added Corruption Enchants information.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **22 May 2023:** Updated the recommended Leg Enchant, as it was found that the Lambent Armor Kit does not provide Stamina as it was assumed.
- **13 May 2023:** Updated the recommended food and Leg enchant.
- **01 May 2023:** Reviewed for Patch 10.1.
- **23 Mar. 2023:** Yet another update to the recommended Gemstones based on a slew of hotfixes.
- **23 Mar. 2023:** Updated the recommended Gemstones after sim updates, and the discovery of a new, powerful combination.
- **21 Mar. 2023:** Updated the Onyx Annulet Information in light of the March 21st buff.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **22 Feb. 2023:** Updated and clarified optimal Gems and Enchants.
- **20 Feb. 2023:** Added information about a DPS-increasing Glyph for Beast Mastery Hunters.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **04 Jan. 2023:** Updated the recommended Phial.
- **11 Dec. 2022:** Updated the recommendation and description of the optimal Flasks/Phials.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Beast Mastery Hunter in World of Warcraft Patch 12.1.5.

1.

### Beast Mastery Hunter in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Hunter in

Mythic+ dungeons, including the best way to set up your character, how your

rotation may change, and tips and tricks for using your abilities in the most

optimal way.

Beast Mastery Hunter has a very "flat" damage profile, doing

roughly the same sort of DPS from pull to pull and from boss to boss. This makes

it reliable, but denies it the high peak burst moments that some other specs can

get. It is very easy to play, and is fully mobile, making it perhaps the best

"pick up and play" spec in the entire game.

If you are unfamiliar with Mythic+ and its associated general mechanics, you

can read more about it on our dedicated Mythic+ pages below.

2.

### Best Mythic+ Talent Builds

Beast Mastery plays ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader in Mythic+.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger is tankier, but it is far behind on damage in all

situations, and it is also a lot more effort to play optimally. We provide a

Dark Ranger build for those who prefer the playstyle, but we do not recommend

you playing it.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Mythic+ Talents

2.1.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader Mythic+ Talent Build for Beast Mastery Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/pack-leader.webp>) Pack Leader build for Mythic+ and

other AoE-focused content. It is based on simulating the conditions found in

real Mythic+ dungeons and seeing not just what does the most DPS, but what

actually clears the dungeon quicker in a group. There are builds that do more

AoE damage, but they all lose more single-target than they gain in terms of AoE,

and vice versa.

2.2.

#### Beast Mastery Hunter Utility Talent Considerations

Not all Utility Talents are relevant for every dungeon. We have created these

Talent builds under the assumption that you are not going to be very diligent

about swapping talents on a per-dungeon basis. However, the goal is to never

be left at a disadvantage by lacking a super impactful Talent for a particular

dungeon. This means we do omit some occasionally useful picks.

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbAYWAbDAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AACCDEFGHQSUYacegikoqs0248+AHNB-AAAA-BCEGIUw4ARZhpJ-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ Talents

2.3.

#### Best ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger Mythic+ Talent Build for Beast Mastery Hunter

This is the optimal ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/dark-ranger.webp>) Dark Ranger build for Mythic+, and

other AoE-focused content. It is based on simulating the conditions found in

real Mythic+ dungeons and seeing not just what does the most DPS, but what

actually clears the dungeon quicker in a group. There are builds that do more

AoE damage, but they all lose more single-target than they gain in terms of AoE,

and vice versa.

2.4.

#### Beast Mastery Hunter Utility Talent Considerations

Not all Utility Talents are relevant for every dungeon. We have created these

Talent builds under the assumption that you are not going to be very diligent

about swapping talents on a per-dungeon basis. However, the goal is to never

be left at a disadvantage by lacking a super impactful Talent for a particular

dungeon. This means we do omit some occasionally useful picks.

- Your "flexible" Talent points are, in our recommended order of most
  
  disposable:
  
  
  
  - [[spell:459983]]
  - [[spell:459517]] is only useful in certain dungeons, and is worthless
    
    in others.

**Be sure to make use of the 'Export Talents' button to import the best

build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C0PAAAAAAAAAAAAAAAAAAAAAAYzsNwAGwMsFYsAAgZGzMziZYmZGMjZmZYGzMjZmZsNzMmxMsMmmBAAAAMDAAAegxYYmBEwsA2GAA"
}
```
:::

:::details 来源计算器编码
```
#9D-ABCEEFGHIKXYYaccegkkmscdltx9BKKSquG-AABDEFGHSUacegiqswyy024+AFHJLNB-AAAA-AGIcgow4ApyCTD-
```

:::

Pre-pot [[item:271886]] around 6 seconds before the pull. Its Versatility

 ramps over its duration, so potting early means the last 15 seconds line up

with your opening [[spell:19574]]. In practice, just potting as you are running

up to the pull works fine.

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts

[[spell:147362]] is your "kick" and your most important bit of utility in

Mythic+, used to stop enemy casts for the benefit of the group and especially

the tank. It is **highly recommended** to use a Focus Kick macro for this.

```wow-macro
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Counter Shot
```

This macro will kick your focus target if you have one, mouseover if you have

no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a

**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly, so that you

are always able to kick it on cooldown, or in coordination with the rest of your

group.

3.2.

#### Stunning and "Stops"

[[spell:19577]] is your second-most important utility and is your

single-target "stop" for negating casts that cannot be normally interrupted. We

recommend using this in the same way as your Counter Shot, with the same macro

(with Intimidation swapped in for Counter Shot, of course). With a Talent, it

can also be an AoE stop.

[[spell:109248]] can be used to save your tank in hectic moments by

helping them kite mobs and generate some range.

[[spell:187650]] can be used as an additional stop alongside

[[spell:19577]], but it has a slow travel time and you will need to be

close to land it before most stunnable casts are finished.

### Other Utility

3.3.

#### Other Utility

[[spell:5384]] can not only be used to drop aggro, but also negate

certain casts and channels on you. In some cases, these mechanics will simply

re-target someone else in the group, but occasionally the mechanic will be

entirely negated with huge benefits. If you notice a cast or effect on you, try

to [[spell:5384]] it! With [[spell:459517]] talented, it will also

remove all Poisons and Diseases on you.

[[spell:19801]] can dispel beneficial Enrage and Magic effects

from enemy targets, which is regularly useful, and our builds already take

[[spell:459983]] for it. In some dungeons, you may choose to change

your default talents to grab [[spell:109248]] or [[spell:199483]].

[[spell:187698]] can be used to aid your tank in kiting by slowing mobs. It

is good to reflexively throw down a Tar Trap if your Tank dies, as it gives

everyone else a better chance at kiting and surviving.

4.

### Dealing with Affixes

This section has Hunter-specific tips for dealing with the various affixes of

Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Beast Mastery Hunter

Use AoE Crowd Control tools like [[spell:19577]] on dense clusters of

Orbs to take out as many as possible. You can use [[spell:187650]] and your

interrupt for the remaining, singular ones.

### Affix: Voidbound

4.2.

#### Voidbound Affix Management for Beast Mastery Hunter

Nothing specific to say here. Use your solid target-swapping

capabilities to focus the Void Emissary down as quickly as possible.

### Affix: Pulsar

4.3.

#### Pulsar Affix Management for Beast Mastery Hunter

Pop [[spell:186257]] and dash around with your excellent mobility

to grab as many orbs as quickly as possible.

### Affix: Devour

4.4.

#### Devour Affix Management for Beast Mastery Hunter

[[spell:5384]]'s Poison/Disease dispel (via [[spell:459517]]) is

a source of the dispel type needed for removing [[spell:440313]]. You can also

[[spell:109304]] to heal it off, but that costs a GCD.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **07 Sep. 2026:** Added Liquid Luster pre-pot timing.
- **15 Aug. 2026:** The Dark Ranger Mythic+ build now takes Kill Cleave over Razor Sharp.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **16 Jul. 2026:** Updated the Pack Leader Mythic+ talent build.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **03 Apr. 2026:** Updated Pack Leader Mythic+ Build.
- **22 Mar. 2026:** Updated both Mythic+ Builds.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Builds for the upcoming 12.0.1 changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **22 Sep. 2025:** Updated Dark Ranger M+ Build, swapping War Orders to Wild Call to smooth out Frenzy management further, gaining ~2.5% AoE, ~2% Prio, but losing ~1% single-target in the process.
- **17 Sep. 2025:** Updated M+ Hero Talent recommendation.
- **13 Sep. 2025:** Updated BM Dark Ranger Mythic+ Build.
- **06 Sep. 2025:** Updated verbiage slightly on NoMulti versus Multi builds and Dark Ranger.
- **03 Sep. 2025:** 1-point swap in the NoMulti build, 0.2% loss but I believe it feels a lot nicer to play and leaves less room for error.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **18 Mar. 2025:** Updated the recommended MDT Sim/Mythic+ Simulation Route Pastebin.
- **17 Mar. 2025:** Updated the recommended Talent Build for Mythic+.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **31 Oct. 2024:** Updated note on what talents you could be flexible with for Beast Mastery Dark Ranger M+.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **25 Oct. 2024:** Updated Hero Talent recommendation and information.
- **22 Oct. 2024:** Updated for Patch 11.0.5.
- **08 Oct. 2024:** Updated Talent Builds for the October 8th Hotfixes.
- **27 Sep. 2024:** Updated Ara-Kara Tips.
- **13 Sep. 2024:** Updated and clarified some tips.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for The War Within Season 1.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Beast Mastery Hunter in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### Generic Macros for Hunters

1.1.1.

##### TankMD AddOn + Macro

This automatically MD's your tank in the group with no need for targeting

or focusing or anything. Install the AddOn, set up the macro, and you are

golden.

1. Grab the [TankMD
   
   AddOn](<https://www.curseforge.com/wow/addons/tankmd>).
2. Set up this Macro:

#### TankMD Misdirection Macro

```wow-macro
#showtooltip Misdirection

/click TankMDButton1
```

1.1.2.

##### Focus Mouseover Macro

An essential macro for serious Mythic+. Sets your mouseover to be your

focus target and marks it with a Green marker (unless it is already marked with

something else), letting you kick it with the macros below.

#### Focus Mouseover Macro

```wow-macro
/focus [@mouseover,harm,exists,nodead][@target,harm,exists,nodead]

/tm [@mouseover,harm,exists,nodead][@target,harm,exists,nodead] 4
```

1.1.3.

##### "Auto Kick/Stun" Macro

This Macro will automatically use your Kick on a random, casting target

with no need for targeting or mouseover or focus. We like it for

lower/uncoordinated keys. See a cast? Hit the macro. The third macro does the

same concept but for [[spell:19577]].

#### Auto Kick Macro (Counter Shot)

```wow-macro
#showtooltip Counter Shot

/cast [@focus,exists,nodead,harm] Counter Shot

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Counter Shot

/target focus

/clearfocus

/startattack
```

#### Auto Kick Macro (Muzzle)

```wow-macro
#showtooltip Muzzle

/cast [@focus,exists,nodead,harm] Muzzle

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Muzzle

/target focus

/clearfocus

/startattack
```

#### Auto Stun Macro (Intimidation)

```wow-macro
#showtooltip 

/cast [@focus,exists,nodead,harm] Intimidation

/stopmacro [@focus,exists,nodead,harm]

/focus target

/cleartarget

/targetenemy

/cast Intimidation

/target focus

/clearfocus

/startattack
```

Note that it will prefer kicking your focus if you have one. If you want

it to prefer your mouseover, just swap out "focus" with "mouseover".

1.1.4.

##### Disengage StopCasting Macro

This macro will stop casts like [[spell:56641]] and force a

[[spell:781]], but it will not cancel channels like [[spell:257044]] or

[[spell:1261193]] that you can actually [[spell:781]] in the middle of.

#### Disengage StopCasting Macro

```wow-macro
#showtooltip Disengage

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/stopcasting [nochanneling:rapid fire,nochanneling:boomstick]

/use Disengage
```

1.1.5.

##### Cursor Macros for Ground-Targeted Abilities

These macros skip the green target circle placement step of using

ground-targeted abilities. We use it for everything from [[spell:1543]] to Traps

to [[spell:109248]] to [[spell:260243]].

Just place your cursor where you want it to go.

#### Cursor Macro (Freezing Trap)

```wow-macro
#showtooltip

/use [@cursor]Freezing Trap
```

#### Cursor Macro (Tar Trap)

```wow-macro
#showtooltip

/use [@cursor]Tar Trap
```

#### Cursor Macro (Binding Shot)

```wow-macro
#showtooltip

/use [@cursor]Binding Shot
```

#### Cursor Macro (Volley)

```wow-macro
#showtooltip

/use [@cursor]Volley
```

#### Cursor Macro (Flare)

```wow-macro
#showtooltip

/use [@cursor]Flare
```

1.1.6.

##### Pet "Reset" Macro

This macro is useful when jumping off ledges where you really want your

pet to follow you. Petpassive and Petfollow can make the pet "snap" to you more

readily. The [[spell:1850]] line ensures your pet gets back to you as quickly as

possible.

#### Pet "Reset" Macro

```wow-macro
/petpassive

/petfollow

/use Dash
```

1.1.7.

##### Pet Taunt Macro

In Mythic+ it is sometimes useful to taunt powerful mobs right before

their tank busters which can help save your tank's life. You will want to use a

Beetle, Boar, Carapid (BM only), Core Hound (BM only), Mechanical, Scalehide,

Shale Beast (BM only), or Turtle for this as they have a 50% DR on a 1-min

CD.

#### Pet Taunt Macro

```wow-macro
#showtooltip

/use [@mouseover,exists,harm][@focus,exists,harm]Growl

/use Scale Shield

/use Harden Carapace

/use Bristle

/use Bulwark

/use Obsidian Skin

/use Defense Matrix

/use Solid Shell

/use Shell Shield
```

1.1.8.

##### Mouseover Tranq Shot

Simply Tranqs your mouseover enemy, or your target if there is no valid

mouseover.

#### Mouseover Tranq Shot

```wow-macro
#showtooltip

/use [@mouseover,exists,harm,nodead][]Tranquilizing Shot
```

1.1.9.

##### Aspect of the Turtle Cancelaura Macro

The default game lets you cancel Turtle by pressing it again but there is

a "grace" period built into this. This macro skips the grace period and lets you

activate and then cancel Turtle immediately. Do not use this if you are the

kind of person who spams Turtle, this macro requires you to be deliberate with

a single key press to activate/deactivate!

#### Aspect of the Turtle Cancelaura Macro

```wow-macro
#showtooltip Aspect of the Turtle

/stopcasting

/stopcasting

/use Aspect of the Turtle

/cancelaura Aspect of the Turtle
```

1.1.10.

##### Mouseover Multi-Shot

Mainly useful for Marksmanship, which wants to put [[spell:2643]] on a

target separate from its main target to activate [[spell:257621]] or to

spread its Marks around. It has no nochanneling entry, since Marksmanship

deliberately clips the end of [[spell:257044]] with [[spell:2643]].

#### Mouseover Multi-Shot

```wow-macro
#showtooltip Multi-Shot

/use [@mouseover,exists,harm,nodead][]Multi-Shot

/petattack

/petassist
```

1.2.

#### Beast Mastery Macros

We recommend macroing petassist to offensive BM abilities to ensure it is

always on assist. We also recommend /petattack for abilities that force your pet

to start attacking a certain target ([[spell:34026]]) or incentivize you

to have your pet in a particular spot ([[spell:1264359]], for

[[spell:115939]] positioning).

1.2.1.

##### Bestial Wrath Cancelaura Shroud Macro

If you open with [[spell:19574]] from

[[spell:199483]]/[[spell:114018]] in Pack Leader, it can glitch

out your [[spell:471876]] and prevent them from spawning, massively

hindering your DPS. This macro ensures it cannot happen.

#### Bestial Wrath Cancelaura Shroud Macro

```wow-macro
#showtooltip

/cancelaura Shroud of Concealment

/cancelaura Camouflage

/use Bestial Wrath
```

1.2.2.

##### Black Arrow Cancelaura Shroud Macro + Mouseover

The same can happen with [[spell:466930]] and [[spell:378769]] procs. In

addition, this macro prefers our mouseover enemy for [[spell:466930]]s. There

are many scenarios where you can [[spell:466930]] a secondary target but not

your main target, and this macro is essential for that. It is also sometimes

optimal to [[spell:466930]] something other than your current target due to

positional constraints, like if your main target is a prio target but is

currently out of AoE position. The nochanneling element is an MM addition that

just prevents this cast from canceling [[spell:257044]].

#### Black Arrow Cancelaura Shroud Macro + Mouseover

```wow-macro
#showtooltip Black Arrow

/cancelaura Shroud of Concealment

/cancelaura Camouflage

/stopmacro [channeling:Rapid Fire]

/use [@mouseover,exists,harm][]Black Arrow
```

1.2.3.

##### Auto Pet-Summon Kill Command Macro

This macro will summon/ress your pet if you do not have one summoned, and is

otherwise just a regular [[spell:34026]] macro. Set the Call Pet X number

to whatever pet you default to. When we are Lusting in a group, we go in and

change

the macro to our Lust pet's number so that if we die in the key and hit KC, it

will summon the right pet. Takes the thinking out of it. Note that the ress part

is not 100% reliable if your pet unit is not actually present, which can happen if

you try to ress and then cancel the cast. So, you should still have

[[spell:982]] bound separately.

#### Auto Pet-Summon Kill Command Macro

```wow-macro
#showtooltip Kill Command

/petassist

/petattack

/cast [@pet,dead] Revive Pet;

/cast [@pet,noexists,mod:shift] Revive Pet; 

/cast [@pet,noexists] Call Pet 1;

/cast Kill Command
```

2.

### Best Addons

2.1.

#### Generic Addons for Hunters

Before you go downloading a bunch of different Addons, we recommend you set
up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many
Addons you may think you
cannot do without, are now available through the standard interface. Once you've
set up your UI, we
recommend thinking about which aspects or customization layers you would like to
add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of
Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional
Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and
reconfiguring your UI.

2.2.

#### User Interface

2.2.1.

##### EllesmereUI

[EllesmereUI](<https://www.curseforge.com/wow/addons/ellesmereui>)
is a complete replacement for the default User Interface.
It is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need: unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. EllesmereUI is
clean, easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the
best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same
customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a
great tool to help
you focus more on your own character, instead of having to worry about keeping
track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While some UI replacements
come with their own nameplates, those are often limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to
enlarge
and change color in certain circumstances, and it might help you keep track of
important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some
setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
an Addon developed by
[plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like
[Auctionator](<https://www.curseforge.com/wow/addons/auctionator>),
[Baganator](<https://www.curseforge.com/wow/addons/baganator>),
[Chattynator](<https://www.curseforge.com/wow/addons/chattynator>),
and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures,
and much more.
It is definitely worth checking out, especially if you end up having any issues
with Plater for
any reason.

2.5.

#### Damage Meters

2.5.1.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still
around
as the #1 Addon to customize damage and healing meters. While it may not offer
as many tracking
options as before due to the limits imposed by Blizzard, it is still around and
kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.6.

#### Specific Addons for Beast Mastery Hunters

Currently, we feel that there is no need for additional addons to play a

Beast Mastery Hunter to its full potential.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **04 Sep. 2026:** Removed the Barbed Shot Mouseover macro.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **04 Dec. 2025:** Added a Call of the Wild Araz/Prism Macro.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **25 Mar. 2025:** Updated for March 25 Updates.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **30 Oct. 2024:** Updated for October 29 Hotfixes.
- **22 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Preliminary update for The War Within Season 1.
- **30 Aug. 2024:** Preliminary update pass in preparation for Season 1.
- **22 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **11 May 2024:** Added a macro to assist when you have forgotten, or simply need to summon your pet on the fly.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Added Barbed Shot Mouseover Macro.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
