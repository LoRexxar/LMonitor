## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Mytholxgy。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-guide>)
- [练级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本神圣圣骑士指南。在这里，你将学习如何在团队副本和大秘境地下城中担任神圣圣骑士进行治疗。我们涵盖从基础到最大化输出的优化技巧的所有内容。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

神圣大秘境资源

[全新！顶级神圣天赋构建](<https://raider.io/specs/holy-paladin/talents>)

[顶级神圣大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/paladin/holy>)

[神圣大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=paladin--holy>)

[热门神圣队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=paladin--holy>)

1.

### 神圣圣骑士概述

神圣圣骑士专精于非常强大的单体治疗，是少数几个能在任何时刻真正决定单个玩家生死的治疗者之一。他们还拥有多种工具，可以帮助自己和团队其他成员减轻或规避伤害，例如[[spell:1022]]和[[spell:465]]。凭借如此多的实用性，他们一直是各种内容中最强的专精之一，并且已经保持了多年。

平庸

在过去的几个资料片中，神圣圣骑士在治疗输出方面一直难以与其他治疗者竞争。虽然他们在12.1版本期间获得了大量增益，但在团队副本中仍然难以跟上其他治疗者的步伐。话虽如此，神圣圣骑士确实通过

[[spell:20473]]

,

[[spell:19750]]

,

[[spell:82326]]

和

[[spell:85673]]

提供了卓越的单体治疗能力。这使得它成为最强的地下城治疗者之一，你可以不断让玩家脱离危险。

稳定的中坚力量

虽然并不总是提供最高的每秒治疗量输出，但神圣圣骑士十多年来一直是团队副本的中坚力量。

[[spell:465]]

是一个极其强大的增益效果，团队配置通常通过带上神圣圣骑士来获得它。

[[spell:31821]]

还允许他们在困难时刻为团队提供相当数量的伤害减免。神圣圣骑士还拥有出色的实用性和极其强大的单体治疗能力，以弥补他们相比其他治疗者缺乏群体治疗的不足。随着神圣圣骑士再次接近治疗量榜首，你可以预期在大多数治疗队伍配置中看到神圣圣骑士的身影。

重新成为版本答案

神圣圣骑士可能缺乏其他治疗者的伤害输出能力，但由于单体法术与圣光道标效果（如

[[spell:1244878]]

以及

[[spell:200025]]

或

[[spell:156910]]

）的结合，它提供了最高的治疗输出。这些使你能够通过将强大的单体治疗转移给盟友来更好地应对困难时刻。此外，神圣圣骑士通过诸如

[[spell:1022]]

和

[[spell:1044]]

等技能提供了所有治疗者中最强的实用性之一。综合考虑，神圣圣骑士是一个极佳的选择，很可能与最强的治疗专精争夺“版本答案”的位置。

超强实用性

神圣圣骑士提供游戏中最好的实用性之一。

[[spell:1044]]

,

[[spell:1022]]

，以及

[[spell:642]]

和自由祝福在各种内容中都极其强大。自由祝福将允许你解除定身和减速效果，这可以使困难的机制变得完全简单。防护可以帮助你在危险的拉怪中解决仇恨问题，同时还能移除物理伤害和流血效果。这可能成为某人生死之间的关键，同时也让他们能够免疫某些机制。最后，神圣之盾或“泡泡”将允许你完全无视机制，让你专注于保命，或者简单地脱离困境。

防御大师

神圣圣骑士拥有三个强大的防御性冷却技能：

[[spell:403876]]

,

[[spell:642]]

和

[[spell:1022]]

。神圣防护的冷却时间极短，意味着你可以持续在危险时刻拥有它。圣盾术是一张免死金牌，让你完全免疫伤害和机制——这是其他治疗职业都没有的。最后，保护祝福也可以作为类似的免疫手段，但仅对物理伤害和流血效果有效。面对高额物理伤害时，它可以直接抵消这些效果，但要始终记住它对魔法效果无效！

表现不佳

神圣圣骑士最大的弱点在于机动性。虽然

[[spell:190784]]

的冷却时间相当短且有多次使用机会，但该职业仍然不如其他专精。站位失误或对机制反应缓慢可能会对你自己和你的队伍造成致命后果。唤魔师可以随时

[[spell:358267]]

脱离机制并重新站位，德鲁伊和萨满祭司拥有

[[spell:768]]

和

[[spell:2645]]

提供帮助，而圣骑士则相当受限

[[spell:190784]]

处于冷却状态时，圣骑士的机动性相当有限。

1.

### 神圣圣骑士在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

随着12.1.5版本的发布，你将可以体验两项新的终局内容：一个新的团队副本和一个新的巨型地下堡。有关这些新终局内容的更多信息，你可以访问下方链接的专属页面。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

有关12.1.5版本改动的完整分析，你可以访问我们的专属中心页面，它将为你提供所需的所有信息，无论你是一直在玩还是回归玩家。

2.3.

#### 职业改动

在12.1.5版本中，神圣圣骑士没有获得任何显著改动。话虽如此，如果你最近没有访问天赋页面，你可能需要去看一看，确保你使用的是最新的构建。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_deathmark.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

在12.1版本中，神圣圣骑士获得了大量治疗量增益，使其能更好地与顶级治疗量专精竞争，在天赋选择中提供更多选择，并增强了[[spell:85673]]的威力。下面我们将列出一些关键改动：

- [[spell:1232616]]、[[spell:157047]]和[[spell:414139]]都获得了数值增益，这增强了[[spell:200025]]的威力，因为这些天赋与它的协同效果远优于[[spell:156910]]
- [[spell:85673]]/[[spell:156322]]被增强到强于[[spell:85222]]的程度，这意味着在团队副本和大秘境中你总是会优先使用它。
- [[spell:1241511]]现在减少[[spell:384376]]和[[spell:394088]]持续时间的幅度变小了。这不太可能对团队副本产生影响，但可能使其在大秘境中更有吸引力。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜中神圣圣骑士的改动

进入至暗之夜后，暴风雪希望专注于减少神圣圣骑士的治疗来源数量，同时消除追踪多种不同增益效果（如[[spell:248033]]）的需求。此外，他们希望减少该专精可用的冷却技能数量，同时让[[spell:31821]]感觉更有影响力。甚至[[spell:35395]]也被移除了，因为更多重点放在了[[spell:20473]]和[[spell:53576]]上。最后，[[spell:85222]]的目标机制得到了调整，现在不再治疗你前方的玩家，而是治疗你周围的玩家。一些核心改动将列在下方：

- [[spell:114165]]和[[spell:375576]]现在共享一个抉择节点。
- [[spell:24275]]不再可直接施放，而是在[[spell:384376]]期间替换[[spell:20271]]。当这种情况发生时，愤怒之锤将获得审判的所有天赋加成。
- [[spell:35395]]已被移除，但当你点出[[spell:394088]]时，它会在冷却期间回归。
- [[spell:196926]]已被重新设计。现在它使[[spell:20473]]减少[[spell:20271]]的冷却时间。
- 以下天赋已被移除：[[spell:148039]]、[[spell:329722]]、[[spell:392951]]、[[spell:183415]]和[[spell:383388]]。
- 加入了大量新天赋，一些天赋被重新设计。

除了这些改动之外，你还将获得新的巅峰天赋以及3个新的英雄天赋选择。

2.4.1.

##### 顶点天赋

在至暗之夜中，你将获得[[spell:1244878]]，即新的巅峰天赋。该能力有3个独立的等级，每个等级都提升其威力。下面我们将详细说明每个等级的作用：

- 等级1——在战斗中，你将获得一个名为[[spell:1244878]]的额外道标。该道标将自动放置在生命值最低的队友身上，如果它治疗的玩家生命值高于50%，或者另一名队友的生命值降到50%以下，它将转移到新的生命值最低的队友身上。
- 等级2——增加[[spell:1244878]]转移的治疗量，并增加你对拥有救世道标的目标造成的治疗量。
- 等级3——每8秒或当[[spell:1244878]]转移时，会在目标身上放置一个吸收护盾，该护盾在被击破前还提供伤害减免。

[[spell:1244878]]最重要的方面是它还受益于任何强化[[spell:53563]]的天赋。这意味着[[spell:387781]]、[[spell:157047]]、[[spell:416799]]甚至[[spell:197446]]都会增益[[spell:1244878]]。这实际上意味着你始终拥有一个额外的道标。此外，由于救世道标等级2还会增加你对救世目标造成的治疗量，直接治疗你的救世道标目标的惩罚性显著降低。在某些时候，与通常避免直接治疗的普通道标相比，它甚至可能更有益。

2.4.2.

##### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱在至暗之夜中有两个显著变化。一个是新天赋：[[spell:1263782]]。这会在进入[[spell:384376]]时为你提供两点神圣能量。理想情况下，你应该确保在按下主要冷却技能时神圣能量没有溢出，但这并不是世界末日。另一个变化是[[spell:431377]]的威力被削弱。在整个《地心之战》中，晨光占据了你总体治疗量的很大比例。在对该专精进行各种增益和削弱之后，晨光失去了大量威力，惩罚性将大大降低。虽然你仍然希望最大化施放次数并选择能获得高价值的目标，但它的重要性将大大降低。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者在至暗之夜中获得了一些有趣的新天赋，将提升其威力。[[spell:1271466]]使你在[[spell:432472]]激活并被使用时有几率触发[[spell:248033]]。虽然[[spell:248033]]在至暗之夜中不再触发[[spell:384376]]，但这仍然是铸光者的一个强力补充，应该能提升[[spell:433718]]的治疗量。需要注意的是，该天赋不需要你点出觉醒即可生效，无论你的天赋选择如何它都会触发。

2.4.3.

##### 输出循环变化

在 至暗之夜 中，神圣 圣骑士 的玩法将基本保持不变，重点在于最大化你可以用于 [[spell:156322]] 或 [[spell:85222]] 的 神圣 力量数量。这一选择将继续取决于你正在进行的内容类型，大秘境希望施放永恒之火，而团本则使用黎明之光。除此之外，你将专注于最大化 [[spell:20473]] 的施放次数，并在必要时穿插 [[spell:19750]] 的施放。[[spell:20271]] 失去了大量威力，通常只会在进行大秘境内容且想要提高伤害时使用。治疗将侧重于 [[spell:20473]]、[[spell:19750]] 和一个 神圣 力量消耗技能。由于十字军打击已被移除，也几乎没有理由全程在近战范围内战斗。如果场面变得极其拥挤或你难以看清某些机制，你可以后退片刻，完全不会受到惩罚。

当你使用 [[spell:394088]] 构建时，你的循环将基本相同，但在技能使用上会有一些细微差异。在复仇十字军期间，你将重新获得 [[spell:35395]] 的使用权限。这意味着你仍将遵循在 [[spell:20271]] 和 [[spell:35395]] 之间轮换的典型玩法，同时尽可能多地消耗 神圣 力量。

1.

### 神圣 圣骑士 玩法基础

神圣 圣骑士 和任何治疗者一样，关键在于策略性地使用你的技能。你不会使用固定的循环，而是利用你灵活的技能组合来适应并克服游戏带给你的任何挑战。

为了成为一名成功的 神圣 圣骑士，你必须尽可能高效地使用你的冷却技能。以下这三个主要焦点最好地概括了 神圣 圣骑士 的基础玩法。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_torch_thrown.jpg>) **不要浪费 神圣 力量**
  
  
  
  
  在游玩 神圣 圣骑士 时，重要的是你绝不能浪费 神圣 力量。虽然你并不总是需要在达到 3 层时立即消耗 神圣 力量，但你仍然应该始终确保在达到 5 层时进行消耗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_paladin_divinetoll.jpg>) **保持技能冷却**
  
  
  
  
  神圣 圣骑士 拥有两个冷却时间较短的技能，它们将在你的 HPS 中发挥重要作用。第一个是 [[spell:200025]]，它对盟友施加一个强化版的 [[spell:53563]]；第二个是 [[spell:375576]]，它施放 5 个 [[spell:20473]]。如果你没有足够频繁地施放这些技能，你将损失大量的治疗量。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **正确利用 神圣 光**
  
  
  
  
  [[spell:82326]] 是我们最强大的法术之一，提供大量治疗但消耗也非常高。重要的是你要经常施放这个技能以利用其治疗效果，但也要平衡使用，不要用到耗尽法力。在大秘境中，由于你可以喝水，你可以在这方面稍微更激进一些。

1.

### 作为 神圣 圣骑士 如何获取装备

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了一个专门的 神圣 配装页面。我们目前涵盖了第二赛季装备的推荐，以便你在 至暗之夜 终局内容发布时有一个良好的开端。在你获取了一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 铸光者大秘境天赋已更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年10月1日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 头部和脚部毕业装备推荐已更新。
- **2026年8月25日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为额外拾取策略添加了额外信息。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 对饰品梯队进行了小幅更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月4日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 史诗钥石天赋构建已更新。
- **2026年4月4日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 史诗钥石天赋构建已更新。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为11.2.5补丁更新。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月31日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 循环页面已全面改版并更新。
- **2025年8月20日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 更新了武器附魔推荐。
- **2025年8月14日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 更新了饰品推荐。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月13日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 更新了谜题卡特尔芯片的推荐。
- **2025年5月6日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 推荐构建已更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 页面已为11.1.5补丁更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 页面已为11.1.5补丁更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 页面已为11.1.5补丁更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 页面已为11.1.5补丁更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 页面已针对11.1.5补丁更新。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** 新增了加里维克斯的信息。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 添加了Cyrces Circlet的信息。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 页面全面改版。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月24日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 复仇十字军循环已更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 页面已针对11.0.5补丁进行更新。
- **2024年10月21日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年9月28日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 属性优先级略有变动。
- **2024年9月28日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 添加了地下城提示。
- **2024年9月16日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 更新了装饰信息。
- **2024年9月16日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** 更新了首领信息和天赋推荐。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 添加了第1赛季毕业装备。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已添加第1赛季信息。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已针对第1赛季更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 消耗品推荐已更新。
- **2024年8月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年8月30日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 天赋构筑已更新。
- **2024年8月30日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 天赋配置已更新。
- **2024年8月27日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 添加了地下堡配装。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为《地心之战》进行了审查和更新。
- **2024年8月21日（本页）：** 为《地心之战》进行了审查和更新。
- **2024年8月17日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 为《地心之战》进行了审查和更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/holy-paladin-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 页面已针对《地心之战》前夕更新。
- **2024年7月20日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 页面已针对《地心之战》前夕更新。
- **2024年6月27日（[地心之战](<https://www.icy-veins.com/wow/holy-paladin-the-war-within-pve-guide>)):** 核心改动已更新以反映新的变化。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/holy-paladin-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/holy-paladin-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为第4赛季进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为第4赛季进行了更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 为第4赛季进行了更新。
- **2024年4月18日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为第4赛季进行了审核。
- **2024年4月1日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 修复了升级用的字符串。
- **2024年3月26日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 已针对10.2.6版本更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 天赋推荐已更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁更新循环。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 天赋推荐已更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 属性优先级已更新。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年11月29日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 更新了BiS列表和美化推荐。
- **2023年11月29日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 对宝石建议进行了小幅更新。
- **2023年11月21日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 更新了武器附魔推荐。
- **2023年11月13日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 天赋推荐已更新。
- **2023年11月13日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 大秘境天赋推荐已更新。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 根据孢子披风的削弱更新了装饰和毕业列表。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 页面已更新至 10.2。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 页面已更新至 10.2。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 页面已更新至 10.2。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 页面已更新至 10.2。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已针对10.2补丁进行审查
- **2023年11月6日（本页）：** 页面已更新至 10.2。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 添加了毕业装备。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 格式更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7补丁更新
- **2023年8月7日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 更新了附魔推荐。
- **2023年8月7日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 更新了天赋推荐。
- **2023年8月7日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 更新了循环并添加了更多关于圣光道标目标选择的信息。
- **2023年8月7日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 更新了天赋推荐。
- **2023年8月7日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 更新了天赋推荐。
- **2023年7月19日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2023年7月17日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2023年7月17日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 天赋推荐已更新。
- **2023年7月17日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 更新了史诗+天赋推荐。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 针对10.1.5补丁更新了装备推荐。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已针对10.1.5补丁更新建议。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 针对10.1.5补丁更新了天赋。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为10.1.5版本更新了循环。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 天赋推荐已针对10.1.5进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 为补丁10.1.5更新了法术。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 10.1.5版本天赋推荐已更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月27日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 复仇十字军循环已更新。
- **2023年5月26日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 添加了关于时光漫游饰品的信息。
- **2023年5月20日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 根据漏洞修复更改了美化装备建议。
- **2023年5月16日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 装饰更新。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已更新至10.1补丁。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已更新至10.1补丁。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已更新至10.1补丁。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已更新至10.1补丁。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已更新至10.1补丁。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已更新至10.1补丁。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已更新至10.1补丁。
- **2023年5月1日（本页）：** 已更新至10.1补丁。
- **2023年3月28日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 更新了原初宝石推荐。
- **2023年3月28日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 更新了原初宝石推荐。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/holy-paladin-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已为10.0.7补丁更新。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年2月22日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 天赋推荐已更新。
- **2023年2月22日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 更新了大秘境天赋推荐。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月13日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 添加了巧思火花制作建议。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月24日（[升级](<https://www.icy-veins.com/wow/holy-paladin-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[传说物品](<https://www.icy-veins.com/wow/holy-paladin-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[托加斯特](<https://www.icy-veins.com/wow/holy-paladin-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[盟约与羁绊](<https://www.icy-veins.com/wow/holy-paladin-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[装备页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[插件页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[附魔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[属性页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[统御圣所页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[大秘境页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[天赋页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[法术页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（[简单模式页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月24日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-2-changes-analysis>)):** 已审核并批准用于9.2补丁。
- **2022 年 1 月 26 日（[9.2版本分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-2-changes-analysis>)):** 更新以包含削弱和双传说物品组合。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** 针对9.1.5补丁更新。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** 措辞已修订以反映9.1补丁的发布。
- **2021年6月4日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** 页面已更新以反映传说物品的改动。
- **2021年5月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** 页面已更新以反映神圣圣骑士最近的削弱。
- **2021年4月25日（[9.1 补丁分析](<https://www.icy-veins.com/wow/holy-paladin-patch-9-1-changes-analysis>)):** 页面已填充初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年12月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** 添加了扎库尔和艾萨拉。
- **2019年10月2日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** 添加了女王之庭。
- **2019年9月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** 为前5个首领添加了提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月14日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** 新增了关于圣光之熠构筑的说明。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-battle-of-dazar-alor-raid-guide>)):** 新增了关于圣光之熠构筑的说明。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-crucible-of-storms-raid-guide>)):** 页面已添加。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** 已审核，确认适用于8.1版本。
- **2018年9月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** 添加了初步的首领提示和天赋建议。
- **2018年8月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-uldir-raid-guide>)):** 加入了神圣圣骑士逐个首领页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页面，你将找到我们的逐级神圣 圣骑士升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[圣骑士 升级指南](<https://www.icy-veins.com/wow/paladin-leveling-guide>).

1.

### 神圣圣骑士在至暗之夜的练级指南

圣骑士是游戏中最好的升级职业之一。你拥有极强的多功能性，因为你既可以在地下城中担任坦克或治疗，同时也可以切换到DPS进行单人任务。

在较低等级时，你通常可以通过玩神圣或防护并排队地下城来轻松升级，因为排队时间几乎是瞬间的。即使你发现自己不擅长治疗或坦克，早期的练级地下城也不是太难，所以这是学习的好机会！在较高等级，做任务变得更快，并且在某些情况下是强制性的（资料片战役），你会想要专精于惩戒或防护，因为它们提供比神圣高得多的伤害。

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的战利品。此规则唯一的例外是，如果你有一个戒指或项链，物品等级略低，但拥有2项副属性而非1项。

使用传家宝物品来帮助提升练级速度时，你通常需要尽可能多地使用 **急速** 尽可能多的装备部位，以帮助对抗你可能拥有的非常低的次要属性。这将加快你的循环速度，并有助于防止感觉缓慢和笨拙。

1.2.

#### 至暗之夜升级实用消耗品

在至暗之夜中升级时，你在整个地心之战中使用的许多消耗品将继续有价值。确保你始终有合剂效果：[[item:212274]]。以及准备大量可能有帮助的药水：[[item:212265]]。在资料片末期，许多玩家会试图卖掉他们剩余的消耗品库存，所以你经常能找到便宜的消耗品来帮助你加快升级速度！

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 神圣 圣骑士 80级 至暗之夜 升级
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyYmZmZMzMLwYYZsZmFzkYWmxMzwY2yAwAwGYzsMzMzysNzMbNAAAALsBYDGjlZGDAAzMMjxwA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjEzyMmZGGzWGAGA2AbmlZmZWmtZmZrBAAAYBA2gxwMjZAAMzwMGDDA"
}
```
:::

:::details 来源计算器编码
```
#BB-URGsmjlZECot5Z7SnrrpJYnEKiTbji4OZdBA-BJNneMILDPMtK1oMKOcWzAEEJ3KC1PR-AAAA-OCYoQIUs0wMEJA-
```

:::

2.1.

#### 升级用战争模式天赋

在这里，你将找到关于升级以及进行单人/小队PvE内容时最佳PvP天赋的信息。

1. [[spell:199441]]在团队内容中非常出色，因为它为你的小队提供免费伤害。[[spell:82326]]是你可能会经常使用的一个技能，而复仇之光将使它在你选择用神圣光治疗盟友时对敌人造成伤害。
2. [[spell:216327]]使你的主要技能之一（[[spell:82326]]）显著增强。这个天赋在单人游戏中用处不大，但在治疗盟友时非常出色。
3. [[spell:210378]]允许你叠加[[spell:85222]]以进行相当可观的额外治疗。由于你不会非常频繁地施放这个技能，当你选择使用它来保持团队健康时，它的效果会更加强大。

神圣 圣骑士不幸的是没有任何强大的单人升级PvP天赋。他们的大部分好处只有在组队内容中才能看到。上面没有列出的PvP天赋不值得考虑，因为它们在非常小众的情况之外没有用处。

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–9：**当你首次创建你的圣骑士时，你只有一个可用技能：[[spell:35395]]。在2级时，你将解锁[[spell:53600]]，在3级时，你获得[[spell:275773]]。在10级时，你可以正式专精神圣。

**等级 10 起：**当你达到10级时，你将可以排队进入地下城。如果你打算以神圣专精升级，你会想要使用地下城查找器工具。这将是游玩神圣时迄今为止最高效的升级方式。如果你对深入的循环解析感兴趣，可以查看我们的 [循环页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-rotation-cooldowns-abilities>)。否则，我们这里总结了如何使用神圣圣骑士可用的一些治疗法术。

3.1.

#### 治疗循环

- **等级 11 起：**尽可能多地施放 [[spell:20473]]。
- **等级 10 起：**尽可能多地施放[[spell:20271]]。
- **等级 10 起：**当你有3层神圣之力且你的目标需要治疗时，施放[[spell:85673]]。
- **等级 13 起：**如果你有3层 神圣 力量，并且有3名或更多盟友需要治疗，则施放[[spell:85222]]。
- **等级 10 起：**如果无法执行以上操作，则施放[[spell:19750]]。
- **等级 10 起：**如果不需要治疗，请使用你的DPS循环（详见下文）。

3.2.

#### DPS循环

**等级 10 起：**输出循环相当简单，应在不需要治疗或你正在做任务时使用。

- **等级 11 起：**按冷却时间使用 [[spell:20473]]。
- 冷却好就使用[[spell:275773]]。
- 如果你在对抗多个目标，可以选择放弃[[spell:26573]]。（一旦你获得了[[spell:414113]]，只需按下[[spell:275773]]即可放下奉献）。
- 当不需要治疗时，用[[spell:53600]]消耗神圣能量。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 页面已为11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 页面已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年4月1日：** 修复了升级用的字符串。
- **2024年3月26日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将解释如何在《魔兽世界》12.1.5版本中轻松游玩 神圣 圣骑士，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 神圣 圣骑士 在 至暗之夜 中的基础知识

本节面向刚接触游戏或该职业的玩家，他们无意参与史诗难度团队副本，或只是希望以更直接的方式进行专精输出，而不会被最优输出所需的众多优先级和主动技能所淹没。

神圣圣骑士最擅长通过其信标和单体治疗被动支援坦克。除此之外，神圣圣骑士的独特之处在于，它拥有许多可用工具，能够以其他治疗者无法做到的方式处理各种战斗机制。学习该专精时需要遵循的3条快速规则：

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_torch_thrown.jpg>) **不要浪费 神圣 力量**
  
  
  
  
  在游玩 神圣 圣骑士 时，重要的是你绝不能浪费 神圣 力量。虽然你并不总是需要在达到 3 层时立即消耗 神圣 力量，但你仍然应该始终确保在达到 5 层时进行消耗。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_paladin_divinetoll.jpg>) **保持技能冷却**
  
  
  
  
  神圣 圣骑士 拥有两个冷却时间较短的技能，它们将在你的 HPS 中发挥重要作用。第一个是 [[spell:200025]]，它对盟友施加一个强化版的 [[spell:53563]]；第二个是 [[spell:375576]]，它施放 5 个 [[spell:20473]]。如果你没有足够频繁地施放这些技能，你将损失大量的治疗量。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_holy_surgeoflight.jpg>) **正确利用 神圣 光**
  
  
  
  
  [[spell:82326]] 是我们最强大的法术之一，提供大量治疗但消耗也非常高。重要的是你要经常施放这个技能以利用其治疗效果，但也要平衡使用，不要用到耗尽法力。在大秘境中，由于你可以喝水，你可以在这方面稍微更激进一些。

1.

### 神圣 圣骑士在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱团队副本天赋

2.1.

#### 神圣圣骑士新手团队副本构筑

这套配装侧重于非常标准的循环，通过[[spell:20473]]和[[spell:19750]]积累神圣能量，然后用[[spell:85222]]将其消耗掉。一如既往，目标是尽可能多地产生神圣能量，同时确保你不会因为没有消耗它而浪费任何能量。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGmBAwMDzghB"
}
```
:::

:::details 来源计算器编码
```
#BB-CDGIMUtIJjnD08MNddlpdbH4FHV2WloIxnp-BJLMNnrIRTWeDGPKFKo0ASUlBk4Ip6H-AAAA-GScgcpBIgQhhCD-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 史诗钥石/探底天赋

2.2.

#### 神圣 圣骑士 新手大秘境配装

这个构建是为那些想玩一个相当简单的以大秘境为中心的构建的人设计的，如果你想去地下堡治疗，它也很有用。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAMAAw2YmZmZMzMLwMDLjNzsY0EzyMmZGGzWGAGA2AbsMzMzysNzMbNAAAALgZwGMGGMDAgZGmxYYA"
}
```
:::

:::details 来源计算器编码
```
#BB-DGWzURilZmmCo9pz1lz2mELwfAKiTZ98iiOB-BNJMnLIePWdMtGKP0oMKIU:yAikLwKR-AAAA-GiE4IghChQxSDD-
```

:::

### 神圣 圣骑士 基础输出循环

2.3.

#### 团队治疗

这个输出循环假设你正在玩推荐的团队副本构建，并且无论你是否拥有套装加成都不会改变。有关更多信息，请参阅输出循环页面以获取根据你想要的构建而定的其他输出循环。

- 尽可能多地施放 [[spell:20473]]。
- 使用[[spell:156322]]进行单体治疗或[[spell:85222]]进行群体治疗来消耗神圣之力。
- 当你没有3点神圣能且无法使用神圣震击时，施放[[spell:19750]]。
- 施放[[spell:82326]]进行大量治疗，但不要施放太多，否则你会极快地耗尽法力值。

2.4.

#### 五人本治疗

五人本治疗与团本循环非常相似，区别在于你会施放[[spell:85673]]（或在时施放[[spell:156322]] ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱）的频率高得多。此循环将假设你使用的是推荐的大秘境配装。

- 将[[spell:20473]]作为你的主要治疗法术使用。
- 用 [[spell:85673]]（或 [[spell:156322]] 消耗 神圣 力量，如果 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱).
- 当你没有3点神圣能且无法使用神圣震击时，施放[[spell:19750]]。
- 施放 [[spell:82326]] 进行大量的单体治疗。

在进行地下城时，你可以更多地依赖[[spell:82326]]，因为你可以在每波小怪之间喝水。这意味着你不会像在团队副本中那样担心法力值。

2.4.1.

##### 巅峰天赋： ![Beacon of the Savior Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) 救世道标

在至暗之夜中，你将获得[[spell:1244878]]，这是一个新的巅峰天赋。该技能拥有三个独立的等级，每个等级都会提升其威力。下面我们将逐一解析每个等级的具体效果：

- 等级1——在战斗中，你将获得一个名为[[spell:1244878]]的额外道标。该道标将自动放置在生命值最低的队友身上，如果它治疗的玩家生命值高于50%，或者另一名队友的生命值降到50%以下，它将转移到新的生命值最低的队友身上。
- 等级2——增加[[spell:1244878]]转移的治疗量，并增加你对拥有救世道标的目标造成的治疗量。
- 等级3——每8秒或当[[spell:1244878]]转移时，会在目标身上放置一个吸收护盾，该护盾在被击破前还提供伤害减免。

[[spell:1244878]]在很大程度上是一个你不需要太担心的被动效果。通常可以将其视为拥有第3个[[spell:53563]]，你可以基本忽略它。话虽如此，因为你会对救世道标目标进行额外治疗，所以如果你发现自己直接治疗救世者目标（就像通常对圣光道标目标那样），也不是什么大问题。

2.4.2.

##### 第2赛季套装

至暗之夜第2赛季的套装对于神圣圣骑士来说相当直接。它将提供以下加成：

- [[spell:1296656]] — 增加 [[spell:19750]] 的治疗量和 [[spell:231663]] 的吸收量。
- [[spell:1296657]]——[[spell:20271]]现在有20%的几率获得[[spell:53576]]，而[[spell:82326]]现在总是获得它。神圣圣光的法力消耗也增加了。

这个套装加成为 神圣 圣骑士 提供了不错的循环提升。[[spell:20271]] 比配合 [[spell:53576]] 的 [[spell:19750]] 弱得多，但现在它变成了在你尝试触发灌注时更好的施放技能。此外，[[spell:82326]] 现在是获得灌注的保证途径。这不会对你的循环产生重大影响，但现在你能获得更多 [[spell:53576]]，意味着你不需要施放那么多无增益的 [[spell:19750]]。

[[spell:82326]]带来的法力消耗增加乍一看可能很奇怪，但它的存在是为了防止玩家因为拥有无限法力而无休止地刷神圣光，从而导致无限的[[spell:53576]]。

### 圣骑士 神圣 属性优先级

2.5.

#### 神圣圣骑士属性优先级

神圣圣骑士的一般属性优先级如下所示。这在很大程度上是一个粗略的指导原则，是为不希望使用模拟工具进行角色模拟的玩家设计的
[QuestionablyEpic](<https://questionablyepic.com/>)。有关此页面上呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>).

智力

精通

急速

暴击

全能

### 暴风雪战斗助手

2.6.

#### 战斗助手

在11.1.7补丁中加入，战斗助手是一个旨在施放你循环技能的一键式功能。不幸的是，对于治疗专精来说，它的表现并不好。作为一名神圣 圣骑士，战斗助手 **不会施放治疗法术**，它将不会施放[[spell:20473]]，也不会消耗神圣能量。这使得它基本无法使用。唯一可以使用它的情况是你完全专注于输出伤害时，即便如此，你仍需要自行施放其他技能。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 页面全面改版。
- **2024年10月21日：** 页面已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年4月18日：** 为第4赛季进行了审核。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 属性优先级已更新。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月7日：** 更新了天赋推荐。
- **2023年7月10日：** 10.1.5版本天赋推荐已更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，你将找到《魔兽世界》12.1.5 补丁中 神圣 圣骑士 的最佳天赋。我们还为不同类型的活动（如团队副本或大秘境）提供了默认天赋构建。如果你开启了战争模式，我们也为你提供了 PvP 天赋的介绍。

1.

### 至暗之夜 中 神圣 圣骑士 的最佳天赋

在第二赛季中，经过 至暗之夜 开局的多次增强后，神圣 圣骑士 有一种玩法在团本中脱颖而出，而在大秘境中则有更具竞争力的选择。

- **团本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 是团本的首选，很大程度上是因为它提供的被动增益能强化 [[spell:85222]]、[[spell:156322]] 和 [[spell:20473]]。不幸的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 在团本中不具竞争力，除非为了好玩，否则不应使用。
- **大秘境 -** 在大秘境中，你有一个更具竞争力的选择：
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 提供稍高的伤害，但缺乏可靠的治疗，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 所能提供的可靠治疗。因此，我们建议玩家使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 构建。

团本的选择相当直接，但在大秘境中，由于两个英雄天赋都具有竞争力，我们将为两者都提供构建，以便你进行尝试并找出最适合你的。再次强调，一般规则是
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 将提供更好的治疗，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 可以提供更多的伤害。

**快速开始导入代码：**

:::talents 烈日先驱 团本
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGmBAwMDzghB"
}
```
:::

:::talents 烈日先驱 大秘境+
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjmYWmxMzwY2yAwAwGYjlZmZWmtZmZrBAAAYBMD2AGGMDAgZGmxYYA"
}
```
:::

:::talents 铸光者 大秘境+
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsYmBAAAmZWWWsMzwGbjZwGwMGAgZGAmxY0A"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

烈日先驱

团本 - 标准

推荐

秘境+

推荐

铸光者

团本 - 复仇十字军构建

大秘境/地下堡

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 标准构建

这是你的标准 神圣 圣骑士 构建。你将主要在施放 [[spell:20473]] 和 [[spell:19750]] 之间轮换以积累 神圣 力量，然后使用 [[spell:85222]] 或 [[spell:156322]] 进行消耗。因为 圣光闪现 也会产生一个 神圣 力量且没有冷却时间，你经常会大量使用它来帮助维持积累和消耗的循环。许多天赋是固定的，但你可以考虑根据战斗和个人风格在 [[spell:156910]] 和 [[spell:200025]] 之间进行更换。当你使用 [[spell:156910]] 时，你需要将 [[spell:1232616]] 更改为 [[spell:414203]]。此外，你可能需要考虑将 [[spell:1241805]] 和 [[spell:157047]] 的点数投入 [[spell:210294]] 和 [[spell:200430]]。

:::details 常见问题：我应该点解放吗？
[[spell:461471]]

以牺牲一些治疗为代价提供可观的伤害提升。你可能会看到高水平的 神圣 圣骑士在世界首杀争夺赛中使用这个天赋，但他们通常处于需要利用现有装备尽可能极限压榨伤害以击败首领的情况。其他所有水平的玩家通常从拥有更多治疗中获益更多，但如果你有兴趣以牺牲治疗为代价来极限压榨伤害，你当然可以点出这个技能。

:::

### 天赋方案 0-1

1.2.

#### 大秘境天赋

大秘境构建牺牲少量治疗来提高你的伤害。这是通过选择能增强 [[spell:53600]] 效果的天赋来实现的。在空闲期间以及只需要少量治疗时，你往往会使用正义盾击来消耗 神圣 力量。只是要小心在困难时刻，可能最好为即将到来的伤害窗口保留 神圣 力量。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 复仇十字军

需要注意的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 和 [[spell:394088]] 不如标准的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 构建那么强力。选择这种玩法会导致明显的治疗损失。此外，这比使用标准的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 构建更差，后者使用与你在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 天赋页面上能找到的相同天赋。这个构建的目的是为那些想要减少施法量的玩家创建一种以近战为核心的玩法。

这个构建专注于 [[spell:433718]] 和 [[spell:394088]] 天赋之间的协同效应。这两者都非常强调尽可能频繁地施放 [[spell:20271]]。这成为了你最重要的技能。这并不意味着你想要停止消耗 神圣 力量，但你应该尽可能保持审判的冷却。在你的 [[spell:394088]] 期间，你还将重新获得 [[spell:35395]] 的使用权限，它将成为一个高优先级技能。为了最大化这个构建的输出，重要的是你要很好地理解它与标准构建之间的循环差异。

### 天赋方案 1-1

1.4.

#### 大秘境/宝库天赋

大秘境/宝库构建牺牲少量治疗来提高你的伤害。这是通过选择能增强 [[spell:53600]] 效果的天赋来实现的。在空闲期间以及只需要少量治疗时，你往往会使用正义盾击来消耗 神圣 力量。只是要小心在困难时刻，可能最好为即将到来的伤害窗口保留 神圣 力量。

这个构建的玩法与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 大秘境构建完全相同，只是将 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 替换为

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxsMjZmhxslBgBgNwmZZGzsMbzMzWDAAAwCAsxYMMzYGAAzMMjxwA"
}
```
:::

:::details 来源计算器编码
```
#BB-CGIMUtKjlnD08MNddpdbH4ELOstuKRRciPTB-BNJnMIeLrPimsGKpE0MKAWJmBEJh63I-AAAA-GScgcpBIgQhhCD-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjmYWmxMzwY2yAwAwGYjlZmZWmtZmZrBAAAYBMD2AGGMDAgZGmxYYA"
}
```
:::

:::details 来源计算器编码
```
#BB-CxGWzyIUD0566Zrz0E8STCtKiTZjiYG88+AA-BNJMneLIHGFaDlUrPMtcAWJmBEJXC1P-AAAA-GiE4IghChQxSDD-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyMzMjZMzAjxY2GbmZzoJmlZMzMMmtMAMAsB2MLzMDAAAMzsttYbmhNMAbwYYmxAwMDAzYMaA"
}
```
:::

:::details 来源计算器编码
```
#BB-CxGWzyMIUD0566Zrz0E8STCtKiTZjiOdHa5A-BNJnLMIeGFmSDlYYUaCWAETzCmkQ9jL-AAAA-LAM8AJQwIxElFG-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAmBAA2GzMzMjZmZBmZYZsZmFjmYWmxMzwY2yAwAwGYjlZmBAAAmZ22WsNzwGYGsBMMYGAzMAMjxoB"
}
```
:::

:::details 来源计算器编码
```
#BB-CxGWzyIUD0566Zrz0E8STCtKiTZjiYG88+AA-BNJMneLIHGFaDlUrPMtcAWJmBEJXC1P-AAAA-LcgAMMQwIxElFG-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

下面我们将为你推荐最佳配置，但大多数加成的强度相当，你可以根据需要进行更换。具体来说，[[spell:1279612]] 可以替换为你想要的任何其他次要加成。

- [[spell:1279599]]
- [[spell:1279603]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279614]]

1.

### 巅峰天赋： ![Beacon of the Savior Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_holyfire_buff.jpg>) 救世道标

在至暗之夜中，你将获得[[spell:1244878]]，即新的巅峰天赋。该能力有3个独立的等级，每个等级都提升其威力。下面我们将详细说明每个等级的作用：

- 等级1——在战斗中，你将获得一个名为[[spell:1244878]]的额外道标。该道标将自动放置在生命值最低的队友身上，如果它治疗的玩家生命值高于50%，或者另一名队友的生命值降到50%以下，它将转移到新的生命值最低的队友身上。
- 等级2——增加[[spell:1244878]]转移的治疗量，并增加你对拥有救世道标的目标造成的治疗量。
- 等级3——每8秒或当[[spell:1244878]]转移时，会在目标身上放置一个吸收护盾，该护盾在被击破前还提供伤害减免。

[[spell:1244878]]最重要的方面是它还受益于任何强化[[spell:53563]]的天赋。这意味着[[spell:387781]]、[[spell:157047]]、[[spell:416799]]甚至[[spell:197446]]都会增益[[spell:1244878]]。这实际上意味着你始终拥有一个额外的道标。此外，由于救世道标等级2还会增加你对救世目标造成的治疗量，直接治疗你的救世道标目标的惩罚性显著降低。在某些时候，与通常避免直接治疗的普通道标相比，它甚至可能更有益。

1.

### 英雄天赋

神圣 圣骑士 可以在两个不同的英雄天赋选择之间进行选择：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 往往是团本和大秘境中更强的选择。虽然它提供的伤害可能略低于另一种选择，但 [[spell:431425]] 使其增加了 [[spell:384376]] 的治疗输出。此外，你还可以使用 [[spell:431377]]，它有助于在你的主要冷却期间以及冷却之外增加治疗量。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 强调使用 [[spell:20271]]，这得益于 [[spell:433718]]。虽然这不是可控的治疗，但它仍然极其强大。这与 [[spell:394088]] 构建有很高的协同效应，你在使用复仇十字军时经常会利用这个英雄天赋。虽然 铸光者 目前可能较弱，但它可以为那些想要尽可能多地造成伤害的玩家提供不错的 DPS 提升。

1.

### PvP天赋（战争模式）

战争模式为你在开放世界中提供了多项好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式对升级和 PvE 内容的好处，建议启用该功能以最大化你的升级速度和满级后的奖励。然而，你将成为开放世界 PvP 的目标，并且在升级或进行世界任务时存在被"围杀"的可能性。

在本节中，我们将为升级和进行单人/小队 PvE 内容排名最佳的 PvP 天赋。以下是 神圣 圣骑士 所有 PvP 天赋的排名

1. [[spell:199454]] 为你提供一次额外的 [[spell:1044]] 和 [[spell:1022]] 充能，使其极其强大。
2. [[spell:199324]] 增加你的光环范围，同时减少 [[spell:31821]] 的冷却时间，这对于提高生存能力非常有帮助。
3. [[spell:410126]] 使用起来可能相当困难，但在时机把握得当的情况下，也能提升你自己的生存能力。

你可以认为其他选择基本上取决于个人偏好。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 铸光者大秘境天赋已更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月4日：** 史诗钥石天赋构建已更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月6日：** 推荐构建已更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 页面已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已针对第1赛季更新。
- **2024年8月30日：** 天赋配置已更新。
- **2024年8月27日：** 添加了地下堡配装。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 天赋推荐已更新。
- **2023年11月13日：** 大秘境天赋推荐已更新。
- **2023年11月6日：** 页面已更新至 10.2。
- **2023年9月4日：** 格式更新。
- **2023年8月7日：** 更新了天赋推荐。
- **2023年7月17日：** 更新了史诗+天赋推荐。
- **2023年7月10日：** 天赋推荐已针对10.1.5进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年2月22日：** 更新了大秘境天赋推荐。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何根据你的团队所承受的伤害类型来优化 神圣 圣骑士 的循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以极限优化你的治疗输出和法力效率。我们所有的内容均已针对《魔兽世界》12.1.5 补丁进行更新。

1.

### 神圣 圣骑士 玩法与循环指南

欢迎来到我们的 神圣 圣骑士循环页面。在本页面中，你将找到关于在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

下面的按钮可用于在精选的 **团本** 和
**秘境+** 配装之间进行选择。你也可以使用下面的开关来添加或移除你可能也在使用的个别天赋。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

秘境+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者

团本 - 复仇十字军

秘境+

主动天赋

被动天赋

[[spell:384376]]

[[spell:394088]]

[[spell:156910]]

[[spell:200025]]

[[spell:375576]]

[[spell:114165]]

[[spell:387170]]

[[spell:414113]]

[[spell:461529]]

### 神圣 圣骑士 详解

1.1.

#### 总体优先级

无论选择哪种构建，你的首要重点将是尽可能多地施放 [[spell:20473]]，并通过以下技能之一尽可能多地消耗 神圣 力量：[[spell:85222]]、[[spell:85673]]（或 [[spell:156322]]），或 [[spell:53600]]。当你无法执行以上任何操作时，你将在施放 [[spell:20473]] 和 [[spell:19750]] 之间轮换以进行治疗。[[spell:275773]] 将在需要伤害的大秘境场景中发挥一定作用。

神圣 圣骑士 是节奏较快的职业之一，你在循环方面所能做的最重要的事情就是确保你始终在施放某个技能。有时你需要在瞬间决定使用哪个技能最好，简单地选择一个总是比犹豫片刻、错过一次施放然后再选择要好。你应该力求尽可能快地施放尽可能多的法术。一旦你能够正确地执行快速循环，你就可以开始优化你施放的具体按钮以及施放时机。

### 团队副本

1.2.

#### 神圣 圣骑士 团本循环

在团队副本中，你需要通过以下技能最大化神圣能的获取：[[spell:20473]]、[[spell:19750]]（或[[spell:275773]]）以及[[spell:82326]]，然后将其消耗在[[spell:85222]]或[[spell:85673]]（[[spell:156322]]当 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 时使用 [[spell:82326]]）。当伤害较重时，如果你有足够的法力，也可以穿插 [[spell:82326]]。

你的总体优先级如下：

- 绝不浪费 神圣 力量——如果你已经达到 5 层或即将达到上限，请消耗它。
- **适用条件：Divine Toll（启用）；铸光者（未启用）。** 尽可能保持 [[spell:375576]] 的冷却。
- **适用条件：神圣Prism（启用）；铸光者（未启用）。** 尽可能保持 [[spell:114165]] 的冷却。
- **适用条件：铸光者（启用）。** 尽可能保持 [[spell:432472]] 的冷却。
- **适用条件：美德道标（启用）。** 在伤害到来的瞬间施放 [[spell:200025]]。力求尽可能保持其冷却。
- 用 [[spell:19750]] 消耗 [[spell:53576]]。如果不需要治疗，则用 [[spell:20271]] 消耗。
- 尽可能多地施放 [[spell:20473]]。
- **适用条件：复仇十字军（启用）。** 尽可能多地施放 [[spell:275773]]。
- **适用条件：烈日先驱（启用）；Empyrean Legacy（未启用）。** 将 神圣 力量消耗在 [[spell:156322]] 上。如果该技能会造成大量过量治疗，你应该改用 [[spell:85222]] 来消耗触发效果。
- **适用条件：铸光者（启用）；Empyrean Legacy（未启用）。** 将 神圣 力量消耗在 [[spell:85673]] 上。如果该技能会造成大量过量治疗，你应该改用 [[spell:85222]] 来消耗触发效果。
- **适用条件：Empyrean Legacy（启用）；烈日先驱（启用）。** 如果你有 [[spell:1241358]] 触发效果，用 [[spell:156322]] 消耗 神圣 力量，否则用 [[spell:85222]] 消耗 神圣 力量
- **适用条件：Empyrean Legacy（启用）；铸光者（启用）。** 如果你有 [[spell:1241358]] 触发效果，用 [[spell:85673]] 消耗 神圣 力量，否则用 [[spell:85222]] 消耗 神圣 力量
- 当你负担得起消耗且不会过量治疗时，施放[[spell:82326]]。
- **适用条件：铸光者（未启用）。** 当你无法施放以上任何技能时，施放[[spell:20271]]。
- 当不需要治疗时，你可以在[[spell:53600]]上消耗神圣力量来恢复少量法力值。

**适用条件：复仇十字军（启用）。** 当你拥有[[spell:394088]]激活时，需要注意你的输出循环会发生轻微变化。最明显的变化是[[spell:35395]]会在你的动作条上替换[[spell:394088]]，并且你会想要按它。整体输出循环大致如下：

- **适用条件：复仇十字军（启用）。** 绝不浪费 神圣 力量——如果你已经达到 5 层或即将达到上限，请消耗它。
- **适用条件：复仇十字军（启用）。** 卡冷却时间施放[[spell:275773]]。
- **适用条件：复仇十字军（启用）。** 卡冷却时间施放[[spell:35395]]。
- **适用条件：复仇十字军（启用）。** 将神圣力量消耗在[[spell:85222]]上。
- **适用条件：复仇十字军（启用）。** 当你无法施放以上任何技能时，施放[[spell:20473]]。

**适用条件：美德道标（启用）。** 神圣 圣骑士最难掌握的方面之一是利用好[[spell:82326]]。这个技能提供极其惊人的治疗量，但法力值消耗也极高。此外，你还会使用非常昂贵的[[spell:200025]]。玩好神圣 圣骑士的部分要求是从这些技能中获取尽可能多的价值，同时仍保留足够的法力值撑到战斗结束。[[spell:29166]]可以成为帮助你实现这一目标的绝佳工具，如果你的队伍中有德鲁伊，你应该总是向他们索求。除了恢复 萨满祭司之外，神圣 圣骑士是它最好的目标之一。

:::details 小贴士：优化美德道标
为了真正从中获得最大收益

[[spell:200025]]

中获得最大收益，你需要围绕它进行主动操作。

[[spell:387786]]

是需要记住的最重要的互动，它使我们的

[[spell:19750]]

当以带有此效果的玩家为目标时提供额外治疗

[[spell:200025]]

。在可能的情况下你应该尽量做到这一点。你还需要确保在美德期间主要施放“优质”法术。“优质”法术指的是任何治疗技能，最好是单体治疗技能，因为它们比群体治疗技能转移的治疗量更多。这意味着诸如

[[spell:20271]]

和

[[spell:85222]]

这样的技能在

[[spell:200025]]

激活时是糟糕的施放选择。

[[spell:20473]]

,

[[spell:19750]]

,

[[spell:156322]]

（或

[[spell:85673]]

），以及

[[spell:82326]]

这样的技能都是在美德光环激活时施放的"优质"技能。你还需要配合强大的冷却技能，比如

[[spell:375576]]

和

[[spell:31821]]

（如果点出

[[spell:1241542]]

）这样的强力冷却技能与

[[spell:200025]]

配合使用以获得更多治疗。优化

[[spell:200025]]

的最后一步是技能排队。这指的是在你刚刚施放完一个技能后立即施放另一个技能，没有任何延迟。你在完成前一个技能的同时排队下一个技能。通过在施放

[[spell:200025]]

后立即施放

[[spell:82326]]

，那次神圣光造成的所有治疗都会转移到你的美德目标身上，为你提供惊人的额外治疗潜力，同时保证你获得

[[spell:53576]]

供你在美德窗口期间使用，这得益于

[[spell:1296657]]

加成。这需要大量法力值，只建议在你能负担得起且需要大量治疗时使用。请注意这会

**不会**

生效，如果你将

[[spell:82326]]

施放在自己身上的话。它需要施放在另一个玩家身上。

:::

:::details 常见问题：为什么我的法力值消耗这么快？
[[spell:82326]]

是游戏中治疗量最高的技能之一，但法力值消耗极其沉重。作为神圣 圣骑士进行团队副本时，管理法力值同时最大化

[[spell:82326]]

的施放次数往往像是一种平衡术。请注意

[[spell:53600]]

现在也能恢复法力值。虽然你不应该频繁使用这个技能，但在不需要治疗的空闲期它可以帮助恢复一些法力值。

:::

**适用条件：烈日先驱（启用）。**

:::details 常见问题：永恒之火还是黎明之光？
[[spell:156322]]

将始终是你消耗神圣力量的最佳选择。例外情况是当

[[spell:156322]]

会过量治疗时，在这种情况下你可以改为施放

[[spell:85222]]

这样的技能。

[[spell:156322]]

的持续治疗部分并不重要，你只需对任何处于危险中的玩家施放该技能即可。

:::

**适用条件：铸光者（启用）。**

:::details 常见问题：荣耀圣令还是黎明之光？
[[spell:85673]]

将始终是你消耗神圣力量的最佳选择。例外情况是当

[[spell:85673]]

会过量治疗时，在这种情况下你可以改为施放

[[spell:85222]]

.

:::

**适用条件：铸光者（启用）。**

:::details 常见问题：我该如何使用神圣军备？
[[spell:227817]]

——应该主要施放在脆弱的玩家身上，但施放在你自己身上会导致

[[spell:432802]]

优先选择坦克。让这个技能以坦克为目标通常能产生最高的每秒治疗量，但这不一定总是最有价值的治疗。你的决定将取决于脆弱的玩家是否能利用额外的坦度度过困难时刻，否则坦克会给你最高的每秒治疗量。

[[spell:432472]]

——应该施放在你自己身上以增加你自己的治疗输出。额外的

[[spell:432472]]

会施放在另一个随机治疗者身上。

:::

### 秘境+

1.3.

#### 神圣 圣骑士的秘境输出循环

你在团队副本中使用的许多优先级在秘境中将保持不变。主要的例外是[[spell:26573]]、[[spell:275773]]和[[spell:53600]]的重要性增加，以便在不需要治疗时输出额外伤害。无论你玩的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱还是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者，输出循环都完全相同。先驱玩家需要卡冷却时间使用[[spell:375576]]，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者则会卡冷却时间使用[[spell:432472]]。

你的总体优先级如下：

- 永远不要浪费神圣力量——如果你有5层或即将达到上限，就消耗掉它。如果不需要治疗，记住你总是可以使用[[spell:53600]]。
- **适用条件：Divine Toll（启用）；铸光者（未启用）。** 尽可能保持 [[spell:375576]] 的冷却。
- **适用条件：神圣Prism（启用）；铸光者（未启用）。** 尽可能保持 [[spell:114165]] 的冷却。
- **适用条件：美德道标（启用）。** 在伤害到来的瞬间施放 [[spell:200025]]。力求尽可能保持其冷却。
- **适用条件：铸光者（启用）。** 尽可能保持 [[spell:432472]] 的冷却。
- 需要治疗时用[[spell:19750]]消耗[[spell:53576]]，否则用[[spell:20271]]来输出伤害或在不需要太多治疗时使用。
- 尽可能多地施放 [[spell:20473]]。
- **适用条件：烈日先驱（启用）。** 将神圣力量消耗在[[spell:156322]]上。
- **适用条件：铸光者（启用）。** 将神圣力量消耗在[[spell:85673]]上。
- 当需要大量治疗且你能负担得起消耗时，施放[[spell:82326]]。
- 尽可能多地施放[[spell:20271]]以最大化你的伤害。如果需要治疗，则改为专注于其他技能。
- 当你没有其他技能可用且情况不需要[[spell:82326]]时，施放[[spell:19750]]。
- 当不需要治疗时，将神圣力量消耗在[[spell:53600]]上。

需要注意的是，当治疗压力很大时，你应该从优先级中放下[[spell:20271]]，转而使用[[spell:19750]]。圣光闪现会以伤害为代价提供显著更多的治疗。玩好神圣 圣骑士的部分在于根据所处情况在这两个技能之间切换。消耗[[spell:53576]]也遵循类似的规则。为了伤害：[[spell:20271]]。需要治疗时：[[spell:19750]]。

请注意，在秘境中可能会出现你没有预料到的伤害。如果你总是尽可能地消耗神圣力量，当需要治疗时你可能没有神圣力量可用。因此，作为新手玩家，通常明智的做法是只在拥有4-5层神圣力量时才施放[[spell:53600]]；这样，当意外需要治疗时，你可以快速生成额外的神圣力量。

:::details 常见问题：我应该施放黎明之光吗？
在秘境中，你经常会发现自己主要施放

[[spell:156322]]

/

[[spell:85673]]

。这并不意味着你永远不应该按

[[spell:85222]]

。当没有人处于重大危险中且

[[spell:156322]]

/

[[spell:85673]]

大部分会过量治疗时，你可以从

[[spell:85222]]

中获得很大价值，它能治疗你的整个小队。把它想象成一种让每个人都恢复一点血量的方式，这样下次你需要进行大量单体治疗时他们会稍微健康一些。

:::

:::details 常见问题：我应该何时使用神圣光？
有效利用

[[spell:82326]]

可能很困难，因为它的法力值消耗很重。虽然它提供了大量在秘境中极其有价值的治疗，但过度使用这个技能会让你很快耗尽法力值。话虽如此，你总可以在首领和小怪群之间喝水，这给了你大胆使用神圣光的空间。与其思考应该施放多少次神圣光，不如从这个角度思考：我需要多少法力值才能度过这个小怪群？此外，如果我不施放神圣光，我能否应对这个时刻的治疗？如果你有法力值且情况需要，不要犹豫使用神圣光。即使你没有法力值，有时它也是保住某人生命的最佳选择。你使用得越多，就越能掌握何时可以使用；完全不施放它的话，你很可能会陷入困境。

:::

1.

### 至暗之夜 第2赛季套装

至暗之夜第2赛季的套装对于神圣圣骑士来说相当直接。它将提供以下加成：

- [[spell:1296656]] — 增加 [[spell:19750]] 的治疗量和 [[spell:231663]] 的吸收量。
- [[spell:1296657]]——[[spell:20271]]现在有20%的几率获得[[spell:53576]]，而[[spell:82326]]现在总是获得它。神圣圣光的法力消耗也增加了。

1.

### 职业与专精机制详解

在本节中，将深入解释重要的机制、互动和游戏元素，以帮助你更好地理解如何在高水平上玩这个职业。

### 圣光灌注

3.1.

#### 圣光灌注

[[spell:53576]]是神圣 圣骑士的核心被动。每当你施放[[spell:20473]]时，这个效果有10%的几率被触发。你可以利用这个增益的两种不同方式：

- **[[spell:19750]]**
  
  
  
  
  与[[spell:53576]]一起施放时，这个技能变为瞬发，治疗量大幅提升。
- **[[spell:20271]]**
  
  
  
  
  与[[spell:53576]]一起施放时，[[spell:231663]]效果大幅提升，并生成1点额外的神圣力量。

消耗[[spell:53576]]的最佳选择在很大程度上取决于你所处的情况。在秘境中且完全不需要伤害时，施放[[spell:20271]]可能更优，因为它提供更多神圣力量。然而， **任何时候** 需要治疗时，你绝对应该施放[[spell:19750]]。圣光闪现提供显著更多的治疗，利用不足可能导致你在秘境中治疗落后，或在团队副本中难以跟上你的共同治疗者。

### 救世道标

3.2.

#### 救世道标

[[spell:1244878]]是在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)中加入的新巅峰天赋。这将给你一个新的道标，它会自动放置在生命值最低的盟友身上。一旦目标的生命值被治疗到超过其最大生命值，或另一个目标的生命值降到50%以下，道标就会移动。关于这个道标需要记住几个互动：

- 这个技能受益于你的常规[[spell:53563]]所受益的所有天赋。这包括[[spell:387781]]、[[spell:157047]]以及任何其他与道标相关的天赋。
- 虽然你仍然会像任何其他道标一样将治疗转移给[[spell:1244878]]，但你还会对拥有你救世道标的目标造成额外治疗。
- 每8秒，或当[[spell:1244878]]被施放到新目标身上时，会在目标身上放置一个小护盾，并且他们在接下来的15秒内受到的伤害降低。

尽管[[spell:1244878]]的目标会获得更多治疗，但你不会想要持续直接治疗他们。你应该在他们处于危险时治疗他们，就像对待任何其他团队/小队成员一样。治疗增益之所以存在，首先是为了让你对道标目标施放法术时不会那么损失治疗效率。由于拥有你[[spell:1244878]]的目标很可能是生命值最低的成员，你不想因为不直接治疗他们而错过潜在的治疗量。治疗增益抵消了这一点，这意味着你只需专注于治疗最危险的玩家即可。

### 精通

3.3.

#### 精通

[[spell:183997]]是神圣 圣骑士的精通。这会根据你与目标的距离增加你法术的治疗量。[[spell:197446]]通过将你的道标加入计算来进一步增加这个效果。治疗增益将根据你和拥有你道标的玩家之间谁更近来计算。过去，常见的做法是将[[spell:53563]]和[[spell:156910]]施放在坦克玩家身上，因为他们总是会受到伤害。这不再成立，你应该将道标放置在生存能力较低的远程玩家身上。这将使你从道标中获得良好价值，同时为你提供更高的精通数值，因为他们会更靠近远程而你会更靠近近战。下面我们列出一些适合作为你的[[spell:53563]]和[[spell:156910]]目标的不错选择。当然，如果你玩的是[[spell:200025]]，这就不相关了。

- 平衡 德鲁伊
- 暗影 牧师
- 湮灭 唤魔师
- 任何猎人专精
- 如果你没有以上任何职业，就把它放在任何剩余的远程身上。
- 在没有远程的小规模队伍中，你通常可以选择坦克和持续承受最多伤害的近战输出。

1.

### 神圣 圣骑士的重要冷却技能

### [[spell:384376]]

4.1.

#### 复仇之怒

[[spell:384376]]是我们的主要冷却技能。这个技能默认有2分钟冷却时间，增加你的伤害、治疗和暴击。你应该尽可能频繁地使用这个冷却技能，理想情况下与更长的伤害窗口对齐，因为它默认持续30秒。激活时，你应该遵循你的标准输出循环，只是你会做更多治疗！

### [[spell:31821]]

4.2.

#### 光环掌握

[[spell:31821]]只能在[[spell:465]]上使用，这意味着在使用之前你应该从光环栏中选择虔诚光环（你应该始终默认开启它）。按下时，你将为所有盟友提供12%的伤害减免。在团队副本中，这个冷却技能很可能会被负责安排治疗冷却的团队成员分配给高伤害机制。当你独自一人时，你应该在你的小队可能处于危险时优先使用这个技能，理想情况下是在大量伤害发生之前。

### [[spell:394088]]

4.3.

#### 复仇十字军

[[spell:394088]]替换[[spell:384376]]，提供不同的加成，并且冷却时间短得多。施放时，这个技能在持续时间内会变为[[spell:35395]]。激活期间，你的[[spell:20271]]和[[spell:35395]]技能在造成伤害时会治疗附近的盟友。这意味着你的输出循环会发生轻微变化，你希望在冷却激活期间尽可能多地按[[spell:20271]]和[[spell:35395]]，同时仍然优先在接近上限时消耗神圣力量。

### [[spell:375576]]/[[spell:114165]]

4.4.

#### 圣光道标/神圣棱镜

[[spell:375576]]和[[spell:114165]]在至暗之夜中共享一个选择节点。当玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者时，这些会被[[spell:432472]]替换。无论你选择哪个技能，这些都是短冷却技能，你应该频繁使用。当玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱时，按下这些技能是你获得[[spell:431377]]的途径，使它们极其重要。

[[spell:375576]]按下时会施放5个[[spell:20473]]。这个冷却技能的重要部分在于你使用它时的目标。如果你以敌人为目标，它将优先对敌人施放5个神圣震击。如果没有足够的敌人，它将对盟友施放剩余数量的神圣震击。这意味着当你的目标是进行治疗时，你需要确保你将技能施放在盟友身上，否则你会浪费大量治疗。如前所述，当你玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱时，你的目标应该是尽可能多地施放这个技能以触发[[spell:431377]]。

[[spell:114165]] 的运作方式与神圣共鸣非常相似，根据你对盟友还是敌人施放而有不同效果。对盟友施放时，它会为你周围敌人造成大量单体治疗和范围伤害。对敌人施放时，它会对敌人造成大量单体伤害，并对附近盟友进行范围治疗。通常你会优先对敌人施放此技能，以触发范围治疗效果。此外，在游玩时你应尽可能频繁地施放此技能 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱时，你的目标应该是尽可能多地施放这个技能以触发[[spell:431377]]。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月31日：** 循环页面已全面改版并更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 页面已针对11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月24日：** 复仇十字军循环已更新。
- **2024年10月21日：** 页面已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁更新循环。
- **2023年11月6日：** 页面已更新至 10.2。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月7日：** 更新了循环并添加了更多关于圣光道标目标选择的信息。
- **2023年7月10日：** 为10.1.5版本更新了循环。
- **2023年5月27日：** 复仇十字军循环已更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面中，你将找到《魔兽世界》12.1.5版本中你的神圣圣骑士的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用纹章升级装备的建议，我们都为你准备好了！

1.

### 神圣圣骑士毕业装备指南

欢迎来到我们的神圣圣骑士装备与毕业装备页面，
[至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)。查看此页面，了解关于为神圣圣骑士配装所需的一切信息，包括来自所有来源的毕业装备、团队副本和大秘境、关于最佳饰品、套装等信息。请注意，随着至暗之夜的到来，属性进行了压缩，意味着每件物品提供的属性将比过去显著减少。你的总体伤害和治疗量也会因此降低。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含神圣圣骑士来自所有来源的最高治疗量配装。请注意，还有许多其他配装的表现处于误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [QuestionablyEpic](<https://questionablyepic.com/>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你可以将任何物品转化为套装件，并且它会保留原有的属性和效果！这意味着你的散件不再那么重要。

[[item:268222]]

和

[[item:271878]]

由于其更高的物品等级，将始终被优先选择，但你剩余的2个套装槽位可以根据你拥有的装备进行更换。

- **头部：** [[item:281239]]的持续治疗部分来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **肩部：** [[item:251138]]来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **胸部：** [[item:268222]]来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **手部：** [[item:271466]]来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **腿部：** [[item:271878]]来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 常见问题：从宏伟宝库中获取什么？
由于 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可以从宏伟宝库中获取而非物品，你将优先在第一次开库时获取这些额外奖励次数。这将允许你对任何副本或首领进行额外奖励抽取，并获得该物品的1/6史诗难度版本。因为 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 从英雄难度掉落史诗难度版本的[[item:271878]]，你将优先使用额外奖励次数在有机会在史诗难度击杀该首领之前就获得这件毕业物品。通过额外奖励抽取该首领，你还可以获得[[item:268265]]。请注意，从史诗难度掉落的物品将是9/6史诗难度，而额外奖励抽取的物品最高为6/6。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护腕</th><td>[[item:268239@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268262@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含神圣圣骑士来自所有来源的最高治疗量配装。请注意，还有许多其他配装的表现处于误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [QuestionablyEpic](<https://questionablyepic.com/>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你可以将任何物品转化为套装件，并且它会保留原有的属性和效果！这意味着你的散件不再那么重要。

[[item:268222]]

和

[[item:271878]]

来自新团队副本的物品由于其更高的物品等级和独特效果而非常令人向往。如果你无法获得这些物品，你将需要优先考虑从以下列表中选择4件的组合。

**裤子**

是你最不理想的槽位。

- **头部：** [[item:251126]]来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **肩部：** [[item:251138]]来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **胸部：** [[item:193753@JAAIAAQkCYHKvbRLfA]]来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- **手部：** [[item:251197]]来自 [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- **腿部：** [[item:273776]] 来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落一个盾牌：[[item:251196]]和一个最佳副本饰品之一：[[item:250214@JAACAAgNyA]]。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：掉落最佳饰品之一：[[item:250215@JAACAAgNyA]]，以及护腕和项链。
- [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：掉落多个不错的物品，但没有特别突出的。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:159418@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>脚部</th><td>[[item:159412@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>护腕</th><td>[[item:251133@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:160216@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:251150@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含神圣圣骑士来自所有来源的最高治疗量配装。请注意，还有许多其他配装的表现处于误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [QuestionablyEpic](<https://questionablyepic.com/>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你可以将任何物品转化为套装件，并且它会保留原有的属性和效果！这意味着你的散件不再那么重要。

[[item:268222]]

和

[[item:271878]]

由于其更高的物品等级，将始终被优先选择，但你剩余的2个套装槽位可以根据你拥有的装备进行更换。

- **头部：** [[item:281239]]的持续治疗部分来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **肩部：** [[item:271463]] 来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **胸部：** [[item:268222]]来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **手部：** [[item:271466]]来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **腿部：** [[item:271878]]来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271878]]：可转化的腿部物品，你将对其进行催化。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:268265]]：另一件可转化物品，掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270162]]：极其强大的饰品，掉落自 [盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>).
- [[item:270164]]：第二好的饰品。掉落自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271465@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271466@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271463@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271464@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268260@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271468@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护腕</th><td>[[item:268239@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/holy-paladin-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268262@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 神圣圣骑士饰品推荐

一如既往，你应该咨询 [QELive](<https://questionablyepic.com/live/>) 来确定你的最佳饰品，因为列表经常随着调整而变化。然而，本赛季你将希望使用[[item:270162@JAACAAgNyA]]和[[item:270164@JAACAAgNyA]]。两件来自新团队副本的极其强大的饰品。大秘境饰品相比之下不幸地有些被低估，但你确实有一些不错的选择可以在努力获取团队副本毕业饰品期间使用。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **神圣圣骑士毕业饰品**
**毕业装备 -**

[[item:270162]]

和

[[item:270164]]

.

**荣誉提名 -**

[[item:250214]]

.

:::

要直接比较饰品，请使用
[QELive](<https://questionablyepic.com/live/>)。我们将在此列出一些特殊饰品及其强度水平的评论。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 神圣圣骑士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:281215]]（仅限史诗钥石地下城）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:249343]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250254]]</li>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:250255]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270171]]</li>&#10;<li>[[item:264507]]</li>&#10;<li>[[item:264701]]</li>&#10;<li>[[item:250254]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

一般来说，有相当多的饰品处于相似的强度水平。同一层级中的任何饰品彼此大致相等。这意味着饰品的物品等级相当重要。F级饰品之所以在那里，是因为它们只比空的饰品槽位好一点。

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可用于从特定首领或副本获取特定物品，通过让你从特定掉落位置获得一件保证的战利品。获得的物品是随机的，但一旦通过这种方式获得了一件物品，你下一次使用虚空核心将获得你尚未获得的剩余物品之一。

随着12.1.5补丁的发布，你可以从
**奥琳·微光** 在银月城，紧邻转化器。

**请注意，通过掉落或宏伟宝库获得物品不会将其从你的额外奖励次数池中移除。**

3.1.

#### 神圣圣骑士推荐的虚空核心使用方式

对于你的虚空核心和制造，你可以采取几种不同的路线。这些主要是赛季初期的问题，如果你在赛季后期才选择这个专精，那么你在两者的选择上都会有更大的自由度。 **在赛季初期对大秘境使用额外奖励次数是一个巨大的战力损失。**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **团队副本虚空核心优先级**
- 英雄难度（或史诗难度） [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 直到你获得[[item:271878]]和[[item:268265]]。
- 史诗难度 [盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 直到你获得[[item:270162]]。
- 然后：填补你还没有史诗难度物品的槽位。你可以使用QE Live来获得每个首领和副本的平均额外奖励次数价值。通常 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>) 可能是一个不错的选择。

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **大秘境/英雄难度团队副本虚空核心优先级**
- [夺目谷](<https://www.wowhead.com/achievement=61641>) - [[item:250214]]（不错）
- [密谋小径](<https://www.wowhead.com/achievement=41960>) - [[item:251126]]和[[item:251138]]（毕业）

:::

如果你是一个全新角色，你仍然希望优先使用额外奖励次数
[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 以获取关键物品。从那里开始，通常使用额外奖励次数抽取 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) 会更有价值，因为掉落的物品数量众多，以及你可以立即进行催化的两个毕业套装槽位。虽然这可能意味着你无法立即获得最强大的饰品，但这可能是快速为角色配装的最佳方式。否则，你可以改为抽取英雄难度/史诗难度
[盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 或 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

3.2.

#### 晋升毒液石

使用[[item:280562]]的优先级将始终是你的 **武器。**
这为你提供最大的战力提升。从那里你可以专注于饰品，然后是你的副手。顺序与你在赛季初花费纹章的方式非常相似：

1. 武器
2. 饰品
3. 副手

你应该始终优先选择史诗难度物品，除非在你短期内无法获得史诗难度版本的情况下。

1.

### 神圣圣骑士最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

由于你在至暗之夜初期阶段制造物品的能力受到时间限制，你有两个选择。制造一个早期 **主手武器** 或直接使用[[item:240167]]制造物品。以更快方式推进团队副本的玩家可能希望避免制造武器，因为他们会在史诗难度推进的早期就获得武器掉落。不期望在赛季早期进入并通关史诗难度的玩家将从制造早期武器所带来的战力中受益，并应尽快这样做。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **神圣圣骑士制造装备优先级**
- 使用[[item:237843]]，搭配[[item:245876]]和急速/精通
- 使用[[item:237831]]，搭配[[item:240167]]和急速/精通
- 任何你尚未获得神话级的物品。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 神圣圣骑士最佳纹饰推荐

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

我们倾向于建议早期制造武器槽位，因为它们在新赛季开始时会提供最大的初始战力，但它们不会是你整体的毕业物品。一般来说，你的毕业装备将是：

- [[item:237834]]，搭配[[item:240167]]和急速/精通
- [[item:237828]]，搭配[[item:240167]]和急速/精通

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中不选择任何选项就可以获得它。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你在第2赛季获得了它们。你通常在赛季后期之前不会拥有任何这些，因为选择物品或 [混沌虚空核心](<https://www.wowhead.com/currency=3418>).

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

优先级将根据你是否制造武器而发生很大变化。如果你不制造武器而是获得一个早期的史诗难度武器，你应该优先升级 **武器** 优先。否则你可以按照以下顺序进行：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **神圣 圣骑士纹章升级优先级**
**武器栏位**

➜

**特效栏位**

➜

**头盔/胸甲/腿甲**

➜

**饰品**

➜

**肩部/手套/腰带/靴子**

➜

**其余部位**

:::

如前所述，你应该优先升级你确定不会替换的装备。如果你有一件神话级轨的毕业头盔，它会优先于一件非毕业的英雄级轨饰品。上述顺序假设所有装备都是神话级轨。

1.

### 评估升级

在本页面和我们指南的其他地方，我们经常提到在 QE Live 上进行自我模拟的重要性。这是因为每个角色都是独一无二的，你能获得的每件装备都可能改变你现在最适合的装备搭配。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年10月1日：** 头部和脚部毕业装备推荐已更新。
- **2026年8月25日：** 为额外拾取策略添加了额外信息。
- **2026年8月17日：** 对饰品梯队进行了小幅更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 饰品天梯榜已更新。
- **2026年3月23日：** 饰品天梯榜已更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月14日：** 更新了饰品推荐。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月13日：** 更新了谜题卡特尔芯片的推荐。
- **2025年4月21日：** 页面已为11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 添加了Cyrces Circlet的信息。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月16日：** 更新了装饰信息。
- **2024年9月9日：** 添加了第1赛季毕业装备。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月29日：** 更新了BiS列表和美化推荐。
- **2023年11月7日：** 根据孢子披风的削弱更新了装饰和毕业列表。
- **2023年11月6日：** 页面已更新至 10.2。
- **2023年9月4日：** 添加了毕业装备。
- **2023年7月19日：** 饰品天梯榜已更新。
- **2023年7月17日：** 饰品天梯榜已更新。
- **2023年7月10日：** 针对10.1.5补丁更新了装备推荐。
- **2023年5月26日：** 添加了关于时光漫游饰品的信息。
- **2023年5月20日：** 根据漏洞修复更改了美化装备建议。
- **2023年5月16日：** 装饰更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月28日：** 更新了原初宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月13日：** 添加了巧思火花制作建议。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将了解到你的 神圣 圣骑士 的最佳属性优先级。我们首先介绍属性优先级，然后深入解释这些属性如何与你的专精和玩法相互作用。我们的内容已针对《魔兽世界》12.1.5 补丁进行更新。

1.

### 圣骑士 神圣 属性优先级

神圣 圣骑士 的属性优先级会根据你的法术选择或战斗时长、你与治疗目标的距离以及你的天赋而有所不同。我们将给出通用的属性优先级，然后解释这些因素如何为你改变它。话虽如此，我们的次要属性价值非常接近，而且智力在当前装备水平下非常强大，所以装等提升通常都值得换上。你应该利用本页面的信息来帮助你判断两件装等相似的装备哪一件更优。

如果你有兴趣通过优化属性来获得尽可能高的每秒治疗量；你可以访问 [QuestionablyEpic](<https://questionablyepic.com/>)，一个专注于治疗者理论计算的网站。该网站会根据你的装备和战斗日志来比较你的属性，告诉你背包中应该装备哪些物品才能让你的角色尽可能强大。否则，我们将简要介绍根据你的天赋构建你需要优先考虑的属性。

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 属性优先级

装备等级

精通

急速

暴击

全能

此属性优先级侧重于最大化 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 的输出。由于精通从次要属性中为我们提供最大的每秒治疗量提升，它将是我们优先考虑的属性。暴击由于对烈日先驱的影响不如其他构建那么大，其价值会下降。

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 属性优先级

装备等级

精通

暴击

急速

全能

当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 时，暴击的价值将因 [[spell:433718]] 而显著增加。这使得 [[spell:275773]] 的暴击会对附近的盟友产生治疗效果。你的大部分玩法都围绕着最大化你的审判施放次数，我们还希望通过增加暴击来提升它造成的治疗量。

话虽如此，精通仍然是我们最强的属性，它将是我们总体上优先考虑的属性。

1.3.

#### 大秘境属性优先级

装备等级

精通

急速

暴击

全能

当游玩大秘境时，在分配次要属性方面你可能面临最有趣的选择。精通将继续为你提供最大的每秒治疗量提升，但它不像其他属性那样能提升你的伤害。

我们建议坚持使用 **精通** ，直到你对新副本更加熟悉、提升你的整体装备，并且觉得不需要更多治疗为止。此时你可以考虑将精通放在属性优先级的末位，转而选择提升伤害的属性，如急速和暴击。

1.

### 深入属性解析

如果你的目标是真正优化你的装备和表现，了解每个属性的影响至关重要。下面我们将分解每个属性的影响。

- **精通** — 根据你与目标的距离增加你的治疗量。你离玩家越近，你造成的治疗就越多。需要注意的是 [[spell:197446]] 稍微改变了这一点。有了这个天赋，治疗加成还会考虑你的道标目标与玩家之间的距离。如果他们离玩家更近，治疗量会根据那个距离而不是你自己的距离来增加。这是你被激励将道标分散给不常靠近你的远程玩家的主要原因之一。他们可以在房间中为你提供额外的覆盖范围，提高你的精通效果。
- **急速** — 游戏中的许多法术“随急速缩放”。这意味着随着你获得更多的急速，它们的冷却时间会减少。对于 神圣 圣骑士 来说，这最显著地适用于 [[spell:20473]] 和 [[spell:275773]]。你的急速越高，这些技能的冷却时间就越短。此外，急速还会减少 [[spell:19750]] 和 [[spell:82326]] 等有施法时间法术的施法时间。
- **暴击** — 使你的法术和攻击有更高几率造成额外治疗或伤害。此外，部分技能只有在暴击时才会触发，例如 [[spell:433718]]，用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 的 [[spell:385515]]。虽然这个技能更多的触发对使用 铸光者 的玩家来说可能是巨大的提升，但暴击存在一个问题，即你通过各种天赋获得了如此多的暴击，以至于在装备上堆叠它会失去效果。[[spell:385515]]、[[spell:387805]] 和 [[spell:384376]] 都以某种方式修改你的暴击几率，导致你通常拥有超过所需的暴击，从而降低了以暴击为目标选择装备的整体意愿。
- **全能** — 到目前为止最不有趣的属性，它少量增加治疗和伤害输出并减少受到的伤害。不幸的是，这个属性无法与替代选项相比。在非常高的大秘境中，你可能会看到玩家堆叠更多的全能来承受原本会秒杀他们的极高伤害，但大多数玩家不会遇到这种情况。除了这种情况外，你通常会避免以全能为目标选择装备。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 页面已针对11.0.5补丁进行更新。
- **2024年9月28日：** 属性优先级略有变动。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的 神圣 圣骑士 可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

重要的是，在一个插槽中你始终使用 [[item:240968]] 或 [[item:240983]]。地脉会以牺牲一些主属性为代价提供更多法力。总体来说差异非常小，你通常可以使用你觉得舒服的，或者简单地镶嵌更便宜的选项。

在大秘境中，你对法力的重视程度可能较低，因为你可以在拉怪之间喝水，而在团队副本中，当你在战斗中吃力时，额外的法力可能很有价值。为了节省金币，你可能想先从最大法力宝石开始，直到你注意到自己在战斗中从不耗尽法力，那时你可以换用以获得一点点额外的治疗量。

当使用 [[item:240968]] 时，你希望装备中有尽可能多的不同颜色宝石。这意味着你应该使用以下每种各一个：

- [[item:240900]]
- [[item:240908]]
- [[item:240892]]
- [[item:240917]]

在剩余的宝石插槽中，或者当使用 [[item:240983]] 时，你将想要使用 [[item:240900]]。话虽如此，你应该继续咨询
[QuestionablyEpic](<https://questionablyepic.com/>) 以真正优化你的宝石。

1.

### 最佳附魔和武器强化

神圣 圣骑士 的最佳武器油将是 [[item:243733]]。它提供的次要属性加成在各种内容中都是很好的增益，而替代品 [[item:243735]] 不够强大，永远不值得使用。当游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 时，你将不需要武器油，因为 [[spell:433568]] 将取而代之。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244003]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243959]]</li>&#10;<li>[[item:244015]]（伤害）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

合剂、食物、药水甚至油类等消耗品可以显著提升你的实力，值得在进行任何有挑战性的内容时使用。如果金币不是问题，你可以选择始终使用它们！

3.1.

#### 合剂

[[item:241322]] 将是你最大化治疗输出的首选。在大秘境等你不需要额外治疗的情况下，你可以选择使用 [[item:241325]] 或 [[item:241326]]。

3.2.

#### 药水

在 至暗之夜 中有两种药水值得考虑：[[item:241288]] 和 [[item:241301]]。需要注意的是，这些药水共享冷却时间。使用其中一种会使其他所有药水进入冷却。在任何涉及法力的情况下，你应该只使用 [[item:241301]]。当你不需要法力时，你可以改用 [[item:241288]] 配合你的主要冷却技能。

确保随时在身上备有 [[item:271883]]。这些药水与战斗/法力药水不共享冷却时间，这意味着当你需要为自己进行紧急治疗时，可以随时使用它们。

3.3.

#### 食物增益

你应该吃 [[spell:1278895]] 作为理想的团队盛宴，或者 [[item:242747]] 作为你自己的个人食物。这些为你提供主属性加成，胜过任何其他食物选择。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月20日：** 更新了武器附魔推荐。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 页面已为11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日：** 消耗品推荐已更新。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月29日：** 对宝石建议进行了小幅更新。
- **2023年11月21日：** 更新了武器附魔推荐。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月7日：** 更新了附魔推荐。
- **2023年7月10日：** 已针对10.1.5补丁更新建议。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月28日：** 更新了原初宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5 补丁中使用你的 神圣 圣骑士 应对大秘境副本的技巧和建议。

1.

### 神圣 圣骑士 在 至暗之夜 第2赛季的大秘境

[神圣 圣骑士](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-guide>) 是大秘境中较好的治疗专精之一。它在副本中几乎任何治疗情况下都有出色的治疗输出，拥有许多防御工具、多个应对紧急情况的冷却技能，以及作为治疗者不错的伤害输出。 [神圣 圣骑士](<https://www.icy-veins.com/wow/holy-paladin-pve-healing-guide>) 在大秘境中的弱点包括机动性低、缺乏标准打断技能，以及控制选项有限。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

虽然 神圣 圣骑士 通过 [[spell:20473]] 和 [[spell:85673]] 拥有许多强大的单体治疗，但该职业在面对造成极高伤害的全团AOE伤害时可能会很吃力。大多数玩家最终会不充分使用冷却技能，这会让AOE伤害感觉更难应对。记住 [[spell:375576]] 的冷却时间很短，你应该尽量频繁使用它。

:::details 技巧避免这个常见错误！
玩家常犯的一个常见错误是过度使用 [[spell:53600]]，这会使治疗队伍变得更加困难。当你不确定你的队伍将承受多少伤害时，你应该尽量保持高神圣能量，这样当意外伤害发生时，你已经积攒了 神圣 能量准备快速治疗。这并不意味着你永远不能用 [[spell:53600]] 造成伤害，但你不应该在获得那点 神圣 能量的瞬间就花费 3 点 神圣 能量。尽量存到 4 或 5 点，然后花费 神圣 能量，再重新积攒。

:::

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 大秘境天赋构建

2.1.

#### 默认 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 大秘境天赋构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 为你提供 [[spell:156322]]、[[spell:431377]] 和 [[spell:431425]]，但天赋树的大部分价值来自被动效果。通过 [[spell:431404]] 获得额外 5% 急速，以及通过 [[spell:431413]] 和 [[spell:200482]] 获得额外的 [[spell:20473]] 治疗，使这成为大秘境中强大的天赋树。它提供的伤害可能少于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者，但它通过被动效果和新技能提供了显著更多的治疗。

选择 [[spell:200025]] 是因为它与被增强的天赋如 [[spell:1232616]]、[[spell:157047]] 和 [[spell:414139]] 有协同作用。对于讨厌美德的玩家来说 [[spell:156910]] 仍然是一个不错的选择，但你会损失一点治疗输出。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAgZBAMAAw2YmZmZMzMLwMDLjNzsY0EzyMmZGGzWGAGA2AbsMzMzysNzMbNAAAALgZwGMGGMDAgZGmxYYA"
}
```
:::

:::details 来源计算器编码
```
#BB-DGWzURilZmmCo9pz1lz2mELwfAKiTZ98iiOB-BNJMnLIePWdMtGKP0oMKIU:yAikLwKR-AAAA-GiE4IghChQxSDD-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 大秘境天赋构建

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 大秘境天赋构建

此构建与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 烈日先驱 的区别在于你失去了 [[spell:375576]] 的使用权。这可能使你很难跟上团队范围的伤害，并导致该构建不被推荐用于大秘境。话虽如此，该构建确实提供了一点额外伤害，这也是为什么它有时会出现在最高等级的秘钥中。在这些更高等级的秘钥中，治疗者需要贡献更多伤害才能成功限时，这使得伤害提升对他们非常有价值。然而，不选择 [[spell:375576]] 所损失的治疗量 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/herald-of-the-sun.webp>) 通常使 烈日先驱 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/lightsmith.webp>) 铸光者 会差得多，除非你只专注于自己的伤害输出。

选择 [[spell:200025]] 是因为它与被增强的天赋如 [[spell:1232616]]、[[spell:157047]] 和 [[spell:414139]] 有协同作用。对于讨厌美德的玩家来说 [[spell:156910]] 仍然是一个不错的选择，但你会损失一点治疗输出。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CEEAAAAAAAAAAAAAAAAAAAAAAAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsYmBAAAmZWWWsMzwGbjZwGwMGAgZGAmxY0A"
}
```
:::

:::details 来源计算器编码
```
#BB-CDGIMUtilnD08ANNddpdbH4FnPVWloIPPxp-BJLMNnIemoPU48AKayqkKz2G3PQpAEHB-AAAA-BGUwwBiyCTgAhE-
```

:::

1.

### 功能技能与能力

### 眩晕和打断

3.1.

#### 眩晕与"打断"

[[spell:853]] 是你的主要“打断”。这会使你的目标眩晕一小段时间，阻止他们施放任何技能。

[[spell:20066]] 是一个控制技能，但只对特定类型的敌人有效。使用它不会让你进入战斗状态。

[[spell:115750]] 是一个范围效果，使 10 码内的敌人迷惑。当目标受到非 神圣 伤害时效果会中断。它也可以用来打断一个或多个敌人的施法，被认为是你的主要“AOE打断”。再次提醒，在副本环境中敌人会在之后立即开始施法/攻击，所以你只能阻止一波打断/施法。

### 其他功能

3.2.

#### 其他功能

- [[spell:1022]] 将移除流血和其他物理持续伤害效果，例如 [重伤](<https://www.wowhead.com/mythic-affix=12>)，同时为目标阻止所有物理伤害 10 秒。它通常用于可能从你的坦克手中抢到仇恨的近战DPS玩家。
- [[spell:1044]] 将移除或阻止移动受损效果的施加，包括许多无法用 [[spell:4987]] 驱散的效果。
- [[spell:465]] 是一个非常强大的防御技能，对你自己和你的团队都有效。配合 [[spell:31821]] 使用它可以防止大量伤害，并在队友受到巨大伤害峰值时拯救他们，尤其是那些缺乏防御技能的队友。尽可能站在坦克的范围内以获得最大收益。

1.

### 应对词缀

至暗之夜 第2赛季只有四个重要的 词缀 提供任何反制手段，称为萨拉塔斯的交易。这些每周轮换，一次只有一个生效。许多大秘境词缀，如强韧或残暴，只是给钥石添加一个被动效果，只有这四个例外是本赛季以萨拉塔斯为主题的：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将出现三波需要打断或干扰的宝珠。[[spell:115750]] 在这些情况下非常有用，但你通常只能每隔一波使用一次。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个 虚空大使 增援将会刷新，需要被设为焦点目标并打断。治疗者通常无法在此词缀上提供帮助，除了对其造成少量额外伤害。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：光球会在玩家周围刷新并绕着他们转。你有 15 秒的时间来吸收所有这些光球以增益你的队伍。虽然并非必须，但治疗者通常非常擅长四处跑动并吸收未被吸收的光球，这样输出职业就可以站着不动保持输出。当然，你不会想在治疗压力大的时候这样做。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有队伍成员都会受到一个治疗吸收效果。该效果可以被驱散，你需要确保尽快驱散那些无法自行清除该效果的玩家，以便驱散两次。这样你只需要处理少数几个玩家的减益效果。通常被动治疗就足以打破这个吸收效果，但你应始终优先治疗带有该减益的玩家。[[spell:1044]] 也可以用来移除玩家身上的该效果，配合你的常规驱散，你可能完全不需要治疗任何人。

如果这些词缀没有被处理，它们会增强敌方小怪和首领。然而，当你能够处理它们时，它们会为你的整个团队提供有益的增益，提高你的输出或生存能力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月4日：** 史诗钥石天赋构建已更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 页面已为11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 页面已针对11.0.5补丁进行更新。
- **2024年9月28日：** 添加了地下城提示。
- **2024年9月9日：** 已添加第1赛季信息。
- **2024年8月30日：** 天赋构筑已更新。
- **2024年8月17日：** 为《地心之战》进行了审查和更新。
- **2024年7月20日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 天赋推荐已更新。
- **2023年11月13日：** 天赋推荐已更新。
- **2023年11月6日：** 页面已更新至 10.2。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月7日：** 更新了天赋推荐。
- **2023年7月17日：** 天赋推荐已更新。
- **2023年7月10日：** 针对10.1.5补丁更新了天赋。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年2月22日：** 天赋推荐已更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5 补丁中游玩你的 神圣 圣骑士 时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件和宏页面。在这里我们将介绍你可以使用的有用插件，通过更具信息量的UI来提升你的游戏体验，同时提供一些常用的 神圣 圣骑士 宏。

1.1.

#### 神圣 圣骑士 专属宏

当游玩治疗者时，建议你使用鼠标悬停宏，这可以让你无需专门选中目标就能治疗玩家。这意味着你只需将鼠标定位在玩家的单位框架上并施放你想要的法术。鼠标悬停宏的示例如下：

#### 基础鼠标悬停示例

```wow-macro
#showtooltip 神圣震击
/use [@mouseover,help,nodead][help,nodead][@player] 神圣震击
```

此外，你可以利用游戏内设置，而无需为每个技能单独创建宏。你可以通过在界面设置中启用“鼠标指向施法”来实现这一点。启用鼠标指向后，你还需要禁用“自动自我施法”设置；否则每个法术都会施放在你自己身上。

1.2.

#### 圣骑士通用宏

对于你可以用于许多不同技能的核心圣骑士技能，也推荐使用鼠标指向宏。如果你决定不启用前面提到的鼠标指向设置，以下是我们建议你在游戏中使用的几个宏：

#### 圣疗术宏

```wow-macro
#showtooltip 圣疗术
/stopcasting
/cast [@mouseover, help, nodead] 圣疗术
```

#### 战斗复活宏

```wow-macro
#showtooltip 代祷
/stopcasting
/cast [@mouseover, dead, exists] 代祷
```

此宏将对你当前鼠标所指向的目标施放[[spell:391054]]。

#### 圣盾术宏

```wow-macro
#showtooltip 圣盾术
/stopcasting
/cast 圣盾术
```

此宏将停止你当前的法术施放并施放[[spell:642]]。这可以防止你因为正在施法而无法立即获得免疫的情况。

#### 鼠标指向保护祝福

```wow-macro
#showtooltip 保护祝福
/stopcasting
/cast [@mouseover, help, nodead] 保护祝福
```

#### 鼠标指向自由祝福

```wow-macro
#showtooltip 自由祝福
/stopcasting
/cast [@mouseover, help, nodead] 自由祝福
```

#### 鼠标悬停 牺牲祝福

```wow-macro
#showtooltip 牺牲祝福
/stopcasting
/cast [@mouseover, help, nodead] 牺牲祝福
```

1.

### 最佳插件

2.1.

#### Harreks高级团队框架

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，许多插件、WeakAuras以及整体功能已被移除。 [Harreks高级团队框架](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>) 为你恢复了部分团队框架的功能，允许你完全自定义在团队框架上可以看到和不能看到哪些增益效果，以及增益效果出现的具体位置。没有这个插件，无论你下载哪个插件，都无法完全自定义你的团队框架。值得庆幸的是，Harreks高级团队框架与大多数团队框架插件兼容，让你两全其美。如果你有其他问题或需要帮助，可以访问Harreks的discord， [Spiritbloom.Pro](<https://discord.gg/spiritbloompro>).

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为《地心之战》进行了审查和更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月24日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
