## 专精概览

Welcome to our Fury Warrior guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Fury Warrior in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Fury Mythic+ Resources

[NEW! Top Fury Talent Builds](<https://raider.io/specs/fury-warrior/talents>)

[Top Fury Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warrior/fury>)

[Fury Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warrior--fury>)

[Popular Fury Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warrior--fury>)

1.

### Fury Warrior Overview

Fury Warriors are very active, GCD-locked damage dealers with a fast and
straightforward rotation revolving around generating Rage and spending it on
[[spell:184367]] in order to maintain [[spell:184361]]. While it has a
relatively simple rotation compared to some classes, the associated haste
buffs make Fury one of the highest action specializations in the game, proving
that gameplay does not necessarily need to be complex in order to be engaging.

In addition to a well-rounded offensive toolkit, Fury boasts high mobility,
moderate self-healing, and one of the few raid-wide defensive cooldowns in the
game. However, their greatest weakness comes from inherent limitations
of melee range and a lack of immunity or cheat death mechanics.

All-Rounder

Fury Warriors have a strong toolkit that rewards constant uptime with strong
sustained single target which can be easily cleaved and several multi-target
cooldowns, it performs quite well in a variety of content, though it does take
time to ramp its damage and can suffer in unusually short encounters or those
with extensive downtime.

Add Sniper

fury warriors have a very strong multitarget toolkit, which excels at
frequent groups large groups of adds, though it struggles to maintain single
target pressure, particularly in encounters with complex movement and
downtime. Its damage profile is not particularly bursty either, which can be a
liability in some encounters.

Trash Master

Fury Warriors generally perform well in Mythic+, thanks to the ease of
cleaving its normal rotation, rather than dedicating to purely single or
multitarget capabilities. Although lacking pure single target or funnel, the
flatter damage profiles are good for extended chain pulls, rather than one big
burst.

Many Minor Effects

Warriors have historically had a very difficult time with utility, having
access to several effects which are wholly unnecessary in the vast majority of
modern content. [[spell:384100]], [[spell:64382]],
[[spell:384110]], [[spell:376079]], and [[spell:12323]] are
all seemingly useful effects, but their mechanics are so under-represented in
modern content that they rarely, if ever, get used.

However, Warriors have seen a few improvements in Midnight. [[spell:97462]]
has been buffed in small group content, no longer being as concerned with
diminishing returns means stuns can be used more liberally, and the addition
of a ranged silence provides circumstantial value.

Very Tanky

Fury Warriors have exceptional survivability, by way of several short
defensive and healing cooldowns, which can be used independently to cover
several effects or layered to significantly reduce the threat of large
attacks.

Although it is now harder to talent into [[spell:184364]],
[[spell:23920]] can immune several effects outright, while
[[spell:386208]] and [[spell:208154]] are some of the most reliable
sources of damage reduction in the entire game, though the caveat is that
Warrior survivability is very pre-emptive by nature.

This requires players to have a keen awareness and very little room for
recovery from errors that true immunity or cheat death classes would survive.

Burst Movement on Cooldown

Between [[spell:6544]], [[spell:100]], and [[spell:3411]], Warriors
have very good mobility, so long as there is an appropriate path or target.

2.

### Fury Warrior in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 contains two new pieces of endgame content in the Unbinding of 
Kith'ix raid encounter and an expanded Mega-Delve: the Labyrinth of Kindo'jan! 
Both of these activities contain new challenges, achievements, and rewards, 
which you may learn more about on our dedicated pages.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5

[Patch 12.1.5](<https://www.icy-veins.com/wow/midnight-1215-guide>) acts as an escalation to the progression of Season 2 in
Midnight, with the story surrounding Ula'tek and the Amani culminating in a new one-boss
raid, access to ascended item levels, multiple sources of catch up gear,
and access to an infinite number of Mistcrests to upgrade it. Make sure to check out our
patch hub for all the information on what is new, or has been updated with Patch 12.1.5.

2.3.

#### Class Changes

There are no Fury Warrior changes in Patch 12.1.5, though our [gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>) has been updated with new 
recommednations from the Unbinding of Kith'ix raid and guidance on using 
[[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_cleave.jpg>) Click for Previous Season 2 Changes
2.4.

#### Patch 12.1 Class Changes

There were extensive Fury Warrior changes intend to rebalance and create new 
gameplay options, making Rend a more passive source of damage, increasing 
multitarget capabilties by removing the downside from Rampaging Ruin, putting 
more emphasis on Thunder Blast, and better support builds focused on Raging Blow 
instead of Bloodthirst.

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Warrior**

<em>Developers' notes: Rend is an iconic and core Warrior ability with 
    a different relationship to each spec. Our approach to Rend in Midnight 
    hasn't worked out as we hoped, so we're making changes to how each spec 
    applies and interacts with Rend in Curse of Ula'tek.</em>

- **Class**
  
  
  - New Talent (Fury): Storm of Blood – Whirlwind applies Rend to 
    	  all targets. Crashing Thunder causes Storm of Blood to also apply to 
    	  Thunder Clap for Mountain Thane.
  - [[spell:6343]] no longer innately applies Rend if known.
  - [[spell:1271948]] has a new icon.

- **Hero Talents**
  
  
  <em>Developers' notes: Thunder Clap's base damage increased 
  	significantly in Midnight, causing overall Thunder Clap damage to rise 
  	significantly for Mountain Thane, which in turn devalued Thunder Blast. 
  	We're moving the Crashing Thunder damage bonus into Thunder Blast itself 
  	to keep Thunder Blast feeling special and powerful.</em>
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane: [[spell:435607]] damage increased 
            by 20%.
  - [[spell:135150]] increases Thunder Clap damage by 10% (was 
            30%).
  - [[spell:436148]] damage increased by 150%.

- **Fury**
  
  
  <em>Developers' notes: Whirlwind has historically been a core part of 
      Fury gameplay, even in single-target situations. We'd like to open the 
      door for Whirlwind to be a useful ability in single target again.</em>
  
  
  
  
  - [[spell:1261051]] has been redesigned – Colossus Smash 
        immediately grants 1 use of Sudden Death.
  - New Talent: [[spell:1300463]] – Whirlwind deals 50% 
            additional damage when it strikes only a single target.
  - [[spell:1680]] has been updated – Whirlwind now generates 3 
            Rage innately.
  - [[spell:12950]] has been updated – No longer causes 
            Whirlwind to generate 3 Rage innately, but still increases Rage 
            generated by Whirlwind by 1 per target hit, up to 8 total Rage.
  - [[spell:1265357]] has been redesigned – While Improved 
            Whirlwind is active, Rampage's final strike slams the ground, dealing 
            Physical damage to all enemies within 8 yards of your target. Damage 
            reduced beyond 5 targets.
  - [[spell:383877]] has been updated – Rampage now has a 75% 
            chance to refund a charge of Raging Blow and increase the damage of 
            your next Raging Blow by 20%.
  - Bloodbath initial damaged reduced by 12% and bleed damage 
            increased by 300%.

:::

### Midnight   Changes Overview

2.5.

#### Midnight Changes Overview

Fury Warriors have undergone significant changes in Midnight, reworking or 
removing and replacing several talents entirely, alongside a newfound emphasis 
on keeping [[spell:23881]] on cooldown. Below is a general overview of 
the most impactful changes and how they affect gameplay going into the new 
expansion.

2.6.

#### Hero Talent Changes

Each Hero gains three new talents by level 90, though they are fairly 
straightforward, with no significant change in playstyle. The most notable 
update is for Slayer, with [[spell:444775]] now having an updated chance 
to proc per ability cast and triggering from [[spell:280721]].

2.7.

#### Rotational Changes

With the exception of a few new talented effects, the general gameplay 
remains very similar to The War Within, though [[spell:23881]] and 
[[spell:184367]] now have a significantly increased priority for all heroes 
and rotations.

- Rage generation has been reduced, which reduces the frequency of Rampage,
      but otherwise has little impact on the overall rotation.
- [[spell:1265357]] is a new talent intended to increase multi-target
      efficiency beyond the normal target cap, though it reduces the normal
      damage of Rampage when hitting smaller numbers of targets, which makes
      it a very niche option.
- [[spell:81099]] has been removed, though
      [[spell:81099]] is a new passive allowing Fury
      Warriors to transmog one-handed appearances, a long requested option which
      solves the disparity between weapon types.
- None of the Fury Warrior tier set bonuses were carried forward, resulting
      in less overall Sudden Death and Thunder Blast procs, though the inclusion
      of Deep Wounds encourages both heroes to use Execute much more regularly
      than before.

2.8.

#### Apex Talent: Rampaging Berserker

A new four-point node of specialization-specific Apex talents is now 
available. [[spell:1269308]] is a largely passive buff triggered by 
[[spell:184367]] in the same manner as [[spell:1264934]].

- The first point triggers the [[spell:106951]] buff every time Rampage is 
  cast, passively increasing strength. While this buff stacks, each has its own 
  duration, resulting in the buff constantly stacking and decaying, making it 
  easy to treat passively and ignore.
- The second and third points passively increase the damage of Rampage and 
  reduce its Rage cost during Recklessness. This allows the powerful attack to 
  be used much more frequently and stack the Berserk buff much higher during the 
  cooldown window.
- The final point increases the duration of Recklessness and grants three 
  stacks of Berserk whenever the cooldown is used, further enhancing its damage 
  potential.

2.9.

#### Survivability Changes

Warriors have seen several small improvements to their self-healing and
survivability, though the removal of WeakAura tracking has made
[[spell:23920]] harder to use effectively.

- [[spell:1271926]] increases incoming healing.
- [[spell:29838]] now heals twice as much when below 35% health.
- [[spell:1280961]] significantly increases the value of
      [[spell:386208]], making it an extremely strong mini-cooldown.

2.10.

#### Utility Changes

Although no major new effects or abilities, Warriors have seen a few
    improvements to their group utility in the new expansion.

- [[spell:97462]] Rallying Cry now provides a larger bonus in small group content.
- Enemies no longer becomes immune after several stuns in PvE content, allowing them to be used more liberally.
- [[spell:1271948]] now causes [[spell:384110]] to serve as a ranged silence, albeit on a long cooldown.
- [[spell:12323]] now grants allies a short movement speed buff, which is not particularly important 
  for countering mechanics, but useful for reducing downtime between pulls.

3.

### Basics of Fury Warrior Gameplay

Fury Warriors is a fast-paced spec with little to no downtime, making it
very active and engaging. As nearly every active ability generates Rage, the
gameplay revolves around using those abilities to build Rage in order to use
[[spell:184367]], converting that Rage into [[spell:184361]], increasing damage
done, and triggering a Haste buff, which makes the rotation even faster.

Rampage typically keeps Enrage at a high uptime all on its own, though it 
can be supplemented with Bloodthirst and related talents, [[spell:215568]] 
or [[spell:383295]]. This is perhaps the single most important aspect of 
playing a Fury Warrior effectively, so take care to ensure the buff is always 
active.

Fury Warrior gameplay can best be described using the three key concepts found below.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **Avoid Downtime**  
  
    Fury generates the majority of its Rage from abilities with short cooldowns, 
    so reducing the amount of time spent chasing, running out mechanics, or 
    otherwise not hitting a target is critical to maximizing performance.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_innerrage.jpg>) **Keep Abilities on Cooldown**  
  
    Fury spends Rage in large amounts, which is also the main way of maintaining 
    Enrage, so maximizing the amount of ability casts to generate and spend as 
    much Rage as possible is paramount to maintaining a high uptime.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **Avoid Wasting Rage**  
  
    Unlike most resources, Rage starts from zero and decays while out of combat. 
    Using it effectively and efficiently will help maintain the rotation and 
    eliminate downtime spent waiting for more resources, both in combat and by 
    reducing the amount of time spent moving from one combat to another.

4.

### How to Gear Up as a Fury Warrior

While we always recommend simming yourself for ideal results, we do provide a
dedicated Fury gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated gear recommendations for Patch 12.1.5 and added new section with guidance for Venomstones.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated recommended weapon enchant and potion description to acknowledge odd statistical situations.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **25 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Adjusted Mountain Thane talents.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated leveling build for Patch 12.1.
- **10 Aug. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated all gearing recommendations for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated gems, weapon enchant, and healing potion for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated build recommendations for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated talent builds for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated with Sporefused Gear in Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated with Omnium Folio powers in Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **23 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated alternative mythic+ build and multiple build descriptions.
- **22 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Added multitarget raid talent build.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **06 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Added disclaimer to Potion of Recklessness.
- **06 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Added disclaimer to Potion of Recklessness.
- **06 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Adjusted description of Battle Shout.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added section on upgrading items using crests.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Midnight launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Midnight launch.
- **26 Feb. 2026 (this page):** Updated for Midnight launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated leveling build for Patch 12.0.1.
- **10 Feb. 2026 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Single Target Slayer now uses Avatar.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated builds for Patch 12.0.1.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **20 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated recommended talent builds. Single Target Slayer now uses Avatar.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added new FAQ section for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Added FAQ sections for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Added new Strengths & Weaknesses widget for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added Dinar, updated recommended trinkets, and increased item levels for Turbo Boost.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Added Patch 11.2.5 changes.
- **06 Sep. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for unannounced hotfix.
- **06 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated multitarget Slayer rotation for unannounced hotfix.
- **06 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated talent builds to reflect unannounced hotfix.
- **06 Sep. 2025 (this page):** Added hotfix notes.
- **25 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Added temporary enhancements and expanded notes on weapon enchants.
- **10 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Added Sudden Death helper WeakAura.
- **10 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Clarified explanation regarding talent choices.
- **10 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated to account rotational changes in Season 3.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Added healing with Recouperate in Patch 11.1.7.
- **15 Jun. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added Titan DISC Belt for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Added Combat Assistant Section for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Added Combat Assistant Section for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Added Patch 11.1.7 changes.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated gear lists, added Dinar purchase priority.
- **12 May 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Minor update to Corruption section acknowledging Echoing Void as an alternative.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added Patch 11.1.5 Cartel Chip recommendations.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Added Patch 11.1.5 Corruption recommendations.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Added Wrecking Throw tip for Gallywix.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Separated rotations into toggled image frames.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 (this page):** Added Patch 11.1.5 class changes.
- **17 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Fixed broken Cyrce's Circlet link and added gems to embed.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** More tips, talent tweaks, and Gallywix information.
- **02 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Updated with raid tips and talent builds.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **16 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated Cyrce's Circlet to account for item level increasing hotfixes.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added Cyrce's Circlet and validated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Tagged recommended builds and validated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Tagged recommended talent builds and updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Simplified rotation and validated information for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated changes in Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added brief section detailing upcoming Timewalking and Anniversary raid trinkets.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Updated various tips and talent recommendations for Broodtwister and The Silken Court.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated Mountain Thane Mythic+ build description and dungeon affix recommendations.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated Mountain Thane Mythic+ build description.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Added overview of Patch 11.0.5 changes.
- **03 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** More tips and new talent recommendations for Broodtwister.
- **23 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Queen Ansurek tips and suggestions.
- **23 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Minor single target rotation updates.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Update pathing in class tree to support hero talents earlier.
- **09 Sep. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Page created.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for The War Within Season 1 launch.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Added a note about toggles, and removed errant bracket from the multitarget list.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated Builds for The War Within Season 1 launch.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Added Delve build, minor talent updates.
- **22 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated leveling build.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for The War Within Pre-Season Launch.
- **21 Aug. 2024 (this page):** Updated for The War Within Pre-Season Launch.
- **31 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Update single target Bladestorm priority.
- **26 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Recommend single target Spear over Roar in accoradnce with recent tuning.
- **26 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Minor build updates to account for bugged talent.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/fury-warrior-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/fury-warrior-mists-of-pandaria-remix-guide>)):** Page added.
- **12 May 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated talent build and spell priorities.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated Bloodthirst Weak Aura for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated gear and bullion recommendations for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated talent and rotation recommendations for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Minor update to introduction.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated talent recommendations for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated talent and rotation recommendations for Season 4.
- **22 Apr. 2024 (this page):** Updated changes for Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Minor adjustments to leveling tree, updated for Patch 10.2.6.
- **19 Mar. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Removed old weak auras, added new ones, and reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Expanded crafting recommendations and reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Feb. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Feb. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **14 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Added Fyr'alath to overall BiS list (good luck).
- **14 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Added section emphasizing proper use of Fyr'alath.
- **14 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Minor updates clarifying recommended talents in selection tool.
- **14 Jan. 2024 (this page):** Overview of changes in Patch 10.2.5.
- **08 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated with new gear sets accounting for Sporecloak nerf.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2 and Season 3.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for T31 builds and rotations in preparation for Season 3.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated talent builds for Patch 10.2 and Season 3 tier sets.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Reviewed for Patch 10.1.7.
- **12 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Minor formatting updates.
- **12 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Minor formatting updates.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5, to include Dawn of the Infinite gear.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.5, to include Shockwave as a recommended talent.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Minor updates for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated with no class changes for Patch 10.1.5.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.1
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated Onyx Annulet gem recommendations.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated Onyx Annulet gem recommendations.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated with minor clarifications for Patch 10.0.7.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated with better Onslaught build.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.0.7 with more clear checkbox options.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated with better Onslaught builds.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Patch 10.1
- **01 May 2023 (this page):** Updated for Patch 10.0.7.
- **04 Apr. 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Swap to new by-level talent calculator format.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/fury-warrior-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated with Onyx Annulet information for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated with Onyx Annulet information for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated build for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated builds for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Talent build updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Fix talent selector formatting.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **18 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated Reckless Abandon and Titanic Rage use and descriptions.
- **18 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated Reckless Abandon and Titanic Rage descriptions.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/fury-warrior-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/fury-warrior-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/fury-warrior-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([WeakAuras page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **21 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/fury-warrior-patch-9-2-changes-analysis>)):** Page reviewed and approved for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/fury-warrior-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/fury-warrior-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/fury-warrior-patch-9-1-changes-analysis>)):** Removed PTR references.
- **19 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/fury-warrior-patch-9-1-changes-analysis>)):** Page created with preliminary Patch 9.1 information.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **29 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-the-eternal-palace-raid-guide>)):** More tips, updated recommended talents and essences, no longer recommending Worldvein Resonance.
- **13 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-the-eternal-palace-raid-guide>)):** More tips added, especially for Azshara; several Essence recommendations changed.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **09 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** Added additional Mythic difficulty tips.
- **25 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** Updated Mythic difficulty talent suggestions.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added new tips.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** Guide was created.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** Fixed error - changed suggested talents from Massacre to Carnage.
- **18 Jan. 2019 ([Uldir page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** Updated for Season 2.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** Reviewed and up to date for Patch 8.1.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** Updated for Uldir release.
- **13 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Fury Warrior leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Warrior leveling guide](<https://www.icy-veins.com/wow/warrior-leveling-guide>).

1.

### Fury Warrior Leveling Guide for Midnight

Fury Warrior is a very straightforward leveling class, 
which starts a little slow, but picks up worthwhile multi-target tools around 
level 17 and features very strong self-sustain.

Past that point, Warriors start to become quite competent, regularly pulling
several mobs together and cleaving them down without fear, thanks to
[[spell:208154]] mitigating damage and [[spell:34428]] to heal back up.
By rotating several offensive cooldowns, Fury Warriors will eventually chain
from pull to pull with little to no downtime.

Always initiate combat with [[spell:100]] whenever able, using
[[spell:57755]] or [[spell:6544]] to pull more as desired. When
facing several enemies, use [[spell:1680]] first so that
[[spell:23881]], [[spell:85288]], [[spell:5308]], and
[[spell:184367]] will cleave onto multiple targets.

Once unlocked, [[spell:385059]] can be used regularly due to its
short cooldown, while longer cooldowns like [[spell:1719]] can be saved
for bigger packs or harder targets.

The [[spell:1231418]] ability can be used to 
quickly regain health between combat, without the need to carry level
appropriate food around, since it always restores 50% of maximum health.

1.1.

#### Leveling Gear Options

When leveling up, equipping the highest item level pieces of gear is 
generally ideal. The major exceptions to this rule are some trinkets and Rings
or Necklaces featuring two secondary stats instead of just one.

When using Heirloom items, we recommend using those with Critical Strike
and Haste, as they will slightly improve Rage economy while leveling.

1.2.

#### Useful Leveling Consumables for Midnight

At the start of every new expansion, the one thing in everyone's mind would be how to reach
the maximum level. For Midnight, the max level is 90. There are various items
to boost your leveling speed and efficiency, allowing you to make the best
out of your playtime.

- [[item:132516]] — Massive movement speed boost that works when
  Mounts do not, and much faster than ground mounts.
- [[item:109076]] — Lets you glide off of ledges and cover vast
  distances quickly.
- [[item:172063]] — Gives you a speed buff when you kill
  enemies.
- [[item:168412]] — Do not forget this Mount Equipment to
  make your mounts faster on the ground.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Arms Midnight Leveling Build
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDmZmZ2WmZmZMmxMzMzMzMz2MzYmxsMmZGAAIMwGssY0YGAzCGWAMDmNAYmBwgFGGMG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDmZmZ2WmZmZMmxMzMzMzMz2MzYmxsMmZGAAIMwGssY0YGAzCGWAMDmNAYmBwgFGGMG"
}
```
:::

:::details 来源计算器编码
```
#IB-CIOHnBENakz4qUCBFFxYZUsocaa85BMBD7D-EHJzu0aKiUEgwwAmAhgwUVNGw9sQxYA-AAAA-SAEYg0wsQM4QRQ-
```

:::

2.1.

#### War Mode Talents for Leveling

The following PvP talents are recommended for
leveling and doing solo / small group PvE content. You may find that different
PvP talents work better for you depending on your playstyle. Experimentation is
encouraged!

1. [[spell:213915]] boosts the value of [[spell:23920]], providing
   both more offensive and defensive value in exchange for a slightly longer cooldown.
2. [[spell:411764]] helps build Rage and use [[spell:184367]] more frequently.
3. [[spell:206572]] grants extra mobility, which is always useful while 
   leveling.

3.

### Leveling Rotation

To keep things simple while leveling and learning the spec, use the slider
to select your level, and watch as the leveling rotation grows with each
level!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 2 起：**Cast [[spell:100]] to initiate combat
   whenever possible.
2. **等级 5 起：**[[spell:34428]] for free damage and healing after killing an enemy.
3. **等级 3–10：**Cast [[spell:23922]] to deal damage, if still using a shield.
4. **等级 72 起：**Cast [[spell:435607]] whenever it is available.
5. **等级 17–70：**Cast [[spell:190411]] to apply the Improved Whirlwind buff when facing multiple targets.
6. **等级 71 起：**Cast [[spell:6343]] to maintain the Improved Whirlwind buff when facing multiple targets.
7. **等级 11 起：**Cast [[spell:23881]] to maintain [[spell:184361]].
8. **等级 27 起：**Cast [[spell:184367]] to spend Rage and maintain [[spell:184361]].
9. **等级 37 起：**Cast [[spell:1719]] when facing large groups or strong enemies.
10. **等级 68 起：**Cast [[spell:107574]] when facing large groups or strong enemies.
11. **等级 55 起：**Cast [[spell:385059]] while Enraged for high burst damage.
12. **等级 71 起：**Cast [[spell:6343]] against multiple targets.
13. **等级 6 起：**Cast [[spell:5308]] whenever possible.
14. **等级 13 起：**Use [[spell:85288]] or [[spell:335097]] as damaging fillers.
15. **等级 31 起：**Use [[spell:190411]] to fill the rotation.
16. **等级 1–26：**Use [[spell:1464]].

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated leveling build for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated leveling build for Patch 12.0.1.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added healing with Recouperate in Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Update pathing in class tree to support hero talents earlier.
- **22 Aug. 2024:** Updated leveling build.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **12 May 2024:** Updated talent build and spell priorities.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **25 Mar. 2024:** Minor adjustments to leveling tree, updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **04 Apr. 2023:** Swap to new by-level talent calculator format.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Fury Warrior in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Fury Warrior

Welcome to our Easy Mode Page! This section is intended for players who are new
to the game or class, have no intentions of raiding Mythic difficulty, and want a
straightforward rundown of how the specialization plays without the overwhelming
priority details needed for optimal play.

Fury is a straightforward damage dealer, focused on building Rage with
auto-attacks and special abilities to spend on [[spell:184367]],
triggering [[spell:184361]]. This creates a constant and fast-paced gameplay
loop, enhanced by the specialization's built-in haste buffs. The build showcased
here is a simple yet effective play style, good for all types of game content,
which is meant to help new players learn the fundamentals of Fury.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **Avoid Downtime**  
  
    Fury generates the majority of its Rage from abilities with short cooldowns, 
    so reducing the amount of time spent chasing, running out mechanics, or 
    otherwise not hitting a target is critical to maximizing performance.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_innerrage.jpg>) **Keep Abilities on Cooldown**  
  
    Fury spends Rage in large amounts, which is also the main way of maintaining 
    Enrage, so maximizing the amount of ability casts to generate and spend as 
    much Rage as possible is paramount to maintaining a high uptime.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **Avoid Wasting Rage**  
  
    Unlike most resources, Rage starts from zero and decays while out of combat. 
    Using it effectively and efficiently will help maintain the rotation and 
    eliminate downtime spent waiting for more resources, both in combat and by 
    reducing the amount of time spent moving from one combat to another.

In Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer is generally the best hero spec after the 
initial leveling, making it the preferred choice in most content. In addition 
to strong priority damage, it has the advantage of giving up very little of 
that single target performance when taking multitarget talents.

2.

### Beginner's Guide to Fury Warrior in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer   Single-Target Talents

2.1.

#### Beginner Single-Target Talents for Fury Warrior

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

The single-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer raid build is recommended for all encounters
which do not feature secondary targets.

2.2.

#### Flexible Talents

Without the need for stuns, virtually all desirable talents are already taken, so there is not much need for swaps outside of specific circumstance:

- [[spell:384110]] can be taken in place of [[spell:1271925]] or [[spell:1271926]] any time there are shielded targets. Taking [[spell:1271948]] instead of [[spell:1280961]] may also be worthwhile, trading some defensive benefit for a ranged interrupt.
- [[spell:29838]] is not particularly useful in group content, as periodic damage is common enough to stop the heal over time, though it does occasionally ignore certain mechanics.
- If facing two targets with any degree of frequency, swap [[spell:184364]] for [[spell:12950]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzYmZmlZmxMzMbGzMAAQMW2GYBMgZYCMDbAzMbGbAAwMDjxwYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShNPDGKUCBZlpxROKSM55ZaCDz7DE-EHJy0KMaik+EUgmwwAQQYess6GDWoGC-AAAA-HIcg0AEQYhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer   Dungeon Talents

2.3.

#### Beginner Dungeon Talents for Fury Warrior

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

The multi-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build is less powerful and less 
consistent, depending on getting the right number of Sudden Death procs to 
ensure Bladestorm lines up with other cooldowns and [[spell:444775]] 
procs to supplement its multitarget damage. [[spell:1265357]] does make 
its sustained multi-target much more powerful, but requires regularly hitting 
6+ targets to be worthwhile.

2.4.

#### Flexible Talents

Due to the need to take stuns, there is less room for talent customization:

- [[spell:384110]] can be taken in place of [[spell:1271925]] or [[spell:1271926]] any time there are shielded targets. Taking [[spell:1271948]] instead of [[spell:1280961]] may also be worthwhile, trading some defensive benefit for a ranged interrupt.
- [[spell:184364]] remains a strong defensive bonus, though it is difficult to fit into the build without losing damage. Best case, drop either one point from [[spell:354479]] or [[spell:383486]], but smart use of [[spell:386208]] should make it unnecessary in most situations.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is actively used, though its offensive benefit is lackluster at best.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzAAAMzwYWGYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShPDGKUCBVZlpxFFRJm88MNhh59BC-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### Fury Warrior   Basic Rotation

2.5.

#### Beginner Fury Warrior Rotation

The simplified rotation outlined below encompasses both single and multiple
target situations using our suggested talents. Although some classes use
different abilities between single or multiple targets, Fury Warriors have the
advantage of cleaving all their single-target attacks using
[[spell:12950]], so ensure that the buff is always active when 
faced with extra targets.

- Cast [[spell:1680]] whenever its buff is not active while facing multiple targets.
- Cast [[spell:1719]] and [[spell:107574]] on cooldown or whenever burst damage is needed.
- Cast [[spell:184367]] whenever possible.
- Cast [[spell:163201]] whenever possible.
- Cast [[spell:85288]] to fill the rotation.
- Cast [[spell:385059]] on cooldown.
- Cast [[spell:23881]] on cooldown.
- Cast [[spell:1680]] if nothing else is available.

Unlike Mountain Thane, Slayer uses Raging Blow as its main attack, though 
all builds follow the same principle of converting Rage into damage
with [[spell:184367]] and maintaining [[spell:184361]]. Other talents add
extra abilities and capabilities, such as extending the Execute phase, all of 
which is covered in more details in the advanced sections of this guide.

2.6.

#### Season 2 Tier Set

The new Midnight Season 2 tier set bonuses enhances the effects of 
[[spell:1719]], though it requires using both Bloodthirst and Raging 
Blow, when most builds focus on one or the other. For Slayer, this is very 
easy, since [[spell:386628]] automatically casts Bloodthirst while it uses 
Raging Blow manually. Mountain Thane is more complicated though, since it 
focuses on Bloodthirst, but still needs to find space in the rotation to use 
Raging Blow three times during each cooldown cycle.

- [[spell:1296645]] - Raging Blow damage increased by 15%. 
  During Recklessness Raging Blow extends the duration of Recklessness by 2 sec, 
  up to 6 sec.
- [[spell:1296646]] - Bloodthirst damage increased by 10%. 
  During Recklessness Bloodthirst increases the critical strike bonus of 
  Recklessness by 5%, up to 10%.

2.6.1.

##### Apex Talent: ![Rampaging Berserker Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12_nonmasculinecharacter_orc.jpg>) Rampaging Berserker

The Fury Warrior Apex Talent, [[spell:1269308]], is very 
straightforward, passively increasing the value of Recklessness and Rampage in 
three parts.

- The first point triggers the [[spell:106951]] buff every time Rampage is 
  cast, passively increasing strength. While this buff stacks, each has its own 
  duration, resulting in the buff constantly stacking and decaying, making it 
  easy to treat passively and ignore.
- The second and third points passively increase the damage of Rampage and 
  reduce its Rage cost during Recklessness. This allows the powerful attack to 
  be used much more frequently and stack the Berserk buff much higher during the 
  cooldown window.
- The final point increases the duration of Recklessness and grants three 
  stacks of Berserk whenever the cooldown is used, further enhancing its damage 
  potential.

### Fury Warrior   Defensive Spells

2.7.

#### Defensive Spells for Fury Warrior

Fury Warriors have several defensive abilities which can be used
individually or layered for stronger damage mitigation. Although lacking any
immunity or cheat death, this can make them very capable at surviving
predictable incoming damage.

- [[spell:184364]] is the main defensive cooldown, reducing
  damage and increasing the amount of healing done by Bloodthirst. It is much 
  harder to take in multitarget builds, though can be swapped with 
  [[spell:208154]] or [[spell:206315]] for only a small performance loss.
- [[spell:23920]] is a very powerful tool that not only reduces
  incoming magic damage, but can deflect or even reflect spells entirely. While
  not all spells will be reflected to deal damage to the attacker, simply
  deflecting their application can be significantly reduce damage, if not
  trivialize many dangerous abilities outright.
- [[spell:386208]] is one of the most reliable cooldowns in the
  game, featuring an extremely short 3-second cooldown, though mitigated by the
  associated reduction in damage. While this makes it somewhat
  unpopular, smart use of the ability can dramatically increase survivability.
- [[spell:208154]] is a very powerful passive damage reduction, which is
  almost always active in sustained combat, thanks to high uptime on Enrage.
- [[spell:202168]] a powerful on-demand heal on a short cooldown that
  resets when an enemy is killed. This makes it regularly available and an
  important reactionary tool that should be used regularly.
- [[spell:29838]], [[spell:382549]], and [[spell:23881]] are
  extra healing effects which trigger passively and do not need to be
  micromanaged, but all contribute to increased self-sustain.

### Fury Warrior   Stat Priority

2.8.

#### Stat Priority for Fury Warrior

The general stat priority for a Fury Warrior is seen
below. This is very much a rough guideline, and is designed for players who do
not wish to sim their character. If you are simming your character, please
disregard this stat priority completely and follow your sim!
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>).

Item Level

Mastery

Haste

Versatility

Critical Strike

Fury has an early emphasis on Haste, quickly transitioning to Mastery after
a good amount has been acquired. Haste is still useful due to increasing
auto-attack speed and reducing the time between ability casts, both of which
lead to increased Rage generation and [[spell:184361]] uptime, while Mastery
increases damage done during that buff. Critical Strikes deal double damage,
while Versatility is a flat increase to damage done and reduces damage taken
by half as much.

### Blizzard   Combat Assistant

2.9.

#### Combat Assistant for Fury Warrior

[Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>), added in Patch 11.1.7, is comprised of two
options meant to help players with combat rotations and gameplay.

The first is Assisted Highlight, which recommends the next rotational
ability that players should use, in order to help them learn how to better
play their specialization. While not a perfectly min-maxed rotation, it is
perfectly serviceable, losing an average of around 5% compared to more
complicated manual ones. However, it does not attempt to recommend offensive
cooldowns, defensives, utility abilities, or other off-GCD abilities such as
[[spell:100]], so players must be mindful to use these on their own.

The second option is the Single-Button Assistant, which is a new button
placed on the action bar which automatically cycles through each ability in
the rotation when pressed. Using the same rotation as the Assisted Highlight,
it is serviceable, though an additional 25% penalty is placed on the global
cooldown to keep this from being an easily competitive option, resulting in a
roughly ~20-25% loss in performance. Therefore, it is only recommended for
brand new players, players in trivial content, or those who are otherwise
unable to keep up with regular gameplay.

In both cases, using cooldowns such as [[spell:1719]] and
[[spell:107574]] can be as easy as macroing them to the
Single-Button Assistant or a common ability like [[spell:385059]] or 
[[spell:227847]], though players may also opt to continue using them 
manually, as described in the rotation section.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Combat Assistant Section for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Simplified rotation and validated information for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated talent and rotation recommendations for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1
- **24 Jan. 2023:** Talent build updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Fury Warrior in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Fury Warrior

Fury has remained fairly middle of the pack in both Mythic+ and 
raid for Season 2 regardless of Hero talent choice. It is a strong but not particularly
top tier spec, though it does still have a few raid encounters in which it can shine
with the right talent build.

- **Single Target -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer is the best pure single-target 
    specialization, though there are only a few encounters like that.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane has the best multi-target 
    performance, which includes most raid encounters that feature adds, as well as Mythic+ 
    dungeons.

**Quick Start Import Codes:**

:::talents Fury Single-Target - Slayer
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM"
}
```
:::

:::talents Fury Multi-target - Slayer
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmBAAYmhxsMwgxA"
}
```
:::

:::talents Fury Dungeons & Delves - Thane
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsZmZGAAIMwGssY0YGQmFMjFAzgBAMzAwwiZAGD"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Slayer

Single-Target Raid

recommended

Multi-Target Raid

recommended

Mythic+ & Delves

recommended

Mountain Thane

Multi-Target Raid

Mythic+ & Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Single-Target Raid Talents

The single-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer raid build is recommended for all encounters
which do not feature secondary targets.

1.2.

#### Flexible Talents

Without the need for stuns, virtually all desirable talents are already taken, so
there is not much need for swaps outside of specific circumstances.

- [[spell:184364]] is a very useful defensive cooldown, though good use
  of [[spell:386208]] can compensate for its lack.
- [[spell:384110]] may be taken in place of [[spell:1271925]] for encounters
  with shielded targets.
- [[spell:1244088]] is also occasionally useful, and can be switched with
  [[spell:12323]] or any other less desired talent.

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Multi-Target Raid Talents

The multi-target raid build is used whenever there are extra targets to
cleave, though the frequency and uptime can dictate talent selection.

1.4.

#### Flexible Talents

Encounters with fewer or quickly defeated adds will not need the full complement
of multi-target talents, so some judgement will be necessary to create the best build for each situation.

- [[spell:12950]], [[spell:280392]], and [[spell:1265357]]
  provide the majority of sustained multi-target damage, but are only useful when
  regularly hitting multiple targets. The single-target build is preferred in
  encounters with a quick bursts of adds that are defeated during Bladestorm.
- [[spell:184364]] is a very useful defensive cooldown, though
  good use of [[spell:386208]] can compensate for its lack.
- [[spell:384110]] may be taken in place of [[spell:1271925]] for
  encounters with shielded targets.

### 天赋方案 0-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Mythic+ Dungeon & Delve Talents

The Mythic+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build has slightly less multi-target
potential, but more single-target boss damage. It is also generally easier to
maximize the new tier set bonus, since Raging Blow is used naturally.

1.6.

#### Flexible Talents

Due to the need to take stuns, there is not a whole lot of room for customization:

- [[spell:384110]] may be taken in place of [[spell:1271925]] for activities
  with shielded targets, and combines very well with [[spell:1271948]] to create a
  ranged interrupt, though this requires giving up some defensive value from [[spell:1280961]].
- [[spell:1271925]] has limited use cases in most PvE content, but can occasionally
  remove deadly debuffs that also have a slowing component.
- [[spell:184364]] is a very useful defensive cooldown, though good
  use of [[spell:386208]] can compensate for its lack.

### 天赋方案 1-0

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane Multi-Target Raid Talents

The multi-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane raid build is only recommended
when there are constant adds and secondary targets to continually cleave down.
Despite not being focused on Raging Blow, it still takes several talents
enhancing its damage when used as a filler.

1.8.

#### Flexible Talents

Due to the need to take Thunder Clap and Crackling Thunder, Thane builds do not
have much room for talent customization:

- [[spell:184364]] remains a strong defensive bonus and can be taken
  in place of [[spell:206315]] or [[spell:1265570]], but smart use
  of [[spell:386208]] should make it unnecessary in most situations.
- [[spell:184364]] is a very useful defensive cooldown, though good use
  of [[spell:386208]] can compensate for its lack.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance
  is actively used, though it requires giving up some amount of damage from [[spell:382764]] or [[spell:383082]].

### 天赋方案 1-1

1.9.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane Mythic+ Dungeon & Delve Talents

The multi-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane build features the highest sustained
multi-target damage, though slightly lower single-target in exchange. It may also be
slightly more complicated to play, as Raging Blow must be used three times during each
cooldown cycle to maximize the tier set bonus. Overall, the two differnet M+ builds perform
very similar to one another, so the choice may come down to a matter of preference.

1.10.

#### Flexible Talents

Due to the need to take Thunder Clap and Crackling Thunder, Thane builds do not
have much room for talent customization:

- [[spell:184364]] remains a strong defensive bonus, best taken in
  place of [[spell:393950]], though smart use of [[spell:386208]] should
  make it unnecessary in most situations.
- The class tree is very tight, though [[spell:275339]], [[spell:384110]],
  and [[spell:202163]] are all potential swaps.
- [[spell:1271925]] has limited use cases in most PvE content, but can occasionally
  remove deadly debuffs that also have a slowing component.
- [[spell:1280961]] has amazing defensive potential as long as Defensive
  Stance is actively used, though it requires giving up some amount of damage
  from [[spell:382764]] or [[spell:383082]].

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOSnBDEFKhgsy04IbGFJm88MNhh59BC-EHJy0KauEUikww+AQQYgmss6WeoOGEC-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzYDAAmZYMLDjBjB"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShNPDGKUCBZlpxROKSM55ZaCDz7DE-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzAAAMzwYWGYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShPDGKUCBVZlpxFFRJm88MNhh59BC-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZmZ2WmZmZMMmZmZmZMzyMzMzMmFzMzAAAhB2glFjGzAYWwMWAMzGDAYmBghFzAMG"
}
```
:::

:::details 来源计算器编码
```
#IB-CGHIMNOdnBDFKXABZlpxFOKasM55ZaCD7DE-EHJy0KauEGUiwwAJCggw48ANZZ1tQJA-AAAA-IQSU0AEUwAjDmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsYmZGAAIMwGssY0YGAzCmxCgZwAAmZAYYxMAjB"
}
```
:::

:::details 来源计算器编码
```
#IB-CGIMNOdBDFKhgqsy04OXEFRNWm88MNhh9BC-EHJy0KauEGUiwwAJCggw48ANZZ1tQJA-AAAA-IQSU0AEUwAjDmF-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), which offers
some minor performance-enhancing customization options after a multi-week quest series.
Some of these bonuses affect your damage output, while others are more defensive in nature.

We recommend the following bonuses, though they can be swapped at any time, 
so feel free to experiment with other options or simulated recommendations for 
your own gearing.

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279616]]

3.

### Apex Talent: ![Rampaging Berserker Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12_nonmasculinecharacter_orc.jpg>) Rampaging Berserker

The Fury Warrior apex talent, [[spell:1269308]], is very 
straightforward, passively increasing the value of Recklessness and Rampage in 
three parts.

- The first point triggers the [[spell:106951]] buff every time Rampage is 
  cast, passively increasing strength. While this buff stacks, each has its own 
  duration, resulting in the buff constantly stacking and decaying, making it 
  easy to treat passively and ignore.
- The second and third points passively increase the damage of Rampage and 
  reduce its Rage cost during Recklessness. This allows the powerful attack to 
  be used much more frequently and stack the Berserk buff much higher during the 
  cooldown window.
- The fourth point increases the duration of Recklessness and grants three 
  stacks of Berserk whenever the cooldown is used, further enhancing its damage 
  potential.

4.

### Hero Talents

Fury Warriors have a choice between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane, each with their 
own strengths, focus, and minor gameplay differences.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer is focused on Execute and Bladestorm, with the main 
gameplay difference being increased [[spell:280721]] procs. It tends to be 
the better choice for raid encounters, due to its high priority damage and 
easy cleave, though is currently enjoying renewed interest in Mythic+ as well.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane uses [[spell:6343]] instead of [[spell:1680]], with a 
strong emphasis on [[spell:23881]] to trigger enhanced [[spell:435607]]s. Due to its 
innate multi-target, it tends to be used more frequently in Mythic+ 
instead of raid encounters.

5.

### PvP Talents (War Mode)

Since Battle for Azeroth, players have the option to go into "War Mode,"
allowing them to participate in PvP combat with other players. Enabling War
Mode provides the following benefits:

- PvP talents enabled in the outdoor world
- 10% increase in World Quest rewards at maximum level
- 10% more experience gained while leveling
- Earn Conquest Points, which can reward gear every week

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will make yourself available for open-world PvP,
and the possibility of being "ganked" while leveling or doing World Quests
exists.

1. [[spell:206572]] grants extra mobility, which is always useful while 
   leveling.
2. [[spell:213915]] boosts the value of [[spell:23920]], providing
   both more offensive and defensive value in exchange for a slightly longer
   cooldown.
3. [[spell:411764]] is rather a niche but provides a small bonus
   whenever crowd-controlled.

[[spell:199261]] is also a powerful offensive option, although maintaining
it is cumbersome in open-world content due to the necessity of refreshing
the buff every 15 seconds, and the ability cannot be cast while mounted,
flying, or otherwise not in control of your character.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **25 Aug. 2026:** Adjusted Mountain Thane talents.
- **10 Aug. 2026:** Updated talent builds for Patch 12.1.
- **15 Jun. 2026:** Updated with Omnium Folio powers in Patch 12.0.7.
- **23 Apr. 2026:** Updated alternative mythic+ build and multiple build descriptions.
- **22 Apr. 2026:** Added multitarget raid talent build.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated builds for Patch 12.0.1.
- **20 Jan. 2026:** Updated recommended talent builds. Single Target Slayer now uses Avatar.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **06 Sep. 2025:** Updated talent builds to reflect unannounced hotfix.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Tagged recommended talent builds and updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated Mountain Thane Mythic+ build description.
- **09 Sep. 2024:** Updated Builds for The War Within Season 1 launch.
- **26 Aug. 2024:** Added Delve build, minor talent updates.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **26 Jul. 2024:** Minor build updates to account for bugged talent.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated talent recommendations for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Minor updates clarifying recommended talents in selection tool.
- **06 Nov. 2023:** Updated talent builds for Patch 10.2 and Season 3 tier sets.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **12 Jul. 2023:** Minor formatting updates.
- **10 Jul. 2023:** Minor updates for Patch 10.1.5.
- **01 May 2023:** Updated with better Onslaught builds.
- **24 Jan. 2023:** Updated builds for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Updated Reckless Abandon and Titanic Rage descriptions.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Fury Warrior in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Fury Warrior Gameplay and Rotation Guide

Welcome to our Rotation page for Fury Warriors. On this page, you will
find everything you need to know about actually playing the spec in Raiding
and Mythic+ scenarios.

The Fury rotation is a conditional priority list, which can change
depending on talent choice. Use the checkboxes below to make the appropriate
customizations and make sure that [[spell:386196]] is always toggled
on! Note that the same toggles are used for both the single and multi-target
rotations.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Multitarget

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane

Single Target

Multitarget

Talent Selection

[[spell:46924]]

[[spell:385059]]

[[spell:1261060]]

[[spell:383877]]

[[spell:1265359]]

[[spell:12950]]

[[spell:107574]]

### Single Target Opener

[[spell:1719]]

**适用条件：Avatar（启用）；Mountain Thane（启用）。**

[[spell:107574]]

[[spell:184367]]

**适用条件：Slayer（启用）；Bladestorm（启用）。**

[[spell:46924]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:5308]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:335097]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:335097]]

**适用条件：Mountain Thane（启用）。**

[[spell:435607]]

**适用条件：Mountain Thane（启用）。**

[[spell:113344]]

**适用条件：Mountain Thane（启用）。**

[[spell:335097]]

**适用条件：Mountain Thane（启用）。**

[[spell:184367]]

**适用条件：Mountain Thane（启用）。**

[[spell:113344]]

**适用条件：Mountain Thane（启用）。**

[[spell:435607]]

**适用条件：Mountain Thane（启用）。**

[[spell:335097]]

**适用条件：Mountain Thane（启用）。**

[[spell:184367]]

1.1.

#### Single Target Opening Rotation for Fury Warrior

Always open with [[spell:100]] when able

1. Cast [[spell:1719]]
2. **适用条件：Avatar（启用）；Mountain Thane（启用）。** Cast [[spell:107574]]
3. Cast [[spell:184367]]
4. **适用条件：Slayer（启用）；Bladestorm（启用）。** Cast [[spell:46924]]
5. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
6. **适用条件：Slayer（启用）。** Cast [[spell:5308]]
7. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
8. **适用条件：Slayer（启用）。** Cast [[spell:335097]]
9. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
10. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
11. **适用条件：Slayer（启用）。** Cast [[spell:335097]]
12. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]] to avoid wasting a proc
13. **适用条件：Mountain Thane（启用）。** Cast [[spell:113344]]
14. **适用条件：Mountain Thane（启用）。** Cast [[spell:335097]]
15. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]
16. **适用条件：Mountain Thane（启用）。** Cast [[spell:113344]]
17. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]] to avoid wasting a proc
18. **适用条件：Mountain Thane（启用）。** Cast [[spell:335097]]
19. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]

Proceed with the normal single target priority.

### Single Target Rotation

1.2.

#### Single Target Opener for Fury Warrior

1.3.

#### Single Target Rotation During Cooldowns for Fury Warrior

The Fury Warrior rotation is a priority list, in which each time an ability is cast, the user should start back at the top of the list, establishing a hierarchy of importance. Because [[spell:1719]] has a major effect on how Rage is generated and spend, this list is split up based on whether or not cooldowns are currently active.

:::details Tier Set and the Rotation
The Season 2 tier set increases the damage of rotational abilities, while causing them to buff Recklessness. Slayer handles this automatically with

[[spell:386628]]

, while Mountain Thane must use both Bloodthirst and Raging Blow during its cooldowns.

- [[spell:1296645]]
- [[spell:1296646]]

:::

During Recklessness, Rage is generated faster and Rampage can be used sooner, though it should not be used as soon as it is available. Instead, Rampage is delayed until approaching the Rage cap, in order to create room for other abilities.

1. Cast [[spell:184367]] with more than 100 Rage or if [[spell:184361]] is not active
2. **适用条件：Mountain Thane（启用）；Avatar（启用）。** Cast [[spell:435607]] with 2 stacks of the Thunder Blast buff, less than 2 seconds of Avatar remaining, or less than 3 seconds remaining on the Thunder Blast buff
3. **适用条件：Mountain Thane（启用）。** Cast [[spell:113344]] twice to apply the Season 2 tier set critical strike chance buff
4. **适用条件：Mountain Thane（启用）；Hack and Slash（启用）。** Cast [[spell:335097]] while the [[spell:383877]] buff is active
5. **适用条件：Mountain Thane（启用）。** Cast [[spell:113344]]
6. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]
7. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
8. **适用条件：Mountain Thane（启用）。** Cast [[spell:335097]]
9. **适用条件：Mountain Thane（启用）。** Cast [[spell:5308]]
10. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]] if nothing else is available
11. **适用条件：Slayer（启用）；Bladestorm（启用）。** Spam [[spell:184367]] immediately before using Bladestorm
12. **适用条件：Slayer（启用）；Bladestorm（启用）。** Cast [[spell:46924]] during Recklessness
13. **适用条件：Slayer（启用）。** Cast [[spell:5308]] with [[spell:280721]]
14. **适用条件：Slayer（启用）；Hack and Slash（启用）。** Spam [[spell:184367]] if the [[spell:383877]] buff is not active
15. **适用条件：Slayer（启用）；Hack and Slash（启用）。** Cast [[spell:335097]]
16. **适用条件：Slayer（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]]
17. **适用条件：Slayer（启用）。** Cast [[spell:5308]]
18. **适用条件：Slayer（启用）。** Cast [[spell:113344]]
19. **适用条件：Slayer（启用）；Hack and Slash（未启用）。** Cast [[spell:335097]]

1.4.

#### Outside of Cooldowns

Outside cooldowns, Rampage is less frequently delayed, though without the extra rage generation from Recklessness, it must be used every few casts in order to maintain Enrage. The rest of the rotation is fairly similar, though Bloodthirst and Raging Blow must be weaved more to generate the extra rage needed to use Rampage.

1. Cast [[spell:1719]] on cooldown
2. **适用条件：Avatar（启用）。** Cast [[spell:107574]] on cooldown
3. Cast [[spell:184367]] when over 100 Rage or if Enrage is about to expire
4. **适用条件：Mountain Thane（启用）；Hack and Slash（启用）。** Cast [[spell:85288]] with the [[spell:383877]] buff active
5. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
6. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]
7. **适用条件：Mountain Thane（启用）。** Cast [[spell:23881]]
8. **适用条件：Mountain Thane（启用）；Deep Wounds（启用）。** Cast [[spell:5308]] with [[spell:1261060]] talented
9. **适用条件：Mountain Thane（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]]
10. **适用条件：Mountain Thane（启用）。** Cast [[spell:85288]]
11. **适用条件：Mountain Thane（启用）；Deep Wounds（未启用）。** Cast [[spell:5308]]
12. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]] when nothing else is available
13. **适用条件：Slayer（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]]
14. **适用条件：Slayer（启用）。** Cast [[spell:163201]]
15. **适用条件：Slayer（启用）。** Cast [[spell:85288]]
16. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
17. **适用条件：Slayer（启用）。** Cast [[spell:23881]]
18. **适用条件：Slayer（启用）。** Cast [[spell:190411]] when nothing else is available

### Multitarget Opener

[[spell:100]]

**适用条件：Mountain Thane（启用）；Odyn's Fury（启用）。**

[[spell:385059]]

**适用条件：Slayer（启用）。**

[[spell:190411]]

[[spell:12950]]

[[spell:772]]

[[spell:1719]]

**适用条件：Mountain Thane（启用）。**

[[spell:107574]]

**适用条件：Mountain Thane（启用）；Odyn's Fury（未启用）。**

[[spell:184367]]

**适用条件：Mountain Thane（启用）。**

[[spell:435607]]

**适用条件：Mountain Thane（启用）。**

[[spell:113344]]

**适用条件：Mountain Thane（启用）。**

[[spell:435607]]

[[spell:184367]]

**适用条件：Mountain Thane（启用）。**

[[spell:435607]]

**适用条件：Mountain Thane（启用）。**

[[spell:184367]]

**适用条件：Mountain Thane（启用）。**

[[spell:6343]]

**适用条件：Slayer（启用）；Bladestorm（启用）。**

[[spell:46924]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:385059]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:190411]]

**适用条件：Slayer（启用）。**

[[spell:184367]]

**适用条件：Slayer（启用）。**

[[spell:335097]]

1.5.

#### Multitarget Opening Rotation for Fury Warrior

Always open with [[spell:100]] when able.

1. **适用条件：Mountain Thane（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]] to apply Enrage
2. **适用条件：Slayer（启用）。** Cast [[spell:190411]] to apply [[spell:12950]] and [[spell:772]]
3. Cast [[spell:1719]]
4. **适用条件：Mountain Thane（启用）。** Cast [[spell:107574]]
5. **适用条件：Mountain Thane（启用）；Odyn's Fury（未启用）。** Cast [[spell:184367]] to apply Enrage
6. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
7. **适用条件：Mountain Thane（启用）。** Cast [[spell:113344]]
8. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
9. Cast [[spell:184367]]
10. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
11. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]
12. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]]
13. **适用条件：Slayer（启用）；Bladestorm（启用）。** Cast [[spell:46924]]
14. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
15. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
16. **适用条件：Slayer（启用）。** Cast [[spell:385059]]
17. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
18. **适用条件：Slayer（启用）。** Cast [[spell:190411]]
19. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
20. **适用条件：Slayer（启用）。** Cast [[spell:335097]]
21. Proceed with the normal multitarget priority.

### Multitarget Rotation

1.6.

#### Multitarget Rotation During Cooldowns for Fury Warrior

Against multiple targets, Fury Warriors make extensive use of [[spell:190411]] and [[spell:6343]] for damage, while also enabling their normal rotation to cleave four additional targets.

:::details Tier Set and the Rotation
The Season 2 tier set increases the damage of rotational abilities, while causing them to buff Recklessness. Slayer handles this automatically with

[[spell:386628]]

, while Mountain Thane must use both Bloodthirst and Raging Blow during its cooldowns.

- [[spell:1296645]]
- [[spell:1296646]]

:::

During Recklessness, Rage is generated faster and Rampage can be used sooner, though it should not be used as soon as it is available. Instead, Rampage is delayed until approaching the Rage cap, in order to create room for other abilities.

1. **适用条件：Mountain Thane（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]] if [[spell:184361]] is not already active
2. **适用条件：Mountain Thane（启用）；Odyn's Fury（未启用）。** Cast [[spell:184367]] if [[spell:184361]] is not already active
3. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
4. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]] against more than 6 targets
5. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]] with more than 100 rage, or if [[spell:184361]] is about to fall
6. **适用条件：Mountain Thane（启用）。** Cast [[spell:113344]]
7. **适用条件：Mountain Thane（启用）；Hack and Slash（启用）。** Cast [[spell:335097]] with the [[spell:383877]] buff active
8. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]
9. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]]
10. **适用条件：Mountain Thane（启用）。** Cast [[spell:335097]]
11. **适用条件：Slayer（启用）。** Cast [[spell:1680]] to apply the [[spell:12950]] buff whenever it is not active
12. **适用条件：Slayer（启用）。** Cast [[spell:184367]] as much as possible
13. **适用条件：Slayer（启用）；Bladestorm（启用）。** Cast [[spell:46924]] during Recklessness
14. **适用条件：Slayer（启用）。** Cast [[spell:5308]] with [[spell:280721]]
15. **适用条件：Slayer（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]]
16. **适用条件：Slayer（启用）。** Cast [[spell:335097]]
17. **适用条件：Slayer（启用）。** Cast [[spell:113344]]
18. **适用条件：Slayer（启用）。** Cast [[spell:5308]]

1.7.

#### Outside of Cooldowns

Outside cooldowns, Rampage is similarly delayed, though for reasons of rage efficiency in order to maintain a better Enrage uptime. Without the extra rage generation from Recklessness, this is a much more important factor and results in a very different gameplay cadence.

1. **适用条件：Improved Whirlwind（启用）；Slayer（启用）。** Cast [[spell:190411]] if [[spell:12950]] is not active
2. **适用条件：Mountain Thane（启用）。** Cast [[spell:385059]]
3. **适用条件：Mountain Thane（启用）。** Cast [[spell:107574]]
4. **适用条件：Mountain Thane（启用）。** Cast [[spell:1719]]
5. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
6. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]] if the [[spell:12950]] buff is not active or against 7+ targets
7. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]] when over 100 Rage or if Enrage is about to expire
8. **适用条件：Mountain Thane（启用）。** Cast [[spell:23881]]
9. **适用条件：Mountain Thane（启用）。** Cast [[spell:435607]]
10. **适用条件：Mountain Thane（启用）；Hack and Slash（启用）。** Cast [[spell:85288]] with the [[spell:383877]] buff active
11. **适用条件：Mountain Thane（启用）。** Cast [[spell:5308]]
12. **适用条件：Mountain Thane（启用）。** Cast [[spell:184367]]
13. **适用条件：Mountain Thane（启用）。** Cast [[spell:85288]]
14. **适用条件：Mountain Thane（启用）。** Cast [[spell:6343]] if nothing else is available
15. **适用条件：Slayer（启用）。** Cast [[spell:184367]]
16. **适用条件：Slayer（启用）。** Cast [[spell:5308]] with [[spell:280721]]
17. **适用条件：Slayer（启用）；Odyn's Fury（启用）。** Cast [[spell:385059]]
18. **适用条件：Slayer（启用）。** Cast [[spell:5308]]
19. **适用条件：Slayer（启用）。** Cast [[spell:85288]]
20. **适用条件：Slayer（启用）。** Cast [[spell:23881]]
21. **适用条件：Slayer（启用）。** Cast [[spell:190411]] to fill the rotation

### Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer

1.8.

#### Playing as a Slayer

Slayer revolves around [[spell:29725]] and [[spell:227847]], though it is still important to keep Bloodthirst on cooldown for damage and Enrage.

- Consuming [[spell:29725]] reduces the cooldown of [[spell:227847]] based on the number of [[spell:445584]] stacks.
- [[spell:29725]] can stack twice, so it does not need to be used immediately, but should not be delayed unnecessarily to avoid overcapping.
- [[spell:227847]] triggers multiple talents, making it better to use early in [[spell:1719]], to maximize the overlap of buffing effects.
- [[spell:107570]] can be cast during Bladestorm for an extremely minor amount of extra damage, any time the stun is not needed.

### Playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane

1.9.

#### Playing as a Colossus

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane effectively replaces Whirlwind with [[spell:6343]], which becomes greatly empowered during [[spell:107574]].

- [[spell:6343]] is occasionally replaced by [[spell:435607]]. Though they deal a very similar amount of direct damage, Blast is extends the duration of Avatar and always triggers an extra Lightning Strike, making it much stronger than the tooltip implies.
- During Avatar, the cooldown of [[spell:6343]] is greatly reduced, allowing it to be used every other global cooldown. It should be kept on cooldown when facing a high number of targets, though in single or low-cleave situations, it is better saved as an intermittent filler.
- [[spell:1719]] and [[spell:107574]] have the same cooldown and are equally affected by [[spell:152278]], allowing them to be safely used together with a macro.

2.

### Midnight Season 2 Tier Set

The new Midnight Season 2 tier set bonuses increases the damage of 
rotational abilities, while causing them to buff [[spell:1719]]. This 
has some small rotational implications, though Slayer handles them automatically 
with [[spell:386628]], while Mountain Thane must use both Bloodthirst and 
Raging Blow during its cooldowns.

- [[spell:1296645]] - Raging Blow damage increased by 15%. 
  During Recklessness Raging Blow extends the duration of Recklessness by 2 sec, 
  up to 6 sec.
- [[spell:1296646]] - Bloodthirst damage increased by 10%. 
  During Recklessness Bloodthirst increases the critical strike bonus of 
  Recklessness by 5%, up to 10%.

3.

### Class and Spec Mechanics Explained

In order to better explain the specifics of Fury Warrior mechanics, we have 
compiled a more detailed explanation on individual parts of our rotation, from 
important rotational mechanics that you need to pay attention to, to cooldowns 
and how to use them, so you can reach your full potential.

### Maintaining Enrage

3.1.

#### Enrage

The goal of the Fury rotation is a continual feedback loop of generating
Rage, spending it on [[spell:184367]] to trigger [[spell:184361]], which 
increases damage of follow-on abilities while they generate more Rage to 
repeat the process. Because it can be such a powerful buff, routinely in the 
30-50% range, maintaining a high uptime is paramount to success as a Fury 
Warrior.

While [[spell:1719]] increases the amount of Rage generated in order 
to use Rampage more quickly, both [[spell:385059]] and [[spell:215568]] 
automatically trigger Enrage, helping jumpstart the rotation when other 
cooldowns are not available. Fresh Meat in particular can be gamed by 
carefully keeping track of which enemies have not yet been hit by the ability, 
allowing it to be chained from target to target to continually trigger the 
effect again.

### Maximizing Uptime

3.2.

#### Maximizing Uptime

Applicable to most classes, though particularly relevant to Fury Warriors, 
due to the high emphasis on stacking haste for more attacks with which to 
generate Rage. Any time spent off target is lost damage, with minimal means to 
recoup lost resources, unlike energy-based classes which will continue 
regenerating their resource up to its cap.

Due to the high mobility innate to the Warrior class, 
it is possible to play around boss mechanics and minimize downtime. If the 
boss is casting an area effect which requires players to run a certain 
distance away, a Warrior can instead continue attacking until the last few 
seconds, [[spell:6544]] away and immediately [[spell:100]] back 
as soon as the danger has passed.

Fury should never have any free global cooldowns, due to Whirlwind always 
being available. This should not be depended on, however, as Whirlwind does 
not generate Rage unless [[spell:12950]] is talented. Instead, 
repeated use of Raging Blow and weaved Bloodthirsts make up the bulk of the 
rotation, while Rampage is often delayed beyond its 80 Rage cost, so long as 
Enrage does not run out. Delaying the use of Rampage this way allows a small 
amount of extra Rage to be pooled, thus requiring less than another full 80 
Rage to be generated before the next Rampage is cast a few seconds later.

### Cycle Charging

3.3.

#### Cycle Charging

A small optimization can be made by moving out of range of the target and
using [[spell:100]] to generate extra Rage during your rotation. Care
should be taken to do this between auto-attack swings when
[[spell:1719]] is not active. [[spell:6544]] can also be
used to create enough room to Charge for bosses with large hitboxes, which is
sometimes more specifically referred to as Heroic Charge.

### Using the Apex Talent

3.4.

#### Using the Apex Talent

Due to the Rage cost reduction, [[spell:184367]] may be cast much more 
frequently during [[spell:1719]], typically every other GCD. Because 
[[spell:106951]] stacks have individual durations though, there is no 
particular need or advantage to track it, making the buff easy to treat 
passively.

4.

### Important Cooldowns for Fury Warrior

### [[spell:1719]]

4.1.

#### Recklessness

The main cooldown for Fury Warriors provides a moderate burst window and 
enhanced Rage generation, allowing Rampage to be used more frequently. 
Talenting [[spell:396749]] also transforming Bloodthirst and Raging 
Blow into their more powerful [[spell:113344]] and [[spell:335097]] 
forms.

### [[spell:107574]]

4.2.

#### Avatar

Now on a choice node with Bladestorm, Avatar is necessary for the proper 
function of Mountain Thane, creating an easy choice between the two. Although 
berefit of its follow-on talents, Avatar has great synergy with the rest of 
the Mountain Thane bonuses, especially [[spell:275336]].

### [[spell:227847]]

4.3.

#### Bladestorm

The signature Slayer ability is not the high-burst powerhouse it used to 
be, but continues to provide a reasonable amount of damage, with its single 
target value increased by [[spell:386628]]. Care should be taken to always be 
enraged before using the ability, preferably immediately after a fresh 
Rampage, and although it does generate Rage, having either [[spell:215568]] 
or [[spell:383295]] will help maintain Enrage during and after the 
channel ends.

Keep in mind that the automatic Bloodthirst caused by Unhinged can also 
trigger their own effects, such as [[spell:184361]] or [[spell:444775]].

Despite three stacks of [[spell:444769]] causing the button to glow, 
this is not an indicator of when Bladestorm should be used. It should almost 
always be used either on cooldown, or timed with groups of adds.

### [[spell:385059]]

4.4.

#### Odyn's Fury

Odyn's Fury provides another way to immediately trigger Enrage, as well as 
its own sudden burst of damage. Best used as an initiator when cooldowns are 
not available, it also benefits from [[spell:385703]].

### [[spell:384110]]

4.5.

#### Wrecking Throw

While not a major cooldown per se, Wrecking Throw deals a surprisingly high 
amount of damage, making it a competent ranged filler that also silences 
enemies while [[spell:1271948]] is talented. However, its true power comes 
into play when facing targets with absorb shields, gaining a 500% damage 
multiplier to become the strongest single attack in the entire Warrior kit. In 
such situations, it should be used quickly, second only to applying Enrage, in 
order to ensure it hits the target to quickly strip its shield.

4.6.

#### Defensive Abilities

Fury boasts high passive survivability, thanks to higher base stamina and 
the passive damage reduction of [[spell:208154]]. Although its primary 
survivability tool is [[spell:184364]], some builds may opt not to 
take it, instead relying on a combination of [[spell:386208]] and/or 
[[spell:1280961]] instead, despite the small loss of damage while it is 
active, while [[spell:202168]] and [[spell:29838]] can 
help heal damage back up instead. Finally, [[spell:23920]] is an 
extremely useful tool for mitigating or outright immuning many sources of 
magical damage.

The [Targeted 
Spells](<https://www.curseforge.com/wow/addons/targetedspells>) addon is very helpful in knowing when an enemy spell is being cast 
on you, though it cannot tell what that spell is or whether it is reflectable, 
so players will need to learn to identify them on their own.

The increased health and self-healing make Fury very tanky in
sustained combat, although less able to deal with frequent bursts of high
damage. In those cases, Enraged Regeneration is best used preemptively, with
Bloodthirst cast as often as possible over its duration to benefit
from its increased healing.

4.7.

#### Group Buffs

Warriors have access to [[spell:97462]], one of the few
defensive group cooldowns in the game. It is typically used to help the group
survive key encounter mechanics rather than as a personal cooldown. Keep in
mind that it is on the global cooldown, so be ready to use it when needed.

Warriors also bring [[spell:6673]], increasing all party and raid
members Attack Power by 5%, which should be applied before combat begins. Note 
that this buff only applies to melee attackers and Hunters, with no bonus for 
casting specializations.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **06 Apr. 2026:** Adjusted description of Battle Shout.
- **06 Apr. 2026:** Added disclaimer to Potion of Recklessness.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Single Target Slayer now uses Avatar.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **06 Sep. 2025:** Updated multitarget Slayer rotation for unannounced hotfix.
- **10 Aug. 2025:** Updated to account rotational changes in Season 3.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Combat Assistant Section for Patch 11.1.7.
- **21 Apr. 2025:** Separated rotations into toggled image frames.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **23 Sep. 2024:** Minor single target rotation updates.
- **09 Sep. 2024:** Added a note about toggles, and removed errant bracket from the multitarget list.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **31 Jul. 2024:** Update single target Bladestorm priority.
- **26 Jul. 2024:** Recommend single target Spear over Roar in accoradnce with recent tuning.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Added section emphasizing proper use of Fyr'alath.
- **06 Nov. 2023:** Updated for T31 builds and rotations in preparation for Season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.0.7 with more clear checkbox options.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Fix talent selector formatting.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Fury Warrior in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Fury Warrior

Welcome to our Fury Warrior Gear and BiS Page for
Midnight Season 2. Check this page to learn everything you need
to know about gearing a Fury Warrior, including the BiS Gear
from all sources, Raiding and Mythic+, information on the best Trinkets, Tier
Sets, or take a look at the [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) to learn more about new 
expansion features.

Generally speaking, item level is the best indicator of power, with higher 
item level pieces of gear almost always being stronger than ones which are 
slightly better itemized, though trinkets can be an exception to this rule of 
thumb due to their varied special effects.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Fury Warrior. Keep in mind that there are some alternatives with similar stat distributions that perform similarly. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

Non-embellished crafted items are not as strong as their fully upgraded counterparts, but can make very strong filler pieces.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, it no longer matters which tier pieces Fury Warriors prioritize, since catalyzed tier pieces now inherit the original item stats and bonuses, making them identical and rendering the idea of "offpieces" obsolete. Players will still have more control over their gearing, though tokens with default stats still continue to drop from bosses as normal.

- Catalyst Helm: [[item:281239@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Catalyst Shoulders: [[item:251138@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Catalyst Chest: [[item:268222@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

That said, completing bonuses is much more important than optimizing itemization, so do not put any emphasis on holding out for better pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271878@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:280799@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Mythic+

This list contains best gear specifically available from dungeons for Fury Warrior. Keep in mind that there are some alternatives with similar stat distributions, as well as several very competitive catalyst pieces that can be obtained from any dungeon. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

Non-embellished crafted items are not as strong as their fully upgraded counterparts, but can make very strong filler pieces.

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Contains the most pieces, including the best weapon.
- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Also has several pieces, making it a more effective farm.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Has a very good ring, which provides important stats.

:::

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, it no longer matters which tier pieces Fury Warriors prioritize, since catalyzed tier pieces now inherit the original item stats and bonuses, making them identical and rendering the idea of "offpieces" obsolete. Players will still have more control over their gearing, though tokens with default stats still continue to drop from bosses as normal.

- Catalyst Helm: [[item:251126@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Catalyst Shoulders: [[item:251138@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Catalyst Chest: [[item:193753@JAAKAAQkCYHKvbRLfYjM]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- Catalyst Hands: [[item:251214@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Catalyst Legs: [[item:273776@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

That said, completing bonuses is much more important than optimizing itemization, so do not put any emphasis on holding out for better pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:273781@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Waist</th><td>[[item:159442@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.wowhead.com/achievement=41960" rel="noopener noreferrer">Murder Row</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:250229@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273782@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251230@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Raid

This list contains the best gear specifically available from raids for Fury Warrior. Keep in mind that there are some alternatives with similar stat distributions that perform similarly. This list is **not the end-all-be-all** list where any item that is not listed is far behind this specific selection.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

Non-embellished crafted items are not as strong as their fully upgraded counterparts, but can make very strong filler pieces.

:::details FAQWhich Tier Set Pieces Do I Want?
For Midnight Season 2, it no longer matters which tier pieces Fury Warriors prioritize, since catalyzed tier pieces now inherit the original item stats and bonuses, making them identical and rendering the idea of "offpieces" obsolete. Players will still have more control over their gearing, though tokens with default stats still continue to drop from bosses as normal.

- Catalyst Helm: [[item:281239@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Catalyst Chest: [[item:268222@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Catalyst Legs: [[item:271878@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

That said, completing bonuses is much more important than optimizing itemization, so do not put any emphasis on holding out for better pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271444@JAACAAgNyA]]&#10;&#10;<div><span>BoE Trash Drop</span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Chest</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Bracers</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></div></td></tr><tr><th>Trinket</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:280799@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Fury Warrior

There are several trinkets available in Season 2, though 
there are very few on-use trinkets this season, with the majority being random 
damage or stat buffs, which have little gameplay value and do not benefit from 
class effects such as [[spell:184361]] or [[spell:107574]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Fury Warrior Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Both Heroes</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250259]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:158367]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

Patch 12.1 continues the bonus roll system, allowing players to earn a 
Nebulous Voidcore bonus roll in lieu of taking an item from the Great Vault. 
With the launch of Patch 12.1.5, players will also be able to purchase an 
additional Voidcore from **Orin Straylight** near the Catalyst in Silvermoon 
each week, giving them two opportunities to earn bonus loot.

**[Nebulous Voidcores](<https://www.wowhead.com/currency=3418>)** can be spent after finishing a dungeon or 
defeating a raid boss, granting you a random item from that specific loot 
table. Each item can only be bonus rolled once in each difficulty or dungeon, 
working as a knock-out list to deterministically obtain items.

4.

### Recommended Nebulous Voidcores Bonus Rolls

From the beginning of Patch 12.1, players can acquire voidcore bonus rolls 
in lieu of taking an item from Great Vault, though they will not be otherwise 
obtainable on a weekly basis until eight weeks into the season, around the 
time Patch 12.1.5 is expected to arrive. These are powerful resources, well 
worth prioritizing and using if the items in the vault are not as good. 
Ultimately this is a gamble, so players will need to evaluate whether the gear 
in their vault is better than the chance of bonus rolling the item they want 
from the specific boss or dungeon loot table.

Bonus rolled loot is awarded as if it came from the Great Vault, so Heroic 
difficulty raid boss loot will be awarded at 1/6 on the Myth track, while 
Mythic raid boss loot will be awarded at its maximum upgrade level, 
potentially saving a great deal of crests.

4.1.

#### Recommended Nebulous Voidcore Usage for Fury Warrior

There are two primary ways of using [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) bonus rolls, 
depending on the needs of the player. Ideally, they should be spent on 
Mythic+10 dungeons and Mythic raid bosses to maximize the reward, but keep in 
mind that Mythic raid bosses can only be defeated once per week, while Mythic+ 
dungeons may be repeated in order to stockpile and then use several bonus 
rolls until the desired item is obtained. As of Patch 12.1, only one 
[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) is consumed regardless of whether it is used on a 
raid boss or in a Mythic+ dungeon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Myth-track weapons, specifically [[item:268213]] or 
   [[item:280799]].
2. Myth-track trinkets, particularly [[item:270173]] and 
   [[item:270175]].
3. Items with extra budget or cantrip effects, such as 
   [[item:268265]], [[item:271878]], and 
   [[item:281029]].
4. Any high budget, rare, or otherwise replacement for a low item level piece 
   of gear.

:::

4.2.

#### Ascendant Venomstones

[[item:280562]] can be used to upgrade an already maximum 
upgraded Heroic, Myth, or equivalent Crafted weapon, trinket, or necklace. 
Heroic gear is upgraded to 328 item level, Crafted pieces to 338, and Mythic 
ones to 340 item level.

1. Weapons are always the highest priority for Warriors.
2. Trinkets are second, as their special effects often provide more power 
     than raw stats.
3. Necklaces should be upgraded last.

Because only these three types of items can be upgraded, highly progressed 
Fury Warriors who have already acquired 344 item level pieces from Mythic 
Coiled Altar and Ula'tek will only need one Venomstone to upgrade their 
offhand weapon. However, most players have not yet reached that point and 
Venomstones are infinitely farmable, so they do not need to be hoarded for the 
best items. They can and should be used to upgrade whatever piece of gear you 
are currently wearing.

5.

### Best Crafted Items for Fury Warrior

Professions are a great way to gear up with your optimal secondary
stats, as adding special items to the crafting process lets you pick and choose 
the exact secondary stats you want.

Crafting a weapon first can be a very good choice for Fury Warriors, as the 
increased item level will discount upgrades on their weapon, effectively 
gearing two slots for the price of one. For their second embellishment, 
bracers are the most competitive crafts, due to the lower budget. Eventually, 
players will want to replace their weapon with a crafted pair of boots, 
assuming they have suitible Mythic-tier replacements and a surpluss of 
upgrade crests by that point.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Fury Crafted Gear Priority**
- [[item:237847]] with [[item:245876]]
- [[item:237834]] with [[item:240167]]
- [[item:237828]] with [[item:240167]]

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.1.

#### Best Embellishments for Fury Warrior

Up to two of your crafted items can be **Embellished**. This is a similar
concept as **Unique-Equipped**, as you can only wear two items that have the
Embellished status. Some crafted items, many of which have powerful procs or
beneficial effects by default, are considered Embellished. You can also add
Embellishments from a variety of professions to any crafted item, adding the
effect to this item either when creating it or at a later stage.

As there is a lot of competition for Embellishments, you will have to pick
and choose the two strongest ones for your overall DPS output. Most of them provide
very similar DPS benefits, even if the effects are entirely different. The two best
choices for this are:

- For Raid and Mythic+: [[item:245876]] on Weapon and [[item:240167]] on other items.

It is recommended to sim yourself to find out what works best, and consider 
any potential spec swaps that may be made in the near future.

5.2.

#### Adding Sockets to Gear

Instead of picking an item from the Great Vault each week, players can opt 
to take tokens instead, six of which can be exchanged for a 
[[item:275707]], a consumable which adds a single socket to 
Helmets, Bracers, or Belts that do not already have one. This makes it a good 
way of finishing gear which you do not intend to replace.

6.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Fury Warrior Crest Upgrade Priority**
**Weapons**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special cantrip items that have 
additional effects unique to that piece of gear.

7.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated gear recommendations for Patch 12.1.5 and added new section with guidance for Venomstones.
- **10 Aug. 2026:** Updated all gearing recommendations for Patch 12.1.
- **15 Jun. 2026:** Updated with Sporefused Gear in Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Added section on upgrading items using crests.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added new FAQ section for Patch 11.2.7.
- **05 Oct. 2025:** Added Dinar, updated recommended trinkets, and increased item levels for Turbo Boost.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Added Titan DISC Belt for Patch 11.1.7.
- **12 May 2025:** Updated gear lists, added Dinar purchase priority.
- **21 Apr. 2025:** Added Patch 11.1.5 Cartel Chip recommendations.
- **17 Mar. 2025:** Fixed broken Cyrce's Circlet link and added gems to embed.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **16 Dec. 2024:** Updated Cyrce's Circlet to account for item level increasing hotfixes.
- **15 Dec. 2024:** Added Cyrce's Circlet and validated for Patch 11.0.7.
- **21 Oct. 2024:** Added brief section detailing upcoming Timewalking and Anniversary raid trinkets.
- **09 Sep. 2024:** Updated for The War Within Season 1 launch.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated gear and bullion recommendations for Season 4.
- **19 Mar. 2024:** Expanded crafting recommendations and reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated for Patch 10.2.5.
- **14 Jan. 2024:** Added Fyr'alath to overall BiS list (good luck).
- **08 Nov. 2023:** Updated with new gear sets accounting for Sporecloak nerf.
- **06 Nov. 2023:** Updated for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5, to include Dawn of the Infinite gear.
- **01 May 2023:** Updated Onyx Annulet gem recommendations.
- **20 Mar. 2023:** Updated with Onyx Annulet information for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Fury Warrior. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Fury Warrior Stat Priority

Both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Fury Warriors primarily 
value item level for Strength, followed by Mastery and Haste, followed up by 
Versatility and Critical Strike. Due to various points of diminishing returns, 
the value of these stats will fluctuate as gear levels increase, dropping as 
more is obtained, so it is not uncommon to gear into a lot of Haste and 
Mastery, then gem or enchant for more Versatility or Critical Strike. By the 
time you have reached moderate gear levels, the stat priority for a Fury 
Warrior should be:

Item Level

Mastery

Haste

Versatility

Critical Strike

At the highest level of gear, these stats will shift further due to 
diminishing returns on the most stacked stats, though there is a point where 
you simply cannot get more of one stat without giving up a large portion of 
another. This is why traditional stat weights compared to one point of 
strength are a difficult tool to utilize and it is recommended that players 
regularly sim their own gear upgrades instead.

:::details FAQIs There a Haste Cap for Fury Warriors?
Technically no, as even above 100%, Haste still continues to reduce the
cooldown of rotational abilities and increase the frequency of auto-attacks.

However, there are several breakpoints at which its value will change.
Being a Haste-driven specialization, it remains one of Fury's most important
secondary stats, since more Haste increases the pace of the rotation. This
equates to more Rage, special procs, and better Enrage uptime.

:::

:::details FAQHow Do Diminishing Returns Work?
Intended to smooth out the value of secondary stats and reduce the
propensity for stacking a single one, the amount of secondary stats required
to convert to 1% is reduced at various points. This is calculated by rating,
rather than raw percentage. So it does not include class buffs
like

[[spell:383848]]

or

[[spell:2825]]

, though it will affect
trinkets and other effects which add a flat number.

In practice, this is not something most players need to keep track of,
as the best secondaries tend to remain valuable even beyond the point of
diminishing. It simply reduces the gap between them to ensure that a wider
variety of gear is useful.

:::

2.

### In-Depth Stat Breakdown

Strength is your primary stat, found on plate armor, weapons, and trinkets. 
It provides Attack Power, which contributes to the damage of all abilities and 
auto-attacks.

Haste compresses the rotation, reducing the global cooldown, the time 
between the auto-attack swings, and the cooldown of the rotational abilities 
[[spell:23881]], [[spell:85288]], and [[spell:5308]], as 
well as the speed at which [[spell:46924]] and [[spell:184367]] 
deal damage. While Enrage uptime is generally very high, Haste remains a 
strong stat simply due to the increased action frequency and reducing the 
cooldown of rotational abilities like Bloodthirst and Raging Blow.

Mastery increases the damage bonus provided by [[spell:76856]] 
boosting all damage dealt while [[spell:184361]] is active. Due to the high 
uptime and strong returns, this is a very powerful stat for Fury Warriors.

Critical Strikes deal double damage, although Fury does not generate extra 
Rage on Critical Strike, the way Arms does. This leaves the value of Critical 
Strike typically low.

Versatility provides a flat increase to damage dealt and reduces damage taken
by half as much. Direct damage trinkets, cantrip items, and other outside 
sources of damage value versatility further, due to typically not scaling with 
attack power.

2.1.

#### Racial Bonuses for Fury Warrior

:::details Click for Bloodmallet Simulations
Loading...

For the complete simulation results, check out [Bloodmallet.com](<https://bloodmallet.com/index.html#warrior_fury>)

:::

Racial bonuses have, as a whole, very minimal impact for Fury. Anything 
within 1% of one another is typically considered trivial, and a small enough 
margin that our recommendation is to simply play what you enjoy the most.

2.2.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Added FAQ sections for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated with minor clarifications for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Fury Warrior, based on your [stat priority](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Of the unique-equipped Diamonds, the [[item:240967]] can 
be slightly stronger when using gems of multiple colors, though this can be 
difficult to juggle during early gearing when sockets are limited. The 
[[item:240983]] may therefore be a simpler option.

Haste and Mastery are generally the best stats for Fury 
Warriors, so [[item:240906]] or 
[[item:240892]] should be filled into other slots. When 
using multiple colors to increase the Powerful Diamond bonus, use one Garnet, 
Peridot, and Amethyst, but avoid the Lapsis, since Versatility is not highly 
valued.

2.

### Best Enchants and Weapon Augments

In addition to enchants, players can also apply temporary augments to their 
weapons, two-hour long buffs that increase their damage or statistics. While 
they last through death, these bonuses are not permanent and must be 
reapplied. [[item:243733]] should be used on both weapons for 
more secondary stats.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulder</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li></li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Several enchants present a choice between prioritizing Leech, Speed, or 
Avoidance enchantments, which largely comes down to personal preference, as 
all three provide only minor and largely interchangeable benefits.

3.

### Optimal Consumables

- Flasks: [[item:241322]] or [[item:241325]]
- Best Combat Potion: [[item:241288]] is the best combat potion, though
          it requires very careful allocation of stats to ensure it always 
          provides Mastery. If this is not the case, or upon acquiring 
          [[item:280799]], [[item:271886]] becomes a better 
          option to avoid triggering the wrong secondary stat.
- Healing Potion: [[item:271883]] should be used for healing.
- Food Buff: [[item:255846]] is the best feast. Personal food such as
          [[item:242275]] provides the same offensive benefit, but lacks bonus stamina.
- Augment Rune: [[item:259085]] is the best and only augment
          rune currently available in Midnight.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated recommended weapon enchant and potion description to acknowledge odd statistical situations.
- **10 Aug. 2026:** Updated gems, weapon enchant, and healing potion for Patch 12.1.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **06 Apr. 2026:** Added disclaimer to Potion of Recklessness.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **25 Aug. 2025:** Added temporary enhancements and expanded notes on weapon enchants.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **12 May 2025:** Minor update to Corruption section acknowledging Echoing Void as an alternative.
- **21 Apr. 2025:** Added Patch 11.1.5 Corruption recommendations.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated Onyx Annulet gem recommendations.
- **20 Mar. 2023:** Updated with Onyx Annulet information for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Fury Warrior in World of Warcraft Patch 12.1.5.

1.

### Fury Warrior in Mythic+ in Midnight Season 2

Fury Warriors in Mythic+ are sustained damage dealers that rely on high 
uptime and frequent cooldowns to put out a steady amount of damage, rather 
than short high periods of burst. Though the gameplay is very active, it is 
also very sensitive to downtime, as every second separated away from their 
targets reduces their potential output. For this reason, a good Fury Warrior 
should always be thinking several steps ahead, anticipating which mechanics 
are about to happen, how enemies are going to be moved, when they are going to 
be defeated, and whether a new pack is about to be pulled, in order to ensure 
they stay ahead of the game.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

Slayer and Mountain Thane are incredibly close in Midnight Season 2, 
allowing players more freedom to choose based on preference or group makeup. 
Neither change their talent builds based on dungeon or key level, so the 
gameplay remains very consistent, though there is still some choice between 
supplementary and utility talents.

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane Build

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane Mythic+ Build

Mountain Thane offers better multi-target damage when facing a high number 
of targets, though at the cost of lower priority damage. Class changes for 
Season 2 have also made it more dependent on [[spell:435607]] procs to 
deal competitive damage. While it normally plays very smoothly in spite of 
this, the new tier set bonus is also somewhat clunkier to manage, requiring 
both Bloodthirst and Raging Blow to be weaved into the rotation during every 
cooldown cycle.

The multi-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) Mountain Thane build features short cooldowns 
and a powerful [[spell:6343]] in place of Whirlwind, offering strong 
sustained and consistent multitarget performance with little concern for 
random procs influencing the rotation.

2.2.

#### Flexible Talents

Due to the need to take Thunder Clap and Crackling Thunder, Thane builds do not have much room for talent customization:

- [[spell:184364]] remains a strong defensive bonus and can be taken in place of [[spell:206315]] or [[spell:1265570]], but smart use of [[spell:386208]] should make it unnecessary in most situations.
- [[spell:202163]] is the best potential swap for any other desired talent in the top half of the tree.
- [[spell:1271925]] has limited use cases in most PvE content, but can be swapped with [[spell:384110]] or [[spell:12323]] in the few cases it becomes relevant.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is actively used, though its offensive benefit is lackluster at best. [[spell:382764]] is typically the best drop in heavy multi-target content, though this also necessitates taking [[spell:1243660]] instead of [[spell:1271948]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsYmZGAAIMwGssY0YGAzCmxCgZwAAmZAYYxMAjB"
}
```
:::

:::details 来源计算器编码
```
#IB-CGIMNOdBDFKhgqsy04OXEFRNWm88MNhh9BC-EHJy0KauEGUiwwAJCggw48ANZZ1tQJA-AAAA-IQSU0AEUwAjDmF-*
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Build

2.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer Mythic+ Build

Slayer has made considerable gains in Midnight Season 2, utilizing its new 
Raging Blow build and increased [[spell:445584]] uptime to provide better 
priority damage, though its multi-target performance can still be somewhat 
inconsistent and dependent on getting well-timed [[spell:444775]] procs. It 
is also generally easier to play, thanks to [[spell:386628]] automatically 
casting Bloodthirst to apply the new tier set bonus effect.

The multi-target ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) Slayer build is less powerful and less 
consistent, depending on getting the right number of Sudden Death procs to 
ensure Bladestorm lines up with other cooldowns and [[spell:444775]] 
procs to supplement its multitarget damage. [[spell:1265357]] does make 
its sustained multi-target much more powerful, but requires regularly hitting 
6+ targets to be worthwhile.

2.4.

#### Flexible Talents

Due to the need to take stuns, there is less room for talent customization:

- [[spell:384110]] can be taken in place of [[spell:1271925]] or [[spell:1271926]] any time there are shielded targets. Taking [[spell:1271948]] instead of [[spell:1280961]] may also be worthwhile, trading some defensive benefit for a ranged interrupt.
- [[spell:184364]] remains a strong defensive bonus, though it is difficult to fit into the build without losing damage. Best case, drop either one point from [[spell:354479]] or [[spell:383486]], but smart use of [[spell:386208]] should make it unnecessary in most situations.
- [[spell:1280961]] has amazing defensive potential as long as Defensive Stance is actively used, though its offensive benefit is lackluster at best.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzAAAMzwYWGYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShPDGKUCBVZlpxFFRJm88MNhh59BC-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns, Stops, and Slows

3.1.

#### Interrupts

[[spell:6552]] is the Warrior version of kick, frequently used in Mythic+
to stop enemy casts for the benefit of the group and especially the tank.
Because it is sometimes necessary to interrupt targets other than the one you
are actively attacking, it is **highly recommended** to use a focus or
mouseover macro.

Slayer has the unique ability to use Pummel during [[spell:227847]],
which normally cannot be done.

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] Pummel
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your primary target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a
**Focus Mouseover macro**.

```wow-macro
/focus [@mouseover]
```

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

Not technically an interrupt, [[spell:23920]] is an incredibly
powerful personal tool, which can deflect or reflect the damage and negative
effect of many enemy spells, but only when they are cast on the Warrior.

[[spell:384110]] also provides a ranged silence when 
paired with [[spell:1271948]]!

3.2.

#### Stuns, "Stops", and Slows

[[spell:107570]] and [[spell:46968]] are single and multi-target stuns,
often called "stops" due to their use in stopping enemy actions. Easier to
talent into than the past; these are core talents in any Mythic+ build.

[[spell:5246]] is another AoE stop, fearing targets instead
of stunning them. This has several limitations, causing targets to run away
and potentially call allies, some targets being immune to the
condition outright, and competing with Piercing Howl. Because
of this, the talent is not always taken in Mythic+ builds, but can be added as
desired.

[[spell:12323]] can be used as AoE slows, though this is not 
something that is regularly needed in most content. [[spell:1715]] is the 
non-talented, single-target alternative, which is typically enough to cover 
any slowing needs. Piercing Howl also provides a minor speed buff to allies, 
though its long cooldown renders it incredibly niche.

### Other Utility

3.3.

#### Other Utility

[[spell:6673]] increases the damage output of all melee classes and
Hunters by 5% and should always be active.

[[spell:97462]] is a group-wide defensive cooldown, useful in helping
yourself or allies survive incoming damage. Its effect is also increased by 
50% in non-raid content!

[[spell:18499]] and [[spell:384100]] removes fear and
disorient effects, which are not very common in the modern game. The shout
version applies to allies but suffers several limitations: requiring an extra
talent point, having a very limited range that often misses casters, and only
able to be used reactively after the fear effect has been applied rather than
pre-emptively immuning it. As a result, it is rarely taken, though the new 
[[spell:1271925]] talent can be situationally useful for removing deadly 
debuffs that also have slowing effects.

4.

### Dealing with Affixes

Unlike most classes, Warriors have very few specialized tricks to handle
various mechanics, being mainly focused on personal damage and defense. Most
of the tips and tricks for Warriors constitute negating or returning incoming
spell damage using [[spell:23920]].

The [Targeted 
Spells](<https://www.curseforge.com/wow/addons/targetedspells>) addon is very helpful in knowing when an enemy spell is being cast 
on you, though it cannot tell what that spell is or whether it is reflectable, 
so players will need to learn to identify them on their own.

4.1.

#### Affixes

Midnight Season 2 has only four significant Affixes that offer any kind
of counterplay, called Xal'ataths Bargains. These rotate every week, with only
one of them being active at a time. Many of the Mythic+ affixes, like Fortified or
Tyrannical, simply add a passive effect to the keystone, with these four exceptions
that are seasonally themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that need
  to be interrupted or disrupted. [[spell:46968]] works great here, though 
  [[spell:5246]] can also be used in a pinch.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): A Void Emissary add will spawn with a 
  shield that needs to b e focus-targeted, making it a perfect target for 
  [[spell:384110]] with [[spell:1271948]].
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and circle
  around them. You have 15 seconds to soak all of these to buff your group. Using
  [[spell:12323]] will help the party get to these faster, though be wary 
  of running circles around one another!
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
  healing absorb, which also reduces movement speed, allowing the entire effect 
  to be immediately removed with [[spell:1271925]]. Otherwise, 
  [[spell:202168]], health potions, or Healthstones can be used to help 
  clear the absorb.

Each of the affixes provides a different set of beneficial effects once it is dealt
with, and while they are very powerful, they are not something you play around
in a specific way. The most important part is to not let any of them buff the enemy
trash or bosses.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated build recommendations for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **06 Sep. 2025:** Updated for unannounced hotfix.
- **10 Aug. 2025:** Clarified explanation regarding talent choices.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Tagged recommended builds and validated for Patch 11.0.7.
- **21 Oct. 2024:** Updated Mountain Thane Mythic+ build description and dungeon affix recommendations.
- **09 Sep. 2024:** Updated for The War Within Season 1 launch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Minor update to introduction.
- **22 Apr. 2024:** Updated talent and rotation recommendations for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2 and Season 3.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **12 Jul. 2023:** Minor formatting updates.
- **10 Jul. 2023:** Updated for Patch 10.1.5, to include Shockwave as a recommended talent.
- **01 May 2023:** Updated with better Onslaught build.
- **24 Jan. 2023:** Updated build for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **18 Nov. 2022:** Updated Reckless Abandon and Titanic Rage use and descriptions.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Fury Warrior in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Warriors typically do not need many macros to play effectively, although 
a few can be very nice quality-of-life improvements, such as automating targeting 
reticules and eliminating excess keystrokes.

With the talent loadouts system creating individual action bars for each 
set, there is much less need for macros that switch abilities depending on 
which is talented at the time. That said, [known:######] conditionals will 
allow this, using a talented spell name or ID to determine which ability is 
shown.

Abilities which directly replace one another, like Victory Rush and 
Impending Victory will continue to work regardless of which ability is named 
in the macro.

1.1.

#### Generic Macros for Warriors

#### Recklessness and Avatar

```wow-macro
#showtooltip
/cast Recklessness
/cast Avatar
```

Because they share a base cooldown and are both off the GCD, Recklessness 
and Avatar are often bound together in order to save keystrokes. The order of 
abilities in the macro does not matter in Midnight.

#### Switch Between Thunder Clap and Whirlwind

```wow-macro
#showtooltip
/cast [@player, known:Thunder Clap] Thunder Clap; Whirlwind
```

This will switch [[spell:1680]] to [[spell:6343]] if it is 
talented.

#### Pummel Macro

```wow-macro
#showtooltip Pummel
/cast [@focus, harm, exists][@target] Pummel
```

This macro uses [[spell:6552]] against your focus target, if you have
one, or against your current target if you have no focus target.

#### Automatic Heroic Leap

```wow-macro
#showtooltip Heroic Leap
/cast [@cursor] Heroic Leap
```

This will cast [[spell:6544]] where ever your cursor is located,
without waiting for the targeting circle.

#### Heroic Leap Spam

```wow-macro
#showtooltip Heroic Leap
/cast !Heroic Leap
```

This allows you to spam the [[spell:6544]] button, but still retain
the ground-targeting circle.

#### Charge and Victory Rush

```wow-macro
#showtooltip
/cast Charge
/cast Victory Rush
/cancelaura Bladestorm
```

Because Charge is off the Global Cooldown, Victory Rush or any other melee
ability can be used on the same keybind. When outside of melee range, Charge
will be cast instead. This macro will also cancel Bladestorm to ensure the 
player is not prevented from moving quickly.

#### Charge and Intervene

```wow-macro
#showtooltip
/cast @harm Charge
/cast @harm Victory Rush
/cast @help Intervene
```

Charge and Intervene can also be combined, even alongside Victory Rush if
desired. While this consolidates the abilities down into one keybind, the
dynamic tooltip may not always show the spell you want at all times, so it is
recommended to track them separately.

#### Stance Swap

```wow-macro
#showtooltip
/cast [stance:2]!Defensive Stance;[known:386164]!Battle Stance;[known:386196]!Berserker Stance
```

This allows you to swap between [[spell:386196]] and 
[[spell:386208]] using the same keybind.

1.2.

#### Specific Macros for Fury Warriors

#### Offensive Cooldown Macro

```wow-macro
#showtooltip
/use Recklessness
/use Avatar
/use Blood Fury
/use Berserking
/use 13
/use 14
```

This macro uses off-global cooldown racial abilities and any equipped
trinkets alongside [[spell:1719]].

2.

### Best Addons

2.1.

#### Generic Addons for Warriors

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and maybe you will even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.2.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.3.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.3.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.3.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.3.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.4.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.4.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

2.4.4.

##### Omen Threat Meter

[Omen Threat Meter](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
is the most popular addon for displaying the current threat levels on your
target. We recommend you to use it to avoid taking aggro when the tank is still building
up threat on an enemy.

2.5.

#### Specific Addons for Fury Warriors

Currently, we do not feel that there are any additional addons needed to 
play a Fury Warrior to its full potential, though there is a wide selection 
of user interface addons to help create a better layout for frames, action 
bars, and more.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Pre-Season Launch.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Feb. 2024:** Fixed broken spell link with the Champion's Spear formerly of Bastion.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
