## 专精概览

欢迎来到我们的《魔兽世界》12.1.5补丁 元素 萨满祭司 指南。在这里，你将学习如何在团队副本和大秘境地下城中扮演 元素 萨满祭司：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

元素 大秘境资源

[全新！顶级 元素 天赋配置](<https://raider.io/specs/elemental-shaman/talents>)

[顶级 元素 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/shaman/elemental>)

[元素 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=shaman--elemental>)

[热门 元素 团队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=shaman--elemental>)

1.

### 元素 萨满祭司 概览

元素 萨满祭司是一名伤害输出型施法者，拥有丰富而灵活的工具箱。元素萨满祭司可以应对多种环境而不感到力不从心。该专精在许多场景中拥有无可匹敌的实用性，并且可以定制以适应各种伤害类型。总体而言，该专精在大多数场景中都有相应的工具或天赋。

全面均衡

元素萨满祭司的伤害曲线非常不均匀，在2/3目标顺劈上很吃力，有两个在各种情况下都有用的重要“冷却技能”，并且在单目标和AOE中都有良好的持续伤害。它的循环非常简单，但机动性一般。然而，对爆发冷却的削弱对元素的影响比大多数职业更大，它现在的伤害曲线相当平坦，阻碍了它的实际表现。

单体优秀，功能性和机动性较低

元素 萨满祭司 在单体目标上有很强的数据，但缺乏相对的爆发力，并且在2个目标时非常弱，这在团本中是常见的场景。其机动性一般，

[[spell:79206]]

虽然主动减伤技能很少，但作为远程输出，其被动生存能力相当扎实。此外，在团本中也缺乏独特的功能性选项。

全面强势

元素 Shamans在大秘境中需求量很高，拥有强大、可靠的AOE伤害，同时单体DPS也很高。在Boss之外额外拉小怪对元素非常有利。

萨满还拥有令人难以置信的功能性和控制技能库，可以根据每个地下城进行更针对性的调整。得益于数个天赋，我们在地下城中的被动生存能力非常出色，其中最值得注意的是

[[spell:355630]]

只要有目标可以打断。

地下城表现出色，团本表现平庸

萨满祭司拥有广泛的实用工具，但其中许多是小众的，有些则完全没有被使用，尤其是在团队副本环境中。其他技能只是比其他职业的更差，萨满祭司因此而吃亏。在团队副本中，萨满祭司的技能组合除了他们珍贵的增益外，在外面并不非常有用

[[spell:462854]]

，但在大秘境中，他们灵活的工具箱才真正大放异彩，拥有独特的增益，例如

[[spell:383013]]

,

[[spell:8143]]

或

[[spell:378075]]

。一个可重复施放的

[[spell:370]]

移除敌人身上恶心增益的技能，在需要的情况下也相当强力。

被动技能强大，主动技能薄弱

元素 Shamans以强大的被动生存能力换取了缺乏主动防御手段。他们只是缺少许多其他职业拥有的强力工具，转而依赖显著的被动减伤和治疗。除了你的个人防御技能外，你只能使用你的

[[spell:198103]]

每3分钟一次，以及在万不得已时的

[[spell:20608]]

冷却时间为30分钟。然而，这最后一个技能仍然是游戏中唯一一个不会在开怪时重置的技能，因此你不能在战略上依赖它。不过，萨满在一种情况下会变得异常坚硬，那就是当你能可靠地获得

[[spell:355630]]

时，也就是周围有可打断的施法者时。

高度依赖一个冷却技能

元素在

[[spell:79206]]

之外的机动性一般，这个技能绝不能被误用。总体上它的瞬发技能很少，尤其是在范围伤害场景中，因此明智地利用你仅有的几个软移动窗口尤为重要。必要时，你确实有多种方法可以快速到达目的地，介于

[[spell:192077]]

,

[[spell:192063]]

和

[[spell:2645]]

之间，但这些在伤害方面都有代价，并且不是特别强力。

1.

### 元素 萨满祭司在至暗之夜中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5版本引入了一个新的团队副本首领战， [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)以及一种全新的、令人兴奋的 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)：Kindo'jan迷宫！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

12.1.5版本中元素 萨满祭司没有任何改动，但你可以在我们的页面上找到更新后的推荐 [装备](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)
页面上找到关于新团队副本新装备掉落以及如何花费你的[[item:280562]]的更新建议。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_lavaburst.jpg>) 点击查看上赛季第二赛季的改动
- 显示12.1版本改动隐藏12.1版本改动
  
  
  
  
  2.4.
  
  
  
  
  ### 补丁12.1职业改动
  
  
  
  
  此补丁对元素带来了重大改动：
  
  
  
  
  首先，最值得注意的是，元素在补丁带来的全局“爆发削弱”中受到的打击比大多数专精更重。
  
  
  
  
  - [[spell:114050]]现在使元素过载的伤害提高30%（原为75%）。激活升腾时的额外[[spell:51505]]现在为正常数值的50%（原为100%）。
  - [[spell:191634]] 不再使 [[spell:188196]] 产生额外的 元素 过载。
  
  
  
  
  接着是一些更通用的改动，主要是对直接伤害技能的增强和对 overload 的削弱。请注意，这些削弱与[[spell:114050]]和[[spell:191634]]的削弱叠加，因为它们在很大程度上依赖于 overload：
  
  
  
  
  - [[spell:191861]]已被重新设计：[[spell:188196]]和[[spell:188443]]有15%的几率使你的下一个[[spell:51505]]造成的伤害提高20%，最多可叠加2次。[[spell:51505]]每次消耗一层。
  - [[spell:51505]]伤害提高30%。这不适用于PvP战斗。
  - [[spell:188196]]伤害提高30%。这不适用于PvP战斗。
  - [[spell:188443]]伤害提高60%。
  - [[spell:188389]]伤害提高60%。
  - [[spell:454009]]伤害降低20%。
  - [[spell:1258843]]现在使[[spell:51505]]的伤害提高10%（原为15%）。
  - [[spell:1270061]]现在使元素过载伤害提高10%（原为35%），并使元素伤害提高10%。
  - [[spell:1270062]]现在提供15/30%的暴击伤害加成（原为25/50%）。
  - 来自 [[spell:462840]] 的 [[spell:117014]] 施放现在仅提供 元素 冲击属性增益正常持续时间的 40%（原为 100%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:455110]]已重做，现在使[[spell:188196]]、[[spell:188443]]和[[spell:454009]]的元素过载额外造成10%的伤害。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖的 [[spell:51505]] 现在也会增加等同于你暴击几率的百分比伤害（注意在上个补丁中它们也被调整为受 [[spell:60188]] 影响）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖[[spell:51505]]的伤害降低20%。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖 [[spell:188443]] 现在最多命中 5 个目标（原为 3 个）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖 [[spell:188443]] 的伤害降低了 20%。
  - [[spell:8004]]治疗量提高25%。
  - [[spell:974]]治疗量提高25%。
  - [[spell:5394]]治疗量提高25%。
  - [[spell:462477]]治疗量提高25%。
  - 修复了一个导致[[spell:470057]]未正确受到[[spell:60188]]暴击伤害加成影响的问题。
  - 修复了一个导致[[spell:1258895]]不影响周期性元素伤害的问题。
  - 修复了一个问题，即[[spell:1270062]]未能正确增加若干元素萨满祭司法术的暴击伤害。
  
  
  
  
  请注意，治疗量的改动只是为了跟上补丁带来的全局25%生命值提升。
  
  
  
  
  2.5.
  
  
  
  
  ### 全新第2赛季套装
  
  
  
  
  元素将在至暗之夜第2赛季获得一套强大的全新套装：
  
  
  
  
  - 2件套效果：[[spell:8042]]、[[spell:117014]]和[[spell:61882]]伤害提高25%。
  - 4件套效果：当[[spell:191634]]或[[spell:114050]]消散时，你接下来的2个[[spell:188196]]、[[spell:188443]]或[[spell:51505]]造成的伤害提高25%，并使你的下一个[[spell:61882]]、[[spell:8042]]或[[spell:117014]]消耗的漩涡值减少100%。
  
  
  
  
  2件套加成很直接：更强力的终结技！这既强大又实用，因为 元素 的“终结技”总感觉伤害不太够。
  
  
  
  
  4件套效果有些奇怪，目前存在一些bug或看似非预期的问题。充能技能的伤害会叠加，但"免费"的终结技能充能不会。更重要的是，当我们像往常一样同时使用两个冷却技能时，套装效果只有在两个冷却都结束后才会触发，只提供4层充能技能增益。通常来说，终结技能的充能很容易被浪费，我们希望暴风雪也能让这些充能叠加。[[spell:1259471]]也会一次消耗多层充能技能增益。话虽如此，这仍然是一个相当强力的套装效果，特别是如果上述问题最终得到修复的话。

:::

### 至暗之夜改动概述

2.6.

#### 至暗之夜职业改动总结

[至暗之夜 测试服开发笔记](<https://eu.forums.blizzard.com/en/wow/t/midnight-alpha-test-development-notes/590289>)

开发者笔记：我们在至暗之夜中对元素专精的目标是减少需要跟踪的循环技能和光环数量，使风暴使者天赋更易于使用，并为在AOE中使用火焰法术添加新的玩法。烈焰震击现在可以被替换为一个升级技能——电光烈焰，它会施加6层烈焰震击，并使你的下一个熔岩爆裂击中所有被烈焰震击的目标，类似于之前原初之波的设计。通过这个版本，我们希望允许从施加烈焰震击到AOE熔岩爆裂的快速过渡，以保持简单并跟上对短命生物进行AOE的需求。这是一条可选的天赋路径，因此对于想要专注于闪电和漩涡值消耗技能的玩家来说，这仍然是一种可行的玩法风格。

2.6.1.

##### 影响最大的改动

- [[spell:378270]]被移除了。
- [[spell:210714]]被移除了。
- [[spell:108270]]和[[spell:108285]]被移除了。
- [[spell:192222]]和[[spell:375982]]已被移除，并合并为[[spell:470057]]。
- [[spell:198067]]不再作为天赋或可使用的技能存在。
- [[spell:114050]]现在获得了一个天赋，使升腾召唤一个火焰元素。
- [[spell:192249]]现在仅通过[[spell:191717]]存在。
- [[spell:378779]]被移除了。
- [[spell:462840]]现在从[[spell:191861]]触发。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:454009]]现在可以通过施放[[spell:114050]]以及在消耗漩涡值时随机触发。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：施放[[spell:454009]]现在会赋予一层[[spell:191634]]。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖现在会从[[spell:191634]]（以及仍然从[[spell:443454]]）召唤，而不再从[[spell:375982]]召唤。

2.6.2.

##### 元素是如何被“精简”的

元素和大多数专精一样，在《魔兽世界：至暗之夜》中正在被“精简”。这意味着若干主动和被动技能将被移除，以简化游戏玩法，使其对新手玩家更易上手，不再需要以往通过WeakAuras等插件实现的高度UI自定义。

对元素来说最值得注意的是：[[spell:210714]]、[[spell:375982]]、[[spell:192222]]、[[spell:378270]]和[[spell:108270]]都被移除了，你不再需要手动召唤元素宠物。来自风暴使者英雄天赋的若干技能也得到了简化。总的来说，与当前版本的元素相比，你需要少绑定5到6个按键，并且需要监控的东西也变少了。

不过，内容远不止于此。虽然许多天赋被移除，但也新增了一些天赋；虽然职业天赋树的大部分新增内容至少可以说乏善可陈，但其中确实有一些有趣的东西。此外，许多天赋已被重做或大幅调整。一旦 至暗之夜 于3月2日上线，三个巅峰天赋也将在 元素 天赋树中开放，且每个英雄天赋将获得三个新节点（你还会额外获得3点天赋点，所以它们仍然会被点满）。

2.6.3.

##### 英雄天赋改动

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 的改动主要旨在消除追踪众多不同的 风暴使者 相关触发效果和资源的必要性（或至少是这种感觉）。这一目标达成了，代价是大幅增加了随机性（RNG），不过将旧的 [[spell:454026]] 效果改为让 [[spell:454009]] 获得一层 [[spell:191634]] 的充能会感觉不错。可惜的是，失去 [[spell:470532]] 原本的伤害提升将大幅降低英雄天赋树的强度。值得注意的是，这些改动以及TWW套装的移除将导致风暴触发次数大幅减少，且通常不再有“连锁”触发，这使得该专精更易于掌控，但也不那么刺激了。

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 在移除 [[spell:375982]] 后，先知 改为让 [[spell:191634]] 生成你的先祖是不可避免的，为此在 [[spell:443445]] 中加入了另一个先祖来源，以弥补 [[spell:191634]] 冷却时间变长的问题。其他改动似乎进一步巩固了 先知 专注于单体和2-3目标顺劈的定位。

总而言之， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 的主要吸引力在于机动性更强，很大程度上是因为不需要 [[spell:117014]]，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 非常需要它。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 如果你能应对机动性和额外的复杂度，风暴使者 在大多数情况下现在能造成高得多的伤害，将成为高水平玩家在大多数内容中的首选英雄天赋。

2.6.4.

##### 循环要点

元素 的按键少了很多，输出循环的复杂度也被大幅削减。虽然这对新手、小号或通常喜欢更简单循环的人来说听起来不错，但喜欢当前元素萨的玩家可能会感到失望。在单体目标中，我们又回到了 [[spell:188196]]、[[spell:51505]]、一个消耗技能以及刷新 [[spell:188389]]，仅此而已。

在多目标中，使用 [[spell:470057]] 配合 [[spell:1259471]] 将以少一个按键的方式模拟之前的液态熔岩图腾+始源之潮组合，而失去大裂隙回响和冰怒意味着我们要回到在 [[spell:470057]] 施放之间 spam [[spell:188443]] 和消耗技能（不过你可以加入 [[spell:454009]] 用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 和 [[spell:51505]] 用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 来触发 [[spell:1259471]]）。

移除 [[spell:378270]]、对 [[spell:114050]] 的大幅削弱以及失去 [[spell:192249]]，我们的伤害曲线将变得更加平缓。

2.6.5.

##### 职业树改动

在所有天赋都被移除而没有任何新天赋加入的情况下，我们的职业树变得相当小，虽然我们之前在任何团队副本中都有足够的点数来获取我们想要的一切，但现在你几乎可以获得地下城甚至PvP中所需的一切，除了选择节点外，你不需要太多更改你的职业树。

[[spell:355630]] 在大多数情况下是一个受欢迎的生存增益，尽管它不再叠加确实意味着我们在某些怪物群中不再无敌。[[spell:198103]] 的改动总体上相当中性，但在实际中在大多数战斗中可能算是轻微的增益，虽然它无法弥补失去 [[spell:108270]] 的损失。

新的 [[spell:1217622]] 相当不错，它将使我们和一名指定的盟友在团队副本或地下城中获得可观的免费治疗。它的姊妹天赋 [[spell:462477]] 有可能被使用，但需要追踪更多的东西，而且收益很小。

2.7.

#### 元素 萨满祭司 的至强天赋：反馈循环

至暗之夜 引入了“至强”天赋，这些天赋应该与普通天赋不同，但对于 元素 来说，它们基本上只是“更多的伤害”，并不会以任何方式真正影响你的游戏方式，你只是稍微多获得一些元素之力，而且它们使精通更有价值。在大多数情况下，它们是“造成更多伤害”的天赋，但由于它们的数值调得非常高，在任何情况下它们都是绝对必选的。

- **至强天赋：**[[spell:1270061]] — 元素 过载伤害提高35%。
- **至强天赋：**[[spell:1270062]] — 法术暴击几率提高5%/10%。[[spell:60188]] 使法术暴击伤害额外提高25%/50%。
- **至强天赋：**[[spell:1270064]] — 元素 过载有25%的几率触发额外的 元素 过载。每次施法只能触发一次。

2.8.

#### 萨满祭司 职业树改动

每个专精现在通过 萨满祭司 天赋树自动学习一个法术而不是两个，这意味着你现在需要花费一个点数来学习 [[spell:188443]]。

[[spell:51505]] 基础伤害降低20%，但其伤害现在会随你的暴击几率而提高。

部分技能的治疗量已提高：

- [[spell:8004]] 治疗量提高130%
- [[spell:5394]] 治疗量提高50%。
- [[spell:974]] 治疗量提高50%
- [[spell:30884]] 治疗量提高100%（从最大生命值的20%提高到40%）
- 新增天赋：
  
  
  
  
  - [[spell:1270375]] — 精通提高3%。
  - [[spell:1270350]] — [[spell:192106]] 使你的智力提高3%。施放闪电盾也会对自己施加 [[spell:974]]，如果已学会的话，还会对任何武器附魔施加。
  - 之前专属于 恢复：[[spell:1217622]] — [[spell:974]] 不再消耗层数，效果为115%（与 [[spell:462477]] 的选择节点）
  - 之前专属于 恢复：[[spell:462477]] — 刷新 [[spell:974]] 时，你的目标会根据其缺失的大地之盾层数获得治疗。此外，大地之盾可以快1.0秒消耗层数。（与 [[spell:1217622]] 的选择节点）
- 天赋被移至其他位置或被移除：
  
  
  
  
  - 数个天赋在天赋树中的位置发生了变化。
  - [[spell:51490]] 现在是所有 元素 萨满在30级学会的基础技能。
  - [[spell:305483]] 现在是一个PvP天赋。
  - [[spell:108270]] 已被移除。
  - [[spell:108285]] 已被移除。
  - [[spell:381819]] 已被移除。
  - [[spell:383011]] 已被移除。
  - [[spell:383012]] 已被移除。
  - [[spell:108285]] 已被移除。
- 修改过的天赋：
  
  
  
  
  - [[spell:57994]] 打断持续时间提高到4秒（原为2秒），不影响PvP战斗。
  - [[spell:1064]] 施法时间现在为2秒（原为2.5秒），跳跃范围现在为20码（原为15码）。
  - [[spell:383013]] 现在是与 [[spell:8143]] 的选择天赋
  - [[spell:355630]] 更名为 [[spell:355630]] 并重新设计——用 [[spell:57994]] 打断法术后，你受到的法术伤害降低15%，持续12秒
  - [[spell:382215]] 现在是一个2点天赋——使你的移动速度提高3%/6%，并使 [[spell:2645]] 的移动速度加成额外提高5%/10%。
  - [[spell:381655]] 现在是一个2点天赋，每级提高自然法术暴击几率2%。
  - [[spell:198103]] 现在持续30秒（原为1分钟），冷却时间为3分钟（原为5分钟）。
  - [[spell:381689]] 现在是一个2点天赋——耐力提高8%/15%。当你生命值全满时，[[spell:20608]] 的冷却速度加快50%/100%。
  - [[spell:30884]] 治疗量提高到最大生命值的40%（原为20%）。
  - [[spell:381650]] 现在使你受到的魔法伤害降低8%（原为6%）。
  - [[spell:265046]] 现在是一个2点天赋——使 [[spell:192058]] 的冷却时间缩短8秒/15秒。
  - [[spell:462762]] 已被重新设计——现在使 [[spell:196840]] 的冷却时间延长15秒，并使 冰霜 震击将目标冻结在原地4秒。
  - [[spell:381867]] 使大多数图腾的冷却时间缩短5秒（原为6秒），不再对 [[spell:192077]] 或 [[spell:355580]] 生效。
  - [[spell:1279819]] 已被重新设计——你的 [[spell:198103]] 不再嘲讽附近的敌人或产生威胁值，而是在激活期间使你的最大生命值提高15%。土元素 元素 不再提高 萨满祭司 的最大生命值。此效果已移至原始羁绊。

在所有天赋都被移除而没有任何新天赋加入的情况下，我们的职业树变得相当小，虽然我们之前在任何团队副本中都有足够的点数来获取我们想要的一切，但现在你几乎可以获得地下城甚至PvP中所需的一切，除了选择节点外，你不需要太多更改你的职业树。

[[spell:355630]] 在大多数情况下是一个受欢迎的生存增益，尽管它不再叠加确实意味着我们在某些怪物群中不再无敌。[[spell:198103]] 的改动总体上相当中性，但在实际中在大多数战斗中可能算是轻微的增益，虽然它无法弥补失去 [[spell:108270]] 的损失。

新的 [[spell:1217622]] 相当不错，它将使我们和一名指定的盟友在团队副本或地下城中获得可观的免费治疗。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_lavaburst.jpg>) 点击查看更详细的补丁说明
2.9.

#### 元素 专精树改动

元素 从精通获得的伤害加成降低10%。

- 新增天赋：
  
  
  
  
  - **至强天赋：**[[spell:1270061]] — 元素 过载伤害提高35%。
  - **至强天赋：**[[spell:1270062]] — 法术暴击几率提高5%/10%。[[spell:60188]] 使法术暴击伤害额外提高25%/50%。
  - **至强天赋：**[[spell:1270064]] — 元素 过载有25%的几率触发额外的 元素 过载。每次施法只能触发一次。
  - [[spell:1273485]] — [[spell:51505]] 伤害提高5%。熔岩爆裂和熔岩爆裂过载额外产生1点元气。
  - [[spell:1258899]] — [[spell:8042]]、[[spell:117014]] 和 [[spell:61882]] 造成20%的额外伤害。与 [[spell:273221]] 的选择。
  - [[spell:1258843]] — [[spell:51505]] 造成15%的额外伤害。与 [[spell:16166]] 的选择
  - [[spell:1258895]] — 所有 元素 伤害提高3%。与 [[spell:462742]] 的选择。
  - [[spell:1258889]] — 使 [[spell:1258895]] 的效果提高2%，使雷击触发的几率提高30%，并使雷击伤害提高75%。
  - [[spell:1259047]] — [[spell:188196]]、[[spell:454009]]、[[spell:188443]]、[[spell:8042]]、[[spell:117014]] 和 [[spell:61882]] 对受 [[spell:188389]] 影响的目标造成的伤害提高15%。
  - [[spell:470057]] — 立即用炽烈的雷霆震击目标和10码范围内的5个敌人，施加 [[spell:188389]] 并造成大量自然伤害。总是暴击。取代 烈焰震击。
  - [[spell:1259471]] — [[spell:470057]] 释放出火山之怒，使你的下一个 [[spell:51505]] 施法以80%的效果命中所有 [[spell:188389]] 过的目标，元气生成量减少。熔岩爆裂伤害提高10%。
  - [[spell:378255]] — 使用 [[spell:114050]] 时会召唤你的 [[spell:198067]]。
  - [[spell:1269215]] — [[spell:470057]] 的冷却时间缩短3秒/6秒，其自然伤害提高50%/100%。
  - [[spell:1269364]] — 智力提高3%。
  - [[spell:1269360]] — 急速提高3%。
  - [[spell:381784]] — [[spell:188389]] 伤害提高100%。
- 被移除的天赋
  
  
  
  
  - [[spell:384087]]
  - [[spell:198067]] 不再作为天赋存在，现在只有在使用 [[spell:378255]] 天赋并按下 [[spell:114050]] 时才会出现
  - [[spell:378270]]
  - [[spell:192222]]
  - [[spell:375982]]
  - [[spell:210714]]
  - [[spell:192249]]
  - [[spell:468574]]
  - [[spell:382042]]
  - [[spell:378271]]
  - [[spell:381776]]
  - [[spell:381932]]
  - [[spell:462865]]
- 修改过的天赋：
  
  
  
  
  - 数个天赋在天赋树中的位置发生了变化。
  - [[spell:318038]] 现在取代 [[spell:382027]]，没有该天赋时不再存在，防止新玩家在没有该天赋时使用旧的基础技能，因为该技能对 元素 没有任何效果。
  - [[spell:462695]] 已被重新设计——现在使 [[spell:188196]]、[[spell:454009]] 和 [[spell:188443]] 的施法时间缩短15%。
  - [[spell:114050]] 在升腾激活期间现在使 元素 过载的伤害提高75%（原为150%）。在PvP战斗中仍为25%。
  - [[spell:462840]] 已更新——消耗 [[spell:191861]] 会额外向你的目标发射一个以40%效果生效的 [[spell:117014]]。
  - [[spell:462866]] 现在使造成的伤害提高6%（原为10%）。
  - [[spell:191861]] 的触发几率降低到15%（原为60%）。
  - [[spell:61882]] 现在造成自然伤害（原为物理伤害）。
  - [[spell:191717]] 现在召唤一个高等风暴 元素（原为高等闪电 元素）。
  - [[spell:468571]] 已被重新设计——现在使 [[spell:191634]] 的冷却时间缩短15秒。
  - [[spell:188389]] 的施加逻辑已针对 [[spell:470057]] 进行更新，优先选择敌方玩家并忽略处于可解除控制效果中的敌人。
  - [[spell:382032]] 现在使 元素 过载伤害提高25%（原为40%）。
  - 原始 [[spell:192249]] 的 [[spell:269005]] 现在在4秒内造成全部伤害（原为8秒）。
  - [[spell:198067]] 的 [[spell:319836]] 伤害提高500%。
  - 原始 [[spell:198067]] 的 [[spell:118297]] 伤害提高500%。
  - 原始 [[spell:198067]] 的 [[spell:117588]] 伤害提高300%。
  - [[spell:192249]] 的 [[spell:157331]] 伤害提高100%。
  - [[spell:192249]] 的 [[spell:157348]] 伤害提高100%。
  - 原始 [[spell:192249]] 的 [[spell:269005]] 伤害提高100%。
  - 修复了在点出 [[spell:117013]] 天赋时 [[spell:191717]] 不会召唤原始 [[spell:192249]] 的问题。
  - [[spell:117013]] 现在只给予对你的原始 [[spell:198067]] 的直接控制（原为控制全部3个元素）。
  - 移除了当你拥有足够元气施放 [[spell:8042]]、[[spell:117014]] 或 [[spell:61882]] 时出现的激活覆盖层。
  - [[spell:273221]] 返还元气时现在会播放音效。

这些改动最直接的后果是你的按键数量大幅减少，循环的复杂性被大幅削减。虽然这对新玩家、小号或通常更喜欢简单循环的人来说听起来不错，但喜欢当前元素萨满的人可能会感到失望。在单体目标中，我们又回到了 [[spell:188196]]、[[spell:51505]]、一个消耗技能和 [[spell:188389]]，仅此而已。

移除 [[spell:378270]]、对 [[spell:114050]] 的大幅削弱以及失去 [[spell:192249]]，我们的伤害曲线将变得更加平缓。

2.10.

#### 英雄天赋改动

- 新增天赋：
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:1264691]] — 自然伤害提高2%
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:1264688]] — [[spell:114050]] 将你的下一个 [[spell:188196]] 升级为 [[spell:454009]]
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:1264762]] — [[spell:192249]] 持续时间延长2秒，[[spell:191634]] 产生10点元气。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:1270446]] — 每有一个激活的先祖，你的智力就提高1%。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:1270447]] — [[spell:8004]]、[[spell:1064]] 和 [[spell:51505]] 的施法时间缩短10%。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:1270450]] — 在施放 [[spell:443454]] 后的8秒内，使 [[spell:77756]] 触发的几率提高20%。
- 修改过的天赋：
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:454009]]不再基于消耗的风暴之力总量触发，现在每次消耗风暴之力有0.3%的几率触发。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:455129]]已被重新设计——现在每消耗一点风暴之力，额外增加0.3%的几率获得[[spell:454009]]。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:454026]]已被重新设计——现在使[[spell:191634]]的冷却时间缩短15秒。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者：[[spell:470532]]已被重新设计——现在使[[spell:454009]]获得一层[[spell:191634]]。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:467646]]已更新——[[spell:191634]]召唤一位先祖到你身边，持续8秒（原为6秒且为[[spell:375982]]）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:443445]]现在也可以由[[spell:188389]]和[[spell:470057]]触发。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:443418]]使[[spell:51505]]的伤害提高10%（原为20%）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：[[spell:443451]]现在在召唤先祖时使[[spell:191634]]的冷却时间缩短3秒（原为使[[spell:198067]]/[[spell:192249]]的冷却时间缩短5秒）。
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知：先祖现在持续8秒（原为6秒）。

这些 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 的改动主要旨在消除追踪众多不同的 风暴使者 相关触发效果和资源的必要性（或至少是这种感觉）。这一目标达成了，代价是大幅增加了随机性（RNG），不过将旧的 [[spell:454026]] 效果改为让 [[spell:454009]] 获得一层 [[spell:191634]] 的充能会感觉不错。可惜的是，失去 [[spell:470532]] 原本的伤害提升将大幅降低英雄天赋树的强度。值得注意的是，这些改动以及TWW套装的移除将导致风暴触发次数大幅减少，且通常不再有“连锁”触发，这使得该专精更易于掌控，但也不那么刺激了。

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知的这一变化是移除[[spell:375982]]后的必然结果，同时在[[spell:443445]]中新增了另一个先祖来源，以弥补[[spell:191634]]冷却时间较长的问题。其他改动似乎进一步巩固了先知专注于单体和2-3目标顺劈的定位。

:::

1.

### 元素 萨满祭司基础玩法

元素 萨满祭司是一个单体和AOE基础手法都很简单的专精，天赋提供了大量自定义选择。有些天赋可以让元素非常容易上手，也可以非常复杂且富有回报。

在单体战斗中，你的大部分时间将用于施放[[spell:51505]]和[[spell:188196]]，同时保持[[spell:188389]]，并在拥有足够风暴之力时施放[[spell:8042]]或[[spell:117014]]。除了这些基础内容之外，玩法很大程度上取决于你的天赋选择。尽管如此，这个专精仍然可以归结为这三个主要概念。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_lightning.jpg>) **ABC：永远保持施法（Always Be Casting）**
  
  
  
  
  这是大多数施法者的基本功，但对元素来说尤其如此。犹豫永远是坏事。拿不准的时候，按点什么，不要只是站在那里。与其他专精不同，你不会犯下危及输出的致命错误。这也意味着你应该随时都能施法。确保自己保持在射程内，并经常移动，以便处于持续输出伤害法术的最佳位置。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritwalkersgrace.jpg>) **使用你的冷却技能**
  
  
  
  
  不要长时间捏着[[spell:114050]]或[[spell:191634]]不放。拿不准的时候，用掉它们！这对非伤害类冷却技能同样适用。需要移动？按下[[spell:79206]]。即将承受伤害？按下[[spell:108271]]！新手元素萨最常见的错误之一就是冷却技能使用不足。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_flameshock.jpg>) **保持烈焰震击不断，风暴之力不溢出！**
  
  
  
  
  特别是在单体目标中，你应该始终让目标身上保持 [[spell:188389]]，因为它能使 [[spell:51505]] 自动暴击。如果你有 [[spell:470057]]，在几乎所有情况下只要它可用就按下。相反，确保你通过施放消耗技能来消耗漩涡值，不注意的话很容易“溢出上限”从而损失大量伤害！

1.

### 如何为 元素 萨满祭司 配装

虽然我们始终建议你自己跑模拟以获得理想结果，但我们确实提供了一个专门的 元素 配装页面。我们目前提供了第二赛季装备的推荐，以便为终局 至暗之夜 内容的发布打好基础。在你拿到一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 为12.1.5补丁更新，新增至尊毒石章节，用基希克斯的物品更新了毕业装备。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年10月2日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了仅限团本毕业装备列表中头盔的催化剂来源为 内克扎莉。
- **2026年8月26日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了最佳武器附魔为哈希伊仪式。
- **2026年8月26日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 更新了最佳武器附魔为哈希伊仪式。
- **2026年8月19日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 根据热修复更新了制作建议，更新了饰品章节。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 新增了关于不要提前用 猎人 的仪式石制作副手的警告，重述了大秘库常见问题解答。
- **2026 年 8 月 17 日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 更新了推荐宝石，以最大化永恒之力钻石的价值。
- **2026 年 8 月 17 日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为 至暗之夜 第二赛季更新，新增了每个地下城推荐功能型天赋的速查表。
- **2026年8月14日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了毕业装备和推荐制作装备，加入了用 猎人 的仪式石制作的副手。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了推荐宝石。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 为12.1补丁更新，新增了“核心思路”要点。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 将孢子凝聚物品添加到最佳装备列表中，已更新至12.0.7补丁。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 添加了万法大全（Omnium Folio）部分。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年5月20日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 更新了驱散/净化宏。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月10日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了制作部分，添加了关于新手斗士项链的一段内容。
- **2026年4月7日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了饰品部分。
- **2026年4月3日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 重新表述了关于元素元素爆裂在4个或更多目标上的句子，以更清楚地说明你应始终保持至少一个来自它的增益效果。
- **2026年4月1日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了制作选项，加入了制作腿部、腰带或靴子。
- **2026年4月1日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 将推荐附魔更新为鹰眼。
- **2026年3月28日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 为推荐的武器附魔放上了正确的链接。
- **2026年3月28日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了先知先知副本天赋中使用的天赋。
- **2026年3月24日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 从4个或更多目标的循环中移除了不必要的行。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了更多饰品并更新了饰品排名。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 移除了关于茶的提及，因为它们已被热修复为不再在副本中生效，添加了个人食物推荐。
- **2026年3月23日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为每个地下城添加了关于功能性法术具体用途的额外信息，更新了功能速查表。
- **2026年3月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 更新了关于风暴守护者的循环建议，以免玩家延迟使用它太久。
- **2026年3月21日（本页）：** 已根据最新的平衡性调整进行更新。
- **2026年3月20日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了先知先知副本天赋，推荐在虚空尖塔中对抗光盲先锋军光盲先锋军时使用。
- **2026年3月20日（本页）：** 由于在团队副本战斗中表现不佳，更新了表现概览。
- **2026年3月19日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了饰品排名和毕业装备，添加了被遗忘的远行者徽记。
- **2026年3月19日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 由于顺劈和目标切换情况占主导，将团队副本天赋中的风暴注入替换为充能导管。
- **2026年3月17日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 将第二个推荐制作部位改为腿部。添加了作为法杖替代品的等效双手锤制作的提及。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 将AOE部分拆分为3个目标和4个或更多目标以提高可读性。调整了AOE循环中的一些内容。将风暴使者风暴使者设为默认选项。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修正了多目标起手循环，在勾选净化烈焰时显示电光烈焰，而不是显示VB。澄清/调整了3/4+目标循环部分中的一句话。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 添加了更多关于通用升级信息和传承装备的链接，并针对至暗之夜第1赛季进行了审查。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜第一赛季更新并重新组织。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对至暗之夜上线进行了审查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 添加了关于茶类烹饪物品提供可与属性食物的吃饱效果叠加的速度增益的提及，调整了武器附魔和宝石推荐。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 已针对至暗之夜第一赛季更新，添加了第一赛季图片区块。
- **2026年3月4日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 移除了一个句子的部分内容，该部分主要对至暗之夜前夕才有意义。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜上线重新组织并更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 添加了一键复制整个宏的功能。已针对至暗之夜上线更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜上线进行了审查。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（本页）：** 已针对至暗之夜上线重新组织并更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 更新了天赋树以反映职业门槛解锁的变更。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜前夕更新。添加了关于至暗之夜有用升级装备的部分。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 调整了关于武器油的部分。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了电光烈焰和元素大师的反向条件开关。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 为职业门槛解锁的改动更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对至暗之夜前夕进行更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 更新了天赋树以反映职业门槛解锁的变更。
- **2026年2月10日（本页面）：** 修复了职业和专精变更图片区块标题的颠倒问题。
- **2026年1月22日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了团本配装以适应至暗之夜前夕中的新短时长战斗。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜前夕更新。添加了关于升级消耗品的部分。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对至暗之夜前夕进行更新。
- **2026年1月19日（本页）：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对11.2.5版本进行了审查，添加了常见问题解答区块。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.7版本进行了审查，添加了常见问题解答区块。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对11.2.7版本进行了审查，添加了常见问题解答区块。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 已针对11.2.7版本更新，将优势与劣势改版为表现评估。
- **2025年10月27日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了黑帮代币部分，说明你只需完成你想要物品所在特定地下城的+12即可。移除了珠宝的提及。
- **2025年10月6日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 修复了高阶蛛魔印记的来源，它来自破晓号角而非阿拉卡拉。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了推荐的专业技能和镶边，新增了令人费解的财团筹码部分。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新，新增了关于军团再临幻境和涡轮增压模式的部分。
- **2025年9月18日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 修复了天赋中的一个复制粘贴错误，该错误导致团队副本配装在拥有套装时仍然使用原始元素代替液态岩浆图腾，以及使用上古结伴英雄天赋而不是潜在智慧。
- **2025年9月7日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 移除了关于本页面基于不拥有任何套装构建的免责声明。
- **2025年9月2日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了推荐，以假设拥有新套装为前提。
- **2025年9月2日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 将配装改为“通用”的先知配置，与新套装搭配更为合理。
- **2025年8月20日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在多目标循环中新增了在没有液态岩浆图腾时使用原初之波，以及在3个或更少目标上保持一个烈焰震击。
- **2025年8月17日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新以反映虚空玻璃武器在热修后不再为元素提供护盾的事实。因此，将钻石虚空核心在大秘境中降了一级。
- **2025年8月15日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 新增了一句话，关于先知2件套加成倾向于全能。
- **2025年8月15日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 更新了关于先知大秘境配装的推荐。
- **2025年8月15日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了关于先知大秘境配装的推荐。
- **2025年8月14日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 进一步更新了饰品排名。
- **2025年8月14日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 新增了WeakAura插件包的选择，以及风暴使者专属的WeakAuras和一个可选的融合用WeakAura。修复了先祖迅捷宏重复的问题。
- **2025年8月12日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 根据最新的热修复更新了饰品排名。
- **2025年8月12日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 新增了更多地下城技巧。
- **2025年8月12日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在双目标场景中为风暴使者（SB）简化了闪电链的使用（效果持平）。
- **2025 年 8 月 10 日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 修复了 先知 大秘境配装未使用大地震击的问题。
- **2025 年 8 月 10 日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 优化了单体目标中Storm 元素的使用，烈焰震击 / 液态熔岩图腾的使用。
- **2025 年 8 月 10 日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 修复了 先知 大秘境配装未使用大地震击的问题。
- **2025年8月9日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 将披风纤维的推荐属性调整为精通，以避免误导玩家专门堆叠全能。
- **2025年8月8日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 在饰品排行中添加了更多饰品，并重新调整了部分排序。
- **2025年8月7日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 更新了先祖迅捷宏命令部分。
- **2025年8月5日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 修复了“适合早期大秘境玩家的即时提升选择”推荐中误将匕首写成法杖的问题。
- **2025年8月5日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 添加了关于急速/全能波动性的说明。
- **2025年8月5日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在APL优化之后，更新了冰霜震击和大地震击的使用。
- **2025年8月5日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 修复了团队副本天赋推荐中的一处笔误：在新四件套效果下，你需要用液态熔岩图腾替换元素宗师，而非二件套。
- **2025年8月5日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 移除了风暴召唤宏，因为它有时会出错且是坏习惯。更新了属性优先级。
- **2025年8月5日（本页）：** 在APL改进之后，调整了一些关于冰霜震击和大地震击使用的说明。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已为11.2版本及第3赛季更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已为11.2版本更新并审核。移除了风暴召唤/闪电链宏（不可靠且非最优）。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已为11.2版本更新并审核。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已为11.2版本更新并审核。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已为11.2版本和第3赛季更新并审核。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2版本更新并审核。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已为11.2版本更新并审核。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已为11.2版本更新并审核。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 添加了说明：本部分适用于没有套装的玩家。已为11.2版本审核。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年7月8日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了“DISC”腰带部分，并在BiS列表中添加了最佳默认选择。
- **2025年7月8日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 修复了天赋树损坏的 先知 团队副本配装。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了关于新“DISC”腰带的新部分。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 为11.1.7补丁更新。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为11.1.7补丁更新。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于新战斗助手系统的部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 为11.1.7补丁更新。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 添加了关于新战斗助手系统的部分。
- **2025年6月15日（本页）：** 已用11.1.7版本信息更新。
- **2025年5月27日（[解放安德迈页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 在史诗难度独臂强盗和加里维克斯战斗中，用液态熔岩图腾替换了深渊之涌。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了关于谜之卡特尔筹码的部分。
- **2025年4月25日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了关于谜之卡特尔筹码的部分。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了BiS饰品，添加了关于伪造商贩筹码的部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 为惊魂幻象添加了腐蚀附魔部分。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在同时使用元素冲击和回响之大分裂的单体目标构建中，移除了大地震击的使用。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 在单体循环中添加了图片区块、关于 先知 的提及以及原始浪潮选项。选择了地壳图腾而非急流。
- **2025年4月21日（本页）：** 已为11.1.5版本更新并审核。
- **2025年3月29日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了总体BiS戒指和饰品。
- **2025年3月29日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 重新添加了因误操作而被吞掉的元素冲击天赋选择行。
- **2025年3月29日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了一处破坏行内容的笔误，调整了在AOE中使用元素融合的条件。
- **2025年3月29日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 重新添加了风暴使者构建中因误操作而被吞掉的元素冲击天赋选择行。为先知构建添加了液态熔岩图腾选项。添加了关于史迪奇·朋克机作为可以使用风暴使者的首领的提及。
- **2025年3月18日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了Brewterializer宏使其更可靠。
- **2025年3月18日（[解放安德迈页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 调整了一些天赋选择，为加里维克斯添加了防御性使用，为史迪奇添加了一个风暴使者构建选项。
- **2025年3月18日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 将默认检查项改为 先知。
- **2025年3月7日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了塞尔西的指环信息，添加了套装升级建议。
- **2025年3月7日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 为风暴使者用户添加了风暴打击+闪电链宏。
- **2025年3月7日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 更新了推荐内容，使其不过于偏向纯单体。
- **2025年3月7日（[解放安德迈页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了铬金大王加里维克斯的推荐。
- **2025年3月7日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了一些疏漏，澄清了若干选项/场景。
- **2025年3月7日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 重新表述了关于使用喷涌岩浆可能性的说明。
- **2025年3月7日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 添加了一个推荐宏。
- **2025年3月3日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 更新为更通用的配装。
- **2025年3月1日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为数个地下城添加了更多推荐的实用工具。
- **2025年3月1日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更精确地标明了必选/可选天赋。为大秘境的先知构筑添加了「大分裂之回响」。
- **2025年3月1日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 添加了几个正在使用的缩写，更新了「电弧放电」的说明。
- **2025年3月1日（本页）：** 根据以下变更更新了套装部分。
- **2025年2月28日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了饰品排名。
- **2025年2月27日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 调整了推荐的战争模式天赋。
- **2025年2月27日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了单手武器和盾牌选项。添加了更多关于「协同酿菌器」的信息。
- **2025年2月27日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 添加了应对恰好2个目标时的具体信息，为在AOE中正确使用「冰怒」添加了许多条件说明。
- **2025年2月25日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了饰品排名。将催化剂添加为套装部件的获取来源。
- **2025年2月25日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 为更多构筑添加了细节。
- **2025年2月25日（[解放安德迈页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2025年2月25日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了循环/起手条件中的一些问题。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对11.1补丁全面更新和审阅。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 添加了时间螺旋"滥用"宏。已针对11.1补丁进行审阅。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.1补丁更新和审阅。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对「地心之战」第2赛季更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对11.1补丁更新和审阅。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对11.1补丁进行更新。
- **2025年2月24日（本页面）：** 已针对11.1补丁更新和审阅。
- **2025年2月20日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对11.1补丁和第2赛季全面更新。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了关于「瑟克尔的王冠」的部分，并将其添加到所有毕业装备列表中。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了关于「瑟尔西的王冠」的部分，并将其添加到毕业装备列表中。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 在更多先知实践后调整了推荐的天赋构筑。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 添加了"推荐"标签。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对11.0.7补丁更新和审阅。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已针对11.0.7补丁更新和审阅。
- **2024年11月26日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 由于先知的加强，调整了推荐的天赋构筑（先知现在在纯单体目标中推荐使用）。
- **2024年11月26日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 根据11月26日的加强调整了先知循环。
- **2024年11月26日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已更新至11月26日的先知增强，单体战斗中现在推荐使用先知。
- **2024年11月26日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已更新至11月26日的在线修正。
- **2024年11月26日（本页）：** 已更新至11月26日的先知增强。
- **2024年11月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了单体循环中多余的风暴打击行。
- **2024年11月4日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 调整了关于单体中双风暴打击使用的措辞。
- **2024年11月2日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了多目标起手中意外重复的一行。
- **2024年10月31日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 将风暴打击在单体优先级中的位置提高。为部分构建添加了更详细的烈焰震击使用说明。
- **2024年10月31日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 重新加入了专门的地下城构建。调整了先知构建。添加了专门的纯单体构建。
- **2024年10月30日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已更新至最近的元素调整，修复了一些错别字。
- **2024年10月29日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了一些大地震击和元素冲击的行。修复了多目标循环中与回响之大地撕裂相关的行。
- **2024年10月26日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 强调了拥有任意间谍大师之网饰品的重要性。
- **2024年10月26日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 调整了推荐天赋构建。
- **2024年10月26日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 将起手和循环放入图片区块，添加了针对先知/风暴使者、元素冲击/大地震击、能量涌动、回响之大地撕裂、原初之波和液体熔岩图腾的循环切换。
- **2024年10月26日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 调整了灵活天赋部分的一些措辞。
- **2024年10月25日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 完全更新了仅限大秘境的毕业装备列表。添加了更多替代选择。
- **2024年10月25日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为先知用户添加了说明。调整了循环以更好地叠加冷却时间来优化升腾。优化了单体中的双风暴打击使用。
- **2024年10月25日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 将 先知 配装调整为喷涌岩浆变体，添加了“无脑”简易大秘境配装。
- **2024年10月23日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了无羁变形者的推荐属性。为没有间谍大师之网的玩家将背叛者发射器加入S级。添加了在没有原初之波的情况下使用暗影之风的警告。
- **2024年10月23日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 将风暴骑手的狂怒替换为缚石工艺作为武器附魔选项。
- **2024年10月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在单体优先级列表中添加了常规烈焰震击选项。在优先级列表中添加了岩浆爆裂以消耗原初之波。澄清了单体优先级列表中的冰霜怒击行。
- **2024年10月23日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 小幅天赋调整。在通用构建中用涌动之涡替换风暴之眼。添加了不使用原初之波的替代构建。
- **2024年10月22日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已为11.0.5版本更新并审查。
- **2024年10月22日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已为11.0.5版本更新并审查。
- **2024年10月22日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月22日（本页）：** 已针对11.0.5补丁进行更新。
- **2024年10月1日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 在总毕业装备列表中添加了项链、戒指和武器的装饰替代选择。
- **2024年10月1日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 调整了部分副本专属天赋推荐。
- **2024年9月23日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 为安苏雷克女王添加了更多提示。
- **2024年9月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 调整了多目标闪电循环中的一行描述，使其更清晰。添加了一行针对 先知 的专属内容。
- **2024年9月16日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了关于专业制造和装饰的更详细信息。调整了饰品推荐，新增了更多饰品。调整了仅限大秘境的护肩推荐。
- **2024年9月16日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 调整了部分天赋推荐。调整了针对安苏雷克女王和其他首领的部分提示。
- **2024年9月13日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 移除了赛季前最佳装备列表。
- **2024年9月13日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 为安苏雷克女王添加了一些提示。
- **2024年9月10日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 添加了更多武器附魔选项。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 重新整理了页面，添加了3个不同的最佳装备列表，为《地心之战》第1赛季进行了更新，调整了装饰推荐。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 移除了不必要的宏，添加了先祖迅捷宏。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 调整了亵渎宝石、披风附魔、护腕附魔的推荐。重新措辞了一句话使其更清晰。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 更新了部分措辞，移除了不必要的句子。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 全面更新并重新整理了页面，添加了多种配装及其用途、特定副本配装和信息、额外的技能和词缀推荐。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 移除了关于“混合”配装的提及。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 添加了一个 先知 闪电大秘境配装，重新排列了天赋配装并调整了推荐，移除了对混合配装的提及。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 对推荐的天赋树进行了轻微调整。
- **2024年9月9日（本页）：** 已针对《地心之战》第1赛季更新。
- **2024年9月6日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 移除了一句现在应该不再必要的句子。
- **2024年8月30日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了最佳装备列表以明确头盔属性，并说明亵渎之芽是我们最好的饰品。调整了饰品和装饰推荐。
- **2024年8月30日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 修正了闪电单体英雄天赋使用了例行沟通而非听我号令的问题。
- **2024年8月30日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 修正了天赋推荐，那里不小心放错了 元素。
- **2024年8月28日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了装饰和饰品推荐。
- **2024年8月28日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 调整了地下堡和群体伤害/大秘境配装，添加了关于 元素 天平与岩浆之巢对比的说明。
- **2024年8月25日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 添加了一个专门的地下堡配装。
- **2024年8月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 重新措辞了闪电单体循环中一行不够清晰的描述。
- **2024年8月22日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 对闪电单体起手式进行了轻微调整。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 更新了推荐的英雄天赋树。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 为《地心之战》的赛季前阶段进行了更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 添加了取消光环宏，在@cursor宏中添加了液态岩浆图腾。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 按配装拆分了属性优先级。添加了一些文字以使属性的相对价值更清晰。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 使用起手式和循环的图片块重新整理了页面。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了天赋配装，添加了指向提供英雄天赋信息页面的重定向。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 更新了英雄天赋技能。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 更新了闪电配装和 先知 英雄天赋。
- **2024年8月21日（本页）：** 重新整理并合并了对 元素 的更改。更新了可行性部分和优势/劣势。
- **2024年8月19日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 更新了一些初步信息。
- **2024年8月14日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 更新了单体闪电循环。
- **2024年8月14日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 添加了单体闪电天赋。
- **2024年8月12日（[地心之战](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** 已为11.0.2补丁更新。
- **2024年8月12日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为11.0.2版本进行了更新，新增了混合大秘境配装。
- **2024年8月12日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为11.0.2版本进行了更新，添加了新混合大秘境配装的循环。
- **2024年8月12日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 为11.0.2版本进行了更新，添加了混合大秘境配装。
- **2024年8月12日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已为11.0.2补丁更新。
- **2024年8月12日（本页）：** 已为11.0.2补丁更新。
- **2024年7月23日（[地心之战](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** 为2.3节添加了标签，更新了核心更改部分以反映未公开的在线修正。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/elemental-shaman-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 更新了练级天赋树并调整了一个天赋选择。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 添加了各种实用宏，移除了几个即将过时的宏。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 修正了风行/灵魂行者宏中的一个拼写错误。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 根据未公开的在线修正调整了循环。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 修复了一些天赋树错误，修正了关于几个天赋的信息。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 为 萨满祭司 重做进行了更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 修复了一些天赋树错误，更新了属性优先级。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 为2.3节添加了标签，更新了核心更改部分以反映未公开的在线修正。
- **2024年7月20日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年7月17日（[地心之战](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** 添加了关于 萨满祭司 重做的详细解析和即时玩法风格变化。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/elemental-shaman-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月15日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/elemental-shaman-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月30日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了饰品推荐。
- **2024年4月29日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 在铸币部分添加了瓦卡什。
- **2024年4月23日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 添加了炙热海鲜杂烩作为选项。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了关于远古青铜铸币的部分，更新了所有最佳装备部分、套装、专业制造、装备升级、武器、饰品、珠宝和装饰部分。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对巨龙时代第4赛季进行更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对巨龙时代第4赛季进行审查。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月17日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月17日（本页）：** 为10.2.6版本进行了更新。
- **2024年3月5日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 更新了 火焰 配装的群体伤害优先级。
- **2024年2月6日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 修正了一个疏漏。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已为10.2.5版本进行更新。
- **2023年11月25日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 将桑索克汗护腿放入了总体最佳装备。调整了饰品推荐，添加了关于灾祸枝条的免责声明。重新措辞了垂坠之石的描述，修正了大秘境最佳装备列表的来源，并移除了几个不在第三赛季副本版本中的物品。
- **2023年11月25日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 添加了头盔附魔和阶梯坠饰底座作为提醒。添加了一个不太可能的情况——使用嘶嘶作响的符文，重新措辞了几句关于衰变学药剂的描述。
- **2023年11月22日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 在装饰推荐中添加了枯萎之书。
- **2023年11月11日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 调整了通用饰品推荐。调整了装饰推荐。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 在孢子披风被削到湮灭之后，修正了最佳装备、专业制造和装饰推荐。
- **2023年11月7日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修正了T31动作优先级列表中遗漏的几行。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 移除了永恒黎明和玛瑙印记部分，添加了一段关于副属性的额外说明，添加了关于专业制造优先级的部分，大幅修改了装饰部分，为10.2更新了所有最佳装备列表并添加了额外免责声明，为10.2更新了武器、珠宝和饰品部分。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 添加了关于精通上限的免责声明。更新了新的最优附魔和宝石，添加了附魔选项，添加了一些偶尔有用的特殊药水，更新了药剂部分，提到了可重复使用的强化符文。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 更新了10.2配装的新属性优先级。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 更新了10.2配装，将 火焰 放在最前面，因为它与T31最为相关。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 添加了新部分以强调T31推荐配装的推荐动作优先级列表。添加了T31部分，移除了T29部分。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了10.2配装，强调T31推荐配装。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 更新了10.2法术和天赋更改。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 为10.2版本进行了审查。
- **2023年11月6日（本页）：** 添加了10.2更改，移除了10.1.7更改，更新了优势和劣势部分。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 重新添加了循环工具，添加了PvP天赋。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 移除了大灾变时空漫游部分，添加了最佳装备列表，添加了Bloodmallet饰品模拟。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已为10.1.7版本审核。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修正了默认勾选天赋以符合T30团本天赋推荐。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 使用新模板更新了页面。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 添加了PvP在线修正，并注明10.1.7中没有 元素 更改。
- **2023年7月12日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为不使用风歌者熔岩重生的闪电配装，在单体循环中添加了额外内容。
- **2023年7月11日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 修正了仍指向第1赛季页面的一些链接。
- **2023年7月11日（本页）：** 重新措辞了几句话以澄清法力值更改，修正了一个数字拼写错误。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了永恒黎明部分，并在武器/饰品部分添加了相关物品。移除了关于饰品在线修正的警告。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 从单体优先级列表中移除了大地 元素。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了生命涌动的推荐措辞。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 根据10.1.5更改更新了自然引导和生命涌动。根据新的基础法力值消耗更新了功能性和治疗法术。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 为10.1.5版本进行了更新。移除了待定更改部分。添加了10.1.5版本更改。更新了可行性部分。
- **2023年5月24日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 修正了几个最佳装备武器推荐，添加了时空漫游饰品的临时推荐，更新了一些饰品排名。
- **2023年5月24日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修正了一些拼写错误，调整了4件套起手式。
- **2023年5月12日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 调整了推荐药剂。
- **2023年5月10日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 对多目标循环进行了一些调整。
- **2023年5月9日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 修正了被替换戒指的描述，添加了关于炼金风味口袋的提醒，更新了饰品列表以反映最近的更改。
- **2023年5月9日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 对某些火焰配装的单体熔岩爆发使用进行了小幅修正。
- **2023年5月6日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 根据最新更改更新了推荐武器和饰品。移除了关于埃拉诺克戒指的过时段落。更新了玛瑙印记部分，推荐给新角色使用。
- **2023年5月6日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 添加了更多关于天赋/配装选择的建议。
- **2023年5月6日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 删除了一句过时的内容，添加了关于野性之火使用的具体建议，以及是否选择元素冲击的建议。
- **2023年5月2日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 调整了一项设置，让从60级开始练级的玩家更容易理解。
- **2023年5月2日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了推荐的美化装备和饰品，添加了先制作什么的建议，更新了应跳过的套装部件。
- **2023年5月2日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 在食物推荐中添加了恶魔风味蛋，并对命运曲奇添加了警告。
- **2023年5月2日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 简化为两套主要配装，添加了说明。
- **2023年5月2日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 更新了风暴守护者的配置，加入了能量涌动，并描述了四件套T30的使用方法。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了关于黑曜石指环的内容，添加了其在第2赛季可用性的信息，添加了第2赛季装备升级的章节，更新了推荐的饰品和武器列表以及首饰和美化装备章节。用T30套装更新了套装章节。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 更新了T30推荐，更新了黑曜石指环章节。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 为10.1补丁进行了更新，并添加了使用T30套装的配装优先级。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 移除了对非第2赛季词缀的提及。添加了如何应对第2赛季3个新词缀的技巧，调整了默认天赋推荐。调整了一些措辞。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 添加了默认勾选标记以指示人们最可能使用的默认配装，添加了2个起手式，一个用于拥有2件套T30但没有4件套的玩家，一个用于拥有4件套T30的玩家。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 移除了涌动之潮、熔岩掌控和幽魂恢复PvP天赋，添加了火山涌动和遁地PvP天赋。用T30更新了默认天赋推荐。更新了天赋说明，并重新排序以与重做的职业天赋树保持一致。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 更新了漩涡之力和缚地图腾的描述以反映10.1的改动。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 修改了一些措辞。
- **2023年5月1日（本页）：** 已更新至10.1补丁。
- **2023年3月27日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石章节。
- **2023年3月23日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 根据新的热修更新了原始宝石章节。
- **2023年3月21日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 根据宝石的最后一刻增强更新了原始宝石章节。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 针对10.0.7补丁的职业天赋大改进行了更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/elemental-shaman-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 添加了关于黑曜石指环的章节。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 更新了大秘境推荐药剂，添加了使用元素项石时关于宝石插槽的警告，添加了关于原始宝石石的部分。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 针对10.0.7补丁的改动进行了更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对10.0.7补丁的改动更新了许多天赋描述。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 针对10.0.7补丁更新了天赋树。
- **2023年3月20日（本页）：** 已为10.0.7补丁更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了饰品章节，更新了虚空修补者暗影宝石的信息。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了法力之泉（图腾）的说明。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 为10.0.5版本更新了法力之泉和图腾祭司激涌的说明。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 针对10.0.5补丁进行了更新。
- **2023年1月5日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 全面修改了单体优先级列表的多个部分，使其更加精确，修复了一些疏漏。
- **2022年12月29日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了美化装备章节。
- **2022年12月21日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 更新了饰品和首饰章节。
- **2022年12月21日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 更新了符文不再与强化火舌武器叠加的信息。
- **2022年12月21日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 为熔岩奔腾和风语者的熔岩复苏添加了专门的行。调整了其他几行。
- **2022年12月15日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 从多目标循环中移除了一行重复内容。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 在饰品部分添加了几件饰品，更新了关于元素项石的部分。
- **2022年12月13日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在起手式章节添加了复选框。
- **2022年12月13日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了带电震击的简述。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 针对巨龙时代第1赛季的发布进行了更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 针对第3周进行了更新。添加了关于分级勋章底座的说明。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 调整了地下城推荐的火焰配装以获得更多AoE爆发。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 对多目标循环进行了小幅修复。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 调整了多目标循环的一些措辞。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 调整了地下城推荐的火焰配装以获得更多AoE爆发。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月18日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 更新了新的配装顺序。想要提前了解从60级到70级该往哪走的人现在可以查看我的推荐了。
- **2022年11月18日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 更新了新火焰配装的免责声明。
- **2022年11月18日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 更新了一些内容，移除了不必要的导出字符串，移除了火焰配装的嵌入式计算器以减少杂乱。
- **2022年11月18日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 更新了一套新配装。
- **2022年11月7日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 计算器中的天赋选择顺序应该已修复。
- **2022年11月7日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 在多目标循环中添加了配合能量涌动的闪电箭（仅限2个目标）。
- **2022年11月3日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 进一步修复了几个天赋切换问题，在元素大师章节进行了修改。
- **2022年11月2日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 修复了各种问题，主要是天赋切换问题，改进了几个列表，添加了一些关于配装可行性的信息。
- **2022年10月31日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 移除了过时的硬化皮肤宏，更新了其他几个宏使其更有用。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/elemental-shaman-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/elemental-shaman-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/elemental-shaman-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/elemental-shaman-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年3月7日（[9.2版本分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-2-changes-analysis>)):** 移除了对现已废弃的“机枪”配装的提及。
- **2022年2月19日（[9.2版本分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-2-changes-analysis>)):** 针对最新的PTR改动进行了更新。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** 移除了PTR提及，所有9.1的改动现已正式上线。
- **2021年7月3日（[9.1 补丁分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** 更新为9.1正式服信息。
- **2021年4月25日（[9.1 补丁分析](<https://www.icy-veins.com/wow/elemental-shaman-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2020年1月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 本页已针对8.3补丁的发布进行了审阅，无需更改。
- **2020年1月13日（[达萨罗之战页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.3补丁的发布进行了审查，无需更改。
- **2020年1月13日（[风暴熔渣页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.3补丁的发布进行了审查，无需更改。
- **2020年1月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-the-eternal-palace-raid-guide>)):** 本页面已针对8.3补丁的发布进行了审查，无需更改。
- **2019年7月15日（[永恒宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-the-eternal-palace-raid-guide>)):** 用逐个首领的推荐充实了指南。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月31日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 更新了天赋推荐。
- **2019年1月31日（[达萨罗之战页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了天赋推荐，添加了更多技巧。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为元素萨满祭司添加了达萨罗之战的建议。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 针对8.1的改动更新了天赋推荐。
- **2018年8月31日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 添加了奥杜尔指南。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-uldir-raid-guide>)):** 暂时添加了一个占位页面。

显示更多

显示更少

:::

## 练级

在本页中，您将找到我们的逐级元素萨满祭司练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[萨满祭司练级指南](<https://www.icy-veins.com/wow/shaman-leveling-guide>).

1.

### 元素萨满祭司练级指南：至暗之夜

元素萨满祭司在冷却技能可用时做任务非常出色，不可用时则差得多。总的来说，在纯任务练级时，你通常会比许多其他专精慢，因为你的原始爆发、多目标持续伤害或可靠地拉半个区域怪物的能力不如许多其他专精。话虽如此，通过明智地使用冷却技能，你几乎可以拉任何东西，尤其是当你可靠的[[spell:198103]]和[[spell:2825]]/[[spell:32182]]可用时。在某种程度上，这有利于休息一下、欣赏新区域、阅读任务文本，而不是尽可能快地竞速，这也是我们推荐的！

元素萨满祭司也非常适合地下城，他们广泛的工具箱使他们能够帮助任何队伍摆脱几乎任何糟糕的情况，而且在使用专门的地下城天赋时，他们的范围伤害格外强大。

1.1.

#### 升级装备选择

练级时，始终选择物品等级最高的装备。此规则的唯一例外是如果你有一个戒指或项链，它的物品等级略低，但拥有两个副属性而不是一个。

如果你正在使用传家宝物品，我们推荐使用带有精通和急速属性的物品，因为它们会在练级过程中稍微改善游戏节奏。

1.2.

#### 至暗之夜中实用的升级消耗品

有几种可购买的消耗品可以帮助你提高练级速度。

- 理想情况下，你希望始终有有用的药剂为你提供增益，你可以便宜地购买各种适合你等级的药剂。[[item:191348]]（61级起）需要频繁刷新，但提供速度，这对于练级来说通常比战斗属性更有用。如果你更喜欢战斗属性，你可以使用71级起的[[item:212277]]等药剂，或[[item:212283]]，因为它让你总体上获得略多的副属性。
- 食物增益没那么好，因为你需要浪费时间吃东西，但它仍然有用，特别是当你必须等待NPC或怪物刷新时。[[item:172063]]或[[item:133576]]会在你击杀敌人后给你速度。
- 治疗药水将帮助你通过让你更激进的游戏而无需经常治疗自己来最大限度地减少停机时间。使用适合你等级的药水，例如71级起的[[item:244835]]。
- [[item:60854]]玩具可用于从附近的尸体上拾取战利品。
- [[item:109076]]对于从高处覆盖很长距离非常有用。
- [[item:132516]]是一种工程学物品，可让你的移动速度提高200%，持续25秒。这会让你几乎和飞行坐骑一样快。我们建议你携带大量这些，并在旅行距离超过约250码时使用它们。

只要枪鞋处于激活状态，你就无法停止移动。使用这个宏两次会取消该增益，让你能够停下来。

```wow-macro
#showtooltip
/use 火枪鞋
/cancelaura 火枪鞋
```

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 元素 80级至暗之夜练级
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMGzMLLLjxMMAAAAgNzsADYAzCTgZBAmtZmZMz2yMhZmF2MzMjZYWmxywMzMLAADAMzYYYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMGzMLLLjxMMAAAAgNzsADYAzCTgZBAmtZmZMz2yMhZmF2MzMjZYWmxywMzMLAADAMzYYYA"
}
```
:::

:::details 来源计算器编码
```
#GE-BHQakm046OFEUidbLsFogxsinHhxiSpgUJk-DIc0EI8AyE4YxCjDOhknZGJRWlAq66EB-AAAA-GQcABYgQhhSDzC-
```

:::

2.1.

#### 升级用战争模式天赋

如果你愿意承担风险并使用战争模式，以下PvP天赋推荐在练级期间或其他开放世界内容中使用。有时你可能想使用其他选择，我们鼓励你尝试！PvP天赋可以随时自由更改。

你的第一个PvP天赋栏将在20级解锁，第二个在30级，最后一个在40级。以下是我们认为适合练级的精选PvP天赋列表。

- <em>20级：</em> [[spell:1217092]]或[[spell:305483]]
- <em>30级：</em> [[spell:305483]]或[[spell:1217092]]
- <em>40级：</em>[[spell:204331]]或[[spell:409293]]，取决于个人喜好。

1.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

记得随时保持以下增益！

- **等级 9 起：**[[spell:192106]]**等级 27 起：**，在点了[[spell:462862]]天赋后尤其重要。
- **等级 16 起：**[[spell:462854]]
- **等级 38 起：**[[spell:974]]
- **等级 49 起：**[[spell:318038]]

按以下优先顺序使用法术。

1. **等级 19 起：**每当[[spell:191634]]可用时就施放它。
2. **等级 74 起：**只要可用就使用 [[spell:443454]]。
3. **等级 3 起：**接敌时施放[[spell:188389]]**等级 55 起：**
   ，并在[[spell:470057]]可用时使用它。
4. **等级 51 起：**在需要爆发时施放 [[spell:114050]]。
5. **等级 1 起：**只要可用就施放 [[spell:51505]]。
6. **等级 10 起：**施放 [[spell:8042]]/[[spell:117014]]**等级 23 起：**
   或者[[spell:61882]]，如果在其整个持续时间内会命中多个敌人。
7. **等级 1 起：**施放 [[spell:188196]]**等级 10 起：**
   或[[spell:188443]]，如果它会命中多个敌人的话。
8. **等级 3 起：**当你需要移动且敌人还会存活一段时间时，施放 [[spell:188389]]。
9.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了更多关于通用升级信息和传承装备的链接，并针对至暗之夜第1赛季进行了审查。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 更新了天赋树以反映职业门槛解锁的变更。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年2月27日：** 调整了推荐的战争模式天赋。
- **2025 年 2 月 24 日：** 已针对11.1补丁全面更新和审阅。
- **2024年12月15日：** 已针对11.0.7补丁更新和审阅。
- **2024年10月22日：** 已为11.0.5版本更新并审查。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 更新了推荐的英雄天赋树。
- **2024年7月23日：** 更新了练级天赋树并调整了一个天赋选择。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年2月6日：** 修正了一个疏漏。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 重新添加了循环工具，添加了PvP天赋。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月2日：** 调整了一项设置，让从60级开始练级的玩家更容易理解。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 针对10.0.7补丁的职业天赋大改进行了更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新了新的配装顺序。想要提前了解从60级到70级该往哪走的人现在可以查看我的推荐了。
- **2022年11月7日：** 计算器中的天赋选择顺序应该已修复。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将介绍如何在《魔兽世界》12.1.5版本中轻松游玩 元素 萨满祭司，使用最简单的输出循环、天赋树、属性优先级、装备配置等，而不牺牲性能。

1.

### 元素 萨满祭司 基础

**本部分面向刚接触游戏或该职业的玩家**，他们没有开荒史诗难度的打算，或者只是想要一种更直接的方式来游玩自己的专精，而不被为达到最佳表现所需考虑的众多优先级和主动技能所淹没。

元素 是一个能够轻松舒适地适应大多数情况的专精。有效游玩该专精所需的键位绑定数量相对较少，使其成为经验较少的玩家的绝佳选择。本部分将专注于一种普遍强力的配置，在任何情况下都应能充分运作。减少按钮数量和反应需求是本页最初的目标，但随着 萨满祭司 的重做，不幸的是，要在不严重影响整体伤害输出的情况下舍弃主动技能变得非常困难。

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_nature_lightning.jpg>) **ABC：永远保持施法（Always Be Casting）**
  
  
  
  
  这是大多数施法者的基本功，但对元素来说尤其如此。犹豫永远是坏事。拿不准的时候，按点什么，不要只是站在那里。与其他专精不同，你不会犯下危及输出的致命错误。这也意味着你应该随时都能施法。确保自己保持在射程内，并经常移动，以便处于持续输出伤害法术的最佳位置。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shaman_spiritwalkersgrace.jpg>) **使用你的冷却技能**
  
  
  
  
  不要长时间捏着[[spell:114050]]或[[spell:191634]]不放。拿不准的时候，用掉它们！这对非伤害类冷却技能同样适用。需要移动？按下[[spell:79206]]。即将承受伤害？按下[[spell:108271]]！新手元素萨最常见的错误之一就是冷却技能使用不足。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_flameshock.jpg>) **保持烈焰震击不断，风暴之力不溢出！**
  
  
  
  
  特别是在单体目标中，你应该始终让目标身上保持 [[spell:188389]]，因为它能使 [[spell:51505]] 自动暴击。如果你有 [[spell:470057]]，在几乎所有情况下只要它可用就按下。相反，确保你通过施放消耗技能来消耗漩涡值，不注意的话很容易“溢出上限”从而损失大量伤害！

1.

### 至暗之夜 中 元素 萨满祭司 新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 单体天赋

2.1.

#### 元素 萨满祭司 新手单体天赋

一旦你熟悉了这种玩法，我们建议你从 [[spell:8042]] 换成 [[spell:117014]]，如果你能承受机动性的损失，它的伤害明显更高。

务必使用'导出天赋'按钮将我们的配置导入游戏！

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAgtZmZMz2yMhZmNWmZmZMDzyMWMzwMLDAYAgZGDDD"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzrqG352WIjBRJwFkpZJ-DIc0EI8EyEYxiDSvvrzMOjMKGJAWmRlA-AAAA-GeEJAgBRDziQhC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 多目标天赋

2.2.

#### 多目标天赋

在地下堡中，换成 [[spell:462791]] 并将 [[spell:1279819]] 替换为 [[spell:192058]]。

一旦你熟悉了这种玩法，我们建议你从 [[spell:8042]] 换成 [[spell:117014]]，如果你能承受机动性的损失，它的伤害明显更高。

务必使用'导出天赋'按钮将我们的配置导入游戏！

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMLLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAgtZmZMz2yMhZmNWmZmZMDzyMjZmxMzCAwAAzMGGGA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzrqG352WIjBRJwFkpJZ-DECIc0A5x0WBpjTPwxlsPLjokSAVddi-AAAA-GeEJAgBRDziQhC-
```

:::

### 元素 萨满祭司 基础输出循环

2.3.

#### 单体目标循环

1. 施放 [[spell:191634]]
2. 施放 [[spell:114050]]，与使用饰品、[[spell:2825]]、[[item:241308]] 同步
3. 施放 [[spell:443454]]
4. 保持 [[spell:188389]]
5. 施放 [[spell:8042]]
6. 施放 [[spell:51505]]
7. 施放 [[spell:188196]]

2.4.

#### 多目标循环

1. 施放 [[spell:191634]]
2. 施放 [[spell:443454]]
3. 施放 [[spell:470057]]
4. 施放 [[spell:467263]]，与使用饰品、[[spell:2825]]、[[item:241308]] 同步
5. 施放 [[spell:61882]]
6. 施放 [[spell:188443]]

2.4.1.

##### 巅峰天赋： ![Feedback Loop Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_shaman_primordialwave.jpg>) 反馈循环

元素 萨满祭司 的巅峰天赋虽然强大，但对他们的游戏方式没有影响，它们只是提供大量的被动伤害加成。

2.4.2.

##### 第2赛季套装

虽然 至暗之夜 第2赛季套装效果 [[spell:1296625]] 对我们的输出循环没有影响，但4件套效果 [[spell:1296626]] 希望我们最好能跟踪2种不同的增益。然而在实践中，我们建议你在 [[spell:191634]] 或 [[spell:114050]] 消失后尽快使用消耗技能，这样你就不会浪费消耗技能增益或漩涡值。

### 元素 萨满祭司 属性优先级

2.5.

#### 元素 萨满祭司 配置的属性优先级

对于一般使用，你需要遵循下面介绍的属性优先级。有关本页内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>).

- 精通
- 急速 = 暴击
- 全能

### 暴风雪战斗助手

2.6.

#### 我应该使用战斗助手功能吗？

关于这个新功能如何工作的基本信息，请访问我们的 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 指南。

请记住，作为一个新的 元素 玩家，这个工具的用途非常有限。

我们不建议使用单键输出循环功能，除非你从未玩过 元素 而是第一次将其作为副专精使用，或者正在使用一个直升的 萨满祭司。仅在这些情况下，它最初可以帮助你了解 元素 玩法的'节奏'，但内置的公共冷却时间惩罚会导致巨大的DPS损失。在这些基础之上，依赖那个按钮将阻止你学习如何真正游玩该专精，你的伤害会更低。

按钮高亮功能不会产生内置的公共冷却时间惩罚，是一个更合理的折中方案，特别是对于一个刚接触 元素 的新手在目标假人身上或在简单内容中练习时。话虽如此，它也比执行'正确的'输出循环要差，因为它会经常给你错误的建议。最后，它需要你盯着动作条而失去对战斗环境的注意力，这可能导致许多错误。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 为12.1补丁更新，新增了“核心思路”要点。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 更新了天赋树以反映职业门槛解锁的变更。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月7日：** 移除了关于本页面基于不拥有任何套装构建的免责声明。
- **2025年9月2日：** 将配装改为“通用”的先知配置，与新套装搭配更为合理。
- **2025年8月5日：** 移除了风暴召唤宏，因为它有时会出错且是坏习惯。更新了属性优先级。
- **2025年8月4日：** 添加了说明：本部分适用于没有套装的玩家。已为11.2版本审核。
- **2025年6月15日：** 添加了关于新战斗助手系统的部分。
- **2025年4月21日：** 在单体循环中添加了图片区块、关于 先知 的提及以及原始浪潮选项。选择了地壳图腾而非急流。
- **2025年3月7日：** 添加了一个推荐宏。
- **2025年3月3日：** 更新为更通用的配装。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 对推荐的天赋树进行了轻微调整。
- **2024年8月30日：** 修正了天赋推荐，那里不小心放错了 元素。
- **2024年8月21日：** 更新了闪电配装和 先知 英雄天赋。
- **2024年7月23日：** 修复了一些天赋树错误，更新了属性优先级。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 修改了一些措辞。
- **2023年3月20日：** 针对10.0.7补丁更新了天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新了一套新配装。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到《魔兽世界》12.1.5版本中你的 元素 萨满祭司 的最佳天赋。我们还有针对不同类型内容（如团本或大秘境）的默认天赋配置。如果你开启了战争模式游玩，我们也为你提供了PvP天赋。

1.

### 元素 萨满祭司 的最佳 至暗之夜 天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 是第2赛季 元素 无可争议的英雄天赋，而 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 在纯单体和AOE方面总体落后，尽管在一般情况下仍然可用。我们目前的建议如下：

- **团队副本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 适用于所有内容。它只是表现得比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者.
- **大秘境 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 总体领先，特别是在较低的层数和进行较小规模拉怪时。如果你在做相对简单的内容， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 完全可以，它只是几乎总是伤害更低，除非有大量的群体AOE。

请注意，我们的职业树有意忽略了一些功能天赋，如 [[spell:370]]。你应该根据每场战斗需要什么功能来调整这个建议。我们的职业树有相当大的灵活性，你可以也应该根据你打算进行的内容来调整你的功能工具包。

**快速开始导入代码：**

:::talents 元素 单体目标 - 先知
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzsxyMzMjZwyMWMzwMLDAYAgZGDDD"
}
```
:::

:::talents 元素 大秘境 - 先知
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMjFLzMmZGzMLAADAMzYYYA"
}
```
:::

:::talents 元素 地下堡 - 先知
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzYsYmZGzYxyMjZmxMzCAwAAzMGGGA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

先知

团队副本

推荐

秘境+

推荐

地下堡

推荐

风暴使者

团本备选

大秘境备选

### 天赋方案 0-0

1.1.

#### 团队副本 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 天赋

这套 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知流派在单体目标和持续性范围伤害方面明显优于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 提供明显更多的单体和持续AOE伤害，并且更容易游玩。

**游玩 [[spell:117014]] 伤害高得多，但机动性损失显著。如果可以的话你应该使用它，但如果你使用 [[spell:8042]] 有更多成功和乐趣，它'只是'最多约5%的损失。**

### 天赋方案 0-1

1.2.

#### 秘境+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 天赋

这是我们推荐的大秘境配置。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 提供的伤害比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 提供明显更可靠的伤害，并且也更容易达到最佳表现。

### 天赋方案 0-2

1.3.

#### 地下堡天赋配置

这个配置偏向单人游玩，省略了 [[spell:1279819]] 以便我们的 [[spell:198103]] 能为我们坦怪，并通过 [[spell:5394]] 增加我们的自我治疗，同时选取 [[spell:192058]] 和 [[spell:57994]] 来控制你的敌人。请注意你可以游玩一个 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 如果你愿意，特别是如果你对自己的能力和知识有信心，并且准备连续拉怪。

有关地下堡的一些一般信息可以在这里找到： [地下堡](<https://www.icy-veins.com/wow/delves-guide>)

### 天赋方案 1-0

1.4.

#### 团队副本 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 天赋

这是一个团本的备选配置，如果你想游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者，但它明显落后于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 配置。

### 天赋方案 1-1

1.5.

#### 秘境+ ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 天赋

这是一个大秘境的备选配置，如果你更喜欢游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者，但它明显落后于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 配置。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzsxyMzMjZwyMWMzwMLDAYAgZGDDD"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKARJwEmsq-DFCIc0A55UBpjTPwxlsPLjokSAXmMKcA-AAAA-GeEJAgBRDziQhC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMjFLzMLDzMzsAAMAwMjhhB"
}
```
:::

:::details 来源计算器编码
```
#GE-BHQakm046OFEUShZbLsFowyzbkJhxiSpgZVB-DJe0EI8Ay0G4YxiDOhknZGJRWlAq66EB-AAAA-GScEpBQgQhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjZ2WmJMzYsYmZGzYxyMjZmxMzCAwAAzMGGGA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKg1IiSgJM-DFCIc0A5x0WBpjTPwxlsPLjokSAVddi-AAAA-GeEJAgBRDziQhC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMzMzMLbLDMmZAAAAAwmZMsBLwMM0YDAsNzMjZ2WmJMzsxyMzMjZYWmxiZGmZBAYAMzADDD"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKRJwEmsqk-DFCIc0Apg0xpH44S2nlRUSJAOaPZUwQA-AAAA-VOMaYWAiIEQcoA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMzYMLWmhZMzAAAAAgNzYYDWgZYoxGAMbzMzYmtlZCzMbsMzMzYGsMjFzMjZWAAGAzMwwwA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKARJwEmsq-DFCIc0Apg0xpH44S2nlRUSJAOahSYIV-AAAA-VOMaYWAiIEQcoA-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

万卷书是在 至暗之夜 中引入的一种机制 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)
它给你提供一些小型增益的选择。有些是进攻性的，有些是防御性的。总体来说，它们相当弱。

我们建议以下选择。你没有被锁定在任何选项上，可以随时自由更换，所以不要担心犯错：

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279609]]
- [[spell:1279614]]

1.

### 巅峰天赋： ![Feedback Loop Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_shaman_primordialwave.jpg>) 反馈循环

至暗之夜 引入了'巅峰'天赋，与常规天赋相比有所改变，根据你分配的点数提供多种不同的加成。元素 萨满祭司获得 [[spell:1270061]]，虽然这是一个强大的伤害提升，但对你的游戏方式没有任何影响。你只是获得稍多的漩涡值，精通变得更有价值。在大多数情况下，反馈循环只是一个'造成更多伤害'的天赋，但由于加成被调整得非常高，它们在任何情况下都是绝对必选的。

- **至强天赋：**[[spell:1270061]] — 元素 过载伤害提高35%。
- **至强天赋：**[[spell:1270062]] — 法术暴击几率提高5%/10%。[[spell:60188]] 使法术暴击伤害额外提高25%/50%。
- **至强天赋：**[[spell:1270064]] — 元素 过载有25%的几率触发额外的 元素 过载。每次施法只能触发一次。

1.

### 英雄天赋

在任何专精上达到71级时，玩家将获得两个独特的天赋树之一，称为英雄天赋。元素 萨满祭司 可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知 的吸引力在于其易用性，这得益于明显更好的机动性和更低的输出循环复杂性。它也明显领先于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 在大多数内容上，所以除非你偏好 风暴使者 的游戏方式，否则你应该在所有内容中都坚持使用 先知。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 更复杂，机动性更差，而且总体伤害更低。只有当你更享受这种游戏方式时才玩它。

:::details 常见问题我应该选择哪个 [[spell:61882]] 天赋？
除非你真的很讨厌放置

[[spell:61882]]

即使使用光标宏，'区域目标'版本通常也更优，尽管它确实需要更多操作。我们建议使用我们

[宏与插件部分](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-macros-addons>)

.

:::

:::details 常见问题我应该玩 火焰 还是闪电配置？
所有 元素 配置现在都混合元素，尽管在一些AOE配置中仍然可以忽略火焰技能。

:::

1.

### PvP天赋（战争模式）

在开放世界中，你可以开启“战争模式”。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

请记住，开启这个会让你暴露在开放世界PvP中，在升级或做世界任务时存在被'偷袭'的可能性。

在本部分中，我们将为升级和进行单人或小队PvE内容排列最佳PvP天赋。下面是 元素 萨满祭司 专属PvP天赋的排名，以辅助PvE。

1. [[spell:1217092]] 每当你施放 [[spell:188196]] 或 [[spell:188443]] 时，将 [[spell:108271]]、[[spell:192063]]、[[spell:57994]] 和自然图腾的冷却时间减少1秒。它还会在施放这两个法术时将你被打断的时间减少30%。
2. [[spell:305483]]是一个引导技能，会用闪电束缚目标，使其昏迷，并在套索持续的5秒内造成中等自然伤害。它也允许你在引导时移动。
3. [[spell:204331]] 在40秒的冷却时间内复制并反射你受到的伤害，持续15秒。当处于高伤害区域时，这可能非常强大，可以对周围的敌人造成一些额外伤害，并将你的生命值转化为额外的伤害。
4. [[spell:409293]] 钻入地下，变得无法被攻击，移除移动限制效果，并使你的移动速度提高50%，持续5秒。当效果结束时，6码内的敌人会被击飞到空中并受到中等的物理伤害。该技能有2分钟的冷却时间。
5. [[spell:460697]] 在施放 [[spell:191634]] 后，使40码内盟友的法术暴击效果提高15%，持续15秒。适合单人游玩，如果你与他人一起进行户外内容则非常出色。
6. [[spell:355580]] 在目标位置召唤一个图腾，创建一个敌人无法穿越的地形圆圈。这是一个非常方便、用途广泛的群体控制技能，冷却时间为1分钟。
7. [[spell:193876]] 将 [[spell:2825]]/[[spell:32182]] 转变为一个更弱、持续时间更短的冷却技能，每分钟可用一次。它持续10秒，只提高20%的急速，并且不施加嗜血/疲劳效果。这当然是一个不错的选择，但我更喜欢更强大、更稀有的冷却技能。
8. [[spell:204336]] 在PvE中可能有用，但主要在PvP专属活动中强势。
9. [[spell:206642]]主要对玩家有用，需要点天赋并绑定[[spell:370]]或[[spell:378773]]。只有在你积极参与PvP时才选择这个。

我们默认推荐选择[[spell:1217092]]、[[spell:204331]]以及[[spell:305483]]或[[spell:409293]]，但最终选择取决于你最看重什么。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 添加了万法大全（Omnium Folio）部分。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月28日：** 更新了先知先知副本天赋中使用的天赋。
- **2026年3月20日：** 更新了先知先知副本天赋，推荐在虚空尖塔中对抗光盲先锋军光盲先锋军时使用。
- **2026年3月19日：** 由于顺劈和目标切换情况占主导，将团队副本天赋中的风暴注入替换为充能导管。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月4日：** 移除了一个句子的部分内容，该部分主要对至暗之夜前夕才有意义。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月22日：** 更新了团本配装以适应至暗之夜前夕中的新短时长战斗。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对11.2.7版本进行了审查，添加了常见问题解答区块。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月18日：** 修复了天赋中的一个复制粘贴错误，该错误导致团队副本配装在拥有套装时仍然使用原始元素代替液态岩浆图腾，以及使用上古结伴英雄天赋而不是潜在智慧。
- **2025年9月2日：** 更新了推荐，以假设拥有新套装为前提。
- **2025年8月15日：** 更新了关于先知大秘境配装的推荐。
- **2025年8月10日：** 修复了 先知 大秘境配装未使用大地震击的问题。
- **2025年8月5日：** 修复了团队副本天赋推荐中的一处笔误：在新四件套效果下，你需要用液态熔岩图腾替换元素宗师，而非二件套。
- **2025年8月4日：** 已为11.2版本更新并审核。
- **2025年7月8日：** 修复了天赋树损坏的 先知 团队副本配装。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年3月29日：** 重新添加了风暴使者构建中因误操作而被吞掉的元素冲击天赋选择行。为先知构建添加了液态熔岩图腾选项。添加了关于史迪奇·朋克机作为可以使用风暴使者的首领的提及。
- **2025年3月7日：** 重新表述了关于使用喷涌岩浆可能性的说明。
- **2025年3月1日：** 更精确地标明了必选/可选天赋。为大秘境的先知构筑添加了「大分裂之回响」。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 添加了"推荐"标签。
- **2024年11月26日：** 已更新至11月26日的先知增强，单体战斗中现在推荐使用先知。
- **2024年10月31日：** 重新加入了专门的地下城构建。调整了先知构建。添加了专门的纯单体构建。
- **2024年10月26日：** 调整了灵活天赋部分的一些措辞。
- **2024年10月25日：** 将 先知 配装调整为喷涌岩浆变体，添加了“无脑”简易大秘境配装。
- **2024年10月23日：** 小幅天赋调整。在通用构建中用涌动之涡替换风暴之眼。添加了不使用原初之波的替代构建。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 添加了一个 先知 闪电大秘境配装，重新排列了天赋配装并调整了推荐，移除了对混合配装的提及。
- **2024年8月30日：** 修正了闪电单体英雄天赋使用了例行沟通而非听我号令的问题。
- **2024年8月28日：** 调整了地下堡和群体伤害/大秘境配装，添加了关于 元素 天平与岩浆之巢对比的说明。
- **2024年8月25日：** 添加了一个专门的地下堡配装。
- **2024年8月21日：** 更新了天赋配装，添加了指向提供英雄天赋信息页面的重定向。
- **2024年8月14日：** 添加了单体闪电天赋。
- **2024年8月12日：** 为11.0.2版本进行了更新，添加了混合大秘境配装。
- **2024年7月23日：** 修复了一些天赋树错误，修正了关于几个天赋的信息。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了10.2配装，强调T31推荐配装。
- **2023年9月4日：** 使用新模板更新了页面。
- **2023年7月10日：** 更新了生命涌动的推荐措辞。
- **2023年5月6日：** 删除了一句过时的内容，添加了关于野性之火使用的具体建议，以及是否选择元素冲击的建议。
- **2023年5月1日：** 移除了涌动之潮、熔岩掌控和幽魂恢复PvP天赋，添加了火山涌动和遁地PvP天赋。用T30更新了默认天赋推荐。更新了天赋说明，并重新排序以与重做的职业天赋树保持一致。
- **2023年3月20日：** 针对10.0.7补丁的改动进行了更新。
- **2023年1月24日：** 更新了法力之泉（图腾）的说明。
- **2022年12月13日：** 更新了带电震击的简述。
- **2022年12月11日：** 调整了地下城推荐的火焰配装以获得更多AoE爆发。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新了一些内容，移除了不必要的导出字符串，移除了火焰配装的嵌入式计算器以减少杂乱。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页面中，你将学习如何在单目标和多目标情况下优化你的元素萨满祭司的输出循环。我们还提供了关于冷却时间、触发效果等高级内容，以最大化你的DPS。我们所有内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 元素萨满祭司玩法与循环指南

欢迎来到我们的元素萨满祭司循环页面。在本页面中，你将了解在团队副本和大秘境场景中实际使用该专精所需的一切知识。

下面的按钮可用于在精选的 **团本** 和
**秘境+** 配装之间进行选择。你也可以使用下面的开关来添加或移除你可能也在使用的个别天赋。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

团队副本 / 单目标（不推荐）

大秘境 / 群体（不推荐）

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

团队副本 / 单目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境 / 群体 / 探索

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:8042]]

[[spell:117014]]

[[spell:470057]]

[[spell:16166]]

[[spell:1259471]]

### 起手式

[[spell:191634]]

[[spell:51505]]

**适用条件：先知（启用）。**

[[spell:443454]]

[[spell:114050]]

[[item:241308]]

[[item:250144]]

**适用条件：先知（启用）。**

[[spell:188196]]

**适用条件：风暴使者（启用）。**

[[spell:454009]]

[[spell:51505]]

1.1.

#### 单体目标起手

1. 在开怪前约3秒施放[[spell:191634]]。
2. 在开怪前约1.5秒施放[[spell:51505]]，使其在开怪后立即落地。
3. **适用条件：先知（启用）。** 使用[[spell:443454]]。
4. 配合主动饰品和[[item:241308]]施放[[spell:114050]]。
5. **适用条件：先知（启用）。** 施放[[spell:188196]]。
6. **适用条件：风暴使者（启用）。** 施放[[spell:454009]]。
7. 施放[[spell:51505]]。
8. **适用条件：元素 Blast（启用）。** 继续常规输出循环。尽早施放[[spell:117014]]。
9. **适用条件：Earth Shock（启用）。** 继续常规输出循环。

1.2.

#### 多目标起手式

1. 施放[[spell:191634]]。
2. **适用条件：先知（启用）。** 使用[[spell:443454]]。
3. **适用条件：Voltaic Blaze（启用）。** 施放 [[spell:470057]]
4. 配合主动饰品和[[item:241308]]施放[[spell:114050]]。
5. **适用条件：元素 Blast（启用）。** 继续常规输出循环。
6. **适用条件：Earth Shock（启用）。** 继续常规输出循环。

### 单体输出循环

1.3.

#### 单目标技能优先级列表 / "输出循环"

1. 施放[[spell:191634]]。如果[[spell:114050]]即将冷却完毕，则延迟使用，并在其可用前1-2个公共冷却时施放。通常不应将风暴守护者延迟超过10秒。
2. **适用条件：先知（启用）。** 使用[[spell:443454]]。
3. 施放[[spell:114050]]，与主动饰品、[[spell:2825]]和[[item:241308]]同步使用。
4. **适用条件：Voltaic Blaze（未启用）。** 如果[[spell:198067]]将在3秒内消失，刷新[[spell:188389]]。
5. **适用条件：Voltaic Blaze（未启用）。** 当[[spell:188389]]剩余6秒或更少时刷新，利用这个灵活的瞬发法术窗口来优化你的移动。
6. **适用条件：Voltaic Blaze（启用）。** 当[[spell:188389]]剩余6秒或更少时施放[[spell:470057]]，利用这个灵活的瞬发法术窗口来优化你的移动。
7. **适用条件：元素 Blast（启用）。** 如果你同时拥有4件套套装效果的两个增益：流电炽焰和超载！，施放[[spell:117014]]。
8. **适用条件：Earth Shock（启用）。** 如果你同时拥有4件套套装效果的两个增益：流电炽焰和超载！，施放[[spell:8042]]。
9. **适用条件：Master of the Elements（启用）。** 如果[[spell:188389]]已激活且不会导致你溢出元能值，并且[[spell:16166]]未激活，施放[[spell:51505]]。
10. **适用条件：Master of the Elements（启用）；风暴使者（启用）。** 如果[[spell:16166]]已激活，施放[[spell:454009]]或被[[spell:191634]]强化的[[spell:188196]]。
11. **适用条件：Earth Shock（启用）。** 施放[[spell:8042]]。
12. **适用条件：元素 Blast（启用）；Master of the Elements（未启用）。** 施放[[spell:117014]]。
13. **适用条件：元素 Blast（启用）；Master of the Elements（启用）。** 如果[[spell:16166]]已激活或否则会溢出元能值，施放[[spell:117014]]。
14. **适用条件：风暴使者（启用）；Master of the Elements（未启用）。** 施放[[spell:454009]]。
15. **适用条件：先知（启用）；Master of the Elements（未启用）。** 如果[[spell:188389]]已激活，施放[[spell:51505]]。
16. **适用条件：风暴使者（启用）；Master of the Elements（未启用）。** 只有当你拥有[[spell:77756]]时才施放[[spell:51505]]。绝不要"硬读"熔岩爆裂。
17. **适用条件：风暴使者（启用）。** 使用[[spell:454009]] / [[spell:188196]]作为填充技能。
18. **适用条件：先知（启用）。** 使用[[spell:188196]]作为填充技能。

### 多目标循环

1.4.

#### 多目标技能优先级列表 / "输出循环"

如果你正在对抗4个或更多目标：

1. 施放[[spell:191634]]。如果[[spell:114050]]即将冷却完毕，则延迟使用，并在其可用前1-2个公共冷却时施放。通常不应将风暴守护者延迟超过10秒。
2. **适用条件：先知（启用）。** 使用[[spell:443454]]。
3. **适用条件：Voltaic Blaze（启用）。** 冷却完毕即施放[[spell:470057]]。
4. 施放[[spell:114050]]，与主动饰品、[[spell:2825]]和[[item:241308]]同步使用。
5. **适用条件：风暴使者（启用）；元素 Blast（启用）。** 如果你没有[[spell:117014]]的增益且最多只有1层[[spell:454009]]，对任何没有[[spell:210689]]的目标施放[[spell:117014]]。
6. **适用条件：风暴使者（启用）；元素 Blast（启用）。** 如果你最多只有1层[[spell:454009]]，施放[[spell:61882]]。
7. **适用条件：风暴使者（启用）。** 如果你有2层[[spell:454009]]且少于4层[[spell:191634]]，施放[[spell:454009]]。
8. **适用条件：风暴使者（启用）。** 如果不会溢出元能值，配合[[spell:191634]]施放[[spell:188443]]。
9. **适用条件：先知（启用）；元素 Blast（启用）。** 如果没有先祖激活且战斗目标不超过5个，施放[[spell:117014]]。
10. **适用条件：先知（启用）；元素 Blast（启用）。** 如果有任何先祖激活或战斗目标超过5个，施放[[spell:61882]]。
11. **适用条件：Earth Shock（启用）；先知（未启用）。** 施放[[spell:61882]]。
12. **适用条件：风暴使者（启用）。** 施放[[spell:454009]]。
13. **适用条件：Purging Flames（启用）。** 施放[[spell:51505]]（理想情况下配合[[spell:77756]]触发）来消耗[[spell:1259471]]。
14. 施放[[spell:188443]]。
15. 使用[[spell:77756]]进行移动。

---

如果你正在对抗恰好3个目标：

1. 施放[[spell:191634]]。如果[[spell:114050]]即将冷却完毕，则延迟使用，并在其可用前1-2个公共冷却时施放。通常不应将风暴守护者延迟超过10秒。
2. **适用条件：先知（启用）。** 使用[[spell:443454]]。
3. **适用条件：Voltaic Blaze（启用）。** 冷却完毕即施放[[spell:470057]]。
4. 施放[[spell:114050]]，与主动饰品、[[spell:2825]]、[[item:241308]]同步使用。
5. **适用条件：Master of the Elements（启用）；Voltaic Blaze（未启用）。** 保持一个[[spell:188389]]。
6. **适用条件：风暴使者（启用）；元素 Blast（启用）。** 如果你最多只有1层[[spell:454009]]，对任何没有[[spell:210689]]的目标施放[[spell:117014]]。
7. **适用条件：Purging Flames（启用）。** 施放[[spell:51505]]（理想情况下配合[[spell:77756]]触发）来消耗[[spell:1259471]]。
8. **适用条件：风暴使者（启用）；Master of the Elements（启用）。** 当[[spell:77756]]可用时，如果你的下一个施法可以是[[spell:454009]]，则施放[[spell:51505]]。
9. **适用条件：风暴使者（启用）；Master of the Elements（启用）。** 如果[[spell:16166]]可用，施放[[spell:454009]]。
10. **适用条件：风暴使者（启用）。** 如果你有2层[[spell:454009]]且少于4层[[spell:191634]]，施放[[spell:454009]]。
11. 如果不会溢出元能值，配合[[spell:191634]]施放[[spell:188443]]。
12. **适用条件：先知（启用）；元素 Blast（启用）。** 如果有任何先祖激活，施放[[spell:61882]]。
13. **适用条件：先知（启用）；元素 Blast（启用）。** 如果没有先祖激活，施放[[spell:117014]]。
14. **适用条件：Earth Shock（启用）。** 施放[[spell:61882]]。
15. **适用条件：风暴使者（启用）；元素 Blast（启用）。**  施放[[spell:117014]]。
16. **适用条件：风暴使者（启用）；元素 Blast（启用）。** 施放[[spell:454009]]。
17. 施放[[spell:188443]]。

---

如果你正在对抗恰好2个目标：

1. 施放[[spell:191634]]。如果[[spell:114050]]即将冷却完毕，则延迟使用，并在其可用前1-2个公共冷却时施放。通常不应将风暴守护者延迟超过10秒。
2. **适用条件：先知（启用）。** 使用[[spell:443454]]。
3. **适用条件：Voltaic Blaze（启用）。** 冷却完毕即施放[[spell:470057]]。
4. 施放[[spell:114050]]，与主动饰品、[[spell:2825]]和[[item:241308]]同步使用。
5. **适用条件：Voltaic Blaze（未启用）。** 当[[spell:198067]]将在5秒内消失时，在两个目标上刷新[[spell:188389]]。
6. **适用条件：Voltaic Blaze（未启用）。** 当[[spell:188389]]剩余6秒或更少时刷新，利用这个灵活的瞬发法术窗口来优化你的移动。
7. **适用条件：Master of the Elements（启用）。** 如果[[spell:188389]]已激活且[[spell:16166]]未激活，施放[[spell:51505]]。
8. **适用条件：风暴使者（启用）；Master of the Elements（启用）。** 如果[[spell:16166]]已激活，施放[[spell:454009]]或被[[spell:191634]]强化的[[spell:188196]]。
9. **适用条件：Earth Shock（启用）；先知（启用）。** 如果有任何先祖激活，施放[[spell:61882]]。
10. **适用条件：Earth Shock（启用）；先知（启用）。** 如果没有先祖激活，施放[[spell:8042]]。
11. **适用条件：Earth Shock（启用）；风暴使者（启用）。** 施放[[spell:8042]]。
12. **适用条件：元素 Blast（启用）。** 施放[[spell:117014]]。如果使用[[spell:210689]]，在每次消耗技能之间切换目标。
13. **适用条件：风暴使者（启用）；Master of the Elements（未启用）。** 施放[[spell:454009]]。
14. **适用条件：风暴使者（启用）；Master of the Elements（未启用）。** 施放被[[spell:191634]]强化的[[spell:188196]]。
15. **适用条件：Master of the Elements（启用）；先知（启用）。**  如果你会在没有增益的[[spell:188196]]上消耗[[spell:16166]]，且第二个目标存活足够长时间，则对其施放[[spell:188389]]。
16. **适用条件：先知（启用）；Master of the Elements（未启用）。** 如果[[spell:188389]]已激活，施放[[spell:51505]]。
17. **适用条件：风暴使者（启用）；Master of the Elements（未启用）。** 只有当你拥有[[spell:77756]]时才施放[[spell:51505]]。绝不要"硬读"熔岩爆裂。
18. 施放[[spell:188443]]。

:::details 常见问题：我应该对多少个目标施放烈焰震击？
在多目标战斗中，你通常只会使用

[[spell:470057]]

冷却完毕即使用。如果你没有选择此天赋，你只需要保持

[[spell:188389]]

在一个目标上，如果可顺劈目标不超过3个。唯一的例外是对抗2个目标时，在

[[spell:114050]]

结束后但在

[[spell:198067]]

消散。

:::

:::details 常见问题：多少个目标时使用闪电链比闪电箭更划算？
在多目标情况下，你应当始终使用

[[spell:188443]]

，但有一个例外，即

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

时，当只有两个可顺劈目标时，你想使用

[[spell:188196]]

，当它们被强化时

[[spell:191634]]

.

:::

:::details 常见问题：多少个目标使得大地震击比大地震击或元素冲击更值得使用？
如果你使用一个

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

构筑，配合

[[spell:8042]]

，那么使用

[[spell:61882]]

是一个小幅提升，只需2个重叠的目标且它们存活完整持续时间，前提是施放时有任何先祖在场。使用

[[spell:117014]]

时，如果没有先祖在场且目标数为5个或更少，使用它是一个小幅收益。6个或更多目标时则完全停止使用它。如果你使用一个

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者

构筑，配合

[[spell:117014]]

，你需要至少四个目标才能让

[[spell:61882]]

值得使用。以及

:::

:::details 常见问题：多个地震术会叠加吗？
会。每个地震术会在其持续时间内独立造成伤害，因此叠加多个地震术会造成大量范围伤害。

:::

1.

### 至暗之夜 第2赛季套装

2件套奖励[[spell:1296625]]很直接：更强的消耗技能！这既强力又实用，因为元素的“消耗技能”总感觉打不够疼。它不会改变我们的循环。

4件套效果[[spell:1296626]]有些特别，目前存在多个错误或看起来并非设计意图的问题。资源生成技能的伤害增益可以叠加，但“免费”的资源消耗技能使用次数不能叠加。更重要的是，当我们像通常那样同时使用两个冷却技能时，套装效果只会在两个冷却技能的效果都结束后触发，给予4层资源生成技能增益。资源消耗技能的免费使用次数通常很容易浪费，我们希望暴雪也能允许这些次数叠加。[[spell:1259471]]还会一次消耗多层资源生成技能增益。尽管如此，这仍是相当强力的套装效果，尤其是在上述问题最终得到修复的情况下。

这个套装奖励使得不浪费生成技或消耗技层数变得非常重要。生成技层数可叠加至4层，按正常方式输出很容易用完，但消耗层数很容易被覆盖，造成显著的伤害损失。在实践中，这意味着你应该专注于一获得"免费"消耗层数就立即使用，除非你确定它不会被覆盖。

1.

### 职业与专精机制详解

我们针对循环中的各项机制编写了更详细的说明，以便您在游玩 元素 时发挥出全部潜力。

### 顶点天赋

3.1.

#### 元素 萨满祭司 最佳天赋：反馈循环

至暗之夜 引入了'巅峰'天赋，与常规天赋相比有所改变，根据你分配的点数提供多种不同的加成。元素 萨满祭司获得 [[spell:1270061]]，虽然这是一个强大的伤害提升，但对你的游戏方式没有任何影响。你只是获得稍多的漩涡值，精通变得更有价值。在大多数情况下，反馈循环只是一个'造成更多伤害'的天赋，但由于加成被调整得非常高，它们在任何情况下都是绝对必选的。

### 熔岩值管理

3.2.

#### 熔岩值管理

你应该避免在熔岩值超过某个阈值时施放产生熔岩值的法术，以免超过熔岩值上限。由于有大量天赋和触发效果与该阈值交互，很难给出确切数字而不制作一份非常不实用的详细列表。相反，我们简单地建议你遵循我们推荐的输出循环优先级，以避免溢出。在囤积熔岩值时也要记住这一点。这些法术很可能会过载。因此，如果你施放[[spell:51505]]且获得超过8点熔岩值就会超过上限，那么你很可能会溢出熔岩值并浪费宝贵资源。在实践中，在低于其上限的熔岩值时施放这些法术更安全，以避免浪费过载触发。成功的关键是管理所有不同的触发效果，而不频繁溢出熔岩值。

注意，对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 在群体伤害环境中，风暴使者 的资源会不断累积，尤其是在使用 [[spell:273221]] 时，您可能会经常溢出资源，有时即使资源已满，施放一个产生资源的技能也是正确的。这也是 风暴使者 更难掌握的原因之一。

### 烈焰震击 与自然延时

3.3.

#### 熔岩爆裂与 烈焰震击/流电炽焰

始终在目标身上保持[[spell:188389]]的原因是：

- 它通过[[spell:1259047]]使你大部分伤害提高10%
- 每一跳都有机会触发[[spell:77756]]，它会重置[[spell:51505]]的冷却时间
- 如果目标身上有 烈焰震击，您的熔岩爆裂必定暴击。由于 [[spell:60188]] 以及我们多个其他的暴击伤害来源，这一点非常重要。

您只应在目标身上激活了 [[spell:188389]] 时才施放 [[spell:51505]]。

[[spell:188389]]/[[spell:470057]] 受益于自然延时，这意味着只要其剩余持续时间少于原始最大持续时间的 30%，您就可以刷新它，且剩余持续时间将叠加到新的减益效果上。因此，当烈焰震击剩余 5 秒或更少时，您可以在不浪费任何持续时间的情况下刷新它，并且它将延长 18 秒。例如，如果您的 烈焰震击 还剩 5 秒，而您刷新了它，那么您新的 烈焰震击 将持续 23 秒。请注意，如果您拥有 [[spell:198067]]，这些数字都会翻倍。

### 移动管理

3.4.

#### 元素 萨满祭司 的移动管理

得益于其主动技能，元素 相对灵活：在 [[spell:58875]] 或 [[spell:192063]]、[[spell:79206]]、[[spell:2645]] 形态以及众多瞬发循环技能之间切换。然而除此之外，您很少有瞬发技能来调整站位，这使得正确站位变得更加重要。主动调整站位以减少机制带来的潜在移动。密切留意首领计时和机制，因为当您所有冷却技能都在冷却中时被点名，可能会对您的伤害造成灾难性影响。

### 范围伤害目标上限

3.5.

#### 范围伤害目标上限

- [[spell:269005]]（来自[[spell:191717]]配合[[spell:117013]]）没有目标上限，但超过5个目标后伤害会降低。
- [[spell:117588]]限制为8个目标。
- [[spell:61882]]在20个目标时有软上限。这个上限足够高，很少会产生影响。

1.

### 元素 萨满祭司 的重要冷却技能

在使用每个冷却技能之前，你应该特别注意考虑几个因素。我们的一些进攻性冷却技能冷却时间较长，但当正确使用时，它们可以占我们伤害输出的很大比例。你应该始终考虑：

- 你的团队的[[spell:2825]]/[[spell:32182]]/[[spell:80353]]使用情况。
- 当前首领的机制，包括需要移动的转阶段和技能。
- 可能出现的小怪的生成计时器，因为我们可能需要根据顺劈和范围伤害来使用或延迟某些冷却技能。

### [[spell:191634]]

4.1.

#### 风暴守护者

[[spell:191634]]在纯单体战斗中基本按冷却时间使用。

在多目标战斗或有间歇性顺劈和范围伤害的战斗中，延迟你的[[spell:191634]]直到你能够对5个目标使用[[spell:188443]]可能是个好主意。

### [[spell:114050]]

4.2.

#### 升腾

确保你有尽可能多的东西与[[spell:114050]]对齐：

- [[spell:2825]]/[[spell:32182]]/[[spell:80353]].
- [[item:241308]].
- 在多目标情况下施放[[spell:470057]]获得的[[spell:1259471]]增益。
- 最好在升腾之前施放[[spell:191634]]。
- 主动使用饰品。

在每次使用[[spell:114050]]之前，确保没有首领机制会干扰，例如转阶段、首领移动或迫使你移动的机制。使用[[spell:79206]]来确保完整的伤害输出时间是个好主意。如果使用这个天赋，尝试在激活升腾之前立即施放[[spell:117014]]。

不要让自己熔岩值溢出；确保在你的下一次施放会使你超过最大熔岩值时或之前施放你的消耗技。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年4月3日：** 重新表述了关于元素元素爆裂在4个或更多目标上的句子，以更清楚地说明你应始终保持至少一个来自它的增益效果。
- **2026年3月24日：** 从4个或更多目标的循环中移除了不必要的行。
- **2026年3月23日：** 更新了关于风暴守护者的循环建议，以免玩家延迟使用它太久。
- **2026 年 3 月 17 日：** 修正了多目标起手循环，在勾选净化烈焰时显示电光烈焰，而不是显示VB。澄清/调整了3/4+目标循环部分中的一句话。
- **2026 年 3 月 17 日：** 将AOE部分拆分为3个目标和4个或更多目标以提高可读性。调整了AOE循环中的一些内容。将风暴使者风暴使者设为默认选项。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜上线进行了审查。
- **2026年2月10日：** 修复了电光烈焰和元素大师的反向条件开关。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对11.2.7版本进行了审查，添加了常见问题解答区块。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月20日：** 在多目标循环中新增了在没有液态岩浆图腾时使用原初之波，以及在3个或更少目标上保持一个烈焰震击。
- **2025年8月12日：** 在双目标场景中为风暴使者（SB）简化了闪电链的使用（效果持平）。
- **2025年8月10日：** 优化了单体目标中Storm 元素的使用，烈焰震击 / 液态熔岩图腾的使用。
- **2025年8月5日：** 在APL优化之后，更新了冰霜震击和大地震击的使用。
- **2025年8月4日：** 已为11.2版本更新并审核。
- **2025年6月15日：** 添加了关于新战斗助手系统的部分。
- **2025年4月21日：** 在同时使用元素冲击和回响之大分裂的单体目标构建中，移除了大地震击的使用。
- **2025年3月29日：** 修复了一处破坏行内容的笔误，调整了在AOE中使用元素融合的条件。
- **2025年3月18日：** 将默认检查项改为 先知。
- **2025年3月7日：** 修复了一些疏漏，澄清了若干选项/场景。
- **2025年2月27日：** 添加了应对恰好2个目标时的具体信息，为在AOE中正确使用「冰怒」添加了许多条件说明。
- **2025年2月25日：** 修复了循环/起手条件中的一些问题。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁更新和审阅。
- **2024年11月26日：** 根据11月26日的加强调整了先知循环。
- **2024年11月23日：** 修复了单体循环中多余的风暴打击行。
- **2024年11月4日：** 调整了关于单体中双风暴打击使用的措辞。
- **2024年11月2日：** 修复了多目标起手中意外重复的一行。
- **2024年10月31日：** 将风暴打击在单体优先级中的位置提高。为部分构建添加了更详细的烈焰震击使用说明。
- **2024 年 10 月 30 日：** 已更新至最近的元素调整，修复了一些错别字。
- **2024年10月29日：** 修复了一些大地震击和元素冲击的行。修复了多目标循环中与回响之大地撕裂相关的行。
- **2024年10月26日：** 将起手和循环放入图片区块，添加了针对先知/风暴使者、元素冲击/大地震击、能量涌动、回响之大地撕裂、原初之波和液体熔岩图腾的循环切换。
- **2024年10月25日：** 为先知用户添加了说明。调整了循环以更好地叠加冷却时间来优化升腾。优化了单体中的双风暴打击使用。
- **2024年10月23日：** 在单体优先级列表中添加了常规烈焰震击选项。在优先级列表中添加了岩浆爆裂以消耗原初之波。澄清了单体优先级列表中的冰霜怒击行。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月23日：** 调整了多目标闪电循环中的一行描述，使其更清晰。添加了一行针对 先知 的专属内容。
- **2024年9月9日：** 移除了关于“混合”配装的提及。
- **2024年8月23日：** 重新措辞了闪电单体循环中一行不够清晰的描述。
- **2024年8月22日：** 对闪电单体起手式进行了轻微调整。
- **2024年8月21日：** 使用起手式和循环的图片块重新整理了页面。
- **2024年8月14日：** 更新了单体闪电循环。
- **2024年8月12日：** 为11.0.2版本进行了更新，添加了新混合大秘境配装的循环。
- **2024年7月23日：** 根据未公开的在线修正调整了循环。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月7日：** 修正了T31动作优先级列表中遗漏的几行。
- **2023年11月6日：** 添加了新部分以强调T31推荐配装的推荐动作优先级列表。添加了T31部分，移除了T29部分。
- **2023年9月4日：** 修正了默认勾选天赋以符合T30团本天赋推荐。
- **2023年7月12日：** 为不使用风歌者熔岩重生的闪电配装，在单体循环中添加了额外内容。
- **2023年7月10日：** 从单体优先级列表中移除了大地 元素。
- **2023年5月24日：** 修正了一些拼写错误，调整了4件套起手式。
- **2023年5月10日：** 对多目标循环进行了一些调整。
- **2023年5月9日：** 对某些火焰配装的单体熔岩爆发使用进行了小幅修正。
- **2023年5月2日：** 更新了风暴守护者的配置，加入了能量涌动，并描述了四件套T30的使用方法。
- **2023年5月1日：** 添加了默认勾选标记以指示人们最可能使用的默认配装，添加了2个起手式，一个用于拥有2件套T30但没有4件套的玩家，一个用于拥有4件套T30的玩家。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月5日：** 全面修改了单体优先级列表的多个部分，使其更加精确，修复了一些疏漏。
- **2022年12月21日：** 为熔岩奔腾和风语者的熔岩复苏添加了专门的行。调整了其他几行。
- **2022年12月15日：** 从多目标循环中移除了一行重复内容。
- **2022年12月13日：** 在起手式章节添加了复选框。
- **2022年12月11日：** 调整了多目标循环的一些措辞。
- **2022年12月11日：** 对多目标循环进行了小幅修复。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新了新火焰配装的免责声明。
- **2022年11月7日：** 在多目标循环中添加了配合能量涌动的闪电箭（仅限2个目标）。
- **2022年11月3日：** 进一步修复了几个天赋切换问题，在元素大师章节进行了修改。
- **2022年11月2日：** 修复了各种问题，主要是天赋切换问题，改进了几个列表，添加了一些关于配装可行性的信息。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页，您将找到魔兽世界 12.1.5 中 元素 萨满祭司 的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用纹章升级装备的建议，我们应有尽有！

1.

### 元素 萨满祭司 毕业装备指南

欢迎来到 元素 萨满祭司 的装备页面。本节将涵盖您需要了解的关于正确装备角色的一切内容。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含所有来源中 元素 萨满祭司 的最高 DPS 配置。请记住，虽然这是最佳可能配置，但在实践中，您可能会使用截然不同的物品打出相似的伤害。

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第 2 赛季，您想要跳过的“自然”套装部件是裤子，但由于您想将催化剂充能用于具有优秀副属性的部件并保留那些副属性，这将取决于您获得了什么。请记住您将想要使用

[[item:271876]]

，因为催化器也会保留特效！你不想要使用"自然"套装胸甲。这是双向的，你不想要催化任何具有全能的普通护甲物品，因为它会转移到套装部件上！你理想情况下想要将那些部件催化成套装，但记住你的副属性值会根据你已有的而变化：

- 头盔：[[item:251220@JAACAAgNyA]]
- 肩膀：使用普通套装物品或[[item:268231@JAACAAAG2A]]
- 胸甲：[[item:271876@JAAEAAAj1ghN]] **这个非常重要！**
- 手套：[[item:281238@JAAEAAwF0YjM]]
- 腿部：[[item:268237@JAACAAAG2A]]

:::

:::details 常见问题：从宏伟宝库中获取什么？
本赛季你现在可以获得一个[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 作为从本赛季第 2 个宝库开始的替代宝库奖励，它允许您对任何地下城或首领进行额外拾取，并获得该物品的 1/6 史诗难度版本。这对 元素 来说是最佳选择，我们强烈建议每个人在史诗难度的前 3 周都这样做。  [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)，将您的拾取专精设置为 恢复 以从池中移除平庸的饰品，并保证获得 3 件非常强大的毕业物品。唯一的缺点是，史诗难度掉落的物品将是 9/6 史诗难度，而额外拾取的物品最高为 6/6，但这对于最终首领的掉落来说并不重要。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:281238@JAAEAAwF0YjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAj1ghNTpC]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAAEAAAj1ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

此列表仅包含在大秘境地下城中可用的物品，以及套装和附魔制造物品。

此列表的主要重点是针对具有精通以及暴击或急速的最好部件。它并不是一个“将这些物品全部装备在一起”的列表。请记住，使用 [[spell:117014]] 时，精通有 86% 的软上限。

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第 2 赛季，您想要跳过的“自然”套装部件是裤子，但由于您想将催化剂充能用于具有优秀副属性的部件并保留那些副属性，这将取决于您获得了什么。请记住您将想要使用

[[item:271876]]

，因为催化器也会保留特效！你不想要使用"自然"套装胸甲。这是双向的，你不想要催化任何具有全能的普通护甲物品，因为它会转移到套装部件上！你理想情况下想要将那些部件催化成套装：

- 头盔：[[item:251220@JAACAAgNyA]]或[[item:159374@JAACAAgNyA]]
- 肩膀：[[item:239049@JAACAAgNyA]]
- 胸甲：[[item:273789@JAACAAgNyA]]
- 手套：[[item:160213@JAACAAgNyA]]
- 腿部：[[item:159375@JAACAAgNyA]]

:::

:::details 提示我应该刷哪些地下城？
我们推荐你刷以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：有两把好武器和你最好的饰品选择
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：有最好的饰品之一和好的珠宝
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>) 和 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：有一些好物品

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271484@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:251228@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273794@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:240900]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

此列表仅包含来自 至暗之夜 第 2 赛季团队副本和带有装饰的制造物品。

:::details 常见问题我需要哪些套装部件？
对于 至暗之夜 第 2 赛季，您想要跳过的“自然”套装部件是裤子，但由于您想将催化剂充能用于具有优秀副属性的部件并保留那些副属性，这将取决于您获得了什么。请记住您将想要使用

[[item:271876]]

，因为催化器也会保留它们的特效！你不想要使用"自然"套装胸甲。这是双向的，你不想要催化任何具有全能的普通护甲物品，因为它会转移到套装部件上！你理想情况下想要将那些部件催化成套装：

- 头盔：[[item:268230@JAACAAgNyA]]
- 肩膀：使用普通套装物品或[[item:268231@JAACAAAG2A]]
- 胸甲：[[item:271876@JAAEAAAj1ghN]]
- 手套：使用普通套装物品
- 腿部：[[item:268237@JAACAAAG2A]]

:::

:::details 小贴士我最想要哪些团队副本物品？
如果你需要向你的团队领袖提交一份高度重要物品的列表，或者只是想专注于最重要的首领和物品，我们应有尽有！

- [[item:268265@JAAEAAAj1ghN]].
- [[item:271876@JAAEAAAj1ghN]]
- [[item:281215@JAACAAAOyA]]
- [[item:270164@JAACAAgNyA]]

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271483@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">内克扎莉</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:281238@JAAEAAwF0YjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAj1ghNTpC]]&#10;&#10;<div>[[item:240967]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271481@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271482@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271486@JAAEAAAj1ghN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 在物品上从 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>护腕</th><td>[[item:244584@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:240917]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/elemental-shaman-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAIAAwt1ENMMYjlGA]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 元素 萨满祭司 饰品推荐

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 元素 萨满祭司饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>元素 萨满祭司</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>S级饰品的任何组合（除了双主动使用）价值相似。</li>&#10;<li>[[item:281215@JAACAAgNyA]]：出色的被动饰品，特别适用于大秘境或你将攻击许多小怪的战斗。</li>&#10;<li>[[item:270164@JAACAAgNyA]]：出色的被动饰品但有些依赖随机性，其中一个触发效果甚至会降低我们的属性。</li>&#10;<li>[[item:250215@JAACAAgNyA]]：非常扎实但不令人兴奋的主动使用效果。</li>&#10;<li>[[item:270167@JAACAAgNyA]]：非常扎实的饰品，由于我们缺乏很好的选择，可以代替主动使用饰品。</li>&#10;<li>[[item:273796@JAACAAgNyA]]：与[[item:250215@JAACAAgNyA]]不相上下，但随机性方面比较遗憾。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161@JAACAAgNyA]]只在Boss身上叠加小怪时大放异彩，在某些情况下可能达到S级。</li>&#10;<li>[[item:270170@JAACAAgNyA]]是大秘境的不错选择，但除此之外并不出众。</li>&#10;<li>如果你能可靠地站在光束中，[[item:250214@JAACAAgNyA]]会很强，但这是一个巨大的缺点，我们无法推荐在任何高难度内容中使用它。</li>&#10;<li>[[item:273649@JAACAAgNyA]]提供大量急速，但在所有情况下都不如A级选择，除非你的急速非常低。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>在大多数情况下[[item:270169]]不值得费心，不过在使用其大部分或完全叠加的效果时，它确实能提供最大的爆发潜力，在你需要更少但更大的伤害爆发时可以使用。</li>&#10;<li>[[item:251792@JAACAAgMyA]]是你在藏宝库中的最佳选择。</li>&#10;<li>如果以有竞争力的物品等级获得[[item:248583@JAACAAgMyA]]，请确保将其调整为你最需要的副属性。</li>&#10;<li>[[item:273794]]还可以，没什么特别的。 </li>&#10;<li>[[item:245752]]是一个非常合理但并不令人兴奋的选择。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]：在没有被盟友包围时对自己使用，使其提供暴击增益，或者至少有3名盟友在你身边以获得急速增益。触发效果很强但频率很低，非常不可靠。</li>&#10;<li>[[item:270168@JAACAAgNyA]]提供相当不错的爆发，特别是如果你能顺劈目标，但其巨大的冷却时间很难让人接受。</li>&#10;<li>[[item:250259]]在单体目标上只是还行，在其他情况下很糟糕。 </li>&#10;<li>[[item:250224]]有一个烦人的缺点，但还是一个合理的选择。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>所有尚未列出的饰品都属于D级或更低。</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 用于从特定Boss或地下城获取物品，让你获得一个来自特定掉落位置的保底掉落。你仍然在该位置可用的掉落池中进行掷骰，但下次你在该难度下该位置/Boss使用虚空核心时，你将获得之前没有获得的物品之一。

它们作为替代奖励选择从大宝库中获得（不是用代币购买），并且在这个补丁中一旦可用——从本赛季第二个宝库开始——实际上就是必选的。

**奥琳·微光** 站在银月城催化剂旁边的NPC将在补丁12.1.5上线后每周免费赠送你一个额外的虚空核心。

3.1.

#### 元素萨满祭司推荐的朦胧虚空核心使用方法

你应该将你的额外骰子用在英雄难度 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 的前3周，保证你从Boss那里获得全部3件毕业装备。 **为了确保这些，将你的拾取专精设置为恢复，以从掉落池中移除一个平庸的饰品。**。同样，你应该将拾取专精设置为增强，以获得从 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. [[item:271092@JAACAAAG2A]]
2. 毒咒物品：[[item:268265@JAAEAAAj1ghN]]和[[item:271876@JAAEAAAj1ghN]]
3. [[item:281215@JAACAAAOyA]]或[[item:270164@JAACAAgNyA]]
4. 剩余的毕业列表物品，从头盔和腿部开始。

:::

3.2.

#### 晋升毒液石

使用[[item:280562]]升级物品遵循与使用纹章类似的优先级列表：

1. 武器
2. 主动使用饰品
3. 被动饰品
4. 项链

请注意，这些升级物品最高只能升到物品等级344。如果你使用的是特殊物品，例如毒咒物品或来自最后2个史诗Boss的物品，它们无法用毒石进一步升级。当然这也取决于你是否拥有史诗轨道的装备。你应该优先考虑这些，但无论怎样，你的武器都应该是第一个升级的。

1.

### 元素萨满祭司的最佳制造物品

你想制造什么不仅取决于掉落/宝库的随机性，还取决于你的进度水平，以及你是想要立即获得力量去爆发，还是想要最大化你角色的中长期效率。你不太可能仅仅因为角色缺少一点潜在DPS而无法通关团队副本遭遇战，你会因为操作失误而失败。

这个等级，你有很多选择，取决于你的进度水平以及你是否愿意牺牲前期力量来换取长期价值。这主要取决于你是否制造双手武器：

- 选项1：短期力量：[[item:245770@JAAIAAwt1ENMMYjlGA]]搭配[[item:273060]]。尽管新的美化被削弱，它仍然非常强，这给你带来大量即时力量，代价是几周内就必须替换它，如果你的第一次硬币给你[[item:271092@JAACAAAG2A]]，你会很伤心，特别是这个赛季史诗盾牌尤其容易从 [潮缚石窟](<https://www.icy-veins.com/wow/midnight-world-bosses-guide>)
  和 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).
- 选项2：长远打算：如果你绝对不需要即时的力量提升，而是追求长期效率，你应该改用[[item:240167]]制造护甲部件。最好的长期选择是制造[[item:244584@JAAIAAwt1ENMMYjlGA]]以及腰带或靴子，不过你也可以妥协，改为制造价值更高的部位，如腿部或头盔，但这也有其自身的缺点。

请注意，暴击/急速/精通的任何组合都是可行的，具体取决于你当前的装备。请使用模拟并根据需要重新制造。如果你已经制造了其他东西，不必担心，选项之间的实际力量差异很小，而且每周都会变得更小。

最终你可能想使用[[item:245770@JAAIAAwt1ENMMYjlGA]]搭配[[item:273060]]来榨取最大可能的DPS，但它只比使用第二个[[item:240167]]槽位搭配普通史诗盾牌高出约300 DPS，而且盾牌本身也有其优势，特别是在团队副本之外，或者如果你想玩恢复。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **元素制造装备优先级**
- 即时力量爆发 [[item:245770@JAAIAAwt1ENMMYjlGA]] **（不是长矛法杖！）** 搭配[[item:273060]]
- [[item:244584@JAAIAAwt1ENMMYjlGA]]和你缺少的任何护甲部位搭配[[item:240167]]

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 纹章使用

不出所料，你应该模拟你的角色，以确定在任何时间点哪些升级能给你带来最大的收益。除此之外，你通常应该先最大化你的武器（和副手），然后是你的首饰，之后通常最好升级提供最多属性的护甲部位：首先是胸甲（特别是如果你有[[item:271876@JAAEAAAj1ghN]]），头盔或裤子，然后是手套、护肩、靴子和腰带。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **元素萨满祭司纹章升级优先级**
**武器（主手）**

➜

**副手**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为12.1.5补丁更新，新增至尊毒石章节，用基希克斯的物品更新了毕业装备。
- **2026年10月2日：** 更新了仅限团本毕业装备列表中头盔的催化剂来源为 内克扎莉。
- **2026年8月26日：** 更新了最佳武器附魔为哈希伊仪式。
- **2026年8月19日：** 根据热修复更新了制作建议，更新了饰品章节。
- **2026年8月18日：** 新增了关于不要提前用 猎人 的仪式石制作副手的警告，重述了大秘库常见问题解答。
- **2026年8月14日：** 更新了毕业装备和推荐制作装备，加入了用 猎人 的仪式石制作的副手。
- **2026年8月11日：** 更新了推荐宝石。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 将孢子凝聚物品添加到最佳装备列表中，已更新至12.0.7补丁。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月10日：** 更新了制作部分，添加了关于新手斗士项链的一段内容。
- **2026年4月7日：** 更新了饰品部分。
- **2026年4月1日：** 更新了制作选项，加入了制作腿部、腰带或靴子。
- **2026年3月23日：** 添加了更多饰品并更新了饰品排名。
- **2026年3月19日：** 更新了饰品排名和毕业装备，添加了被遗忘的远行者徽记。
- **2026 年 3 月 17 日：** 将第二个推荐制作部位改为腿部。添加了作为法杖替代品的等效双手锤制作的提及。
- **2026年3月16日：** 已针对至暗之夜第一赛季更新并重新组织。
- **2026年2月26日：** 已针对至暗之夜上线重新组织并更新。
- **2026年2月10日：** 已针对至暗之夜前夕更新。添加了关于至暗之夜有用升级装备的部分。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025年10月27日：** 更新了黑帮代币部分，说明你只需完成你想要物品所在特定地下城的+12即可。移除了珠宝的提及。
- **2025年10月6日：** 修复了高阶蛛魔印记的来源，它来自破晓号角而非阿拉卡拉。
- **2025 年 10 月 5 日：** 更新了推荐的专业技能和镶边，新增了令人费解的财团筹码部分。
- **2025年8月17日：** 更新以反映虚空玻璃武器在热修后不再为元素提供护盾的事实。因此，将钻石虚空核心在大秘境中降了一级。
- **2025年8月14日：** 进一步更新了饰品排名。
- **2025年8月12日：** 根据最新的热修复更新了饰品排名。
- **2025年8月9日：** 将披风纤维的推荐属性调整为精通，以避免误导玩家专门堆叠全能。
- **2025年8月8日：** 在饰品排行中添加了更多饰品，并重新调整了部分排序。
- **2025年8月5日：** 修复了“适合早期大秘境玩家的即时提升选择”推荐中误将匕首写成法杖的问题。
- **2025年8月4日：** 已为11.2版本及第3赛季更新。
- **2025年7月8日：** 更新了“DISC”腰带部分，并在BiS列表中添加了最佳默认选择。
- **2025年6月15日：** 添加了关于新“DISC”腰带的新部分。
- **2025年5月12日：** 更新了关于谜之卡特尔筹码的部分。
- **2025年4月25日：** 更新了关于谜之卡特尔筹码的部分。
- **2025年4月21日：** 调整了BiS饰品，添加了关于伪造商贩筹码的部分。
- **2025年3月29日：** 调整了总体BiS戒指和饰品。
- **2025年3月18日：** 更新了Brewterializer宏使其更可靠。
- **2025年3月7日：** 更新了塞尔西的指环信息，添加了套装升级建议。
- **2025 年 2 月 28 日：** 调整了饰品排名。
- **2025年2月27日：** 添加了单手武器和盾牌选项。添加了更多关于「协同酿菌器」的信息。
- **2025年2月25日：** 调整了饰品排名。将催化剂添加为套装部件的获取来源。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2025年2月20日：** 已针对11.1补丁和第2赛季全面更新。
- **2024年12月17日：** 更新了关于「瑟克尔的王冠」的部分，并将其添加到所有毕业装备列表中。
- **2024年12月15日：** 添加了关于「瑟尔西的王冠」的部分，并将其添加到毕业装备列表中。
- **2024年10月26日：** 强调了拥有任意间谍大师之网饰品的重要性。
- **2024年10月25日：** 完全更新了仅限大秘境的毕业装备列表。添加了更多替代选择。
- **2024年10月23日：** 更新了无羁变形者的推荐属性。为没有间谍大师之网的玩家将背叛者发射器加入S级。添加了在没有原初之波的情况下使用暗影之风的警告。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月1日：** 在总毕业装备列表中添加了项链、戒指和武器的装饰替代选择。
- **2024年9月16日：** 添加了关于专业制造和装饰的更详细信息。调整了饰品推荐，新增了更多饰品。调整了仅限大秘境的护肩推荐。
- **2024年9月13日：** 移除了赛季前最佳装备列表。
- **2024年9月9日：** 重新整理了页面，添加了3个不同的最佳装备列表，为《地心之战》第1赛季进行了更新，调整了装饰推荐。
- **2024年8月30日：** 调整了最佳装备列表以明确头盔属性，并说明亵渎之芽是我们最好的饰品。调整了饰品和装饰推荐。
- **2024年8月28日：** 更新了装饰和饰品推荐。
- **2024年8月21日：** 为《地心之战》的赛季前阶段进行了更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月30日：** 调整了饰品推荐。
- **2024年4月29日：** 在铸币部分添加了瓦卡什。
- **2024年4月22日：** 添加了关于远古青铜铸币的部分，更新了所有最佳装备部分、套装、专业制造、装备升级、武器、饰品、珠宝和装饰部分。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月25日：** 将桑索克汗护腿放入了总体最佳装备。调整了饰品推荐，添加了关于灾祸枝条的免责声明。重新措辞了垂坠之石的描述，修正了大秘境最佳装备列表的来源，并移除了几个不在第三赛季副本版本中的物品。
- **2023年11月22日：** 在装饰推荐中添加了枯萎之书。
- **2023年11月11日：** 调整了通用饰品推荐。调整了装饰推荐。
- **2023年11月7日：** 在孢子披风被削到湮灭之后，修正了最佳装备、专业制造和装饰推荐。
- **2023年11月6日：** 移除了永恒黎明和玛瑙印记部分，添加了一段关于副属性的额外说明，添加了关于专业制造优先级的部分，大幅修改了装饰部分，为10.2更新了所有最佳装备列表并添加了额外免责声明，为10.2更新了武器、珠宝和饰品部分。
- **2023年9月4日：** 移除了大灾变时空漫游部分，添加了最佳装备列表，添加了Bloodmallet饰品模拟。
- **2023年7月10日：** 添加了永恒黎明部分，并在武器/饰品部分添加了相关物品。移除了关于饰品在线修正的警告。
- **2023年5月24日：** 修正了几个最佳装备武器推荐，添加了时空漫游饰品的临时推荐，更新了一些饰品排名。
- **2023年5月9日：** 修正了被替换戒指的描述，添加了关于炼金风味口袋的提醒，更新了饰品列表以反映最近的更改。
- **2023年5月6日：** 根据最新更改更新了推荐武器和饰品。移除了关于埃拉诺克戒指的过时段落。更新了玛瑙印记部分，推荐给新角色使用。
- **2023年5月2日：** 更新了推荐的美化装备和饰品，添加了先制作什么的建议，更新了应跳过的套装部件。
- **2023年5月1日：** 更新了关于黑曜石指环的内容，添加了其在第2赛季可用性的信息，添加了第2赛季装备升级的章节，更新了推荐的饰品和武器列表以及首饰和美化装备章节。用T30套装更新了套装章节。
- **2023年3月20日：** 添加了关于黑曜石指环的章节。
- **2023年1月24日：** 更新了饰品章节，更新了虚空修补者暗影宝石的信息。
- **2022年12月29日：** 更新了美化装备章节。
- **2022年12月21日：** 更新了饰品和首饰章节。
- **2022年12月13日：** 在饰品部分添加了几件饰品，更新了关于元素项石的部分。
- **2022年12月11日：** 针对巨龙时代第1赛季的发布进行了更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面，你将找到你的元素萨满祭司的最佳属性优先级。我们首先展示属性优先级，然后深入解释这些属性如何与你的专精和玩法互动。我们的内容已根据《魔兽世界》12.1.5补丁更新。

1.

### 元素 萨满祭司 属性优先级

精通

急速

暴击

全能

智力是你最重要的属性。这意味着你大部分时间应该装备你物品等级最高的装备，并以此为基础模拟自己，以获得针对你装备的具体调整。

1.

### 深入属性解析

**精通**，通过[[spell:168534]]，增加你所有的元素和物理伤害，并使你的某些法术有几率造成额外伤害并产生额外的漩涡值。请注意，有了[[spell:381726]]天赋，你的精通将作用于你的消耗技能，使精通更有价值。

:::details 常见问题：元素萨满祭司有精通上限吗？
精通在达到 100% 精通时有硬上限。使用 [[spell:117014]] 时，您应考虑 86% 的“软”上限，因为 元素 震荡可能使您达到 100%。请注意，使用锁甲套装根须看守者的华服时，有一个 76% 的“更软”上限。

精通目前是非常理想的属性，是你最好的综合次级属性。话虽如此，人们经常高估拥有“正确”次级属性的重要性，而实际上，拥有更高数量的属性通常会胜过拥有“更好”的属性。拥有150点你最差的属性通常比拥有100点你最好的属性更好，因为各属性之间的价值差异并没有那么大。

:::

**急速** 提高你的施法速度以及持续伤害效果的跳动频率。

:::details 常见问题：元素萨满祭司有急速上限吗？
你需要大量的急速，它是你第二好的次级属性。对于任何次级属性，你都不需要特定的阈值。人们经常高估拥有“正确”次级属性的重要性，而实际上，拥有更高数量的属性通常会胜过拥有“更好”的属性。拥有150点你最差的属性通常比拥有100点你最好的属性更好，因为差异并不像许多人想象的那么大。

:::

**暴击** 提高你的法术伤害。值得注意的是，元素 萨满祭司有多个天赋可以提高其暴击伤害。

**全能** 提高你造成的所有伤害并降低你受到的所有伤害。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 已针对11.2.5版本进行了审查，添加了常见问题解答区块。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月15日：** 新增了一句话，关于先知2件套加成倾向于全能。
- **2025年8月5日：** 添加了关于急速/全能波动性的说明。
- **2025年8月4日：** 已为11.2版本更新并审核。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月7日：** 更新了推荐内容，使其不过于偏向纯单体。
- **2025年2月25日：** 为更多构筑添加了细节。
- **2025 年 2 月 24 日：** 已针对11.1补丁进行更新。
- **2024年12月15日：** 已针对11.0.7补丁更新和审阅。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 更新了部分措辞，移除了不必要的句子。
- **2024年8月21日：** 按配装拆分了属性优先级。添加了一些文字以使属性的相对价值更清晰。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年3月5日：** 更新了 火焰 配装的群体伤害优先级。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了10.2配装的新属性优先级。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月2日：** 简化为两套主要配装，添加了说明。
- **2023年5月1日：** 为10.1补丁进行了更新，并添加了使用T30套装的配装优先级。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的元素 萨满祭司可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/elemental-shaman-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

元素萨满的最佳属性是精通，其次是急速。因此你应该为精通镶嵌宝石，除非你已经在每件装备上都有大量的精通。

你应该首先将[[item:240967]]放入你的一个插槽中。然后，你应该在你可用的插槽中放入除耐力外每种颜色各一颗双属性宝石， **以适应你最缺乏的次级属性**。如果你不确定或没有特殊需求，我们建议镶嵌：

- 一颗[[item:240900]]
- 一颗[[item:240908]]
- 一颗[[item:240917]]
- 然后用[[item:240892]]填满你所有剩余的插槽

注意，所有珠宝类装备都带有一个插槽，你无法添加更多。唯一拥有2个插槽的物品是非常稀有的团本珠宝。宝库的功绩代币只能为头盔/腰带/护腕添加插槽。

1.

### 最佳附魔和武器强化

如果你没有使用[[spell:318038]]武器附魔天赋，你应该每隔几小时在你的武器上使用一次[[item:243733]]。它们不会叠加。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]（速度）</li>&#10;<li>[[item:244007]]（闪避）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]（移动速度）</li>&#10;<li>[[item:243991]]（闪避）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240133]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]（移动速度）</li>&#10;<li>[[item:243953]]（闪避）</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]].</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

3.1.

#### 合剂

你应该喝次属性合剂：如果你缺少精通，喝[[item:241322]]；如果缺少暴击，喝[[item:241326]]。

3.2.

#### 药水

有几种不同的药水都能提供相似的DPS收益，但我们推荐使用[[item:241308]]或者可能使用[[item:241288]]。你应该在[[spell:2825]]/[[spell:32182]]期间配合[[spell:114050]]和[[spell:191634]]一起使用它们。

使用[[item:241292]]可能值得，但要小心那个会沉默你的虚空之区！

你应该储备一些[[item:271883]]，在生命值低时使用；如果队伍里有术士，就拿取他们的[[item:5512]]并一起使用。不要把这些做成宏，它们最好分开使用！

3.3.

#### 食物增益

你想使用[[item:255845]]或[[item:255846]]来获得50点智力。当你需要购买个人食物时，改用[[item:242275]]或[[item:255847]]。

3.4.

#### 增辉与凡图斯符文

当你真正觉得值得为了多一点点伤害时，你可以使用[[item:259085]]。不过你大概应该把它们卖掉换点金币，除非你在开荒史诗钥石地下城！

当你的团队在某个首领身上挣扎时，你可以对首领使用[[item:245879]]来获得大量全能，但只对该首领生效。你每周只能对一个首领使用一次，但它跨难度有效，死亡不会消失，并且持续到每周重置。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月26日：** 更新了最佳武器附魔为哈希伊仪式。
- **2026年8月17日：** 更新了推荐宝石，以最大化永恒之力钻石的价值。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月1日：** 将推荐附魔更新为鹰眼。
- **2026年3月28日：** 为推荐的武器附魔放上了正确的链接。
- **2026年3月23日：** 移除了关于茶的提及，因为它们已被热修复为不再在副本中生效，添加了个人食物推荐。
- **2026年3月16日：** 添加了关于茶类烹饪物品提供可与属性食物的吃饱效果叠加的速度增益的提及，调整了武器附魔和宝石推荐。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 调整了关于武器油的部分。
- **2026年1月19日：** 已针对至暗之夜前夕更新。添加了关于升级消耗品的部分。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已为11.2版本更新并审核。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 为惊魂幻象添加了腐蚀附魔部分。
- **2025 年 2 月 24 日：** 已针对11.1补丁更新和审阅。
- **2024年12月15日：** 已针对11.0.7补丁更新和审阅。
- **2024年10月23日：** 将风暴骑手的狂怒替换为缚石工艺作为武器附魔选项。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年9月10日：** 添加了更多武器附魔选项。
- **2024年9月9日：** 调整了亵渎宝石、披风附魔、护腕附魔的推荐。重新措辞了一句话使其更清晰。
- **2024年9月6日：** 移除了一句现在应该不再必要的句子。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月23日：** 添加了炙热海鲜杂烩作为选项。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月25日：** 添加了头盔附魔和阶梯坠饰底座作为提醒。添加了一个不太可能的情况——使用嘶嘶作响的符文，重新措辞了几句关于衰变学药剂的描述。
- **2023年11月6日：** 添加了关于精通上限的免责声明。更新了新的最优附魔和宝石，添加了附魔选项，添加了一些偶尔有用的特殊药水，更新了药剂部分，提到了可重复使用的强化符文。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月12日：** 调整了推荐药剂。
- **2023年5月2日：** 在食物推荐中添加了恶魔风味蛋，并对命运曲奇添加了警告。
- **2023年5月1日：** 更新了T30推荐，更新了黑曜石指环章节。
- **2023年3月27日：** 更新了原始宝石章节。
- **2023年3月23日：** 根据新的热修更新了原始宝石章节。
- **2023年3月21日：** 根据宝石的最后一刻增强更新了原始宝石章节。
- **2023年3月20日：** 更新了大秘境推荐药剂，添加了使用元素项石时关于宝石插槽的警告，添加了关于原始宝石石的部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月21日：** 更新了符文不再与强化火舌武器叠加的信息。
- **2022年12月11日：** 针对第3周进行了更新。添加了关于分级勋章底座的说明。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的元素萨满祭司挑战史诗钥石地下城的技巧和建议。

1.

### 元素萨满祭司在至暗之夜第2赛季的史诗钥石地下城中

元素萨满祭司目前在至暗之夜的史诗钥石地下城中是一个高于平均水平的远程DPS专精。它可以提供强大的多目标爆发和持续伤害，以及大量实用性。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

首先，史诗钥石地下城有多种可行的变体，在这里列出每一个都是适得其反的。在某些地下城或针对某些组合或钥石等级，有一定的变体空间。

如果你是新手元素萨满祭司，我们建议切换到[[spell:8042]]，直到你对地下城和专精都有更好的理解，因为正确操作下，[[spell:117014]]最终会大幅领先，但它对走位、施法和漩涡值管理的容错率要低得多。

1.

### 最佳至暗之夜天赋构筑

我们目前为2个英雄天赋各有一个构筑。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知给你顶级的单体和顺劈伤害，并且操作非常简单。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者在各方面都落后，更难操作，机动性也更差。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知史诗钥石构筑

2.1.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知为元素萨满祭司的构筑

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbbzMGjZZZZMmhBAAAAsYmNYADY2YCMLAwsNzMjx2iJMzsNWmZmZMjFLzMLDzMzsAAMAwMjhhB"
}
```
:::

:::details 来源计算器编码
```
#GE-BHQakm046OFEUShZbLsFowyzbkJhxiSpgZVB-DJe0EI8Ay0G4YxiDOhknZGJRWlAq66EB-AAAA-GScEpBQgQhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者史诗钥石构筑

2.2.

#### 最佳 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者 萨满祭司的 元素专精构筑

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CYQAAAAAAAAAAAAAAAAAAAAAAAAAAAzMbLzMzYMLWmhZMzAAAAAgNzYYDWgZYoxGAMbzMzYmtlZCzMbsMzMzYGsMjFzMjZWAAGAzMwwwA"
}
```
:::

:::details 来源计算器编码
```
#GE-DTdCBFwg0IpslyswzTj7cbL0YRKARJwEmsq-DFCIc0Apg0xpH44S2nlRUSJAOahSYIV-AAAA-VOMaYWAiIEQcoA-
```

:::

1.

### 大秘境深度输出循环提示

在大秘境中，你应该养成几个额外的习惯：

- 在每一波小怪战斗接近尾声时积攒漩涡值是个好主意，这样可以减少在下一波战斗中达到最大输出所需的预热时间。
- 记住效率很重要，你不应该把持续伤害技能浪费在几秒内就会死亡的敌人身上。这一点对于[[spell:61882]]的施放尤为重要。当然，这同样适用于爆发技能。不要把爆发技能浪费在即将死亡的怪物群上。
- 在大秘境中，伤害并非全部，因此你经常需要在最高伤害技能之间穿插使用控制类技能，例如[[spell:192058]]。

1.

### 功能技能与能力

### 打断、昏迷和控制

4.1.

#### 打断

[[spell:57994]]是你的“打断”，也是你在大秘境中最重要的功能技能，用于打断敌人的施法，为队伍尤其是坦克提供帮助。它是 **强烈推荐** 使用焦点打断宏来完成此操作。

#### 焦点打断宏

```wow-macro
#showtooltip
/stopcasting
/stopcasting
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 风剪
```

这个宏会打断你的焦点目标（如果有），如果没有焦点目标则打断鼠标悬停目标，如果两者都没有则打断你的当前目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

#### 焦点宏

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

4.2.

#### 眩晕与“停手”

元素萨满拥有大量“硬”控制技能，但它们的工作方式各不相同。

[[spell:61882]]会“自然地”不时击倒敌人，为你提供免费的停手机会，但由于其不可预测性，你绝不应该指望它能可靠地打断任何施法。把它当作额外奖励就好。

[[spell:192058]]有延迟但很可靠，通过几个天赋你可以将其冷却时间缩短近一半，尽管这需要付出相当大的机会成本。

[[spell:51490]]会打断敌人并将他们击飞。一定要非常注意你将敌人击飞的方向，因为你可能会减慢队伍的输出、恶化控制效果，甚至更糟的是，引到额外的怪物群。

[[spell:51514]]是作为一种长时间的控制技能设计的，但在紧急情况下也可以用作停手技能，尽管这很少实用或高效。除非你真的为了某个特定怪物而需要它，否则你并没有多余的天赋点可以投入。

请注意[[spell:51485]]会“定身”目标，但它并不是“停手”技能；它只能阻止移动。

从技术上讲，搭配[[spell:117013]]的[[spell:198103]]在召唤后不久也会眩晕其目标，因此可以在紧急情况下用来打断敌人。

### 移动能力

4.3.

#### 移动能力

元素的机动性一般：

瞬发技能很少：

- 我们的循环中瞬发技能很少：[[spell:470057]]（或[[spell:188389]]）、[[spell:8042]]/[[spell:61882]]、[[spell:188196]]以及被[[spell:191634]]强化的[[spell:188443]]。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/stormbringer.webp>) 风暴使者用户可以将[[spell:378081]]用作反应性瞬发技能。

但拥有强大的移动工具：

- [[spell:192077]]，特别是被[[spell:462820]]或[[spell:462791]]增强，并可能被[[spell:382201]]增强时，是一个强大的技能，对任何内容都有用，效果显著。此外，你可以通过使用[[spell:108287]]重新放置它来延长其增益效果！
- [[spell:79206]]不仅能让你在施法时自由移动，持续15秒（19秒则适用于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知用户为19秒）施法时拥有完全的移动能力，还为你提供20%的移动速度，并且由于[[spell:192088]]，冷却时间相当短。
- [[spell:192063]]是极佳的多功能爆发性移动技能，而我们的另一个选择[[spell:58875]]冷却时间要长得多，但可以解除定身和减速效果。
- [[spell:2645]]形态在战斗中需要谨慎使用，但非常有用，特别是在高层数中由于[[spell:378075]]或可能的[[spell:260878]]。

### 其他功能

4.4.

#### 其他功能

萨满拥有出色的工具箱，如果针对每个地下城进行定制，将大大受益：

辅助治疗：

- [[spell:974]]，特别是当同时施放在你的坦克或自我恢复能力较弱的角色身上时，几乎可以免费累积非常可观的治疗量，尤其是与[[spell:1217622]]搭配时。
- [[spell:8004]]是一个通用的快速治疗技能，只有在你治疗自己并且点了[[spell:974]]和[[spell:337974]]天赋时才真正发挥作用，但治疗量并不大。
- [[spell:5394]]是那种在你没有其他事情可做时才会放下的技能之一；它有一点帮助，[[spell:462368]]有可能帮助你在秒杀伤害中存活。然而，很难为它投入天赋点。

多种“可选”驱散。通常你应该提前知道某个地下城是否需要它们，否则就不应该点出相应天赋：

- [[spell:370]]可以驱散敌人身上可怕的魔法增益，并有助于应对升腾词缀。通常你应该提前知道某个地下城是否需要它。
- [[spell:51886]]可以解除诅咒，并有助于应对吞噬词缀。通常你应该提前知道某个地下城是否需要它。
- [[spell:383013]]每1.5秒驱散全队的所有中毒效果，持续最多9秒。当它有用时，你很可能需要点出[[spell:382201]]，因为它可以将其持续时间延长50%。通常你应该提前知道某个地下城是否需要它。
- [[spell:8143]]可以解除魅惑、恐惧和睡眠效果。它很少有用，但当这些减益出现时，它是游戏中应对此类效果的最佳工具。

1.

### 地下城天赋切换速查表

有关每个地下城需要哪些功能天赋的快速指南，请使用下方工具选择地下城。所有相关的功能天赋都会在下方高亮显示。

<table>&#10;<tr>&#10;<th colspan="2" style="text-align: center">地下城</th>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;</tr>&#10;<tr>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;<td style="text-align: center"> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;</table>

基于以上选择，你应该使用以下职业天赋：

- **适用条件：纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；塞塔里斯神庙（启用）。** [[spell:51886]]
- **适用条件：诸王之眠（启用）；塞塔里斯神庙（启用）。** [[spell:51485]]
- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；红玉新生法池（启用）。** [[spell:462820]]
- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；密谋小径（启用）；塞塔里斯神庙（启用）；Blinding Vale（启用）；虚空之痕竞技场（启用）。** [[spell:383013]]
- **适用条件：纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）。** [[spell:370]]
- **适用条件：纳洛拉克的洞穴（启用）；Blinding Vale（启用）。** [[spell:58875]]
- **适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）。** [[spell:378075]]
- **适用条件：密谋小径（启用）。** [[spell:8143]]
- **适用条件：毒牙祭坛（启用）。**
  
  
  
  
  - 使用[[spell:383013]]驱散[[spell:1307567]]
    **乌拉特克的选民**。请注意，如果可能的话，你应该并且可以打断这个施法。
  - 使用 [[spell:192077]] 配合 [[spell:462820]] 移除由其施加的 [[spell:1294569]] **双牙劫掠者**。你也可以使用 [[spell:378075]] 或 [[spell:58875]] 将其从自己身上移除。
- **适用条件：纳洛拉克的洞穴（启用）。**
  
  
  
  
  - 使用 [[spell:58875]] 摆脱由其施加的 [[spell:1241463]]
    **天神下凡之决心**.
  - 使用 [[spell:51886]] 驱散由其造成的 [[spell:1238801]] **饥饿之灵**'s **饥荒雕像**.
  - 在期间使用 [[spell:383013]] 移除 [[spell:1234846]] **囤宝狂人** 首领战斗中。
  - 使用 [[spell:370]] 移除其使用的 [[spell:1297696]] **低语大地看守者**。请注意，如果可能的话，你应该并且可以打断这个施法。
  - 使用 [[spell:192077]] 配合 [[spell:462820]] 驱散由其施加的 [[spell:1309919]] **严寒槌手**。请注意，如果可能的话，你应该并且可以打断这个施法。你也可以使用 [[spell:378075]] 或 [[spell:58875]] 将其从自己身上移除。
  -
- **适用条件：诸王之眠（启用）。**
  
  
  
  
  - 使用 [[spell:370]] 移除由其造成的“精神控制”效果 [[spell:270920]] **瓦希女王** 在 **殓尸者姆沁巴**.
  - 使用 [[spell:370]] 移除其施放的 [[spell:270901]]
    **总管姆巴拉** 在 **殓尸者姆沁巴**.
  - 使用 [[spell:51485]] 定身并减速 **活化金币** 这样它们在期间就不会到达首领 **黄金风蛇** 首领战斗中。
  - 使用 [[spell:51886]] 驱散其施放的 [[spell:269972]]
    **暗影之裔巫医** 以及其施放的 [[spell:270492]] **幽灵妖术 妖术 牧师**。注意，这两个都是你应该在可能时打断的施法。
- **适用条件：密谋小径（启用）。**
  
  
  
  
  - 使用 [[spell:51886]] 驱散其施放的 [[spell:1217973]]
    **堕落的 术士**
  - 在与的首场首领战中使用 [[spell:383013]] 移除 [[spell:474515]] **赞恩·刃悲**
  - 使用 [[spell:8143]] 移除其引导的 [[spell:1201554]]
    **魅惑萨亚德**。注意，这应该是最后的手段，因为当可能时应该改为打断它，并且[[spell:51490]]也能阻止它。
- **适用条件：红玉新生法池（启用）。**
  
  
  
  
  - 你可以使用 [[spell:370]] 从身上移除 [[spell:373973]]
    **Primalist Flamedancer** 以终结它们，或从 [[spell:391031]] 中移除 **原始雷云**.
  - 如有必要，可使用 [[spell:192077]] 配合 [[spell:462820]] 来移除由...施加的若干层 [[spell:373803]] **灌能雏龙** 以防止 [[spell:373593]] 发生。
- **适用条件：塞塔里斯神庙（启用）。**
  
  
  
  
  - [[spell:51490]]在这个地下城中非常有用，可以打断[[spell:1290031]]和[[spell:1308113]]的引导，并防止 **Faithless Tormentor**
    在 **塞塔里斯的化身** 最终首领战期间到达首领。对于最后这种情况，你也可以使用[[spell:51485]]。
  - 使用 [[spell:383013]] 移除由...造成的 [[spell:267027]] **Venomous Ophidian** 在第二场首领战期间 **米利克萨**。请注意，在可能的情况下，这应该改为打断。
  - 使用 [[spell:51886]] 驱散由...施加的 [[spell:1293307]]
    **Faithles Tender**。请注意，在可能的情况下，这应该改为打断。
- **适用条件：Blinding Vale（启用）。**
  
  
  
  
  - 在第二场首领战中使用 [[spell:58875]] 移除 [[spell:1236658]] **圣光猎手伊库兹**.
  - 使用 [[spell:383013]] 移除由...造成的 [[spell:1250937]] **土豆蟾蜍女族长**.
- **适用条件：虚空之痕竞技场（启用）。**
  
  
  
  
  - 在第二场首领战中使用 [[spell:383013]] 移除 [[spell:1226120]] **阿特洛苏斯**.

1.

### 应对词缀

至暗之夜 第二赛季只有四个重要的 词缀 提供了某种应对手段，称为萨拉塔斯的交易。它们每周轮换，同一时间只有一个处于激活状态。每个交易在被处理后会提供一套独特的增益效果，虽然它们很强大，但并不需要你以特定方式来应对。关键是不要让其中任何一个强化敌方小怪或首领。

### 升腾

6.1.

#### 萨拉塔斯的交易：萨满祭司 元素专精的升腾应对

元素有相当多的方法来应对此词缀：

- [[spell:370]]
- [[spell:51490]]
- [[spell:192058]]

### 脉冲星

6.2.

#### 萨拉塔斯的交易：萨满祭司 元素专精的脉冲星应对

这里没什么特别的，只需确保在你没有生命危险时去吸收它们，因为它们会造成大量伤害。至少靠近一名其他队伍成员，这样你的脉冲星也会被吸收。

### 吞噬

6.3.

#### 萨拉塔斯的交易：萨满祭司 元素专精的吞噬应对

[[spell:383013]]或搭配[[spell:462820]]的[[spell:192077]]可以瞬间驱散所有东西。相当强大！

你可以使用[[spell:378075]]或[[spell:58875]]来解除自身的该效果。

你也可以点出[[spell:51886]]，但除非它在该特定地下城中表现出色，否则通常没必要这么做。

### 虚空束缚

6.4.

#### 萨拉塔斯的交易：为元素萨满祭司管理虚空束缚

快速击杀虚空大使。就这么简单。不过不值得为它留爆发技能，除非它们莫名地没能及时死掉。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月17日：** 为 至暗之夜 第二赛季更新，新增了每个地下城推荐功能型天赋的速查表。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 为每个地下城添加了关于功能性法术具体用途的额外信息，更新了功能速查表。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为职业门槛解锁的改动更新了天赋树。
- **2026年1月19日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月15日：** 更新了关于先知大秘境配装的推荐。
- **2025年8月12日：** 新增了更多地下城技巧。
- **2025年8月10日：** 修复了 先知 大秘境配装未使用大地震击的问题。
- **2025年8月4日：** 已为11.2版本和第3赛季更新并审核。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月29日：** 重新添加了因误操作而被吞掉的元素冲击天赋选择行。
- **2025年3月1日：** 为数个地下城添加了更多推荐的实用工具。
- **2025 年 2 月 24 日：** 已针对「地心之战」第2赛季更新。
- **2024年12月15日：** 已针对11.0.7补丁更新和审阅。
- **2024年10月22日：** 已针对11.0.5补丁进行更新。
- **2024年10月1日：** 调整了部分副本专属天赋推荐。
- **2024年9月9日：** 全面更新并重新整理了页面，添加了多种配装及其用途、特定副本配装和信息、额外的技能和词缀推荐。
- **2024年8月19日：** 更新了一些初步信息。
- **2024年8月12日：** 为11.0.2版本进行了更新，新增了混合大秘境配装。
- **2024年7月20日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 更新了10.2配装，将 火焰 放在最前面，因为它与T31最为相关。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023 年 7 月 11 日：** 修正了仍指向第1赛季页面的一些链接。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月6日：** 添加了更多关于天赋/配装选择的建议。
- **2023年5月1日：** 移除了对非第2赛季词缀的提及。添加了如何应对第2赛季3个新词缀的技巧，调整了默认天赋推荐。调整了一些措辞。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 调整了地下城推荐的火焰配装以获得更多AoE爆发。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些实用的宏和插件，让你在魔兽世界12.1.5补丁中游玩你的元素萨满祭司时更加轻松。

1.

### 最佳宏

欢迎来到我们的插件与宏页面。在这里我们将介绍一些有用的插件，你可以通过更信息丰富的界面来提升游戏体验，同时提供一些常用的元素萨满祭司宏。你只需点击每个代码块上的"Copy"按钮即可导入这些宏。

1.1.

#### 风剪

#### 焦点打断

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 风剪
```

这个宏会停止你当前的施法，并对你的焦点目标施放[[spell:57994]]（如果焦点目标存在），否则会对你的目标施放。

1.2.

#### 净化术

#### 焦点驱散

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 净化术
```

这个宏会停止你当前的施法，并对你的焦点目标施放[[spell:370]]（如果焦点目标存在），否则会对你的目标施放。

1.3.

#### 狂风图腾

有两种选择可用，允许你立即在脚下施放[[spell:192077]]：

#### 在脚下施放狂奔

```wow-macro
#showtooltip
/stopcasting
/cast [@player] 狂风图腾
```

或者在你当前光标位置施放：

#### 在光标处施放狂奔

```wow-macro
#showtooltip
/stopcasting
/cast [@cursor] 狂风图腾
```

这些宏省去了一次点击，让你能比平时更快地激活图腾，从而快速获得移动速度加成。

1.4.

#### 先祖迅捷宏 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/farseer.webp>) 先知

为了保持最大覆盖率并让技能尽可能易于使用，我们建议将[[spell:443454]]至少绑定到[[spell:51505]]上，这样可以在无需思考的情况下最大化覆盖率。用这个宏替换你的熔岩爆裂快捷键，你也可以对[[spell:188196]]和[[spell:188443]]做同样的操作：

#### 熔岩爆裂上的先祖迅捷

```wow-macro
#showtooltip 熔岩爆裂
/use 先祖迅捷
/cast 熔岩爆裂
```

1.5.

#### 常驻增益施法序列宏

这个宏会用一个按钮按顺序施放你的两个常驻增益。多亏了[[spell:1270350]]，你只需要两个公共冷却时间就能施加所有增益，因为施加[[spell:192106]]会免费附带施加[[spell:974]]、[[spell:318038]]和[[spell:462742]]（如果点了天赋）。注意你可能至少还需要一个单独的[[spell:974]]快捷键，这样你才能在地下城中或战斗中给其他人施放和刷新它。

#### 常驻增益施法序列

```wow-macro
#showtooltip
/castsequence reset=10 天怒, 闪电之盾
```

1.6.

#### 图腾投射施法序列宏

这个宏会在你的光标位置先施放[[spell:192077]]再施放[[spell:108287]]。它可以调整为用于任何图腾。

#### 狂奔 + 图腾投射

```wow-macro
#showtooltip
/castsequence [@cursor] reset=20 狂风图腾, 图腾投射, 图腾投射
```

1.7.

#### 光标/鼠标悬停地震术、电容图腾 & 烈焰震击

这个宏会在你光标的当前位置施放[[spell:61882]]，省去目标选择圈。使用这个宏要小心，因为它很容易导致失误，但有些玩家更喜欢它提供的速度和便利。你可以将地震术替换为电容图腾。

#### 在光标处施放地震术

```wow-macro
#showtooltip
/cast [@cursor] 地震术
```

下面的宏会对你的光标所指的目标施放[[spell:188389]]。如果你的光标没有指向任何敌人，则会对你的当前选中目标施放。

#### 在光标处施放烈焰震击

```wow-macro
#showtooltip
/cast [@mouseover,exists]烈焰震击;烈焰震击
```

1.8.

#### 幽魂步 + 时间螺旋滥用宏

这个宏利用了[[spell:58875]]和[[spell:79206]]不占用公共冷却时间的特性，让我们能通过同时获得两个技能的收益来"双重享受"[[spell:374968]]。

#### 双重享受时间螺旋

```wow-macro
#showtooltip
/stopcasting
/cast 幽魂步
/cast 灵魂行者的恩赐
```

1.9.

#### 焦点目标宏

这个宏将一个目标指定为你的焦点，并可选地立即对它施放一个法术。通常与[[spell:57994]]一起使用，但对大多数法术都有效。

#### 焦点目标

```wow-macro
/focus [@focus,noexists]
/cast [@focus] 风剪
```

1.10.

#### 原始火焰元素流星宏

这个宏允许你手动施放你的原始[[spell:198067]]的[[spell:117588]]技能。注意，既然元素现在可以自动施放该技能，除非你特别想手动使用，否则这个宏在大多数情况下并不实用。

#### 手动流星

```wow-macro
#showtooltip
/use [pet:primal fire elemental]流星
```

当天赋选择中出现两个主动技能二选一的情况时，也可以使用类似的宏。在至暗之夜中，只有2处额外的用法：[[spell:192063]]对比[[spell:58875]]，以及[[spell:8042]]对比[[spell:117014]]。例如：

#### 共用按键移动

```wow-macro
#showtooltip
/use [known:阵风]阵风;[known:幽魂步]幽魂步
```

下一个宏允许你在鼠标悬停的盟友身上施放[[spell:974]]（如果点了[[spell:383010]]天赋）。如果你的光标没有指向盟友，或者没有点之前的天赋，则会对你自己施放大地之盾。

#### 鼠标悬停施放大地之盾

```wow-macro
#showtooltip
/use [@mouseover,help,nodead,known:383010]大地之盾;[@player]大地之盾
```

1.11.

#### 仅限地精！阵风和火箭跳宏

地精玩家也可以使用施法序列宏，在[[spell:192063]]处于冷却时使用[[spell:69070]]。

#### 地精跳跃

```wow-macro
#showtooltip
/castsequence reset=14 阵风, 火箭跳
```

1.12.

#### 治疗或复活盟友

这个宏通常会在盟友死亡时复活他们，或者在他们存活时治疗他们。

#### 标题文本

```wow-macro
#showtooltip
/use [@mouseover,help,dead]Ancestral Spirit;[@mouseover,help,nodead]治疗之涌;[dead]Ancestral Spirit;治疗之涌
```

1.13.

#### 敌我自适应宏

下面的宏会根据你选择的是敌人还是盟友来施放[[spell:370]]或[[spell:51886]]：

#### 净化术和驱散灵魂共用按键

```wow-macro
#showtooltip
/use [@mouseover,harm,nodead,known:净化术]净化术;[@mouseover,help,nodead]净化灵魂;[harm,known:净化术]净化术;净化灵魂
```

下面的宏会根据你选择的是敌人还是盟友来施放[[spell:188443]]或[[spell:1064]]。注意你实际上永远不应该使用治疗链。

#### 链式法术共用按键

```wow-macro
#showtooltip
/use [@mouseover,harm,nodead]闪电链;[@mouseover,help,nodead]治疗链;[harm]闪电链;[]治疗链
```

你可以选择从这个宏中移除单独的部分。例如，如果你永远不想在鼠标悬停时施放治疗链，请移除：

#### 可调整部分

```wow-macro
[@mouseover,help,nodead]Chain Heal;
```

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.

#### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月20日：** 更新了驱散/净化宏。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对至暗之夜上线进行了审查。
- **2026年2月26日：** 添加了一键复制整个宏的功能。已针对至暗之夜上线更新。
- **2026年2月10日：** 已针对至暗之夜前夕进行更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月14日：** 新增了WeakAura插件包的选择，以及风暴使者专属的WeakAuras和一个可选的融合用WeakAura。修复了先祖迅捷宏重复的问题。
- **2025年8月7日：** 更新了先祖迅捷宏命令部分。
- **2025年8月4日：** 已为11.2版本更新并审核。移除了风暴召唤/闪电链宏（不可靠且非最优）。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月7日：** 为风暴使者用户添加了风暴打击+闪电链宏。
- **2025 年 2 月 24 日：** 添加了时间螺旋"滥用"宏。已针对11.1补丁进行审阅。
- **2024年12月15日：** 已针对11.0.7补丁更新和审阅。
- **2024年10月22日：** 已为11.0.5版本更新并审查。
- **2024年9月9日：** 移除了不必要的宏，添加了先祖迅捷宏。
- **2024年8月21日：** 添加了取消光环宏，在@cursor宏中添加了液态岩浆图腾。
- **2024年7月23日：** 修正了风行/灵魂行者宏中的一个拼写错误。
- **2024年7月23日：** 添加了各种实用宏，移除了几个即将过时的宏。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对巨龙时代第4赛季进行审查。
- **2024年3月17日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月31日：** 移除了过时的硬化皮肤宏，更新了其他几个宏使其更有用。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
