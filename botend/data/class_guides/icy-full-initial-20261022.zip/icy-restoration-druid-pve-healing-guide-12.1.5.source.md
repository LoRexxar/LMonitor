## 专精概览

Welcome to our Restoration Druid guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Restoration Druid in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Restoration Mythic+ Resources

[NEW! Top Restoration Talent Builds](<https://raider.io/specs/restoration-druid/talents>)

[Top Restoration Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/restoration>)

[Restoration Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--restoration>)

[Popular Restoration Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--restoration>)

1.

### Restoration Druid Overview

Restoration Druids specialize in doing strong bursts of healing after using
cooldowns in raids. Restoration Druids also do well when healing a small number of
targets for a prolonged period (for example, in dungeons).

To properly play a healing role, you will need more than just class-specific
information. To better understand healing in general, we recommend that you read
our [healing guide](<https://www.icy-veins.com/wow/healing-guide>).

Strong

Restoration Druid was decent but overshadowed early in the season, but has blossomed as
  the season progressed thanks to a few nice buffs and more familiarity with the new rotation.

More generally speaking, our position in the raid meta tends to vary a lot from season to season -
usually based on how strong the other Druid specs are since [[spell:1126]] is an essential raid buff. From a healing
perspective we are very versatile, and have a great combination of sustained healing
and burst and can optimize further into one or the other with our talent choices.

Historically Dominant

Restoration is a famously strong Mythic+ healer and has been the dominant choice
in many seasons including the first few months of Midnight. The spec is
especially well designed for healing smaller group content which means that we're also
a great choice for people looking to get into healing for the first time. On the very
top end, Restoration Druid isn't one of the "meta" picks right now.

Our mastery ([[spell:77495]]) in particular is practically designed for
dungeon content since you will have a much higher concentration of heal-over-time effects
on targets. When comfortable we also have the ability to bring decent damage via
weaving in melee abilities in Cat Form and we also bring one of the strongest buffs
and decent crowd control (see utility section).

Big Raid Buffs; Decent Crowd Control

Restoration brings the most powerful raid buff in the game with

[[spell:1126]]

along with a large collection of crowd control like

[[spell:102793]]

,

[[spell:132469]]

,

[[spell:33786]]

and

[[spell:102359]]

which are all useful,
if sometimes situationally so. They tend to be a more core part of your gameplay in
dungeon content like Mythic+ as opposed to raid. As a healing spec we also bring

[[spell:88423]]

which is a dispel ability.

Ample Passive and Active Defensives

Restoration Druid is one of the tankiest healing specs in the game. It combines
excellent self-healing via talents like

[[spell:377847]]

and

[[spell:474750]]

with low-cooldown defensives like

[[spell:22812]]

. You also have insurance against massive hits
with

[[spell:5487]]

and associated talents like

[[spell:377842]]

. It's also
very easy to put heal-over-time effects on yourself like

[[spell:774]]

whenever
you're in danger. As a Restoration Druid you'll have multiple solutions to every
type of damage.

Heal on the Move

Restoration also has very strong mobility, with many of our spells being instant
and so castable on the move. We also have a lot of mobility talents and abilities
like

[[spell:131768]]

,

[[spell:102401]]

,

[[spell:1850]]

,

[[spell:106898]]

and more. Our only downside is our current reliance on

[[spell:8936]]

for tough
healing moments since we need to plant in one spot to cast. As a Druid you can also forgo
 mounts if you like since

[[spell:783]]

is just as fast!

Decent but Time Consuming. Bad Passive DPS.

In raid, Restoration Druid is one of the lower DPS healing specs since we don't
have a lot of passive damage options. Thankfully healer DPS is not particularly
important in the current game. In Mythic+, we have more DPS options since
our healing rotation requires less time investment and we can make up a larger
portion of the groups damage. We still lack passive damage so you'll spend time in

[[spell:768]]

to maximize damage instead. This can take some getting used to but
is rewarding when you master it.

2.

### Restoration Druid in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 offers a minor revamp to the [[spell:1263879]] talent, making it significantly
  easier to use. It also brings two new key pieces of content: a new mega-delve known as a 
  labyrinth, and a new raid where you'll face Kith'ix!

You will also be able to upgrade fully upgraded Myth or Hero track necks, trinkets, and
  weapons (including offhands) via the Ascendant Venomstone system which returns a week
  after the patch goes live.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Chest. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

2.3.

#### Class Changes

Sadly, there are no changes to Restoration Druid in Patch 12.1.5. We have updated our
[gear](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>) page with new information on the gear
from the [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) raid encounter, as well as recommendations on how to
spend your first [[item:280562]].

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_treeoflife.jpg>)Click for Previous Season 2 Changes
2.4.

#### Season 2 Class Changes

Restoration Druid received a mini-rework when Season 2 began in patch 12.1. Significant changes to [[spell:207383]]  
  heavily altered how much you cast each spell. If you're returning to the game, 
  expect Restoration Druid to be a little simpler than in the past, but with enough depth to keep you interested. Here are the big changes:

- [[spell:207383]] reworked. It is now active when you have 5 [[spell:774]]s active instead of scaling
      with the quantity. Crit and Mana cost reductions set to 60% instead of scaling.
- [[spell:29166]] reworked. It now restores 25% of your maximum mana instead of making your spells free for
      eight seconds. This version will be much easier to use and is stronger.
- [[spell:392410]] no longer extends HoTs on your [[spell:18562]]s target.
- [[spell:48438]] healing increased by 20%. Mana cost increased by 15%.
- [[spell:774]], [[spell:8936]], [[spell:18562]] mana costs reduced.
- [[spell:740]] now gives you a shield for 60% your maximum health while channeling.
- [[spell:33891]] now casts [[spell:8936]] on 3 injured allies.
- Several talents changed places in the tree, like [[spell:155675]] swapping places with [[spell:392325]].

:::

### Midnight   Changes Overview

2.5.

#### Midnight Changes for Restoration Druid

Midnight brings with it a massive overhaul to Restoration Druid and 
  healing as a whole. It also includes sweeping UI changes which affect Restoration Druid
  more than a lot of other specs. The overall objective is to make the game more accessible
  by removing how many addons you need to play the game competitively, as well as making
  specs themselves easier to get into. They did succeed in making specs easier to play, 
  though the user interface changes have had a disastrous roll out so far.

2.6.

#### New Apex Talents

The new talent addition in Midnight is the "Apex Node". It acts as a tier 3 spec talent
  node but you can put up to 4 points in it. Ours is called Everbloom and it does the following:

- Point 1 ([[spell:392167]]): [[spell:33763]] stacks up to 3 times, stacking every 5 seconds.
- Points 2 and 3 ([[spell:1244331]]): 20/40% of [[spell:33763]]s "bloom" healing splashes to up to 6 nearby allies.
- Point 4 ([[spell:1244470]]): When you cast [[spell:18562]], your [[spell:33763]] blooms
    3 times in quick succession.

Our Apex node is extremely powerful in Mythic+, but only on the edge of viability in Raid. It excels
  at making one target (whoever has your [[spell:33763]] near immortal) which is very useful when
  you only have five people to heal.

2.6.1.

##### Hero Talent Changes

Both hero trees got three new nodes for the expansion and you are able to take all of them at level 90.

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker tree plays very similarly to The War Within. It still focuses on
  putting out [[spell:439530]] and offering both healing and large healing taken increases
  to those with the buff. The proc rate of [[spell:439530]] has been nerfed a little bit,
  and there are some new generic heal-over-time increases like [[spell:1270592]]. It
  continues to be an extremely strong tree in Mythic+ but expect it to be a bit weaker in raid.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove sees larger changes due to the [[spell:102693]] ability now
  being passive instead of an active button. [[spell:102693]] now proc whenever you cast
  [[spell:18562]] and [[spell:48438]]. This simplifies Keeper of the Grove gameplay by
  removing the need to stack charges and drop them all at once during burst. The flavor of the tree
  remains, but it should feel like it's giving you more straightforward healing increases now instead
  of requiring specific gameplay to maximize. You also get a lot more [[spell:102693]] overall
  than you did before. The new hero tree talents in Midnight also give you even more [[spell:18562]]
  casts which will play well given how many effects are now attached to it.

2.6.2.

##### Healing Changes

There were two major changes to Restoration Druid in Midnight:

- Many small heal-over-time effects were removed like Spring Blossoms and Cultivation. 
    With the user interface changes, tracking many HoTs at once has become burdersome so 
    they removed a bunch of smaller ones. These usually didn't have gameplay interactions
    anyway. Our Mastery effect ([[spell:77495]]) was buffed significantly to 
    compensate the loss of HoTs.
- Our frequent cooldowns are now available less often. [[spell:197721]] was turned into a passive
    that procs when you cast Tranquility instead which turns its former one minute cooldown
    into three. This might seem quite bad but Blizzard have pruned healing cooldowns across all
    specs. The goal is for healing to be based around which rotational buttons you press instead
    of countering every mechanic with a major healing cooldown.

Despite all of the changes, your rotation won't be greatly different. You will still prepare
  for upcoming damage with [[spell:774]], and you will still pay off your ramp by casting
  Regrowth as damage hits (to take advantage of [[spell:207383]]). You'll continue to maintain 
  [[spell:33763]] and [[spell:145205]] (though [[spell:1217941]] makes the latter easier) and 
  [[spell:18562]] and [[spell:48438]] remain key rotational casts.

2.6.3.

##### Midnight User Interface Changes

Midnight completely revamps the games UI by adding heavy restrictions
  to a lot of addons. This means that addons you might have used for decades like Grid2, Cell, or
  Weak Auras might no longer be available and even if they are they'll be in a much more restricted
  format. In exchange for the loss of a lot of combat addons, Blizzard have been working on the base
  user interface. It still leaves a lot to be desired though.

3.

### Basics of Restoration Druid Gameplay

Restoration Druid is all about using your abilities strategically. Rather
than a fixed rotation, you will be using your flexible spell kit to adapt and
overcome whatever the game throws at you.

Two abilities require constant maintenance throughout the combat:
[[spell:145205]] and [[spell:33763]]. [[spell:48438]] has a
relatively low cooldown, high Mana efficiency, and high group-wide healing. [[spell:18562]]
does moderate healing, but also procs numerous other talents like [[spell:158478]].
Using these four spells often is essential to good Restoration Druid gameplay.
[[spell:774]] will be used as a filler spell for as much as your
Mana will allow, but preferably concentrated around heavy group damage and
coupled with your cooldowns such as [[spell:33891]], [[spell:29166]].
After damage hits you will use [[spell:8936]] to heal anyone still injured.
To break the specialization down further, reference the following bullet points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_empoweredrejuvination.jpg>) **Keep Abundance Active**  
  
    Your [[spell:207383]] talent supercharges your [[spell:8936]] ability by greatly increasing its crit chance and reducing its mana
  cost. A lot of Restoration Druid gameplay revolves around taking advantage of these cheap casts. Keeping five [[spell:774]] buffs
  out should be fairly trivial - especially given you can use [[spell:158478]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_herb_felblossom.jpg>) **Keep Lifebloom Active**  
   
    Your [[spell:33763]] lasts for 15 seconds and can only be put on one target at a time. Keep it active at all times, since our "Apex talent" [[spell:1244470]]
  relies on it being active. With [[spell:33763]] up, every [[spell:18562]] cast will do a ton of AoE healing.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_relics_idolofrejuvenation.jpg>) **Cast Swiftmend on Cooldown**  
  
  [[spell:18562]] has a ton of attached effects like [[spell:158478]] and [[spell:1244470]]. That means you should cast it as often as you can. In raid, you will mostly cast it on yourself,
  in Mythic+ you can cast it on anyone injured, though make sure you still cast it on cooldown regardless.

4.

### How to Gear Up a Restoration Druid

Gearing can get complicated as a healer due to many variables and
multiple available group sizes. You can find information on how best to gear a
Restoration Druid on the gearing page, which includes Best in Slot recommendations for this tier.
After acquiring gear, you will want to ensure you have the best
consumables, gems, and enchants. Both guides can be found below and will 
provide you with the most up to date information.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Midnight Launch.
- **26 Feb. 2026 (this page):** Updated for Midnight Launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for changes in Patch 11.2.5.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Reviewed for Patch 11.2.5.
- **26 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated talent recommendations.
- **20 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations.
- **12 Aug. 2025 (this page):** Updated for season start hotfixes.
- **06 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated some gear recommendations.
- **06 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Showing stat priority as a list.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.0.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 11.2.0.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 11.2.0.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.0.
- **24 Jul. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.2.0.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **23 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Changed talent recommendations due to tier set changes.
- **23 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Changed talent recommendations due to tier set changes.
- **16 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Changed raid trinket recommendations.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** Updated boss recommendations for Heroic and Mythic.
- **03 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** Added some boss recommendations for Normal and Heroic.
- **03 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Added season 2 recommendations and new tier set analysis.
- **25 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated trinket rankings.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** Updated cooldown recommendations for some bosses.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated low target count spell priority.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** Updated some boss recommendations and talent builds.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **18 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** Updated the guide with cooldown advice.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for TWW Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for TWW Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for TWW Season 1.
- **09 Sep. 2024 (this page):** Reviewed for TWW Season 1.
- **29 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Minor updates.
- **29 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Added Wildstalker dungeon build and added clarifications on some talents.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **20 Aug. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/restoration-druid-mists-of-pandaria-remix-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for The War Within pre-patch.
- **23 Jul. 2024 (this page):** Updated for The War Within pre-patch.
- **20 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/restoration-druid-the-war-within-pve-guide>)):** Updated for The War Within pre-patch.
- **20 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for The War Within pre-patch.
- **19 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/restoration-druid-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/restoration-druid-mists-of-pandaria-remix-guide>)):** Page added.
- **14 May 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated Mythic+, embellishment and trinket recommendations.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **26 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.6.
- **20 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.2.6.
- **20 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated trinket list with Spark of Hope and updated for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Reviewed for Patch 10.2.5.
- **02 Dec. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated the talent tree.
- **26 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated BiS list and trinket recommendations for raids.
- **21 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Added Efflorescence WeakAura.
- **21 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated talent recommendations.
- **21 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated talent recommendations.
- **11 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated gear recommendations for Amirdrassil.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated embellishment and trinket recommendations.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **31 Aug. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.7.
- **12 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated pathing and talent choice recommendations for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **07 May 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated Leech values for Patch 10.1.0.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.1.0.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.1.0.
- **01 May 2023 (this page):** Updated for Patch 10.1.0.
- **28 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Patch 10.1.0.
- **28 Apr. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 10.1.0.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated Onyx Annulet recommendations.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated Onyx Annulet recommendations.
- **24 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Changed rotation recommendations for raiding.
- **24 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated raid talent recommendations.
- **24 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Changed build recommendations.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/restoration-druid-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Reviewed for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **29 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Adjusted some enchant and consumable advice.
- **29 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Changed talent build advice.
- **29 Dec. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Changed spell priorities and Convoke the Spirits advice.
- **29 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Minor fixes.
- **29 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Adjusted talent advice for both Mythic+ and Raids.
- **29 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Adjusted recommended talent builds.
- **12 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Fixed food and gem advice.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated with Vault of the Incarnates and Mythic+ loot.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated with crafting recommendations and tier set analysis.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Added advice for boots enchant.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Adjusted DPS rotations.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Small updates to Mythic+ rotation and tier set advice.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Added more Mythic+ build options.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **30 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Changed talent build recommendation. .
- **30 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated Regenesis advice.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/restoration-druid-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/restoration-druid-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/restoration-druid-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/restoration-druid-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-spell-summary>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **31 May 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Page reviewed for Patch 9.2.5.
- **23 Apr. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** Updated with live data.
- **18 Feb. 2022 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 9.2.
- **10 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** Updated for latest PTR builds.
- **21 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** Updated with changes from latest PTR build.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** Updated for 9.1.5.
- **29 Oct. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated for Patch 9.1.5.
- **08 Aug. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** Updated information.
- **28 Jun. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed and approved for Patch 9.1.
- **21 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** Updated some information after recent PTR patch.
- **19 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/restoration-druid-patch-9-1-changes-analysis>)):** Page created with initial information.
- **09 Mar. 2021 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Reviewed for Patch 9.0.5.
- **23 Nov. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Updated with Balance affinity rotations.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **12 Oct. 2020 ([DPS guide](<https://www.icy-veins.com/wow/restoration-druid-pve-dps-guide>)):** Page updated for the Shadowlands pre-patch.
- **17 Sep. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** Updated recommendations. .
- **09 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** Updated recommendations.
- **25 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** Updated recommendations for the first 3 bosses.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **18 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-crucible-of-storms-raid-guide>)):** Updated tips for both bosses. .
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-crucible-of-storms-raid-guide>)):** Guide added.
- **23 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added Mythic Jaina advice, clarified Stormwall Blockade Phase 2. .
- **07 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** Added some clarification to all encounters. .
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-battle-of-dazar-alor-raid-guide>)):** Page created.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** Updated for Patch 8.1.
- **21 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** Added some suggestions for Mythic versions of the bosses. .
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** Updated recommendations for Fetid Devourer. .
- **01 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** Updated talents.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-uldir-raid-guide>)):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Restoration Druid leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Druid leveling guide](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### Restoration Druid Leveling Guide for Midnight

Leveling as a healer is quite a lot slower than DPS or tank specs since we do not kill things very quickly. Expect a longer journey. You can also take advantage
of dungeon content to put your healing abilities to use. It is quite common to level as one of the Druid DPS specs LinkEngineering
Balance or Feral and then swap to Restoration at max level but it is your choice.

If you do persist as a healer then you will want to take advantage of your amazing survivability by pulling a lot of enemies at once - 
particularly once you have picked up a few talent points. As a Druid you also have access to [[spell:5215]] which allows you to skip some
enemies entirely since it puts you in "stealth" where enemies are much less likely to detect you. You can use this ability to skip past tricky 
mobs to get quest items.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Consumables for Midnight

To level fast, you will want to focus on minimizing downtime and increasing damage
as much as possible. You will also want to take advantage of your powerful healing capabilities
by pulling as many enemies at a time as possible. You do not need any special items to level,
but picking up a few of these beforehand might hasten your journey:

- Flask of Tempered Swiftness: Flasks are a decent way to add damage without having to pay a high price. Haste is a great choice.
- Tempered Potion: Combat potions can speed up big pulls or difficult mobs.
- Silvermoon Health Potion: You do not really need healing potions when levelling as a healing spec, but these
  are very good and can be used from level 81 onwards.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Restoration Druid Level 80 Midnight Leveling
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNzMglZsYbGAAAAAAAAAAsNoZjxkhZmxsZmZmZZGYAAAAAAAwAAAAAghZrZZsYDmZgZWAZAAmZAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNzMglZsYbGAAAAAAAAAAsNoZjxkhZmxsZmZmZZGmZAAAAAAAwAAAAAgZZmtmlZWsBzMwMLgMAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BRQNKKTTA7kyALiUxRsu+ZdTTrFWq6onwQR-FDhWWLNO0AQRO+BKV50zpzUJrKkP1rL-AAAA-RGUAQ8gRDziQgE-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section, we will highlight the most useful War Mode PvP talents to 
speed up your levelling process. Unfortunately, none of the others provide
anything useful in terms of damage output.

- [[spell:305497]] provides incredible damage against any enemies that hit you
  in melee.
- [[spell:377801]] slightly increases your movement speed while
  leveling.
- [[spell:233755]] can be paired with [[spell:102359]] to pull a lot
  of mobs and DoT them all up.
- [[spell:1217474]] can be a nice healing bonus, if you are leveling in a group.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 1–9：**Starting at Level 1, you only have one main
attack ability: [[spell:190984]].

- **等级 53 起：**[[spell:391528]] is a great spell to
  damage an enemy and heal your group quickly. Use it as often as possible.
- **等级 2 起：**[[spell:8921]] is a damage over time
  spell that you should use against any enemy you are fighting. It's particularly
  good at pulling new enemies into combat with you.
- **等级 7 起：**[[spell:22568]] deals damage based on the
  amount of combo points spent. The damage is increased further for each Energy
  point used beyond 25, up to 25 extra.
- **等级 20 起：**Use [[spell:1079]] instead of Ferocious Bite
  if you expect the enemy to live long enough for the DoT to do all the damage.
- **等级 10 起：**You gain your first talent point, spend it on
  [[spell:1822]]. Use Rake and Moonfire to DoT up multiple enemies.
- **等级 5 起：**[[spell:768]]. You move 30% faster in Cat
  Form.
  This also unlocks [[spell:5221]], a single target attack only usable in Cat Form
  and awards 1 Combo Point. Use [[spell:1822]] instead most of the time.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for TWW Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **26 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **02 Dec. 2023:** Updated the talent tree.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Restoration Druid in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Restoration Druid

This page is intended for players who are new to the game or class, have no
intentions of raiding Mythic difficulty, or want a more straightforward way to
play their specialization without being overwhelmed by the numerous subtleties
and active abilities that need to be taken into consideration for optimal play.

Restoration Druid relies on HoTs to set up strong bursts using
[[spell:391528]] in raids, while also having strong and steady output in dungeons. They
have good healing on single targets, but require some time to set up their HoTs.
They require knowledge of the encounter to prepare for the incoming damage.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_empoweredrejuvination.jpg>) **Keep Abundance Active**  
  
    Your [[spell:207383]] talent supercharges your [[spell:8936]] ability by greatly increasing its crit chance and reducing its mana
  cost. A lot of Restoration Druid gameplay revolves around taking advantage of these cheap casts. Keeping five [[spell:774]] buffs
  out should be fairly trivial - especially given you can use [[spell:158478]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_herb_felblossom.jpg>) **Keep Lifebloom Active**  
   
    Your [[spell:33763]] lasts for 15 seconds and can only be put on one target at a time. Keep it active at all times, since our "Apex talent" [[spell:1244470]]
  relies on it being active. With [[spell:33763]] up, every [[spell:18562]] cast will do a ton of AoE healing.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_relics_idolofrejuvenation.jpg>) **Cast Swiftmend on Cooldown**  
  
  [[spell:18562]] has a ton of attached effects like [[spell:158478]] and [[spell:1244470]]. That means you should cast it as often as you can. In raid, you will mostly cast it on yourself,
  in Mythic+ you can cast it on anyone injured, though make sure you still cast it on cooldown regardless.

2.

### Beginner's Guide to Restoration Druid in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove   Raid Talents

2.1.

#### Beginner Raid Healing Talents for Restoration Druid

Use our calculator's 'Export Talents' to quickly import our build!

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthhxsZsNmBAAAAAAAAAAbDa2YMNzY4BMLzMzMDDzAAAAAAAAAAAAAwsNzSz2Mb2YMzMYGY0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQTzEIMVWy2AXXZBWkrLVNWTLMU88CD-FGHWWHCXq08ARmGk4QhM96qrqEno4nG-AAAA-BEIcEpJ4gRiSmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker   Dungeon Talents

2.2.

#### Beginner Dungeon and Delve Healing Talents for Restoration Druid

Use our calculator's 'Export Talents' to quickly import our build!

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8AMzsMjFbzAAAAAAAAAAgNDNLjx0MDwsZmZmZxwMAAAAAMAAzAAAAAgZZmtmlZWsxYmBmZD0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-NzKKMOkCIEVA74WtuBmVY1wUTrNmaq4ZYoH-FGrDhOUu0oQO2LF4Bi60pD3UJkPVttL-AAAA-REAaYIGYQRyhFD-
```

:::

### Restoration Druid   Basic Rotation

2.3.

#### Raid Rotation

The following rotation is a rough idea of what you should prioritize when
    playing. It does not include deeper details, and there are many small
    ways you could improve your gameplay, but it will give you a general idea.

- Maintain [[spell:145205]] under the melee group. Ignore if running [[spell:1217941]].
- Keep [[spell:33763]] on yourself.
- Use [[spell:18562]] on cooldown. Follow it up with [[spell:774]].
- Use [[spell:48438]] whenever the raid is heavily injured. It is expensive but heals for a lot..
- Cast [[spell:774]] in order to keep your [[spell:207383]] active (5 active).
- Cast [[spell:8936]] with [[spell:207383]] active. This will be your most common cast.
- Cast [[spell:5176]] to regenerate Mana (via [[spell:289237]]).

The Restoration Druid tier set is completely passive, and increases the amount your heal-over-time-effects heal. The buff is a rare
      proc on [[spell:774]] cast, and you will get a guaranteed stack on [[spell:740]], [[spell:391528]] and [[spell:132158]] casts.

2.4.

#### Dungeon Rotation

- Maintain [[spell:145205]] under the tank and melee. Ignore this if running [[spell:1217941]] (it's in the default build).
- Keep [[spell:33763]] on the tank. If they are standing away from the group then it is ok to put it on a DPS.
- Use [[spell:18562]] and follow it up with either [[spell:8936]] or
      [[spell:774]], depending on whether you need healing now or over the next 20 seconds.
- Cast [[spell:48438]] during light to moderate damage.
- Keep [[spell:774]] on the tank and on members of the group that just
      took damage or are about to take damage.
- During downtime, use [[spell:8921]], [[spell:93402]] and
      [[spell:5176]] on enemies to help contribute damage.

2.4.1.

##### Apex Talent: ![Everbloom Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_focusedgrowth.jpg>) Everbloom

The new talent addition in Midnight is the "Apex Talent" Node. It acts as a tier 3 spec talent
  node, but you can put up to 4 points in it. Ours is called "Everbloom", and it has the following effects.

- Point 1 ([[spell:392167]]): [[spell:33763]] stacks up to 3 times, stacking every 5 seconds.
- Points 2 and 3 ([[spell:1244331]]): Your [[spell:33763]] cleaves 20/40% of its "bloom" healing to up to 6 nearby allies.
        This includes talents that generate more blooms like [[spell:274902]]
- Point 4 ([[spell:1244470]]): When you cast [[spell:18562]], your [[spell:33763]] blooms
    3 times in quick succession.

Our builds all take the Apex talent so you will want to really emphasize keeping [[spell:33763]]
active on a target at all times.

2.4.2.

##### Cooldowns

- [[spell:740]] should be used during heavy raid damage or when you are
  assigned to use it by your raid leader. Make sure you cast [[spell:774]] beforehand
  since [[spell:740]] will extend them all.
- [[spell:29166]] should be used as often as possible during the
  fight. Use your first when you are at about 75% mana.
- [[spell:391528]] in raids should be used often. Cast some [[spell:774]]
    beforehand and try and line it up with the most dangerous moments of the fight.
- [[spell:102342]] should be used to reduce the damage a tank takes
  during critical moments (such as when important boss abilities are about to be
  cast). In the absence of such situations, you should use it on players who are
  taking damage. You may be assigned to use it at a specific time as part of a
  rotation with other healers and the tanks' cooldowns.

### Restoration Druid   Stat Priority

2.5.

#### Restoration Druid Stat Priorities

Intellect

Haste

Mastery

Versatility

Critical Strike

Intellect is stronger than all secondary stats, making most item level increases an upgrade.
   The only exceptions are rings
and necks. You generally want to equip higher item level ones, but there might
be small exceptions for those within 5 item levels.

Haste and Mastery are the strongest secondaries for pure healing. If your priority
is healing, then just equip Mastery and Haste because they are by far the strongest healing
stats in small group content. This also aligns your raid and dungeon stat priorities which
can be very useful.

For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>).

### Blizzard   Combat Assistant

2.6.

#### Combat Assistant

The [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) feature introduced in Patch 11.1.7 does not
work for healing. Both Combat Assistant and One-Button will only make you
use damage spells but you are better off just casting [[spell:5176]].
They will also not work at all when you are in
[[spell:5487]].

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **06 Aug. 2025:** Showing stat priority as a list.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **20 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.0.
- **24 Mar. 2023:** Changed build recommendations.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **29 Dec. 2022:** Adjusted recommended talent builds.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Restoration Druid in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Talents for Restoration Druid in Midnight

For Season 2, thanks to a few changes late into the first season that carried over into
Patch 12.1, Restoration Druid now plays the Wildstalker hero tree
in all content. While there are a lot of minor sidegrades available, the following
trees will serve you very well:

- **Raid -** While Keeper of the Grove is not unplayable, the raid playstyle will
  harness Wildstalkers multiple healing increases to greatly empower our Apex talents.
  It also offers unrivalled survivability and you will constantly and automatically return to full health.
- **Mythic+ -** Wildstalker will also be our go-to choice in Mythic+, though don't think of it
  as a cat-focused tree; it is more of a healing-focused one. It's a common misconception that playing Wildstalker
  necessitates Cat Form play, but instead we will actually be taking talents that empower our healing and caster-based
  DPS instead.

While you can make arguments for several minor talent swaps in different scenarios, you shouldn't
feel like you have to swap talents a lot. The builds below can be used in all levels of content from
absolute beginners to Hall of Fame / title-level Mythic+ keys.

**Quick Start Import Codes:**

:::talents Wildstalker Raid
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthBzsZsNmBAAAAAAAAAAbDa2YMNzY4BMLzMzMDDzAAAAAAAAAAIAAgZbmlmtZ2sxYmZwMwoZAAmZAYA"
}
```
:::

:::talents Wildstalker Mythic+
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZzw0MjZwsYmZmZZGegZAAAAAAAwAAQAAAz2MbNbzsYjxMDMzCoZAAmZAYA"
}
```
:::

:::talents Wildstalker Delves
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmxYGzMjZbmZYYhZx2MAAAAAAAAAAYbQzmhpZMzYMLmZmZWmhxAAAAAAAYMAAEAAwsMzWzyML2gZeAMjFQzAAMzAwA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Wildstalker

Raid

Mythic+

Delves

Keeper of the Grove

Alternative Raid

Alternative Mythic+

### 天赋方案 0-0

1.1.

#### Raid Healing Build

This is our recommended build for raiding in Midnight in Season 2.

### 天赋方案 0-1

1.2.

#### Dungeon Healing Build

This is our recommended talent build for Mythic+. We're recommending Wildstalker because
it heals for the most.

### 天赋方案 0-2

1.3.

#### Delve Build

This is our recommended build for Delves, which focuses on maximizing your
damage output while still being Restoration spec. If you want to learn more about
Delves, check out our dedicated Delve guide: [Delves](<https://www.icy-veins.com/wow/delves-guide>)

### 天赋方案 1-0

1.4.

#### Raid Healing Build

This is an alternative that plays Keeper of the Grove instead of Wildstalker. This is not recommended.

### 天赋方案 1-1

1.5.

#### Alternative - Keeper of the Grove M+ Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove is an alternative Mythic+ tree that does less, but it's still playable. It also does more damage overall than Wildstalker.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAYMmZZmZMzMmthHYYmNjtxMAAAAAAAAAAYbQzGjpZGDPgZZmZmZYYGAAAAAAAAAAAAAmtZWa2mZzGjZmBzAjmBAYmBgB"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQTzEIMVWy2AXXZBWkrLVNWTLMU88CD-FGHWWHCXq08ARmGk4QhM9arrqEno4HG-AAAA-BEIcEpJ4gRiSmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZzw0MjZwsYmZmZZGegZAAAAAAAwAAAAAgZbmtmtZWsxYmBmZB0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQRfzEMVWy2AXXBU8grLVVTzTo44ZLM-FGHWWHCXq08ARmC4QN+0DZ61lWHVJuP-AAAA-BEIeEpJ4gRiCmF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNzMgFzsZbGAAAAAAAAAAsNoZzw0MmZMmFzMzMLzwYAAAAAAAwAAAAAgZZmtmlZWsBz8AYGLgmBAYmBgB"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNQRTTVWy2+AXnBSU8g5hrLVVTzTY4YLM-FGHWWHCXq08ARmC4QN+EFZq11VnPpKQ-AAAA-BEIeApJwgRiCmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMjxMLzMjZmxsN8ADzsZsxMAAAAAAAAAAYbQzGjpZGDPgZZmZmZYYGAAAAAAAAYbbshpZmlBAAAwCjZmhZGY0MAYmBAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-BKKNOQTzEIMVWy2AXXZBWkrLVNWTLMU88CD-FGHWWHCXq08ARmGk4QhM9qrqE3HA6GG-AAAA-IOEaGygkAoSQjF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsNMMmtZsZbGAAAAAAAAAAsYoZbmxkZAmFzMzMLGGAAAAAMAAzA2WGLYamZZAAAAswYmZwMbgmBAzMAgB"
}
```
:::

:::details 来源计算器编码
```
#pB-KKNOzEVWy2AXXBU8grLVVTzTY4ZbSBEWDTM-FGHWWHCXq08ARmC4QN+07DZ61lWXVJO-AAAA-EGQYcgkQpBYAmF-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization options after a quest series.
These are minor bonuses overall but still worth getting.

- Node 1: [[spell:1279599]]
- Node 2: [[spell:1279603]]
- Node 3: [[spell:1287555]]
- Node 4: [[spell:1279610]]
- Node 5: [[spell:1279614]]

Most of the Folio power comes from the stat node (4) and we will take [[spell:1279599]] in order
  to proc it more often.

The 5th node is also very flexible. Each increases the power of your Core Rune (Node 1) by the same amount, so you are 
  mostly just picking the healing <em>format</em> you'd prefer.

3.

### Apex Talent: ![Everbloom Icon](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_focusedgrowth.jpg>) Everbloom

Apex talents are new to Midnight. They are a new node in your Restoration spec talent
tree  that you can put up to four points into. Ours is called [[spell:392167]] and it's
designed around enhancing [[spell:33763]].

  Putting points in unlocks the following benefits:

- First Point: Your [[spell:33763]] stacks up to 3 times, automatically stacking every 5 seconds.
        It heals for 3 times as much, but you still get the same mastery value as without the talent.
- Second and Third Points: Your [[spell:33763]] cleaves 20/40% of its "bloom" healing to up to 6 nearby allies.
        This includes talents that generate more blooms like [[spell:274902]].
- Fourth Point: When you cast [[spell:18562]], your [[spell:33763]] blooms 3 times in quick succession.

In dungeon content our Apex node is incredibly powerful, since it makes your [[spell:33763]]
    target nearly immortal. The cleave healing to the rest of the party is also very 
    valuable and you get a ton of value every time you press [[spell:18562]]. 
    You'll not only take it in all scenarios but you will take accompanying nodes that
    further buff [[spell:33763]] like [[spell:274902]].

In raid, it is not quite as valuable to make one person immortal since they make up a smaller
  percentage of your group. Mid-Season buffs prior to Patch 12.1 were enough to make it a good talent though and you
  should still expect to take it in all content.

4.

### Hero Talents

Restoration Druid gets to pick between the Hero Talents ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove, both 
offering similar gameplay, but with different strengths.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker focuses on its unique [[spell:439530]] heal-over-time effect
that greatly buffs the amount of healing the target takes and adds a Mastery stack. It has
special synergy with Cat-based gameplay, however its DPS and Healing capabilities are completely
separate and [[spell:768]] is not required in order to play the tree. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker is a mostly
passive tree and you don't have to uniquely play into it to benefit from its strengths. **This will
be our default tree in Mythic+ and other small group content. It is also competitive in raid.**

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

The ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove tree focuses instead on burst healing and our [[spell:102693]] mechanic.
Every time we cast [[spell:18562]] or [[spell:48438]], we will do more healing for 8+ seconds. [[spell:391528]]
will cast plenty of both, which means when we need the healing most we can have 4-5 [[spell:102693]] active, 
greatly increasing our healing. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove is also a fairly passive tree. It's just ok in both content types
but is hampered by the high cost of [[spell:48438]].

5.

### PvP Talents (War Mode)

You can go into "War Mode." Enabling War Mode
provides the following benefits:

- PvP talents enabled in the outdoor world.
- 10-30% increase in World Quest rewards at maximum level.
- 10-30% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

Enable War Mode if you enjoy PVP, or if you want a slightly quicker levelling experience.
   However, you will make yourself available for open-world PvP,
and might occasionally be involved in skirmishes.

In this section, we will rank the PvP talents best for leveling and doing
solo / small group PvE content. Below is a ranking of General PvP Talents
and Restoration Druid-specific PvE talents.

1. [[spell:305497]] is a good choice that offers a direct damage
   increase. It is usable in any form and can provide significant damage to big
   pulls.

[[spell:233673]], [[spell:247543]], [[spell:233755]],
[[spell:203553]], [[spell:428937]] have limited effect on PvE content
in terms of increasing your damage in the open-world or healing in a small
group setting.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **26 Aug. 2025:** Updated talent recommendations.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** Changed talent recommendations due to tier set changes.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **29 Aug. 2024:** Added Wildstalker dungeon build and added clarifications on some talents.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **20 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **21 Nov. 2023:** Updated talent recommendations.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated pathing and talent choice recommendations for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **24 Mar. 2023:** Updated raid talent recommendations.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **29 Dec. 2022:** Adjusted talent advice for both Mythic+ and Raids.
- **11 Dec. 2022:** Added more Mythic+ build options.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **30 Oct. 2022:** Updated Regenesis advice.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Restoration Druid, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Restoration Druid Gameplay and Rotation Guide

Welcome to our Rotation page for Restoration Druid. On this
page, you will find everything you need to know about playing the spec in
Raiding and Mythic+ scenarios.

Your exact healing playstyle as a Restoration Druid will depend on how many
targets you need to heal. The chief difference will be betwen raid and dungeon content.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

Keeper of the Grove

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker

Wildstalker

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

### Raid

1.1.

#### Raiding Rotation for Restoration Druid

There are two key concepts in Restoration Druid healing that you'll need to get comfortable with to master the spec: efficient maintenance casts, and the [[spell:207383]] cycle. **Note that our rotation does not meaningfully change between Keeper of the Grove and Wildstalker. Everything you are about to read applies to both.**

1.2.

#### Maintenance Casts

Try and follow this list at all times through the fight. Most of these are very efficient casts and you can often improve your healing a lot by just doing everything in this section more reliably.

- Keep [[spell:33763]] on yourself. We self-cast because we will be stacking healing modifiers on ourselves, which means our Apex healing ([[spell:1244331]]) will also be much larger. You will also want to keep 1-2 [[spell:774]] on yourself in order to proc [[spell:274902]].
- Keep [[spell:145205]] under a group of players. Due to the [[spell:1217941]] talent, our [[spell:145205]] will follow the target of our [[spell:33763]] (that's us!)
- Cast [[spell:18562]] on cooldown on yourself, and follow it with [[spell:774]]. This will put [[spell:774]] on 3 targets due to the [[spell:392302]] talent. Self-casting will also put a powerful [[spell:439530]] HoT which increases our healing received by 20%, and thus our Apex healing by the same amount.
- Cast [[spell:48438]] during periods of heavy damage. It is very expensive, and will be the primary spell you spend your mana on. If you are running out of mana a lot, then cast less [[spell:48438]].

1.3.

#### Abundance

The [[spell:207383]] talent greatly increases the crit chance, and lowers the mana cost of [[spell:8936]] when you have 5x [[spell:774]] buffs active on your party or raid. The talent encourages you to have 5 active at all times so that you can take advantage of the powerful, and cheap [[spell:8936]] casts afterwards. [[spell:392302]] can also take care of a lot of your [[spell:774]] count.

We also have two (and a half) different ways to extend our heal-over-time effects to open up a longer window where we can chain-cast [[spell:8936]]:

- [[spell:740]] extends all heal-over-time effects by 10 seconds (via the [[spell:197721]] talent).
- [[spell:391528]] has a 45% chance to extend all heal-over-time effects by 2 seconds (via the [[spell:197721]] talent).

**Your rotation this season will be enormously [[spell:8936]] focused.** Take special care to ensure you aren't casting more [[spell:774]]s than you need. If a fight is very movement heavy then expect to cast more [[spell:774]] manually, which will let you spend more of your [[spell:158478]] procs on [[spell:8936]] instead.

1.4.

#### Additional Spells

In addition to your core rotation above, you will have access to a few extra buttons with various functions. We will cover what each of those do here. We also have a number of very powerful cooldowns that you can read more about further down the page.

- [[spell:29166]]: Restores 25% of your maximum mana. Cast your first at ~75% mana and try and maximize casts through the fight.
- [[spell:102342]]: Reduces the damage a target takes by 20%. Build a habit of using this often because the cooldown is quite low and it is off the global cooldown.
- [[spell:1126]]: This is our "Raid Buff" and it's very powerful. Cast this before every boss.
- [[spell:106898]]: An AoE movement speed increase that you might use during specific boss mechanics.
- [[spell:22812]]: Your personal defensive ability. Very low cooldown so use this whenever you're in danger.
- [[spell:20484]]: An in-combat resurrection ability. Combat resurrections are in a shared pool and will recharge
        over a boss fights duration.

:::details FAQI am having mana issues. How can I fix that?
Make sure you are not casting

[[spell:8936]]

without

[[spell:207383]]

active. You can adjust how many

[[spell:5176]]

you cast as opposed to healing spells if you require more mana but most mana issues are caused by too few

[[spell:8936]]

casts. Remember to fit as many

[[spell:29166]]

casts into a fight as possible. Cast less

[[spell:48438]]

while incoming damage is low.

:::

### Dungeon Healing

1.5.

#### Dungeon Healing for Restoration Druid

Dungeons consist of two primary types of damage: unavoidable and avoidable. You will deal with the former every single key and once you have mastered a boss you can easily repeat it. The latter is from people getting hit by mechanics, failing interrupts and so on. It will vary heavily from dungeon to dungeon. You will be expected to handle all unavoidable damage through a dungeon and simply to do your best against the avoidable.

1.6.

#### Maintenance Casts

Similar to in raid, you'll have a few maintenance casts that you should take care of at all times. As a beginner you should do these even if there isn't a lot of damage at the time, and then you can start cutting casts once you are very comfortable with the dungeon.

- Keep [[spell:145205]] under as many players as you are able. If you have the [[spell:1217941]] talent, then it will automatically follow the target of your [[spell:33763]].
- Keep [[spell:33763]] on a tank or a player taking heavy damage. If the tank is not near the party, and you are using [[spell:1217941]] then put it on a more central player so that you don't lose [[spell:145205]] value. Remember that this player will get a ton of healing via [[spell:392167]].
- Cast [[spell:18562]] on cooldown and follow it with [[spell:774]] if the party is quite healthy, or [[spell:8936]] if they are struggling to stay alive. The choice is between better setup for later, or more healing **now**. Either way you will proc your [[spell:1244470]] talent and heal everyone for a lot.
- Cast [[spell:48438]] on cooldown to cover light to moderate party damage.
- When nobody is hurt and you do not expect that to change soon you can cast DPS spells to speed up the dungeon. We will cover that in the "Damage Rotation" tab because we have a few choices over how we do that.

1.7.

#### Handling Dangerous AoE Damage

Your maintenance rotation above will take care of about 75% of your dungeon. The other 25% you will face a mix of dangerous AoE damage to the entire party, and sharp damage on a single target.

- Make sure [[spell:33763]] and [[spell:145205]] are up before the damage hits.
- Prepare for the damage ahead of time by casting [[spell:774]] on DPS in the party. You want five active during all dangerous damage in order to gain the [[spell:207383]] buff.
- Cast [[spell:18562]] -> [[spell:8936]] as damage hits. Your [[spell:8936]] will hit three targets.
- Follow up with more [[spell:8936]] casts until the danger has passed.

Most of these AoE checks are built into the dungeon and will happen at set times that you can predict and prepare for.

1.8.

#### Handling Dangerous Single Target Damage

Single-target damage comes in a few forms. It can be a dangerous damage-over-time effect that he have to heal over 5-10 seconds, or it can be a missed interrupt that causes someone to lose 80% of their health at once. Our responses to both will differ slightly.

- If the damage is sharp and instant, then [[spell:8936]] the target. This is a great time to pair the cast with [[spell:132158]] if it is available. Continue to cast [[spell:8936]] until they are safe.
- For semi-dangerous damage-over-time effects you should cast 1-2 [[spell:774]] on the target before you start casting [[spell:8936]]. If the damage is very dangerous then move over [[spell:33763]] too. Targets with [[spell:33763]] are much safer and are nigh-immortal. This is particularly good for mechanics that announce their target in advance - since that gives you more setup time and moving [[spell:33763]] becomes easier.

There is more specific information on spell usage in Mythic+ on our Restoration Druid Mythic+ page:

### Damage

1.9.

#### How to DPS as a Restoration Druid

You have two options for adding damage as a Restoration Druid: caster-form spells like [[spell:5176]], or swapping to [[spell:768]] and using melee abilities. The latter is more advanced and usually more damage, though this isn't the case right now. Regardless of how you DPS, you should still go into Cat Form when casting [[spell:319454]].

**You are a healer first, your damage is very low priority** and it is fine to not do any of this, though do cast [[spell:5176]] at least because it is good to build a habit of spending spare global cooldowns on something productive.

1.10.

#### How to DPS in Caster Form

Most players find DPSing in Caster Form easier than Cat, and it is tuned very well right now.

- **Single Target:** Cast [[spell:78674]] on cooldown, then cast [[spell:5176]]. You can cast [[spell:8921]] while moving if [[spell:78674]] is on cooldown.
- **AoE:** Cast [[spell:194153]]. If you are moving you can cast [[spell:93402]].

1.11.

#### How to Catweave

When setting up your bars for Catweaving you should find a keybind on your caster-form bar for [[spell:1822]] and if possible one for [[spell:5221]]. We will be taking the [[spell:449193]] talent which will automatically shift us to [[spell:768]] when we cast these abilities - saving us a global cooldown and greatly improving the Catweaving experience.

- (Optional) [[spell:5215]] before a pull. It increases the damage of your next ability.
- Cast [[spell:1822]] on the biggest enemy in the pack to enter [[spell:768]] and apply a big DoT.
- Cast [[spell:1079]] if you have five combo points, or tab-target to apply [[spell:1822]] otherwise.
- If all enemies in the pack have [[spell:1822]] then use [[spell:5221]] (1-2 targets) or [[spell:213764]] (3+ targets).
          Note that most of your damage will come from the bleeds above.
- Cast [[spell:22568]] if you are fighting a single target and it already has a fresh [[spell:1079]] on it.
- You can also use [[spell:391528]] in [[spell:768]] to make it cast mostly damage spells. This is quite a good idea if not much else is happening.

Catweaving can feel scary at first, but you will get used to it quickly.

2.

### Midnight Season 2 Tier Set

Our Season Two tier set offers the following bonuses:

- **Two-piece Bonus:** [[spell:774]] has a 15% chance to grant [[spell:1302255]], causing all heal-over-time effects
    to heal for 15% more for 8 seconds. Stacks.
- **Four-piece Bonus:** [[spell:1302255]] lasts 8 seconds longer. [[spell:132158]], [[spell:740]], [[spell:391528]] and [[spell:33891]]
    have a 100% chance to grant it.

Our tier set doesn't have a large impact on our playstyle though it does reward us for pressing our big cooldowns often.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Restoration Druid
kit, we have compiled a more detailed explanation on individual parts of our rotation including
important rotational mechanics that you need to pay attention to, how to use our major cooldowns,
and more!

### Apex: Everbloom

3.1.

#### Apex: Everbloom

Apex talents are new to Midnight. They are a special type of spec-talent that you can put
  up to four points into. Ours is called [[spell:392167]] and it focuses on enhancing [[spell:33763]].

  Putting points into the node unlocks the following benefits:

- First Point: Your [[spell:33763]] stacks up to 3 times, automatically stacking every 5 seconds.
- Second and Third Points: Your [[spell:33763]] cleaves 20/40% of its "bloom" healing to up to 6 nearby allies.
- Fourth Point: When you press [[spell:18562]], your [[spell:33763]] blooms 3 times in quick succession.

Our Apex node is incredibly powerful, offering near-immortality to one target and very decent cleave 
    healing to the rest of the party. It is well worth the investment and you will even take
    synergistic talents like [[spell:274902]] to enhance it further.

### Mastery

3.2.

#### Mastery

Your Mastery, [[spell:77495]], increases your healing done to a
target for each HoT that you have on that target at the time. Each HoT's healing
is updated dynamically as soon as you apply another and it applies from your first
heal-over-time effect. With 20% Mastery, a single [[spell:774]] will do 20% extra healing.
The value of Mastery decreases the more HoTs you have. The second HoT will only provide 70%,
third 60%, fourth 50% and so on. Regardless, the more HoTs you have on average, the better
Mastery is.

There are currently 7 HoTs that count towards our Mastery:

- [[spell:774]]
- [[spell:155675]]
- [[spell:48438]]
- [[spell:8936]]'s HoT portion
- [[spell:33763]]
- [[spell:22842]]
- [[spell:439530]] (![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker HoT)

It is important to note that this list is exhaustive. No trinket effect
interacts, contributes, or otherwise benefits from Mastery.

### Pandemic

3.3.

#### Pandemic

Pandemic is what players call an in-game mechanic where casting a heal-over-time effect
on a player that already has that one will both refresh its duration and add some of the remaining
duration to the new heal-over-time effect. The general rule is you can add up to 30% of the original 
HoTs duration.

4.

### Important Cooldowns for Restoration Druid

### Tranquility

4.1.

#### Tranquility

[[spell:740]] should be used during heavy raid damage or when you are
        assigned to use it by your raid leader. [[spell:740]] extends the duration
        of all your heal-over-time effects on the group by a massive 10 seconds which
        means it is a best used during the most dangerous moments of each fight. We 
        mentioned this briefly above, but your rotation around [[spell:740]] will
        look something like the following:

![Tranquility Ramp](<https://static.icy-veins.com/images/wow/classes/druid/restoration/RestoTranqRamp.webp>)

You will want to get several [[spell:774]] buffs out, a [[spell:48438]] and a few [[spell:8936]] HoTs, in order
        to maximise the value of the [[spell:740]] extension. This enables a very long [[spell:207383]] window, and the long [[spell:774]] HoTs
       will give us even more value from subsequent [[spell:8936]] casts via the [[spell:1263879]] talent.

This [[spell:740]] "Ramp" as we will call it is one of the most powerful healing cooldowns
        in the game. It's best if you plan out its usage before every fight, since as you can see it is much
        more powerful if you can cast a lot of spells before you press it.

In Dungeon content like Mythic+, [[spell:740]] is similarly powerful, and you can keep the same
        concept as the ramp above but it'll be a faster process. You'll just try and get out as many [[spell:774]]
        as you can but it'll number closer to 5-6 rather than the 12+ you can aim for in raid. The [[spell:740]] heal itself 
      is also much more potent in dungeon content.

### Convoke the Spirits

4.2.

#### Convoke the Spirits

[[spell:391528]] is a powerful healing cooldown on a short cooldown. It casts
          random Druid spells over 3-4 seconds. It's mostly random what spells it casts but there is a little 
        bit of logic in how many healing and damage spells it will cast. Roughly 50% of casts will include a
      mini-[[spell:740]] if you have the [[spell:393371]] talent (a default in the Icy Veins builds).

You will also usually get 0-2 [[spell:48438]] casts, 2-4 [[spell:18562]]s and a handful of [[spell:774]]s.
        It will usually cast 2-4 [[spell:5176]] and these can proc associated talents like [[spell:289237]].

[[spell:391528]] should be used often during the most dangerous moments of each fight.

### Incarnation: Tree of Life

4.3.

#### Incarnation: Tree of Life

[[spell:33891]] is a choice-node alternative to [[spell:391528]]. It focuses on 
          healing over a longer period of time. It can be useful for longer phases of healing in raid like a 30 second
          burn phase near the end of a fight. It has a longer cooldown than [[spell:391528]] but a very high
          overall uptime (60-70%).

![Incarnation: Tree of Life](<https://static.icy-veins.com/images/wow/classes/druid/restoration/DruidTreeForm.webp>)

You get the following bonuses when [[spell:33891]] is <em>active</em>:

- All of your healing is 10% stronger.
- [[spell:48438]] heals an additional 2 targets.
- [[spell:8936]] cast time reduced to 0 (it still costs you one global cooldown though).
- [[spell:5176]] damage increased by 20%.

While [[spell:33891]] is active your [[spell:774]] casts are extremely cheap,
            and very powerful. [[spell:48438]] also becomes an even higher priority spell. The other advantage to it is that it
            lets you cast [[spell:8936]] while on the move. It's a potent choice for ultra-high movement fights.

### Innervate

4.4.

#### Innervate

[[spell:29166]] restores 25% of your mana on a 3-minute cooldown. It can be cast on yourself
        or another healing spec, however, I recommend self-casting it in most situations.
        You should use [[spell:29166]] as often as possible during a fight, starting at 
        around 75% mana.

### Nature's Swiftness

4.5.

#### Nature's Swiftness

[[spell:132158]] makes your next [[spell:8936]] instant cast and
        increases the amount of healing it does. You will mostly
        use it when people drop low to save them.

### Ironbark

4.6.

#### Ironbark

[[spell:102342]] reduces the damage a target takes by 20% for 12 seconds. You should
        use it on anyone about to take heavy damage. It is available very often so you are usually
        better off using it often rather than saving it for a special occasion.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **31 Aug. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **24 Mar. 2023:** Changed rotation recommendations for raiding.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **29 Dec. 2022:** Minor fixes.
- **11 Dec. 2022:** Small updates to Mythic+ rotation and tier set advice.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Restoration Druid in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Restoration Druid

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item. Harder content drops gear that can be upgraded to higher item levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

:::details ![](<https://static.icy-veins.com/images/wow/tools/recommended.png>) **Be Careful With Early Crafts!**
Make sure to check back to see if this warning has been removed.

:::

### Overall

This list contains your theoretical best-in-slot gear from all content in the game including raids, dungeons, and more. Best-in-slot lists are useful for finding pieces to aim for, but use [QE Live](<https://questionablyepic.com/live>) in order to determine which of your current items to actually equip.

In addition to the below list, you will equip two crafted items with special "Embellishment" effects on them. Which Embellishments you wear and which crafted pieces you'll put them on depends on which state of gearing you're currently in, so we will cover this in-depth in the Crafted section below. **The crafts on the list below aren't necessarily the ones you should create first.**

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that we will be hunting for some very specific pieces to catalyze - chiefly Haste / Mastery items.

- **Helm:** [[item:271875]] (Key Item)
- **Shoulders:**  No good choices. Do not Catalyze. This is your offpiece and you will craft here.
- **Chest:** [[item:268235]]
- **Gloves:** Wear the regular tier piece. [[item:159337]] is ok if you can't get the regular piece.
- **Legs:** [[item:268225]] (Key Item)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:244572@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAAD2cbNRDD]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains your theoretical best-in-slot gear from dungeon content only. Best-in-slot lists are useful for finding pieces to aim for, but use [QE Live](<https://questionablyepic.com/live>) in order to determine which of your items to actually equip.

In addition to the below list, you will equip two crafted items with special "Embellishment" effects on them. Which Embellishments you wear and which crafted pieces you'll put them on depends on which state of gearing you're currently in, so we will cover this in-depth in the Crafted section below. **The crafts on the list below aren't necessarily the ones you should create first.**

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that we will be hunting for some very specific pieces to catalyze - chiefly Haste / Mastery items. Unfortunately the best items drop in raid this season, though even heroic raid is enough to snag Mythic-quality cantrip items. The list below is for if you do not intend on raiding at all.

- **Helm:** [[item:251140]].
- **Shoulders:**  No good choices. Do not Catalyze. This is your offpiece and you will craft here.
- **Chest:** [[item:251159]].
- **Gloves:** [[item:159337]].
- **Legs:** [[item:159313]].

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): Your best-in-slot Ring drops here ([[item:252258]]).
- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): A well-itemized 2h Weapon drops here which is essential early in the season ([[item:251156]]).
- [The Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Strong early trinket ([[item:250214]]), decent Legs and Cape.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:159317@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:159304@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:193757@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Bracers</th><td>[[item:251183@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:159636@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains your theoretical best-in-slot gear from raid content only. Best-in-slot lists are useful for finding pieces to aim for, but use [QE Live](<https://questionablyepic.com/live>) in order to determine which of your items to actually equip.

In addition to the below list, you will equip two crafted items with special "Embellishment" effects on them. Which Embellishments you wear and which crafted pieces you'll put them on depends on which state of gearing you're currently in, so we will cover this in-depth in the Crafted section below. **The crafts on the list below aren't necessarily the ones you should create first.**

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, you are able to convert any item to a tier piece and it'll keep its original stats and effects! This means that we will be hunting for some very specific pieces to catalyze - chiefly Haste / Mastery items.

- **Helm:** [[item:271875]] (Key Item)
- **Shoulders:**  No good choices. Do not Catalyze. This is your offpiece and you will craft here.
- **Chest:** [[item:268235]]
- **Gloves:** Wear the regular tier piece. [[item:159337]] is ok if you can't get the regular piece.
- **Legs:** [[item:268225]] (Key Item)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271528@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:244572@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:244569@JAAGAAAD2cbNRDD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> + <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:240949@JAAGAAAD2cbNRDD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">Jewelcrafting</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAAD2cbNRDD]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/restoration-druid-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Restoration Druid

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Restoration Druid BiS Trinkets**
**Best-in-Slot -**

[[item:270162]]

and

[[item:270167]]

.

**Honorable Mention - [[item:270164]]**

.

:::

For direct trinket comparison, we recommend using
[QELive](<https://questionablyepic.com/live/>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Restoration Druid Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]]</li>&#10;<li>[[item:280835]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:251792]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:250255]]</li>&#10;<li>[[item:270171]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250254]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:264507]]</li>&#10;<li>[[item:264701]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>F- Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193748@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

In general, there are quite a few trinkets that have a similar power level. Any
of the trinkets in a tier will be roughly equal to each other. This means that item level on trinkets is quite important.
F-tier trinkets are there because they are only better than an empty trinket slot.

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be used to acquire specific items from specific bosses
  or dungeons, by letting you gain a guaranteed piece of loot from a specific drop-location.
  The received item is random, but once an item has been acquired in this way,
  your next use of a Voidcore will grant one of the remaining items you haven't yet acquired.

**Note that obtaining an item via drop or great vault does NOT remove it from your Bonus Roll pool.**

3.1.

#### Recommended Nebulous Voidcore usage for Restoration Druid

There are a few different paths you can take for your Nebulous Voidcores and crafts. These are mostly early-season problems,
  and if you pick up the spec later in the season then you will have a lot more freedom in what you choose for both. **It is a big
  power loss to bonus roll Mythic+ early in the season.**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Raid Voidcore Priority**
- **Ideal:** Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) until you obtain [[item:271875]] and [[item:271092]].
- **Next Best:** Mythic [Nek'zali the Soulcoiler](<https://www.icy-veins.com/wow/nekzali-raid-guide>) until you obtain [[item:268235]] and [[item:270162]].
- **Then:** Fill in slots you don't have Myth-track items for yet. You can use QE Live in order to get the average bonus roll value from each boss and dungeon.

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **M+ Voidcore Priority**
- [The Blinding Vale](<https://www.wowhead.com/achievement=61641>) - [[item:250214]] (good), [[item:251190]] (good).
- [Voidscar Arena](<https://www.wowhead.com/achievement=61508>) - [[item:252258]] (BiS)

:::

3.1.1.

##### Understanding the Bonus Roll Strategy

Restoration Druid is in a tough spot in regards to bonus rolls because two of the items [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) drops are absurdly good, while the 3rd option ([[item:268265]]) is
    just ok. However, after three bonus rolls on the boss we are guaranteed all three items.

If you bonus roll both items early then you can skip the third. 1/3rd of the population will be fortunate in that way.

:::details FAQWhat if I will not kill Uta'tek Heroic in the first few weeks?
If you expect to kill the boss but might take an extra week or two then proceed with the strategy above. You can bonus roll a boss
  more than once per week so you will be able to catch up quickly. If you have no interest in raiding and / or will never clear heroic then
  proceed to the dungeon list above. Hopefully gearing will not be this complex and tricky in future seasons.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] follows a similar priority as your Crests:

1. Your Weapon is the highest priority
2. Offhand is the next most important if you are using a 1-handed weapon.
3. If you have an S-tier trinket from the list above, then upgrade it before Neck.
4. Neck

Prioritize Myth track items over Hero track ones, unless you do not expect
   to get Myth-track items. Ascendant Venomstones do NOT work on 344 item level
   gear from Mythic Coiled Altar and Ulatek.

4.

### Best Crafted Items for Restoration Druid

Crafting is an essential way of getting high-item-level gear. You can craft one item every two weeks.
   You generally want to be very particular about what you craft. You're also able to attach "embellishments" to two of your 
   crafted items. They contribute about 1% healing each.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Restoration Crafted Gear Priority**
- [[item:245769]] with [[item:245876]].
- [[item:244572]] or [[item:244569]] with [[item:240167]].
- Any item you do not have on Myth track yet.

:::

- If you get a Myth-track offhand from the first few raid bosses, then you can skip that step.
- The Leather 2-pc Embellishment set is not very good. Avoid it.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Restoration Druid

Up to two of your crafted items can be **Embellished**. Embellishments add special
  effects to your items and you will want to have two once you are up and running.

Since you can only pick two, it's important you craft the correct ones since some are quite poor. The two best
choices for this are:

- [[item:240167]] on two armor slots.

It is recommended to use QE Live to find out what might be best for your particular gearset, and if you
also play any other Druid specs, you might want to pick Embellishments that work
well for all of them.

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable item that you can choose 
instead of a Great Vault item. You will generally not have any of these 
until later in the season since it is better to take an item or a [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>).

5.

### Crest Usage

Early into your characters gearing path, you will have limited
access to crests that [ upgrade the level of your gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) (such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>)). 
Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items that have the most stats on them, and those that you won't replace soon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Restoration Druid Crest Upgrade Priority**
**Weapon Slots**

➜

**Special Effect Slots**

➜

**Helmet/Chest/Legs**

➜

**Trinkets**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**The Rest**

:::

Eventually, you will be able to upgrade all of your items, this priority order is only for when you are limited in crests.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on QE Live. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for changes in Patch 11.2.5.
- **20 Aug. 2025:** Updated trinket recommendations.
- **06 Aug. 2025:** Updated some gear recommendations.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **16 Mar. 2025:** Changed raid trinket recommendations.
- **25 Feb. 2025:** Updated trinket rankings.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **14 May 2024:** Updated Mythic+, embellishment and trinket recommendations.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **20 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Updated trinket list with Spark of Hope and updated for Patch 10.2.5.
- **26 Nov. 2023:** Updated BiS list and trinket recommendations for raids.
- **11 Nov. 2023:** Updated gear recommendations for Amirdrassil.
- **07 Nov. 2023:** Updated embellishment and trinket recommendations.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **12 Jul. 2023:** Updated trinket recommendations.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **07 May 2023:** Updated trinket recommendations.
- **01 May 2023:** Updated for Patch 10.1.0.
- **24 Mar. 2023:** Updated Onyx Annulet recommendations.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated with crafting recommendations and tier set analysis.
- **11 Dec. 2022:** Updated with Vault of the Incarnates and Mythic+ loot.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Restoration Druid. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Restoration Druid Stat Priority

The stat priority for a Restoration Druid depends on whether you plan on
healing in a raid or dungeon environment though the same gear set will be quite effective in both.

Stat values change depending on your gear, the content you are doing, and
your spell choices. There are no universal weights. They will change every time
you swap a piece of gear.

Having said all that, there will be very few situations where item-level
upgrades will not be actual upgrades. Sockets are usually worth roughly 10
item levels, Leech on the first 2-3 pieces is worth about 6 item levels, and
Avoidance is worth around 5.

1.1.

#### Raid Healing

Your stat priority will look something like this.

Intellect

Haste

Mastery

Versatility

Critical Strike

:::details FAQIs There a Haste Cap?
It's generally discouraged to go beyond the second diminishing breakpoint because you will
 start losing too many stats. You can use the

[Questionably Epic Live](<https://questionablyepic.com/>)

app to fine-tune
 your stats around breakpoints. There are no Haste Breakpoints in the modern game.

:::

:::details FAQWhy is Crit Such a Bad Stat for Restoration Druid?
Crit is discouraged because

[[spell:8936]]

has a very high crit chance already
  due to

[[spell:207383]]

, which means every other stat gives you more value overall.

:::

1.2.

#### Dungeon Healing

You can wear much the same gear in raid and dungeon content. Mastery value goes up
in dungeons since you can have more heal-over-time effects on each player, but Haste is still
very good too. In very high keys, players might equip a certain amount of versatility in order
to improve surivivability and the ability to survive severe burst damage - but the amount required
varies from dungeon to dungeon and is only relevant for the highest keys being done in the world.

Intellect

Mastery

Haste

Versatility

Critical Strike

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. You should look for this stat in all
of your upgrades. It provides you with Spell Power, which increases the power
of your heals.

**Haste** reduces the cast time of your spells, increases the
healing of your HoTs by making them tick faster, and reduces global cooldown.

**Mastery** ([[spell:77495]]) increases the healing you do to
targets affected by your HoTs by an amount (determined by your Mastery level)
for each active HoT. You get full value for the first HoT, and then it scales
down for subsquent HoTs.

**Critical Strike** increases your chance to critically hit with
all spells and abilities. Crits deal double healing by default, but several 
effects can increase your crit healing.

**Versatility** increases all your damage and healing done, and decreases
all damage taken.

2.1.

#### Diminishing Returns of Secondary Stats

All secondary stats (Critical Strike, Haste, Mastery, Versatility) have
**Diminishing Returns**. After reaching specific values from the rating, you
will receive penalties for further rating acquisitions. The penalties for
different stats are different and only affect gains expressed in raw ratings.

As such, effects like [[spell:32182]] / [[spell:2825]],
[[spell:10060]], [[spell:378988]], and similar effects do not
contribute towards Diminishing Returns. [[spell:378988]] is an important example since
we take it in all builds and it's a multiplicative increase to your haste. Some other classes will start having diminishing
returns at 30%, but Restoration Druid will need to pay attention to stat
rating instead. The breakpoints for different stats are as follows:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">-10%</th>&#10;<th style="text-align: left">-20%</th>&#10;<th style="text-align: left">-30%</th>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Crit &amp; Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for TWW Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated Leech values for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Restoration Druid, based on your [stat priority](<https://www.icy-veins.com/wow/restoration-druid-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

You are able to socket a single **Eversong Diamond** into your gear. It provides
Intellect and sometimes a secondary effect which is less important. The four possible
options are:

- [[item:240967]] (Critical effect)
- [[item:240970]] (Armor)
- [[item:240968]] (Maximum Mana)
- [[item:240983]] (No effect, more intellect)

The Critical effect gem only provides half the benefit for healing; maximum Mana is
not useful because we have no Mana scaling at all. Therefore, we recommend using [[item:240983]].

For the other gem slots, you're able to just socket our preferred gem in every slot
because you are not gaining any benefits from socketing unique gem types. Therefore,
socket each slot with [[item:240892]] (Haste / Mastery).

2.

### Best Enchants and Weapon Augments

Make sure you apply [[item:243733]] to your weapon for all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;[[item:243951]]&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>[[item:244021]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240155]]</td>&#10;</tr>&#10;<tr>&#10;<td>Feet</td>&#10;<td>[[item:243983]]</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>[[item:243959]]</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:244029]]</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

- **Raid:** [[item:241325]]
- **Mythic+:** [[item:241322]]

3.2.

#### Potions

You will also use [[item:241288]] as your default potion.
Mana potions are very weak currently and burst healing cooldowns are weaker than in previous expansions, so it is 
recommended to use a stat-potion to better cover the most difficult parts of the fight
by using them with your cooldowns.

For Healing Potions, use [[item:271883]] - **This is new in 12.1!**.
 Also, do not forget to keybind and use [[item:5512]]s too. You can use one per pull.

3.3.

#### Food Buff

The different intellect Feast options are all very good ([[item:255845]], [[item:242272]],
    [[item:255846]]). [[item:255847]] is a fine personal food
    choice if a Feast is not available. The secondary stat food options are not viable.

3.4.

#### Augment Rune

[[item:259085]] is the only other consumable worth mentioning.
Use it whenever possible for extra stats though they can be expensive.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **29 Aug. 2024:** Minor updates.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **20 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.0.
- **24 Mar. 2023:** Updated Onyx Annulet recommendations.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **29 Dec. 2022:** Adjusted some enchant and consumable advice.
- **12 Dec. 2022:** Fixed food and gem advice.
- **11 Dec. 2022:** Added advice for boots enchant.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Restoration Druid in World of Warcraft Patch 12.1.5.

1.

### Restoration Druid in Mythic+ in Midnight Season 2

Restoration Druid has enough throughput to get through almost any
healing situation, good crowd control, and one of the best tank cooldowns in
the game. Restoration Druid specialises in steady AoE healing, burst single
target healing, and high damage output (for a healing spec).

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below.

2.

### Best Mythic+ Talent Builds

The two hero trees are much closer in power than they were last expansion and, while we will recommend Wildstalker below, you are free
to play either. Note that ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker does **not** require you to DPS in cat form (or "catweave"). It is played for its
healing capability. Similarly, if you'd like to DPS in Caster Form, you are not required to be ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove.

The type of builds being recommended in the spec tree revolve around
[[spell:33763]] and [[spell:8936]]. Those two and their flow-on effects will make
up quite a lot of your healing though expect to press all of your buttons.

### Optimal Mythic+ Build   ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker

2.1.

#### Recommended - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) Wildstalker is recommended mainly for healing purposes. If you
do not care about damage, you will still want to pick this hero talent tree.

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8AMzsNjFbzAAAAAAAAAAgFDNbzw0MAmFzMzMLGGAAAAAMAAzAAAAAgZbmtmtZWsxMzMDmZD0MAAzMAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-KKNkzCGMVWy2ANXXZBQU8grLVVTzTY4JabM-FGHWWHCVq08ARmC4QN+07DZ6l2WXVJO-AAAA-BEIeEpJ4gRiCmF-
```

:::

### Alternative Mythic+ Build   ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove

2.2.

#### Alternative - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove Talents

We wouldn't recommend ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/keeper-of-the-grove.webp>) Keeper of the Grove to most players, since it heals for
quite a lot less and the playstyle differences are minimal. But, if you prefer the theme
behind the hero tree, you'll want to make sure to play the below build.

:::talents 天赋构筑
```json
{
  "code": "CkGAAAAAAAAAAAAAAAAAAAAAAMMmZZMjZmxsN8AMzsNjFbzAAAAAAAAAAgFDNbzw0MAmFzMzMLGGAAAAAMAAzA22GLYamZZAAAAswMzMDmZD0MAYmBAMA"
}
```
:::

:::details 来源计算器编码
```
#pB-KKNkzCGMVWy2ANXXZBQU8grLVVTzTY4JabM-FGHWWHCVq08ARmC4QN+07DZ6l2WXVJO-AAAA-EGQYcgkQpBYQmF-
```

:::

3.

### In-Depth Rotation Tips for Mythic+

While there is no specific rotation you should follow in Mythic+ content, it
is important to know which spells are most efficient to cast or do the most
healing so that you can make better-informed decisions.

1. Keep [[spell:145205]] down. This is a powerful, efficient sourceof healing and is required for [[spell:392325]].
      If you have the [[spell:1217941]] talent then keeping [[spell:33763]] active will do this for you.
2. Keep [[spell:33763]] on a tank by default. If you have [[spell:1217941]]
       then consider keeping it on yourself or a ranged DPS player if the tank is standing
       too far away.
3. Use [[spell:8936]] with [[spell:404521]] talent to put three Regrowth
   HoTs up.
4. Use [[spell:18562]] to activate [[spell:158478]] and [[spell:102693]].
       Follow the cast with [[spell:774]] if the party is lighty damaged or if damage is coming up,
       and [[spell:8936]] if the group needs immediate healing.
5. Use [[spell:48438]] often since it procs several talents and takes care of minor to moderate AoE damage.
6. Keep [[spell:774]] on an active tank and any players with
   debuffs. Avoid casting too many unnecessary Rejuvenations. A lot of small damage
   can be healed passively by your AoE healing or even self-healed by players
   themselves.
7. Use [[spell:8936]] to mop up any damage or to handle dangerous AoE or single target healing challenges.

If you look at the priority, you should notice how far down both
[[spell:774]] and [[spell:8936]] are. Your first instinct in most
situations should be to use more efficient healing spells, which are listed at
the top. Once all of them are on cooldown, you can go back to Rejuvenations and
Regrowths.

During downtime from healing, you should be actively looking to deal as much
damage as you can. The rotation might be complicated to master fully, but you
should still learn which spells to prioritize to time more keys. We cover
this in depth on our Rotation page.

4.

### Utility Kit and Abilities

Restoration Druid provides much more to the group than just healing. Due to
the nature of dungeon content, you will be expected to do damage, crowd
control, and heal all at the same time.

### Interrupts, Stuns and Stops

4.1.

#### Stunning and "Stops"

Most healing specs no longer have an interrupt or "kick" ability, but we do have a decent
array of stuns and other ways of stopping mobs. [[spell:99]] is our "AoE stop". You need to be somewhat close
to the mobs to use it, so keep that in mind and position yourself accordingly.

You can use [[spell:132469]] for a similar effect, but keep in mind that it will
displace the mobs and potentially move them out of damage zones. We recommend
using it in combination with [[spell:102793]] whenever possible.

[[spell:2637]] puts an enemy Beast or Dragonkin to sleep for up to 40
seconds. Any damage will awaken the target. Hibernate works in the same way
as [[spell:339]] for stopping patrolling packs in dungeons
without pulling them. It can also be used to interrupt casts of NPCs without
removing DoTs from the target.

[[spell:33786]] can be used to make certain enemies immune to everything
for 6 seconds. Make sure you use
it with caution because you will also make them immune to taking damage, which
might slow your group down instead of helping. We'll rarely take this.

### Other Utility

4.2.

#### Other Utility

[[spell:2908]] is probably our most notable utility outside of AoE stops. It
will remove all Enrage effects from the target.

[[spell:106898]] will let your group either move faster between the packs
or help some slower players move out of dangerous mechanics. [[spell:288826]]
will give you access to it more often.

[[spell:339]] can be used to root patrols. If you apply them
to the leading mob in the group, the entire patrol will stop moving. It is
useful in tight quarters or to skip certain packs altogether.

[[spell:102793]] conjures a ground zone for 10 seconds that will
slow all enemies affected by 50%. It will also pull them to the center after
the first time they attempt to leave the circle. It is an extremely powerful
tool for kiting. You can pair Ursol's Vortex with [[spell:132469]] to group
packs on top of each other for better AoE.

5.

### Dealing with Affixes

### Affix: Ascendant

5.1.

#### Ascendant Management

This affix will spawn 10 NPCs (small orbs) that start casting. The idea is to use AoE
crowd control to interrupt the cast and gain the buffs. [[spell:99]]
or [[spell:132469]] are perfect for this.

### Affix: Voidbound

5.2.

#### Voidbound Management

This is not necessarily a healer affix, because it is just an NPC your group
needs to kill as soon as possible. You can at the very least apply DoTs to it
and possibly use [[spell:22568]] but your DPS players should be taking care of it.

### Affix: Pulsar

5.3.

#### Pulsar Management

Each player spawns a rotating orb around them for 15 seconds. When other players
    come into contact with this orb, they get a stacking Mastery and Leech buff. If
    15 seconds expire with no player picking an orb up, enemies gain a +10% damage
    and +20% damage reduction buff per orb. Pretty straightforward.

### Affix: Devour

5.4.

#### Devour Management

This affix will spawn a rift that you will have to dispel and heal off. Dispel
    whoever either cannot dispel themselves, or those who do not have your [[spell:33763]].
    This is a very good spot to use [[spell:158478]] coupled
    with [[spell:132158]] and [[spell:8936]].

If you dispel instantly on application, you will be able to dispel once more
    towards the end. Keep this in my mind and do not heal the second target you
    are planning to dispel needlessly. It can also be removed by changing form now,
which means you can remove your own very easily.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **23 Mar. 2025:** Changed talent recommendations due to tier set changes.
- **03 Mar. 2025:** Added season 2 recommendations and new tier set analysis.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for TWW Season 1.
- **20 Aug. 2024:** Updated for The War Within.
- **20 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **20 Mar. 2024:** Updated for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **21 Nov. 2023:** Updated talent recommendations.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Updated for Patch 10.0.5.
- **29 Dec. 2022:** Changed talent build advice.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **30 Oct. 2022:** Changed talent build recommendation. .
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Restoration Druid in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Listed below are the most useful Macros to use when playing Restoration Druid.

1.1.

#### Rebirth

#### Mouseover: Rebirth

```wow-macro
#showtooltip Rebirth
/cast [@mouseover,help]Rebirth;Rebirth
```

This macro casts [[spell:20484]] on your mouseover target if they are a
friendly player. Otherwise, it casts Rebirth on your current target.

1.2.

#### Shapeshift Forms

#### Bear Form Macro

```wow-macro
#showtooltip Bear Form
/cast [noform:1] Bear Form
```

#### Cat Form Macro

```wow-macro
#showtooltip Cat Form
/cast [noform:2] Cat Form
```

#### Travel Form Macro

```wow-macro
#showtooltip Travel Form
/cast [noform:3] Travel Form
```

#### Tree Form Macro

```wow-macro
#showtooltip Incarnation: Tree of Life
/cast !Incarnation: Tree of Life
```

These macros will shift you into a corresponding form. Spamming the button
will not put you out of the forms.

1.3.

#### Canceling Forms

#### Cancel Form Macro

```wow-macro
/cancelform
```

This macro will shift you out of any current form.

2.

### Specific Macros for Restoration Druids

Listed below are some of the more spec-specific macros that you will want to set
up when playing Restoration Druid.

2.1.

#### Mouseover Macros

Unless you are using a specific addon that will perform the same function,
for all your healing and utility spells, we advise you to use Mouseover
macros such as:

#### Mouseover Macro

```wow-macro
#showtooltip
/cast [@mouseover] Rejuvenation;Rejuvenation
```

3.

### Best Addons

3.1.

#### Raid Frames

To perform well as a Restoration Druid, you will need a clear way to see the state of the raid,
    including which HoTs you have on each target. Unfortunately, in 12.0 Blizzard disabled most
    pre-existing ways of doing this and you are now required to use a combination of addons to restore some of
    your previous functionality.

The best solution right now is to pick a raid frame of your choice below and combine it with the
excellent Harreks Advanced Raid Frames addon which will let you customize placement of specific
heal-over-time effects. It also works with default frames if you prefer them.

- [Harreks Advanced Raid Frames](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>)
- [Grid 2](<https://www.curseforge.com/wow/addons/grid2>)
- [ElvUI (Does more than just frames)](<https://www.tukui.org/welcome.php>)
- [Ellesmere UI (Does more than just frames)](<https://www.curseforge.com/wow/addons/ellesmereui>)

To complement your raid frame, you should either make a mouseover
macros as shown above or install
[Clicked](<https://www.curseforge.com/wow/addons/clicked>). Another
similar option is [
Clique](<https://www.curseforge.com/wow/addons/clique>).

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.0.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within pre-patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Dragonflight Season 4.
- **20 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **21 Nov. 2023:** Added Efflorescence WeakAura.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **28 Apr. 2023:** Updated for Patch 10.1.0.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
