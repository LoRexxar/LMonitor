## 专精概览

Welcome to our Vengeance Demon Hunter guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to tank as a Vengeance Demon Hunter in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your survivability.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Vengeance Mythic+ Resources

[NEW! Top Vengeance Talent Builds](<https://raider.io/specs/vengeance-demon-hunter/talents>)

[Top Vengeance Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/demon-hunter/vengeance>)

[Vengeance Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=demon-hunter--vengeance>)

[Popular Vengeance Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=demon-hunter--vengeance>)

1.

### Vengeance Demon Hunter Overview

Demon Hunters are the kings of mobility in raids and dungeons. In general,
they can move around more and more quickly than many other specs, thanks to
[[spell:189110]], as well as various talents that aid their mobility.
Additionally, they excel at burst AoE damage, with many abilities dealing
AoE and cleave damage. They also excel at dungeon utility using tools such
as [[spell:202137]] and [[spell:179057]] to control enemy spellcasters
for extended periods.

Vengeance Demon Hunter defensively features a mix of strong, constant healing
and damage mitigation, with low-cost but low uptime of active mitigation and the
ability to mitigate magic damage extremely well.

Good Damage Profiles

Vengeance Demon Hunter brings useful damage profiles depending on the Hero Talents
chosen, with access to a strong cooldown profile as

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator

and
exceptional funnel damage through

[[spell:442806]]

as

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

.
However, to fully get the most of out of your damage potential you also need to
use most of your defensive cooldowns offensively, and often overlapping them for
portions of time, meaning your damage does come at a defensive cost.

Brings Nothing Unique

Vengeance Demon Hunter, while capable of surviving and dealing good damage in a raid
environment, suffers to some extent from most of its utility being limited to
spells and effects that rarely affect mechanics of raid bosses. In the rare cases
where they do work, it is still common for another tank spec
to bring a better solution to the problem. Despite this, Vengeance is both a solid
offensive choice and generally has plenty of tools to manage tank mechanics defensively.

Good Control and Survivability

Vengeance Demon Hunter brings a lot of tools to Mythic+ which can be very helpful,
a great deal of control with talents like

[[spell:202137]]

,

[[spell:207684]]

,
and

[[spell:179057]]

, as well as having access to two different strong damage profiles
and strong defensive tools. It is only held back in situations where you need to
dedicate all your defensive tools to surviving, which does come at an offensive
loss.

Strong in Mythic+, Lackluster in Raid

Vengeance Demon Hunter utility is a bit of an odd one, since it is heavily skewed toward
Mythic+ content. In this environment it offers a strong utility toolkit.
However, most of these utility tools are either rarely applicable or straight unusable in
most raid Encounters, where Vengeance utility is one of the worst in the game. To add
insult to injury,

[[spell:196718]]

, our only means of helping our group survive
mechanics, loses half of its power inside raids.

Strong Self-healing Profile with Good Defensive Coverage

Vengeance Demon Hunter has a really potent defensive profile, with a strong mix
of high uptime defensives in

[[spell:204021]]

and

[[spell:187827]]

,
and passive defensive options through a multitude of talents
like

[[spell:207387]]

,

[[spell:389705]]

, and

[[spell:268175]]

,
to name a few. All this leads to Vengeance being capable of sustaining
and healing through very high amounts of damage. It only really struggles when
damage intake gets extremely high, or you are forced away from melee-range and
cannot continue your rotation.

Incredible Mobility

Vengeance sports one of the best mobility toolkits in the game, especially if
talented to maximize it.

[[spell:189110]]

gives access to a 30 yard leap
with a 15-second hasted cooldown that can be further reduced through talents.

[[spell:198793]]

adds another mobility tool on a short cooldown on
top. Beyond the movement spells, Vengeance also has access to several passive
movement speed buffs through talents like

[[spell:320654]]

and

[[spell:389846]]

, as well as a

[[spell:196055]]

which is only available
to Demon Hunters, and

[[spell:131347]]

which allows you to reach places and take
paths that very few other classes can access.

2.

### Vengeance Demon Hunter in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

With the new Patch 12.1.5 there are no direct changes to Vengeance Demon Hunter
	which will affect your gameplay. There are however new content both in the form
	of a new Raid encounter and the new Labyrinth, an expansion on the [Delves](<https://www.icy-veins.com/wow/delves-guide>) system.
	Follow the links below for more information about both of them!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
two powerful Trinkets, one of which you will want in all content forms, a Ring, and a Chest.
Additionally, you will be able to upgrade items with [[item:280562]] starting October 20th.
Weapons, Necks, and Trinkets can all be upgraded unless they are from Mythic [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) or [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).

2.3.

#### Class Changes

Vengeance Demon Hunters have not recieved any direct changes or tuning in patch 12.1.5.
	However, there are new items from the new raid encounter which are strong upgrades in certain
	slots which changes up our gear recommendations which you can find on our
	[gear](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>) page. You can also find recommendations
	on how you can use the new [[item:280562]] to quickly increase your power in
	Patch 12.1.5.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_demonspikes.jpg>) Click for Previous Season 2 Changes
:::details Show September 22nd Class Tuning Hide September 22nd Class Tuning
The September 22nd update brings more buffs to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver to try and bring
	it closer in line with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator offensively. The buffs mainly target
	single-target nodes or parts that have very little impact on damage dealt. The end result
	is that in a pure-single target fight with no downtime and no damage amplification phases,
	![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver should be ahead in damage. However that mold does not fit
	most Raid fights and in reality ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator comes out ahead in most situations
	due to both much stronger AoE Damage and much better burst damage during vulnerability
	phases. Below is a list of all the changes:

- [[spell:442290]] now buffs the first spell by 15% and the second by 30%, was 10% and 20% respectively.
- [[spell:442294]] deals 25% more damage.
- [[spell:442624]] now increases damage taken by 8% per stack, was 7%.

:::

:::details Show September 1st Class Tuning Hide September 1st Class Tuning
The September 1st update brings a few passive upgrades to Vengeance Demon Hunter to increase the
	general durability of the spec a bit further. The buffs total roughly 5.5% passive damage reduction
	for all recommended builds as long as [[spell:389958]] is applied to your target, which it usually is.
	[[spell:212084]] also got a minor buff to its healing, however it will have very little impact on
	the defensive power of the spell, it is still a button you want to use fairly often for damage and
	[[spell:204062]] generation as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator. The changes are as follow:

- [[spell:320382]] now reduce all damage taken by 15%, up from 12%.
- [[spell:268175]] now reduces damage taken from enemies affected by [[spell:389958]] by 6%, up from 5%.
  	This effect is doubled by the [[spell:389985]] talent.
- [[spell:212084]] healing increased by 25%

:::

:::details Show August 25th Class Tuning Hide August 25th Class Tuning
The August 25th update had a single change which is both simple and impactful. [[spell:203747]]
	is buffed by 24%, which is just enough to put it on the same level as Critical Strike and
	Versatility defensively. This greatly simplifies gearing as we now only want a bit more Haste compared
	to other stats defensively.

:::

:::details Show Class Changes in Patch 12.1 Hide Class Changes in Patch 12.1
Season 2 brings a few changes to Vengeance Demon Hunter.	With Patch 12.1 all players will gain 25%
	more Health, and all enemies will deal 25% more damage as a way to reduce the power of Healers.
	To make sure our self-healing does not get affected by this change most of our flat healing and leech talents
	have also gotten buffed by roughly 25%. Our talent tree has also changed such that [[spell:218612]] is
	easier to talent into in Raid environments, and [[spell:202138]] is now a baseline spell. [[spell:202138]]
	no longer replaces [[spell:207684]], instead it gets replaced if you talent into [[spell:202137]].
	Beyond that we have gotten a flat 5.5% damage buff to most of our abilities, most notably excluding both
	[[spell:442718]] and [[spell:442502]], which means this is a larger buff to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator
	and will mean it continues to overperform compared to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver with an even bigger margin.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Summary for Vengeance Demon Hunter

The Midnight expansion has brought a long list of changes to Vengeance
Demon Hunter spells and talents including an entirely new Hero Talent tree.
Below you can see breakdown of changes which have a large impact on the specialization
but excludes changes that are just numerical tuning of existing effects.

There have been several baseline updates to our **Hero Talents**.

2.4.1.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

- [[spell:390163]] now activates [[spell:442290]] instead
  			of [[spell:370965]], which is no longer available forVengeance 
  			Demon Hunter.
- New Talent: [[spell:1272143]] - [[spell:390163]]
  			spawns an additional Soul Fragment, and casting [[spell:228477]]
  			has a chance to spawn a Soul Fragment.
- New Talent: [[spell:1272138]] - All Physical damage is increased
  			and [[spell:442294]] damage is increased Further.
- New Talent: [[spell:1272153]] - [[spell:442624]] to stack up to 3 
  			times, and finishing your [[spell:442294]] combo with 
  			[[spell:263642]] puts 3 stacks of [[spell:442624]], and finishing 
  			the combo with [[spell:228477]] grants 12 slashes instead of 6 from 
  			[[spell:442718]].
- [[spell:442686]] now increases [[spell:442294]] damage by 30%
  			and grants 6% Haste for 30 seconds. Does not stack.

2.4.2.

##### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator replaces ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred as our second
			Hero Talent option. It plays around [[spell:1253304]], a buff we
			build up with [[spell:263642]] and releases with our spenders to
			deal massive damage to enemies and reduce the cooldown of
			[[spell:187827]] through [[spell:1256353]].

Most of the remaining Hero Talents can be broken into a couple
			categories such as; buffs to abilities like [[spell:263642]], stat buffs
			linked to our [[spell:1253304]] stacks, buffs and effects tied to 
			[[spell:187827]], and simple buffs to [[spell:1253304]]
			damage.

2.5.

#### Other Midnight Changes to Vengeance Demon Hunter

There have also been changes to both active and passive parts of our
	**defensive toolkit**.

- [[spell:204021]] now applies a buff to us which reduces
  			all damage taken by 40%, instead of being reliant on the DoT effect
  			to reduce enemy damage done.
- Passive talents [[spell:207387]] and [[spell:389958]] no longer
  			have the option to stack, instead the baseline values are stronger to
  			give more upfront defensive value without being reliant on ramping.
- [[spell:203720]] now has the Parry built into the base spell,
  			a longer duration and only a single baseline charge with the second locked
  			in the Class Talent Tree. [[spell:218612]] is buffed and more easily
  			available and functionally guarantees full uptime.
- [[spell:321453]] has been removed for Vengeance, making
  			[[spell:212084]] more of a damage ability.
- [[spell:263648]] have been reworked to a passive talent which
  			gives a shield based on Soul Fragments consumed by [[spell:247454]].

Our **offensive toolkit** has also seen some changes.

- [[spell:247454]] is now on a hasted 25-second cooldown, and
  			deals flat damage which increases based on the amount of Soul Fragments
  			consumed by it.
- [[spell:228477]] is now uncapped and hits more than 5 enemies,
  			damage is also increased based on the amount of Soul Fragments consumed.
- [[spell:1265818]] increases the duration of 
  			[[spell:187827]] and increases the damage of some of our
  			core rotational abilities while it is active.

There have been some changes to some of our **Utility Spells**.

- [[spell:202138]] now replaces [[spell:207684]] instead
  			of being a separate spell.
- [[spell:1266296]] brings a longer stun to our main target.
- [[spell:1266316]] and [[spell:1266496]] offers ways to dispel
  			ourselves from Diseases and Curses respectively.
- [[spell:1266493]] increases our Glide speed when talented, which
  			could potentially enable us to do certain skips or reach places we
  			would not be able to without it.

2.6.

#### Apex Talents for Vengeance Demon Hunter

The Midnight Expansion adds a new feature called Apex Talents, located at
the bottom of the Vengeance Talent tree, which unlocks gradually as you level
to level 90. You can invest up to 4 points into these talents to get the full
benefit, and while they are optional their tuning and power make them very
desirable for Vengeance Demon Hunter and are likely to be recommended in all
content.

For Vengeance Demon Hunter the talents effectively do two things.
The first and last points give your spenders [[spell:228477]] and [[spell:247454]]
an increasing chance per [[spell:204062]] consumed to give you an extra,
shorter duration, cast of your main cooldown [[spell:187827]],
which is both a strong offensive and defensive effect. Meanwhile the second and
third points are passive in nature and increases the damage of [[spell:228477]] and
[[spell:247454]], as well as allowing both to consume one additional
[[spell:204062]], which further increases your chance to activate the first
effect.

This all leads to a fairly enjoyable rotation with somewhat predictable bursts
of power when you spend [[spell:203981]], and the increased soul consumption
for each spender works well with the increased amount of [[spell:203981]] we
can have active, leading [[spell:247454]] to be able to consume all 6, and
[[spell:228477]] half of the full amount at 3.

3.

### Basics of Vengeance Demon Hunter Gameplay

Vengeance is all about resource management, including active mitigation,
healing, damage, and enemy control. The rotation is all about building souls as quickly
as possible with tools like [[spell:263642]] or [[spell:227174]] and then
consuming them with either [[spell:247454]] or [[spell:228477]]. Outside
of the build/spend cycle, you will be weaving in multiple
sigils to help crowd-control the enemies. These key features of the 
specialization can be quickly described through the following bullet points.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_creature_felsunder.jpg>) **Maximize Soul Generation**  
  
    Vengeance live and dies based on their generation and consumption of [[spell:203981]]
    which is our main tool for healing ourselves. Maximizing your generation by keeping
    [[spell:263642]] and [[spell:258920]] on cooldown is key to surviving.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_fierybrand.jpg>) **Cycle Defensive Cooldowns**  
   
    Vengeance has one maintenance defensive in [[spell:203720]] which you can and
    and should keep up at all times. You also want to alternate your 
    [[spell:187827]] and [[spell:204021]] to make sure you
    have one active whenever possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_metamorphasistank.jpg>) **Utilize your Procs**  
  
    Vengeance have three key procs to work around. Your Apex [[spell:1270444]],
    [[spell:1253304]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator and [[spell:442294]] as
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver.

4.

### How to Gear Up as a Vengeance Demon Hunter

While we always recommend simming yourself for ideal results, we do provide a
dedicated Vengeance gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **13 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with new Patch 12.1.5 gear.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 12.1.5, no changes needed.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 12.1.5, no changes needed.
- **23 Sep. 2026 (this page):** Updated with class tuning.
- **01 Sep. 2026 (this page):** Updated with weekly class tuning.
- **26 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated Trinket tier-list with recent changes to our Mastery.
- **26 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated after Mastery buff.
- **26 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated stat priority slightly.
- **26 Aug. 2026 (this page):** Updated with class tuning.
- **16 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with Socket section as well as small changes to Trinket tier-list.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated with opener timelines for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **03 May 2026 (this page):** Updated with the Thick Skin buff.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Minor trinket updates.
- **31 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated with clarifications and formatting.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Removed mention of gathering teas.
- **23 Mar. 2026 (this page):** Updated with minor formatting changes.
- **21 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated macros and added some explanations.
- **18 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Fixed the headers for the BiS lists.
- **18 Mar. 2026 (this page):** Updated with changes to Vengeance Demon Hunter
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated with a minor fix for Midnight Season 1 release.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Midnight Season 1 release, no changes needed.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Midnight Season 1 release, no changes needed.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Midnight Season 1 release.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1 release.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated with a talent build for starting at level 80.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Midnight release.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated for Midnight release.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Midnight.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Midnight.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for the Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for the Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for the Midnight release.
- **26 Feb. 2026 (this page):** Updated for Midnight release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Removed note about bugs since most gameplay altering bugs are fixed.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for the Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **10 Feb. 2026 (this page):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for the Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.7, no changes needed.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.5, Turbo Boost and Puzzling Cartel Chips.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 11.2.5, no changes needed.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **05 Sep. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated with minor fixes to spelling.
- **05 Sep. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated some incorrect drop locations for items, as well as updating the trinket tier list.
- **05 Sep. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Changed some addon recommendations.
- **05 Sep. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with minor spelling fixes.
- **05 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated to make Tier Set bonus baseline and updated numbers for the Combat Assistant.
- **05 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Corrected some spelling mistakes.
- **05 Sep. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Fixed a few minor text errors.
- **05 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated information about tier sets and the Combat Assistant.
- **05 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Minor corrections to the upgrades section.
- **05 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Minor update to the class tree of the Weekly keys build.
- **05 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Minor fix to the stat recommendations.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.2, no changes needed.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 11.2, no changes needed.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 11.2, Mastery slightly devalued.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **17 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with changes the DISC belt after buffs to the effects.
- **17 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated Talent Switches with recommendations and Mythic+ Split up between Weekly and Pushing Higher Key levels.
- **17 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated Talent pages to separate Mythic+ builds between Weekly Keys and Pushing High Key levels.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.1.7 to verify that rotation and talents are still relevant.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.7 with the new DISC belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7, no changes needed.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.7, no changes needed.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7, no changes needed.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.1.7, no changes needed.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 11.1.7, no changes needed.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.7, no changes needed.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **19 May 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with slightly altered Helmet enchants after buffs.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated the trinket tier list and added Mythic+ options to the Cartel Chips.
- **29 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with new information about the Puzzling Cartel Chips.
- **29 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated High Mythic+ build and added Dungeon tips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Fixed an error and updated the description of PVP talents for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with new Helmet enchants from Horrific Visions in Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.5 with a fix to the Mythic+ pre-sets.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 11.1.5, no changes needed.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **12 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated talent explanation section with minor changes ahead of Patch 11.1.5.
- **12 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated with talent changes before Patch 11.1.5.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-liberation-of-undermine-raid-guide>)):** Updated with Gallywix tips.
- **02 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with new information on Cyrce's Circlet.
- **02 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-liberation-of-undermine-raid-guide>)):** Updated with some tips and talents.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Corrected the spell mentioned in one of the macro description.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with best enchants for patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for patch 11.1.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated for patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-liberation-of-undermine-raid-guide>)):** Guide added.
- **20 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated further to account for the recent buffs to Cyrce's Circlet.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated to account for Cyrce's Circlet buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with information on Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Removed Reaver's Glaive macro since it is not relevant currently.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated with recommended builds.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 11.0.7, no changes needed.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updates to simplify rotation.
- **15 Dec. 2024 (this page):** Updated for patch 11.0.7.
- **24 Nov. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Small update to Weapon Enchants.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for patch 11.0.5, no changes needed.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with trinkets for patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for patch 11.0.5, no changes needed.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated the section with weapon oils/stones.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for patch 11.0.5, no changes needed.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.5 with some minor additions to tips and tricks.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for patch 11.0.5, no changes needed.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for patch 11.0.5, no changes needed.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated with Patch 11.0.5 changes.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for patch 11.0.5, no changes needed.
- **21 Oct. 2024 (this page):** Updated for patch 11.0.5 with all the new changes.
- **09 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated information regarding defensive stat priority and added information about diminishing returns.
- **09 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated after buff to Lesser Soul Fragments.
- **28 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-nerub-ar-palace-raid-guide>)):** Updated with new tips and tricks.
- **21 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated Mythic+ trinket list.
- **15 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated trinket lists after trinket tuning.
- **13 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Added section for Voidbound affix.
- **13 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Cleaned up the section regarding Aldrachi Reaver builds.
- **10 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated Embellishment recommendations.
- **10 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Added section on best gem combinations and fixed some minor formatting errors.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for The War Within Season 1, no changes were necessary.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Season 1 of The War Within.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Season 1 The War Within, no changes were needed.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Minor clarification to leg enchants.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Added some information to Haste description.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Prepared for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for season 1 of The War Within, no rotational changes have been made.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Some updates for the release of Season 1 of The War Within.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Fixed a few errors in spell descriptions.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Changed the recommended raid talents.
- **09 Sep. 2024 (this page):** Minor edits ahead of The War Within Season 1.
- **29 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated rotations and matched talent build buttons to new recommended talent builds.
- **29 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated recommended talent builds.
- **28 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Fixed a formatting error.
- **26 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated with talent recommendations for Delves.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/vengeance-demon-hunter-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **19 Jul. 2024 ([The War Within](<https://www.icy-veins.com/wow/vengeance-demon-hunter-the-war-within-pve-guide>)):** Updated for The War Within Pre-Patch.
- **19 Jul. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/vengeance-demon-hunter-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/vengeance-demon-hunter-mists-of-pandaria-remix-guide>)):** Page added.
- **12 May 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated the leveling rotation.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated description of Sigil of Silence after changes in Patch 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated with changes to spells in Patch 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Updated with Vengeance changes in Patch 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Season 4,
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Season 4 with new gear and special items.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with clarification on which food buff to use when.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Added some information regarding diminishing returns on secondary stats.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Some minor adjustments to spell descriptions for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Minor corrections and updates to talent descriptions.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Slight adjustments and clarifications to the basic rotations.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Corrected rotation so Soul Carver appears at the correct level.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.6 and fixed a typo.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** A minor mistake fixed as well as clarification added to a macro.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Minor change to recommended potions.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Expanded slightly on a condition for item level differences on gear.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Fixed a few spell descriptions.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated a line to better reflect current single target priorities
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated a few mistakes in some of the spell descriptions.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Fixed a minor error in the description of Sigil of Silence.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Updated for Patch 10.2.6.
- **31 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Fixed minor errors for a couple of spells.
- **27 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Added a Utility based build for Mythic+ and descriptions for some optional talent options.
- **27 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Added link to a Utility build for Mythic+ content.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for changes to The Hunt and Elysian Decree in Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **19 Dec. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Reworded a paragraph slightly.
- **19 Dec. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated a few rotational nuances.
- **06 Dec. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated Phial and Healing Potion recommendations.
- **27 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Changed Embellishment slot and Mythic+ Neck recommendations and specified dungeon for Dawn of the Infinite gear.
- **10 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated so AoE Rotation now shows full rotation.
- **08 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Removed a mention of Undulating Sporecloak.
- **08 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated Rotation Switches for the Heretic Build.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated after Undulating Sporecloak Nerf.
- **07 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with correct Stat Gem.
- **07 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Fixed error in text and a minor Talent error on the Offensive Muthic+ build.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated with changes for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated with new and changed spell descriptions for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **06 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Link updated
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Restructured and updated for Patch 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Restructured and updated for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Restructured the page.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated with some minor corrections for Patch 10.1.5.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **09 Aug. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated talents for multiple targets.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated section regarding the Onyx Annulet and added information about the Dawn of the Infinites Megadungeon.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **19 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated Embellishments recommendations.
- **19 Jun. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated Tier set interaction.
- **19 Jun. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated spell description for a spell that was wrong.
- **10 Jun. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated Onyx Annulet section and added gear for patch 10.1.5.
- **10 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated with new build added for Fortified Dungeons.
- **10 Jun. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.1.5.
- **10 Jun. 2023 (this page):** Updated for Patch 10.1.5
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated Trinket recommendations and added information on Firelands trinkets.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Changed Trinket recommendation and other gear related changes.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated section on enchants as well as the section about the Onyx Annulet and Primordial Stones.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated to reflect changes with changing tier sets in patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for new talents and affix changes in Patch 10.1
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated with changes to rotation in patch 10.1
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated with new talent recommendations and talent description for Patch 10.1.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated with changes to spells and talents in Patch 10.1
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated with new beginner friendly talents and rotation for patch 10.1.
- **01 May 2023 (this page):** Updated with changes to Vengeance and its playstyle in Patch 10.1.
- **26 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Fixed issue with Talent Tree.
- **26 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated section about the Onyx Annulet and Primordial Stones.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/vengeance-demon-hunter-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Added section about the Onyx Annulet.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Added section about the Onyx Annulet and Primordial Stones.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated and reviewed for 10.0.7 and added a list of Significant bugs to Vengeance Demon Hunters.
- **08 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated recommendations for weapon enchants and consumables.
- **08 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated description for talents and passives.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **13 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated with Embellishments.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight season 1 start.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated gems and enchants, and added Augment runes.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated with minor changes to make things a bit more clear.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated Soulcrush description and added Elysian Decree to noteworthy talents.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **30 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated Down in Flames description and advice.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **10 Nov. 2022 ([Legendaries](<https://www.icy-veins.com/wow/vengeance-demon-hunter-best-legendaries-shadowlands>)):** Minor updates to Legendary powers.
- **10 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated with minor changes for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/vengeance-demon-hunter-leveling-guide>)):** Updated for Dragonflight.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/vengeance-demon-hunter-best-legendaries-shadowlands>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/vengeance-demon-hunter-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/vengeance-demon-hunter-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-macros-addons>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gems-enchants-consumables>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-mythic-plus-tips>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spec-builds-talents>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-spell-summary>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-easy-mode>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight Pre-Patch.
- **22 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-castle-nathria-raid-guide>)):** Updated with recommended talents for Dragonflight pre-patch.
- **22 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-sanctum-of-domination-raid-guide>)):** Updated with talent recommendation for Dragonflight pre-patch.
- **11 Sep. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/vengeance-demon-hunter-patch-9-2-changes-analysis>)):** Legendary recommendation updated and tier set corrected.
- **30 Jul. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-castle-nathria-raid-guide>)):** Updated for fated Castle Nathria.
- **30 Jul. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-sanctum-of-domination-raid-guide>)):** Updated for Fated Sanctum.
- **19 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/vengeance-demon-hunter-patch-9-2-changes-analysis>)):** Page adjusted for Patch 9.2 launch.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/vengeance-demon-hunter-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/vengeance-demon-hunter-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **01 Nov. 2021 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-sanctum-of-domination-raid-guide>)):** Reviewed and approved for Patch 9.1.5.
- **11 Jul. 2021 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-sanctum-of-domination-raid-guide>)):** Page added.
- **19 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/vengeance-demon-hunter-patch-9-1-changes-analysis>)):** Page created with initial information.
- **03 Jan. 2021 ([Castle Nathria page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-castle-nathria-raid-guide>)):** Updated boss information. Updated build recommendation.
- **08 Dec. 2020 ([Castle Nathria page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-castle-nathria-raid-guide>)):** Added boss tips.
- **01 Dec. 2020 ([Castle Nathria page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-castle-nathria-raid-guide>)):** Added placeholder Castle Nathria page.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **23 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-the-eternal-palace-raid-guide>)):** Updated guide with tips.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-the-eternal-palace-raid-guide>)):** Guide added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **14 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-crucible-of-storms-raid-guide>)):** Updated guide with tips for Crucible of Storms.
- **16 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-crucible-of-storms-raid-guide>)):** Guide added.
- **05 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-uldir-raid-guide>)):** This page has been reviewed and is up to date for patch 8.1.
- **09 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-uldir-raid-guide>)):** Updated all bosses with Uldir information.
- **11 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-uldir-raid-guide>)):** Page added (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Vengeance Demon Hunter leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Demon Hunter leveling guide](<https://www.icy-veins.com/wow/demon-hunter-leveling-guide>).

1.

### Vengeance Demon Hunter Leveling Guide for Midnight

Due to it being a Tank specialization, Vengeance is capable of a multitude of
effective ways of leveling. The ability to pull large groups of enemies quickly by
moving around with [[spell:189110]], and self-sustaining
large amounts of damage through consuming [[spell:203981]],
makes it fairly efficient at questing despite doing less
damage than a DPS specialization. Alternatively, you will also enjoy short, if not
instant queues to dungeons, which means that you can also speedrun dungeons for experience
by gathering a ton of enemies and clearing dungeons in only a handful of pulls.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Consumables for Midnight

As you level in Midnight there are certain consumables you
could consider using to speed up leveling. Below is a list of a few items that
can be useful in some situations.

- [[spell:1246966]] can be used in a similar fashion to [[spell:58984]]
  to drop combat, which can be very useful both in outdoor content to let you drop
  combat to mount, or to skip enemies as you go between quests in areas with many
  enemies.
- [[item:244835]] can be useful to give a burst of healing
  if you find yourself fighting too many enemies at some point while leveling.
- Enchants that give Speed for Cloak and Bracers can be useful if only to slightly
  speed up your process whenever you are unable to mount.
- Speed consumables can help speed up your journey to some extent, including
  foods like [[item:225592]] which can be useful to
  speed up your process whenever you are unable to mount.
- [[item:212265]] can be combined with cooldowns to deal slightly
  more damage when leveling, which might speed your process up a bit if you have
  some lying around.

2.

### Leveling Talents

You unlock your Demon Hunter talent tree at level 10
and will get access to points to spend in the Vengeance tree every level after
that.

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Vengeance Level 80 Midnight Leveling
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMmBDzMzYYGzMmxMmZGmZmZsNmBDAAAAAAAAYGjNAAAAMYmZGzotZGDAGAAAAA"
}
```
:::

Below are what talents and abilities are recommended that you access as you level.
Note that talents may differ from what is recommended for other content once you
hit level 90.

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYYmZGDzYmxMmxMzwMzMjtxMYYAAAAAAAAYGjNAAAAMYmZmZml2mZmBADAAAAD"
}
```
:::

:::details 来源计算器编码
```
#FJ-lONUEnKSVZQQCXwK44yyOOMNssQFGBDmm+A-oAJmnTlQRUVabkjHHEXNILLYeefgKd-AAAA-VWaKQmEIQAwYYA-
```

:::

2.1.

#### War Mode Talents for Leveling

Questing in War Mode provides at least 10% additional experience
and three new talents to choose. You will unlock one talent slot at level 20, 30, and
level 40. There are several good choices depending on
the content you are doing and whether or not you are playing solo.

- [[spell:205626]] is a passive ability that increases your
  movement speed by 15% for 3 seconds when dealing damage. This ability is
  designed to move from pack to pack quickly and more efficiently.
- [[spell:205627]] reflects damage back to the attacker for 30%
  of the damage received when Demon Spikes is active. A strong tool to speed up
  how fast you can kill enemies while leveling.
- [[spell:205630]] crowd controls 1 target for 6 seconds. If the
  ability is activated again, throw the target at a location within 40
  yards and stun everything in the target area for 3 seconds. This
  ability provides additional crowd control and is fun to use.
- [[spell:207029]] debuffs the target when taunted, applying the Focused
  Assault debuff, which increases the damage received by 3%. Your melee
  attacks refresh the duration of Focused Assault. Each unique target up to
  5 that hits the target will stack Focused Assault by an additional 3%. This
  ability will provide a decent single-target damage buff in a party.
- [[spell:205596]] increases the duration of Imprison by 2 seconds and
  makes the imprisoned target immune to damage and healing. This talent is amazing
  for arena and battlegrounds, but it should not be picked for leveling.
  Imprisoning a target while using this talent will put you into combat and
  prevents monster skipping when leveling.
- [[spell:213480]] increases Fury generation based on magic damage
  received. Larger attacks will increase Fury generation. This talent is quite
  situational and weak while leveling.
- [[spell:205625]] removes all magical effects when you cast Immolation
  Aura. This talent is situational, but it can be very strong depending on the
  situation.
- [[spell:205629]] transforms you into a demon and increases your
  movement speed by 175%. Any enemy hit with the trample will be knocked and
  receive physical damage. You are immune to snares while trampling. Demonic
  Trample shares cooldown with Infernal Strike. This ability is decent
  to move around inside caves and other places where you cannot mount.
- [[spell:211489]] reduces the cooldown of sigils by 25% which can be useful
  if you are leveling by doing large pulls while questing.
- [[spell:205604]] removes all harmful magic effects on you and all
  allies within 10 yards and, if possible, returns them to their caster.
  It has a 1-minute cooldown. It can provide situational value while leveling.
- [[spell:355995]] empowers your [[spell:278326]] to now affect
  all enemies within 8 yards of the target and grants 5% leech for 5 seconds
  after using it.
- [[spell:356510]] makes your [[spell:185123]] deal damage
  from a random school of magic, leaving a mark increasing their damage taken
  from that school by 10% for 20 seconds. A good talent to increase damage
  done to enemies that you gather with [[spell:185123]].
- [[spell:357419]] increases the radius of [[spell:196718]] by
  4 yards and increases its duration by 2 seconds.
- [[spell:206803]] launches you up in the air and grants access to
  [[spell:206966]] allowing you to deal damage to enemies on the ground.
- [[spell:354489]] grants you immunity to loss of control effects while
  under the effect of [[spell:198793]] and reduces damage taken by 75%
  until you land. A talent that will not add much to your leveling
  experience.

3.

### Leveling Rotation

To help with understanding what changes as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 20 起：**Use [[spell:187827]].
2. **等级 27 起：**Use [[spell:390163]].
3. **等级 69 起：**Use [[spell:207407]].
4. **等级 13 起：**Use [[spell:204021]].
5. **等级 11 起：**Use [[spell:212084]].
6. **等级 10 起：**Use [[spell:204596]].
7. **等级 11 起：**Use [[spell:258920]].
8. **等级 13 起：**Use [[spell:247454]] with 5 Soul Fragments.
9. **等级 8 起：**Use [[spell:228477]] with 2 or more Soul Fragments.
10. **等级 10 起：**Use [[spell:232893]] to build Fury.
11. **等级 8 起：**Use [[spell:263642]] to build Fury and Soul Fragments.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **02 Mar. 2026:** Updated with a talent build for starting at level 80.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, no changes needed.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Sep. 2025:** Updated with minor fixes to spelling.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no changes needed.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7 to verify that rotation and talents are still relevant.
- **21 Apr. 2025:** Fixed an error and updated the description of PVP talents for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, no changes needed.
- **21 Oct. 2024:** Reviewed for patch 11.0.5, no changes needed.
- **09 Sep. 2024:** Reviewed for The War Within Season 1, no changes were necessary.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **12 May 2024:** Updated the leveling rotation.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4,
- **25 Mar. 2024:** Corrected rotation so Soul Carver appears at the correct level.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **26 Mar. 2023:** Fixed issue with Talent Tree.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Vengeance Demon Hunter in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Vengeance Demon Hunter

This page is intended for players who are new to the game or class,
who might not have intentions of raiding Mythic difficulty, or simply want a more
straightforward way to play their specialization, without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Vengeance Demon Hunter is when boiled down to the core a fairly simple
tank. You do not have many spells that have intricate conditions when
to use them, and your defensive tools are fairly straightforward.
Below are three quick rules which will help make your life easier as you
are learning to play Vengeance:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_creature_felsunder.jpg>) **Maximize Soul Generation**  
  
    Vengeance live and dies based on their generation and consumption of [[spell:203981]]
    which is our main tool for healing ourselves. Maximizing your generation by keeping
    [[spell:263642]] and [[spell:258920]] on cooldown is key to surviving.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_fierybrand.jpg>) **Cycle Defensive Cooldowns**  
   
    Vengeance has one maintenance defensive in [[spell:203720]] which you can and
    and should keep up at all times. You also want to alternate your 
    [[spell:187827]] and [[spell:204021]] to make sure you
    have one active whenever possible.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_metamorphasistank.jpg>) **Utilize your Procs**  
  
    Vengeance have three key procs to work around. Your Apex [[spell:1270444]],
    [[spell:1253304]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator and [[spell:442294]] as
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver.

2.

### Best Talents for Vengeance Demon Hunter

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator   Raid Talents

2.1.

#### Beginner Raid Talents for Vengeance Demon Hunter

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator offers a relatively simple Raid build with good
passive defensive coverage. The core concept of this build centers around
building and spending [[spell:1253304]] stacks with your core abilities. This
version drops some damage talents to get [[spell:209258]] for a safety net,
which can be useful, especially when learning new Raid Encounters.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYGzMDzMzM2GzsNGAAAAAAAAwMzYDAAAADGzMzMbtNzMDAAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OUlNSYEKVDFLQQWY44OOyyMNssG30CONJEA-oAJnTQRUabkFOOuQWw88+A7MLXGrIUA-AAAA-VWYaKMiMJQYgAA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator   AoE Talents

2.2.

#### Beginner Mythic+/Delve Talents for Vengeance Demon Hunter

The best build for Mythic+ and Delves is very similar to the Raid Build,
opting to take some utility and defensive options more applicable to the content type
at the cost of some of the weaker damage talents. The core concept of this 
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator build centers around building and spending [[spell:1253304]]
stacks with your core abilities. This version drops some damage talents to get
[[spell:209258]] for a safety net, which can be especially useful when learning
in Mythic+ content.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmBWMjZwMjZGzMzMzYwMzM2YmtxwAAAAAAAAwMzMbAAAAYgZmZmZrtZmZAgBAAAwA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OPSUYflKNVDFJKQQ44OPOyyAHJTFMmm2C0C-oAmnTlQRUVZZabkFOOeuw88QWW6AV4A-AAAA-VWYaKMiMJQYgAA-
```

:::

### Vengeance Demon Hunter   Basic Rotation

2.3.

#### Basic Single-Target Rotation for Vengeance Demon Hunter

- Use extra charges of [[spell:187827]] you get from your
  Apex Talent [[spell:1270444]].
- As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator use [[spell:228477]] or [[spell:247454]] when you
  have 3 stacks of Voidfall.
- As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver use [[spell:442294]] and finish the Combo
  by using [[spell:263642]] and then [[spell:228477]].
- Use [[spell:204021]] and [[spell:187827]] close to on cooldown.
- Use all of [[spell:207407]], [[spell:390163]], [[spell:258920]], and [[spell:204596]] on cooldown.
- Keep [[spell:263642]] recharging.
- Use [[spell:247454]] close to on cooldown when you have 5 or more
  Soul Fragments ready.
- Use [[spell:232893]] when low on Fury.
- Use [[spell:228477]] to spend Fury and Soul Fragments for damage and healing.
- Use [[spell:185123]] as a filler
  when nothing else is available.

2.4.

#### Basic Multi-Target Rotation for Vengeance Demon Hunter

- Use extra charges of [[spell:187827]] you get from your
  Apex Talent [[spell:1270444]].
- As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator use [[spell:228477]] or [[spell:247454]] when you
  have 3 stacks of Voidfall.
- As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver use [[spell:442294]] and finish the Combo
  by using [[spell:263642]] and then [[spell:228477]].
- Use [[spell:204021]] and [[spell:187827]] close to on cooldown.
- Use all of [[spell:207407]], [[spell:390163]], and [[spell:204596]] close
  to on cooldown.
- Use [[spell:320378]] on cooldown unless you have 5 or more Soul
  Fragments ready.
- Use [[spell:247454]] close to on cooldown when you have 5 or more
  Soul Fragments ready.
- Keep [[spell:263642]] recharging.
- Use [[spell:228477]] to spend Fury and Soul Fragments for damage and healing.
- Use [[spell:232893]] when low on Fury.
- Use [[spell:185123]] as a filler when nothing else is available.

2.5.

#### Apex Talent for Vengeance Demon Hunter: Untethered Rage

The Vengeance Apex Talents [[spell:1270444]] does a few things, some
passive that do not impact your gameplay a lot, and some that you will have to
interact with. When the main ability from the first point activates you gain
a charge of [[spell:187827]] which lasts 10 seconds and have to
be used within 12 seconds. There are some things that you can do to benefit even
more from this effect, but simply using [[spell:187827]] when it
activates is still very good value and can be done if you do not want to complicate
things.

The second point you place in your Apex Talent also lets [[spell:247454]]
and [[spell:228477]] consume one additional [[spell:204062]], which
means you can consume more per button press than before you have it. This might
take some getting used to but does not affect gameplay past that point.

2.6.

#### Tier Set for Vengeance Demon Hunter

Midnight Season 2 brings a new Tier Set, which for Vengeance Demon Hunter
centers around our core builder spell [[spell:263642]]. The 2-piece bonus simply
increases the damage [[spell:263642]] deals, and the 4-piece bonus gives it
a small chance to explode for medium Fire damage to all nearby enemies.

The tier set does not affect our rotation and has no real effect on how we play,
however it is a decent power increase that you will want to try and pick up during
the Season.

### Vengeance Demon Hunter   Defensive Abilities

2.7.

#### Active Mitigation and Cooldowns

You have one active mitigation ability that you need to use to keep yourself
alive, which is [[spell:203720]]. This should be used frequently, even
simply against auto-attacks. Always keep at least one of its charges
rolling.

Aside from this, you also have a couple of other abilities you can use to
help keep you alive.

[[spell:204021]] should be used when you think
you will take high damage soon or simply to give damage reduction for a period
of time.

In addition to that, you have access to a major survivability cooldown in
[[spell:187827]]. This works best when used proactively to increase
your health in preparation for incoming damage. Additionally,
an additional Soul Fragment and an extra 15 Fury
is generated when [[spell:263642]] is used.

### Vengeance Demon Hunter   Stat Priority

2.8.

#### Vengeance Demon Hunter Stat Priorities

Currently, you will want to prioritize stats as follows. For more information 
on what's presented on this page, check out our main [Stat Priority page](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>).

Agility

Haste

Mastery

Versatility

Critical Strike

### Blizzard   Combat Assistant

2.9.

#### Combat Assistant for Vengeance Demon Hunter

Patch 11.1.7 added the [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) tool, which can help simplify your
rotation either by highlighting abilities or by condensing it into a single button,
which rotates through abilities for you. These tools rotate through a priority
list set up ahead of time by Blizzard and are of varying quality, depending on your
Hero Talents of choice. Below is information for both Hero Trees. Do note that
the Single-Button Assistant comes with a built-in penalty to the global cooldown,
making it 25% longer. Because of this, it will always perform worse than
if you use the spells yourself.

**The Single-Button Assistant is currently broken and does not use [[spell:263642]]
right now, effectively breaking it completely for both Hero Talents,
until this is fixed it is highly recommended to not use it in any situation.**

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **26 Aug. 2026:** Updated stat priority slightly.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **26 Feb. 2026:** Updated for the Midnight release.
- **10 Feb. 2026:** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, no changes needed.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Sep. 2025:** Updated information about tier sets and the Combat Assistant.
- **05 Aug. 2025:** Minor fix to the stat recommendations.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, no changes needed.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updates to simplify rotation.
- **21 Oct. 2024:** Reviewed for patch 11.0.5, no changes needed.
- **09 Sep. 2024:** Changed the recommended raid talents.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Slight adjustments and clarifications to the basic rotations.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated with new beginner friendly talents and rotation for patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Vengeance Demon Hunter in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Vengeance Demon Hunter

Vengeance Demon Hunter continues Midnight with two Hero Talents
  that have distinct use cases built around a otherwise fairly
  similar gameplay loop. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver has an extremely
  potent priority damage profile through [[spell:442806]], rivaling
  that of many DPS specializations, at the cost of falling behind
  in damage quickly as soon as you add more targets. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator
  instead has a very strong and bursty damage profile around their
  [[spell:1253304]] mechanic scaling much better into multi-target situations 
  doing about 40% more damage on 5 targets, a massive
  gap that only widens as you add more targets.

- **Single-Target -** The Hero Talents deal very similar damage against
    a single target, however ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator is both better able to take
    advantage of damage amplifying phases and offers a slightly better defensive
    profile with shorter defensive cooldowns.
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator dominates as soon as you add more targets
    to a fight, with the difference only growing as you add more targets. However, if there is
    a single target with much higher priorty to kill then you might want
    to consider maybe going ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver for the ability to funnel damage into
    that target.

Because of this ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator remains
  the recommended Hero Talent for virtually all content, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
  being a viable choice, especially in content with fewer targets, specific
  raid fights with some minor mobs you can use for increased priority damage, or
  simply if you enjoy the playstyle more.

**Quick Start Import Codes:**

:::talents Vengeance Single Target
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYGzMDzMzM2GzsNGAAAAAAAAwMzYDAAAADGzMzMbtNzMDAAAAAwA"
}
```
:::

:::talents Vengeance AoE
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmBWMjZwMjZGzMzMzYwMzM2YmtxwAAAAAAAAwMzMbAAAAYgZmZmZrtZmZAgBAAAwA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Annihilator

Raid/Single-Target

recommended

Mythic+

recommended

Delves

recommended

Aldrachi Reaver

Raid/Single-Target

Mythic+

Delves

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator Raid Talents

With current tuning
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator offers the best single-target damage, with heavy burst damage
centered around [[spell:187827]] and syncing up [[spell:204021]]
with the bursts around [[spell:1253304]] and potential Apex procs of
[[spell:1270444]].
It is also loses less damage by being forced out of melee range since more of
your damage is centered around your cooldown windows. The raid build focuses
primarily on offensive value, taking defensive and mobility nodes to fill out
the tree. [[spell:209258]] is opted out for
[[spell:207407]] for a small offensive gain, but if you want to have a
cheat death effect, especially if you are finding content tough, you
can switch [[spell:207407]] to [[spell:209258]].

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator Mythic+ Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator
offers an extremely potent cooldown centered damage profile around [[spell:187827]] and syncing up [[spell:204021]]
with the bursts around [[spell:1253304]] and potential Apex procs of
[[spell:1270444]], allowing you to pull aggressively around your and your
groups cooldowns. It has the potential to deal more
damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, and while it lacks some of the healing
capabilities of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver it makes up with relatively strong
passive defensive nodes including [[spell:1256353]] which gives cooldown
reduction on [[spell:187827]] which combined with
[[spell:1270444]] can lead to a pretty significant amount of
[[spell:187827]] uptime against both hard hitting Bosses and large
dangerous trash pulls.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator Delve Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator
utilizes the very strong burst damage profile around [[spell:187827]]
and [[spell:1256295]] to allow you to quickly take care of large groups
of enemies in Midnight [Delves](<https://www.icy-veins.com/wow/delves-guide>) before they pose a serious danger. While
it does fall slightly behind on self-sustain it provides good damage to let you
quickly finish Delves without spending all too much time doing so. This build has
also opted into most mobility nodes.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver Raid Talents

With current tuning
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver appears slightly behind in pure single-target damage, while
also featuring a slightly more punishing rotation, it also loses slightly more
damage and defensive value when you are forced out of melee range of enemies.
The raid build focuses primarily on offensive value, taking defensive and
mobility nodes to fill out the tree. [[spell:209258]] is opted out for
[[spell:207407]] for a small offensive gain, but if you want to have a
cheat death effect, especially if you are finding content tough, you
can switch [[spell:207407]] to [[spell:209258]].

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver Weekly Key Mythic+ Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver has
some things going for it in Mythic+. While it is not as strong
offensively as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator, once targets start to live long enough for
the funnel potential of [[spell:442806]] can start to shine as you
get into higher Mythic+ levels. Defensively it scales well with increased damage
intake due to the high generation of [[spell:203981]] which makes
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver a fairly self-sufficient specialization.
However, despite all of these things it still underperform ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator offensively
to a degree where it is not the recommended Hero Talent for most Mythic+ keys.

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver Delve Talents

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
takes advantage of its great self-sustain to power through Midnight [Delves](<https://www.icy-veins.com/wow/delves-guide>),
and can make use of smaller enemies to take out more dangerous targets through
[[spell:442806]]. These tools make it more than capable to manage by its
own in Delves. This build has also opted into most mobility nodes.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYGzMDzMzM2GzsNGAAAAAAAAwMzYDAAAADGzMzMbtNzMDAAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OUlNSYEKVDFLQQWY44OOyyMNssG30CONJEA-oAJnTQRUabkFOOuQWw88+A7MLXGrIUA-AAAA-VWYaKMiMJQYgAA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmBWMjZwMjZGzMzMzYwMzM2YmtxwAAAAAAAAwMzMbAAAAYgZmZmZrtZmZAgBAAAwA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OPSUYflKNVDFJKQQ44OPOyyAHJTFMmm2C0C-oAmnTlQRUVZZabkFOOeuw88QWW6AV4A-AAAA-VWYaKMiMJQYgAA-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMjZwMjZGzYGzMDzMzM2GzghBAAAAAAAgZY2AAAAwgZmZmZWabmZGAMAAAAMA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OUflKNSYhEFIILV54MPPOYyyAJFMmmssQDA-oAmnTlQRUVabkEFOOeuGRWWw88+AV6A-AAAA-VWYaKMgMJQYgAA-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMzMDMjZGzYGzMDzMzM2GzsNGAAAAwsNDGGLbMhhZmxCAAAAGMAAwMDAAAAAD"
}
```
:::

:::details 来源计算器编码
```
#FJ-OUlNSYEKVDFLQQWY44MPOyyAHFMmm2C0aZB-oAJnTQRUVabkEFOOuGRWw88+A7MLXUA-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmBWMjZwMjZGzMzMzYwMzM2YmtxwAAAAwsNDGGLLMhhZmZWAAAAwADAAmZAGAAAAD"
}
```
:::

:::details 来源计算器编码
```
#FJ-OPSUYflKNVDFJKQQ44OPOyyAHJTFMmm2C0C-oAmnTlQRUVabkFOOeuQWw88A56yyWUA-AAAA-GIOg0AEUowgCzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMzMjMzMYWMjZwMjZGzYGzMDzMzM2GzghBAAAgZbGMMWWYCDzwsAAAAgBzAAgZGwAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OUflKNSYhEFIILV54MPPOYyyAJFMmmssQDA-oAmnTlQRUVabkEFOOeuGRWWw88+AV6A-AAAA-GIOg0AEUowgCzC-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a system that was introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>). 
By doing a few quests you can unlock 5 runes which give you minor power boosts.
The powers range from passive damage effects, to minor defensive bonuses
and most imporantly a minor proc that grants passive secondary stats of your choice.

Below are the recommendations for your runes. You will 
be able to freely change your runes and experiment with different choices. The choices
below gives the best balance of damage, healing and gives you Haste from
rune 4 which is usually your best secondary stat offensively and defensively.

- Rune 1:[[spell:1279599]]
- Rune 2:[[spell:1279604]]
- Rune 3:[[spell:1287555]]
- Rune 4:[[spell:1279610]]
- Rune 5:[[spell:1279614]]

3.

### Apex Talent: ![Untethered Rage Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_ability_demonhunter_vengeanceismine.jpg>) Untethered Rage

The Vengeance Demon Hunter Apex Talent is the new feature introduced
in the Midnight expansion, a single node where you can spend up to four of the
new Specialization talent points you unlock as you level to 90. For Vengeance
Demon Hunter the Apex Talents effectively have two functions, to empower our spenders
in [[spell:228477]] and [[spell:247454]], and to make casting them have a chance
to give us extra uses of [[spell:187827]] with slightly shorter duration.
Below is a list of how each point invested work, and then some discussion how it
affects our gameplay.

1. [[spell:1270444]] — Consuming [[spell:204062]]s with
   [[spell:247454]] or [[spell:228477]] have a chance to grant
   [[spell:1270444]], giving a second charge of [[spell:187827]]
   which will last 10 seconds. The chance increases with the amount of [[spell:203981]]
   consumed.
2. [[spell:1270448]] — Two point node. The first point allows
   [[spell:247454]] and [[spell:228477]] to consume an extra
   [[spell:204062]]. Each point further increases the damage bonus from
   consuming [[spell:204062]]s by 5% per [[spell:204062]], for 10% total.
3. [[spell:1270449]] — When a cast of [[spell:247454]] or
   [[spell:228477]] does not grant [[spell:1270444]], you gain 1 stack
   of [[spell:1270547]], granting 1% Agility and a higher chance of activating
   [[spell:1270444]]. The stacks last for 12 seconds and do not refresh
   duration after getting a [[spell:1270444]] proc.

These are all strong effects, and generally recommended in all content forms once
they are available. They have relatively passive, but yet noticeable effects on gameplay,
with [[spell:1270444]] and [[spell:1270449]] giving us more uptime on
[[spell:187827]] which gives us higher defensive uptime and allows us
to use our defensives for offensive value more frequently.

[[spell:1270448]] is also very interesting since it increases the amount
of [[spell:203981]] consumed by [[spell:247454]] and [[spell:228477]],
which in turn increases the chance for [[spell:1270444]] to activate.

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator the Apex nodes is especially interesting since activating
[[spell:187827]] granted by [[spell:1270444]] still activates
effects like [[spell:1256295]] and [[spell:1256307]]. Making it an
even more potent effect.

4.

### Hero Talents

Vengeance has two distinct Hero Talent choices available that, as covered in the
above sections, drastically alter your gameplay goals depending on which you pick.
These two Hero Talents are ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver focuses very heavily on the consumption of [[spell:203981]]
to grant access to [[spell:442294]] which is the foundation of the entire
Hero tree. [[spell:442806]] grants a very strong funnel profile, where fighting
more enemies lets you increase the damage you deal to a priority target. This can
be useful in both raid in fights with many enemies as well as in Mythic+ to deal
a lot of damage to dangerous enemies and bosses. The defensive profile of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
is incredibly focused on healing, making it a strong choice for self-sustain, it
does lack tools to mitigate damage from large hits to compensate for this.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator is designed around building [[spell:1253304]] stacks
with [[spell:263642]] which you then consume to rain down meteors on enemies once
you reach 3 stacks. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator excels in dealing strong, bursty damage
around [[spell:187827]] thanks to the [[spell:1256295]] talent,
especially if you buff the damage with [[spell:389220]].
The defensive profile has two parts, one through passive stat bonuses from talents
like [[spell:1253668]], [[spell:1256245]] and extending them with [[spell:1253805]].
The second major part of Annihilator is [[spell:1256353]]
which reduces the cooldown of [[spell:187827]] by 10 seconds whenever you
call down a set of three meteors which in itself enhances the loop through [[spell:1256295]].

5.

### PvP Talents (War Mode)

You have the option to enter into "War Mode" in your Factions Capital city.
Enabling War Mode provides the following benefits:

- Grants access to PvP talents in the open-world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended to enable the feature to maximize your leveling and rewards at
maximum level. However, you will enable yourself for open-world PvP and the
possibility, so be aware of hostile enemy players who could interfere with you,
and this is a risk you will have to take.

Generally, the selections are made to optimize your ability to kill enemies
faster, increasing your pace when moving through content.

1. [[spell:205626]] is a passive ability that increases your
   movement speed by 15% for 3 seconds when dealing damage. This ability is
   designed to move from pack to pack quickly and more efficiently.
2. [[spell:205627]] reflects damage back to the attacker for 30%
   of the damage received when Demon Spikes is active.
3. [[spell:205630]] crowd controls 1 target for 6 seconds. If the
   ability is activated again, throw the target at a location within 40
   yards and stun everything in the target area for 3 seconds. This
   ability provides additional crowd control and is fun to use.
4. [[spell:207029]] debuffs the target when taunted, applying the Focused
   Assault debuff, which increases the damage received by 3%. Your melee
   attacks refresh the duration of Focused Assault. Each unique target up to
   5 that hits the target will stack Focused Assault by an additional 3%. This
   ability will provide a decent single-target damage buff in a party.
5. [[spell:205596]] increases the duration of Imprison by 1 second and
   makes the imprisoned target immune to damage and healing. This Talent is amazing
   for arenas and battlegrounds, but it should not be picked for leveling.
   Imprisoning a target while using this Talent will put you into combat and
   prevent monster skipping in PvE content.
6. [[spell:213480]] increases Fury generation based on magic damage
   received. Larger attacks will increase the Fury generation. This Talent is quite
   situational and should not be used in normal content.
7. [[spell:205625]] removes all magical effects when you cast
   Immolation Aura.
   This Talent is situational, but it can be very strong depending on the
   situation.
8. [[spell:205629]] transforms you into a demon and increases your
   movement speed by 175%. Any enemy hit with the trample will be knocked and
   receive physical damage. You are immune to snares while trampling. Demonic
   Trample shares cooldown with Infernal Strike. This ability is very strong
   in battlegrounds to remove snares and for pseudo-crowd control with the
   knockdown.
9. [[spell:211489]] reduces the cooldown of sigils by 25%. This Talent
   should not be used.
10. [[spell:205604]] removes all harmful magic effects on you and all
    allies within 10 yards and, if possible, returns them to their caster.
    It has a 1-minute cooldown.
11. [[spell:355995]] empowers your [[spell:278326]] to now affect
    all enemies within 8 yards of the target and grants 5% leech for 5 seconds
    after using it.
12. [[spell:356510]] makes your [[spell:185123]] deal damage
    from a random school of magic, leaving a mark increasing their damage taken
    from that school by 10% for 20 seconds.
13. [[spell:357419]] increases the radius of [[spell:196718]] by
    4 yards and increases its duration by 2 seconds.
14. [[spell:206803]] launches you up in the air and grants access to
    [[spell:206966]] allowing you to deal damage to enemies on the ground.
15. [[spell:354489]] grants you immunity to loss of control effects while
    under the effect of [[spell:198793]] and reduces damage taken by 35%
    until you land.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **26 Feb. 2026:** Updated for the Midnight release.
- **10 Feb. 2026:** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, no changes needed.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Sep. 2025:** Corrected some spelling mistakes.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **17 Jun. 2025:** Updated Talent pages to separate Mythic+ builds between Weekly Keys and Pushing High Key levels.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7, no changes needed.
- **21 Apr. 2025:** Reviewed for patch 11.1.5, no changes needed.
- **12 Apr. 2025:** Updated talent explanation section with minor changes ahead of Patch 11.1.5.
- **24 Feb. 2025:** Updated for patch 11.1.
- **15 Dec. 2024:** Updated with recommended builds.
- **21 Oct. 2024:** Reviewed for patch 11.0.5, no changes needed.
- **13 Sep. 2024:** Cleaned up the section regarding Aldrachi Reaver builds.
- **09 Sep. 2024:** Some updates for the release of Season 1 of The War Within.
- **29 Aug. 2024:** Updated recommended talent builds.
- **26 Aug. 2024:** Updated with talent recommendations for Delves.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Minor corrections and updates to talent descriptions.
- **19 Mar. 2024:** Updated a few mistakes in some of the spell descriptions.
- **27 Jan. 2024:** Added link to a Utility build for Mythic+ content.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Restructured the page.
- **09 Aug. 2023:** Updated talents for multiple targets.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **10 Jun. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated with new talent recommendations and talent description for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated Soulcrush description and added Elysian Decree to noteworthy talents.
- **30 Nov. 2022:** Updated Down in Flames description and advice.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Vengeance Demon Hunter, depending on the type of damage you will be tanking.
We also have advanced sections about cooldowns, procs, etc. in order to maximize your
survivability and DPS. All our content is updated for World of Warcraft Patch
12.1.5.

1.

### Vengeance Demon Hunter Gameplay and Rotation Guide

Welcome to the rotation guide for Vengeance Demon Hunter. Below, you will find
the general priority of your abilities, as well as how your talent choices
will affect the Rotation.
Further down, you can find out more about several 
[core mechanics](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities#core-mechanics>) that have a large impact
on your gameplay, as well as information about several strong
[cooldowns](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities#cooldowns>), and how you want to
consider their uses and what value they add to your core toolkit. In the
final section, you will also find advice on how to best approach your
[defensive toolkit](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-rotation-cooldowns-abilities#active-mitigation>).

Your Rotation will vary a lot depending on both the regular talent choices
you make. They are further impacted by the Hero talent tree you use.
To start, select your Hero talent tree and your talent choices below. If a
talent is not presented below,
it likely does not affect your Rotation enough to be mentioned. The links
below will default the talent choices to those present in our recommended
talent builds.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

Single Target

AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:232893]]

[[spell:390163]]

[[spell:207407]]

[[spell:227174]]

[[spell:389220]]

[[spell:207739]]

[[spell:389732]]

### Vengeance Demon Hunter Explained

1.1.

#### Core Goals For Vengeance Demon Hunter

Vengeance Demon Hunter, at the most basic level, plays like a very standard builder and spender specialization. Your core rotation centers around building [[spell:204062]] using builders such as [[spell:263642]] or [[spell:258920]] with [[spell:227174]] talented, and then spending them using [[spell:228477]], and [[spell:247454]] when it is available. Both of these spenders deal increased damage depending on the amount of souls you consume with them which rewards good soul management.

Beyond this, Vengeance has a very simple relationship with our longer, offensive cooldowns, such as [[spell:204596]] and [[spell:390163]]. We want to get as much out of these powerful spells as possible during an encounter or dungeon, which you most easily do simply by using them close to as soon as you are able to. While there are tools to amplify some of these abilities, such as [[spell:389220]], the case is almost always that more uses beats out waiting for better uses.

---

1.2.

#### Rotational Goals for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

When you play ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, your goals shift a bit from the baseline version of Vengeance Demon Hunter to make better use of the core mechanic [[spell:442290]]. To activate [[spell:442290]], you want to make sure to maximize your use of builders. This does not necessarily mean to use [[spell:263642]] as soon as a charge is available, but you want to make sure it and other Soul Fragment generators spend as little time as possible without recharging cooldown.

Make sure to use your empower in the correct order, which thanks to the new talent [[spell:1272153]] is to always use [[spell:263642]] first and [[spell:228477]] second, no matter the situation.

Since the main focus of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver lies almost entirely on generating souls it also means that spending them is more of a filler part of your rotation. Due to the large amount of damage amplifiers to [[spell:228477]] and Physical damage in general ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver has slightly less incentive to use the new version of [[spell:247454]], and can choose to hold it to activate [[spell:263648]] defensively if desirable. If you do not need the defensive value it will be worth to press [[spell:247454]] for damage, especially on large target counts.

Some other things to keep in mind is that [[spell:442806]] makes it extremely important to spend as much time as possible auto-attacking any target since it increases the chances you have to generate Soul Fragments.

[[spell:442686]] increases your Haste by 6% and increases the damage of your next [[spell:442294]] by 30%. This buff lasts for 30 seconds and you should have 100% uptime once in combat. If you do not then it is likely a good indicator that you are doing something wrong in your rotation.

---

1.3.

#### Rotational Goals for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator at its core differs slightly in its goals from ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, but in practice it plays very similarly. You generate [[spell:1253304]] through [[spell:263642]], which makes it one of your most important spells, and something you want to strive to keep on cooldown at all times. Once you reach three stacks of [[spell:1253304]] you can spend them to release a burst of damage using [[spell:228477]], or [[spell:247454]] with [[spell:1253391]] talented.

Another core part of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator is the ways it empowers [[spell:187827]], through talents such as [[spell:1256295]], [[spell:1256307]], and [[spell:1256353]]. This makes  [[spell:187827]] into a very powerful cooldown, with a large damage burst tied to it, which also applies to [[spell:187827]] casts you get from your Apex [[spell:1270444]]. These things combined with the cooldown reduction through [[spell:1256353]], which will lower the average cooldown of your normal [[spell:187827]] to somewhere between 60 and 80 seconds.

One important factor is that [[spell:1253304]] Meteors deal Shadowflame damage, which is enhanced by talents such as [[spell:389220]], which means there is a lot of damage to be gained stacking burst of [[spell:1253304]], and casts of [[spell:187827]], with [[spell:204021]] for maximum damage. This means the spec is punished to some degree defensively if you want to deal optimal damage.

### Single-Target Rotation

1.4.

#### Single-Target Rotation for Vengeance Demon Hunter

This priority list describes what spells to use in which priority to maximize damage. As a tank you have to consider the Defensive value of certain cooldowns, and if you need to save one for a brief period of time you simple follow the list without considering that spell.

1. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:442294]] unless you are currently performing an [[spell:442290]] combo already
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:263642]] buffed by [[spell:442290]] as the first ability in the combo
3. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:228477]] buffed by [[spell:442290]] as the second ability in the combo
4. **适用条件：Sigil of Spite（启用）；Aldrachi Reaver（启用）。** Cast [[spell:390163]] on cooldown to activate [[spell:442290]] if [[spell:442294]] is not available
5. **适用条件：Aldrachi Reaver（启用）；Down in Flames（未启用）。** Cast [[spell:204021]]
6. **适用条件：Down in Flames（启用）；Aldrachi Reaver（启用）。** Cast [[spell:204021]] when you are close to reaching two stacks of [[spell:204021]], or you need a defensive for some mechanic
7. **适用条件：Down in Flames（启用）；Annihilator（启用）。** Cast [[spell:204021]] spenders when any of the following criteria are met - <em>Click for Full List</em>
   
   
   - You need [[spell:204021]] defensively
   - You are about to cast [[spell:187827]]
   - You have 3 stacks of [[spell:1253304]]
   - You are about to reach 2 charges of [[spell:204021]]
8. **适用条件：Annihilator（启用）。** [[spell:187827]] unless you currently have 2 or more stacks of
   [[spell:1253304]]
9. **适用条件：Annihilator（启用）。** Cast [[spell:247454]] with 5+ Soul Fragments if you have 3 stacks of [[spell:1253304]]
10. **适用条件：Annihilator（启用）。** Cast [[spell:228477]] with at least 3 Soul Fragments if you have 3 stacks of [[spell:1253304]]
11. Cast [[spell:263642]] if you have 2 charges, or you are about to reach 2 charges
12. **适用条件：Annihilator（启用）。** Cast [[spell:390163]] on cooldown
13. **适用条件：Soul Carver（启用）。** Cast [[spell:207407]] on cooldown
14. **适用条件：Down in Flames（启用）。** Cast [[spell:247454]] on cooldown with at least 5 [[spell:203981]], hold shortly if you plan on using [[spell:204021]] within roughly 5 seconds
15. **适用条件：Aldrachi Reaver（启用）；Fiery Demise（未启用）。** Cast [[spell:247454]] with at least 5 [[spell:203981]]
16. Cast [[spell:258920]] on cooldown
17. Cast [[spell:228477]] if you have 5 or more [[spell:203981]], and [[spell:247454]] is on cooldown
18. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:212084]]
19. **适用条件：Annihilator（启用）。** Cast [[spell:212084]] with 3 or fewer [[spell:203981]]
20. Cast [[spell:204596]], ideally without overcapping Fury
21. Cast [[spell:228477]] with a least 3 or more [[spell:203981]]
22. Cast [[spell:263642]]
23. **适用条件：Felblade（启用）。** Cast [[spell:232893]]
24. Cast [[spell:228477]] with 2 or fewer [[spell:203981]]
25. Cast [[spell:204157]] as a filler or when you are not in range
    of your enemy

### Single-Target Opener

[[spell:204596]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:187827]]

[[spell:189110]]

[[spell:204021]]

[[spell:258920]]

[[spell:390163]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:442294]]

[[spell:263642]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:228477]]

**适用条件：Aldrachi Reaver（启用）；Annihilator（启用）。**

[[spell:263642]]

**适用条件：Annihilator（启用）。**

[[spell:247454]]

**适用条件：Soul Carver（启用）。**

[[spell:207407]]

**适用条件：Annihilator（启用）。**

[[spell:187827]]

**适用条件：Annihilator（启用）；Soul Carver（未启用）。**

[[spell:263642]]

**适用条件：Annihilator（启用）。**

[[spell:263642]]

**适用条件：Annihilator（启用）。**

[[spell:247454]]

**适用条件：Aldrachi Reaver（启用）；Soul Carver（启用）。**

[[spell:247454]]

**适用条件：Annihilator（启用）。**

[[spell:228477]]

1.5.

#### Single-Target Opener for Vengeance Demon Hunter

1. Pre-place [[spell:204596]] 1 second before you pull
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:187827]] and [[spell:189110]]
3. Cast [[spell:204021]]
4. Cast [[spell:258920]]
5. Cast [[spell:390163]]
6. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:442294]]
7. Use [[spell:263642]]
8. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:228477]]
9. **适用条件：Aldrachi Reaver（启用）；Annihilator（启用）。** Use [[spell:263642]]
10. **适用条件：Annihilator（启用）。** Cast [[spell:247454]]
11. **适用条件：Soul Carver（启用）。** Cast [[spell:207407]]
12. **适用条件：Annihilator（启用）。** Cast [[spell:187827]]
13. **适用条件：Annihilator（启用）；Soul Carver（未启用）。** Cast [[spell:263642]]
14. **适用条件：Annihilator（启用）。** Cast [[spell:263642]]
15. **适用条件：Annihilator（启用）。** Cast [[spell:247454]]
16. **适用条件：Aldrachi Reaver（启用）；Soul Carver（启用）。** Cast [[spell:247454]]
17. **适用条件：Annihilator（启用）。** Cast [[spell:228477]]
18. Continue with your rotation

### AoE Rotation

1.6.

#### AoE Rotation for Vengeance Demon Hunter

This priority list describes what spells to use in which priority to maximize damage. As a tank you have to consider the Defensive value of certain cooldowns, and if you need to save one for a brief period of time you simple follow the list without considering that spell.

1. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:442294]] unless you are currently performing an [[spell:442290]] combo already
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:263642]] buffed by [[spell:442290]] as the first ability in the combo
3. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:228477]] buffed by [[spell:442290]] as the second ability in the combo
4. **适用条件：Sigil of Spite（启用）；Aldrachi Reaver（启用）。** Cast [[spell:390163]] on cooldown to activate [[spell:442290]] if [[spell:442294]] is not available
5. **适用条件：Down in Flames（启用）；Aldrachi Reaver（启用）。** Cast [[spell:204021]] when you are close to reaching two stacks of [[spell:204021]], or you need a defensive for some mechanic
6. **适用条件：Aldrachi Reaver（启用）；Down in Flames（未启用）。** Cast [[spell:204021]]
7. **适用条件：Annihilator（启用）。** Cast [[spell:204021]] spenders  when any of the following criteria are met - <em>Click for Full List</em>
   
   
   - You need [[spell:204021]] defensively
   - You are about to cast [[spell:187827]]
   - You have 3 stacks of [[spell:1253304]]
   - You are about to reach 2 charges of [[spell:204021]]
8. **适用条件：Annihilator（启用）。** [[spell:187827]] unless you currently have 2 or more stacks of
   [[spell:1253304]]
9. **适用条件：Annihilator（启用）。** Cast [[spell:247454]] with 5+ Soul Fragments if you have 3 stacks of [[spell:1253304]]
10. **适用条件：Annihilator（启用）。** Cast [[spell:228477]] with at least 3 Soul Fragments if you have 3 stacks of [[spell:1253304]]
11. Cast [[spell:263642]] if you have 2 charges, or you are about to reach 2 charges
12. **适用条件：Soul Carver（启用）。** Cast [[spell:207407]] on cooldown
13. **适用条件：Fallout（启用）。** Cast [[spell:258920]] on cooldown, preferably without overcapping [[spell:203981]] from [[spell:227174]]
14. **适用条件：Fallout（未启用）。** Cast [[spell:258920]] on cooldown
15. **适用条件：Burning Alive（启用）；Fiery Demise（启用）。** Cast [[spell:212084]], ideally with as many enemies affected by [[spell:204021]] as possible
16. **适用条件：Fiery Demise（启用）。** Cast [[spell:247454]] on cooldown with at least 5 [[spell:203981]], hold shortly if you plan on using [[spell:204021]] within roughly 5 seconds
17. **适用条件：Fiery Demise（未启用）。** Cast [[spell:247454]] on cooldown with at least 5 [[spell:203981]]
18. **适用条件：Burning Alive（未启用）；Down in Flames（未启用）。** Cast [[spell:212084]]
19. Cast [[spell:228477]] if you have 5 or more [[spell:203981]], and [[spell:247454]] is on cooldown
20. Cast [[spell:204596]], ideally without overcapping Fury
21. Cast [[spell:228477]] with a least 3 or more [[spell:203981]]
22. Cast [[spell:263642]]
23. **适用条件：Felblade（启用）。** Cast [[spell:232893]]
24. Cast [[spell:228477]] with 2 or fewer [[spell:203981]]
25. Cast [[spell:204157]] as a filler or when you are not in range
    of your enemy

### AoE Opener

[[spell:204596]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:187827]]

[[spell:189110]]

[[spell:204021]]

[[spell:258920]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:390163]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:442294]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:263642]]

**适用条件：Aldrachi Reaver（启用）。**

[[spell:228477]]

**适用条件：Soul Carver（启用）；Aldrachi Reaver（启用）。**

[[spell:207407]]

**适用条件：Soul Carver（启用）；Aldrachi Reaver（启用）。**

[[spell:247454]]

**适用条件：Soul Carver（启用）；Annihilator（启用）。**

[[spell:390163]]

**适用条件：Annihilator（启用）。**

[[spell:263642]]

**适用条件：Annihilator（启用）。**

[[spell:247454]]

**适用条件：Annihilator（启用）；Soul Carver（未启用）。**

[[spell:390163]]

**适用条件：Annihilator（启用）；Felblade（启用）。**

[[spell:232893]]

**适用条件：Soul Carver（启用）；Annihilator（启用）。**

[[spell:207407]]

**适用条件：Annihilator（启用）。**

[[spell:187827]]

**适用条件：Annihilator（启用）；Soul Carver（未启用）。**

[[spell:263642]]

**适用条件：Annihilator（启用）。**

[[spell:247454]]

**适用条件：Annihilator（启用）；Felblade（启用）。**

[[spell:228477]]

1.7.

#### AoE Opener for Vengeance Demon Hunter

1. Pre-place [[spell:204596]] 1 second before pull
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:187827]] and [[spell:189110]]
3. Cast [[spell:204021]]
4. Cast [[spell:258920]]
5. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:390163]]
6. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:442294]]
7. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:263642]]
8. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:228477]]
9. **适用条件：Soul Carver（启用）；Aldrachi Reaver（启用）。** Cast [[spell:207407]]
10. **适用条件：Soul Carver（启用）；Aldrachi Reaver（启用）。** Cast [[spell:247454]]
11. **适用条件：Soul Carver（启用）；Annihilator（启用）。** Cast [[spell:390163]]
12. **适用条件：Annihilator（启用）。** Cast [[spell:263642]]
13. **适用条件：Annihilator（启用）。** Cast [[spell:247454]]
14. **适用条件：Annihilator（启用）；Soul Carver（未启用）。** Cast [[spell:390163]]
15. **适用条件：Annihilator（启用）；Felblade（启用）。** Cast [[spell:232893]]
16. **适用条件：Soul Carver（启用）；Annihilator（启用）。** Cast [[spell:207407]]
17. **适用条件：Annihilator（启用）。** Cast [[spell:187827]]
18. **适用条件：Annihilator（启用）；Soul Carver（未启用）。** Cast [[spell:263642]]
19. **适用条件：Annihilator（启用）。** Cast [[spell:247454]]
20. **适用条件：Annihilator（启用）；Felblade（启用）。** Cast [[spell:228477]]
21. Continue with your rotation

2.

### Midnight Season 2 Tier Set

Season 2 brings a new Tier Set for Vengeance Demon Hunter, which
revolves heavily around our core builder spell [[spell:263642]]. Once again the Tier Set is
a minor damage boost and brings no defensive benefits. It also does not have any significant
rotational impact. This means that you are not incentivized to drop too many
item levels on item slots to get your Tier Set. The bonuses from the Tier Set are:

- [[spell:1296613]] — [[spell:204596]] deals 50% increased
      damage, and [[spell:228477]] extends its duration by 2 seconds on your main target.
- [[spell:1296614]] — [[spell:390163]] and [[spell:258920]]
      deal 100% increased damage to targets afflicted by [[spell:204596]].

3.

### Class and Spec Mechanics Explained

To give more insight into how certain mechanics for Vengeance Demon Hunter
works, and how to get as much out of every part of our kit, we have created this
section for deeper explanations of how certain core parts of Vengeance interacts
with your gameplay at every level so you can further improve when you are playing
Vengeance Demon Hunter.

### Apex Talents

3.1.

#### Apex Talents for Vengeance Demon Hunter

The Vengeance Demon Hunter Apex Talents have two functions, to empower our spenders
in [[spell:228477]] and [[spell:247454]], and to make casting them have a chance
to give us extra uses of [[spell:187827]] with slightly shorter duration.
Below is a list of what each individual point does, followed by a section where we
discuss how it will affect our gameplay.

1. [[spell:1270444]] — Consuming [[spell:204062]]s with
   [[spell:247454]] or [[spell:228477]] have a chance to grant
   [[spell:1270444]], giving a second charge of [[spell:187827]]
   which will last 10 seconds. The chance increases with the amount of [[spell:203981]]
   consumed.
2. [[spell:1270448]] — Two point node. The first point allows
   [[spell:247454]] and [[spell:228477]] to consume an extra
   [[spell:204062]]. Each point further increases the damage bonus from
   consuming [[spell:204062]]s by 5% per [[spell:204062]], for 10% total.
3. [[spell:1270449]] — When a cast of [[spell:247454]] or
   [[spell:228477]] does not grant [[spell:1270444]], you gain 1 stack
   of [[spell:1270547]], granting 1% Agility and a higher chance of activating
   [[spell:1270444]]. The stacks last for 12 seconds and do not refresh
   duration after getting a [[spell:1270444]] proc.

These are all strong effects, and generally recommended in all content forms once
it is available. They have relatively passive, but yet noticeable effects on gameplay,
with [[spell:1270444]] and [[spell:1270449]] giving us extra uptime on
[[spell:187827]] which lets us use defensives for damage more liberally
since we have much higher defensive uptime.

[[spell:1270448]] is also very interesting since it increases the amount
of [[spell:203981]] consumed by our spenders, which in turn increases the
chance for [[spell:1270444]] to activate.

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator the Apex nodes is especially interesting since activating
[[spell:187827]] granted by [[spell:1270444]] still activates
effects like [[spell:1256295]] and [[spell:1256307]]. Making it an
even more potent effect.

### Soul Fragment Management

3.2.

#### Soul Fragment Management

[[spell:203981]] are a core part of Vengeance Demon Hunters kit, being
both our main source of self-healing, as well as fuel for increasing the damage
of our spenders [[spell:228477]] and [[spell:247454]], and core to the
entire design of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver. This section will describe how Soul
Fragments work and some things to consider when playing to make your rotation
smoother.

[[spell:203981]] spawn as small orbs around your character, and will expire
after 30 seconds if not consumed. To consume a Soul Fragment you either have to
absorb them with a spell like [[spell:228477]] or [[spell:247454]], walk
over it manually, or generate enough Soul Fragments such that you go over 6 Soul Fragments.
If you go over 6 Soul Fragments you will automatically consume Soul Fragments until
there is only 6 left, starting with the oldest Soul Fragment, this is often referred
to as "overcapping" Soul Fragments.

At a baseline consuming a [[spell:203981]] will heal you for 6% of the damage
you have taken in the last 5 seconds, or 1% of your maximum Health, whichever number
is largest. One noteworthy caveat is that damage that is not sourced to any particular
enemy, usually referred to as "environmental" damage, does not count to damage you
have taken in the last 5 seconds. This includes things like Fall damage and rarely certain
abilities in Raids and Dungeons, often without any real logic.

In Midnight both our spenders [[spell:228477]] and
[[spell:247454]] deal increased damage based on the amount of Soul Fragments consumed,
up to 2 for [[spell:228477]] and up to 5 for [[spell:247454]], further increased to 3
and 6 respectively if you talent into the second Apex Talent point
[[spell:1270448]]. This means that you ideally always consume the maximum
amount of Soul Fragments when you cast these spells. To make sure of this you generally
want to try and reduce the amount of Soul Fragments you overcap from different sources as 
often as possible **without holding
important rotational abilities and cooldowns**. This might sound more complex
than it necessarily is, usually keeping your builders on cooldown and using
spenders otherwise will usually work out to overcap few souls while buffing your
spenders most of the time.

### Defensives as Offensive Cooldowns

3.3.

#### Defensives as Offensive Cooldowns

Vengeance is somewhat unique in that almost all of our defensive cooldowns
also have strong offensive value tied to them. [[spell:204021]] reduces damage
we take by 40%, while also dealing a fair bit of damage, and buffs Fire damage through the 
[[spell:389220]] talent. This makes it a potent defensive and offensive cooldown,
especially for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator which deals a lot of Fire damage. This means
that you generally want to align it with bursts of Fire damage, while also
maintaining a high spread of defensive uptime alongside our other major defensive
cooldown.

[[spell:187827]] increases your current and maximum health
by 40%, and your Armor by 200% for 15 seconds, or 20 seconds with [[spell:1265818]]
talented. [[spell:1265818]] also increases the damage of several spells
during the duration of [[spell:187827]]. Alongside this it is also
linked to several strong ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator talents, making it an even stronger
cooldown which you want to at least partially align with [[spell:204021]].

One thing to keep in mind with all this is that you need to consider how
aggressive you can be in any one situation. In some situations you might not
expect any high damage bursts for a while, and you can get away with some defensive
overlap for more damage. In other cases you will need to save defensive cooldowns
for dangerous mechanics to survive. Doing this is one of the hardest parts of
playing Vengeance Demon Hunter to its fullest potential and unfortunately it is
not possible to give an easy guide on what situation counts as which, it is
something you will have to pick up with time as you get more and more experience
tanking.

### Voidfall

3.4.

#### Voidfall

[[spell:1253304]] is the new core mechanic for the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator Hero
Specialization and affects the way Vengeance Demon Hunter plays to a certain degree.

The way [[spell:1253304]] works is that you have a 35% chance to get a stack
when you cast [[spell:263642]], and when you reach 3 stacks you can spend those
stacks to drop Meteors that deal damage on all targets near your active target.
As a baseline you drop 1 Meteor per cast of [[spell:228477]], but if you talent
into [[spell:1253391]] both [[spell:228477]] and [[spell:247454]] will
spend all 3 at once.

There is one major part of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator and [[spell:1253304]] management
that you generally need to keep in mind. You can only at most have 3 stacks of
[[spell:1253304]], so whenever you reach 3 stacks you want to spend them
before you use any spell that generates more, either [[spell:263642]] or 
[[spell:187827]] with [[spell:1256295]] talented. This
means that you do not want to use [[spell:187827]] offensively if
you have 2 stacks of [[spell:1253304]], and should instead fish for 3 stacks by
using [[spell:263642]] on cooldown and spending the stacks before using 
[[spell:187827]].

### Infernal Strike

3.5.

#### Infernal Strike

In addition to your Rotation, you can also make use of our movement cooldown
[[spell:189110]] which is off the global cooldown to deal
additional damage. The new talent [[spell:1266497]] also adds a defensive
aspect to [[spell:189110]].It is recommended to always keep at least 1 charge in reserve, however, unless the fight requires no movement whatsoever, in which case you
can use up both charges.

One way you can go about doing this without actually manually pressing
[[spell:189110]] all the time is to create a macro to use it where you are
standing and combining it with [[spell:258920]], since they have a the
same cooldown time, which is linked below.

#### Infernal Strike on Player

```wow-macro
#showtooltip
/cast Immolation Aura
/cast [@player] Infernal Strike
```

4.

### Important Cooldowns for Vengeance Demon Hunter

### [[spell:187827]]

4.1.

#### Metamorphosis

[[spell:187827]] is our strongest defensive cooldown, as well
as our strongest offensive cooldown, especially for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator. This
means that you want to use it as many times as you can, while making sure you
cover important mechanics with defensives. Often this can mean that you use it
close to on cooldown, but holding briefly to align it with a dangerous Boss mechanic
in a Raid encounter, or holding it because the Mythic+ pack is about to die and
you want it for the next set of enemies you are fighting.

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator you want to align at least a portion of
[[spell:187827]] with [[spell:204021]] to maximize damage, which
can mean using [[spell:204021]] 5-10 seconds before [[spell:187827]]
comes off cooldown, which only causes some overlap while still buffing the [[spell:1253304]]
stacks you get from [[spell:1256295]], and the damage burst from 
[[spell:1256307]].

### [[spell:204021]]

4.2.

#### Fiery Brand

[[spell:204021]] works such that you apply a 12 second buff to yourself which
reduces all damage taken by 40%, as well as applying a DoT effect to your target enemy.
This enemy will be affected by [[spell:389220]] and spread the DoT effect
to nearby enemies through [[spell:207739]] if talented. It is still strong
for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, especially in large AoE situations where it will
increase the funnel damage from [[spell:442806]] by 30% making for a significant
burst potential on priority targets paired with [[spell:442718]].

If you play with the [[spell:389732]] talent, you will also have two
charges as a baseline, which means that you can to some extent use one charge
offensively while holding the second charge in case of defensive needs. Juggling
this alongside [[spell:187827]] will also allow far higher spread
of cooldown uptime.

Finding a good balance of using [[spell:389220]] offensively and the damage
reduction part defensively is something you will pick up over time and is a big
part of mastering Vengeance Demon Hunter.

### [[spell:390163]]

4.3.

#### Sigil of Spite

[[spell:390163]] is a fairly straightforward ability, you place it on the
ground and it deals damage to all enemies hit, and spawns 3 Soul Fragments should
you hit at least 1 enemy. And for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator that is all it does.

For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver it is a bit different, since it also activates
[[spell:442294]], as long as you do not have one ready at the moment. This
means you want to use [[spell:390163]] as close to on cooldown as possible,
as long as you make sure you do not have a [[spell:442294]] available.

### Utility Sigils

4.4.

#### Utility Sigils

Vengeance is known for the efficient enemy control it can achieve
through its sigils, with [[spell:202137]], [[spell:207684]], and
[[spell:202138]]. We will go through the use cases for all three in here
as well as some things to keep in mind. All three sigils effects will be 2 seconds
longer if you talent into [[spell:389715]].

[[spell:202137]] will do what the name suggests, any normal enemies hit by
the sigil will be Silenced for 2 seconds, interrupt any spells being cast and preventing
the enemies from starting new casts for the duration. [[spell:202137]] only works
entirely on normal enemies the same level as you, elite enemies of higher levels and
bosses are immune to the Silence effect, however they can still be interrupted if
they are actively casting an interruptible spell.

[[spell:207684]] will Fear all enemies locking them in place for 15 seconds.
It has the same restriction as [[spell:202137]] and only works on normal enemies.
One noteworthy feature of [[spell:207684]] is that if you use it on enemies that
are not in combat with anything, they will ignore any other players that run past them
and only be in combat with you, which means if you use [[spell:58984]] as a Night
Elf, or a [[spell:1246966]] potion your entire group can run past a full pack of enemies and drop combat with them to skip them. Outside of this it can be used to stop
enemies from casting spells briefly, although it risks syncing up enemy auto-attacks
which can be lethal in really hard content.

[[spell:202138]] replaces [[spell:207684]] and has a slightly shorter
cooldown, instead of fearing enemies it will grip all normal enemies hit into the
center of the Sigil and slow them by 70% for 6 seconds. It can be very useful to stack
or slow enemies that either are hard to move or enemies you want to stop from reaching
some area because of a mechanic. One minor risk in harder content is that [[spell:202138]] risks syncing up enemy auto-attacks which can be lethal in really hard content.

5.

### Active Mitigation for Vengeance Demon Hunter

As a Vengeance Demon Hunter, you have one active mitigation ability,
[[spell:203720]].

[[spell:203720]] should be used frequently to avoid and reduce Physical
damage taken, even against simple auto-attacks. Try to generally always keep at
least one of its charges rolling unless you are about to enter a longer period
of downtime with [[spell:204021]] and [[spell:187827]]
on cooldown. During situations like that, you want to use [[spell:203720]] to
bridge the gap.

If you play with the [[spell:218612]] talent you can macro [[spell:203720]]
to a common spell like [[spell:263642]] and maintain full uptime of [[spell:203720]]
with relative ease.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated with opener timelines for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Removed note about bugs since most gameplay altering bugs are fixed.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Sep. 2025:** Updated to make Tier Set bonus baseline and updated numbers for the Combat Assistant.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **17 Jun. 2025:** Updated Talent Switches with recommendations and Mythic+ Split up between Weekly and Pushing Higher Key levels.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5 with a fix to the Mythic+ pre-sets.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, no changes needed.
- **21 Oct. 2024:** Reviewed for patch 11.0.5, no changes needed.
- **09 Sep. 2024:** Reviewed for season 1 of The War Within, no rotational changes have been made.
- **29 Aug. 2024:** Updated rotations and matched talent build buttons to new recommended talent builds.
- **28 Aug. 2024:** Fixed a formatting error.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Updated a line to better reflect current single target priorities
- **31 Jan. 2024:** Fixed minor errors for a couple of spells.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **19 Dec. 2023:** Updated a few rotational nuances.
- **10 Nov. 2023:** Updated so AoE Rotation now shows full rotation.
- **08 Nov. 2023:** Updated Rotation Switches for the Heretic Build.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **19 Jun. 2023:** Updated Tier set interaction.
- **01 May 2023:** Updated with changes to rotation in patch 10.1
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated with minor changes to make things a bit more clear.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **10 Nov. 2022:** Updated with minor changes for Dragonflight Pre-Patch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Vengeance Demon Hunter in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Vengeance Demon Hunter

Welcome to our Gear and BiS Page for Vengeance Demon Hunter for
Midnight season 2. Check this page to learn everything
you need to know about gearing a Vengeance Demon Hunter, including some of the
best Gear from all sources, Raiding, and Mythic+, information on the best Trinkets, Tier 
Sets, and much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the Best in Slot Gear for Vengeance Demon Hunter from all gear sources and assumes all items are available at maximum item level. This list goes for a balance of maximum damage output while leaning into stats that are stronger for us defensively and there are plenty of other combinations which will perform at a similar level.

For pure damage output make sure to [simulate](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) your available gear to figure out what combination will perform best from what you have available. And do keep in mind that if you have an item that is not on this list but that has **higher Item Level**, then that item is almost certainly better defensively.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2 as a Vengeance Demon Hunter, you will want to try and prioritize catalyzing set pieces that give good stats. Defensively this means items with higher item level, Venomcursed effects, or simply items with good stats. In the case of Legs

[[item:268225@JAACAAAG2A]]

have an elevated item level if looted from Mythic

[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

, but the high Mastery rating means you only want to catalyze them if you can get them specifically from Mythic difficulty. Your best items to catalyze for each slot is:

- Helm: [[item:271875@JAAEAAwF2ghN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: [[item:251146@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Chest: Base [[item:281236@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- Hands: [[item:251124@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:268225@JAACAAAG2A]] from Mythic [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) only, otherwise [[item:159313@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)

:::

:::details FAQAre There High-Priority Vault Items?
In Midnight Season 2 there are some changes to the

[Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>)

, namely Heroic

[Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

awards Myth-track 1/6 gear, and Mythic awards 6/6. This means that you can either get loot you would not be able to loot on Myth-track, or save a lot of Crests. It can sometimes mean you can pick items from Bosses and Dungeons who only have a single desireable item, without risking having to spend several Nebulous Voidcores (Bonus rolls) to get a single item. Below are a couple examples of high-value items that can be worth taking over extra Nebulous Voidcores.

- [[item:270165]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) is the only item you want from this boss long term.
- [[item:268209]] and [[item:270173]] from Heroic [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) can be worth it, especially if you already have the other item.
- Any item that is the last you want from that Boss or Dungeon is a valueable pick.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271537@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span>Catalyst Helm from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div>Catalyst Hands from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAwUqghN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span>Catalyst Shoulders from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span>Catalyst Legs from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Feet</th><td>[[item:268247@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span>Catalyst Chest from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270165@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:270930@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243973]]</span></div></td></tr></tbody></table>

### Mythic+

This list contains the Best in Slot Gear for Vengeance Demon Hunter you can loot from Mythic+ dungeons. This list goes for a balance of maximum damage output while leaning into stats that are stronger for us defensively and there are plenty of other combinations which will perform at a similar level.

For pure damage output make sure to [simulate](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) your available gear to figure out what combination will perform best from what you have available. And do keep in mind that if you have an item that is not on this list but that has **higher Item Level**, then that item is almost certainly better defensively.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2 as a Vengeance Demon Hunter, you will want to try and prioritize catalyzing set pieces that give good stats. Defensively this means items with higher item level, Venomcursed effects, or simply items with good stats. Your best items to catalyze for each slot is:

- Helm: [[item:273791@JAACAAgNyA]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Shoulders: [[item:251146@JAACAAgNyA]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Chest: Base [[item:271540@JAACAAgNyA]] or [[item:251226@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Hands: [[item:251124@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs: [[item:159313@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend farming the following dungeons:

- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Drops [[item:251143@JAACAAgNyA]], your best weapon from dungeons, as well as several strong items
- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Drops several good items including a weapon and decent trinket options.
- [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>): Drops items in most slots and is a solid place to grind out items you have yet to upgrade.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271537@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span>Catalyst Helm from <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div>Catalyst Hands from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Neck</th><td>[[item:251173@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span>Catalyst Shoulders from <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271536@JAACAAgNyA]]&#10;&#10;<div><span>Catalyst Legs from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271540@JAACAAgNyA]]&#10;&#10;<div><span>Catalyst Chest from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251143@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:251143@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243973]]</span></div></td></tr></tbody></table>

### Raid

This list contains the Best in Slot Gear for Vengeance Demon Hunter from the Raids available in Season 2. This list goes for a balance ofmaximum damage output while leaning into stats that are stronger for us defensively and there are plenty of other combinations which will perform at a similar level.

For pure damage output make sure to [simulate](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) your available gear to figure out what combination will perform best from what you have available. And do keep in mind that if you have an item that is not on this list but that has **higher Item Level**, then that item is almost certainly better defensively.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2 as a Vengeance Demon Hunter, you will want to try and prioritize catalyzing set pieces that give good stats. Defensively this means items with higher item level, Venomcursed effects, or simply items with good stats. In the case of Legs

[[item:268225@JAACAAAG2A]]

have an elevated item level if looted from Mythic

[Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

, but the high Mastery rating means you only want to catalyze them if you can get them specifically from Mythic difficulty. Your best items to catalyze for each slot is:

- Helm: [[item:271875@JAAEAAwF2ghN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- Shoulders: Base [[item:271535@JAACAAgNyA]]
- Chest: Base [[item:271540@JAACAAgNyA]]
- Hands: Base [[item:271538@JAACAAgNyA]]
- Legs: [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details TipsWhich Raid-Items Do I Want Most?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:268209]] is the strongest weapon available this season, especially from Mythic with elevated item level. Drops from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:271875]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) is a potent head item with a proc that gives Haste at the cost of other stats.
- [[item:268265]] is a Neck item with a strong Critical Strike proc that also drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) and is highly desireable.
- [[item:281215]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) is the strongest passive trinket, and strongest trinket in general.
- [[item:270175]] is our strongest active offensive trinket and drops from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270165]] is our second strongest passive trinket and drops from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271537@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span>Catalyst Helm from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div>Tier token from <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAwUqghN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Waist</th><td>[[item:244573@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span>Tier token from <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span>Catalyst Legs from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Feet</th><td>[[item:268247@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span>Catalyst Chest from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270165@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:281215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243973]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:270930@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a> in <a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">Venomous Abyss</a></span><span>[[item:243973]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Vengeance Demon Hunter

There are a great number of fairly good Trinkets available for Vengeance, and
there are a few different kinds of set-ups that can work for us as a Tank specialization.
For general value stat stick trinkets that offer permanent or high uptime buffs of
stats are generally good offensively while offering consistent defensive value.
For ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator pairing an on-use trinket with [[spell:187827]]
can lead to strong burst damage. And if you want an additional defensive layer you can
choose to use a defensive shield trinket.

Below are a list of trinkets filling these niches ranked based on how strong they are.
Click on our ranking chart here to see if they are worth equipping. Trinkets absent from
the list are generally C-tier or lower in power or cannot be looted on Myth-track.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Vengeance Demon Hunter Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp"/></span> Aldrachi Reaver</th>&#10;<th><span><img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp"/></span> Annihilator</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]]</li>&#10;<li>[[item:280617]]</li>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]]</li>&#10;<li>[[item:280617]]</li>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270160]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:270160]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:159617]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:159617]]</li>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250243]]</li>&#10;<li>[[item:250244]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250243]]</li>&#10;<li>[[item:250244]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:250225]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250259]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250245]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250225]]</li>&#10;<li>[[item:270174]]</li>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:159618]]</li>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:159618]]</li>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls)

Season 2 of Midnight keeps the Nebulous Voidcore system from Season 1 which
  can be used in dungeons or after killing a
  specific raid boss, and lets you gain a guaranteed piece of loot from that dungeon
  or raid boss. The item you get is random, but you can not get a duplicate item
  so using it again in a specific place will give you another chance on the remaining
  items.

These can be obtained once a week from an NPC next to the [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)
  as well as from the Great Vault if you choose to not take an item.

3.1.

#### Recommended Nebulous Voidcore Usage for Vengeance Demon Hunter

The item you want to look for will depend a lot on the gear you already have
available which will change for each individual player. Ideally you make sure you
increase the odds of obtaining good Myth-track items, if possible in slots where
you do not have a Myth-track item yet. Below are the items to try to target, unless
you already have them:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) on Mythic or Heroic for Myth Track [[item:271875]] and [[item:268265]].
2. [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) for Myth Track [[item:268209]].
3. [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) for Myth Track [[item:270165]].
4. Remaining BiS List items or item level upgrades.

:::

3.2.

#### Ascendant Venomstones

[[item:280562]] can be used to upgrade Hero and Myth gear in certain slots
  to higher Item Level, which allows for some additional power. These are ideally used on
  Myth-track items where you do not think you will get at 344 Item Level version from 
  Mythic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) or [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) any time soon.
  The following is the ideal order to upgrade your items:

1. Your Main Hand Weapon takes the highest priority, ideally being a [[item:268209]].
2. All Myth-track Trinkets you frequently use.
3. Your Necklace.
4. Your Off Hand weapon.
5. Any Trinkets you use very infrequently.

4.

### Best Crafted Items for Vengeance Demon Hunter

Crafting is a very useful way of getting access to high Item Level gear, with
the ability to craft a high Item Level gear piece unlocking every other week during the
Season.

Since you will be limited during Season 2 in how many items you can craft it is
worth planning ahead what items can be useful to grab. Generally it is best to
avoid crating in one of the five slots that are occupied by tier items. Below is
a recommended order of crafting items:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Vengeance Crafted Gear Priority**
- [[item:237840]] with [[item:273060]]
- [[item:244573]] with [[item:240167]]
- Any item you do not have on Myth track yet.
- [[item:244576]] with [[item:240167]] to replace the [[item:237840]] when you have
    two better weapons.

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Best Embellishments for Vengeance Demon Hunter

You can use up to two items that are **Embellished**, items with additional
bonus effects that empower your character. These are added to crafted gear by
people who have mastered professions, adding the bonuses to items making them stronger.

Generally, as a tank your best Embellishments are options that grant you extra
stats, since we benefit both offensively and defensively. And as of current tuning the
two best options are:

- [[item:273060]] on a weapon, any weapon works, but [[item:237840]] is
    the only crafted weapon that can be used by both Vengeance and
  Devourer Demon Hunter, so if you ever want to play Devourer it is the recommended option.
- [[item:240167]], ideally on a low budget slot like Wrists, Cloak, or Belt.

5.

### Adding Sockets to Gear

Some items come with natural sockets, mainly Rings and Necklaces, but you can also add sockets
  to Helmets, Belts, and Wrist slot items using the [[item:275707]] which can be purchased
  with 6 tokens from The Great Vault. Since these are only obtainable once a week by not taking
  an item or a Nebulous Voidcore bonus roll you often only want to purchase them if you can upgrade
  an item that you will not replace for the rest of the season.

6.

### Crest Usage

You will be able to upgrade your items via Crests, such as
[Veteran Mistcrest](<https://www.wowhead.com/currency=3443>). Once you have upgraded a slot to a certain item
level, **upgrading other items of that slot to that item level is free**.

When you upgrade with Crests, you should think of it as upgrading **slots** and not items.

Additionally, to speed up gearing, you will generally want to obtain
the highest item-level possible **before** upgrading a given slot,
as this means you will spend fewer Crests on that slot in total.

Below is the slot priority you should upgrade your items in. It is essentially based on "which slot gives the most DPS and survivability if you increase its Item Level".

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Vengeance Demon Hunter Crest Upgrade Priority**
**Weapon (Main hand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

➜

**Rings/Neck**

:::

Note that exceptions are possible, such as special items that have strong additional
effects on top of their normal stat budget like [[item:268265]] or [[item:271875]].

7.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

8.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated with new Patch 12.1.5 gear.
- **26 Aug. 2026:** Updated Trinket tier-list with recent changes to our Mastery.
- **16 Aug. 2026:** Updated with Socket section as well as small changes to Trinket tier-list.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Minor trinket updates.
- **18 Mar. 2026:** Fixed the headers for the BiS lists.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, no changes needed.
- **05 Oct. 2025:** Updated for Patch 11.2.5, Turbo Boost and Puzzling Cartel Chips.
- **05 Sep. 2025:** Updated some incorrect drop locations for items, as well as updating the trinket tier list.
- **05 Aug. 2025:** Minor corrections to the upgrades section.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **17 Jun. 2025:** Updated with changes the DISC belt after buffs to the effects.
- **15 Jun. 2025:** Updated for Patch 11.1.7 with the new DISC belt.
- **12 May 2025:** Updated the trinket tier list and added Mythic+ options to the Cartel Chips.
- **29 Apr. 2025:** Updated with new information about the Puzzling Cartel Chips.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **02 Mar. 2025:** Updated with new information on Cyrce's Circlet.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **20 Dec. 2024:** Updated further to account for the recent buffs to Cyrce's Circlet.
- **17 Dec. 2024:** Updated to account for Cyrce's Circlet buffs.
- **15 Dec. 2024:** Updated with information on Cyrce's Circlet.
- **21 Oct. 2024:** Updated with trinkets for patch 11.0.5.
- **21 Sep. 2024:** Updated Mythic+ trinket list.
- **15 Sep. 2024:** Updated trinket lists after trinket tuning.
- **10 Sep. 2024:** Updated Embellishment recommendations.
- **09 Sep. 2024:** Updated for Season 1 of The War Within.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 with new gear and special items.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6 and fixed a typo.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **19 Dec. 2023:** Reworded a paragraph slightly.
- **27 Nov. 2023:** Changed Embellishment slot and Mythic+ Neck recommendations and specified dungeon for Dawn of the Infinite gear.
- **08 Nov. 2023:** Removed a mention of Undulating Sporecloak.
- **07 Nov. 2023:** Updated after Undulating Sporecloak Nerf.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Restructured and updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated section regarding the Onyx Annulet and added information about the Dawn of the Infinites Megadungeon.
- **19 Jun. 2023:** Updated Embellishments recommendations.
- **10 Jun. 2023:** Updated Onyx Annulet section and added gear for patch 10.1.5.
- **24 May 2023:** Updated Trinket recommendations and added information on Firelands trinkets.
- **01 May 2023:** Changed Trinket recommendation and other gear related changes.
- **20 Mar. 2023:** Added section about the Onyx Annulet.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Jan. 2023:** Updated with Embellishments.
- **11 Dec. 2022:** Updated for Dragonflight season 1 start.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Vengeance Demon Hunter. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Vengeance Demon Hunter Stat Priority

For raiding and Mythic+, the secondary stat priority for Vengeance Demon Hunter
is as follows:

Agility

Haste

Mastery

Versatility

Critical Strike

There are not any set stat numbers to shoot for with any particular stat. To optimize for damage,
it is recommended that you simulate the gear you have available to help figure
out which stats gives you the most damage. Defensively you ideally focus on having
a Haste on most items and then having a relatively good balance of all other stats.

For survivability, you will want to prioritize item level beyond all, with a rough
priority of secondary stats as above while still maintaining a roughly equal
spread of stats. Items with higher item level with no Haste are still almost
always your best items defensively.

FAQHow do simulations work for tanks?

You can currently simulate DPS gains for tanks using similar
rules and with similar results compared to simming damage-dealing specs.
The difference for tanks is that you cannot properly simulate for survivability.
There are several factors and metrics for tanking that make it almost impossible
to accurately simulate survivability. However, often the best result for
dealing damage will be close to the best option defensively.

2. 

## In-Depth Stat Breakdown

**Agility** increases your Attack Power, Dodge chance, and Baseline Armor
of [[spell:203720]], as well as Armor via [[spell:203747]].

**Haste** reduces the global cooldown (until you reach 100% Haste) and
also reduces the cooldown of [[spell:203720]],
[[spell:258920]], [[spell:232893]], and
[[spell:263642]]. Haste scales well, with many of our talents gaining significantly
more value from having higher Soul Fragment generation. It also increases the
rate of your Auto-attacks, which is relevant for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver since
it slightly increases the amount of souls generated by [[spell:442806]].

[[spell:203747]] increases your Attack Power and the amount of
Armor you gain from [[spell:203720]] based on your
Agility. Will increase your Armor by half the amount when [[spell:203720]]
is not active.

**Critical Strike** increases the chance for your damaging abilities to
be twice as effective. Your Critical Strike rating is also converted into Parry
rating. [[spell:1227619]] can not critically heal for twice the amount,
but some other minor self-healing effects can. Critical Strike interacts
with the talent [[spell:390808]] to generate extra Fury from
[[spell:258920]]. Critical Strike scales incredibly well
defensively with flat Parry effects such as [[spell:203720]].

Versatility is a very straightforward stat, increasing the damage and healing
you do, and reducing the damage you take by half that amount. It scales all damage
and healing effects, including from items and effects not related to your character.

FAQIs there any point where you want to drop Item Level on gear?

Going only for gear based on the power of secondary stats is generally not
advised. Instead you often want to prioritize item level, with
some rare exceptions on Ring and Neck items. You can consider using a
Ring or Neck with lower item level if your higher item level alternative has a
very large amount of Mastery, since Mastery is currently very undertuned defensively.
When doing this it is only generally worth dropping down one gear track, a Myth
track neck with a lot of Mastery is still likely to be better defensively than a
Champion track Neck, but you can consider using a Hero track neck with better stats.

2.1. 

### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

FAQIs there any point where you stop stacking stats?

Vengeance Demon Hunter does like a lot of Haste, and a lot of players
prefer the faster-paced gameplay it leads to. However, due to the
stat squish that came with Midnight, and thus the low amount of total stats available
with gear, this means that if you stack Haste past the first point of
diminishing returns, you are probably losing a decent amount of power from lacking
other stats.

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3. 

## Changelog

- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **26 Aug. 2026:** Updated after Mastery buff.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Updated with clarifications and formatting.
- **16 Mar. 2026:** Reviewed for Midnight Season 1 release, no changes needed.
- **26 Feb. 2026:** Updated for Midnight.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **04 Aug. 2025:** Updated for Patch 11.2, Mastery slightly devalued.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7, no changes needed.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, no changes needed.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, no changes needed.
- **21 Oct. 2024:** Reviewed for patch 11.0.5, no changes needed.
- **09 Oct. 2024:** Updated information regarding defensive stat priority and added information about diminishing returns.
- **09 Sep. 2024:** Added some information to Haste description.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Added some information regarding diminishing returns on secondary stats.
- **19 Mar. 2024:** Expanded slightly on a condition for item level differences on gear.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated to reflect changes with changing tier sets in patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Vengeance Demon Hunter, based on your [stat priority](<https://www.icy-veins.com/wow/vengeance-demon-hunter-pve-tank-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Your best combination of gems uses a [[item:240983]]
for your single Thalassian Diamond, and combining it with [[item:240890]]
in all remaining sockets. If you happen to have gear that is very heavy on Haste you
could use [[item:240910]] instead of [[item:240890]]
for slightly better stat balance.

2. 

## Best Enchants and Weapon Augments

In current tuning [[item:243733]] wins compared to other oils and
[[item:237371]] both offensively and defensively.

FAQWhat Weapon Enchant Should I use?

Generally you want to use [[item:243973]] since Haste is
the strongest stats defensively for Vengeance. However, if you happen to be very
heavily invested into Haste on your gear, and close to the diminishing
returns breakpoints of 1320 Haste, you probably want to consider running one or
even two [[item:243971]] or [[item:244000]]
to spread out your stats a bit and gain slightly more offensive and defensive value.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Main Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243973]]</li>&#10;<li>[[item:243971]] (See FAQ note)</li>&#10;<li>[[item:244000]] (See FAQ note)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Off Hand</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243973]]</li>&#10;<li>[[item:243971]] (See FAQ note)</li>&#10;<li>[[item:244000]] (See FAQ note)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Head</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]] (Defense)</li>&#10;<li>[[item:243957]] (Max Damage)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]] (Armor)</li>&#10;<li>[[item:244641]] (Stamina)</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3. 

## Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1. 

### Flask

Midnight flasks come in four variants, one for each secondary stat. Vengeance
prefers [[item:241325]] for Haste, but if you are very
heavy on Haste gear you can choose to use [[item:241326]] for
Critical Strike or [[item:241320]] for Versatility instead.

3.2. 

### Potions

When it comes to Combat potions the strongest option is currently
[[item:241288]] for a massive burst of your highest Secondary Stat,
which is usually going to be Haste, at a small loss of your lowest Secondary Stat.
This makes it a really strong potion for both burst damage and survivability while
it is active.

Midnight season 2 introduces a new Healing potion, [[item:271883]], which
heals for a larger amount than normal Healing potions making it a small upgrade. As a tank it will not
restore a massive amount of your health, but it can still be useful in a pinch.

3.3. 

### Food Buff

There are plenty of food choices available in Midnight, but the food that currently
looks to perform the best is one of the Main Stat Feasts such as [[item:255845]],
and if that is not available you can use [[item:242275]] for yourself.

4. 

## Changelog

- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **23 Mar. 2026:** Removed mention of gathering teas.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Sep. 2025:** Updated with minor spelling fixes.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7, no changes needed.
- **19 May 2025:** Updated with slightly altered Helmet enchants after buffs.
- **21 Apr. 2025:** Updated with new Helmet enchants from Horrific Visions in Patch 11.1.5.
- **24 Feb. 2025:** Updated with best enchants for patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, no changes needed.
- **24 Nov. 2024:** Small update to Weapon Enchants.
- **21 Oct. 2024:** Updated the section with weapon oils/stones.
- **10 Sep. 2024:** Added section on best gem combinations and fixed some minor formatting errors.
- **09 Sep. 2024:** Minor clarification to leg enchants.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated with clarification on which food buff to use when.
- **19 Mar. 2024:** Minor change to recommended potions.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Dec. 2023:** Updated Phial and Healing Potion recommendations.
- **07 Nov. 2023:** Updated with correct Stat Gem.
- **06 Nov. 2023:** Updated with changes for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated section on enchants as well as the section about the Onyx Annulet and Primordial Stones.
- **26 Mar. 2023:** Updated section about the Onyx Annulet and Primordial Stones.
- **20 Mar. 2023:** Added section about the Onyx Annulet and Primordial Stones.
- **08 Mar. 2023:** Updated recommendations for weapon enchants and consumables.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated gems and enchants, and added Augment runes.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Vengeance Demon Hunter in World of Warcraft Patch 12.1.5.

1.

### Vengeance Demon Hunter in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Vengeance Demon Hunter in
Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Vengeance Demon Hunter is a tank that focuses on a balance between
juggling strong defensive spells to mitigate damage while healing back damage
through Soul Fragments generated by your regular rotation. Vengeance is a good Mythic+
Tank due to its strong mobility, good AoE damage profile, and abundance of Crowd
Control spells to control enemy spellcasters.

With changes to the Vengeance talent tree and [[spell:202138]] becoming
    a baseline spell instead of a talent, the best talent build for Mythic+ will
    essentially be the same in all levels of keys, with fewer relevant talent choices.

2.

### Best Mythic+ Talent Builds

### Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator Mythic+ Talents for Vengeance Demon Hunter

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator remains the recommended option in all key levels going
    into Season 2 of Midnight. The damage potential is so much higher that it
    supersedes the funnel damage potential of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver. It offers
    potent damage through [[spell:1253304]] meteors while also reducing the cooldown of
    [[spell:187827]] by a significant amount through [[spell:1256353]].

This build takes the strongest defensive talents available without major offensive
    losses. If you are doing keys you consider very easy, the only major offensive gain
    you can get is from moving [[spell:209258]] to [[spell:207407]]. While our
    tier set buffs both [[spell:204596]], [[spell:390163]], and [[spell:258920]],
    talenting into [[spell:428603]] through to [[spell:343014]] offers less
    total healing and mitigation than putting those talent points into [[spell:207387]].

2.2.

#### Flexible Talents

This talent tree is a general blueprint for Dungeons, and while most dungeons
can be completed with this tree as is, there are going to be cases where you want
to switch a few talents for utility options, especially in the Class Tree. Below
are just a few talents to consider depending on the situation.

- If the dungeon contains mainly Humanoid or Beast enemies, you can use
  [[spell:217832]] as an interrupt of sorts, or to skip certain packs of enemies.
- If there are dangerous magic buffs that need to be purged in the dungeon,
  [[spell:278326]] can be a consideration if your group is lacking options to
  deal with these mechanics.
- [[spell:1266316]] and [[spell:1266496]] are options you can choose to take
  in dungeons that feature a lot of Disease and Curse effects respectively, allowing
  you to remove annoying effects from yourself when casting [[spell:258920]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmBWMjZwMjZGzMzMzYwMzM2YmtxwAAAAAAAAwMzMbAAAAYgZmZmZrtZmZAgBAAAwA"
}
```
:::

:::details 来源计算器编码
```
#FJ-OPSUYflKNVDFJKQQ44OPOyyAHJTFMmm2C0C-oAmnTlQRUVZZabkFOOeuw88QWW6AV4A-AAAA-VWYaKMiMJQYgAA-
```

:::

### Mythic+ Talent Build — ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

2.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver Mythic+ Talents for Vengeance Demon Hunter

Due to dealing a fair bit less damage than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/annihilator.webp>) Annihilator as well as having
larger mitigation gaps due to a longer [[spell:187827]] cooldown,
we do not recommend playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver in most Mythic+ dungeons.

While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver is not recommended, it still offers a fairly
strong damage profile with priority target funnel damage through the 
[[spell:442806]] talent, as well as strong self-healing through its many extra
sources of [[spell:203981]]. Because of this it will still likely manage to perform
relatively decently in Mythic+, and if it is your preferred way to play these are the talents
we recommend.

2.4.

#### Flexible Talents

This talent tree is a general blueprint for Dungeons, and while most dungeons
can be completed with this tree as is, there are going to be cases where you want
to switch a few talents for utility options in the Class Tree especially. Below
are just a few talents to consider depending on the situation.

- If the dungeon contains mainly Humanoid or Beast enemies, you can also use
  [[spell:217832]] as an interrupt of sorts or to skip certain packs of enemies.
- If there are dangerous magic buffs that need to be Purged in the dungeon,
  [[spell:278326]] can be a consideration if your group is lacking options to
  deal with these mechanics.
- [[spell:1266316]] and [[spell:1266496]] are options you can choose to take
  in dungeons that feature a lot of Disease and Curse effects respectively, allowing
  you to remove annoying effects from yourself when casting [[spell:258920]].

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CUkAAAAAAAAAAAAAAAAAAAAAAAAMjZmZMMzkZmBWMjZwMjZGzMzMzYwMzM2YmtxwAAAAwsNDGGLLMhhZmZWAAAAwADAAmZAGAAAAD"
}
```
:::

:::details 来源计算器编码
```
#FJ-OPSUYflKNVDFJKQQ44OPOyyAHJTFMmm2C0C-oAmnTlQRUVabkFOOeuQWw88A56yyWUA-AAAA-GIOg0AEUowgCzC-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts, Stuns and Stops

[[spell:183752]] is your "kick" and your most important bit of utility in
Mythic+, used to stop enemy casts for the benefit of yourself and the rest of
the group. It is **highly recommended** to use a Focus Kick macro for this.

#### Focus Target Interrupt

```wow-macro
#showtooltip Disrupt
/cast [@focus,harm,nodead][] Disrupt
```

This macro will kick your focus target if you have one, mouseover if you have
no Focus target, and your target if you have neither of those.

To quickly set a focus target in hectic scenarios, we also recommend a

Focus Mouseover Macro

/focus [@mouseover]

Make sure that your UI shows your Focus Target's casts clearly so that you
are always able to kick it on cooldown or in coordination with the rest of your
group.

3.2. 

### Stunning and "Stops"

[[spell:202137]] is your best talent for stopping enemy spellcasters,
silencing all enemies hit for 2-4 seconds, depending on talent choices. Able to
stop all nearby casters to allow for regular "kicks" and other tools to come
off cooldown.

[[spell:179057]] is your second-most important utility and is an AoE Stun,
stunning all nearby targets for 2 seconds on a short 45-second cooldown and your
main target for 4 seconds if you talent into [[spell:1266296]].

[[spell:207684]] is a more situational tool that can fear enemies for
up to 15 seconds, depending on your talents. The fear easily breaks from damage and is, therefore, usually mostly a momentary "stop". It can also be used to skip enemy
trash packs by fearing them and using [[spell:58984]] after you and your entire
party has moved past them. Does generally not work on undead targets.

[[spell:202138]] can also be used to momentarily disrupt enemy casters
or reposition enemies with a shorter cooldown to [[spell:207684]] which it
replaces. Due to the short range, the usefulness of stacking enemies
is not very high since if enemies are close enough to be gripped, they are likely
already grouped well enough. It is also worth noting that the risk of syncing up
the auto-attacks of enemies is high by grouping them, which can lead to a very
high spike in damage at once. Therefore, it is advised never to grip enemies on top
of your location and always moving slightly so the enemies spread out a bit as they move
towards you.
This talent is thus a choice you can consider when you need an extra interrupt on
a slightly shorter cooldown than [[spell:207684]], if there are parts of a
dungeon where the grip aspect has a ton of value, or if many enemies are Undead
and immune to the fear from [[spell:207684]].

[[spell:217832]] can be used to trap a enemy Humanoid, Beast, or Demon for a
minute; it can also be used as a weaker version of [[spell:183752]] to stop casts
for a moment. It will break as soon as anyone deals damage to the enemy, so the
duration will be almost zero.

### Other Utility

3.3.

#### Other Utility

[[spell:278326]] can be used to remove a beneficial magic buff on an enemy
every 10 seconds. There are often other specs with better tools for this, and the
amount of times it is useful to have are usually less than the dungeons in the
season pool. However, if there are situations where it is useful, it can be a
worthwhile talent choice.

[[spell:198793]] is a movement tool with a nice side-effect. Using it
removes most debuffs that reduce your movement speed, which sounds limited in use
until you learn how many strong debuffs are also attached to a small slow.
If you have any such dangerous debuffs, you want to clear [[spell:198793]]
is a cheap and convenient tool.

[[spell:1266316]] and [[spell:1266496]] are two new talents on a choice node
which lets you remove Disease or Curse effects from yourself when casting 
[[spell:258920]].

4.

### Dealing with Affixes

This section has Vengeance Demon Hunter-specific tips for dealing with the
various affixes of Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Vengeance Demon Hunter

[[spell:202137]], [[spell:179057]] and [[spell:202138]] are all amazing
for this affix.

### Affix: Pulsar

4.2.

#### Oblivion Affix Management for Vengeance Demon Hunter

Help your party absorb the pulsars by positioning properly. Avoid hitting your
party members with dangerous frontal attacks while trying to help collect them.

### Affix: Devour

4.3.

#### Devour Affix Management for Vengeance Demon Hunter

Your natural healing will generally be able to heal through [[spell:440313]].

### Affix: Voidbound

4.4.

#### Voidbound Affix Management for Vengeance Demon Hunter

Make sure to position enemies with the Void Emmisary so that your party
members can cleave other targets efficiently.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1 release.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Talent trees updated with changes to the final talent gate on the Class talent tree.
- **19 Jan. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, no changes needed.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Aug. 2025:** Minor update to the class tree of the Weekly keys build.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7, no changes needed.
- **29 Apr. 2025:** Updated High Mythic+ build and added Dungeon tips.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, no changes needed.
- **21 Oct. 2024:** Updated for patch 11.0.5.
- **13 Sep. 2024:** Added section for Voidbound affix.
- **09 Sep. 2024:** Prepared for The War Within Season 1.
- **19 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Updated description of Sigil of Silence after changes in Patch 10.2.7.
- **22 Apr. 2024:** Some minor adjustments to spell descriptions for Season 4.
- **19 Mar. 2024:** Fixed a few spell descriptions.
- **27 Jan. 2024:** Added a Utility based build for Mythic+ and descriptions for some optional talent options.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **07 Nov. 2023:** Fixed error in text and a minor Talent error on the Offensive Muthic+ build.
- **06 Nov. 2023:** Updated for Patch 10.2
- **06 Sep. 2023:** Link updated
- **04 Sep. 2023:** Restructured and updated for Patch 10.1.7.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **10 Jun. 2023:** Updated with new build added for Fortified Dungeons.
- **01 May 2023:** Updated for new talents and affix changes in Patch 10.1
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Vengeance Demon Hunter in World of Warcraft Patch 12.1.5.

1.

### Best Macros

1.1.

#### General Macros for Demon Hunters

1.1.1.

##### Focus Interrupt Macro

#### Focus: Disrupt

```wow-macro
#showtooltip Disrupt
/cast [@focus,harm,nodead][] Disrupt
```

This macro will use [[spell:183752]] on your current focus target.

1.1.2.

##### Focus Purge Macro

#### Focus: Purge

```wow-macro
#showtooltip Consume Magic
/cast [@focus,harm,nodead][] Consume Magic
```

This macro will use [[spell:278326]] on your current focus
target.

1.2.

#### Specific Macros for Vengeance Demon Hunters

1.2.1.

##### Demon Spikes Macro

#### Demon Spikes macro

```wow-macro
#showtooltip Fracture
/cast Demon Spikes
/cast Fracture
```

This macro is useful when playing with [[spell:218612]] since you will
virtually guarantee 100% or higher uptime of [[spell:203720]] with it. This
way you can drop a button from your action bars.

1.2.2.

##### Sigil Macro

You should use this macro for your Sigils to remove the need to manually place
the reticle for your sigil spells, instead placing it where your cursor is placed.
You can also change @cursor to @player, which always places the sigil at your feet. 
Only use the macro if you are comfortable with the range of your sigils. You can
replace [[spell:204596]] with any other Sigil spell name to get the same effect.

#### Sigil on Player/Cursor

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Flame
```

1.2.3.

##### Infernal Strike on Immolation Aura Macro

#### Infernal Strike on Immolation Aura

```wow-macro
#showtooltip
/cast Immolation Aura
/cast [@player] Infernal Strike
```

This macro is designed to make the most out of the general damage from
[[spell:189110]], which is off the Global Cooldown and deals a bit of
uncapped damage to all nearby targets. It also makes the most of the new talent
[[spell:1266497]] which gives a shield for 6% of your Maximum Health when
you cast [[spell:189110]]. This macro will keep [[spell:189110]]
on cooldown, giving you a few % extra damage, and roughly 30% of your max health
as a shield every minute, while still keeping one charge of [[spell:189110]]
avaiable for movement should it be needed.

Keep a separate keybind for [[spell:258920]] in case there are parts of
encounters where spending half a second locked into [[spell:189110]] can
be dangerous

1.2.4.

##### Infernal Strike Macro General Macro

This macro for [[spell:189110]] causes you to leap to where your
cursor is placed without the need to click there with the standard reticle, which
makes it faster and less likely to cause gaps in your rotation or let you escape
dangerous situations faster.

#### Infernal Strike Macro

```wow-macro
#showtooltip
/cast [@cursor] Infernal Strike
```

The following version modifies your button so that you can alternate between
the normal @cursor macro that lets you use [[spell:189110]] easier, and
adding a modifier. The modifier makes is so that pressing the button while holding
down Ctrl makes you leap in place to deal damage and get a shield from
[[spell:1266497]].

:::details FAQWhy is the macro not working for me?
The macro effectively binds two keybinds to the same button, and if you have
the modified keybind combination bound then the macro does not work. The solution
is to make sure that if you that ctrl+5 is not bound if you keybind this to 5.

:::

#### Infernal Strike Macro

```wow-macro
#showtooltip
/cast [mod:ctrl, @player] Infernal Strike; [nomod, @cursor] Infernal Strike
```

1.2.5.

##### Blessing of Protection Cancelaura Macro

#### Blessing of Protection Cancelaura

```wow-macro
/cancelaura Blessing of Protection
```

This macro is very useful to have. It allows you to cancel a
[[spell:1022]] that may have been cast on you, allowing you
to resume your attacks. It is also important because, while you are under the
effect of [[spell:1022]], mobs will not attack you and instead will
attack the next person the aggro list (usually your Co-tank in raid or a DPS player).

1.2.6.

##### Mouseover Taunt Macro

#### Mouseover Taunt Macro

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]Torment
```

This macro will use [[spell:185245]] on the target you are currently
mousing over.

2.

### Best Addons

Before you go downloading a bunch of different Addons, we recommend you set up your base UI first.
Blizzard has added a wide variety of improvements to the base UI, and many Addons you may think you
cannot do without, are now available through the standard interface. Once you've set up your UI, we
recommend thinking about which aspects or customization layers you would like to add, and then look for
Addons that do those things, instead of downloading an entire suite's worth of Addons that you may
not even need anymore.

It might even be worth it to see how far you can get without any additional Addons, and
maybe you'll even enjoy not having to spend hours every Patch updating and reconfiguring your UI. Many
Addons are still in development or are specifically aiming to launch with all their options for Midnight launch, so some
of your favorites may not be available just yet.

2.1.

#### ElvUI

ElvUI is a complete replacement for the default User Interface, and you
will often find even the best players in the world use ElvUI for certain customization options. 
ElvUI is extremely user friendly, and takes
very little time to set up and master. It also comes already furnished with
almost everything you need; unit frames, raid frames, minimap, buffs and
debuffs, and much more. You can easily unlock and drag all the components
around so your UI will look exactly the way you want it to. ElvUI is clean,
easy to use, and a great starting point for your UI.

2.2.

#### Boss Mods

Boss Mods are helpful pre-made timers that allow you to keep track of the
noteworthy mechanics in any given encounter. Usually they come equipped with
helpful prompts, visuals, and sounds to ensure you do not miss anything
important.

2.2.1.

##### BigWigs Bossmods

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) is the best
boss mod available currently. It is extremely customizable, allowing you to
change what is displayed on an individual boss level and how boldly you want
each alert customized.

2.2.2.

##### LittleWigs Bossmods

This is really just BigWigs, but for dungeons. It has the same customization
options, and allows you to prepare as best as you can for all mechanics that will
be thrown at you in regular or Mythic+ dungeons.

2.2.3.

##### Deadly Boss Mods

[Deadly Boss
Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) is an alternative to BigWigs, and offers almost the exact same customization options
for keeping track of boss abilities, trash mobs, and combat timers. It is a great tool to help
you focus more on your own character, instead of having to worry about keeping track
of all those pesky boss mechanics!

2.3.

#### Name Plates

Nameplates are essential for allowing you to easily keep track of basic
debuffs and quickly select new targets in combat. While ElvUI nameplates do
come standard with the AddOn, they are a little limited and occasionally buggy.
Listed below are some good alternatives.

2.3.1.

##### Plater Nameplates

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
offers a very high degree of customization and accuracy, although somewhat limited
due to the Addon changes in Midnight. You can still configure the nameplates to enlarge
and change color in certain circumstances, and it might help you keep track of important
buffs and debuffs in a chaotic fight, so you do not get lost in the weeds. Some setup is
required, although it is very simple and straightforward.

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) is
a new Addon developed by [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>),
who is known for many super helpful addons like Auctionator, Baganator, Prat, and many more.
They have now developed a very customizable Nameplate
addon that offers numerous options for debuffs, status colors, icons, textures, and much more.
It is definitely worth checking out, especially if you end up having any issues with Plater for
any reason.

2.4.

#### Details

[Details](<https://www.curseforge.com/wow/addons/details>) is still around
as the #1 Addon to customize damage and healing meters. While it may not offer as many tracking
options as before due to the limits imposed by Blizzard, it is still around and kicking to help you
customize the Blizzard Damage, Healing, and Other metrics pane.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5, no changes needed.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **21 Mar. 2026:** Updated macros and added some explanations.
- **16 Mar. 2026:** Updated with a minor fix for Midnight Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for the Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7, no changes needed.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5, no changes needed.
- **05 Sep. 2025:** Changed some addon recommendations.
- **04 Aug. 2025:** Reviewed for Patch 11.2, no changes needed.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5, no changes needed.
- **24 Feb. 2025:** Corrected the spell mentioned in one of the macro description.
- **15 Dec. 2024:** Removed Reaver's Glaive macro since it is not relevant currently.
- **21 Oct. 2024:** Reviewed for patch 11.0.5, no changes needed.
- **09 Sep. 2024:** Reviewed for Season 1 The War Within, no changes were needed.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** A minor mistake fixed as well as clarification added to a macro.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::
