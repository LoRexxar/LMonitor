## 专精概览

欢迎阅读我们关于魔兽世界12.1.5版本的野性德鲁伊指南。在这里，你将学习如何在团队副本和大秘境中扮演野性德鲁伊：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

野性大秘境资源

[全新！顶级野性天赋构筑](<https://raider.io/specs/feral-druid/talents>)

[顶级野性大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/druid/feral>)

[野性大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=druid--feral>)

[热门野性队伍组合](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=druid--feral>)

1.

### 野性德鲁伊概览

野性是德鲁伊的近战输出专精，在[[spell:768]]中战斗。它专注于强大的物理攻击，同时维持流血效果，并围绕资源管理构建了一种较为沉稳的战斗节奏。

其输出循环比许多其他近战职业更慢，常常会有空置的公共冷却时间。这给了你规划双资源系统的时间——先产生能量，再转化为连击点数。这些连击点数随后被消耗以施加强力的持续伤害流血效果和高伤害终结技。作为德鲁伊，它还会为团队提供[[spell:1126]]增益，提升队伍的全能属性。

1.

### 野性德鲁伊表现分析

和任何专精一样，野性也有其优势和劣势。下面我们将根据一些关键类别对其进行评估。

**优秀的爆发伤害特征**

野性在至暗之夜中的技能库被大幅精简，这见仁见智。尽管如此，配合正确的天赋构筑，它可以打出极具竞争力的单体 <em>和</em> 伤害，即使在较高目标数量下也是如此。它最大的弱点在于缺乏灵活性，常常需要在单体或范围伤害之间做出巨大牺牲以强烈偏向某一方向。虽然[[spell:106951]]和[[spell:391528]]都是强力的2分钟（某些情况下为1分钟）冷却技能，但第2赛季的调整和新套装将部分强度转移到了其他地方。尽管它在正确的情况下表现出色，但这种缺乏灵活性使其在需要多样化伤害特征的内容中处于劣势。

**强力的单体爆发**

虽然野性确实需要专精于纯单体构筑，优化后的
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者构筑目前能打出可观的Boss伤害。问题在于剧毒深渊中的许多Boss都高度侧重顺劈，而这正是野性难以高效应对的。不过，超大的团队副本场地提供了来自[[spell:106898]]的独特优势，再加上德鲁伊在[[spell:1126]]、[[spell:20484]]和[[spell:29166]]方面的常规工具。

**强力的爆发工具与无上限范围伤害**

在大秘境中，野性的缺乏灵活性受到的惩罚略小，使构筑能够达到一个不错的平衡点，从而专注于任何特定波次的需求。虽然它并不出众到能左右整个环境，但在合适的阵容下它可以非常有竞争力。借助[[spell:285381]]的强力无上限范围伤害与[[spell:106951]]、[[spell:391528]]和[[spell:1243807]]中的爆发工具的结合，它在每个重要的波次前通常都有应对手段。最后，它还带来[[spell:1126]]——一个价值极高的团队增益——以及用于战斗复活的[[spell:20484]]。

**多功能工具箱**

野性德鲁伊在至暗之夜中仍然带来了大量较为小众的工具性技能。虽然它们并非 <em>总是</em> 有用，但当需要时往往价值很高。同时拥有[[spell:132469]]和[[spell:102793]] / [[spell:102359]]可以在特定赛季提供独特的群体控制，再加上用于打断的[[spell:99]]。在第2赛季中，剧毒深渊更大的Boss场地和高移动需求也使1分钟冷却的[[spell:106898]]成为非常有吸引力的团队工具。除此之外，它还提供[[spell:29166]]作为治疗者的外部减伤，以及[[spell:1126]]和[[spell:20484]]这两个关键的团队增益。

**强力的主动防御工具**

野性在至暗之夜中配备了一些非常强力的主动防御工具，但它
<em>确实</em> 缺乏保持健康的被动手段。这意味着在应对更困难的战斗时，它 **需要** 你主动出击并制定生存计划。在[[spell:22812]]和[[spell:61336]]之间有可观的减伤可用，若这些尚未就绪，[[spell:5487]]总是有用的。必要时还可以叠加[[spell:319454]]以获得更强的防御。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊还提供了额外的防御工具，并能在[[spell:768]]中使用[[spell:22842]]。

**极高的机动性**

虽然与许多近战专精相比，野性更依赖于传统的移动手段，但它所拥有的机动能力既强大又频繁。[[spell:768]]始终提供被动移动速度加成（同时在变形时移除任何减速或定身效果），而[[spell:106839]]则身兼二职，既是短距离冲锋，也是位移反制手段。配合[[spell:1850]]（或[[spell:252216]]）、[[spell:102401]]以及[[spell:106898]]，野性在应对最严苛的战斗时也几乎不会遇到走位难题。

1.

### 野性 德鲁伊 在 至暗之夜

### **第2赛季**   改动

3.1.

#### 至暗之夜 12.1.5版本内容指南

虽然12.1.5补丁并未对野性本身带来重大改动，但它为玩家带来了全新的终局PvE内容供你深入体验。团队副本可以挑战
[Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 这一全新的单体首领战，以获取强大的战利品，同时
[地下堡](<https://www.icy-veins.com/wow/delves-guide>) 推出了首个超级大秘境迷宫供你探索！请务必查看下方关于这两项新增内容的详细信息。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### 12.1.5版本改动

主要改动将来自基斯提克斯团队副本战斗的新物品。最值得注意的是一个饰品、一个戒指和一件胸甲。此外，你将能够从 10 月 20 日起使用[[item:280562]]升级物品。武器、项链和饰品都可以升级。

3.3.

#### 职业改动

随着12.1.5补丁的发布，野性没有任何改动，不过在第二赛季期间它确实收到了大量在线修正。我们的许多建议与之前保持一致，但一些来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 的新装备已加入我们的装备列表，你可以在我们的 [野性 装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_catform.jpg>) 点击查看上赛季第二赛季的改动
3.4.

#### 第2赛季 野性 热修复

[乌拉特克的诅咒热修复](<https://worldofwarcraft.blizzard.com/en-gb/news/24296142>)

**野性 德鲁伊**

- **10月1日**
  
  
  
  
  - 修复了导致[[spell:391709]]对单个目标触发不正确的问题。
- **9月22日**
  
  
  
  
  - [[spell:440120]]伤害提高15%。
  - [[spell:1270592]]现在使流血伤害提高10%（原为8%）。
- **9月2日**
  
  
  
  
  - [[spell:5221]]、[[spell:22568]]和自动攻击伤害提高10%。
  - 所有技能伤害提高5%。
  - [[spell:1263657]]现在优先选择免疫物理伤害或承受物理伤害低于5%的目标。

虽然在第二赛季期间野性反复获得增益和调整改进，但这些改动都没有真正帮助它在剧毒深渊中翻身，它仍然仅仅因为首领机制设计而苦苦挣扎。在大秘境中，许多这些改动确实帮助提升了它的表现，但主要只是让它跟上其他专精的曲线，而无法脱颖而出或改变构筑。

3.5.

#### 12.1版本 野性 改动

第二赛季的到来为野性带来了大量改动，但大多数是旨在为天赋树内开拓一些选择的小幅调整。虽然在修复其灵活性问题上并未完全成功，但它确实改进了许多原本弱势或被锁死的天赋。

[乌拉特克的诅咒开发笔记](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

**野性 德鲁伊**

<em>开发者笔记：《乌拉特克的诅咒》中野性的更新旨在促进天赋多样性。我们希望撕咬对喜欢它的玩家更强，同时正在调整其他一些天赋使其强度更接近，从而开放更多配装选择。它的大部分AOE伤害来自狂暴凶残，而团本配装不会点出该天赋。为使团本配装更容易点出狂暴凶残，我们将其与残忍利爪在第一层交换了位置。</em>

- 造成的所有伤害提高3%。
- [[spell:385786]]、[[spell:774]]、[[spell:48438]]和[[spell:8936]]的治疗量提高25%。
  
  
  
  
  - <em>注意：这是为了抵消12.1版本中玩家基础生命值的提升。</em>
- [[spell:231063]]和[[spell:391709]]在天赋树上互换了位置。
- [[spell:5221]]和[[spell:213764]]伤害提高10%。
- [[spell:421432]]每点连击点的加成伤害提高至60%（原为50%）。
- [[spell:1244544]]的伤害加成降低至15%（原为20%）。
- [[spell:391347]]的伤害加成提高至20%（原为15%）。
- [[spell:391709]]伤害提高25%。
- [[spell:1244258]]伤害提高30%。
- [[spell:391881]]的基础触发几率降低至4%（原为5%）。
- [[spell:231063]]使[[spell:5221]]和[[spell:213764]]的伤害提高25%（原为20%）。
- [[spell:1244532]]使[[spell:22568]]的伤害提高8%（原为2%），但最多叠加6层（原为10层）。
- [[spell:384665]]使[[spell:22568]]的伤害提高16%（原为12%），在[[spell:5217]]期间额外提高8%（原为12%）。

与第一赛季的玩法相比，变化并不大，之前强势的天赋依然强势。不过，它确实整体提升了伤害，同时在单体目标损失不大的情况下，使顺劈能力的获取变得更加容易。天赋树的中部和底部在强度方面也获得了大量整体改进，根据情况开放了许多选择。

:::

### 至暗之夜改动概述

3.6.

#### 野性 德鲁伊 在 至暗之夜 中的改动

随着至暗之夜的发布，野性发生了一些相当重大的变化，许多之前的核心机制都受到了影响。快照机制尤其被大幅简化，同时需要主动按下的按钮数量也有所减少。虽然有些部分与之前的版本相似，但需要关注的事情确实减少了——无论好坏。由于这些改动对该专精的运作方式影响相当大，改动将在下方分为几个部分进行详细说明。

3.6.1.

##### 循环与天赋改动

野性对快照机制及其与流血效果的关系进行了一些全面的改动。最值得注意的是，[[spell:319439]]已被移除，[[spell:384667]]已被重做，因此 <em>主要的</em> 流血增伤来源变为[[spell:5217]]。这意味着需要管理的减益效果大幅减少，操作起来也更加简单。

此外，天赋树中还进行了一些具体的改动：

- [[spell:106830]]和[[spell:202028]]已从天赋树中移除。
- [[spell:1244258]]已作为高伤害攻击加入，在特定能量阈值时可用。
- [[spell:274837]]已添加了一个后续节点——通过[[spell:1244544]]将其冷却时间缩短至30秒，或通过[[spell:1243807]]将其转化为AOE技能。
- [[spell:391548]]现在将[[spell:102543]]的冷却时间缩短至1分30秒。
- 新增[[spell:1244532]]和[[spell:1244547]]，在AOE中提供来自[[spell:1079]]的加成。

3.6.2.

##### 野性 顶级天赋 - 隐形猎手

至暗之夜中的新职业特色是巅峰天赋，这是强大的四步天赋节点，点出后可获得叠加增益。对于野性，[[spell:1263657]]专注于强化终结技，提高造成伤害并触发额外攻击：

- [[spell:1263657]] — [[spell:22568]]每消耗1点连击点有15%几率根据附近目标触发[[spell:1271863]]或[[spell:1263903]]。如果触发时消耗的连击点少于5点且能量少于50点，伤害会降低。
- [[spell:1263658]]——可投入两个天赋点；通过[[spell:1263657]]触发隐秘攻击时，每点使你造成的所有伤害提高7.5%，每消耗一个连击点就持续1秒。额外攻击会延长持续时间。
- [[spell:1263660]] — 使你造成的所有[[spell:1079]]伤害提高30%。此外，施放[[spell:5217]]会使你接下来的两次产生连击点的攻击触发一次造成最大伤害的隐秘攻击。

整套天赋相当强大，强化了两种构筑核心的终结技。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 特别是荒野追猎者从额外的[[spell:1079]]倍率中获益良多，这也显著提升了两系天赋在AOE中的表现。不过，该效果主要是被动的，通过常规游戏循环触发。

3.6.3.

##### 英雄天赋改动

虽然该专精的核心进行了一些大刀阔斧的改动，但英雄天赋与之前相比仍然非常相似。新增了一些与新天赋选项的整合，但其伤害构成的划分保持不变。以下是改动的简要概述：

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) **利爪德鲁伊 改动 -** <em>点击查看详情</em>
  
  
  
  
  - [[spell:441846]]现在使[[spell:274837]]和[[spell:1244258]]的伤害提高25%。
  - [[spell:441845]]现在使伤害技能提高10%，暴击几率提高5%。
  - [[spell:441835]]现在有20%几率激活（原为25%）。
  - **三个新天赋：** [[spell:1271540]]、[[spell:1271635]]和[[spell:1271839]]。
    
    
    
    
    关于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊提供了额外的[[spell:441583]]获取途径，同时试图通过新天赋保留一些来自流血效果的价值。具体来说，[[spell:441846]]通过同时增强新的[[spell:1244258]]和[[spell:274837]]而变得更具吸引力，但其构建方式与之前基本相同：专注于高伤害的[[spell:22568]]强化。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) **荒野追猎者 改动 -** <em>点击查看详情</em>
  
  
  
  
  - **三个新天赋：** [[spell:1270592]]、[[spell:1270586]]和[[spell:1270565]]。
    
    
    
    
    至于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者，天赋树几乎没有改动，保留了其对流血和持续伤害效果的强烈专注。新天赋通过为[[spell:440120]]增加从[[spell:439531]]触发的被动几率，使其更专注于该技能，但它仍然是一个相当简单的被动天赋树。

3.6.4.

##### 功能性与防御

在功能性和防御方面，野性与《地心之战》相比非常相似，只是失去了[[spell:124974]]。作为交换，[[spell:319454]]被改为一个主动防御工具——在[[spell:5487]]期间使用时，使你的最大生命值提高30%。至暗之夜的功能性工具箱也基本相同，带来了[[spell:132469]]、[[spell:102793]]和[[spell:99]]，同时仍然拥有为治疗者准备的[[spell:29166]]。

1.

### 野性 德鲁伊 游戏基础

虽然之前野性因其重叠的机制而被认为是上手较复杂的专精之一，但至暗之夜大幅降低了部分管理要求。它确实有一些需要适应的独特之处，但其节奏通常足够缓慢，让你有时间思考决策并驾驭其有条不紊的游戏循环。它遵循的三条核心规则是：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mount_jungletiger.jpg>) **管理能量**
  
  
  
  
  野性使用能量，能量通过被动方式再生，或通过[[spell:5217]]等工具主动恢复。能量用于施放如[[spell:5221]]之类的“产生技能”，这些技能积累连击点，用于驱动“终结技”。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_ferociousbite.jpg>) **不要浪费连击点**
  
  
  
  
  积攒到5点后，这些连击点用于施放如[[spell:1079]]和[[spell:22568]]之类的“终结技”。尽量不要提前消耗，但 <em>绝对不要</em> 超过5点而浪费任何连击点。这些是你核心的伤害输出手段。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_ghoulfrenzy.jpg>) **保持流血效果**
  
  
  
  
  管理流血效果是野性的核心，流血效果必须始终保持。[[spell:1822]]是一个产生技能，[[spell:1079]]是一个终结技。规划你的资源循环，以确保这些效果100%时间在线。

这些规则赋予了野性一种更有分寸的游戏感，要求你在确保能始终保持这些持续伤害效果的同时，判断两种资源的流动。随着你逐渐适应这个循环，你将学会判断何时有多余资源可以施放高消耗的[[spell:22568]]而无需担心效果覆盖。虽然各种条件一开始可能让人不知所措，但较慢的节奏和直观的规则创造出一种流畅且富有成就感的游戏风格，一旦你掌握了窍门，这便是野性独有的体验。

1.

### 如何作为一名野性 德鲁伊获取装备

虽然我们始终建议你通过模拟来获得最佳结果，但我们确实提供了专门的野性配装页面。我们目前涵盖了第二赛季装备的推荐，让你在踏入至暗之夜终局内容时能有一个良好的开端。在你获取了一些装备后，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月24日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已确认装备列表，调整武器附魔，强调早期武器制作，并扩展关于理想早期属性散件的常见问题解答。
- **2026年8月24日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 将武器附魔更换为哈希仪式，并扩展了药剂部分。
- **2026年8月19日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 由于阿希尔班圣匣在线修正，添加了关于装备推荐不确定性的免责声明。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026 年 6 月 30 日（本页）：** 已根据6月30日的平衡性在线修正进行更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已根据12.0.7补丁使用全知卷册推荐进行更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月7日（本页面）：** 调整了团队副本表现，以更好地反映当前的专精占比。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 添加了关于至暗之夜中传家宝的说明。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新完整的第1赛季推荐。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已为第1赛季更新——为大秘境增加了茶饮和额外的消耗品。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为第1赛季发布进行更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对第1赛季发布进行审查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为至暗之夜第1赛季的发布进行更新。
- **2026年3月16日（本页面）：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（本页）：** 已为至暗之夜的发布进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 为11.2.7补丁更新。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 为11.2.7补丁更新。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 为11.2.7补丁更新。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 为11.2.7补丁更新。
- **2025年11月30日（本页面）：** 已为11.2.7版本进行更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为11.2.5版本更新，并加入了卡特尔代币推荐。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年9月3日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 在AOE中将急速略微提升至高于全能。
- **2025年9月3日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已更新以强调推荐是基于新套装的。
- **2025年8月28日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 添加了大秘境实用天赋速查表，涵盖各副本中的使用场景。
- **2025年8月16日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 更新了饰品排行榜以涵盖额外的平衡性调整。
- **2025年8月12日（本页）：** 已更新以包含第3赛季的热修增强。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新以纳入D.I.S.C.的热修。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为11.1.7版本更新，加入D.I.S.C.腰带，并为双加里维克斯武器微调了毕业列表。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 为11.1.7补丁更新。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 为11.1.7补丁更新。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为涡轮加速发布确认迪纳尔推荐。
- **2025年5月12日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已根据腐蚀调整进行更新。
- **2025年5月12日（本页）：** 添加了说明以突出更新后的卡特尔代币和腐蚀推荐。
- **2025年4月28日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 添加了各个副本的提示。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对11.1.5版本进行审查，并添加了卡特尔代币部分。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年3月16日（[解放安德迈页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对正式服的Boss和加里维克斯提示进行更新。
- **2025年3月16日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 修正了错误的荒野追猎者单体导入代码。
- **2025年3月3日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 更新了希尔赛的项圈和部分饰品推荐。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新以突出热修后新戒指的强度。
- **2024年12月17日（本页）：** 已更新以突出热修后新戒指的强度。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为11.0.7版本更新，加入希尔赛的项圈。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对11.0.7版本进行审查，修正了利爪德鲁伊天赋树链接并添加了推荐标签。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为11.0.7版本更新，并添加了推荐标签。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为11.0.7版本更新，基础循环部分大幅简化。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对11.0.5版本进行审查，将疯狂女王的敕令移至推荐栏。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对11.0.5版本进行审查。添加了关于愈合变形宏的一些说明。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 已为11.0.5版本更新，将热修单独列为一个部分。
- **2024年9月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** 已更新为所有Boss配上了合适的配装和更新的提示。
- **2024年9月30日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 将默认配装改为荒野追猎者单体，以与天赋页面保持一致。
- **2024年9月30日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 将单体目标推荐更新为荒野追猎者。
- **2024年9月30日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 将单体目标推荐切换为荒野追猎者。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新第1赛季毕业列表。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 添加了关于亵渎尖晶石的说明。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为地心之战第1赛季的发布进行更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为最近的血之爪热修和利爪德鲁伊推荐进行更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为最近的血之爪热修和利爪德鲁伊推荐进行更新。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为最近的血之爪热修进行更新。
- **2024年9月9日（本页）：** 已为最近的血之爪热修进行更新。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/feral-druid-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/feral-druid-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/feral-druid-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月13日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 格式调整，将滑块移近循环部分。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为第4赛季和觉醒装备的发布进行更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为第4赛季发布进行更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对第4赛季进行审查，无玩法改动，但为提高可读性重构了页面。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对第4赛季进行审查，有细微调整但配装无重大变化。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对第4赛季进行审查，有少量天赋变动。
- **2024年4月22日（本页）：** 已为第4赛季发布进行更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对10.2.5版本进行审查，无需更新。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对10.2.5版本进行审查，将烬魄之灰标注为与枯萎之 bark 同等。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5版本进行审查，将食物推荐改为次级食物。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对10.2.5版本进行审查，将推荐改为聚灵，并添加了关于2分钟饰品的说明。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5版本进行审查，将聚灵移至主按钮，并添加了AOE起手切换。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对10.2.5版本进行审查，将聚灵配装移至单体推荐。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对10.2.5版本进行审查，无需更改。
- **2024年1月15日（本页）：** 已为10.2.5版本进行更新。
- **2023年11月10日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为10.2版本重构并更新。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新以移除孢子斗篷推荐，切换了剧毒荆棘/剧毒补丁。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对10.2版本进行审查，对天赋路线进行了微调并切换为聚灵。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 为10.2版本添加了激活宏。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已更新大秘境中心的链接。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为10.2版本更新，并重构了循环工具。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为10.2版本更新，加入新配装。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已为10.2版本天赋变动进行更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为10.1.7版本重构，信息保持不变。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 略微调整措辞，以显示暴击、急速和精通在装备支持下均可达到持平。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已针对10.1.7版本进行审查，将推荐配装改为更侧重撕碎的方案。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本重构。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对10.1.7版本进行审查，部分章节有小幅重构但推荐不变。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对10.1.7版本进行审查，无需更改。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已为10.1.5版本更新，并添加了凶猛凝视。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为10.1.5版本更新，加入大秘境装备，并澄清了制造业部分。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5版本进行审查，关于宝石替代品的小提示。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为10.1.5版本更新，将急速和精通调整为持平。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为10.1.5版本更新，并在配装中添加了凶猛凝视。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5版本进行审查，有细微调整和关于凶猛凝视AOE的说明。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 重新加入了混合配装，重新措辞了部分段落，并强调了凶猛凝视的重要性。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为10.1.5版本更新，包含凶猛凝视。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年5月25日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 添加了关于大灾变时光漫游的部分。
- **2023年5月9日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已更新以纳入饰品变动。
- **2023年5月9日（本页）：** 已更新以突出Boss提示和装备更新。
- **2023年5月4日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已更新以切换为猛击利爪。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为10.1版本和第2赛季的发布更新，加入新的装备推荐。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已为10.1版本更新，加入可用的新附魔。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已根据10.1补丁更新，小幅度调整了天赋方案并添加了新的词缀详情。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已根据10.1补丁更新，包含新的狂暴技能改动和更新后的天赋方案。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已根据10.1补丁更新，包含新的10.1补丁改动和天赋方案选择。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已根据10.1补丁天赋改动更新。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已根据10.1补丁审查，由于新的天赋选项，对天赋方案进行了轻微更新。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已根据10.1补丁审查，无需更改。
- **2023年4月29日（本页）：** 已根据10.1补丁改动更新，添加了新的亮点部分和预期表现。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已根据原始宝石的在线修复更新。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已根据原始宝石的在线修复更新。
- **2023年3月22日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月22日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已根据原始宝石的增益效果更新。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已根据原始宝石的在线修复更新。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/feral-druid-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已根据10.0.7补丁更新，包含熔炉指环推荐。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已根据10.0.7补丁审查并更新。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已根据10.0.7补丁审查并更新。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已为10.0.7补丁更新。
- **2023年1月29日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已更新天赋树路径。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 添加了一些额外的鼠标悬停和天赋宏。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对 10.0.5 补丁进行审阅和更新。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已更新至10.0.5补丁。
- **2023年1月24日（本页）：** 已更新至10.0.5补丁。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已根据巨龙时代第1赛季更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已根据巨龙时代第1赛季更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/feral-druid-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/feral-druid-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/feral-druid-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/feral-druid-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月20日（[9.2版本分析](<https://www.icy-veins.com/wow/feral-druid-patch-9-2-changes-analysis>)):** 已为9.2补丁上线整理完毕。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/feral-druid-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/feral-druid-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年5月17日（[9.1 补丁分析](<https://www.icy-veins.com/wow/feral-druid-patch-9-1-changes-analysis>)):** 页面已创建并包含初始信息。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月3日（[风暴熔渣页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-crucible-of-storms-raid-guide>)):** 已更新每个首领的说明。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019 年 2 月 3 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** 已根据8.1补丁更新，并添加了关于当前信息尚不明确的免责声明。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** 已根据奥迪尔初期版本更新。
- **2018年8月11日（[奥杜尔页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-uldir-raid-guide>)):** 已创建本页（暂时为空），为即将到来的奥迪尔做准备。

显示更多

显示更少

:::

## 练级

在本页，你可以找到我们的野性德鲁伊逐级练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[德鲁伊 升级指南](<https://www.icy-veins.com/wow/druid-leveling-guide>).

1.

### 野性德鲁伊练级指南——适用于至暗之夜

欢迎阅读我们的野性德鲁伊至暗之夜练级指南！本指南将帮助你在升至满级的旅程中，涵盖你应该了解的天赋和技能。

野性德鲁伊机动性极强，在做任务时能快速从一点移动到另一点，具有很大优势。它拥有强大的范围伤害技能组合，而且很早就能使用，但由于其中大部分是持续伤害，你可能需要小心应对，避免被围殴。它同样适合地下城，原因相同，不过如果你以守护身份去当坦克，排队时间可能会更快。

1.1.

#### 升级装备选择

升级时，物品等级总是比单项属性更重要。始终选择物品等级最高的装备。带有速度副属性的物品可以帮助加快你的升级速度，尤其是在长时间室内活动期间。传家宝装备在升级时也很有用，可以让你在升级旅程的大部分时间里忽略大量配装需求。

1.2.

#### 至暗之夜升级实用消耗品

如果你想获得额外助力来度过至暗之夜的练级过程并追赶满级内容，有一些物品和附魔可以帮助你加快进度。

- [[item:191348]] —— 一瓶药水，来自 [巨龙时代](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  死亡后依然存在，提供30分钟的移动速度加成。如果你装备已经不错，重点往往在于各波怪物之间的移动速度，而不是多一点伤害。
- [[item:225592]] —— 一种食物，来自 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)，提供持续1小时的大量移动速度加成，但死亡后会失去。
- [[item:213746]] —— 如果你的装备插槽足够多，就换上这颗阿格里安钻石，配合每种 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)宝石颜色来获得额外速度。
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —— 如果你之前使用的是闪避或吸血附魔，请将所有护甲附魔换成额外的移动速度效果。
- [[item:132516]] —— 练级时经久不衰的选择，在无法骑马的区域总能派上用场，甚至在水面上也能使用。这些 <em>无法</em> 在战斗中激活，并且在受到伤害时会被取消。
- [[item:109076]] —— 如果你不慎被击落下坐骑，或者需要从高处下来但无法使用[[spell:165962]]，这些道具可以减免坠落伤害，非常适合应急。

1.

### 升级天赋

**等级 1–9：**在1到9级时，你还没有激活野性专精，因此前4个等级必须以施法者形态使用[[spell:5176]]和[[spell:8921]]。在5级习得[[spell:768]]后，你可以使用[[spell:5221]]。当你到达7级时，就可以将它产生的连击点数用在[[spell:22568]]上。

**等级 10 起：**

在10级选择野性专精时，你将立即获得[[spell:1822]]和[[spell:1079]]，这是你的核心流血效果。它们分别消耗能量和连击点数施放，应始终保持在目标身上。在单目标时，你的主要连击点数获取技能是[[spell:5221]]，在范围伤害时则是[[spell:213764]]。

只要脱离战斗，你可以在世界任何地方更改天赋。练级期间一定要尝试各种天赋组合，感受游戏的节奏。我们在下面提供了一条兼顾核心机制与复杂度的练级天赋路径示例。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 野性练级 —— 80级起始天赋
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMDzMmZmZmNjtZ2mZmZegZGAAAA2CGGGzMqZMLjZmZMmBAAAAAAGYAAAAkxsMmZAALgZGgFGMAAAmZDA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMDzMmZmZmNjtZ2mZmZegZGAAAA2CGGGzMqZMLjZmZWGzMAAAAAAYgBAAAQzsMLzMzAAWAzMALMYAAAMzGGA"
}
```
:::

:::details 来源计算器编码
```
#nB-fTTOM0NhAl6ErssRkxd02qoIrp9al960z4I-kgfijKOhedEQScNMTLfi220mhdtKBpA-AAAA-YauQIYUQJB5IYA-
```

:::

2.1.

#### 升级用战争模式天赋

在本节中，我们将对最适合练级以及单人/小队PvE内容的PvP天赋进行排名。以下是野性德鲁伊专属PvE天赋的排名。

1. 优先选择[[spell:203224]]，在施加[[spell:1822]]效果时为你的目标提供额外爆发，因为有了这个天赋，你总是从[[spell:5215]]中发起攻击。
2. **等级 30 起：**选择[[spell:202626]]或[[spell:236020]]其中之一。前者在你暴击时提供移动速度并治疗你，后者则通过降低最大生命值来提高[[spell:22568]]的伤害。
3. **等级 40 起：**选择前两项中你没有选的那项，或者[[spell:205673]]。它在你成功打断时降低[[spell:5217]]的冷却时间，有助于更频繁地使用冷却技能。

其他选项更侧重于控制敌人，更偏向于PvP玩法，而非更高效地击杀敌人，因此不推荐。

1.

### 升级循环

为了帮助你了解升级和天赋树进程中的变化，请使用下方的滑块选择你当前的等级。每次升级时，将滑块移动，本节内容也会随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 71 起：**达到71级并解锁英雄天赋后，我们建议使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊以获得[[spell:441583]]。

3.1.

#### 核心概念

随着你升级并填充天赋树，野性将获得额外的工具来探索世界，而不仅仅局限于输出循环。本节内容将随滑块一起逐级增长。

- **记得恢复！** - 每当你在波次之间生命值较低时，可以使用所有职业都有的[[spell:1231418]]技能来快速恢复。
- **等级 1–9：****先升到10级** - 由于野性要到10级才能作为天赋专精解锁，在出现选项之前，你应该使用新手任务中提供的技能。
- **等级 10 起：****别忘了，你是只猫！** - 野性 <em>需要</em>
  [[spell:768]]才能使用其技能，所以要始终保持变形状态！
- **等级 10 起：****但是……也是只熊** - [[spell:5487]]非常耐打，所以如果你陷入 <em>极其</em> 糟糕的处境，就切换形态。
- **等级 10–16：****记住其他变形形态** - [[spell:783]]在户外能显著提高移动速度，所以在区域间移动时切换到它。你甚至可以在不取消形态的情况下与物体互动和采集材料！
- **等级 17–19：****记住其他变形形态** - [[spell:783]]在户外能提高移动速度，所以在区域间移动时切换到它。在水中它会自动切换为[[spell:276012]]。这两种形态甚至都可以在不取消的情况下与物体互动和采集材料！
- **等级 20 起：****记住其他变形形态** - [[spell:783]]在户外能提高移动速度，所以在区域间移动时切换到它。在水中它会自动切换为[[spell:276012]]，在脱离战斗时切换为[[spell:165962]]。所有这些形态甚至都可以在不取消的情况下与物体互动！
- **等级 13 起：****悄悄接近敌人** - 尽量总是从[[spell:5215]]开始战斗，以利用[[spell:390772]]提供的[[spell:1822]]加成。如果你只是想悄悄溜过去，也可以用它来避免战斗！
- **等级 30 起：****利用你的自我治疗** - [[spell:16974]]使[[spell:8936]]在消耗连击点数后变为瞬发，所以当你身处险境时记得利用这一点。

**等级 10 起：**3.2.

#### **等级 10 起：**动态优先级列表

以下是用于追踪该使用哪些技能的优先级列表示例。

1. **等级 1 起：**确保始终处于[[spell:768]]状态。
2. **等级 1 起：**尽可能在对目标发起攻击前进入[[spell:5215]]。
3. **等级 1 起：**从潜行中以[[spell:1822]]起手。
4. **等级 31 起：**对危险的精英怪或大群敌人施放[[spell:106951]]。
5. **等级 59 起：**对危险的精英怪或大群敌人施放[[spell:391528]]。
6. **等级 63 起：**施放[[spell:22568]]**等级 71 起：** / [[spell:441583]]，配合 [[spell:391881]] 触发。
7. **等级 11 起：**冷却完毕即施放[[spell:5217]]。
8. **等级 61 起：**冷却完毕即施放[[spell:1243807]]，尤其是在范围伤害场景中。
9. **等级 59–60：**冷却完毕即施放[[spell:274837]]。
10. **等级 13 起：**在面对多个目标时，以5连击点数施放[[spell:285381]]以施加[[spell:1079]]。
11. **等级 1–12：**如果尚未施加，对高生命值目标以5连击点数施加[[spell:1079]]。
12. **等级 13 起：**在单目标时以5连击点数施加[[spell:1079]]。
13. **等级 1 起：**施放[[spell:22568]]**等级 71 起：** / 在5个连击点时使用[[spell:441583]]。
14. **等级 65 起：**对单个目标冷却完毕即施放[[spell:1244258]]。
15. **等级 1 起：**保持[[spell:1822]]。
16. **等级 1 起：**在面对多个目标时施放[[spell:213764]]来产生连击点数。
17. **等级 1 起：**在面对单个目标时施放[[spell:5221]]来产生连击点数。

**等级 10 起：**3.3.

#### **等级 10 起：**生存工具

**等级 10 起：**野性拥有一些防御手段来应对压倒性的局面，所以如果你身处险境，请记得使用它们：

- **等级 10 起：**[[spell:5487]]是野性的“坦克模式”，所以如果你处于危险境地，这将大幅提升你的防御能力。
- **等级 10–28：**[[spell:22812]]持续时间长且冷却时间短，提供伤害减免。它不仅不占用公共冷却时间，而且可以在任何形态下使用，所以在紧急情况下总是可用的。
- **等级 29 起：**[[spell:22812]]持续时间长且冷却时间短，提供伤害减免。它不仅不占用公共冷却时间，而且可以在任何形态下使用，所以在紧急情况下总是可用的。当情况
  <em>极其</em> 极其危急时，冷却时间长得多的[[spell:61336]]还能提供高达50%的减伤。
- **等级 10–25：**有时候最好的选择就是逃跑，使用[[spell:1850]]冲刺逃离，或者如果你在户外，切换到[[spell:783]]。
- **等级 26–37：**有时候最好的选择就是逃跑，使用[[spell:252216]]冲刺逃离，或者如果你在户外，切换到[[spell:783]]。
- **等级 38 起：**有时候最好的选择就是逃跑，使用[[spell:252216]]或[[spell:106898]]冲刺逃离，或者如果你在户外，切换到[[spell:783]]。
- **等级 15 起：**[[spell:390772]]会使你的[[spell:1822]]在潜行状态下使用时击晕目标4秒，让你在每次开怪时获得先手优势。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 添加了关于至暗之夜中传家宝的说明。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月13日：** 格式调整，将滑块移近循环部分。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更新。
- **2023年11月6日：** 已针对10.2版本进行审查，对天赋路线进行了微调并切换为聚灵。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已为10.1.5版本更新，并添加了凶猛凝视。
- **2023年5月4日：** 已更新以切换为猛击利爪。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月22日：** 已针对10.0.7补丁进行审核。
- **2023年1月29日：** 已更新天赋树路径。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将讲解如何在《魔兽世界》12.1.5版本中轻松游玩野性德鲁伊，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 野性德鲁伊基础

欢迎来到我们的简易模式页面！本部分面向刚接触游戏或职业的玩家，他们没有参与史诗难度团队副本的打算，只想了解该专精的简明玩法，而不需要最优玩法所需的大量优先级细节。

野性乍看之下往往令人生畏，因为它有两种资源和多个需要维持的持续性效果。在至暗之夜中，情况要简单一些，在本页中我们会将其分解为若干步骤，希望能让你更容易掌握。最简单地说，输出循环围绕着三条关键规则构建：

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_chargepositive.jpg>)
  **管理能量**
  
  
  
  
  这会自动恢复，[[spell:5217]]使用时也会为你提供大量能量。将其用于“攒星”法术来产生连击点数。单体目标时用于[[spell:5221]]，AOE时用于[[spell:213764]]。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_ferociousbite.jpg>)
  **不要浪费连击点**
  
  
  
  
  这些由你的“攒星”技能产生，上限为5点。它们用于“终结技”，终结技会消耗你所有的连击点数（以及部分能量）。始终保持[[spell:1079]]，其余情况下使用[[spell:22568]]消耗连击点数。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_ghoulfrenzy.jpg>)
  **保持流血效果**
  
  
  
  
  野性有两个需要全程保持的流血效果。[[spell:1822]]是一个“攒星”技能，很容易保持。[[spell:1079]]是一个“终结技”，需要你规划好有足够的连击点数来刷新它。

学习野性的最佳方法从你的资源开始。了解能量的起伏是最好的基础，因为它决定了整个输出循环的节奏。在此之后，对连击点数节奏的良好感觉会让你更容易进入流血效果的管理，一旦你将它们结合起来，你就拥有了舒适地游玩野性所需的一切！

虽然在本页中我们会以更易于理解的方式分解内容，但推荐的构筑仍将与终局内容中最流行的配置保持一致。有一些变体可以稍微降低操作要求，但适应常见的玩法风格会让你对野性的运作方式有最好的认识。

在至暗之夜第2赛季中，野性在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者中作为单体和顺劈输出，因此是团队副本中的首选。然而在范围输出情况下，
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊更胜一筹，因此用于地下城、大秘境和宝库。

1.

### 野性德鲁伊在至暗之夜中的新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者团队副本构筑

2.1.

#### 野性德鲁伊单体天赋

在团队副本中，野性以 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者的形式游玩，牺牲部分范围输出能力，专注于对单个目标造成尽可能多的伤害。这些构筑围绕持续性伤害效果构建，因此有效地维持流血效果非常重要。由于剧毒深渊的大部分内容都涉及顺劈，我们提供的构筑包含了一些多目标天赋以更好地适应它。

英雄天赋树提供被动加成，因此不会显著改变输出循环。然而，它会游玩[[spell:155580]]，将[[spell:8921]]作为一个额外的持续性伤害效果来维持。它有每2分钟的[[spell:106951]]，每2分钟的[[spell:391528]]，以及每30秒的[[spell:274837]]作为爆发冷却技能。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAgtgZzwYmRNjZZmZmZMmxAAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9Vs8FGJ-kgijBKOfhQST58KFIWaYq22MmQBTbxF-AAAA-BEIcApJ4gRiCmF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊地下城与宝库构筑

2.2.

#### 野性德鲁伊大秘境天赋

由于大秘境更侧重于范围输出，野性切换为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊，因为它在多目标情况下有更好的混合能力。这更侧重于[[spell:22568]]，使用[[spell:285381]]在范围输出中施加[[spell:1079]]并触发[[spell:391709]]。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊还加入了[[spell:441583]]触发效果来进一步强化[[spell:22568]]，同时有[[spell:391881]]触发效果可以应对，以进行瞬发的、免费的撕咬施放。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9lMmHSV-kgijBKOfQST58KFIWaGYq22Mmgpt4aG-AAAA-EMQUYaGMgoQyyB-
```

:::

### 单体与范围输出循环详解

2.3.

#### 新手野性德鲁伊输出循环

进入战斗前，请务必确保执行以下操作：

- **处于猎豹形态中——** [[spell:768]]是施放大多数野性技能所必需的，所以请始终保持变形状态。
- **施放团队增益——** 使用[[spell:1126]]为你的队伍提供精通加成。
- **从潜行开始——** [[spell:5215]]会在你破隐时强化你的第一个[[spell:1822]]。

2.4.

#### 单体输出详解

在单体输出中，野性的核心是平衡其资源，以尽可能少的投入维持完整的[[spell:1079]]覆盖率，从而腾出额外的连击点数来施放[[spell:22568]]。以下是需要记住的一些要点，帮助你入门：

- **消耗能量以产生连击点数**
  
  
  
  
  将能量消耗在攒点技能上以达到5个连击点数，避免溢出。
  
  
  
  
  <em>连击点数生成技能</em> ——[[spell:5221]]、[[spell:1822]]、[[spell:8921]]和[[spell:274837]]。
- **高效消耗连击点数**
  
  
  
  
  <em>始终</em> 确保在达到5个连击点数时使用终结技消耗掉。
  
  
  
  
  <em>优先级</em> ——如果[[spell:1079]]缺失则使用它，否则使用[[spell:22568]]。
- **维持持续性伤害效果**
  
  
  
  
  确保[[spell:1822]]、[[spell:8921]]和[[spell:1079]]始终施加在你的目标上。
  
  
  
  
  如果可能，在[[spell:5217]]期间刷新这些效果以快照该效果。
- **使用冷却技能**
  
  
  
  
  每30秒施放一次[[spell:5217]]，随后施放[[spell:274837]]。
  
  
  
  
  每2分钟施放一次[[spell:106951]]，并与[[spell:391528]]配合使用。

学习野性的最佳方法是将其分解为若干部分。你掌握的资源管理游戏的每个组成部分都会让你更容易适应节奏，并建立起何时刷新的直觉。我们建议按以下步骤进行：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_catform.jpg>) **野性单体输出**
**能量/连击点数管理**

➜

**流血效果覆盖率**

➜

**冷却技能顺序**

:::

2.5.

#### 范围输出详解

在范围输出中，野性使用[[spell:285381]]对所有附近目标施加[[spell:1079]]。这用于通过[[spell:391881]]触发免费的[[spell:22568]]施放，进而激活[[spell:391709]]：

- **消耗能量和连击点数**
  
  
  
  
  使用[[spell:1822]]施加流血效果，否则使用[[spell:213764]]积攒到5个连击点数。
  
  
  
  
  使用[[spell:285381]]终结以维持[[spell:1079]]，将多余的连击点数用于[[spell:22568]]。
- **应对触发效果**
  
  
  
  
  在[[spell:1079]]激活的情况下，立即消耗[[spell:391881]]触发效果。
  
  
  
  
  始终在拥有5个连击点数时施放[[spell:441583]]，同样需要割裂激活。
- **同步你的冷却技能**
  
  
  
  
  每30秒施放一次[[spell:5217]]，每45秒施放一次[[spell:1243807]]。
  
  
  
  
  每分钟施放一次[[spell:391528]]。每2分钟将[[spell:106951]]与之配合使用。

虽然野性在范围输出中遵循类似的原则，但最好在 <em>掌握</em> 单体输出之后再处理范围输出玩法——它遵循相同的基本规则集，只是增加了一些额外的复杂性。我们建议如下：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_druid_catform.jpg>) **野性范围输出**
**资源管理**

➜

**[[spell:285381]]覆盖率**

➜

**应对触发效果**

:::

2.5.1.

##### 巅峰天赋： ![Unseen Predator Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_druid_unseenpredator.jpg>) 顶级捕食者的渴望

所有构筑都会在巅峰天赋[[spell:1263657]]中投入四点，它在使用[[spell:22568]]时触发额外打击。这在整个战斗过程中提供良好的额外伤害并强化你的其他技能，但主要是被动的——除了标准输出循环外，没有重要的操作要求来正确执行它。唯一需要记住的重要事项是，它强化了只在5个连击点数时消耗的目标。

2.5.2.

##### 第2赛季套装

至暗之夜第2赛季引入了 **神秘梦行者之皮**，可在不同的终局内容中获得。它提供以下加成：

- [[spell:1296605]]——当[[spell:106951]]结束时，你在狂暴期间每消耗一个连击点数，就会使你造成的伤害提高10%，持续1秒。
- [[spell:1296606]]——[[spell:106951]]持续时间延长10秒。

虽然这两个加成在游戏中肯定很有影响力，但不需要做任何独特的事情来优化它们。你的[[spell:106951]]持续时间更长，并且有额外的动力来高效地循环使用连击点数，但除此之外，野性的玩法与没有它时仍然相同。

### 生存工具与   **防御法术**

2.6.

#### 野性德鲁伊防御法术

野性可以使用各种不同的主动和被动生存工具，在应对即将到来的伤害时拥有很大的灵活性。

- **[[spell:22812]] -** 提供30%的伤害减免，持续12秒（配合[[spell:449191]]），冷却时间为1分钟。这是野性的常规防御工具，由于冷却时间短，可以大量使用以减少危险攻击造成的伤害。
- **[[spell:61336]] -** 提供60%的伤害减免（配合[[spell:449191]]），持续6秒。这是应对最危险伤害事件的备用防御工具，或者在[[spell:22812]]不可用时使用。
- **[[spell:5487]] -** 激活时提供生命值和护甲的显著提升。虽然在这种形态下你的伤害手段非常有限，但你可以快速切换到该形态而无需任何冷却时间，使你能够在承受致命一击后存活下来，然后再治疗回来。
- **[[spell:319454]] -** 冷却时间为2分钟，如果在[[spell:5487]]期间使用，可使你的最大生命值提高30%，持续20秒。即使你从该形态变形退出，该效果仍会保留，使其成为一个强大的额外防御选项，可以叠加在其他手段之上。
- **[[spell:377847]] -** 当你生命值低于40%时会触发[[spell:22842]]，为你恢复大量生命值。该效果冷却时间为120秒（使用[[spell:1213597]]时为90秒），可以在危急时刻救你一命。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊也可以在[[spell:768]]中施放狂暴回复，效果相同，但需要消耗40点能量，冷却时间为36秒。
- **[[spell:16974]] -** 由连击点消耗技能触发，使你的下一个[[spell:8936]]变为瞬发。可以在空闲的公共冷却时间中使用，以帮助维持自身健康。

### 装备选择与   **属性优先级**

2.7.

#### 野性 德鲁伊属性优先级

野性在至暗之夜中针对不同情况最通用的属性优先级如下。如需了解本页所展示内容的更多信息，请查看我们的主
[属性优先级页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>).

敏捷

精通

急速

暴击

全能

属性优先级会根据不同配装中选择的其他天赋而变化，但总体而言，这套优先级能很好地为你服务。

2.8.

#### 野性 德鲁伊的装备搭配

在至暗之夜第2赛季中搭配装备时，你应尽快优先获取你的套装。但由于角色装备选择众多，最好跳转到我们的主 [装备页面](<https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot>)
以获取关于需要追求哪些装备的更全面解析。

### 暴风雪循环助手

2.9.

#### 暴风雪针对野性 德鲁伊的循环助手

循环助手工具由暴风雪在《地心之战》中推出，有两种模式：第一种会以推荐优先级高亮动作条按钮，第二种则提供单个快捷键，自动按下该列表中优先级最高的技能，但每次施放之间有25%的公共冷却时间惩罚。

如果你刚接触野性并想大致了解其玩法流程，这是一个很好的起点。然而，由于某些限制，它确实会带来一定的性能损失。最重要的是，该工具不会 **非** 使用[[spell:106951]]、种族技能或使用型饰品——如果你使用它，这些都需要你手动施放。这也包括移动、防御和控制技能。

该工具通常能较好地管理持续伤害效果，而且由于野性的空闲时间比平均职业更多，公共冷却时间惩罚也没有其他职业那么严重。不使用冷却技能意味着你需要手动使用这些技能——尤其是在它选择施放[[spell:391528]]之前，但除此之外，它非常适合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 本页提供的利爪德鲁伊配装。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月3日：** 已更新以强调推荐是基于新套装的。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为11.0.7版本更新，基础循环部分大幅简化。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月30日：** 将单体目标推荐切换为荒野追猎者。
- **2024年9月9日：** 已为最近的血之爪热修进行更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查，有少量天赋变动。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已为10.1.5版本更新，包含凶猛凝视。
- **2023年5月1日：** 已根据10.1补丁审查，由于新的天赋选项，对天赋方案进行了轻微更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页，你将了解到魔兽世界12.1.5版本中你的野性 德鲁伊的最佳天赋。我们还提供适用于不同类型内容（如团队副本或大秘境）的默认天赋配装。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 野性 德鲁伊在至暗之夜中的最佳天赋

野性在至暗之夜中保持着类似的英雄天赋选择，但在第2赛季中，两者在输出和伤害构成方面有很大重叠。两者调校得极为接近，并且使用了许多相同天赋。真正区分它们的只有灵活性和防御能力的结合。我们目前根据内容的推荐如下。

- **团队副本/单体目标 -**
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在单体目标上表现接近，并且拥有相似的伤害构成。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在转为少量目标顺劈时更为轻松，这使其更适合剧毒深渊。
- **大秘境/群体伤害 -**
  同样，在群体伤害方面两棵天赋树的伤害也相当接近，不过 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊更能利用[[spell:1244532]]增益，因此牺牲的单体伤害更少。凭借其 <em>稍低的</em> 操作要求以及更好的防御能力，它略胜一筹。

虽然两棵英雄天赋树在输出方式上有所不同，但它们的输出在几乎所有情况下都极为接近。它们也拥有相似的冷却窗口，这意味着两者都可以在大多数内容中使用。
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在引入顺劈时能将部分天赋选择发挥得更充分，这使其在团队副本中占优，因为剧毒深渊中的大多数战斗都涉及多个目标。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊则更容易操作，并且拥有更全面的防御工具，非常适合大秘境。下面我们提供了一些导入代码，如果你想直接进入游戏：

**快速开始导入代码：**

:::talents 团队副本/顺劈 - 荒野追猎者
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAgtgZzwYmRNjZZmZmZMmxAAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA"
}
```
:::

:::talents 群体伤害/大秘境 - 利爪德鲁伊
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::talents 团队副本/单体目标 - 荒野追猎者
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYLY2MMmZUzYWmZmZGjZMAAAAAAMwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB"
}
```
:::

:::talents 地下堡 - 利爪德鲁伊
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZYmxMzMzsZsNz2MmZegZGAAAA2CmNDPgZG1MmlxMzMLjZYAAAAAAMwAAAAoZWmlZmZAALwMzAswgBAAwMbYA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

荒野追猎者

团队副本/顺劈

推荐

团队副本/单体目标

推荐

大秘境/群体伤害

地下堡

利爪德鲁伊

团队副本/单体目标

团队副本/顺劈

大秘境/群体伤害

推荐

地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者团队副本顺劈天赋

由于剧毒深渊中有大量遭遇战具有双目标顺劈或小怪生成的特点，我们为下面这份专门提供了一套顺劈构筑 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者提供了一套更适合这些战斗的专用顺劈配装。与单体目标类似，也有
<em>大量</em> 多种选择可以根据不同战斗进行互换，请查看天赋计算器下方的说明。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者团队副本天赋

在至暗之夜第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者的单体目标表现与
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊非常相似，不过天赋树上的一些互换使其能更好地过渡到少量目标顺劈。这使其 <em>勉强</em> 成为推荐选择，但多目标战斗请参考团队副本顺劈配装。最后，请查看天赋计算器下方的说明，了解可能的互换细节。

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者大秘境天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在第2赛季转为群体伤害时表现更好，专注于对大量敌人施加流血效果。它有
<em>稍低的</em> 更高的操作要求才能发挥最大效果，并且相比而言单体输出稍逊一些 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊相比损失了略多的单体伤害。它完全能够打出高额伤害，唯一有实质性的损失是防御能力。

### 天赋方案 0-3

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者地下堡天赋

虽然略逊于其对应配装， [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 不太适合 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在第2赛季中仍然可以构建一套不错的配装来应对地下堡。尽管持续伤害效果的前置爆发不如其他配装的直接伤害，但它能够打出极强的大范围群体伤害，但其较弱的防御工具会限制你推进路线的激进程度。

### 天赋方案 1-0

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊单体目标团队副本天赋

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊与……不相上下 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者不相上下，这很大程度上要归功于套装提供的额外[[spell:106951]]持续时间。与对应配装类似，其天赋树上有大量价值极为接近的天赋，因此在多目标战斗中我们建议改用提供的团队副本顺劈配装。请查看计算器下方的说明，了解一些选择。

### 天赋方案 1-1

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊顺劈团队副本天赋

由于剧毒深渊中有大量顺劈战斗，我们提供了一套专用配装，以支持目标数量变化更多的战斗。由于野性拥有大量专用工具，许多选择都极为接近，因此你的决定往往取决于战斗风格。请查看天赋计算器下方的额外说明。

### 天赋方案 1-2

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊大秘境天赋

在第2赛季中，虽然伤害差距在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊之间的伤害差距已大幅缩小，但防御差距并未缩小。可用的选择允许在不同目标数量之间更平滑地过渡，使其能够更好地 <em>稍低的</em> 驾驭大秘境环境。由于它也更容易操作且防御更强，它是我们的 **推荐选择**:

### 天赋方案 1-3

1.8.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊地下堡天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在地下堡中 [地下堡](<https://www.icy-veins.com/wow/delves-guide>) 表现尤为出色，这得益于巨大的生存优势和按需群体伤害。再加上其前置爆发和[[spell:441824]]（奖励脱离战斗），你就拥有了一个能应对即使最危险的地下堡中任何情况的职业专精。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMzGzMzMGz2yYZsNjZmHYmBAAAgtgZzwYmRNjZZmZmZMmxAAAAAAwADAAAAAwsNzSzyMLbgZeAgFzgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9Vs8FGJ-kjOifhQST58KFIWaY22w0S5iCYgxkqC-AAAA-BEIcApJ4gRiCmF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYLY2MMmZUzYWmZmZGjZMAAAAAAMwAAAAAAMbzs0sMzyGYmHAYxMYAAMzAgB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9Vs8FGJ-kAjOifhhQST58KFIWa6Y22OOSw0WQ5C-AAAA-BEIcApJ4gRiCmF-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPw2YbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112WUTbl9l8JmqnDS-kgijBKOfQST58KFIWaGYq22Mmgpt4qF-AAAA-BEIeApJ4gRiCmF-
```

:::

### 天赋方案 0-3

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZMDzMzMjZmNjtZ2mZmZMzAAAAwWwsZ4BMzomxsYmZmZZMDDAAAAAgBAAAAAAMbzs1sNzyGYmBYhZYAAMzAgB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QTbl9lMmnyzZ-kjKOgifBedCEcNMQSTXq220mggdNLqA-AAAA-RGUIEMBg4RjGmF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAA2CmNDjZG1MmlZmZmxYGDAAAAAADMAAAAamlZZmZGAwCYmBYhBDAAgZ2wA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9l8FGZL-kAjOifhhQST58KJWa6Y22OOSw0ex6JD-AAAA-QCGokcIYUgp5CB-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPwyYbGzMmZAAAAYLY2MMmZUzYWmZmZGjZMAAAAAAMwAAAAoZWmlZmZAALgZGgFGMAAAmZDD"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUUkqsktx11W8QT7cl9l8FGZL-kjOifQST58KJWaY22Sw0exCMQRwY1QB-AAAA-QCGokcIYUgp5CB-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9lMmHSV-kgijBKOfQST58KFIWaGYq22Mmgpt4aG-AAAA-EMQUYaGMgoQyyB-
```

:::

### 天赋方案 1-3

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjZYmxMzMzsZsNz2MmZegZGAAAA2CmNDPgZG1MmlxMzMLjZYAAAAAAMwAAAAoZWmlZmZAALwMzAswgBAAwMbYA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9l8lnSV-kgijKOfhQST58KFIaeiYq22Sw0WgcND-AAAA-EMQUYaGMgoQyyB-
```

:::

### 天赋方案 0-0

核心构筑与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者单体目标配装类似，但关键互换取决于目标数量和持续时间。可以根据顺劈在特定战斗中的重要性，组合使用这些选择。

- 如果一场战斗中有持续的顺劈机会，[[spell:285381]]和[[spell:391709]]就极为值得，因此它们是[[spell:449537]]和从[[spell:383352]]中取出一点的首选互换对象。
- [[spell:391700]]在持续2目标的战斗中（如双子毒牙）同样强大。
- [[spell:391347]]和[[spell:391881]]能进一步提升顺劈伤害，如果是 <em>重度</em> 群体伤害战斗，可以进一步提升顺劈。
- 上述两者可以与[[spell:1244544]]互换，[[spell:390902]]和[[spell:391548]]则是根据战斗时机选择的其他选项。

### 天赋方案 0-1

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者的单体目标围绕持续伤害效果和流血展开，因此它会选择强化这些效果的天赋。特别是[[spell:391969]]以提高其跳动频率（进而带来更多[[spell:439531]]触发），以及[[spell:155580]]以融入[[spell:8921]]。[[spell:106951]]和[[spell:391528]]组合提供2分钟爆发，[[spell:1263657]]中的四点总是会点满。关于天赋互换选项的说明：

- 野性有大量 <em>大量</em> 天赋，其价值都极为接近。一些选择包括：
  
  
  
  
  - [[spell:390902]]与[[spell:421432]]类似，如果你难以正确管理能量。
  - 如果1分钟爆发更适合，[[spell:391548]]也可以替代上述两者之一。
  - [[spell:449537]]和[[spell:383352]]中的两点都可以逐点舍弃，在上层大门中换为群体伤害，使用[[spell:285381]]、[[spell:391709]]或[[spell:391700]]，按强度排序。
- [[spell:231063]]、[[spell:1280316]]和[[spell:48484]]在中间层 <em>非常</em> 的价值都非常接近。
- [[spell:102543]]的两件套加成较弱，所以虽然有协同效应，但并不值得。

### 天赋方案 0-2

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者需要牺牲更多单体目标中使用的工具来为群体伤害配装，但在第2赛季中这种损失的感觉要小得多。最重要的是，[[spell:285381]]、[[spell:391709]]和[[spell:391700]]全部整合到第一层大门中，为中间层腾出了空间。与单体目标类似，它仍然组合[[spell:106951]]和[[spell:391528]]进行2分钟爆发，但将[[spell:1244544]]换为[[spell:1243807]]。一些额外的天赋说明：

- [[spell:1244547]]是一个选择 <em>前提是你能持续击杀敌人</em>。这依赖于你连续拉怪，并且目标以错开的方式死亡以叠加增益，因此其不稳定性使其无法成为推荐选择。
- 第2赛季中[[spell:1244532]]获得了大幅增强，使其成为在转为AoE时弥补损失的单体伤害的优秀选择。在大约3个目标时就能带来可观的收益，并一直提升到6个目标。
- [[spell:391347]]在第2赛季中也有了显著提升，在高目标数的AoE中表现良好。
- 如果1分钟的冷却时间更为有利，[[spell:390902]]可以替换为[[spell:391548]]。

### 天赋方案 1-0

在单体情况下， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊尽可能选取增强[[spell:22568]]的天赋——尤其是[[spell:421432]]。一个例外是[[spell:391881]]，它会干扰[[spell:441583]]触发的效果强度。该天赋将[[spell:106951]]与[[spell:391528]]组合以实现强大的2分钟爆发，同时选取[[spell:1244544]]以与每次[[spell:5217]]施放同步。额外的天赋说明如下：

- 在天赋树底部，选取[[spell:390902]]是为了使用的便利性。这个 <em>选择很灵活</em>，可以替换为[[spell:391969]]或[[spell:391347]]用于顺劈，[[spell:391548]]用于1分钟爆发，甚至[[spell:1244258]]。
- [[spell:449537]]和[[spell:383352]]中的两点都可以逐点舍弃，在上层大门中换为群体伤害，使用[[spell:285381]]、[[spell:391709]]或[[spell:391700]]，按强度排序。

### 天赋方案 1-1

核心构筑与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊的单体配置，不过它牺牲了[[spell:421432]]以为天赋树底部腾出空间。根据目标数量和它们的活跃频率，某些替换比其他替换更为重要。选择说明如下：

- 如果一场战斗中有持续的顺劈机会，[[spell:285381]]和[[spell:391709]]就极为值得，因此它们是[[spell:449537]]和从[[spell:383352]]中取出一点的首选互换对象。
- [[spell:391700]]在持续2目标的战斗中（如双子毒牙）同样强大。
- [[spell:391347]]和[[spell:391881]]能进一步提升顺劈伤害，如果是 <em>重度</em> 群体伤害战斗，可以进一步提升顺劈。
- 上述两者可以与[[spell:1244544]]互换，[[spell:390902]]和[[spell:391548]]则是根据战斗时机选择的其他选项。

### 天赋方案 1-2

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在第2赛季中保持了相同的构筑目标，但由于上移至顶层天赋门，更容易整合[[spell:285381]]和[[spell:391709]]。[[spell:391700]]和[[spell:207272]]的组合使[[spell:1822]]成为首选的产生连击点技能。[[spell:1244532]]有了显著提升，提供后备的优先目标伤害以弥补在转为AoE时损失的单体伤害。由于选择较多，补充说明如下：

- [[spell:1244547]]是一个选择 <em>前提是你能持续击杀敌人</em>。这依赖于你连续拉怪，并且目标以错开的方式死亡以叠加增益，因此其不稳定性使其无法成为推荐选择。
- [[spell:391347]]在第2赛季中有了显著提升，在高目标数的AoE中表现良好。
- 如果1分钟的冷却时间更为有利，[[spell:390902]]可以替换为[[spell:391548]]。

以上列出的构筑是基于强度和流行度的推荐，涵盖了终局PvE的每个内容领域。每个构筑都有自己需要执行的输出循环、需要掌握的独特方面，以及各自的技巧来在不同的战斗中协助你的团队。

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)中引入，万灵卷册是一个玩家强度系统，通过一系列任务解锁少量的性能增强效果。这些加成与任何装备无关，并且始终在你的角色身上生效。有些提供额外伤害，而另一些则提供一些治疗和额外的防御手段。

下面，我们列出了在完成典籍任务链时解锁的五个符文的推荐：

- **符文1 –** [[spell:1279599]]
- **符文2 –** [[spell:1279603]]
- **符文3 –** [[spell:1287555]]
- **符文4 –** [[spell:1279612]]
- **符文5 –** [[spell:1279614]]

值得注意的是，这些效果之间的差异非常微小。然而，第四个属性增强符文会根据你的装备而变化，因此如果你缺少某种属性，这是一个平衡属性的好地方。由于
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者偏向不同的属性，急速、精通和暴击根据你的装备平衡都可以是不错的选择。

1.

### 巅峰天赋： ![Unseen Predator Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_druid_unseenpredator.jpg>) 顶级捕食者的渴望

野性的顶点天赋[[spell:1263657]]专注于为你的终结技施放增加额外伤害。这进一步激励你正确地循环你的资源，并且目前在所有构筑中都会使用：

- [[spell:1263657]] **第一点 –** [[spell:22568]]每消耗一个连击点有15%的几率根据附近的目标触发[[spell:1271863]]或[[spell:1263903]]。如果触发时消耗的连击点少于5个或能量少于50点，则造成的伤害降低。
- [[spell:1263658]] **第二和第三点 –** 当通过[[spell:1263657]]触发隐秘攻击时，每点使你造成的所有伤害提高7.5%，持续1秒/每个消耗的连击点。额外的攻击会延长持续时间。
- [[spell:1263660]] **第四点 –** 使你造成的所有[[spell:1079]]伤害提高30%。此外，施放[[spell:5217]]会使你接下来的两个产生连击点的攻击以最大强度触发隐秘攻击。

整套效果相当强大，通过额外伤害增强终结技，通过[[spell:1079]]的DoT增幅，以及[[spell:1263658]]提供的后续增益来强化输出。由于该效果主要来自正常游戏过程，它在单体和AoE中都充当纯粹的输出提升，对两者都有普遍的收益 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊.

1.

### 英雄天赋

野性有两个英雄天赋选择，分别倾向于其核心玩法的不同方面，并根据你的选择改变你的游戏目标。这两个英雄天赋是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

该天赋树使你能够使用[[spell:441583]]，它通过自动攻击触发，大幅强化你接下来的[[spell:22568]]。具体机制如下：

- [[spell:441583]]造成AoE伤害，通过你的自动攻击触发和在[[spell:106951]]期间的[[spell:441835]]触发。
- [[spell:441846]]同时提升[[spell:274837]]和[[spell:1244258]]的伤害。

这使得 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊成为更偏向直接伤害的天赋树，专注于[[spell:22568]]和额外的爆发。它还提供更优越的防御收益，提升[[spell:5487]]并让你更容易使用[[spell:22842]]。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者

相反， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在野性的工具包中非常侧重于DoT效果和流血。最重要的是，[[spell:439531]]会在受[[spell:1822]]和[[spell:1079]]影响的目标身上成长，造成流血伤害并增幅你的其他技能。一些具体机制如下：

- [[spell:439868]]鼓励[[spell:155580]]，倾向于更重度的DoT玩法。
- 当对受[[spell:439531]]影响的目标施放[[spell:22568]]时，[[spell:440120]]会造成额外的AoE伤害，为你的终结技提供额外收益。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者由于其对流血和DoT的重度侧重，通常更偏向单体和低顺劈。随着最近的天赋树改动，它更容易进行混合搭配，因此比在至暗之夜中更具多样性。

1.

### PvP天赋（战争模式）

「战争模式」是一个可选功能，启用后可开启开放世界的PvP遭遇，并在激活时提供一些好处：

- 在开放世界中获得使用PvP天赋的权限。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

考虑到战争模式在练级和PvE内容中的好处，它是最大化你练级速度和奖励潜力的一种可选方式。然而，你将使自己暴露在开放世界的PvP中，因此要注意可能干扰你的敌对玩家；这是一个你需要自己决定是否要承担的风险。

通常，选择是为了优化你更快击杀敌人的能力，提高你在推进内容时的节奏。

- [[spell:203224]]可以在施加你的[[spell:1822]]效果时为目标提供额外的爆发伤害，并且在目标之间循环时能带来全面的可观提升。
- [[spell:236020]]为你的[[spell:22568]]提供额外伤害。其价值主要取决于你所遭遇敌人的难度，并且在对抗高血量精英时尤其有价值。
- [[spell:202626]]使你和附近盟友的移动速度提高10%，并使玩家在暴击时恢复3%的最大生命值，冷却时间为8秒。这被动地提供了一些额外的速度和续航。
- [[spell:205673]]使使用[[spell:106839]]成功打断时，[[spell:5217]]、[[spell:106898]]和[[spell:61336]]的冷却时间缩短10秒。这在世界中移动时很有用，同时也提供额外的爆发窗口。
- 在有额外敌人存在的场景中，[[spell:305497]]可以发挥一些作用，使你在被击中时能够反击造成额外伤害。

另一方面，[[spell:213200]]、[[spell:200931]]、[[spell:236012]]、[[spell:203242]]和[[spell:236019]]的PvE用途非常有限，更侧重于战斗中的控制和团队辅助。这些更适合PvP遭遇，因此不建议在开放世界中使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用全知卷册推荐进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月16日：** 修正了错误的荒野追猎者单体导入代码。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为11.0.7版本更新，并添加了推荐标签。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月30日：** 将单体目标推荐更新为荒野追猎者。
- **2024年9月9日：** 已为最近的血之爪热修和利爪德鲁伊推荐进行更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查，有细微调整但配装无重大变化。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，将聚灵配装移至单体推荐。
- **2023年11月6日：** 已为10.2版本更新，加入新配装。
- **2023年9月4日：** 已针对10.1.7版本进行审查，部分章节有小幅重构但推荐不变。
- **2023年7月10日：** 重新加入了混合配装，重新措辞了部分段落，并强调了凶猛凝视的重要性。
- **2023年5月1日：** 已根据10.1补丁更新，包含新的10.1补丁改动和天赋方案选择。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标情况下优化你的野性德鲁伊的输出循环。我们还有关于冷却时间、触发效果等方面的进阶部分，以帮助你最大化你的DPS。我们的所有内容均已更新至《魔兽世界》12.1.5补丁。

1.

### 野性德鲁伊玩法与循环指南

欢迎来到我们的野性德鲁伊指南的循环部分，这里涵盖了你在终局团队副本和大秘境中需要了解的关于野性玩法的一切！

由于野性有两个决定你玩法风格的不同英雄天赋树，以下是我们关于在至暗之夜第2赛季中玩哪个以及在何处使用的快速上手推荐：

- **团队副本/单体目标 -**
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在单体上都很接近，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者更容易转为顺劈。由于这在剧毒深渊中非常常见，因此推荐使用它。
- **大秘境/群体伤害 -**
  同样，在AoE中两棵天赋树的伤害相似，不过 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊更多地利用[[spell:1244532]]来弥补优先目标伤害的损失。它的操作要求也更低，防御更好，因此略胜一筹。

两者皆有 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 在纯数值调整方面，荒野追猎者在第2赛季中从未如此接近。虽然套装有一个 <em>轻微</em>
偏向 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊的[[spell:106951]]窗口，但两棵天赋树的伤害相似。它们的主要区别在于在天赋树的范围内应对不同战斗风格的难易程度，以及实用性上的细微差异。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

团队副本 / 单体目标

大秘境 / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者

团队副本 / 单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境 / AoE

主动天赋

被动天赋

[[spell:391528]]

[[spell:1244544]]

[[spell:1243807]]

[[spell:391881]]

[[spell:155580]]

[[spell:1244258]]

### 单体目标

1.1.

#### 野性德鲁伊单体输出循环

野性德鲁伊在单体情况下围绕其资源经济构建，通过消耗能量产生连击点，然后用强大的终结技消耗它们。这与流血管理一起构成了所有野性构筑的核心。

---

1. 冷却好就施放[[spell:5217]] – <em>点击查看详情</em>
   
   
   
   
   - 尽量在拥有5个连击点时使用，或在能量低于上限50点时使用。
2. 冷却好就施放[[spell:106951]]。始终与[[spell:5217]]同时施放
3. **适用条件：Focused Frenzy（启用）。** 冷却好就施放[[spell:274837]]。始终在[[spell:5217]]期间施放
4. **适用条件：Frantic Frenzy（启用）。** 冷却好就施放[[spell:1243807]]。尽可能在[[spell:5217]]期间施放
5. **适用条件：Chomp（启用）。** 冷却好就施放[[spell:1244258]]。
6. **适用条件：Apex Predator's Craving（启用）。** 在有[[spell:391881]]触发时施放[[spell:22568]]
7. 如果[[spell:1079]]未激活或处于可刷新范围内，用5个连击点施放 – <em>点击查看详情</em>
   
   
   
   
   - 尽可能只在[[spell:5217]]激活时施加/刷新此效果。
8. **适用条件：Convoke the Spirits（启用）。**
   施放 [[spell:391528]]。 **始终** 与[[spell:106951]]和[[spell:5217]]同步 – <em>点击查看详情</em>
   
   
   
   
   - 确保在你的主要目标身上保持[[spell:1079]]。
   - 尽量保持尽可能少的连击点。
9. **适用条件：荒野追猎者（启用）。**
   在有5个连击点且[[spell:1079]]已施加的情况下施放[[spell:22568]] – <em>点击查看详情</em>
   
   
   
   
   - 尽量保留50点以上的能量以触发额外伤害。
10. **适用条件：利爪德鲁伊（启用）。**
    在有5个连击点且[[spell:1079]]已施加的情况下施放[[spell:441583]] / [[spell:22568]] – <em>点击查看详情</em>
    
    
    
    
    - 尽量保留50点以上的能量以触发额外伤害。
11. 如果[[spell:1822]]在你的目标身上未激活或处于可刷新范围内，施放 – <em>点击查看详情</em>
    
    
    
    
    - 如果DoT可以通过[[spell:5217]]快照得到提升，在增益消失前刷新它。
12. **适用条件：Lunar Inspiration（启用）。**
    如果[[spell:8921]]在你的目标身上未激活或处于可刷新范围内，施放 – <em>点击查看详情</em>
    
    
    
    
    - 如果DoT可以通过[[spell:5217]]快照得到提升，在增益消失前刷新它。
13. 施放[[spell:5221]]来产生连击点

---

野性需要你高效地管理你的能量和连击点。虽然浪费一点能量不算太糟，但你的目标应该是避免 <em>任何</em> 浪费连击点，所以要注意[[spell:1280316]]带来的连击点爆发，它可能会改变你的决策树。[[spell:5221]]是你主要的连击点产生技能，你需要确保在[[spell:1822]]和[[spell:1079]]上维持你的流血效果，最好用[[spell:5217]]来强化它们。

1.2.

#### 单体输出循环说明与技巧

**适用条件：利爪德鲁伊（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊，根据你在上方工具中的选择：

**适用条件：荒野追猎者（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者，根据你在上方工具中的选择：

- [[spell:1079]]和[[spell:1822]]应始终维持，在[[spell:5217]]期间进行快照。
- **适用条件：Lunar Inspiration（启用）。** [[spell:8921]]遵循上述相同规则，需使用[[spell:155580]]。
- **适用条件：Convoke the Spirits（未启用）。** [[spell:106951]]应卡冷却施放，与[[spell:5217]]同步。
- **适用条件：Convoke the Spirits（启用）。** [[spell:106951]]卡冷却施放，与[[spell:5217]]同步。 <em>始终</em> 在此增益窗口重叠期间、连击点较低时施放[[spell:391528]]。确保[[spell:1079]]能持续整个引导时间。
- **适用条件：Focused Frenzy（启用）。** [[spell:274837]]应卡冷却施放。配合[[spell:1244544]]，与每一次[[spell:5217]]对齐。
- **适用条件：Frantic Frenzy（启用）。** [[spell:1243807]]应卡冷却施放。这与每第三次[[spell:5217]]对齐，或者可以每分钟保留一次以与[[spell:106951]]对齐，代价是减少使用次数，如果这样能让计时器更利于小怪刷新的话。
- **适用条件：Chomp（启用）。** [[spell:1244258]]每20秒卡冷却使用。尽量在其冷却结束前倾泻能量。
- **适用条件：利爪德鲁伊（启用）。** [[spell:22568]] / [[spell:441583]]应当 <em>总是</em> 在拥有50以上能量时施放以触发加成伤害。
- **适用条件：荒野追猎者（启用）。** [[spell:22568]]应当 <em>总是</em> 在拥有50以上能量时施放以触发加成伤害。
- **适用条件：Apex Predator's Craving（启用）。** [[spell:391881]]应尽快消耗以避免浪费后续触发效果。

---

:::details 常见问题：我何时应该刷新我的流血和持续伤害效果？
只要它们在目标身上未激活，或者它们处于大灾变计时器内且不会覆盖更强的快照。如果

[[spell:5217]]

即将消失，而你能对一个即将到期的持续伤害效果进行快照，请在它到期前这样做。

:::

:::details 常见问题：我是否总是在5连击点时消耗？
是的。

[[spell:1263657]]

强烈鼓励在5连击点时消耗以最大化增益持续时间。始终瞄准在5连击点时消耗，并在使用时拥有50以上能量。

[[spell:22568]]

.

:::

:::details 常见问题：什么是快照？
快照是野性特有的机制，与

[[spell:5217]]

在至暗之夜中的相关。这会导致在增益激活期间施加的持续伤害和流血效果在其整个持续时间内保留伤害加成。你理想情况下应在此窗口内刷新效果，并避免在更强的持续伤害效果到期前覆盖它们。

:::

### 群体伤害

1.3.

#### 野性 德鲁伊 AoE循环

在AoE情况下，野性依赖 <em>大量</em> 天赋树中的特定天赋将单体终结技转化为AoE攻击。[[spell:285381]]提供了一种对多个目标施加[[spell:1079]]的方式，而[[spell:22568]]配合[[spell:391709]]触发溅射伤害。其玩法与单体类似，但有一些额外的事项需要考虑。

---

1. 冷却好就施放[[spell:5217]] – <em>点击查看详情</em>
   
   
   
   
   - 目标是在使用时能量低于上限70点或更多。
2. **适用条件：Apex Predator's Craving（启用）；荒野追猎者（启用）。**
   在有[[spell:391881]]触发时施放[[spell:22568]] – <em>点击查看详情</em>
   
   
   
   
   - 理想情况下在有[[spell:1079]]激活时以触发[[spell:391709]]。
3. **适用条件：Apex Predator's Craving（启用）；利爪德鲁伊（启用）。**
   在有[[spell:391881]]触发时施放[[spell:441583]] / [[spell:22568]] – <em>点击查看详情</em>
   
   
   
   
   - 理想情况下在有[[spell:1079]]激活时以触发[[spell:391709]]。
4. 冷却好就施放[[spell:106951]]。始终与[[spell:5217]]同时施放
5. **适用条件：Frantic Frenzy（启用）。** 冷却好就施放[[spell:1243807]]。尽可能在[[spell:5217]]期间施放
6. **适用条件：Focused Frenzy（启用）。** 冷却好就施放[[spell:274837]]。始终在[[spell:5217]]期间施放
7. 如果未激活或在大灾变范围内，使用5连击点施放[[spell:285381]]
8. **适用条件：Convoke the Spirits（启用）。**
   在[[spell:5217]]激活时施放[[spell:391528]] – <em>点击查看详情</em>
   
   
   
   
   - 在[[spell:106951]]期间、[[spell:5217]]消失前施放此技能，并尽可能使用最少的连击点。
   - 确保 <em>确保</em> 拥有能持续整个引导时间的[[spell:1079]]。
9. **适用条件：利爪德鲁伊（启用）。** 在5连击点、50以上能量且[[spell:1079]]激活时施放[[spell:441583]] / [[spell:22568]]
10. **适用条件：荒野追猎者（启用）。** 在5连击点且[[spell:1079]]激活时施放[[spell:22568]]
11. **适用条件：利爪德鲁伊（启用）。**
    在[[spell:106951]]期间或有[[spell:263725]]触发时施放[[spell:213764]] – <em>点击查看详情</em>
    
    
    
    
    - 在[[spell:106951]]期间优先使用此技能作为产生器是为了钓[[spell:441835]]的触发。
12. 施放[[spell:1822]]，在目标间循环
13. **适用条件：荒野追猎者（启用）；Lunar Inspiration（启用）。** 施放[[spell:8921]]，在目标间循环
14. 施放[[spell:213764]]产生连击点，并对所有目标施加[[spell:1822]]
15. **适用条件：Chomp（启用）。** 能量耗尽时施放[[spell:1244258]]

---

**适用条件：利爪德鲁伊（启用）。** 野性在单体中遵循的许多规则在多目标情况下仍然适用。有了[[spell:391700]]，在目标间循环[[spell:1822]]是你理想的连击点产生方式，而[[spell:213764]]是它已施加到附近敌人后的后备手段。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 然而，利爪德鲁伊在[[spell:106951]]期间优先使用[[spell:213764]]来钓[[spell:441835]]的触发。

**适用条件：荒野追猎者（启用）。** 野性在单体中遵循的许多规则在多目标情况下仍然适用。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者，在目标间循环[[spell:1822]]是你的主要连击点产生方式，利用[[spell:391700]]快速对其施加于多个敌人。[[spell:213764]]则是当你已经设置了[[spell:1822]]后的后备产生器。

1.4.

#### AoE循环说明与提示

**适用条件：利爪德鲁伊（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊，根据你在上方工具中的选择：

**适用条件：荒野追猎者（启用）。** 以下是关于你在游玩时输出循环最重要方面的几个快速说明： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者，根据你在上方工具中的选择：

- [[spell:285381]]应始终选取以在AoE中施加[[spell:1079]]。在所有目标上始终保持。
- **适用条件：利爪德鲁伊（启用）。** 当[[spell:1079]]已施加且拥有5连击点时使用[[spell:22568]]，触发[[spell:391709]]。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊还有不可预测的[[spell:441583]]触发需要管理，保持你的[[spell:1079]]更加重要。
- **适用条件：荒野追猎者（启用）。** 在[[spell:1079]]已施加时，使用5连击点施放[[spell:22568]]，触发[[spell:391709]]。
- **适用条件：Apex Predator's Craving（启用）。** [[spell:391881]]在AoE中触发更频繁，因此快速消耗它们以触发[[spell:391709]]。

---

:::details 常见问题：我在AoE中施放什么终结技？
始终瞄准拥有

[[spell:1079]]

通过施加

[[spell:285381]]

在所有时间。之后，多余资源消耗于

[[spell:22568]]

以触发

[[spell:391709]]

.

:::

:::details 常见问题：我是否总是在5连击点时消耗？
是的。

[[spell:1263657]]

强烈鼓励在5连击点时消耗以最大化增益持续时间。始终瞄准在5连击点时消耗，并在使用时拥有50以上能量。

[[spell:22568]]

.

:::

:::details 常见问题：什么是快照？
快照是野性特有的机制，与

[[spell:5217]]

在至暗之夜中的相关。这会导致在增益激活期间施加的持续伤害和流血效果在其整个持续时间内保留伤害加成。你理想情况下应在此窗口内刷新效果，并避免在更强的持续伤害效果到期前覆盖它们。

:::

### 单体起手

1.5.

#### 野性 德鲁伊 单体起手

野性在至暗之夜中有一个非常快速的单体起手序列，快速建立流血并开始[[spell:106951]]。

---

[[spell:5215]]

潜行

拉怪

[[spell:1822]]

[[spell:5217]]

[[spell:106951]]

[[item:241288]]

**适用条件：Focused Frenzy（启用）。**

**适用条件：Focused Frenzy（启用）。**

[[spell:274837]]

**适用条件：Focused Frenzy（启用）。**

[[item:270175]]

**适用条件：Frantic Frenzy（启用）。**

**适用条件：Frantic Frenzy（启用）。**

[[spell:1243807]]

**适用条件：Frantic Frenzy（启用）。**

[[item:270175]]

[[spell:1079]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:391528]]

---

1. 战斗开始前施放[[spell:5215]]
2. 施放[[spell:5217]]并以[[spell:1822]]开怪
3. 施放[[spell:106951]]
   
   
   
   
   - 使用[[item:241288]]
   - 使用主动饰品，例如[[item:270175]]
4. **适用条件：Frantic Frenzy（未启用）。** 施放[[spell:274837]]
5. **适用条件：Frantic Frenzy（启用）。** 施放[[spell:1243807]]
6. 施放[[spell:1079]]
7. **适用条件：Convoke the Spirits（启用）。** 施放[[spell:391528]]
8. **适用条件：Convoke the Spirits（启用）。** 施放[[spell:22568]]
9. 继续按照正常的技能优先级。

---

**适用条件：Focused Frenzy（启用）；Convoke the Spirits（未启用）。** 在仍在[[spell:5215]]时施放你的[[spell:5217]]，会在开怪时施加最大强度的[[spell:1822]]快照。[[spell:274837]]立即为[[spell:1079]]建立5连击点，让你随后转入常规循环。

**适用条件：Frantic Frenzy（启用）；Convoke the Spirits（未启用）。** 在仍在[[spell:5215]]时施放你的[[spell:5217]]，会在开怪时施加最大强度的[[spell:1822]]快照。[[spell:1243807]]立即为[[spell:1079]]建立5连击点，让你随后转入常规循环。

**适用条件：Convoke the Spirits（启用）；Focused Frenzy（启用）。** 在仍在[[spell:5215]]时施放你的[[spell:5217]]，会在开怪时施加最大强度的[[spell:1822]]快照。[[spell:274837]]立即为[[spell:1079]]建立5连击点，让你能立即施放[[spell:391528]]。

**适用条件：Convoke the Spirits（启用）；Frantic Frenzy（启用）。** 在仍在[[spell:5215]]时施放你的[[spell:5217]]，会在开怪时施加最大强度的[[spell:1822]]快照。[[spell:1243807]]立即为[[spell:1079]]建立5连击点，让你能立即施放[[spell:391528]]。

### AoE起手

1.6.

#### 野性 德鲁伊 AoE起手

野性的AoE起手是灵活的，取决于你想要多快开始冷却。你的首要任务是施放[[spell:285381]]以施加[[spell:1079]]，为[[spell:106951]]做好准备。

---

[[spell:5215]]

参见注释

拉怪

[[spell:1822]]

[[spell:285381]]

[[spell:5217]]

[[item:241288]]

[[spell:106951]]

[[item:270175]]

**适用条件：Focused Frenzy（启用）。**

[[spell:274837]]

**适用条件：Frantic Frenzy（启用）。**

[[spell:1243807]]

**适用条件：利爪德鲁伊（启用）。**

[[spell:441583]]

**适用条件：荒野追猎者（启用）。**

[[spell:22568]]

**适用条件：Convoke the Spirits（启用）。**

[[spell:391528]]

---

1. 战斗开始前施放[[spell:5215]]
   
   
   
   
   - 可选 - 眩晕可能会干扰开怪设置
2. 对不同目标施放[[spell:1822]]直到你达到5连击点
3. 施放[[spell:5217]]并立即[[spell:285381]]
   
   
   
   
   - 使用[[item:241288]]
4. 施放[[spell:106951]]
   
   
   
   
   - 使用主动饰品，例如[[item:270175]]
5. **适用条件：Frantic Frenzy（未启用）。** 施放[[spell:274837]]
6. **适用条件：Frantic Frenzy（启用）。** 施放[[spell:1243807]]
7. **适用条件：荒野追猎者（启用）。** 施放[[spell:22568]]
8. **适用条件：利爪德鲁伊（启用）。** 施放[[spell:441583]]
9. **适用条件：Convoke the Spirits（启用）。** 施放[[spell:391528]]
10. 继续按照正常的技能优先级。

---

**适用条件：Convoke the Spirits（启用）。** <em>始终</em> 确保在进入[[spell:106951]]之前用[[spell:285381]]做好准备，并由你的第一个[[spell:5217]]增益。这些需要激活以确保[[spell:391709]]触发，尤其是在[[spell:391528]]期间。

**适用条件：Convoke the Spirits（未启用）。** <em>始终</em> 确保在进入[[spell:106951]]之前用[[spell:285381]]做好准备，并由你的第一个[[spell:5217]]增益。这些需要激活以确保[[spell:391709]]触发。

1.

### 至暗之夜 第2赛季套装

至暗之夜第2赛季引入了 **神秘梦行者之皮**，可在不同的终局内容中获得。它提供以下加成：

- [[spell:1296605]] — 当[[spell:106951]]结束时，你在狂暴期间每消耗1个连击点数，就会获得持续1秒的10%伤害提高效果。
- [[spell:1296606]] — [[spell:106951]]持续时间延长10秒。

这两个增益都是围绕野性的最大爆发窗口设计的，在延长[[spell:106951]]的同时，还提供了一个次要增益，奖励你在冷却期间进行资源循环。这意味着，虽然它没有引入任何特定的循环变化，但对你充分利用狂暴窗口提出了更高的要求。

<em>注意</em> – [[spell:102543]]则提供同样的10%伤害增益，但持续时间为每消耗1个连击点数0.75秒。这抵消了与套装的大部分额外内置协同，因此在第2赛季中它仍然是较弱的选择。

2.1.

#### 野性 德鲁伊机制详解

在下面的章节中，我们将介绍驱动野性游戏循环的具体机制的细节。它们深入探讨了你的主要冷却技能、循环技能和触发效果的工作原理。这是一个更高级的章节，旨在帮助你更好地理解
<em>为什么</em> 每次按下按钮。

1.

### 职业与专精机制详解

### 连击点数与能量

3.1.

#### 连击点数与能量

野性 德鲁伊的核心循环由其双资源系统决定：能量和连击点数。其中第一个是能量，基础容量为100（可通过某些天赋增加），每秒恢复11点能量（受急速加成）。这用于驱动 <em>每一个技能</em>，包括你的连击点数生成技能和连击点数终结技能。

野性有几种不同的技能来生成连击点数（称为生成技能）：[[spell:5221]]、[[spell:1822]]、[[spell:213764]]、[[spell:8921]]（配合[[spell:155580]]）以及最后的[[spell:274837]]。使用时，这些技能至少生成1个连击点数，如果点出[[spell:159286]]，暴击时还会额外生成一个。

终结技（称为终结技能）会一次性消耗 <em>全部</em> 你的连击点数，并且通常有自身的能量消耗。消耗的连击点数越多，伤害越高（或效果越强），因此始终以5个连击点数为上限来施放。你最常用的终结技能是[[spell:1079]] / [[spell:285381]]来施加强大的持续伤害效果，以及[[spell:22568]]用于直接伤害。

3.2.

#### 能量囤积

由于野性的能量生成缓慢，它经常利用"囤积"能量的概念。在实践中，这意味着保留技能使用直到满足特定条件，积累资源储备，然后消耗以最大化效率。野性的循环中总有自然的空闲时间，所以规划这些时刻而不是被迫进入空窗期通常更好。在使用[[spell:5217]]之前将能量降到最低也是个好主意，以给它生成的能量爆发留出空间。

[[spell:16864]]触发应尽快使用（在5个连击点数以下），以避免覆盖触发效果。有了[[spell:236068]]，这让你可以保留一层充能，为你规划它提供的额外免费生成技能留出一些空间。

### 流血、持续伤害与大流行

3.3.

#### 流血与持续伤害效果

野性应始终确保[[spell:1822]]和[[spell:1079]]的100%覆盖率，并根据你的天赋配置加入额外的持续伤害效果。这是你伤害输出的核心，并创造了野性所围绕的维护型玩法。记住，如果你使用[[spell:391969]]，以下所有效果的持续时间都会缩短25%！

- [[spell:1079]] — 消耗20点能量，但持续时间取决于你施放时使用的连击点数。目标是使用5个以获得最佳能量效率，这样持续时间为24秒。
- [[spell:1822]] — 消耗35点能量施加，持续15秒。按循环施放。
- [[spell:8921]] <em>（配合[[spell:155580]]）</em> — 消耗40点能量，持续18秒。按循环施放。

3.4.

#### 何时刷新流血效果和增益

野性受益于 <em>大流行</em> 效果对其持续伤害的作用，允许你提前最多30%刷新特定的持续伤害效果，并将剩余持续时间带入下一次施放。这 **不会** 不会带入任何快照效果，这些效果需要在新的持续伤害施加时存在。大流行计时器如下：

- [[spell:1822]] – 4.5秒
- [[spell:1079]] – 7.2秒 <em>（假设5个连击点数）</em>
- [[spell:8921]] – 5.4秒

注意这些数值在使用[[spell:391969]]时会减少25%，加快其跳动速度。

### 快照

3.5.

#### 快照

"快照"长期以来一直是野性 德鲁伊玩法的核心支柱，用于强化你的流血效果。然而在至暗之夜中，这已被大幅削弱，只有少数特定的增益保留了这种行为。

与流血效果有快照交互的技能，以及它们影响的持续伤害效果如下：

- [[spell:5217]] — 所有持续伤害效果
- [[spell:390772]] — [[spell:1822]]（来自[[spell:5215]]）

[[spell:5217]]是你大部分快照的主要激活手段，因此在至暗之夜中利用这一机制要简单得多。只需记住在此窗口期间重新施加流血效果，并避免覆盖你之前快照的任何强化持续伤害效果，直到它们过期。通常，要遵循的规则是只在你将施加一个 **更强的** 快照时才覆盖持续伤害效果。如果你目前无法做到这一点，那么等到初始流血效果过期后再重新施加。

在至暗之夜引入的UI更改下，追踪这些效果要稍微困难一些，不过应该注意的是，当流血效果在快照效果下施加时，图标会发生变化。你的动作条也会切换到强化图标，突出显示有更强的流血效果可供施加，因此两者都可以用来辅助你的决策。

### 凶猛撕咬

3.6.

#### 凶猛撕咬

[[spell:22568]]是你的直接伤害终结技能，你只应在 **掌握** 你激活了 [[spell:1079]]（或 [[spell:285381]]）。施放时，请确保当前割裂的剩余时间足够长，以便你能够获得刷新它所需的连击点数。使用撕咬 撕咬 时，始终尽量保持 50 点以上能量以增强其伤害（如果使用 [[spell:421432]] 则更是如此）。

正如循环章节中所述，这只在你有闲置资源时才投入。虽然看到它造成的巨大伤害很诱人，但失去持续伤害的覆盖率几乎永远不值得投入。然而，[[spell:391881]]触发会让它变得 <em>完全免费</em>，应立即消耗。这些触发 **知道** 从额外的能量消耗中获得加成伤害，但 **不会** 被[[spell:421432]]进一步提高。

3.6.1.

##### 野性难驯

上述规则也适用于[[spell:391709]]，使其被额外的能量消耗所放大。这个天赋使它 <em>更加重要</em>
在投入之前将[[spell:1079]]施加到 **全部** 附近的目标身上，因为它只对受到该持续伤害影响的敌人造成伤害。

3.6.2.

##### 毁灭

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 在利爪德鲁伊中，你还可以获得[[spell:441583]]触发。这些遵循 <em>全部</em> 上述规则，在扩展方式上与[[spell:22568]]功能相同。应尽快消耗以避免覆盖触发效果（尤其是在AOE中），但仍要确保满足能量阈值以最大化其伤害。

### 野性狂乱与粉碎

3.7.

#### 野性狂乱

[[spell:274837]]应在你有0-2个连击点数时使用，并立即接上终结技。这意味着你既需要能量来施放它，也需要能量在快速连续中使用后续的连击点数消耗技能。只要有可能，就与[[spell:5217]]重叠使用。它还有一个后续选择节点：

- [[spell:1244544]]将冷却时间缩短15秒，并提高15%的伤害。
- [[spell:1243807]]是AOE版本，在目标之间快速闪现并施加强大的流血效果。

这两个节点分别在单体或AOE中都很强大，并且在每个构建中都会被选取以增强野性的爆发工具包。有了[[spell:1244544]]，它会 <em>总是</em> 与每一次[[spell:5217]]施放配对，而[[spell:1243807]]要么保留以对齐，要么每第三次施放使用一次，取决于你的拉怪节奏或小怪刷新。伤害也可以通过[[spell:441846]]在游玩时放大
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊.

3.8.

#### 啃噬

至暗之夜新增的[[spell:1244258]]有20秒冷却时间且无消耗，对你的目标造成高额物理伤害，暴击时造成三倍伤害。这 <em>只能</em> 在能量降至30%以下后使用，或在满足该阈值后的2秒窗口内使用。点出后应在可用时立即施放——最好在[[spell:5217]]期间，但不要保留以对齐。伤害也会被 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊通过[[spell:441846]]放大。

### 顶点天赋

3.9.

#### 野性 德鲁伊顶级天赋 – 无形捕食者

野性的顶点天赋[[spell:1263657]]专注于为你的终结技施放增加额外伤害。这进一步激励你正确地循环你的资源，并且目前在所有构筑中都会使用：

- [[spell:1263657]] **第一点 –** [[spell:22568]]每消耗一个连击点有15%的几率根据附近的目标触发[[spell:1271863]]或[[spell:1263903]]。如果触发时消耗的连击点少于5个或能量少于50点，则造成的伤害降低。
- [[spell:1263658]] **第二和第三点 –** 当通过[[spell:1263657]]触发隐秘攻击时，每点使你造成的所有伤害提高7.5%，持续1秒/每个消耗的连击点。额外的攻击会延长持续时间。
- [[spell:1263660]] **第四点 –** 使你造成的所有[[spell:1079]]伤害提高30%。此外，施放[[spell:5217]]会使你接下来的两个产生连击点的攻击以最大强度触发隐秘攻击。

这些会在你的循环中发生，造成直接伤害，并在触发后的短暂窗口内放大你造成的所有伤害。由于其力量偏向被动增益，最大化效果几乎不需要循环上的考虑。它唯一的作用是巩固了在5个连击点数时消耗的必要性，以避免过度激进消耗的惩罚。

3.10.

#### 野性 德鲁伊主要冷却技能

在天赋树中，有各种不同的冷却选项，以不同的方式提供爆发。下面，我们将逐一介绍它们，它们如何影响循环，以及如何使用它们。

1.

### 野性 德鲁伊的重要冷却技能

### 狂暴

4.1.

#### 狂暴

[[spell:106951]]是野性的主要冷却技能。持续15秒，冷却时间为3分钟（使用[[spell:391174]]减少至2分钟）。这提供巨大的伤害提升，因此应尽可能接近冷却就绪时使用，并与其他伤害提升效果配合。激活期间，它提供以下几种好处：

- 每1.5秒生成1个连击点数。
- 所有技能伤害提高15%。
- 连击点数生成技能额外生成1个连击点数。
- 最多可作为[[spell:405069]]层数在5个连击点数之上存储3个连击点数。
- 终结技消耗[[spell:405069]]层数以返还相同数量的连击点数。
- [[spell:102543]] — 持续时间延长至20秒，激活期间[[spell:768]]技能的能量消耗降低25%。
  
  
  
  
  - [[spell:391548]]额外将化身的冷却时间减少至90秒。

虽然有很多效果与之关联，但主要影响相当简单：你造成 **显著** 更多的伤害，并能获得更多资源。野性使用这个的2分钟爆发窗口相当强大，应始终与[[spell:5217]]和[[spell:391528]]施放对齐。激活期间，更激进地消耗以利用资源的涌入。

当升级到[[spell:102543]]时，你还能获得一次
**单次** 在战斗中使用[[spell:5215]]的机会，每次施放它时。用它通过[[spell:390772]]施加强化的[[spell:1822]]。

### 猛虎之怒

4.2.

#### 猛虎之怒

[[spell:5217]]有30秒冷却时间，不在GCD上，使用时立即生成50点能量。此外，所有野性技能伤害在10秒内提高15%。这个伤害提升也会 <em>快照</em> 激活期间施加的流血效果，在其完整持续时间内改善它们。有许多野性天赋与之交互：

- [[spell:202021]] – 持续时间延长5秒，连击点数生成技能的伤害提高你急速的40%。
- [[spell:449645]] – [[spell:5217]]提供10%急速和25%的能量回复提高，持续8秒。
- [[spell:391078]] – 持续时间额外延长5秒。
- [[spell:391872]] – 使你施放后的接下来三个终结技也恢复1个连击点数。此外，施加到的[[spell:5217]]伤害快照 **流血** 提高10%。
- [[spell:390902]] – 每点投入提高6%的伤害加成。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 – [[spell:441824]]在每场战斗中首次施放时赋予[[spell:441583]]。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者 – [[spell:439890]]使[[spell:5221]]、[[spell:1822]]和[[spell:213764]]的暴击几率提高，持续6秒。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者 – [[spell:440118]]施放时会附上一个[[spell:439531]] <em>和</em> 在其到期时。

[[spell:5217]]在野性天赋树中占有重要地位，其30秒的冷却时间在很大程度上决定了野性的游戏节奏。由于它不占用GCD，因此应尽可能接近每30秒使用一次。在可能的情况下，尽量在能量较低时使用以利用其能量返还，并在流血效果即将到期时刷新以进行快照。尽量保持其循环，以维持它与[[spell:106951]]和[[spell:391528]]的对齐。

### 万灵之召

4.3.

#### 万灵之召

[[spell:391528]]是一个2分钟冷却的技能，使用后会在4秒内快速连续施放16个德鲁伊法术（不消耗资源）。这可以在移动时引导，但 <em>会受到</em> 敌人打断的影响。在众多法术池中，野性技能是首选，但在引导过程中也会施放少量其他专精的法术。 **如果你不在近战范围内**
它将默认施放可以远程使用的技能。关于它施放的技能，有几点快速说明：

- [[spell:22568]]是野性技能池中的终结技。这被视为满连击点的施放， **不会** 消耗额外能量，但会 **非**
  被[[spell:421432]]进一步提高。
- 任何产生连击点的技能仍然会为你产生一个连击点。
- 它能施放的“特殊法术”是[[spell:274837]]。
  
  
  
  
  - 这套 **将会** 如果点出，则变为[[spell:1243807]]。
- [[spell:8921]] <em>将会</em> 会受到[[spell:155580]]的加成，但仅在点出时生效。它也 <em>总是</em> 在技能池中。
- [[spell:774]]、[[spell:8936]]和[[spell:5176]]也在技能池中。
- [[spell:384667]] <em>将会</em> 被消耗。
- [[spell:441583]] <em>将会</em> 被消耗。
- [[spell:391881]]将会 <em>非</em> 被消耗。

由于在[[spell:106951]]和[[spell:5217]]激活期间获得的伤害加成，这应该 <em>总是</em> 在增益重叠期间施放。它们的冷却时间自然对齐，所以尽量不要让它们错开。最后，在单体目标和
<em>尤其是</em> AOE中，确保你有活跃的[[spell:1079]]，且其持续时间能覆盖整个引导时长。

4.3.1.

##### 阿曼萨的指引

[[spell:391548]]是一个后续节点，与[[spell:391528]]搭配使用时，可将冷却时间缩短至1分钟，法术数量减少至12个，引导持续时间缩短至3秒。虽然并非总是点出，但使用时应严格将其冷却时间保持在1分钟，以避免与[[spell:106951]]错开。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为第1赛季发布进行更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 已为11.1.7版本更新，加入关于循环助手的说明。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7版本进行审查，添加了推荐标签。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月30日：** 将默认配装改为荒野追猎者单体，以与天赋页面保持一致。
- **2024年9月9日：** 已为最近的血之爪热修和利爪德鲁伊推荐进行更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已针对第4赛季进行审查，无玩法改动，但为提高可读性重构了页面。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，将聚灵移至主按钮，并添加了AOE起手切换。
- **2023年11月6日：** 已为10.2版本更新，并重构了循环工具。
- **2023年9月4日：** 已为10.1.7版本重构。
- **2023年7月10日：** 已针对10.1.5版本进行审查，有细微调整和关于凶猛凝视AOE的说明。
- **2023年5月1日：** 已根据10.1补丁更新，包含新的狂暴技能改动和更新后的天赋方案。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 已根据巨龙时代第1赛季更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页，你将找到《魔兽世界》12.1.5中野性德鲁伊的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们都为你准备好了！

1.

### 野性德鲁伊毕业装备指南

欢迎来到至暗之夜的野性德鲁伊装备与毕业页面！查看本页，了解关于为野性德鲁伊配装的一切，包括来自所有来源、团本和大秘境的毕业装备、最佳饰品、套装等信息。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，允许你沿着与获取内容难度相关的轨道提升装备物品等级。更难的内容会掉落更高等级轨道的装备，从而达到更高的物品等级。欲了解更多信息，请阅读我们关于纹章如何运作的专属页面。 [配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 在至暗之夜中的运作方式。

12.1.5更新带来了[[item:280562]]的发布，允许334武器、饰品和项链一路升级至340物品等级。此外，它还带来了新首领基斯伊克斯，掉落强大的新战利品，其中有一些对野性非常有用的强力提升。

### 总体

以下列表包含来自 <em>所有可能的终局内容来源</em>的装备，包括团本、大秘境、制造、地下宝库和大宝库。它旨在提供绝对最佳的配置，但请记住，每个 **单件** 装备在你特定的配装中可能并非最强。套装件如果比标准版本更强，则会列出理想转化器部件的掉落位置。

请注意，这套装备旨在暴击、精通和急速之间取得平衡，因为这三者的收益相近。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

目前每个部位可供转化的最佳物品为：

- **头盔 –** [[item:271875@JAAEAAAG2chN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **肩膀 –** [[item:271526@JAACAAgNyA]]，来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **胸甲 –** [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **手套 –** [[item:268234@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- **腿部 –** [[item:268225@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 常见问题：有哪些需要留意的高优先级大宝库或虚空核心物品吗？
第2赛季团本中提供的任何特殊效果物品都极具价值，即使它们不是来自史诗难度的344物品等级。以下物品即使来自英雄难度宝库也强烈值得考虑，如果你不打算快速推进史诗难度，甚至值得使用虚空核心来获取：

1. [[item:268215@JAAEAAAG2YhN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

所有三件新的 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) 物品也非常强力，是很好的虚空核心候选。该池中的物品足够强大，以至于如果你 <em>没有</em> 击杀任何史诗首领以获得更高的宝库奖励，如果这些物品都没有出现，你总是可以选择从大宝库中获取一个虚空核心。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268215@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 秘境+

以下套装包含来自大秘境的最佳物品，仅使用第2赛季副本池中的装备，以及你理想的套装转化器位置和用于装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 来自大秘境地下城的 **非** 并非你在大秘境内容中应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限地下城** 的各部位转化件为：

- **头盔 –** [[item:251140@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **肩膀 –** [[item:251223@JAACAAgNyA]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **胸甲 –** [[item:251159@JAACAAgNyA]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- **手套 –** [[item:251124@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- **腿部 –** [[item:251130@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 提示我应该刷哪些地下城？
野性所有最强的装备都来自第2赛季的团本，但在等待获取它们期间，有一些值得追求的替代品：

1. [[item:252258@JAACAAgNyA]] – [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
2. [[item:159617@JAACAAAOyA]] – [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
3. [[item:251124@JAACAAgNyA]] – [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
4. [[item:250228@JAACAAAOyA]] – [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAAOyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:159317@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240892]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:251149@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### 团队副本

以下套装是你的 **团本** 毕业列表，使用来自 **只能** 团本掉落的装备，以及理想的套装件（或用于转化器的物品）和用于激活装饰效果的制造物品。请注意，这是 <em>可获得的最佳物品</em> 团本内部的 **非** 并非你在团本内部应使用的严格列表。

:::details 常见问题：我在转化器中使用哪些物品？
在至暗之夜第2赛季中，转化器现在 **保留次要属性和戏法** 你转换的 <em>任何</em> 物品的特殊效果。因此，使用哪个部位来激活套装效果并不重要，重要的是你放入的物品。

最佳 **仅限团本** 的各部位转化件为：

- **头盔 –** [[item:271875@JAAEAAAG2chN]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **肩膀 –** [[item:271526@JAACAAgNyA]]，来自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>)
- **胸甲 –** [[item:281236@JAAEAAgNyEuN]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **手套 –** [[item:268234@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)
- **腿部 –** [[item:268225@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

与第1赛季类似，你的 <em>首要任务</em> 是通过任何方式获得4件套效果以解锁 **转化器解放** 以应对第2赛季。

:::

:::details 小贴士：我最应该追求哪些物品？
野性在剧毒深渊中有一些极具价值的特殊效果物品，其中大部分来自最终首领乌拉特克。来自最后两个首领的所有物品都值得获取，因为它们的物品等级更高，但其中一些尤其强力：

1. [[item:268215@JAAEAAAG2YhN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
2. [[item:270175@JAACAAAG2A]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
3. [[item:270173@JAACAAAG2A]] – [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271528@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271529@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240900]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271526@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271527@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271531@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>护腕</th><td>[[item:244576@JAAKAAwt1ENMMYDYwklI]]&#10;&#10;<div>[[item:240908]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/feral-druid-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268215@JAAEAAAG2YhN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 野性德鲁伊饰品推荐

野性通常寻求使用一个与[[spell:106951]]对齐的主动饰品来增强其本已强大的爆发窗口，然后搭配一个强力的被动饰品。

目标是分别从以下每个类别中获取一个饰品，组成一对：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **在至暗之夜中值得追求的饰品**
**使用型 -**

[[item:270175@JAACAAAG2A]]

**被动 -**

[[item:270173@JAACAAAG2A]]

或

[[item:281215@JAACAAAOyA]]

:::

你可以点击下方打开其他饰品的排名图表，以防你捡到了别的东西并想看看它与其他饰品相比如何。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 野性 第二赛季饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270175@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   尽管冷却时间是尴尬的1分30秒，但这仍是第二赛季目前最强的主动使用型饰品。没有其他选项在威力上能与之接近，所以这是你重点追求的装备之一。记得留着它与你的 [[spell:106951]] 窗口配合使用。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   一个相对标准的直接伤害饰品，但拥有更高的装等上限，并且能打出极佳的单体伤害。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   在12.1.5补丁中新增，这是 <em>最强的</em> 被动群体伤害饰品。由于 野性 无法激活断头台技巧套装效果，一旦有顺劈场景，触须就能追平差距，并且之后只会更强。适合任何有频繁小怪刷新的场景，或在大秘境中使用。</p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   触发多种不同的属性增益效果，且不同的增益可以叠加。虽然其触发池中包含一个负面效果，但它仍是一个可靠的被动选择，在顺劈、群体伤害和地下城中特别有用。</p>&#10;</li>&#10;<li>[[item:270165@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:159617@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   当然不如贪食之心强，但它在大秘境中可作为主动使用型饰品的替代品。更长的持续时间也让它能覆盖新套装带来的延长 [[spell:106951]] 持续时间的大部分。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:273796@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   与 [[spell:106951]] 配合以强化你的爆发窗口，但负面后遗症会触发并覆盖你冷却时间的尾声 <em>和</em> 以及套装效果的收益，使其略弱于其他主动使用型替代品。</p>&#10;</li>&#10;<li>[[item:250228@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250225@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   尽量始终对一个存活时间足够长的目标使用它，以便叠加暴击增益，否则它的大部分价值都会流失。</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   虽然这个饰品的数值调校得不错，精通也很理想，但留在触发区域内非常受限，尤其是在第二赛季。由于团队副本战斗场地较大且地下城中移动频繁，实际使用时效果可能因人而异。</p>&#10;</li>&#10;<li>[[item:270166@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   前往 祖尔'Aman 中的 Jan'alai 祭坛，将其设置为 <strong>精通</strong>.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>点击查看详情</em></span>&#10;<p>&#10;		   留着与 [[spell:106951]] 配合。使用 [[item:241288]] 时，记得 <em>之前</em> 使用你的饰品以避免将其设置为暴击。</p>&#10;</li>&#10;<li>[[item:265657@JAACAAAMyA]]</li>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>点击查看详情</em></span>&#10;<span>&#10;		   这会造成一个 <em>极</em> 大量的爆发伤害到你的主要目标上，同时附带一些额外的群体伤害。虽然由于它是引导技能且冷却时间长，在与其他选项竞争时有些吃力，但它在处理关键敌人方面的独特潜力意味着在第二赛季的某些边缘情况下值得一看。</span>&#10;</li>&#10;<li>[[item:250259@JAACAAAOyA]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;<li>[[item:158374@JAACAAAOyA]]</li>&#10;<li>[[item:251785@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>制造饰品详情</em></span>&#10;<span>&#10;		   虽然这些饰品选项并不 <em>差</em>，但第二赛季的装饰比以前更强了。这意味着使用它们的机会成本太高，它们比原本就已经落后的地位更加落后了。</span>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚无核心与升腾毒石

第二赛季沿用了第一赛季推出的额外奖励骰系统，提供了一种获取重要装备的途径：

**[混沌虚空核心](<https://www.wowhead.com/currency=3418>)s** 可在完成终局地下城或击败团队副本首领后使用，从相应的掉落表中随机获得一件物品。一旦通过虚无核心骰获得过某件物品，它就不会再次出现。在第二赛季， **单** 虚无核心用于对地下城掉落进行掷骰 <em>或</em> 单个团队副本首领，获得相当于你每周宏伟宝库奖励装等的掉落。

每周可从 **奥琳·微光** 获得一个，该物品位于催化剂旁边，随12.1.5补丁发布后开放。此外，如果你解锁了总共三个奖励，也可以从宏伟宝库中选择一个虚无核心而非一件物品。

3.1.

#### 野性 德鲁伊 推荐虚无核心使用方式

你应该优先获取哪件物品，很大程度上取决于你已经拥有的装备、可通过 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)获得的物品，以及你目前已击杀的首领。虽然随着12.1.5补丁加入每周奖励，它们现在更容易获得，但从宏伟宝库中拿一个应被视为 <em>安慰奖</em> ，在没有更好选择的情况下。

关于 <em>以及</em> 当你确实拿到一个虚无核心后，应该在哪里使用它，答案很简单：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **第二赛季虚无核心用途**
1. **乌拉特克** （英雄/史诗）
   
   
   
   
   - [[item:270175@JAACAAAG2A]]
   - [[item:268265@JAAGAAAG2MqNTpC]]
   - [[item:271875@JAAEAAAG2chN]]
   - [[item:268215@JAAEAAAG2YhN]]
2. **Kith'ix** （英雄/史诗）
   
   
   
   
   - [[item:281236@JAAEAAgNyEuN]]
   - [[item:281029@JAACAAgNyA]]
   - [[item:281215@JAACAAAOyA]]
3. **盘卷祭坛** （英雄/史诗）
   
   
   
   
   - [[item:270173@JAACAAAG2A]]

:::

:::details 常见问题：我何时应该考虑从宏伟宝库中选择虚无核心？
随着赛季推进，虚无核心更容易获得，推荐也更加具体。虽然你现在拥有更多掷骰机会，但仍需记住一些可能让你觉得拿一个不太划算的情况：

- 如果你尚未解锁你的四件套效果，获取它应优先考虑。
- 如果 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 中的关键追求装备被提供，就选它。
- 留意早期史诗首领击杀掉落的单件关键装备（例如来自 [陵寝哨兵](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)的饰品），因为它们以6/6史诗难度提供，可以节省纹章并省去为有用物品进行额外掷骰的需求。

主要需要考虑的是，虽然额外奖励骰会缩小后续掷骰可获得的物品池（提高获得追求装备的几率），但一开始就从掉落或宝库中获得你想要的物品，可能可以避免投入额外的虚无核心。

:::

3.2.

#### 晋升毒液石

随着12.1.5补丁发布，你现在可以获取 [[item:280562]]，允许你将特定装备栏位一直升级到装等340（制造装备为338）。使用这些的优先级与你的纹章使用类似：

1. **武器** 始终优先。
2. **主动使用型饰品** 其次，理想情况下是 [[item:270175@JAACAAgNyA]]。
3. **被动饰品** 第三。
4. **项链** 最后。

你还希望优先升级神话级装备而非英雄级装备，除非你不打算获得你正在升级的装备的神话级版本。例外是 乌拉特克 在剧毒深渊中最难获得的装备之一——[[item:270175@JAACAAgNyA]]。由于它是我们目前最强的主动使用型饰品，即使在较低级别的装备上也值得投资。

1.

### 野性 德鲁伊 最佳制造装备

制造装备提供了在赛季中获取高价值物品最简单的方式之一，让你能够定向获取关键装备来完善你的配装。随着第二赛季发布，每次制造需要两个 [[item:274476]]。

除非装备已自带副属性，否则你应该使用 [[item:245783]] 来获得急速和精通。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **野性 制造订单**
**[[item:244569@JAAKAAwt1ENMMYDYwklI]]**

➜

**[[item:244576@JAAKAAwt1ENMMYDYwklI]]**

➜

**可选制造**

:::

- **关于武器制造的说明** ——虽然通常武器制造适合填补空缺，但咒术武器（[[item:268215@JAAEAAAG2YhN]]）即使从英雄难度额外掷骰获得也足够强大，因此消耗两次制造的价值比平时低。如果 <em>你早期无法获得它</em> 或者你运气不好没掉落，制造 [[item:245771@JAAMAAwt1ENMMYzy1klIcYD]] 并附加 [[item:273060]] 是 <em>总是</em> 最佳选择。
- 制造 **一件散件** ——我们推荐在鞋子栏位制造 [[item:244569@JAAKAAwt1ENMMYDYwklI]]。将 [[item:240167]] 作为你的第一个装饰附加。
- 制造 **另一件散件** ——我们推荐在护腕栏位制造 [[item:244576@JAAKAAwt1ENMMYDYwklI]]。将第二个 [[item:240167]] 作为你的第二个装饰附加。

之后，根据你当前装备的空缺来制造物品。

:::details 常见问题：第二赛季的新装饰好吗？
**有些**。在第二赛季发布前，许多装饰被削弱了，这在12.1.5补丁中并未改变：

- [[item:273060]] 是 [[item:245876]] 的更好替代品，使其成为最佳武器装饰，也是我们目前的首选。
- [[item:273069]] 提供可叠加的急速触发。这 <em>非常</em>
  在价值上接近 [[item:240167]]，但落后太多，无法证明其合理性，尤其是后者还能增益盟友。
- [[item:273066]] 遭到了 <em>巨大的</em> 削弱，因此不值得考虑。
- [[item:270899]] 也遭受了大幅削弱，因此也不值得考虑。

:::

一旦你完成了两个主要装饰的制造，你的配置应该就相当扎实了。进一步优化装备时，你的优先级应该是制造高装等的装备来填补你配装中的漏洞。高优先级候选是珠宝首饰，虽然有强力的独特选择，但它们 <em>极</em>
在这个赛季竞争激烈。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

1.

### 纹章使用

赛季初期，或者如果你刚开始玩一个副角色，你获得升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 以提升装等）的机会有限。纹章每周上限为100个，升级无论哪个栏位都花费20个纹章。因此，你应该优先将这些纹章用在你短期内不打算更换的物品上，或者能提供更大属性收益的特定栏位：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **野性 德鲁伊 纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些不是唯一值得升级的物品。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的物品。注意例外情况是可能的，例如附带额外触发的特殊咒术物品，比如 [[item:268265@JAAGAAAG2MqNTpC]]。

5.1.

#### 为装备添加插槽

虽然所有戒指和项链默认带有一个插槽，但头盔、腰带和护腕栏位在掉落时作为奖励可以获得三个额外插槽。这些也可以使用 [[item:275707]] 消耗品手动添加，该消耗品可以用6个 [[item:258556]] 购买，这是宏伟宝库的保底货币。

使用这些时，最好将它们用在你预计永远不会替换的装备上。这意味着史诗级物品，或这些栏位中的任何制造装备，因为它们无法通过其他方式添加插槽。由于它们是非常有限的货币，如果你拥有这些，最好在使用前做好长期规划。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月24日：** 已确认装备列表，调整武器附魔，强调早期武器制作，并扩展关于理想早期属性散件的常见问题解答。
- **2026年8月19日：** 由于阿希尔班圣匣在线修正，添加了关于装备推荐不确定性的免责声明。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已根据12.0.7补丁使用孢子坠落装备进行更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已更新完整的第1赛季推荐。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已为11.2.5版本更新，并加入了卡特尔代币推荐。
- **2025年8月16日：** 更新了饰品排行榜以涵盖额外的平衡性调整。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 已更新以纳入D.I.S.C.的热修。
- **2025年6月15日：** 已为11.1.7版本更新，加入D.I.S.C.腰带，并为双加里维克斯武器微调了毕业列表。
- **2025年5月12日：** 已为涡轮加速发布确认迪纳尔推荐。
- **2025年4月21日：** 已针对11.1.5版本进行审查，并添加了卡特尔代币部分。
- **2025年3月3日：** 更新了希尔赛的项圈和部分饰品推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月17日：** 已更新以突出热修后新戒指的强度。
- **2024年12月15日：** 已为11.0.7版本更新，加入希尔赛的项圈。
- **2024年10月21日：** 已针对11.0.5版本进行审查，将疯狂女王的敕令移至推荐栏。
- **2024年9月9日：** 已更新第1赛季毕业列表。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为第4赛季和觉醒装备的发布进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，将烬魄之灰标注为与枯萎之 bark 同等。
- **2023年11月7日：** 已更新以移除孢子斗篷推荐，切换了剧毒荆棘/剧毒补丁。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本重构，信息保持不变。
- **2023年7月10日：** 已为10.1.5版本更新，加入大秘境装备，并澄清了制造业部分。
- **2023年5月25日：** 添加了关于大灾变时光漫游的部分。
- **2023年5月9日：** 已更新以纳入饰品变动。
- **2023年5月1日：** 已为10.1版本和第2赛季的发布更新，加入新的装备推荐。
- **2023年3月24日：** 已根据原始宝石的在线修复更新。
- **2023年3月22日：** 已根据原始宝石的增益效果更新。
- **2023年3月20日：** 已根据10.0.7补丁更新，包含熔炉指环推荐。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 已根据巨龙时代第1赛季更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页，你将找到你的 野性 德鲁伊 的最佳属性优先级。我们首先介绍属性优先级，然后深入解释这些属性如何与你的专精和游戏玩法相互作用。我们的内容已针对魔兽世界12.1.5补丁更新。

1.

### 野性 德鲁伊 属性优先级

欢迎来到 至暗之夜 资料片中 野性 德鲁伊 的属性优先级页面！在这里，我们将快速介绍你在装备上应该追求的属性，以及根据你的天赋构建需要考虑的任何特殊事项。

在第二赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 的总体属性优先级相似，但根据你是单体还是群体场景，情况会略有不同。

1.1.

#### 野性 德鲁伊 单体属性优先级

A <em>综合</em> 野性在单体目标下的属性优先级如下：

敏捷

精通

急速

暴击

全能

在至暗之夜中，属性压缩后敏捷的收益大幅提升，这意味着你的大多数配装决策再次由物品等级驱动。

精通、急速和暴击的收益都 <em>非常</em> 相近，理想情况下你需要保持它们的平衡。暴击和急速都通过能量回复和[[spell:159286]]提供资源平滑。而精通则提升你的终结技和流血伤害，因此被推荐高于其他属性，因为你希望你的[[item:241288]]触发这个属性。

全能排在最后，没有特殊互动，不过它确实提供一些防御收益。在第2赛季，由于剧毒诅咒装备和[[item:241288]]的组合，你最好尽可能降低全能，因为这些负面触发效果无法将全能降低到零以下。

1.2.

#### 野性 德鲁伊AoE属性优先级

A <em>综合</em> 野性在AoE下的属性优先级如下：

敏捷

精通

暴击

急速

全能

与单体目标相同，敏捷仍然是装备上最有价值的属性，因此你的大多数配装决策由物品等级驱动。

精通仍然是你的首要属性，用于强化终结技和流血，也是你希望设置[[item:241288]]的属性。暴击排第二（尤其是对于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊），通过[[spell:159286]]提供额外的资源平滑。

在AoE中，一旦你有足够的资源来维持循环，急速会稍逊一筹，但在装备上保持一定的急速仍然值得。

全能排在最后，没有独特的互动，不过它确实提供防御收益。与单体目标一样，由于剧毒诅咒装备和[[item:241288]]的组合，你应尽量少堆全能，以避免受到这些效果负面作用的惩罚。

1.

### 深入属性解析

作为一名野性 德鲁伊， **敏捷** 是你的主属性，应出现在你穿戴的所有皮甲装备以及你的武器上。各属性提供以下收益：

- **敏捷**：为你提供攻击强度，提升你的野性技能和近战攻击的伤害。
- **暴击**：提高你攻击暴击的几率，造成双倍伤害。此外：
  
  
  
  
  - [[spell:159286]]在你用连击点生成技能暴击时额外提供一个连击点。
- **精通**：强化[[spell:77493]]，提升你流血效果造成的所有伤害。此外：
  
  
  
  
  - 提升所有直接伤害终结技造成的伤害。
  - 提升[[spell:391709]]造成的伤害。
- **急速**：提高你的自动攻击速度和能量回复。此外：
  
  
  
  
  - 提高你流血DoT效果的跳数频率。
  - 通过[[spell:202021]]，将连击点生成技能的伤害提升你急速百分比的40%。
- **全能**：以固定数值提升你造成的所有伤害和治疗（包括饰品和触发效果）。此外，使你受到的所有伤害降低该数值的一半。

2.1.

#### 属性递减收益

每种属性都有一个收益递减点，超过该点后每点属性带来的提升会减少。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对第1赛季发布进行审查。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月3日：** 在AOE中将急速略微提升至高于全能。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 已为第4赛季发布进行更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 略微调整措辞，以显示暴击、急速和精通在装备支持下均可达到持平。
- **2023年7月10日：** 已为10.1.5版本更新，将急速和精通调整为持平。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页，我们列出了你的野性 德鲁伊所能获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/feral-druid-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

所有内容的推荐选择为：

- 在你的第一个插槽中使用[[item:240983]]。
  
  
  
  
  - 在其他插槽中使用[[item:240900]]。
- 由于 **5个及以上插槽**，切换为[[item:240967]]。
  
  
  
  
  - 每种颜色使用一颗以最大化奖励——[[item:240900]]、[[item:240892]]、[[item:240908]]和[[item:240917]]。

根据你的属性平衡，插槽通常是弥补装备差距的最佳位置。由于精通、急速和暴击对于野性都具有竞争力，我们建议对你的人物进行模拟，以确定在宝石插槽中优先考虑哪种属性。

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td><strong>主手</strong></td>&#10;<td>&#10;<ul>&#10;<li>&#10;[[item:273072]]<br/>&#10;   使用[[item:243733]]&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>头部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>护肩</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>胸部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>腿部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>靴子</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>戒指</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

头盔、肩膀和靴子的附魔取决于个人喜好，因为它们对性能没有直接影响，但我们建议所有插槽都选择闪避附魔以获得额外的生存能力。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

如果你的装备配置在某个特定属性上有所欠缺，合剂是调整你的次级属性的好方法。根据内容，你通常会选择堆叠急速或精通：

- [[item:241322]]——提供精通。
- [[item:241325]]——提供急速。

你也可以从药剂师提供的[[item:241319]]中获得你选择的合剂。

3.2.

#### 药水

在第2赛季，根据你当前的装备，有几种不同的选择：

- [[item:241288]]——如果你能触发精通，通常是最强的选择。
- [[item:271886]]——在单体目标中作为[[spell:391528]]的预备药水有特殊用途。
- [[item:241308]]——如果你的装备没有为鲁莽进行优化。

在这三者中，一旦你的装备设置好触发首选属性，[[item:241288]]通常会是最强的。你可能会在模拟中发现，在属性不平衡的装备组合下，[[item:241308]]更受青睐——这是正常的，你应该遵循该建议，直到你的属性平衡到足以支持它。

药水应始终与大型冷却技能以及[[spell:2825]]/[[spell:32182]]配合使用。你也可以从药剂师提供的[[item:241285]]中获得这些药水的短暂版本。

关于[[item:241292]]的一点说明是，虽然它在技术上更强，但一步走错就会在它偶尔生成的虚空区域内被沉默。只需在里面待上1-2个GCD（或一个被取消的[[spell:391528]]！）就足以抵消额外的收益，所以使用这种药水通常不值得。

[[item:271883]]是目前最好的治疗药水。使用后有5分钟冷却时间，但如果首领战持续足够长，可以消耗多个。此外，术士的[[item:5512]]与其他治疗消耗品不共享冷却时间。如果你持有一个，记得也要使用它！

3.3.

#### 食物增益

敏捷在第2赛季仍然是最强的属性，所以如果可能的话，你应该吃[[item:255845]]或其他主属性大餐。如果团队没有提供，就改用[[item:242275]]个人食物。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用[[item:259085]]来提升你的主属性。记住：强化符文价格昂贵且死亡后消失，所以明智地使用它们！

3.5.

#### 其他消耗品

除了标准的增益消耗品外，还有少数其他物品值得保留——尤其是在大秘境中：

- [[item:188152]]——让你自动与附近的术士[[spell:111771]]互动。
- [[item:244639]]——使用时为你的小队提供较弱的15%急速[[spell:2825]]效果。这些仍会受到[[spell:57724]]的影响，所以只应在你没有小队成员自然提供该效果时使用。
- [[item:241303]]——至暗之夜的隐身药水，可用于在大秘境中跳过某些小怪战斗。请注意，这 <em>确实</em>
  与你选择的战斗药水共享冷却时间。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月24日：** 将武器附魔更换为哈希仪式，并扩展了药剂部分。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为第1赛季更新——为大秘境增加了茶饮和额外的消耗品。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月12日：** 已根据腐蚀调整进行更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 添加了关于亵渎尖晶石的说明。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，将食物推荐改为次级食物。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5版本进行审查，关于宝石替代品的小提示。
- **2023年5月1日：** 已为10.1版本更新，加入可用的新附魔。
- **2023年3月24日：** 已根据原始宝石的在线修复更新。
- **2023年3月22日：** 已根据原始宝石的在线修复更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 已针对 10.0.5 补丁进行审阅和更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的野性 德鲁伊挑战大秘境地下城的提示和建议。

1.

### 野性 德鲁伊在至暗之夜第2赛季的大秘境

在本页，我们将介绍如何在大秘境地下城中充分发挥你的野性 德鲁伊的实力，包括最佳天赋构建方式、你需要了解的循环变化，以及在钥石中表现出色的提示和技巧。

如果你不熟悉大秘境及其相关的一般机制，你可以在下面我们专门的大秘境页面上了解更多信息。你也可以在我们的层级列表页面上了解更多关于大秘境环境的内容。

野性德鲁伊在大秘境中提供强大的持续AoE输出，同时每两分钟还能带来强力的爆发。其在多目标场景中的很大一部分伤害来自[[spell:285381]]施加的AoE流血，因此与许多其他专精不同，它不受目标数量上限的限制。虽然它常常需要牺牲一些专精的单体天赋来为AoE核心腾出空间，但野性在被迫参与首领战时仍能发挥作用。与过去的许多赛季一样，在第2赛季 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊最适合大秘境环境的需求，尽管 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在输出量上比以往更加接近。

1.

### 最佳大秘境天赋配置

在第2赛季，虽然套装对两系都很好，但它更突显了
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊在大秘境中的游戏思路。其伤害分布的前置特性加上额外的防御工具，使其成为最佳选择。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者 <em>仍然可以使用</em> ，特别是天赋树的重构有助于缓解其在第1赛季的一些构建限制。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊推荐选择

2.1.

#### 最佳野性 德鲁伊大秘境构建—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊是 **推荐** 系，因为它造成的伤害、简单性以及提供的额外防御。核心野性工具包的唯一显著变化是增加了[[spell:441583]]触发，这只是替代了你原本会使用的[[spell:22568]]施放。第2赛季对[[spell:1244532]]的改进也有助于保持其优先伤害的完整性，即使切换到更侧重AoE的循环。

它通过[[spell:285381]]和[[spell:391709]]将其单体终结技转化为AoE，因此在循环上玩法非常相似。天赋树顶部的变化也使其更容易融入，同时保留[[spell:391700]]以推动[[spell:1822]]作为通用的连击点生成技能。它每两分钟带来一次爆发（由套装奖励延长），配合[[spell:106951]]和[[spell:391528]]，以及每45秒一次的小爆发[[spell:1243807]]。

2.1.1.

##### 天赋更换选项

由于天赋树的大部分在第2赛季得到了大幅改进，有 <em>大量</em>
多种选择的表现相近。我们下面的构建是一个宽泛的推荐，但有很大的空间根据地下城或个人喜好进行自定义。

- 选择[[spell:391548]]将[[spell:391528]]缩短为1分钟冷却，但如果这些在特定地下城中不利，可以切换到[[spell:390902]]。
- [[spell:1244532]]提供额外的优先伤害以弥补你在AoE循环中的损失，但如果你想更专注于通用单体，[[spell:231063]]是一个替代选择。
- [[spell:1244547]]需要敌人频繁死亡并且你的队伍连续拉怪才能发挥价值，但如果你能持续做到，这是一个很好的选择。
- [[spell:29166]]推荐给你的治疗者，但如果不需要，你可以切换到[[spell:449193]]。
- [[spell:132469]]、[[spell:102793]]和[[spell:99]]都是强烈推荐的控制工具。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 大秘境/AoE——利爪德鲁伊
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2M2mZbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAgmZZWmZmBAsAzMDwCDGAAAzshB"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112W8QT7cl9lMmHSV-kgijBKOfQST58KFIWaGYq22Mmgpt4aG-AAAA-EMQUYaGMgoQyyB-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者替代构建

2.2.

#### 替代野性 德鲁伊大秘境构建—— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者从第2赛季天赋调整中获得了巨大改进，使其更容易启用AoE终结技而不必牺牲重要的天赋选择。[[spell:285381]]、[[spell:391709]]和[[spell:391700]]都是必选天赋，使其能够将大部分单体技能转化为多目标输出。它的构建比 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊放弃稍多的单体能力，并且对操作水平要求更高才能发挥最大效果。

与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊类似，它在[[spell:106951]]期间有很高的2分钟爆发（由套装延长），同时还有[[spell:391528]]提供一连串高伤害攻击。[[spell:1243807]]完善了冷却选项，每45秒造成一次高额AoE伤害，因此它通常每次拉怪都有可用的技能。

2.2.1.

##### 天赋更换选项

与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊，有几种天赋选项可供 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/wildstalker.webp>) 荒野追猎者在较小的差距内选择。

- 选择[[spell:390902]]作为通用选择，但如果1分钟冷却更有利，可以使用[[spell:391548]]。
- [[spell:1244532]]提供额外的优先伤害以弥补你在AoE循环中的损失，但如果你想更专注于通用单体，[[spell:231063]]是一个替代选择。
- [[spell:1244547]]需要敌人频繁死亡并且你的队伍连续拉怪才能发挥价值，但如果你能持续做到，这是一个很好的选择。
- [[spell:29166]]推荐给你的治疗者，但如果不需要，你可以切换到[[spell:449193]]。
- [[spell:132469]]、[[spell:102793]]和[[spell:99]]都是强烈推荐的控制工具。

**使用下方的复制按钮生成导入代码，在游戏中使用！**

:::talents 大秘境/AoE——荒野追猎者
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPw2YbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAgZmZ2YmZmxY2MPw2YbGzMmZAAAAYLY2M8AmZUzYWMzMzsMmxAAAAAAwADAAAAAwsNzWzyMLbwMzAswgBAwMDAGA"
}
```
:::

:::details 来源计算器编码
```
#nB-MOTTf0NhiAJUkqsktx112WUTbl9l8JmqnDS-kgijBKOfQST58KFIWaGYq22Mmgpt4qF-AAAA-BEIeApJ4gRiCmF-
```

:::

1.

### 地下城天赋切换速查表

本节包含第2赛季地下城池中的实用用途。

要快速参考你的可选野性实用天赋的额外用途，请使用下面的工具选择一个地下城。下方会突出显示相关选择以及它们所应对的目标。

<table>&#10;<tr>&#10;<th colspan="2">地下城</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></td>&#10;</tr>&#10;</table>

基于以上选择，以下技能具有独特的用途：

![Remove Corruption Not Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/decurse.jpg>)**适用条件：毒牙祭坛（未启用）；Blinding Vale（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；塞塔里斯神庙（未启用）；密谋小径（未启用）；虚空之痕竞技场（未启用）。**

![Remove Corruption Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/decurse.jpg>)**适用条件：毒牙祭坛（启用）；Blinding Vale（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；塞塔里斯神庙（启用）；虚空之痕竞技场（启用）。**

‌

![Soothe not Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/soothe.jpg>)**适用条件：毒牙祭坛（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；密谋小径（未启用）；虚空之痕竞技场（未启用）。**

![Soothe Talented](<https://static.icy-veins.com/images/wow/classes/druid/icons/soothe.jpg>)**适用条件：毒牙祭坛（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；密谋小径（启用）；虚空之痕竞技场（启用）。**

‌

![No Shapeshift uses](<https://static.icy-veins.com/images/wow/classes/druid/icons/cat.jpg>)**适用条件：毒牙祭坛（未启用）；Blinding Vale（未启用）；纳洛拉克的洞穴（未启用）；诸王之眠（未启用）；红玉新生法池（未启用）；虚空之痕竞技场（未启用）。**

![Shapeshift uses](<https://static.icy-veins.com/images/wow/classes/druid/icons/cat.jpg>)**适用条件：毒牙祭坛（启用）；Blinding Vale（启用）；纳洛拉克的洞穴（启用）；诸王之眠（启用）；红玉新生法池（启用）；虚空之痕竞技场（启用）。**

- **适用条件：毒牙祭坛（启用）。** [[spell:768]] 变形解除定身/缠绕：
  
  
  
  
  - 清除 [[spell:1296069]]，在 **拉维** 首领战斗中。
  - 从 [[spell:1310974]] 中清除 **扭缠盘蛇**.
  - 从 [[spell:1294569]] 中清除 **双牙折磨者**.
- **适用条件：毒牙祭坛（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散 [[spell:1307571]]，来自 **高级进化者**.
  - 驱散 [[spell:1307567]]，来自 **乌拉特克的选民**.
- **适用条件：毒牙祭坛（启用）。** [[spell:2908]] 使用：
  
  
  
  
  - 驱散 [[spell:1306338]]，来自 **贪婪的后裔**.
- **适用条件：Blinding Vale（启用）。** [[spell:768]] 变形解除定身/缠绕：
  
  
  
  
  - 从 [[spell:1238084]] 中清除 **鞭笞者** 如果你在近战中被击中。
- **适用条件：Blinding Vale（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散 [[spell:1250937]]，来自 **土豆蟾蜍女族长**.
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:768]] 变形解除定身/缠绕：
  
  
  
  
  - 从 [[spell:1309919]] 中清除 **严寒殴斗者**.
  - 从 [[spell:1241463]] 中清除 **天神下凡之决心**.
  - 从失败的 [[spell:1263590]] 中清除 **碎霜** 站位中清除。
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散由召唤的雕像施加的 [[spell:1238760]] **猎人之魂**.
  - 在 [[spell:1234233]] 期间驱散 **囤宝狂人** 首领战中。
- **适用条件：纳洛拉克的洞穴（启用）。** [[spell:2908]] 使用：
  
  
  
  
  - 驱散 [[spell:1238053]]，来自 **领地母族长**.
  - 驱散 [[spell:1246865]]，来自 **结伴的驯兽师**.
- **适用条件：诸王之眠（启用）。** [[spell:768]] 变形解除定身/缠绕：
  
  
  
  
  - 从 [[spell:1294815]] 中清除 **复生巫师**.
  - 清除由施加的 [[spell:106823]] **帕特拉女王**.
  - 清除由施加的 [[spell:271563]] **防腐液**.
  - 清除由施加的 [[spell:12548]] **幽灵萨满祭司**.
- **适用条件：诸王之眠（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散 [[spell:269972]]，由施放 **复生巫师**.
  - 驱散 [[spell:270492]]，由施放 **幻影妖术牧师**.
  - 驱散 [[spell:106823]]，来自 **帕特拉女王**.
  - 驱散 [[spell:271563]]，来自 **防腐液**.
  - 在 [[spell:267273]] 期间驱散 **部族议会** 首领战中。
- **适用条件：诸王之眠（启用）。** [[spell:2908]] 使用：
  
  
  
  
  - 驱散 [[spell:269976]]，来自 **暗影之裔勇士**.
  - 驱散 [[spell:1297763]]，来自 **帕特拉女王**.
- **适用条件：密谋小径（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散由施加的 [[spell:1217973]] **被腐化的术士**.
  - 驱散由施加的 [[spell:474515]] **街头潜行者**.
  - 在 [[spell:1222795]] 期间驱散 **赞恩·刃悲** 首领战中。
- **适用条件：密谋小径（启用）。** [[spell:2908]] 使用：
  
  
  
  
  - 驱散 [[spell:1216970]]，来自 **敏锐监工**.
  - 驱散 [[spell:1214922]]，来自 **愤怒守卫剥皮者**.
- **适用条件：红玉新生法池（启用）。** [[spell:768]] 变形解除定身/缠绕：
  
  
  
  
  - 从 [[spell:373803]] 中清除 **灌能雏龙** 如果你在近战中被击中。
- **适用条件：塞塔里斯神庙（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散 [[spell:1293307]]，由施放 **背信的征服者**.
  - 驱散由施加的 [[spell:1308100]] **蔽影尖牙**.
  - 驱散由施加的 [[spell:1308148]] **剧毒蝰蛇**.
  - 在 [[spell:267027]] 期间驱散 **米利克萨** 首领战中。
- **适用条件：虚空之痕竞技场（启用）。** [[spell:768]] 变形解除定身/缠绕：
  
  
  
  
  - 在 [[spell:1263982]] 层数中清除 **煞戎努斯** 首领战斗中。
  - 从 [[spell:1249621]] 中清除 **愤怒的克洛斯克**.
- **适用条件：虚空之痕竞技场（启用）。** [[spell:2782]] 使用：
  
  
  
  
  - 驱散 [[spell:1289265]]，由施放 **暴躁的虚空镰**.
  - 在 [[spell:1226120]] 期间驱散 **阿特洛苏斯** 首领战中。
- **适用条件：虚空之痕竞技场（启用）。** [[spell:2908]] 使用：
  
  
  
  
  - 驱散 [[spell:1254826]]，来自 **被支配的斗士**.
  - 驱散 [[spell:1310319]]，来自 **长牙海象人**.
  - 驱散 [[spell:1249661]]，来自 **狂怒的迅猛龙**.

1.

### 功能技能与能力

本节涵盖野性可使用的关键天赋和技能，这些可在大秘境中加以利用。

### 控制

4.1.

#### 打断与控制

通常，任何大秘境副本（除了你的伤害输出之外）最关键的环节，就是你打算如何阻止危险的敌人施法。野性在单体和群体打断方面都有一些不错的选择：

4.1.1.

##### 单体控制

**[[spell:106839]] –** 野性的打断技能，冷却时间15秒，射程13码，并附带一个小冲锋。应经常使用它来打断危险的施法，也可以利用冲锋在远距离重新接近目标。不过从远处使用时要小心，避免冲进危险之中。

**[[spell:339]] –** 一个软控制选项，适用于想让敌人保持在射程之外的情况。但记住被缠绕的敌人仍然可以施法和攻击。这也可以通过 [[spell:16974]] 触发变为瞬发。

**[[spell:48484]] –** 由你的 [[spell:1822]] 技能被动施加，使目标减速20%，持续12秒。与同类效果相比是非常弱的减速，但它是被动施加的，适合风筝。

**[[spell:22570]] / [[spell:5211]] –** 两个天赋，可对目标提供指向性眩晕。虽然在天赋树上难以取舍，但当你需要额外控制时，它们总是备选方案。

**[[spell:2637]] –** 一种硬控制，仅限野兽或龙类，施法时间1.5秒，射程30码。使用后，目标沉睡最多40秒，但受到伤害会打破该效果。

**[[spell:33786]] –** 一种紧急控制工具，将目标放逐6秒，使其无法行动，同时免疫所有伤害和治疗效果。可用于短暂控制危险目标，但其1.5秒的施法时间和递减效果使其最多只能算作冷门选择。

4.1.2.

##### 群体控制

**[[spell:102793]] –** 锁定目标区域内的敌人，如果他们试图离开（或被强制推出），会将其拉回中心。这与 [[spell:132469]] 有很好的协同作用，通过将所有被推向中心的敌人聚集在一起，起到伪群体拉怪的作用。

**[[spell:132469]] –** 可以将敌人击退，打断施法。也可以将目标从地面效果中强制推出。

**[[spell:99]] –** 一种范围迷惑效果，主要用于打断敌人的施法。由于冷却时间很短，它在面对大量敌人时极其有用，但会使你进入[[spell:5487]]，因此会造成伤害损失。记住你可以利用[[spell:449193]]通过使用[[spell:5221]]快速重新进入[[spell:768]]。

### 防御与辅助治疗

4.2.

#### 防御手段

在控制之后，你还需要考虑如何在伤害承受极高的地下城中生存下来。这意味着在团队副本中往往处于边缘地位的天赋在这里大放异彩，让你能够度过原本致命的机制：

**[[spell:5487]] –** 使用后可以让你变身为坦克导向形态，获得[[spell:6795]]作为嘲讽效果。这在紧急情况下能提供帮助，提高你的生存能力，并让你转移坦克的压力。如果同时点出[[spell:377842]]，它可以作为短暂的额外生命值窗口，帮助你度过可能致命的机制。

**[[spell:22812]] –** 是你1分钟冷却的防御技能，提供12秒内30%的伤害减免（配合[[spell:449191]]和[[spell:327993]]）。低冷却时间加上强大的伤害减免，使它成为一个可以放心使用的手段，在任何你觉得危险的情况下都可以使用。

**[[spell:61336]] –** 是一个巨大的冷却技能，最好用于度过最致命的机制。它提供的高达60%的伤害减免（配合[[spell:449191]]）非常出色，但6秒的持续时间加上3分钟的冷却时间意味着你需要明智地规划使用时机。

**[[spell:319454]] –** 有2分钟的冷却时间，与[[spell:5487]]配合时可提供持续20秒的30%生命值加成。即使你变身离开该形态，这个效果仍然存在，因此非常适合用来承受致命伤害。

**[[spell:377847]] –** 在你措手不及或在长时间内持续掉血时，能提供完美的紧急治疗。是一个很好的选择，应该始终点出。

**![](<https://static.icy-veins.com/images/wow/tools/hero-talents/druid-of-the-claw.webp>) 利爪德鲁伊 –** 即使在[[spell:768]]中也能使用[[spell:22842]]，以少量能量消耗提供大量治疗。如果你的生命值看起来不稳定，这将非常强大。

4.3.

#### 辅助治疗手段

野性也有一套小工具可以在治疗者吃力时帮助团队进行治疗：

**[[spell:16974]] –** 使你在使用5星终结技后可以立即施放[[spell:8936]]或[[spell:339]]。这有助于辅助治疗，或提供紧急的群体控制。

**[[spell:319454]] –** 在任何变身形态之外施放时，会对你的团队施加强化的[[spell:48438]]。虽然其治疗量不足以证明2分钟冷却时间的合理性，但它可以在紧急情况下提供帮助。

### 驱散与其他功能

4.4.

#### 驱散

许多地下城都有驱散需求来应对特定机制，而你不能仅仅依赖治疗者来处理所有驱散。野性有两个可以在需要时点出的技能：

**[[spell:2782]] –** 对目标友方驱散诅咒和中毒减益效果，冷却时间为8秒。如果你的治疗者无法自行驱散这两种效果，这将特别有用。

**[[spell:2908]] –** 一种进攻性的激怒效果驱散技能。射程40码，冷却时间10秒，可以在[[spell:768]]中使用。对于任何有激怒效果的地下城中的任何团队来说，这都极具价值。

4.5.

#### 其他功能

最后，德鲁伊拥有一些独特的工具，在进行大秘境时需要牢记：

**[[spell:1126]] –** 为你的团队提供3%全能，任何德鲁伊都会自带此光环。配合[[spell:1262034]]，对你自己会提升至6%。记得在每个地下城开始时（或者在你或队友死亡后）补上这个增益！

进出[[spell:768]]（或你的任何其他变身效果）的动作也会解除定身效果，这在应对某些机制时会很有帮助。

**[[spell:449193]] –** 一个很有用的天赋点，因为有许多功能手段会将你踢出[[spell:768]]。这意味着你可以通过施放[[spell:5221]]快速回到输出状态，而不用手动变身浪费一个GCD。一个非常舒适的点法选择。

**[[spell:29166]] –** 对帮助你的治疗者极其有用，在短时间内提供额外生成的法力值。在第2赛季的改动之后，这不需要太多协调就可以使用，只要在他们资源枯竭时给他们即可。

**[[spell:106898]] –** 为你和15码范围内的所有盟友提供额外移动速度。这对于粘住目标、帮助盟友躲避危险效果或更快地赶往下一波怪非常有用。

**[[spell:20484]] –** 一种战斗复活效果，允许你在战斗限制之外复活一名玩家，以应对意外死亡。这需要你离开[[spell:768]]。

1.

### 应对词缀

### 词缀：升腾

5.1.

#### 升腾词缀处理

**萨拉塔斯的交易：升腾** 会定期生成一波波的光球，需要以某种方式对其进行群体控制，阻止它们完成施法。每成功阻止一个光球，团队就会获得急速加成，因此处理它们是高度优先事项。

野性应利用[[spell:99]]和[[spell:132469]]，如果瞄准得当，在光球开始生成时可以清除大量光球。

### 词缀：虚缚

5.2.

#### 虚空绑定词缀处理

**萨拉塔斯的交易：虚缚** 会周期性地召唤一个大型的虚空大使，它将开始施放[[spell:462508]]。这个敌人 **必须** 在施法完成前被击杀以阻止它，否则它会为附近的敌人提供显著的减伤。如果成功阻止，队伍将获得大量的全能和冷却缩减。

这需要尽快击杀，因此理想情况下，当它生成时拥有像[[spell:5217]]这样的短时间爆发冷却技能或一些连击点数储备，会让团队轻松得多。

### 词缀：脉冲星

5.3.

#### 脉冲星词缀处理

**萨拉塔斯的交易：脉冲星** 会生成一个围绕每个玩家旋转的光球，需要由另一名玩家在光球消失前分担。每个光球将为队伍提供4%精通和2%吸血，可叠加，持续30秒。未被分担的光球会增加附近敌人的伤害输出，并降低他们受到的伤害。

野性没有特定的功能来处理这个。相反，你需要注意自己的站位，既要确保其他玩家可以吸收绕着你转的光球，也要让你能接住附近玩家的光球。

### 词缀：吞噬

5.4.

#### 吞噬词缀处理

**萨拉塔斯的交易：吞噬** 会对每名队伍成员施加一个减益效果，必须通过驱散或治疗来消除（但请注意这 <em>不会</em>
吸收即将到来的治疗）。每驱散一个减益效果都会为队伍提供最大生命值和暴击，可叠加，持续30秒。任何被 <em>非</em>
清除的减益效果都会为附近的敌人恢复大量生命值。

在这些周，我们建议点出[[spell:2782]]，通过立即为自己解除该效果来帮助你的治疗者。离开[[spell:768]]变身也会移除它，因为在至暗之夜中该效果已添加了一个小幅减速。最后，如果这不可行，当治疗者吃力时，[[spell:22842]]可以快速覆盖大量治疗需求。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已为至暗之夜第1赛季的发布进行更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对新的职业天赋树天赋门槛进行更新。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月28日：** 添加了大秘境实用天赋速查表，涵盖各副本中的使用场景。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月28日：** 添加了各个副本的提示。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7版本进行审查，修正了利爪德鲁伊天赋树链接并添加了推荐标签。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为地心之战第1赛季的发布进行更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，将推荐改为聚灵，并添加了关于2分钟饰品的说明。
- **2023年11月10日：** 已为10.2版本重构并更新。
- **2023年11月6日：** 已更新大秘境中心的链接。
- **2023年9月4日：** 已针对10.1.7版本进行审查，将推荐配装改为更侧重撕碎的方案。
- **2023年7月10日：** 已为10.1.5版本更新，并在配装中添加了凶猛凝视。
- **2023年5月1日：** 已根据10.1补丁更新，小幅度调整了天赋方案并添加了新的词缀详情。
- **2023年3月20日：** 已根据10.0.7补丁审查并更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些有用的宏命令和插件，以便在《魔兽世界》12.1.5补丁中游玩你的野性德鲁伊时让游戏体验更轻松。

1.

### 最佳宏

欢迎来到我们的插件和宏命令页面。在这里我们将介绍一些有用的插件，你可以通过更具信息量的界面来提升你的游戏体验，同时提供一些常用的野性德鲁伊宏命令。

1.

### 野性德鲁伊宏命令

宏命令可以通过游戏内的/macro命令访问，允许你创建在按下快捷键时执行的小型脚本。这对于将多个动作组合在一起非常有用，一个常见的例子是将不占用GCD的饰品与冷却技能组合在一次按键中使用。

2.1.

#### 复生

#### 鼠标指向战斗复活

```wow-macro
#showtooltip
/stopcasting
/cast [@mouseover,help]复生;复生
```

这个宏会对你的鼠标悬停目标施放[[spell:20484]]，如果他们是友方玩家的话。否则，它会对你的当前目标施放复生。

2.2.

#### 清除腐蚀

#### 鼠标指向驱散

```wow-macro
#showtooltip
/cast [target=mouseover,help,nodead][target=target] 清除腐蚀
```

使用此宏会对你的鼠标指向目标施放[[spell:2782]]，前提是该目标是友方玩家且未死亡。否则，它会对你的当前目标施放清除腐蚀。

2.3.

#### 迎头痛击焦点打断

这会将你的打断技能指向你的焦点目标，这样你就不需要为关键施法切换目标。请注意，你需要事先通过/focus宏设置好焦点才能使用此功能。

#### 焦点打断

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] 迎头痛击
```

2.4.

#### 激活宏命令

在治疗者需要时快速施放[[spell:29166]]有两种选择。你可以选择将你的指定治疗者设为焦点，并使用此宏对他们施放：

#### 焦点激活

```wow-macro
#showtooltip
/cast [@focus,nodead], [@target,nodead] 激活
```

或者使用鼠标指向宏，在你的队伍/团队框架上高亮选中他们：

#### 鼠标悬停激活

```wow-macro
#showtooltip
/cast [@mouseover,nodead], [@target,nodead] 激活
```

否则，这两个宏在使用时都会默认对你的当前目标施放。

2.5.

#### 乌索尔旋风接台风

此宏可作为施法序列绑定在同一个快捷键上，依次施放[[spell:102793]]和[[spell:132469]]，通过两次按键伪拉怪。@cursor用于将旋风瞬间放置在你的光标位置，如果你想手动放置可以移除它，或者将其替换为@player以将其放置在你自己脚下：

#### 乌索尔接台风

```wow-macro
#showtooltip
/castsequence [@cursor] reset=20 乌索尔旋风, 台风
```

1.

### 最佳插件

你的大部分界面需求可以通过至暗之夜中新的暴风雪界面选项在一定程度上得到满足，但如果你想要一些额外的自定义，以下是一些热门选择。

3.1.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) 是对默认用户界面的完整替代。它包含了你正常发挥所需的几乎所有功能：动作条、单位框体、冷却计时器、触发提示等。

3.1.1.

##### 首领模块插件：Deadly Boss Mods 或 Bigwigs

首领模块插件会警告你首领的技能，并就如何处理某些机制提供实时建议。我们强烈建议你安装这样一个插件。在Icy Veins，我们主要使用
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>)，这是最受欢迎的首领模块插件。一个不错的替代选择是
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 已针对第1赛季发布进行审查。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年10月21日：** 已针对11.0.5版本进行审查。添加了关于愈合变形宏的一些说明。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5版本进行审查，无需更改。
- **2023年11月6日：** 为10.2版本添加了激活宏。
- **2023年9月4日：** 已针对10.1.7版本进行审查，无需更改。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年4月29日：** 已根据10.1补丁审查，无需更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 添加了一些额外的鼠标悬停和天赋宏。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
