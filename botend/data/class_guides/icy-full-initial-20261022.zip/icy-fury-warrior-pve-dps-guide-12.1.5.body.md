## 专精概览

欢迎来到我们为《魔兽世界》12.1.5补丁编写的 狂怒 战士 攻略。在这里，你将学习如何在团队副本和大秘境地下城中玩好 狂怒 战士：从最基础的开始，直到将你的伤害输出最大化。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

狂怒 大秘境资源

[全新！顶级 狂怒 天赋构建](<https://raider.io/specs/fury-warrior/talents>)

[顶级 狂怒 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warrior/fury>)

[狂怒 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warrior--fury>)

[热门 狂怒 团队配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warrior--fury>)

1.

### 狂怒 战士 概览

狂怒 战士是非常活跃的、受公共冷却时间限制的输出职业，拥有快速而直接的循环，围绕着生成怒气并将其消耗于 [[spell:184367]] 以维持 [[spell:184361]]。与一些职业相比，它的循环相对简单，但相关的急速增益使 狂怒 成为游戏中操作频率最高的专精之一，证明了玩法并不一定需要复杂才能引人入胜。

除了全面的进攻手段外，狂怒 还拥有高机动性、中等的自我治疗能力，以及游戏中少数几个团队范围的防御性冷却技能之一。然而，他们最大的弱点来自于近战范围的固有限制，以及缺乏免疫或免死机制。

全能选手

狂怒 战士拥有强大的工具箱，持续输出能带来丰厚回报，拥有强大的持续单体伤害，可以轻松顺劈，以及数个多目标冷却技能。它在各种内容中表现相当出色，尽管伤害需要时间预热，在异常短暂的战斗或有大量空闲时间的战斗中可能会吃亏。

Add Sniper

狂怒战士拥有一套非常强大的多目标输出工具组，在面对频繁出现的大规模小怪群时表现出色，但在维持单体目标伤害方面较为吃力，尤其是在具有复杂移动和停手时间的战斗中。其伤害曲线也并非特别偏向爆发，这在某些战斗中可能成为一个劣势。

Trash Master

狂怒 战士在大秘境中通常表现出色，这得益于其常规循环易于顺劈，而不是专注于纯单体或多目标能力。尽管缺乏纯单体或漏斗伤害，但更平稳的伤害曲线有利于持续的连锁拉怪，而不是一次性的大爆发。

众多次要效果

战士在功能性方面历来非常艰难，拥有若干在现代绝大多数内容中完全不必要的效果。[[spell:384100]]、[[spell:64382]]、[[spell:384110]]、[[spell:376079]]和[[spell:12323]]看似都是有用的效果，但它们的机制在现代内容中出现频率太低，以至于很少甚至从未被使用。

不过，战士在至暗之夜中获得了一些改进。[[spell:97462]]在小型队伍内容中得到了增强，不再需要太担心递减效应意味着昏迷可以更自由地使用，而且新增的远程沉默也提供了特定情况下的价值。

非常肉

狂怒 战士拥有卓越的生存能力，通过数个短冷却的防御和治疗技能，这些技能可以独立使用以覆盖多种效果，或者叠加使用以显著降低大型攻击的威胁。

尽管现在更难通过天赋点出 [[spell:184364]]，[[spell:23920]] 可以直接免疫多种效果，而 [[spell:386208]] 和 [[spell:208154]] 是整个游戏中最可靠的减伤来源之一，不过需要注意的是 战士 的生存能力本质上非常依赖预判。

这要求玩家具备敏锐的意识，对于那些拥有真正免疫或免死技能的职业本可以承受的失误，几乎没有恢复的余地。

爆发性移动技能按冷却使用

在[[spell:6544]]、[[spell:100]]和[[spell:3411]]之间，战士拥有非常好的机动性，只要存在合适的路径或目标。

1.

### 狂怒 战士 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁包含两项新的终局内容：基斯伊克斯的解放团队副本战斗，以及扩展的巨型探窟——金多詹迷宫！这两项活动都包含新的挑战、成就和奖励，你可以在我们的专属页面了解更多。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5 补丁

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

12.1.5补丁中没有 狂怒 战士 的改动，不过我们的 [装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>) 已根据基希克斯之缚团队副本的新建议以及使用 [[item:280562]] 的指南进行了更新。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_cleave.jpg>) 点击查看上赛季第二赛季的改动
2.4.

#### 补丁12.1职业改动

进行了大量的 狂怒 战士 改动，旨在重新平衡并创造新的玩法选择，使撕裂成为更被动的伤害来源，通过移除暴怒破坏的负面效果来增强多目标能力，更加强调雷霆之击，并更好地支持以怒击而非嗜血为主的构建。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**战士**

<em>开发者说明：撕裂是一个标志性的核心战士技能，与每个专精有着不同的关系。我们在至暗之夜中对撕裂的处理方式没有达到预期，因此我们正在改变每个专精在乌拉特克诅咒中施加和与撕裂互动的方式。</em>

- **职业**
  
  
  
  
  - 新天赋（狂怒）：鲜血风暴 鲜血 – 旋风斩对所有目标施加撕裂。碎裂雷霆使鲜血风暴 鲜血 也能在 山丘领主 的雷霆一击上生效。
  - [[spell:6343]]在学会后不再自动施加撕裂。
  - [[spell:1271948]]有了新的图标。
- **英雄天赋**
  
  
  
  
  <em>开发者说明：在 至暗之夜 中雷霆一击的基础伤害显著增加，导致 山丘领主 的雷霆一击总伤害显著上升，这反过来降低了雷霆之击的价值。我们将碎裂雷霆的伤害加成移入雷霆之击本身，以保持雷霆之击的特殊和强大感。</em>
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主：[[spell:435607]] 伤害提高20%。
  - [[spell:135150]] 使雷霆一击伤害提高10%（原为30%）。
  - [[spell:436148]] 伤害提高150%。
- **狂怒**
  
  
  
  
  <em>开发者说明：旋风斩历来是 狂怒 玩法的核心部分，即使在单体目标情况下也是如此。我们希望为旋风斩再次成为单体目标中有用的技能打开大门。</em>
  
  
  
  
  - [[spell:1261051]]已重新设计——巨神兵 猛击立即提供1次突然死亡的使用次数。
  - 新天赋：[[spell:1300463]] – 当旋风斩只击中一个目标时，造成的伤害提高50%。
  - [[spell:1680]] 已更新 – 旋风斩现在本身产生3点怒气。
  - [[spell:12950]] 已更新 – 不再使旋风斩本身产生3点怒气，但仍会使旋风斩产生的怒气每击中一个目标增加1点，最多总计8点怒气。
  - [[spell:1265357]] 已重新设计 – 在强化旋风斩激活期间，暴怒的最后一击会猛击地面，对目标8码范围内的所有敌人造成物理伤害。超过5个目标时伤害降低。
  - [[spell:383877]] 已更新 – 暴怒现在有75%的几率返还一次怒击的使用次数，并使你下一次怒击的伤害提高20%。
  - 浴血 initial damage reduced by 12% and bleed damage increased by 300%.

:::

### 至暗之夜改动概述

2.5.

#### 至暗之夜改动概述

狂怒 战士在 至暗之夜 中经历了重大改动，重新设计或完全移除并替换了数个天赋，同时新强调了保持 [[spell:23881]] 处于冷却状态。以下是关于最具影响力的改动及其如何影响新资料片玩法的总体概述。

2.6.

#### 英雄天赋改动

每位英雄在90级前获得三个新天赋，尽管它们相当直接，玩法风格没有显著变化。最值得注意的更新是 屠戮者，[[spell:444775]] 现在每次施放技能都有更新的触发几率，并由 [[spell:280721]] 触发。

2.7.

#### 输出循环变化

除了少数新的天赋效果外，总体玩法与《地心之战》非常相似，不过 [[spell:23881]] 和 [[spell:184367]] 现在对所有英雄和循环的优先级都显著提高了。

- 怒气生成已减少，这降低了暴怒的频率，但除此之外对整体循环影响不大。
- [[spell:1265357]] 是一个新天赋，旨在提高超出常规目标上限的多目标效率，不过它会在击中较少数量的目标时降低暴怒的常规伤害，这使其成为一个非常小众的选择。
- [[spell:81099]] 已被移除，不过 [[spell:81099]] 是一个新被动，允许 狂怒 战士幻化单手武器外观，这是一个长期被要求的选项，解决了武器类型之间的差异。
- 没有任何 狂怒 战士 套装加成被保留，导致总体上猝死和雷霆之击的触发减少，不过深度 wounds 的加入鼓励两位英雄比以前更频繁地使用 斩杀。

2.8.

#### 巅峰天赋：暴怒狂战士

现在有一个新的四点专精专属 Apex 天赋节点可用。[[spell:1269308]] 是一个主要被动的增益，由 [[spell:184367]] 以与 [[spell:1264934]] 相同的方式触发。

- 第一点每次施放暴怒时触发 [[spell:106951]] 增益，被动提高力量。虽然该增益可以叠加，但每次都有自己的持续时间，导致增益不断叠加和衰减，使其容易被动地处理和忽略。
- 第二点和第三点被动提高暴怒的伤害，并在 鲁莽 期间降低其怒气消耗。这使得强大的攻击可以更频繁地使用，并在冷却窗口期间将狂乱增益叠加得更高。
- 最后一点增加 鲁莽 的持续时间，并在使用冷却技能时给予三层狂乱，进一步增强其伤害潜力。

2.9.

#### 生存能力改动

战士在自我治疗和生存能力方面有了一些小的改进，尽管移除 WeakAura 追踪使得 [[spell:23920]] 更难有效使用。

- [[spell:1271926]]提高受到的治疗量。
- [[spell:29838]]现在在生命值低于35%时治疗量翻倍。
- [[spell:1280961]]显著提高了[[spell:386208]]的价值，使其成为一个非常强大的小型冷却技能。

2.10.

#### 功能性改动

虽然没有重大的新效果或技能，但战士在新资料片中在团队功能性方面有了一些改进。

- [[spell:97462]] 集结呐喊现在在小队内容中提供更大的加成。
- 在PvE内容中，敌人在多次眩晕后不再变得免疫，使它们可以更自由地使用。
- [[spell:1271948]]现在使[[spell:384110]]充当远程沉默技能，尽管冷却时间较长。
- [[spell:12323]]现在为盟友提供短暂的移动速度增益，这对对抗机制并不特别重要，但对减少拉怪之间的空闲时间很有用。

1.

### 狂怒 战士 玩法基础

狂怒 战士是一个快节奏的专精，几乎没有空闲时间，使其非常活跃和引人入胜。由于几乎每个主动技能都会产生怒气，玩法围绕着使用这些技能来积累怒气，以便使用 [[spell:184367]]，将该怒气转化为 [[spell:184361]]，提高造成的伤害，并触发急速增益，使循环更快。

暴怒通常能独立维持激怒的高覆盖率，不过可以通过嗜血及相关天赋、[[spell:215568]] 或 [[spell:383295]] 来补充。这也许是有效玩好 狂怒 战士 最重要的一个方面，所以要确保增益始终处于激活状态。

狂怒 战士 玩法最好用下面的三个关键概念来描述。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **避免空闲时间**
  
  
  
  
  狂怒 的大部分怒气来自冷却时间较短的技能，因此减少追逐、跑开机制或以其他方式不攻击目标的时间，对于最大化表现至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_innerrage.jpg>) **保持技能冷却**
  
  
  
  
  狂怒 大量消耗怒气，这也是维持激怒的主要方式，因此最大化技能施放次数以生成和消耗尽可能多的怒气，对于保持高覆盖率至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **避免浪费怒气**
  
  
  
  
  与大多数资源不同，怒气从零开始并在脱离战斗时衰减。有效且高效地使用它将有助于维持循环并消除等待更多资源的空闲时间，无论是在战斗中还是通过减少从一场战斗到另一场战斗的移动时间。

1.

### 如何为 狂怒 战士 配装

虽然我们始终建议你自己进行模拟以获得理想结果，但我们确实提供了专门的 狂怒 配装页面。我们目前涵盖第二赛季装备的建议，以便在 至暗之夜 终局内容发布时顺利起步。一旦你获得了一些装备，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了12.1.5补丁的装备推荐，并添加了关于毒石的新章节。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 更新了推荐的武器附魔和药水描述，以说明特殊情况下的属性问题。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月25日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 调整了 山丘领主 天赋。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 更新了12.1补丁的升级天赋配置。
- **2026年8月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了12.1补丁的所有装备推荐。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 更新了12.1补丁的宝石、武器附魔和治疗药水。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 更新了12.1补丁的配置推荐。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了12.1补丁的天赋构建。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已为12.1补丁更新。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 在12.0.7补丁中添加了孢化装备。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 在12.0.7补丁中添加了万卷之典能力。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月23日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了备选大秘境配置和多个配置描述。
- **2026年4月22日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 添加了多目标团本天赋配置。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月6日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为鲁莽药水添加了免责声明。
- **2026年4月6日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为鲁莽药水添加了免责声明。
- **2026年4月6日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 调整了战斗怒吼的描述。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 添加了关于使用纹章升级物品的章节。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为至暗之夜上线进行了更新。
- **2026年2月26日（本页）：** 为至暗之夜上线进行了更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 更新了12.0.1补丁的升级天赋配置。
- **2026年2月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 单体目标 屠戮者 现在使用 天神下凡。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了12.0.1补丁的配置。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026 年 1 月 20 日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了推荐的天赋构建。单体目标 屠戮者 现在使用 天神下凡。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁添加了新的常见问题解答部分。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为11.2.7补丁添加了常见问题解答部分。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁添加了新的优劣势组件。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 添加了迪纳尔，更新了推荐饰品，并为涡轮增压提高了物品等级。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 添加了11.2.5补丁的改动。
- **2025年9月6日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为未公布的热修复进行了更新。
- **2025年9月6日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为未公布的热修复更新了多目标 屠戮者 循环。
- **2025年9月6日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了天赋构建以反映未公布的热修复。
- **2025年9月6日（本页）：** 添加了热修复说明。
- **2025年8月25日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 新增了临时强化，并扩充了关于武器附魔的说明。
- **2025 年 8 月 10 日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 添加了突然死亡辅助WeakAura。
- **2025 年 8 月 10 日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 澄清了关于天赋选择的解释。
- **2025 年 8 月 10 日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已根据第3赛季的循环变化进行更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 在11.1.7补丁中添加了复苏的治疗内容。
- **2025年6月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为11.1.7补丁添加了泰坦神装DISC腰带。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为11.1.7补丁添加了战斗助手部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为11.1.7补丁添加了战斗助手部分。
- **2025年6月15日（本页）：** 添加了11.1.7补丁的改动。
- **2025年5月12日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了装备列表，添加了代币购买优先级。
- **2025年5月12日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 对腐蚀部分进行了小幅更新，将回响虚空作为备选方案。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 添加了11.1.5补丁的帮会代币推荐。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 添加了11.1.5补丁的腐蚀推荐。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 为加里维克斯添加了碎击投掷提示。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 将循环拆分为可切换的图片框架。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 添加了11.1.5补丁的职业改动。
- **2025年3月17日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 修复了失效的塞尔西的王冠链接，并在嵌入内容中添加了宝石。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 更多提示、天赋调整以及加里维克斯相关信息。
- **2025年3月2日（[解放安德迈页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了团队副本提示和天赋配置。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月16日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了塞尔西的王冠，以计入物品等级提升的热修。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 添加了塞尔西的王冠，并针对11.0.7补丁进行了验证。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 标记了推荐配置，并针对11.0.7补丁进行了验证。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 标记了推荐的天赋配置，并针对11.0.7补丁进行了更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 简化了循环，并针对11.0.7补丁验证了信息。
- **2024年12月15日（本页）：** 更新了11.0.7补丁中的改动。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 添加了一个简要部分，详细介绍了即将到来的时光漫游和周年庆团队副本饰品。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了 Broodtwister 和 The Silken Court 的各种提示和天赋建议。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 更新了 山丘领主 大秘境构建描述和地下城词缀建议。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了 山丘领主 大秘境构建描述。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 添加了11.0.5补丁改动的概述。
- **2024年10月3日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** Broodtwister 的更多提示和新天赋建议。
- **2024年9月23日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 安苏雷克女王的提示和建议。
- **2024年9月23日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 单体目标循环的次要更新。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 更新了职业树中的路径以更早支持英雄天赋。
- **2024年9月9日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已创建。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为地心之战第1赛季的上线进行了更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于开关的说明，并从多目标列表中移除了多余的括号。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为《地心之战》第一赛季发布更新了构建。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 新增了地下城（Delve）天赋配置，并进行了少量天赋更新。
- **2024年8月22日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 更新了升级构建。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为地心之战季前赛的上线进行了更新。
- **2024年8月21日（本页）：** 为地心之战季前赛的上线进行了更新。
- **2024年7月31日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 更新单体目标剑刃风暴优先级。
- **2024年7月26日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 根据最近的调整，推荐单体目标使用长矛而非咆哮。
- **2024年7月26日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为解决有 bug 的天赋，对构建进行了次要更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/fury-warrior-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为地心之战前夕补丁进行了更新。
- **2024年7月23日（本页面）：** 为地心之战前夕补丁进行了更新。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/fury-warrior-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月12日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 更新了天赋配置和法术优先级。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为第四赛季更新了嗜血 Weak Aura。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为第四赛季更新了装备和铸币建议。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为第4赛季进行了更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为第四赛季更新了天赋和循环建议。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 对简介进行了小幅更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为第四赛季更新了天赋建议。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为第四赛季更新了天赋和循环建议。
- **2024年4月22日（本页）：** 更新了第四赛季的改动。
- **2024年3月25日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 对升级天赋树进行了小幅调整，并为10.2.6补丁进行了更新。
- **2024年3月19日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 移除了旧的WeakAuras，添加了新的，并为10.2.6补丁进行了审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 扩展了专业制造推荐，并为10.2.6补丁进行了审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年2月15日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年2月15日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2024年1月14日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 将菲莱克巨剑添加到整体毕业列表中（祝你好运）。
- **2024年1月14日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 添加了一个强调正确使用菲莱克巨剑的部分。
- **2024年1月14日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 对配置选择工具中推荐天赋的说明进行了小幅更新。
- **2024年1月14日（本页）：** 10.2.5补丁改动概述。
- **2023年11月8日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了新的装备套装，以计入孢子披风的削弱。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为10.2版本进行了审查。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为第3赛季做准备，更新了T31配置和循环。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为10.2补丁和第3赛季套装更新了天赋配置。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已更新至 10.2 补丁。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已为10.1.7版本审核。
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已为10.1.7版本审核。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已为10.1.7版本审核。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为10.1.7版本审核。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已为10.1.7版本审核。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已为10.1.7版本审核。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已为10.1.7版本审核。
- **2023年9月4日（本页）：** 已为10.1.7版本审核。
- **2023年7月12日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 小幅格式更新。
- **2023年7月12日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 小幅格式更新。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为10.1.5补丁进行了更新，以包含永恒黎明的装备。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 为10.1.5补丁进行了更新，将震荡波作为推荐天赋纳入。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 为10.1.5补丁进行了小幅更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（本页）：** 更新了10.1.5补丁无职业改动的信息。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为10.1补丁进行了审查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了玛瑙指环的宝石推荐。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 更新了玛瑙指环的宝石推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行了小幅说明更新。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 更新了更优的猛击流派。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁更新，使复选框选项更加清晰。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了更优的猛击流派。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 为10.1补丁进行了审查。
- **2023年5月1日（本页）：** 已为10.0.7补丁更新。
- **2023年4月4日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 切换到新的按等级天赋计算器格式。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/fury-warrior-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已更新至10.0.5补丁。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 10.0.5补丁已更新构筑。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 10.0.5补丁已更新多个构筑。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 天赋构筑已更新至10.0.5补丁。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 修复天赋选择器的格式。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 为巨龙时代上线进行了复查。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月18日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 更新了无畏冲锋和泰坦之怒的使用方式及说明。
- **2022年11月18日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 更新了无畏冲锋和泰坦之怒的说明。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/fury-warrior-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/fury-warrior-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/fury-warrior-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/fury-warrior-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[WeakAuras页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-weak-auras>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月21日（[9.2版本分析](<https://www.icy-veins.com/wow/fury-warrior-patch-9-2-changes-analysis>)):** 本页已审核并批准用于9.2补丁。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/fury-warrior-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/fury-warrior-patch-9-1-changes-analysis>)):** 已针对9.1.5补丁进行审核和批准。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/fury-warrior-patch-9-1-changes-analysis>)):** 移除了PTR相关内容。
- **2021年5月19日（[9.1 补丁分析](<https://www.icy-veins.com/wow/fury-warrior-patch-9-1-changes-analysis>)):** 使用9.1补丁的初步信息创建了本页。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月29日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-the-eternal-palace-raid-guide>)):** 新增了更多提示，更新了推荐天赋和精华，不再推荐世界之魂共鸣。
- **2019年7月13日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-the-eternal-palace-raid-guide>)):** 增加了更多技巧，尤其是针对艾萨拉的；更改了数个精华推荐。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-the-eternal-palace-raid-guide>)):** 页面已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月9日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 增加了额外的史诗难度技巧。
- **2019年4月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 更新了史诗难度天赋建议。
- **2019年4月15日（[奥杜尔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已经过审查，对于风暴熔炉团本的发布无需更改。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年1月22日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 增加了新的技巧。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 指南已创建。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-battle-of-dazar-alor-raid-guide>)):** 修正错误——将推荐天赋从屠杀改为大屠杀。
- **2019年1月18日（[奥杜尔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** 已更新至第2赛季。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** 已审核并更新至8.1补丁。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** 已更新至奥迪尔开放。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-uldir-raid-guide>)):** 已添加页面（目前为空）。

显示更多

显示更少

:::

## 练级

在本页中，您将找到我们的狂怒 战士逐级练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[战士练级指南](<https://www.icy-veins.com/wow/warrior-leveling-guide>).

1.

### 狂怒 战士练级指南——至暗之夜

狂怒 战士是一个非常简单直接的练级专精，起步稍慢，但在17级左右会获得实用的多目标技能，并且拥有非常强大的自我恢复能力。

度过那个阶段后，战士开始变得相当强力，凭借[[spell:208154]]减免伤害和[[spell:34428]]回复生命值，可以经常将多个怪物拉到一起无惧地顺劈击杀。通过轮换多个输出冷却技能，狂怒战士最终可以在一波接一波的战斗中持续作战，几乎不需要停歇。

只要能够，始终使用[[spell:100]]发起战斗，并根据需要使用[[spell:57755]]或[[spell:6544]]拉更多的怪。面对多个敌人时，先使用[[spell:1680]]，这样[[spell:23881]]、[[spell:85288]]、[[spell:5308]]和[[spell:184367]]就能顺劈到多个目标。

一旦解锁，由于冷却时间较短，[[spell:385059]]可以经常使用，而像[[spell:1719]]这样冷却时间较长的技能则可以留给更大的怪群或更棘手的目标。

[[spell:1231418]]技能可以在战斗之间快速恢复生命值，无需携带等级对应的食物，因为它总是恢复最大生命值的50%。

1.1.

#### 升级装备选择

练级时，装备物品等级最高的装备通常是理想的。这一规则的主要例外是一些具有两项副属性而非仅一项的饰品和戒指或项链。

使用传家宝物品时，我们推荐使用带有暴击和急速属性的传家宝，因为它们会在练级期间略微改善怒气循环。

1.2.

#### 至暗之夜升级实用消耗品

在每个新资料片开始时，每个人心中最关心的事情就是如何达到最高等级。对于至暗之夜，最高等级是90级。有各种物品可以提升你的练级速度和效率，让你充分利用游戏时间。

- [[item:132516]]——巨大的移动速度提升，在坐骑无法使用时也能生效，且比地面坐骑快得多。
- [[item:109076]]——让你从悬崖边滑翔出去，快速覆盖很远的距离。
- [[item:172063]]——在你击杀敌人时给你一个速度增益。
- [[item:168412]]——别忘了这件坐骑装备，它能让你的坐骑在地面上更快。

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 武器至暗之夜练级构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDmZmZ2WmZmZMmxMzMzMzMz2MzYmxsMmZGAAIMwGssY0YGAzCGWAMDmNAYmBwgFGGMG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDmZmZ2WmZmZMmxMzMzMzMz2MzYmxsMmZGAAIMwGssY0YGAzCGWAMDmNAYmBwgFGGMG"
}
```
:::

:::details 来源计算器编码
```
#IB-CIOHnBENakz4qUCBFFxYZUsocaa85BMBD7D-EHJzu0aKiUEgwwAmAhgwUVNGw9sQxYA-AAAA-SAEYg0wsQM4QRQ-
```

:::

2.1.

#### 升级用战争模式天赋

以下PvP天赋推荐用于练级和单人/小型队伍的PvE内容。你可能会发现不同的PvP天赋更适合你的游戏风格。鼓励尝试！

1. [[spell:213915]]提升了[[spell:23920]]的价值，在冷却时间略微延长的同时提供更多的进攻和防御价值。
2. [[spell:411764]]有助于生成怒气，并更频繁地使用[[spell:184367]]。
3. [[spell:206572]]提供额外的机动性，这在练级时总是有用的。
4.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 2 起：**尽可能使用[[spell:100]]发起战斗。
2. **等级 5 起：**在击杀敌人后，通过[[spell:34428]]获得免费的伤害和治疗。
3. **等级 3–10：**如果仍然装备盾牌，使用[[spell:23922]]造成伤害。
4. **等级 72 起：**只要可用就施放[[spell:435607]]。
5. **等级 17–70：**面对多个目标时，施放[[spell:190411]]以获得强化旋风斩增益效果。
6. **等级 71 起：**面对多个目标时，施放[[spell:6343]]以维持强化旋风斩增益效果。
7. **等级 11 起：**施放[[spell:23881]]以维持[[spell:184361]]。
8. **等级 27 起：**施放[[spell:184367]]以消耗怒气并维持[[spell:184361]]。
9. **等级 37 起：**面对大型怪群或强力敌人时施放[[spell:1719]]。
10. **等级 68 起：**面对大型怪群或强力敌人时施放[[spell:107574]]。
11. **等级 55 起：**在激怒状态下施放[[spell:385059]]以造成高额爆发伤害。
12. **等级 71 起：**面对多个目标时施放[[spell:6343]]。
13. **等级 6 起：**只要可能就施放[[spell:5308]]。
14. **等级 13 起：**使用[[spell:85288]]或[[spell:335097]]作为伤害填充技能。
15. **等级 31 起：**使用[[spell:190411]]填充循环。
16. **等级 1–26：**使用[[spell:1464]]。
17.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了12.1补丁的升级天赋配置。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 更新了12.0.1补丁的升级天赋配置。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 在11.1.7补丁中添加了复苏的治疗内容。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 更新了职业树中的路径以更早支持英雄天赋。
- **2024年8月22日：** 更新了升级构建。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月12日：** 更新了天赋配置和法术优先级。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月25日：** 对升级天赋树进行了小幅调整，并为10.2.6补丁进行了更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月4日：** 切换到新的按等级天赋计算器格式。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页中，我们将介绍如何在《魔兽世界》12.1.5补丁中轻松游玩狂怒 战士，使用最简单的循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 狂怒 战士基础

欢迎来到我们的简易模式页面！本部分面向刚接触游戏或职业的玩家，他们没有参与史诗难度团队副本的打算，只想了解该专精的简明玩法，而不需要最优玩法所需的大量优先级细节。

狂怒是一个简单直接的输出职业，专注于通过自动攻击和特殊技能积累怒气，用于消耗在[[spell:184367]]上，触发[[spell:184361]]。这创造了一个持续且快节奏的游戏循环，并通过该专精内置的急速增益效果得到强化。这里展示的流派是一种简单而有效的游戏风格，适用于所有类型的游戏内容，旨在帮助新玩家学习狂怒的基础知识。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_charge.jpg>) **避免空闲时间**
  
  
  
  
  狂怒 的大部分怒气来自冷却时间较短的技能，因此减少追逐、跑开机制或以其他方式不攻击目标的时间，对于最大化表现至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warrior_innerrage.jpg>) **保持技能冷却**
  
  
  
  
  狂怒 大量消耗怒气，这也是维持激怒的主要方式，因此最大化技能施放次数以生成和消耗尽可能多的怒气，对于保持高覆盖率至关重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_racial_bloodrage.jpg>) **避免浪费怒气**
  
  
  
  
  与大多数资源不同，怒气从零开始并在脱离战斗时衰减。有效且高效地使用它将有助于维持循环并消除等待更多资源的空闲时间，无论是在战斗中还是通过减少从一场战斗到另一场战斗的移动时间。

在第2赛季中， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者在初始练级之后通常是最佳的英雄天赋，使其成为大多数内容中的首选。除了强大的优先目标伤害外，它还有一个优势，即在选择多目标天赋时，单体性能的损失非常小。

1.

### 狂怒 战士新手指南——至暗之夜

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者单体目标天赋

2.1.

#### 狂怒 战士新手单体天赋

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

单体目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 推荐屠戮者团本流派用于所有没有次要目标的战斗。

2.2.

#### 灵活天赋

由于不需要控制技能，几乎所有理想的天赋都已被选取，因此在特定情况之外没有太多更换的必要：

- 任何时候有护盾目标时，都可以用[[spell:384110]]替换[[spell:1271925]]或[[spell:1271926]]。用[[spell:1271948]]替换[[spell:1280961]]也可能值得，以牺牲一些防御收益换取远程打断能力。
- [[spell:29838]]在团队内容中用处不大，因为周期性伤害足够频繁，会打断持续治疗，尽管它偶尔可以无视某些机制。
- 如果以任何频率面对两个目标，将[[spell:184364]]换成[[spell:12950]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzYmZmlZmxMzMbGzMAAQMW2GYBMgZYCMDbAzMbGbAAwMDjxwYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShNPDGKUCBZlpxROKSM55ZaCDz7DE-EHJy0KMaik+EUgmwwAQQYess6GDWoGC-AAAA-HIcg0AEQYhhCzC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者地下城天赋

2.3.

#### 狂怒 战士新手地下城天赋

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

多目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者流派威力较小且不够稳定，取决于获得正确数量的斩杀触发，以确保剑刃风暴与其他冷却技能和[[spell:444775]]触发对齐，从而补充其多目标伤害。[[spell:1265357]]确实能使其持续多目标输出更加强大，但需要经常命中6个以上目标才值得。

2.4.

#### 灵活天赋

由于需要选择眩晕技能，天赋自定义的空间较小：

- 任何时候有护盾目标时，都可以用[[spell:384110]]替换[[spell:1271925]]或[[spell:1271926]]。用[[spell:1271948]]替换[[spell:1280961]]也可能值得，以牺牲一些防御收益换取远程打断能力。
- [[spell:184364]]仍然是一个强大的防御加成，尽管在不损失伤害的情况下很难融入流派。最好的情况是从[[spell:354479]]或[[spell:383486]]中去掉一点，但合理使用[[spell:386208]]应该能在大多数情况下使其变得不必要。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzAAAMzwYWGYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShPDGKUCBVZlpxFFRJm88MNhh59BC-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 狂怒 战士基础循环

2.5.

#### 新手狂怒 战士循环

下面概述的简化循环涵盖了使用我们推荐天赋的单体和多目标情况。虽然有些职业在单体或多目标时使用不同的技能，但狂怒战士的优势在于可以使用[[spell:12950]]将所有单体攻击顺劈出去，因此面对额外目标时请确保该增益效果始终激活。

- 面对多个目标时，只要其增益效果未激活就施放[[spell:1680]]。
- 按冷却时间施放[[spell:1719]]和[[spell:107574]]，或在需要爆发伤害时使用。
- 只要可能就施放[[spell:184367]]。
- 只要可能就使用[[spell:163201]]。
- 施放[[spell:85288]]填充循环。
- 按冷却时间施放[[spell:385059]]。
- 按冷却时间施放[[spell:23881]]。
- 如果没有其他技能可用，施放[[spell:1680]]。

与山丘领主不同，屠戮者以怒击作为主要攻击技能，不过所有流派都遵循相同的原则，即通过[[spell:184367]]将怒气转化为伤害，并维持[[spell:184361]]。其他天赋会增加额外的技能和能力，例如延长斩杀阶段，所有这些内容在本指南的高级章节中有更详细的介绍。

2.6.

#### 第2赛季套装

新的至暗之夜第2赛季套装奖励增强了[[spell:1719]]的效果，不过它需要同时使用嗜血和怒击，而大多数流派只专注于其中之一。对于屠戮者来说这非常容易，因为[[spell:386628]]会自动施放嗜血，同时手动使用怒击。山丘领主则更为复杂，因为它专注于嗜血，但仍需要在循环中找到空间，在每个冷却周期内使用三次怒击。

- [[spell:1296645]] - 怒击伤害提高15%。在鲁莽期间，怒击将鲁莽的持续时间延长2秒，最多延长6秒。
- [[spell:1296646]] - 嗜血伤害提高10%。在鲁莽期间，嗜血使鲁莽的暴击加成提高5%，最多提高10%。

2.6.1.

##### 巅峰天赋： ![Rampaging Berserker Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12_nonmasculinecharacter_orc.jpg>) 狂暴突袭者

狂怒 战士的巅峰天赋[[spell:1269308]]非常简单明了，通过三个部分被动提升鲁莽和鲁莽的价值。

- 第一点每次施放暴怒时触发 [[spell:106951]] 增益，被动提高力量。虽然该增益可以叠加，但每次都有自己的持续时间，导致增益不断叠加和衰减，使其容易被动地处理和忽略。
- 第二点和第三点被动提高暴怒的伤害，并在 鲁莽 期间降低其怒气消耗。这使得强大的攻击可以更频繁地使用，并在冷却窗口期间将狂乱增益叠加得更高。
- 最后一点增加 鲁莽 的持续时间，并在使用冷却技能时给予三层狂乱，进一步增强其伤害潜力。

### 狂怒 战士防御法术

2.7.

#### 狂怒 战士的防御法术

狂怒战士拥有多个防御技能，可以单独使用或叠加使用以获得更强的伤害减免。尽管缺乏任何免疫或假死技能，但这能使他们在应对可预见的即将到来的伤害时非常有能力存活下来。

- [[spell:184364]]是主要的防御冷却技能，可以减少伤害并增加嗜血的治疗量。在多目标流派中很难选择它，不过可以换成[[spell:208154]]或[[spell:206315]]，只会造成很小的性能损失。
- [[spell:23920]]是一个非常强大的工具，不仅能减少受到的魔法伤害，还能完全偏转甚至反射法术。虽然并非所有法术都会被反射回去对攻击者造成伤害，但仅仅偏转它们的施放就能显著减少伤害，如果不是让许多危险技能变得毫无威胁的话。
- [[spell:386208]]是游戏中最可靠的冷却技能之一，其冷却时间极短，仅为3秒，但相应的会降低造成的伤害。虽然这使其不太受欢迎，但明智地使用该技能可以显著提高生存能力。
- [[spell:208154]]是一个非常强大的被动减伤效果，由于激怒的高覆盖率，它在持续战斗中几乎始终处于激活状态。
- [[spell:202168]]是一个强大的即时治疗技能，冷却时间短，并在击杀敌人时重置。这使它经常可用，是一个应该经常使用的重要反应性工具。
- [[spell:29838]]、[[spell:382549]]和[[spell:23881]]是额外的治疗效果，会被动触发，不需要进行微管理，但都有助于增强自我恢复能力。

### 狂怒 战士属性优先级

2.8.

#### 狂怒 战士的属性优先级

狂怒 战士的一般属性优先级如下所示。这在很大程度上是一个粗略的指南，是为不希望对自己的角色进行模拟的玩家设计的。如果您正在模拟自己的角色，请完全忽略此属性优先级并遵循您的模拟结果！有关本页内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>).

装备等级

精通

急速

全能

暴击

狂怒早期侧重于急速，在获得大量急速后迅速转向精通。急速仍然有用，因为它可以提高自动攻击速度并减少技能施放之间的间隔，这两者都能增加怒气生成和[[spell:184361]]的覆盖率，而精通则增加该增益效果期间造成的伤害。暴击造成双倍伤害，而全能则直接提高造成的伤害，并减半降低受到的伤害。

### 暴风雪战斗助手

2.9.

#### 狂怒 战士战斗助手

[战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>)，在11.1.7补丁中加入，由两个选项组成，旨在帮助玩家进行战斗循环和游戏。

第一个是辅助高亮，它会推荐玩家接下来应该使用的循环技能，以帮助他们学习如何更好地玩自己的专精。虽然不是完美的极限优化循环，但它完全可用，与更复杂的手动循环相比平均只损失约5%。然而，它不会尝试推荐进攻性冷却技能、防御技能、功能性技能或其他非全局冷却技能如[[spell:100]]，因此玩家必须注意自行使用这些技能。

第二个选项是单键助手，这是一个放置在动作条上的新按钮，按下时会自动循环使用循环中的每个技能。它使用与辅助高亮相同的循环，虽然可用，但会在公共冷却时间上额外增加25%的惩罚，以防止它成为一个容易具有竞争力的选项，导致性能损失约20-25%。因此，它只推荐给全新玩家、处于无关紧要内容中的玩家，或那些无法跟上常规游戏节奏的玩家。

在两种情况下，使用像[[spell:1719]]和[[spell:107574]]这样的冷却技能可以很简单，将其宏绑定到单键助手或像[[spell:385059]]或[[spell:227847]]这样的常用技能上，不过玩家也可以选择继续手动使用它们，如循环部分所述。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 简化了循环，并针对11.0.7补丁验证了信息。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第四赛季更新了天赋和循环建议。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了审查。
- **2023年1月24日：** 天赋构筑已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，您将找到在《魔兽世界》12.1.5补丁中您的狂怒 战士的最佳天赋。我们还为团本或大秘境等各种类型的内容提供了默认天赋流派。如果您开启了战争模式，我们也为您准备了PvP天赋。

1.

### 狂怒 战士的至暗之夜最佳天赋

无论选择哪种英雄天赋，狂怒在第2赛季的大秘境和团本中都处于中游水平。它是一个强力但并非特别顶级的专精，不过在使用正确的天赋流派时，它在少数团本战斗中仍然能够大放异彩。

- **单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者是最佳的纯单体专精，尽管这样的战斗并不多。
- **AoE -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主拥有最佳的多目标性能，这包括大多数有增援的团本战斗，以及大秘境地下城。

**快速开始导入代码：**

:::talents 狂怒单体 - 屠戮者
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM"
}
```
:::

:::talents 狂怒多目标 - 屠戮者
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmBAAYmhxsMwgxA"
}
```
:::

:::talents 狂怒地下城与地下堡 - 领主
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsZmZGAAIMwGssY0YGQmFMjFAzgBAMzAwwiZAGD"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

斩杀者

单体目标团队副本

推荐

团队副本多目标

推荐

大秘境与地下堡

推荐

山丘领主

团队副本多目标

大秘境与地下堡

推荐

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者单体目标团队副本天赋

单体目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 推荐屠戮者团本流派用于所有没有次要目标的战斗。

1.2.

#### 灵活天赋

由于不需要眩晕技能，几乎所有理想的天赋都已被选取，因此在特定情况之外没有太多更换的必要。

- [[spell:184364]]是一个非常有用的防御冷却技能，不过合理使用[[spell:386208]]可以弥补其缺失。
- 在有护盾目标的战斗中，可以用[[spell:384110]]替换[[spell:1271925]]。
- [[spell:1244088]]偶尔也有用，可以与[[spell:12323]]或任何其他不太理想的天赋进行互换。

### 天赋方案 0-1

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者多目标团本天赋

只要有多余的目标可以顺劈，就会使用多目标团本流派，不过频率和覆盖率可以决定天赋的选择。

1.4.

#### 灵活天赋

增援较少或很快被击败的战斗不需要完整的多目标天赋，因此需要一些判断力来为每种情况创建最佳流派。

- [[spell:12950]]、[[spell:280392]]和[[spell:1265357]]提供了大部分持续多目标伤害，但只有在经常命中多个目标时才有用。在增援快速出现且在剑刃风暴期间被击败的战斗中，更倾向于使用单体流派。
- [[spell:184364]]是一个非常有用的防御冷却技能，不过合理使用[[spell:386208]]可以弥补其缺失。
- 在有护盾目标的战斗中，可以用[[spell:384110]]替换[[spell:1271925]]。

### 天赋方案 0-2

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者大秘境地下城与地下堡天赋

大秘境 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者流派的多目标潜力略低，但单体首领伤害更高。它通常也更容易最大化新的套装奖励，因为怒击是自然使用的。

1.6.

#### 灵活天赋

由于需要选择眩晕技能，自定义的空间并不大：

- [[spell:384110]] 可以替代 [[spell:1271925]] 用于有护盾目标的活动，并且与 [[spell:1271948]] 配合非常好，可以制造远程打断，不过这需要放弃 [[spell:1280961]] 提供的部分防御价值。
- [[spell:1271925]] 在大多数 PvE 内容中用处有限，但偶尔可以移除带有减速效果的致命减益。
- [[spell:184364]]是一个非常有用的防御冷却技能，不过合理使用[[spell:386208]]可以弥补其缺失。

### 天赋方案 1-0

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 多目标团队副本天赋

多目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 团队副本构筑仅在有源源不断的小怪和次要目标可以持续顺劈时推荐。尽管不以怒击为重点，它仍然点出了几个在用作填充技能时增强其伤害的天赋。

1.8.

#### 灵活天赋

由于需要点出雷霆一击和雷鸣怒吼，领主构筑没有太多天赋自定义的空间：

- [[spell:184364]] 仍然是一个强大的防御增益，可以替代 [[spell:206315]] 或 [[spell:1265570]]，但合理使用 [[spell:386208]] 应该能在大多数情况下使其变得不必要。
- [[spell:184364]]是一个非常有用的防御冷却技能，不过合理使用[[spell:386208]]可以弥补其缺失。
- 只要主动使用 防御姿态，[[spell:1280961]] 就拥有惊人的防御潜力，不过这需要放弃 [[spell:382764]] 或 [[spell:383082]] 提供的部分伤害。

### 天赋方案 1-1

1.9.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 史诗钥石地下城与宝库天赋

多目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 构筑拥有最高的持续多目标伤害，不过作为交换单体伤害略低。它在操作上也可能稍微复杂一些，因为必须在每个冷却周期内使用三次怒击才能最大化套装加成。总体而言，这两个不同的大秘境构筑表现非常相似，因此选择可能取决于个人偏好。

1.10.

#### 灵活天赋

由于需要点出雷霆一击和雷鸣怒吼，领主构筑没有太多天赋自定义的空间：

- [[spell:184364]] 仍然是一个强大的防御增益，最好替代 [[spell:393950]]，不过合理使用 [[spell:386208]] 应该能在大多数情况下使其变得不必要。
- 职业树非常紧凑，不过 [[spell:275339]]、[[spell:384110]] 和 [[spell:202163]] 都是潜在的替换项。
- [[spell:1271925]] 在大多数 PvE 内容中用处有限，但偶尔可以移除带有减速效果的致命减益。
- 只要主动使用 防御姿态，[[spell:1280961]] 就拥有惊人的防御潜力，不过这需要放弃 [[spell:382764]] 或 [[spell:383082]] 提供的部分伤害。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDzMmZ2MzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgBMDTgZYDYmhxGAAMzwYMMGMG"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOSnBDEFKhgsy04IbGFJm88MNhh59BC-EHJy0KauEUikww+AQQYgmss6WeoOGEC-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzYDAAmZYMLDjBjB"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShNPDGKUCBZlpxROKSM55ZaCDz7DE-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzAAAMzwYWGYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShPDGKUCBVZlpxFFRJm88MNhh59BC-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZmZ2WmZmZMMmZmZmZMzyMzMzMmFzMzAAAhB2glFjGzAYWwMWAMzGDAYmBghFzAMG"
}
```
:::

:::details 来源计算器编码
```
#IB-CGHIMNOdnBDFKXABZlpxFOKasM55ZaCD7DE-EHJy0KauEGUiwwAJCggw48ANZZ1tQJA-AAAA-IQSU0AEUwAjDmF-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsYmZGAAIMwGssY0YGAzCmxCgZwAAmZAYYxMAjB"
}
```
:::

:::details 来源计算器编码
```
#IB-CGIMNOdBDFKhgqsy04OXEFRNWm88MNhh9BC-EHJy0KauEGUiwwAJCggw48ANZZ1tQJA-AAAA-IQSU0AEUwAjDmF-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，它在完成一系列多周任务后提供了一些微小的性能增强自定义选项。其中一些增益会影响你的伤害输出，而另一些则更偏向防御性质。

我们推荐以下增益，但它们可以随时更换，所以请随意尝试其他选项或针对你自己的配装使用模拟推荐。

- [[spell:1279599]]
- [[spell:1279604]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279616]]

1.

### 巅峰天赋： ![Rampaging Berserker Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_12_nonmasculinecharacter_orc.jpg>) 狂暴突袭者

狂怒 战士 的顶点天赋 [[spell:1269308]] 非常直观，分三个部分被动提升 鲁莽 和暴怒的价值。

- 第一点每次施放暴怒时触发 [[spell:106951]] 增益，被动提高力量。虽然该增益可以叠加，但每次都有自己的持续时间，导致增益不断叠加和衰减，使其容易被动地处理和忽略。
- 第二点和第三点被动提高暴怒的伤害，并在 鲁莽 期间降低其怒气消耗。这使得强大的攻击可以更频繁地使用，并在冷却窗口期间将狂乱增益叠加得更高。
- 第四点延长了 鲁莽 的持续时间，并在使用冷却技能时提供三层狂暴，进一步增强其伤害潜力。

1.

### 英雄天赋

狂怒 战士有以下选择： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主，各自拥有其优势、侧重点和细微的游戏差异。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 斩杀者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者 侧重于 斩杀 和剑刃风暴，主要的游戏差异在于 [[spell:280721]] 触发更频繁。由于其高优先级伤害和轻松的顺劈，它通常是团队副本战斗的更好选择，尽管目前在大秘境中也重新受到关注。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 使用 [[spell:6343]] 而非 [[spell:1680]]，并高度强调 [[spell:23881]] 以触发强化的 [[spell:435607]]。由于其固有的多目标能力，它在大秘境中比团队副本中使用得更频繁。

1.

### PvP天赋（战争模式）

自《争霸艾泽拉斯》以来，玩家可以选择进入“战争模式”，使他们能够与其他玩家进行PvP战斗。启用战争模式可获得以下好处：

- 在户外世界启用PvP天赋
- 在最高等级时，世界任务奖励提高10%
- 升级时获得的经验值提高10%
- 赚取征服点数，每周可兑换装备奖励

鉴于启用战争模式对升级和PvE内容的好处，建议启用该功能以最大化你的升级效率和满级后的奖励。然而，你将使自己成为开放世界PvP的目标，并且在升级或进行世界任务时存在被“偷袭”的可能性。

1. [[spell:206572]]提供额外的机动性，这在练级时总是有用的。
2. [[spell:213915]]提升了[[spell:23920]]的价值，在冷却时间略微延长的同时提供更多的进攻和防御价值。
3. [[spell:411764]] 属于小众选择，但在被控制时会提供一个小的加成。

[[spell:199261]] 同样是一个强大的进攻选择，不过在开放世界内容中维持它很麻烦，因为每15秒就需要刷新一次增益，而且在骑乘、飞行或以其他方式无法控制角色时无法施放该技能。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月25日：** 调整了 山丘领主 天赋。
- **2026年8月10日：** 更新了12.1补丁的天赋构建。
- **2026年6月15日：** 在12.0.7补丁中添加了万卷之典能力。
- **2026年4月23日：** 更新了备选大秘境配置和多个配置描述。
- **2026年4月22日：** 添加了多目标团本天赋配置。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 更新了12.0.1补丁的配置。
- **2026 年 1 月 20 日：** 更新了推荐的天赋构建。单体目标 屠戮者 现在使用 天神下凡。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月6日：** 更新了天赋构建以反映未公布的热修复。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 标记了推荐的天赋配置，并针对11.0.7补丁进行了更新。
- **2024年10月21日：** 更新了 山丘领主 大秘境构建描述。
- **2024年9月9日：** 为《地心之战》第一赛季发布更新了构建。
- **2024年8月26日：** 新增了地下城（Delve）天赋配置，并进行了少量天赋更新。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月26日：** 为解决有 bug 的天赋，对构建进行了次要更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第四赛季更新了天赋建议。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 对配置选择工具中推荐天赋的说明进行了小幅更新。
- **2023年11月6日：** 为10.2补丁和第3赛季套装更新了天赋配置。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月12日：** 小幅格式更新。
- **2023年7月10日：** 为10.1.5补丁进行了小幅更新。
- **2023年5月1日：** 更新了更优的猛击流派。
- **2023年1月24日：** 10.0.5补丁已更新多个构筑。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新了无畏冲锋和泰坦之怒的说明。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单目标和多目标情况下优化你的 狂怒 战士 的循环。我们还提供了关于冷却技能、触发效果等的进阶章节，以便你最大化你的DPS。我们的所有内容均已针对《魔兽世界》12.1.5补丁更新。

1.

### 狂怒 战士 游戏玩法与循环指南

欢迎来到 狂怒 战士的循环页面。在本页中，你将找到在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

狂怒 的循环是一个有条件的优先级列表，可能会根据天赋选择而改变。使用下方的复选框进行适当的自定义，并确保 [[spell:386196]] 始终处于开启状态！请注意，单目标和多目标循环使用相同的开关。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 斩杀者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

多目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主

单体目标

多目标

天赋选择

[[spell:46924]]

[[spell:385059]]

[[spell:1261060]]

[[spell:383877]]

[[spell:1265359]]

[[spell:12950]]

[[spell:107574]]

### 单体目标起手式

[[spell:1719]]

**适用条件：天神下凡（启用）；山丘领主（启用）。**

[[spell:107574]]

[[spell:184367]]

**适用条件：屠戮者（启用）；剑刃风暴（启用）。**

[[spell:46924]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:5308]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:335097]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:335097]]

**适用条件：山丘领主（启用）。**

[[spell:435607]]

**适用条件：山丘领主（启用）。**

[[spell:113344]]

**适用条件：山丘领主（启用）。**

[[spell:335097]]

**适用条件：山丘领主（启用）。**

[[spell:184367]]

**适用条件：山丘领主（启用）。**

[[spell:113344]]

**适用条件：山丘领主（启用）。**

[[spell:435607]]

**适用条件：山丘领主（启用）。**

[[spell:335097]]

**适用条件：山丘领主（启用）。**

[[spell:184367]]

1.1.

#### 狂怒 战士 单目标起手循环

只要能用，始终以 [[spell:100]] 起手

1. 施放 [[spell:1719]]
2. **适用条件：天神下凡（启用）；山丘领主（启用）。** 施放 [[spell:107574]]
3. 施放 [[spell:184367]]
4. **适用条件：屠戮者（启用）；剑刃风暴（启用）。** 施放 [[spell:46924]]
5. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
6. **适用条件：斩杀者（启用）。** 施放 [[spell:5308]]
7. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
8. **适用条件：斩杀者（启用）。** 施放 [[spell:335097]]
9. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
10. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
11. **适用条件：斩杀者（启用）。** 施放 [[spell:335097]]
12. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]] 以避免浪费一次触发
13. **适用条件：山丘领主（启用）。** 施放 [[spell:113344]]
14. **适用条件：山丘领主（启用）。** 施放 [[spell:335097]]
15. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]
16. **适用条件：山丘领主（启用）。** 施放 [[spell:113344]]
17. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]] 以避免浪费一次触发
18. **适用条件：山丘领主（启用）。** 施放 [[spell:335097]]
19. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]

继续执行常规的单目标优先级。

### 单体目标循环

1.2.

#### 狂怒 战士 单目标起手

1.3.

#### 狂怒 战士 冷却期间的单目标循环

狂怒 战士 的循环是一个优先级列表，每次施放技能后，玩家应从列表顶部重新开始，建立重要性的层级。由于 [[spell:1719]] 对怒气的生成和消耗有重大影响，此列表根据当前是否处于冷却状态分为两部分。

:::details 套装与循环
第2赛季套装提高循环技能的伤害，同时使它们能够增益 鲁莽。屠戮者 通过以下方式自动处理：

[[spell:386628]]

，而 山丘领主 必须在其冷却期间同时使用嗜血和怒击。

- [[spell:1296645]]
- [[spell:1296646]]

:::

在 鲁莽 期间，怒气生成更快，暴怒可以更早使用，但不应在可用时立即使用。相反，暴怒应延迟到接近怒气上限时使用，以便为其他技能留出空间。

1. 怒气超过100或 [[spell:184361]] 未激活时施放 [[spell:184367]]
2. **适用条件：山丘领主（启用）；天神下凡（启用）。** 在拥有2层雷霆爆裂增益、天神下凡 剩余时间少于2秒，或雷霆爆裂增益剩余时间少于3秒时施放 [[spell:435607]]
3. **适用条件：山丘领主（启用）。** 施放两次 [[spell:113344]] 以施加第2赛季套装的暴击几率增益
4. **适用条件：山丘领主（启用）；Hack and Slash（启用）。** 在 [[spell:383877]] 增益激活期间施放 [[spell:335097]]
5. **适用条件：山丘领主（启用）。** 施放 [[spell:113344]]
6. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]
7. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
8. **适用条件：山丘领主（启用）。** 施放 [[spell:335097]]
9. **适用条件：山丘领主（启用）。** 施放 [[spell:5308]]
10. **适用条件：山丘领主（启用）。** 如果没有其他技能可用，施放 [[spell:6343]]
11. **适用条件：屠戮者（启用）；剑刃风暴（启用）。** 在使用剑刃风暴前立即连发 [[spell:184367]]
12. **适用条件：屠戮者（启用）；剑刃风暴（启用）。** 在 鲁莽 期间施放 [[spell:46924]]
13. **适用条件：斩杀者（启用）。** 在拥有 [[spell:280721]] 时施放 [[spell:5308]]
14. **适用条件：屠戮者（启用）；Hack and Slash（启用）。** 如果 [[spell:383877]] 增益未激活，连发 [[spell:184367]]
15. **适用条件：屠戮者（启用）；Hack and Slash（启用）。** 施放 [[spell:335097]]
16. **适用条件：斩杀者（启用）；奥丁之怒（启用）。** 施放 [[spell:385059]]
17. **适用条件：斩杀者（启用）。** 施放 [[spell:5308]]
18. **适用条件：斩杀者（启用）。** 施放 [[spell:113344]]
19. **适用条件：屠戮者（启用）；Hack and Slash（未启用）。** 施放 [[spell:335097]]

1.4.

#### 无冷却期间

在无冷却期间，暴怒的延迟频率较低，但由于没有 鲁莽 提供的额外怒气生成，必须每隔几次施放就使用一次以维持激怒。循环的其余部分相当相似，不过必须更频繁地穿插嗜血和怒击，以生成使用暴怒所需的额外怒气。

1. 冷却就绪时施放 [[spell:1719]]
2. **适用条件：天神下凡（启用）。** 冷却完毕即施放 [[spell:107574]]
3. 怒气超过100或激怒即将结束时施放 [[spell:184367]]
4. **适用条件：山丘领主（启用）；Hack and Slash（启用）。** 在 [[spell:383877]] 增益激活期间施放 [[spell:85288]]
5. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
6. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]
7. **适用条件：山丘领主（启用）。** 施放 [[spell:23881]]
8. **适用条件：山丘领主（启用）；重伤（启用）。** 点出 [[spell:1261060]] 后施放 [[spell:5308]]
9. **适用条件：山丘领主（启用）；奥丁之怒（启用）。** 施放 [[spell:385059]]
10. **适用条件：山丘领主（启用）。** 施放 [[spell:85288]]
11. **适用条件：山丘领主（启用）；Deep Wounds（未启用）。** 施放 [[spell:5308]]
12. **适用条件：山丘领主（启用）。** 如果没有其他技能可用，施放 [[spell:6343]]
13. **适用条件：斩杀者（启用）；奥丁之怒（启用）。** 施放 [[spell:385059]]
14. **适用条件：斩杀者（启用）。** 施放 [[spell:163201]]
15. **适用条件：斩杀者（启用）。** 施放 [[spell:85288]]
16. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
17. **适用条件：斩杀者（启用）。** 施放 [[spell:23881]]
18. **适用条件：斩杀者（启用）。** 如果没有其他技能可用，施放 [[spell:190411]]

### 多目标起手

[[spell:100]]

**适用条件：山丘领主（启用）；奥丁之怒（启用）。**

[[spell:385059]]

**适用条件：斩杀者（启用）。**

[[spell:190411]]

[[spell:12950]]

[[spell:772]]

[[spell:1719]]

**适用条件：山丘领主（启用）。**

[[spell:107574]]

**适用条件：山丘领主（启用）；奥丁之怒（未启用）。**

[[spell:184367]]

**适用条件：山丘领主（启用）。**

[[spell:435607]]

**适用条件：山丘领主（启用）。**

[[spell:113344]]

**适用条件：山丘领主（启用）。**

[[spell:435607]]

[[spell:184367]]

**适用条件：山丘领主（启用）。**

[[spell:435607]]

**适用条件：山丘领主（启用）。**

[[spell:184367]]

**适用条件：山丘领主（启用）。**

[[spell:6343]]

**适用条件：屠戮者（启用）；剑刃风暴（启用）。**

[[spell:46924]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:385059]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:190411]]

**适用条件：斩杀者（启用）。**

[[spell:184367]]

**适用条件：斩杀者（启用）。**

[[spell:335097]]

1.5.

#### 狂怒 战士 多目标起手循环

只要能够，始终以[[spell:100]]作为起手。

1. **适用条件：山丘领主（启用）；奥丁之怒（启用）。** 施放 [[spell:385059]] 以施加激怒
2. **适用条件：斩杀者（启用）。** 施放 [[spell:190411]] 以施加 [[spell:12950]] 和 [[spell:772]]
3. 施放 [[spell:1719]]
4. **适用条件：山丘领主（启用）。** 施放 [[spell:107574]]
5. **适用条件：山丘领主（启用）；奥丁之怒（未启用）。** 施放 [[spell:184367]] 以施加激怒
6. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
7. **适用条件：山丘领主（启用）。** 施放 [[spell:113344]]
8. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
9. 施放 [[spell:184367]]
10. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
11. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]
12. **适用条件：山丘领主（启用）。** 施放 [[spell:6343]]
13. **适用条件：屠戮者（启用）；剑刃风暴（启用）。** 施放 [[spell:46924]]
14. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
15. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
16. **适用条件：斩杀者（启用）。** 施放 [[spell:385059]]
17. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
18. **适用条件：斩杀者（启用）。** 施放 [[spell:190411]]
19. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
20. **适用条件：斩杀者（启用）。** 施放 [[spell:335097]]
21. 继续按正常的多目标优先级执行。

### 多目标循环

1.6.

#### 狂怒 战士 冷却期间的多目标循环

面对多个目标时，狂怒 战士大量使用 [[spell:190411]] 和 [[spell:6343]] 造成伤害，同时使其常规循环能够顺劈另外四个目标。

:::details 套装与循环
第2赛季套装提高循环技能的伤害，同时使它们能够增益 鲁莽。屠戮者 通过以下方式自动处理：

[[spell:386628]]

，而 山丘领主 必须在其冷却期间同时使用嗜血和怒击。

- [[spell:1296645]]
- [[spell:1296646]]

:::

在 鲁莽 期间，怒气生成更快，暴怒可以更早使用，但不应在可用时立即使用。相反，暴怒应延迟到接近怒气上限时使用，以便为其他技能留出空间。

1. **适用条件：山丘领主（启用）；奥丁之怒（启用）。** 如果 [[spell:184361]] 尚未激活，则施放 [[spell:385059]]
2. **适用条件：山丘领主（启用）；奥丁之怒（未启用）。** 如果 [[spell:184361]] 尚未激活，则施放 [[spell:184367]]
3. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
4. **适用条件：山丘领主（启用）。** 面对超过6个目标时施放 [[spell:6343]]
5. **适用条件：山丘领主（启用）。** 怒气超过100，或 [[spell:184361]] 即将消失时施放 [[spell:184367]]
6. **适用条件：山丘领主（启用）。** 施放 [[spell:113344]]
7. **适用条件：山丘领主（启用）；Hack and Slash（启用）。** 在 [[spell:383877]] 增益激活期间施放 [[spell:335097]]
8. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]
9. **适用条件：山丘领主（启用）。** 施放 [[spell:6343]]
10. **适用条件：山丘领主（启用）。** 施放 [[spell:335097]]
11. **适用条件：斩杀者（启用）。** 只要 [[spell:12950]] 增益未激活，就施放 [[spell:1680]] 以施加该增益
12. **适用条件：斩杀者（启用）。** 尽可能多地施放 [[spell:184367]]
13. **适用条件：屠戮者（启用）；剑刃风暴（启用）。** 在 鲁莽 期间施放 [[spell:46924]]
14. **适用条件：斩杀者（启用）。** 在拥有 [[spell:280721]] 时施放 [[spell:5308]]
15. **适用条件：斩杀者（启用）；奥丁之怒（启用）。** 施放 [[spell:385059]]
16. **适用条件：斩杀者（启用）。** 施放 [[spell:335097]]
17. **适用条件：斩杀者（启用）。** 施放 [[spell:113344]]
18. **适用条件：斩杀者（启用）。** 施放 [[spell:5308]]

1.7.

#### 无冷却期间

在无冷却期间，暴怒的延迟方式类似，但原因是出于怒气效率以维持更好的激怒覆盖率。没有 鲁莽 提供的额外怒气生成，这成为了一个重要得多的因素，导致截然不同的游戏节奏。

1. **适用条件：Improved Whirlwind（启用）；屠戮者（启用）。** 如果 [[spell:12950]] 未激活，则施放 [[spell:190411]]
2. **适用条件：山丘领主（启用）。** 施放 [[spell:385059]]
3. **适用条件：山丘领主（启用）。** 施放 [[spell:107574]]
4. **适用条件：山丘领主（启用）。** 施放 [[spell:1719]]
5. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
6. **适用条件：山丘领主（启用）。** 如果 [[spell:12950]] 增益未激活或面对7个以上目标，则施放 [[spell:6343]]
7. **适用条件：山丘领主（启用）。** 怒气超过100或激怒即将结束时施放 [[spell:184367]]
8. **适用条件：山丘领主（启用）。** 施放 [[spell:23881]]
9. **适用条件：山丘领主（启用）。** 施放 [[spell:435607]]
10. **适用条件：山丘领主（启用）；Hack and Slash（启用）。** 在 [[spell:383877]] 增益激活期间施放 [[spell:85288]]
11. **适用条件：山丘领主（启用）。** 施放 [[spell:5308]]
12. **适用条件：山丘领主（启用）。** 施放 [[spell:184367]]
13. **适用条件：山丘领主（启用）。** 施放 [[spell:85288]]
14. **适用条件：山丘领主（启用）。** 如果没有其他技能可用，施放 [[spell:6343]]
15. **适用条件：斩杀者（启用）。** 施放 [[spell:184367]]
16. **适用条件：斩杀者（启用）。** 在拥有 [[spell:280721]] 时施放 [[spell:5308]]
17. **适用条件：斩杀者（启用）；奥丁之怒（启用）。** 施放 [[spell:385059]]
18. **适用条件：斩杀者（启用）。** 施放 [[spell:5308]]
19. **适用条件：斩杀者（启用）。** 施放 [[spell:85288]]
20. **适用条件：斩杀者（启用）。** 施放 [[spell:23881]]
21. **适用条件：斩杀者（启用）。** 施放 [[spell:190411]] 以填充循环

### 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 斩杀者

1.8.

#### 作为屠戮者游玩

屠戮者 围绕 [[spell:29725]] 和 [[spell:227847]] 展开，但为了伤害和激怒，保持嗜血冷却就绪仍然很重要。

- 消耗 [[spell:29725]] 会根据 [[spell:445584]] 的层数减少 [[spell:227847]] 的冷却时间。
- [[spell:29725]] 可以叠加两层，因此无需立即使用，但也不应无谓地延迟以避免溢出。
- [[spell:227847]] 会触发多个天赋，因此最好在 [[spell:1719]] 早期使用，以最大化增益效果的重叠。
- 只要不需要昏迷，任何时候都可以在剑刃风暴期间施放 [[spell:107570]]，以造成极少量的额外伤害。

### 作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主

1.9.

#### 作为巨神兵游玩

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主 实际上用 [[spell:6343]] 替代了旋风斩，而它在 [[spell:107574]] 期间会得到极大的强化。

- [[spell:6343]] 偶尔会被 [[spell:435607]] 替代。虽然它们造成的直接伤害非常相似，但爆裂会延长 天神下凡 的持续时间，并且总会触发一次额外的闪电打击，使其比技能说明上显示的要强得多。
- 在 天神下凡 期间，[[spell:6343]] 的冷却时间大幅缩短，使其可以每隔一个全局冷却使用一次。面对大量目标时应保持其冷却就绪，不过在单体或低顺劈情况下，最好将其保留作为间歇性填充技能。
- [[spell:1719]] 和 [[spell:107574]] 冷却时间相同，且同样受到 [[spell:152278]] 的影响，因此可以安全地通过宏一起使用。

1.

### 至暗之夜 第2赛季套装

新的 至暗之夜 第2赛季套装加成提高了循环技能的伤害，同时使它们能够增益 [[spell:1719]]。这带来了一些细微的循环影响，不过 屠戮者 通过 [[spell:386628]] 自动处理这些影响，而 山丘领主 必须在其冷却期间同时使用嗜血和怒击。

- [[spell:1296645]] - 怒击伤害提高15%。在鲁莽期间，怒击将鲁莽的持续时间延长2秒，最多延长6秒。
- [[spell:1296646]] - 嗜血伤害提高10%。在鲁莽期间，嗜血使鲁莽的暴击加成提高5%，最多提高10%。

1.

### 职业与专精机制详解

为了更好地解释 狂怒 战士 机制的具体细节，我们编写了关于循环各个部分的更详细说明，从你需要注意的重要循环机制，到冷却技能及其使用方法，以便你能发挥出全部潜力。

### 维持激怒

3.1.

#### 激怒

狂怒 循环的目标是一个持续的反馈循环：生成怒气，将其花费在 [[spell:184367]] 上以触发 [[spell:184361]]，这会提高后续技能的伤害，而这些技能又生成更多怒气以重复该过程。由于它是一个如此强大的增益（通常在30-50%之间），维持高覆盖率对于成为一名成功的 狂怒 战士 至关重要。

虽然 [[spell:1719]] 增加了怒气生成量以便更快地使用暴怒，但 [[spell:385059]] 和 [[spell:215568]] 都会自动触发激怒，有助于在其他冷却技能不可用时启动循环。特别是鲜肉，可以通过仔细追踪哪些敌人尚未被该技能击中来加以利用，从而使其可以在目标之间链式触发，不断再次触发该效果。

### 最大化输出时间

3.2.

#### 最大化输出时间

适用于大多数职业，但对 狂怒 战士尤为重要，因为他们高度重视堆叠急速以获得更多攻击来生成怒气。任何脱离目标的时间都是损失的伤害，且几乎没有手段弥补损失的资源，这与基于能量的职业不同，后者会继续恢复资源直到上限。

由于战士职业固有的高机动性，可以围绕Boss机制进行操作并尽量减少停手时间。如果Boss正在施放需要玩家跑开一定距离的区域效果技能，战士可以继续攻击到最后几秒，然后 [[spell:6544]] 离开，危险一过立即 [[spell:100]] 回来。

狂怒 不应有任何空闲的全局冷却，因为旋风斩总是可用的。然而，不应依赖这一点，因为除非点出 [[spell:12950]]，否则旋风斩不会生成怒气。相反，反复使用怒击和穿插的嗜血构成了循环的主体，而暴怒通常会延迟到其80怒气消耗之后，只要激怒不消失。这样延迟使用暴怒可以囤积少量额外怒气，从而在几秒后施放下一次暴怒之前，无需生成完整的80怒气。

### 循环冲锋

3.3.

#### 循环冲锋

可以通过移出目标射程并使用 [[spell:100]] 在循环中生成额外怒气来进行小幅优化。应注意在 [[spell:1719]] 未激活时，在自动攻击间隔期间进行此操作。[[spell:6544]] 也可以用来为拥有大型碰撞箱的首领创造冲锋的空间，这有时更具体地被称为英勇冲锋。

### 使用巅峰天赋

3.4.

#### 使用巅峰天赋

由于怒气消耗降低，在 [[spell:1719]] 期间可以更频繁地施放 [[spell:184367]]，通常每隔一个GCD一次。不过由于 [[spell:106951]] 层拥有各自的持续时间，因此没有特别的需要或优势去追踪它，使得该增益很容易被动处理。

1.

### 狂怒 战士 重要冷却技能

### [[spell:1719]]

4.1.

#### 鲁莽

狂怒战士的主要爆发技能提供了一段中等长度的爆发窗口和额外的怒气生成，使暴怒可以更频繁地使用。点出[[spell:396749]]还会将嗜血和怒击转化为更强力的[[spell:113344]]和[[spell:335097]]形态。

### [[spell:107574]]

4.2.

#### 天神下凡

现在与剑刃风暴处于同一个抉择节点，天神下凡是山丘领主正常运作所必需的，这使得两者之间的选择变得简单。尽管失去了其后续天赋，天神下凡与山丘领主的其他加成有着极佳的协同作用，尤其是[[spell:275336]]。

### [[spell:227847]]

4.3.

#### 剑刃风暴

招牌技能屠戮者已经不再是过去那样的高爆发杀手锏，但依然能提供可观的伤害，其单体价值通过[[spell:386628]]得到了提升。使用该技能时务必确保自己处于激怒状态，最好是在一次新的暴怒之后立即使用；虽然它确实会生成怒气，但拥有[[spell:215568]]或[[spell:383295]]将有助于在引导期间及结束后维持激怒状态。

请记住，无羁狂怒触发的自动嗜血也可以触发它们自身的效果，例如[[spell:184361]]或[[spell:444775]]。

尽管三层 [[spell:444769]] 会让按钮发光，但这并不是何时使用剑刃风暴的指示。它几乎总是应该冷却完毕就用，或者配合小怪群的时机。

### [[spell:385059]]

4.4.

#### 奥丁之怒

奥丁的狂怒提供了另一种立即触发激怒的方式，同时带来自身的瞬间伤害爆发。最好在没有可用爆发技能时作为起手使用，它同样受益于[[spell:385703]]。

### [[spell:384110]]

4.5.

#### 破裂投掷

虽然本身不是一个主要的爆发技能，但破坏之击能造成高得惊人的伤害，使其成为一个称职的远程填充技能，并且在点出[[spell:1271948]]时还能沉默敌人。然而，它的真正威力在于面对带有吸收护盾的目标时，获得500%的伤害加成，成为整个战士技能体系中最强大的单次攻击。在这种情况下，应尽快使用，优先级仅次于施加激怒，以确保它命中目标并迅速剥离其护盾。

4.6.

#### 防御技能

狂怒拥有很高的被动生存能力，这得益于更高的基础耐力和[[spell:208154]]的被动减伤。虽然其主要的生存手段是[[spell:184364]]，但有些流派可能选择不点它，而是转而依靠[[spell:386208]]和/或[[spell:1280961]]的组合，尽管在激活期间会有少量的伤害损失，而[[spell:202168]]和[[spell:29838]]则可以帮助将损失的生命值治疗回来。最后，[[spell:23920]]是一个极其有用的工具，可以减轻甚至完全免疫许多魔法伤害来源。

该 [指向性法术](<https://www.curseforge.com/wow/addons/targetedspells>) 插件在知道敌人何时对你施放法术时非常有帮助，但它无法告诉你该法术是什么或是否可以反射，因此玩家需要自己学会识别它们。

提高的生命值和自我治疗能力使狂怒在持续战斗中非常耐打，尽管应对频繁的高额伤害爆发的能力较弱。在这些情况下，最好预先使用激怒回血，并在其持续期间尽可能频繁地使用嗜血，以受益于其提高的治疗量。

4.7.

#### 团队增益

战士可以使用[[spell:97462]]，这是游戏中为数不多的团队防御技能之一。它通常用于帮助团队在关键的战斗机制中存活下来，而不是作为个人的防御技能。请记住它占用全局冷却时间，所以要在需要时准备好使用它。

战士还提供 [[spell:6673]]，使所有小队和团队成员的攻击强度提高5%，应在战斗开始前施加。请注意，该增益仅适用于近战攻击者和猎人，对施法专精没有加成。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月6日：** 调整了战斗怒吼的描述。
- **2026年4月6日：** 为鲁莽药水添加了免责声明。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 单体目标 屠戮者 现在使用 天神下凡。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月6日：** 为未公布的热修复更新了多目标 屠戮者 循环。
- **2025年8月10日：** 已根据第3赛季的循环变化进行更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁添加了战斗助手部分。
- **2025年4月21日：** 将循环拆分为可切换的图片框架。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月23日：** 单体目标循环的次要更新。
- **2024年9月9日：** 添加了关于开关的说明，并从多目标列表中移除了多余的括号。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月31日：** 更新单体目标剑刃风暴优先级。
- **2024年7月26日：** 根据最近的调整，推荐单体目标使用长矛而非咆哮。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 添加了一个强调正确使用菲莱克巨剑的部分。
- **2023年11月6日：** 为第3赛季做准备，更新了T31配置和循环。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已针对10.0.7补丁更新，使复选框选项更加清晰。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 修复天赋选择器的格式。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面中，你将找到魔兽世界12.1.5版本中你的狂怒战士的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章来升级装备的建议，我们都为你准备好了！

1.

### 狂怒战士毕业装备指南

欢迎来到我们的狂怒战士装备与毕业页面，适用于至暗之夜第2赛季。查看此页面，了解关于为狂怒战士配装所需的一切信息，包括来自所有来源（团队副本和大秘境）的毕业装备、关于最佳饰品和套装的信息，或者查看 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 以了解有关新资料片功能的更多信息。

一般来说，物品等级是衡量实力的最佳指标，物品等级更高的装备几乎总是比那些属性稍好的装备更强，不过饰品由于其多样的特殊效果，可能是这一经验法则的例外。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含狂怒战士来自所有来源的最高DPS配置。请记住，还有一些属性分布相似、表现也相近的替代方案。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

未加衬的制造物品不如完全升级的对应物品强，但可以作为非常强力的填充部件。

:::details 常见问题我需要哪些套装部件？
对于至暗之夜第2赛季，狂怒战士优先选择哪件套装部位已不再重要，因为通过催化剂转化的套装部位现在会继承原始物品的属性和加成，使它们变得完全相同，从而使“散件”的概念过时。不过玩家对自己的配装仍有更多控制权，因为带有默认属性的代币仍会像往常一样从首领身上掉落。

- 转化器头盔：[[item:281239@JAACAAgNyA]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 催化剂护肩：[[item:251138@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 转化器胸甲：[[item:268222@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

话虽如此，凑齐套装加成远比优化属性分配重要，所以不要过分执着于等待更好的部件。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271878@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:280799@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 秘境+

此列表包含狂怒战士专门来自地下城的最佳装备。请记住，还有一些属性分布相似的替代方案，以及几件可以从任何地下城获得的极具竞争力的催化剂套装部位。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

未加衬的制造物品不如完全升级的对应物品强，但可以作为非常强力的填充部件。

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：包含最多的部件，包括最佳武器。
- [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)：也有若干部件，使其刷取效率更高。
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：拥有一枚非常优秀的戒指，提供重要属性。

:::

:::details 常见问题我需要哪些套装部件？
对于至暗之夜第2赛季，狂怒战士优先选择哪件套装部位已不再重要，因为通过催化剂转化的套装部位现在会继承原始物品的属性和加成，使它们变得完全相同，从而使“散件”的概念过时。不过玩家对自己的配装仍有更多控制权，因为带有默认属性的代币仍会像往常一样从首领身上掉落。

- 催化剂头盔：[[item:251126@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 催化剂护肩：[[item:251138@JAACAAgNyA]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 催化剂胸甲：[[item:193753@JAAKAAQkCYHKvbRLfYjM]]，来自 [红玉新生法池](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)
- 转化器手套：[[item:251214@JAACAAgNyA]]，来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- 转化器腿部：[[item:273776@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)

话虽如此，凑齐套装加成远比优化属性分配重要，所以不要过分执着于等待更好的部件。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:159442@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>护肩</th><td>[[item:271454@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.wowhead.com/achievement=41960" rel="noopener noreferrer">密谋小径</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273796@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:250229@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273782@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:251230@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### 团队副本

此列表包含狂怒战士专门来自团队副本的最佳装备。请记住，还有一些属性分布相似、表现也相近的替代方案。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

未加衬的制造物品不如完全升级的对应物品强，但可以作为非常强力的填充部件。

:::details 常见问题我需要哪些套装部件？
对于至暗之夜第2赛季，狂怒战士优先选择哪件套装部位已不再重要，因为通过催化剂转化的套装部位现在会继承原始物品的属性和加成，使它们变得完全相同，从而使“散件”的概念过时。不过玩家对自己的配装仍有更多控制权，因为带有默认属性的代币仍会像往常一样从首领身上掉落。

- 转化器头盔：[[item:281239@JAACAAgNyA]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 转化器胸甲：[[item:268222@JAACAAAG2A]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 转化器腿部：[[item:271878@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)

话虽如此，凑齐套装加成远比优化属性分配重要，所以不要过分执着于等待更好的部件。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271456@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>手套</th><td>[[item:271457@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240917]][[item:240892]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268259@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护肩</th><td>[[item:271444@JAACAAgNyA]]&#10;&#10;<div><span>可交易的小怪掉落</span><span>[[item:243963]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271455@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:244643]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:237828@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>胸部</th><td>[[item:271459@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a> <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240892]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:237834@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]][[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">锻造</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fury-warrior-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268213@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>副手</th><td>[[item:280799@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 狂怒战士饰品推荐

第2赛季有几种饰品可供选择，不过本赛季的主动使用型饰品非常少，大多数是随机伤害或属性加成，它们在游戏玩法上价值不大，也无法从诸如[[spell:184361]]或[[spell:107574]]等职业效果中受益。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看狂怒战士饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>两者皆有</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270173]]</li>&#10;<li>[[item:270175]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250229]]</li>&#10;<li>[[item:270165]]</li>&#10;<li>[[item:250238]]</li>&#10;<li>[[item:250259]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:193762@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:270163]]</li>&#10;<li>[[item:273795]]</li>&#10;<li>[[item:158367]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1版本继续沿用额外拾取系统，允许玩家获得一个朦胧虚空核心作为额外拾取，以代替从宏伟宝库中获取一件物品。随着12.1.5版本的发布，玩家还将能够每周从 **奥琳·微光** 银月城转化器附近的商人处额外购买一个虚空核心，从而获得两次获取额外拾取战利品的机会。

**[朦胧虚空核心](<https://www.wowhead.com/currency=3418>)** 可以在完成地下城或击败团队副本首领后使用，使你从该特定掉落列表中获得一件随机物品。每个物品在每个难度或地下城中只能被额外拾取一次，作为剔除列表以确定性地获取物品。

1.

### 推荐的朦胧虚空核心额外拾取

从12.1版本开始，玩家可以通过放弃从宏伟宝库获取物品来获得虚空核心作为额外拾取，不过在赛季开始八周内（大约在12.1.5版本预计到来之时），它们无法以其他方式每周获取。这些是强大的资源，如果宝库中的物品不够好，非常值得优先使用。归根结底这是一种赌博，玩家需要评估宝库中的装备是否比从特定首领或地下城掉落列表中额外拾取他们想要的物品的机会更好。

额外拾取的战利品会按照来自宏伟宝库的方式发放，因此英雄难度团队副本首领的战利品会以神话路线1/6的等级发放，而史诗团队副本首领的战利品则会以其最高升级等级发放，这可能节省大量纹章。

4.1.

#### 狂怒战士虚空核心推荐用法

使用 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 额外拾取有两种主要方式，取决于玩家的需求。理想情况下，它们应该用在大秘境10层和史诗团队副本首领身上以最大化奖励，但请注意，史诗团队副本首领每周只能击败一次，而大秘境可以重复进行，以便囤积并使用多个额外拾取直到获得所需物品。截至12.1版本，只有一个
[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 会被消耗，无论它是用在团队副本首领身上还是在大秘境中。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 神话路线武器，特别是[[item:268213]]或[[item:280799]]。
2. 神话路线饰品，特别是[[item:270173]]和[[item:270175]]。
3. 拥有额外预算或特效的物品，例如[[item:268265]]、[[item:271878]]和[[item:281029]]。
4. 任何高预算、稀有或可替代低物品等级装备的物品。

:::

4.2.

#### 晋升毒液石

[[item:280562]]可用于升级已经达到最高等级的英雄、神话或同等制造的武器、饰品或项链。英雄装备升级至328物品等级，制造部件升级至338，而史诗装备升级至340物品等级。

1. 武器始终是战士的最高优先级。
2. 饰品位居第二，因为它们的特殊效果通常比纯粹的属性提供更多的强度。
3. 项链应该最后升级。

因为只有这三类物品可以升级，所以那些已经从史诗难度盘蛇祭坛和乌拉特克获得344物品等级装备、进度非常靠前的狂怒战士只需要一颗毒石就能升级他们的副手武器。然而，大多数玩家尚未达到那个阶段，而且毒石是可以无限刷取的，所以不需要囤积起来留给最好的装备。它们可以而且应该用来升级你当前穿着的任何一件装备。

1.

### 狂怒战士最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

对于狂怒战士来说，首先制造武器是一个非常好的选择，因为更高的物品等级会降低武器升级所需的纹章，相当于花一份钱升级了两个部位。对于第二个装饰效果，护腕是竞争力最强的制造部位，因为其属性预算较低。最终，玩家会希望用制造的靴子来替换武器，前提是那时他们已经有了合适的史诗难度替代品，并且有多余的升级纹章。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **狂怒制造装备优先级**
- [[item:237847]]搭配[[item:245876]]
- [[item:237834]]搭配[[item:240167]]
- [[item:237828]]搭配[[item:240167]]

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

5.1.

#### 狂怒战士最佳装饰效果

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 对于团队副本和大秘境：武器上使用[[item:245876]]，其他部位使用[[item:240167]]。

建议你自行模拟以找出最适合你的方案，并考虑任何可能在不久的将来进行的专精转换。

5.2.

#### 为装备添加插槽

玩家可以每周选择不从宏伟宝库中挑选物品，而是选择代币，其中六个可以兑换一个[[item:275707]]，这是一种消耗品，可以为尚无插槽的头盔、护腕或腰带增加一个插槽。这使得它成为完善你打算长期保留的装备的好方法。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **狂怒战士纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些并不是唯一值得升级的物品。它们只是在赛季初期、你的升级货币有限时提供最高的DPS收益。请注意，例外是可能存在的，例如拥有该装备独特额外效果的特殊特效物品。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了12.1.5补丁的装备推荐，并添加了关于毒石的新章节。
- **2026年8月10日：** 更新了12.1补丁的所有装备推荐。
- **2026年6月15日：** 在12.0.7补丁中添加了孢化装备。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 添加了关于使用纹章升级物品的章节。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁添加了新的常见问题解答部分。
- **2025 年 10 月 5 日：** 添加了迪纳尔，更新了推荐饰品，并为涡轮增压提高了物品等级。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁添加了泰坦神装DISC腰带。
- **2025年5月12日：** 更新了装备列表，添加了代币购买优先级。
- **2025年4月21日：** 添加了11.1.5补丁的帮会代币推荐。
- **2025年3月17日：** 修复了失效的塞尔西的王冠链接，并在嵌入内容中添加了宝石。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月16日：** 更新了塞尔西的王冠，以计入物品等级提升的热修。
- **2024年12月15日：** 添加了塞尔西的王冠，并针对11.0.7补丁进行了验证。
- **2024年10月21日：** 添加了一个简要部分，详细介绍了即将到来的时光漫游和周年庆团队副本饰品。
- **2024年9月9日：** 为地心之战第1赛季的上线进行了更新。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第四赛季更新了装备和铸币建议。
- **2024年3月19日：** 扩展了专业制造推荐，并为10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2024 年 1 月 14 日：** 将菲莱克巨剑添加到整体毕业列表中（祝你好运）。
- **2023年11月8日：** 更新了新的装备套装，以计入孢子披风的削弱。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月10日：** 为10.1.5补丁进行了更新，以包含永恒黎明的装备。
- **2023年5月1日：** 更新了玛瑙指环的宝石推荐。
- **2023年3月20日：** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面中，你将找到你的狂怒战士的最佳属性优先级。我们首先介绍属性优先级，然后深入解释这些属性如何与你的专精和游戏玩法相互作用。我们的内容已更新至魔兽世界12.1.5补丁。

1.

### 狂怒 战士属性优先级

两者皆有 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者系狂怒战士主要看重装等提供的力量，其次是精通和急速，然后是全能和暴击。由于各种收益递减的存在，随着装等提升，这些属性的价值会有所波动，获取越多价值越低，因此经常会出现堆了很多急速和精通之后，再通过宝石或附魔来补充更多全能或暴击的情况。当你达到中等装等水平时，狂怒系战士的属性优先级应为：

装备等级

精通

急速

全能

暴击

在最高装等水平下，由于堆叠最多的属性会受到递减收益的影响，这些属性的价值会进一步变化，不过存在一个点，你无法在不放弃大部分另一种属性的情况下获得更多某一种属性。这就是为什么与一点力量相比的传统属性权重难以使用，因此建议玩家经常对自己装备的升级进行模拟。

:::details 常见问题：狂怒战士有急速上限吗？
严格来说没有，因为即使超过100%，急速仍会继续减少循环技能的冷却时间并增加自动攻击的频率。

然而，有几个关键节点会改变它的价值。作为一个由急速驱动的专精，它仍然是狂怒最重要的次要属性之一，因为更多的急速会加快循环的节奏。这相当于更多的怒气、更多的特殊触发以及更好的激怒覆盖率。

:::

:::details 常见问题：收益递减是如何运作的？
为了平滑副属性的价值并减少堆叠单一属性的倾向，在各个点上，转换为1%所需的副属性量会减少。这是按等级而非原始百分比计算的。所以它不包括职业增益效果，例如

[[spell:383848]]

或

[[spell:2825]]

，但它会影响饰品和其他添加固定数值的效果。

在实践中，这不是大多数玩家需要关注的事情，因为最好的副属性即使在收益递减点之后也往往保持价值。它只是缩小了它们之间的差距，以确保更多种类的装备有用。

:::

1.

### 深入属性解析

力量是你的主属性，出现在板甲、武器和饰品上。它提供攻击强度，有助于所有技能和自动攻击的伤害。

急速压缩了循环，减少了全局冷却时间、自动攻击之间的间隔，以及循环技能[[spell:23881]]、[[spell:85288]]和[[spell:5308]]的冷却时间，还加快了[[spell:46924]]和[[spell:184367]]造成伤害的速度。虽然激怒覆盖率通常非常高，但由于行动频率的增加以及嗜血和怒击等循环技能冷却时间的缩短，急速仍然是一个强力属性。

精通增加了[[spell:76856]]提供的伤害加成，在[[spell:184361]]激活期间提升所有造成的伤害。由于其高覆盖率和强大的收益，这对狂怒战士来说是一个非常强大的属性。

暴击造成双倍伤害，尽管狂怒不像武器那样在暴击时产生额外的怒气。这使得暴击的价值通常较低。

全能按百分比直接提高造成的伤害，并减少受到的一半数值的伤害。直接伤害饰品、法术类物品和其他外部伤害来源会更看重全能，因为它们通常不随攻击强度缩放。

2.1.

#### 狂怒战士种族加成

:::details 点击查看Bloodmallet模拟数据
加载中...

如需查看完整的模拟结果，请查看 [Bloodmallet.com](<https://bloodmallet.com/index.html#warrior_fury>)

:::

总体而言，种族加成对狂怒的影响非常小。任何差距在1%以内的通常都被认为是微不足道的，差距足够小，以至于我们的建议是选择你最喜欢玩的种族。

2.2.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁添加了常见问题解答部分。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 已针对10.0.7补丁进行了小幅说明更新。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面中，我们列出了你的狂怒战士可以获取的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/fury-warrior-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

在唯一装备的钻石中，当镶嵌多种颜色的宝石时，[[item:240967]]会更强一些，不过在装备初期插槽有限时，这可能难以兼顾。因此，[[item:240983]]可能是更简单的选择。

急速和精通通常是狂怒战士的最佳属性，因此其他插槽应填入[[item:240906]]或[[item:240892]]。当使用多种颜色来增加强力钻石加成时，使用一颗红宝石、一颗橄榄石和一颗紫水晶，但要避免使用天青石，因为全能的价值不高。

1.

### 最佳附魔和武器强化

除了附魔之外，玩家还可以在武器上应用临时强化，这是一种持续两小时的增益效果，可以提高伤害或属性。虽然它们在死亡后依然存在，但这些加成并非永久性的，必须重新涂抹。[[item:243733]]应涂抹在两把武器上，以获得更多次要属性。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273072]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>肩部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243963]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;<li></li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244643]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

几种附魔提供了在吸血、速度或闪避附魔之间进行选择的余地，这主要取决于个人偏好，因为这三者都只提供微小且在很大程度上可以互换的收益。

1.

### 最佳消耗品

- 合剂：[[item:241322]]或[[item:241325]]
- 最佳战斗药水：[[item:241288]]是最佳战斗药水，但它需要非常谨慎的属性分配以确保它总是提供精通。如果情况并非如此，或者在获得[[item:280799]]之后，[[item:271886]]成为更好的选择，以避免触发错误的次要属性。
- 治疗药水：应使用[[item:271883]]进行治疗。
- 食物增益：[[item:255846]]是最佳的大餐。像[[item:242275]]这样的个人食物提供相同的进攻收益，但没有额外的耐力加成。
- 强化符文：[[item:259085]]是至暗之夜中目前唯一可用且最佳的强化符文。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 更新了推荐的武器附魔和药水描述，以说明特殊情况下的属性问题。
- **2026年8月10日：** 更新了12.1补丁的宝石、武器附魔和治疗药水。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月6日：** 为鲁莽药水添加了免责声明。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025 年 8 月 25 日：** 新增了临时强化，并扩充了关于武器附魔的说明。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年5月12日：** 对腐蚀部分进行了小幅更新，将回响虚空作为备选方案。
- **2025年4月21日：** 添加了11.1.5补丁的腐蚀推荐。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 更新了玛瑙指环的宝石推荐。
- **2023年3月20日：** 更新了10.0.7补丁的玛瑙指环信息。
- **2023年1月24日：** 已更新至10.0.5补丁。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在魔兽世界12.1.5补丁中使用你的狂怒战士挑战大秘境地下城的提示和建议。

1.

### 狂怒战士在至暗之夜第2赛季的大秘境

在大秘境中，狂怒战士是持续伤害输出者，依赖高在线率和频繁的冷却技能来输出稳定的伤害，而不是短暂的高爆发。虽然游戏玩法非常活跃，但它对停机时间也非常敏感，因为每一秒远离目标都会降低他们的潜在输出。因此，一个好的狂怒战士应该总是提前考虑几步，预判即将发生的机制、敌人将如何被移动、他们何时会被击败以及是否即将拉入新的一波怪物，以确保他们保持领先。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

1.

### 最佳大秘境天赋配置

在至暗之夜第2赛季中，屠戮者和山丘领主非常接近，让玩家有更多自由根据偏好或队伍构成来选择。两者都不会根据地下城或钥匙等级改变天赋构建，因此游戏玩法保持高度一致，不过在辅助和功能性天赋之间仍有一些选择空间。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主构建

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主大秘境构建

山丘领主在面对大量目标时提供更好的多目标伤害，但代价是优先目标伤害较低。第2赛季的职业改动也使其更加依赖[[spell:435607]]的触发来打出有竞争力的伤害。尽管如此，它通常玩起来非常流畅，但新的套装加成在管理上也有些繁琐，需要在每个爆发循环期间都将嗜血和怒击穿插到循环中。

多目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/mountain-thane.webp>) 山丘领主构建的特点是短冷却时间和强大的[[spell:6343]]取代了旋风斩，提供强大、持续且稳定的多目标表现，几乎不用担心随机触发影响循环。

2.2.

#### 灵活天赋

由于需要点出雷霆一击和雷鸣怒吼，领主构筑没有太多天赋自定义的空间：

- [[spell:184364]] 仍然是一个强大的防御增益，可以替代 [[spell:206315]] 或 [[spell:1265570]]，但合理使用 [[spell:386208]] 应该能在大多数情况下使其变得不必要。
- [[spell:202163]]是与天赋树上半部分中任何其他所需天赋进行互换的最佳选择。
- [[spell:1271925]]在大多数PvE内容中用途有限，但在少数它变得相关的情况下，可以与[[spell:384110]]或[[spell:12323]]互换。
- 只要积极使用防御姿态，[[spell:1280961]]就具有惊人的防御潜力，尽管其进攻性收益充其量只是平平。在多目标内容繁重的情况下，[[spell:382764]]通常是最佳的舍弃选择，不过这也需要选择[[spell:1243660]]而不是[[spell:1271948]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsYmZGAAIMwGssY0YGAzCmxCgZwAAmZAYYxMAjB"
}
```
:::

:::details 来源计算器编码
```
#IB-CGIMNOdBDFKhgqsy04OXEFRNWm88MNhh9BC-EHJy0KauEGUiwwAJCggw48ANZZ1tQJA-AAAA-IQSU0AEUwAjDmF-*
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者构建

2.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者大秘境天赋构建

屠戮者在至暗之夜第2赛季取得了长足的进步，利用其新的怒击构建和提高的[[spell:445584]]覆盖率来提供更好的优先目标伤害，尽管其多目标表现仍有些不稳定，且依赖于获得时机恰到好处的[[spell:444775]]触发。它通常也更容易玩，这要归功于[[spell:386628]]会自动施放嗜血来施加新的套装加成效果。

多目标 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/slayer.webp>) 屠戮者流派威力较小且不够稳定，取决于获得正确数量的斩杀触发，以确保剑刃风暴与其他冷却技能和[[spell:444775]]触发对齐，从而补充其多目标伤害。[[spell:1265357]]确实能使其持续多目标输出更加强大，但需要经常命中6个以上目标才值得。

2.4.

#### 灵活天赋

由于需要选择眩晕技能，天赋自定义的空间较小：

- 任何时候有护盾目标时，都可以用[[spell:384110]]替换[[spell:1271925]]或[[spell:1271926]]。用[[spell:1271948]]替换[[spell:1280961]]也可能值得，以牺牲一些防御收益换取远程打断能力。
- [[spell:184364]]仍然是一个强大的防御加成，尽管在不损失伤害的情况下很难融入流派。最好的情况是从[[spell:354479]]或[[spell:383486]]中去掉一点，但合理使用[[spell:386208]]应该能在大多数情况下使其变得不必要。
- 只要积极使用防御姿态，[[spell:1280961]]就具有出色的防御潜力，尽管其进攻收益充其量只是平庸。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CgEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgBMDTgZYDYmZzAAAMzwYWGYwYA"
}
```
:::

:::details 来源计算器编码
```
#IB-CHIMNOShPDGKUCBVZlpxFFRJm88MNhh59BC-EHJy0KauEGUiww+ABggANZZ1t8QdMIE-AAAA-HIcg0AEQYhhCzC-
```

:::

1.

### 功能技能与能力

### 打断、昏迷、制止和减速

3.1.

#### 打断

[[spell:6552]]是战士版本的脚踢，经常在大秘境中使用以打断敌人的施法，从而造福整个队伍，尤其是坦克。由于有时需要打断你当前正在攻击的目标以外的目标，因此 **强烈推荐** 使用焦点或鼠标悬停宏是必要的。

屠戮者拥有在[[spell:227847]]期间使用拳击的独特能力，这通常是无法做到的。

```wow-macro
/cast [@focus,exists,nodead][@mouseover,exists,nodead] [] 拳击
```

这个宏会踢你的焦点目标（如果你有焦点目标的话），没有焦点目标则踢鼠标悬停目标，两者都没有则踢你的主要目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏**.

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

严格来说不是打断技能，[[spell:23920]]是一个极其强大的个人工具，可以偏转或反射许多敌人法术的伤害和负面效果，但仅限于法术施放在战士身上时。

[[spell:384110]]配合[[spell:1271948]]还能提供远程沉默！

3.2.

#### 昏迷、“制止”和减速

[[spell:107570]]和[[spell:46968]]是单体和多目标昏迷技能，由于常用于制止敌人行动而被称为“制止”。与过去相比更容易点出天赋；这些是任何大秘境构建中的核心天赋。

[[spell:5246]]是另一个群体制止技能，它恐惧目标而不是击晕目标。这有几个限制，会导致目标逃跑并可能引来援军，某些目标对该状态免疫，以及与刺穿怒吼冲突。因此，在大秘境构建中并不总是会点出这个天赋，但可以根据需要添加。

[[spell:12323]]可用作群体减速，尽管这在大多数内容中并不是经常需要的。[[spell:1715]]是不需要天赋的单体替代方案，通常足以满足任何减速需求。刺穿怒吼还能为盟友提供少量的速度加成，但由于其超长的冷却时间，使其适用范围非常有限。

### 其他功能

3.3.

#### 其他功能

[[spell:6673]]使所有近战职业和猎人的伤害输出提高5%，应始终保持激活状态。

[[spell:97462]]是一个全队防御性冷却技能，有助于帮助自己或盟友承受即将到来的伤害。其效果在非团队副本内容中还会提高50%！

[[spell:18499]]和[[spell:384100]]可以移除恐惧和迷惑效果，这在现代游戏中并不常见。呐喊版本作用于盟友，但有几个限制：需要额外的天赋点、范围非常有限经常无法覆盖施法者，以及只能在恐惧效果施加后反应性地使用，而不能提前免疫。因此，它很少被点出，不过新的[[spell:1271925]]天赋在移除同时带有减速效果的致命减益时可能有用武之地。

1.

### 应对词缀

与大多数职业不同，战士处理各种机制的专门技巧很少，主要专注于个人伤害和防御。战士的大多数技巧都是使用[[spell:23920]]来抵消或反射即将到来的法术伤害。

该 [指向性法术](<https://www.curseforge.com/wow/addons/targetedspells>) 插件在知道敌人何时对你施放法术时非常有帮助，但它无法告诉你该法术是什么或是否可以反射，因此玩家需要自己学会识别它们。

4.1.

#### 词缀

至暗之夜第2赛季只有四个重要的词缀提供某种反制手段，称为萨拉塔斯的交易。它们每周轮换，一次只有一个生效。许多大秘境词缀，如强韧或残暴，只是简单地给钥石添加一个被动效果，而这四个例外则是以萨拉塔斯为主题的赛季专属词缀：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将刷新三波球体，需要打断或制止。[[spell:46968]]在这里效果极佳，不过紧急情况下也可以使用[[spell:5246]]。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个虚空大使小怪会带着护盾刷新，需要集火，这使它成为配合[[spell:1271948]]使用[[spell:384110]]的完美目标。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体将在玩家周围刷新并绕着他们转。你有15秒的时间吸收所有这些球体来为你的队伍提供增益。使用[[spell:12323]]可以帮助队伍更快地到达这些球体，不过要小心互相绕圈跑！
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有队伍成员都会受到一个治疗吸收效果的影响，该效果还会降低移动速度，使用[[spell:1271925]]可以立即移除整个效果。否则，可以使用[[spell:202168]]、治疗药水或治疗石来帮助清除吸收效果。

每一种词缀在被处理后都会提供一组不同的增益效果，虽然它们非常强大，但你不需要以特定的方式围绕它们进行操作。最重要的是不要让任何词缀强化敌方小怪或首领。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 更新了12.1补丁的配置推荐。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年9月6日：** 为未公布的热修复进行了更新。
- **2025年8月10日：** 澄清了关于天赋选择的解释。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 标记了推荐配置，并针对11.0.7补丁进行了验证。
- **2024年10月21日：** 更新了 山丘领主 大秘境构建描述和地下城词缀建议。
- **2024年9月9日：** 为地心之战第1赛季的上线进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 对简介进行了小幅更新。
- **2024年4月22日：** 为第四赛季更新了天赋和循环建议。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 已为10.1.7版本审核。
- **2023年7月12日：** 小幅格式更新。
- **2023年7月10日：** 为10.1.5补丁进行了更新，将震荡波作为推荐天赋纳入。
- **2023年5月1日：** 更新了更优的猛击流派。
- **2023年1月24日：** 10.0.5补丁已更新构筑。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月18日：** 更新了无畏冲锋和泰坦之怒的使用方式及说明。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页面中，你将找到许多有用的宏和插件，让你在魔兽世界12.1.5补丁中玩你的狂怒战士时更加轻松。

1.

### 最佳宏

战士通常不需要太多宏就能有效操作，尽管有几个宏可以作为非常好的生活质量改进，例如自动设置目标圈和减少多余按键。

随着天赋配装系统为每套天赋创建独立的动作条，根据当前点出的天赋来切换技能的宏需求大大减少。话虽如此，[known:######]条件仍然可以实现这一点，使用已点天赋的法术名称或ID来确定显示哪个技能。

那些直接互相替代的技能，如胜利冲击和即刻生效的胜利，无论宏中写的是哪个技能名称，都能继续正常工作。

1.1.

#### 战士通用宏

#### 鲁莽和天神下凡

```wow-macro
#showtooltip
/cast 鲁莽
/cast 天神下凡
```

因为它们共享基础冷却时间且都不占用全局冷却，鲁莽和天神下凡经常被绑定在一起以节省按键。在至暗之夜中，宏中技能的顺序并不重要。

#### 在雷霆一击和旋风斩之间切换

```wow-macro
#showtooltip
/cast [@player, known:雷霆一击] 雷霆一击; 旋风斩
```

如果点出了天赋，这将把[[spell:1680]]切换为[[spell:6343]]。

#### 拳击宏

```wow-macro
#showtooltip 拳击
/cast [@focus, harm, exists][@target] 拳击
```

这个宏会对你有焦点目标时对焦点目标使用[[spell:6552]]，没有焦点目标时则对当前目标使用。

#### 自动英勇飞跃

```wow-macro
#showtooltip 英勇飞跃
/cast [@cursor] 英勇飞跃
```

这会在你鼠标光标所在的位置施放[[spell:6544]]，无需等待选择地面目标圈。

#### 英勇飞跃连按

```wow-macro
#showtooltip 英勇飞跃
/cast !英勇飞跃
```

这让你可以狂按[[spell:6544]]按钮，但仍保留地面目标选择圈。

#### 冲锋和胜利在望

```wow-macro
#showtooltip
/cast 冲锋
/cast 乘胜追击
/cancelaura 剑刃风暴
```

因为冲锋不占用公共冷却时间，胜利在望或任何其他近战技能可以使用相同的快捷键。在近战范围之外时，将施放冲锋。这个宏还会取消剑刃风暴，以确保玩家不会被阻止快速移动。

#### 冲锋和援护

```wow-macro
#showtooltip
/cast @harm Charge
/cast @harm Victory Rush
/cast @help Intervene
```

冲锋和援护也可以组合在一起，甚至可以根据需要与胜利冲击结合。虽然这将技能整合到了一个按键上，但动态技能提示可能并不总是显示你想要的法术，因此建议单独追踪它们。

#### 姿态切换

```wow-macro
#showtooltip
/cast [stance:2]!防御姿态;[known:386164]!战斗姿态;[known:386196]!狂暴姿态
```

这让你可以使用同一个按键在[[spell:386196]]和[[spell:386208]]之间切换。

1.2.

#### 狂怒战士专属宏

#### 进攻爆发宏

```wow-macro
#showtooltip
/use 鲁莽
/use 天神下凡
/use 血性狂怒
/use 狂暴
/use 13
/use 14
```

此宏在使用[[spell:1719]]的同时，使用不占用全局冷却时间的种族技能和任何已装备的饰品。

1.

### 最佳插件

2.1.

#### 战士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

看看在不使用任何额外插件的情况下你能走多远甚至可能是值得的，也许你甚至会喜欢不必在每个补丁上花费数小时更新和重新配置你的界面。许多插件仍在开发中，或者专门旨在为至暗之夜上线时提供所有选项，因此你的一些最爱可能还不可用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### Omen 仇恨统计

[Omen 仇恨统计](<https://www.curseforge.com/wow/addons/omen-threat-meter>)
是显示当前目标仇恨水平最流行的插件。我们建议你使用它，以避免在坦克仍在对敌人建立仇恨时抢到仇恨。

2.5.

#### 狂怒战士专属插件

目前，我们认为要发挥狂怒系战士的全部潜力，并不需要任何额外的插件，不过有大量的界面插件可供选择，有助于更好地排布框架、动作条等。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 为至暗之夜上线进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 为地心之战季前赛的上线进行了更新。
- **2024年7月23日：** 为地心之战前夕补丁进行了更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6版本更新。
- **2024年2月15日：** 修复了前堡垒盟约的勇士之矛失效法术链接。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 为巨龙时代上线进行了复查。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
