## 专精概览

Welcome to our Mistweaver Monk guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to heal as a Mistweaver Monk in both raids
and Mythic+ dungeons. We cover everything from the basics all the way to min-maxing techniques to optimize your output.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Mistweaver Mythic+ Resources

[NEW! Top Mistweaver Talent Builds](<https://raider.io/specs/mistweaver-monk/talents>)

[Top Mistweaver Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/monk/mistweaver>)

[Mistweaver Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=monk--mistweaver>)

[Popular Mistweaver Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=monk--mistweaver>)

1.

### Mistweaver Monk Overview

The Mistweaver specialization is versatile, and different talent choices can
allow it to fit a wide range of raid requirements. Mistweavers can,
therefore, heal both tanks and the raid very well.

Based on talent choices, Mistweavers can be either unparalleled tank healers
with strong area of effect throughput or damage-dealing mobile raid healers.

Middle of the pack

Mistweaver Monk is a throughput healer, and as such, lives and dies by its ability
to top up health bars. Unlike other specs that bring powerful mitigation or utility spells
to bypass certain mechanics, Mistweaver relies solely on its HPS throughput. As of 12.15, Mistweaver is
performing better than about half of healer specs	.

Middle of the pack

Mistweaver Monk is a strong option in Mythic+, in no small part due to our immense
durability. Mistweavers have a plethora of damage reduction cooldowns and passives that
allow us to take a substantial amount of punishment without dying. Furthermore, Mistweaver's kit is
designed around dealing damage, passively increasing your group's total DPS. However, where
Mistweaver falls short is its lack of meaningful group utility; we do not bring a
strong group-wide damage reduction like

[[spell:98008]]

or

[[spell:62618]]

,
nor do we have a battle resurrection or

[[spell:2825]]

. Equally, our external DR cooldown

[[spell:116849]]

provides a flat amount of damage prevention, meaning it scales
less effectively into higher keys than other healer's cooldowns like

[[spell:102342]]

or

[[spell:33206]]

. All that being said though, while a Mistweaver likely won't be used
in a rank 1 run, they absolutely still excel in bleeding edge keys.

Niche Utility

Utility is Mistweaver Monk's Achilles' heel; while we do have numerous interesting utility
options, many of them are particularly niche during combat. The obvious stand-outs for us
are

[[spell:116844]]

,

[[spell:119381]]

, and

[[spell:115078]]

which give us excellent
group CC ability in dungeons, however it is extremely rare that a strategy will uniquely
revolve around any of those abilities in specific; other classes can be brought to do the same
thing. Our raid cooldown

[[spell:115310]]

includes a group-wide magic dispel, but given
the current design philosophy of debuffs often requiring intentionally timed dispels, this
effect is often a detriment rather than a boon (so much so that Revival as a talent exists
on a choice node with another talent

[[spell:388615]]

, which does the exact same thing, just
with no dispel). Lastly, we bring the debuff

[[spell:8647]]

as a monk specific raid buff.
However, the debuff can also be brought by a Windwalker or Brewmaster, and as far buffs go,
5% physical damage is among the weaker buffs as most damage in WoW is magical.

Extremely Durable

Mistweaver Monk is one of the most durable specs in the game. With talents like

[[spell:414132]]

making us straight up immune to certain attacks, as well a personal DR cooldown

[[spell:388917]]

,
and a plethora of passive damage reduction talents, it is very hard for a Mistweaver to run out of defensive options.

Hyper Mobile

In terms of mobility few specs can hold a candle to a Monk's toolkit. Between

[[spell:109132]]

,

[[spell:116841]]

,

[[spell:101643]]

, and

[[spell:449582]]

, it is almost impossible
to be caught flat-footed as a Mistweaver.

Strong Damage

Mistweaver is largely designed around dealing damage to a target in order to heal, either
directly through effects like

[[spell:388023]]

or by buffing our spells like

[[spell:274909]]

and

[[spell:467307]]

. As such, Mistweavers will passively do more damage than the average healer,
however with proper play, certain healers can exceed our top end throughput.

2.

### Mistweaver Monk in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 brings no significant changes to Mistweaver Monk,
outside of a little tuning in the weeks prior to release. Instead, the main focus
is on two new endgame activities: a new single-boss Raid encounter
and an exciting addition to [Delves](<https://www.icy-veins.com/wow/delves-guide>) called Labyrinths.
Check out our guides the Kith'ix encounter and the new Labyrinth Mega-Delve!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

For a full list of all the changes that Patch 12.1.5 has brought, like quality of life
improvements or other new types of content, check out our dedicated overview page!

2.3.

#### Class Changes

While these changes did not explicitly arrive with 12.1.5, they happened
so close to the release date, that they bear mentioning here anyway.
In total they amount to ~10% buff to our throughput in raids.

[Midnight Hotfixes](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-october-6/2336376/166>)

**October 6th**

- <em>Developers' notes: We're making a few raid focused adjustments to Mistweaver with the aim of increasing their overall performance in that content.</em>
- Invigorating Mists healing increased by 15%.
- Enveloping Mist healing increased by 15%. Does not apply in PvP combat.

**September 22nd**

- All healing increased by 5%. Does not apply to PvP combat.
- Vivify healing increased by 15%. Does not apply to PvP combat.
- Sheilun's Gift healing increased by 15%. Does not apply to PvP combat.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_soothingmists.jpg>) Click for Previous Season 2 Changes
2.4.

#### 12.1 Hotfixes

[Pre-Season Tuning](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-18/2336820>)

- All healing increased by 8%. Does not affect PvP combat.
- Venomous Abyss 4-set bonus has been updated – Activation rate increased by 33%.

2.4.1.

##### Patch 12.1 Launch Changes

This is a tough patch for Mistweaver. This patch cycle saw us receive a 3% and an 8%
aura nerf to all our healing, as well as a re-tuning of our DPS-to-Healing mechanics.
There seems to be an attempt to make Mastery a valuable stat again, however the new interactions
of a high mastery build + our set bonus were cut down with a 60% nerf to [[spell:1277302]].

It remains to be seen just how these changes will truly affect Mistweaver once the Raid releases,
but currently available data from PTR paints a troubling picture.

In Mythic+ Mistweaver remains decent, though our over reliance on [[spell:101546]]
has been tamped down through a series of nerfs and bug fixes. While you will still press SCK
during larger AoE pulls, anything under five mobs will have us returning to [[spell:100780]] and [[spell:100784]].

[12.1 Class Tuning](<https://us.forums.blizzard.com/en/wow/t/midnight-curse-of-ulatek-ptr-development-notes/2317811>)

- New Talent: [[spell:1299572]] — [[spell:115175]]’s healing is increased by 300%, but its mana cost is increased by 200%. Choice node with [[spell:388701]].
- All healing reduced by ~10.7%.
- Mastery: Gust of Mist healing increased by 225%.
- [[spell:101546]] damage decreased by 6.5%.
- [[spell:216113]] now transfers 280% of damage done (was 340%).
- [[spell:467293]] now increases Ancient Teaching’s transfer amount by 320% (was 270%).
- Resolved an issue that caused Temple Training’s Spinning Crane Kick damage increase to apply to Mistweaver.
- [[spell:1277302]] effectiveness reduced by 60%.

:::

### Midnight   Changes Overview

2.5.

#### Midnight for Mistweaver Monk

Mistweaver received a myriad of changes in Midnight, largely aimed at reducing
the amount of buffs and passive interactions that needed to be maintained in order
to succeed. The spec plays fairly similarly to how it has in the past, albeit somewhat
simplified.

Broadly speaking, the tempo of healing in general has slowed down quite a bit. Power has
been taken out of our cooldowns and, for Mistweavers in specific, many of our healing
amplifiers have been nerfed or removed entirely. The core theme and loop of our spec
remains unchanged though: we're still a melee-dps healer who wants to blanket their
group in [[spell:115151]].

2.6.

#### Apex Talents

Midnight has expanded on the Talent system by introducing Apex Talents; effectively 
a powerful ability at the end of the class tree that players can opt into starting at level 81.
For Mistweavers, that ability is **Spiritfont**. You will be able to allocate up to 4
talents points to increase your Apex Talent's power:

1. [[spell:1260511]] — Causes your [[spell:116670]] and [[spell:107428]]
     to grant you a buff that causes your next [[spell:124682]] to channel [[spell:115175]]
     onto up to 5 targets at 20% effectiveness. If a target is at max Health, the Soothing Mist will
     jump to a new target, or split its healing among the other 4 targets.
2. [[spell:1260677]] — [[spell:107428]] damage is increased by 10%/20%
     and [[spell:124682]] healing is increased by 10%/20%. This bonus is increased by 50%
     while Spirit Font is active.
3. [[spell:1260680]] — [[spell:116680]] activates Spirit Font, and applies
     Chi Cocoons to targeted allies at 30% effectiveness.

2.7.

#### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials is largely the same, save for a few changed talents.
[[spell:443566]] was moved and in its place we received [[spell:1262756]]
which increases the healing of your [[spell:443110]] shield by 400%.
Additionally, since Refreshing Jade Wind was removed, the talents that affected
it have been reworked to provide small passive bonuses to damage/healing.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony functions very similarly, but did get a fairly
impactful rework to the function of the caption talent [[spell:450529]]. Now,
the healing intensification is capped at 20% additional healing, instead fully withdrawing
your banked vitality. Additionally, [[spell:116670]] / [[spell:399491]] no longer
generate vitality and instead will <em>always</em> withdraw vitality, 
increasing their healing by up to 100%.

2.8.

#### Rotational Changes

Moment to moment gameplay has changed very little, but minutia of the spec has
been simplified. We still want to achieve a high uptime and spread of [[spell:115151]]
as well as look to set up frequent [[spell:322118]] windows. Mana 
is more sparse even though the raw mana return from [[spell:197908]] was buffed,
it no longer reduces the mana cost of your spells.

2.9.

#### Utility Changes

Midnight has brought a massive reduction in defensiveness across the board, and
Mistweaver is no exception. [[spell:1243287]] was reworked and now instead of
being a damage reduction cooldown, instead causes [[spell:388917]] to dispel
a magic effect on you. [[spell:389577]] was also removed, which accounted for a substantial
amount of our durability. That being said, we are still one of the tankiest healers in 
the game; we retained most of our damage reduction talents and gained a few bonuses
to the amount of healing we receive.

3.

### Basics of Mistweaver Monk Gameplay

Like all healers, a Mistweaver needs to have a solid understanding of their
spells so that they know which one to use in any given context. Unlike DPS, who
can follow a rotation or priority queue, Healers are much more contextual.

Your aim needs to be maximizing efficient casts to squeeze the most healing
out of your Mana bar. A high uptime and coverage of [[spell:115151]] is
ideal is almost every situation for a Mistweaver as it is the driver for an
enormous swath of our healing. You should be looking to use your cooldowns such
as [[spell:322118]], [[spell:325197]] and
[[spell:115310]] as frequently as the fight allows, as these large cooldowns
generally result in the strongest throughput (and by proxy mana efficiency)
that our kit has to offer. Lastly, to keep up with your mana consumption, you
should be mindful to use [[spell:197908]] enough as to not overcap your stacks.

The backbone of Mistweaver Monk can be condensed into the following ideas.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_renewingmists.jpg>) **Renewing Mist is Life**  
   
    An enormous swath of Mistweaver's kit revolves around [[spell:115151]].
    It's a powerful HoT all on its own, and it enables your bread and butter [[spell:116670]]
    to hit additional targets. Make sure to cast this ability as close to on cooldown
    as possible to ensure proper coverage on your group.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_risingsunkick.jpg>) **You are a Melee Class**  
  
    While Mistweaver can cast and do the majority of its rotation from ranged, in 
    terms of targeting for boss mechanics, the game will treat you as melee. It's important
    to take advantage of that to leave room for your ranged players. Ability targeting is 
    more nuanced than that, but <em>generally</em> you will be immune to ranged only
    mechanics unless they specifically target healers.
- ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_cherrymanatea.jpg>) **Don't Forget Mana Tea!**  
  
    Mistweavers have active mana regeneration: spending mana generates [[spell:197908]]
    stacks and consuming Mana Tea stacks generates mana. However Mana Tea only stacks
    up to 20 and it is easy to forget to use Mana Tea if you aren't low on mana!
    Ensuring that you're using Mana Tea before you cap will ensure you don't run 
    OOM later on.

4.

### How to Gear Up as a Mistweaver Monk

While we always recommend simming yourself for ideal results, we do provide a
dedicated Mistweaver gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **03 Sep. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Changed Mythic+ Stat priority.
- **18 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Pre-Season Trinket tuning.
- **18 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated Raid Talent Recommendations.
- **18 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated Raid talent recommendations.
- **18 Aug. 2026 (this page):** Updated for Pre-Season Tuning.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Sporefused gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Added Omnium Folio section.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **19 May 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated recommended talents.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated trinket recommendations and added Ascendant and Nebulous Voidcore sections.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated Mythic+ gem recommendations.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Pruned tertiary stat section.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **31 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Added "No Apex" talent build.
- **31 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Added DPS talent build.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Added section about Sanguithorn Tea.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated fro Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for Midnight Season 1.
- **05 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Fixed issue of linking to outdated gems.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Midnight Launch.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Midnight Launch.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Midnight Launch.
- **26 Feb. 2026 (this page):** Updated for Midnight Launch.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Midnight Pre-Patch
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated Talent recommendations for Midnight Pre-Patch.
- **10 Feb. 2026 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Midnight Pre-Patch
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Patch 12.0.1.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Edited talents for Patch 12.0.1.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Puzzling Cartel Chip section.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **07 Sep. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reordered information for visual clarity.
- **07 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Added rotational information about our Tier Set.
- **12 Aug. 2025 (this page):** Updated for the Rushing Wind Kick nerf.
- **10 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated Raid build to use Lotus Infusion instead of Chi Harmony.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated For Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 11.2
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.2 and added section about Tier Set rotations.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.2
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.7, and added DISC section.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reworded stat priority explanations.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-liberation-of-undermine-raid-guide>)):** Reviewed for patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for patch 11.1.7.
- **15 Jun. 2025 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for patch 11.1.7.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **25 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated Puzzling Cartel Chip section.
- **22 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated Boss tips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-liberation-of-undermine-raid-guide>)):** Adjusted talent recommendations.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for patch 11.1.5.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **17 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-liberation-of-undermine-raid-guide>)):** Mug'zee and Gallywix tips added.
- **05 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Fixed and error on the Mythic+ weapon recommendation.
- **03 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Adjusted trinket tier list.
- **02 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-liberation-of-undermine-raid-guide>)):** Boss tips added.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.1.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 11.1.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated Talent builds to reflect the 11.1 changes.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 11.1.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated talents for Patch 11.1.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.
- **20 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Patch 11.1.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated Cyrce's Circlet section to reflect the buffs.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added section for Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Added a Master of Harmony Build.
- **15 Dec. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Added a Mythic+ Master of Harmony build.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **30 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated Rising Mist build.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated Talent selection for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Adjusted raid trinket recommendations.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Added Boss and Trash tips for Patch 11.0.5.
- **21 Oct. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated Talent choices for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **21 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-nerub-ar-palace-raid-guide>)):** Added tips for the last four bosses.
- **12 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Adjusted Gem recommendations.
- **12 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Added section on how to fix the Jade Bond bug.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for 11.0.2
- **09 Sep. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Reviewed for The War Within Season 1.
- **28 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Added recommendation for Solo Delve Talents.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Update for The War Within Release.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for The War Within Release.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for the War Within Release.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for The War Within Release.
- **21 Aug. 2024 (this page):** Updated for The War Within Release.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/mistweaver-monk-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **18 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/mistweaver-monk-the-war-within-pve-guide>)):** Added Page.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/mistweaver-monk-mists-of-pandaria-remix-guide>)):** Page added.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated talent recommendations for Season 4.
- **22 Apr. 2024 (this page):** Updated for Dragonflight Season 4.
- **25 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated the foreword to include dungeon leveling.
- **21 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated Talents for Patch 10.2.6.
- **21 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated the Clouded Focus ramp rotation to reflect the introduction of the Peer into Peace talent.
- **21 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated all talent trees to reflect the new talents added in Patch 10.2.6.
- **21 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Changed Phial recommendations.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Added Peer into Peace and Dance of Chi-Ji to the spell list.
- **19 Mar. 2024 (this page):** Added Patch 10.2.6 section.
- **29 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated a few Talent choices and fixed pathing to Invoke Chi-Ji.
- **23 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated recommended Talents.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated trinket rankings.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated Faeline Stomp to Jadefire Stomp to reflect the visual update.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated the name of Faeline Stomp to Jadefire Stomp.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Added Patch 10.2.5 section.
- **12 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Slightly altered the recommended Clouded Focus talent build.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Changes to Embellishments.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated Talents for Patch 10.2.
- **06 Nov. 2023 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated all talent trees to reflect the Patch 10.2 changes
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Adjusted Talent selection to reflect the 10.2 changes.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated Talents for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reintroduced BiS Lists, and updated for 10.1.7.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Added Mana Tea's interaction with Critical Strike to the stat descriptions and recommendations.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated Talents for Patch 10.1.7.
- **04 Sep. 2023 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.1.7.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Adjusted Mana Tea's usage to reflect the 10.1.7 rework
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated all talents trees to reflect the Mana Tea change, and other shuffling of talent positions.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Patch 10.1.7.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Adjusted Talent selection to reflect the 10.1.7 changes.
- **04 Sep. 2023 (this page):** Added 10.1.7 section.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Dawn of the Infinite section.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 10.1.5
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Removed old content and updated for Patch 10.1.5
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Added Yu'lon's Grace and Dance of the Wind.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 (this page):** Added Patch 10.1.5 section.
- **24 May 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Cataclysm Timewalking Section.
- **06 May 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Aberrus Trinkets.
- **05 May 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated PvP and PvE talents.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for 10.1
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Added Clouded Focus section and updated for Patch 10.1.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Changed the Affix and Talent sections for Dragonflight Season 2.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Added "At a Glance" section and updated for 10.1
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Patch 10.1, and added the Clouded Focus build.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Changed the talent recommendations for Patch 10.1
- **01 May 2023 (this page):** Added Patch 10.1 section.
- **25 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Adjusted the Onyx Annulet section to reflect the buffs to Primordial Gemstones.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/mistweaver-monk-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added section of Onyx Annulet.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Added Primordial Gemstones.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated to reflect the 10.0.7 talent tree rework.
- **20 Mar. 2023 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated to reflect the addition of  the talent Legacy of Wisdom.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Added Legacy of Wisdom and changed Enveloping Breath to Celestial Harmony.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added Patch 10.0.7 section.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated to reflect the 10.0.5 talent tree rework.
- **24 Jan. 2023 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated to reflect the 10.0.5 talent tree rework.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Added Sheilun's Gift, Shaohao's Lessons, Veil of Pride, and Burst of Life.  Removed Bonedust Brew, Bountiful Brew, and Attenuation.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated Talent tree to reflect the 10.0.5 rework.
- **24 Jan. 2023 (this page):** Reviewed for Patch 10.0.5.
- **13 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Added Embellishment section.
- **13 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated Talent recommendations and added a special mention for Mote of Sanctification.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Reformatted the page, added a tier list for Trinkets.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated Enchant recommendations.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Changed the recommendations for both Raids and Mythic+.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Changed Thunder Focus Tea recommendations and added Tier set section.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Adjusted the talent selections for both Raiding and Mythic+.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated Stat priorities.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **15 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Fixed a typo regarding Enveloping Breath.
- **25 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/mistweaver-monk-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/mistweaver-monk-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/mistweaver-monk-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/mistweaver-monk-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-macros-addons>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spell-summary>)):** Updated for Dragonflight pre-Patch.
- **25 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-easy-mode>)):** Updated for Dragonflight pre-patch.
- **25 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **31 May 2022 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Page reviewed for Patch 9.2.5.
- **20 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/mistweaver-monk-patch-9-2-changes-analysis>)):** Updated for the release of Patch 9.2.
- **20 Feb. 2022 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed and approved for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/mistweaver-monk-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/mistweaver-monk-patch-9-1-changes-analysis>)):** Updated for Patch 9.1.5.
- **14 Oct. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/mistweaver-monk-patch-9-1-changes-analysis>)):** Updated Covenant recommendations, emphasizing Venthyr as the optimal choice.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/mistweaver-monk-patch-9-1-changes-analysis>)):** Updated the Necrolord and Venthyr Legendaries to reflect their buffs.
- **28 Jun. 2021 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed and approved for Patch 9.1.
- **22 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/mistweaver-monk-patch-9-1-changes-analysis>)):** Page created with preliminary patch 9.1 information.
- **09 Mar. 2021 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Reviewed for 9.0.5.
- **24 Nov. 2020 ([DPS guide](<https://www.icy-veins.com/wow/mistweaver-monk-pve-dps-guide>)):** Page added.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **09 Aug. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-the-eternal-palace-raid-guide>)):** Mythic added.
- **12 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-the-eternal-palace-raid-guide>)):** Added tips for Azshara.
- **11 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-the-eternal-palace-raid-guide>)):** Added boss-specific tips.
- **09 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-the-eternal-palace-raid-guide>)):** Page added.
- **25 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **25 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **18 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-crucible-of-storms-raid-guide>)):** Additional information added from live testing.
- **16 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **16 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-crucible-of-storms-raid-guide>)):** Page added.
- **22 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **07 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-uldir-raid-guide>)):** Page added.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Mistweaver Monk leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Monk leveling guide](<https://www.icy-veins.com/wow/monk-leveling-guide>).

1.

### Mistweaver Monk Leveling Guide for Midnight

Of the three Monk specs, Mistweaver is probably the slowest in terms of
leveling speed. If your goal is to reach max level as quickly as you can, it is
highly recommended to level as a Windwalker. That being said, there are niche
situations in which Mistweaver can be extremely useful. Depending on your level,
due to our sustain, Mistweavers can solo elite quests (albeit slowly) by simply outlasting
a dangerous mob and chipping away at its Health pool in between healing
ourselves. Outside of that, Windwalker outclasses Mistweaver in almost
every way for leveling.

If you choose to level as a Mistweaver, then you ought to be spending as much
time as possible inside dungeons, with your goal being to rush to the end and re-queue
as quickly as you can in order to maximize the experience gained from the RDF queue bonus (the bonus
experience gained for queueing in the Random Dungeon Finder).

You will need to move with confidence as a form of non-verbal communication with your tank. If your
tank sees you timidly waiting at the back of the group for them to go pull something, they
might pull slowly, because they are unsure of what you are comfortable doing. Make it
clear via your actions that you don't want to stop moving forward until you have to
kill a boss.

Run along side your tank, use your movement abilities to stay with them, or even pull for
them if they agreed to you doing so. Use [[spell:116841]] on them so they can keep up
with you. Of course, as you level up and dungeons start to become harder, you will have
to temper your pro-active pulling and movement based on your and each group's comfort level.

Lastly, it bears mentioning that you shouldn't take this "aggressive movement"
playstyle to force your tank or the group into playing in a way that they are not comfortable with.
Normally, pulling mobs to a tank, or running ahead, is frowned upon unless communicated in
advance, so make sure to ask your tank if they are fine with it, and remember that
bludgeoning them into playing in a way that they are not comfortable with is going to
lessen everyone's enjoyment of the game.

1.1.

#### Leveling Gear Options

When leveling, you should always select the pieces with the highest item
level. Between two equivalent pieces, try to prioritize Critical Strike and
Haste.

If you have access to them, equipping Heirloom items provides a strong boost
to your leveling experience while also removing the need to constantly replace
certain item slots.

We recommend picking up pieces with as much Critical Strike as you can find.
This will increase both your DPS, as well as making your healing more efficient.
Haste is also good for Mistweaver DPS. However, it is less desirable for the
other Monk specs, so if you plan on swapping around, it might be better to have
your second priority by Versatility instead.

1.2.

#### Useful Leveling Consumables for Midnight

There are a couple of consumable items that can
significantly increase your speed while leveling. These are by no means
compulsory. However, they can be a nice quality of life change.

- [[item:109076]] is a leveler's best friend. It reduces your
  falling speed while also granting a large forward velocity. Any time you are
  able to jump from a high place, these will get you to your destination very
  quickly.
- [[item:132516]] are an Engineering item that increases your movement speed
  by 200% for 25 seconds. The drawback, however, is that you cannot stop moving, so
  you will either need to click off the buff or wait for it to time out. Any
  time you need to cover a large distance, these are good to use.

2.

### Leveling Talents

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Mistweaver Level 80 Midnight Leveling
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLDL2MjZshtttZMDzsttMzYhhmxMgBDzgZmZGmNYYWmJAAAAAAYBWmlZGAAAAwMgBYRGzA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MjZsZsttNjZ2Mz22yMjFGaGzAGMMDmZmZY2wMMLzEAAAAAAsYZmlZZmBAAgBgZAjBWkxMA"
}
```
:::

:::details 来源计算器编码
```
#OE-oHKJwAkkNhddFozqcohFZ68ESTLz744a7mI-pORoEFnmYSe8RSir8gjADiKo+95tpFb2EwWN--QYOMUaSGQUAQgA-
```

:::

2.1.

#### War Mode Talents for Leveling

As you level up, you will gain access to War Mode,
allowing you to participate in world PvP while also giving a small boost to
your experience gained and allowing you to use PvP talents in the open-world.
Unfortunately for Mistweavers, essentially, none of our PvP talents help almost
at all with leveling. However, they are still better than nothing, so listed
below is the ideal setup for leveling.

1. [[spell:287503]]: Provides a nice passive haste bonus.
2. [[spell:410777]]: As it is the only remaining damage increase.
3. [[spell:353361]]: To give you damage reduction if you find yourself stunned.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 10 起：**Use [[spell:322109]] to instantly kill an enemy
   with lower Health than you.
2. **等级 10 起：**[[spell:107428]] should be pressed on
   cooldown.
3. **等级 7 起：**[[spell:101546]] when there are 4 or
   more enemies.
4. **等级 2–18：**[[spell:100784]] should be pressed on
   cooldown.
5. **等级 2–18：**[[spell:100780]] should be pressed whenever
   Blackout Kick is unavailable.
6. **等级 19 起：**[[spell:100780]] should be used until you gain
   4 stacks of [[spell:116645]].
7. **等级 19 起：**[[spell:100784]] when you reach 4 stacks of
   Teachings of the Monastery.
8. **等级 5 起：**[[spell:117952]] should be used to
   engage targets at a distance, or to deal damage when you cannot get into melee
   range

**等级 15 起：**At level 15, you will be able to queue for the Dungeon
Finder. Your goal while leveling as a Mistweaver should be to join as many
dungeons as possible, as queue times healers are short, and dungeons provide
a great deal of experience. An added benefit is being able to practice your
healing rotation. For a more in-depth look, visit our [rotation
page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-rotation-cooldowns-abilities>). For a quick glance at your spell priority, continue reading below:

1. **等级 13 起：**Use [[spell:116680]] on cooldown.
2. **等级 2 起：**Apply [[spell:115151]] on cooldown.
3. **等级 17 起：**Use [[spell:124682]] and
   follow up with [[spell:116670]] as needed.
4. **等级 15 起：**Use your DPS rotation when no other healing is required.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for patch 11.2.
- **15 Jun. 2025:** Reviewed for patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **20 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated Talent selection for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **25 Mar. 2024:** Updated the foreword to include dungeon leveling.
- **29 Jan. 2024:** Updated a few Talent choices and fixed pathing to Invoke Chi-Ji.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Updated Talents for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **05 May 2023:** Updated PvP and PvE talents.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Mistweaver Monk in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Mistweaver Monk

This page is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous subtleties and active abilities that need to be taken into
consideration for optimal play.

Mistweaver Monks are versatile healers that can cover both the single target
and AoE healing roles. Mistweavers are peculiar in that they can also
heal by dealing damage, sometimes referred to as <em>fistweaving</em>.

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_renewingmists.jpg>) **Renewing Mist is Life**  
   
    An enormous swath of Mistweaver's kit revolves around [[spell:115151]].
    It's a powerful HoT all on its own, and it enables your bread and butter [[spell:116670]]
    to hit additional targets. Make sure to cast this ability as close to on cooldown
    as possible to ensure proper coverage on your group.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_monk_risingsunkick.jpg>) **You Are a Melee Class**  
  
    While Mistweaver can cast and do the majority of its rotation from ranged, in 
    terms of targeting for boss mechanics, the game will treat you as melee. It's important
    to take advantage of that to leave room for your ranged players. Ability targeting is 
    more nuanced than that, but <em>generally</em> you will be immune to ranged only
    mechanics unless they specifically target healers.
- ![](<https://static.icy-veins.com/images/wow/large_icons/monk_ability_cherrymanatea.jpg>) **Don't Forget Mana Tea!**  
  
    Mistweavers have active mana regeneration: spending mana generates [[spell:197908]]
    stacks and consuming Mana Tea stacks generates mana. However Mana Tea only stacks
    up to 20 and it is easy to forget to use Mana Tea if you aren't low on mana!
    Ensuring that you're using Mana Tea before you cap will ensure you don't run 
    OOM later on.

2.

### Beginner's Guide to Mistweaver Monk in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials   Raid Talents

2.1.

#### Beginner Raid Talents for Mistweaver Monk

These talents listed are selected due to ease of use and are not necessarily
the "correct" choice for optimal play. The reason for this is that even though
they might not produce the highest throughput as opposed to other talents,
if you select the more optimal talents and then use them incorrectly, then your
throughput will be lower comparatively.

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZbbmxCzoZMDYwghlZmZGmNYYWmJAAAAAAYxyMLzyMDAAMgBYGwYgFZMDA"
}
```
:::

:::details 来源计算器编码
```
#OE-oHKJwAkNhddFozqcohFZ68ESTLz74Y7WFCV-poEnmdigYUWSib4hBSBjTso895JqsqCL-AAAA-QYOMUaSGQUAQgA-
```

:::

Your goal is to maintain a large number of [[spell:115151]]s on the raid
so that you are able to group heal with [[spell:116670]] and [[spell:124081]] at
a moment's notice. [[spell:322118]] should be used as often as
the fight allows. Given its short cooldown, it is a stellar way to blanket the raid
in [[spell:124682]] and [[spell:115151]], thanks to [[spell:388847]].

If you are looking for the optimal talent builds, then you can find a more
in-depth examination of the available talents in the link below. It is
**<em>highly</em>** recommended that once you feel confident and comfortable
playing Mistweaver, you "graduate" from this build onto the more optimal ones.
They take a little more effort but are very rewarding and fun to play.

[Mistweaver Monk Talents and Builds Page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials   Dungeon Talents

2.2.

#### Beginner Dungeons Talents for Mistweaver Monk

These talents listed are selected due to ease of use and are not necessarily
the "correct" choice for optimal play. The reason for this is that even though
they might not produce the highest throughput as opposed to other talents,
if you select the more optimal talents and then use them incorrectly, then your
throughput will be lower comparatively.

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MmZsZstsMjZ2Mz22yMjFmRzYGwgBDLzMzMMbwwsMTAAAAAAwilZWmlZGAAYAAmBMGYRGzA"
}
```
:::

:::details 来源计算器编码
```
#OE-oHKJwAkNhddFozqcohFZ68ESTLz74Y7WFCV-poEFnmcigYSescgkE3gDDU:+8aEVkspBbGwW--QYOMUaSGQUAQgA-
```

:::

Your goal with is to maintain [[spell:115151]] on your entire group, while relying
on [[spell:101546]] to take care of the rest of the healing through [[spell:216113]]
and [[spell:467293]]. When extra spot healing is needed, you can fall back on instant cast [[spell:399491]]s
from [[spell:388812]], or if even more single target healing is required, swap to
[[spell:115175]] and [[spell:124682]] on the targets needing the most attention.

You will want to regularly use [[spell:107428]] in order to extend the duration of
your HoTs as well as provide some minor priority damage to specific targets.

If you are looking for the optimal talent builds, then you can find a more
in-depth examination of the available talents in the link below. It is
**<em>highly</em>** recommended that once you feel confident and comfortable
playing Mistweaver, you "graduate" from this build onto the more optimal ones.
They take a little more effort but are very rewarding and fun to play.

[Mistweaver Monk Talents and Builds Page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-spec-builds-talents>)

### Mistweaver Monk   Basic Rotation

2.3.

#### Single Target Healing

The list below goes over the tasks you should perform when healing a
single target (such as a tank). This is not a priority list, and you will have to adapt
your spell usage to the situation.

- Keep [[spell:115151]] on cooldown as much as possible while in combat.
- Use [[spell:115175]] on targets that will take constant damage.
- Use [[spell:116670]]/[[spell:399491]] on targets who need healing (often times cast <em>while</em> channeling [[spell:115175]]).
- Use [[spell:124682]] if your target is going to take heavy damage
  over 6 or 7 seconds.

2.4.

#### Raid Healing

If you are healing raid damage, you will tailor your use of spells to how
many targets are taking damage (and not to how much damage there is).

To begin with, you should use [[spell:115151]] and [[spell:107428]]/[[spell:467307]] on cooldown.
Blanketing the raid with Renewing Mist and then extending it with Rising Sun Kick with result in the lion's share of our healing,
and enables [[spell:116670]] to hit many more targets.

If the two abilities mentioned above are on cooldown and there are 3-4+ raid members taking damage, then you should use [[spell:116670]]
to top them off.

Make sure to be using [[spell:116680]] as close to on cooldown as you can
to proc you [[spell:443294]]. Ideally, you should line up these abilities for heavy damage windows, while not waiting too
long and losing effective casts.

2.5.

#### Cooldowns

As a Mistweaver Monk, you have a number of cooldowns in your arsenal, which
you must use in tandem with your regular rotation.

- [[spell:116680]] should be used as many times as possible during
  the encounter. You should normally use this spell either on [[spell:115151]]
  to for the duration on your HoTs, as well as the haste buff from [[spell:388491]]
- [[spell:116849]] should be used on the tank or another target who is
  about to sustain a large amount of damage. You should time this in such a way
  that its effect coincides with dangerous encounter abilities.
- [[spell:115310]] is a raid-wide heal, and it could be considered a raid
  cooldown, in which case your raid leader may ask you to use it at a specific
  time. Otherwise, just use it when the raid is dangerously low or when you want
  to dispel the entire raid.
- [[spell:322118]] you need to be aggressively casting [[spell:124682]]
  to make use of the mana reduction, as well as to blanket the raid in [[spell:115151]]s via
  [[spell:388847]].

2.5.1.

##### Apex Talent: ![Spiritfont Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_shoulder__inv_leather_raidmonkmythic_s_01.jpg>) Spiritfont

While [[spell:1260511]] is largely passive, we are afforded some agency on when 
to utilize it, as the proc's activation is tied to [[spell:124682]]. Most of the time,
if you are in a situation in which you would cast Enveloping Mist, then the proc from Spirit Font
would not go to waste. However, if you see that a particularly dangerous damage event is coming soon,
it can be advantageous to hold off on casting Enveloping Mist to line up Spirit Font with said event.

2.5.2.

##### Season 2 Tier Set

The Midnight Season 2 Tier puts strong emphasis on pressing [[spell:107428]]/[[spell:467307]]
as much as possible.

1. [[spell:1296619]] — [[spell:107428]] deals 30% increased damage and [[spell:467307]]'s healing is increased by 100%.
2. [[spell:1296620]] — [[spell:107428]] and [[spell:467307]] have a chance to cause their next cast to ignore their cooldown and reduce their mana cost by 100%.

### Mistweaver Monk   Stat Priority

2.6.

#### Stat Priority for Mistweaver Monk

Currently, you will want to prioritize stats as follows.
For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>).

Item Level

Haste

Critical Strike

Versatility

Mastery

While these priority lists are a good rule of thumb, you should not be
valuing them over item level. Generally, any piece that is 3-6 item level
above another will be an upgrade, regardless if it does not have optimal stats.
The exception here is in the case of rings and items with tertiary stats like
leech.

### Blizzard   Combat Assistant

2.7.

#### Combat Assistant for Mistweaver Monk

Patch 11.1.7 introduced the [Combat Assistant](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>)  as a means to help players build
muscle memory for their rotations. Unfortunately due to the dynamic nature of healing,
it doesn't help us outside of assisting in our DPS rotation.

Even then, because Mistweaver's DPS rotation is so often tied into our healing
"rotation" through talents like [[spell:467293]], the use of this tool may end up doing more harm than good.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **18 Aug. 2026:** Updated Raid talent recommendations.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated fro Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Edited talents for Patch 12.0.1.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Sep. 2025:** Added rotational information about our Tier Set.
- **04 Aug. 2025:** Updated for patch 11.2.
- **15 Jun. 2025:** Reviewed for patch 11.1.7.
- **21 Apr. 2025:** Reviewed for patch 11.1.5.
- **24 Feb. 2025:** Updated talents for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated Talent choices for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated talent recommendations for Season 4.
- **21 Mar. 2024:** Updated for Patch 10.2.6.
- **23 Jan. 2024:** Updated recommended Talents.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Adjusted Talent selection to reflect the 10.2 changes.
- **04 Sep. 2023:** Adjusted Talent selection to reflect the 10.1.7 changes.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Changed the talent recommendations for Patch 10.1
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated Talent tree to reflect the 10.0.5 rework.
- **11 Dec. 2022:** Updated Stat priorities.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Mistweaver Monk in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Mistweaver Monk

In season 2 of Midnight, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials has remained
the dominant hero talent selection for Mistweavers in all contexts, however which
type of content you are running will drastically alter your options within the spec 
tree itself.

- **Raid** — This build has remained relatively unchanged throughout the
    season, focusing on a wide proliferation of [[spell:115151]] across as
    much of the group as possible. This in conjunction with [[spell:116670]] cleaves
    will result in he bulk of your HPS.
- **Mythic+** — As the season has progressed, the once niche "Apexless"
    build has become the clear favorite to progress through all levels of Keys. Eschewing our
    Apex talents allows us to pick up extra baseline talents that double down on our
    "DPS to Healing" play style, with next to no loss in survivability for the group.

Our raid build shines when it a swath of potential [[spell:115151]] targets,
quickly spreading and extending your HoTs with talents like [[spell:388847]]
and [[spell:274909]]. Conversely, our Mythic+ build gets it strength from being
able to use [[spell:101546]] buffed by [[spell:216113]] to turn 
mass AoE pulls into extremely strong healing throughput.

**Quick Start Import Codes:**

:::talents Mistweaver Raid - Conduit of the Celestials
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZbbmxCzoZMDYwAsMzMzwsBDWmJAAAAAAYxyMLzyMDAAMgBYGwYYsMZMDA"
}
```
:::

:::talents Mistweaver Mythic+ - Conduit of the Celestials
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MmZsZstsNjZ2Mz22yMjFmRzYGwgBDmZmZY2GmhZ5BmAAAAAAgFLzsMLzMAAwAAMDYMwiMmBA"
}
```
:::

:::talents Mistweaver Delves - Conduit of the Celestials
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MzMz2G2sNjZ2Mz22yMjFmZaGzYBDGglZmZGmNYwyMBAAAAAALWmZZWmZAAAYAYGwAsMZMDA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Conduit of the Celestials

Rising Mist Raid Build

recommended

DPS Mythic+ Build

recommended

Solo-Delves

Master of Harmony

Raid Talents

Mythic+ Talents

### 天赋方案 0-0

1.1.

#### Rising Mist Build

This build's goal is to maintain a large amount of [[spell:115151]]s
during our Invoke windows, and aggressively spot healing with [[spell:116670]] outside
of our cooldowns. [[spell:467307]] also needs to be cast on cooldown to
maximize the HoT extension effect it brings.

### 天赋方案 0-1

1.2.

#### DPS Mythic+ Build

This build skips our Apex talent, and instead allocates those points into
talents like [[spell:1277302]], [[spell:1268807]], and [[spell:197895]].
The idea is to spend 100% of your Thunder Focus Tea charges on [[spell:107428]] in
order to trigger the [[spell:388193]] from Emperor's Elixir. The stomp does a
sizable amount of damage that is also converted into healing via [[spell:388023]].

You can either use Thunder Focus Tea on cooldown for max damage, while using
the standard [[spell:101546]] in between for filler, or you can save
your charges and use it as a mini-dealing cooldown on large AoE packs.

### 天赋方案 0-2

1.3.

#### Delve Soloing

The [Delves](<https://www.icy-veins.com/wow/delves-guide>) build is largely the same as our Mythic+ Build
while taking talents to create distance on your enemies like [[spell:450335]].

In general, you will want to pull as aggressively as you can while using
your [[spell:388023]] talents and [[spell:101546]] to keep
yourself alive. If you find that your passive healing is being outstripped by your
damage intake, then HoT yourself up, and if that's still not enough, then make use
of your mobility and [[spell:450335]] in order to create some breathing
room for you to be able to heal yourself.

It should be noted that Windwalker is likely the superior option for solo
delve content, as the moment-to-moment gameplay is extremely similar, but Windwalker
will just put out more DPS. In both instances, you will be in melee, hitting
[[spell:100780]], [[spell:100784]], and [[spell:107428]], however
Windwalker at least has a fully fleshed-out damage kit and isn't at the whims
of our dear NPC Veleera Sanguinar to follow and attack the correct targets.

### 天赋方案 1-0

1.4.

#### Master of Harmony Raid Build

This build is not recommended at this time, as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony's
talents do not scale well in a raid environment. That being said, if you just want to have a little fun and play something slightly different,
the MoH build has the same fundamentals as the CotC build, just with a few minor differences.

You will still want to maintain a high uptime on [[spell:115151]] across your raid,
extending your HoTs with [[spell:274909]], but now your [[spell:116680]]
windows become more important, as each use will provide you with a healing buff.

### 天赋方案 1-1

1.5.

#### Master of Harmony Mythic+ Build

This build is not recommended at this time, as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony's
talents do not provide a throughput advantage over ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials. That being said,
if you would like to try out this Hero Talent tree just for fun, here is the recommended build.

You will want to keep [[spell:116680]] and [[spell:467307]] on
cooldown as much as possible. [[spell:101546]] will be your go-to healing and DPS
button on 5 or more targets, whereas [[spell:100780]] and [[spell:100784]]
should be used otherwise.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2YZYzixMzyyM2wYGmZZbbmxCzoZMDYwAsMzMzwsBDWmJAAAAAAYxyMLzyMDAAMgBYGwYYsMZMDA"
}
```
:::

:::details 来源计算器编码
```
#OE-HIKJoAnwcVljPNhddFgwitboi3WINtstxxG-poEnORQmZQacikEXQ5hHGo895VVh1SUJ-AAAA-QYOMUaSGQUAQgA-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MmZsZstsNjZ2Mz22yMjFmRzYGwgBDmZmZY2GmhZ5BmAAAAAAgFLzsMLzMAAwAAMDYMwiMmBA"
}
```
:::

:::details 来源计算器编码
```
#OE-oHIKANTwSUlxuuCw2ZZqcg4EqVTLbz74o4H-poOnEFmigYWm8YwgDDSScUBvpFbmvPRFJNeW--QYOMUaSGQUAQgA-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MzMz2G2sNjZ2Mz22yMjFmZaGzYBDGglZmZGmNYwyMBAAAAAALWmZZWmZAAAYAYGwAsMZMDA"
}
```
:::

:::details 来源计算器编码
```
#OE-HIJKMaQhJDUgZ68MOAh11VH7AUFNtNvjjrZ-pORnoEFmGw8RSijc5gRqbffiKa06hd6RCEYD--AEIMgogBiCTzRC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYMLzMzMMbDGsYCAAAAMLTLz2MLzGAAAADYmZAgxwYBDA"
}
```
:::

:::details 来源计算器编码
```
#OE-HIJKNTouwkBwMpyGggy66qbAqim2m3vxx2M-pORnoEFmHy4RSirjU5gRKVVWY9++EVOB-AAAA-FIUY8QZhpJQCAE-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MmZsZstsNjZ2Mz22yMjFmRzYGwgBjZZmZmhZbwglHYCAAAAMLTLz2MLzGAAAADwMDAMGYBDA"
}
```
:::

:::details 来源计算器编码
```
#OE-HIJKNTowkBwMpyGggy66qbAqimm3vxx2szN-poEFOnmigYSu84gDDSScBUFVk8914tpFbGwW--FIUY8QZhpJQCAE-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a  system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>). 
It unlocks a range of minor customization options that can improve your character's
performance after completing a multi-step questline. Some of these bonuses
increase your damage output, while others provide defensive benefits.

Wrecommend selecting the bonuses listed belowm, however, since you can switch
between options freely at any time, don't hesitate to experiment and find the
setup that best suits your playstyle if the recommended choices aren't
providing the results you're looking for.

- Week 1:[[spell:1279599]]
- Week 2:[[spell:1279604]]
- Week 3:[[spell:1287555]]
- Week 4:[[spell:1279610]]
- Week 5:[[spell:1279614]]

3.

### Apex Talent: ![Spiritfont Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_shoulder__inv_leather_raidmonkmythic_s_01.jpg>) Spiritfont

Midnight has introduced additional capstone abilities to each spec's tree called Apex Talents.
These abilities are separate from the rest of the tree, and require you to be level 81 before
you can invest points into them. Mistweaver's Apex talent is called **Spirit Font**.
Below we will list what each of the four ranks of Spirit Font will provide to you:

1. [[spell:1260511]] — Causes your [[spell:116670]] and [[spell:107428]]
     to grant you a buff that causes your next [[spell:124682]] to channel [[spell:115175]]
     onto up to 5 targets at 20% effectiveness. If a target is at max Health, the Soothing Mist will
     jump to a new target, or split its healing among the other 4 targets.
2. [[spell:1260677]] — [[spell:107428]] damage is increased by 10%/20%
     and [[spell:124682]] healing is increased by 10%/20%. This bonus is increased by 50%
     while Spirit Font is active.
3. [[spell:1260680]] — [[spell:116680]] activates Spirit Font, and applies
     Chi Cocoons to targeted allies at 30% effectiveness.

The effect of Spirit Font is largely passive, however, because its activation is predicated on
casting [[spell:124682]], it does pose some conflicts with our ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials 
hero talent tree. CotC has us casting Enveloping Mist rationally in order to get value from [[spell:443110]].
As such, when running Spirit Font, you will need to be aware of your procs and weigh whether or not
you want to hold an Enveloping Mist cast for an upcoming damage event in order to line up your Spirit Font healing
and shielding.

4.

### Hero Talents

Mistweaver Monk has access to two powerful Hero Talent trees, each of which
augment out gameplay in different ways. These are ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials 
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials centers around calling forth the power of the August body to empower 
your spells. These procs such as [[spell:443087]] cause your rotational abilities to do
additional healing and damage, while also triggering secondary effects like [[spell:443110]]
to allow your to shield your group from damage.

It's on-use ability [[spell:443028]] is a powerful group wide damage
and healing cooldown that you will be able to activate with relative frequency.
On a 90 second cooldown you will channel a large amount of healing split between your group,
while also dealing AoE damage to any enemies nearby.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony revolves around storing vital energy within you in order
to release it after drinking a [[spell:116680]]. For the next 10 seconds, this to cause your spells and
abilities to do extra damage and healing in the form of a Hot/Dot.

The identity of this talent tree is generally centered on dealing extra damage
through passives like [[spell:451024]], and the versatility of being able
to spend your stored energy on DPS abilities during times of low HPS requirements.

5.

### PvP Talents (War Mode)

PvP talents are PvP-centric options that activate out in the world
when you enable War Mode in the talent pane or when participating in instanced
PvP content. If you are comfortable with being flagged for PvP, some offer great
benefits to questing.

You are permitted to choose three talents from the PvP Talents list. Here is
a recommendation of those most helpful for questing.

- [[spell:353584]] reduces the cooldown of [[spell:119996]] by
  15 seconds and allows you to port while stunned.
- [[spell:353502]] removing hostile magic effects from your target
  causes you to deal 10% increased healing to them for 10 seconds, stacking up
  to three times.
- [[spell:353508]] while channeling [[spell:115175]], you can a
  stacking buff increasing [[spell:322101]]'s healing by 15% and allows it to
  dispel one Poison, Magic, and Disease effect from the target.
- [[spell:205234]] places a small orb on the ground that heals friendly
  targets who walk over it while also removing all harmful magic DoT effects.
- [[spell:209584]] causes you to be immune to silence and interrupt effects
  for 5 seconds on a 30-second cooldown.
- [[spell:233759]] allows you to shoot a rope at a target, disarming them
  of their weapons for 6 seconds on a 45-second cooldown.
- [[spell:287503]] Your first [[spell:100780]] on a target grants 20%
  haste for 8 seconds.
- [[spell:353361]] causes you to take 30% less damage while stunned. This
  damage reduction decays by 10% per second.
- [[spell:202370]] Knocks back your opponent.
- [[spell:353313]] Reduces [[spell:115310]]'s cooldown by 50% and makes
  targets hit by it immune to magic for 2 seconds.
- [[spell:353936]] causes [[spell:116680]] to make your
  [[spell:117952]]'s knockback trigger instantly or causes
  [[spell:191837]] to increase your movement speed by 70% and make you immune
  to movement-impairing effects.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **18 Aug. 2026:** Updated Raid Talent Recommendations.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Omnium Folio section.
- **19 May 2026:** Updated recommended talents.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **31 Mar. 2026:** Added DPS talent build.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Patch 12.0.1.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **10 Aug. 2025:** Updated Raid build to use Lotus Infusion instead of Chi Harmony.
- **04 Aug. 2025:** Reviewed for Patch 11.2
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated Talent builds to reflect the 11.1 changes.
- **15 Dec. 2024:** Added a Mythic+ Master of Harmony build.
- **30 Oct. 2024:** Updated Rising Mist build.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **12 Sep. 2024:** Added section on how to fix the Jade Bond bug.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **28 Aug. 2024:** Added recommendation for Solo Delve Talents.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Updated all talent trees to reflect the new talents added in Patch 10.2.6.
- **15 Jan. 2024:** Updated the name of Faeline Stomp to Jadefire Stomp.
- **12 Nov. 2023:** Slightly altered the recommended Clouded Focus talent build.
- **06 Nov. 2023:** Updated all talent trees to reflect the Patch 10.2 changes
- **04 Sep. 2023:** Updated all talents trees to reflect the Mana Tea change, and other shuffling of talent positions.
- **10 Jul. 2023:** Updated for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1, and added the Clouded Focus build.
- **20 Mar. 2023:** Updated to reflect the addition of  the talent Legacy of Wisdom.
- **24 Jan. 2023:** Updated to reflect the 10.0.5 talent tree rework.
- **11 Dec. 2022:** Adjusted the talent selections for both Raiding and Mythic+.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **15 Nov. 2022:** Fixed a typo regarding Enveloping Breath.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Mistweaver Monk, depending on the type of damage your group
is receiving. We also have advanced sections about cooldowns, procs, etc.
in order to minmax your healing output and your mana efficiency. All our
content is updated for World of Warcraft Patch
12.1.5.

1.

### Mistweaver Monk Gameplay and Rotation Guide

The following will be a thorough explanation of your goals while
healing certain content. Unlike DPS players, our rotation is much
more dynamic and changes based on moment-to-moment gameplay.

By selecting talents and Hero Talents below, the rotations in this guide will
update accordingly.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

Raid

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/master-of-harmony.webp>) Master of Harmony

Raid

Mythic+

Active Talents

Passive Talents

[[spell:1250566]]

[[spell:467293]]

[[spell:1260511]]

[[spell:1268807]]

[[spell:438439]]

### Raid

1. [[spell:116670]] if someone is about to die
2. [[spell:115151]] if at 3 charges
3. [[spell:197908]] if at 20 stacks
4. [[spell:1250566]]
5. [[spell:116670]] if at 2 [[spell:124081]] stacks
6. [[spell:124682]] if at 2 [[spell:1260511]] stacks
7. [[spell:116680]] - (spent on [[spell:115151]])
8. [[spell:116670]] if a significant portion of the raid is injured
9. [[spell:124682]] if buffed by [[spell:443110]]
10. DPS if no one is in danger ([[spell:100780]] into [[spell:100784]])

---

Basically, your goal is to try to maintain a high uptime on [[spell:115151]] across the raid, while also not over-capping on your procs or ability charges.

### Mythic+

1. [[spell:116849]] on someone if they are about to die
2. [[spell:116680]]
3. [[spell:107428]]
4. [[spell:101546]] if you have a [[spell:438439]] proc
5. [[spell:399491]] critically injured targets
6. [[spell:115151]] if at 3 stacks
7. [[spell:197908]] if at 20 stacks
8. [[spell:101546]] if there are 5 or more enemies
9. [[spell:124682]] if buffed by [[spell:443110]]
10. [[spell:100784]]
11. [[spell:100780]]

---

You rotation in Mythic+ is going to be fairly fluid and reactive. The bulk of your healing is going to be done through [[spell:101546]] via [[spell:216113]], but when someone takes an unexpected spike of damage, a quick [[spell:399491]] can be used to top them off.

2.

### Midnight Season 2 Tier Set

The Midnight Season 2 Tier puts strong emphasis on pressing [[spell:107428]]/[[spell:467307]]
as much as possible.

1. [[spell:1296619]] — [[spell:107428]] deals 30% increased damage and [[spell:467307]]'s healing is increased by 100%.
2. [[spell:1296620]] — [[spell:107428]] and [[spell:467307]] have a chance to cause their next cast to ignore their cooldown and reduce their mana cost by 100%.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Mistweaver Monk
kit, we have compiled a more detailed look at some of the nuances of certain aspects
of the spec. From proper usages of certain cooldowns, to specific interactions of abilities,
knowing the ins and outs of your class can help you reach your full potential.

### Soothing Mist Targeting

3.1.

#### Soothing Mist

[[spell:115175]] is a cheap, efficient, channelled heal that allows
us to instantly cast all of our other single target abilities onto that target
without breaking the channel. It also has a 1-second global cooldown, as
opposed to the normal 1.5, meaning it is faster to channel Soothing Mist then
[[spell:116670]] than it would be to just cast Vivify on its own.

It used to be the case that swapping targets while channeling Soothing Mist would
break the channel, which would actually increase the effective time between heals 
if you were swapping targets, but as of Midnight, if you are channeling Soothing Mist
on one target, then cast [[spell:116670]] or [[spell:124682]] on another, the
Soothing Mist will follow your cast to the new target.

### Rising Sun Kick

3.2.

#### Rising Sun Kick

[[spell:107428]] is a core DPS and healing ability for Mistweavers and
our strongest single-target damage ability. Its cooldown is augmented by 3 separate
mechanics, offering some on-the-fly randomness and variation to our rotation.
First, Haste will reduce its cooldown so that it will always be in sync with
your GCDs. Second, [[spell:116645]] give [[spell:100784]]
the chance to reset Rising Sun Kick. Third, [[spell:116680]] can reduce
the cooldown by 9 seconds. This reduction happens before the haste reduction,
so you will always have 1 global cooldown in between your two Rising Sun Kicks.

It is a good idea to plan out your [[spell:100784]]s in such a way that
they provide high-value resets. For example, using a 4-stack Blackout Kick when
[[spell:107428]] has 3 seconds left on its cooldown and is generally pretty
weak when you could save it and get a very high chance for a 1st GCD reset.

[[spell:107428]] is also a large driver of our healing through talents
such as [[spell:274909]], [[spell:388847]], [[spell:388023]],
[[spell:446260]], and [[spell:173841]].

### Roll Momentum

3.3.

#### Roll Momentum

Roll often times is used in the same way a dash would, however unlike other dashes
that simply move your character a set distance forward like [[spell:344865]], Roll is actually a movement
speed increase like [[spell:2983]]. When you press Roll, your character is locked into
the directional button you were pressing, then given a ~400% movement speed increase
for a few seconds. Most of the time this distinction does not matter much, however,
when rolling off of ledges or other such terrain, your character will retain the 
velocity of the roll until they hit the ground, allowing you to travel much farther.

Furthermore, this quirk can be paired with [[spell:449582]] and
[[spell:115008]]. When you start losing horizontal velocity, you can do a mid-air
torpedo and quickly mash the space bar to proc the dash from Lighter than Air. Normally, any
dash will cancel your momentum while falling, but if you are quick enough, 
Chi Torpedo's speed boost lasts just long enough to carry over the dash, allowing you to
reset your horizontal velocity.

### Spirit Font

3.4.

#### Spirit Font

Spirit Font’s gameplay is largely passive, though its activation requirement will sometimes introduce friction in your rotation.
Because it only triggers when you cast [[spell:124682]], its value is directly tied to how choose to use that spell.

This creates natural tension with the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials hero talent tree, as
CotC will have you rotationally casting Enveloping in order to make use of [[spell:443110]].
Spirit Font, on the other hand, may incentivize slightly different timing depending on incoming damage patterns.

As a result, optimal Spirit Font usage may require you to hold and [[spell:124682]]
in order get better alignment on damage events. You’ll need to actively track your
procs and upcoming damage events, then weigh whether casting Enveloping Mist immediately
for [[spell:443110]] is optimal, or if holding it briefly will allow you to better align
Spirit Font.

4.

### Important Cooldowns for Mistweaver Monk

### [[spell:116680]]

4.1.

#### Thunder Focus Tea

[[spell:116680]] is an active ability with a 30-second cooldown that
empowers your next [[spell:115151]], [[spell:107428]],
[[spell:124682]] cast within 30 seconds.
Depending on which spell you use the effect on, it has the following consequences.

- [[spell:115151]]: extends Renewing Mist's duration by 10 seconds
- [[spell:124682]]: makes Enveloping Mist instantly heal for a large amount
- [[spell:107428]]: reduces the cooldown of Rising Sun Kick by 9
  seconds

It is also important to note that [[spell:116680]] is not on the
global cooldown, and can be cast during channelled spells, like [[spell:115175]].

Most of your [[spell:116680]] casts should be used on 
[[spell:115151]] for the extension on the HoT, but using it on [[spell:124682]]
can also be a good idea when you need the extra boost in single-target healing.

If running [[spell:388491]], you can also select what spell you want to
empower based on what buff it will give you. Most of the time, you will still want
to go with Renewing Mist as it grants Haste; however during defensive moments,
Rising Sun Kick granting you Versatility can be the deciding factor between living 
or dying.

### [[spell:116849]]

4.2.

#### Life Cocoon

[[spell:116849]] is a single-target healing cooldown, which places a
damage absorption shield on the target, lasting for 12 seconds or until
broken by damage. While the shield is active, the target also receives 50%
increased healing from healing over time spells. It is not on the global
cooldown and will not break [[spell:115175]]'s channel if cast into the
same target.

### [[spell:322118]]

4.2.1.

##### Invoke Yu'lon, the Jade Serpent

This summons an effigy of Yu'lon lasting for 25 seconds, which will
periodically heal several members of your raid. Additionally, after you talent
into [[spell:343655]], Yu'lon will apply a shield called
[[spell:406139]] to up to 5 players within 10 yards of your target, as well as
reducing the cast time of your [[spell:124682]]s by 30%.

The game plan for this cooldown is fairly simple, you want to cast as many
[[spell:124682]]s as you can to coat the raid with your HoTs (thanks to [[spell:388847]]),
then extend them with [[spell:274909]]. First, make sure you have your haste buff
active from [[spell:388491]], and spend all your charges of [[spell:115151]]
prior to the damage event. When damage starts going out, pop [[spell:322118]]
and start rotating Enveloping Mists on the raid. After casting
3-4 Enveloping Mists, you should [[spell:107428]], pressing it every time it comes
off cooldown.  After that, you should be filling with [[spell:116670]] casts to make use
of all the extra [[spell:115151]]s you have spread via [[spell:388847]]. 
Also make sure you keep weaving in casts of [[spell:124682]] after every couple
of globals to keep your HoTs rolling.

### [[spell:325197]]

4.2.2.

##### Invoke Chi-Ji, the Red Crane

[[spell:325197]] is the Mana-friendly version of Yu'lon that
allows you to leverage your DPS to do tremendous healing. It causes all your
[[spell:100784]]s, [[spell:107428]]s, and [[spell:101546]]s
to trigger a [[spell:117907]] proc on 2 allies. Additionally, it makes
your [[spell:124682]] casts instant and cost 20% less mana.

The rotation is fairly simple; pressing Chi-Ji will grant you 4 stacks of 
[[spell:116645]], so you will want to open with a [[spell:100784]]
to spend those stacks, ideally hitting multiple targets. If large damage events are
incoming, you can cast a few [[spell:124682]]s on your group both for the HoT
but also the HPS amplification from Enveloping Mist before extending them with [[spell:274909]].

### [[spell:115310]]

4.2.3.

##### Revival

[[spell:115310]] is a raid-wide heal, which also removes 3 Magical,
Disease or Poison effects from all targets.

In most cases, you should use it for the heal it provides, but it can also be used
as a sort of "mass dispel." The spell has a 3-minute cooldown and a 40-yard
range. If a fight requires your use of Revival, but the Magic dispel would cause
a wipe, then talent into [[spell:388615]] instead. The spell functions exactly
the same, just without the Magic dispel and with the added perk of being able
to be used while stunned.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **07 Sep. 2025:** Reordered information for visual clarity.
- **04 Aug. 2025:** Updated for Patch 11.2 and added section about Tier Set rotations.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **21 Mar. 2024:** Updated the Clouded Focus ramp rotation to reflect the introduction of the Peer into Peace talent.
- **15 Jan. 2024:** Updated Faeline Stomp to Jadefire Stomp to reflect the visual update.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Adjusted Mana Tea's usage to reflect the 10.1.7 rework
- **10 Jul. 2023:** Removed old content and updated for Patch 10.1.5
- **01 May 2023:** Added "At a Glance" section and updated for 10.1
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Changed Thunder Focus Tea recommendations and added Tier set section.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Mistweaver Monk in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Mistweaver Monk

Upon reaching Level 90 in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), you have three main options to start gearing your
character: Dungeons and Raids, PvP such as Arena or Battlegrounds, and world systems
like Renown with the four main Reputations.

Once you can get invited to Mythic dungeons, be sure to complete each
one during your first week, then look to see if you can find groups for your
preferred style of play, be that Mythic+ or Rated PvP.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest all-around HPS setup from most sources for Mistweaver Monk. This does not take into account content-specific weights and instead opts for a primarily item-level-based approach.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalyzing a piece of gear into tier will cause it to retain its original stats, meaning choosing which pieces of gear to put into the catalyst becomes much more important.

- **Helm:** [[item:271875@JAACAAAG2A]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- **Shoulders:** [[item:251223@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **Chest:** [[item:281236@JAACAAgNyA]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Gloves:** [[item:271520@JAACAAgNyA]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)
- **Legs:** [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) in [Venomous Abyss](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>)

:::

:::details FAQWhat Should I Be Taking from My Vault Early?
At the start of Season 2,

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)

's become available from your Vault instead of gear, with the exception of the first week. Spending these bonus rolls on Heroic Raid bosses also awards Mythic quality items at 1/6 on the upgrade track. The final Raid boss is particularly important, as it drops two extremely powerful cantrip items. As a result, you should prioritize taking a bonus roll from your Vault during the first two weeks and use your bonus rolls on the final boss on Heroic until you have obtained both items.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAACAAgNyA]]&#10;&#10;<div>The Great Vault or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2wYN]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:268247@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:273779@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest all-around HPS setup from Mythic+ and crafting for Mistweaver Monk. This does not take into account content-specific weights and instead opts for a primarily item-level-based approach.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalyzing a piece of gear into tier will cause it to retain its original stats, meaning choosing which pieces of gear to put into the catalyst becomes much more important.

- **Helm:** [[item:273791]]
- **Shoulders:** [[item:251223]]
- **Chest:** [[item:251226]]
- **Gloves:** Wear the regular tier piece
- **Legs:** [[item:159313]]

:::

:::details TipsWhich Dungeons Should I Farm?
If you have limited time to play the game, we recommend to farm the following dungeons:

- [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>): Your Weapon, Neck, and Boots drop here.
- [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>): Has two pieces to catalyze into tier.
- [Skyreach](<https://www.icy-veins.com/wow/skyreach-dungeon-guide>): Drops your BiS Trinket as well as a Ring and Belt.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:273791@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAACAAgNyA]]&#10;&#10;<div>The Great Vault</div></td></tr><tr><th>Neck</th><td>[[item:251173@JAACAAAOyA]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></div></td></tr><tr><th>Waist</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:251153@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:273792@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273649@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250215@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251156@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td><span>&#10;<img alt="Empty Off Hand inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_off-hand.webp"/>&#10;</span></td></tr></tbody></table>

### Raid

This list contains the highest all-around HPS setup from raid and crafting for Mistweaver Monk. This does not take into account content-specific weights and instead opts for a primarily item-level-based approach.

:::details FAQWhich Tier Set Pieces Do I Want?
In Midnight Season 2, catalyzing a piece of gear into tier will cause it to retain its original stats, meaning choosing which pieces of gear to put into the catalyst becomes much more important.

- **Helm:** [[item:271875]]
- **Shoulders:** Wear the regular tier peice
- **Chest:** [[item:281236]]
- **Gloves:** Wear the regular tier piece
- **Legs:** [[item:268225]]

:::

:::details TipsWhich Raid-Items Do I Want Most?
Need to share a BiS list with your raid leader, or just want to zero in on the most important bosses and loot? We've got you covered!

- [[item:271875]] and [[item:268265]]: Both uniquely powerful items, both drop from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [Nymrissa Wavecaller](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>): Drops our BiS trinket, ring, and offhand, and boots, making it a very loot-dense fight for us.
- [[item:268211]]: Our BiS weapon - naturally a high value item to receive. Drops from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271875@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271520@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271517@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> or <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271518@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:239656@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Feet</th><td>[[item:268247@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271522@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> and <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span><span>[[item:244015]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270167@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270162@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali the Soulcoiler</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268211@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:268263@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">Nymrissa Wavecaller</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Mistweaver Monk

For healers like Mistweaver, trinkets that are often referred to as "stat sticks" are usually
a very safe pick. Unlike DPS, where random procs are very rarely wasted, healers do not always
have health bars to heal. A powerful proc can go totally unused if it does not line up with moments
of extreme damage. Usually, a strong trinket for us will be an item that has static Intellect and
a proc with a high uptime of either Haste or Critical Strike.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Mistweaver Monk Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Item</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>A Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:281215]] (<em>Note that you must be in Windwalker Spec to bonus roll this item)</em></li>&#10;<li>[[item:280835]]</li>&#10;<li>[[item:270164]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>B Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><span><strong>C Tier</strong></span></td>&#10;<td>&#10;<ul>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:251792]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores and Ascendant Venomstones

Voidcores and Ascendant Venomstones are a pair of returning systems to aid in gearing up your character:

- [Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s can be used to acquire a random item from specific bosses
    or dungeons. This system has bad-luck protection built in, in that once you receive 
    a particular item from this method, you will no longer be able to roll that item again (until
    you receive everything from that source's loot table).
- [[item:280562]]s can be used to further increase the item level 
    weapons, trinkets, and necklaces up to a maximum of 340! This system will only be available 
    on max rank Hero & Myth track items, as well as Tidal Crafted pieces.

3.1.

#### Recommended Nebulous Voidcore Usage for Mistweaver Monk

The items that you choose to target will largely be a function of what items 
you already have as well as what content you have available to you. For the short-term,
it can be valuable to send your rolls on any upgrade in order to get a burst of ilvl,
however that comes at the cost of long-term character growth, and may hamper your future
progression. Our generation recommendation is to save your rolls for high value items -
a loose priority is listed below:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Mythic or Heroic [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) for [[item:271875]] and [[item:268265]]/li>
   Mythic [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>) for [[item:270162]]
   Remaining BiS List items (prioritize a weapon if you do not have one)

:::

3.2.

#### Ascendant Venomstones

When using your Venomstones, you will want to stick to the following priority:

1. Mainhand weapon
2. Your on-use trinket
3. Your passive trinket
4. Your offhand weapon
5. Necklace

4.

### Best Crafted Items for Mistweaver Monk

Crafted items provide powerful bonus effects to gear called Embellishments. The effects
can fairly radically increase the power of a particular item slot. Your character can
have a maximum of **two Embellishments**. The cost of these Embellishments however, is
that crafted gear cannot reach the same maximum item level as Myth track pieces, meaning usually
you will want to put Embellishments on gear slots that has the lowest stat budget possible: wrists and cloaks.
That way you get all the power of the Embellishment, while minimizing the stat loss from the items.
Alternatively, you can opt use one of your Embellishments on a weapon; over the long term
this is sub optimal, however it provides the most radical boost in power at the start of a season,
or for new characters.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Mistweaver Embellishment Priority**
- For Armor: [[item:240167]]
- For Weapons: [[item:245873]]

:::

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.1.

#### Adding Sockets to Gear

Helmets, Belts, and Bracers can all be socketed using the
[[item:275707]] consumable which is acquired by skipping your Great
Vault selection. Doing so will earn you tokens, and six of those tokens can be
exchanged for the [[item:275707]], which adds a socket to any eligible
piece of gear acquired in Season 2.

5.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **18 Aug. 2026:** Updated for Pre-Season Trinket tuning.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added Sporefused gear.
- **20 Apr. 2026:** Updated trinket recommendations and added Ascendant and Nebulous Voidcore sections.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Added Puzzling Cartel Chip section.
- **04 Aug. 2025:** Updated For Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7, and added DISC section.
- **25 Apr. 2025:** Updated Puzzling Cartel Chip section.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **05 Mar. 2025:** Fixed and error on the Mythic+ weapon recommendation.
- **03 Mar. 2025:** Adjusted trinket tier list.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **17 Dec. 2024:** Updated Cyrce's Circlet section to reflect the buffs.
- **15 Dec. 2024:** Added section for Cyrce's Circlet.
- **21 Oct. 2024:** Adjusted raid trinket recommendations.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Dragonflight Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Updated trinket rankings.
- **07 Nov. 2023:** Added Changes to Embellishments.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reintroduced BiS Lists, and updated for 10.1.7.
- **10 Jul. 2023:** Added Dawn of the Infinite section.
- **24 May 2023:** Added Cataclysm Timewalking Section.
- **06 May 2023:** Added Aberrus Trinkets.
- **01 May 2023:** Updated for 10.1
- **25 Mar. 2023:** Adjusted the Onyx Annulet section to reflect the buffs to Primordial Gemstones.
- **20 Mar. 2023:** Added section of Onyx Annulet.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Jan. 2023:** Added Embellishment section.
- **11 Dec. 2022:** Reformatted the page, added a tier list for Trinkets.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Mistweaver Monk. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Mistweaver Monk Stat Priority

The stat priority for a Mistweaver Monk is slightly different depending on
what sort of content you are doing.

1.1.

#### Raiding

Item Level

Haste

Critical Strike

Versatility

Mastery

While the other three stats are all reasonably balanced, Critical Strike pulls ahead
not only because of throughput and efficiency, but because it generates [[spell:197908]]
stacks.

1.2.

#### Mythic+

Stat priorities are somewhat ephemeral for Mythic+ because they can change
dramatically based on not only your skill but the skill of your group, the
route they take, or even the affixes in play. Keep in mind the following are
loose guidelines.

Item Level

Haste

Mastery

Critical Strike

Versatility

Haste continues to be very powerful and should be your first choice for secondary stats.
After that, it depends on your goals. Mastery is an extremely powerful spot healing stat, and also buffs
our [[spell:325197]] windows. Critical Strike is good for throughput not only in
terms of healing but also DPS. Finally, Versatility offers similar throughput
to Crit (though slightly less), and has the added benefit of reducing the damage you take
which can become an important factor as you climb higher and higher keys.

If you just do a couple keys per week to fill our your Great Vault, then going Haste and Crit with a
 bit of Mastery for Chi-Ji will do just fine. **<em>However</em>** if your focus is on Mythic+ specifically,
 you may want to look into stacking Mastery after Haste. Our healing profile changed in 12.1
 to make Mastery more appealing in group content, as we now depend a lot more on our Chi-Ji to counter
 burst windows. Historically we have been hesitant to recommend Mastery each time it has been buffed,
 but initial data from the top rated Monks across regions seems to be skewing towards a Haste > Mastery build.
 Feel free to try out this new stat combination, just remember that item level will essentially always be king.

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. It increases the base power of all of your
abilities.

**Critical Strike** increases your healing throughput by granting your
healing spells a chance to heal for double the amount. [[spell:197908]]
also has a chance equal to your Critical Strike to generate an extra stack.

**Versatility** increases your throughput by a set percentage, and also reduces the damage
you take by half that amount. So 10% Vers will increase your HPS/DPS by 10%, and reduce the damage
you take by 5%.

**Haste** lowers the cast time of your heals, as well as your global
cooldown and the cooldowns of [[spell:100784]] and
[[spell:107428]].

:::details FAQIs there a Haste cap for Mistweaver Monk?
Generally, stat caps will not be a major concern until closer to the end of
an expansion. The new diminishing returns on stats only kick in once you reach
30% worth of rating, which is not the easiest thing to do. That being said,
stats gain or lose value based on their relation to each other. For example,
imagine you have 5000 Intellect and the choice between two hypothetical
trinkets: one gives 10% Critical Strike, and the other gives 750 Intellect. On
average, the Crit trinket would increase your throughput by 10%, whereas the
Intellect trinket would increase it by 15%; however, after a few weeks pass,
you will gain better gear, and now you have 8000 Intellect (excluding the
trinket). Now, that same 750 Intellect trinket only provides a ～9.3% throughput
increase, as opposed to the 10% of the Crit trinket.

Haste, specifically, is somewhat different. Haste increases cast speed, as
well as the rate at which HoT and DoT spells tick. There used to be breakpoints
for HoTs, in which it would tick quickly enough to gain an additional tick.
Thankfully, Blizzard deemed this to be a pretty negative gearing experience
because any haste rating that you had that did not reach a breakpoint was
essentially wasted stats. Instead, now all HoTs and DoTs gain an additional tick
at the end which is equal to the amount that would have been healed in the time
remaining. So, if [[spell:115151]] falls off when it was 50% of the way to
the next tick, then it will heal one last time for 50% of the normal amount.

Finally, as for casting breakpoints, there technically are still some
breakpoints you could reach, such as fitting extra casts inside [[spell:124682]] windows.
However, the gain that these niche situations would net you is often less than what you would lose for
gaining other stats.

:::

**Mastery** ([[spell:117907]]) causes [[spell:115151]],
[[spell:124682]], to also heal the their for a certain amount (determined by how much Mastery you have).

2.1.

#### Tertiary Stats

Along with the default stats listed above, items have a chance to acquire
bonus stats called Tertiary Stats. While most of these are nice bonuses, the
two you need to look out for are Leech and Avoidance.

2.1.1.

##### Leech

Leech causes you to heal yourself for a percentage of the damage and healing
that you do. By itself it is a tremendously powerful stat in terms of healer 
throughput; per point of rating it will do more throughput than any of your 
secondary stats.

Does that mean you should drop item level if in order to maintain Leech? The
answer is complicated, but generally speaking, probably not. A good rule of thumb
is that item level is the most important factor when considering how to gear your
character.

:::details TCIs Leech Really That Strong?
Like mentioned above, Leech's throughput is unparalleled, but this comes with
a huge asterisk. Because all this healing is being done to yourself, it is very
likely to overheal. Furthermore, it can be argued that a stat that exclusively
heals yourself, which cannot provide a benefit to a friendly player in need,
is inherently worse than other stats. Others could counter by saying that all
fights have some number of total healing required, and Leech reduces that
number just like any other stat.

There are further philosophical questions about what is the "true" value of
Leech. While Leech may in fact be doing a large amount of healing, it might
not actually be doing **effective** healing. Consider the following
hypothetical: you are at 90% and cast a heal, which causes your Leech to bring
you back up to 99%. While all this is happening, imagine a Chain heal is coming
your way, which will heal you for 10% of your max Health. The bounce of this
Chain Heal hits you, heals you for 1% of your Health and overhealing for 9%. In
this situation, the Leech did literally no **effective** healing because it
just sniped from another healer that was going to happen anyway. But if that
Leech was to bring you to 100%. Instead; it would have taken you off the target
table for those spells, causing them to hit people who might need the healing
more.

If an upgrade rolls with Leech, then you likely will not have to think about
these sorts of things since it's a tertiary stat; it is just a bonus on top.
But when you get your next upgrade, it can be tricky to know if you ought not to
equip something of a higher item level just because your old gear has Leech
on it. Just how much item level is Leech worth? It depends; on a fight with
constant ticking damage, where you are unlikely to ever be fully topped off,
then Leech is almost certainly worth dropping item level for, so long as you
maintain a good amount of Stamina. Otherwise, I would recommend against dropping
item level for Leech. Unless it is your first Leech piece, then dropping a
little bit of item level is okay. If you would like to get a stat rating for
Leech, check out QELive linked on our Simulations Guide.

:::

2.1.2.

##### Avoidance

Avoidance is a tremendously powerful stat that some people often undervalue
because it does not increase throughput or make your parses look better.
Avoidance will reduce the damage you take from AoE attacks by a percentage,
capping at 20%.

Most damage that you will be taking in a Raid is considered AoE, aside from
specifically targeted abilities. With this stat, you are able to significantly
reduce the amount of healing that you will require over the course of an
encounter. So not only are you less likely to die, but you will be increasing
the mana efficiency of your healing team.

All that being said, it is still not advisable to choose Avoidance over item
level gains.

2.1.3.

##### Speed

Like the name suggests, Speed increases your movement speed by a percentage,
up to 20%. Unlike the previous two, Speed does not directly change your output
or the effective healing of the group in a major way. It can be argued that
sufficient levels of Speed would allow you to gain extra casts during a fight
by reducing the amount of time spent moving. However, this is not a real concern
for Mistweavers who are already very mobile. Speed should be thought of as a
nice bonus, but never drop the item level for it.

2.1.4.

##### Indestructible

Indestructible removes the durability attribute of an item. This means you
will never have to repair it, nor will it ever break. Not much to say on this
one; it provides no benefit in combat, making it the worst of the tertiaries.

2.2.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **03 Sep. 2026:** Changed Mythic+ Stat priority.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Pruned tertiary stat section.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2
- **15 Jun. 2025:** Reworded stat priority explanations.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within Release.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Added Mana Tea's interaction with Critical Strike to the stat descriptions and recommendations.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5
- **01 May 2023:** Added Clouded Focus section and updated for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Changed the recommendations for both Raids and Mythic+.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Mistweaver Monk, based on your [stat priority](<https://www.icy-veins.com/wow/mistweaver-monk-pve-healing-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

Your priority for gems differs slightly between raiding and Mythic+, due to the difference
in how they affect your healing and DPS output.

The best stats for **Raiding** are Haste and Crit, so that is what we will be gemming for.
You should use [[item:240983]] in one socket, then fill the
rest of your sockets with [[item:240890]]s.

The best stats for **Mythic+** are still Haste and Crit, but that can change depending
on your exact goals. Haste will always be ideal to stack until you hit diminishing
returns, but depending on whether you intend
pushing into higher levels of keys, Versatility will start becoming more and more
important. It doesn't provide quite as much damage or healing throughput as Crit,
but the damage reduction component will start to become necessary to survive the 
scaling 1-shot mechanics of high keys. Adjusting your gems is the fastest way to get more
Versatility if you need it to survive.

Most of the time, you should use [[item:240983]] in one socket, then
fill the rest with [[item:240890]]s. However if you are finding that you are 
comfortable on your haste and want a tiny bit more tankiness, you can opt for [[item:240916]]
instead.

2.

### Best Enchants and Weapon Augments

The best Weapon Oil for Mistweavers is [[item:243733]] as it buffs both of our
strongest secondary stats.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Helm</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Boots</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>Rings</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244015]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

3.

### Optimal Consumables

Consumables substantially increase the power of your character for a limited time. Any
time you are challenging yourself with difficult content, it is advisable that you buff
yourself with Flasks, Food, Potions, and Weapon Oils.

3.1.

#### Flask

For most content [[item:241325]] will be your standard choice, as
it provides our strongest throughput stat. In Mythic+, there may be times in which you 
find that the extra Versatility from [[item:241320]] is more 
beneficial in order to leverage the slight damage reduction.

3.2.

#### Food Buff

For optimal throughput, you should be using [[item:255845]]/[[item:255846]]
in order to gain primary stat. However, if these feasts are unavailable to you (as they can be
cost prohibitive) then you should make use of [[item:242275]]. The secondary stat it provides is
weaker than the Intellect you would gain from a feast, but it is much more affordable.

3.3.

#### Potions

Mistweavers generally have three options for potions: [[item:241294]]
for maximal mana return, [[item:241301]] for immediate mana return, and
[[item:241308]] for throughput. Generally, in raids you will be using [[item:241294]]
and in Mythic+ you will be using [[item:241301]], but it is a good idea 
to carry a stock of all three in order to use whichever is best in the moment.

In Season 2 you now have access to [[item:271883]] 
which is significantly better than [[item:241305]]. Using
this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]] does not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.4.

#### Augment Rune

[[item:259085]] provide around 1% HPS increase and
should be evaluated during progress, especially when close to important kills.They can
be quite pricey though, so use them sparingly when truly needed.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated Mythic+ gem recommendations.
- **16 Mar. 2026:** Added section about Sanguithorn Tea.
- **05 Mar. 2026:** Fixed issue of linking to outdated gems.
- **26 Feb. 2026:** Updated for Midnight Launch.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Reviewed for Patch 11.1.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **12 Sep. 2024:** Adjusted Gem recommendations.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Update for The War Within Release.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Changed Phial recommendations.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Updated for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Updated for Patch 10.1.
- **20 Mar. 2023:** Added Primordial Gemstones.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Updated Enchant recommendations.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Mistweaver Monk in World of Warcraft Patch 12.1.5.

1.

### Mistweaver Monk in Mythic+ in Midnight Season 2

In this guide, we will talk about getting the most out of your Mistweaver
in Mythic+ dungeons, including the best way to set up your character, how your
rotation may change, and tips and tricks for using your abilities most optimally.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

2.

### Best Mythic+ Talent Builds

### Standard Mythic+ Talent Build: ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials

2.1.

#### Recommended ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/conduit-of-the-celestials.webp>) Conduit of the Celestials Mythic+ Talents

This build eschews our Apex talent, and instead allocates those points into
talents like [[spell:1277302]], [[spell:1268807]], and [[spell:197895]].
The idea is to spend 100% of your Thunder Focus Tea charges on [[spell:107428]] in
order to trigger the [[spell:388193]] from Emperor's Elixir. The stomp does a 
sizable amount of damage that is also converted into healing via [[spell:388023]].

You can either send Thunder Focus Tea on cooldown for max damage, while using
the standard [[spell:101546]] in between for filler, or you can save
your charges and use it as a mini-dealing cooldown on large AoE packs.

If you are after more DPS, swapping [[spell:467293]] for
[[spell:467307]] will net you a sizable chunk of damage at the expense 
some of the burst healing from the combo.

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLjZx2MmZsZstsNjZ2Mz22yMjFmRzYGwgBDmZmZY2GmhZ5BmAAAAAAgFLzsMLzMAAwAAMDYMwiMmBA"
}
```
:::

:::details 来源计算器编码
```
#OE-oHIKANTwSUlxuuCw2ZZqcg4EqVTLbz74o4H-poOnEFmigYWm8YwgDDSScUBvpFbmvPRFJNeW--QYOMUaSGQUAQgA-
```

:::

### Apex Mythic+ Talent Build: [[spell:1260511]]

2.2.

#### Apex Mythic+ Build

This build relies on frequent use of your DPS abilities such as [[spell:101546]] and
[[spell:100784]] in order to cover the majority of the maintenance healing in dungeons via
[[spell:216113]] and [[spell:467293]]. You will be able to maintain full coverage of
[[spell:115151]] as well by frequently pressing [[spell:107428]].

When more direct healing is required, [[spell:399491]] can be used to instantly top someone off,
then [[spell:197908]] can be used to recharge your spent Sheilun stacks.

This build lacks some of the DPS throughput that is so valuable from healers in higher keys, but if you
prefer to play with the Apex talent, it's totally fine as an option for your weekly keys.

:::talents 天赋构筑
```json
{
  "code": "C4QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAghxyMLDL2MmZshtltZMDzsttMzYhZ0MmBMYwgZmZGmthZYWegJAAAAAAYxyMLzyMDAAMgBYGwYgFZMDA"
}
```
:::

:::details 来源计算器编码
```
#OE-oHIKANTwSUlxuuCw2ZZqcg4EqVTLbz74o4H-poOnEFmigYWm8YwgDDSScU30iNz3noCP-AAAA-QYOMUaSGQUAQgA-
```

:::

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts

Midnight has removed interrupt abilities from most healers, Mistweaver included. We no longer have
access to [[spell:116705]], so we must rely on our groups to kick important casts.

3.2.

#### Stunning and "Stops"

It should be noted that for many abilities that mobs will cast, "stopping" a spell is just a stopgap to buy time.
If an enemy has a "kickable" cast that is stopped by anything other than an interrupt spell such as [[spell:1766]],
they will simply try to cast the same spell again.

[[spell:119381]] is one of your "AoE stops". It stuns all enemies within 6 yards for 3 seconds. Perfect for preventing
multiple abilities from going off at once if your group is low on kicks or for saving your tank, allowing them to create some distance.

[[spell:116844]] is your second "AoE stop" and will be used the same way as Leg Sweep most of the time.
However, rather than being a stun, Ring of Peace creates a zone on the ground that knocks any enemies out of it
and will continue to knock enemies out that try to enter. This can be used to stop a large group of mobs from casting or placed on your tank
to give them a window of safety. You can also use this ability to prevent a fixated mob from reaching their target.

Because Ring of Peace is a persistent area knock-back, in certain circumstances, you can lock enemy mobs down for
longer than intended - if two Monks are in the same group, they can create a Venn diagram with their Rings in order to bounce mobs back
forth between the two until one of them fades. In that same vein, if mobs are near a wall, with careful positioning, you can cause your ring to
infinitely knock them against the wall. Finally, Ring of Peace also does not trigger combat with a mob, meaning it can be used to
move a group of mobs out of your way so that your group can sneak by undetected.

[[spell:115078]] is an incredibly versatile spell, allowing you to instantly crowd control a single target from 20 yards away while also
not engaging in combat with them. That means if a patrol is pathing towards your group, you can Paralyze the lead mob, and usually, the adds
following them will stop and wait as well. You can also pair this with Ring of Peace in order to bounce Paralyzed mobs a bit further than
they'd normally go while also preventing them from trying to run back to where they were.

When used in combat, it can be a simple ranged single-target stop, or if talented into [[spell:450432]], it can be used to remove
enrage effects from the target as well.

### Other Utility

3.3.

#### Other Utility

[[spell:450335]] can be used to slow a large group of packs if you find that your tank has run out of
cooldowns and needs to run away from a particularly scary pull.

[[spell:101643]] is easily one of our most powerful spells, allowing us to teleport
through moving barrier mechanics, quickly reposition, or, if your reactions are fast enough,
negate knock-back abilities that would otherwise knock you off a ledge.

4.

### Dealing with Affixes

This section has Monk-specific tips for dealing with the various affixes of Mythic+.

### Affix: Ascendant

4.1.

#### Ascendant Affix Management for Mistweaver Monk

Our myriad of crowd control is excellent for this Affix. Between [[spell:116844]],
[[spell:119381]], [[spell:116705]], and [[spell:115078]], we have got more
then enough tools to assist the group.

### Affix: Pulsar

4.2.

#### Pulsar Affix Management for Mistweaver Monk

This affix is fairly straightforward for Mistweavers since we are in melee, our orbs
will be easily soaked by nearby melee.  Depending on your group, you may need to [[spell:109132]] out to tag a ranged player
instead.

### Affix: Devour

4.3.

#### Devour Affix Management for Mistweaver Monk

[[spell:115310]] can clear this in a pinch; otherwise, use [[spell:115450]] on priority targets
and just heal the rest of it off normally. [[spell:1243287]] can be used to remove it from
yourself if you think you aren't going to need the damage reduction soon.

### Affix: Voidbound

4.4.

#### Voidbound Affix Management for Mistweaver Monk

[[spell:322109]] can be used the moment these mobs spawn, as they have 1hp, but a
large shield. If talented into [[spell:394123]], you can use Touch of Death on every other
spawn.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **31 Mar. 2026:** Added "No Apex" talent build.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent recommendations for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for patch 11.1.7.
- **22 Apr. 2025:** Updated Boss tips.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.
- **15 Dec. 2024:** Added a Master of Harmony Build.
- **21 Oct. 2024:** Added Boss and Trash tips for Patch 11.0.5.
- **09 Sep. 2024:** Updated for 11.0.2
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Updated Talents for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated Talents for Patch 10.2.
- **04 Sep. 2023:** Updated Talents for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Changed the Affix and Talent sections for Dragonflight Season 2.
- **20 Mar. 2023:** Updated to reflect the 10.0.7 talent tree rework.
- **24 Jan. 2023:** Updated to reflect the 10.0.5 talent tree rework.
- **13 Jan. 2023:** Updated Talent recommendations and added a special mention for Mote of Sanctification.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Mistweaver Monk in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Mistweaver Monk macros.

1.1.

#### Specific Macros for Mistweaver Monks

Currently, we do not feel that any additional macros are needed to play a
Mistweaver Monk to its full potential, but mouseover macros are very useful.

1.1.1.

##### Mouseover Macros

For all your healing and utility spells, we advise you to use mouseover
macros such as:

#### Example Mouseover Macro

```wow-macro
#showtooltip Soothing Mist
/cast [@mouseover] Soothing Mist
```

2.

### Best Addons

2.1.

#### Specific Addons for Mistweaver Monks

Clique
essentially does everything a mouseover macro does, but faster, and with
"click-casting" functionality.  It allows you to contextually bind your left and
right mouse buttons (as well as any other button) to spells, but only when
interacting with unit frames.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight Launch.
- **10 Feb. 2026:** Reviewed for Midnight Pre-Patch
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **25 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
