## 专精概览

欢迎阅读我们的 狂徒 潜行者 指南，适用于《魔兽世界》12.1.5补丁。在这里，你将学习如何在团队副本和大秘境中扮演 狂徒 潜行者：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

狂徒 大秘境资源

[全新！顶级 狂徒 天赋构建](<https://raider.io/specs/outlaw-rogue/talents>)

[顶级 狂徒 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/rogue/outlaw>)

[狂徒 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=rogue--outlaw>)

[热门 狂徒 队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=rogue--outlaw>)

1.

### 狂徒 潜行者 概述

啊哈！狂徒 潜行者 是一个专注于管理资源同时对聚集目标维持高伤害的专精。和之前的资料片一样，狂徒 是一个出色的全能型职业，能够从容应对任何情况或战斗类型。在三个 潜行者 专精中，狂徒 在涉及顺劈DPS的情况下最为有效。

持续输出专家

狂徒 潜行者 拥有非常独特的伤害曲线，没有能提供有效爆发的高影响力冷却技能。该专精的持续DPS出色，但在面对大量目标的AOE时表现不佳，在团队副本战斗中也从未跻身顶尖。

由于大多数战斗策略都围绕使用冷却技能快速击杀首领或小怪群，狂徒 不幸地无法胜任团队副本中最重要的任务之一。如果你能接受这个弱点，那么只要能在目标身上保持高覆盖率，狂徒 的表现就非常出色。

生存能力出色，但缺乏强力冷却技能

狂徒 潜行者 凭借其出色的持续DPS，在团队副本战斗中是一个不错的选择，但如果某场战斗需要在增伤阶段打出高爆发伤害，或者需要快速击杀某个小怪，那么 狂徒 无法提供所需的伤害曲线来有效应对。

这使得它落后于大多数其他专精，因为那些专精即使整体DPS输出远低于 狂徒，仍能提供有用的爆发DPS。

然而，如果你所处的团队环境不需要这种爆发，那么 狂徒 是一个非常适合直接对首领输出的优秀专精。它独特的团队增益 [[spell:381637]] 是减轻许多团队副本首领伤害的有用工具，遗憾的是它并不适用于所有首领机制。

每波都有伤害，但缺乏爆发

狂徒 在大秘境中可以非常舒适地游玩，选择相关天赋后拥有不错的AOE伤害，代价是首领战的单体DPS略有损失。尤其是在较小的小怪波次中，狂徒 总能打出可观的伤害，不依赖任何冷却技能来击杀敌人。

然而，在任何大规模小怪波次中它确实会落后，所以如果你经常拉15只以上的怪物一起打，它无法与那些能靠自己的冷却技能单独扛下整波的其他职业竞争。

狂徒 还拥有大量实用技能，借助 [[spell:6770]]、[[spell:2094]]、[[spell:1776]] 和 [[spell:200733]]，你能像极少数专精那样干扰和控制敌人，并且它是游戏中仅有的两个拥有群体潜行能力 [[spell:114018]] 的职业之一。

大秘境表现出色，团队副本表现糟糕

狂徒 可以使用许多不同的实用技能，例如 [[spell:381637]]、[[spell:114018]]、[[spell:6770]]、[[spell:2094]]，或 [[spell:1776]] 或 [[spell:200733]]。除了虚弱毒药之外，这些技能在团队副本环境中都派不上用场。即使虚弱毒药并不适用于所有团队副本首领技能，大多数团队仍然会带上至少一个 潜行者（任意专精）来提供它。

不过在大秘境中，一个懂得运用所有看家本领的 潜行者 能够让每次通关都变得更加轻松和安全，虽然这些好处可能不会体现在DPS统计上，但如果你充分发挥你的实用技能，许多坦克和治疗都会心存感激。[[spell:200733]] 恢复为AOE[[spell:2094]]对我们来说也是一大福音，因为它不仅能干扰敌人，还能通过[[spell:379005]]降低他们造成的伤害。

极其耐打

盗贼是生存之王，尤其是在团队副本环境中。多亏了[[spell:31230]]、[[spell:1966]]、[[spell:31224]]、[[spell:5277]] 和[[spell:185311]]，你通常会是最后几个存活的人之一，这使你即使在局势不利时也能力挽狂澜地击杀首领或小怪。

当坦克死亡而你又能安全地为小怪群坦10秒时，备好 [[spell:5277]] 可以拯救整场进度，虽然 潜行者 在应对长时间持续伤害时往往比较吃力，但你拥有大量手段来活到最后。

唯一真正棘手的是持续性的持续伤害，但通过点出 [[spell:79008]]，你甚至可以在最高层数的钥石中可靠地存活下来。

移动非常灵活

狂徒 拥有出色的机动性，可以使用冷却时间很短的 [[spell:2983]]（让你跑得和骑马的角色一样快），还能使用 [[spell:195457]] 快速脱离危险，或接近距离你很远的敌人。能够跳跃到大范围内的任何位置提供了极大的灵活性，甚至可以让你完全避开某些机制的伤害。

1.

### 狂徒 潜行者 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

12.1.5补丁对 潜行者 或 狂徒 专精没有实质性改动。补丁的主要重点是2项新的终局内容，一项面向团队副本，另一项面向 [地下堡](<https://www.icy-veins.com/wow/delves-guide>)。请务必查看关于新的基斯提克斯团队副本战斗的信息，以及令人兴奋的全新迷宫巨型地下堡！

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

[12.1.5 补丁](<https://www.icy-veins.com/wow/midnight-1215-guide>) 作为至暗之夜第2赛季进程的延续，围绕乌拉特克和阿曼尼的故事最终带来了一个全新的单首领团队副本、升级装备等级的途径、多种追赶装备来源，以及无限量的雾玉用于升级装备。请务必查看我们的补丁中心，了解补丁12.1.5的所有新增或更新信息。

2.3.

#### 职业改动

狂徒 潜行者 没有任何改动，除了 [[spell:381878]] 的一次更新。

- 矫捷灵动已更新 - 不再使剑刃乱舞的能量消耗增加30点。现在，它使剑刃乱舞的能量消耗每命中一个目标增加5点，最多增加30点。
- <em>开发者说明：这一改动旨在让玩家在与少量额外目标战斗时，维持剑刃乱舞的成本稍低一些。</em>

因此，我们的
[天赋](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>) 推荐和
[输出循环](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>) 优先级没有任何变化。但是，随着新装备的加入，我们的 [装备](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>) 页面已经更新，包含了关于新物品以及如何最好地使用你的[[item:280562]]的信息。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_112_rogue_betweentheeyes.jpg>) 点击查看上赛季第二赛季的改动
12.1补丁对 潜行者 职业以及特别是 狂徒 带来了大量改动。许多其他职业的冷却技能遭到削弱，以降低爆发伤害并提高持续DPS。狂徒 在这一特定领域本就表现出色，我们获得了进一步的伤害增益来强化我们本已非常独特的伤害曲线，而我们的冷却技能也获得了一定程度的加强！

我们还获得了对表现不佳天赋的大量增益，所以你可能不再觉得被迫使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 和 [[spell:51690]]。总体而言，狂徒 的手感会非常熟悉，大体的优先级保持不变。不过，新的天赋灵活性为我们提供了一些以前没有的新机会，我们的伤害在各个方面也会更有影响力。

[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**狂徒 潜行者**

<em>开发者说明：狂徒在乌拉特克的诅咒中的改动旨在提高天赋构建的多样性和灵活性。我们增强了某些表现不佳的天赋，并回调了一些让人感觉“被锁死”的天赋。杀戮盛宴的伤害得到了显著提升，因为它造成的伤害原本不足以显著强于在引导期间使用其他技能。该天赋现在应能像其他同等天赋一样显著提升你的整体伤害。</em>

- **职业**
  
  
  
  
  - [[spell:381623]]现在是一个选择天赋——玩家现在可以在现有版本（除了可以主动使用外，还会在低能量时自动施放）和一个必须主动施放的新版本之间进行选择。
  - 虚弱毒药现在降低4%的伤害（原为3%）。
  - 虚弱毒药的持续时间增加至60秒（原为10秒）。在PvP战斗中持续时间保持不变。
- **英雄天赋**
  
  
  
  
  - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者：宿命之击在你封印命运时有60%的几率给予额外连击点数（原为100%）。
- **狂徒**
  
  
  
  
  - [[spell:51690]] 已更新——持续时间不再因消耗超出最大值的连击点而增加。每消耗一个超出最大值的连击点，伤害提高15%。
  - [[spell:13750]] 现在使 [[spell:51690]] 的执行速度加快20%，与它提高你其他攻击速度的幅度相同。
  - [[spell:51690]] 优先选择免疫伤害或受到物理伤害低于5%的目标。
  - [[spell:51690]] 伤害提高60%。不影响PvP战斗。
  - [[spell:51690]] 的射击在目标有效时，有更高几率选择你选定的目标。
    
    
    
    
    - <em>开发者说明：[[spell:51690]] 的价值很大程度上在于其产生的连击点，因此当玩家能通过 [[spell:470347]] 等方式在 [[spell:51690]] 上消耗超过最大值的连击点时，这些额外点数的价值就被削弱了。[[spell:51690]] 的持续时间现在最多为产生最大连击点所需的时间，消耗的额外连击点会按比例提高该技能的伤害。</em>
  - [[spell:235484]] 已更新——使 [[spell:315341]] 的暴击造成2.5倍普通伤害（原为3倍）。
  - [[spell:1259480]] 已更新——现在使 [[spell:315341]] 的冷却时间缩短8秒（原为5秒），并使每层 [[spell:315341]] 提供的伤害加成提高1%。
  - 所有伤害提高9%。不影响PvP战斗。
  - [[spell:381885]] 使产生连击点的攻击伤害提高15%/30%（原为10%/20%）。
  - [[spell:1259485]] 每层价值降低至2%（原为3%）。
    
    
    
    
    - <em>开发者说明：我们不希望玩家觉得必须使用副手匕首才能最大化该天赋的价值。[[spell:1259485]] 现在有30%的几率在由1.8速度的武器触发时不触发，使其在使用匕首与其他单手武器攻击时的触发几率相同。</em>
  - [[spell:381845]] 现在还使 [[spell:8676]] 的伤害提高80%。
  - [[spell:383281]] 使 [[spell:8676]] 获得 [[spell:279876]] 的几率提高到 [[spell:1752]] 获得 [[spell:279876]] 几率的100%（原为80%）。
  - [[spell:383281]] 还使 [[spell:8676]] 的能量消耗降低5点。
    
    
    
    
    - <em>开发者说明：[[spell:381845]] 和 [[spell:383281]] 不如其他天赋选项强力，因此我们为它们添加了一些效果，使其更具竞争力。</em>
  - [[spell:381990]] 使 [[spell:2098]] 的伤害提高15%/30%（原为10%/20%）。
  - 天赋树中已在 [[spell:14161]] 和 [[spell:1259457]] 之间，以及闪烁钢刃抉择节点与 [[spell:193358]] 之间添加了新的连接线。

:::

### 至暗之夜改动概述

至暗之夜 终于上线了，狂徒 潜行者 迎来了大量改动，既包括专精本身的改动，也包括 潜行者 职业整体的改动。其中许多改动已经在资料片上线前的前夕版本中实装，但我们在此列出了全部改动，以便回归玩家参考，并确保你确切知道用 狂徒 潜行者 探索 至暗之夜 时会遇到什么。

这些改动的主要目标是强化两个英雄天赋树的独特定位， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者，并通过让能量再次成为更有影响力的资源来改变循环玩法流程。[[spell:315508]]进行了全面重做，所以请务必查看它现在的运作方式！

2.4.

#### 英雄天赋改动

作为命缚者的硬币滚动现在更加稳定，不再需要消失或现已移除的[[spell:382245]]来持续触发顶点增益。它还获得了一些额外的资源生成，这将有助于弥补狂徒在所有被动技能上降低的能量生成，使专精在你没有遇到极差触发时仍然感觉流畅顺滑。总体而言，这些改动提升了命缚者在所有情况下的可用性，为我们伤害构成提供更可靠的收益，同时仍然保留其抛硬币的核心特色。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者几乎没有改动，除了每个英雄天赋树都获得的三个新天赋之外。它仍然有点不稳定的选项，尽管在地心之战期间困扰欺诈者的大多数bug都已幸运地被修复。它仍然高度依赖[[spell:441146]]触发和其顶点天赋致死一击，提供一些额外的伤害和连击点，可以帮助改善你的循环流程。

话虽如此，它在所有内容中都大幅落后于命缚者。

2.5.

#### 顶点天赋：掘墓人

[[spell:1265861]]是我们在至暗之夜中的顶点天赋，它提供了一些伤害提升，同时生成额外资源以获得更多冷却缩减。虽然不是特别花哨，但它使我们的玩法更加平滑，并且在主题上非常契合。

根据投入该天赋的点数不同，你将获得以下加成：

- [[spell:1265861]]：你的要害攻击有几率将其伤害增益效果应用两次。
- [[spell:1265862]]：当在[[spell:2098]]上消耗5个以上连击点时，你会造成额外伤害。
- [[spell:1265863]]：施放斩杀时，你有基于所消耗连击点的几率在袖中藏起一颗子弹。一旦你达到6层增益，你可以免费释放一次要害攻击，并返还6个连击点。

这些加成都为我们的技能组合增添了更多伤害，偶尔获得免费的要害攻击和更多伤害增益屟能够很好地提升我们本就很高的持续DPS。

2.6.

#### 循环要点

狂徒和潜行者在至暗之夜中的改动影响深远，影响了我们工具箱和循环设计的许多方面。话虽如此，该专精所基于的玩法循环仍然存在——而且专精有了更清晰的重点。不幸的是，我们一些最好的防御和功能性法术被移除或削弱了，比如[[spell:354897]]和[[spell:256188]]，而[[spell:1833]]增加冷却时间也会让我们用于打断敌人的手段减少。

2.6.1.

##### 命运骨骰

对我们循环最大的改动是[[spell:315508]]的重新设计。它现在稳定得多，当你使用命运硬币时，你将获得一个特定阶段：

- **阶段1**
  
  
  
  
  影袭有20%的几率造成两次攻击并获得机会。
- **阶段2**
  
  
  
  
  影袭和伏击额外生成1个连击点并造成15%的额外伤害。
- **阶段3**
  
  
  
  
  不安之刃的冷却缩减提高30%。
- **阶段4**
  
  
  
  
  暴击几率提高10%。

根据你进入的阶段，你还将获得之前所有阶段的增益。例如，如果你获得阶段3，你不仅会获得不安之刃的冷却缩减提升，还会获得阶段1和阶段2中影袭和伏击的加成。

这有助于将大部分强度转移到你最常获得的前两个阶段，从而在很大程度上使循环流程更加稳定，而较罕见的结果虽然不会提供那么多感觉对循环流畅性至关重要的收益，但仍然提供你想要获得的不错的加成。

获得增益的当前几率 **似乎是** 55%几率获得第1阶段，30%几率获得第2阶段，10%几率获得第3阶段，5%几率获得第4阶段。

2.6.2.

##### 正中眉心

狂徒玩家在至暗之夜中的大量关注点在于[[spell:315341]]，其运作方式与守护德鲁伊的[[spell:192081]]类似，即提供一个增加你造成伤害的增益，且每个增益都有各自的持续时间并可与其自身叠加。你通常会维持该增益的多层叠加，尤其是在触发恰到好处、冷却时间被重置时，而当你在触发方面特别幸运时，可能会有一些有趣的极限优化机会。

2.6.3.

##### 能量生成

我们的能量获取整体被降低了，这反过来使得[[spell:271877]]感觉像是一个必点天赋，在你触发不多或能量开始见底的情况下有所帮助。

由于我们的循环流程大部分由第1和第2阶段增益改善，我们很少无法持续获得对流畅快速循环至关重要的邪恶攻击触发，虽然这些改动可能看起来会让狂徒玩起来慢很多且笨拙，但Alpha的初步体验并未证实这一担忧。

2.6.4.

##### 冷却调整

[[spell:13750]]不再预期接近100%的覆盖率，在当前Alpha版本中更接近约30-35%。至少第2阶段的覆盖率更接近75-80%，新的顶点天赋也有助于缓解那些你没有冲动、只有RtB增益第一阶段、且邪恶攻击和机会触发运气不佳的游戏时刻。

[[spell:1856]]以及由此带来的潜行，不再是我们DPS的主要优势，它通过某些天赋（如[[spell:424044]]或[[spell:423703]]）提供的许多潜行相关好处，反而被整合进了技能本身或无需任何潜行要求即可生效的新天赋中。

[[spell:271877]]现在是狂徒玩法的核心部分，其能量回复是缓解循环中不良随机性打击的关键组成部分，此外还有一个围绕该技能设计的套装。

[[spell:196937]]和[[spell:382245]]也被移除，降低了最佳操作狂徒所需的按键数量，并在不过度简化专精的情况下提高了易用性。

1.

### 狂徒 潜行者基础玩法

狂徒 潜行者是一个高度围绕增益效果和冷却时间维护的专精，例如，你需要决定是在[[spell:315508]]冷却完毕时立即重掷，还是保持当前拥有的增益效果，同时还需管理许多不同的冷却时间，其中一些的优先级高于其他。

围绕 **命运骨骰** 很快就会成为你的本能反应，你会注意不浪费任何资源，也不会让冷却时间闲置过久。你的大多数冷却时间并非固定不变，因为[[spell:79096]]会在你消耗连击点数时不断降低所有冷却时间。善用这种冷却缩减是高效游玩狂徒 潜行者的关键。我们可以进一步将内容分为这三个主要概念。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_helmet_66.jpg>) **冷却缩减**
  
  
  
  
  冷却缩减（CDR）是狂徒潜行者的核心玩法。你的许多进攻技能都有冷却时间，但消耗连击点数可以借助[[spell:79096]]降低这些技能的冷却时间。这造就了一个流畅的循环，你交替使用许多不同的技能，打出极高的持续伤害，因为即使是你最长的冷却技能也会很快再次可用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_pistolshot.jpg>) **斩杀机会触发**
  
  
  
  
  [[spell:279876]]是狂徒潜行者的一个关键机制。每次你施放近战连击技能（生成连击点数的技能）时，都有机会获得一层该增益效果。你可以消耗这些层数来强化[[spell:185763]]的施放，从而大幅提升你生成连击点数的能力。虽然你偶尔会遇到触发不给力的情况，但这是狂徒体验的一部分，你的循环也因此会有自然的起伏。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowworddominate.jpg>) **反应式玩法**
  
  
  
  
  在[[spell:279876]]触发和[[spell:79096]]的冷却缩减之间，你需要时刻密切关注你的技能和资源。很容易在斩杀充能、连击点数上溢出，或者在某个冷却技能已经冷却完毕时不小心使用了另一个终结技，而这正是这个专精学习曲线的一部分。由于全局冷却时间天然较短，你没有太多时间来正确评估每一次技能施放，因此当你更熟练地掌握这个专精时，会感到更加有成就感。

1.

### 如何为狂徒 潜行者配装

虽然我们始终建议你使用模拟工具来获得最佳结果，但我们确实提供了一个专门的狂徒配装页面。我们目前涵盖了第二赛季装备的推荐，以便你在至暗之夜终局内容发布时顺利起步。一旦你获得了一些装备，你还需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月18日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对第2赛季上线以及最近的装备削弱和改动进行更新。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年4月25日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 将戒指附魔仅推荐改为鹰眼之印。
- **2026年4月25日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 更新了欺诈者大秘境天赋构建，加入了灵巧之手。
- **2026年4月25日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 更新了欺诈者大秘境天赋构建，加入了灵巧之手。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已更新至12.0.5补丁。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 更新了饰品推荐。
- **2026 年 3 月 31 日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式信息中关于戒备的说明，以及掘墓者冷却刷新的延迟。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对至暗之夜进行更新。
- **2026年2月26日（本页）：** 已针对至暗之夜进行更新。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已针对至暗之夜 pre-patch进行了更新。
- **2026年2月10日（本页面）：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为11.2.7补丁审查页面，无需更改。
- **2025年11月30日（本页面）：** 页面已针对11.2.7补丁进行更新，列出了所有主要的内容更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对11.2.5补丁更新了信息，添加了谜之财团筹码部分，移除了DISC腰带部分。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为11.2.5补丁审查页面，无需更改。
- **2025年10月5日（本页）：** 页面已针对11.2.5补丁和军团再临重制版进行更新。
- **2025年9月6日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已更新，包含简化的循环改动。
- **2025年9月6日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已更新，内容围绕套装进行撰写。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对11.2版本和地心之战第3赛季更新。添加了所有新的毕业装备列表。移除了关于瑟西斯的指环和令人费解的卡特尔筹码的信息。添加了关于蕾希裹布的信息。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对11.2版本更新。移除了腐蚀部分。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 针对11.2版本审核了本页面，无需更改。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对11.2版本和第3赛季更新本页面，包含每周和高层大秘境的构筑推荐。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2版本更新页面，为有无新套装的天赋推荐添加了标签。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对11.2版本更新，添加了新的天赋构建并更新了英雄天赋信息。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对11.2版本更新。更新了杀戮盛筵信息。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对11.2版本进行审阅，添加了无套装免责声明。
- **2025年8月4日（本页面）：** 已针对11.2版本更新信息。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 为11.1.7版本添加了关于戒律牧腰带的信息。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 添加了关于战斗辅助功能的信息。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 针对11.1.7版本审核了本页面，无需更改。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 添加了关于战斗辅助功能的信息。
- **2025年6月15日（本页）：** 添加了关于11.1.7版本的信息。
- **2025年5月20日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 更新了惊魂幻象附魔部分，推荐回响虚空。
- **2025年5月9日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 切换为欺诈者大秘境天赋构建推荐。
- **2025年5月9日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 切换了大秘境天赋构建的推荐。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已更新至11.1.5补丁，新增了令人费解的财团代币建议。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 新增了惊魂幻境附魔信息，并为11.1.5复核了页面。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 针对11.1.5版本审核了本页面，无需更改。
- **2025年4月21日（本页）：** 新增了11.1.5补丁相关信息。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 新增了额外提示、加里维克斯信息，以及数个首领的史诗难度提示。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月24日（本页面）：** 页面已为地心之战11.1补丁复核并更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月17日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对塞尔赛斯指环的强化进行更新。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 为11.0.7补丁新增了塞尔赛斯指环信息。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已为11.0.7补丁复核。
- **2024年12月15日（本页）：** 页面已为11.0.7补丁复核。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 指南已针对11.0.5版本进行审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 指南已针对11.0.5版本进行审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 略微更新了宝石描述。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 指南已针对11.0.5版本进行审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 添加了各种普通和史诗难度的提示。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对11.0.5版本更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 为《地心之战》11.0.5版本更新了循环和命运骨骰优先级。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 天赋构建已针对《地心之战》11.0.5版本更新。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已为地心之战11.0.5补丁更新。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（本页）：** 新增了11.0.5补丁的职业改动。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对地心之战第1赛季更新，包含毕业装备和美化。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对地心之战第1赛季的开启进行更新。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对第1赛季更新，移除了赛季前构筑。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月24日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 新增了地下堡天赋构筑。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对地心之战进行更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对地心之战进行更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对地心之战进行更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对地心之战进行更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对地心之战进行更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对地心之战进行更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对地心之战进行更新。
- **2024年8月21日（本页）：** 已针对地心之战进行更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/outlaw-rogue-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（本页面）：** 已更新至《地心之战》前夕补丁。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/outlaw-rogue-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/outlaw-rogue-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年4月22日（本页）：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 针对10.2.6补丁进行了审查。
- **2024年3月21日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.2.6版本进行审阅。
- **2024年3月21日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年3月21日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已针对10.2.6版本进行审核和更新。
- **2024年3月21日（本页）：** 页面已针对10.2.6版本进行审核和更新。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已针对10.2.5版本进行审核和更新。
- **2024年1月15日（本页）：** 页面已针对10.2.5版本进行审核和更新。
- **2023年12月14日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 修正了大秘境装备的毕业列表。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年11月6日（本页）：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 添加了10.1.7版本的毕业列表。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 天赋采用了新布局，添加了KIR大秘境天赋构建。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年9月4日（本页）：** 已针对10.1.7补丁进行更新。
- **2023年8月8日（本页）：** 已针对8月8日的职业调整进行更新。
- **2023年7月16日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了命运骨骰优先级。
- **2023年7月16日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已更新为KiR现在是更强的单体天赋构建。
- **2023年7月16日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 更新了HO天赋构建的命运骨骰优先级。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 新增了永恒黎明部分，移除了大灾变漫游部分，针对10.1.5版本更新了永恒之戒部分。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 更新了关于黑曜石指环的段落，在10.1.5版本指环削弱后不再推荐刷取它。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 添加了在GM激活时的BF条件。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对10.1.5补丁更新，在GM激活期间的循环中加入了BF条件。
- **2023年7月10日（本页）：** 为10.1.5补丁更新，更新了职业和指南的最新改动。
- **2023年6月6日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 更新了美化信息。
- **2023年6月6日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 添加了腰带扣环和光耀护甲片作为腿部附魔的替代方案。添加了腐化之怒药剂的讨论。
- **2023年6月6日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 更新了KIR推荐，作为HO天赋构建的可行替代方案。
- **2023年6月6日（本页）：** 已根据最新的理论构筑社区（TC）发现进行更新。
- **2023年5月24日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 添加了时光漫游信息。
- **2023年5月14日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2023年5月7日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 根据最近的热修更新了美化推荐。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 页面已针对10.1补丁全面更新。新增了飞龙石和纹章信息，新增了第2赛季毕业装备及推荐、毕业美化推荐等内容。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对10.1补丁进行审核。更新了奥妮克希亚的印记推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 10.1补丁未更改属性优先级。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 针对10.1补丁词缀更改更新了提示和技巧。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 10.1补丁无需更改循环。新增了循环速查指南。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已针对10.1补丁进行审核。推荐的天赋配置和天赋树保持不变，页面无需更新。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 10.1补丁无需对此页面进行更改，因为除了数值调整外没有法术更改。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已针对10.1版本更新。简化了循环优先级和天赋构建。
- **2023年5月1日（本页）：** 已针对10.1补丁发布进行更新。新增了指南近期更新和待处理更新的章节。
- **2023年4月29日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 10.1补丁无需对此页面进行更改。
- **2023年3月26日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 根据最新热修更新了原始宝石推荐。
- **2023年3月26日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 添加了KIR天赋构建的天赋模拟器链接。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/outlaw-rogue-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为10.0.7补丁更新。
- **2023年3月20日（本页）：** 已为10.0.7补丁更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已针对10.0.5补丁更改进行更新。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 已针对10.0.5补丁更改进行更新。
- **2023年1月18日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 更新了HO天赋构建的循环优先级和命运骨骰优先级。
- **2023年1月18日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 阐明了循环优先级，更新了推荐天赋构建。
- **2023年1月5日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 更新了天赋树。
- **2023年1月4日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 更新了团队副本饰品和毕业列表免责声明。
- **2023年1月4日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 更新了属性优先级和幸运饼干食物增益。
- **2023年1月4日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 为HO添加了关于急速的免责声明。
- **2023年1月4日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 更新了天赋构建推荐。
- **2023年1月4日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 更新了HO天赋构建的路线/建议，并添加了KiR天赋构建替代方案。
- **2023年1月4日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 更新了关于循环优先级、命运骨骰增益和天赋构建的信息。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/outlaw-rogue-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/outlaw-rogue-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/outlaw-rogue-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/outlaw-rogue-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年6月23日（[9.2版本分析](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-2-changes-analysis>)):** 已针对 9.2.5 补丁审核本页面。
- **2022年2月3日（[9.2版本分析](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-2-changes-analysis>)):** 已更新至构建42174。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月2日（[9.1 补丁分析](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-1-changes-analysis>)):** 新增了9.1.5版本更改。
- **2021年6月28日（[9.1 补丁分析](<https://www.icy-veins.com/wow/outlaw-rogue-patch-9-1-changes-analysis>)):** 页面已添加。
- **2020年10月28日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-ny-alotha-raid-guide>)):** 更新了天赋和艾泽里特特质推荐。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年12月11日（[永恒宫殿页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 更新了所有首领的提示。
- **2019年7月15日（[永恒宫殿页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 新增了所有首领的提示。
- **2019年7月8日（[永恒宫殿页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月24日（[奥杜尔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[达萨罗之战页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月24日（[风暴熔渣页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年5月8日（[风暴熔渣页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 新增了更多首领提示。
- **2019年4月15日（[风暴熔渣页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月23日（[达萨罗之战页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 小幅更新。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-battle-of-dazar-alor-raid-guide>)):** 为达萨罗之战添加了狂徒 潜行者建议。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** 本页面已为8.1版本审核，无需更改。
- **2018年9月4日（[奥杜尔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** 新增了各首领专精专属提示。
- **2018年8月13日（[奥杜尔页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-uldir-raid-guide>)):** 页面已添加（目前为占位内容）。

显示更多

显示更少

:::

## 练级

在本页面，你将找到我们的逐级狂徒 潜行者练级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[潜行者 升级指南](<https://www.icy-veins.com/wow/rogue-leveling-guide>).

1.

### 狂徒 潜行者练级指南（适用于至暗之夜）

不幸的是，潜行者经常被认为是魔兽世界中最糟糕的练级职业。不过别担心，它仍然完全能够轻松应对练级之旅，即使这可能会比选择了其他职业的朋友们花的时间稍长一些。一旦你达到满级，你很快就会超过他们，并且会庆幸自己花了时间选择潜行者！

潜行者练级期间最大的优势之一，就是能够简单地潜行绕过许多麻烦。巧妙运用[[spell:2094]]、[[spell:1856]]、[[spell:6770]]和其他控制技能，你往往可以拾取重要任务物品，然后直接消失脱离，无需击杀任何敌人。

每当你的[[spell:5277]]冷却完毕时，值得同时拉很多怪物，然后简单地躲避它们造成的所有伤害。[[spell:185311]]的冷却时间很短，所以记得使用它和新的[[spell:1231418]]法术在拉怪之间进行治疗。一旦你能使用[[spell:13877]]，地下城也是一个不错的练级选择，因为它能让你在练级旅程的所有阶段都贡献出良好的AOE伤害。

随着你的升级，你的一些技能将被专精专属技能所取代，例如，在22级时，[[spell:196819]]将被[[spell:2098]]取代。在其他时候，新技能会加入你的循环优先级列表。其中一些你会在升级时自动学会，另一些则需要你投入天赋点数。如果你按照我们天赋模拟器的逐级路线来点天赋，本指南将立即告诉你如何高效地使用这些新技能。

1.1.

#### 升级装备选择

练级时，始终选择物品等级最高的装备。此规则的唯一例外是如果你有一个戒指或项链，它的物品等级略低，但拥有两个副属性而不是一个。

使用传家宝装备时，我们推荐使用带有暴击和急速的装备，因为它们会在练级过程中略微改善游戏体验。

1.2.

#### 至暗之夜升级实用消耗品

随着 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)的全面发布，玩家们将再次有机会将等级提升至新的上限90级。这意味着许多人希望尽可能快地达到最高等级。为此，有许多 <em>可选的</em> 消耗品可以收集来加快进度。不需要囤积太多，因为你只需要将每个角色练一次级。

为了做好最充分的准备，请设法获取以下至少部分物品和附魔。

- [[item:191348]] — 这是一种来自 [巨龙时代](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  资料片的一种可交易消耗品，可以持续30分钟提高你的移动速度属性，并且死亡后仍然保留。练级通常是关于快速旅行，而不是更快地击败敌人。
- [[item:225592]] —— 一种食物，来自 [地心之战](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)，这道可交易的菜肴同样能提供一小时的大量移动速度加成，但死亡后会消失。
- [[item:132516]]——这是一种比较特殊的消耗品，这个来自军团再临工程学的可交易物品（多亏了 [工程学](<https://www.icy-veins.com/wow/professions-engineering>)）可以让你在很长一段时间内移动速度超过地面坐骑速度，甚至可以在水面上移动，但受到伤害时会失效，且无法在战斗中激活。如果在无法使用坐骑的区域，可以将其视为你最快的移动工具。
- [[item:154168]]/[[item:154169]]——虽然很少需要，但这两个来自争霸艾泽拉斯的可交易消耗品可以搭配使用，为你提供水下呼吸能力和大幅提升的游泳速度，比水上坐骑还要快。
- [[item:109076]]——虽然你受到的坠落伤害比大多数职业少得多，而且只要你有东西可以[[spell:36554]]，就能完全避免坠落伤害，但这种消耗品还能让你在无法骑乘时以极快的速度从高空飞行。你甚至可以考虑将其与[[item:122124]]或[[item:104299]]搭配使用！

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串，为你接下来的10个等级做好准备。一旦你开始在至暗之夜中获得等级，你就可以按照下面天赋树的逐点分配进行加点。

请记住，下面的天赋树是专门为练级设计的，与任何满级天赋树都有很大不同。一旦你达到满级，请务必查看我们的天赋部分，换成合适的终局天赋构建！

:::talents 狂徒 80级 至暗之夜练级
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgBwMzgZbmZmxYmZbxMzMLTbD2mBAAAAAM2mZmZmZGGGzsMAAAAmBAMmFAMwgFahNGgZGYgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgxCYmZwsNzMzYMzstYmZmlptBbzAAAAAAGbzMzMzMDziZmZZAAAAMDAYMLGGYgZhFahNGgZGYwM"
}
```
:::

:::details 来源计算器编码
```
#EE-MphLGPAk+g8yOFVORN+MC0aDG2llVFXX3GB-hNZAVQ4MM69oYw811BVh1q6aaaZ02GH-AAAA-bYWCUYIAARBxhB-
```

:::

**等级 20 起：**2.1.

#### **等级 20 起：**升级用战争模式天赋

**等级 20 起：**在本节中，我们将对最适合练级和进行单人/小队PVE内容的PVP天赋进行排名。以下是通用PVP天赋和狂徒 潜行者专属PVE天赋的排名。

1. [[spell:269513]]是这里唯一真正的伤害天赋，它能稍微提升刺杀的伤害，代价是延长了动画时间。不过看起来真的很酷！
2. [[spell:209752]]使[[spell:315341]]提高10码内所有友方玩家30%的移动速度，持续5秒。练级时移动速度总是很有用，所以强烈推荐。如果你从不与他人组队，[[spell:197000]]也可以使用，但只有在你觉得你已经能足够快地接近下一个目标时才值得。
3. [[spell:354425]]为猩红之瓶增加了一点额外的治疗量。
4.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1–1：**从1级开始，你只有一个主要攻击技能：[[spell:1752]]。

1. 当你拥有4个以上连击点数时，施放[[spell:196819]]来消耗它们。
2. 使用[[spell:1752]]来积累连击点数。
3. **等级 7 起：**当你能从[[spell:1784]]状态下起手，或者以其他方式获得施放能力时，施放[[spell:8676]]。
4. **等级 13 起：**冷却完毕时使用[[spell:13750]]。理想情况下，当它可用时，你应该尝试拉多个敌人，这样你就不会把它的持续时间浪费在跑路上。
5. **等级 13 起：**在与一个以上敌人战斗时，使用[[spell:13877]]。在其激活期间，尽量总是用你的技能攻击生命值最高的目标。
6. **等级 19 起：**冷却完毕时施放[[spell:315508]]。
7. **等级 9 起：**施放[[spell:315496]]来消耗你的连击点数，并通过施放其他终结技来维持增益效果。只有当它掉buff时才手动刷新。
8. **等级 17 起：**在拥有6个以上连击点数时，冷却完毕后使用[[spell:315341]]。
9. **等级 10–21：**施放[[spell:196819]]来消耗多余的连击点数。
10. **等级 22 起：**在拥有5个以上连击点数时施放[[spell:2098]]。
11. **等级 12 起：**当你获得[[spell:279876]]触发时，施放[[spell:185763]]。
12. **等级 10 起：**施放[[spell:1752]]，除非你有4个以上连击点数。

3.1.

#### 防御技能

狂徒潜行者拥有几种可用的工具，使与多个敌人战斗变得更容易，或让你能够避免虚弱效果。

- **等级 6 起：**[[spell:1766]]允许你打断正在施法的敌人。经常使用它，以避免在法术施放完成时你原本会受到的伤害。
- **等级 8 起：**[[spell:185311]]让你在4秒内恢复最大生命值的20%。在需要治疗时或在两波拉怪之间使用它。
- **等级 11 起：**[[spell:6770]]让你控制任何人型生物、野兽、恶魔或龙类，持续最多60秒。用它来防止单个敌人在你从潜行状态对一群敌人发起攻击前加入战斗。当敌人受到伤害时，这个控制效果会打破。尽量避免用任何命中多个目标的技能击中它，否则它会加入战斗。
- **等级 13 起：**[[spell:408]] 可以用来击晕单个敌人，持续最多6秒。用它来打断危险的施法，或者单纯地避免受到敌人的伤害。某些NPC可能免疫击晕。
- **等级 34 起：**[[spell:5277]] 使你在10秒内闪避近战和远程攻击的几率提高100%。在与多个敌人战斗时，只要可用就使用它。只有面对敌人时你才能闪避其攻击。
- **等级 16 起：**[[spell:195457]]是一个非常强大的移动技能。这有时可以让你攀爬到更高的地方，或者用来完全抵消坠落伤害，在练级时为你节省宝贵的时间。
- **等级 23 起：**[[spell:1856]] 使你从视野中消失。这基本上会重置你正在战斗中的所有敌人。如果你濒临死亡，并且觉得使用其他任何防御或进攻技能都无法让你解决掉所有交战中的敌人，请使用
  **消失** 来保命。
- **等级 10 起：**[[spell:2094]] 允许你控制一个敌人最多60秒。可以在潜行状态下或非潜行状态下使用。当目标受到伤害时控制效果会中断，所以确保不要用你的任何AoE技能命中它，或者在 **致盲** 敌人身上带有你的持续伤害效果之一时使用。
- **等级 24 起：**[[spell:31224]] 移除魔法效果并使你免疫魔法效果，持续5秒。这使你有可能移除可能打断你 [[spell:1784]] 的持续伤害效果、让你承受更少的伤害，或者单纯地避免某些控制或伤害效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 针对11.2版本审核了本页面，无需更改。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 指南已针对11.0.5版本进行审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月21日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月5日：** 更新了天赋树。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 快速入门

在本页面，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩狂徒 潜行者，使用最简单的循环、天赋树、属性优先级、装备配置等，同时不牺牲性能。

1.

### 狂徒 潜行者在至暗之夜中的基础

如果你是这个职业或专精的新手，最好从一个简单的天赋构建开始，以便更好地掌握核心机制和相互作用。这个天赋构建只比最优化的玩法略差一点，所以当你在了解狂徒的基础时，完全不必担心会落后于其他潜行者玩家。以下是该专精的一些核心概念。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_helmet_66.jpg>) **冷却缩减**
  
  
  
  
  冷却缩减（CDR）是狂徒潜行者的核心玩法。你的许多进攻技能都有冷却时间，但消耗连击点数可以借助[[spell:79096]]降低这些技能的冷却时间。这造就了一个流畅的循环，你交替使用许多不同的技能，打出极高的持续伤害，因为即使是你最长的冷却技能也会很快再次可用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_rogue_pistolshot.jpg>) **斩杀机会触发**
  
  
  
  
  [[spell:279876]]是狂徒潜行者的一个关键机制。每次你施放近战连击技能（生成连击点数的技能）时，都有机会获得一层该增益效果。你可以消耗这些层数来强化[[spell:185763]]的施放，从而大幅提升你生成连击点数的能力。虽然你偶尔会遇到触发不给力的情况，但这是狂徒体验的一部分，你的循环也因此会有自然的起伏。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_shadow_shadowworddominate.jpg>) **反应式玩法**
  
  
  
  
  在[[spell:279876]]触发和[[spell:79096]]的冷却缩减之间，你需要时刻密切关注你的技能和资源。很容易在斩杀充能、连击点数上溢出，或者在某个冷却技能已经冷却完毕时不小心使用了另一个终结技，而这正是这个专精学习曲线的一部分。由于全局冷却时间天然较短，你没有太多时间来正确评估每一次技能施放，因此当你更熟练地掌握这个专精时，会感到更加有成就感。

总而言之，狂徒是一个围绕管理多个自身增益效果和冷却时间的专精。你将使用产生技能来积攒连击点数，然后消耗它们来释放强大且爆发性的终结技。在我们狂徒指南的本页面中，我们将专注于一个尽量减少所需按键数量和反应需求的配置，同时不会过度损害整体伤害输出。

1.

### 狂徒 潜行者新手指南（适用于至暗之夜）

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者单体天赋

2.1.

#### 狂徒 潜行者新手单体天赋

这个天赋构建是单体目标的一个很好的新手选择，即使在最高水平的游戏中也是首选构建。由于12.1补丁的一些改动迫使 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者转而玩[[spell:51690]]。

不过别担心，因为狂徒相当容易上手，即使你在开始熟悉该专精时可能会犯一些循环错误。这也是意料之中的，而且犯错不会受到严厉惩罚，所以即使你觉得自己经常溢出资源或浪费重要冷却时间，也要坚持下去。很快就会好起来的！

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 命缚者 团本构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JeowUV1tM6KZaiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者多目标天赋

2.2.

#### 狂徒潜行者的入门级AOE、地下堡和大秘境天赋

这是我们推荐的团本顺劈战斗配装， [地下堡](<https://www.icy-veins.com/wow/delves-guide>)以及大秘境场景。它玩起来 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者，也是最高水平游戏中的首选构筑。你一开始可能会有些吃力，因为狂徒是一个节奏非常快、需要快速反应的专精，但一旦你掌握了诀窍，你将打出惊人的持续DPS，并可以直接跳入更高等级的钥石，届时你仍将使用这个完全相同的构筑！

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 命缚者 团本构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### 狂徒潜行者基础循环

2.3.

#### 入门级狂徒潜行者DPS循环

这是一个非常基础的优先级列表，要从该专精中获得最大伤害，一些更精细的细节缺失了。通过点击链接，你将能够找到这个优先级列表的更详细版本，涵盖单体和AOE，以及对狂徒玩法一些核心概念的更深入解释。

:::details 常见问题：哪个种族最适合狂徒潜行者？
各种族之间的DPS差异相当小。部落方面DPS最佳的种族是牛头人、至高岭牛头人和鲜血精灵。联盟方面最佳的是矮人、虚空精灵和人类。

:::

你是否第一次尝试狂徒？这里是一份所有重要循环优先级的简短列表。你应始终让[[spell:315584]]和你选择的非致命毒药保持激活。

- 当它未激活或你仅处于第一阶段时使用[[spell:315508]]。
- 让[[spell:13750]]、[[spell:51690]]和[[spell:271877]]保持冷却完毕即用。使用[[spell:1277933]]来刷新它们的冷却时间。
- 将[[spell:1752]]作为你的主要产生连击点技能，当你有[[spell:279876]]触发时使用[[spell:185763]]。
- 只要有超过1个目标可以攻击，就使用[[spell:13877]]。
- 在拥有6个以上连击点时冷却完毕即施放[[spell:315341]]。
- 将[[spell:2098]]作为主要终结技，在6个及以上连击点时使用（下述英雄天赋为5个及以上： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者).
- 当你处于第二阶段或更高时使用[[spell:381989]]。之后立即使用[[spell:315508]]。

一个重要的循环方面是，当[[spell:470347]]激活时，务必使用[[spell:51690]]，这发生在使用[[spell:13750]]之后。你总是获得两次使用机会，所以确保其中一次与KS配合使用，另一次与BTE配合使用。

2.3.1.

##### 巅峰天赋： ![Gravedigger Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_rogue_betweentheeyes.jpg>) 掘墓者

[[spell:1265861]]是我们在至暗之夜中的顶点天赋，它提供了一些伤害提升，同时生成额外资源以获得更多冷却缩减。虽然不是特别花哨，但它使我们的玩法更加平滑，并且在主题上非常契合。

2.3.2.

##### 第2赛季套装

至暗之夜第2赛季套装[[spell:1296588]]和[[spell:1296589]]对我们的循环没有任何影响。它只是提升我们的伤害输出，所以获得它后玩法没有任何变化。

### 狂徒 潜行者 防御性法术

2.4.

#### 狂徒 潜行者 的防御性法术

[[spell:1966]]是一个激活式法术，可减少你受到的所有范围伤害。它的冷却时间非常短，应该经常使用。伤害输出的损失可以忽略不计，而且这是一个其他每个职业都羡慕的防御技能。

[[spell:31224]]是你的免疫技能。当你按下它时，它会移除大多数魔法、诅咒、疾病或中毒减益效果，这在某些情况下并不是一件好事。它还会使你对所有魔法效果和伤害免疫。大多数团队副本首领战往往会施加相关的减益效果，但至少你根本不会受到伤害。

[[spell:5277]]将你的闪避提升到100%以上，使你免疫近战攻击。在团队副本中很少有用，但它可以在大秘境或开放世界内容中救你一命。

[[spell:31230]]能救你一命，让你以低生命值存活下来，并获得非常强的伤害减免效果。它有6分钟的冷却时间，并让你本已强大的防御能力更加强大。

[[spell:1856]]在团队副本中用作伤害输出技能，但在世界内容和大秘境中可以救你的命。它会让所有敌人失去对你的仇恨，如果你是唯一存活的玩家，敌方小怪会在你不死亡的情况下重置。它偶尔也可以用来规避指向性法术施放，只要你在敌人完成施放前消失。

### 狂徒 潜行者 属性优先级

2.5.

#### 狂徒 潜行者 的属性优先级

目前，你希望按以下顺序优先考虑属性。有关本页所呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>).

装备等级

暴击至40%

急速至25%

全能

精通

暴击是我们最好的属性，直到约40%。急速仅用于在[[spell:13750]]期间达到0.8秒的公共冷却时间，你需要达到25-30%之间的急速才能做到这一点。你可能希望在许多装备上优先考虑急速和暴击，并尽可能多地获取全能。

### 暴风雪 单键循环

2.6.

#### 狂徒 潜行者 的单键助手

遗憾的是，由于种种原因，协助战斗系统对狂徒来说几乎毫无用处。其中最大的问题是全局冷却时间的增加。由于该专精非常依赖缩短其GCD，我们的GCD在肾上腺素激涌期间为0.8秒（在我们拥有约20%急速的情况下），按键延迟的增加本身就会造成显著的DPS损失。仅此一项就会使其性能下降约25-30%。

除此之外，它还无法正确使用某些高影响度的冷却技能，这使得与简化循环相比，DPS损失更大。因此，目前不建议为狂徒使用战斗协助。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年9月6日：** 页面已更新，内容围绕套装进行撰写。
- **2025年8月4日：** 已针对11.2版本进行审阅，添加了无套装免责声明。
- **2025年6月15日：** 添加了关于战斗辅助功能的信息。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核和更新。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月16日：** 更新了HO天赋构建的命运骨骰优先级。
- **2023年7月10日：** 已针对10.1.5补丁更新，在GM激活期间的循环中加入了BF条件。
- **2023年5月1日：** 已针对10.1版本更新。简化了循环优先级和天赋构建。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023 年 1 月 18 日：** 阐明了循环优先级，更新了推荐天赋构建。
- **2023年1月4日：** 更新了关于循环优先级、命运骨骰增益和天赋构建的信息。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页面中，您将找到魔兽世界12.1.5补丁中您的狂徒 潜行者的最佳天赋。我们还提供了适用于不同类型内容（如团队副本或大秘境）的默认天赋构建。如果您开启了战争模式进行游戏，我们也为您提供了PvP天赋。

1.

### 狂徒 潜行者 的最佳 至暗之夜 天赋

狂徒 潜行者 在选择其英雄天赋和天赋构建时，必须在更高的DPS和易用性之间取得平衡。它也是一个没有重大冷却技能的专精，无法让你在伤害统计中遥遥领先，而是提供高持续性DPS，起伏很小。

两个英雄天赋树都支持这一利基市场，并进一步加深了其优势。该专精已经简化到两个英雄树几乎完全使用相同的天赋和职业天赋的程度，循环也几乎完全相同，只有在命缚者施放[[spell:2098]]时的能量点数阈值上有细微差别。这意味着现在的差异完全取决于数值调整，而欺诈者目前占据优势。

- **单体目标 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 是这里更好的选择，尤其是在那些偶尔能从你的[[spell:13877]]顺劈中获得良好收益的战斗中。对于纯单体目标战斗， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 仅略落后于 欺诈者，但一旦战斗中出现额外小怪，欺诈者 就会获得更大的优势。话虽如此， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 落后的幅度足够小，如果你不介意损失百分之几的DPS（约5%），可以为了主题性而选择它。
- **AoE -** 对于AoE和大秘境， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 由于[[spell:441367]]的额外AoE伤害加成而具有更大的优势。这使它在大规模AoE怪群或持续性顺劈场景中稍微领先，这适用于本团队副本赛季的相当多首领，以及所有大秘境或探底内容。

掌握了这些信息后， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 是几乎所有内容的推荐构建。如前所述， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 如果你最终不喜欢欺诈者的主题理念或游戏流程，命缚者 是一个可行的选择，但在循环方面，两个专精目前的玩法几乎完全相同，因此在执行难度上不再有重大差异。

**快速开始导入代码：**

:::talents 狂徒 单体目标 - 欺诈者
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 狂徒 AoE - 欺诈者
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 狂徒 宝库 - 欺诈者
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

欺诈者

团队副本和单目标

推荐

大秘境和地下堡

推荐

命缚者

团队副本和单目标

大秘境和地下堡

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 单体天赋

这是我们首选的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 是单体目标和团队副本构建，也是高端开荒的唯一推荐选择。它的伤害比命缚者高约5%，且玩法与命缚者版本的构建几乎完全相同。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 AoE天赋

这是为狂徒提供的更高表现的AoE/地下城构建，使用欺诈者。它能造成出色的持续AoE伤害，虽然为此牺牲了一些单体目标伤害，但其上限显著高于等效的命缚者构建。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者单体天赋

这是我们推荐的 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者在至暗之夜中的单体天赋构建，适用于因任何原因不想使用表现更强的欺诈者构建的情况。它拥有很高的持续单体伤害，但牺牲了部分AoE能力。如果你正在对抗单个高难度精英，或者想切换到最大化的首领伤害，这是作为命缚者你能选择的最佳构建。

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者AoE天赋

这是命缚者在狂徒专精下表现稍弱的AoE/地下城构建。它拥有出色的持续AoE伤害，尽管为此牺牲了一些单体伤害，且上限远低于对应的欺诈者构建。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JeowUV1tM6KZaiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JeowUV1tM6KZaiUARC-AAAA-YaWMQOcQoEMJgA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-Sy0sAIYgc4gQJI-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

我们建议你选择以下增益，但由于你可以随时在它们之间自由切换，如果你觉得推荐的选项收益不够，可以自行尝试其他选项：

- 节点1：[[spell:1279599]]
- 节点 2：[[spell:1279603]]
- 节点3：[[spell:1287555]]
- 节点4：[[spell:1279613]]
- 节点5：[[spell:1279614]]

1.

### 巅峰天赋： ![Gravedigger Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_112_rogue_betweentheeyes.jpg>) 掘墓者

至暗之夜的新主要内容是 **巅峰天赋**，而狂徒的
**掘墓者** 专注于额外免费的[[spell:315341]]施放，以及BtE对你所有伤害的更多伤害加成。最多可在此投入4点。目前，这些按1 ➜ 2 ➜ 1点的方式分配。

1. [[spell:1265861]]：使你的每次[[spell:315341]]施放有几率额外叠加一层其增益效果。
2. [[spell:1265862]]：2点天赋税节点，本质上只是在你施放[[spell:2098]]时增加更多伤害。
3. [[spell:1265863]]：使你逐渐积累以获得一次免费的[[spell:315341]]施放，该施放不触发冷却时间也不消耗任何资源。

这些巅峰天赋通过提供一种稳定的方式偶尔获得一次免费BtE，同时也提供一些额外伤害加成，帮助平滑循环的低谷。虽然不是最有创意或最具影响力的巅峰天赋，但这在某种程度上确实有助于弥补该专精的弱点。

1.

### 英雄天赋

狂徒可以在两个截然不同的英雄天赋之间做出选择：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者的触发效果一致性更高。仅凭这一点，它就成为了一个非常可靠的选择，尤其对于一个已经拥有极高持续DPS的专精而言；而且由于它更容易上手，许多狂徒玩家在刚接触时会将命缚者作为首选。

不过它的伤害低于欺诈者，因此一旦你开始尝试更高难度的内容、更高层数的大秘境或极限开荒，就不推荐使用它。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者

从历史上看， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者需要在数值上比命缚者高出一点才值得推荐，因为命缚者提供了额外的循环流畅度，而欺诈者需要按更多的按键，并且需要追踪更多的循环优先级。

欺诈者还有另一个优势，那就是它凭借[[spell:441367]]在AoE中表现极佳。其终极天赋还能提供额外伤害，并自动施放[[spell:2098]]，仿佛它已经消耗了5个额外的连击点。

这增加了大量的额外冷却缩减，有助于稍微平滑循环，同时为循环增添了一层复杂性和技巧表达，其回报是高得多的伤害输出表现。

1.

### PvP天赋（战争模式）

在任何主要主城中，都会有进入"战争模式"的选项。启用战争模式可获得以下好处：

- 户外世界中启用的PvP天赋。
- 满级时世界任务奖励提高10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

考虑到开启战争模式在升级和 PvE 内容中的好处，建议开启此功能以在满级时最大化你的升级速度和奖励。不过，你会使自己成为开放世界 PvP 的目标，在升级或做世界任务时存在被"偷袭"的可能性。

在本节中，我们将对最适合练级和进行单人/小队PVE内容的PVP天赋进行排名。以下是通用PVP天赋和狂徒 潜行者专属PVE天赋的排名。

1. [[spell:269513]]是这里唯一真正的伤害天赋，它能稍微提升刺杀的伤害，代价是延长了动画时间。不过看起来真的很酷！
2. [[spell:209752]]使[[spell:315341]]提高10码内所有友方玩家30%的移动速度，持续5秒。练级时移动速度总是很有用，所以强烈推荐。如果你从不与他人组队，[[spell:197000]]也可以使用，但只有在你觉得你已经能足够快地接近下一个目标时才值得。
3. [[spell:354425]]为猩红之瓶增加了一点额外的治疗量。
4.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月25日：** 更新了欺诈者大秘境天赋构建，加入了灵巧之手。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 页面已针对11.2版本更新，添加了新的天赋构建并更新了英雄天赋信息。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年5月9日：** 切换了大秘境天赋构建的推荐。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 天赋构建已针对《地心之战》11.0.5版本更新。
- **2024年9月9日：** 已针对第1赛季更新，移除了赛季前构筑。
- **2024年8月24日：** 新增了地下堡天赋构筑。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 天赋采用了新布局，添加了KIR大秘境天赋构建。
- **2023年7月16日：** 已更新为KiR现在是更强的单体天赋构建。
- **2023年7月10日：** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年6月6日：** 更新了KIR推荐，作为HO天赋构建的可行替代方案。
- **2023年5月1日：** 已针对10.1补丁进行审核。推荐的天赋配置和天赋树保持不变，页面无需更新。
- **2023年3月26日：** 添加了KIR天赋构建的天赋模拟器链接。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了HO天赋构建的路线/建议，并添加了KiR天赋构建替代方案。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何在单体和多目标环境下优化你的狂徒潜行者的输出循环。我们还提供了关于冷却时间、触发效果等方面的进阶内容，以便你最大化你的DPS。所有内容均已针对《魔兽世界》12.1.5版本更新。

1.

### 狂徒潜行者玩法与循环指南

欢迎来到我们的狂徒潜行者循环页面。在这里，你将了解更多关于单体和多目标环境下的循环优先级，这些内容将应用于团队副本和大秘境场景。

以下各部分分别讲解不同环境下的输出循环。点击方框可切换到所需场景。

1.1.

#### 命运骨骰重做

在多年[[spell:315508]]运作方式不变之后，该技能在至暗之夜中进行了重做。这是一个非常重要的改动，因此我们认为有必要在循环优先级之前列出一份重做总结。该技能现在更加稳定，当你使用RtB时，你将获得一个特定阶段：

- **阶段1**
  
  
  
  
  影袭有20%的几率造成两次攻击并获得机会。
- **阶段2**
  
  
  
  
  影袭和伏击额外生成1个连击点并造成15%的额外伤害。
- **阶段3**
  
  
  
  
  不安之刃的冷却缩减提高30%。
- **阶段4**
  
  
  
  
  暴击几率提高10%。

根据你进入的阶段，你还将获得之前所有阶段的增益。例如，如果你获得阶段3，你不仅会获得不安之刃的冷却缩减提升，还会获得阶段1和阶段2中影袭和伏击的加成。

这有助于将大部分强度转移到你最常获得的前两个阶段，从而在很大程度上使循环流程更加稳定，而较罕见的结果虽然不会提供那么多感觉对循环流畅性至关重要的收益，但仍然提供你想要获得的不错的加成。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者

团队副本构建

大秘境天赋构建

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者

团队副本构建

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

大秘境天赋构建

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

### 单目标和AoE起手

[[spell:1784]]

[[spell:315584]]

[[spell:13750]]

[[spell:315508]]

[[spell:315496]]

[[spell:13877]]

[[spell:1752]]

[[spell:271877]]

[[spell:33697]]

[[item:241308]]

[[item:270175]]

[[spell:1752]]

[[spell:315341]]

[[spell:1752]]

[[spell:185763]]

[[spell:271877]]

[[spell:1752]]

[[spell:315341]]

[[spell:1752]]

[[spell:185763]]

[[spell:51690]]

[[spell:1277933]]

[[spell:315341]]

**适用条件：欺诈者（启用）。** 1.2.

#### **适用条件：欺诈者（启用）。** 欺诈者单体起手

**适用条件：命缚者（启用）。** 1.3.

#### **适用条件：命缚者（启用）。** 命缚者 单目标起手式

你的起手相当直接，虽然由于潜在的[[spell:278676]]触发重置你的[[spell:315341]]冷却时间，存在一定的随机性。注意[[spell:1277933]]的说明！

1. 始终尝试从[[spell:1784]]中起手，这样你可以在开怪时更接近首领，并让[[spell:315584]]处于激活状态。
2. 在开怪前立即施放[[spell:13750]]、[[spell:315508]]和[[spell:315496]]。切割不会消耗[[spell:470347]]。（如果RtB和切割已经激活，在起手中不要使用它们）
3. 如果有任何顺劈机会，使用[[spell:13877]]。
4. 以[[spell:271877]]（如果点了天赋）或[[spell:1752]]起手。使用你的伤害输出药水、种族技能以及你可能拥有的任何使用型饰品。
5. 使用[[spell:1752]]产生连击点
6. 在拥有6个以上连击点时使用[[spell:315341]]
7. 使用 [[spell:1752]] 或在拥有 3 层以上 [[spell:381846]] 时使用 [[spell:185763]] 来积累连击点
8. 使用 [[spell:1752]] 或在拥有 3 层以上 FtH 层数时使用 [[spell:185763]] 来积累连击点
9. 在拥有 6 个以上连击点时施放 [[spell:51690]]，即使 BTE 已重置了其冷却时间。
10. 如果 [[spell:315341]] 正在冷却中，则使用 [[spell:1277933]]；否则，积累连击点并再次使用 BTE，直到它进入冷却。

### 单体和AoE循环

**适用条件：欺诈者（启用）。** 1.4.

#### **适用条件：欺诈者（启用）。** 欺诈者 单体目标循环

**适用条件：命缚者（启用）。** 1.5.

#### **适用条件：命缚者（启用）。** 命缚者 单目标循环

这是关于如何使用你的技能的一般优先级列表。这不是一个应该逐步遵循的列表；它只是为你提供一个关于在瞬息万变的游戏过程中优先考虑哪些事情的好主意，因为你经常会面临多个按哪个技能的选择。优先级列表只是突出了哪些技能比其他技能更重要。

1. 你的循环优先级在单体和AoE中几乎完全相同。唯一的区别在于 [[spell:13877]] 的使用。只要在顺劈范围内有第二个目标，你就应该尽量在冷却完毕时使用 BF，但要尝试在低连击点时使用，以获得 [[spell:381878]] 的全部收益。在AoE中，你应该在潜行状态下以剑刃乱舞起手
2. 在冷却完毕时使用 [[spell:315508]]，除非你已经处于第 2 阶段或更高阶段。
3. 在处于第 3 阶段时使用 [[spell:381989]]。如果你的下一个 [[spell:315508]] 不太可能与 [[spell:256170]] 一起使用，你也可以在第 2 阶段使用 KIR。
4. 在低连击点时，冷却完毕就使用 [[spell:13750]]。
5. 如果点了天赋，就像使用常规攒点技能一样，在冷却完毕时使用 [[spell:271877]]。
6. 在拥有6个以上连击点时冷却完毕即施放[[spell:315341]]。
7. 使用 [[spell:1277933]] 来重置你的 AR、BtE 和刀锋冲刺的冷却时间。
8. 在拥有 6 个以上连击点时，冷却完毕就使用 [[spell:51690]]。务必在 [[spell:470347]] 激活时施放它。
9. **适用条件：命缚者（启用）。** 如果没有其他终结技可用，则以 5 个以上连击点施放 [[spell:2098]] 作为你的主要终结技。
10. **适用条件：欺诈者（启用）。** 如果没有其他终结技可用，则以 6 个以上连击点施放 [[spell:2098]] 作为你的主要终结技。
11. 如果你拥有 6 层 [[spell:279876]]，则施放 [[spell:185763]]。如果你拥有 3 层，则只在 1-3 个连击点时使用它。
12. 施放 [[spell:1752]] 来产生连击点。

---

**关于 [[spell:381989]] 的注意事项 -** 为第 3 阶段的 RtB 保留 KIR 可能会带来理论上的收益，但在实践中，如果运气不佳，你可能会在很长一段时间内都无法使用它。因此，你可以在第 2 阶段或更高阶段直接使用它，以获得更好的稳定性和更少的令人沮丧的战斗。

1.

### 至暗之夜 第2赛季套装

至暗之夜 第 2 赛季团本套装 [[spell:1296588]] 和 [[spell:1296589]] 对我们的循环没有任何影响。它只是提升了我们的伤害输出，并让我们的循环更加流畅。

1.

### 职业与专精机制详解

为了更好地解释 狂徒 潜行者 技能包的具体用法和收益，我们编写了关于循环各个部分的更详细说明。从需要注意的重要循环机制，到冷却技能及其使用方法，请阅读以下内容，以在游玩 狂徒 时发挥你的全部潜力。

### 命运骨骰

3.1.

#### 命运骨骰

在多年 [[spell:315508]] 以相同方式运作之后，该技能得到了重做。这是一个非常重要的改变，因此我们将其列在循环优先级之前。该技能现在更加稳定，使用 RtB 时，你将获得一个特定的阶段：

- **阶段1**
  
  
  
  
  影袭有20%的几率造成两次攻击并获得机会。
- **阶段2**
  
  
  
  
  影袭和伏击额外生成1个连击点并造成15%的额外伤害。
- **阶段3**
  
  
  
  
  不安之刃的冷却缩减提高30%。
- **阶段4**
  
  
  
  
  暴击几率提高10%。

根据你进入的阶段，你还将获得之前所有阶段的增益效果。即：如果你获得第 3 阶段，你不仅会获得无休锋刃的冷却缩减加成，还会获得第 1 和第 2 阶段对影袭和伏击的加成。

这有助于将大部分强度转移到你最常获得的前两个阶段，从而在很大程度上使循环流程更加稳定，而较罕见的结果虽然不会提供那么多感觉对循环流畅性至关重要的收益，但仍然提供你想要获得的不错的加成。

获得增益的当前几率 **似乎是** 55%几率获得第1阶段，30%几率获得第2阶段，10%几率获得第3阶段，5%几率获得第4阶段。

### 顶点天赋

3.2.

#### 顶点天赋：掘墓人

至暗之夜的新主要内容是 **巅峰天赋**，而狂徒的
**掘墓者** 专注于获得额外的免费 [[spell:315341]] 施放，以及来自 BtE 的所有伤害的更多伤害加成。这里最多可以投入 4 点。目前，这些天赋的投入方式为 1 ➜ 2 ➜ 1 点：

1. **[[spell:1265861]]** <em>（1 点）</em>
   
   
   
   
   使你的每次 BtE 施放都有机会施加一层额外的增益效果。
2. **[[spell:1265862]]** <em>（2 点）</em>
   
   
   
   
   2 点天赋税节点，本质上只是在你施放 [[spell:2098]] 时增加更多伤害。
3. **[[spell:1265863]]** <em>（1 点）</em>
   
   
   
   
   使你缓慢积累一次免费的 BtE 施放机会，该施放不消耗冷却时间或任何资源。

掘墓者的攻击有轻微的弹道飞行时间，这可能会延迟最后一个掘墓者节点的刷新。特别是在大型 Boss 战中，你可能会使用 [[spell:315341]]，看到技能进入冷却，然后当它实际击中你的目标时，通过消耗 [[spell:1265863]] 来刷新其冷却时间。我们建议使用冷却管理器来追踪 [[spell:1265931]] 增益，以便你知道何时拥有 6 层。

这些巅峰天赋通过提供一种稳定的方式偶尔获得一次免费BtE，同时也提供一些额外伤害加成，帮助平滑循环的低谷。虽然不是最有创意或最具影响力的巅峰天赋，但这在某种程度上确实有助于弥补该专精的弱点。

### 能量囤积

3.3.

#### 能量囤积

“囤积”你的能量和连击点数可能非常有益，这涉及在能量恢复时进行自动攻击。这提供的优势是可变的，意味着囤积并不总是带来伤害增益。囤积能量和连击点数有益的情况包括：

- 在重要的小怪生成之前，以便你能施加尽可能多的即时压力
- 即将到来的特定战斗增益或伤害阶段

囤积能量本身并不是神奇的 DPS 增益。它允许你稍微调整技能的时机，以便在伤害增加期间塞入更多攻击，前提是你能正确识别此类期间何时会发生。

### 致命一击

3.4.

#### 致命一击

在游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 在 欺诈者 英雄天赋树中，你将围绕你的 [[spell:441423]] 触发来游玩。恩赐终结会让你的下一个 [[spell:2098]] 变得更强大，就像你使用了 5 个额外连击点一样施放它。这些额外的连击点会计入我们来自无休锋刃的冷却缩减，所以你应该尽快使用它。

### 快手射击

3.5.

#### 快手射击

[[spell:381846]] 是一项天赋，它极大地提高了你使用 [[spell:279876]] 增强的 [[spell:185763]] 的能力。它还允许你积累多层增益，并消耗 2 层触发效果而不是 1 层。这意味着你施放的每一次机会射击都会产生 4 个连击点，你需要注意不要在任何时候让层数溢出。理想情况下，你也应该避免因此导致连击点溢出，但这 **更重要的是** 不要让层数溢出，而不是不要让连击点溢出。

1.

### 狂徒 潜行者 的重要冷却技能

### [[spell:13750]]

4.1.

#### 冲动

[[spell:13750]] 大幅提高你的能量恢复、最大能量和攻击速度。在其激活期间能量溢出并不少见，你可能会浪费大量资源。这是正常的。

还有一个工具提示中未提及的隐藏效果：在 AR 激活期间，你的全局冷却时间会根据你的急速值减少，最多减少到 0.8 秒（从 1 秒的基础值降低）。

达到足够的急速以从此效果中获益几乎是 **始终推荐的**，你需要大约 20-30% 的急速才能做到这一点（考虑到触发效果和其他急速来源）。

### [[spell:315341]]

4.2.

#### 正中眉心

[[spell:315341]] 是你造成伤害的主要终结技，每次使用都会增加你所有技能造成的伤害。然而，每次施放都有其持续时间，因此增加的伤害量会随着你连击点生成和冷却缩减的触发效果而起伏。确保在冷却完毕时使用此技能！

### [[spell:381989]]

4.3.

#### 时运继延

[[spell:381989]] 将你当前的 [[spell:315508]] 的持续时间延长 30 秒，在用于处于第 3 甚至第 4 阶段的 RTB 时特别有效。你通常应该在冷却完毕时使用 KIR，但如果你有一个 [[spell:256170]] 触发就绪，或者你即将通过施放另一个 [[spell:13750]] 获得它，你可能想保留时运继延。

由于灌铅骰子为你提供 +1 阶段，你很有可能最终获得一个第 3 阶段，甚至可能是第 4 阶段的 RtB，然后你可以立即用时运继延延长它。即使你最终没有获得一个好的 RtB 掷骰，也应立即使用 KIR，因为它有非常高的冷却时间，你不想错过它的其中一次使用。

**理论上：** 这是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者 仅在第 3 阶段使用 KIR 的一个微小收益。然而，尽管这在数十万次战斗中是理论上的收益，但如果你在一场战斗中一次都没有达到第 3 阶段，并且全程都在保留 KIR，你可能会遇到低得多的低谷。因此，不建议围绕这条规则游玩，除非你正在争取第一名的记录。

### [[spell:2094]]

4.4.

#### 致盲

[[spell:2094]]不是我们DPS工具包的一部分，但在大秘境中仍有一些可能不那么明显的有趣用途。虽然[[spell:6770]]允许玩家安全地通过被控制的生物而不进入战斗，但被致盲的敌人会困惑地四处走动，并且仍然会与 **第一个** 靠近它的玩家进入战斗。一旦致盲debuff结束，它就会攻击该玩家。然而，它不会与任何其他靠近它的玩家进入战斗。

你仍然可以很好地利用致盲来通过敌人，利用只有一个玩家会与它进入战斗的事实。做到这一点最好也最简单的方法是，在致盲目标后，确保你靠近到足以进入战斗，然后你和你的整个队伍就可以通过这个敌人。一旦你离它足够远，你就可以安全地[[spell:1856]]，脱离战斗，并跳过这个敌人。

这在有一整群敌人挡在你面前而你想跳过，但有一两个敌人太近以至于无法在不引到它们的情况下通过时特别有用。作为一个潜行者，你可以[[spell:6770]]一个，然后用上面的技巧处理另一个，让你可以跳过那些如果你使用[[spell:114018]]就会发现你，或者帷幕在冷却中的敌人。

1.

### 狂徒 潜行者 的学术信息

5.1.

#### 连击点数与能量

作为一名 潜行者，你的大多数技能都需要能量才能使用。你的能量条容量为 100 点能量（选择 [[spell:14983]] 作为天赋时为 200 点，在 [[spell:13750]] 期间为 250 点），并以每秒 10 点能量的基础速率恢复。你的能量恢复速度会因以下因素而增加：

- 近战急速（急速 + 增强急速的增益效果）
- [[spell:61329]] 被动技能，它使你的能量恢复速度提高 25%
- 你的 [[spell:13750]] 冷却技能，它会暂时将你的能量恢复速度提高 60%
- 如果点了天赋，还有 [[spell:14983]]

你恢复能量的速度越快，你能施放的终结技就越多，这（通过 [[spell:193359]] 和 [[spell:79096]]）将导致更高的 [[spell:13750]] 覆盖率。

让能量达到最大值是你想要避免的。你应该始终尝试通过（字面意义上的）狂按技能键来消耗你的能量。与 敏锐 和 奇袭 潜行者不同，狂徒 潜行者通常不会从能量池中获益。有很多情况你会产生比你能消耗更多的能量（急速饰品触发、[[spell:2825]] / [[spell:32182]] / [[spell:80353]] 等），在这种时候你应该比平时更用力地狂按你的技能键。

连击点的产生由多种因素增加，例如：

- 在点了 [[spell:196938]] 天赋时 [[spell:279876]] 的触发
- 如果点了天赋，还有 [[spell:381620]] 或 [[spell:381846]]。
- [[spell:1752]] 的双重攻击
- [[spell:315508]] 增益效果
- 你的 [[spell:14161]] 被动技能，它使你的终结技在每消耗一个连击点时有 20% 的几率获得一个连击点
- 能量恢复，使你能够施放更多的攒点技能

你永远不应该浪费连击点。永远不要在连击点达到最大值时施放产生连击点的技能。注意那些你保证会产生 2 个连击点的情况，例如，在 [[spell:315508]] 第 2 阶段期间，或者在点了 [[spell:196938]] 天赋时，使用带有机会触发的 [[spell:185763]]。

5.2.

#### 冲动

[[spell:13750]] 增加你的能量恢复、最大能量和攻击速度。它应该在冷却完毕时使用。不要犹豫将其与 [[spell:2825]]、[[spell:32182]] 或 [[spell:80353]] 叠加，因为你仍然会从增加的攻击速度中获益，尽管你可能会达到能量上限（这不是问题）。[[spell:13750]] 有 3 分钟的冷却时间，但这可以被 [[spell:79096]] 减少。

它还会根据你的急速值减少你的全局冷却时间，上限为 0.8 秒的 GCD。

5.3.

#### 狂徒 冷却缩减

[[spell:79096]] 使以下技能的冷却时间每被终结技消耗一个连击点就减少 1 秒（如果你处于掷骰第 3 阶段，则增加 30%）：

- [[spell:13750]]
- [[spell:315341]]
- [[spell:13877]]
- [[spell:271877]]
- [[spell:195457]]
- [[spell:381989]]
- [[spell:51690]]
- [[spell:315508]]
- [[spell:2983]]

5.4.

#### 剑刃乱舞

值得重申的是，[[spell:13877]] 顺劈的来源是你，而不是目标。因此，你可以让一个怪物在你面前，另一个在你身后，你的 [[spell:13877]] 仍然会击中你身后的怪物，即使怪物之间的距离超过 8 码，因为你是顺劈的来源。

5.5.

#### 防御实用性

所有潜行者都自带令人眼花缭乱的防御冷却技能，这使他们成为承担必要机制和应对大量 incoming 伤害的最佳人选。

- [[spell:1966]] 仅消耗 35 点能量，即可在 6 秒内将受到的 AoE 伤害降低 40%。当点了 [[spell:79008]] 天赋时，它还会将所有其他伤害降低 20%，并为 [[spell:5277]] 提供 10% 的伤害减免。这是游戏中最强大的技能之一，在团队承受大量伤害的战斗中是一笔巨大的财富。
- [[spell:31224]] 提供一秒的魔法免疫，随后是 4 秒的所有法术都将未命中的时间。这个法术主要用于清除那些可能迫使你离开近战范围的负面效果。暗影斗篷也是吸收不穿透免疫效果的技能的绝佳工具。
- [[spell:31230]] 是一项天赋，允许你每 6 分钟逃脱一次致命伤害。该伤害不能超过你最大生命值的两倍。装死非常适合用于吸收穿透免疫和减伤效果的机制，因为它能保证你的生存。它也非常适合那些可能让你措手不及的爆发性伤害遭遇战，因为你每 6 分钟就能得到一张免死金牌。
- [[spell:185311]] 在非常短的冷却时间内提供可观的治疗量。在 Boss 战中经常使用它。
- 只要面对敌人，[[spell:5277]] 就会提供 100% 的几率闪避敌人的攻击。这有时也可以用来躲避物理法术。

5.6.

#### 毒药

你的 **致命毒药** 始终应该是 [[spell:315584]]。

你的非致命毒药有两个选择，[[spell:3408]] 和 [[spell:5761]] 或 [[spell:381637]]。对于团队副本，你通常会使用 **萎缩药膏** 除非你的团队希望你减缓特定目标的移动速度。

对于大秘境，你需要使用最适合你的坦克或团队需求的毒药。致残药膏让你的坦克更容易风筝敌人，而迟钝药膏则是减缓敌人的攻击速度。萎缩药膏减少的是整个团队受到的伤害，而不仅仅是坦克，尽管数值要低得多，但在推进更高等级的钥石时可能非常有用，因为那时的 Boss 可能会开始秒杀玩家。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 更新了起手式信息中关于戒备的说明，以及掘墓者冷却刷新的延迟。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年9月6日：** 页面已更新，包含简化的循环改动。
- **2025年8月4日：** 已针对11.2版本更新页面，为有无新套装的天赋推荐添加了标签。
- **2025年6月15日：** 添加了关于战斗辅助功能的信息。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 为《地心之战》11.0.5版本更新了循环和命运骨骰优先级。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月16日：** 更新了命运骨骰优先级。
- **2023年7月10日：** 添加了在GM激活时的BF条件。
- **2023年5月1日：** 10.1补丁无需更改循环。新增了循环速查指南。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023 年 1 月 18 日：** 更新了HO天赋构建的循环优先级和命运骨骰优先级。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页，你将找到《魔兽世界》12.1.5 中你的 狂徒 潜行者 的最佳装备、饰品和毕业装备推荐。从制造物品到关于如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 狂徒 潜行者 毕业装备指南

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含 狂徒 潜行者 来自所有来源的最高 DPS 配置。请注意，还有许多其他配置的表现在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
你将想要尝试优先获取 **肩膀、胸部、腿部和手套** 套装部件。然而，获取头盔以完成其中一个加成仍然比任何其他装备选择都要好。长期来看，你将想要使用来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 的特定头盔。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:251223]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸部：[[item:281236]]来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 手套：[[item:251124]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部：我们想要从代币中获取这些。

严格来说，只有手套和头盔真正需要被催化，其他部位的属性基础值都已经相当不错了。

:::

:::details 常见问题：从宏伟宝库中获取什么？
一般来说，你的目标应该是尽快获取一把好武器、你的毕业饰品，当然还有你的新四件套加成。然而，有一种替代策略可能最终会有些取巧，但如果你的进度最终需要几周或几个月，它可能会有所回报。

你可以选择不从宏伟宝库中选择物品，而是简单地获取一个 [混沌虚空核心](<https://www.wowhead.com/currency=3418>)。这让你可以在任何地下城或Boss身上使用额外拾取，并获得该物品的1/6神话品质版本。在 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 如果你连续 5 周遵循此策略，英雄难度的 Boss 就能保证你获得毕业饰品、武器、腿部，以及一件普通的披风和一条腰带。

虽然由于这些物品需要纹章才能完全升级，这可能会稍微减慢你的物品等级进度，但它能让你在真正击杀史诗难度 Boss 之前就获得一些你绝对最好的物品。不过请注意，史诗难度掉落的物品将是 9/6 史诗难度，而额外拾取的物品上限为 6/6，并且这 5 件物品中有 2 件由于精通属性过高，对 狂徒 来说相当糟糕。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240914]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244573@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:268240@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr></tbody></table>

### 秘境+

本列表包含使用第 2 赛季大秘境可刷取装备的最高 DPS 配置。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
你将想要尝试优先获取 **肩膀、胸部、腿部和手套** 套装部件。然而，获取头盔以完成其中一个加成仍然比任何其他装备选择都要好。长期来看，你将想要使用来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 的特定头盔。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头部：[[item:273791]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 肩部：[[item:251223]]，来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 胸部：来自的 [[item:251226]] [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- 手套：[[item:251124]]，来自 [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- 腿部：来自的 [[item:159313]] [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)

严格来说，只有手套和头盔真正需要被催化，其他部位的属性基础值都已经相当不错了。

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>), [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>), [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)：掉落多个高价值物品。
- **武器**：尝试运行 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>) 获得一件不错的副手武器。
- **饰品**: [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>) 和 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>) 掉落你最好的地下城饰品，尽管少数团本选项往往要强得多。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:273791@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>项链</th><td>[[item:273781@JAACAAAOyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>腰部</th><td>[[item:244573@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:193763@JAAKAAQkCYHKvbRLfYjM]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251148@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250259@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></div></td></tr><tr><th>护腕</th><td>[[item:251135@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>饰品</th><td>[[item:159617@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:193767@JAAKAAQkCYHKvbRLfgjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">红玉新生法池</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:275070@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr></tbody></table>

### 团队副本

本列表包含仅使用来自剧毒深渊团本装备的最高 DPS 配置。

此列表绝不能替代 **模拟你自己**。根据你之前的宏伟宝库选择以及你可获得的装备，你的毕业装备在某些位置可能与此列表有所不同。

:::details 常见问题我需要哪些套装部件？
你将想要尝试优先获取 **肩膀、胸部、腿部和手套** 套装部件。然而，获取头盔以完成其中一个加成仍然比任何其他装备选择都要好。长期来看，你将想要使用来自 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>) 的特定头盔。

随着 [催化剂](<https://www.icy-veins.com/wow/catalyst-guide>) 在第2赛季中的改动，你在催化套装部件时也会保留副属性和任何其他潜在的被动效果，如伤害触发。这意味着我们要尝试催化那些确保我们在装备上获得最佳副属性的物品，但如果不可能的话，也没关系。拥有属性稍次的套装并在赛季后期修复，比错过一两周的套装加成要好。一些催化时属性最佳的物品有：

- 头盔：[[item:271875]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩膀：我们想要从代币中获取这些。
- 胸部：[[item:281236]]来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- 手套：我们不情愿地从代币中获取这些。
- 腿部：[[item:268225]]，来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) 以获得物品等级的提升（仅在开悟时）。

严格来说，只有手套和头盔真正需要被催化，其他部位的属性基础值都已经相当不错了。在这个新系统下，强烈建议获取几件大秘境装备来催化以获得良好的副属性，尤其是在手套上（或者制造它们）。

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:268209]]：我们的毕业主手，如果你能在神话轨迹上获得它。掉落自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:270173]]：我们最好的饰品。也掉落自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>).
- [[item:271875]]：我们唯一真正适合催化头盔的选择。
- 荣誉提名：来自巢穴Boss的[[item:268266]] [尼姆瑞莎·唤波者](<https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa>)。如果你作为一个团队这样做，你真的很需要这个戒指提供的急速。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271875@JAAEAAwF2ghN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>手套</th><td>[[item:271511@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAAEAAAj1ghN]]&#10;&#10;<div>[[item:240914]][[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:244573@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></div></td></tr><tr><th>护肩</th><td>[[item:271508@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271509@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘卷祭坛</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>披风</th><td>[[item:268248@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>脚部</th><td>[[item:244569@JAAIAAwt1ENMMYjViA]]&#10;&#10;<div>[[item:240167]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">皮革制作</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271513@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a> 由 <a href="https://www.icy-veins.com/wow/professions-jewelcrafting" rel="noopener noreferrer">珠宝加工</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>护腕</th><td>[[item:268240@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/venomous-abyss-raid-guide" rel="noopener noreferrer">剧毒深渊</a></div></td></tr><tr><th>饰品</th><td>[[item:270175@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268204@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span><span>[[item:244029]]</span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 狂徒 潜行者 饰品推荐

狂徒有大量饰品可供选择，我们总是希望搭配两个强力的被动饰品，例如[[item:270173]]和[[item:270175]]。狂徒没有有意义的爆发冷却技能，所以使用型饰品对我们来说并不强力，但乌拉特克之心实在太强了。来自Kith'ix的新[[item:281215]]也是一个不错的选择，尤其是如果你还没有344装等版本的两个史诗级剧毒深渊饰品的话。

还有相当多其他有价值的饰品，所以请务必查看我们的排名图表，看看它们是否值得装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看狂徒潜行者饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270175]] - 最佳装备候选</li>&#10;<li>[[item:270173]] - 最佳装备候选</li>&#10;<li>&#10;&#10;&#10;[[item:281215]] - <span><em>点击查看详情</em></span>&#10;<span>作为被动饰品的不错替代选择，尤其是如果你没有上面两个的344版本。你可能需要自己跑模拟来看看哪个更好，尤其是在AOE场景中。&#10;       </span>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270164]]</li>&#10;<li>&#10;&#10;&#10;[[item:270165]] - <span><em>点击查看详情</em></span>&#10;<span>作为被动饰品的不错替代选择，但即使在赛季上线前的削弱之后，Gebbos也严格优于它。&#10;       </span>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250259]] - <span><em>点击查看详情</em></span>&#10;<span>我们最好的大秘境选择，但在AOE中表现不佳，那里白字属性通常更好。&#10;       </span>&#10;</li>&#10;<li>[[item:159617]]</li>&#10;<li>[[item:273796]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:250225]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273797]]</li>&#10;<li>[[item:250228]]</li>&#10;<li>[[item:158374]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270166]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250245]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270168]]</li>&#10;<li>制造的饰品</li>&#10;<li>地下堡饰品</li>&#10;<li>任何其他未列出的饰品</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

12.1补丁延续了最初在12.0.7补丁中引入的额外奖励骰系统。然而，获得它的唯一方式是在至少解锁3个宝库槽位的情况下，不选择宝库选项。值得注意的是，对英雄难度团队副本首领使用额外奖励骰将使你获得1/6史诗难度路线的物品，因此你可以相当早地获得一些后期团本装备，只要你愿意投入额外的纹章来升级它。

**[混沌虚空核心](<https://www.wowhead.com/currency=3418>)s** 可以在完成地下城或击杀团队副本Boss后使用，它会从地下城或Boss的掉落列表中随机奖励你一件物品。一旦通过虚空核拾取获得了一件物品，当你再次对同一Boss或地下城使用额外拾取时，该物品就不会再次出现。

8周后，你还将免费获得一个额外的虚空核心，来源为
**奥琳·微光** 在银月城，紧邻转化器。

3.1.

#### 狂徒潜行者推荐的虚无核心使用建议

你想追求哪件装备，在很大程度上取决于你已经通过（例如） [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>)，或者你是否期望以神话难度击败某些Boss以在9/6神话物品等级获得它们。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心（额外拾取）优先级**
1. 史诗[[item:268209]]
2. 史诗[[item:270173]]
3. 剩余的毕业装备列表物品

:::

3.2.

#### 晋升毒液石

使用你的[[item:280562]]遵循与使用徽记类似的优先级列表。请注意，你无法进一步升级来自史诗乌拉特克和盘绕祭坛的已是344的物品，因为神话追踪器物品的新最高物品等级为340，制造物品为338。

1. 你的主手武器是最高优先级
2. 你的副手武器
3. 你的主动使用饰品
4. 你的被动饰品
5. 你的项链

你还需要优先考虑神话追踪器物品而非英雄追踪器物品，除非你预计无法获得该物品的神话追踪器版本。也就是说，如果你不预计很快击杀史诗乌拉特克或为史诗版本进行额外掉落，升级英雄追踪器的[[item:270175]]或[[item:270168]]是可以的。

1.

### 狂徒潜行者最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

由于在至暗之夜初期阶段你的制造能力会受到时间限制，我们强烈建议获取一个 **主手武器** 尽早获取，除非你能在其他地方可靠地获得。一旦你有了不错的武器，接下来就制作你的另一件附魔装备，然后制作你还没有高品质版本的装备。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **狂徒制造装备优先级**
- [[item:237839]]搭配[[item:245873]]，但 **只能** 如果你需要一把主手武器
- [[item:244569]]搭配[[item:240167]]
- [[item:244573]]搭配[[item:240167]]

:::

至于制造武器上应该选择的副属性，这在很大程度上取决于你的其他装备。你的两个主要属性目标是约40%暴击和约25-30%急速，所以如果你还没有达到其中任何一个，暴击/急速的制造物品可能会最适合你。

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 狂徒潜行者最佳镶边推荐

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

由于衬饰的竞争非常激烈，你必须为你整体的DPS输出挑选出最强的两个。大多数衬饰提供的DPS收益非常相似，即使效果完全不同。对此最佳的两个选择是：

- 对于团队副本和大秘境：在腰带或靴子等制造物品上获得两个[[item:240167]]是你的最佳选择。如果你还没有高装等的主手武器，你可以用[[item:245873]]制作一把。

建议你进行模拟，找出最适合你的方案。如果你还玩其他两个潜行者专精，你可能想要选择对三者都适用的装饰。

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得该消耗品。不选择选项将奖励你代币，其中六个可以兑换[[item:275707]]物品，该物品允许你为上述装备添加插槽，如果你是在第2赛季获得它们的话。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **狂徒潜行者纹章升级优先级**
**武器（主手）**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**肩部/手套/腰带/靴子**

:::

当然，这些并不是唯一值得升级的装备。它们只是在赛季初期、你的升级货币有限时能提供最高DPS收益的装备。请注意，例外情况是可能存在的，例如附带额外触发效果的特殊装备。

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月18日：** 已针对第2赛季上线以及最近的装备削弱和改动进行更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 更新了饰品推荐。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已针对11.2.5补丁更新了信息，添加了谜之财团筹码部分，移除了DISC腰带部分。
- **2025年8月4日：** 已针对11.2版本和地心之战第3赛季更新。添加了所有新的毕业装备列表。移除了关于瑟西斯的指环和令人费解的卡特尔筹码的信息。添加了关于蕾希裹布的信息。
- **2025年6月15日：** 为11.1.7版本添加了关于戒律牧腰带的信息。
- **2025年4月21日：** 已更新至11.1.5补丁，新增了令人费解的财团代币建议。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月17日：** 已针对塞尔赛斯指环的强化进行更新。
- **2024年12月15日：** 为11.0.7补丁新增了塞尔赛斯指环信息。
- **2024年10月21日：** 指南已针对11.0.5版本进行审阅。
- **2024年9月9日：** 已针对地心之战第1赛季更新，包含毕业装备和美化。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年12月14日：** 修正了大秘境装备的毕业列表。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 添加了10.1.7版本的毕业列表。
- **2023年7月10日：** 新增了永恒黎明部分，移除了大灾变漫游部分，针对10.1.5版本更新了永恒之戒部分。
- **2023年6月6日：** 更新了美化信息。
- **2023年5月24日：** 添加了时光漫游信息。
- **2023年5月14日：** 已更新饰品推荐。
- **2023年5月7日：** 根据最近的热修更新了美化推荐。
- **2023年5月1日：** 页面已针对10.1补丁全面更新。新增了飞龙石和纹章信息，新增了第2赛季毕业装备及推荐、毕业美化推荐等内容。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了团队副本饰品和毕业列表免责声明。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页中，你将了解你的狂徒潜行者的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已针对《魔兽世界》12.1.5补丁更新。

1.

### 狂徒 潜行者 属性优先级

对于团队副本和大秘境，狂徒潜行者的副属性优先级基本相同。单体和AOE之间唯一有意义的区别是你在单体配装中不使用[[spell:271877]]，这使得急速更有价值，所以尽量以 **30%** 为目标，在团队副本配装中，而约25%对于大秘境地下城就足够了。总体属性优先级如下：

装备等级

暴击至40%

急速至25%

全能

精通

急速和暴击的价值在一定程度上取决于你已经拥有的数量。暴击在你达到约40%暴击后开始贬值，而急速在你达到冲动期间获得0.8秒公共冷却的临界点后，在25-30%左右开始下降。虽然你通常应避免在每件装备上都堆叠属性，但你希望确保自己足够接近这些"临界点"，只要你不因此降低装等。

你可能希望在许多装备上优先选择急速和暴击，并尽可能少地选择全能。

1.

### 深入属性解析

**敏捷** 是你的主要属性。你应该在所有升级中寻找它。它为你提供攻击强度，决定了你技能的伤害。

**全能** 是纯粹的造成伤害提升和承受伤害降低。

**暴击** 提高你攻击的暴击几率并造成双倍伤害。它与[[spell:235484]]有一些互动，后者在暴击时造成额外伤害。

**急速** 为你提供更高的攻击速度和能量回复。除了基础能量回复外，急速还通过[[spell:61329]]为你提供更多能量。此外，更高的急速会让你有更多次数的[[spell:86392]]触发。在[[spell:13750]]期间，它将你的公共冷却降低至最多0.8秒，从1.0秒降低。

:::details 常见问题：狂徒潜行者有急速上限吗？
你希望以约20-25%的急速为目标。这是由于急速在

[[spell:13750]]

期间影响公共冷却，最高可将公共冷却降低至0.8秒。一旦你达到这个临界点，多余的急速价值就非常低了。

:::

**精通** 提高你的[[spell:76806]]触发所造成的伤害。这个攻击有几率触发[[spell:61329]]，它会提高你的能量回复。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 针对11.2版本审核了本页面，无需更改。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 指南已针对11.0.5版本进行审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年5月1日：** 10.1补丁未更改属性优先级。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 为HO添加了关于急速的免责声明。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的狂徒潜行者可以获取的最佳宝石、附魔、药剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/outlaw-rogue-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

你应该在一个插槽中使用[[item:240967]]。对于你的副属性宝石，选择暴击或急速宝石，例如[[item:240890]]或[[item:240906]]。确保至少获取每种类型的宝石各一个，例如[[item:240914]]和[[item:240898]]，然后用我们前面列出的更高价值宝石填充剩余插槽。

请记住，宝石的选择在很大程度上取决于你装备的装备。四种副属性中的任何一种都可能根据你当前穿戴的装备而成为宝石最有价值的属性，因此宝石的选择可能差异很大。我们强烈建议你通过自行模拟来找出最适合你角色的宝石组合， [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>).

1.

### 最佳附魔和武器强化

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>主手</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>副手</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243733]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243981]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>胸部</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244009]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

你选择用闪避、吸血还是加速来附魔装备取决于你自己。吸血会让你在造成伤害的同时获得一些额外的被动治疗，闪避降低范围法术造成的伤害，类似于[[spell:1966]]，而加速只是提高你的移动速度。对于团队副本开荒，移动速度经常被低估，如果它能让你更快接近目标，可以带来少量的DPS提升。

始终建议你进行模拟，以找出哪些附魔能为你个人提供最佳收益。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

你应该将[[item:241326]]作为你的首选药剂以获得暴击加成，除非这会让你超过约40%暴击的上限，那时你应该改用[[item:241325]]。你也可以从炼金术士提供的[[item:241319]]中获取你选择的药剂。

3.2.

#### 药水

[[item:241288]]是你的最佳选择，应与主要冷却技能和[[spell:2825]]/[[spell:32182]]配合使用。你也可以从炼金术士提供的[[item:241285]]中获取该药水的临时版本。

在第2赛季中，你现在可以使用[[item:271883]]，它明显优于[[item:241305]]。使用它有5分钟冷却时间，但如果首领战持续足够长，可以消耗多个。此外，术士的[[item:5512]]与其他治疗消耗品不共享冷却时间。如果你带着一个，记得也使用它！

3.3.

#### 食物增益

如果可能的话，尽量吃下[[item:255845]]或其他主属性大餐。如果你的团队没有提供这些，就坚持使用[[item:242275]]作为你的个人食物。

3.4.

#### 强化符文

此外，如果负担得起，你应该使用 [[item:259085]] 来提高你的主属性。强化符文价格昂贵且死亡后消失，所以请明智而节制地使用它们！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月25日：** 将戒指附魔仅推荐改为鹰眼之印。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 已针对11.2版本更新。移除了腐蚀部分。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年5月20日：** 更新了惊魂幻象附魔部分，推荐回响虚空。
- **2025年4月21日：** 新增了惊魂幻境附魔信息，并为11.1.5复核了页面。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 略微更新了宝石描述。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审阅。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 更新了关于黑曜石指环的段落，在10.1.5版本指环削弱后不再推荐刷取它。
- **2023年6月6日：** 添加了腰带扣环和光耀护甲片作为腿部附魔的替代方案。添加了腐化之怒药剂的讨论。
- **2023年5月1日：** 已针对10.1补丁进行审核。更新了奥妮克希亚的印记推荐。
- **2023年3月26日：** 根据最新热修更新了原始宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了属性优先级和幸运饼干食物增益。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5补丁中使用你的狂徒潜行者挑战大秘境地下城的技巧和建议。

1.

### 狂徒潜行者在至暗之夜第2赛季中的大秘境

狂徒在大秘境中的游戏风格与你常规的单体循环几乎完全相同。由于当[[spell:13877]]激活时，你几乎所有的伤害都会溅射到额外的目标身上，因此保持 **剑刃乱舞** 的永久覆盖，并且不在敌人即将死亡时浪费它，是作为狂徒表现出色的关键。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

狂徒在大秘境中既能提供高额的持续AOE伤害，也能提供强大的持续单体伤害，这些伤害始终可用，且不依赖于主要冷却技能与团队其他成员同步。虽然你在爆发DPS方面无法超越任何职业，但当他们的冷却技能用尽时，你将扛起DPS大旗。利用这种灵活性和持续伤害，始终集火血量最高的目标！

1.

### 最佳大秘境天赋配置

12.1补丁对[[spell:1224865]]进行了重大改动，[[spell:51690]]得到了大幅加强，使其成为两个英雄天赋树的共同选择。这最终导致两个英雄天赋树使用完全相同的职业和专精天赋树， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者在各项指标上都优于命缚者。因此，命缚者只在你不介意DPS损失或更喜欢其主题风格时才值得使用。

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/trickster.webp>) 欺诈者大秘境配装

2.1.

#### 欺诈者大秘境天赋

这是狂徒表现更高的AOE/地下城配装，使用欺诈者。它拥有出色的持续AOE伤害，并具有非常高的DPS上限，无论你遇到什么情况，你总有强大的伤害准备应对每一波怪。虽然在其他职业使用所有冷却技能时你可能无法跟上，但一旦他们耗尽资源，你很快就会超越他们——而这种情况不会发生在狂徒身上！

请务必使用'导出天赋'按钮在游戏中导入我们的配装！

:::talents 狂徒欺诈者AOE
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBAjZxwADMLsQLsxAMzgBG"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-BIOgQRzQhBTggF-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fatebound.webp>) 命缚者 大秘境构筑

2.2.

#### 命缚者大秘境天赋

这是狂徒表现较低的AOE/地下城配装，使用命缚者。它拥有不错的持续AOE伤害，虽然为此牺牲了一些单体伤害，且上限低于对应的欺诈者配装。如果你更喜欢使用命缚者，那么这就是你要选择的配装。

请务必使用'导出天赋'按钮在游戏中导入我们的配装！

:::talents 命缚者AOE
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CQQAAAAAAAAAAAAAAAAAAAAAAAgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYmBMwGMjRjZDw2ALMAYmZgB"
}
```
:::

:::details 来源计算器编码
```
#EE-LMOeEiCY4QaiS7D8I5pSooMPCMMuuuhhrNCB-hNgHKcGJegw49JaowUVZdlscaiiUARC-AAAA-Sy0sAIYgc4gQJI-
```

:::

1.

### 功能技能与能力

### 打断、昏迷和阻止

3.1.

#### 打断

[[spell:1766]]就是你的，嗯，"踢"。你将打断你的目标敌人，或者在使用焦点宏时，打断你设置为焦点的目标。

#### 焦点打断宏

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists,nodead] [] 脚踢
```

如果你有焦点目标，这个宏会打断你的焦点目标，如果没有焦点目标，则打断你的目标。我们建议将这个宏和普通的踢击施法都放在你的动作条上，因为你可能有多个目标需要打断，而宏总是优先处理焦点目标。

为了在混乱的场景中快速设置焦点目标，我们还推荐使用
**鼠标悬停设为焦点宏** 或者在游戏中按键设置中设置“焦点目标”快捷键。

#### 焦点宏

```wow-macro
/focus [@mouseover]
```

确保你的界面清晰地显示你的焦点目标的施法，以便你始终能在冷却完毕时打断它，或与团队其他成员协调打断。

3.2.

#### 眩晕与"打断"

[[spell:6770]]和[[spell:2094]]可用于对一组小怪中的多个怪物进行硬控。你也可以在坦克拉怪之前使用它，因为[[spell:379005]]在闷棍破除时会对目标施加一个降低伤害的减益效果。

点出[[spell:200733]]和[[spell:379005]]后，[[spell:2094]]变成一个低冷却时间的AOE干扰技能，还能在短时间内大幅降低坦克受到的伤害，但它只对真正可以被迷惑的目标有效。它对大型精英或首领无效。

[[spell:1856]]可用于[[spell:1833]]敌人，感谢[[spell:108208]]使其眩晕。只在万不得已时使用，因为你希望将[[spell:1856]]作为DPS冷却技能使用。

[[spell:1776]]（如果点出天赋）可用于干扰敌人施放原本无法打断的法术。这需要你站在敌人面前，但在许多情况下可以用来阻止敌人使用他们最致命的一些技能。这些技能中许多在使用后会进入冷却，因此用凿击、[[spell:408]]或[[spell:2094]]干扰它们，将使这些小怪暂时无法再次施放这些技能。

### 致盲跳怪

3.3.

#### 致盲跳怪

[[spell:2094]]不是我们DPS工具包的一部分，但在大秘境中仍有一些可能不那么明显的有趣用途。虽然[[spell:6770]]允许玩家安全地通过被控制的生物而不进入战斗，但被致盲的敌人会困惑地四处走动，并且仍然会与 **第一个** 靠近它的玩家进入战斗。一旦致盲debuff结束，它就会攻击该玩家。然而，它不会与任何其他靠近它的玩家进入战斗。

你仍然可以很好地利用致盲来通过敌人，利用只有一个玩家会与它进入战斗的事实。做到这一点最好也最简单的方法是，在致盲目标后，确保你靠近到足以进入战斗，然后你和你的整个队伍就可以通过这个敌人。一旦你离它足够远，你就可以安全地[[spell:1856]]，脱离战斗，并跳过这个敌人。

这在有一整群敌人挡在你面前而你想跳过，但有一两个敌人太近以至于无法在不引到它们的情况下通过时特别有用。作为一个潜行者，你可以[[spell:6770]]一个，然后用上面的技巧处理另一个，让你可以跳过那些如果你使用[[spell:114018]]就会发现你，或者帷幕在冷却中的敌人。

### 其他功能

3.4.

#### 其他功能

[[spell:114018]]在你周围投射AOE[[spell:1784]]。但需要注意的是，在当前资料片中，有更多敌人可以侦测到潜行或隐形，你需要对此保持警惕。

[[spell:1725]]有助于设置帷幕跳怪，并使巡逻的小怪群停留10秒。确保迫使敌人背对你，以便你潜行通过他们。

[[spell:1966]]、[[spell:31224]]、[[spell:5277]]、[[spell:185311]]和[[spell:31230]]构成了一组非常强大的防御冷却技能，是潜行者在大秘境中强大的最大原因之一。

[[spell:57934]]通常并不特别出色。然而，任何有助于你的坦克对所有敌人保持仇恨的支持都是值得鼓励的。遗憾的是，它与[[spell:379005]]是选择节点。

[[spell:5938]]可用于驱散 **激怒** 效果。请记住，这意味着你将无法使用毒刃进行DPS输出。

[[spell:5761]]和[[spell:381637]]在大秘境中都很有用，但由于更强调小怪，在强韧周[[spell:5761]]可能会胜出，而在残暴周萎减则获得更多价值。与你的坦克和治疗沟通哪种更可取。

1.

### 应对词缀

至暗之夜 第2赛季只有四个重要的 词缀 提供任何反制手段，称为萨拉塔斯的交易。这些每周轮换，一次只有一个生效。许多大秘境词缀，如强韧或残暴，只是给钥石添加一个被动效果，只有这四个例外是本赛季以萨拉塔斯为主题的：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将生成三波需要打断或扰乱的宝珠。[[spell:2094]]由于[[spell:200733]]在这里作为AOE打断效果极佳。只有在绝对必要时才使用[[spell:408]]或[[spell:1833]]。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个虚空大使小怪会刷新，需要设置焦点目标并打断。如果你知道这会发生，请确保对这个目标使用你的冷却技能，并以此目标进行顺劈。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：球体将在玩家周围生成并绕着他们转。你有15秒时间吸收所有这些来增益你的队伍。使用[[spell:2983]]将帮助你更快地吸收这些。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有小队成员都会受到一个治疗吸收效果的影响。你可以用[[spell:31224]]或石像形态等种族技能移除它。如果这些对你不可用，使用[[spell:185311]]来帮助更快摆脱减益效果。如果治疗者资源不足，生命药水或治疗石也能很好地发挥作用。

每一种词缀在被处理后都会提供一组不同的增益效果，虽然它们非常强大，但你不需要以特定的方式围绕它们进行操作。最重要的是不要让任何词缀强化敌方小怪或首领。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月25日：** 更新了欺诈者大秘境天赋构建，加入了灵巧之手。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 已针对11.2版本和第3赛季更新本页面，包含每周和高层大秘境的构筑推荐。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年5月9日：** 切换为欺诈者大秘境天赋构建推荐。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 已针对11.0.5版本更新。
- **2024年9月9日：** 已针对地心之战第1赛季的开启进行更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对巨龙时代第4赛季进行审核和更新。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 页面已针对10.2.5版本进行审核和更新。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年5月1日：** 针对10.1补丁词缀更改更新了提示和技巧。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月4日：** 更新了天赋构建推荐。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你将找到一些有用的宏和插件，让你在《魔兽世界》12.1.5补丁中使用你的狂徒潜行者时更加轻松。

1.

### 最佳宏

你可以使用修饰符，以防某些技能彼此“互斥”，而无需更改快捷键或一直将技能拖到快捷键栏上。这些的语法如下：

- [known:SPELLNAME] 或 [known:SPELLID]

和

- [noknown:SPELLNAME] 或 [noknown:SPELLID]

1.1.

#### 狂徒专属宏

狂徒是一个非常简单的专精，几乎没有能帮助你提升DPS的宏。唯一相关的宏是将[[spell:195457]]设为在鼠标位置施放，这样你就不需要用左键点击确认操作。

1.2.

#### 狂徒潜行者专属宏

#### 鼠标位置抓钩

```wow-macro
#showtooltip
/cast [@cursor] 抓钩
```

1.

### 最佳插件

2.1.

#### 盗贼通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

2.4.4.

##### TankMD

[TankMD](<https://www.curseforge.com/wow/addons/tankmd>) 是一个新的插件，之前是一个WeakAura。它允许你自动将队伍的坦克作为你的[[spell:57934]]法术的目标，而无需鼠标悬停、焦点目标、切换目标或任何类似操作。

2.5.

#### 狂徒潜行者专属插件

目前，我们认为不需要额外的插件来充分发挥狂徒潜行者的潜力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已针对至暗之夜进行更新。
- **2026年2月10日：** 页面已针对至暗之夜 pre-patch进行了更新。
- **2025年11月30日：** 已为11.2.7补丁审查页面，无需更改。
- **2025 年 10 月 5 日：** 已为11.2.5补丁审查页面，无需更改。
- **2025年8月4日：** 针对11.2版本审核了本页面，无需更改。
- **2025年6月15日：** 针对11.1.7版本审核了本页面，无需更改。
- **2025年4月21日：** 针对11.1.5版本审核了本页面，无需更改。
- **2025 年 2 月 24 日：** 页面已为地心之战11.1补丁复核并更新。
- **2024年12月15日：** 页面已为11.0.7补丁复核。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已更新至《地心之战》前夕补丁。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月21日：** 页面已针对10.2.6版本进行审核，无需更改。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 页面已针对10.2版本的潜行者重做进行更新。
- **2023年9月4日：** 页面已针对10.1.7版本进行审核，无需更改。
- **2023年7月10日：** 页面已针对10.1.5版本进行审阅，无需更改。
- **2023年4月29日：** 10.1补丁无需对此页面进行更改。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
