## 专精概览

Welcome to our Havoc Demon Hunter guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Havoc Demon Hunter in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Havoc Mythic+ Resources

[NEW! Top Havoc Talent Builds](<https://raider.io/specs/havoc-demon-hunter/talents>)

[Top Havoc Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/demon-hunter/havoc>)

[Havoc Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=demon-hunter--havoc>)

[Popular Havoc Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=demon-hunter--havoc>)

1.

### Havoc Demon Hunter Overview

Havoc is the Melee DPS Demon Hunter specialization, using a mixture of relentless
Physical attacks and Fel magic to deal damage and move around the battlefield
effortlessly.

Its gameplay heavily focuses on a classic <em>build-and-spend</em> resource
loop using Fury, which is mixed in with a variety of short, high intensity burst
cooldowns. Gameplay is very fast-paced, rewards good ability sequencing, and has
one of the best mobility toolkits. As a Demon Hunter, it also brings the
[[spell:255260]] debuff to assist your group.

2.

### Havoc Demon Hunter Performance Breakdown

Like any spec, Havoc has some strengths and weaknesses. Below we've
evaluated it based on some key categories.

**High Burst and Desirable Damage Profiles**

Havoc boasts high-value damage profiles, having the option to switch between
different styles depending on what's needed. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver brings
funnel, often one of the most desirable types of damage, while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred
brings raw burst and AoE. Although Season 2 has limited some of the complete flexibility
to build AoE while maintaining full single-target, it still compromises less than
many specializations do when hybridizing its loadouts.

**Flexible and Durable**

The Venomous Abyss has a number of atypical encounter styles, with a large
variety of different damage profiles needed. Havoc has enough tools available that
it can adjust its damage to suit any given encounter, while also having the
mobility and defense necessary to navigate them. Improvements to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
in particular over the course of the season mean that both hero trees can work
throughout the raid, each with their own speciality. On top of that, it brings both
[[spell:196718]] as a raid defensive cooldown and [[spell:255260]], a key
group debuff.

**High Damage and Defense**

Season 2 has shifted the distribution of Havoc's damage, but it's still maintained
potent burst AoE with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred. Similarly, Season 2's improvements to
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver paired with ongoing buffs have pushed it into the spotlight,
allowing it to excel as a powerful priority damage specialist at higher key levels
through [[spell:442806]]. The ability to switch between either style
depending on composition or dungeon requirements and meaningfully contribute makes
Havoc a solid all-rounder pick.

**Broad Toolkit and Good Control**

Havoc's utility toolkit is solid, providing a variety of abilities that have
their uses regardless of the encounter - in particular the Demon Hunter raid buff,
[[spell:255260]]. Between its crowd control provided by [[spell:179057]],
[[spell:207684]] and [[spell:217832]], group defensive tool in
[[spell:196718]], and its stellar mobility, Havoc can usually provide <em>something</em>.
While none of the tools are particularly unique, having broad coverage for most
group needs is its own advantage.

**Strong Defensives and Sustain Tools**

Midnight improved Havoc's already solid defensive toolkit, and that continues
into Season 2, making it one of the more durable melee options. Between two
charges of [[spell:198589]] providing a 35% damage reduction with a 1-minute
recharge, passive defense when below 35% with [[spell:205411]], and
Leech granted by [[spell:204909]], there aren't many mechanics that Havoc needs
to be afraid of.

**Exceptional Mobility**

Freedom of movement is one of Havoc's key selling features, so naturally it's
one of the most mobile melee specializations available. [[spell:344865]] grants
instant repositioning on a low cooldown, while [[spell:198793]] gives you
another displacement tool as backup. Add in high passive movement via the
[[spell:320654]] Mastery conversion and the ability to reset momentum
with [[spell:131347]] (which now also provides extra on-demand movement with
[[spell:1266493]]), and you'll rarely struggle to stay on top of movement
requirements in combat.

3.

### Havoc Demon Hunter in Midnight

### **Season 2**   Changes

3.1.

#### Midnight Patch 12.1.5 Content Guides

While Patch 12.1.5 brings no significant changes to Havoc itself, it did receive
extensive tuning throughout Season 2 if you missed it. The patch also brings new
endgame PvE content for you to dive into. Raid groups can take on [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
in a new single encounter instance to claim powerful loot, while [Delves](<https://www.icy-veins.com/wow/delves-guide>)
introduce the first Mega-Delve Labyrinth for you to explore! Make sure to check
out information on both new additions below.

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

3.2.

#### Patch 12.1.5 Changes

The main changes will be the new items from the Kith'ix Raid encounter. Most notably 
a Trinket, Ring, and Chest. Additionally, you will be able to upgrade items with 
[[item:280562]] starting October 20th. Weapons, Necks, and Trinkets can all 
be upgraded.

3.3.

#### Class Changes

Although nothing changed for Havoc with the release of Patch 12.1.5, in the weeks
leading up to its release there was a significant hotfix that drastically improved
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver. The notes below are from the 22nd of September, but
were significant enough that we've kept them highlighted for anyone who missed it:

[Class Tuning Incoming - 22 September](<https://eu.forums.blizzard.com/en/wow/t/class-tuning-incoming-22-september/629804>)

**Havoc Demon Hunter**

<em>Developers’ notes: Aldrachi Reaver has fallen well behind the alternative
	hero talent options for both specs it is available to. We are improving some
	of its core effects for both specs, and for Havoc specifically the soul
	fragment generation from Broken Spirit is increasing to give a small boost to
	Fury generation and hasten the cycle of Reaver’s Glaive and its bonuses.</em>

- [[spell:442290]] increases the damage of enhanced strikes by 15% (up from 10%) and 30% (up from 20%).
- [[spell:442294]] damage increased by 25%.
- [[spell:442624]] increases your damage dealt to the target by 7% (up from 6%).
- [[spell:1272143]] chance to shatter a Soul Fragment increased to 20% (up from 15%).

These changes had already been in effect for two weeks before the release of
the patch, and rocketed ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver up to the best pick on many raid
encounters. While it's a more involved playstyle to make use of on some encounters
with less on-demand burst, the raw throughput and funnel suit it well to many
fights. It's also shown up as a strong competitor to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred for
Mythic+ - especially at higher key levels once funnel and priority target damage
become a premium.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_specdps.jpg>)Click for Previous Season 2 Changes
3.4.

#### Patch 12.1 Havoc Changes

The arrival of Season 2 brought with it a large number of changes for Havoc, shaking
up the Talent Tree while also altering the resource economy.

[Curse of Ula'tek Content Update Notes](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

**Havoc Demon Hunter**

<em>Developers’ notes: The following changes to Fury generation are a small
	overall increase, paced more smoothly and relying less heavily on Immolation
		Aura's talent effects.</em>

- New Talent: [[spell:427794]] - damage increased by 3% above 50%
  	  health, and Leech increased by 5% below 50% health.
- [[spell:427794]] has been removed.
- [[spell:258881]] now deals its full damage immediately rather than over 4 seconds.
- [[spell:390154]] is now a 12 second buff on the player rather than on targets affected.
- [[spell:203550]] now generates 10 Fury per second per point (down from 15).
- [[spell:389693]] has been moved to a choice node with [[spell:389687]].
- [[spell:427640]] now increases damage by 12% for 6 seconds (previously 18% for 5 seconds).
- [[spell:258920]] damage reduced by 8%.
- [[spell:258860]] initial damage increased by 49%.
- [[spell:320374]] causes [[spell:258920]] to generate an additional 30 Fury (down from 40).
- [[spell:203555]] now generates 10-16 Fury per hit (up from 8-15).
- [[spell:188499]], [[spell:210152]], [[spell:344862]] & [[spell:201427]] damage increased by 6%.
- [[spell:370965]] damage increased by 12%.

Many of these changes had a significant impact on the value of previously key
talents, while opening up more options to sustain its Fury needs without relying
on [[spell:258920]]. Paired with some previous changes, this brought
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver much closer - especially in single-target - and both
builds can shine depending on the situation. Despite having some of its key tools
reduced, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred remained a potent pick, able to adapt its damage
profile to all encounter types without much difficulty.

:::

### Midnight   Changes Overview

3.5.

#### Havoc Demon Hunter Changes in Midnight

The release of Midnight brought with it massive overhauls to some specs, but
when it comes to Havoc it remains very similar to the core built in The War
Within. The most notable change relates to its Fury generation, which has been
reduced, alongside surgical changes to reduce some sequencing requirements. Below
are some notes on key things to be aware of, broken down into sections.

3.5.1.

##### Havoc Apex Talent - Eternal Hunt

The new class feature in Midnight is Apex Talents, powerful 4-step talent nodes
that provide compounding benefits when taken. For Havoc, [[spell:1270898]]
focuses on [[spell:370965]], turning it into a stronger cooldown with follow-up
effects:

- [[spell:1270898]] — causes [[spell:370965]] to increase the damage
    of your next [[spell:198013]] cast, and affect enemies in a wider area.
- [[spell:1270900]] — has two points, reducing the cooldown of
    [[spell:370965]] by 15 seconds and causing it to hit 2 additional enemies per
    point.
- [[spell:1270901]] — increases [[spell:188499]] damage by 20%,
    and whenever you fully channel [[spell:198013]] your next Blade Dance
    cast will refresh its own cooldown.

The entire package is extremely powerful for both hero talents, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
gaining more frequent [[spell:442294]] procs, and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred
empowering its [[spell:213410]] windows further with extra [[spell:210152]]
casts. These points are included in every build, turning [[spell:370965]] into
a powerful combo-enabling cooldown useful in both single-target and AoE.

3.5.2.

##### Hero Talent Changes

While the changes to both Hero Talent trees are relatively modest for Havoc,
they are impacted in particular by the Fury generation changes. They still maintain
a similar gameplay flow while retaining their damage profile niches, with some
key changes:

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) **Aldrachi Reaver Changes -** <em>Click for Details</em>
  
  
  - [[spell:442686]] now grants 6% Haste, and increases the damage of your next [[spell:442294]] by 30%.
  - [[spell:442806]] now has a soft-cap of 8 targets on its funnel effect.
  - **Three new talents:** [[spell:1272143]], [[spell:1272138]] and
    	  [[spell:1272153]].
  
  
  
    Of the two trees, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver is more negatively impacted by the
    Fury and Talent Tree changes that happened. [[spell:390163]]
    and [[spell:204596]] (alongside [[spell:395446]]) have been replaced by
    [[spell:1266330]], but this is a noticeable reduction in reliable Soul
    generation. The new [[spell:1272143]] does go some way towards mending this,
    though the potency of its funnel through [[spell:442806]] in high target
    situations has been toned down.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) **Fel-Scarred Changes -** <em>Click for Details</em>
  
  
  - [[spell:452402]] now deals Chaos damage, scaling with Mastery.
  - [[spell:452415]] increases [[spell:452402]] damage by 5% per stack, down from 10%.
  - [[spell:452408]] accumulates 35% of damage dealt, down from 50%,
    	  but now also applies to [[spell:206416]] damage from [[spell:188499]].
  - **Three new talents:** [[spell:1272364]], [[spell:1272405]] and
    	  [[spell:1272453]].
  
  
  
    On the other hand, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred saw quality of life improvements
    across the board. The most important is [[spell:452402]] being
    added back to the Havoc Mastery, while also including [[spell:206416]] in the
    [[spell:452408]] effect. This goes a long way toward fixing some of the
    rotational issues that had crept in before, and while losing [[spell:204596]]
    did impact [[spell:452415]], the tree is definitely improved over its
    previous iteration.

3.5.3.

##### Rotation & Talent Changes

The most noticeable thing when starting with Midnight Havoc will be the changes
to Fury. Both [[spell:204596]] and [[spell:390163]] have been removed,
along with [[spell:344859]] (with [[spell:203555]] now becoming baseline,
and buffed by 20%). Pair that with [[spell:232893]] having its generation reduced
to 15, and you'll find resources are slower alongside being more passive.

On the talent tree, a few things have changed and been moved:

- [[spell:370965]] and [[spell:213410]] are now both in the centre of the spec tree.
- [[spell:389693]] and [[spell:388112]] have been combined into a choice node.
- [[spell:427775]] is now flat CDR for [[spell:258920]] rather than a reset proc.
- [[spell:258860]] now triggers flat bonus damage instead of being a multiplier.
- [[spell:342817]] is now a passive proc when [[spell:188499]] hits 3+ enemies, instead of an active.

This makes pathing on the tree a bit more streamlined, while also trimming both
the extended opener sequencing and AoE RNG streaks that can get in the way of
smooth gameplay.

3.5.4.

##### Utility & Defense

For defense, Havoc saw big improvements with the addition of [[spell:1266307]].
Adding a second charge to [[spell:198589]] is a huge bonus for survival, and the spec
tree node change that came with it is even stronger. [[spell:205411]]
now increases the damage reduction to 35%, and provides 10% damage reduction whenever
you're below 35% HP. Although it came at the cost of the bonus dodge chance, it
still results in a significant boost to your overall durability. [[spell:196555]]
has also been lost in the transition to Midnight.

In the utility department, [[spell:211881]] was removed, though in exchange
[[spell:179057]] stun duration has been increased to 3 seconds. This pairs with
a new follow-up, [[spell:1266296]], increasing the duration to 5 seconds on your
current target. [[spell:1266493]] has also been added, increasing your movement
speed while gliding, providing even more mobility on an already mobile spec.

4.

### Basics of Havoc Demon Hunter Gameplay

Havoc comes with a tight core ability package that gives it an easy
pick-up-and-play aspect. This is greatly expanded through the talent tree, and
build diversity adds a lot of depth. Broken down into a few key building blocks,
the general flow operates on these rules:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_chaosstrike.jpg>)
  **Build and Spend Fury**  
  
    The core loop for Havoc involves building Fury with [[spell:203555]] and
    [[spell:232893]], then spending it on [[spell:188499]] and [[spell:344862]].
    This is the central pillar of the spec.
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_eyebeam.jpg>)
  **Combo Burst Windows**  
  
    Havoc has a number of short cooldown burst effects that work best when overlapped.
    [[spell:198013]], [[spell:258860]] and [[spell:198793]] all trigger
    powerful buffs and debuffs to capitalize on.
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_ability_felscarreddemonhunter_demonsurge.jpg>)
  **Maximize Hero Tree Effects**  
  
    Each of Havoc's Hero Trees adds in a core effect. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
    uses [[spell:442294]] to trigger combos, while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred
    executes a [[spell:452402]] sequence each [[spell:191427]].

These come together to flesh the Havoc rotation out, and are still in play
during your major cooldown window: [[spell:191427]]. The spec has a lot of
hidden complexity to optimize, but under the hood it follows some very simple
rules that are easy to understand. Paired with its robust mobility toolkit in
[[spell:344865]] and [[spell:198793]], the spec has a uniquely fast-paced
feel in all aspects.

5.

### How to Gear Up as a Havoc Demon Hunter

While we always recommend simming yourself for ideal results, we do provide a
dedicated Havoc gearing page. We currently cover recommendations for
Season 2 gear to start off on the right foot when stepping into endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate
consumables, gems, and enchants to go with those new items.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.5 and addition of Kith'ix.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.5, adjusted Aldrachi to recommended to align with mid Season 2 buffs.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5.
- **30 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated to adjust for Font of Venomous Rage power following sim fixes.
- **30 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Switched to double Rite of the Hash'ey - very close but much easier to fit into gearsets.
- **30 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated to set recommendations to Fel-Scarred and default to Raid Cleave.
- **30 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Switched recommendations in raid to Fel-Scarred due to current performance.
- **30 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated to switch recommendation for Raid to Fel-Scarred.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Confirmed gearset following gear changes, switched weapon enchants and expanded FAQ about early craft optimizaiton.
- **24 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Switched to double Jan'alai's Precision due to Neck changes encouraging more Crit.
- **19 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Added disclaimer regarding uncertain gear recommendations due to Aqirbane Reliquary hotfixes.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 12.1.
- **10 Aug. 2026 (this page):** Updated for Patch 12.1.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.7 with Sporefall gear.
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.7 with Omnium Folio recommendations.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Updated for Patch 12.0.7.
- **24 May 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated openers for better sequencing.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Updated for Patch 12.0.5.
- **07 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Added FAQ note regarding early crafts to optimize Dawncrest uses.
- **07 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Adjusted ring enchant recommendations to Eyes of the Eagle.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated with full Season 1 recommendations.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Season 1 - added Teas and additional Consumables for Mythic+.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Season 1 release.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Season 1 release.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for release of Midnight Season 1.
- **16 Mar. 2026 (this page):** Updated for release of Midnight Season 1.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Midnight release.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight release and Pre-season.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Midnight release with copy elements.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight release.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Midnight release.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight release.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight release.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Midnight release.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Midnight release.
- **26 Feb. 2026 (this page):** Updated for Midnight release.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for new Class Tree talent gates.
- **10 Feb. 2026 (this page):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated for Patch 11.2.7
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.5 with Cartel Chip recommendations.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **03 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated to emphasize recommendations are with the new Tier Set.
- **28 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Re-organized Trinket rankings based on current performance.
- **28 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Added Mythic+ Utility Talent cheat sheet for use cases in each dungeon.
- **28 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Improved signposting for build use cases in the rotation tool.
- **28 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated to highlight Fel-Scarred's edge in single target more clear.
- **14 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Season 3 release trinket hotfixes.
- **12 Aug. 2025 (this page):** Updated to include Season 3 release buff.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.2.
- **04 Aug. 2025 (this page):** Updated for Patch 11.2.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated to account for D.I.S.C. hotfixes.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.7, added D.I.S.C. belt and adjusted BiS list slightly for double Gallywix weapon.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **15 Jun. 2025 (this page):** Updated for Patch 11.1.7.
- **28 May 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Amended Corruption recommendation due to ongoing Echoing Void bug.
- **12 May 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Confirmed Dinar recommendations for Turbo Boost release.
- **12 May 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated following Corruption tuning.
- **12 May 2025 (this page):** Added note to highlight updated Cartel Chip and Corruption recommendations.
- **28 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Added individual dungeon tips.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.1.5 and added Cartel Chips section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Updated for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5 - moved Aldrachi AoE build back to low movement options due to ease of execution.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.5 - moved Aldrachi AoE build back to low movement options due to ease of execution.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.1.5 - moved Aldrachi AoE build back to low movement options due to ease of execution.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Updated for live releases of bosse and Gallywix tips.
- **04 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Adjusted some trinket rankings to account for recent changes.
- **04 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Adjusted class trees to be more raid appropriate.
- **04 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Adjusted Aldrachi Reaver build to add Inertia for now.
- **04 Mar. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Added Inertia to base Aldrachi AoE loadout.
- **04 Mar. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Shifted Aldrachi Reaver AoE toward picking Inertia.
- **04 Mar. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Added movement talents back to Aldrachi Reaver AoE for now.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 (this page):** Updated for Patch 11.1.0.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated to highlight strength of new ring following hotfixes.
- **17 Dec. 2024 (this page):** Updated to highlight strength of new ring following hotfixes.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 11.0.7 for Cyrce's Circlet.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.7, added recommended tags.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.0.7, added recommended tags.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.7, added recommended tags.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 11.0.7 with much simpler basic rotation breakdown.
- **15 Dec. 2024 (this page):** Updated for Patch 11.0.7.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5, shifted recommended trinkets around.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5, switched to Mastery recommendations.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 11.0.5 to separate Fel-Scarred and Aldrachi Reaver weights.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 (this page):** Updated for Patch 11.0.5.
- **30 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Updated with appropriate builds and more recent tips for all bosses.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated with Season 1 BiS lists.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Added note for Speed Blasphemite.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-nerub-ar-palace-raid-guide>)):** Page added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for War Within Season 1 release.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated to reflect new Fel-Scarred recommendations.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated to reflect new Fel-Scarred recommendations.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated to reflect new Fel-Scarred recommendations.
- **09 Sep. 2024 (this page):** Added note regarding tier set hotfix.
- **02 Sep. 2024 (this page):** Updated to reflect new Fel-Scarred information.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/havoc-demon-hunter-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/havoc-demon-hunter-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/havoc-demon-hunter-mists-of-pandaria-remix-guide>)):** Page added.
- **13 May 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Format adjustment to move slider closer to rotation.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Season 4.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Season 4.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Season 4.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated to include Season 4 builds.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Season 4 with new talent options.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Season 4.
- **22 Apr. 2024 (this page):** Updated for Season 4.
- **21 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Slight shuffle of trinket recommendations, but content remains the same for Patch 10.2.6.
- **21 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.6, shifted recommended build to Glaive Tempest but otherwise no changes.
- **21 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.6, core recommendations remain the same.
- **21 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.6, strongest builds remain the same but alternatives kept.
- **21 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **21 Mar. 2024 (this page):** Reviewed for Patch 10.2.6.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5, highlighted Ashes of the Embersoul as an alternative.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5, added note that Crit stays good even during diminishing returns.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed and touched up for mid-season 3 information.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5, small cleanups but no major changes necessary.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5, small recommendation cleanups around AoE final point choices.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated to account for spell school changes in Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5, no changes necessary.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **06 Dec. 2023 (this page):** Updated with note for Dec. 6th hotfixes.
- **27 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Added Augury to ideal trinkets.
- **13 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Slight change to T30 AoE build tips and added low movement T30 single target.
- **09 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Restructured and updated for Patch 10.2.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated to remove Sporecloak recommendation, switched to Blue Silk/Toxic Thorn options.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Checked for Patch 10.2, no changes necessary.
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated link to Mythic+ hub.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Restructured and fully updated for Patch 10.2 rework.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.2 rework.
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Patch 10.2.
- **06 Nov. 2023 (this page):** Updated for Patch 10.2.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Added BiS lists for Patch 10.1.7 and restructured page.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1.7, added Glaive Tempest/Ragefire build and switched it to the recommended choice.
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7, added loadout buttons in rotation section and restrucutred page.
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.1.7, changed AoE recommendation to Glaive Tempest/Ragefire, restructured page.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7, no changes necessary.
- **04 Sep. 2023 (this page):** Updated for Patch 10.1.7.
- **10 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.1.5.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1.5 to clean up Trinket and Crafting sections, and add Dawn of the Infinite items.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Patch 10.1.5 to add Wafting Devotion note and recommend against Annulet.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.5, moved up Haste in single-target.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.5 with small tweaks for clarity and Isolated Prey highlights.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Patch 10.1.5, added individual sections and the No Movement build recommendation.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.5, no changes necessary.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **25 May 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Added Timewalking section, cleaned up original Trinket recommendations.
- **15 May 2023 (this page):** Added note regarding May 15th buff hotfixes.
- **09 May 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Trinket changes.
- **09 May 2023 (this page):** Updated to point to Boss Tips and Trinket updates.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.1 and Season 2 release with new gear recommendations.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Patch 10.1, no significant changes needed.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.1 with details about new affixes, build remains the same.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.1 with Serrated Glaive and notes added, and extra Essence Break combo notes.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Builds updated to account for Patch 10.1 changes, including Serrated Glaive as an option.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Patch 10.1 talent changes.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.1, added section highlighting Essence Break's importance.
- **01 May 2023 (this page):** Updated for Patch 10.1 changes, added new highlight sections and expected performance.
- **29 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.1, no changes necessary.
- **24 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Primordial Gemstones hotfixes.
- **24 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Primordial Stones hotfixes.
- **22 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Patch 10.0.7.
- **22 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated to account for Primordial Gemstone buffs.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated to account for Primordial Stone buffs.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/havoc-demon-hunter-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Patch 10.0.7 with Annulet information.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed and updated for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed and cleaned up for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Updated for Patch 10.0.7.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5, rotation tool refined.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed and updated for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Reviewed and updated for Patch 10.0.7.
- **01 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated Opener.
- **31 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Weapon Enchantment recommendation changed to Sophic Devotion.
- **31 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Raised the priority of Mastery in single target.
- **31 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Raised Mastery in Stat Priority.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated to Gear Page Format.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Season 1.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Fixed Formatting and Hotfixes.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **27 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Added an additional, single-target-focused build.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/havoc-demon-hunter-leveling-guide>)):** Updated for Dragonflight.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/havoc-demon-hunter-best-legendaries-shadowlands>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/havoc-demon-hunter-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/havoc-demon-hunter-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spec-builds-talents>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-easy-mode>)):** Updated for Dragonflight Pre-Patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight Pre-Patch.
- **30 Jul. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Season 4.
- **29 Jul. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated for Season 4.
- **19 Feb. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-2-changes-analysis>)):** Checked for Patch 9.2 release.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **01 Nov. 2021 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Patch 9.1.5 to more broadly accomodate Momentum/Demonic as equal.
- **10 Jul. 2021 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-sanctum-of-domination-raid-guide>)):** Page added.
- **17 May 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-1-changes-analysis>)):** Page updated with Covenant Legendaries.
- **27 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/havoc-demon-hunter-patch-9-1-changes-analysis>)):** Page created with initial information.
- **21 Jan. 2021 ([Castle Nathria page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated for more recent logs following settling of Nathria release.
- **08 Dec. 2020 ([Castle Nathria page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** Updated for Shadowlands Season 1 release.
- **01 Dec. 2020 ([Castle Nathria page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-castle-nathria-raid-guide>)):** Added placeholder Castle Nathria page.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **08 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Uldir page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **01 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Updated with details for each boss.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **03 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-battle-of-dazar-alor-raid-guide>)):** Page added.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **12 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** Updated following week 1 Uldir observations.
- **04 Sep. 2018 ([Uldir page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** Updated with initial tips for Uldir release.
- **09 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-uldir-raid-guide>)):** Page created in preparation for the eventual Uldir release (empty for now).

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Havoc Demon Hunter leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Demon Hunter leveling guide](<https://www.icy-veins.com/wow/demon-hunter-leveling-guide>).

1.

### Havoc Demon Hunter Leveling Guide for Midnight

Welcome to our Leveling Guide for Midnight. This will help you in your
journey to max level as a Havoc Demon Hunter, covering talents and
abilities you should know about.

Havoc Demon Hunter deals massive front-loaded AoE burst while
leveling, and is suited to pulling a large amount of enemies to kill them quickly.
It also has excellent self-sustain, which means you usually don't have to worry
about how much you pull. It's also well suited to dungeons because of this AoE
toolkit, but you may find your queues go faster if you do so as Vengeance instead,
to tank.

1.1.

#### Leveling Gear Options

Item level is always more important than individual stats when leveling up. Always
choose the piece of gear with the highest item level. Items with Speed tertiary
stats can help speed up your leveling, especially during parts of extended time
spent indoors. Heirloom gear is also useful while leveling, allowing you to ignore a lot
of gearing for a large part of your leveling journey.

1.2.

#### Useful Leveling Consumables for Midnight

If you're looking for that extra boost to get through Midnight leveling and
catch up to endgame, there's a handful of items and enchants that can help speed
things up.

- [[item:191348]] — A Phial from [Dragonflight](<https://www.icy-veins.com/wow/dragonflight-expansion>)
  which persists through death, giving bonus Speed for 30 minutes. If you're already
  geared, it's often about moving between pulls rather than a bit more damage.
- [[item:225592]] — A food item from [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>),
  grants a large boost to Speed for 1 hour, but is lost on death.
- [[item:213746]] — If your gear has plenty of sockets, switch
  to this Algari Diamond and each of [The War Within](<https://www.icy-veins.com/wow/the-war-within-patch-11-0-overview>)'s gem colors
  for extra speed.
- [[item:223653]] / [[item:223683]] / [[item:223725]] / [[item:223800]] —
  Switch all of your armor enchants over to extra Speed effects if you were previously
  using Avoidance or Leech.
- [[item:132516]] — A tried and true pickup for leveling, these are always
  nice to have to get through areas where you can't mount, and even work across water.
  These <em>can't</em> be activated while in combat though, and are cancelled when
  taking damage.
- [[item:154168]] / [[item:154169]] — These
  consumables from Battle for Azeroth can help with any sections that involve going
  underwater - though in Midnight's zones that doesn't happen very often.

2.

### Leveling Talents

**等级 1–9：**Unlike many classes, you start at Level 8, and start in
the Demon Hunter intro campaign on Mardum. Some abilities are unlocked as you
progress through this story segment, granting access to your core
Havoc abilities when you select your specialization at Level 10.

**等级 10 起：**

At level 10, you will unlock [[spell:198793]], an extra movement tool
to pair with [[spell:344865]]. Your first class tree point is [[spell:232893]],
generating Fury, and your first spec tree point is [[spell:198013]] - a powerful
burst AoE cooldown.

Your talents can be changed anywhere in the world as long as you are out of
combat. Be sure to explore various combinations of talents at will while leveling
to get a feel of the gameplay flow. We have provided a sample leveling path below
that introduces core Havoc concepts over the course of your journey.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Havoc Leveling - Level 80 Starting Talents
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmwMDAAAAAAY2MGmxYwMDmZmx2Y2YWGwsZGY2QjZmxwGAAAAAAAAzMYAAAAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMzmxMzMmZmwMDAAAAAAY2mxwMGDmZwMzM2GzGzyAbzmZMMbMNmZGDbAAAAAAAAMzwMAAAAM"
}
```
:::

:::details 来源计算器编码
```
#BJ-iNEVUSgKkIIWZKAqpdc055tYmaIMONhddhC-PIJXgOhEtOqqMCEGoaaAm0IJHJ44y2F-AAAA-ZaWUMCEekYAISB-
```

:::

**等级 20 起：**2.1.

#### **等级 20 起：**War Mode Talents for Leveling

**等级 20 起：**In this section, we will rank the PvP talents for
leveling and doing solo or small-group PvE content. Below is a ranking of both
General PvP Talents and Havoc Demon Hunter-specific PvE talents.

1. [[spell:213480]] is just free Fury generation as you will take damage
   in the open world.
2. [[spell:206803]] can be helpful to deal with dangerous enemies while
   staying safe, though it's not as strong as simply using your abilities.
3. [[spell:355995]] can provide a small amount of extra healing and Soul generation

**等级 20 起：**[[spell:205604]], [[spell:205596]],
[[spell:357419]], [[spell:205625]], [[spell:205630]] and
[[spell:354489]] all have very limited uses in PvE. These are more focused
on crowd control tools, or pressuring enemy players into spending more resources
than they would otherwise want to, so don't really have uses in the open world.

3.

### Leveling Rotation

To help with understanding what changes as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

**等级 71 起：**After reaching level 71 and unlocking Hero Talents, we
recommend playing with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred to empower your [[spell:191427]]
with [[spell:452402]].

3.1.

#### Key Concepts

As you level and populate the talent tree, you'll gains access to additional
tools to navigate the world outside of just its rotation. This section will
grow alongside the slider with each level.

- **Remember to Recuperate!** - Whenever you're low on health between pulls,
   you can use the [[spell:1231418]] ability available to all classes to
   quickly recover.
- **等级 1–9：****Use your Movement!** - Havoc has access to [[spell:344865]],
   allowing you to quickly cross distances to stay in the fight.
- **等级 10 起：****Use your Movement!** - Havoc has access to [[spell:344865]]
   and [[spell:198793]], giving you two ways to quickly jump between targets.
- **等级 1–27：****Leverage your Healing** - Havoc heals from killing
   enemies with [[spell:178940]] orbs.
- **等级 28 起：****Leverage your Healing** - Havoc heals from killing
   enemies with [[spell:178940]] orbs. [[spell:204909]] also provides
   a large amount of Leech (especially while in [[spell:191427]]), so
   pull big!
- **等级 18–69：****Remember your Defense** - [[spell:198589]] is a strong
   defensive, use it frequently!
- **等级 70 起：****Remember your Defense** - [[spell:198589]] is a strong
   defensive, and even has two charges, so use it frequently!

**等级 10 起：**3.2.

#### **等级 10 起：**Dynamic Priority List

Below is a sample priority list to keep track of which abilities to press:

1. **等级 56 起：**Cast [[spell:370965]] as frequently as possible (especially against tough enemies).
2. **等级 10 起：**Cast [[spell:232893]] to engage targets
3. **等级 75 起：**Cast [[spell:452487]] / [[spell:452497]] while in [[spell:191427]].
4. **等级 20–50：**Use [[spell:191427]] as frequently as possible (especially against tough enemies).
5. **等级 11 起：**Cast [[spell:198013]] on cooldown.
6. **等级 15 起：**Cast [[spell:188499]] / [[spell:210152]] on cooldown.
7. **等级 14 起：**Cast [[spell:258920]] on cooldown.
8. **等级 51 起：**Use [[spell:191427]] as frequently as possible when [[spell:198013]] and [[spell:188499]] are on cooldown (especially against tough enemies).
9. **等级 12–14：**Cast [[spell:188499]] on cooldown against multiple enemies.
10. **等级 8 起：**Cast [[spell:344862]] / [[spell:201427]] whenever you have enough Fury.
11. **等级 10 起：**Cast [[spell:232893]] to generate Fury.
12. **等级 16 起：**Cast [[spell:185123]] when you need to pull enemies from a distance.

**等级 10 起：**3.2.

#### **等级 10 起：**Survival Tools

**等级 10 起：**Havoc has a habit of pulling big and getting into dangerous
situations, but luckily it comes with a variety of tools to help manage this:

- **等级 10 起：**[[spell:178940]] spawn when killing an enemy,
    healing for a percentage of health.
- **等级 10 起：**If you ever find yourself stuck or caught in a dangerous
    situation, [[spell:344865]] dashes and [[spell:198793]] can almost
    always get you out of it.
- **等级 18 起：**[[spell:198589]] has a high duration and a low cooldown,
    so don't be afraid to use it if you ever feel unsafe.
- **等级 24 起：**[[spell:179057]] gives you an emergency AoE stun if
    you're caught in a bad situation.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **13 May 2024:** Format adjustment to move slider closer to rotation.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5.
- **01 May 2023:** Reviewed for Patch 10.1.
- **22 Mar. 2023:** Updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Havoc Demon Hunter in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics of Havoc Demon Hunter

Welcome to our Easy Mode Page! This section is intended for players who are new
to the game or class, have no intentions of raiding Mythic difficulty, and want a
straightforward rundown of how the specialization plays without the overwhelming
priority details needed for optimal play.

The Havoc rotation is relatively simple at its core, expanded greatly by the
talent tree. It's almost GCD locked, so it follows the common melee principle:
**always be pressing something**. Three simple rules to keep in mind that cover
its core pillars are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_chaosstrike.jpg>)  **Build and Spend Fury**  
  
    Your offensive resource. It's built with auto-attacks through [[spell:203555]],
    [[spell:232893]], and [[spell:258920]]. Most abilities require it, such
    as [[spell:188499]] (cast on cooldown) and [[spell:344862]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_eyebeam.jpg>)  **Utilize Burst Windows**  
  
    Havoc has cooldown windows with follow-up sequences. [[spell:198013]] triggers
    [[spell:213410]], cast on cooldown every 20 seconds, followed by two [[spell:210152]]
    casts via [[spell:1270901]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_metamorphasisdps.jpg>)  **Use Big Cooldowns**  
  
  [[spell:191427]] resets the cooldown of [[spell:188499]] and [[spell:198013]]
    every 2 minutes, so use those before casting it. [[spell:370965]] should be cast
    on cooldown to empower Eye Beam.

Learning Havoc is all about understanding the cadence of Fury and planning
your cooldown cycles. It's best to start out by getting a feel for how quickly it
can generate, and building up the intuition for when you need to keep some in
reserve to avoid running out. Once you have that down, get comfortable with your
cooldown timings and learn the sequencing they use.

While previously we've used low-movement options on this page, the shift toward
[[spell:206476]] in Season 2 makes standard builds much easier to execute. Although
elsewhere on our guide we recommend using ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver for
raid encounters, for the purposes of picking the spec up, we'll be sticking to
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred. It has much easier execution, is more flexible, and also
punishes mistakes less aggressively in all types of endgame content.

2.

### Beginner's Guide to Havoc Demon Hunter in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred   Raid Build

2.1.

#### Raid / Single-Target Talent Build for Havoc Demon Hunter

In The Venomous Abyss, both of Havoc's Hero Trees have their strengths, but
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred's ability to shift its damage profile depending on the
situation with its up-front burst makes it easier to pull off when getting started.
It's focused around the power of your [[spell:213410]] windows, dealing additional
bursts of AoE damage through [[spell:452402]].

It has a 20-second burst cycle, using [[spell:198013]] and [[spell:258887]].
Every minute, [[spell:370965]] further empowers your Eye Beam, while
[[spell:191427]] gives a period of intense burst every two minutes with
additional [[spell:452402]]s.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMzMmJjZGAAAAAAwsZMbzMGDmZsMzYGmZMmlB2mFzYY2YaMzMG2AAAAAAAAYmBDAAAAD"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXgiIJOWAHNSUeGRm044IJ3CFIMQ0MC-AAAA-BeERhphowYJQwA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred   Dungeon & Delve Build

2.2.

#### Dungeon / AoE Talent Build for Havoc Demon Hunter

In AoE and dungeon content, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred provides frequent and effective
burst tools, providing punchy overall damage regardless of target count. The
benefits of having most of its single-target toolkit are invaluable, and the burst
from [[spell:198013]] casts every 20 seconds triggering [[spell:452402]] makes
it easy to plan around.

The playstyle is fairly straightforward, rewarding good use of your [[spell:198013]]
on cooldown while efficiently using Fury. AoE also has a stronger focus on
[[spell:258920]] to deal pulsing damage around you.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJOhACEGOoqqsMkiMpxxRSWSsNC-AAAA-BeERhphowYJQ4A-
```

:::

### Single-Target & AoE   Rotation Breakdown

2.3.

#### Beginner Havoc Demon Hunter DPS Rotation

Anywhere that [[spell:344862]] is mentioned, this also applies to
[[spell:201427]] during [[spell:191427]]. The same is also true for
[[spell:188499]] and [[spell:210152]]. Havoc has no buffs to apply to your
party, or setup required before entering combat. It's always prepared!

2.4.

#### Single Target Breakdown

The Havoc single-target rotation is dictated by the building and spending of
Fury to fuel its abilities. Managing this is the most important skill to learn.
Here's a brief breakdown of the key steps when getting started:

- **Generate & Spend Fury**  
  
    Your auto-attacks generate via [[spell:203555]], and [[spell:232893]] / [[spell:258920]] generate when cast.  
  
  <em>Always</em> cast [[spell:188499]] on cooldown, otherwise spend on [[spell:344862]].
- **Execute Your Combo**  
  
    Cast [[spell:198013]] every 20 seconds, followed by two [[spell:210152]]s using [[spell:1270901]].  
  
    Cast [[spell:258860]] on cooldown with the tier set.
- **Use Big Cooldowns**  
  
    Cast [[spell:191427]] every 2 minutes - make sure [[spell:188499]] and [[spell:198013]] are on cooldown.  
  
    Cast [[spell:370965]] on cooldown every minute.
- **Consume your Demonsurges**  
  
    Every [[spell:198013]] cast should be followed by [[spell:201427]] and [[spell:210152]].  
  
    Your [[spell:191427]] casts also extend this to [[spell:452487]] and [[spell:452497]].

When first starting out, it's best to break up the steps to adjust to the gameplay flow.
We recommend focusing on getting each of these things down in the following order.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_specdps.jpg>) **Havoc Single-Target**
**Fury Management**

➜

**[[spell:198013]] & [[spell:452402]] Usage**

➜

**Combos & Cooldowns**

:::

2.5.

#### AoE Breakdown

Havoc plays almost exactly the same in AoE, with the addition of more [[spell:258920]]
casts as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred using [[spell:427775]]. Below is a rundown of how
it changes:

- **Blade Dance as a Priority**  
  
    Save a reserve of Fury to keep [[spell:188499]] / [[spell:210152]] on cooldown.
- **Keep Immolation Aura on Cooldown**  
  
    You never want to be at 2 charges of [[spell:258920]] with [[spell:427775]].  
  
    Spend all charges before casting [[spell:191427]].

When it comes to AoE, a lot of the core principles can be learned by practicing
single-target. We'd recommend focusing on things in the following order:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_demonhunter_specdps.jpg>) **Havoc AoE**
**Learn Single-Target**

➜

**[[spell:452402]] Usage**

➜

**[[spell:258920]] Priorities**

:::

2.5.1.

##### Apex Talent: Eternal Hunt

All builds spend four points in the Apex Talent, [[spell:1270898]], which
turns [[spell:370965]] into a strong cooldown, used every minute. Follow up each
cast with an empowered [[spell:198013]], then back-to-back [[spell:210152]]s
using the reset [[spell:1270901]] provides.

2.5.2.

##### Season 2 Tier Set

Season 2 of Midnight introduces the **Abyssal Doomhound's Pursuit**, available
from different endgame content. This provides the following bonuses:

- [[spell:1296611]] — [[spell:188499]], [[spell:344862]]
  	and [[spell:258860]] deal 12% increased damage.
- [[spell:1296612]] — [[spell:258860]] now applies
  	and benefits from the effects of [[spell:258887]], deals 35% increased
  	initial strike damage, and has a 2 second increased duration.

Both of these bonuses make [[spell:258860]] a mandatory talent, which is
used on cooldown to trigger bonus damage. While there are some optimizations
covered on our main [Rotation page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-rotation-cooldowns-abilities>),
the basic principle is covered by taking the talent and using it on cooldown.

### Survival Tools &   **Defensive Spells**

2.6.

#### Defensive Spells for Havoc Demon Hunter

Havoc has access to a few different active and passive defensive tools, giving
it solid survivability and self-sustain during combat. Havoc is generally considered
quite durable, and is great in solo or group content.

**[[spell:198589]] -** provides 25% damage reduction for 10 seconds, with a
1-minute cooldown, and has two charges with [[spell:1266307]]. This is
Havoc's most consistent defense tool, and due to both its low cooldown and extra
charge, should be used liberally to counteract incoming damage.

**[[spell:205411]] -** further increases the damage reduction of
[[spell:198589]] to 35%. Additionally, reduces all damage taken while below 35% health
by 10% at all times, giving some extra durability.

**[[spell:427776]] -** grants an absorb shield equal to 15% of your
maximum health during the [[spell:188499]] animation. This is an extra way to
mitigate damage when timed well, allowing you to survive lethal mechanics, but it
can be difficult to get the timing down since the ability is often cast on
cooldown.

**[[spell:196718]] -** provides you and nearby allies a 15% chance
(increased to 30% outside of a raid group) to avoid damage taken from attacks for
8 seconds. This can be extremely powerful, but is best used for frequent instances
of damage rather than gambling on avoiding lethal ones.

**[[spell:191427]] -** during the cast animation, you are briefly
immune to all damage and effects for 1 second. On rare occasions, this can be
used to avoid dangerous mechanics.

**Self-Healing -** while not active defensive tools, Havoc comes with built-in
Leech through [[spell:204909]]. This gives a flat 10% at all times, plus an
additional 10% during [[spell:191427]]. Alongside that, [[spell:206478]]
and enemy deaths often trigger Soul Fragments which provide healing in combat.

**![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver -** has access to [[spell:442714]], which causes
[[spell:232893]] to reduce damage taken by 10% for 5 seconds when cast. This
has sporadic uptime and can't really be planned around due to Felblade
being needed for Fury generation, but adds some extra defense.

### Gearing &   **Stat Priority**

2.7.

#### Havoc Demon Hunter Stat Priorities

The Havoc stat priority is fairly straightforward and is as follows. For more information 
on what's presented on this page, check out our main [Stat Priority page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>).

Agility

Critical Strike

Mastery

Haste

Versatility

Stat priorities may shift based on other talents taken or in different encounter
types, but this should cover most scenarios.

2.8.

#### Gearing a Havoc Demon Hunter

When it comes to gearing in Midnight Season 2, you want to
prioritize your Tier Set as quickly as possible, and crafting a weapon is a
quick way to gain a lot of power right out of the gate. Due to how many different
options are available when it comes to gearing a character, it's best to
jump over to our main [Gearing page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot>)
for a more comprehensive breakdown on things to chase.

### Blizzard   Rotation Assist

2.9.

#### Blizzard Rotation Assist for Havoc Demon Hunter

Added in The War Within, the Rotation Assist tool curated by Blizzard has
two modes: the first highlights action bar buttons with a recommended priority,
while the second provides a single keybind that automatically presses the
top priority ability on that same list, but with a 25% GCD penalty between
casts.

Uniquely for Havoc, it's significantly impacted by the restrictions on what
the tool will <em>not</em> recommend, and this still hasn't changed in Midnight.
In addition to on-use trinkets, racials, and major cooldowns, any of Havoc's
abilities that displace your character will **never** be recommended in the 
priority. This includes:

- **Cooldowns -** [[spell:191427]], [[spell:370965]].
- **Movement/Displacement -** [[spell:232893]], [[spell:344865]], [[spell:198793]].

All of these will need to be used manually if you have talents related to
them taken. This extends to defensive and crowd control abilities as
well.

Due to the exclusion of [[spell:232893]], Havoc has a harder time keeping up with
resource requirements, and the flow is often disrupted. While it can be used, you'll
still need to be manually inserting these casts to really make good use of it in
combat.

While in many cases the tool is quite good for picking up a brand new spec,
unfortunately in Havoc's case it is heavily impacted, and doesn't really perform
the actions it needs to. We'd recommend staying well away from using ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
with it, and sticking to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred builds.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **30 Aug. 2026:** Updated to switch recommendation for Raid to Fel-Scarred.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **03 Sep. 2025:** Updated to emphasize recommendations are with the new Tier Set.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5 - moved Aldrachi AoE build back to low movement options due to ease of execution.
- **04 Mar. 2025:** Added movement talents back to Aldrachi Reaver AoE for now.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7 with much simpler basic rotation breakdown.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated to reflect new Fel-Scarred recommendations.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Reviewed for Patch 10.1, added section highlighting Essence Break's importance.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **31 Dec. 2022:** Raised Mastery in Stat Priority.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Havoc Demon Hunter in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Havoc Demon Hunter

In Midnight, Havoc saw some restructuring within its tree, and Season 2 has
broadened some options to allow for less strict build requirements. It still has
to specialize a little more than it did previously, but has some good tools
available, in particular the Apex Talent - [[spell:1270898]] - cementing
[[spell:370965]] as a powerful 1-minute cooldown.

- **Raid –**
  	Both trees are capable of performing in raids, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
  	has the higher ceiling following repeated buffs. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred is still
  	very capable on cleave encounters though, so both can be played.
- **Mythic+ –**
  	Similarly, both Hero Trees are strong, with different specialties. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred
  	excels at raw overall throughput, while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver exists as a
  	priority target specialist for higher key levels.

The release of Season 2 brought with it a lot of tuning to try and bring both
Hero Trees together, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver needed follow-up buffs to hit
that mark. Now by Patch 12.1.5, both are competitive, carving out specialties that
allow for them to shine in different areas. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred is easy to
execute, bringing punchy up-front burst and free cleave throughout, suiting it
well to Mythic+ and raid encounters with multiple targets or damage amp windows.
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver on the other hand brings potent funnel with [[spell:442806]]
and similarly good cleave tools for lower target counts, allowing it to stand out
in the more difficult raid encounters and high-level Mythic+.

**Quick Start Import Codes:**

:::talents Raid / Single-Target – Aldrachi Reaver
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZMjZmZmxMZMzAAAAAAAmNjZbmxYmtZmxyMjZsMzwMLzsNDGGLbMhxMjhFAAAAAAAwMDwAAAAwA"
}
```
:::

:::talents AoE / Mythic+ – Fel-Scarred
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::talents High Mythic+ Keys – Aldrachi Reaver
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::talents Delves – Fel-Scarred
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMjxMhZGAAAAAAwsYmhZMzAzYZmZmxyMDmlB2mNzYY2YaMzMzM2AAAAAAAAYmBDAAAAD"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Aldrachi Reaver

Single-Target

recommended

Mythic+

high key

Delves

Fel-Scarred

Raid/Cleave

Raid/Single-Target

Mythic+

recommended

Delves

recommended

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver Single-Target Build

In Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver has benefited from many of the changes
  made to Havoc, in particular the additional Fury from [[spell:203555]]. Due
  both to the power of the new Tier Set and repeated tuning buffs, it
  now stands as the strongest single-target option, while bringing enough cleave
  and funnel to stand out in The Venomous Abyss. As such, it's our recommended
  choice:

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver AoE Build

Much like in single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver saw big improvements in
  Season 2, and repeated buffs targeted at its specialty raised its value. It's
  returned as a strong priority damage and funnel spec, making it well suited for
  higher key levels where this comes at a premium. While it's less broad in its
  use cases, in cutting-edge content it becomes the go-to pick.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver Delve Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver is well suited to [Delves](<https://www.icy-veins.com/wow/delves-guide>) due to the high
  Soul Fragment generation, providing additional sustain. It can handle larger pulls
  comfortably, though the extra management that [[spell:442624]] requires can
  be awkward in some situations. Aside from that, it's a solid pick.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred Raid Cleave Build

Due to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred having significant variance in builds if you want
  to build for pure single-target, we've chosen to provide a build tailored to the
  high amount of cleave present in The Venomous Abyss. While this falls slightly
  behind ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver when played correctly, its ease of execution
  and flexibility make it a worthwhile competitor if you find it more comfortable:

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred Single-Target Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred was previously the strongest tree in The Venomous Abyss,
  but repeated buffs to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver have caused it to fall slightly
  behind. It's still more than capable of keeping up though, and its easier
  execution paired with the higher focus on burst means it can still perform well
  on certain encounters. We would, however, still recommend the **Raid Cleave**
  build if you're looking to use this extensively.

### 天赋方案 1-2

1.6.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred AoE Build

While ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred's lead was lost in single-target, it has retained most
  of its advantage when it comes to AoE. It still provides more burst, while having
  a solid single-target core for boss encounters. Since it is also fairly easy to play,
  it is our **recommended choice** for general keys in Season 2.

### 天赋方案 1-3

1.7.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred Delve Build

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred excels in [Delves](<https://www.icy-veins.com/wow/delves-guide>), having both frequent and
  powerful burst AoE through [[spell:213410]] every 20 seconds. Pair this with
  [[spell:191427]] every 2 minutes for dangerous foes, and [[spell:204909]]
  providing Leech whenever you're transformed, and you can often tear through
  encounters very safely. The number of tools it has that specifically play into
  solo encounters found in Delves makes this the **recommended** choice.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZMjZmZmxMZMzAAAAAAAmNjZbmxYmtZmxyMjZsMzwMLzsNDGGLbMhxMjhFAAAAAAAwMDwAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZMjZmZMmJMzAAAAAAAmFzMMjZmZbmZsMzYGLzMMzyMbzghxyGTYMzMzYBAAAAAAAMzAMAAAAM"
}
```
:::

:::details 来源计算器编码
```
#BJ-NUiEKSVWAJPLQQY6OO00GNTFMmmC88yKxCB-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMzMmJjZGAAAAAAwsZMbzMGDmZsMz8AzwMDmlB2mFzYY2YaMzMG2AAAAAAAAYmBDAAAAD"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXgiIJOWAHNSUGRm044IJ3CFIMQ0UNC-AAAA-BeERhphowYJQwA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYAzMjZMzMzMmJjZGAAAAAAwsZMbzMGjlZmxyMzDMzsMzsMGDsNLmxwsx0wMjhNAAAAAAAAmZwAAAAwA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUiEKSVWBJLQQSY688OO00GNTFMmmw4C2C-PXYgiIJOWAHNNSUVeGMRm0446QSuIzG-AAAA-BeERhphowYJQwA-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJOhACEGOoqqsMkiMpxxRSWSsNC-AAAA-BeERhphowYJQ4A-
```

:::

### 天赋方案 1-3

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMjZMzMjxMhZGAAAAAAwsYmhZMzAzYZmZmxyMDmlB2mNzYY2YaMzMzM2AAAAAAAAYmBDAAAAD"
}
```
:::

:::details 来源计算器编码
```
#BJ-NhiEKUVgknFIIMSWy688KPO00GNTFMmmwCA-PXgiIJOhACEGOoqqsMkiMpxxRSSkZbE-AAAA-BeERhphowYJQ4A-
```

:::

### 天赋方案 0-0

In single-target, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver picks up all of the [[spell:185123]]
  talents to empower [[spell:442294]], and uses [[spell:1220506]]
  to pull value out of them rotationally. It picks up both [[spell:206476]] and
  [[spell:389688]] to integrate movement into the build, and takes
  [[spell:388116]] on the final choice node.

[[spell:258887]] is a key pickup at the bottom of the tree, enabling the
  20-second burst cycle for [[spell:198013]] and [[spell:213410]]. Due to the
  Season 2 Tier Set effects, it also picks up [[spell:258860]]. Finally, it
  invests all four points into [[spell:1270898]], granting increased access to
  [[spell:370965]] and, by extension, [[spell:442294]] triggers.

### 天赋方案 0-1

In AoE situations ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver builds are extremely similar to
  single-target, picking up the same [[spell:185123]] package to empower
  [[spell:442294]]. Due to a lot of its AoE being sourced from abilities it
  leans into for single-target, the rest of the tree follows the same priorities
  optimizing [[spell:188499]] and other physical damage effects for
  [[spell:442806]]. Your one choice is whether you pick up [[spell:427794]]
  or [[spell:258881]] - both are similar in terms of throughput, with the latter
  providing more overall damage in a dungeon.

The Season 2 set bonus keeps [[spell:258860]] as a mandatory pick at the
  bottom, while [[spell:258887]] remains crucial to building its 20-second
  burst cycle. Lastly, all four points are spent in the Apex Talent, [[spell:1270898]],
  to improve [[spell:370965]] as a 1-minute cooldown.

### 天赋方案 1-0

Functionally this has the same goals as the single-target build, building out
  [[spell:191427]] related talents to empower [[spell:213410]] windows.
  Instead of skipping [[spell:427776]] and grabbing purely single-target
  talents, it paths through it to reach high value cleave options, while building
  out [[spell:258920]]. This adds significantly more flexibility, working
  better in encounters where add spawns need to be killed as a priority. **One**
  talent point in the centre is flexible, depending on fight style:

- **Drop -** One point in [[spell:203550]].
- **Take -** [[spell:388113]].

This is done in fights where there is a <em>significant</em> amount of time spent
  with the boss alone (for example Vashnik). You maintain the cleave benefits for
  add spawns, while picking up a powerhouse single-target talent for the remainder
  of the fight.

### 天赋方案 1-1

Season 2 still retains the heavy focus on your [[spell:213410]] windows,
  emphasizing the 20-second cycle through [[spell:258887]] lined up with
  [[spell:389688]] activations. Due to the reduction in [[spell:427640]]'s
  power, it instead uses [[spell:206476]] for more consistent damage. It also plays
  [[spell:388116]] at the bottom of the tree instead of [[spell:427775]],
  as it can now sustain its Fury through the improvements made to [[spell:203555]].
  Due to there being a few different options to switch around in Raids, we have a
  few additional notes.

- With the addition of [[spell:427794]], ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred can now
    get out of the opening gate while avoiding [[spell:427776]], picking up
    purely offensive talents. However, this limits some of the cleave options
    available, so many fights in The Venomous Abyss are more suited to the Raid Cleave
    loadout.
- The Season 2 Tier Set significantly improves [[spell:258860]], making
    it a mandatory pickup in the final gate and locking up a talent point compared to
    previous builds.
- [[spell:388113]] is a hard choice to evaluate, as its power ebbs and
    flows with add spawns. In <em>most</em> cases, however, it is valuable enough to
    pick, provided the encounter isn't <em>entirely</em> cleave-based.

### 天赋方案 1-2

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred's goals remain very similar to both the single-target and
  cleave builds, leaning heavily into [[spell:213410]] windows every 20 seconds.
  Like all loadouts, the Season 2 Tier Set requires [[spell:258860]] to
  activate, and both [[spell:258887]] and [[spell:1270901]] form its
  core mid-range cooldowns.

It always grabs [[spell:258920]] talents, relying on [[spell:427775]]
  and [[spell:388107]] to empower it in AoE, while taking [[spell:452413]]
  on the Hero Tree. Due to reductions in the strength of [[spell:427640]] in Season
  2, it's also made the switch over to [[spell:206476]].

The builds listed above are recommendations based on strength and popularity,
covering each area of content in endgame PvE. Each build has its own rotation to
execute, with unique aspects to master, with their own tricks up their sleeve to
assist your group in different encounters.

2.

### Omnium Folio

Introduced in [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), the Omnium Folio is a player power system
that provides a small number of performance boosting effects, unlocked through a
series of quests. These bonuses aren't related to any gear pieces, and are
always active on your character. Some provide additional damage, while others
grant some healing and extra defensive tools.

Below, we've listed recommendations for each of the five Runes, unlocked as you
complete the Folio quest chain:

- **Rune 1 –** [[spell:1279599]]
- **Rune 2 –** [[spell:1279603]]
- **Rune 3 –** [[spell:1287555]]
- **Rune 4 –** [[spell:1279609]]
- **Rune 5 –** [[spell:1279614]]

It's worth noting that the difference between most of these effects is very
minor. The fourth stat boosting Rune is relevant, however, providing a solid
amount of your chosen secondary through regular procs. Due to the uniquely powerful
benefits for Havoc, Critical Strike is recommended.

3.

### Apex Talent: ![Eternal Hunt Icon](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_demonhunter_eternalhunt.jpg>) Eternal Hunt

The Havoc Apex Talent, [[spell:1270898]], focuses on both [[spell:370965]]
and [[spell:198013]], adding additional combo effects to each cast. All four
points are extremely powerful, and each node has unique interactions for <em>both</em>
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred:

- [[spell:1270898]] **first point –** causes [[spell:370965]] to empower
    your next [[spell:198013]] cast, increasing its damage by 100% and increasing
    the range of the beam.
- [[spell:1270900]] **second and third points –** reduces the cooldown
    of [[spell:370965]] by 15 seconds and increases the number of targets hit by the
    DoT effect by 2 for each point.
- [[spell:1270901]] **fourth point –** increases [[spell:188499]]
    damage by 20%, and fully channelling [[spell:198013]] causes your next
    Blade Dance cast to reset its own cooldown.

This turns [[spell:370965]] into a 1-minute burst cooldown, dealing high AoE
damage on its own, while also causing each follow-up [[spell:213410]] window to
guarantee two [[spell:210152]] casts. This significantly improves 20-second
burst cycles for each tree, leaning toward ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred's high focus on
these windows. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver instead benefits greatly from the reduced
cooldown, providing a reliable way to guarantee [[spell:442294]] procs.

4.

### Hero Talents

Havoc has two distinct Hero Tree choices available that, as covered in the
above sections, drastically alter your gameplay goals depending on which you pick.
These two Hero Talents are ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

This tree grants access to [[spell:442294]], triggered via consuming
Souls, and replaces your next [[spell:185123]] with a significantly more powerful
version. Specific mechanics are:

- After casting [[spell:442294]], a combo sequence is initiated. Your
    next [[spell:344862]] and [[spell:188499]] will trigger a bonus effect,
    and after both you gain [[spell:442686]].
- [[spell:442624]] is applied via [[spell:344862]] from this combo.
    This causes <em>all</em> Physical damage you deal to duplicate a portion as
    Chaos onto the affected target through [[spell:442806]].

This makes ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver a powerful funnel specialization, which is
often extremely sought after. The addition of [[spell:1272153]] in Midnight
causes [[spell:188499]] casts to convert a significant amount of AoE damage
directly into your marked target, allowing it to pick off priority targets.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred focuses on your [[spell:191427]] windows - both the
2-minute cooldown and activations through [[spell:213410]]. It comes with a number
of buffs and effects to your core abilities, and some specific mechanics:

- After entering [[spell:191427]] via any means, your next cast of both
    [[spell:201427]] <em>and</em> [[spell:210152]] will trigger
    [[spell:452402]], dealing high AoE Chaos damage.
- After casting [[spell:191427]], your next [[spell:198013]]
    and [[spell:258920]] also trigger a [[spell:452402]]. When transformed,
    they also convert to [[spell:452497]] and [[spell:452487]], respectively.

This means ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred's damage is centered around its 20-second burst
cycle, making use of [[spell:258887]] to lower [[spell:198013]]'s cooldown
to enter [[spell:213410]]. This is then amplified even more every two
minutes during [[spell:191427]], dealing potent front-loaded burst through
[[spell:452402]] chains.

5.

### PvP Talents (War Mode)

"War Mode" is an optional feature that enables open-world PvP
encounters that confer some benefits when active:

- Grants access to PvP talents in the open world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points which can reward gear every week.

With the benefits of War Mode for leveling and PvE content, it is an optional
way to maximize your leveling speed and reward potential. However, you will open
yourself up to open-world PvP, so be aware of hostile enemy players who could
interfere with you; this is a risk you will have to decide on your own if you want
to take.

Here, we'll only be looking at PvP talents that have use cases for aiding with
leveling or open-world PvE scenarios, as their PvP benefits are discussed on our
PvP page. Generally, the selections are made to optimize your ability to kill
enemies faster, increasing your pace when moving through content.

- [[spell:213480]] is just free Fury generation as you will take damage
  in the open world.
- [[spell:206803]] can be helpful to deal with dangerous enemies while
  staying safe, though it's not as strong as simply using your abilities.
- [[spell:355995]] can provide a small amount of extra healing and Soul generation.

[[spell:205604]], [[spell:205596]], [[spell:357419]],
[[spell:205625]] and [[spell:354489]] all have minimal uses in
PvE, due to them being very focused on crowd control tools or pressuring
enemy players into spending more resources than they would otherwise want
to.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5, adjusted Aldrachi to recommended to align with mid Season 2 buffs.
- **30 Aug. 2026:** Switched recommendations in raid to Fel-Scarred due to current performance.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Omnium Folio recommendations.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **28 Aug. 2025:** Updated to highlight Fel-Scarred's edge in single target more clear.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5 - moved Aldrachi AoE build back to low movement options due to ease of execution.
- **04 Mar. 2025:** Shifted Aldrachi Reaver AoE toward picking Inertia.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, added recommended tags.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated to reflect new Fel-Scarred recommendations.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4 with new talent options.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6, strongest builds remain the same but alternatives kept.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, small recommendation cleanups around AoE final point choices.
- **13 Nov. 2023:** Slight change to T30 AoE build tips and added low movement T30 single target.
- **06 Nov. 2023:** Updated for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, changed AoE recommendation to Glaive Tempest/Ragefire, restructured page.
- **10 Jul. 2023:** Updated for Patch 10.1.5, added individual sections and the No Movement build recommendation.
- **01 May 2023:** Builds updated to account for Patch 10.1 changes, including Serrated Glaive as an option.
- **20 Mar. 2023:** Reviewed and updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Havoc Demon Hunter in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Havoc Demon Hunter Gameplay and Rotation Guide

Welcome to the Rotation section of our Havoc Demon Hunter guide
that goes over everything you need to know about Havoc gameplay in Raids and
Mythic+!

Due to both Hero Talents for Havoc having different specialities, below
we have some quick recommendations on which tree to use in each content style
in Midnight Season 2:

- **Raid / Single Target –**
  	Both trees are capable of performing in raids, but ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
  	has the higher ceiling following repeated buffs. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred is still
  	very capable on cleave encounters though, so both can be played.
- **Mythic+ / AoE –**
  	Similarly, both Hero Trees are strong, with different specialties. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred
  	excels at raw overall throughput, while ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver exists as a
  	priority target specialist for higher key levels.

At the onset of Season 2, attempts were made to bring both ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver
and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred closer together. While they initially missed the mark,
follow-up tuning achieved that, and even allowed ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver to
leapfrog above. It sits as a powerful priority damage spec through [[spell:442806]],
capable of dealing with most raid encounters. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred instead can
slot into almost all situations, using its 20-second burst cycle with [[spell:452402]]
to navigate different encounter cadences.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

Raid / Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Mythic+ / AoE

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred

Raid / Cleave

Raid / Single Target

Mythic+ / AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

Active Talents

Passive Talents

[[spell:258860]]

[[spell:427775]]

[[spell:206476]]

[[spell:427640]]

[[spell:388108]]

### Single Target

1.1.

#### Havoc Demon Hunter Single Target Rotation

Havoc's single-target rotation is closely linked to its build-and-spend cycle. It uses generation tools to fuel [[spell:188499]], spends excess Fury on [[spell:344862]], and combos cooldowns together.

---

1. **适用条件：Aldrachi Reaver（启用）。** 
   Cast [[spell:370965]] - <em>Click for Notes</em>
   
   
   - <em>Make sure</em> you've spent any active [[spell:442294]] procs before casting.
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:191427]] if [[spell:198013]] and [[spell:210152]] are **both** on cooldown
3. **适用条件：Inertia（启用）；Aldrachi Reaver（启用）。** 
   Cast [[spell:232893]] with [[spell:427640]] ready - <em>Click for Notes</em>
   
   
   - If [[spell:232893]] isn't available, use [[spell:344865]] instead.
4. **适用条件：Exergy（启用）。** 
   Cast [[spell:198793]] to trigger [[spell:206476]] - <em>Click for Notes</em>
   
   
   - <em>Always</em> try to align this with [[spell:198013]] for [[spell:388108]].
5. **适用条件：Initiative（启用）；Exergy（未启用）。** 
   Cast [[spell:198793]] to trigger [[spell:388108]] - <em>Click for Notes</em>
   
   
   - <em>Always</em> try to align this with [[spell:198013]].
6. **适用条件：Aldrachi Reaver（启用）。** 
   Cast [[spell:442294]] - <em>Click for Notes</em>
   
   
   - Make sure to have no active [[spell:442442]] or [[spell:442435]] buffs active
   - Follow this up with [[spell:344862]] / [[spell:201427]] to apply [[spell:442624]]
7. **适用条件：Fel-Scarred（启用）。** 
   Cast [[spell:191427]] if [[spell:198013]] and [[spell:210152]] are **both** on cooldown - <em>Click for Notes</em>
   
   
   - Make sure you've consumed any [[spell:210152]] and [[spell:201427]] procs of [[spell:452402]]
8. **适用条件：Inertia（启用）；Fel-Scarred（启用）。** 
   Cast [[spell:232893]] with [[spell:427640]] ready - <em>Click for Notes</em>
   
   
   - If [[spell:232893]] isn't available, use [[spell:344865]] instead.
9. **适用条件：Fel-Scarred（启用）。** 
   Cast [[spell:370965]] - <em>Click for Notes</em>
   
   
   - If [[spell:191427]] is available, hold to buff [[spell:452497]].
10. **适用条件：Fel-Scarred（启用）；Essence Break（未启用）。** Cast [[spell:210152]] with [[spell:452402]] active
11. **适用条件：A Fire Inside（启用）；Fel-Scarred（启用）。** 
    Cast [[spell:258920]] if at 2 charges - <em>Click for Notes</em>
    
    
    - If [[spell:191427]] is almost ready, dump both charges to make use of the reset.
12. **适用条件：Fel-Scarred（启用）；Essence Break（启用）。** Cast [[spell:210152]] during [[spell:258860]] or with [[spell:452402]] active
13. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:198013]]
14. **适用条件：Essence Break（启用）；Aldrachi Reaver（启用）。** 
    Cast [[spell:258860]] - <em>Click for Notes</em>
    
    
    - If [[spell:198013]]'s cooldown has 4 or less seconds remaining, hold until after.
15. **适用条件：Fel-Scarred（启用）。** Cast [[spell:201427]] with [[spell:452402]] active
16. **适用条件：Fel-Scarred（启用）。** 
    Cast [[spell:198013]] / [[spell:452497]] - <em>Click for Notes</em>
    
    
    - Make sure you've consumed any [[spell:201427]] and [[spell:210152]] procs of [[spell:452402]].
17. **适用条件：Essence Break（启用）；Aldrachi Reaver（未启用）。** 
    Cast [[spell:258860]] - <em>Click for Notes</em>
    
    
    - If [[spell:198013]]'s cooldown has 4 or less seconds remaining, hold until after.
18. Cast [[spell:210152]] / [[spell:188499]]
19. **适用条件：Fel-Scarred（启用）。** Cast [[spell:452487]] with [[spell:452402]] active
20. Cast [[spell:201427]] / [[spell:344862]]
21. **适用条件：Fel-Scarred（启用）。** Cast [[spell:258920]] / [[spell:452487]]
22. Cast [[spell:232893]]
23. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:258920]]
24. Cast [[spell:344865]] with nothing else available

---

**适用条件：Fel-Scarred（启用）。** Havoc's gameplay loop is heavily influenced by your talent selections, with many effects impacting your priority. Each Hero Tree also interacts with the toolkit in different ways, shifting around when your key burst moments happen. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred heavily focuses on your [[spell:213410]] windows following each [[spell:198013]], while front-loading burst every 2 minutes with your [[spell:191427]] cast.

**适用条件：Aldrachi Reaver（启用）。** Havoc's gameplay loop is heavily influenced by your talent selections, with many effects impacting your priority. Each Hero Talent also interacts with the toolkit in different ways, shifting around when your key burst moments happen. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver weaves in [[spell:442294]] throughout its rotation gained through gathering souls, empowering your [[spell:188499]] and [[spell:344862]] casts, and uses [[spell:370965]] every minute to guarantee a proc.

1.2.

#### Single Target Rotation Notes & Tips

**适用条件：Fel-Scarred（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred, based on your selections in the tool above:

**适用条件：Aldrachi Reaver（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, based on your selections in the tool above:

- **适用条件：Fel-Scarred（启用）。** Every time you enter [[spell:213410]], you should be casting two [[spell:210152]]s through [[spell:1270901]], and one [[spell:201427]] to consume [[spell:452402]]. Following a [[spell:191427]] cast, this extends to consuming the effect from both [[spell:452497]] and [[spell:452487]].
- **适用条件：Fel-Scarred（启用）。** In Midnight, triggering [[spell:213410]] from [[spell:191427]] via [[spell:452497]]
  <em>will</em> generate new [[spell:452402]] procs, so you can freely refresh for a new set.
- **适用条件：Aldrachi Reaver（启用）。** [[spell:442294]] is a high priority press due to the raw damage it deals. [[spell:442624]] should be maintained at all times, but stacks aren't a huge concern.
- **适用条件：Aldrachi Reaver（启用）。** [[spell:370965]] is used to snap generate [[spell:442294]] at the start of the pull, or for priority targets.
- **适用条件：Essence Break（启用）。** [[spell:258860]] windows are longer with the Tier Set, so you want to avoid cutting into the debuff with [[spell:198013]]. If there's a clash coming up, hold it until you've entered into [[spell:191427]].
- **适用条件：Fel-Scarred（启用）。** You want to buff [[spell:452497]] with [[spell:1270901]], so when [[spell:191427]] is ready hold until after using it.
- **适用条件：Exergy（启用）。** [[spell:206476]] is maintained by casting [[spell:198793]] on cooldown.
- **适用条件：Inertia（启用）。** [[spell:427640]] should be triggered right before each [[spell:198013]] window, as the cooldown of [[spell:198793]] naturally aligns. Trigger it with a follow-up [[spell:232893]] (or [[spell:344865]] if unavailable) right before beginning your [[spell:198013]].

---

:::details FAQShould I Cast Fel Rush for Damage?
Rarely. While you may run into some empty GCDs occasionally, its damage is washed out if you lose melee uptime using it. When playing with

[[spell:427640]]

however, it's an important backup method to trigger the effect in the event you don't have

[[spell:232893]]

ready.

:::

:::details FAQShould I Actively Cast Throw Glaive?
Rarely. It's a filler GCD that deals minimal damage if you have

<em>absolutely nothing else</em>

available. With talents that improve it, due to the way

[[spell:1220506]]

works, you shouldn't be actively casting

[[spell:185123]]

at all when taken, instead using

[[spell:188499]]

to trigger it.

:::

### AoE

1.3.

#### Havoc Demon Hunter AoE Rotation

Havoc's gameplay doesn't change much in AoE, thanks to the large amount of passive cleave built into many of its core abilities. Its talent builds do alter slightly though, shifting the priority.

---

1. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:191427]] if [[spell:198013]] and [[spell:210152]] are **both** on cooldown
2. **适用条件：Aldrachi Reaver（启用）。** 
   Cast [[spell:370965]] - <em>Click for Notes</em>
   
   
   - <em>Make sure</em> you've spent any active [[spell:442294]] procs before casting.
3. **适用条件：Inertia（启用）；Aldrachi Reaver（启用）。** 
   Cast [[spell:232893]] with [[spell:427640]] ready - <em>Click for Notes</em>
   
   
   - If [[spell:232893]] isn't available, use [[spell:344865]] instead.
4. **适用条件：Exergy（启用）。** 
   Cast [[spell:198793]] to trigger [[spell:206476]] - <em>Click for Notes</em>
   
   
   - <em>Always</em> try to align this with [[spell:198013]] for [[spell:388108]].
5. **适用条件：Initiative（启用）；Exergy（未启用）。** 
   Cast [[spell:198793]] to trigger [[spell:388108]] - <em>Click for Notes</em>
   
   
   - <em>Always</em> try to align this with [[spell:198013]].
6. **适用条件：Aldrachi Reaver（启用）。** 
   Cast [[spell:442294]] - <em>Click for Notes</em>
   
   
   - Make sure to have no active [[spell:442442]] or [[spell:442435]] buffs active
   - Follow this up with [[spell:344862]] / [[spell:201427]] to apply [[spell:442624]] to your priority target
7. **适用条件：Fel-Scarred（启用）。** 
   Cast [[spell:191427]] if [[spell:198013]] and [[spell:210152]] are **both** on cooldown - <em>Click for Notes</em>
   
   
   - Make sure you've consumed any [[spell:210152]] and [[spell:201427]] procs of [[spell:452402]]
8. **适用条件：Inertia（启用）；Fel-Scarred（启用）。** 
   Cast [[spell:232893]] with [[spell:427640]] ready - <em>Click for Notes</em>
   
   
   - If [[spell:232893]] isn't available, use [[spell:344865]] instead.
9. **适用条件：Fel-Scarred（启用）。** 
   Cast [[spell:370965]] - <em>Click for Notes</em>
   
   
   - If [[spell:191427]] is available, hold to buff [[spell:452497]].
10. **适用条件：Fel-Scarred（启用）；Essence Break（未启用）。** Cast [[spell:210152]] with [[spell:452402]] active
11. **适用条件：A Fire Inside（启用）；Fel-Scarred（启用）。** 
    Cast [[spell:258920]] if at 2 charges - <em>Click for Notes</em>
    
    
    - If [[spell:191427]] is almost ready, dump both charges to make use of the reset.
12. **适用条件：Fel-Scarred（启用）；Essence Break（启用）。** Cast [[spell:210152]] during [[spell:258860]] or with [[spell:452402]] active
13. **适用条件：Essence Break（启用）；Aldrachi Reaver（启用）。** Cast [[spell:210152]] during [[spell:258860]]
14. **适用条件：Fel-Scarred（启用）。** Cast [[spell:201427]] with [[spell:452402]] active
15. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:198013]]
16. **适用条件：Fel-Scarred（启用）。** 
    Cast [[spell:198013]] / [[spell:452497]] - <em>Click for Notes</em>
    
    
    - Make sure you've consumed any [[spell:201427]] and [[spell:210152]] procs of [[spell:452402]].
17. **适用条件：Essence Break（启用）。** 
    Cast [[spell:258860]] - <em>Click for Notes</em>
    
    
    - If [[spell:198013]]'s cooldown has 4 or less seconds remaining, hold until after.
18. Cast [[spell:210152]] / [[spell:188499]]
19. **适用条件：Fel-Scarred（启用）。** Cast [[spell:258920]] / [[spell:452487]]
20. **适用条件：Aldrachi Reaver（启用）；A Fire Inside（启用）。** Cast [[spell:258920]]
21. Cast [[spell:201427]] / [[spell:344862]]
22. **适用条件：Aldrachi Reaver（启用）；A Fire Inside（未启用）。** Cast [[spell:258920]]
23. Cast [[spell:232893]]
24. Cast [[spell:344865]] with nothing else available

---

**适用条件：Fel-Scarred（启用）。** The majority of tools you make use of in single-target apply directly to AoE, with the exception of [[spell:201427]] / [[spell:344862]], which have slightly less impact. Your focus depends on which Hero Talent is being played, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred placing a higher focus on [[spell:258920]] in combination with [[spell:427775]].

**适用条件：Aldrachi Reaver（启用）。** The majority of tools you make use of in single-target apply directly to AoE, with the exception of [[spell:201427]] / [[spell:344862]], which have slightly less impact. Your focus depends on which Hero Talent is being played, with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver leveraging [[spell:442806]] to deal high funnel damage to priority targets with [[spell:188499]] / [[spell:210152]].

1.4.

#### AoE Rotation Notes & Tips

**适用条件：Fel-Scarred（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred, based on your selections in the tool above:

**适用条件：Aldrachi Reaver（启用）。** Below is a list of a few quick notes about the most important aspects of your rotation when playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, based on your selections in the tool above:

- **适用条件：Fel-Scarred（启用）。** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred builds deal very high AoE burst every 2 minutes during [[spell:191427]]. Make sure to plan around these moments to maximize your output with [[spell:452402]] empowered abilities.
- **适用条件：Fel-Scarred（启用）；A Fire Inside（启用）。** [[spell:258920]] is a core component of AoE for ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred. [[spell:388107]] requires you to watch its expiry time, making sure you hit targets with the explosion. With [[spell:427775]], you should avoid sitting at 2 charges, and make sure you dump any before casting [[spell:191427]] to refund both charges.
- **适用条件：Aldrachi Reaver（启用）。** [[spell:442294]] is a high priority press both for its own damage and the [[spell:442718]] funnel into [[spell:442806]]. Always apply [[spell:442624]] to your priority target first, then consume the [[spell:188499]] buff **second** to empower it with [[spell:1272153]].
- **适用条件：Aldrachi Reaver（启用）。** [[spell:370965]] is used to snap generate [[spell:442294]] at the start of the pull, or for priority targets.
- **适用条件：Essence Break（启用）。** [[spell:258860]] windows are stronger with the tier set, but the main goal is to get as many [[spell:210152]] casts during the window as possible to maximize debuff procs. When possible, line uses up with opportunities to use [[spell:1270901]] resets.
- **适用条件：Fel-Scarred（启用）。** You want to buff [[spell:452497]] with [[spell:1270901]], so when [[spell:191427]] is ready hold until after using it.
- **适用条件：Exergy（启用）。** [[spell:206476]] is maintained by casting [[spell:198793]] on cooldown.
- **适用条件：Inertia（启用）。** [[spell:427640]] should be triggered right before each [[spell:198013]] window, as the cooldown of [[spell:198793]] naturally aligns. Trigger it with a follow-up [[spell:232893]] (or [[spell:344865]] if unavailable) right before beginning your [[spell:198013]].

---

:::details FAQShould I Cast Fel Rush for Damage?
Rarely. While you may run into some empty GCDs occasionally, its damage is washed out if you lose melee uptime using it. When playing with

[[spell:427640]]

however, it's an important backup method to trigger the effect in the event you don't have

[[spell:232893]]

ready.

:::

:::details FAQShould I Actively Cast Throw Glaive?
Rarely. It's a filler GCD that deals minimal damage if you have

<em>absolutely nothing else</em>

available. With talents that improve it, due to the way

[[spell:1220506]]

works, you shouldn't be actively casting

[[spell:185123]]

at all when taken, instead using

[[spell:188499]]

to trigger it.

:::

### ST Opener

1.5.

#### Havoc Demon Hunter Single Target Opener

The Havoc opener follows a sequence to make use of [[spell:388112]]. The aim is to get everything on cooldown, then enter [[spell:191427]] as soon as possible.

---

**适用条件：Aldrachi Reaver（启用）。**

[[spell:258920]]

1s

Pull

[[spell:370965]]

[[item:241288]]

[[spell:442294]]

[[item:270175]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

[[spell:198013]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

[[spell:442718]]

[[spell:201427]]

[[spell:442624]]

[[spell:210152]]

[[spell:191427]]

[[spell:198793]]

[[spell:344865]]

[[spell:427640]]

[[spell:198013]]

[[spell:210152]]

x2

**适用条件：Fel-Scarred（启用）。**

[[spell:258920]]

1s

Pull

**适用条件：Inertia（未启用）。**

**适用条件：Inertia（未启用）。**

[[spell:232893]]

**适用条件：Inertia（未启用）。**

[[item:241288]]

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：A Fire Inside（启用）。**

[[spell:258920]]

[[spell:198013]]

[[item:270175]]

[[spell:370965]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

x2

[[spell:201427]]

[[spell:191427]]

[[spell:198793]]

[[spell:210152]]

[[spell:452487]]

[[spell:201427]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

[[spell:452497]]

---

1. Cast [[spell:258920]] 1 second before the pull
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:370965]] to engage your target
   
   - Use [[item:241288]]
   - Use on-use trinkets such as [[item:270175]]
3. **适用条件：Fel-Scarred（启用）；Inertia（未启用）。** Cast [[spell:232893]] to engage your target
   
   - Use [[item:241288]]
   - Use on-use trinkets such as [[item:270175]]
4. **适用条件：Fel-Scarred（启用）；Inertia（启用）。** Cast [[spell:344865]] to engage your target
   
   - Use [[item:241288]]
   - Use on-use trinkets such as [[item:270175]]
5. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:442294]]
6. **适用条件：Aldrachi Reaver（启用）；Inertia（启用）。** Cast [[spell:232893]] to trigger [[spell:427640]]
7. **适用条件：Fel-Scarred（启用）；A Fire Inside（启用）。** Cast [[spell:258920]]
8. Cast [[spell:198013]]
9. **适用条件：Fel-Scarred（启用）。** Cast [[spell:370965]]
10. **适用条件：Inertia（启用）；Fel-Scarred（启用）。** Cast [[spell:232893]] to trigger [[spell:427640]]
11. **适用条件：Essence Break（启用）。** Cast [[spell:258860]]
12. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:210152]]
13. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:201427]]
14. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:210152]]
15. **适用条件：Fel-Scarred（启用）。** Cast [[spell:210152]] twice
16. **适用条件：Fel-Scarred（启用）。** Cast [[spell:201427]]
17. Cast [[spell:198793]] and immediately [[spell:191427]]
18. **适用条件：Inertia（启用）。** Cast [[spell:344865]] to trigger [[spell:427640]]
19. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:198013]]
20. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:210152]] twice
21. **适用条件：Fel-Scarred（启用）。** Cast [[spell:210152]]
22. **适用条件：Fel-Scarred（启用）。** Cast [[spell:201427]]
23. **适用条件：Fel-Scarred（启用）；A Fire Inside（启用）。** Cast [[spell:452487]]
24. **适用条件：Fel-Scarred（启用）。** Cast [[spell:452497]]
25. Continue with normal ability priority.

---

The most warping effect on the initial rotation is [[spell:388112]], which causes your [[spell:188499]] and [[spell:198013]] cooldowns to reset. [[spell:1270901]] also means you need to squeeze in two [[spell:210152]] casts from your opening [[spell:198013]] cast, before entering into [[spell:191427]].

### AoE Opener

1.6.

#### Havoc Demon Hunter AoE Opener

Much like in single-target, the AoE opener is about setting up before your [[spell:191427]]. The sequence is similar, with some elevated priority on AoE tools.

---

**适用条件：Aldrachi Reaver（启用）。**

[[spell:258920]]

1s

Pull

[[spell:370965]]

[[item:241288]]

[[spell:442294]]

[[item:270175]]

[[spell:198013]]

[[spell:201427]]

[[spell:442624]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

x2

[[spell:442718]]

[[spell:191427]]

[[spell:198793]]

[[spell:198013]]

[[spell:210152]]

x2

**适用条件：Fel-Scarred（启用）。**

[[spell:258920]]

1s

Pull

**适用条件：Inertia（未启用）。**

**适用条件：Inertia（未启用）。**

[[spell:232893]]

**适用条件：Inertia（未启用）。**

[[item:241288]]

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：A Fire Inside（启用）。**

[[spell:258920]]

[[spell:198013]]

[[item:270175]]

[[spell:370965]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:232893]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

[[spell:201427]]

**适用条件：Essence Break（启用）。**

[[spell:258860]]

[[spell:210152]]

x2

[[spell:191427]]

[[spell:198793]]

[[spell:210152]]

**适用条件：Inertia（启用）。**

**适用条件：Inertia（启用）。**

[[spell:344865]]

**适用条件：Inertia（启用）。**

[[spell:427640]]

**适用条件：A Fire Inside（启用）。**

[[spell:452487]]

[[spell:201427]]

[[spell:452497]]

---

1. Cast [[spell:258920]] 1 second before the pull
2. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:370965]] to engage your target
   
   - Use [[item:241288]]
   - Use on-use trinkets such as [[item:270175]]
3. **适用条件：Fel-Scarred（启用）；Inertia（未启用）。** Cast [[spell:232893]] to engage your target
   
   - Use [[item:241288]]
4. **适用条件：Fel-Scarred（启用）；Inertia（启用）。** Cast [[spell:344865]] to engage your target
   
   - Use [[item:241288]]
5. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:442294]]
6. **适用条件：Fel-Scarred（启用）；A Fire Inside（启用）。** Cast [[spell:258920]]
7. Cast [[spell:198013]]
   
   - Use on-use trinkets such as [[item:270175]] right before casting
8. **适用条件：Fel-Scarred（启用）。** Cast [[spell:370965]]
9. **适用条件：Inertia（启用）；Fel-Scarred（启用）。** Cast [[spell:232893]] to trigger [[spell:427640]]
10. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:201427]]
11. **适用条件：Aldrachi Reaver（启用）；Inertia（启用）。** Cast [[spell:232893]] to trigger [[spell:427640]]
12. **适用条件：Essence Break（启用）。** Cast [[spell:258860]]
13. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:210152]] twice
14. **适用条件：Fel-Scarred（启用）。** Cast [[spell:210152]] twice
15. **适用条件：Fel-Scarred（启用）。** Cast [[spell:201427]]
16. Cast [[spell:198793]] and immediately [[spell:191427]]
17. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:198013]]
18. **适用条件：Aldrachi Reaver（启用）。** Cast [[spell:210152]] twice
19. **适用条件：Fel-Scarred（启用）。** Cast [[spell:210152]]
20. **适用条件：Fel-Scarred（启用）；A Fire Inside（启用）。** Cast [[spell:452487]]
21. **适用条件：Fel-Scarred（启用）。** Cast [[spell:201427]]
22. **适用条件：Inertia（启用）。** Cast [[spell:344865]] to trigger [[spell:427640]]
23. **适用条件：Fel-Scarred（启用）。** Cast [[spell:452497]]
24. Continue with normal ability priority.

---

**适用条件：Fel-Scarred（启用）。** Just like in single-target, the most warping effect on your opening sequence is [[spell:388112]], requiring you to get both [[spell:188499]] and [[spell:198013]] on cooldown before entering into [[spell:191427]]. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred additionally needs to get [[spell:258920]] on cooldown for the reset, while making sure it sequences all of its [[spell:452402]] procs correctly.

**适用条件：Aldrachi Reaver（启用）。** Just like in single-target, the most warping effect on your opening sequence is [[spell:388112]], requiring you to get both [[spell:188499]] and [[spell:198013]] on cooldown before entering into [[spell:191427]]. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver needs to make sure it applies [[spell:442624]] to its target <em>before</em> triggering [[spell:442435]], then maximize [[spell:210152]] casts during [[spell:258860]] for AoE Tier Set procs.

2.

### Midnight Season 2 Tier Set

Season 2 of Midnight introduces the **Abyssal Doomhound's Pursuit**, available
from different endgame content. This provides the following bonuses:

- [[spell:1296611]] — [[spell:188499]], [[spell:344862]]
  	and [[spell:258860]] deal 12% increased damage.
- [[spell:1296612]] — [[spell:258860]] now applies
  	and benefits from the effects of [[spell:258887]], deals 35% increased
  	initial strike damage, and has a 2 second increased duration.

These bonuses both firmly lock in [[spell:258860]] as a required pickup,
turning it into a potent burst cooldown. Ideally, you want to layer this inside
[[spell:191427]] to make use of the extra Haste to trigger the debuff more
frequently. This isn't always possible though, as even at four stacks and a 30-second
cooldown, it desyncs from [[spell:198013]]'s 20. Don't hold for too long trying to
force an overlap, especially if it costs uses down the line.

The cooldown reduction <em>before it reaches max stacks</em> is dynamic, meaning
[[spell:258860]] will reduce the current cooldown on [[spell:198013]] by
2.5 seconds, and vice versa. Once you reach 4 stacks, both cooldowns will be
reduced by a flat 10 seconds when cast. This means you reach 4 stacks faster than
normal, hitting the 20-second Eye Beam cycle after your third cast.

2.1.

#### Havoc Demon Hunter Mechanics Breakdown

In the below sections are several explanations on exactly how some of Havoc's
core components work. They dive into the underlying mechanics of major cooldowns
and rotational abilities, helping you to get a better understanding of exactly
<em>why</em> you are pressing each button.

3.

### Havoc Mechanics Explained

### Apex Talent

3.1.

#### Havoc Apex Talent - Eternal Hunt

Havoc's Apex Talent, [[spell:1270898]], converts [[spell:370965]] into a
potent cooldown while also providing benefits to [[spell:198013]] and [[spell:188499]].
As both of these are core rotational buttons for each Hero Tree, all four points
have significant benefits, and are taken together:

- [[spell:1270898]] **first point -** causes [[spell:370965]] to empower
    your next [[spell:198013]] cast, increasing its damage by 100% and increasing
    the range of the beam.
- [[spell:1270900]] **second and third points -** reduces the cooldown
    of [[spell:370965]] by 15 seconds and increases the number of targets hit by the
    DoT effect by 2 for each point.
- [[spell:1270901]] **fourth point -** increases [[spell:188499]]
    damage by 20%, and fully channelling [[spell:198013]] causes your next
    Blade Dance cast to reset its own cooldown.

This turns [[spell:370965]] into a 1-minute burst tool, followed by a stronger
[[spell:198013]] cast, then a double [[spell:210152]] cast in the following
[[spell:213410]] window. The final point applies to <em>all</em> Eye Beam
casts, meaning that the 20-second burst cycle that both Hero Trees make use of is
significantly empowered. It's **crucial** however that you make sure you can
fully complete an Eye Beam cast when you commit to it, as losing out on
the follow-up effect is a major loss.

When playing as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred, you want to empower [[spell:452497]]
rather than [[spell:198013]] whenever possible. This means every two minutes when
[[spell:191427]] is available, you want to use [[spell:370965]] <em>after</em> 
the transformation, instead of the Eye Beam entry just beforehand.

### Movement Talents

3.2.

#### Movement Talents

Havoc comes with a number of unique talents that make use of its movement tools
to gain additional damage. Due to that, unlike other specs, being aware of how to
manage movement during an encounter is a key skill for Havoc. Notable talents that
make use of this type of gameplay are:

- [[spell:388108]] <em>and</em> [[spell:389688]]
- [[spell:206476]] <em>or</em> [[spell:427640]]
- [[spell:347461]]

[[spell:198793]] is the main activator for both [[spell:206476]] and
[[spell:427640]], cast on cooldown. The best way to get back to a target following
a Vengeful Retreat cast is [[spell:232893]], but it has a brief shared
movement cooldown after casting. This means you have to wait to cast it, but this
<em>usually</em> provides enough distance to activate the charge effect. This is
also the method for triggering [[spell:347461]], empowering
the return Felblade significantly.

3.2.1.

##### Exergy

[[spell:206476]] causes both [[spell:198793]] and [[spell:370965]] to
grant 5% increased damage, lasting for 20 seconds, and can be extended up to 30
seconds. This should be 100% uptime throughout an encounter, as the additional
time buffer granted by The Hunt gives you some breathing room to drift
Vengeful Retreat slightly. This is much less involved, very consistent, and
is the go-to pick in Season 2.

3.2.2.

##### Inertia

[[spell:427640]] provides a short-duration, high-intensity burst window.
This pairs well with a number of Havoc's tools, and with [[spell:258887]]
it perfectly aligns [[spell:198793]] with every [[spell:198013]]. You
should be timing your Vengeful Retreat casts around these windows, making
sure to have [[spell:232893]] available to get back onto your target quickly.

### Fury Management

3.3.

#### Fury Management

With Havoc being so reliant on its resources, it's important to identify
situations where you need to aggressively spend Fury vs. what you expect to
generate. Midnight brought a reduction to the amount generated on the tree, but
Season 2 increased the passive generation through [[spell:203555]], smoothing
out some of its resource issues. You'll also need to catch refunds from
[[spell:344862]] and potentially alter your plan for spending on the fly.

Some basic rules to follow when thinking about your Fury management in practice are:

- <em>Always</em> have enough Fury available to cast [[spell:188499]] / [[spell:210152]]
  and [[spell:198013]].
- Cast [[spell:344862]] / [[spell:201427]] as frequently as possible,
   unless pooling for burst windows.
- Cast [[spell:232893]] for active generation.
- Cast [[spell:258920]] as a backup generation tool if you fall behind
   on Fury.
- Wait, allowing [[spell:203555]] to generate Fury, or collect
  [[spell:206478]] orbs.
- Cast [[spell:185123]] or [[spell:344865]] if out of range of any
  targets or during empty globals.

Due to [[spell:203555]] being the primary generation method, there's often
a small amount of waiting, especially if you commit to over-spending. This is
normal, but with some experience you should be able to plan around - and
mitigate - the worst cases. The most important thing to remember though, is that
you never want to be caught during a burst window without the Fury to capitalize
upon it.

There will also be periods where you are flooded with Fury with good RNG streaks.
This is also normal, and having some waste in this period is fine. Making sure you
keep high priority abilities on cooldown is always more important.

### Essence Break

3.4.

#### Essence Break

[[spell:258860]] is an additional high-value burst cooldown, but only
lasts for 4 seconds, increased to 6 with the new Season 2 Tier Set. In Midnight,
this is now flat damage rather than a multiplier, so it's less important to
execute during [[spell:191427]]. It's still beneficial to cast inside this
window however, due to the bonus Haste allowing for extra procs.

Depending on your Haste, and whether you are affected by [[spell:2825]],
you should be able to fit in 4 casts during this window (5-6 with the set). As many
of these as possible should be [[spell:210152]] / [[spell:201427]] casts.
With the Apex Talent, [[spell:1270901]], this should reliably allow
you to cast at least two Death Sweeps per use, provided you cast it after
[[spell:198013]] to trigger [[spell:213410]]. With [[spell:191427]]
available, this extends to three through [[spell:388112]].

### Throw Glaive

3.5.

#### Throw Glaive Talents

While these talents are more supplementary than central, there are a number of
synergistic talents on the tree that bring [[spell:185123]] into the rotation
as a relevant ability.

- [[spell:391275]] – increases [[spell:185123]] damage by
    60%, reducing by 30% per bounce.
- [[spell:393029]] – adds a 25 Fury cost to [[spell:185123]],
    but it launches a second glaive when cast.
- [[spell:390154]] – causes [[spell:185123]] and
    [[spell:344862]] to increase your damage done with both abilities by
    15% for 12 seconds.
- [[spell:388106]] – [[spell:185123]] also leaves a Chaos damage
    DoT on the target, dealing 80% of the damage dealt over 6 seconds.
- [[spell:1220506]] – each cast of [[spell:188499]]
    automatically consumes one charge of [[spell:185123]], casting it for free
    on your primary target. Each individual Blade Dance slash also has a 50%
    chance to throw an additional glaive at 35% effectiveness.

These are often taken as a package, and use [[spell:1220506]] as the
activator to access the effects during rotational gameplay. This is far more
efficient than investing GCDs into manually casting it - which no build currently
does - so is usually the driver for taking other [[spell:185123]] talents.
This means this talent package is actually a lot more passive than it looks on
the surface.

While playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver however, these are required talents as
  they also affect your casts of [[spell:442294]]. It's important to know
  [[spell:1220506]] **does not** cast Reaver's Glaive with
  [[spell:188499]], it always needs to be manually cast.

### Immolation Aura

3.6.

#### Immolation Aura

[[spell:258920]] has a dedicated section of supporting talents on the
tree, down the right side. These are often taken together, especially in AoE,
synergizing well with each other:

- [[spell:320374]] – generates an additional 18 Fury over 6 seconds when cast.
- [[spell:390158]] – deals 10% increased damage each time it ticks.
- [[spell:391189]] – [[spell:203555]] and [[spell:185123]]
  apply a 15-second DoT, dealing Chaos damage. Targets affected take 35%
  increased [[spell:258920]] damage, with a limit of 3 wounds.
- [[spell:388107]] – 35% of damage dealt by up to 3 Critical Strikes of
  [[spell:258920]] is accumulated as Ragefire. When it expires, you detonate,
  dealing damage equal to the stored amount to nearby enemies.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred – [[spell:452413]] increases
  its range by 2 yards, and Critical Strike damage by 50%.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred – [[spell:1272405]] grants a 25% chance to
  reignite when it expires.

This forms a strong core in AoE that pairs with the talent discussed below,
[[spell:427775]], and is often cast as frequently as possible when taken.
[[spell:1220506]] also naturally applies the maximum number of
[[spell:391189]]s in AoE, but if you aren't playing it, this requires
tab-targeting to apply with [[spell:203555]].

[[spell:388107]] is a key mechanic to be aware of, and knowing when each instance
of [[spell:258920]] is about to expire is important. Making sure you don't
move out of range of enemies (or use movement tools to displace yourself) just
before it goes off helps to avoid it exploding into thin air.

3.6.1.

##### A Fire Inside

When playing [[spell:427775]], your [[spell:258920]] gains a second
charge, and its cooldown is reduced by 6 seconds. Additionally, it allows for
multiple auras to be active at once, so cast frequency is much higher. This is
usually paired with other Immolation Aura talents to maximize its damage.

When taken, your goal should be to avoid leaving it at 2 charges,
making sure that you plan around when it's about to cap and use it again beforehand.
Remember - nothing is lost due to the buffs overlapping. When playing as
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred, [[spell:452415]] will refund two charges when
cast, giving you a full refill to double up on [[spell:452487]]. This means
before [[spell:191427]], you want to be drained to zero charges to get the
most out of it.

3.7.

#### Havoc Demon Hunter Major Cooldowns

Throughout the talent tree, there are a few different cooldown options that
provide burst in different ways. Below, we'll be covering each of them, how they
impact the rotation, and how to use them.

4.

### Important Cooldowns for Havoc Demon Hunter

### Metamorphosis

4.1.

#### Metamorphosis

Havoc's major cooldown is [[spell:191427]], a 2-minute cooldown. When
cast, it deals a small amount of Chaos damage, stuns targets at your location
after casting, and enters into your Demon Form for 20 seconds. While transformed,
it confers the following benefits:

- **Haste** is increased by 20%
- [[spell:344862]] swaps to [[spell:201427]], dealing significantly more damage
- [[spell:188499]] swaps to [[spell:210152]], dealing significantly more damage
- [[spell:388112]] – resets the cooldown of [[spell:188499]] and [[spell:198013]]
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred – [[spell:452415]] resets the cooldown of [[spell:258920]]

While this is active, Havoc deals significantly more damage, and generates
additional resources to fuel its stronger abilities. Aim to enter with
as much Fury as you can, and leave with as little as possible, planning your
[[spell:191427]] casts so it's always on cooldown. While playing with
[[spell:388112]], you should make <em>absolutely sure</em> that both
[[spell:188499]] and [[spell:198013]] are on cooldown before pressing it. You
can also use the leap from casting it to cancel the [[spell:198793]]
animation in your opener, allowing you to stick to a target.

As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred, Fury generation is also dramatically
increased. This means you should spend <em>much</em> more aggressively, aiming to
ramp up the [[spell:452408]] DoT with [[spell:201427]].

### Eye Beam

4.2.

#### Eye Beam

Although [[spell:198013]] has a shorter 30-second cooldown, it's still a powerful
ability that's a core part of Havoc's damage profile, dealing heavy Chaos damage
during its channel. It has a variety of talents to enhance it, making it a priority
cast both in single-target and <em>especially</em> AoE situations:

- [[spell:213410]] – grants 5 seconds of [[spell:191427]]
- [[spell:390152]] – summons an allied demon hunter to cast [[spell:212084]]
- [[spell:203550]] – generates a large amount of Fury while channeling
- [[spell:388113]] – deals 30% increased damage if it only hits a single target
- [[spell:343311]] – grants 10% Haste for 10 seconds after completing the channel
- [[spell:1270898]] – increases damage by 100% after casting [[spell:370965]]
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred – [[spell:452412]] grants 18% Mastery and generates Fury.

You should aim to cast this as frequently as possible, both for the damage it
provides and, in particular, the [[spell:213410]] triggers. The only situation
worth holding for is in single-target, when you expect adds to spawn before its
cooldown completes again. Also, make sure to have it on cooldown before casting
[[spell:191427]], as its cooldown is reset by [[spell:388112]].

4.2.1.

##### Cycle of Hatred

[[spell:258887]] increases your access to [[spell:198013]], ramping up
during an encounter. Each time you cast Eye Beam while in combat, it gains
a stack, up to 4. Each stack reduces the cooldown of Eye Beam by 2.5 seconds,
and is a cornerstone of the Havoc rotation for both Hero Trees. This means, after
your opener, it should be down to 25 seconds, reducing to 20 with your next two
casts. After this point it will align naturally with other burst windows such
as [[spell:389688]].

This effect persists through death, but after 1 minute spent out of combat you
revert to 1 stack.

### The Hunt

4.3.

#### The Hunt

[[spell:370965]] at a baseline level is a less high-impact cooldown, serving as
a 1.5-minute cooldown burst tool with a huge 50-yard range. This deals heavy Chaos
damage, applying a DoT to both your target and up to 5 other enemies you pass
through. Your hitbox also remains active briefly after arrival, allowing you to
spread the DoT effect more consistently.

This is <em>significantly</em> improved by the Apex Talent - [[spell:1270898]] - which
both reduces the cooldown to 1 minute, and increases the DoT application count to
9. Alongside that, it provides a follow-up damage buff to [[spell:198013]],
effectively turning it into a 1-minute combo enabler that deals significant
burst damage for each Hero tree.

When playing ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, it also grants a charge of
[[spell:442294]] and shatters an additional Soul. This means it's used to
quickly set up your Hero Talent on pull to apply [[spell:442624]] to a
priority target.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5.
- **30 Aug. 2026:** Updated to set recommendations to Fel-Scarred and default to Raid Cleave.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **24 May 2026:** Updated openers for better sequencing.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **28 Aug. 2025:** Improved signposting for build use cases in the rotation tool.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Updated for Patch 11.1.7 to include notes regarding Rotation Assist.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **04 Mar. 2025:** Added Inertia to base Aldrachi AoE loadout.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Updated to reflect new Fel-Scarred recommendations.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated to include Season 4 builds.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6, core recommendations remain the same.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, small cleanups but no major changes necessary.
- **06 Nov. 2023:** Restructured and fully updated for Patch 10.2 rework.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, added loadout buttons in rotation section and restrucutred page.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5 with small tweaks for clarity and Isolated Prey highlights.
- **01 May 2023:** Updated for Patch 10.1 with Serrated Glaive and notes added, and extra Essence Break combo notes.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5, rotation tool refined.
- **01 Jan. 2023:** Updated Opener.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Havoc Demon Hunter in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Havoc Demon Hunter

Welcome to our Gear and BiS Page for Havoc Demon Hunter for Midnight! 
Check this page to learn everything you need to know about gearing an
Havoc Demon Hunter, including the BiS Gear from all sources, Raiding,
and Mythic+, information on the best Trinkets, Tier Sets, and much more.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system, allowing
you to increase the item level of gear along tracks relating to the level of
content it was obtained from. Harder content drops gear on higher level tracks, thus
reaching higher Item Levels. For more information, read up on our dedicated page
on how the [gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works in
Midnight.

The 12.1.5 update brings with it the release of [[item:280562]],
allowing 334 Weapons, Trinkets, and Necklaces to be upgraded all the way to 340
item level. Additionally, it brings the new boss Kith'ix, which drops powerful
new loot, with some good pieces on offer for Havoc.

### Overall

The list below contains gear from <em>all possible endgame sources</em>, including Raids, Mythic+, Crafting, Delves and The Great Vault. It aims to provide the absolute best possible setup, but bear in mind that each **individual** item may not be the strongest in your particular gear setup. Tier pieces have the drop locations of ideal Catalyst pieces listed if they're stronger than the standard version.

This gearset aims to optimize your Critical Strike and Mastery rating as much as possible.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The absolute best pieces currently available to Catalyze in each slot are:

- **Helm –** [[item:271875@JAAEAAAG2chN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Shoulders –** [[item:268246@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- **Chest –** [[item:281236@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Gloves –** [[item:271538@JAACAAgNyA]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **Legs –** [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details FAQAre There Any High Priority Great Vault or Voidcore Items to Look Out For?
Any of the cantrip items available in Season 2 raids are extremely valuable, even if they aren't at item level 344 from Mythic. The following items are strongly worth considering even from a Heroic Vault, and are even worth using Voidcores on to obtain if you don't expect to progress Mythic quickly:

1. [[item:268209@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270173@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
3. [[item:270168@JAACAAAG2A]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

Two of the three items on the [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>) loot pool are also very strong, adding to the list of pieces worth seeking out. These are strong enough that if you <em>aren't</em> killing any Mythic bosses for higher vault rewards, you always have the option to pick up a Voidcore from your Great Vault if none of these show up.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271537@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240908]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:159327@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Mythic+

The gearset below contains the best items available from Mythic+, using gear only available from dungeons in the Season 2 pool, alongside your ideal Tier Set catalyst locations and Crafted items for Embellishments. Note that this is a list of the <em>best items available</em> from Mythic+ dungeons, **not** a strict list of what you should be using in Mythic+ content.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The best **Dungeon only** pieces to Catalyze in each slot are:

- **Helm –** [[item:159318@JAACAAgNyA]] from [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **Shoulders –** [[item:251223@JAACAAgNyA]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **Chest –** [[item:239048@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **Gloves –** [[item:159312@JAACAAgNyA]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **Legs –** [[item:251130@JAACAAgNyA]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details TipsWhich Dungeons Should I Farm?
All of Havoc's big ticket items are sourced from Raids in Season 2, but there are some worthwhile alternatives to hunt while you wait to get hold of them:

1. [[item:250225@JAACAAAOyA]] – [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
2. [[item:250228@JAACAAAOyA]] – [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
3. [[item:159327@JAACAAgNyA]] – [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
4. [[item:158366@JAACAAgNyA]] – [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271537@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Neck</th><td>[[item:251234@JAACAAAOyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Waist</th><td>[[item:159301@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271536@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Feet</th><td>[[item:159327@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271540@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:250225@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240898]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:250228@JAACAAAOyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:251186@JAACAAAOyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

### Raid

The gearset below is your **raid** Best-in-Slot list, using gear from **only** raid drops, as well as ideal Tier Set pieces (or items to use in the Catalyst) and crafted items to activate Embellishment effects. Note that this is a list of the <em>best items available</em> within the Raid, **not** a strict list of what you should be using inside the raid.

:::details FAQWhich Items Do I Use in the Catalyst?
In Midnight Season 2, the Catalyst now **retains the secondary stats and cantrips** of <em>any</em> item you convert. Therefore, it doesn't matter which slots you use to activate your set bonus, and instead what matters is the items you input.

The best **Raid only** pieces to Catalyze in each slot are:

- **Helm –** [[item:271875@JAAEAAAG2chN]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **Shoulders –** [[item:268246@JAACAAgNyA]] from [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- **Chest –** [[item:281236@JAAEAAgNyEuN]] from [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **Gloves –** [[item:271538@JAACAAgNyA]] from [Entombed Sentinels](<https://www.icy-veins.com/wow/entombed-sentinels-raid-guide>)
- **Legs –** [[item:268225@JAACAAAG2A]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

Similar to Season 1, your <em>number one priority</em> is to acquire the 4-piece bonus through any means to unlock **Catalyst Unbound** for Season 2.

:::

:::details TipsWhat Are My Top Items To Chase?
Havoc has some extremely high value cantrip picks available in Season 2 raids, weighted heavily toward the final two bosses of The Venomous Abyss. Nearly all of these items are worth obtaining due to their increased item level, but some are particularly strong:

1. [[item:268209@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
2. [[item:270173@JAACAAAG2A]] – [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
3. [[item:270168@JAACAAAG2A]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
4. [[item:268265@JAAGAAAG2MqNTpC]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
5. [[item:271875@JAAEAAAG2chN]] – [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
6. [[item:281236@JAAEAAgNyEuN]] – [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271537@JAAEAAAG2chN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244007]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271538@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">Entombed Sentinels</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAGAAAG2MqNTpC]]&#10;&#10;<div>[[item:240908]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268256@JAACAAAG2A]]&#10;&#10;<div>[[item:240914]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271535@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271536@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244641]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268261@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271540@JAAEAAgNyEuN]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a> from <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240908]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270168@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Bracers</th><td>[[item:244576@JAAKAAwt1ENMMYDYwclI]]&#10;&#10;<div>[[item:240890]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-leatherworking" rel="noopener noreferrer">Leatherworking</a></div></td></tr><tr><th>Trinket</th><td>[[item:270173@JAACAAAG2A]]&#10;&#10;<a href="https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:268209@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:273072]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-blacksmithing" rel="noopener noreferrer">Blacksmithing</a></span><span>[[item:273072]]</span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Havoc Demon Hunter

Havoc generally seeks to use one on-use trinket that aligns with [[spell:191427]]
to enhance its burst windows, and then one strong passive trinket to go with it.
Both stat procs and damage effects are useful due to [[spell:388118]], so
there's a good amount of flexibility on offer.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Trinkets to Hunt in Midnight Season 2**
**On-Use –**

[[item:270168@JAACAAAG2A]]

or

[[item:270175@JAACAAAG2A]]

**Passive –**

[[item:270173@JAACAAAG2A]]

or

[[item:281215@JAACAAAOyA]]

:::

You can click below to open a ranking chart for other trinkets, in case you've
picked something else up and are looking to check how it stacks up.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Havoc Season 2 Trinket Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinket</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270173@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   A strong direct damage trinket, but gets stronger when paired&#10;		   with the cantrip weapon, [[item:268209@JAACAAAG2A]].&#10;		   Due to how much damage trinket effects deal through [[spell:388118]],&#10;		   this is so strong that it even extends into AoE situations, and is the&#10;		   most powerful trinket available in most Venomous Abyss&#10;		   encounters when enabled.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270168@JAACAAAG2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Font was already on Havoc's radar due to [[spell:388118]], and due&#10;		   to some additional findings after live release, its performance is much&#10;		   better than expected. The ability to line it up with [[spell:388108]]&#10;		   to deal incredible damage at key moments makes it an excellent on-use&#10;		   tool regardless of the situation.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:270175@JAACAAAG2A]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   This is by far the best stat boosting on-use option available in Season&#10;		   2, despite being on an awkward 1m30s cooldown. This and Font compete for&#10;		   your on-use slot, depending on whether you want to boost your own damage&#10;		   more frequently, or deal front-loaded burst via the trinket itself.&#10;		   Both of these are strong picks.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:281215@JAACAAAOyA]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Click for Details</em></span>&#10;<p>&#10;		   New in Patch 12.1.5, this is extremely powerful for Havoc in AoE situations,&#10;		   and only slightly behind a set-bonus enabled Guillotine Technique.&#10;		   Providing bulk Critical Strike (and even more if there's frequent add&#10;		   spawns) makes it perfectly suited for multi-target situations.</p>&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:250225@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Try to always use this on a target that will live long enough for you&#10;		   to stack up the Crit buff, otherwise most of its value is lost.</p>&#10;</li>&#10;<li>[[item:273796@JAACAAAOyA]]</li>&#10;<li>[[item:270165@JAACAAAOyA]]</li>&#10;<li>[[item:270166@JAACAAAOyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>&#10;&#10;&#10;[[item:270164@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Triggers a variety of different stat boosting effects, and different&#10;		   buffs can overlap. While it does have a negative proc in the pool, it's&#10;		   a solid stat trinket.</p>&#10;</li>&#10;<li>[[item:250228@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:250215@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Can be used on cooldown in single-target, but hold for [[spell:191427]]&#10;		   in AoE.</p>&#10;</li>&#10;<li>[[item:159617@JAACAAAOyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:248583@JAACAAAMyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Go to the Jan'alai altar in Zul'Aman to set this to <strong>Mastery</strong>, or&#10;		   the Akil'zon altar to set it back to <strong>Critical Strike</strong>, depending&#10;		   on your gearset.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250214@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   While this is tuned well, staying within the zone of the proc is&#10;		   extremely restrictive, especially for Havoc which moves around frequently.&#10;		   Pair that with both the large arenas in raid encounters and the hectic&#10;		   movement in dungeons, and your mileage may vary in reality when using it.</p>&#10;</li>&#10;<li>&#10;&#10;&#10;[[item:250259@JAACAAAOyA]] - <span><em>Click for Details</em></span>&#10;<p>&#10;		   Very single-target focused direct damage trinket, but is an alternative&#10;		   while you hunt for Guillotine Technique. This can, however, have some&#10;		   issues hitting some bosses, so isn't always as strong as sims imply.</p>&#10;</li>&#10;<li>[[item:251792@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:265657@JAACAAAMyA]]</li>&#10;<li>[[item:158374@JAACAAAOyA]]</li>&#10;<li>[[item:251785@JAACAAAMyA]]</li>&#10;<li>[[item:274493@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:274497@JAACAAAMyA]]</li>&#10;<li>[[item:251784@JAACAAAMyA]]</li>&#10;<li>&#10;&#10;&#10;[[item:246304@JAAIAAwt1ENMMYDH2A]] <img alt="" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/common/button-icons/tc.png"/> - <span><em>Crafted Trinket Details</em></span>&#10;<span>&#10;		   While these trinket options aren't <em>bad</em>, Embellishments are&#10;		   stronger in Season 2 compared to before. That means the opportunity cost&#10;		   of using them is too high, and they've fallen even further behind than&#10;		   they already were.</span>&#10;</li>&#10;<li>[[item:246305@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246306@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:246307@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:241340@JAAIAAwt1ENMMYDH2A]]</li>&#10;<li>[[item:251783@JAACAAAMyA]]</li>&#10;<li>[[item:274496@JAACAAAMyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores and Ascendant Venomstones

Season 2 brings forward the bonus roll system introduced in Season 1,
providing a way to target big ticket items:

**[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>)s** can be spent after completing endgame
dungeons or defeating raid bosses, granting you an item at random from its
respective loot table. Once an item has been received through Voidcore rolls,
it cannot appear again. In Season 2, **one** Voidcore is used to roll on
dungeon loot <em>or</em> individual raid bosses, granting loot equivalent to
the item level you'd receive from a weekly Great Vault reward.

One can be acquired each week from **Orin Straylight** next to the Catalyst,
following the release of Patch 12.1.5. Additionally, one can be selected from The
Great Vault instead of an item, provided you unlocked three total rewards.

3.1.

#### Recommended Nebulous Voidcore Usage for Havoc Demon Hunter

Which item you should target is strongly influenced by what pieces you already
have access to, items available through the [Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>), and what bosses
you have currently killed. While they are now more freely available following the
addition of weekly rewards in Patch 12.1.5, taking one from The Vault should be
treated as a <em>consolation prize</em> in the event that nothing better appears.

When it comes to <em>where</em> you should use Voidcore rolls when you do pick
one up however, the answer is quite simple:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Season 2 Voidcore Uses**
1. **Ula'tek** (Heroic/Mythic) <em>Havoc Loot Spec</em>
   
   - [[item:270168@JAACAAAG2A]]
   - [[item:270175@JAACAAAG2A]]
   - [[item:268265@JAAGAAAG2MqNTpC]]
   - [[item:271875@JAAEAAAG2chN]]
2. **The Coiled Altar** (Heroic/Mythic) <em>Havoc Loot Spec</em>
   
   - [[item:268209@JAACAAAG2A]]
   - [[item:270173@JAACAAAG2A]]
3. **Kith'ix** (Heroic/Mythic) <em>Havoc Loot Spec</em>
   
   - [[item:281236@JAAEAAgNyEuN]]
   - [[item:281215@JAACAAAOyA]]

:::

:::details FAQWhen Should I Consider Voidcores From The Great Vault?
Now that the season has progressed and Voidcores are more freely available,
recommendations are more concrete. Although you now have access to more rolls, it's
still worth keeping in mind things that may make it less appealing to pick one
up:

- If you have yet to unlock your 4-piece bonus, acquiring that takes priority.
- If a key chase item from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) or [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
    is offered, pick that up.
- Look out for individual key items offered from early Mythic boss kills (such
    as a weapon from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)), as they're offered at 6/6 Myth, saving
    crests and the need to bonus roll them.

In Havoc's case, the items available from the final two bosses are so strong
that, outside of accessing your Tier bonus, it's worth bonus rolling even Heroic
versions to pick up their unique loot. This is <em>especially</em> true for
[Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), which has no bad items in its loot pool.

:::

3.2.

#### Ascendant Venomstones

Following the release of Patch 12.1.5, you can now acquire [[item:280562]],
allowing you to upgrade specific item slots all the way up to item level 340 (or
338 for crafted pieces). Using these follows a similar priority to your crest
usage:

1. **Main-Hand Weapon** first, always.
2. **Trinkets** second & third.
3. **Off-Hand Weapon** fourth.
4. **Necklace** last.

You also want to prioritize Myth track items over Hero track pieces, unless you
don't expect to acquire a Myth track variant of the piece you're upgrading. The
exception to this is one of the most difficult items to obtain from Ula'tek
in The Venomous Abyss - [[item:270168@JAACAAgNyA]]. As this
is an extremely powerful on-use pick for Havoc that doesn't have an easier to
acquire alternative, it's worth the investment even on a lower track.

4.

### Best Crafted Items for Havoc Demon Hunter

Crafted gear provides one of the easiest ways to pick up high value items in a
season, allowing you to target key pieces to fill out your gearset. With the
release of Season 2, each craft requires two [[item:274476]].

Unless secondary stats are already assigned by the item, you should use
a [[item:245789]] for Critical Strike and Mastery on your
crafts.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_green.jpg>) **Havoc Crafting Order**
**[[item:237840@JAAMAAwt1ENMMYzy1clIcYD]]**

➜

**[[item:244576@JAAKAAwt1ENMMYDYwclI]]**

➜

**Optional Crafts**

:::

- Craft a **weapon first**, as it has the biggest impact early. Warglaive is
  best, as it allows you to switch specs. Attach [[item:273060]] for your
  first embellishment.
- Craft **an off-piece second** - we recommend [[item:244576@JAAKAAwt1ENMMYDYwclI]]
  in the Wrist slot. Attach [[item:240167]] as your second embellishment.
- Following this, craft items based on gaps in your current gear.

:::details FAQAre the New Embellishments in Season 2 Good?
**Some of them**. In the lead-up to the release of Season 2 many were reduced
in power, and this hasn't changed in Patch 12.1.5:

- [[item:273060]] serves as a better [[item:245876]],
    making it the best weapon Embellishment.
- [[item:273069]] provides a stacking Haste proc. This is close in value
    to [[item:240167]], but far enough behind that it can't be justified
    considering the latter also buffs allies.
- [[item:273066]] was hit by <em>enormous</em> nerfs, so while it
    would normally fit Havoc perfectly, it's far too weak to be worth using.
- [[item:270899]] also saw huge reductions, so even with the bonus
    damage Havoc deals with cantrip effects through [[spell:388118]], it's
    still not worth it.

:::

Once you have your two main Embellishment crafts, you should have a solid setup.
Your priority when optimizing your gear further should be toward crafting high item-level
pieces to cover holes in your gear. Good candidates are jewellery pieces, as while
there are unique strong options available, they're often <em>extremely</em>
contested.

For more information about crafting gear you can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will
have limited access to upgrade crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can
be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) to higher item levels. Crests are
limited to 100 per week, and upgrades cost 20 crests regardless of the slot. Due
to that, you should prioritize your usage of these on items you don't plan on
replacing any time soon, or specific slots that offer larger stat benefits:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_121_crest_myth.jpg>) **Havoc Demon Hunter Crest Upgrade Priority**
**Weapon (Main-Hand)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

These are not the only items worth upgrading, of course. They simply offer
the highest DPS gain early into the tier when your upgrade currency is limited.
Note that exceptions are possible, such as special cantrip items that have
additional procs attached to them, for example [[item:268265@JAAGAAAG2MqNTpC]].

5.1.

#### Adding Sockets to Gear

While all Rings and Necklaces come with one socket by default, three additional
sockets can be acquired on the Helmet, Belt and Bracer slots as a bonus when they
drop. These can also be added manually using the [[item:275707]]
consumable, which can be purchased using 6 [[item:258556]], the pity
currency from The Great Vault.

When using these, it's always best to put them on pieces you don't expect to
ever replace. This means Mythic items, or any crafted pieces in these slots, since
they can't have them added in any other way. Due to them being a very limited
currency, if you have these, it's best to plan long term before using any.

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Updated for Patch 12.1.5 and addition of Kith'ix.
- **30 Aug. 2026:** Updated to adjust for Font of Venomous Rage power following sim fixes.
- **24 Aug. 2026:** Confirmed gearset following gear changes, switched weapon enchants and expanded FAQ about early craft optimizaiton.
- **19 Aug. 2026:** Added disclaimer regarding uncertain gear recommendations due to Aqirbane Reliquary hotfixes.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7 with Sporefall gear.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **07 Apr. 2026:** Added FAQ note regarding early crafts to optimize Dawncrest uses.
- **16 Mar. 2026:** Updated with full Season 1 recommendations.
- **26 Feb. 2026:** Updated for Midnight release and Pre-season.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Updated for Patch 11.2.5 with Cartel Chip recommendations.
- **28 Aug. 2025:** Re-organized Trinket rankings based on current performance.
- **14 Aug. 2025:** Updated for Season 3 release trinket hotfixes.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **24 Jun. 2025:** Updated to account for D.I.S.C. hotfixes.
- **15 Jun. 2025:** Updated for Patch 11.1.7, added D.I.S.C. belt and adjusted BiS list slightly for double Gallywix weapon.
- **12 May 2025:** Confirmed Dinar recommendations for Turbo Boost release.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5 and added Cartel Chips section.
- **04 Mar. 2025:** Adjusted some trinket rankings to account for recent changes.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **17 Dec. 2024:** Updated to highlight strength of new ring following hotfixes.
- **15 Dec. 2024:** Updated for Patch 11.0.7 for Cyrce's Circlet.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5, shifted recommended trinkets around.
- **09 Sep. 2024:** Updated with Season 1 BiS lists.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Slight shuffle of trinket recommendations, but content remains the same for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, highlighted Ashes of the Embersoul as an alternative.
- **27 Nov. 2023:** Added Augury to ideal trinkets.
- **07 Nov. 2023:** Updated to remove Sporecloak recommendation, switched to Blue Silk/Toxic Thorn options.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Added BiS lists for Patch 10.1.7 and restructured page.
- **10 Jul. 2023:** Updated for Patch 10.1.5 to clean up Trinket and Crafting sections, and add Dawn of the Infinite items.
- **25 May 2023:** Added Timewalking section, cleaned up original Trinket recommendations.
- **09 May 2023:** Updated for Trinket changes.
- **01 May 2023:** Updated for Patch 10.1 and Season 2 release with new gear recommendations.
- **24 Mar. 2023:** Updated for Primordial Gemstones hotfixes.
- **22 Mar. 2023:** Updated to account for Primordial Gemstone buffs.
- **20 Mar. 2023:** Updated for Patch 10.0.7 with Annulet information.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **11 Dec. 2022:** Updated to Gear Page Format.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Havoc Demon Hunter. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Havoc Demon Hunter Stat Priority

Welcome to our Stat Priority page for Havoc Demon Hunter in the
Midnight expansion! Here we'll quickly be going over the stats you should
aim for on gear, alongside any special considerations depending on your build.

Havoc has no significant alterations between Hero Talents or target counts, so
it can safely use similar gearsets for both. Havoc <em>generally</em> has the
following stat priority:

Agility

Critical Strike

Mastery

Haste

Versatility

In Midnight, Agility is much more valuable following the stat squish, meaning
that most of your gearing decisions are driven by item level once again.

[[spell:388118]] keeps Critical Strike as the focus due to the additional
multiplier it provides, alongside working with proc effects. It's also the stat
you ideally want your [[item:241288]] to provide when used. Mastery
is another strong multiplier to the majority of Havoc's strongest abilities, so is
often very similar in value. Generally, you want to stack as much of both stats as
possible.

Haste is much improved in Season 2 due to the resource benefits from the buff
to [[spell:203555]], but is still slightly less desirable than the above two
options.

Versatility falls to the bottom, and while it provides some defensive benefits,
it's noticeably worse than all three other options. Additionally in Season 2, with
the addition of Venomcursed items on top of [[item:241288]], it's
beneficial to keep it as low as possible, as it can't be reduced below zero. This
bypasses the downsides of these procs, making them even stronger.

:::details FAQDoes the talent "Know Your Enemy" affect trinkets?
**Yes**

.

[[spell:388118]]

affects

<em>everything</em>

, so trinket procs,
cantrip effects, and embellishments all benefit from its Critical Strike
damage multiplier. As such, it maintains the high value of the stat regardless of
your gear choices.

:::

2.

### In-Depth Stat Breakdown

As a Havoc Demon Hunter, **Agility** is your primary stat,
meaning you want it present on all gear pieces when possible. Individual
stats provide the following benefits:

- **Agility**: provides you with Attack Power, increasing the damage of
  your Havoc abilities and melee attacks.
- **Critical Strike**: increases the chance for your attacks to critically
  strike, dealing double damage. Additionally:
    
  
  - Havoc has talents with specific <em>additional</em> scaling with
    	Crit, including [[spell:320413]] and [[spell:388107]].
  - [[spell:388118]] also converts Critical Strike Chance into bonus
    	Critical Strike damage at a fixed rate, increasing the base 200% multiplier
    	based on gear.
- **Mastery**: increases all Chaos damage you deal through
  [[spell:185164]]. Additionally:
    
  
  - Also increases your base Movement Speed via [[spell:320654]].
  - Certain talents convert non-Chaos abilities into Chaos damage, including
    	them in the Mastery effect. Important examples are [[spell:206416]],
    	[[spell:427775]], and [[spell:388106]].
- **Haste**: increases your auto-attack speed, increasing Fury generation
  via [[spell:203555]]. Additionally:
    
  
  - Reduces your Global Cooldown to a minimum of 0.75 seconds.
  - Reduces the cooldown of [[spell:188499]], [[spell:258920]],
    	and [[spell:185123]].
- **Versatility**: increases all damage and healing you do (including trinkets
  and proc effects) by a flat amount. Additionally, reduces all damage you take by
  half of that amount.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where it will begin to offer less increase per point
gained, known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Updated for Patch 11.0.5 to separate Fel-Scarred and Aldrachi Reaver weights.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, added note that Crit stays good even during diminishing returns.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, moved up Haste in single-target.
- **01 May 2023:** Updated for Patch 10.1, no significant changes needed.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **31 Dec. 2022:** Raised the priority of Mastery in single target.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Havoc Demon Hunter, based on your [stat priority](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

The recommended gems for all content are:

- Use [[item:240983]] in your first socket.
  
  - Use [[item:240908]] in other sockets.
- With **5+ Sockets**, switch to [[item:240967]].
  
  - Use one of each colour to maximize the bonus - [[item:240898]],
      [[item:240908]], [[item:240890]], and [[item:240914]].

Depending on your stat balance, sockets are often the best place to fix any
gaps in your gear. Since both Mastery and Critical Strike are close for Havoc, we
recommend simming your character to see which of the two is worth weighting your
gems toward.

2.

### Best Enchants and Weapon Augments

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Best Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td><strong>Main Hand</strong></td>&#10;<td>&#10;<ul>&#10;<li>&#10;[[item:273072]]<br/>&#10;   with [[item:243733]]&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Off Hand</strong></td>&#10;<td>&#10;<ul>&#10;<li>&#10;[[item:273072]]<br/>&#10;   with [[item:243733]]&#10;</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Helm</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244007]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Shoulders</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243991]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Chest</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Legs</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:244641]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Boots</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243953]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td><strong>Rings</strong></td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

Helm, Shoulder and Boot enchants are up to personal preference as they have no
direct impact on performance, but we recommend Avoidance picks on all slots for
the extra survivability.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

There are two options for your flask of choice depending on your character's
stats:

- [[item:241326]] — provides Critical Strike. Commonly the
   best pick.
- [[item:241322]] — provides Mastery, if your gearset is
   severely lacking it.

You can also obtain a flask of your choice from [[item:241319]],
provided by Alchemists.

3.2.

#### Potions

[[item:241288]] is your best option, provided you can make it
provide Critical Strike. Always pair these with [[spell:2825]] / [[spell:32182]]
alongside [[spell:191427]]. You can also obtain
[[item:245902]] from a [[item:241285]]
provided by Alchemists.

A note on [[item:241292]] is that, while it's technically
stronger, the void zones it spawns pacify you. It only takes 1-2 GCDs inside this
to wipe out the extra value, so it isn't generally worth it.

[[item:271883]] is the current best healing potion.
Using this has a 5-minute cooldown, but multiple can be consumed in an extended boss
fight should it go on long enough. Additionally, Warlock's
[[item:5512]]s do not share a cooldown with other healing consumables.
Remember to use it as well if you are holding one!

3.3.

#### Food Buff

Agility remains the strongest stat in Season 2, so you should be
eating a [[item:255845]] or other primary stat Feast if possible. If
this isn't provided by your group, stick to [[item:242275]] personal food instead.

3.4.

#### Augment Rune

In addition, if you can afford it, you should use [[item:259085]]s
to increase your primary stat. Remember: Augment Runes are expensive and disappear
on death, so use them wisely!

3.5.

#### Other Consumables

Alongside standard buff consumables, there are a handful of other items worth
keeping hold of - especially in Mythic+:

- [[item:188152]] — allows you to auto-interact with nearby Warlock [[spell:111771]]s.
- [[item:244639]] — grants a weaker 15% Haste [[spell:2825]]
  effect on your party when used. These are still affected by [[spell:57724]], so should
  only be used if you have no party member that provides it naturally.
- [[item:269586]] — can be used as a combat resurrection on your target,
  and <em>does not</em> require Engineering.
- [[item:241303]] — Midnight's invisibility potion, which can
  be used to skip certain trash pulls in Mythic+. Bear in mind this <em>does</em>
  share a cooldown with your offensive potion [[item:241288]].

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **30 Aug. 2026:** Switched to double Rite of the Hash'ey - very close but much easier to fit into gearsets.
- **24 Aug. 2026:** Switched to double Jan'alai's Precision due to Neck changes encouraging more Crit.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **07 Apr. 2026:** Adjusted ring enchant recommendations to Eyes of the Eagle.
- **16 Mar. 2026:** Updated for Season 1 - added Teas and additional Consumables for Mythic+.
- **26 Feb. 2026:** Updated for Midnight release.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **28 May 2025:** Amended Corruption recommendation due to ongoing Echoing Void bug.
- **12 May 2025:** Updated following Corruption tuning.
- **21 Apr. 2025:** Updated for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5, switched to Mastery recommendations.
- **09 Sep. 2024:** Added note for Speed Blasphemite.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Updated for Patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Updated for Patch 10.1.5 to add Wafting Devotion note and recommend against Annulet.
- **01 May 2023:** Reviewed for Patch 10.1.
- **24 Mar. 2023:** Updated for Primordial Stones hotfixes.
- **22 Mar. 2023:** Updated to account for Primordial Stone buffs.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed and updated for Patch 10.0.5.
- **31 Dec. 2022:** Weapon Enchantment recommendation changed to Sophic Devotion.
- **11 Dec. 2022:** Updated for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Havoc Demon Hunter in World of Warcraft Patch 12.1.5.

1.

### Havoc Demon Hunter in Mythic+ in Midnight Season 2

On this page, we will be covering how to get the most out of your Havoc
Demon Hunter in Mythic+ dungeons, including the best talent builds, any rotational
changes that you need to know, and tips and tricks to excel in keystones.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our dedicated Mythic+ page below. You can also find
out more about the Mythic+ Meta on our Tier List page.

Havoc Demon Hunter features excellent throughput in Mythic+,
with each of its Hero Trees specializing in two of the most desirable
damage profiles. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred provides high burst AoE every 20 seconds,
becoming even stronger every two minutes during your [[spell:191427]]
casts. On the other hand, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver provides powerful funnel
through [[spell:442806]], allowing it to focus down priority targets quickly.
Pair that with both a strong defensive toolkit and some universally useful utility,
and it creates a well-rounded Mythic+ specialization.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred    Recommended Choice

2.1.

#### Havoc Demon Hunter Mythic+ Build - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred continues to be a solid all-rounder in Midnight Season 2,
bringing with it strong, reliable burst AoE. The 20-second cadence of [[spell:452402]]
procs via [[spell:213410]] maps on well to most dungeon routes, while having the
added benefit of [[spell:191427]] to overload power into dangerous pulls.
Since most of its tools flex between single-target and AoE as well, it still packs
a good punch when forced into boss encounters.

2.1.1.

##### Talent Swap Options

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred has a couple of swap options to keep in mind:

- **Movement Talents -** While both [[spell:389688]] and [[spell:206476]]
  add complexity by introducing movement talents into the rotation, they provide
  <em>extremely</em> high value and smooth out Fury. If you're really struggling
  to make use of them, you can switch both out for [[spell:389978]].
- [[spell:342817]] adds some pressure onto Fury management, but the AoE
  is generally worth it. It can be switched out for [[spell:389978]] or 
  [[spell:389693]], but comes at a hefty loss.
- [[spell:452406]] can be switched to [[spell:452407]] if
  you are looking for more general sustain rather than a little bit of mitigation.
- [[spell:1266496]] and [[spell:1266316]] are both case-by-case tools depending
  on the dungeon. Select the appropriate option depending on if Curses or Diseases are
  present.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Mythic+ / AoE - Fel-Scarred
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYmZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyAbzmZMMbMNmZGzYDAAAYAAAAMzgBAAAgB"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJOhACEGOoqqsMkiMpxxRSWSsNC-AAAA-BeERhphowYJQ4A-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver    High Key Alternative

2.2.

#### Havoc Demon Hunter High Key Build - ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver

In Season 2, the gap between ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred
is much smaller, which makes their damage profile differences stand out more. The
funnel provided by [[spell:442806]] combined with [[spell:1272153]] is
very high, making it a specialist in dealing with priority targets. Its overall
AoE is lower, and it comes with higher execution requirements to manage
[[spell:442624]], making it a less universal playstyle in general keystones.
That said, in organized high-end play where <em>what</em> you deal damage to
often matters more than <em>how much</em>, this may end up being the pick for some
compositions.

2.2.1.

##### Talent Swap Options

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver has a couple of swap options to keep in mind:

- [[spell:428492]] and [[spell:388116]] are swaps that can
  be made for high value AoE picks like [[spell:258881]] and [[spell:342817]],
  but these cut into the value of your funnel. Since that's the main benefit of
  ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, it's not generally recommended.
- [[spell:442714]] can be switched out for [[spell:442736]]
  for some free absorb shields, which puts less pressure on timing [[spell:232893]]
  for defense.
- [[spell:1266496]] and [[spell:1266316]] are both case-by-case tools depending
  on the dungeon. Select the appropriate option depending on if Curses or Diseases are
  present.

**Use the Copy button below to generate an Import Code to use in-game!**

:::talents Mythic+ / AoE - Aldrachi Reaver
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CEkAAAAAAAAAAAAAAAAAAAAAAYgZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxEGzMmxCAAAAAAAYmBYAAAAYA"
}
```
:::

:::details 来源计算器编码
```
#BJ-NQUhiEKSVWAJPLQQY6AecopNamKYMNhxFsF-PXgiIJKOWhAOaako+MYiMpxxRSWsMzG-AAAA-GIOi0AEUowgCzC-
```

:::

3.

### Dungeon Talent Swap Cheat Sheet

For a quick reference of extra uses for your Havoc utility
	talents, use the tool below to select a dungeon. Underneath, relevant options
	will be highlighted alongside what they're used to counter.

<table>&#10;<tr>&#10;<th colspan="2">Dungeons</th>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a></td>&#10;</tr>&#10;<tr>&#10;<td> <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">Temple of Sethraliss</a></td>&#10;<td> <a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></td>&#10;</tr>&#10;</table>

Based on the selections above, the following class talents have unique use cases:

![Consume Magic not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/consume.jpg>)**适用条件：Den of Nalorakk（未启用）；Murder Row（未启用）；King's Rest（未启用）；Ruby Life Pools（未启用）。**

![Consume Magic Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/consume.jpg>)**适用条件：Den of Nalorakk（启用）；Murder Row（启用）；King's Rest（启用）；Ruby Life Pools（启用）。**

‌

![Burn It Out not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/burnitout.jpg>)**适用条件：Altar of Fangs（未启用）；King's Rest（未启用）。**

![Burn It Out Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/burnitout.jpg>)**适用条件：Altar of Fangs（启用）；King's Rest（启用）。**

‌

![Soul Cleanse Not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/cleanse.jpg>)**适用条件：Den of Nalorakk（未启用）；Murder Row（未启用）。**

![Soul Cleanse Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/cleanse.jpg>)**适用条件：Den of Nalorakk（启用）；Murder Row（启用）。**

‌

![Vengeful Retreat Not Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/retreat.jpg>)**适用条件：Altar of Fangs（未启用）；Blinding Vale（未启用）；Den of Nalorakk（未启用）；King's Rest（未启用）；Ruby Life Pools（未启用）；Voidscar Arena（未启用）。**

![Vengeful Retreat Talented](<https://static.icy-veins.com/images/wow/classes/dh/icons/retreat.jpg>)**适用条件：Altar of Fangs（启用）；Blinding Vale（启用）；Den of Nalorakk（启用）；King's Rest（启用）；Ruby Life Pools（启用）；Voidscar Arena（启用）。**

‌

- **适用条件：Altar of Fangs（启用）。** [[spell:198793]] uses:
  	  
  
  - Clears [[spell:1296069]] in the **Rav'i** boss encounter.
  - Clears [[spell:1310974]] from **The Writhing Coil**.
  - Clears [[spell:1294569]] from **Twinfang Harrowers**.
- **适用条件：Altar of Fangs（启用）。** [[spell:1266316]] uses:
  	  
  
  - Dispels [[spell:1296069]] applied by **Rav'i**.
- **适用条件：Blinding Vale（启用）。** [[spell:198793]] uses:
  	  
  
  - Clears [[spell:1238084]] applied by **Lashers** if you're hit in melee.
- **适用条件：Den of Nalorakk（启用）。** [[spell:198793]] uses:
  	  
  
  - Clears [[spell:1309919]] applied by **Frigid Maulers**.
- **适用条件：Den of Nalorakk（启用）。** [[spell:278326]] uses:
  	  
  
  - Dispels [[spell:1297696]] from **Earthwhisper Tenders**.
- **适用条件：Den of Nalorakk（启用）。** [[spell:1266496]] uses:
  	  
  
  - Dispels [[spell:1238760]] applied by effigies summoned by **Spirits of Hunter**.
- **适用条件：King's Rest（启用）。** [[spell:198793]] uses:
  	  
  
  - Clears [[spell:1294815]] applied by **Risen Hexers**.
  - Clears [[spell:106823]] applied by **Queen Patlaa**.
  - Clears [[spell:271563]] applied by **Embalming Fluid**.
  - Clears [[spell:12548]] applied by **Spectral Shaman**.
- **适用条件：King's Rest（启用）。** [[spell:278326]] uses:
  	  
  
  - Dispels [[spell:269935]] active on **Minions of Zul**.
  - Dispels [[spell:1296671]] applied by **Guard Captain Atu**.
  - Dispels [[spell:270901]] from **Seneschal M'bara**.
- **适用条件：King's Rest（启用）。** [[spell:1266316]] uses:
  	  
  
  - Dispels [[spell:267763]] applied by **Half-Finished Mummies**.
  - <em>Note:</em> While [[spell:1266496]] can dispel [[spell:269972]]
    		from **Risen Hexers** on this node, these casts should be handled as a
    		priority with interrupts rather than using dispels to cover it. You're
    		more likely to survive and be able to dispel diseases here instead, making
    		[[spell:1266316]] the more valuable pick.
- **适用条件：Murder Row（启用）。** [[spell:278326]] uses:
  	  
  
  - Dispels [[spell:1229433]] applied by **Felonious Mages**.
- **适用条件：Murder Row（启用）。** [[spell:1266496]] uses:
  	  
  
  - Dispels [[spell:1217973]] applied by **Corrupted Warlocks**.
- **适用条件：Ruby Life Pools（启用）。** [[spell:198793]] uses:
  	  
  
  - Clears [[spell:373803]] from **Infused Whelps** if you're hit in melee.
- **适用条件：Ruby Life Pools（启用）。** [[spell:278326]] uses:
  	  
  
  - Dispels [[spell:373973]] applied by **Ashseer Flamelashers** at low health.
  - Dispels [[spell:391031]] active on **Primal Thunderclouds**.
- **适用条件：Temple of Sethraliss（启用）。** Currently [Temple of Sethraliss](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) has no dispel utility uses from talent swaps.
- **适用条件：Voidscar Arena（启用）。** [[spell:198793]] uses:
  	  
  
  - Clears [[spell:1263982]] stacks in the **Charonus** boss encounter.
  - Clears [[spell:1249621]] applied by **Angry Krolusks**.

4.

### Utility Kit and Abilities

This section covers key talents and abilities Havoc has access to that
can be leveraged in Mythic+ situations.

### Crowd Control

4.1.

#### Interrupts and Crowd Control

Havoc has a variety of tools to stop enemy casts. Due to their different uses,
we've broken them down into tools for single-target situations, and those
better suited to AoE.

4.1.1.

##### Single Target Crowd Control

[[spell:183752]] is Havoc's interrupt, with a 15-second cooldown. It should be
used aggressively to stop dangerous enemy casts (see our Disrupt macro on
the [Havoc Demon Hunter macro page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-macros-addons>)).

[[spell:217832]] is a 45-second cooldown hard crowd control, but breaks on
damage taken. This can be used either as a stop mid-combat, or to lock
a target down that you would rather skip. Imprison is unique in that
enemies affected by this will not aggro as you or your party run past.

4.1.2.

##### AoE Crowd Control

[[spell:179057]] is Havoc's AoE stun tool, stunning nearby targets for 3
seconds. This has a 45-second cooldown and a 25-Fury cost. This
is great for disrupting large groups of enemies and, due to its instant activation,
can be a strong AoE stop when multiple targets are casting at once. With [[spell:1266296]]
taken, this also extends the stun on your current target to 5 seconds, making it
an even better lockdown tool.

[[spell:207684]] is an AoE disorient on a 2-minute cooldown (reduced to
1.5 minutes with [[spell:320418]]), that disorients targets within
for 15 seconds after a 2-second delay. The effect breaks on damage, and the delay
means it needs to be timed well to use as an AoE stop. This can also be used to
skip, as affected enemies won't aggro party members (but will aggro you), so it
requires a way to drop combat, such as [[spell:58984]], after you make
it past.

[[spell:191427]] may be your major cooldown, but when cast it also
stuns enemies within the impact zone for 3 seconds. This should not really be
something you use it for, but if it's ready you can use it as an additional way to
disrupt a group at the start of a pull.

### Defense & Self-Healing

4.2.

#### Defense & Self-Healing

Havoc is one of the most robust melee specializations, having a mixture of
both active and passive damage reduction tools. It also comes with a number of
passive self-healing effects, giving it a great foundation for survival even at
cutting-edge key levels.

4.2.1.

##### Damage Reduction Tools

[[spell:198589]] is Havoc's primary active defense tool, reducing damage taken
by 25% for 10 seconds, with a 1-minute cooldown. With [[spell:1266307]]
taken, it gains an additional charge, and with [[spell:205411]] the
damage reduction is increased to 35%. Due to having two charges <em>and</em> a low
cooldown, it should be used proactively against lethal damage or dangerous
situations.

[[spell:427776]] grants a shield during [[spell:210152]] / [[spell:188499]]
casts, absorbing up to 15% of your maximum health. This is active for a very brief
period of time, but allows you to outplay some damage events by timing your
rotational casts. This is a high skill ceiling tool, but great for dealing with
one-shot mechanics.

[[spell:205411]] also passively reduces damage taken while below 35%
health. This also applies to damage events that would place you <em>below</em> that
threshold, giving you even more room to passively survive through lethal attacks.

[[spell:1266329]] reduces all Magic damage you take by 15% for 12 seconds,
following a successful interrupt with [[spell:183752]]. This is an excellent
defensive tool due to how frequently you should be interrupting in Mythic+.

[[spell:196718]] grants a 15% chance (increased to 30% in dungeons) to avoid any
damage event for you or party members stood within. This lasts 8 seconds, with a
5-minute cooldown. The duration can be increased to 11 seconds with
[[spell:389781]], or the cooldown can be reduced to 3 minutes with
[[spell:389783]]. A helpful bonus for group survival, <em>especially</em>
against repeat damage events (such as DoTs), to help your Healer keep up. Due to
its long cooldown, you should plan ahead of time when to deploy this.

[[spell:442714]], exclusive to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver, grants 10%
damage reduction for 5 seconds following [[spell:232893]] casts. This is a nice
extra benefit that can also be timed to survive dangerous mechanics. In Midnight,
Felblade is available less frequently, so it's not quite as strong as it
was previously. Remember though that you can also always force a proc if using
[[spell:444931]].

4.2.2.

##### Self-Healing

[[spell:204909]] provides <em>a lot</em> of self-healing, granting 10%
Leech at all times, increased to 20% during [[spell:191427]]. This already
provides a lot of sustain, but the extra stability it gives during cooldowns means
Havoc can often be much more aggressive in big pulls due to its self-sufficient
nature. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/fel-scarred.webp>) Fel-Scarred can also increase this by 2% and 4%, respectively,
when playing [[spell:452407]].

[[spell:1227619]] combined with [[spell:206478]] causes a steady
stream of Soul Fragments to spawn during combat, healing you for a small amount.
Greater Soul Fragments spawned when enemies are killed heal for significantly more,
giving Havoc great self-sufficiency during keystones. ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/aldrachi-reaver.webp>) Aldrachi Reaver also
spawns significantly more souls, giving it extra passive sustain, which can be
augmented by [[spell:442736]] to provide Absorb shields as well.

[[spell:427794]], added in Patch 12.1, has some minor defensive benefits as
well, increasing Leech by 5% when below 50% health. Ideally you don't spend too
long below this threshold as it reduces your damage, but it helps get you out of
bad situations.

### Other Utility

4.3.

#### Other Utility

[[spell:328725]] reduces enemy healing received by 50% for 6 seconds
after being hit by your [[spell:188499]] / [[spell:210152]]. While niche,
this can provide a lot of effective damage by cutting the amount of healing
enemies receive, alongside being easy to apply in AoE.

[[spell:255260]] is Havoc's strongest reason to be brought to raid,
and in Mythic+, this is no different. <em>Depending on the group composition</em>,
this can be extremely beneficial, as a large number of classes in the game
currently deal at least <em>some</em> magic damage for this to amplify. This
usually ends up providing a significant amount of extra damage, on top of what
you yourself do.

[[spell:278326]] is Havoc's offensive dispel with a 10-second cooldown.
This has the advantage of a 30-yard range and can be used to remove buffs from
enemy targets. Its cooldown does mean you have to be picky with what to dispel
though, especially if multiple enemies are buffed at once.

[[spell:198793]], while niche, breaks snares when cast. This can
be useful in certain dungeons.

[[spell:1266496]] / [[spell:1266316]] allow you to use [[spell:258920]]
as a self-dispel. The former removes Curses, while the latter removes Diseases, so
you should make your choice on this node based on the dungeon you're doing.

5.

### Dealing with Affixes

This section contains quick tips to deal with each of the weekly Xalatath-themed
affixes in Mythic+ Season 2.

### Affix: Ascendant

5.1.

#### Ascendant Affix Management for Havoc Demon Hunter

**Xalatath's Bargain: Ascendant** will periodically spawn a number of orbs
in waves that need to be crowd-controlled in some way, before they complete a cast.
Each orb successfully stopped provides the group bonus Haste, so it is a high
priority to deal with.

Havoc can and should make use of [[spell:179057]] and [[spell:207684]]
to stop a wave, and also has [[spell:183752]] to catch any strays if your group is
struggling to clear them all.

### Affix: Voidbound

5.2.

#### Voidbound Affix Management for Havoc Demon Hunter

**Xalatath's Bargain: Voidbound** will periodically summon a large Void
Emissary that will begin to cast [[spell:462508]]. This enemy **must** be
killed before the cast completes to stop it, otherwise it provides significant
damage reduction to nearby enemies. If successfully stopped, the group is granted
a large amount of Versatility and cooldown reduction.

This needs to be killed off quickly, so ideally, have short, bursty cooldowns
like [[spell:198013]] or [[spell:370965]] ready to go as it spawns. This
is not always possible, however, due to them being key to your AoE rotation, so just
be aware of when they appear and swap accordingly.

### Affix: Pulsar

5.3.

#### Pulsar Affix Management for Havoc Demon Hunter

**Xalatath's Bargain: Pulsar** spawns an orb that orbits each player, which
needs to be soaked by a separate player before they expire. Each orb will grant
the party 4% Mastery and 2% Leech, stacking, with a 30-second duration. Unsoaked
orbs will increase nearby enemies' damage done, and reduce their damage taken.

Havoc has no specific utility to deal with this. Instead, you need to be
aware of your positioning, both to make sure other players can soak up the orb
circling you, and so you can catch orbs from nearby players.

### Affix: Devour

5.4.

#### Devour Affix Management for Havoc Demon Hunter

**Xalatath's Bargain: Devour** applies a debuff to each party member, which
must be either dispelled or healed off (though bear in mind this <em>does not</em>
absorb incoming heals). Each debuff dispelled provides the group with maximum
health and Critical Strike, stacking, for 30 seconds. Any debuffs <em>not</em>
cleared will heal nearby enemies a large amount.

Both [[spell:1266316]] and [[spell:1266496]] can be used here to immediately
remove the debuff. Additionally, [[spell:198793]] will remove the debuff,
as in Midnight it now applies a small slow as well. If you don't have this available,
or any charges of [[spell:258920]], use Healthstones / Healing
Potions if the healer is falling behind.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Updated for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for release of Midnight Season 1.
- **26 Feb. 2026:** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for new Class Tree talent gates.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **28 Aug. 2025:** Added Mythic+ Utility Talent cheat sheet for use cases in each dungeon.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **28 Apr. 2025:** Added individual dungeon tips.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5 - moved Aldrachi AoE build back to low movement options due to ease of execution.
- **04 Mar. 2025:** Adjusted Aldrachi Reaver build to add Inertia for now.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7, added recommended tags.
- **21 Oct. 2024:** Updated for Patch 11.0.5.
- **09 Sep. 2024:** Updated for War Within Season 1 release.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6, shifted recommended build to Glaive Tempest but otherwise no changes.
- **15 Jan. 2024:** Reviewed and touched up for mid-season 3 information.
- **09 Nov. 2023:** Restructured and updated for Patch 10.2.
- **06 Nov. 2023:** Updated link to Mythic+ hub.
- **04 Sep. 2023:** Updated for Patch 10.1.7, added Glaive Tempest/Ragefire build and switched it to the recommended choice.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, no changes necessary.
- **01 May 2023:** Updated for Patch 10.1 with details about new affixes, build remains the same.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **27 Oct. 2022:** Added an additional, single-target-focused build.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Havoc Demon Hunter in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Welcome to our Addons and Macros page. Here we will be covering helpful addons
you can use to elevate your gameplay through a more informative UI, alongside
provide some commonly used Havoc Demon Hunter macros.

2.

### Havoc Demon Hunter Macros

Macros are accessible through the /macro command in-game, and allow you to
create small scripts that will be executed when you press a keybind. These are
very useful for combining multiple actions into one, so a common example is
combining off-GCD trinkets with cooldowns within one press.

2.1.

#### Disrupt Focus Interrupt Macro

#### Focus Interrupt

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Disrupt
```

This macro will stop your current cast and cast [[spell:183752]] on your
focus if available; otherwise, it will be cast on your target
(more information about Disrupt on our [spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)).

2.2.

#### Consume Magic

#### Focus Dispel

```wow-macro
#showtooltip
/stopcasting
/cast [@focus,exists][@target] Consume Magic
```

This macro will stop your current cast and cast [[spell:278326]] on
your focus, if available, otherwise it will be cast on your target (more
information about Consume Magic on our [spells page](<https://www.icy-veins.com/wow/havoc-demon-hunter-pve-dps-spell-summary>)).

2.3.

#### Sigil of Misery Targeting Macros

[[spell:207684]] can be modified to be cast instantly, without the need
to use the targeting circle and removing one input. This can be done in two
different ways, with the following placing it at your mouse cursor:

#### At Cursor Sigil

```wow-macro
#showtooltip
/stopcasting
/cast [@cursor] Sigil of Misery
```

Alternatively, you can cast it at your feet if you are well
positioned already:

#### At Player Sigil

```wow-macro
#showtooltip
/stopcasting
/cast [@player] Sigil of Misery
```

2.4.

#### Metamorphosis Macros

Similarly, you can Macro [[spell:191427]] to be cast in the same
way to instantly enter into it when you need to, with the following landing
at your cursor:

#### At Cursor Meta

```wow-macro
#showtooltip
/stopcasting
/cast [@cursor] Metamorphosis
```

Or in place where you are currently standing:

#### At Player Meta

```wow-macro
#showtooltip
/stopcasting
/cast [@player] Metamorphosis
```

3.

### Best Addons

3.1.

#### General Addons for Demon Hunter

Most of your UI needs can be met with some effort using the new Blizzard UI
options in Midnight, but if you're looking for some extra customization, below are
some popular choices.

3.1.1.

##### Boss Mods: Deadly Boss Mods or Bigwigs

Boss mods are addons that warn you about boss abilities and give you
live advice on how to handle some mechanics. We strongly recommend you to
get one such addon. At Icy Veins, we mostly use
[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>),
the most popular boss mod. A good alternative is
[Big Wigs](<https://www.curseforge.com/wow/addons/big-wigs>).

3.2.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) is a complete replacement of the default
User Interface. It comes with almost everything you need to perform properly:
action bars, unit frames, cooldown timers, proc displays, etc.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Reviewed for Season 1 release.
- **26 Feb. 2026:** Updated for Midnight release with copy elements.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Reviewed for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **21 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5, no changes necessary.
- **06 Nov. 2023:** Checked for Patch 10.2, no changes necessary.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7, no changes necessary.
- **10 Jul. 2023:** Reviewed for Patch 10.1.5, no changes necessary.
- **29 Apr. 2023:** Reviewed for Patch 10.1, no changes necessary.
- **20 Mar. 2023:** Reviewed and updated for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight Pre-Patch.

Show more

Show less

:::
