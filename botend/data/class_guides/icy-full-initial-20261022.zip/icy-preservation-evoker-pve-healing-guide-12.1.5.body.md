## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本 恩护 唤魔师指南。在这里，你将学习如何在团队副本和大秘境中担任 恩护 唤魔师进行治疗。我们涵盖了从基础知识到极限优化手法的一切内容，以最大化你的治疗输出。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

恩护大秘境资源

[全新！顶级 恩护天赋构建](<https://raider.io/specs/preservation-evoker/talents>)

[顶级 恩护大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/evoker/preservation>)

[恩护大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=evoker--preservation>)

[热门 恩护队伍配置](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=evoker--preservation>)

1.

### 恩护 唤魔师概述

[恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) 擅长在站位集中的环境中作战，能够充分发挥其极其强大的范围治疗能力。凭借 [[spell:355936]] 和 [[spell:355913]] 等技能，当小队和团队成员处于其较小的治疗范围内时，他们能发挥出最大效能。

[恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) 还通过多种功能带来实用性，包括 [[spell:374227]] 提供的小队伤害减免、[[spell:374968]] 和 [[spell:364342]] 提供的团队增益，甚至还有通过 [[spell:390386]] 实现的、他们版本的 [[spell:80353]]。

强大的冷却技能，更强的治疗

尽管缺乏强大的团队增益或某些其他治疗者提供的功能性，恩护 唤魔师 通过其治疗输出弥补了这一点。[[spell:363534]] 是目前游戏中最强的治疗冷却技能，其治疗量在理论上没有上限。你承受的伤害越多，它产生的治疗就越多，这使其威力惊人。

除此之外，唤魔师 的数值一直被调整为接近治疗量（HPS）榜首，以弥补其有限的治疗范围。在12.1版本中情况依然如此，唤魔师 预计将在治疗量方面跻身最强治疗者之列。

卓越

恩护 唤魔师 自在《巨龙时代》加入以来，历史起伏不定。有时他们强大到你会带两个，并且他们的治疗量比游戏中其他任何治疗者都高出30%。其他时候，他们在世界顶级公会中毫无立足之地。在12.1版本中，凭借其卓越的治疗输出和强大的团队冷却技能（如 [[spell:363534]]，它仍然是游戏中最强的治疗冷却技能），你可以预期唤魔师将处于强势地位。无论在哪个游戏水平，你几乎肯定会看到治疗队伍中有 唤魔师。

前所未有的强势

恩护 唤魔师 在大秘境环境中一直难以具备竞争力，但随着12.1版本的改动，他们似乎终于能挑战顶级专精了。缺乏强大的团队增益将阻碍他们成为“版本答案”治疗者，但 恩护 提供了所有治疗者中最高的伤害之一，同时拥有非常强大的治疗输出和扎实的功能性。虽然他们可能终于处于一个不错的位置，但公众认知往往需要一段时间才能跟上，与更典型的版本答案治疗者相比，玩家可能仍然难以进入集合石队伍。

充其量只是小众选择

恩护 唤魔师 最大的弱点是缺乏功能性。虽然 [[spell:370665]] 可能有价值，[[spell:374968]] 也有其小众用途，但这些不足以支撑一个高功能性评分，尤其是与其他职业相比。龙希尔种族提供的打断在大秘境环境中可能不错，[[spell:406732]] 偶尔也有用，但这些对整体局面影响不大。最强的功能性来自 [[spell:374251]]，它允许你移除流血效果。除了拥有冷却技能 [[spell:1022]] 的 神圣 圣骑士 之外，没有其他专精能复制这一点，缺点是流血驱散并不总是有用的，这意味着这个非常独特且强大的功能性有时可能完全派不上用场。

名列前茅

恩护 唤魔师 拥有极强的生存能力，以及更好的外部冷却技能。拥有两层充能的 [[spell:363916]] 极其强大，允许你在非常困难的时刻连续施放。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 玩家甚至可以借助 [[spell:444322]] 天赋将此技能用于他人，为你提供一个额外的外部防御技能。

这，加上 [[spell:357170]]，意味着 唤魔师 可以为游戏中玩家提供一些最好的防御技能。虽然 [[spell:374227]] 仅对标记为范围性的伤害生效，但在合适的情况下，它仍能提供巨大的价值。

移动能力之王

恩护 唤魔师 拥有游戏中所有治疗者中最好的机动性。能够不断 [[spell:358267]] 对于重新定位和快速到达某处极其有价值。此技能还允许你在移动时施放一些法术（主要是 [[spell:361469]] 和 [[spell:373861]]），结合 [[spell:364343]] 是瞬发施放这一事实，能带来很好的收益。

因此，无论需要怎样的移动，你都能始终保持你的治疗循环，不像其他治疗者在被迫移动时可能会遭受巨大损失。

1.

### 恩护 唤魔师 在 至暗之夜 中

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

随着12.1.5版本的发布，你将可以体验两项新的终局内容：一个新的团队副本和一个新的巨型地下堡。有关这些新终局内容的更多信息，你可以访问下方链接的专属页面。

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

有关12.1.5版本改动的完整分析，你可以访问我们的专属中心页面，它将为你提供所需的所有信息，无论你是一直在玩还是回归玩家。

2.3.

#### 职业改动

在12.1.5版本中，恩护 唤魔师 仅针对
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 获得了一项微小改动。具体来说，[[spell:444088]] 的治疗量提高了20%，以抵消最近一个导致它与 [[spell:376239]] 等治疗增益效果双重叠加的Bug修复。这不会影响任何天赋选择或循环要素。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_temporalanomaly.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1版本职业平衡调整 隐藏12.1版本职业平衡调整
[乌拉泰克的诅咒内容更新说明](<https://worldofwarcraft.blizzard.com/en-us/news/24293281>)

在12.1版本中，恩护 的改动集中在调整 [[spell:355936]] 的强度上，同时增强了其他技能，以帮助提供更多的应急治疗并加强其大秘境治疗输出。最值得注意的改动如下：

- [[spell:355936]] 的持续治疗显著增加，但直接治疗减少
- [[spell:361469]] 的直接治疗增加
- [[spell:360995]] 的治疗量增加

在第1赛季，该专精在应急治疗和应对困难减益方面表现不佳。此外，[[spell:355936]] 被大幅增强，以帮助弥补 [[spell:373270]] 的损失。作为回报，这导致它失去了一些在技能组中的独特性。这些改动旨在让 [[spell:355936]] 回归其作为强大持续治疗（HoT）效果的原始定位，同时增强 [[spell:361469]] 和 [[spell:360995]] 的威力，以帮助覆盖梦境吐息之前所负责的领域。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜 对 恩护 唤魔师 的改动

在进入 至暗之夜 时，暴风雪 希望简化 恩护 唤魔师 的游戏体验。他们的目标之一是让新玩家更容易上手，同时移除一些在高水平操作中所需的非常严苛的时机要求。如果你是回归游戏的玩家，且自上个资料片以来未曾游玩，我们将为你梳理一些整体上的关键改动：

- [[spell:373270]] 不再能通过 [[spell:364343]] 复制给其他玩家。
- [[spell:367226]]、[[spell:370960]] 和 [[spell:371832]] 已被移除。
- [[spell:373834]] 已更改，现在仅增加 [[spell:355936]] 和 [[spell:361469]] 的治疗量。
- [[spell:443328]] 已被移除，[[spell:444088]] 已被重做。不再是触发效果时治疗整个团队，现在你只会治疗你所选中的玩家。
- [[spell:206005]] 是一个新的天赋，增加 [[spell:360995]] 的治疗量，并使你在使用 青翠之拥 时不会飞向你的目标。
- [[spell:1241704]] 是一个新的天赋，为你提供一层额外的 [[spell:360995]] 充能。
- [[spell:1236776]] 作为重做的新天赋从《地心之战》回归。在施放 [[spell:370537]]/[[spell:359816]] 后的15/20秒内，你的持续治疗效果提高，并且你触发 [[spell:369297]] 的几率提高100%。
- 在游玩时，[[spell:355936]] 将获得两层充能 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者.
- [[spell:376150]] 现在也会缩短梦境吐息的冷却时间。
- 一些其他天赋获得了微小改动或在天赋树中改变了位置。

除了这些改动之外，你还将获得新的巅峰天赋以及3个新的英雄天赋选择。

2.5.

#### 顶点天赋

在 至暗之夜 中，你将获得 [[spell:1256577]]，即新的顶点天赋。此技能有三个独立的等级，每个等级都会增强其威力。下面我们将分别介绍每个等级的效果。

- 等级1 — 消耗精华的技能有几率触发 [[spell:1256577]]，使你的下一个 [[spell:366155]] 发生变形。除了提供标准的 逆转 效果外，它还会改变图标，并产生类似活化烈焰（Spiritbloom）的效果，治疗会射出并弹跳至玩家。
- 等级2 — [[spell:366155]] 现在每点使受到的伤害降低1%，并改为每点为其恢复1%的生命值。这既是伤害减免也是治疗，其中伤害减免部分在伤害统计中显示为吸收效果。
- 等级3 — [[spell:355936]] 的瞬时治疗量大幅增加，并且每次施放都会触发 [[spell:1256577]]，让你在每次施放梦境吐息时都能可靠地触发该被动。

[[spell:1256577]] 是一个极其强大的技能，能大幅增强 [[spell:366155]] 的威力。主要由于等级2的存在，你需要确保尽可能频繁地让尽可能多的玩家拥有 逆转。由于麦琳瑟拉的祝福在所有 逆转 效果之外还提供了一大波治疗，你可以配合 [[spell:364343]] 使用获得双重收益，这也是你在 至暗之夜 中使用 [[spell:364343]] 的主要方式。

2.6.

#### 英雄天赋改动

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 有两个非常重要的改动，我们之前已简要提及。[[spell:444088]] 的运作方式完全不同，不再在整个团队触发治疗爆炸。吞噬之焰在你的循环中将占小得多的部分，整体重要性也大大降低。塑焰者 的大量价值将来自新的 [[spell:1264269]] 天赋。这为你提供两层 [[spell:355936]] 充能。由于梦境吐息总是触发 [[spell:1256577]]，你可以执行稳定的爆发治疗循环，并通过 [[spell:364343]] 麦琳瑟拉获得巨额治疗。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 的玩法基本保持不变，因为没有值得注意的、会对你的输出产生重大影响的改动或新增内容。唯一值得一提的是 [[spell:431715]]，它缩短 [[spell:373861]] 的冷却时间和法力消耗。这使得尽可能保持时空畸体冷却结束就使用变得极其重要，以最大化你产生的 [[spell:364343]] 数量，同时输出大量护盾。

2.7.

#### 输出循环变化

在 至暗之夜 中，你可以预期在所有形式的内容中都会发生显著的循环变化。造成这些变化的最大因素是 [[spell:373270]] 和 [[spell:367226]] 的移除。失去这些技能意味着你不再需要执行时机极其精确的爆发治疗循环来达到完整的治疗输出。虽然 [[spell:360995]] 配合 [[spell:364343]] 用于爆发治疗仍然强大，但你经常会像之前的版本那样，使用 回响 配合 [[spell:366155]]。

此外，[[spell:1242031]] 在循环中带来了一个有趣的变化：在你的爆发治疗循环之间，配合 [[spell:369297]] 使用 [[spell:355913]]（该技能在 至暗之夜 中获得了显著增强）以获得免费的 [[spell:364343]] 施放，可能非常有价值。之前你被迫只能二选一，但有了双重回响天赋，你的循环拥有很高的灵活性。

在大秘境环境中，失去 [[spell:367226]] 的影响会更大，你可能会发现自己更加依赖 [[spell:361469]]，当 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫。作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者，你将获得一层额外的 [[spell:355936]] 充能来帮助你应对困难时刻。除此之外，你将专注于使用 [[spell:360995]] 进行爆发治疗，以及使用 [[spell:366155]] 进行常规治疗。

最后一个值得一提的循环改动是针对 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 的。由于 [[spell:444088]] 的改动，你将不再对整个团队进行大规模爆发治疗。你的游戏玩法将专注于利用 [[spell:355936]] 施放来获得 [[spell:1256577]] 的爆发治疗，其他时候则使用 [[spell:366155]]/[[spell:360995]]。

1.

### 恩护 唤魔师 游戏基础

恩护 唤魔师 和任何治疗者一样，关键在于策略性地使用你的技能。你不会使用固定的循环，而是会运用你灵活的技能组来适应并克服游戏中出现的一切情况。

这个专精在所有构建、游戏风格和内容形式中都严重依赖 [[spell:364343]]。[[spell:364343]] 提供少量治疗，但更重要的是在玩家身上施加一个增益，使你的下一个治疗法术也会对拥有 [[spell:364343]] 增益的玩家生效。这让你能够打出强力的连招，例如同时对大量玩家施放 [[spell:366155]] 或 [[spell:355936]]。恩护 可以进一步分为以下三个核心要点。

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **管理精华使用**
  
  
  
  
  确保你不断消耗精华。每当你因精华溢出而浪费精华时，你就错过了潜在的 [[spell:364343]] 施放。这可能导致治疗量显著损失，并使你难以跟上即将到来的伤害。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_dreambreath.jpg>) **保持技能冷却**
  
  
  
  
  恩护 依赖于 [[spell:355936]] 和 [[spell:373861]] 等关键技能才能正常运作。[[spell:355936]] 保证你触发 [[spell:1256577]]，[[spell:373861]] 为你提供大量 [[spell:364343]]。长时间不使用这些技能会削弱你应对即将到来的伤害的能力。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_echo.jpg>) **正确消耗 回响**
  
  
  
  
  [[spell:364343]] 的难点之一在于它可能被多种技能意外消耗。这样做会导致治疗量的巨大损失。在团队副本中，你必须始终使用 [[spell:1256577]] 来消耗 [[spell:364343]]。在大秘境中你有更多余地，因为 [[spell:360995]]、[[spell:355936]] 和 [[spell:366155]] 都是不错的选择。

1.

### 如何为 恩护 唤魔师 配装

虽然我们始终建议你自行模拟以获得理想结果，但我们确实提供了专门的 恩护 配装页面。我们目前涵盖了第二赛季装备的推荐，以便在 至暗之夜 终局内容发布时有个良好的开端。在你获得一些装备后，你需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** BiS列表已针对12.1.5版本更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年10月1日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 对大秘境装备推荐进行了微小修正。
- **2026年8月28日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 更新了团队副本构建的职业天赋树。
- **2026年8月25日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 为额外拾取策略添加了额外信息。
- **2026年8月23日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 更新了 塑焰者 大秘境构建。
- **2026 年 8 月 17 日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 对饰品梯队进行了小幅更新。
- **2026年8月13日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 添加了关于内在火焰的信息。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026 年 5 月 3 日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 推荐属性已更新。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026 年 3 月 31 日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** BiS饰品和饰品强度列表已更新。
- **2026 年 3 月 31 日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 添加了额外的循环信息。
- **2026 年 3 月 31 日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋推荐已更新。
- **2026年3月23日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2026年3月20日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 为翡翠之花和青翠之拥添加了额外信息。
- **2026年3月20日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋推荐已更新。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 推荐天赋已更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（本页）：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 为11.2.7补丁更新。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月31日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 翡翠之花配装已更新。
- **2025年8月31日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 页面已全面改版，并调整了翡翠之花配装。
- **2025年8月29日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 生命缚者信息已更新。
- **2025年8月20日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 武器附魔推荐已更新。
- **2025年8月14日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 更新了饰品推荐。
- **2025年8月11日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 小幅更新。
- **2025年8月9日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 循环更新。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对11.2补丁进行审阅。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 为11.1.7补丁更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 为11.1.7补丁更新。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 为11.1.7补丁更新。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年5月13日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 困惑的卡特尔芯片推荐已更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 页面已针对11.1.5补丁更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 页面已针对11.1.5补丁更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 页面已针对11.1.5补丁更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 页面已针对11.1.5补丁更新。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 页面已针对11.1.5补丁更新。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 页面已针对11.1.5补丁更新。
- **2025年3月17日（[解放安德迈页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** 添加了加里维克斯提示。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 塑焰者输出循环已针对11.1版本更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋推荐已针对11.1版本更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 添加了Cyrces Circlet的信息。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 页面全面改版。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年10月7日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** 首领推荐已更新。
- **2024年10月7日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 时空守卫回响配装的输出循环已更新。
- **2024年9月28日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 添加了特定地下城的提示。
- **2024年9月19日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** 添加了天赋推荐和提示。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 添加了第1赛季毕业装备。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已添加第1赛季信息。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对《地心之战》第1赛季更新。
- **2024年9月9日（本页）：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 消耗品推荐已更新。
- **2024年8月30日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-nerub-ar-palace-raid-guide>)):** 页面已添加。
- **2024年8月27日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 添加了地下堡配装。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年8月21日（本页）：** 页面已针对《地心之战》进行审查和更新。
- **2024年8月17日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/preservation-evoker-mists-of-pandaria-remix-guide>)):** 已更新至《地心之战》前夕补丁。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已为《地心之战》前夕补丁审核。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 页面已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 页面已针对《地心之战》前夕更新。
- **2024年7月20日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 页面已针对《地心之战》前夕更新。
- **2024年6月17日（[地心之战](<https://www.icy-veins.com/wow/preservation-evoker-the-war-within-pve-guide>)):** 页面已添加。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/preservation-evoker-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 页面已针对第4赛季更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 页面已针对第4赛季更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 页面已针对第4赛季更新。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 页面已针对第4赛季更新。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 页面已针对第4赛季更新。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 页面已针对第4赛季更新。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 为第4赛季进行了更新。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 页面已针对第4赛季更新。
- **2024年4月22日（本页）：** 页面已针对第4赛季更新。
- **2024年4月1日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 修复了升级用天赋串。
- **2024年3月26日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对10.2.6版本更新。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 天赋推荐已针对10.2.6更新。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋推荐已针对10.2.6更新。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 针对10.2.6补丁进行了审查。
- **2024年3月19日（本页面）：** 针对10.2.6补丁进行了审查。
- **2024年2月8日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 回响配装已更新，加入了衔尾蛇。
- **2024年1月17日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 回响配装推荐进行了小幅更新。
- **2024年1月16日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 输出循环变更。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 配装推荐已针对10.2.5更新。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 输出循环已针对10.2.5更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 配装推荐已针对10.2.5更新。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 添加了10.2.5的改动。
- **2023年11月29日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 最佳配装列表小幅更新。
- **2023年11月21日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 武器附魔推荐已更改。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 针对孢子斗篷削弱更新了美化和最佳配装列表。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已更新至10.2。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已更新至10.2。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已更新至10.2。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已更新至10.2。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对10.2补丁进行审查
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对10.2补丁进行审查
- **2023年11月6日（本页）：** 已更新至10.2。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 添加了最佳配装。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 格式更新。
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 针对 10.1.7 补丁进行了审阅
- **2023年8月8日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 为翡翠之花输出循环添加了额外信息。
- **2023年7月19日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2023年7月17日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 饰品天梯榜已更新。
- **2023年7月17日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 天赋推荐进行了小幅调整。
- **2023年7月17日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋推荐进行了小幅调整。
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（本页）：** 已针对10.1.5补丁进行更新。
- **2023年7月8日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 天赋推荐已更新。
- **2023年5月26日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 添加了关于时光漫游饰品的信息。
- **2023年5月20日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 根据漏洞修复更改了美化装备建议。
- **2023年5月16日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 美化推荐已更新。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已更新至10.1补丁。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已更新至10.1补丁。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已更新至10.1补丁。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已更新至10.1补丁。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已更新至10.1补丁。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已更新至10.1补丁。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已更新至10.1补丁。
- **2023年5月1日（本页）：** 已更新至10.1补丁。
- **2023年4月20日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 升级配装已更新。
- **2023年3月28日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 更新了原初宝石推荐。
- **2023年3月28日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 更新了原初宝石推荐。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/preservation-evoker-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已为10.0.7补丁更新。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（本页）：** 已针对10.0.7补丁进行审核。
- **2023年1月31日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 天赋推荐略微更新。
- **2023年1月31日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋说明已更新。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 天赋已针对10.0.5更新。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 输出循环已针对10.0.5更新。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋已针对10.0.5更新。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 为10.0.5补丁进行了审核。
- **2023年1月13日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 添加了巧思火花制作建议。
- **2022年12月28日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 消耗品/附魔已更新。
- **2022年12月28日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 在属性优先级中，将急速移至暴击之下。
- **2022年12月28日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 天赋构筑已更新。
- **2022年12月28日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 输出循环已更新，加入了翡翠之花与逆转配装之间的差异。
- **2022年12月28日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 天赋配置已更新。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年11月15日（[升级](<https://www.icy-veins.com/wow/preservation-evoker-leveling-guide>)):** 页面已添加。
- **2022年11月15日（[传说物品](<https://www.icy-veins.com/wow/preservation-evoker-best-legendaries-shadowlands>)):** 页面已添加。
- **2022年11月15日（[盟约与羁绊](<https://www.icy-veins.com/wow/preservation-evoker-best-covenants-soulbinds-and-conduits>)):** 页面已添加。
- **2022年11月15日（[装备页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot>)):** 页面已添加。
- **2022年11月15日（[插件页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-macros-addons>)):** 页面已添加。
- **2022年11月15日（[附魔页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gems-enchants-consumables>)):** 页面已添加。
- **2022年11月15日（[属性页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)):** 页面已添加。
- **2022年11月15日（[大秘境页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-mythic-plus-tips>)):** 页面已添加。
- **2022年11月15日（[循环页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-rotation-cooldowns-abilities>)):** 页面已添加。
- **2022年11月15日（[天赋页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spec-builds-talents>)):** 页面已添加。
- **2022年11月15日（[法术页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-spell-summary>)):** 页面已添加。
- **2022年11月15日（[简单模式页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-easy-mode>)):** 页面已添加。
- **2022年11月15日（本页）：** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页面中，你将找到我们的逐级恩护唤魔师升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[唤魔师 练级指南](<https://www.icy-veins.com/wow/evoker-leveling-guide>).

1.

### 恩护唤魔师《至暗之夜》升级指南

恩护唤魔师是一个升级速度极快的职业，这主要得益于它相比其他职业拥有极高的机动性。更不用说，你还可以治疗地下城以获得更快的排队时间。

在较低等级时，你通常会发现以恩护进行治疗并排队地下城是最轻松的升级方式，因为排队时间几乎是瞬时的。即使你觉得自己治疗起来不太自在，早期的升级地下城也并不太难，所以这是一个很好的学习机会！

在较高等级时，做任务会变得更快，并且在某些情况下是必须的（例如资料片战役），此时你会希望切换到
[湮灭 唤魔师](<https://www.icy-veins.com/wow/devastation-evoker-pve-dps-guide>) ，因为它将为你提供最高的整体伤害输出，让你获得尽可能快的任务体验。

1.1.

#### 升级装备选择

升级时，始终选择物品等级最高的战利品。此规则唯一的例外是，如果你有一个戒指或项链，物品等级略低，但拥有2项副属性而非1项。

使用传家宝物品来帮助提升练级速度时，你通常需要尽可能多地使用 **急速** 尽可能多的装备部位，以帮助对抗你可能拥有的非常低的次要属性。这将加快你的循环速度，并有助于防止感觉缓慢和笨拙。

1.2.

#### 至暗之夜升级实用消耗品

在至暗之夜中升级时，你在整个地心之战中使用的许多消耗品将继续有价值。确保你始终有合剂效果：[[item:212274]]。以及准备大量可能有帮助的药水：[[item:212265]]。在资料片末期，许多玩家会试图卖掉他们剩余的消耗品库存，所以你经常能找到便宜的消耗品来帮助你加快升级速度！

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 恩护唤魔师《至暗之夜》80级升级
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2MwwMjZzMGzs9AMAAwMmxMYYmMzMDAAAsNzMTzYmZmxYGAYMDsAWAzwEYhxmhBwMDD"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2MwwMjZzMGzs9AMAAwMmxMYYmMzMDAAAsNzMTzYmZmxYGAYMDsAWAzwEYhxmhBwMDD"
}
```
:::

:::details 来源计算器编码
```
#8W-SsFLLKbTlPpqqXkkjIIHaZBWedgniihEYY-lEkDjFiCQUVlii8iY8qJMmmGXwHAwZH-AAAA-ZaWCSIMQxogwBA-
```

:::

2.1.

#### 升级用战争模式天赋

在这里，你将找到关于升级以及进行单人/小队PvE内容时最佳PvP天赋的信息。

1. [[spell:377509]]是一个强大的冷却技能，会在你和盟友身上放置一个强大的持续治疗效果。
2. [[spell:378437]]对于风筝敌人和逃跑以防止被击退很有用。
3. [[spell:370388]]可以用于将你和一名队友传送到其他位置。

**等级 20 起：**恩护唤魔师的PvP天赋对加快升级过程没有多大帮助。它们唯一的用途是功能性，总体而言，这些天赋不会显著提高或阻碍你的升级速度。

1.

### 升级循环

为了在练级和学习专精时保持简单，使用滑块选择你的等级，观察练级循环随着每个等级而增长！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

1. **等级 11 起：**施放[[spell:364343]]为盟友施加增益并消耗精华。
2. **等级 15 起：**尽可能使用[[spell:366155]]，冷却完毕就用。
3. **等级 10 起：**施放[[spell:360995]]进行快速的单体治疗。
4. **等级 13 起：**只要队友在范围内，就施放[[spell:355936]]治疗你的队伍。
5. **等级 17 起：**在队伍承受大量范围伤害时施放[[spell:363534]]。
6. **等级 37 起：**使用[[spell:370537]]储存治疗量，并在你的队伍受到大量伤害时重新施放。
7. **等级 10 起：**在没有其他技能可用时使用[[spell:361469]]进行治疗。
8. **等级 10 起：**如果不需要治疗，请使用你的DPS循环（详见下文）。

**等级 10 起：**伤害输出循环相当简单，应在不需要治疗或做任务时使用。

1. **等级 10 起：**冷却完毕就使用[[spell:357210]]造成大量范围伤害。
2. **等级 10 起：**冷却完毕就使用[[spell:357208]]。
3. **等级 10 起：**只要有精华就使用[[spell:356995]]。
4. **等级 10 起：**在没有精华且[[spell:357208]]处于冷却时施放[[spell:361469]]。

在获得更多技能之前，你可能会发现自己严重依赖[[spell:361469]]进行治疗。一旦你获得了更多法术，就可以开始将它们加入你的循环中，减少活化烈焰的使用。

升级期间，[[spell:364343]]实际上可以配合任何技能消耗，但你的最佳选择与大秘境类似。将其用在[[spell:366155]]上会为你提供强大的被动治疗，[[spell:360995]]会为你提供更多的爆发治疗，而[[spell:355936]]也能为你提供一些额外的持续治疗。你应该尝试所有这些技能，并在升级过程中习惯使用不同类型的技能。尝试得越多，你学到的就越多，达到满级后你也会变得更强。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 页面已针对11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年4月1日：** 修复了升级用天赋串。
- **2024年3月26日：** 已针对10.2.6版本更新。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年4月20日：** 升级配装已更新。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 快速入门

在本页面中，我们将解释如何在《魔兽世界》12.1.5补丁中轻松游玩恩护唤魔师，使用最简单的输出循环、天赋树、属性优先级、装备搭配等，同时不牺牲性能。

1.

### 《至暗之夜》中恩护唤魔师基础指南

本节面向刚接触游戏或该职业的玩家，他们无意参与史诗难度团队副本，或只是希望以更直接的方式进行专精输出，而不会被最优输出所需的众多优先级和主动技能所淹没。

游玩恩护唤魔师的关键在于频繁使用[[spell:355936]]和[[spell:373861]]，同时将精华花在[[spell:364343]]上，然后用[[spell:1256577]]消耗该[[spell:364343]]。除此之外，你可以通过[[spell:361469]]、[[spell:357208]]和[[spell:356995]]造成伤害。学习该专精时需要遵循的三条快速规则是：

- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_essenceburst.jpg>) **管理精华使用**
  
  
  
  
  确保你不断消耗精华。每当你因精华溢出而浪费精华时，你就错过了潜在的 [[spell:364343]] 施放。这可能导致治疗量显著损失，并使你难以跟上即将到来的伤害。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_dreambreath.jpg>) **保持技能冷却**
  
  
  
  
  恩护 依赖于 [[spell:355936]] 和 [[spell:373861]] 等关键技能才能正常运作。[[spell:355936]] 保证你触发 [[spell:1256577]]，[[spell:373861]] 为你提供大量 [[spell:364343]]。长时间不使用这些技能会削弱你应对即将到来的伤害的能力。
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_evoker_echo.jpg>) **正确消耗 回响**
  
  
  
  
  [[spell:364343]] 的难点之一在于它可能被多种技能意外消耗。这样做会导致治疗量的巨大损失。在团队副本中，你必须始终使用 [[spell:1256577]] 来消耗 [[spell:364343]]。在大秘境中你有更多余地，因为 [[spell:360995]]、[[spell:355936]] 和 [[spell:366155]] 都是不错的选择。

1.

### 《至暗之夜》中恩护唤魔师新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者团本天赋

2.1.

#### 新手 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 恩护唤魔师的塑焰者团本配装

这是恩护唤魔师推荐的新手团本配装。重点是尽可能多地使用[[spell:373861]]，同时将精华花在[[spell:364343]]上。有了这些[[spell:364343]]增益，你将用[[spell:366155]]和[[spell:1256577]]来消耗它们。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbYAAwMjZMDGzIzMDAAAwMzMZGzMmtZGAYGzALgFwMMB2MsZYAMzMGA"
}
```
:::

:::details 来源计算器编码
```
#8W-SsFLLKbRRZBYYlPuoIIHjpXWeEnmFF:WDHA-lEkDFCjiUVVUWakiiuSSC2004+829ZC-AAAA-TKMIgpZRxogwBA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者地下城天赋

2.2.

#### 新手 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 恩护唤魔师的塑焰者地下城配装

该配装专为想要游玩以大秘境为主的相对简单的配装的玩家设计。游玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者的好处是你获得两层[[spell:355936]]充能，这意味着你有额外的工具可用。虽然它学习起来可能也有难度，但你也能获得非常强大的[[spell:444322]]。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYmxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVliiu8qosgYsJAA4877AG-AAAA-TKMIgpZRxogwBA-
```

:::

### 恩护唤魔师基础输出循环

2.3.

#### 恩护唤魔师的基本玩法

下面，我们将根据你所进行的内容形式来分解你的总体优先级。

2.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者团本治疗

- 以1级蓄力施放[[spell:355936]]，并尽可能频繁地施放它。
- 尽可能多地施放[[spell:373861]]和[[spell:364343]]。
- 尽可能用[[spell:366155]]或[[spell:1256577]]消耗[[spell:364343]]。
- 对需要单体治疗的玩家施放[[spell:360995]]。

重要的是，你只能用[[spell:366155]]或[[spell:1256577]]消耗[[spell:364343]]。其他技能如[[spell:355936]]和[[spell:360995]]只能在你没有任何活跃的[[spell:364343]]时使用。

2.5.

#### 五人本治疗

- 在应对大量伤害时以最高蓄力等级施放[[spell:355936]]，或以低蓄力等级进行少量持续治疗。
- 尽可能多地施放[[spell:373861]]和[[spell:364343]]。
- 尽可能用[[spell:366155]]或[[spell:1256577]]消耗[[spell:364343]]。
- 使用[[spell:360995]]进行快速的爆发性单体治疗。尽量多使用，并对最需要大量治疗的目标使用。当它冷却完毕时，尽量用[[spell:364343]]配合它使用，而不是用逆转。
- 只有在情况危急时才连续使用[[spell:361469]]。

2.5.1.

##### 巅峰天赋： ![Merithra's Blessing Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_boss_valithradreamwalker.jpg>) 麦琳瑟拉的祝福

在至暗之夜中，你将获得[[spell:1256577]]，新的顶峰天赋。该技能有三个独立的等级，都会增强其威力，但并非所有等级都需要理解。下面我们将列出你需要了解的两个主要组成部分。

- 消耗精华的技能有几率触发[[spell:1256577]]，使你的下一个[[spell:366155]]被转化。除了提供标准的逆转效果外，它还会更换图标，并产生类似梦境花的效果，治疗会射出并弹跳到玩家身上。
- 每次施放[[spell:355936]]都会触发[[spell:1256577]]，使你在施放梦境吐息时可靠地触发该被动。

[[spell:1256577]]是一个极其强大的技能，能大幅增强[[spell:366155]]的威力。你应确保尽可能频繁地让尽可能多的玩家拥有逆转。由于麦琳瑟拉的祝福在所有逆转效果之外还提供大量爆发治疗，你可以在使用[[spell:364343]]时获得双重收益，这也是你在至暗之夜中使用[[spell:364343]]的主要方式。

2.5.2.

##### 第2赛季套装

至暗之夜第二赛季的套装对于唤魔师的恩护专精来说相当直接，主要围绕[[spell:360995]]展开。套装奖励如下所列。

- [[spell:1296641]]——消耗[[spell:369297]]时，会对你的目标或附近的一名受伤盟友发射一道[[spell:361469]]。
- [[spell:1296642]]——[[spell:360995]]现在将提供一个[[spell:369297]]。此外，所有绿色法术现在恢复的生命值提高5%。

这套套装在很大程度上是被动的，会为你提供不错的治疗增益。在需要时，你可以使用[[spell:360995]]作为生成[[spell:369297]]的可靠手段。但在大多数情况下，你通常只需照常继续你的技能循环，只不过现在威力更强了。

### 唤魔师的恩护专精属性优先级

2.6.

#### 唤魔师的恩护专精属性优先级

唤魔师的恩护专精的一般属性优先级如下所示。这是一个非常粗略的指南，专为那些不希望通过模拟来分析角色的玩家设计的
[QuestionablyEpic](<https://questionablyepic.com/>)。有关此页面上呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>).

智力

精通

暴击

急速

全能

### 暴风雪战斗助手

2.7.

#### 战斗助手

战斗助手在11.1.7补丁中加入，是一个旨在施放你循环技能的一键式功能。遗憾的是，对于治疗专精来说，它运作得并不好。作为唤魔师的恩护专精，战斗助手 **不会施放治疗法术**。相反，它只会施放[[spell:357208]]和[[spell:361469]]。这造成了一种独特的情况，即有可能使用战斗助手作为单个按键，而不需要为每个技能分别设置两个按键，但这并不推荐，因为有时候你会想在不施放火焰吐息的情况下使用活化烈焰，而被施放的活化烈焰只会造成伤害。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 页面全面改版。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将了解到在《魔兽世界》12.1.5补丁中，你的唤魔师的恩护专精的最佳天赋。我们还为不同类型的活动（如团队副本或大秘境）提供了默认天赋方案。如果你开启了战争模式，我们也为你准备了PvP天赋。

1.

### 唤魔师的恩护专精在至暗之夜中的最佳天赋

虽然恩护有大量具有竞争力的选择，但我们的推荐重点在于 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者，它能为你提供最大的伤害和治疗输出提升。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫仍然是一个具有竞争力的替代方案，但会带来更严重的法力问题和更少的输出。

- **团本 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者进一步增强了[[spell:355936]]的威力，并通过你的[[spell:369297]]为你提供额外的治疗，使其在团队副本环境中尤为强大。
- **大秘境 -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者为你提供最高的伤害和治疗潜力，同时提供额外的灵活性和独特的功能性。[[spell:1264269]]将使你获得两层[[spell:355936]]，而[[spell:444322]]允许你给予一名团队成员[[spell:363916]]，不过效果会有所降低。

**快速开始导入代码：**

:::talents 塑焰者团队副本
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsNzMAYGzALgFwMMB2MsZYAMzMGA"
}
```
:::

:::talents 塑焰者大秘境
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::talents 时空守卫团队副本
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZwMjBzY2MMzMbYAAgZMjBzYGZmZAAAAmZmJzYmxsNzMAYgxM2YBGYGGawYBGzMAjB"
}
```
:::

:::talents 时空守卫大秘境
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMz2yAzYmxsZGjx2wAAAzYGzghZyMzMAAAw2MzMNjZmZGjZAAYMjFWgBmhhGGWgxMDAD"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

塑焰者

团队副本

推荐

大秘境/地下堡

推荐

时空守卫

团队副本

秘境+

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 团本配装

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者的玩法与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫的构建非常相似，但有几个额外的重要细节需要你牢记。首先，你将拥有两层[[spell:355936]]，这意味着你可以更可靠地触发[[spell:1256577]]来获得大量爆发治疗。其次，[[spell:444322]]将允许你将[[spell:363916]]放置在其他玩家身上。这与[[spell:357170]]相结合，为恩护创造了一个非常有趣的定位，使你能够提供大量的外部防御性冷却技能。

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 大秘境天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者的主要优势在于你获得了一层额外的[[spell:355936]]，以及非常强大的[[spell:444322]]天赋。这些额外的工具可以使恩护感觉更加宽容，因为你总会有一些技能可用于应对地下城对你和队伍造成的一切。话虽如此，塑焰者在5人小队环境中缺乏时空守卫所拥有的某些整体威力。

### 天赋方案 1-0

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫团队副本构建

在使用 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫构建时，重要的是你要尽可能多地使用[[spell:373861]]，以最大化[[spell:431715]]的效果。你还需要尽可能让[[spell:370553]]保持冷却。要真正从这个英雄天赋树中获得全部价值，你需要围绕[[spell:394332]]和[[spell:431657]]的效果来操作：每次你施放[[spell:360995]]，你都会获得叠加的急速，这意味着你需要尽可能频繁地使用青翠之拥。

### 天赋方案 1-1

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫大秘境构建

虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫将[[spell:370553]]变成一个强大的冷却技能，其大部分价值来自于英雄天赋树中的其他节点。[[spell:431875]]、[[spell:431442]]和[[spell:431615]]可以提供大量被动治疗。你还将通过[[spell:1260568]]获得额外的[[spell:369297]]，并且[[spell:364343]]会通过[[spell:432004]]得到增强。时空守卫充满了强大的天赋，可以提高你的输出，并让你即使在没有冷却技能可用的情况下也能应对困难的时机。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAMzMDmZMYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsNzMAYGzALgFwMMB2MsZYAMzMGA"
}
```
:::

:::details 来源计算器编码
```
#8W-KSbsFRRZlqqIIOPXYYpuHjoEWefgiinrhmB-lEFkDjCiKKLNSUVv8mkEFt1Fopx99ZC-AAAA-JckUhpBIQYgxSB-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVlu8qosgYsJAA4877AWSC-AAAA-TKMIgpZRxogwBA-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZwMjBzY2MMzMbYAAgZMjBzYGZmZAAAAmZmJzYmxsNzMAYgxM2YBGYGGawYBGzMAjB"
}
```
:::

:::details 来源计算器编码
```
#8W-SsFKbRRZBYYlPuoIIHjpXqqWefriihEnOmB-lEkDFCjiUVVUWakii8elkE0BAsppxdC-AAAA-OIoYI0wsEAgUME-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYmxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAwYGbsADMDDNYsAjZGgxA"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVliiu8qosgYsJAA4877AG-AAAA-OUaAQYMIMUIYpA-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

全知卷宗是 至暗之夜 中引入的一个新系统 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)，并在一个为期数周的任务系列之后提供一些增强性能的自定义选项。其中一些加成会影响你的伤害输出，而另一些则更具防御性质。

下面我们将为你推荐最佳配置，但大多数加成的强度相当，你可以根据需要进行更换。具体来说，[[spell:1279612]] 可以替换为你想要的任何其他次要加成。

- [[spell:1279599]]
- [[spell:1279603]]
- [[spell:1287555]]
- [[spell:1279612]]
- [[spell:1279614]]

1.

### 巅峰天赋： ![Merithra's Blessing Icon](<https://static.icy-veins.com/images/wow/large_icons/achievement_boss_valithradreamwalker.jpg>) 麦琳瑟拉的祝福

在至暗之夜中，你将获得麦琳瑟拉的祝福，这是新的顶峰天赋。该技能有三个独立的等级，都能增强其威力。下面我们将分别解析每个等级的效果。

- 等级1（[[spell:1256577]]）——消耗精华的技能有几率触发麦琳瑟拉的祝福，使你的下一个[[spell:366155]]发生转化。除了提供标准的逆转效果外，它还会改变图标，并产生类似活化之种的效果，治疗会射出并弹跳到玩家身上。
- 等级2（[[spell:1256682]]）——[[spell:366155]]现在每点使受到的伤害降低1%，并同时每点为其恢复1%的生命值。这既是减伤也是治疗，其中减伤部分会在伤害统计中显示为吸收。
- 等级3（[[spell:1256689]]）——[[spell:355936]]的瞬发治疗量将大幅提升，且每次施放都会触发[[spell:1256577]]，使你每次施放梦境吐息时都能可靠地触发该被动。

麦琳瑟拉的祝福是一个极其强大的技能，极大地增强了[[spell:366155]]的威力。主要由于等级2的原因，你会希望确保尽可能频繁地将逆转保持在尽可能多的玩家身上。由于麦琳瑟拉的祝福在所有逆转效果之外还提供大量的爆发治疗，你可以通过[[spell:364343]]的使用获得双重收益，这也是你在至暗之夜中使用[[spell:364343]]的主要方式。

1.

### 英雄天赋

唤魔师的恩护专精可以在两个不同的英雄天赋选择之间挑选：
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者。两者在团队副本和大秘境中都具有竞争力，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者更胜一筹。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫可以提供强大的爆发治疗和额外的急速，使专精感觉更流畅，但在伤害和治疗输出方面都落后。

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫专注于[[spell:370553]]和[[spell:431695]]，以大幅提升你的急速、移动速度和冷却缩减。通过[[spell:431875]]和[[spell:431442]]，你施放的任何蓄力法术都能获得不错的加成。这使大量威力与你的[[spell:355936]]施放绑定在一起。此外，[[spell:431715]]将大量威力专门投入到[[spell:373861]]中。让你能够不断为玩家提供护盾，同时生成大量[[spell:364343]]。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者为你提供一层额外的[[spell:355936]]和[[spell:357208]]。鉴于[[spell:1256577]]（新的顶峰英雄天赋）必定会由梦境吐息触发，你可以不断地布置大型预热：施放梦境吐息，尽可能多地施放[[spell:364343]]，然后用麦琳瑟拉的祝福消耗这些回响。最后，你将通过[[spell:444088]]获得不错的治疗加成，你可以用[[spell:360995]]和[[spell:355913]]在玩家身上触发它。

1.

### PvP天赋（战争模式）

战争模式为你在开放世界中提供了多项好处。

- 户外世界中启用的PvP天赋。
- 在最高等级时，世界任务奖励至少提高 10%。
- 升级时获得的经验值提高10%。
- 赚取征服点数，每周可兑换装备。

鉴于开启战争模式对升级和 PvE 内容的好处，建议启用该功能以最大化你的升级速度和满级后的奖励。然而，你将成为开放世界 PvP 的目标，并且在升级或进行世界任务时存在被"围杀"的可能性。

在本节中，我们将为练级以及单人/小队PvE活动对PvP天赋进行排名。以下是唤魔师的恩护专精的所有PvP天赋排名。

1. [[spell:378464]]可以免疫接下来的3个控制效果，使其在你有被控制风险时格外强大。需要注意的是，它有施法时间，这意味着你需要在安全时施放它。
2. [[spell:378438]]可作为[[spell:370]]使用，当你处于攻势并试图击杀某人时会很有帮助。
3. [[spell:378437]]能大幅增强你的移动能力，防止你在[[spell:358267]]期间移动速度被降低。这使你更容易在战场上移动并接近盟友。

你可以认为其他选择基本上取决于个人偏好。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月28日：** 更新了团队副本构建的职业天赋树。
- **2026年8月23日：** 更新了 塑焰者 大秘境构建。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 天赋推荐已更新。
- **2026年3月20日：** 天赋推荐已更新。
- **2026年3月16日：** 推荐天赋已更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月31日：** 页面已全面改版，并调整了翡翠之花配装。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 天赋推荐已针对11.1版本更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月27日：** 添加了地下堡配装。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 天赋推荐已针对10.2.6更新。
- **2024年2月8日：** 回响配装已更新，加入了衔尾蛇。
- **2024年1月17日：** 回响配装推荐进行了小幅更新。
- **2024年1月15日：** 配装推荐已针对10.2.5更新。
- **2023年11月6日：** 已更新至10.2。
- **2023年9月4日：** 格式更新。
- **2023年7月17日：** 天赋推荐进行了小幅调整。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月31日：** 天赋说明已更新。
- **2023年1月24日：** 天赋已针对10.0.5更新。
- **2022年12月28日：** 天赋配置已更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何根据你的队伍承受的伤害类型来优化你的唤魔师的恩护专精的技能循环。我们还提供了关于冷却技能、触发效果等方面的进阶内容，以最大限度地提高你的治疗输出和法力效率。我们的所有内容均已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 唤魔师的恩护专精玩法与循环指南

欢迎来到我们的恩护唤魔师循环页面。在本页中，你将找到在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

以下各节将根据你选择的构建和你所进行的活动，分别讲解唤魔师的恩护专精的技能循环。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

团队副本

秘境+

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

团队副本

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

秘境+

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

主动天赋

被动天赋

[[spell:359816]]

[[spell:370537]]

[[spell:372233]]

[[spell:443177]]

### 唤魔师的恩护专精详解

1.1.

#### 总体优先级

唤魔师的恩护专精玩法侧重于用[[spell:364343]]为玩家施加增益。当此增益在玩家身上激活时，你施放的下一个治疗法术也会同时施放在拥有回响的所有玩家身上。例外情况是[[spell:355913]]，它将不再消耗[[spell:364343]]。通常这意味着，如果你点出了[[spell:1242031]]，你应该用[[spell:355913]]来消耗[[spell:369297]]，以在玩家身上施加更多回响。同样，[[spell:373861]]允许你传播更多回响。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，[[spell:364343]]的使用方式已大大简化，在团队副本中你几乎总是会用[[spell:1256577]]来消耗回响。在大秘境环境中，你仍然会优先使用[[spell:1256577]]，但你也需要使用诸如[[spell:360995]]之类的其他法术来应对爆发性伤害。

### 团队副本

1.2.

#### 唤魔师的恩护专精团队副本循环

作为唤魔师的恩护专精进行治疗时，重点是尽可能有效地使用[[spell:373861]]、[[spell:364343]]和[[spell:355913]]。在几乎所有情况下，你都会用[[spell:1256577]]来消耗[[spell:364343]]。

通常，你应该力求在用[[spell:366155]]或[[spell:1256577]]消耗它们的同时，最大化[[spell:364343]]的生成。这意味着要卡着冷却时间施放[[spell:373861]]，并且不要浪费任何精华。请记住，你应该用[[spell:355913]]配合[[spell:369297]]，借助[[spell:1242031]]来生成免费的[[spell:364343]]。除此之外，保持技能卡着冷却时间使用。

当你确实无事可做且没有精华可消耗时，你应该对敌人施放[[spell:361469]]来生成[[spell:369297]]。因为你进攻性地施放它，它会返还部分法力消耗。用它来治疗往往非常耗费法力。此外，确保你频繁使用[[spell:357208]]来触发[[spell:369939]]，这能让你生成更多[[spell:369297]]。

你的总体优先级如下：

- **适用条件：时空守卫（启用）；静滞（启用）。** 保持[[spell:370537]]卡着冷却时间使用，并力求将其与[[spell:370553]]配合使用。
- **适用条件：塑焰者（启用）；静滞（启用）。** 保持[[spell:370537]]卡着冷却时间使用。
- **适用条件：时空守卫（启用）；静滞（未启用）。** 尽可能频繁地使用[[spell:370553]]。
- 尽可能保持[[spell:373861]]卡着冷却时间使用。
- 尽可能保持[[spell:355936]]卡着冷却时间使用，以保证触发[[spell:1256577]]。请记住，你应该在1级时施放此技能。
- 用[[spell:355913]]消耗[[spell:369297]]，以触发[[spell:1242031]]。
- 只要有精华可用，就尽可能多地施放[[spell:364343]]。
- 用[[spell:1256577]]消耗[[spell:364343]]。（如果你失误了且没有麦琳瑟拉的祝福，你可以用[[spell:366155]]来消耗它们）
- 在完成一轮预热后且没有精华可用时施放[[spell:360995]]。
- **适用条件：生命火花（启用）。** 在两轮预热之间尽可能多地施放[[spell:357208]]。在获得[[spell:443177]]触发效果时，使用[[spell:369939]]进行治疗。尽可能将其与大型伤害窗口对齐。
- **适用条件：生命火花（未启用）。** 当你无事可做时，施放[[spell:357208]]来触发[[spell:369939]]，你可以利用它来帮助你生成[[spell:369297]]。
- **适用条件：能量循环（启用）。** 在不需要治疗时，用[[spell:356995]]消耗精华来恢复法力。

每一轮预热都应该围绕[[spell:355936]]来进行，因为正是它保证了我们触发[[spell:1256577]]。如果你处于一种它已冷却完毕但你有[[spell:1256577]]触发效果的情况，那么你应该迅速消耗该触发效果，以便用[[spell:355936]]重新开始你的预热。如果你的精华完全耗尽且刚刚完成了一轮预热，你很可能拥有[[spell:369297]]的触发效果，可以在下一个[[spell:355936]]之前开始使用它们。如果你没有[[spell:369297]]的触发效果，你应该转而开始施放[[spell:360995]]和[[spell:361469]]来生成触发效果，直到你的[[spell:355936]]冷却完毕。

:::details 小贴士：充分利用内在火焰！
在进行你的常规技能循环时，你被告知要施放

[[spell:355913]]

当你拥有

[[spell:369297]]

。当这种情况在

[[spell:1242745]]

期间仍然成立，但重要的是要知道你将主要专注于

[[spell:355913]]

而非

[[spell:364343]]

在此期间。要理解这一点，我们必须首先了解

[[spell:1242745]]

的工作原理。施放

[[spell:370537]]

后，你将获得内在火焰，它会提高持续治疗效果的治疗量，但更重要的是使

[[spell:361469]]

和

[[spell:366155]]

有100%的几率生成一个

[[spell:369297]]

。接下来，考虑我们的套装：

[[spell:1296641]]

。当你消耗一个

[[spell:369297]]

时，你会发射一道

[[spell:361469]]

。在

[[spell:1242745]]

激活的情况下，我们的套装奖励将为我们提供一个

[[spell:369297]]

使我们能够连续施放大量的

[[spell:355913]]

，前提是我们足够幸运地获得触发效果。你应该优先在此窗口期间尽可能多地施放

[[spell:355913]]

。为了帮助最大限度地减少因运气不佳而耗尽

[[spell:369297]]

的可能性，你可以做一些准备工作。首先，你应该力求在施放

[[spell:357208]]

之前施放一个最高等级的

[[spell:370537]]

。这将给你

[[spell:369939]]

你可以在触发效果耗尽时使用

[[spell:1242745]]

。此外，你随时可以使用一次快速的

[[spell:373861]]

- 

[[spell:1256577]]

（或

[[spell:366155]]

）来快速生成更多触发效果。你会遇到触发效果即将耗尽或完全用尽的情况，因此你应该始终制定好计划，在你的

[[spell:1242745]]

窗口结束前快速获取它们。总结一下，专注于施放尽可能多的

[[spell:355913]]

在

[[spell:1242745]]

期间，如果触发效果耗尽，别忘了利用

[[spell:369939]]

和

[[spell:373861]]

作为快速生成更多触发效果的方式。

:::

:::details 常见问题：我应该施放多少次 翡翠之花？
你希望施放

[[spell:355913]]

每次

[[spell:369297]]

触发时。随着

[至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)

的改动，翡翠之花 将不再消耗

[[spell:364343]]

。此外，

[[spell:1242031]]

使每次 翡翠之花 施放都为你提供一个可叠加两次的增益效果。该增益效果使

[[spell:364343]]

作用于额外一名玩家。这样，你就可以在治疗循环中安全地使用 翡翠之花，同时也不会影响你在大型伤害窗口期间放出回响的能力。话虽如此，翡翠之花 的法力消耗非常高，且比 回响 多消耗 1 点精华，这意味着你应该只在拥有

[[spell:369297]]

激活时施放它。这将使你获得大量额外治疗，同时不影响你的法力值。

:::

**适用条件：时空守卫（启用）。**

:::details 常见问题：我应该施放多少次 青翠之拥？
有效利用

[[spell:360995]]

实际上可能比较困难。一般来说，你会希望优先在爆发之间使用这个技能。根据你是否拥有该效果，有两种不同的施放顺序

[[spell:369297]]

触发，有两种不同的施放顺序。

- [[spell:369297]] 触发 —— 通过施放 [[spell:1256577]] 完成你的爆发期。接着将你的 [[spell:369297]] 花在 [[spell:355913]] 上。施放一次 [[spell:364343]]。施放 [[spell:360995]]，它将消耗两个回响（来自 [[spell:364343]] 的施放和 [[spell:1242031]] 触发）。这将使你获得 [[spell:431657]] 的最大层数。通过施放 [[spell:355936]] 开始你的下一个爆发期，并开始生成 [[spell:364343]]。
- 没有 [[spell:369297]] 触发 —— 通过施放 [[spell:1256577]] 完成你的爆发期。施放 [[spell:360995]]，接着施放 [[spell:355936]] 来开始新的爆发期。

请记住，你经常会发现自己无法按冷却时间使用它。它实在太昂贵了，而且你常常会发现自己在爆发期之间的间隔很短。在决定是否应该这样做时，你需要确保你刚刚施放了

[[spell:1256577]]

并且精华已经完全用尽。这意味着你可以快速施放

[[spell:360995]]

而不会错过任何

[[spell:364343]]

，那些本来可以包含在你上一个爆发期中。

:::

**适用条件：Stasis（启用）；塑焰者（启用）。**

:::details 常见问题：我该如何使用 Stasis？
利用

[[spell:370537]]

的最佳方式可能比较困难，因为它需要你拥有两层

[[spell:355936]]

充能。你需要积攒充能以确保它们在

[[spell:370537]]

冷却完毕时已经就绪。理想的连招看起来像这样：

- 激活 [[spell:370537]] 并施放 [[spell:355936]]。
- 施放你的第二层 [[spell:355936]] 充能。
- 施放 [[spell:373861]] 作为你最后一个 [[spell:370537]] 法术。

在你将所有 3 个法术存入你的

[[spell:370537]]

后，你应该专注于最大化

[[spell:1242745]]

，通过施放尽可能多的

[[spell:355913]]

并生成

[[spell:369297]]

触发效果，通过

[[spell:369939]]

和

[[spell:373861]]

- 

[[spell:1256577]]

.

:::

**适用条件：Stasis（启用）；时空守卫（启用）。**

:::details 常见问题：我该如何使用 Stasis？
使用

[[spell:370537]]

使用

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫

可能比

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者

简单一些。你会想要施放

[[spell:355936]]

,

[[spell:373861]]

，然后要么

[[spell:355913]]

或

[[spell:364343]]

.

- 激活 [[spell:370537]] 并施放 [[spell:355936]]。
- 施放 [[spell:373861]] 作为你的第二个法术。
- 如果你有 [[spell:369297]] 或额外的精华，施放 [[spell:355913]]。否则施放 [[spell:364343]]。

在你将所有 3 个法术存入你的

[[spell:370537]]

后，你应该专注于最大化

[[spell:1242745]]

，通过施放尽可能多的

[[spell:355913]]

并生成

[[spell:369297]]

触发效果，通过

[[spell:369939]]

和

[[spell:373861]]

- 

[[spell:1256577]]

.

:::

### 秘境+

1.3.

#### 大秘境循环 恩护 唤魔师

[恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) 没有强大的可连发治疗技能可以在情况艰难时使用。 [神圣 牧师](<https://www.icy-veins.com/wow/holy-priest-pve-healing-guide>)可以连发 [[spell:2060]]，而 [恢复 萨满祭司](<https://www.icy-veins.com/wow/restoration-shaman-pve-healing-guide>)可以连发 [[spell:1064]]，但 [唤魔师](<https://www.icy-veins.com/wow/evoker-class-overview-dragonflight>)唯一类似的按钮是 [[spell:361469]]，它相当弱。要在大秘境中精通 恩护，你必须考虑你的众多冷却技能，以及如何为每次伤害事件轮换它们。

你通常需要确保不断消耗你的精华，让 [[spell:373861]] 保持冷却，并频繁使用 [[spell:355936]] 和 [[spell:360995]] 等关键技能。此外，新的巅峰天赋：[[spell:1256577]] 为我们提供了另一个强大的爆发治疗来源，以应对困难时刻。

你的总体优先级大致如下：

- **适用条件：时空守卫（启用）。** 施放 [[spell:364343]] 为伤害做准备。
- 始终保持 [[spell:373861]] 处于冷却状态。
- 在伤害到来时保持队友身上的 [[spell:366155]]，通过 [[spell:376239]] 获得额外治疗。
- 大多数情况下以 1 级施放 [[spell:355936]]。在真正紧急的情况下，如果缺少额外治疗玩家可能会死亡时，可以使用更高等级。
- **适用条件：塑焰者（启用）。** 当需要群体治疗时，施放 [[spell:355913]] 以触发 [[spell:444088]] 和其他效果。
- 当需要大量单体治疗时，如果你有 [[spell:443177]] 触发，可以使用 [[spell:361469]]。只需记住这在法力方面会非常昂贵。
- 频繁使用 [[spell:357208]]，不仅为了伤害，还为了生成额外的 [[spell:369297]] 并触发 [[spell:369939]]。
- **适用条件：能量循环（启用）。** 当完全不需要治疗时，你可以将精华消耗在 [[spell:356995]] 上以造成额外伤害。

为了进一步理解大秘境循环，你还应该了解你消耗 [[spell:364343]] 的主要方式：

- **适用条件：时空守卫（启用）。** [[spell:355936]] —— 随着梦境吐息持续治疗效果的增强，在玩家身上始终保持这个持续治疗效果会非常有益。凭借你拥有的众多 [[spell:364343]]，按冷却时间 [[spell:364343]] 这个技能不应该太困难。
- **适用条件：塑焰者（启用）。** [[spell:355936]] —— 随着 [[spell:444088]] 得到增强，这个技能现在成为你最需要 [[spell:364343]] 的技能。当你在两名玩家身上都有 [[spell:355936]] 时，[[spell:355913]] 会同时触发两者的 [[spell:444088]]，带来巨大的爆发治疗。你应该始终在 [[spell:355936]] 冷却完毕时 [[spell:364343]] 它。
- [[spell:1256577]] —— 这个技能会在消耗精华以及施放 [[spell:355936]] 后触发。当你用这个技能消耗 [[spell:364343]] 时，你会获得大量爆发治疗，同时为每个身上有 [[spell:364343]] 的玩家施加 [[spell:366155]]。这提供了 [[spell:366155]] 的所有好处（想象 [[spell:378196]]）。这是你获得良好群体治疗并维持 [[spell:366155]] 的最简单方法。
- [[spell:360995]] —— 使用这个技能来消耗你的 [[spell:364343]] 将使你能够进行快速的爆发治疗。由于 唤魔师 在单体治疗方面尤其吃力，在困难时刻能够 回响 这个技能将非常有价值。
- [[spell:366155]] —— 保持你身上的被动治疗将使每一波小怪都更容易应对，同时还能提供 [[spell:376239]] 增益。多亏了 [[spell:378196]]，它在整体治疗以及应对爆发伤害方面都非常强大。在你的队伍承受大量伤害后，光是黄金时刻本身就能提供大量额外治疗。通常，你会通过 [[spell:1256577]] 获得所有这些效果，这意味着你不会像之前版本那样施放那么多 [[spell:366155]]。这也是它落后于 [[spell:360995]] 的原因。

总的来说，你的游戏玩法将专注于通过 [[spell:373861]] 不断为玩家放出 [[spell:364343]]，让你的队伍身上布满 [[spell:355936]] 持续治疗效果，并在需要群体治疗时用 [[spell:355913]] 触发 [[spell:444088]]。消耗 回响 总是视情况而定，你经常会根据手头有什么来轮换使用不同的技能。维持 [[spell:366155]] 总是很重要，类似于 [[spell:355936]] 持续治疗效果，你可以使用 [[spell:360995]] 来获得额外的爆发治疗。

:::details 常见问题：我该如何使用 Stasis？
为

[[spell:370537]]

选择最佳法术在很大程度上取决于具体情况。

[[spell:355936]]

,

[[spell:373861]]

,

[[spell:1256577]]

,

[[spell:360995]]

和

[[spell:355913]]

都是强大的选择，你需要在它们之间做决定。我们将推荐以下 Stasis 连招：

- 激活 [[spell:370537]] 并以一个强力法术开始：[[spell:355936]]。
- 接着施放 [[spell:373861]]，以便为你的队伍施加 [[spell:364343]]。
- 施放 [[spell:1256577]] 或 [[spell:360995]] 作为你的最后一个法术，以消耗 [[spell:364343]] 并为你的队伍提供大量爆发治疗。

通过这个连招，你可以通过消耗来快速输出大量群体治疗

[[spell:364343]]

生成的

[[spell:373861]]

在

[[spell:1256577]]

。如果

[[spell:355936]]

处于冷却状态，你可以改变法术顺序。你只需确保始终施放

[[spell:373861]]

接着是一个强力法术：

[[spell:1256577]]

/

[[spell:360995]]

。只要你有这个连招，你实际上可以在你的

[[spell:370537]]

中放入各种法术作为第三个法术。

:::

**适用条件：塑焰者（启用）。**

:::details 常见问题：我该如何使用 翡翠之花？
[[spell:355913]]

已经从我们在大秘境中从不按的技能变成了我们严重依赖的技能，这对许多玩家来说可能是个改变。对

[[spell:444088]]

的增强以及对

[[spell:370062]]

的改动使这个技能的价值飙升。你将目标是尽可能多地使用

[[spell:355913]]

来应对全队伤害，但这也意味着你需要维持

[[spell:355936]]

在玩家身上。虽然这个技能是你主要的治疗方式，但你仍然希望通过

[[spell:366155]]

在玩家身上维持

[[spell:1256577]]

并使用

[[spell:360995]]

来进行快速爆发和单体治疗。

:::

1.

### 至暗之夜 第2赛季套装

至暗之夜第二赛季的套装对于唤魔师的恩护专精来说相当直接，主要围绕[[spell:360995]]展开。套装奖励如下所列。

- [[spell:1296641]]——消耗[[spell:369297]]时，会对你的目标或附近的一名受伤盟友发射一道[[spell:361469]]。
- [[spell:1296642]]——[[spell:360995]]现在将提供一个[[spell:369297]]。此外，所有绿色法术现在恢复的生命值提高5%。

这套套装在很大程度上是被动的，会为你提供不错的治疗增益。在需要时，你可以使用[[spell:360995]]作为生成[[spell:369297]]的可靠手段。但在大多数情况下，你通常只需照常继续你的技能循环，只不过现在威力更强了。

1.

### 职业与专精机制详解

在本节中，将深入解释重要的机制、互动和游戏元素，以帮助你更好地理解如何在高水平上玩这个职业。

### 回响

3.1.

#### 回响

[[spell:364343]] 是 恩护 唤魔师 最核心的技能。当对盟友施放时，玩家将获得 [[spell:364343]] 增益。任何时候只要你有 回响 增益激活，你施放的下一个治疗法术也会同时施放在当时拥有 回响 的任何玩家身上。这不适用于 [[spell:363534]] 等主要冷却技能，但任何核心技能都可以 回响。

下面我们将分解你使用 [[spell:364343]] 的方式：

- **[[spell:366155]]**
  
  
  
  
  [[spell:366155]] 仍然是消耗 [[spell:364343]] 最常见和最强力的方法之一。虽然它提供了稳定的治疗来源，但它也受益于许多不同的天赋。具体来说：[[spell:378196]] 也会作用于任何从 [[spell:364343]] 获得 [[spell:366155]] 的目标，为这个技能增添更多威力。在大秘境和团队副本中，由于 [[spell:376239]]，它也已成为核心，让你能在许多不同目标上获得额外的治疗加成。
- **[[spell:1256577]]**
  
  
  
  
  在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，[[spell:1256577]] 是新的巅峰英雄天赋。这个技能由 [[spell:355936]] 和精华技能触发。它提供了相当大量的爆发治疗，而且完全可控，因为你可以通过 [[spell:355936]] 可靠地触发它。在 至暗之夜 中，这将是你在团队副本和大秘境中消耗 [[spell:364343]] 的最强选择之一。
- **[[spell:360995]]**
  
  
  
  
  没有 [[spell:373270]]，[[spell:360995]] 失去了一部分威力。随着其治疗量的增强，它仍然是爆发治疗的可靠选择，尤其在大秘境中。在团队副本中，它往往会落后于 [[spell:1256577]]，因为 Merithra 也会为玩家提供 [[spell:366155]] 的好处，让你同时获得两种治疗方式。但话虽如此，当你需要爆发治疗且在特定时刻无法使用 Merithra 时，它会很强大。
- **[[spell:355936]]**
  
  
  
  
  [[spell:355936]]通常落后于[[spell:366155]]，因为[[spell:366155]]提供的额外效果，而目前情况依然如此。它最大的价值在于大秘境环境中，你已经在大量玩家身上拥有逆转，因此对梦境吐息使用[[spell:364343]]，就相当于给团队施加了更多的HoT效果，使持续伤害更容易应对。
- **[[spell:355913]]**
  
  
  
  
  在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>), **[[spell:355913]]不再消耗回响。**这意味着你可以继续施放[[spell:355913]]而不会打断你正在进行的任何预铺。由于不再需要担心消耗你的[[spell:364343]]，许多流派现在在大秘境和团队副本中都会频繁使用这个技能。
- **[[spell:361469]]**
  
  
  
  
  只有在真正危急的单体治疗时刻，才应该用[[spell:361469]]消耗[[spell:364343]]。这绝不能在团队副本中使用，主要是在大秘境中你当时无法使用更强力法术的情况下。

虽然在[[spell:364343]]上花费精华很好，但你的大部分[[spell:364343]]来自[[spell:373861]]。无论你使用什么流派，尽可能多地按出这个技能都极其重要，不仅是为了回响，也为了护盾。

### 精华与精华迸发

3.2.

#### 精华与精华迸发

除了法力值外，恩护唤魔师还有精华作为需要管理的额外资源。与任何治疗职业一样，你会希望尽可能避免浪费精华，但有时在没什么事情发生的空闲期这是不可避免的。有三种不同的技能可以消耗精华：

- **[[spell:364343]]**
  
  
  
  
  消耗2点精华，[[spell:364343]]将是你消耗精华的主要方式。它是恩护唤魔师玩法的基础，让你能够执行大规模预铺或一次性输出大量治疗。
- **[[spell:355913]]**
  
  
  
  
  消耗3点精华，[[spell:355913]]为一名玩家及其效果半径内的其他玩家提供可观的治疗量。在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)中，当你点出[[spell:1242031]]天赋时，这个技能不再与回响直接竞争。这让你可以施放[[spell:355913]]而不会错过潜在的[[spell:364343]]增益。此外，翡翠之花 **将不再消耗已激活的[[spell:364343]]。**.
- **[[spell:356995]]**
  
  
  
  
  [[spell:356995]]是你通过精华造成伤害的方式。单看这个技能相当弱，但当与[[spell:372233]]天赋结合时，它成为一种不错的造成伤害、消耗额外精华并生成法力值的方式。在大多数团队副本流派中，你不会点这个天赋，意味着你几乎从不按[[spell:356995]]，但在大秘境中它是必备技能。

既然已经讨论了这些技能，现在重要的是讨论[[spell:369297]]以及它们是如何生成的。下面我们将讨论你需要记住的要点：

- **[[spell:361469]]与[[spell:366155]]**
  
  
  
  
  [[spell:361469]]和[[spell:366155]]在施放时都有机会生成一个[[spell:369297]]。通常你会发现空闲期使用[[spell:361469]]来输出伤害，因为用于进攻时会返还部分法力值，同时也让你有机会在空闲期生成精华迸发。[[spell:366155]]是我们最常用的技能之一，意味着你不断循环于消耗精华、生成精华迸发、然后消耗以继续这一过程。
- **[[spell:369939]]**
  
  
  
  
  点出[[spell:369939]]后，你的[[spell:357208]]会使你的下一个[[spell:361469]]对多个目标施放（根据你施放火焰吐息的等级增加）。施放满级的[[spell:357208]]接[[spell:361469]]是生成1-2个[[spell:369297]]的可靠方式。
- **[[spell:1236776]]**
  
  
  
  
  虽然并非所有流派都点，[[spell:1236776]]天赋由施放[[spell:370537]]或[[spell:359816]]触发。一旦触发，在短时间内你会生成更多的[[spell:369297]]。

消耗[[spell:369297]]时，有多个因素需要考虑。[[spell:355913]]和[[spell:356995]]的精华消耗为3点，而[[spell:364343]]只需2点。这使得用翡翠之花或裂解来消耗精华迸发更高效。

话虽如此，我们在团队副本中通常不施放[[spell:356995]]，这让选择变得更容易。[[spell:364343]]能帮助我们快速产出执行大规模预铺所需的额外回响，但同样需要考虑消耗。[[spell:355913]]的法力值消耗非常高，进一步提升了配合[[spell:369297]]触发时施放的效果。

更不用说，当你使用[[spell:1242031]]（在大多数流派中很常见）时，你实际上同时获得了[[spell:364343]]和[[spell:355913]]，这使它在大多数情况下都是正确的选择。当然，如果你的目标是快速执行预铺，直接施放[[spell:364343]]可能更快，但你仍需在方式和如何决定消耗你的[[spell:369297]]上保持灵活。

### 终极天赋 - 麦琳瑟拉的祝福

在至暗之夜中，你将获得[[spell:1256577]]，新的终极天赋。这个技能有3个独立等级，都会增强其威力。下面我们将逐一解析每个等级的效果：

- 等级1 — 消耗精华的技能有几率触发 [[spell:1256577]]，使你的下一个 [[spell:366155]] 发生变形。除了提供标准的 逆转 效果外，它还会改变图标，并产生类似活化烈焰（Spiritbloom）的效果，治疗会射出并弹跳至玩家。
- 等级2 — [[spell:366155]] 现在每点使受到的伤害降低1%，并改为每点为其恢复1%的生命值。这既是伤害减免也是治疗，其中伤害减免部分在伤害统计中显示为吸收效果。
- 3级 — [[spell:355936]]的即时治疗量大幅提升，每次施放都会触发[[spell:1256577]]，让你每次施放梦境吐息都能可靠地触发被动效果。

[[spell:1256577]] 是一个极其强大的技能，能大幅增强 [[spell:366155]] 的威力。主要由于等级2的存在，你需要确保尽可能频繁地让尽可能多的玩家拥有 逆转。由于麦琳瑟拉的祝福在所有 逆转 效果之外还提供了一大波治疗，你可以配合 [[spell:364343]] 使用获得双重收益，这也是你在 至暗之夜 中使用 [[spell:364343]] 的主要方式。

1.

### 恩护唤魔师的重要冷却技能

### [[spell:370537]]

4.1.

#### 静滞

[[spell:370537]]是团队副本和大秘境中都极为强大的冷却技能。激活后，这个冷却会存储你接下来施放的3个治疗法术。伤害法术或像[[spell:363534]]这样的主要冷却技能不会被存储。你有无限时间来存储法术，但一旦存储了3个法术，你只有30秒时间重新激活该技能，否则它会自动重新激活。

需要注意的是，你存储技能的顺序就是重新激活技能时它们施放的顺序。这对[[spell:373861]]尤为重要。如果你在[[spell:370537]]开始时施放[[spell:373861]]，那么免费的回响会被你的下一个法术立即消耗。

因此，最好始终以[[spell:373861]]来结束你的[[spell:370537]]，而不是过早施放而浪费回响。

下面我们将解析一些你可能会看到的常见[[spell:370537]]：

- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者：[[spell:355936]]、[[spell:355936]]、[[spell:373861]]。由于你可以通过[[spell:1264269]]拥有两层梦境吐息充能，你希望每次使用静滞时都存有两层充能，为你提供强大的爆发性HoT覆盖和保证触发的[[spell:1256577]]。
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫：[[spell:355936]]、[[spell:373861]]、[[spell:355913]]。这个组合为你提供保证触发的[[spell:1256577]]和额外的[[spell:364343]]，帮助启动新一轮预铺。
- 大秘境AoE爆发：[[spell:355936]]、[[spell:373861]]、[[spell:360995]]。使用这个组合为你提供即时的全团爆发和一个[[spell:1256577]]触发，之后可用于更多团血治疗。
- 开怪前技巧：[[spell:373861]]、[[spell:373861]]和[[spell:373861]]。如果在拉Boss前立即使用会很有用，让你在战斗开始时快速为团队生成大量护盾。请注意，你只应施放前2个[[spell:373861]]，等到拉怪时再施放第3个，这样你的[[spell:370537]]就不会提前过期。

同样重要的是要注意，[[spell:370537]]会保留你最初施放治疗法术的目标。换句话说，如果我在静滞存储阶段对我的共同治疗者"Youtee"施放[[spell:355913]]，当我重新激活静滞时，该技能会再次对"Youtee"施放。

### [[spell:363534]]

4.2.

#### 回溯

[[spell:363534]]应在承受极高伤害窗口后使用。它的治疗量取决于你在过去5秒内承受的伤害量，意味着你的团队或小队承受的伤害越多，它治疗得就越多。这个冷却技能是为数不多的真正紧急按钮之一， [恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>)；你应该在真正危急的情况下尽可能好好使用它。

玩家最常犯的错误之一是捏着[[spell:363534]]太久。虽然它是一个极其强大的冷却技能，但你仍应力求在任何时候落后时都使用它。在你开始吃力时主动使用它，可以防止你之后手忙脚乱地追赶。

### [[spell:359816]]

4.3.

#### 梦境飞行

[[spell:359816]]是一个强大的冷却技能，但与[[spell:370537]]共享选择节点，这使它出现得少得多。对于不想应对[[spell:370537]]机制的玩家来说，它可能是一个可行的选择，但通常会更差。

[[spell:359816]]有两个主要机制需要记住。首先，当你飞过玩家时，它会在初始施放时产生大量治疗。这意味着你应该力求在能从初始治疗部分获得强大价值的情况下使用它。

此外，它会在被击中的玩家身上留下一个持续时间很长的HoT，意味着它可用于延长的伤害窗口。理想情况下，你应在治疗的两个部分都强力的情况下施放这个技能，但这并非总能实现，你仍应力求尽可能多地使用该技能。

### [[spell:370553]]

4.4.

#### 扭转天平

[[spell:370553]]的大部分价值来自 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫。虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者仍可使用，唯一的收益在于能够快速打出满级蓄力技能。

作为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫，你将获得[[spell:431695]]，它为你提供大量急速、移动速度和冷却缩减，且每秒递减。由于大部分威力是前置的，你希望确保在困难的移动过程中立即使用这个技能以大幅增强你。因为[[spell:1260484]]也会将持续时间减少30秒，且增益本身的持续时间很长，频繁使用它很重要。

### [[spell:374227]]

4.5.

#### 微风

[[spell:374227]]使你和你最近的4名盟友在8秒内受到的范围伤害降低20%。由于它只针对你最近的4名盟友，在大秘境中比团队副本更容易使用。然而，当你知道接下来几秒内会承受大量AoE伤害时，仍需主动使用它。并非所有伤害事件都被视为AoE，因此你必须很好地了解你将承受的伤害类型，以确保不浪费该技能的效果。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月13日：** 添加了关于内在火焰的信息。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** 添加了额外的循环信息。
- **2026年3月20日：** 为翡翠之花和青翠之拥添加了额外信息。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月31日：** 翡翠之花配装已更新。
- **2025年8月29日：** 生命缚者信息已更新。
- **2025年8月9日：** 循环更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 塑焰者输出循环已针对11.1版本更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024 年 10 月 7 日：** 时空守卫回响配装的输出循环已更新。
- **2024年9月9日：** 已针对《地心之战》第1赛季更新。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月16日：** 输出循环变更。
- **2024年1月15日：** 输出循环已针对10.2.5更新。
- **2023年11月6日：** 已更新至10.2。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年8月8日：** 为翡翠之花输出循环添加了额外信息。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 输出循环已针对10.0.5更新。
- **2022年12月28日：** 输出循环已更新，加入了翡翠之花与逆转配装之间的差异。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 装备选择

在此页面上，你将找到《魔兽世界》12.1.5中你的恩护唤魔师的最佳装备、饰品和毕业物品推荐。从制造物品到如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 恩护唤魔师毕业装备指南

欢迎来到我们的恩护唤魔师装备页面至暗之夜。查看此页面，了解关于为恩护唤魔师配装所需的一切，包括来自所有来源、团队副本和大秘境的毕业装备、最佳饰品、套装等信息。请注意，随着至暗之夜的到来，属性将被压缩，意味着每件物品提供的属性将比以前显著减少。你的整体伤害和治疗也会因此降低。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含恩护唤魔师来自所有来源的最高HPS配置。请注意，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [QuestionablyEpic](<https://questionablyepic.com/>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你可以将任何物品转化为套装件，并且它会保留原有的属性和效果！这意味着你的散件不再那么重要。

[[item:268231]]

,

[[item:271876]]

，以及

[[item:268237]]

由于其更高的物品等级，将始终被优先选择，但你剩余的2个套装槽位可以根据你拥有的装备进行更换。

- **头部：** [[item:159374]]来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **肩部：** [[item:268231]]来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **胸部：** [[item:271876]]来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **手部：** [[item:281238]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **腿部：** [[item:268237]]来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 常见问题：从宏伟宝库中获取什么？
由于 [混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可以从宏伟宝库中获取而非物品，你将优先在第一次开库时获取这些额外奖励次数。这将允许你对任何副本或首领进行额外奖励抽取，并获得该物品的1/6史诗难度版本。因为 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 掉落我们从英雄难度获得神话级[[item:271092]]，你会优先使用额外拾取来获得这个毕业物品，远在你有机会击杀史诗难度Boss之前。通过额外拾取Boss，你还可以获得[[item:268265]]和[[item:271876]]。请注意，史诗难度掉落的物品将是9/6，而额外拾取的物品上限为6/6。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护腕</th><td>[[item:268217@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:251191@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含恩护唤魔师来自所有来源的最高HPS配置。请注意，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [QuestionablyEpic](<https://questionablyepic.com/>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你可以将任何物品转化为套装件，并且它会保留原有的属性和效果！这意味着你的散件不再那么重要。

[[item:268231]]

,

[[item:271876]]

，以及

[[item:268237]]

由于其更高的物品等级，将始终是首选，但如果你无法从团队副本获得这些物品，你可以改从大秘境获得以下物品：

- **头部：** [[item:159374]]来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **肩部：** [[item:239049]]来自 [诸王之眠](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- **胸部：** [[item:159370]]来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- **手部：** [[item:251165]]来自 [夺目谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- **腿部：** [[item:159375]]来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)

:::

:::details 提示我应该刷哪些地下城？
如果你的游戏时间有限，我们建议刷取以下地下城：

- [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)：掉落最佳副本饰品之一：[[item:250214@JAACAAgNyA]]。
- [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)：掉落许多你可以催化成套装的好物品。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>项链</th><td>[[item:251142@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>腰部</th><td>[[item:251155@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>脚部</th><td>[[item:159388@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:250214@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></div></td></tr><tr><th>护腕</th><td>[[item:273775@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></div></td></tr><tr><th>饰品</th><td>[[item:250215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:160216@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:251191@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">夺目谷</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含恩护唤魔师来自所有来源的最高HPS配置。请注意，还有许多其他配置在误差范围内表现相当。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [QuestionablyEpic](<https://questionablyepic.com/>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

:::details 常见问题我需要哪些套装部件？
在至暗之夜第2赛季中，你可以将任何物品转化为套装件，并且它会保留原有的属性和效果！这意味着你的散件不再那么重要。

[[item:268231]]

,

[[item:271876]]

，以及

[[item:268237]]

由于其更高的物品等级，将始终被优先选择，但你剩余的2个套装槽位可以根据你拥有的装备进行更换。

- **头部：** [[item:251220]]来自 [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- **肩部：** [[item:268231]]来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- **胸部：** [[item:271876]]来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- **手部：** [[item:281238]]，来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)
- **腿部：** [[item:268237]]来自 [盘卷祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)

:::

:::details 提示：我最想要哪些团队副本物品？
如果你需要向团队领袖提交一份重要物品清单，或者只想专注于最重要的Boss和物品，我们已经为你准备好了！

- [[item:271876]]：你会催化的奇物胸甲。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:271092]]：来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>).
- [[item:270162]]：极其强大的饰品，掉落自 [盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>).
- [[item:270164]]：第二好的饰品。掉落自 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271501@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271502@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]][[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268254@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></div></td></tr><tr><th>护肩</th><td>[[item:271499@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:244021]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271500@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:240155]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268233@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></span><span>[[item:243983]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271504@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> + <a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">万毒邪祟者瓦什尼克</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243959]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270162@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">盘魂者内克扎莉</a></div></td></tr><tr><th>护腕</th><td>[[item:268217@JAACAAgNyA]]&#10;&#10;<div>[[item:240898]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide#nymrissa" rel="noopener noreferrer">尼姆瑞莎·唤波者</a></div></td></tr><tr><th>饰品</th><td>[[item:270164@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/preservation-evoker-pve-healing-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:268197@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/entombed-sentinels-raid-guide" rel="noopener noreferrer">陵寝哨兵</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 饰品推荐：恩护 唤魔师

一如既往，你应该咨询 [QELive](<https://questionablyepic.com/live/>) 来确定你的最佳饰品，因为列表经常随着调整而变化。然而，本赛季你将希望使用[[item:270162@JAACAAgNyA]]和[[item:270164@JAACAAgNyA]]。两件来自新团队副本的极其强大的饰品。大秘境饰品相比之下不幸地有些被低估，但你确实有一些不错的选择可以在努力获取团队副本毕业饰品期间使用。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **恩护唤魔师毕业饰品**
**毕业装备 -** [[item:270162]]和[[item:270164]]。

**荣誉提名 -** [[item:250214]].

:::

要直接比较饰品，请使用
[QELive](<https://questionablyepic.com/live/>)。我们将在此列出一些特殊饰品及其强度水平的评论。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 恩护唤魔师饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270162]]</li>&#10;<li>[[item:270164]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270167]]</li>&#10;<li>[[item:250214]]</li>&#10;<li>[[item:248583]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:270169]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:249343]]</li>&#10;<li>[[item:249811]]</li>&#10;<li>[[item:251792]]</li>&#10;<li>[[item:274493]]</li>&#10;<li>[[item:273796]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250248]]</li>&#10;<li>[[item:250255]]</li>&#10;<li>[[item:268292]]</li>&#10;<li>[[item:264507]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250254]]</li>&#10;<li>[[item:270171]]</li>&#10;<li>[[item:264701]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

一般来说，有相当多的饰品处于相似的强度水平。同一层级中的任何饰品彼此大致相等。这意味着饰品的物品等级相当重要。F级饰品之所以在那里，是因为它们只比空的饰品槽位好一点。

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 可用于从特定首领或副本获取特定物品，通过让你从特定掉落位置获得一件保证的战利品。获得的物品是随机的，但一旦通过这种方式获得了一件物品，你下一次使用虚空核心将获得你尚未获得的剩余物品之一。

随着12.1.5补丁的发布，你可以从
**奥琳·微光** 在银月城，紧邻转化器。

**请注意，通过掉落或 [大秘境宝库](<https://www.icy-veins.com/wow/great-vault-guide>) 获得物品不会将其从你的额外拾取池中移除。**

3.1.

#### 恩护唤魔师的推荐虚空核心使用方案

对于你的虚空核心和制造，你可以采取几种不同的路线。这些主要是赛季初期的问题，如果你在赛季后期才选择这个专精，那么你在两者的选择上都会有更大的自由度。 **在赛季初期对大秘境使用额外奖励次数是一个巨大的战力损失。**

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **团队副本虚空核心优先级**
- 英雄难度（或史诗难度） [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 直到你获得[[item:271876]]、[[item:271092]]和[[item:268265]]。
- 英雄难度（或史诗难度） [盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 直到你获得[[item:270162]]。
- 然后：填补你还没有神话级物品的插槽。你可以使用QE Live来获取每个Boss和副本的平均额外拾取价值。

:::

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **大秘境/英雄难度团队副本虚空核心优先级**
- [夺目谷](<https://www.wowhead.com/achievement=61641>) - [[item:250214]]（不错）
- [塞塔里斯神庙](<https://www.wowhead.com/achievement=12504>) - 多件好物品

:::

如果你是一个全新角色，你仍然希望优先使用额外奖励次数
[乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 以获取关键物品。从那里开始，通常使用额外奖励次数抽取 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>) 由于掉落的物品数量众多，以及三个你可以立即催化的强力套装插槽。虽然这可能意味着你无法立即获得最强力的饰品，但它可能是快速为角色配装的最佳方式。否则，你可以改为额外拾取英雄/史诗
[盘魂者内克扎莉](<https://www.icy-veins.com/wow/nekzali-raid-guide>) 或 [迷失的探险者](<https://www.icy-veins.com/wow/lost-explorers-raid-guide>).

3.2.

#### 晋升毒液石

使用[[item:280562]]的优先级将始终是你的 **武器。**
这为你提供最大的战力提升。从那里你可以专注于饰品，然后是你的副手。顺序与你在赛季初花费纹章的方式非常相似：

1. 武器
2. 饰品
3. 副手

你应该始终优先选择史诗难度物品，除非在你短期内无法获得史诗难度版本的情况下。

1.

### 恩护唤魔师最佳制造物品

专业是使用你的最佳副属性配装的好方法，因为在制造过程中添加特殊物品可以让你选择确切的副属性。

由于我们的额外拾取策略侧重于尽早获得主手武器，我们推荐的制作顺序将侧重于获得一个 **副手** 。之后你会想要制作一件带有[[item:240167]]的物品。如果你决定不遵循推荐策略而不制作副手，你只需早期制作两件带有[[item:240167]]的物品。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **恩护唤魔师制造装备优先级**
- [[item:245769]]搭配[[item:245876]]
- [[item:244584]]搭配[[item:240167]]
- [[item:244577]]搭配[[item:240167]]
- 任何你尚未获得神话级的物品。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 恩护唤魔师最佳纹饰

你的两件制造装备中最多可以有两件被 **美化**。这与的概念类似 **唯一装备**，因为你只能穿戴两件具有美化状态的物品。一些制造物品，其中许多默认就具有强大的触发效果或有益效果，被视为美化物品。你也可以从各种专业中添加美化到任何制造物品上，在制作时或稍后阶段将该效果添加到该物品上。

我们倾向于建议早期制造武器槽位，因为它们在新赛季开始时会提供最大的初始战力，但它们不会是你整体的毕业物品。一般来说，你的毕业装备将是：

- [[item:244584]]搭配[[item:240167]]
- [[item:244577]]搭配[[item:240167]]

4.2.

#### 为装备添加插槽

你可以使用[[item:275707]]消耗品为头盔、腰带和护腕添加插槽，如果你在宏伟宝库中没有选择任何选项，就可以获得它。不选择选项会奖励你代币，其中六个可以兑换[[item:275707]]物品。这使你可以在第二赛季获得上述装备时为其添加插槽。

1.

### 纹章使用

在赛季初期，或者如果你刚开始玩一个副角色，你能够获得的升级纹章（如 [秘境雾崖](<https://www.wowhead.com/currency=3446>)。这些可以用来 [ 升级装备](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
到更高的物品等级。由于纹章每周获取量有限，而且升级不同物品所花费的纹章数量相同，你应该优先将纹章用在那些你短期内不打算更换的物品上，或是能带来最大收益的物品上。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **恩护唤魔师纹章升级优先级**
**武器栏位** ➜ **特效栏位** ➜ **头盔/胸甲/腿甲** ➜ **饰品** ➜ **肩部/手套/腰带/靴子** ➜ **其余部位**

:::

如前所述，你应该优先升级你确定不会替换的装备。如果你有一件神话级轨的毕业头盔，它会优先于一件非毕业的英雄级轨饰品。上述顺序假设所有装备都是神话级轨。

1.

### 评估升级

在本页面和我们指南的其他地方，我们经常提到在 QE Live 上进行自我模拟的重要性。这是因为每个角色都是独一无二的，你能获得的每件装备都可能改变你现在最适合的装备搭配。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** BiS列表已针对12.1.5版本更新。
- **2026年10月1日：** 对大秘境装备推荐进行了微小修正。
- **2026年8月25日：** 为额外拾取策略添加了额外信息。
- **2026年8月17日：** 对饰品梯队进行了小幅更新。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月31日：** BiS饰品和饰品强度列表已更新。
- **2026年3月23日：** 饰品天梯榜已更新。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月14日：** 更新了饰品推荐。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7补丁更新。
- **2025年5月13日：** 困惑的卡特尔芯片推荐已更新。
- **2025年4月21日：** 页面已针对11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 添加了Cyrces Circlet的信息。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 添加了第1赛季毕业装备。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月29日：** 最佳配装列表小幅更新。
- **2023年11月7日：** 针对孢子斗篷削弱更新了美化和最佳配装列表。
- **2023年11月6日：** 已更新至10.2。
- **2023年9月4日：** 添加了最佳配装。
- **2023年7月19日：** 饰品天梯榜已更新。
- **2023年7月17日：** 饰品天梯榜已更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月26日：** 添加了关于时光漫游饰品的信息。
- **2023年5月20日：** 根据漏洞修复更改了美化装备建议。
- **2023年5月16日：** 美化推荐已更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月28日：** 更新了原初宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月13日：** 添加了巧思火花制作建议。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 属性优先级

在此页面上，你将找到你的恩护唤魔师的最优属性优先级。我们首先呈现属性优先级，然后深入解释属性如何与你的专精和玩法互动。我们的内容已更新至《魔兽世界》12.1.5补丁。

1.

### 唤魔师的恩护专精属性优先级

属性优先级 [恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) 无论选择什么内容，都将保持相当一致。精通为你提供最大的治疗提升，而其他属性提供的治疗提升稍少，但也会增加你的伤害输出。优化装备时，你通常会追求尽可能多的精通，同时保持其他副属性的平衡。

无论你玩的是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫还是 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者流派，你的属性优先级都保持不变。重点将继续放在最大化精通上。

智力

精通

暴击

急速

全能

在 [秘境+](<https://www.icy-veins.com/wow/dragonflight-mythic-season-4-guide>)中，你的属性优先级不会改变，但你对如何分配属性有更多选择。精通继续提供每点最大的治疗提升，但它不提供任何伤害。如果你发现自己处于治疗量超过需求并希望优化伤害的情况，你可以选择牺牲一些精通以换取暴击或急速。

1.

### 深入属性解析

如果你的目标是真正优化你的装备和表现，了解每个属性的影响至关重要。下面我们将分解每个属性的影响。

- **精通** — [恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>)的[[spell:363510]]会在你的最大生命值百分比高于你尝试治疗的目标时提高你造成的治疗量。虽然这个属性本身相当不错，但重要的是要记住它不提供 **任何** 伤害加成，这会降低它在伤害输出很重要的内容中的价值。每一个其他次要属性都会增加你的伤害，即使只是略微高于0，而精通不会。
- **急速** — 游戏中的许多法术都“随急速缩放”。这意味着当你获得更多急速时，它们的冷却时间会缩短。对于恩护 唤魔师来说，这最显著地适用于[[spell:373861]]和[[spell:360995]]。你拥有的急速越多，这些技能的冷却时间就越短。
- **暴击** — 使你的法术和攻击有更高的几率造成额外的治疗或伤害。[[spell:366155]]在暴击时还会延长其持续时间。在玩 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫时，英雄天赋[[spell:431874]]会使[[spell:355936]]和[[spell:357208]]的持续时间通过暴击得到延长。
  
  
  
  
  需要注意的是，到目前为止列出的所有技能的持续时间延长都有上限，以防止无限持续时间。此外，我们很大一部分的治疗无法暴击。例如，[[spell:373861]]无法暴击，这降低了该属性的整体价值。
- **全能** — 到目前为止最不有趣的属性，它少量增加治疗和伤害输出并减少受到的伤害。不幸的是，这个属性无法与替代选项相比。在非常高的大秘境中，你可能会看到玩家堆叠更多的全能来承受原本会秒杀他们的极高伤害，但大多数玩家不会遇到这种情况。除了这种情况外，你通常会避免以全能为目标选择装备。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年5月3日：** 推荐属性已更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 页面已针对11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月28日：** 在属性优先级中，将急速移至暴击之下。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 附魔与消耗品

在本页中，我们列出了你的恩护 唤魔师可以获得的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

重要的是，在其中一个插槽中，你应始终使用 [[item:240968]] 或 [[item:240983]]。泰卢瑞克会提供更多法力，但会牺牲一些主属性。总体而言，差距非常小，你可以根据自己的舒适程度来选择，或者选择制作或购买成本更低的宝石。

在大秘境中，你对法力的需求可能较低，因为你可以在拉怪间隙喝水。而在团队副本中，额外的法力在战斗艰难且战斗结束前就耗尽法力时会非常有价值。

当使用 [[item:240968]] 时，你希望装备中有尽可能多的不同颜色宝石。这意味着你应该使用以下每种各一个：

- [[item:240900]]
- [[item:240908]]
- [[item:240892]]
- [[item:240917]]

对于剩余的宝石插槽，当你使用 [[item:240983]] 时，你应该使用 [[item:240900]]。话虽如此，你应该继续参考
[QuestionablyEpic](<https://questionablyepic.com/>) 以真正优化你的宝石。

1.

### 最佳附魔和武器强化

恩护 唤魔师 的最佳武器油是 [[item:243733]]。副属性的提升在所有内容中都能带来不错的加成，而替代品 [[item:243735]] 的强度不足以值得使用。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>最佳附魔</th>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243951]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244021]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243977]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>&#10;<ul>&#10;<li>[[item:240155]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>靴子</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243983]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243959]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

1.

### 最佳消耗品

合剂、食物、药水，甚至武器油等消耗品可以显著提升你的能力，在进行有挑战性的内容时值得使用。如果金币不是问题，你可以选择始终使用它们！

3.1.

#### 合剂

[[item:241322]] 将是你最大化治疗输出的首选。在不需要额外治疗的大秘境等情况下，你可以选择使用 [[item:241325]]。

3.2.

#### 药水

在 至暗之夜 中有两种药水值得考虑：[[item:241288]] 和 [[item:241301]]。需要注意的是，这些药水共享冷却时间。使用其中一种会使其他所有药水进入冷却。在任何需要注意法力的情况下，你都应只使用 [[item:241301]]。当你不需要法力时，可以改用 [[item:241288]]。

确保随时在身上备有 [[item:271883]]。这些药水与战斗/法力药水不共享冷却时间，这意味着当你需要为自己进行紧急治疗时，可以随时使用它们。

3.3.

#### 食物增益

你应该食用 [[item:242747]] 作为理想的团队盛宴，或使用 [[spell:1278895]] 作为个人食物。这些会为你提供主属性加成，胜过任何其他食物选择。

3.4.

#### 强化符文

[[item:259085]] 提供约 1% 的治疗量提升，在开荒时值得评估，尤其是在接近关键击杀时。不过它们可能相当昂贵，所以在真正需要时再谨慎使用。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月20日：** 武器附魔推荐已更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 页面已针对11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月30日：** 消耗品推荐已更新。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 针对10.2.6补丁进行了审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月21日：** 武器附魔推荐已更改。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月28日：** 更新了原初宝石推荐。
- **2023年3月20日：** 已为10.0.7补丁更新。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月28日：** 消耗品/附魔已更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 大秘境

在本攻略中，你将找到在《魔兽世界》12.1.5 版本中使用 恩护 唤魔师 挑战大秘境地下城的技巧和建议。

1.

### 恩护 唤魔师 在 至暗之夜 第2赛季的大秘境

在本指南中，我们将讨论如何在大秘境地下城中充分发挥你的唤魔师的潜力，包括设置角色的最佳方式、你的输出循环可能如何变化，以及最优化使用技能的提示和技巧。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

恩护 唤魔师 拥有所有治疗职业中最高的伤害和治疗量之一。话虽如此，它的治疗可能比其他职业更困难，需要一些练习和学习才能完全掌握。

1.

### 最佳大秘境天赋配置

无论你是只打每周的+10钥匙，还是冲高层内容，你的天赋构建都将围绕 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者。塑焰者 目前提供最高的治疗和伤害输出，并以 [[spell:444322]] 的形式提供独特的功能性。

默认 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 大秘境天赋构建
![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 大秘境天赋构建

### 默认 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 大秘境天赋构建

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 大秘境天赋构建

随着 [12.1版本](<https://www.icy-veins.com/wow/midnight-patch-12-1-guide>), ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 已成为 恩护 更优的英雄天赋选择。[[spell:355936]] 和 [[spell:444088]] 获得了显著增强，加上新的 [[spell:1296641]] 和4件套奖励， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 已经脱颖而出。

除了更高的强度外，你还将获得 [[spell:1264269]] 和 [[spell:444322]]。拥有两层 [[spell:355936]] 将为你的治疗提供更多灵活性，而 [[spell:444322]] 将允许你将 [[spell:363916]] 施放在一名玩家身上。这为你提供了一个额外的防御性冷却技能，在大秘境环境中非常有价值。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAjZgFwCYGmAbM2MMAmZGD"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVlu8qosgYsJAA4877AWSC-AAAA-TKMIgpZRxogwBA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 大秘境天赋构建

2.2.

#### 默认 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 大秘境天赋构建

虽然 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/flameshaper.webp>) 塑焰者 已经脱颖而出， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 对于喜欢这种玩法风格的玩家来说仍然是一个可行的选择。[[spell:370553]] 通过 [[spell:431695]] 继续作为一个强大的冷却技能，为你提供额外的急速、冷却缩减和移动速度。此外，[[spell:431442]] 通过 [[spell:1296641]] 和4件套奖励获得了额外的强度。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/chronowarden.webp>) 时空守卫 可能不会提供相同的伤害或治疗加成，但由于急速加成，它的节奏要快得多。拥有 [[spell:429483]] 也总是有益的。

**务必使用'导出天赋'按钮，将最佳配置直接导入你的游戏中！**

:::talents 天赋构筑
```json
{
  "code": "CwbBAAAAAAAAAAAAAAAAAAAAAAAAAAAmZmZ2WGzYYmxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMjxMzAAwYGbsADMDDNYsAjZGgxA"
}
```
:::

:::details 来源计算器编码
```
#8W-TaSsFLLKbIIHjZBYYuloXqqPpEiihnNeMg-lEkjDFQiCUVliiu8qosgYsJAA4877AG-AAAA-OUaAQYMIMUIYpA-
```

:::

1.

### 功能技能与能力

### 眩晕和打断

3.1.

#### 眩晕与"打断"

- [[spell:372048]] 可用于延长队友施放的控制效果的持续时间。在队友使用群体眩晕（例如 武僧 的 [[spell:119381]]）之前使用此技能，将使眩晕效果持续更长时间。得益于职业天赋树中的 [[spell:374346]] 天赋，此技能甚至可用于驱散小怪的狂暴效果。
- [恩护 唤魔师](<https://www.icy-veins.com/wow/preservation-evoker-pve-healing-guide>) 还可以同时携带定身和眩晕技能，让你的坦克和队伍在应对高难度怪物群时轻松得多。[[spell:358385]]可以用来定身敌人，而[[spell:357210]]可以在你从职业天赋树中点出[[spell:371032]]被动后用来眩晕他们。
- 值得一提的是，[[spell:357214]]和[[spell:368970]]这两个种族技能也可以用来将敌人击飞，并将他们击退远离你。

### 其他功能

3.2.

#### 其他功能

- [[spell:390386]]为你的队伍提供[[spell:80353]]/[[spell:2825]]效果。唯一能带来这一巨大增益的其他治疗职业是萨满祭司。
- [[spell:370665]]可以让你抱起一名盟友并将他们带到你光标所在的位置。如果盟友在应对某个机制时难以跑位、需要集合，或者仅仅需要一点移动加速，这个技能真的能帮他们到达需要的位置。

1.

### 应对词缀

至暗之夜 第2赛季只有四个重要的 词缀 提供任何反制手段，称为萨拉塔斯的交易。这些每周轮换，一次只有一个生效。许多大秘境词缀，如强韧或残暴，只是给钥石添加一个被动效果，只有这四个例外是本赛季以萨拉塔斯为主题的：

- [萨拉塔斯的交易：扬升](<https://www.wowhead.com/mythic-affix=148>)：将刷新三波宝珠，需要被打断或干扰。[[spell:368970]]和[[spell:357214]]在应对这一机制时会非常有用。
- [萨拉塔斯的交易：虚缚](<https://www.wowhead.com/mythic-affix=158>)：一个 虚空大使 增援将会刷新，需要被设为焦点目标并打断。治疗者通常无法在此词缀上提供帮助，除了对其造成少量额外伤害。
- [萨拉塔斯的交易：脉冲](<https://www.wowhead.com/mythic-affix=162>)：光球会在玩家周围刷新并绕着他们转。你有 15 秒的时间来吸收所有这些光球以增益你的队伍。虽然并非必须，但治疗者通常非常擅长四处跑动并吸收未被吸收的光球，这样输出职业就可以站着不动保持输出。当然，你不会想在治疗压力大的时候这样做。
- [萨拉塔斯的交易：吞噬](<https://www.wowhead.com/mythic-affix=160>)：所有小队成员都会受到一个治疗吸收效果的影响。该效果可以被驱散，你需要确保尽快驱散那些无法自行解除该效果的玩家，以便完成2次驱散。这样你只需要专注于清除少数几名玩家的负面效果。[[spell:374251]]也可以用来额外驱散一个负面效果。

如果这些词缀没有被处理，它们会增强敌方小怪和首领。然而，当你能够处理它们时，它们会为你的整个团队提供有益的增益，提高你的输出或生存能力。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月11日：** 小幅更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 页面已针对11.1.5补丁更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月28日：** 添加了特定地下城的提示。
- **2024年9月9日：** 已添加第1赛季信息。
- **2024年8月17日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月20日：** 页面已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 页面已针对第4赛季更新。
- **2024年3月19日：** 天赋推荐已针对10.2.6更新。
- **2024年1月15日：** 配装推荐已针对10.2.5更新。
- **2023年11月6日：** 已更新至10.2。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月17日：** 天赋推荐进行了小幅调整。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年7月8日：** 天赋推荐已更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月31日：** 天赋推荐略微更新。
- **2023年1月24日：** 天赋已针对10.0.5更新。
- **2022年12月28日：** 天赋构筑已更新。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::

## 宏与插件

在本页中，你可以找到一些实用的宏命令和插件，帮助你在魔兽世界12.1.5版本中游玩你的恩护唤魔师时更加轻松。

1.

### 最佳宏

自巨龙时代发布以来，你获得了启用鼠标悬停施法的选项。这将使你的技能在你按下技能时治疗你的光标当前悬停的目标。这将省去你为每个技能创建许多鼠标悬停宏的麻烦。请注意，许多玩家在启用鼠标悬停后需要关闭“自动对自己施法”设置；否则每个法术都会施放在你自己身上。

如果你长期使用宏并更喜欢它们而不是新的游戏内选项，你可以复制以下宏并为每个你想要做宏的法术进行调整：

#### 翡翠之花 宏

```wow-macro
#showtooltip
/cast [@mouseover, help, nodead] [] 翡翠之花
```

这个宏会对你鼠标悬停的目标施放法术；如果他们已死亡或你没有目标，它会改为对你自己施放。

1.

### 最佳插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.1.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.2.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.2.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.2.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.2.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.3.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.3.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.3.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.3.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### Harreks高级团队框架

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，许多插件、WeakAuras以及整体功能已被移除。 [Harreks高级团队框架](<https://www.curseforge.com/wow/addons/harreks-advanced-raid-frames>) 让你恢复部分团队框架的功能，允许你完全自定义在框架上可以看到和不能看到哪些增益，以及增益出现的具体位置。没有这个插件，无论你下载哪个插件，都无法完全自定义你的团队框架。

值得庆幸的是，Harreks Advanced Raid Frames 可以与大多数团队框架插件配合使用，让你两全其美。如果你有其他问题或需要帮助，可以访问 Harreks 的 discord， [Spiritbloom.Pro](<https://discord.gg/spiritbloompro>).

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 页面已针对《地心之战》进行审查和更新。
- **2024年7月23日：** 已为《地心之战》前夕补丁审核。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已针对10.2补丁进行审查
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年11月15日：** 页面已添加。

显示更多

显示更少

:::
