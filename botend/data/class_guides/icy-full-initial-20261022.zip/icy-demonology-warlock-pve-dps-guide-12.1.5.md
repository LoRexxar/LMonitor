## 来源与翻译说明

本篇由 Icy Veins 原文完整翻译整理。原作者：Motoko。

来源：[Icy Veins 原文](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-guide>)；[公开转载与翻译条款](<https://www.icy-veins.com/faq>)。仅供非商业阅读，版权归原作者及 Icy Veins 所有。

翻译整理：本站。各章节原文链接如下：

- [专精概览](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)

## 专精概览

欢迎阅读我们的《魔兽世界》12.1.5版本 术士 恶魔学识 指南。在这里，你将学习如何在团队副本和大秘境中扮演 术士 恶魔学识：从入门到最大化你的DPS。

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

恶魔学识 大秘境资源

[最新！顶级 恶魔学识 天赋构筑](<https://raider.io/specs/demonology-warlock/talents>)

[顶级 恶魔学识 大秘境玩家](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/warlock/demonology>)

[恶魔学识 大秘境热力图](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=warlock--demonology>)

[热门 恶魔学识 团队组合](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=warlock--demonology>)

1.

### 恶魔学识 术士 概述

恶魔学识 术士 是一个多功能专精，核心玩法是召唤大量可消耗的仆从为你作战，并在间隙生成资源。虽然该专精需要一定的预热时间，但一旦全速运转起来，手感相当流畅且迅速。恶魔学识 术士在移动模式稳定的战斗中表现尤为出色，而非那些移动混乱无序的战斗。

与所有 术士 专精一样，恶魔学识 带来了[[spell:111771]]，这是一个强大的团队冷却技能，可以立即将你的整个小队传送40码。

强大的单体与顺劈伤害

恶魔学识 术士 拥有出色的单体伤害和强大的范围伤害，但代价是几乎没有集中输出能力、换目标能力较差，且完全缺乏分散顺劈能力。顶峰天赋为该专精带来了大量强度，但不幸的是也带来了输出上的较大波动性。

高性能主力专精

在 至暗之夜 中，恶魔学识 术士 拥有不错的单体伤害，可以相对轻松地使用额外的顺劈法术，冷却技能强大且机动性足够。顶峰天赋为这个此前几乎没有波动性的专精引入了一些变数，而灵魂收割者增加了更多波动，恶魔使徒 则是那个一如既往可靠的选择。

出色的伤害输出

恶魔学识 在大秘境中的伤害表现非常扎实，提供强大的单体和集中顺劈能力，同时保持一定程度的机动性。然而顶峰天赋的波动性在这里会达到最差，因为部分召唤物带来卓越的范围伤害，而另一些则更偏向单体。

除此之外，至暗之夜 为 术士 职业带来了很多实用性，包括诅咒和AoE诅咒，以及所有职业中最高的生存能力之一。

高功能性

[[spell:111771]]在团队副本环境中大多数时候是必备的，而[[spell:20707]]和[[item:5512]]则提供了不错的便利性。

在地下城中情况则有所不同，传送门用于罕见的跳怪场景，灵魂石是一个需要施法时间的战斗复活，而治疗石则只是更好的药水。

诅咒的处境有所改善，提供了范围施加能力，以及瘟疫这种更强但有时限的变体。[[spell:1276467]]的加入使恶魔学识能够同时拥有专职打断技能，以及来自恶魔卫士的打断/昏迷效果，以便在需要连续打断的情况下应对。

勉强够用

恶魔学识 在冷却技能之外是一个机动性相当强的专精，尤其是作为术士而言。根据天赋配置，有多个触发效果可以留到移动时机使用。

名列前茅

术士 的生存能力总体不错。虽然该职业缺乏免疫或伤害转移工具，但主要机制是通过

[[spell:108370]]

的护盾溢出来缓冲现有生命值上限，

[[spell:108415]]

来自

[[spell:108416]]

和

[[spell:104773]]

.

1.

### 恶魔学识 术士 in 至暗之夜

### **第2赛季**   改动

2.1.

#### 至暗之夜 12.1.5版本内容指南

本次补丁没有术士的改动，而是专注于两个新的终局内容：一个新团队副本和备受期待的迷宫巨型地下堡。请查看以下链接获取更多详情：

[基斯伊克斯的解放团本](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[金多占迷宫地下城](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### 12.1.5版本改动

本次补丁延续了第2赛季的剧情和装备进度，专注于游戏体验优化、新的单人向内容，以及 [安其拉入侵](<https://www.icy-veins.com/wow/aqir-invasions-guide>)，还有更多！如果你对12.1.5版本及之后还有什么在等着你感到好奇，请务必访问我们的专题页面。

2.3.

#### 职业改动

恶魔学识 术士 在12.1.5补丁中没有改动，因此该专精最近一次改动发生在第2赛季初期。装备页面已更新，加入了来自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>)的新物品，以及关于一旦[[item:280562]]可用后如何使用的建议。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_warlock_haunt.jpg>) 点击查看上赛季第二赛季的改动
:::details 显示12.1补丁改动 隐藏12.1补丁改动
8月25日的改动主要是为了提高 恶魔学识 的单体输出，使其更接近 毁灭。附带效果是这些改动也提升了 恶魔学识 的AoE能力，使其巩固为最强的AoE 术士 专精，并在整体AoE中名列前茅。宠物相对增益并不会改变 恶魔卫士 作为该专精当前默认宠物的地位。

[至暗之夜 8月25日热修](<https://us.forums.blizzard.com/en/wow/t/world-of-warcraft-midnight-hotfixes-august-25/2336376/68>)

**术士**

<em>开发者说明：我们正在提升痛苦和恶魔学识的输出能力，主要专注于它们的单体目标技能，次要关注它们的多目标技能。此外，我们还大幅提升了术士恶魔的伤害，使它们对整体输出的贡献更大。这也有助于在单人游玩时减轻一些仇恨问题。</em>

- 小鬼、虚空行者、萨亚德和地狱猎犬的伤害提高350%。

**恶魔学识**

- 暗影 箭伤害提高35%。不适用于PvP战斗。
- 恶魔箭伤害提高30%。
- 野生小鬼 伤害提高20%。
- 召唤的 恶魔卫士 伤害提高20%。
- 阿古斯之主召唤的恶魔伤害提高20%。不适用于PvP战斗。
- 召唤恐惧猎犬伤害提高30%。

8月18日的改动将 恶魔学识 套装加成从个位数提升到约10%，具体取决于英雄天赋。

[职业调整即将到来 - 8月18日](<https://us.forums.blizzard.com/en/wow/t/class-tuning-incoming-%E2%80%93-august-18/2336820>)

**恶魔学识**

- <em>开发者说明：我们正在提高 恶魔学识 的剧毒深渊2件套加成的收益，使其表现更接近其他专精的套装加成。</em>
- 剧毒深渊2件套加成已更新 - 野生小鬼现在对主目标以350%的效果进行内爆（原为250%），对其他目标以315%的效果进行内爆（原为225%）。

随着12.1补丁的临近，恶魔学识 术士 收到了多项影响英雄和专精天赋树的改动，同时修复了该专精的错误以及基础技能 [[spell:108370]] 的问题，该技能现在提供了更实质的防御层。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒 的削弱是为了提高的价值 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者，它现在成为了略好一些的单体目标选择。

[乌拉特克之诅咒 补丁说明](<https://us.forums.blizzard.com/en/wow/t/2317811/16>)

**恶魔学识**

- 暗影 箭伤害提高45%。
- 恶魔箭伤害提高55%。
- 召唤冥犬伤害提高35%。

**恶魔使徒**

- 混沌齐射伤害降低20%。
- 邪能搜寻者伤害降低20%。
- 邪恶劈砍伤害降低20%。
- 眼球爆炸伤害降低20%
- 克罗索斯之焰现在使你的 火焰 伤害和你的恶魔造成的伤害提高3%（原为4%）。

:::

:::

### 至暗之夜改动概述

2.4.

#### 至暗之夜 概述：恶魔学识 术士

2.5.

#### 巅峰天赋

该资料片最突出的特色是巅峰天赋，它们将在升级过程中逐渐解锁。这些点数独立于天赋树存在，必须按顺序投入才能解锁后续点数。

1. [[spell:1276163]]
2. [[spell:1276190]]
3. [[spell:1276222]]

这些天赋足够强大，值得围绕它们来构建输出循环，从恶魔暴君前置构建转变为恶魔暴君后置构建，旨在最大化额外召唤的数量。

2.6.

#### 改动总结

以下列出了按章节划分的改动明细，以便于阅读。

- **英雄天赋** 获得了基础的小幅改动，并新增了第四列。
  
  
  
  
  ► **点击展开**
  
  
  
  
  2.6.1.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒
  
  
  
  
  - [[spell:429893]] 已被调整为轻微的伤害增益
  - 新天赋：[[spell:1268709]] 每当你消耗碎片时，召唤最多3个眼球，在消耗恶魔艺术时会爆炸造成AoE伤害
  - 新天赋：[[spell:1268713]] 激活期间，邪能眼球每秒会对你的目标施放 [[spell:1269892]]
  - 新天赋：[[spell:407470]] 每个爆炸的邪能眼球将使你获得2%智力，持续10秒
  
  
  
  
  2.6.2.
  
  
  
  
  #### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者
  
  
  
  
  - 新天赋：[[spell:1268884]] 每消耗一个甘露之魂，都有几率触发[[spell:1239714]]对10码范围内的所有目标造成额外伤害
  - 新天赋：[[spell:1268889]]按百分比提高精通，当[[spell:449614]]触发时效果翻倍
  - 新天赋：[[spell:1268903]]提高[[spell:1268884]]的持续时间和伤害
- 核心/循环技能发生了重大改动 **恶魔学识 术士** 法术进行了几项改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:105174]] 现在只能在拥有3个碎片时施放
  - [[spell:428344]]、[[spell:267171]] 和 [[spell:267211]] 已被移除
  - [[spell:196277]] 现在是与 [[spell:264130]] 互选的冷却技能
  - [[spell:265187]] 已被改为
    **动态** 根据激活的野生小鬼和恐惧猎犬的数量来调整其伤害
  - [[spell:265187]] 不再延长其他恶魔的持续时间，也不再提供基础的伤害提升光环
  - [[spell:1251778]] 及其升级不再是一个独立的法术，而是现在附加到了 [[spell:418540]] 上
  - [[spell:111898]] 已被移除
  - 新增了一个选择节点，包含 [[spell:1276452]] 和 [[spell:1276467]]，分别以 烧灼驱魔 或 法术封锁 的形式提供额外的功能性
  - [[spell:1276947]] 的效果已从几率触发改为对每次 [[spell:418540]] 施放都施加施法时间和碎片消耗降低效果
  - [[spell:1276672]] 的功能已从与 [[spell:453568]] 一起几率触发改为一个冷却技能，消耗恶魔之核时会动态减少其冷却时间
- 术士的辅助法术也发生了一些值得注意的改动。
  
  
  
  
  ► **点击展开**
  
  
  
  
  - [[spell:1714]]和[[spell:334275]]现在是独立的天赋
  - [[spell:1265813]]已被添加，使每个诅咒也能影响主目标周围10码内的敌人
  - 引入了灾祸，提供了比诅咒更强大的版本，持续时间和冷却时间更短
  - [[spell:5484]] 现在是与 [[spell:30283]] 互选的选择节点，并且有一个新的辅助天赋 [[spell:1270255]]，减少其冷却时间并最多影响10个目标
  - [[spell:755]]已被移除，其治疗效果被添加到[[spell:234153]]并配合[[spell:1265810]]

1.

### 恶魔学识 术士 玩法基础

[恶魔学识 术士](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-guide>) 是一个围绕不断召唤临时恶魔来为你效劳而设计的专精，冷却时间相对较短，其中一些需要精确的准备和大量的宠物管理。其核心玩法在于产生和消耗 术士 的标志性资源：灵魂碎片。

恶魔学识 是最能体现“始终施法”原则的专精，但同时也很直接直观。通过 [[spell:686]] 和 [[spell:264178]] 不断产生灵魂碎片，然后将这些资源消耗在 [[spell:104316]] 和 [[spell:105174]] 上。这些概念可以分解为以下三个要点。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **保持施法**
  
  
  
  
  恶魔学识 是碎片流转最快的专精，因此通过 [[spell:686]] 和 [[spell:264178]] 不断产生碎片非常重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_calldreadstalkers.jpg>) **使用你的短冷却技能**
  
  
  
  
  [[spell:104316]] 和 [[spell:196277]] 是短冷却法术，提供额外的资源和顺劈伤害，应尽可能频繁地使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_warlock_dominionofargus.jpg>) **在巅峰窗口内最大化古尔丹之手的施放次数**
  
  
  
  
  ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) 阿古斯之主是 恶魔学识 的主要伤害窗口。为了获得最多的召唤，尝试在进入阶段时拥有一些恶魔之核，以便在计时结束前打出更多的 [[spell:105174]]。

1.

### 如何为 恶魔学识 术士 配装

虽然我们总是建议你自己进行模拟以获得理想结果，但我们确实提供了一个专门的 恶魔学识 配装页面。我们目前涵盖了当前赛季装备的推荐，以便在 至暗之夜 终局内容发布时有一个良好的开端。一旦你获得了一些装备，你就需要相应的消耗品、宝石和附魔来搭配这些新物品。

1.

### 更新日志

:::details 历史更新记录
- **2026年10月12日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为补丁12.1.5进行了更新。
- **2026年10月12日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对12.1.5补丁进行审查。
- **2026年10月12日（本页）：** 为补丁12.1.5进行了更新。
- **2026年8月31日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了饰品列表。
- **2026年8月31日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 添加了非 恶魔卫士 的天赋更换。
- **2026年8月25日（本页）：** 已更新至8月25日热修。
- **2026年8月16日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了最佳配装列表、美化和饰品，以适应新的属性配置和饰品调整。
- **2026年8月16日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了消耗品以反映新的最佳配装列表。
- **2026年8月15日（本页面）：** 添加了8月18日的改动。
- **2026年8月11日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了宝石和常见问题解答部分。
- **2026年8月11日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了宝石。
- **2026年8月11日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了天赋选择。
- **2026年8月10日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已为12.1补丁更新。
- **2026年8月10日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已为12.1补丁更新。
- **2026年8月10日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已为12.1补丁更新。
- **2026年8月10日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已为12.1补丁更新。
- **2026年8月10日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已为12.1补丁更新。
- **2026年8月10日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为12.1补丁更新。
- **2026年8月10日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已为12.1补丁更新。
- **2026年8月10日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对12.1补丁进行了审查。
- **2026年8月10日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已为12.1补丁更新。
- **2026年8月10日（本页）：** 已为12.1补丁更新。
- **2026年6月25日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 12.0.7补丁后更新了单体目标推荐。
- **2026年6月15日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已针对12.0.7补丁更新。
- **2026年6月15日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 更新了 恶魔使徒 天赋。
- **2026年6月15日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了 恶魔使徒 天赋。
- **2026年6月15日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对12.0.7版本进行审查。
- **2026年6月15日（本页）：** 已针对12.0.7补丁更新。
- **2026年6月12日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为12.0.7补丁添加了全知卷册。
- **2026年4月20日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已更新至12.0.5补丁。
- **2026年4月20日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 针对 12.0.5 补丁进行了审阅。
- **2026年4月20日（本页）：** 已更新至12.0.5补丁。
- **2026年4月13日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 更新了天赋选项以适应热修复。
- **2026年4月13日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 进一步修复错误后更新了地下城天赋。
- **2026年4月2日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 修复错误后更新了 恶魔使徒 地下城天赋。
- **2026年3月27日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了饰品排名。
- **2026年3月23日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了茶部分。
- **2026 年 3 月 23 日（本页）：** 已为即将到来的调整进行更新。
- **2026年3月17日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 澄清了恶魔暴君的使用方法。
- **2026年3月17日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 扩展了套装奖励部分。
- **2026年3月16日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对 至暗之夜 第1赛季进行了复查。
- **2026年3月16日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为至暗之夜第一赛季更新。
- **2026年3月16日（本页面）：** 为至暗之夜第一赛季更新。
- **2026年3月2日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 添加了一个用于升级到至暗之夜的80级导入方案。
- **2026年3月2日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 修复了针对情况选择天赋的起手式。
- **2026年2月26日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为至暗之夜的发布更新了天赋树。
- **2026年2月26日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为 至暗之夜 发布进行了更新。
- **2026年2月26日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已为至暗之夜的发布进行更新。
- **2026年2月26日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月26日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已更新至至暗之夜 12.0.1。
- **2026年2月26日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜的发布更新了输出循环并添加了巅峰部分。
- **2026年2月26日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜的发布更新了天赋树并添加了巅峰部分。
- **2026年2月26日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 为 至暗之夜 版本添加了巅峰天赋。
- **2026年2月26日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为 至暗之夜 版本添加了巅峰天赋部分并更新了天赋。
- **2026年2月26日（本页）：** 为 至暗之夜 版本更新了性能和巅峰天赋部分。
- **2026年2月10日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对至暗之夜前夕进行审查。
- **2026年2月10日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 针对每次解锁节点的变化更新了天赋树。
- **2026年2月10日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为至暗之夜前夕进行了更新。
- **2026年2月10日（本页面）：** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为至暗之夜前夕进行了更新。
- **2026年1月19日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为至暗之夜前夕进行了更新。
- **2025年11月30日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为11.2.7补丁更新。
- **2025年11月30日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 针对11.2.7补丁进行了审查。
- **2025年11月30日（本页面）：** 为11.2.7补丁更新。
- **2025年10月5日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为11.2.5补丁更新。
- **2025年10月5日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对11.2.5版本进行审查。
- **2025年10月5日（本页）：** 为11.2.5补丁更新。
- **2025年8月22日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔。
- **2025 年 8 月 4 日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对11.2补丁进行审阅。
- **2025 年 8 月 4 日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对11.2补丁进行了更新。
- **2025 年 8 月 4 日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 针对11.2补丁进行了更新。
- **2025年8月4日（本页面）：** 针对11.2补丁进行了更新。
- **2025年6月24日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 根据调整更新了暗影牧师的插槽推荐。
- **2025年6月15日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为 11.1.7 补丁和暗影牧师进行了更新。
- **2025年6月15日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[解放安德迈页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了战斗助手部分。
- **2025年6月15日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 为11.1.7版本进行了审查。
- **2025年6月15日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 添加了战斗助手部分。
- **2025年6月15日（本页）：** 为11.1.7补丁更新。
- **2025年4月21日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.1.5补丁进行更新。
- **2025年4月21日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[解放安德迈页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对11.1.5版本进行审查。
- **2025年4月21日（本页）：** 已针对11.1.5补丁进行更新。
- **2025年4月4日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已更新饰品推荐。
- **2025年3月19日（[解放安德迈页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 更新了天赋推荐。
- **2025年3月5日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 天赋推荐的小幅更新。
- **2025年3月4日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了毕业装备列表和饰品排行。
- **2025年2月24日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对11.1.0补丁更新。
- **2025年2月24日（本页面）：** 已针对11.1.0补丁更新。
- **2025年2月20日（[解放安德迈页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-liberation-of-undermine-raid-guide>)):** 指南已添加。
- **2024年12月15日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为 11.0.7 补丁和赛尔西的指环进行了更新。
- **2024年12月15日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对11.0.7补丁进行审查。
- **2024年12月15日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已为 11.0.7 补丁更新。
- **2024年12月15日（本页）：** 已为 11.0.7 补丁更新。
- **2024年11月29日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** simc更新后更新了天赋推荐。
- **2024年11月29日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** simc实现更新后更新了天赋。
- **2024年10月21日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 更新了天赋推荐。
- **2024年10月21日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对11.0.5补丁进行更新。
- **2024年10月21日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 针对11.0.5补丁进行了审阅。
- **2024年10月21日（本页）：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 重新制作了页面布局，并相应地更新了各部分。
- **2024年9月25日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 最新热修复后将单体目标推荐改回 恶魔使徒。
- **2024年9月19日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为 11.0.5 补丁进行了更新，并添加了地下城提示部分。
- **2024年9月12日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器附魔和磨刀石。
- **2024年9月9日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 添加了第1赛季毕业装备列表，更新了饰品部分。
- **2024年9月9日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了宝石部分，因为策略发生了变化。
- **2024年9月9日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[尼奥鲁巴宫殿页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-nerub-ar-palace-raid-guide>)):** 指南已添加。
- **2024年9月9日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 针对第1赛季上线更新了天赋选择。
- **2024年9月9日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了第1赛季天赋推荐。
- **2024年9月9日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已为《地心之战》第1赛季进行了审查。
- **2024年9月9日（本页）：** 更新了强度评估以反映第1赛季状况。
- **2024年8月29日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了单体目标天赋推荐。
- **2024年8月26日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了所有天赋树并添加了宝库天赋推荐。
- **2024年8月21日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 添加了升级玩法风格部分。
- **2024年8月21日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 添加了赛季前毕业装备列表部分。
- **2024年8月21日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对地心之战进行更新。
- **2024年8月21日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对地心之战进行更新。
- **2024年8月21日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 添加了英雄天赋部分和选择器。
- **2024年8月21日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了推荐以包含英雄天赋树。
- **2024年8月21日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对《地心之战》进行审阅。
- **2024年8月21日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 更新了各部分以考虑英雄天赋。
- **2024年8月21日（本页）：** 更新了优劣势和强度评估部分。
- **2024年7月23日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/demonology-warlock-mists-of-pandaria-remix-guide>)):** 页面已针对《地心之战》前夕补丁进行更新。
- **2024年7月23日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已为《地心之战》前夕版本审阅。
- **2024年7月23日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对《地心之战》前夕更新。
- **2024年7月23日（本页面）：** 已针对《地心之战》前夕更新。
- **2024年7月19日（[地心之战](<https://www.icy-veins.com/wow/demonology-warlock-the-war-within-pve-guide>)):** 已针对《地心之战》前夕更新。
- **2024年7月19日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对《地心之战》前夕更新。
- **2024年6月19日（[地心之战](<https://www.icy-veins.com/wow/demonology-warlock-the-war-within-pve-guide>)):** 页面创建。
- **2024年5月14日（[熊猫人之谜：Remix](<https://www.icy-veins.com/wow/demonology-warlock-mists-of-pandaria-remix-guide>)):** 页面已添加。
- **2024年5月7日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对10.2.7进行审查。
- **2024年5月7日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对10.2.7进行审查。
- **2024年5月7日（本页）：** 已针对10.2.7进行审查。
- **2024年4月22日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为第4赛季上线进行了更新。
- **2024年4月22日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 为第4赛季进行了更新。
- **2024年4月22日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 为第4赛季进行了审阅。
- **2024年4月22日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为第4赛季进行了审阅。
- **2024年4月22日（本页）：** 已针对巨龙时代第4赛季进行更新。
- **2024年3月19日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对10.2.6进行审查。
- **2024年3月19日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对10.2.6进行审查。
- **2024年3月19日（本页面）：** 已针对10.2.6进行审查。
- **2024年1月15日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为 10.2.5 补丁更新了饰品部分。
- **2024年1月15日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 更新了天赋和属性。
- **2024年1月15日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.2.5补丁进行更新。
- **2024年1月15日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为10.2.5补丁更新了AoE天赋。
- **2024年1月15日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已针对10.2.5补丁进行审核。
- **2024年1月15日（本页）：** 已针对10.2.5补丁进行更新。
- **2023年11月28日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 更新了单体目标配置。
- **2023年11月13日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 更新了天赋树。
- **2023年11月7日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 在波纹孢子斗篷被削弱后更新了美化推荐。
- **2023年11月7日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 更新了暴君天赋。
- **2023年11月6日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为10.2版本进行了审查。
- **2023年11月6日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为 10.2 补丁和第3赛季更新了装备推荐。
- **2023年11月6日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 为10.2版本进行了审查。
- **2023年11月6日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为10.2补丁和第3赛季进行了更新。
- **2023年11月6日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至 10.2 补丁。
- **2023年11月6日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为 10.2 补丁更新了天赋。
- **2023年11月6日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已针对10.2版本进行更新
- **2023年11月6日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为10.2补丁更新了天赋。
- **2023年11月6日（本页）：** 已更新至 10.2 补丁。
- **2023年9月4日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 重新格式化了页面，包含毕业装备表格和部分更新。
- **2023年9月4日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 重构了天赋部分。
- **2023年9月4日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已针对10.1.7补丁更新
- **2023年9月4日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 针对 10.1.7 补丁进行了审阅
- **2023年9月4日（本页）：** 已针对10.1.7补丁更新
- **2023年7月10日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对10.1.5补丁进行审查。
- **2023年7月10日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 针对10.1.5补丁更新了天赋。
- **2023年7月10日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.1.5补丁进行更新。
- **2023年7月10日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为 10.1.5 补丁更新了天赋。
- **2023年7月10日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对 10.1.5 补丁的天赋变更进行了更新。
- **2023年7月10日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为 10.1.5 补丁更新了天赋。
- **2023年7月10日（本页）：** 添加了 10.1.5 补丁并更新了强度评估部分。
- **2023年5月1日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为10.1补丁进行了复查。
- **2023年5月1日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已更新至10.1补丁。
- **2023年5月1日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 在腐化之怒增益后更新了药水推荐。
- **2023年5月1日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已更新至10.1补丁。
- **2023年5月1日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为10.1补丁更新了天赋。
- **2023年5月1日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已更新至10.1补丁。
- **2023年5月1日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为 10.1 补丁审查了天赋。
- **2023年5月1日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 根据10.1补丁的改动，将“暗影之中”更名为“猎犬大师的谋略”。
- **2023年5月1日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为 10.1 补丁进行了审查。
- **2023年5月1日（本页）：** 为 10.1 补丁添加了新部分并更新了强度评估部分。
- **2023年3月24日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了黑龙戒指部分以考虑正式服的在线修复。
- **2023年3月24日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐以考虑额外的正式服在线修复。
- **2023年3月22日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了原始宝石推荐以考虑25%增益的在线修复。
- **2023年3月20日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对10.0.7补丁更新了天赋树。
- **2023年3月20日（[传说物品](<https://www.icy-veins.com/wow/demonology-warlock-best-legendaries-shadowlands>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 添加了10.0.7补丁新戒指部分。
- **2023年3月20日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 为 10.0.7 补丁添加了原始宝石部分。
- **2023年3月20日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为 10.0.7 补丁更新了天赋。
- **2023年3月20日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已针对10.0.7补丁进行审核。
- **2023年3月20日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 更新了天赋树以反映 10.0.7 补丁的职业和专精变更。
- **2023年3月20日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为10.0.7版本更新了天赋。
- **2023年3月20日（本页）：** 添加了 10.0.7 补丁并更新了强度评估部分。
- **2023年1月24日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 为10.0.5补丁进行了审核。
- **2023年1月24日（本页）：** 已更新至10.0.5补丁。
- **2023年1月7日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 将地下城药水更新为更可靠的微温全能药水。
- **2023年1月3日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 移除了灵魂燃烧宏。
- **2022年12月23日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 更新了天赋树。
- **2022年12月15日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 澄清了优先级列表的推理。
- **2022 年 12 月 14 日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 更新了武器符文。
- **2022 年 12 月 14 日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 将属性优先级分为单体和多目标。
- **2022年12月13日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 更新了美化推荐。
- **2022年12月11日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已为第一赛季上线更新。
- **2022年12月11日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已针对巨龙时代第1赛季进行更新。
- **2022年12月11日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 更新了推荐配置。
- **2022年12月11日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 更新了起手式和优先级列表的选择器。
- **2022年12月11日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 针对巨龙时代第1赛季进行了审查。
- **2022年12月11日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 针对巨龙时代第1赛季进行了审查。
- **2022 年 12 月 11 日（本页）：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已为巨龙时代上线更新。
- **2022年11月28日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已为巨龙时代上线更新。
- **2022年11月28日（本页）：** 已为巨龙时代上线更新。
- **2022年10月25日（[升级](<https://www.icy-veins.com/wow/demonology-warlock-leveling-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[传说物品](<https://www.icy-veins.com/wow/demonology-warlock-best-legendaries-shadowlands>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[托加斯特](<https://www.icy-veins.com/wow/demonology-warlock-torghast-guide-and-best-anima-powers>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[盟约与羁绊](<https://www.icy-veins.com/wow/demonology-warlock-best-covenants-soulbinds-and-conduits>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[装备页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[插件页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-macros-addons>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[附魔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gems-enchants-consumables>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[属性页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[纳斯利亚堡页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-castle-nathria-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[统御圣所页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-sanctum-of-domination-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[初诞者圣墓页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[大秘境页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-mythic-plus-tips>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[循环页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[天赋页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spec-builds-talents>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[法术页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-spell-summary>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（[简单模式页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-easy-mode>)):** 已为巨龙时代前夕更新。
- **2022年10月25日（本页）：** 已为巨龙时代前夕更新。
- **2022年2月22日（[9.2版本分析](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-2-changes-analysis>)):** 更新以反映 9.2 补丁上线。
- **2022年1月15日（[9.2版本分析](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-2-changes-analysis>)):** 页面已添加，包含初步想法和信息。
- **2021年11月1日（[9.1 补丁分析](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** 针对9.1.5补丁更新。
- **2021年7月13日（[9.1 补丁分析](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** 移除了PTR免责声明。
- **2021年6月27日（[9.1 补丁分析](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** 基础变更，更新了传说装备和盟约推荐。
- **2021年5月5日（[9.1 补丁分析](<https://www.icy-veins.com/wow/demonology-warlock-patch-9-1-changes-analysis>)):** 页面已创建。
- **2020年10月12日（[奈亚拉托提普页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-ny-alotha-raid-guide>)):** 本页已为《暗影国度》前夕更新。
- **2019年7月14日（[永恒宫殿页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-the-eternal-palace-raid-guide>)):** 更新了首领提示和天赋/精华选择。
- **2019年7月9日（[永恒宫殿页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-the-eternal-palace-raid-guide>)):** 指南已添加。
- **2019年6月25日（[奥杜尔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[达萨罗之战页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年6月25日（[风暴熔渣页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-crucible-of-storms-raid-guide>)):** 本页面已针对8.2版本的发布进行了审查，无需更改。
- **2019年4月14日（[达萨罗之战页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 在最近的团队副本削弱后进行了更新。
- **2019年4月14日（[风暴熔渣页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-crucible-of-storms-raid-guide>)):** 指南已添加。
- **2019年2月11日（[达萨罗之战页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 更新了更好的天赋选择和更多提示。
- **2019 年 1 月 21 日（[达萨罗之战页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-battle-of-dazar-alor-raid-guide>)):** 页面已添加。
- **2019年1月3日（[奥杜尔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** simc热修复后更新了恶魔之门的价值。
- **2018年12月10日（[奥杜尔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** 为8.1补丁进行了更新。审查了所有首领的天赋建议。
- **2018年11月6日（[奥杜尔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** 更新了安托鲁斯首领的提示。
- **2018年9月7日（[奥杜尔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** 为奥迪尔进行了更新。
- **2018年8月12日（[奥杜尔页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-uldir-raid-guide>)):** 页面已添加。

显示更多

显示更少

:::

## 练级

在本页面，你将找到我们的逐级 恶魔学识 术士 升级指南，适用于 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
**确保使用滑块让攻略适配你的等级。**
有关更通用的升级信息，请参阅我们的
[术士 升级指南](<https://www.icy-veins.com/wow/warlock-leveling-guide>).

1.

### 恶魔学识 术士 升级指南 - 至暗之夜

恶魔学识 术士 在升级过程中依赖 恶魔卫士 来承担主要工作，其自身同样坚韧且强大。虽然它没有太多引怪的方式，主要使用宠物或恶魔之核 [[spell:264178]]，但它的优势在于极高的AoE爆发潜力，以及与其他专精相比威胁值较低的玩家法术。

诅咒、控制技能和宠物副坦克可以显著减少承受的伤害，鼓励激进的打法，而所有个人防御冷却技能即使在拉多怪时也能提供一定程度的安全保障。

对于更大的敌人，如精英或稀有怪，恶魔学识 的伤害构成围绕着数个独立的恶魔和守护者，使我们能够安全地使用所有冷却技能，依靠能够维持仇恨的 恶魔卫士，尽管对于伤害更高的敌人可能需要一些 [[spell:234153]] 配合 [[spell:1265810]]。

1.1.

#### 升级装备选择

升级时，应始终选择物品等级最高的装备。如果物品等级相同，则应选择属性最有利于你专精的装备。如果你当前的装备是传家宝，则不应更换。

虽然传家宝最重要的方面是经验加成，但为了最大化其属性收益，你应该优先考虑智力，然后是急速，然后是暴击。其原因在于，急速通常能提供更流畅的战斗体验，并以均匀的方式提升你的DPS，而暴击虽然同样重要，但本质上不够稳定。

能够更快施法提供了更快标记怪物的优势，而且当大多数动作都更快完成时，整体感觉会更好。

1.2.

#### 至暗之夜升级实用消耗品

以下列出了几种可以用来加快升级进程的消耗品，无论数值调整如何，它们通常都是有益的。

《地心之战》的附魔在升级过程中仍然有效，并可以帮助提升角色速度。优先考虑以下附魔：

- [[item:223653]]
- [[item:223800]]
- [[item:223725]]

战斗药水能提供爆发性的力量，如果有什么区别的话，最好在它们于满级变得无关紧要之前使用它们。

这些消耗品主要用于加快穿越和导航速度。

- [[item:109076]]
- [[item:132516]]或[[item:212268]]
- [[item:168412]]
- [[item:219905]]
- [[item:212250]]
- [[item:172063]]或[[item:133576]]

1.

### 升级天赋

如果你刚刚开始你的旅程 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>)，我们为你准备了一个80级导入字符串。一旦你开始在至暗之夜中升级，你就可以按照下面天赋树的逐点分配进行加点。

:::talents 恶魔学识 80级 至暗之夜 升级
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAYMjZGNLmx2MzYWGAAAAAAAwYGDLwAbDL0wixMzsMbzYGGAwYGjBAjZGGAAAzMGzMzgZmBA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAYMzMzoZxM2mZGzyAAAAAAAAGzYYBGYbYhGWMmZmlZbmZGGAwMGjZmBYMzwsAAAmZGjZmZwMGwA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITVVUUHDPfiklbLM8OJSD0kw01ZkdF1ZURB-DGRCYUFeYYCC804IWS62QQKFHtOmpIB-AAAA-AUMKEcQYARRDzC-
```

:::

2.1.

#### 升级用战争模式天赋

1. [[spell:212459]] 在与其他玩家进行PvP战斗时最为有用，因为它能让你从专注于你的近战职业手中获得片刻喘息。
2. [[spell:212619]] 每24秒提供一次打断，前提是你的当前宠物不是地狱猎犬。
3. [[spell:201996]] 召唤一个恶魔，对20码内任何施放有害法术的敌人造成其最大生命值5%的伤害。
4. 考虑到我们选择了[[spell:1276947]]，[[spell:1240189]] 最多只能算过得去。
5. **等级 49 起：**在无法使用坐骑的封闭空间中，应始终考虑使用[[spell:248855]]来加快你的移动速度。
6. **等级 55 起：**在风筝目标时，[[spell:353753]]可以提供额外的范围爆发伤害。
7.

### 升级循环

为了帮助理解随着你升级和推进天赋树，你的专精会发生什么变化，请使用下面的滑块选择你当前的等级。每次升级时，将其移动，该部分将随之升级！

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。

:::

**等级 1 起：**

**等级 1–2：**从1级开始，你只有一个主要攻击技能：[[spell:686]]。

1. **等级 2–3：**当连续施放几发暗影箭无法更快杀死多个敌人时，使用[[spell:172]]来标记并削弱它们。
2. **等级 45 起：**当你拥有5个灵魂碎片且[[spell:104316]]处于激活状态时，施放[[spell:265187]]。
3. **等级 13 起：**无论目标数量多少，都要卡着冷却时间施放[[spell:104316]]。
4. **等级 11 起：**[[spell:105174]] 是第一个消耗灵魂碎片的技能，也是唯一一个没有冷却时间的技能。当你没有其他可用的碎片消耗技能且拥有5个碎片时，就使用它。
5. **等级 15 起：**[[spell:264178]] 已解锁，每当触发恶魔之核时就使用它。
6. **等级 23 起：**每当至少有6只小鬼激活时，就应使用[[spell:196277]]。

小贴士：治疗你的恶魔

不要忘记在战斗中使用[[spell:234153]]配合[[spell:1265810]]来保持你的恶魔的生命值。

小贴士：不要低估诅咒！

随着[[spell:1265813]]的引入，诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

1.

## 升级时的宠物选择

[[spell:688]] 是你第一个可用的恶魔。这只宠物在升级时并不是特别有用，但在早期等级你别无选择。

如果你是单人升级，[[spell:697]]在升级过程中是一个不错的选择，因为它能为你分担很多压力。避免施法被打断也能提高升级速度。

由于集硬控制、伤害、顺劈和坦克潜力于一体，[[spell:30146]] 是绝大多数内容（包括升级）中恶魔学识的默认选择。

如果你在组队升级或进入地下城，[[spell:691]]可能是一个不错的选择。额外的打断技能对于处理麻烦的施法怪物很有帮助。

1.

## 更新日志

- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026 年 3 月 17 日：** 澄清了恶魔暴君的使用方法。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月2日：** 添加了一个用于升级到至暗之夜的80级导入方案。
- **2026年2月26日：** 为至暗之夜的发布更新了天赋树。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 添加了升级玩法风格部分。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月13日：** 更新了天赋树。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 为10.1补丁进行了复查。
- **2023年3月20日：** 针对10.0.7补丁更新了天赋树。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

## 快速入门

在本页中，我们将解释如何在魔兽世界12.1.5补丁中轻松游玩术士的恶魔学识专精，使用最简单的输出循环、天赋树、属性优先级、装备配置等，而不牺牲性能。

1.

### 术士恶魔学识专精基础

本章节适用于对游戏或职业不熟悉的玩家，没有打史诗难度团本的打算，或者只是想以更直接的方式进行游戏，而不会被为实现最优操作所需考虑的众多优先级和主动技能所淹没。

恶魔学识专精专注于始终维持一支小型恶魔军队，它们将造成你的大部分伤害。该专精可以非常有效，特别是在单体目标和爆发性AOE场合。

在本节中，我们将专注于一种配置，它能最大限度地减少所需按键、插件和反应操作的数量，同时不影响整体伤害输出。以下是三条简单规则，帮助你理解该专精。

- ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_gem_amethyst_02.jpg>) **保持施法**
  
  
  
  
  恶魔学识 是碎片流转最快的专精，因此通过 [[spell:686]] 和 [[spell:264178]] 不断产生碎片非常重要。
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_warlock_calldreadstalkers.jpg>) **使用你的短冷却技能**
  
  
  
  
  [[spell:104316]] 和 [[spell:196277]] 是短冷却法术，提供额外的资源和顺劈伤害，应尽可能频繁地使用。
- ![](<https://static.icy-veins.com/images/wow/large_icons/inv12_apextalent_warlock_dominionofargus.jpg>) **在巅峰窗口内最大化古尔丹之手的施放次数**
  
  
  
  
  ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) 阿古斯之主是 恶魔学识 的主要伤害窗口。为了获得最多的召唤，尝试在进入阶段时拥有一些恶魔之核，以便在计时结束前打出更多的 [[spell:105174]]。

1.

### 至暗之夜中术士恶魔学识专精新手指南

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者新手天赋

2.1.

#### 术士恶魔学识专精新手天赋

此构建针对易用性进行了优化，同时提供了一个适用于任何情况、无需调整的配置，包括团队副本、大秘境甚至地下城。就输出而言，这并非单体或多目标的最优选择，但它作为一个构建，可以帮助玩家在转向我们天赋页面中更专精的构建之前，先熟悉专精的核心。

要直接在游戏中导入这个全能构建，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAgZmZGNLmxmZGzyAAAAAAAMW2GYADYGWCM2MmZsMbzYGzAAzMzYMAzMjZGzsBAAGzMjZMDmxAGA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnELM028MTjehprrowwJbM-DGRUCFewyCCSYYcgk268KXmmEHRQsOC-AAAA-HIOQ0AEQYhhCzC-
```

:::

### 术士恶魔学识专精基础输出循环

2.2.

#### 单体目标循环

1. 只要可用就施放[[spell:104316]]。
2. 如果你有4-5个灵魂碎片，施放[[spell:105174]]。
3. 当你有6只野生小鬼时，施放[[spell:196277]]。
4. 如果你有2层或更多层[[spell:267102]]，施放[[spell:264178]]。
5. 使用3个灵魂碎片施放[[spell:105174]]。
6. 施放[[spell:686]]来产生灵魂碎片。

[[spell:265187]] 应卡着冷却时间施放，并确保延长[[spell:104316]]。

:::details 常见问题：我应该使用什么宠物/恶魔？
在任何情况下都始终选择恶魔卫士，因为恶魔学识术士专精就是如此。

:::

2.3.

#### 术士恶魔学识专精多目标输出循环

输出循环与单体目标时相同，因为你的绝大部分伤害也会顺劈到主目标周围。

:::details 小贴士：治疗你的恶魔
不要忘记在战斗中使用以下技能保持你的恶魔的健康

[[spell:234153]]

使用

[[spell:1265810]]

.

:::

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:440057]]是独有的， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/hellcaller.webp>) 地狱召唤者并结合了上述两种诅咒。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

2.3.1.

##### 巅峰天赋： ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) 阿古斯支配

[[spell:1276163]]的核心思路是在[[spell:265187]]之后最大化[[spell:105174]]的施放次数。为了实现这一目标，最好在已经拥有5个碎片时施放[[spell:265187]]，理想情况下最好有最多4个[[spell:267102]]来加速整个流程。值得注意的是，为了获得更多恶魔之核而延迟暴君，如果在战斗或副本过程中因此错过了额外的暴君召唤，很可能导致DPS损失。

2.3.2.

##### 第2赛季套装

第2赛季套装加成完全是被动的，不会改变游戏玩法。

### 术士恶魔学识专精属性优先级

2.4.

#### 术士恶魔学识专精属性优先级

目前，你应按以下顺序优先考虑次要属性。关于本页呈现内容的更多信息，请查看我们的主要
[属性优先级页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>).

装备等级

急速达到22%

暴击

精通

急速

全能

### 暴风雪战斗助手

2.5.

#### 术士恶魔学识专精战斗助手

在11.1.7补丁中引入的 [战斗助手](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>) 在撰写本文时，包含两个主要功能：

- **辅助高亮：** 显示下一个要排队的法术，在单体目标循环中足够准确，在多目标中功能有限，最适合用于熟悉专精的流程和节奏
- **单键助手：** 允许使用单个输入来完成辅助高亮提示序列中的多个技能，代价是更长的基础公共冷却时间（这会导致额外5%到10%的DPS损失）

**值得指出的是，这些工具首先是无障碍功能，不应被视为学习专精及其背后逻辑的直接替代品。**

战斗助手在术士恶魔学识专精方面表现最差的领域是：

- 多目标，因为它无论情况如何都考虑所有目标聚在一起。
- 冷却技能的使用，因为它们要么被遗漏，要么在进入某个冷却技能前没有进行准备，暴君被完全遗漏，而正确地设置它是恶魔学识专精整体DPS的重要组成部分
- 不支持[[spell:196277]]

2.6.

#### 战斗助手小贴士

- 冷却时间的对齐必须手动完成，特别是考虑到种族技能、药水和使用型装备
- 在多目标情况下，[[spell:460551]]的分配也必须手动完成
- 一般来说，尽量最大化施法时间，特别是在使用单键助手时，因为等待时间是游戏任何阶段的改进领域之一

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为 至暗之夜 版本添加了巅峰天赋部分并更新了天赋。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 更新了各部分以考虑英雄天赋。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 为10.2补丁更新了天赋。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 为 10.1.5 补丁更新了天赋。
- **2023年5月1日：** 为 10.1 补丁进行了审查。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月23日：** 更新了天赋树。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 天赋与构筑

在本页中，你将找到魔兽世界12.1.5补丁中术士恶魔学识专精的最佳天赋。我们还为团队副本或大秘境等不同类型的内容提供了默认天赋配置。如果你开启了战争模式进行游戏，我们也为你准备了PvP天赋。

1.

### 恶魔学识术士专精的最佳至暗之夜天赋

在第2赛季中，恶魔学识专精的天赋选择基本保持不变， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者成为纯单体目标时略优的选择。虽然仍有一些个人偏好和情境调整的空间，以下是我们的当前建议：

- **单体目标**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者的调校表现高出约3%，比较对象为 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒高出约3%，但在顺劈伤害方面存在明显不足。
- **群体伤害**— ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒在任何层数的大秘境中都是更好的选择。大秘境天赋配置提供与 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者相当的单体目标伤害，同时保留更优的AOE能力。

**快速开始导入代码：**

:::talents 恶魔学识专精单体目标 - 灵魂收割者
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMAAAAAAAjtlBGwAmhtQGbmhZ2mlZmZMDAYMzMzAMzMmxMDAAwMzMzMjZYZAYA"
}
```
:::

:::talents 恶魔学识专精AOE - 恶魔使徒
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAAAAAAGzYYBGYb0CNsYMzYZ2mZmxMAwMjZGzMDwYmxMbAAgxMzMzww2MGwA"
}
```
:::

:::talents 恶魔学识专精地下堡 - 灵魂收割者
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MmZsMmxMzMAwMzMGDwMzYmxMbAAgxMzMzYw2MDwA"
}
```
:::

要显示天赋树，请选择你想要游玩的英雄天赋和内容

恶魔使徒

单体目标

秘境+

推荐

灵魂收割者

单体目标

推荐

秘境+

地下堡

### 天赋方案 0-0

1.1.

#### 单体目标天赋

恶魔学识专精的单体目标循环围绕最大化[[spell:1276163]]窗口展开，以召唤尽可能多的恶魔。目前， ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒能带来更多附带顺劈伤害，代价是单体表现比下述构筑低3%： ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者.

### 天赋方案 0-1

1.2.

#### AOE/大秘境 恶魔使徒天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒提供更好的多目标成长性，并能通过霸主和深渊领主前置爆发伤害。

[[spell:196277]]既用于产生恶魔之核，也借助[[spell:1281511]]让野生小鬼在目标数量较少时也能顺劈。

### 天赋方案 1-0

1.3.

#### 单体目标天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者以约3%更优的单体伤害和远程[[spell:265187]]换取了明显更差的顺劈表现。

### 天赋方案 1-1

1.4.

#### AoE/大秘境 灵魂收割者天赋

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者提供稍快的启动速度，但代价是更高的波动性和更差的整体伤害，使其成为一个非常情境化的选择，适用于你需要尽快打出伤害的场合。

其玩法与另一英雄天赋树非常相似，显著的区别在于由于[[spell:449638]]的存在，可以更快地设置[[spell:1276163]]。

### 天赋方案 1-2

1.5.

#### 地下堡天赋

英雄天赋树的选择更多是一种风格偏好。 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者提供整体更好的防御能力，但 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒拥有更强的爆发能力，可以使某些原本困难的情况变得简单。

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAYmxMzoZjZ2mZGzyAAAAAAAAGzYYBGYbYhGWMGjlZZmZGzAAzMmZmZmBwMjZAAAMmZmxwwyMGwA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPQSghklnoBLM18MjehhrrToowID-DGRUVYFeyCCSYYcgku28KVWCJOigYdA-AAAA-AOQo0QowITgwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxMzMzMAjZGzsBAAGzMzMDYbGDYA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-DGRUVYCFYYceyCCSgk2KVWCLOigYd8C-AAAA-AOQo0QowITgwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMzMzoZjhZmxsMAAAAAAAjtlBGwAmhtAjNzwMbzyMzMmBAMmZmZAmZGzYmBAAYmZmZmxMsMAMA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPSghiklnoELM128MTvw01JUUYkB-DGRUVYFfy0IWYYcu68S2AQQUmmsCJeA-AAAA-HIOQ2AEUQhhCzC-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MmZsMbzMzYGAYmxMzMAzMjZGzsBAAGzMzMDYbGDYA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjchprTwwJbM-DGRUVYCFYYceyCCSgku2KVWCLOigYdE-AAAA-HIOQ2AEQQhhCzC-
```

:::

### 天赋方案 1-2

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MmZsMmxMzMAwMzMGDwMzYmxMbAAgxMzMzYw2MDwA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjchprTwwJbM-DGRUCFewyCCSYYcgk26WmmEHJRQasCD-AAAA-HIOQ2AEQQhhCzC-
```

:::

上面列出的构筑是热门推荐，涵盖了适合各种终局内容风格的不同配置。每个天赋构筑都有自己的循环，也可以针对特定类型的内容进一步调整，以更好地为你的团队提供帮助。

1.

### 全知典籍

在 [12.0.7补丁](<https://www.icy-veins.com/wow/midnight-1207-guide>)万卷书是一种新的玩家力量来源，会在数周内逐步解锁，并提供一系列小而灵活的加成选择，可随时更换以匹配所需的内容。符文的选择可以量身定制以提供输出，也可以转向生存能力和实用性。

以下是推荐的指南，逐点列出：

1. [[spell:1279599]]
2. [[spell:1279603]]或[[spell:1279604]]
3. [[spell:1287555]]
4. [[spell:1279609]]
5. [[spell:1279615]]和[[spell:1279614]]提供相似的输出

:::details 常见问题：哪个副属性符文最好？
术士的默认选择是

[[spell:1279609]]

。如果你不知怎么设法让暴击几率超过35%而忽视了精通，可以考虑使用

[[spell:1279612]]

.

:::

1.

### 巅峰天赋： ![Dominion of Argus Icon](<https://static.icy-veins.com/images/wow/large_icons/inv_felstalkermount_green.jpg>) 阿古斯支配

在至暗之夜练级期间可用，这些天赋与专精树的其余部分分开，需要后续投入点数才能解锁更高的等级。

1. [[spell:1276163]]
2. [[spell:1276190]]
3. [[spell:1276222]]

这些天赋足够强大，值得围绕它们构建输出循环，从暴君设置循环转变为暴君后循环，旨在最大化[[spell:105174]]的施放次数和由此产生的额外召唤。

1.

### 英雄天赋

英雄天赋在71级解锁，是互斥的天赋树，你可以选择来略微改变游戏玩法和视觉效果。恶魔学识术士可以在 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒和 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒以恶魔为主题，围绕通过[[spell:470479]]召唤的霸主、混沌之母和深渊领主的循环。因此其游戏玩法具有可预测的节奏和更高的爆发潜力，与英雄天赋树的召唤和法术强化相关联。

在实用性方面，[[spell:428911]]在[[spell:48020]]期间提供减速和定身免疫以及50%的移动速度，而另一方面[[spell:429072]]结合[[spell:1270255]]可启用25秒冷却的[[spell:5484]]，最多可影响10个目标。

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者的精髓在于非常激进地消耗碎片，以从触发的各种持续伤害效果中获益，并通过[[spell:449637]]产生更多恶魔之核触发。

在实用性方面，[[spell:449701]]保证了更强的治疗石而无需灵魂燃烧碎片，[[spell:449703]]增强了主动减伤能力，[[spell:389623]]使[[spell:20707]]与其他复活法术持平。

1.

### PvP天赋（战争模式）

在我们的天赋部分，有一个启用“战争模式”的选项。启用战争模式可提供以下好处：

- 在户外世界启用PvP天赋
- 在最高等级时，世界任务奖励提高10%
- 升级时获得的经验值提高10%
- 赚取征服点数，每周可兑换装备奖励

考虑到开启战争模式进行升级和PvE内容的好处，建议你启用该功能。在大多数情况下，尽管存在风险，这将带来最大收益。你将使自己可用于开放世界PvP，在升级或进行世界任务时存在被“偷袭”的可能性。

5.1.

#### 最佳战争模式天赋

在本节中，我们将对最适合升级和单人/小队PvE内容的PvP天赋进行排名。以下是通用PvP天赋和术士恶魔学识专精特定PvP天赋的排名。

1. [[spell:353753]]允许你将目标从标记位置拖走来进行爆发。
2. [[spell:248855]]将你的传送门射程增加20码，并将使用它的玩家身上的减益效果持续时间缩短15秒，使其成为需要更高机动性时的良好选择。
3. [[spell:212295]]召唤一个持续3秒的护盾，反射所有以你为目标的有害法术。
4. [[spell:201996]]只在应对大量施法小怪时才有意义。
5. [[spell:212459]]守卫一个位置15秒；任何进入范围的敌人将受到最多5%最大生命值的伤害。在某些情况下可以非常战略性地使用，并能造成可观的爆发伤害。
6. [[spell:201996]]守护一个位置20秒；在范围内施法的敌人将受到最多相当于其最大生命值5%的伤害。这在大多数情况下的用途更为有限，但在特定情况下可能具有极高的价值。
7. [[spell:1240189]]使[[spell:104316]]变为瞬发。由于我们经常使用[[spell:1276947]]，这个天赋的生活质量价值降低了。如果你偏好稳定性可以使用它，但通常有更好的选择。
8.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月11日：** 更新了天赋选择。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月25日：** 12.0.7补丁后更新了单体目标推荐。
- **2026年6月15日：** 更新了 恶魔使徒 天赋。
- **2026年6月12日：** 为12.0.7补丁添加了全知卷册。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月13日：** 进一步修复错误后更新了地下城天赋。
- **2026年4月2日：** 修复错误后更新了 恶魔使徒 地下城天赋。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为至暗之夜的发布更新了天赋树并添加了巅峰部分。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025年3月5日：** 天赋推荐的小幅更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已针对11.0.7补丁进行审查。
- **2024年11月29日：** simc实现更新后更新了天赋。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日：** 最新热修复后将单体目标推荐改回 恶魔使徒。
- **2024年9月9日：** 更新了第1赛季天赋推荐。
- **2024年8月29日：** 更新了单体目标天赋推荐。
- **2024年8月26日：** 更新了所有天赋树并添加了宝库天赋推荐。
- **2024年8月21日：** 更新了推荐以包含英雄天赋树。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 为10.2.5补丁更新了AoE天赋。
- **2023年11月28日：** 更新了单体目标配置。
- **2023年11月6日：** 为 10.2 补丁更新了天赋。
- **2023年9月4日：** 已针对10.1.7补丁更新
- **2023年7月10日：** 为 10.1.5 补丁更新了天赋。
- **2023年5月1日：** 为 10.1 补丁审查了天赋。
- **2023年3月20日：** 为10.0.7版本更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 技能循环与冷却

在本页中，你将学习如何优化你的术士恶魔学识专精在单体和多目标情况下的输出循环。我们还有关于冷却时间、触发效果等方面的进阶内容，以最大化你的DPS。我们所有的内容都已更新至魔兽世界12.1.5补丁。

1.

### 术士恶魔学识专精玩法与输出循环指南

欢迎来到我们的恶魔学识术士输出循环页面。在本页中，你将找到在团队副本和大秘境场景中实际游玩该专精所需了解的一切。

在下方选择天赋和英雄天赋后，本指南中的循环将会相应更新。

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒

单体目标

群体伤害

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者

单体目标

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

最佳选择

群体伤害

主动天赋

被动天赋

[[spell:196277]]

[[spell:264130]]

[[spell:265187]]

[[spell:1276672]]

[[spell:1276452]]

[[spell:1276467]]

[[spell:1281511]]

[[spell:267216]]

### 单体目标

1.1.

#### 单体目标优先级

术士恶魔学识专精围绕生成恶魔力量的系统展开。你拥有的激活恶魔越多，造成的伤害就越高。除了直接伤害外，你还会获得更多的[[spell:267102]]触发，这反过来会带来更多灵魂碎片生成，进而带来更多恶魔。

1. **适用条件：魔典：小鬼领主（启用）。** 施放[[spell:1276452]]。
2. **适用条件：魔典：魔能毁灭者（启用）。** 施放[[spell:1276467]]。
3. **适用条件：召唤恶魔暴君（启用）。** 施放[[spell:265187]]。
4. **适用条件：召唤末日守卫（启用）。** 施放 [[spell:1276672]]。
5. **适用条件：能量虹吸（启用）。** 在拥有2个或更少的[[spell:267102]]且至少有2只野生小鬼存活时施放[[spell:264130]]。
6. **适用条件：地狱归来（启用）；内爆（启用）。** 在有 6 只野生小鬼在场时，施放 [[spell:196277]]。
7. 只要可用就施放[[spell:104316]]。
8. 如果你有4-5个灵魂碎片，施放[[spell:105174]]。
9. 如果你有2层或更多层[[spell:267102]]，施放[[spell:264178]]。
10. **适用条件：恶魔使徒（启用）。** 在灵魂碎片少于或等于 2 个时，施放 [[spell:433891]]。
11. 施放[[spell:686]]来产生灵魂碎片。

### 群体伤害

这是一个新的构筑。点击编辑并在此处添加你的内容。

1.2.

#### 多目标优先级

恶魔学识 在多目标情况下的打法变化很小。

1. **适用条件：魔典：小鬼领主（启用）。** 施放[[spell:1276452]]。
2. **适用条件：魔典：魔能毁灭者（启用）。** 施放[[spell:1276467]]。
3. **适用条件：召唤恶魔暴君（启用）。** 施放[[spell:265187]]。
4. **适用条件：召唤末日守卫（启用）。** 施放 [[spell:1276672]]。
5. **适用条件：能量虹吸（启用）。** 在拥有2个或更少的[[spell:267102]]且至少有2只野生小鬼存活时施放[[spell:264130]]。
6. **适用条件：内爆（启用）。** 在有 6 只野生小鬼在场时，施放 [[spell:196277]]。
7. 只要可用就施放[[spell:104316]]。
8. 如果你有4-5个灵魂碎片，施放[[spell:105174]]。
9. 如果你有2层或更多层[[spell:267102]]，施放[[spell:264178]]。
10. **适用条件：恶魔使徒（启用）。** 在灵魂碎片少于或等于 2 个时，施放 [[spell:433891]]。
11. 施放[[spell:686]]来产生灵魂碎片。

### 起手序列

**适用条件：能量虹吸（未启用）。**

[[spell:264178]]

**适用条件：能量虹吸（启用）；内在恶魔（未启用）。**

[[spell:264178]]

**适用条件：能量虹吸（启用）；内在恶魔（启用）。**

[[spell:264130]]

**适用条件：能量虹吸（启用）；内在恶魔（启用）。**

[[spell:686]]

**适用条件：能量虹吸（启用）；内在恶魔（启用）。**

[[spell:686]]

**适用条件：召唤末日守卫（启用）。**

[[spell:1276672]]

**适用条件：魔典：小鬼领主（启用）。**

[[spell:1276452]]

**适用条件：魔典：魔能毁灭者（启用）。**

[[spell:1276467]]

**适用条件：召唤末日守卫（启用）；恶魔使徒（启用）。**

[[spell:686]]

**适用条件：魔典：小鬼领主（启用）；恶魔使徒（启用）。**

[[spell:686]]

**适用条件：魔典：邪能掠夺者（启用）；恶魔使徒（启用）。**

[[spell:686]]

**适用条件：灵魂收割者（启用）。**

[[spell:686]]

[[spell:246985]]

[[spell:246985]]

[[spell:104316]]

**适用条件：召唤恶魔暴君（启用）。**

[[spell:265187]]

[[spell:105174]]

[[item:250144]]

[[item:241308]]

[[spell:105174]]

**适用条件：内爆（启用）。**

[[spell:196277]]

[[spell:267102]]

**适用条件：能量虹吸（启用）；内在恶魔（未启用）。**

[[spell:264130]]

[[spell:105174]]

1.3.

#### 起手序列

1. **适用条件：能量虹吸（未启用）。** 预读 [[spell:264178]]。
2. **适用条件：能量虹吸（启用）；内在恶魔（未启用）。** 预读 [[spell:264178]]。
3. **适用条件：能量虹吸（启用）；内在恶魔（启用）。** 在有 2 只野生小鬼在场时，预读 [[spell:264130]]。
4. **适用条件：能量虹吸（启用）；内在恶魔（启用）。** 预读 [[spell:686]]。
5. **适用条件：能量虹吸（启用）；内在恶魔（启用）。** 施放 [[spell:686]]。
6. **适用条件：召唤末日守卫（启用）。** 施放 [[spell:1276672]]。
7. **适用条件：魔典：小鬼领主（启用）。** 施放[[spell:1276452]]。
8. **适用条件：魔典：魔能毁灭者（启用）。** 施放[[spell:1276467]]。
9. **适用条件：召唤末日守卫（启用）；恶魔使徒（启用）。** 施放 [[spell:686]]。
10. **适用条件：魔典：小鬼领主（启用）；恶魔使徒（启用）。** 施放 [[spell:686]]。
11. **适用条件：魔典：邪能掠夺者（启用）；恶魔使徒（启用）。** 施放 [[spell:686]]。
12. **适用条件：灵魂收割者（启用）。** 如果灵魂碎片少于 2 个，则施放 [[spell:686]]。
13. 施放 [[spell:104316]]。
14. **适用条件：召唤恶魔暴君（启用）。** 施放[[spell:265187]]。
15. 专注于尽可能多地施放 [[spell:105174]]。
16. **适用条件：内爆（启用）。** 在拥有6只野生小鬼且只有1个或更少的[[spell:267102]]时施放[[spell:196277]]。
17. **适用条件：能量虹吸（启用）；内在恶魔（未启用）。** 在第二个 [[spell:105174]] 之后施放 [[spell:264130]]

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

1.

### 至暗之夜 第2赛季套装

第2赛季套装加成如下：

- [[spell:1296573]] 野生小鬼的伤害提高 10%。[[spell:196277]] 的伤害提高 20%。
- [[spell:1296574]] 被动地使野生小鬼有几率在寿命结束时自我内爆。

这两个套装加成都不是特别强，其设计目的是提供被动的伤害提升，不会改变游戏中的优先级或决策。

1.

### 职业与专精机制详解

以下章节将解释与 恶魔学识 和 术士 相关的各种机制，以及技能以特定方式使用的理由。

### 末日降临

3.1.

#### 末日降临

[[spell:460551]] 的最新版本提供了更细腻的游戏体验和优化机会，尤其是在多目标战斗中。为了最大化其贡献，了解伤害触发条件非常重要：如果目标死亡或减益效果持续时间结束，[[spell:460551]] 将造成伤害。

因此，尽可能对不同目标施放 [[spell:264178]] 是很重要的，尤其是那些生命值较低的目标。

在只有一个目标的情况下，值得注意的是每次后续的 [[spell:105174]] 施放都会使 [[spell:460551]] 的持续时间缩短 3 秒。因此，建议尽可能保留 1 层恶魔之核充能，以便在末日效果过期后重新施加。

### 内爆

3.2.

#### 内爆

为了更好地理解 [[spell:196277]] 的使用，有必要概述该法术的工作原理。

[[spell:196277]] 的伤害由两个不同的部分组成：

1. 对主目标的伤害，与在给定时刻被内爆的野生小鬼的剩余能量成正比
2. 对次要目标的伤害，无论内爆时野生小鬼的能量如何，始终为完整数值

在算上 1 个公共冷却时间的成本后，[[spell:196277]] 本身的施放每次激活的机会成本为 0.75 个碎片（此时你本可以施放 [[spell:686]]）。

另一个需要考虑的因素是与 [[spell:1281511]] 的特定互动：

- 没有该天赋，[[spell:196277]] 在单目标下永远不值得施放
- 拥有该天赋时，在单目标下使用 [[spell:196277]] 是值得的，因为会生成额外的野生小鬼，以及内爆本身带来的额外 [[spell:267102]]

### 顶点天赋

3.3.

#### 阿古斯支配

恶魔学识 巅峰 [[spell:1276163]] 是对最初虚空之门的致敬，以一种更易于上手和直接的方式呈现，尽管精细度有所降低。目标是在传送门持续期间尽可能多地进行召唤，为此玩家需要为每只召唤的恶魔施放两倍数量的 [[spell:105174]]。

因此，务必带着尽可能多的资源（灵魂碎片和 [[spell:267102]]）进入暴君窗口，以加快碎片生成和 [[spell:105174]] 的施放过程。

巅峰天赋的引入，以及暴君根据活跃召唤物动态更新其伤害的改动，使得循环从围绕暴君前的准备转变为暴君后的施放序列。

1.

### 恶魔学识 术士 的重要冷却技能

### 暴君

4.1.

#### 恶魔暴君

[[spell:265187]] 是我们的主要冷却技能。恶魔暴君持续 20 秒，其伤害基于活跃的野生小鬼和恐惧猎犬数量。与之前的版本不同，这里没有快照机制，因为伤害是根据每次施放动态计算的。

虽然 [[spell:265187]] 的准备窗口不像过去那么严格，但重点已经转移到暴君窗口本身，在其中获得尽可能多的 [[spell:105174]] 施放将是优化 DPS 的决定性因素。

1.

### 恶魔学识 术士 重要注意事项

### 灵魂碎片

5.1.

#### 灵魂碎片

所有术士都使用灵魂碎片作为主要资源。正确管理你的碎片对成功至关重要，因为它们控制着你的恶魔大军的规模。在错误的时间错误地消耗灵魂碎片可能会产生多米诺骨牌效应，降低你的伤害输出，尤其是在 [[spell:265187]] 即将冷却完毕的时候。

不过，随着 [[spell:1276947]] 的引入降低了 [[spell:104316]] 的碎片消耗，以及 [[spell:105174]] 固定的消耗，碎片管理和连招已经变得更加简化。

### 恶魔之核

5.2.

#### 管理恶魔之核

[[spell:267102]] 是我们的主要触发效果，几乎是该专精的次要资源。如果你在《德拉诺之王》或更早版本玩过 恶魔学识，你会注意到恶魔之核和恶魔之箭几乎与熔火之心和灵魂 火焰 完全相同。恶魔之核使 [[spell:264178]] 的使用成为可能，换句话说，使我们能够快速生成大量灵魂碎片。恶魔之核最多有 4 层，这使得正确管理这项技能成为娴熟操作的必要条件。

每次接近使用 [[spell:265187]] 时，你都应至少拥有 2 层 [[spell:267102]]。这将使你能够快速生成灵魂碎片，以便在恶魔暴君窗口内尽可能多地施放召唤物。

如果你处于频繁使用 [[spell:196277]] 的情况，你可以更随意地使用 [[spell:267102]] 层数。你的伤害将更多地受益于你能扔向小怪的更多野生小鬼，而不是拥有一个满层的暴君。你仍然需要确保你的暴君能强化几波未引爆的小鬼，但你不应该觉得必须为了顺劈而保留本可以使用的恶魔之核层数。

通常情况下，你不想囤积超过 2 层 [[spell:267102]] 充能，否则你有失去潜在层数的风险；然而，每当你需要爆发或快速转火时，不要犹豫，提前规划并保留更多充能。

### 恶魔选择

5.3.

#### 恶魔选择

始终使用 恶魔卫士，你的 恶魔学识 专属恶魔。你的 [[spell:119898]] 技能现在是 [[spell:89766]]，它同时充当打断和昏迷。建议你将 [[spell:89751]]、[[spell:30213]] 和 [[spell:428344]] 技能设置为自动施放。

在小队或团队环境中，记得关闭你的 恶魔卫士 的 [[spell:134477]]。

### 移动能力

5.4.

#### 移动管理

虽然很难描述在地下城或团队副本战斗中定位和移动的最佳方式，但这对于你作为 恶魔学识 术士 的成功至关重要。[[spell:111771]] 在许多战斗中可以非常有效，但被许多玩家和团队低估了。

把 [[spell:111771]] 想象成一个团队冷却技能，可以立即将你的整个团队传送 40 码，这项技能的潜力很快就变得清晰了。询问你的团队是否希望 [[spell:111771]] 放在特定位置；如果不符合你们的策略，就把它当作个人冷却技能使用。

[[spell:264178]] 可以战略性地用来覆盖移动，因为它是我们要用的唯一瞬发技能。你可以通过站在战斗移动的中心位置来减少移动的需要。

例如，如果 Boss 被风筝绕圈，你应该保持在风筝路径的内侧以确保最小的移动。你还应该确定你的 [[spell:268358]] 如何能让战斗对你来说更容易。有许多 Boss 机制可以通过巧妙的传送门变得微不足道，这可以让你腾出手来造成更多伤害。

[[spell:385899]]与[[spell:111771]]配合使用提供了一种快速覆盖长距离的方法，并在需要立即重新定位时可以用于冲刺。

5.4.1.

##### 静默移动

许多玩家会在战斗中无意识地移动，尽管这没有必要。例如，有时 Boss 或小怪会被坦克拉走几码，虽然你仍在施法范围内，但你会下意识地模仿那种移动，浪费你的公共冷却时间。有意识地努力“安静”你的移动，将不必要的移动减少到最低限度。观察这一点的最佳方式是录制你的团队副本视频，然后观看自己的操作。大多数玩家会对自己浪费的移动量感到惊讶。当你被迫移动时，让你的路径尽可能直接和果断。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026 年 3 月 17 日：** 扩展了套装奖励部分。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年3月2日：** 修复了针对情况选择天赋的起手式。
- **2026年2月26日：** 为至暗之夜的发布更新了输出循环并添加了巅峰部分。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 添加了战斗助手部分。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月25日：** 重新制作了页面布局，并相应地更新了各部分。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 添加了英雄天赋部分和选择器。
- **2024年7月23日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了起手式和优先级列表的选择器。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 装备选择

在本页面，你将找到《魔兽世界》12.1.5 版本中 恶魔学识 术士 的最佳装备、饰品和毕业装备推荐。从制造物品到如何使用你的纹章升级装备的建议，我们应有尽有！

1.

### 恶魔学识 术士 毕业装备指南

欢迎来到 恶魔学识 术士 的装备页面；本节将涵盖你正确装备角色所需了解的一切。

在 [至暗之夜](<https://www.icy-veins.com/wow/midnight-expansion-guide>) 继续使用纹章系统，该系统允许你沿着与获取物品来源相关的轨道提升装备的物品等级，更难的内容掉落的装备可以升级到更高的物品等级。欲了解更多信息，请阅读我们关于如何的专属页面
[配装系统](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) 运作方式以及至暗之夜资料片中的变化。

### 总体

此列表包含来自所有来源的 恶魔学识 术士 最高 DPS 配置。请记住，还有许多其他配置的表现在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩部：[[item:239031@JAACAAAG2A]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸甲：[[item:271549@JAACAAgNyA]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：[[item:268243]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿甲：[[item:271545@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 常见问题我应该从大宝库中选择哪些物品？
团队副本中的稀有掉落以及在模拟中

[最佳装备](<https://www.raidbots.com/simbot/topgear>)

能带来最高提升的物品应优先追求。以下是值得追逐的部分物品：

- [[item:271092]]：仅凭物品等级就是最佳的施法者武器
- [[item:271874@JAACAAAG2A]] 和 [[item:268265@JAACAAAG2A]]，高物品等级且带有强力咒术效果的物品
- [[item:270164@JAACAAgNyA]] 是本赛季最好的饰品

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 秘境+

此列表包含来自地下城的 恶魔学识 术士 最高 DPS 配置。请记住，还有许多其他配置的表现在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:251199@JAACAAgNyA]]，来自 [致盲之谷](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>)
- 肩部：[[item:239031@JAACAAgNyA]]，来自 [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 胸部：[[item:273785@JAACAAgNyA]]，来自 [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- 手部：来自的[[item:159247@JAACAAgNyA]] [塞塔里斯神庙](<https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide>)
- 腿部：[[item:251160@JAACAAgNyA]] 来自 [纳洛拉克的洞穴](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 小贴士：应该优先刷哪些地下城？
如果你的游戏时间有限，可以考虑刷以下地下城：

- [毒牙祭坛](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)：武器和饰品
- [虚空之痕竞技场](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)：项链、腰带和第二个饰品
- [密谋小径](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)：戒指、披风和靴子

:::

:::details 常见问题：双手法杖和单手武器+副手之间有区别吗？
只要物品等级相同，两者在总属性值上就没有区别。

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:251199@JAACAAgNyA]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">致盲之谷</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></div></td></tr><tr><th>项链</th><td>[[item:251234@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>腰部</th><td>[[item:251222@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">纳洛拉克的洞穴</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:251132@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></div></td></tr><tr><th>脚部</th><td>[[item:251137@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:158366@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/temple-of-sethraliss-dungeon-guide" rel="noopener noreferrer">塞塔里斯神庙</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:251136@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">密谋小径</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:273649@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">诸王之眠</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:250224@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">虚空之痕竞技场</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:273778@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">毒牙祭坛</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

### 团队副本

此列表包含来自团队副本的 恶魔学识 术士 最高 DPS 配置。请记住，还有许多其他配置的表现在误差范围内。此列表是 **并非终极定论** 的列表，任何未列出的物品都远逊于这个特定选择。

此列表绝不能替代 [模拟你自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)。根据你之前的宏伟宝库选择以及你拥有的装备，你的毕业装备在某些部位可能与下面的列表不同。

在某些非套装部位，最高物品等级的制造物品在技术上是最优的，因为你可以根据喜好自定义副属性。你的情况可能有所不同。

:::details 常见问题：应该以哪些套装部件为目标？
在第2赛季中，

[催化剂](<https://www.icy-veins.com/wow/catalyst-guide>)

已被改为保留原物品的基础属性和物品等级，这使得在遵循特定属性分配的同时能够获得套装加成。以下是理想的催化物品，但请注意

**胸甲和腿甲**

是直接掉落的。

- 头部：[[item:271874@JAACAAAG2A]]，来自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- 肩膀：[[item:268241]]，来自 [双生利牙](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- 胸甲：[[item:271549@JAACAAgNyA]]，来自 [Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)
- 手套：[[item:268243]]，来自 [盘绕祭坛](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- 腿甲：[[item:271545@JAACAAgNyA]]，来自 [斯索拉克](<https://www.icy-veins.com/wow/sszorak-raid-guide>)

优先获取套装加成而非理想的属性分配，因为前者带来的DPS提升更高。

:::

:::details 小贴士：团队副本中最重要的掉落是什么？
以下是值得优先获取的最重要掉落。

- [[item:271092@JAACAAAG2A]]：物品等级最高的武器。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:271874@JAACAAAG2A]]：在属性预算较高的部位中物品等级最高且属性优秀。掉落自 [乌拉特克](<https://www.icy-veins.com/wow/ulatek-raid-guide>) 位于 [剧毒深渊](<https://www.icy-veins.com/wow/venomous-abyss-raid-guide>).
- [[item:281215@JAACAAgNyA]]：综合最佳饰品。掉落自 [Kith'ix](<https://www.icy-veins.com/wow/kithix-raid-guide>).

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>头部</th><td>[[item:271874@JAACAAAG2A]]&#10;&#10;<div>[[item:240983]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:243951]]</span></div></td></tr><tr><th>手套</th><td>[[item:271547@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>项链</th><td>[[item:268265@JAACAAAG2A]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></div></td></tr><tr><th>腰部</th><td>[[item:268257@JAACAAgNyA]]&#10;&#10;<div>[[item:240890]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">斯索拉克</a></div></td></tr><tr><th>护肩</th><td>[[item:271544@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">迷失的探险者</a></span><span>[[item:243991]]</span></div></td></tr><tr><th>腿部</th><td>[[item:271545@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 来自 <a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>披风</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></div></td></tr><tr><th>脚部</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">盘绕祭坛</a></span><span>[[item:243953]]</span></div></td></tr><tr><th>胸部</th><td>[[item:271549@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">催化剂</a> 或 <a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>戒指</th><td>[[item:268249@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>衬衣</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>戒指</th><td>[[item:281029@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]][[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>战袍</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>饰品</th><td>[[item:270170@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">双生利牙</a></div></td></tr><tr><th>护腕</th><td>[[item:239648@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:240906]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">裁缝</a></div></td></tr><tr><th>饰品</th><td>[[item:281215@JAACAAgNyA]]&#10;&#10;<a href="https://www.icy-veins.com/wow/demonology-warlock-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/kithix-raid-guide" rel="noopener noreferrer">Kith'ix</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>主手</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">乌拉特克</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>副手</th><td>[[item:245769@JAAGAAwt1ENMMYD]]&#10;&#10;<div>[[item:273059]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">制造</a> 由 <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">铭文</a></span></div></td></tr></tbody></table>

请记住，催化后的物品现在会保留原物品的属性！

1.

### 恶魔学识 术士 饰品推荐

以下列表提供了所有可供玩家获取的饰品的综合排名，以便更好地了解哪些饰品可能更具吸引力。这些排名假设每件物品都处于其最高可能的物品等级，因此若要进行直接或即时的装备提升，最好还是对自己的角色进行模拟。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **恶魔学识 术士 饰品**
**毕业 -**

[[item:281215@JAACAAgNyA]]

和

[[item:273649@JAACAAgNyA]]

**次选被动饰品——**

[[item:270164@JAACAAgNyA]]

或

[[item:250224@JAACAAgNyA]]

**次选主动饰品——**

[[item:270170@JAACAAgNyA]]

或

[[item:250215@JAACAAgNyA]]

:::

任何未在此列表上显示的饰品，通常都被认为比此列表上所有其他饰品都要差。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) 点击查看 恶魔学识 术士 饰品排名
<table>&#10;<tr>&#10;<th>排名</th>&#10;<th>饰品</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273649@JAACAAgNyA]]</li>&#10;<li>[[item:281215@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796@JAACAAgNyA]]</li>&#10;<li>[[item:270167@JAACAAgNyA]]</li>&#10;<li>[[item:270164@JAACAAgNyA]]</li>&#10;<li>[[item:270169@JAACAAAG2A]]</li>&#10;<li>[[item:270170@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250224@JAACAAgNyA]]</li>&#10;<li>[[item:250214@JAACAAgNyA]]</li>&#10;<li>[[item:250215@JAACAAgNyA]]</li>&#10;<li>[[item:270168@JAACAAAG2A]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C级</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273794@JAACAAgNyA]]</li>&#10;<li>[[item:270161@JAACAAgNyA]]</li>&#10;<li>[[item:250259@JAACAAgNyA]]</li>&#10;<li>[[item:193757@JAAKAAQkCYHKvbRLfYjM]]</li>&#10;<li>[[item:158368@JAACAAgNyA]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

1.

### 虚空核心（额外奖励骰）和升腾毒石

[混沌虚空核心](<https://www.wowhead.com/currency=3418>) 作为额外战利品使用，可保证从首领或地下城的掉落列表中掉落一件物品。虽然掉落本身是随机的，但每额外消耗一个虚空核心，都会保证在掉落列表全部掉落完之前不会出现重复物品。

3.1.

#### 恶魔学识 术士 推荐的虚无核心使用方法

朦胧虚空核心是一种宝贵但有限的资源，虽然通常应用于填补玩家当前装备的空缺，但重要的是要记住，能多快保证获得一件物品，取决于该来源已经掉落了多少件其他物品。

并非所有掉落都同样重要，以下是应优先关注的通用优先级列表：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **虚空核心定向优先级**
1. 史诗级路线的[[item:271092@JAACAAAG2A]]
2. 史诗级 [[item:271874@JAACAAAG2A]]
3. 史诗级武器（单手或双手）；
4. 史诗级饰品（尤其是[[item:281215@JAACAAgNyA]]）；
5. 缺少2件套或4件套加成的套装部件；
6. 你BiS列表中影响最大的部位。

:::

3.2.

#### 晋升毒液石

[[item:280562]]作为第2赛季中升级装备的方式回归。以下是各装备部位的升级优先顺序：

1. 主手武器最为重要
2. 副手武器
3. 主动使用饰品
4. 被动饰品
5. 项链。

[[item:280562]]也可用于将后2个首领掉落的英雄难度命运骰子物品升级至340物品等级。

1.

### 恶魔学识 术士 最佳制造物品

制造装备的主要限制因素仍然是每周发放的火花，这是制作高端装备所必需的，因此了解如何处理这个问题很重要。

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **恶魔学识 术士 制造装备优先级**
1. 总体最佳组合是手腕部位使用[[item:240167]]，副手饰品使用[[item:273059]]，但这适用于装备已毕业的角色，因此应被视为长期策略，更适合那些不需要立即获得最高战力提升，而是选择最少重铸次数和资源投入的玩家。
2. 如果重点是立即获得战力提升，那么使用4个火花制作带有[[item:273060]]的[[item:245770@JAAGAAwt1ENMMYD]]，并以较低物品等级制作带有[[item:240167]]的手腕，能提供最大的DPS提升。

:::

每次制造所使用的公函如下：

- 武器和手腕使用[[item:245786]]
- 其他任何部位使用[[item:245783]]

:::details 常见问题：如果武器不是毕业装备，为什么要先制造武器？
武器提供最高额的主属性，尤其是在前期，这是非常珍贵的资源。然而制造物品的物品等级上限比完全升级的史诗级替代品低4个物品等级，因此在高端装备方面有所限制，前提是玩家能够获得那种级别的装备。

:::

:::details 常见问题：是否值得为更换公函而重铸？
如果相关的重铸成本不是问题，可以考虑在任何时候模拟你自己的角色，以获得当时最佳的铭文。在单件装备上更改副属性不太可能带来超过十分之一个百分点的 DPS 提升。

:::

有关制造装备的更多信息，你可以访问我们的 [专业页面](<https://www.icy-veins.com/wow/professions>).

4.1.

#### 为装备添加插槽

在第2赛季中，[[item:275707]]可在宏伟宝库中以6个代币兑换，可用于为任意头部、腰部或手腕物品添加插槽。

1.

### 纹章使用

迷雾纹章是一种有每周上限的赛季限定货币，上限每周增加，用于将物品升级至各自奖励路线中的最高等级。

由于每个装备部位的设计不同，其战力也存在差异，这与特定效果或更高的属性有关。因此，以下是投资迷雾纹章最有价值的部位顺序：

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **恶魔学识 术士 纹章升级优先级**
**武器**

➜

**饰品**

➜

**头盔/胸甲/腿甲**

➜

**项链**

➜

**副手**

➜

**肩部/手套/腰带/靴子**

➜

**戒指**

➜

**手腕/披风**

:::

1.

### 评估升级

在本页面及我们攻略的其他部分，我们经常提到在 Raidbots 上为自己进行模拟的重要性。这是因为每个角色都是独一无二的，你所能获得的每件装备都可能改变目前最适合你的选择。

虽然我们确实提供装备和饰品推荐，但这些并不能完全替代你自己跑模拟。真正将你的角色优化到那个程度的唯一方法，就是充分利用现有的工具！

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 为补丁12.1.5进行了更新。
- **2026年8月31日：** 更新了饰品列表。
- **2026年8月16日：** 更新了最佳配装列表、美化和饰品，以适应新的属性配置和饰品调整。
- **2026年8月11日：** 更新了宝石和常见问题解答部分。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7补丁更新。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月27日：** 更新了饰品排名。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 为 至暗之夜 发布进行了更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 为11.2.7补丁更新。
- **2025 年 10 月 5 日：** 为11.2.5补丁更新。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月24日：** 根据调整更新了暗影牧师的插槽推荐。
- **2025年6月15日：** 为 11.1.7 补丁和暗影牧师进行了更新。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025年4月4日：** 已更新饰品推荐。
- **2025年3月4日：** 更新了毕业装备列表和饰品排行。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 为 11.0.7 补丁和赛尔西的指环进行了更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 添加了第1赛季毕业装备列表，更新了饰品部分。
- **2024年8月21日：** 添加了赛季前毕业装备列表部分。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季上线进行了更新。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 为 10.2.5 补丁更新了饰品部分。
- **2023年11月7日：** 在波纹孢子斗篷被削弱后更新了美化推荐。
- **2023年11月6日：** 为 10.2 补丁和第3赛季更新了装备推荐。
- **2023年9月4日：** 重新格式化了页面，包含毕业装备表格和部分更新。
- **2023年7月10日：** 已针对10.1.5补丁进行更新。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月24日：** 更新了黑龙戒指部分以考虑正式服的在线修复。
- **2023年3月20日：** 添加了10.0.7补丁新戒指部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月13日：** 更新了美化推荐。
- **2022年12月11日：** 已为第一赛季上线更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 属性优先级

在本页面，你将找到 恶魔学识 术士 的最佳属性优先级。我们首先介绍属性优先级，然后深入解释属性如何与你的专精和游戏玩法互动。我们的内容已针对《魔兽世界》12.1.5 补丁更新。

1.

### 术士恶魔学识专精属性优先级

恶魔学识 术士 的属性优先级如下：

装备等级

急速达到22%

暴击

精通

急速

全能

值得注意的是，我们的副属性在价值上相对接近，因此通常认为优先考虑物品等级是最好的方法，尤其是当你接近属性收益递减时。更均衡的属性分配优于将两个最佳属性堆叠到收益递减的程度。

1.

### 深入属性解析

**智力** 是你的主属性。你应该在所有升级中寻找该属性。它为你提供法术强度，增加你法术的伤害。

**急速** 影响你所有法术的施放速度，以及你的恶魔（野生小鬼除外）在消失前能输出的攻击次数。急速是一个理想的属性，因为它通过 [[spell:267102]] 生成额外资源，并允许更快的灵魂碎片生成。

**精通**，通过 [[spell:77219]]，增加你的恶魔造成的伤害。与单目标相比，它在多目标中更重要。

**暴击** 提高你所有法术和技能的暴击几率。

**全能** 是纯粹的造成伤害提升和承受伤害降低。

2.1.

#### 属性递减收益

每项属性都有一个临界点，超过该点后每点属性带来的提升会减少，这些点被称为递减收益点。一旦你达到这些数值，属性的价值会逐渐降低，可能落后于其他选择。当前的临界点为：

<table>&#10;<tr>&#10;<th style="text-align: left">属性</th>&#10;<th style="text-align: left">10% 减伤等级</th>&#10;<th style="text-align: left">20% 减伤等级</th>&#10;<th style="text-align: left">30% 减伤评级</th>&#10;</tr>&#10;<tr>&#10;<td>精通</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>暴击</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>急速</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>全能</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已针对至暗之夜 12.0.1进行审查。
- **2026年2月10日：** 已针对至暗之夜前夕进行审查。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行审核。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 已更新至10.1补丁。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月15日：** 澄清了优先级列表的推理。
- **2022年12月14日：** 将属性优先级分为单体和多目标。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 附魔与消耗品

在本页面，我们列出了你可以为你的 恶魔学识 术士 获取的最佳宝石、附魔、合剂、药水和食物，基于你的 [属性优先级](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-stat-priority>)。我们还提供了经济实惠的替代方案。本页已针对《魔兽世界》12.1.5补丁进行更新。

1.

### 推荐宝石

可镶嵌宝石分为两类：史诗和稀有。前者提供强大的效果但只能装备1个，后者包括单属性或双副属性组合的宝石。

宝石可以通过来自宝库的[[item:275707]]物品镶嵌到头盔、护腕或腰带上。

闪耀钻石史诗宝石的选择是[[item:240983]]或[[item:240967]]。在获得史诗级装备之前前者更优，之后后者表现更好。

在物品属性方面，选择暴击宝石能获得最佳效果，因为该副属性对术士普遍非常强大。[[item:240906]] 是与 [[item:240983]] 搭配的最佳宝石，而通过装备 4 颗不同颜色的稀有宝石来激活 [[item:240967]] 的全部收益也非常重要。

你应该装备的四种稀有宝石是：

- 橄榄石：[[item:240890]]
- 青金石：[[item:240914]]
- 紫水晶：[[item:240898]]
- 石榴石：[[item:240906]]

<em>强烈建议使用 [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 来模拟你角色的理想宝石和附魔，因为它们可能与一般推荐不同。</em>

**确保在选项中勾选"Always use"和"Only 4+ Colors"复选框。**

1.

### 最佳附魔和武器强化

在所有内容中使用 [[item:243733]] 作为你的武器油。

<table>&#10;<tr>&#10;<th>部位</th>&#10;<th>附魔</th>&#10;</tr>&#10;<tr>&#10;<td>头部</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>护肩</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>胸部</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>腿部</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>脚部</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>戒指</td>&#10;<td>&#10;<ul>&#10;<li>[[item:243957]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>武器</td>&#10;<td>&#10;<ul>&#10;<li>[[item:244029]]</li>&#10;<li>[[item:243973]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

副属性武器附魔可能比[[item:244029]]提供更好的价值，但哪一个最适合你很大程度上取决于你其余的装备。因此，根据你当前的属性分配，你可能需要 [模拟自己](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) 因为你最好的副属性附魔可能与上面列出的不同。

1.

### 最佳消耗品

除了附魔和装备提升之外，确保你为终局内容准备正确的消耗品也会对你的表现产生重大影响。

3.1.

#### 合剂

对于第 2 赛季，[[item:241326]] 是默认选择。

3.2.

#### 药水

如果你的装备几乎没有全能，那么[[item:241288]]应该是首选，否则使用[[item:241308]]。

[[item:271883]]是治疗药水的选择。

3.3.

#### 食物

[[item:242275]]和[[item:255846]]是推荐的食物。你可以直接购买最便宜的那种，或者在团队提供盛宴时食用。

在灭团/死亡相当频繁的情况下，应考虑丰盛版本的食物，因为它们在死亡后仍然存在。

3.4.

#### 强化符文

[[item:259085]]提供约1%的DPS提升，应在开荒期间评估，尤其是在接近关键击杀时。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月16日：** 更新了消耗品以反映新的最佳配装列表。
- **2026年8月11日：** 更新了宝石。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年3月23日：** 更新了茶部分。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月22日：** 更新了武器附魔。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5补丁进行更新。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月12日：** 更新了武器附魔和磨刀石。
- **2024年9月9日：** 更新了宝石部分，因为策略发生了变化。
- **2024年8月21日：** 已针对地心之战进行更新。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了更新。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 已更新至 10.2 补丁。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年5月1日：** 在腐化之怒增益后更新了药水推荐。
- **2023年3月24日：** 更新了原始宝石推荐以考虑额外的正式服在线修复。
- **2023年3月22日：** 更新了原始宝石推荐以考虑25%增益的在线修复。
- **2023年3月20日：** 为 10.0.7 补丁添加了原始宝石部分。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月7日：** 将地下城药水更新为更可靠的微温全能药水。
- **2022年12月14日：** 更新了武器符文。
- **2022年12月11日：** 已针对巨龙时代第1赛季进行更新。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 大秘境

在本指南中，你将找到在《魔兽世界》12.1.5 补丁中使用你的 恶魔学识 术士 挑战大秘境地下城的提示和建议。

1.

### 恶魔学识 术士 在 至暗之夜 第 2 赛季的大秘境

大秘境已成为《魔兽世界》终局内容的重要组成部分，但其繁多的变量让许多玩家感到不知所措。队伍配置、每周词缀、队伍装等、大秘境钥石层数以及队伍的经验与熟练度，都只是影响你如何应对每个地下城的因素之一。本页的目的是帮助你做好准备，了解使大秘境区别于典型《魔兽世界》终局体验的关键差异，包括可能乍看之下并不明显的天赋和循环异常。

如果你不熟悉史诗钥石地下城及其相关的一般机制，你可以在下方我们的至暗之夜史诗钥石地下城页面阅读更多信息，或者如果你想了解当前的史诗钥石地下城环境，可以查看我们的史诗钥石地下城强度排行！

恶魔学识在经过适当的铺垫后有潜力打出极高的爆发性AOE伤害，同时提供多个适合地下城平均拉怪节奏的短冷却技能。由于多个技能具有某种顺劈效果，恶魔学识的伤害特性非常适合地下城，唯一的缺点是受限于特定的铺垫周期，以及一个与昏迷共享的稍长打断。该专精仍然保留了职业基础工具，包括治疗石、灵魂石、诅咒、用于跳怪的[[spell:111771]]，以及诸如[[spell:30283]]和[[spell:5484]]之类的AOE控制技能。

:::details 小贴士如何应对小鬼在大秘境中意外引怪？
除了普遍适用的建议（例如尽可能保持骑乘状态，或解散恶魔卫士）之外，野生小鬼和其他守护者会尝试与玩家面朝方向垂直排列，因此侧移是缓解近距离引怪问题的解决方法。目标是在穿过怪群时让野生小鬼的阵型尽可能狭窄，而不是默认的宽阵型。

:::

1.

### 最佳大秘境天赋配置

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒大秘境配装

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒大秘境天赋

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/diabolist.webp>) 恶魔使徒配装通过[[spell:428522]]和[[spell:428517]]提供了更多的爆发机会，并且总体上在更高目标数量时表现更好，这在高层大秘境中经常发生。

要直接在游戏内导入配装，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxmZGzyAAAAAAAAGzYYBGYbYhGWMmZsMbzMzYGAYmxMzMzMAjZGzsBAAGzMzMDYbGDYA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjehprTwwJbM-DGRUVYCFYYceyCCSgk2KVWCLOigYd8C-AAAA-AOQo0QowITgwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者变体

2.2.

#### 灵魂收割者大秘境天赋

该 ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/soul-harvester.webp>) 灵魂收割者变体的核心思路是在增强恶魔之核生成的同时提供死亡时的伤害效果。它在较低目标数量时伤害更好，并且启动顶峰序列的速度稍快，因此更适合每周大秘境钥匙或会有较小拉怪的地下城。

要直接在游戏内导入配装，请点击计算器底部的导出按钮：

:::talents 天赋构筑
```json
{
  "code": "CoQAAAAAAAAAAAAAAAAAAAAAAwMjZGNLmxiZGzyAAAAAAAMWWGYADYG2CM2MYsMmxMzMAwMmZmZAmZGzMmZDAAMzMzMzMD2mZAGA"
}
```
:::

:::details 来源计算器编码
```
#KE-ITUUVVDHPfhiklnoELM028MTjchprTwwJbM-DGRUVYFey04WYYcu6Sg2QQmmsCLOS2A-AAAA-HIOQ2AEQQhhCzC-
```

:::

1.

### 恶魔学识 术士大秘境灵活天赋

### 功能/防御天赋替换

3.1.

#### 功能/防御灵活天赋

关于AOE打断，[[spell:30283]]和[[spell:5484]]通常可以互换，应在存在免疫眩晕或恐惧的目标时，以及更快的冷却时间是否更重要时进行评估。

[[spell:710]]是一个更加小众的工具，可以将畸变怪、恶魔或元素目标从战斗中移除长达30秒。它对首领无效，在首领战斗中大多数时候主要机制通常会出现免疫该法术的目标。

[[spell:268358]]和[[spell:111771]]可以被视为重新定位工具，后者通常允许特定路线的跳怪，前者则用于个人处理那些会迫使长时间移动的机制。

对于[[spell:108416]]的辅助天赋，[[spell:386664]]减少生命值损失，主要用于需要保持在一定生命值阈值以上的场合，但总体而言不如其替代选择[[spell:386686]]适用，后者冷却时间更快，因此有更多机会减免伤害。

反过来，对于[[spell:104773]]，选择[[spell:317138]]使伤害减免更为显著，通常是首选，因为基础冷却时间足够长，只有在特定战斗需要在3分钟内进行两次减伤时，才应考虑使用[[spell:386659]]。

:::details 小贴士魔典选择
虽然

[[spell:1276452]]

是基础推荐，但需要注意它实际上是一个灵活的选择。两本魔典作为冷却技能的伤害相当，因此主要区别在于哪本魔典的

[[spell:19505]]

或

[[spell:89808]]

更适合特定地下城或队伍配置。如果需要进攻性驱散，值得考虑

[[spell:1276467]]

.

:::

### 伤害天赋替换

3.2.

#### DPS灵活天赋

放弃[[spell:30146]]而选择[[spell:267216]]，可以开放使用[[spell:691]]的恶魔选择，提供非昏迷打断和进攻性驱散，还有额外单体伤害的好处，代价是一些AOE伤害。如果Boss战不需要任何一种功能，那么[[spell:366222]]能提供更多单体伤害。

选择[[spell:455449]]而非[[spell:455450]]，可获得超过4%的单体伤害提升，代价是约2%的AOE伤害下降，具体取决于目标数量。

[[spell:1250375]]应被视为最后一个灵活点，可以重新分配到[[spell:267216]]上以获得更多单体伤害。

1.

### 大秘境深度输出循环提示

虽然单体和多目标循环与中概述的标准优先级没有实质性差异 [循环、冷却与技能页面](<https://www.icy-veins.com/wow/demonology-warlock-pve-dps-rotation-cooldowns-abilities>) 有几点值得注意：

- 在没有资源的情况下开始新一轮拉怪，意味着会有一段相对较长的时间伤害较低，因为[[spell:686]]是触发效果之外唯一的资源生成手段。因此，在拉怪之间保持灵魂碎片/恶魔之核/野生小鬼的衔接，对于在整个地下城中维持较高的DPS曲线至关重要。
- 虽然在地下城怪群结束时内爆看起来很诱人，但通常最好不要这样做，而是尝试将所有碎片用于召唤额外的野生小鬼，以便脱战后恢复3个碎片，并能在下一群怪时施放巨大的[[spell:196277]]或暴君。

1.

### 功能技能与能力

虽然伤害是带恶魔学识 术士的主要原因，但该职业本身也提供了可观的控制和各种辅助能力：

- 诅咒最近回归，可以针对特定危险敌人提供一些优势：[[spell:1714]]可以降低团队的打断需求。同时，[[spell:702]]减轻坦克受到的普通攻击伤害。最后但同样重要的是，[[spell:334275]]可以在需要风筝时减速目标。
- [[item:5512]]冷却时间为1分钟，恢复25%最大生命值，允许每位玩家进行一次紧急治疗。
- [[spell:20707]]提供战斗复活，你可以在死亡跑尸的情况下主动和预防性地使用。
- [[spell:111771]]提供了独特的能力，可以根据地下城跳过地图的某些部分，避免特定的小怪。
- [[spell:30283]]是一个3秒的AOE眩晕，有助于在大型拉怪时减轻坦克的压力。
- [[spell:5484]]在当前版本中，点出[[spell:1270255]]后，作为短冷却时间的群体打断技能尤其强大。
- [[spell:5782]]和[[spell:710]]都是可重复施放的控制技能，可在紧急情况下打断施法或暂时移除目标的战斗能力。

:::details 小贴士：不要低估诅咒！
随着

[[spell:1265813]]

诅咒现在比以往任何时候都更容易在大多数战斗和情境中使用，了解在什么场景下使用哪种诅咒可以减轻团队的压力。

- [[spell:1714]]降低施法速度，并且对任何可以被打断的技能都有效。
- [[spell:702]]会延迟近战攻击之间的时间，应在主要由近战怪物组成的战斗中使用。
- [[spell:334275]]是一种移动速度减速效果，对风筝很有帮助，但在其他情况下更具情境性。

:::

:::details 常见问题如何最好地使用凋零？
灾厄是诅咒的强化版本，但代价是绑定2分钟冷却时间且仅持续12秒。因此应将其视为队伍的防御性冷却技能，以便在适用时减轻即将到来的伤害。每个灾厄遵循与其对应诅咒相同的规则：

- [[spell:1271748]]适用于任何攻击，降低攻击频率和暴击几率
- [[spell:1271802]]适用于任何可被打断的施法

:::

1.

### 应对词缀

### 词缀：升腾

6.1.

#### 恶魔学识 术士词缀应对：升腾

大约每分钟一次，萨拉塔斯会出现并召唤总共10个升腾宝珠，其施法需要被打断。任何控制或打断法术均可生效：

- [[spell:30283]];
- [[spell:5484]]（上限为10个）；
- [[spell:5782]];
- [[spell:6789]];
- 宠物打断。

### 词缀：虚缚

6.2.

#### 恶魔学识 术士词缀应对：虚缚

战斗中，萨拉塔斯会召唤一个虚空大使来强化附近的敌人，它成为优先目标，最好集火击杀。

### 词缀：脉冲星

6.3.

#### 恶魔学识 术士词缀应对：脉冲星

战斗中，萨拉塔斯会显现脉冲星宝珠，缠绕并环绕玩家15秒。对于该机制没有特别的建议，只需承受这些宝珠即可，虽然移动速度降低可以用[[spell:111400]]来抵消。

### 词缀：吞噬

6.4.

#### 恶魔学识 术士词缀应对：吞噬

周期性地，萨拉塔斯会对所有5名玩家施加护盾减益，可以通过治疗量或驱散来移除。诸如[[spell:6789]]和[[item:5512]]之类的治疗技能可以在没有其他驱散手段时帮助移除护盾。

- 来自小鬼和[[spell:1276452]]的[[spell:89808]]各可以驱散一个护盾。

1.

### 恶魔学识 术士宠物选择

作为恶魔学识 术士，你应该始终使用你的恶魔卫士。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月31日：** 添加了非 恶魔卫士 的天赋更换。
- **2026年8月10日：** 已为12.1补丁更新。
- **2026年6月15日：** 更新了 恶魔使徒 天赋。
- **2026年4月20日：** 已更新至12.0.5补丁。
- **2026年4月13日：** 更新了天赋选项以适应热修复。
- **2026年3月16日：** 为至暗之夜第一赛季更新。
- **2026年2月26日：** 已更新至至暗之夜 12.0.1。
- **2026年2月10日：** 针对每次解锁节点的变化更新了天赋树。
- **2026年1月19日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 针对11.2补丁进行了更新。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年11月29日：** simc更新后更新了天赋推荐。
- **2024年10月21日：** 已针对11.0.5补丁进行更新。
- **2024年9月19日：** 为 11.0.5 补丁进行了更新，并添加了地下城提示部分。
- **2024年9月9日：** 针对第1赛季上线更新了天赋选择。
- **2024年7月19日：** 已针对《地心之战》前夕更新。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 更新了天赋和属性。
- **2023年11月7日：** 更新了暴君天赋。
- **2023年11月6日：** 为10.2补丁和第3赛季进行了更新。
- **2023年9月4日：** 重构了天赋部分。
- **2023年7月10日：** 针对10.1.5补丁更新了天赋。
- **2023年5月1日：** 为10.1补丁更新了天赋。
- **2023年3月20日：** 为 10.0.7 补丁更新了天赋。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2022年12月11日：** 更新了推荐配置。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::

## 宏与插件

在本页中，你可以找到一些有用的宏和插件，帮助你在《魔兽世界》12.1.5版本中更轻松地游玩你的恶魔学识 术士。

1.

### 最佳宏

以下是常用宏的示例；你可以根据需要将其调整为任何法术。

1.1.

#### 宠物宏

这些宏允许你管理你的恶魔，因为将宠物姿态设置为协助是首选的游玩方式。

#### 宠物攻击

```wow-macro
/petattack
```

这会命令你的恶魔攻击你的目标。

#### 宠物跟随

```wow-macro
/petfollow
```

这会命令你的恶魔跟随你。

#### 宠物移动

```wow-macro
/petmoveto
```

这会命令你的恶魔移动到你指定的位置。此宏在需要让宠物处于预定位置以完成特定任务时特别有用——例如打断一个原本超出范围的目标——但也可用于最大化恶魔卫士的顺劈/[[spell:89751]]伤害，不过要注意任何下达的命令也会使你的恐惧猎犬、邪犬（如果点了天赋）和暴君移动，如果使用不当会造成更大的损失。

1.1.1.

##### 鼠标指向持续伤害技能

#### 鼠标指向腐蚀术

```wow-macro
#showtooltip 腐蚀术
/use [@mouseover,harm] [harm] 腐蚀术
```

如果鼠标指向的目标是敌对且存活的，则对其施放[[spell:172]]，否则对当前目标施放。

值得一提的是，暴风雪在控制设置中增加了将所有施法切换为鼠标指向逻辑的功能，不过某些技能可能无法正常运作，因此仍然建议花点时间为任何需要鼠标指向用例的技能制作一个宏。

1.1.2.

##### 放逐焦点

#### 放逐焦点

```wow-macro
#showtooltip 放逐术
/use [mod:shift,@focus] [] 放逐术
```

按住Shift同时对焦点目标施放[[spell:710]]，否则对当前目标施放。

1.1.3.

##### 灵魂石鼠标指向

#### 灵魂石鼠标指向

```wow-macro
#showtooltip 灵魂石
/target [@mouseover] 灵魂石
/use 灵魂石
/targetlasttarget
```

针对当前与鼠标指向已死亡盟友相关的bug的变通宏。该宏会先选中鼠标指向的目标以施放[[spell:20707]]，然后切换回之前的目标。

1.1.4.

##### 恶魔法阵

#### 恶魔法阵

```wow-macro
#showtooltip
/stopcasting
/use [mod:shift] 恶魔法阵; [nomod] 恶魔法阵：传送
```

按住Shift放置恶魔之环，或不使用修饰键传送到法阵，同时取消任何正在进行的施法。这样你就省去了手动打断施法的麻烦（以及时间！）。

1.1.5.

##### 暗影之怒/恐惧嚎叫

#### 暗影之怒/恐惧嚎叫

```wow-macro
#showtooltip
/use [known:暗影之怒,@cursor] 暗影之怒; [known:恐惧嚎叫] 恐惧嚎叫
```

根据所选天赋，在光标处施放[[spell:30283]]或改为施放[[spell:5484]]。

1.2.

#### 鼠标悬停恶魔之箭

#### 鼠标悬停恶魔之箭

```wow-macro
#showtooltip 恶魔之箭
/use [@mouseover,harm,nodead] [] 恶魔之箭
```

此宏会在鼠标悬停目标为有效目标时对其施放[[spell:264178]]，否则对当前目标施放。在多目标战斗中用于传播[[spell:460551]]时很有用。

1.3.

#### 魔典：小鬼与魔典：邪能掠夺者

#### 魔典小鬼与邪能

```wow-macro
#showtooltip [known:1276467] 魔典：邪能破坏者; [known:1276452] 魔典：小鬼领主
/cast [known:1276467,@mouseover,harm,nodead][] 魔典：邪能破坏者
/cast [known:1276452,@mouseover,exists,nodead][] 魔典：小鬼领主
```

上面的宏结合了两本魔典（取决于你点了哪一个天赋），可以优先对鼠标悬停目标使用，否则对当前目标使用。这既适用于魔典技能本身，也适用于相关联的功能性法术。

1.

### 最佳插件

2.1.

#### 术士通用插件

在你去下载一大堆不同的插件之前，我们建议你先设置好你的基础界面。暴风雪已经为默认界面添加了各种各样的改进，许多你可能认为不可或缺的插件，现在都可以通过标准界面实现。一旦你设置好了界面，我们建议你思考一下你想要添加哪些方面或自定义层次，然后寻找能实现这些功能的插件，而不是下载一整套你可能根本不再需要的插件。

甚至可以先看看不使用任何额外插件你能走多远，也许你甚至会喜欢不必在每个补丁后花几个小时更新和重新配置界面。许多插件仍在开发中，或专门针对 至暗之夜 上线时发布全部选项，因此你最喜欢的一些插件可能暂时还无法使用。

2.2.

#### ElvUI

ElvUI 是默认用户界面的完全替代品，你经常会发现即使是世界上最好的玩家也会为了某些自定义选项而使用 ElvUI。ElvUI 非常用户友好，只需很少的时间就能设置和掌握。它还预先配备了几乎所有你需要的东西：单位框架、团队框架、小地图、增益和减益效果等等。你可以轻松解锁并拖动所有组件，让你的界面完全按照你想要的样子呈现。ElvUI 简洁、易用，是你界面的绝佳起点。

2.3.

#### 首领模块

首领模块是有用的预制计时器，让你能够跟踪任何战斗中的重要机制。通常它们配备了有用的提示、视觉效果和声音，以确保你不会错过任何重要的东西。

2.3.1.

##### BigWigs 首领模块

[BigWigs](<https://www.curseforge.com/wow/addons/big-wigs>) 是目前可用的最好的首领模块。它具有极高的可定制性，允许你在单个首领级别更改显示内容以及你希望每个警报的自定义程度。

2.3.2.

##### LittleWigs 首领模块

这其实就是 BigWigs，但是用于地下城的版本。它具有相同的自定义选项，让你能够为普通或 Mythic+ 地下城中遇到的所有机制做好最佳准备。

2.3.3.

##### Deadly Boss Mods

[Deadly Boss Mods](<https://www.curseforge.com/wow/addons/deadly-boss-mods>) 是 BigWigs 的替代品，提供几乎完全相同的自定义选项，用于跟踪首领技能、小怪和战斗计时。这是一个很棒的工具，帮助你更专注于自己的角色，而不必担心跟踪所有那些恼人的首领机制！

2.4.

#### 姓名板

姓名板对于让你轻松跟踪基础减益效果和在战斗中快速选择新目标至关重要。虽然 ElvUI 姓名板确实随插件标配，但它们有些局限性，偶尔还会出现故障。下面列出了一些不错的替代品。

2.4.1.

##### Plater 姓名板

[Plater](<https://www.curseforge.com/wow/addons/plater-nameplates>)
提供了非常高的自定义程度和准确性，尽管由于 至暗之夜 中的插件变更而受到一些限制。你仍然可以配置姓名板在特定情况下放大和改变颜色，这可能有助于你在混乱的战斗中跟踪重要的增益和减益效果，这样你就不会迷失方向。需要一些设置，虽然非常简单直接。

2.4.2.

##### Platynator

[Platynator](<https://www.curseforge.com/wow/addons/platynator>) 是一个新开发的插件，由 [plusmouse](<https://www.curseforge.com/members/plusmouse/projects>)开发，他以许多超级有用的插件而闻名，如 Auctionator、Baganator、Prat 等等。他们现在开发了一个非常可定制的姓名板插件，提供大量减益效果、状态颜色、图标、纹理等选项。这绝对值得一试，特别是如果你因为任何原因在使用 Plater 时遇到任何问题。

2.4.3.

##### Details

[Details](<https://www.curseforge.com/wow/addons/details>) 仍然是排名第一的插件，用于自定义伤害和治疗统计。虽然由于 暴风雪 施加的限制，它可能不像以前那样提供那么多跟踪选项，但它仍然存在并继续帮助你自定义 暴风雪 的伤害、治疗和其他指标面板。

1.

### 更新日志

:::details 历史更新记录
- **2026 年 10 月 12 日：** 已针对12.1.5补丁进行审查。
- **2026年8月10日：** 针对12.1补丁进行了审查。
- **2026年6月15日：** 已针对12.0.7版本进行审查。
- **2026年4月20日：** 针对 12.0.5 补丁进行了审阅。
- **2026年3月16日：** 针对 至暗之夜 第1赛季进行了复查。
- **2026年2月26日：** 已为至暗之夜的发布进行更新。
- **2026年2月10日：** 为至暗之夜前夕进行了更新。
- **2025年11月30日：** 针对11.2.7补丁进行了审查。
- **2025 年 10 月 5 日：** 已针对11.2.5版本进行审查。
- **2025年8月4日：** 已针对11.2补丁进行审阅。
- **2025年6月15日：** 为11.1.7版本进行了审查。
- **2025年4月21日：** 已针对11.1.5版本进行审查。
- **2025 年 2 月 24 日：** 已针对11.1.0补丁更新。
- **2024年12月15日：** 已为 11.0.7 补丁更新。
- **2024年10月21日：** 针对11.0.5补丁进行了审阅。
- **2024年9月9日：** 已为《地心之战》第1赛季进行了审查。
- **2024年8月21日：** 已针对《地心之战》进行审阅。
- **2024年7月23日：** 已为《地心之战》前夕版本审阅。
- **2024年5月7日：** 已针对10.2.7进行审查。
- **2024年4月22日：** 为第4赛季进行了审阅。
- **2024年3月19日：** 已针对10.2.6进行审查。
- **2024年1月15日：** 已针对10.2.5补丁进行更新。
- **2023年11月6日：** 为10.2版本进行了审查。
- **2023年9月4日：** 针对 10.1.7 补丁进行了审阅
- **2023年7月10日：** 已针对10.1.5补丁进行审查。
- **2023年3月20日：** 已针对10.0.7补丁进行审核。
- **2023年1月24日：** 为10.0.5补丁进行了审核。
- **2023年1月3日：** 移除了灵魂燃烧宏。
- **2022年12月11日：** 针对巨龙时代第1赛季进行了审查。
- **2022年11月28日：** 已为巨龙时代上线更新。
- **2022年10月25日：** 已为巨龙时代前夕更新。

显示更多

显示更少

:::
