## 专精概览

Welcome to our Fire Mage guide for World of Warcraft Patch 12.1.5.
Here, you will learn how to play as a Fire Mage in both raids
and Mythic+ dungeons: from the very beginning to maximizing your DPS.

![](<https://static.icy-veins.com/images/common/raiderio-logo.svg>)

Fire Mythic+ Resources

[NEW! Top Fire Talent Builds](<https://raider.io/specs/fire-mage/talents>)

[Top Fire Mythic+ Players](<https://raider.io/mythic-plus-spec-rankings/season-mn-2/world/mage/fire>)

[Fire Mythic+ Heatmaps](<https://raider.io/stats/mythic-plus-heatmaps?season=season-mn-2&specs=mage--fire>)

[Popular Fire Group Comps](<https://raider.io/stats/mythic-plus-group-compositions?season=season-mn-2&specs=mage--fire>)

1.

### Fire Mage Overview

The Fire specialization is fantastic at delivering both burst and sustained
damage on a variety of fight types. Fire can cleave on stacked targets,
gaining overall damage while sacrificing minimal single-target
damage. It also has the ability to great AoE damage as long as enemies
are stacked up.
Like all Mage specializations, Fire
has high mobility and is fantastic at doing encounter-specific jobs and baiting
mechanics. Between [[spell:1953]] or [[spell:212653]], [[spell:195283]], and
[[spell:2948]], high movement encounters have minimal impact on Fire's
overall output.

Great Damage Profile — Held Back By Tuning

Fire Mage has a great damage profile, where it has both burst damage and execute
DPS, both valued damage types. It can even do cleave damage for free, while also
having the ability to do solid AoE DPS on stacked enemies. Current tuning
holds it back slightly, but there are usually multiple tuning patches early
on in a Season that can significantly change this.

Decent — Great to Learn Fights With

Fire has a strong kit for raiding, with okay survivability, a good damage
profile, and good mobility. It even brings a raid buff (

[[spell:1459]]

).
DPS with current tuning is on the lower side, and on some (Mythic) Raid
encounters, you need to heavily rely on your healers to stay alive.
Fire can do almost all of its DPS while on the move, and has a relatively
straightforward rotation, allowing you to focus on the encounters, making
it a great spec to learn fights with.

Decent Damage — Great Utility

Fire does decent overall DPS in Mythic+/Dungeons, while it also
comes with multiple layers of AoE interrupts, and provides important buffs
and utility to the group in the form of

[[spell:1459]]

and

[[spell:80353]]

,
providing great utility to any group. It can struggle defensively, having
to rely a lot on your healer to keep you alive (more than most classes),
but with great preparation this can be partly mitigated.

Great utility, especially in smaller groups

Fire Mages come with strong utility, like its raid buff

[[spell:1459]]

,
or the ever-important

[[spell:80353]]

, some crowd-control like

[[spell:31661]]

,
debuff removal via

[[spell:475]]

and enemy buff removal via

[[spell:30449]]

.
Most of this utility (aside from Arcane Intellect) is also brought by other
classes, so the utility is not that valuable in raids, however in Mythic+
the utility is great.

Good defenses, but highly reliant on a few strong cooldowns that can run out quickly

As a Fire Mage, you have a few strong defensive tools.

[[spell:235313]]

is a low cooldown strong defensive tool for low
to medium damage, whereas

[[spell:342245]]

is great at quickly healing
up after a big damage ability by using it pre-emptively. Additionally,

[[spell:45438]]

or

[[spell:414659]]

(mutually exclusive) are extremely
strong at dealing with high damaging abilities, but have long cooldowns.
Finally,

[[spell:86949]]

gives Fire a cheat-death ability, which
is incredibly useful especially when learning new content.
Overall, Fire's survivability is highly dependent on the timing of enemy mechanics,
as it has almost no passive damage reduction,
causing it to be very strong defensively in some encounters, but quickly run out
of defensives in others.

Very Mobile

Fire has some of the best on-demand mobility in the game, due to its ability
to use double

[[spell:212653]]

or

[[spell:1953]]

, and even resetting a charge via some talent options.
Due to this, it can generally get anywhere on a boss fight almost immediately.
You can even get a sprint-like option in the form of

[[spell:382293]]

.
The only downside to its mobility is sustained movement speed, as all of its
mobility is burst-oriented mobility. Fire can also do a large chunk of its
rotation on the move, and the parts where you cannot, can be made up with
via

[[spell:212653]]

.

2.

### Fire Mage in Midnight

### **Season 2**   Changes

2.1.

#### Midnight Patch 12.1.5 Content Guides

Patch 12.1.5 is a mid-season patch for Season 2. It adds two new pieces of
endgame content: a new single-boss raid, the Unbinding of Kith'ix, and the
Labyrinth of Kindo'jan, a new Mega-Delve for [Delves](<https://www.icy-veins.com/wow/delves-guide>). Check out our
guides for both below!

[Unbinding of Kith'ix Raid](<https://www.icy-veins.com/wow/kithix-raid-guide>)

[Labyrinth of Kindo'jan Delve](<https://www.icy-veins.com/wow/labyrinth-of-kindojan-delve-guide>)

2.2.

#### Patch 12.1.5 Changes

Aside from the new raid and the Labyrinth, the patch brings
item level upgrades through [[item:280562]], and more.
Check out our 12.1.5 Patch Hub for a full overview.

2.3.

#### Class Changes

Patch 12.1.5 brings no changes to Fire Mage. The new raid and the Labyrinth
do bring new items, so make sure to check out our
[Gear](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>) page, which also covers how
[[item:280562]] can upgrade your existing equipment.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_firestarter.jpg>) Click for Previous Season 2 Changes
:::details Show Patch 12.1 Class ChangesHide Patch 12.1 Class Changes
Fire goes into Season 2 in a very different spot. The headline is a large
damage buff outside of [[spell:190319]], making time spent outside of
Combustion more meaningful. Additionally, the new tier set builds a lot of the
rotation around [[spell:269650]], and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury had some changes
around [[spell:448601]] and [[spell:449293]].

2.3.1.

##### Damage Tuning

- All Fire ability damage increased by 12%.
- [[spell:11366]] and [[spell:2120]] damage increased by an
          additional 15% on top of that.

Together, this is by far the biggest buff Fire has had in Midnight.

2.3.2.

##### Season 2 Tier Set

Season 2 comes with a new Tier Set:

- [[spell:1296583]]: [[spell:269650]] causes
          [[spell:11366]] and [[spell:2120]] to always critically
          strike.
- [[spell:1296584]]: [[spell:269650]] reduces
          [[spell:11366]] and [[spell:2120]] cast time by 20% and increases
          Pyroclasm's damage bonus by 20%.

[[spell:269650]] also had its duration increased from 15 to 20 seconds,
providing some more flexibility in how you can use it.
This new set effectively locks in Pyroclasm builds as the only viable endgame
builds, tying Fire's identity to the Pyroclasm playstyle. Great if you enjoy those,
but it is not everyone's favorite playstyle.

2.3.3.

##### Apex Talent

[[spell:1257343]] has its damage profile changed:

- [[spell:1257343]] now gives 2% Fire damage for 8 seconds (was 4% for 12
          seconds).
- [[spell:1257349]]: Fire damage increased to 5%/10% (was 3%/6%).
- [[spell:1257348]]: chance to trigger during [[spell:190319]] is slightly lower.

This moves some power out of back-to-back procs (generally only during
[[spell:190319]]) and into non-Combustion phases, further improving Fire's
damage outside of Combustion relative to during Combustion.

2.3.4.

##### Sunfury Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is where the mechanical changes are. Sphere generation and
[[spell:449293]] both work differently:

- [[spell:448601]] base generation reduced from 25% to 12%, and
          [[spell:449596]] no longer raises the maximum to 5 Spheres. Instead it
          adds 12% of generation back (24% in total) and gives every
          Sphere an additional 1% spell damage.
- [[spell:449412]] now extends [[spell:190319]] by 0.8 seconds per
          Sphere (was 0.4), up to a maximum of 2.4 seconds (was 2). Since you are
          back to a three-Sphere maximum, three Spheres reach the full
          extension.
- [[spell:1260272]] has been redesigned. It no longer grants
          [[spell:1236231]] when your Arcane Phoenix expires, instead,
          every spell the Phoenix casts grants a [[spell:449293]] stack, and
          Exceptional spells grant two.
- [[spell:449293]]'s 10 stack cap has been removed. Consuming
          [[spell:195283]] still generates it the same way as before.
- [[spell:449619]] no longer doubles [[spell:449293]] generation
          during [[spell:190319]].

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire received no changes in 12.1.

2.3.5.

##### Defensives and Utility

Overall, Fire became slightly sturdier in 12.1, but the
overall defensive profile does not move much. Most importantly, Fire gets a
second [[spell:235313]] charge, which helps a lot with dealing with
relatively low but more frequent damage. Expand the section below for
the full defensive and utility changes.

:::details **Click for all Defensive and Utility changes**
- [[spell:321708]] now grants an additional
          [[spell:235313]] charge, but no longer increases Blazing
          Barrier's retaliation damage by 200%. The second part was usually
          irrelevant for PvE purposes.
- New talent: [[spell:1297073]] — reduces damage taken from
          area-of-effect attacks by 4%.
- [[spell:1244090]] still restores 50% of your health, but gives
          20% immediately and the remaining 30% over 6 seconds.
- [[spell:2139]] now has a distinct missed visual and sound when you
          use it on a target that is not casting. The interrupt itself is
          unchanged.

:::

The tier set and the Sunfury changes both move Talents around and change how
you use [[spell:269650]], so make sure to check out our
[Talents](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>),
[Rotation](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>) and
[Gear](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>) pages for the details.

:::

:::details Show Season 2 HotfixesHide Season 2 Hotfixes
2.3.6.

##### September 1 Hotfix

Two weeks into the patch, one week into the Season,
    Fire received some minor buffs: **All damage increased by 3%.**

Any buff is welcome, but 3% does not really meaningfully make up for
    the gap between Fire and the top specs. It does help solidify its spot
    as a middle of the pack spec, making it viable for all content aside
    from very high-end Mythic raiding and the highest Mythic+ keys.

2.3.7.

##### September 22/23 Hotfix

With the weekly reset of September 22nd (US) / 23rd (EU), Fire received some
    small buffs, mostly focused on improving its Mythic+ performance:

- [[spell:153561]]'s damage over time increased by 100%. Does not apply in
          PvP.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire: [[spell:1248014]] buffed to increase
          [[spell:2120]] damage by 15%, from 10%.
- ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury: [[spell:451035]] buffed to increase
          [[spell:2120]] damage by 6%, from 3%.

The buffs are roughly 1% DPS increase on single-target, with 3-5% DPS on
    multiple targets, depending on the target count.

These buffs do not change our recommendations in terms of best Talents
    or best Hero Talents to pick.

:::

:::

### Midnight   Changes Overview

2.4.

#### Midnight Changes for Fire Mage

Midnight has arrived, and Fire Mage has received a substantial rework
affecting both the Mage class tree and the Fire spec itself. The core identity of Fire
remains the same, chaining critical strikes for [[spell:195283]] procs, but the
pacing and burst profile has shifted significantly. Fire is now a more burst-oriented spec,
with [[spell:190319]] being a much stronger and more meaningful cooldown,
however with significantly less Combustion uptime, while damage
outside of Combustion is more reliant on fishing for critical strikes. Additionally,
Fire now has significantly fewer buffs and debuffs to track.

2.4.1.

##### Apex Talent

Midnight introduced a new type of talent, called Apex Talent.
It shows up at the bottom of your talent tree, and has four ranks.
It functions similar to other talents, costing talent points like usual.

For Fire, we get the following Apex Talent:

- [[spell:1257343]]: Consuming [[spell:195283]] has a chance to grant
          you a stack of Fired Up, which increases your fire damage. Multiple
          applications may overlap.
- [[spell:1257349]]: Gaining Fired Up reduces your [[spell:319836]]
          cooldown by 2.5 seconds per point, 2 points.
- [[spell:1257348]]: [[spell:190319]] greatly increases the chance of
          getting Fired Up, reducing each time you proc Fired Up. Also causes
          Fired Up to extend Combustion by 1 second.

The Apex Talent is a strong damage increase, especially during
[[spell:190319]], further cementing Combustion as a very strong cooldown.
The bonus damage alone is great, but the reduced [[spell:319836]] cooldown
also causes your Combustion to feel very fast paced.

2.4.2.

##### Hero Talent Changes

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

has been streamlined to reduce buff tracking.
    The tree now focuses on being visually appealing while buffing Fire's
    core abilities and firing off additional Frost spells for extra damage.

:::details **Click to             expand**
- The Fire/Frost Mastery buffs have been completely removed.
- [[spell:153561]] is further cemented as a strong ability for
              Frostfire.
              For example, [[spell:431178]] causes it to give
              [[spell:431176]] alongside the pre-existing
              functionality
              of [[spell:431095]] causing it to
              also fire off a [[spell:153595]].
- New talent: [[spell:1262843]] — Casting [[spell:11366]]
              has
              a chance to fire a [[spell:199786]].
- Many different talents increase the effectiveness of both your
              Fire spells and your procced Frost spells, like
              [[spell:1262845]] causing [[spell:153595]] and
              [[spell:199786]] to apply [[spell:12846]],
              [[spell:1262844]] increasing Ignite from all Frostfire spells,
              [[spell:1248014]] increasing the critical damage of Frost
              spells, etc.

:::

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury

has had any buffs you would previously track and
    play around removed, while keeping the core fantasy of summoning a
    Phoenix to do high burst damage.

:::details **Click to             expand**
- [[spell:451035]] now passively increases [[spell:11366]]
              and [[spell:2120]] damage instead of being proc-based.
- New [[spell:1260272]] talent — When your Arcane
              Phoenix expires, grants Lesser Time Warp (20% Haste for 10 seconds).
- New [[spell:1260673]] talent — [[spell:133]] has a chance
              to summon a [[spell:449569]], which reduces the cooldown of
              [[spell:319836]] when it lands.
- [[spell:449349]] has been reworked — Causes
              [[spell:269650]] to do more damage and causes [[spell:153561]] to
              proc Pyroclasm.

:::

2.4.3.

##### Core Rotational Changes

The biggest change is the shift in pacing especially outside of
    [[spell:190319]].
    You will cast more [[spell:133]]s fishing for
    [[spell:195283]] and [[spell:48107]] procs. This is due to the removal
    of many sources of guaranteed critical strikes and greatly reduced
    Combustion uptime:

- [[spell:257541]] and all related talents have been removed.
- [[spell:383886]] has been removed.
- [[spell:383860]] has been removed.

To compensate, [[spell:133]] now has a significantly faster cast time
    (1.8 sec baseline, down from 2.3 sec), making the rotation outside of
    Combustion feel quite fast despite fewer guaranteed procs. Additionally, a
    new proc in the form of [[spell:269650]] has been added, giving
    [[spell:195283]] a chance to make your next hardcast [[spell:11366]] or
    [[spell:2120]] deal massively increased damage.

2.4.4.

##### Ignite and Cleave Changes

[[spell:12846]] has been reworked: It no longer automatically spreads
    to nearby targets when you cast [[spell:319836]], and its base
    effectiveness is reduced. However, you can regain Ignite spreading (and
    more) through talents like [[spell:1254756]] and [[spell:383489]], making
    cleave builds a real trade-off instead of free damage.

Additionally, the entire [[spell:450716]] / [[spell:44457]] set of
    talents have been removed. However, these were all entirely passive
    and barely ever picked anyway, so this does not meaningfully change
    the rotation.

2.4.5.

##### Other Changes

- Mage defensives have been consolidated and simplified:  
  
  
   ►
                  **Click to expand**
  
  
  - [[spell:235313]] is now your primary defensive.
                        When fully talented into all supported talents it now
                        provides more absorption (30% max HP), damage reduction, and
                        healing you for 15% of damage absorbed. It also has a
                        shorter GCD so you can quickly return to DPSing.
  - [[spell:110959]] and [[spell:55342]] no
                        longer reduce damage taken — they are now purely
                        utility spells.
  - [[spell:414660]] has been removed.
  - [[spell:1244090]] has been added, which allows
                        you to self-heal after dropping to low health, at the cost
                        of some manual control over [[spell:342245]]. Alter Time
                        is normally mostly used for dealing with high burst damage,
                        but via Temporal Realignment, it can also be useful for
                        healing yourself up when you get low health from chip
                        damage.
- Mage Mobility has been slightly reduced and has a few tradeoffs to make now:  
  
  
   ►
                  **Click to expand**
  
  
  - [[spell:212653]] now has only 1 charge base (was 2) and a 30
                        second cooldown (was 25) baseline. You can gain back the
                        lost charge, but it is now a trade-off between
                        [[spell:1270829]] and the extra
                        charge.
  - [[spell:1953]] can now be improved via talents:
                        [[spell:1244031]] grants an extra charge,
                        [[spell:1244340]] reduces its cooldown.
  - [[spell:108839]] has been removed.
- Various utility talents have been nerfed or changed into choice-nodes:  
  
  
   ►
                  **Click to expand**
  
  
  - [[spell:382440]] has been removed entirely.
  - [[spell:157981]] has been removed from baseline (only
                        accessible via Sunfury talent, but very situational).
  - [[spell:157997]] and [[spell:120]] are now mutually
                        exclusive.
  - [[spell:383121]] and [[spell:113724]] are now
                        mutually exclusive.
  - [[spell:2139]] now interrupts for 7 seconds (was 5).

3.

### Basics of Fire Mage Gameplay

Fire Mage is all about chaining critical strikes to trigger
[[spell:195283]]. The main way to do this is by converting [[spell:48107]]s into Hot Streak via
[[spell:319836]]. Most of your time will be spent casting [[spell:133]]
and converting the critical strikes from that via Fire Blasts into Hot Streaks
and using those on [[spell:11366]].

Fire Mage is one of the few specs in the game that has spells that can be
cast during other casts. [[spell:319836]] is the main spell you will be
casting during other spells, but Fire's main DPS cooldown, [[spell:190319]], can also
be cast during other spells.

[[spell:190319]] is Fire's major DPS cooldown, which allows for a period
of heavy burst by making all your spells critically strike, causing a large amount
of [[spell:195283]]s in a short period. A further breakdown of what the 
specialization is built around can be found below in the following bulleted list.

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_fireball.jpg>) **Avoid Overcapping Fire Blast**  
  
  [[spell:319836]] is incredibly important, as it is a guaranteed crit,
    and can be cast while casting other spells. Overcapping these leads to greatly
    reduced amount of [[spell:195283]]s, and with that, a huge damage loss.
    Make sure to get comfortable casting this during your filler casts to
    convert [[spell:48107]] to [[spell:195283]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_hotstreak.jpg>) **Manage Heating Up and Hot Streak Procs**  
  
    This goes hand-in-hand with the first point: Almost all of your damage comes
    from using [[spell:195283]] procs, so make sure you never waste them by
    overriding them, and make sure all of your [[spell:48107]]s get converted 
    into [[spell:195283]] by using one of your methods of guaranteeing crits,
    like [[spell:319836]] or [[spell:2948]] (in execute).
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_soulburn.jpg>) **Always Cast While Moving**  
  
    As a Fire Mage, you have the luxury of always being able to cast something while on the move.
    One of your most frequently cast spells is instant, namely [[spell:11366]]
    with [[spell:195283]]. Focusing your movement around this is very important.
    However, even if you do not have Hot Streak and need to move, you can use
    [[spell:212653]] to move quickly, or [[spell:2948]] which can be cast on the move.
    As Fire, you really have no excuse to not be casting <em>something</em> while on the move.

4.

### How to Gear Up as a Fire Mage

While we always recommend simming yourself for ideal results, we do provide a
dedicated Fire gearing page. We currently cover recommendations for
Season Two gear to start off on the right foot for the release of endgame
Midnight content. Once you've picked up some gear, you'll need the appropriate consumables,
gems, and enchants to go with those new items.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added drop location to list of items to catalyze.
- **12 Oct. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.1.5.
- **12 Oct. 2026 (this page):** Updated for Patch 12.1.5 (new raid and Labyrinth links, no Fire changes), moved Patch 12.1 and Season 2 hotfixes into a dropdown, and removed the Season 1 changes.
- **09 Oct. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated bis gear to show Ascendant Venomstones upgraded item levels, and added Ascendant Venomstones upgrade guidance, and added Kith'ix loot.
- **19 Sep. 2026 (this page):** Added buffs for the September 22/23 weekly reset tuning.
- **03 Sep. 2026 (this page):** Updated viability section based on Mythic progress and early Mythic+ pushing.
- **01 Sep. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated some bonus IDs to ensure they correct tooltips for Venomcursed effects and update neck for bis updates.
- **31 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added the crafted stats to the tooltips of crafted items and aligned the best embellishment list with the crafting order below it.
- **29 Aug. 2026 (this page):** Added week 2 buffs.
- **24 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Corrected to the correct raid name for a ring drop.
- **23 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated overall BiS list to include Hunter's Ritual stone and updated crafting priority to more clearly explain the pros and cons of 2h vs off-hand crafts.
- **17 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated best Flask.
- **15 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated early crafting to use Hunter's Ritual Stone.
- **10 Aug. 2026 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.1.
- **10 Aug. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated optimal talents for 12.1 / Season 2 and updated rotation info for optimal talents.
- **10 Aug. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 12.1.
- **10 Aug. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated spells for the 12.1 changes.
- **10 Aug. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated best talents, rotation, and tier set bonuses for 12.1 changes. Also added new section with 3 core principles of learning Fire.
- **10 Aug. 2026 (this page):** Added Patch 12.1 and Season 2 changes, including the new tier set, and summarized the Season 1 changes into a single dropdown.
- **17 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated bis lists and best trinkets based on updated theorycrafting post-patch.
- **15 Jun. 2026 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated bis lists and trinket recommendations for the new Sporefused gear
- **15 Jun. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Added section for Omnium Folio.
- **15 Jun. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 12.0.7.
- **15 Jun. 2026 (this page):** Added 12.0.7. changes.
- **23 May 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best-in-slot gear and trinket rankings slightly due to May 26/27 buffs.
- **23 May 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated Hero Talent comparisons slightly based on May 26/27th tuning.
- **22 May 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Meteor usage slightly, and remove the Frostfire no-pyro rotation due to minimal to no DPS gain.
- **24 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Swapped some utility talents around for slightly more common default choices.
- **24 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Swapped some utility talents around for slightly more common default choices.
- **21 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Small typo fix
- **21 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Small typo fix
- **20 Apr. 2026 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Nebulous Voidcore and Ascendant Voidcore sections and update bis lists for new item level cap on weapons/trinkets.
- **20 Apr. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated utility section layout and added some additional context for interrupts and utility.
- **20 Apr. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 12.0.5.
- **20 Apr. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for Patch 12.0.5.
- **20 Apr. 2026 (this page):** Added note that Fire received no changes in 12.0.5.
- **04 Apr. 2026 (this page):** Updated viability section based on latest tuning and Mythic numbers.
- **31 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Crucible of Erratic Energies trinket to trinket tier list.
- **24 Mar. 2026 (this page):** Removed section about upcoming changes with Mythic week as Fire received no changes at the start of Mythic week.
- **23 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Removed Tea mention since it does not work in instances.
- **17 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated trinket priorities because of trinket tuning patch.
- **16 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Added some useful links to Heirloom gear and general level advice, and added section for what Heirlooms to use when leveling.
- **16 Mar. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Replaced pre-season BiS list for 3 different season 1 bis lists (overall, raid, m+), updated crafting info for season 1, added trinkets tier list for season 1.
- **16 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated Combustion Macro to have all relevant racials/trinket slots by default and added FAQs for not seeing Hot Streak procs and Meteor/Flamestrike macros and usage.
- **16 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated best consumables due to latest theorycrafting findings.
- **16 Mar. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Midnight Season 1.
- **16 Mar. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Season 1 of Midnight: Updated best talents, flexible talents, added seasonal affixes, etc.
- **16 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Added Tier-set section for season 1 start and added FAQ for Flamestrike usage + Flamestrike macro. Also set default rotation to Frostfire, and added a no-pyroblast rotation for Frostfire due to tuning changes.
- **16 Mar. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated recommended talent builds to specify mythic+ weekly keys vs pushing keys and updated best builds based on tuning changes.
- **16 Mar. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Midnight Season 1.
- **16 Mar. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Added tier set section for season 1 start and updated talents description to indicate there is a slightly better build on the main talent page.
- **16 Mar. 2026 (this page):** Added Season 1 changes + new content, and updated performance for season 1 start.
- **09 Mar. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Fixed mouseover macro for remove curse.
- **03 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated best ring enchant to eyes of the eagle.
- **02 Mar. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Added level 80 tree for easy importing when starting Midnight leveling.
- **02 Mar. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Flamestrike target counts to provide a bit more context.
- **01 Mar. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added Teas for their movement speed bonus to food section.
- **27 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Frostfire rotation to provide more Scorch context.
- **27 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated Frostfire talents to not run Scorch due to it being pretty meaningful DPS loss to cast Scorch over Frostfire bolt.
- **26 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE rotation threshholds for Flamestrike based on latest math.
- **26 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for Midnight 12.0.1.
- **26 Feb. 2026 (this page):** Updated  for Midnight changes (Apex Talents, viability)
- **10 Feb. 2026 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for Midnight 12.0.1.
- **10 Feb. 2026 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated Talent Trees for 12.0.1 tree changes.
- **10 Feb. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated default selected talents based on latest optimal talents and updated rotation for improved Flamestrike usage.
- **10 Feb. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated Talent Trees for 12.0.1 tree changes.
- **10 Feb. 2026 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for Midnight Pre-Patch.
- **10 Feb. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated Talent Trees for 12.0.1 tree changes.
- **10 Feb. 2026 (this page):** Slightly updated viability again to reflect overall performance.
- **23 Jan. 2026 (this page):** Updated the viability section based on live numbers.
- **22 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated Sunfury trees based on latest theorycrafting.
- **22 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated Sunfury trees based on latest theorycrafting.
- **21 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated default rotation checkboxes to be set to Sunfury based on latest findings and added full loadouts for both Hero Specs for both AoE and ST.
- **21 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Optimized Sunfury trees slightly and changed recommended trees to Sunfury based on latest optimizations.
- **21 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Optimized Sunfury trees slightly and changed recommended trees to Sunfury based on latest optimizations.
- **19 Jan. 2026 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for Midnight Pre-Patch.
- **19 Jan. 2026 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for Midnight Pre-Patch.
- **19 Jan. 2026 (this page):** Updated for Midnight Pre-Patch.
- **30 Nov. 2025 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Patch 11.2.7.
- **30 Nov. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.7.
- **30 Nov. 2025 (this page):** Updated strengths and weaknesses to a more informative format + updated for 11.2.7.
- **05 Oct. 2025 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated item levels for 11.2.5 (Turbo boost item levels) and added puzzling cartel section and updated crafting recommendations for unlimited crests.
- **05 Oct. 2025 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 11.2.5.
- **05 Oct. 2025 (this page):** Updated for Patch 11.2.5.
- **09 Sep. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated defensive talents for standard raid talents slightly.
- **05 Sep. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated tier set disclaimer to explain that this page works well both with and without tier set.
- **16 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best trinkets based on trinket tuning and new findings.
- **15 Aug. 2025 (this page):** Updated viability section based on post PTR tuning and actual in-game activity.
- **05 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added more trinkets to the list of trinkets, and updated Mythic+ bis gear slightly.
- **04 Aug. 2025 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for 11.2.
- **04 Aug. 2025 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best in slot lists, trinket recommendations, crafting order, added Reshii section, for 11.2.0
- **04 Aug. 2025 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.2.
- **04 Aug. 2025 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for 11.2.0.
- **04 Aug. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Patch 11.2.
- **04 Aug. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated best builds for 11.2, added section for season 3 utility spells.
- **04 Aug. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated best rotation based on 11.2 changes for both single-target and AoE, added tier rotation changes section.
- **04 Aug. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated all talent builds for 11.2.0, and updated recommended talents based on the changes.
- **04 Aug. 2025 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated spells for the 11.2.0 changes.
- **04 Aug. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated optimal rotation, talents, hero talents for 11.2 changes and tier bonus.
- **04 Aug. 2025 (this page):** Added patch 11.2 information and removed some of the older patch changes.
- **24 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated DISC Belt information for the changes coming with the reset.
- **17 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Slightly update Durable Information Securing Container Belt information to show % gains for the different bonuses.
- **17 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **17 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **15 Jun. 2025 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for 11.1.7.
- **15 Jun. 2025 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Durable Information Securing Container Belt information and best bonuses, and updated BiS lists for new belt.
- **15 Jun. 2025 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.7.
- **15 Jun. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Added Combat Assistant information and tips.
- **15 Jun. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.7.
- **15 Jun. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Added Combat Assistant information and tips. Clarified stats in more detail.
- **15 Jun. 2025 (this page):** Added Patch 11.1.7 information.
- **20 May 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated Puzzling Cartel Chips section to have more context and removed reference to Neural Synapse Enhancer.
- **15 May 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated item levels to turbo item levels, and updated recommended trinkets with more context and options, and updated cartel chips with more context and different track recommendations.
- **27 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated Puzzling Cartel Chips section with latest information.
- **21 Apr. 2025 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for 11.1.5.
- **21 Apr. 2025 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for 11.1.5.
- **21 Apr. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Counterfeit Dealer's Chips section.
- **21 Apr. 2025 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added Corruption Enchants section.
- **21 Apr. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated default single-target rotation to Frostfire.
- **21 Apr. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated recommended single-target talents to Frostfire after latest Frostfire buffs.
- **21 Apr. 2025 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.1.5.
- **21 Apr. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Added note that the Frostfire talent build is stronger, but more difficult to play.
- **21 Apr. 2025 (this page):** Updated for Patch 11.1.5.
- **30 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Add warning to not spec into Lessons in Deblitation for TOP+Brew.
- **22 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Removed wind up interrupt tip as they cannot be interrupted by disorients.
- **20 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Removed unneeded sections.
- **16 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Updated alter Time usage on healing absorbs due to Alter Time healing changes.
- **15 Mar. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated crafting order to be more organized by clearly splitting the first craft versus the rest.
- **14 Mar. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Added tips for all dungeons.
- **13 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Added Gallywix tips and updated some boss tips based on live kills.
- **10 Mar. 2025 (this page):** Updated viability section based on week 1 performance.
- **04 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Fixed incorrect talent tree for Sprocketmonger
- **03 Mar. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Removed old paragraph that is no longer relevant, and fixed a typo.
- **01 Mar. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Added tips based on PTR.
- **25 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Frostfire BiS gear and updated trinkets for latest tuning and theorycrafting optimisations.
- **25 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Added best Frostfire talents.
- **24 Feb. 2025 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for 11.1.0.
- **24 Feb. 2025 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated talents and rotation for 11.1 changes.
- **24 Feb. 2025 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best in slot for season 2 / 11.1 gear, updated crafting recommendations due to new bis items, updated trinkets for new trinkets.
- **24 Feb. 2025 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated best talents for 11.1 changes, updated affix tips for new affixes.
- **24 Feb. 2025 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for 11.1 changes: New default setup set to sunfury, updated rotation for new optimal rotation due to changes, added a less complex basic rotation.
- **24 Feb. 2025 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated best talents for 11.1: New recommended trees set to Sunfury and updated optimal trees for 11.1 changes.
- **24 Feb. 2025 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for Patch 11.1.0.
- **24 Feb. 2025 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for 11.1: Updated optimal rotation, stats, talents and hero talents for 11.1 changes and tier bonus.
- **24 Feb. 2025 (this page):** Added overview of most important 11.1 changes, updated viability for 11.1, streamlined page further to focus on most important aspects of the guide.
- **20 Feb. 2025 ([Liberation of Undermine page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-liberation-of-undermine-raid-guide>)):** Guide added.
- **17 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated Cyrce's Circlet suggestions after buffs, and updated BiS to include it now that it's better.
- **15 Dec. 2024 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for 11.0.7.
- **15 Dec. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Cyrce's Circlet section.
- **15 Dec. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated page layout to split the different AoE Talents into their own sections, and added recommended tags to more quickly spot the best builds.
- **15 Dec. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for Patch 11.0.7.
- **15 Dec. 2024 (this page):** Added note for 11.0.7 patch and updated viability for 11.0.7.
- **26 Nov. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated talents for the latest buffs.
- **26 Nov. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation to have Frostfire as the defaults now that it is better than Sunfury after the buffs.
- **26 Nov. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated best talents for after the buffs: switching to SKB based frostfire as best builds. Updated AoE builds as well.
- **26 Nov. 2024 (this page):** Added a section with the mid-season buffs and how it impacts the guide. Updated viability for after the buffs.
- **21 Oct. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated talents for 11.0.5 changes.
- **21 Oct. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated talents and split viable talents up into 3 different builds. Also added dungeon specific tips.
- **21 Oct. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated talents for 11.0.5 changes. Split AoE talents in to 3 different builds.
- **21 Oct. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 11.0.5.
- **21 Oct. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated talents for 11.0.5. changes.
- **21 Oct. 2024 (this page):** Added 11.0.5 changes and how it impacts the guide. Updated viability section.
- **02 Oct. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated Flamestrike vs Ignite choice to further emphasize that Flamestrike does more overall DPS.
- **02 Oct. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated Flamestrike vs Ignite choice to further emphasize that Flamestrike does more overall DPS.
- **24 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Fixed incorrect profession linked for off-hand craft.
- **24 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Added Flamestrike based aoe builds now that it is more viable due to the latest buffs
- **24 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE rotation to include a flamestrike based rotation now that it is more viable due to the latest buffs.
- **24 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Added Flamestrike based aoe builds now that it is more viable due to the latest buffs
- **21 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated stat weights description to more clearly explain that using top gear is better.
- **20 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Added more tips to multiple bosses, added exact cooldown usage to various bosses and added cooldowns outline for Queen Ansurek.
- **16 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated crafting recommendations for new BiS setup.
- **14 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated M+ talents to run Improved Scorch instead of Scald for more boss damage without giving up any meaningful AoE damage, and switched Fire's Ire to Molten Fury for all builds due to being slightly more DPS in most scenarios.
- **14 Sep. 2024 (this page):** Updated viability section after latest buffs.
- **11 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added weapon consumable (oil).
- **09 Sep. 2024 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added 3 bis lists from different sources: Raiding, Mythic+, Overall. Added trinket tier list. Removed disclaimer from crafting text.
- **09 Sep. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added Elusive Blasphemite as an alternative gem.
- **09 Sep. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 ([Nerub-ar Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-nerub-ar-palace-raid-guide>)):** Guide added.
- **09 Sep. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for TWW Season 1.
- **09 Sep. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Season 1.
- **09 Sep. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Removed pre-season talents, and updated AoE talents to no longer spend 2 points on AoE talents that add only 0.1% DPS at the cost of single-target DPS.
- **09 Sep. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Removed mention of bug on Ignite the future after the bug fix.
- **09 Sep. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for The War Within Season 1.
- **09 Sep. 2024 (this page):** Updated viability section for Season 1.
- **03 Sep. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated crafting recommendations and bis lists.
- **02 Sep. 2024 (this page):** Updated viability section based on further buffs and Flamestrike overperformance compared to initial expectations.
- **29 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated disclaimer for AoE build to be clearer.
- **28 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Fix a typo.
- **28 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Fixed a typo.
- **28 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated some spell descriptions.
- **27 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated crafting suggestions on updated Embellishments and updated bis lists.
- **24 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Added Delve Talent Tree.
- **21 Aug. 2024 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for The War Within.
- **21 Aug. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for The War Within.
- **21 Aug. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for The War Within.
- **21 Aug. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for The War Within.
- **21 Aug. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for The War Within.
- **21 Aug. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within.
- **21 Aug. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within.
- **21 Aug. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for The War Within.
- **21 Aug. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for The War Within.
- **21 Aug. 2024 (this page):** Updated for The War Within.
- **30 Jul. 2024 ([cosmetics](<https://www.icy-veins.com/wow/fire-mage-cosmetics>)):** Page added.
- **30 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Fixed not having 4 piece in the overall bis list.
- **23 Jul. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/fire-mage-mists-of-pandaria-remix-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for The War Within Pre-Patch.
- **23 Jul. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for The War Within Pre-Patch.
- **23 Jul. 2024 (this page):** Updated for The War Within Pre-Patch.
- **18 Jun. 2024 ([MoP Remix](<https://www.icy-veins.com/wow/fire-mage-mists-of-pandaria-remix-guide>)):** Fixed a typo caused incorrect html
- **17 Jun. 2024 ([The War Within](<https://www.icy-veins.com/wow/fire-mage-the-war-within-pve-guide>)):** Page added.
- **14 May 2024 ([MoP Remix](<https://www.icy-veins.com/wow/fire-mage-mists-of-pandaria-remix-guide>)):** Page added.
- **12 May 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Small rotation update.
- **10 May 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated the separate tier section to refer to the correct tier set.
- **10 May 2024 (this page):** Updated viability section.
- **07 May 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for 10.2.7.
- **07 May 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Reviewed for 10.2.7.
- **07 May 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for 10.2.7.
- **07 May 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for 10.2.7.
- **07 May 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for 10.2.7.
- **07 May 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for 10.2.7.
- **07 May 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for 10.2.7.
- **07 May 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for 10.2.7.
- **07 May 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for 10.2.7.
- **07 May 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for 10.2.7.
- **07 May 2024 (this page):** Reviewed for 10.2.7.
- **22 Apr. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best for Season 4: updated bis lists, tier description, crafting suggestions, etc.
- **22 Apr. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added new season 4 helm enchant, and minor potion improvements.
- **22 Apr. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated best talents based on Season 4 changes.
- **22 Apr. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation based on new tier set from Season 4.
- **22 Apr. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated best talents based on tier changes from Season 4.
- **22 Apr. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Season 4.
- **22 Apr. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated best talents for Season 4 due to new tier set.
- **22 Apr. 2024 (this page):** Added Season 4 changes and updated viability section for Season 4.
- **23 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Split Combustion rotation up into two distinct sections, one to enter Combustion, and one during Combustion, for readability. Additionally simplified the opener description.
- **19 Mar. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for 10.2.6., updating the default addons to a more relevant set of addons for today's Raiding and Mythic+ climate.
- **19 Mar. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Patch 10.2.6., splitting up the different M+ builds into separate boxes so they take up less space and can be viewed more easily.
- **19 Mar. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Patch 10.2.6., added Flame Accelerant as default checked rotation checkbox, and added line for using Fireball in Combustion during it. Also cleaned up some typos.
- **19 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 10.2.6., made Flame Accelerant a default node instead of Alexstrasza's Fury
- **19 Mar. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.6.
- **19 Mar. 2024 (this page):** Reviewed for patch 10.2.6.
- **09 Mar. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated suggested Mythic+ talents slightly, and added more information on picking between Ignite vs Flamestrike builds.
- **09 Mar. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated suggested Flamestrike talents slightly, and added more information on picking between Ignite vs Flamestrike builds.
- **15 Jan. 2024 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.2.5.
- **15 Jan. 2024 (this page):** Replaced 10.2 changes for (lack of) 10.2.5 changes.
- **15 Jan. 2024 (this page):** Updated for Patch 10.2.5.
- **16 Dec. 2023 (this page):** Updated viability section based on December 19th buffs.
- **24 Nov. 2023 (this page):** Updated viability section based on live data.
- **19 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated checkboxes to by default has Alexstrasza's Fury enabled due to optimisations found make AF part of the default talent tree.
- **19 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated talent tree to pick Alexstrasza's Fury by default due to optimisations found.
- **07 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated BiS and embellishments due to sporecloak nerf.
- **06 Nov. 2023 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated all 3 best-in-slot and gearing lists for 10.2, added tier 31 section and updated crafting suggestions based on new crafting item levels.
- **06 Nov. 2023 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Removed sections related to Onyx Annulet as it is now too far behind to be considered.
- **06 Nov. 2023 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated suggested stats due to changes in 10.2.
- **06 Nov. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated talents for 10.2.
- **06 Nov. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for new best talent builds in 10.2, and new tier set.
- **06 Nov. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated suggested talents due to 10.2 changes.
- **06 Nov. 2023 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.2
- **06 Nov. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated suggested talents and stats due to changes in patch 10.2.
- **06 Nov. 2023 (this page):** Added section with 10.2 changes, removed changes from older patches, updated viability section for 10.2.
- **01 Oct. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated food buff suggestion.
- **26 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Changed layout.
- **07 Sep. 2023 (this page):** Updated viability section with more details.
- **04 Sep. 2023 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added 3 different best-in-slot builds.
- **04 Sep. 2023 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Changed talent layout to be easier to navigate.
- **04 Sep. 2023 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.1.7
- **04 Sep. 2023 (this page):** Added 10.1.7 guide changes.
- **09 Aug. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated gem suggestion to haste + vers instead of mastery.
- **09 Aug. 2023 (this page):** Updated viability for after the latest nerfs.
- **01 Aug. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated talent choice between improved scorch and critical mass instead of meteor.
- **15 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE Flamestrike rotation due to the nerf to Flamestrike.
- **15 Jul. 2023 (this page):** Updated viability for after the nerf.
- **14 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated AoE Flamestrike rotation based on latest optimisations.
- **14 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Added disclaimed that Living Bomb should not be used on single target.
- **11 Jul. 2023 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Upated levelling tree for the new talent trees.
- **10 Jul. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best-in-slot for reworked Fire and added Dawn of the Infinite gear section.
- **10 Jul. 2023 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for the Fire rework of 10.1.5, and no changes were necessary.
- **10 Jul. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for the Fire Mage rework of 10.1.5 and the Primordial Gems nerf.
- **10 Jul. 2023 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated suggested stats for the Fire Mage rework of 10.1.5.
- **10 Jul. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated talents suggestions, rotation and utility for after the 10.1.5 Fire rework.
- **10 Jul. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation for the Fire Mage rework of 10.1.5.
- **10 Jul. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated suggested talents after the Fire rework for 10.1.5.
- **10 Jul. 2023 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated all spells and talents for the Fire Mage rework of 10.1.5
- **10 Jul. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated Talents and Rotation for the 10.1.5 Fire rework.
- **10 Jul. 2023 (this page):** Updated for Patch 10.1.5.
- **12 Jun. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Fix talent import string.
- **25 May 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Timwalking section.
- **22 May 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated leg enchant suggestions.
- **08 May 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated trinket suggestions based on improved sims and further theorycrafting.
- **06 May 2023 (this page):** Updated viability section based on item hotfixes impacting spec balance.
- **03 May 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Added note about the suggested talents being based on having 2 and 4 set.
- **01 May 2023 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.1.
- **01 May 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best in slot, crafting suggestions, embellishments and replaced valor description to the new crest system and updated Onyx Annulet section based on new 10.1 gear.
- **01 May 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated Onyx Annulet suggestions based on new 10.1 gear.
- **01 May 2023 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated suggested stats based on 10.1 changes.
- **01 May 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated talents based on new optimal talents and removed mentions to the Flamestrike build as it is now too behind to consider, and removed mentions about thundering.
- **01 May 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated rotation pased on new tier set bonuses and new optimal talents.
- **01 May 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated suggested talents based on 10.1 changes and cleaned up some talent advice.
- **01 May 2023 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Cleaned up some descriptions to be more clear.
- **01 May 2023 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated the suggested talents and rotation for the 10.1 set bonus.
- **01 May 2023 (this page):** Added 10.1 changes, added a section pointing out the major changes to the guide made for 10.1 and updated viability section for 10.1 tuning.
- **28 Apr. 2023 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Added a generic weakaura pack containing all neccesary WeakAuras for all specs.
- **25 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated Onyx ring suggestions based on hotfixes.
- **25 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stone Gem suggestions based on hotfixes.
- **22 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated bis to include Onyx Annulet due to new gem combinations being found.
- **22 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Update Primordial Stone Gem suggestions due to Desirious Blood Stone combinations being very strong.
- **21 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated Primordial Stone gem suggestions based on Obscure Pastel Stone being Arcane instead of Shadow on live servers.
- **20 Mar. 2023 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([Legendaries](<https://www.icy-veins.com/wow/fire-mage-best-legendaries-shadowlands>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Added Onyx Annulet information and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added Primordial Stone gem suggestions and reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.7 and switched mastery to above versatility.
- **20 Mar. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.7 and provided some small phrasing tweaks.
- **20 Mar. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Rewrote parts of the rotation to be easier to follow, and split the SKB/Pyroclasm into its own section. Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Patch 10.0.7.
- **20 Mar. 2023 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.7.
- **20 Mar. 2023 (this page):** Added link to enchants and gems page for Primordial gems.
- **16 Feb. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Removed old note.
- **24 Jan. 2023 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated best in slot advice based on updated theorycrafting.
- **24 Jan. 2023 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Patch 10.0.5.
- **24 Jan. 2023 (this page):** Updated viability section for the 10.0.5 buffs.
- **13 Jan. 2023 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added leg enchant.
- **03 Jan. 2023 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Add Shifting Power to the rotation.
- **17 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated crafted gear due to bronzed grip changes.
- **14 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Added weapon imbuement advice.
- **13 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Further updated crafted gear info with latest theorycrafting knowledge.
- **13 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated phial advice.
- **11 Dec. 2022 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for season 1, including crafted gear, m+ gear and raid gear.
- **11 Dec. 2022 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated trinket recommendations on further theorycrafting, and added more info for crafted gear.
- **11 Dec. 2022 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated phial advice.
- **11 Dec. 2022 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated gems advice based on better simulations.
- **11 Dec. 2022 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Added section explaining rotational changes due to the tier set.
- **11 Dec. 2022 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Update AoE rotation to more clearly explain the AoE rotation when you are not talented into Flamestrike/Flamepath.
- **11 Dec. 2022 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Reviewed for Dragonflight Season 1.
- **11 Dec. 2022 (this page):** Updated for Dragonflight Season 1.
- **30 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Removed flamestrike line from rotation as it is no longer worth using and no longer talented.
- **28 Nov. 2022 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Reviewed for Dragonflight launch.
- **28 Nov. 2022 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for Dragonflight launch.
- **28 Nov. 2022 (this page):** Updated for Dragonflight launch.
- **25 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Split talent suggestions up into Night Fae and non Night Fae section.
- **24 Oct. 2022 ([Leveling](<https://www.icy-veins.com/wow/fire-mage-leveling-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Legendaries](<https://www.icy-veins.com/wow/fire-mage-best-legendaries-shadowlands>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Torghast](<https://www.icy-veins.com/wow/fire-mage-torghast-guide-and-best-anima-powers>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Covenants and Soulbinds](<https://www.icy-veins.com/wow/fire-mage-best-covenants-soulbinds-and-conduits>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([gear page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([addons page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-macros-addons>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([enchants page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-gems-enchants-consumables>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([stats page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Castle Nathria page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-castle-nathria-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sanctum of Domination page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-sanctum-of-domination-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([Sepulcher of the First Ones page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-sepulcher-of-the-first-ones-raid-guide>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([mythic+ page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([rotation page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([talents page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spec-builds-talents>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([spells page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-spell-summary>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 ([easy mode page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-easy-mode>)):** Updated for Dragonflight pre-patch.
- **24 Oct. 2022 (this page):** Updated for Dragonflight pre-patch.
- **26 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/fire-mage-patch-9-2-changes-analysis>)):** Updated tier set section for nerfs applied to it.
- **22 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/fire-mage-patch-9-2-changes-analysis>)):** Updated for Patch 9.2.
- **15 Jan. 2022 ([Patch 9.2 Analysis](<https://www.icy-veins.com/wow/fire-mage-patch-9-2-changes-analysis>)):** Page added with initial thoughts and information.
- **01 Nov. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/fire-mage-patch-9-1-changes-analysis>)):** Reviewed and approved for Patch 9.1.5.
- **13 Jul. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/fire-mage-patch-9-1-changes-analysis>)):** Updated for Patch 9.1 raid release.
- **25 Apr. 2021 ([Patch 9.1 Analysis](<https://www.icy-veins.com/wow/fire-mage-patch-9-1-changes-analysis>)):** Page Created.
- **12 Oct. 2020 ([Ny'alotha page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-ny-alotha-raid-guide>)):** Page updated for the Shadowlands pre-patch.
- **13 Jan. 2020 ([Uldir page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **13 Jan. 2020 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** This page has been reviewed for the release of Patch 8.3 and no changes are necessary.
- **18 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added Azshara tips.
- **16 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** Removed disclaimer.
- **13 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added tips for every boss except for Azshara, updated talent recommendations, and split essence recommendations into 2 categories.
- **10 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** Added initial talent recommendations.
- **07 Jul. 2019 ([The Eternal Palace page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-the-eternal-palace-raid-guide>)):** Page added.
- **24 Jun. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **24 Jun. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** This page has been reviewed for the release of Patch 8.2 and no changes are necessary.
- **12 May 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** Added more tips.
- **15 Apr. 2019 ([Uldir page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** This page has been reviewed and no changes are necessary for the release of the Crucible of Storms raid.
- **15 Apr. 2019 ([Crucible of Storms page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-crucible-of-storms-raid-guide>)):** Guide added.
- **03 Feb. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added tips for Opulence.
- **30 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Updated for Jaina stun hotfixes.
- **28 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added more Jaina info and suggestions.
- **23 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Fixed a section containing Arcane Mage info.
- **21 Jan. 2019 ([Battle of Dazar'alor page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-battle-of-dazar-alor-raid-guide>)):** Added Battle of Dazar'alor guide for Fire Mages.
- **10 Dec. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** This page has been reviewed for Patch 8.1 and no changes are necessary.
- **29 Oct. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** Removed potential usage for Firestarter on Taloc.
- **30 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** Added talent suggestions and boss guides for Uldir.
- **10 Aug. 2018 ([Uldir page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-uldir-raid-guide>)):** Added Fire Mage Boss by Boss empty page for now.

Show more

Show less

:::


## 练级

On this page, you will find our Level by Level Fire Mage leveling guide for [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>).
  **Make sure to use the slider to make the guide adapt to your level.**
  For more general leveling information, please refer to our
[Mage leveling guide](<https://www.icy-veins.com/wow/mage-leveling-guide>).

1.

### Fire Mage Leveling Guide for Midnight

Fire Mage, is relatively strong at outdoor content,
when you are able to do massive pulls during [[spell:190319]] and quickly
kill all enemies. However, it struggles if enemies are spread out, as
Fire takes a little while to start doing its damage properly, and Fire is not
very good at swapping targets often. Unfortunately, these same downsides apply
to dungeons as well, as leveling dungeons often are fast with enemies dying
quickly. Due to this, the best course of leveling is usually to simply
do quests.

1.1.

#### Leveling Gear Options

When leveling up, always choose the piece of loot with the
highest item level. The only exception to this rule is if you have a Ring
or Necklace with a slightly lower item level, but two secondary stats on it
instead of one.

When using Heirloom items, we generally recommend simply running 2x [[item:122361]].
It provides useful sustain, allowing you to chainpull, and makes it so you do
not need to worry about replacing Trinkets while leveling.

For the other Heirlooms, I recommend using Haste items across the board.
Versatility is a safe second stat when picking between multiple
Haste items.

1.2.

#### Useful Leveling Consumables in Midnight

In this section we'll highlight some consumables that can be useful when leveling
in Midnight. These will focus primarily on speed. Both your movement speed,
and of course your actual DPS.

- [[item:223653]] — Boots Speed Enchant. Requires
  Level 70.
- [[item:223800]] — Cloak Speed Enchant.
  Requires Level 70.
- [[item:223725]] — Bracers Speed Enchant.
  Requires Level 70.

- [[item:225592]] — Provides a large amount of
  speed. Requires Level 75.
- [[item:172063]] or [[item:133576]] — Older speed buffs,
  which might be useful if they are much cheaper or you happen to have
  them leftover from previous expansions. Most of these require Level 55.

2.

### Leveling Talents

Below, you can see the suggested leveling talent build and the order in
which to pick the talents while leveling.

If you are just starting your journey into [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>), we have a Level 80
import string for you. You can follow the point-by-point
allocation of the below tree once you start gaining levels in Midnight.

:::talents Fire Level 80 Midnight Leveling
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFbzMjMzYAAAYAAzMTWYGAgNzMjtxMzM2AAAAAwmZGzAAAjZMzYmZmZBAzMwgxgZAA"
}
```
:::

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAMjFDzYmFbzMjMzMDAAADAYmZaWWWmBAYzMzYbMzMjNAAAAAsZmxMAAwYGzMmZmZWAwMDMGjBzwYA"
}
```
:::

:::details 来源计算器编码
```
#:A-VSLLidjiAawdMxy6CLbaD5rwDFECaQAj5TV-CABkbMdwMW0UQK5omuqSSiKmlBJC6MA-AAAA-DSEAGaYWUMcARB-
```

:::

2.1.

#### War Mode Talents for Leveling

In this section we will rank the PvP talents best for
leveling and doing solo / small group PvE content.

1. [[spell:390428]] gives you a significant damage buff. The reduced
   health is usually not a problem in open-world content.
2. [[spell:353082]] puts up a relatively large circle that burns enemies
   who walk into the outer part of the circle, doing significant damage.
3. [[spell:203286]] is a very hard-hitting spell, especially on
   high-health enemies, and it will greatly increase your damage against
   high-health enemies, like world bosses or rares.

3.

### Leveling Rotation

To help with understanding what changes for your spec as you level up and progress through the
talent tree, use the slider below to select your current level. Each time you
level up, move it along, and the section will level up with you!

:::callout 练级内容阅读说明
原文等级滑块中的内容已按等级区间展开，请阅读对应等级的说明。



:::

1. **等级 8 起：**Make sure you keep [[spell:1459]] up at all times.
   Keep in mind, if you die, you have to re-cast it. Otherwise just cast it once per hour.
2. **等级 49 起：**Cast [[spell:80353]] when you are about to go into a big
   pull or boss fight. Keep in mind, you can only gain the benefit once every 10 minutes,
   even though the cooldown is 5 minutes.
3. **等级 75 起：**Cast [[spell:11366]] during [[spell:383860]].
     (the proc you get after [[spell:190319]] ends when specced into [[spell:449619]].
4. **等级 2–9：**Use [[spell:319836]] on cooldown.
5. **等级 39 起：**Cast [[spell:153561]] whenever it is ready. If [[spell:190319]] is coming
   up soon, delay Meteor until Combustion and then use it during Combustion.
6. **等级 15 起：**Cast [[spell:190319]] when it is ready and you have
   at least a couple of charges of [[spell:319836]].
7. **等级 10–20：**Cast [[spell:11366]] when you have
   [[spell:195283]].
8. **等级 21 起：**Cast [[spell:11366]] when you have
   [[spell:195283]] while fighting 1-3 targets.
9. **等级 25 起：**Cast [[spell:2120]] when you have
   [[spell:195283]] while fighting 4 or more targets.
10. **等级 13 起：**Cast [[spell:319836]] when you have
    [[spell:48107]] to get [[spell:195283]].
11. **等级 33 起：**Cast [[spell:2948]] as your filler when the target is below 30% health.
12. **等级 10 起：**Cast [[spell:133]] as your filler.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Added some useful links to Heirloom gear and general level advice, and added section for what Heirlooms to use when leveling.
- **02 Mar. 2026:** Added level 80 tree for easy importing when starting Midnight leveling.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated for 11.1.5.
- **24 Feb. 2025:** Updated talents and rotation for 11.1 changes.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated talents for 11.0.5 changes.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **12 May 2024:** Small rotation update.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **11 Jul. 2023:** Upated levelling tree for the new talent trees.
- **01 May 2023:** Reviewed for Patch 10.1.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **30 Nov. 2022:** Removed flamestrike line from rotation as it is no longer worth using and no longer talented.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 快速入门

On this page, we explain how to easily play Fire Mage in World of Warcraft Patch 12.1.5, using
     the simplest rotation, talent tree, stat priority, gear setup, etc., without sacrificing performance.

1.

### The Basics for Fire Mage

This section is intended for players who are new to the game or class,
have no intentions of raiding Mythic difficulty or simply want a more
straightforward way to play their specialization without being overwhelmed
by the numerous priorities and active abilities that need to be taken into
consideration for optimal play.

Fire is a well-rounded specialization that largely relies on planning
burst windows in advance. Generally speaking, it is not very keybind taxing,
though the number of actions executed in short succession can overwhelm
beginners. In this section, we will be focusing on a setup that
minimizes the number of buttons and reactivity necessary without unduly
compromising overall damage output. Three quick rules to follow when learning the spec are:

- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_fireball.jpg>) **Avoid Overcapping Fire Blast**  
  
  [[spell:319836]] is incredibly important, as it is a guaranteed crit,
    and can be cast while casting other spells. Overcapping these leads to greatly
    reduced amount of [[spell:195283]]s, and with that, a huge damage loss.
    Make sure to get comfortable casting this during your filler casts to
    convert [[spell:48107]] to [[spell:195283]].
- ![](<https://static.icy-veins.com/images/wow/large_icons/ability_mage_hotstreak.jpg>) **Manage Heating Up and Hot Streak Procs**  
  
    This goes hand-in-hand with the first point: Almost all of your damage comes
    from using [[spell:195283]] procs, so make sure you never waste them by
    overriding them, and make sure all of your [[spell:48107]]s get converted 
    into [[spell:195283]] by using one of your methods of guaranteeing crits,
    like [[spell:319836]] or [[spell:2948]] (in execute).
- ![](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_soulburn.jpg>) **Always Cast While Moving**  
  
    As a Fire Mage, you have the luxury of always being able to cast something while on the move.
    One of your most frequently cast spells is instant, namely [[spell:11366]]
    with [[spell:195283]]. Focusing your movement around this is very important.
    However, even if you do not have Hot Streak and need to move, you can use
    [[spell:212653]] to move quickly, or [[spell:2948]] which can be cast on the move.
    As Fire, you really have no excuse to not be casting <em>something</em> while on the move.

2.

### Beginner's Guide to Fire Mage in Midnight

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury   Raid Talents

2.1.

#### Beginner Raid Talents for Fire Mage

This build is your best starting point for single-target situations, like
    Raid encounters. A great benefit of this build is that it is also
    the same build you can use in AoE situations, meaning you only need
    to learn one set of talents for all situations.

The build below does not pick up [[spell:457735]], making it so
    you do not have to track this additional proc, while giving up very little
    DPS for this reduced complexity.

**Be sure to make use of the 'Export Talents' button to import the best
build directly into your game!**

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAMGwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRx7DUo4QAJ5GEE-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury   Dungeon Talents

2.2.

#### Beginner Dungeon Talents for Fire Mage

The Mythic+ build looks very similar to the Raid build, as the DPS
    talents are entirely the same. This is because no switches
    are needed in terms of talents to perform optimal DPS in both
    AoE and single-target.

This build does swap around some utility spells to provide you with
very helpful tools for Mythic+, such as multiple interrupts and dispels.

You can easily import the talent tree below into the game by using the "copy
export string" button below.

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZmHYDAAAAAbmZMzAAgZMmZmZMzsAgZGMjxAmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhlxd0EVFJRx7DUo4QQJJJ-CdIBCw02MUWYs4KRoquATSceimGKe0A-AAAA-DQko0IUY4IDwwC-
```

:::

### Fire Mage   Basic Rotation

2.3.

#### Beginner Fire Mage DPS Rotation

Our goal is to use our strong DPS cooldowns [[spell:190319]]
and get as many critical strikes and instant cast [[spell:11366]]s
as possible. Below, we go over a simplified rotation on achieving this:

1. Delay your first [[spell:190319]] until the target is below 90%
           health. (due to [[spell:205026]])
2. Use [[spell:190319]] when available after your target is below 90%
           health.
3. While [[spell:383860]] is active, cast [[spell:11366]].
4. Cast [[spell:153561]] during [[spell:190319]]. It will also come up
           in-between Combustions, but to keep things simple, I recommend only
           using it during Combustion.
5. During [[spell:190319]], use [[spell:319836]]s and
           [[spell:11366]]s to generate [[spell:48107]] and
           [[spell:195283]]s. When you run out
           of Fire Blast charges, use [[spell:2948]].
6. Cast [[spell:11366]] when you have [[spell:195283]].
7. Hard-cast (meaning: non-instant cast) [[spell:11366]] when you have
           [[spell:269650]].
8. Cast [[spell:319836]] to get [[spell:195283]]s when you have
           [[spell:48107]]. Remember: You can cast Fire Blast
           while casting other spells, so you should cast it during
           [[spell:133]]/[[spell:2948]] when it procs, so you can immediately
           follow the previous cast up with [[spell:11366]].
9. Cast [[spell:2948]] as a filler to generate [[spell:48107]]
           / [[spell:195283]] if the target is below 30% health.
10. Cast [[spell:133]] as a filler to generate [[spell:48107]]
            / [[spell:195283]] when the target is above 30% health.

2.4.

#### AoE Rotation

On anything less than 4 targets, you should stick to the single-target rotation.

On 4 targets or more, you follow the single-target rotation, with one critical change:
Spend [[spell:195283]] and [[spell:269650]] procs on [[spell:2120]] instead of
[[spell:11366]] That's it!

2.4.1.

##### Apex Talent: ![Fired Up Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_incinerate.jpg>) Fired Up

Fire has the following Apex Talent:

- [[spell:1257343]]: Consuming [[spell:195283]] has a chance to grant
  you a stack of Fired Up, which increases your fire damage. Multiple
  applications may overlap.
- [[spell:1257349]]: Gaining Fired Up reduces your [[spell:319836]]
  cooldown by 2.5 seconds per point, 2 points.
- [[spell:1257348]]: [[spell:190319]] greatly increases the chance of
  getting Fired Up, reducing each time you proc Fired Up. Also causes
  Fired Up to extend Combustion by 1 second.

The Apex Talent for Fire grants a lot of damage for both Hero Specs, and
is virtually always taken. Fired Up is a new proc which grants a large
amount of bonus damage whenever it procs, which is just a very nice passive
bonus. However, even more impactful is the massive 5 second [[spell:319836]]
cooldown reduction when it procs, which happens quite
frequently, especially during [[spell:190319]].

This [[spell:319836]] cooldown reduction makes it so you barely run out of
Fire Blast charges during [[spell:190319]], often only running out
towards the very end of Combustion. This allows you to chain [[spell:11366]]
into Fire Blast for almost the entire duration of Combustion without needing
to weave in any other spells.

All these extra [[spell:319836]] charges do cause a bit of a weird luxury
"problem", where it relatively devalues [[spell:269650]], because hard-casting
[[spell:11366]] during [[spell:190319]] risks overcapping Fire Blast
charges, making it difficult to hard-cast during Combustion.
Due to this, you often end up having to delay the hard-casts until Combustion
is over.

2.4.2.

##### Season 2 Tier Set

Our Tier Sets for Season 2 are:

- [[spell:1296583]]: [[spell:269650]] causes
          [[spell:11366]] and [[spell:2120]] to always critically
          strike.
- [[spell:1296584]]: [[spell:269650]] reduces
          [[spell:11366]] and [[spell:2120]] cast time by 20% and increases
          Pyroclasm's damage bonus by 20%.

This tier set focuses entirely on [[spell:269650]], making it pretty much
    a mandatory talent for all builds.

The tier set is incredibly powerful, and you should try to obtain it
    at any item level possible, as it not only greatly increases your DPS,
    it also makes the rotation easier by making the hard-casts from
    [[spell:269650]] quicker, leaving less room to get it interrupted by
    having to move.

### Fire Mage   Stat Priority

2.5.

#### Stat Priority for Fire Mage

You will want to prioritize stats as follows for both single-target and AoE
as follows. For more information on what's presented on this page, check out our main 
[Stat Priority page](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>).

Intellect

Haste

Mastery

Versatility

Critical Strike

We recommend you prioritize item levels over specific stats,
as they are all close in value, and they fluctuate greatly
based on the gear you currently have.

### Blizzard   Combat Assistant

2.6.

#### Combat Assistant For Fire Mage

Patch 11.1.7 introduced two new combat related functionalities,
the Assisted Highlight, and the Single-Button Assistant. For a full
overview on how to enable these features and
all of their details, check out our
[Combat Assistant page](<https://www.icy-veins.com/wow/single-button-assistant-assisted-highlight-guide>).

The Assisted Highlight rotation is a relatively good rotation, so following it
can be a good way to learn the rotation, but you will be giving up
a decent chunk of damage, around 10-20% compared to following the rotation on this page.
Note that Fire is unique in that it can cast spells while using other spells, like [[spell:319836]].
Due to this, seeing the next spell is sometimes not enough, as you need to
also know when exactly you should cast it during the current spell.
Due to this, I highly recommend you also read the basic rotation when using
the Assisted Highlight so you know when to cast the spells that are highlighted.

The Single-Button assistant unfortunately has some issues for Fire, causing
it to be around 30-40% less damage than the rotation on this page.
The global-cooldown penalty applied is a large issue for Fire, because Fire
relies on queueing certain spells at the same time (like [[spell:133]] into [[spell:11366]]),
which the single-button assistant does not allow you to do. Additionally,
Fire simply has very many instant-cast spells, which are also hurt by the
global-cooldown penalty, leading to this ~30-40% damage loss when using the
Single-Button Assistant.

The Single-Button assistance can be useful, especially
when you are new to the spec, or when learning new boss mechanics,
as it will allow you to focus fully on the boss mechanics instead of the rotation.
However, if you want to maximize your damage, I recommend you
either follow the Highlighted rotation, or the rotation on
this page due to the Single-Button
rotation's 30-40% damage loss.

Note that neither the Single-Button rotation nor the Assisted Highlight rotation
will cast/highlight [[spell:190319]], racial cooldowns, or
items, like trinkets, so you will have to use these manually.

2.7.

#### Tips for using the Combat Assistant as Fire Mage

- Make sure to use [[spell:190319]] on cooldown, as the Combat Assistant
  will not use/highlight this.
- Use your trinkets, potions, racial cooldowns (like [[spell:26297]])
  or other on-use cooldowns during [[spell:190319]].
- If using the One-Button Assistant, make sure to press the button a lot,
  as [[spell:319836]] can be cast while casting other spells, so
  you will have to press the button twice to cast both the Fire Blast
  and the spell after it.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated best talents, rotation, and tier set bonuses for 12.1 changes. Also added new section with 3 core principles of learning Fire.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Added tier set section for season 1 start and updated talents description to indicate there is a slightly better build on the main talent page.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Trees for 12.0.1 tree changes.
- **22 Jan. 2026:** Updated Sunfury trees based on latest theorycrafting.
- **21 Jan. 2026:** Optimized Sunfury trees slightly and changed recommended trees to Sunfury based on latest optimizations.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **05 Sep. 2025:** Updated tier set disclaimer to explain that this page works well both with and without tier set.
- **04 Aug. 2025:** Updated optimal rotation, talents, hero talents for 11.2 changes and tier bonus.
- **17 Jun. 2025:** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **15 Jun. 2025:** Added Combat Assistant information and tips. Clarified stats in more detail.
- **21 Apr. 2025:** Added note that the Frostfire talent build is stronger, but more difficult to play.
- **24 Feb. 2025:** Updated for 11.1: Updated optimal rotation, stats, talents and hero talents for 11.1 changes and tier bonus.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Updated talents for 11.0.5. changes.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated best talents for Season 4 due to new tier set.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated suggested talents and stats due to changes in patch 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated Talents and Rotation for the 10.1.5 Fire rework.
- **01 May 2023:** Updated the suggested talents and rotation for the 10.1 set bonus.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 天赋与构筑

On this page, you will find out the best talents for your Fire Mage in World of Warcraft Patch
  12.1.5. We also have default talent builds for various types of content, such as raiding or Mythic+.
  If you play with Warmode on, we have your PvP talents covered as well.

1.

### Best Midnight Talents for Fire Mage

For Season 2, ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is looking to be the strongest Hero Talent
    tree in both AoE and single-target scenarios. It simply does more DPS than
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire, without any downsides whatsoever.

- **Raid -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is meaningfully ahead of ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire
          in Raid content, without having to give up any mobility or important
          defensives for it, making it the preferred choice.
- **Mythic+ -** ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is significantly ahead in
          Mythic+ scenarios due to its higher AoE DPS, while also
          having higher single-target DPS than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire.

Since ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury simply does more DPS than ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire in all
    content without having to give up anything in return, there is no real reason to
    play a build other than Sunfury, unless you greatly prefer ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire visually
    or thematically.

**Quick Start Import Codes:**

:::talents Fire Raid - Sunfury
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAMGwMMGA"
}
```
:::

:::talents Fire Mythic+ - Sunfury
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZGbAAAAAYzMjZGAAMjxMzMjZmlBgZGMjxAmhxA"
}
```
:::

:::talents Fire Delves - Sunfury
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZGbAAAAAYzMjZGAAMjxMzMjZmlBgZGMjxAmhxA"
}
```
:::

to display the talent tree please select the hero talent & content you would like to play

Sunfury

Raid Talents

recommended

Mythic+

weekly-keys

high-keys

Delves and Open World

Frostfire

Raid Talents

Mythic+

### 天赋方案 0-0

1.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Raid Talents

Standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Fire Raid build. It not only has the best
    single-target DPS, it can also do AoE DPS if an encounter requires it,
    without having to make any swaps to do so.

You can swap out of [[spell:110959]] and [[spell:382293]]
    for other utility nodes like [[spell:475]] if you need to dispel
    curses, or [[spell:1270865]] for more interrupts, if needed.

### 天赋方案 0-1

1.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Mythic+ Talents

Standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Fire Mythic+ build. It does both the best AoE DPS
    and best single-target DPS, without having to give up any of either to do
    so, making it the obvious choice for any Mythic+ content.

Feel free to swap out of any of the utility talents like [[spell:475]]
    or [[spell:1270865]] if they are not needed in the specific
    dungeon you are doing. [[spell:110959]] into
    [[spell:382293]] can be a decent pick up if you need more movement speed.

### 天赋方案 0-2

1.3.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Delve Talent

This build is focused on making [Delves](<https://www.icy-veins.com/wow/delves-guide>) as smooth of an experience
as possible. It focuses on maximizing your survival and kiting capabilities, by
speccing into more mobility and crowd-control, while giving up very minimal DPS.
This build is also excellent for outdoor content.

### 天赋方案 1-0

1.4.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Raid Talents

Standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Fire Raid build. It is a very flexible Raid build,
    as it works for both single-target damage and AoE DPS without having to do
    any talent swaps, allowing you to run a single build for all bosses regardless
    of target count on them. Sadly the damage just isn't comparable to ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury.

You can swap out of [[spell:110959]] and [[spell:382293]]
    for other utility nodes like [[spell:475]] if you need to dispel
    curses, or [[spell:1270865]] for more interrupts, if needed.

### 天赋方案 1-1

1.5.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Mythic+ Talents

Standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Fire Mythic+ build. Works great in Mythic+,
    as it does both the best Frostfire single-target and AoE DPS, without
    compromising on either. Unfortunately it cannot keep up with ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury's numbers.

Feel free to swap out of any of the utility talents like [[spell:475]]
    or [[spell:1270865]] if they are not needed in the specific
    dungeon you are doing. [[spell:110959]] into
    [[spell:382293]] can be decent pick ups if you need more movement speed.

### 天赋方案 0-0

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAMGwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRx7DUo4QAJ5GEE-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### 天赋方案 0-1

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAAAmZmmltlZAA2MzM2mZmZGbAAAAAYzMjZGAAMjxMzMjZmlBgZGMjxAmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhlxd0EVFJRx7DUo4QQJJJ-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### 天赋方案 0-2

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAMzwYZmZmFMzIzMzMAAAGAwMz0sssMDAwmZmx2YmZGLAAAAAYzMjZGAAMmhxMzMzsNAMzAMGDmhBA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhltxZkkEFAJRRz7DMQo4A-CdJBCw02MUWYs4KRouyy8ATScgiEHKC-AAAA-DQko0IUY4ADwwC-
```

:::

### 天赋方案 1-0

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDZmZGAAAmZZGzMLzCAAAYxMDbzMzMjNAAAAAsZmxMDAAmZYmxMzMzCwMDIMGDmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRx7DUo4QAJ5GEE-CdIBCw02MUWY4KRoquATScemKeklBJC-AAAA-SgEgZR4QhBAhyA-
```

:::

### 天赋方案 1-1

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAMLzYmZZWAAAALmZYbmZmZsBAAAAgNzMmZAAwMDzMmZmZWAmZANjxYwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRBU4QAJ5Up5XhH-CdIBCw02MUWY4KRoquATScemKeklBJC-AAAA-SgEgZR4QhBAhyA-
```

:::

The builds listed above are popular recommendations,
covering various different loadouts suited to each style of endgame content.
Each Talent Build will have it's own rotation, and can also be manipulated 
further for specific types of content and to better benefit your group.

2.

### Omnium Folio

The Omnium Folio is a new system introduced in Midnight's [Patch 12.0.7](<https://www.icy-veins.com/wow/midnight-1207-guide>), and offers
some minor performance-enhancing customization.
Some of these bonuses affect your damage output, while others are more defensive in nature.

You can change them freely without any penalty, so feel free to experiment with
them to your liking! Below I list the default recommendations:

- Point 1: [[spell:1279596]]
- Point 2: [[spell:1279604]] for group play, or [[spell:1279603]] for solo play
- Point 3: [[spell:1287555]]
- Point 4: [[spell:1279610]]
- Point 5: [[spell:1279616]]

3.

### Apex Talent: ![Fired Up Icon](<https://static.icy-veins.com/images/wow/large_icons/spell_fire_incinerate.jpg>) Fired Up

Fire has the following Apex Talent:

- [[spell:1257343]]: Consuming [[spell:195283]] has a chance to grant
          you a stack of Fired Up, which increases your fire damage. Multiple
          applications may overlap.
- [[spell:1257349]]: Gaining Fired Up reduces your [[spell:319836]]
          cooldown by 2.5 seconds per point, 2 points.
- [[spell:1257348]]: [[spell:190319]] greatly increases the chance of
          getting Fired Up, reducing each time you proc Fired Up. Also causes
          Fired Up to extend Combustion by 1 second.

The Apex Talent for Fire grants a lot of damage for both Hero Specs, and
is virtually always taken. Fired Up is a new proc which grants a large
amount of bonus damage whenever it procs, which is just a very nice passive
bonus. However, even more impactful is the massive 5 second [[spell:319836]]
cooldown reduction when it procs, which happens quite
frequently, especially during [[spell:190319]].

This [[spell:319836]] cooldown reduction makes it so you barely run out of
Fire Blast charges during [[spell:190319]], often only running out
towards the very end of Combustion. This allows you to chain [[spell:11366]]
into Fire Blast for almost the entire duration of Combustion without needing
to weave in any other spells.

All these extra [[spell:319836]] charges do cause a bit of a weird luxury
"problem", where it relatively devalues [[spell:269650]], because hard-casting
[[spell:11366]] during [[spell:190319]] risks overcapping Fire Blast
charges, making it difficult to hard-cast during Combustion.
Due to this, you often end up having to delay the hard-casts until Combustion
is over.

4.

### Hero Talents for Fire Mage

Fire has access to the ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury and ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire
Hero Talent trees.

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury is generally ahead in most situations, making it the
    go-to for most content, as it does this extra DPS without having to
    sacrifice on anything else like utility or survivability.

4.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury mostly focuses around speeding up your rotation
and spawning an Arcane Phoenix alongside you during [[spell:190319]],
throwing out spells of its own providing damage and some utility.
Gameplay wise, Sunfury speeds up your rotation a bit by proving a couple of
sources of cooldown reduction on [[spell:319836]] or additional haste,
but the main rotational change comes from [[spell:449619]],
which grants you [[spell:383860]] when Combustion ends. While
Hyperthermia is active, you can spam instant-cast [[spell:11366]]s or
[[spell:2120]]s, providing another Combustion-like mini-burst after
Combustion ends.

4.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire is entirely focused on augmenting your damage
by firing off a bunch of extra Frost spells, like [[spell:199786]]s
and [[spell:153595]]. Gameplay wise, Frostfire replaces
your [[spell:133]] for [[spell:431044]], which makes your rotation
slightly faster because it has a lower cast time,
but otherwise plays the same as Fireball. The main rotational change comes
from [[spell:431176]], which makes your next Frostfire Bolt
a very hard hitting instant-cast spell that also deals AoE damage.

5.

### PvP Talents (War Mode)

Since Battle for Azeroth, there is the option to enable "War Mode."
Enabling War Mode grants the following benefits:

- PvP talents enabled in the outdoor world.
- 10% increase in World Quest rewards at max level.
- 10% more experience gained while leveling.
- Earn Conquest Points, which can reward gear every week.

With the benefits of enabling War Mode for leveling and PvE content, it is
recommended enabling the feature to maximize your leveling and rewards at max
level. However, doing so will enable PvP combat and the possibility of being
attacked by members of the opposite faction while leveling or doing World
Quests exists.

In this section, we will rank the War Mode talents for leveling and outdoor
content.

1. [[spell:390428]] gives you a significant damage buff. The reduced
   health is usually not a problem in open-world content.
2. [[spell:353082]] puts up a relatively large circle that burns enemies
   who walk into the outer part of the circle, doing significant damage.
3. [[spell:203286]] is a very hard-hitting spell, especially on
   high-health enemies, and it will greatly increase your damage against
   high-health enemies, like world bosses or rares.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Added section for Omnium Folio.
- **23 May 2026:** Updated Hero Talent comparisons slightly based on May 26/27th tuning.
- **24 Apr. 2026:** Swapped some utility talents around for slightly more common default choices.
- **21 Apr. 2026:** Small typo fix
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated recommended talent builds to specify mythic+ weekly keys vs pushing keys and updated best builds based on tuning changes.
- **27 Feb. 2026:** Updated Frostfire talents to not run Scorch due to it being pretty meaningful DPS loss to cast Scorch over Frostfire bolt.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Trees for 12.0.1 tree changes.
- **22 Jan. 2026:** Updated Sunfury trees based on latest theorycrafting.
- **21 Jan. 2026:** Optimized Sunfury trees slightly and changed recommended trees to Sunfury based on latest optimizations.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **09 Sep. 2025:** Updated defensive talents for standard raid talents slightly.
- **04 Aug. 2025:** Updated all talent builds for 11.2.0, and updated recommended talents based on the changes.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Updated recommended single-target talents to Frostfire after latest Frostfire buffs.
- **25 Feb. 2025:** Added best Frostfire talents.
- **24 Feb. 2025:** Updated best talents for 11.1: New recommended trees set to Sunfury and updated optimal trees for 11.1 changes.
- **15 Dec. 2024:** Updated page layout to split the different AoE Talents into their own sections, and added recommended tags to more quickly spot the best builds.
- **26 Nov. 2024:** Updated best talents for after the buffs: switching to SKB based frostfire as best builds. Updated AoE builds as well.
- **21 Oct. 2024:** Updated talents for 11.0.5 changes. Split AoE talents in to 3 different builds.
- **02 Oct. 2024:** Updated Flamestrike vs Ignite choice to further emphasize that Flamestrike does more overall DPS.
- **24 Sep. 2024:** Added Flamestrike based aoe builds now that it is more viable due to the latest buffs
- **14 Sep. 2024:** Updated M+ talents to run Improved Scorch instead of Scald for more boss damage without giving up any meaningful AoE damage, and switched Fire's Ire to Molten Fury for all builds due to being slightly more DPS in most scenarios.
- **09 Sep. 2024:** Removed pre-season talents, and updated AoE talents to no longer spend 2 points on AoE talents that add only 0.1% DPS at the cost of single-target DPS.
- **29 Aug. 2024:** Updated disclaimer for AoE build to be clearer.
- **28 Aug. 2024:** Fixed a typo.
- **24 Aug. 2024:** Added Delve Talent Tree.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated best talents based on tier changes from Season 4.
- **19 Mar. 2024:** Updated for Patch 10.2.6., made Flame Accelerant a default node instead of Alexstrasza's Fury
- **09 Mar. 2024:** Updated suggested Flamestrike talents slightly, and added more information on picking between Ignite vs Flamestrike builds.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **19 Nov. 2023:** Updated talent tree to pick Alexstrasza's Fury by default due to optimisations found.
- **06 Nov. 2023:** Updated suggested talents due to 10.2 changes.
- **04 Sep. 2023:** Changed talent layout to be easier to navigate.
- **14 Jul. 2023:** Added disclaimed that Living Bomb should not be used on single target.
- **10 Jul. 2023:** Updated suggested talents after the Fire rework for 10.1.5.
- **03 May 2023:** Added note about the suggested talents being based on having 2 and 4 set.
- **01 May 2023:** Updated suggested talents based on 10.1 changes and cleaned up some talent advice.
- **20 Mar. 2023:** Updated for Patch 10.0.7.
- **16 Feb. 2023:** Removed old note.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **25 Oct. 2022:** Split talent suggestions up into Night Fae and non Night Fae section.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 技能循环与冷却

On this page, you will learn how to optimize the rotation of your
Fire Mage in both single-target and multi-target
situations.  We also have advanced sections about cooldowns, procs, etc.
in order to minmax your DPS. All our content is updated for World of
Warcraft Patch 12.1.5.

1.

### Fire Mage Gameplay and Rotation Guide

Welcome to our Rotation page for Fire Mages. On this
page you will
find everything you need to know about actually playing the spec in Raiding and Mythic+
scenarios.

<em>Note: Currently there are no differences in the talents picked
for single-target or AoE, regardless of Hero Spec presets.
</em>

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury

Single Target

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

AoE

![recommended](<https://static.icy-veins.com/images/common/button-icons/tc.png>)

best choice

![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire

Single Target

AoE

Active Talents

Passive Talents

[[spell:153561]]

[[spell:2948]]

[[spell:205026]]

[[spell:416719]]

[[spell:269650]]

[[spell:416094]]

[[spell:457735]]

[[spell:1271177]]

### Single-Target Rotation

1.1.

#### Single Target Rotation

The Fire rotation follows a priority system. Below we list this priority system. You should read from the top to the bottom, and then execute the first action where all conditions match.

The Fire rotation has two distinct phases, a [[spell:190319]] phase, where you will chain a lot of crits together for very high burst DPS, and a non-Combustion phase that does significantly less DPS but tides you over to the next phase.

**适用条件：Sunfury（启用）；Scorch（未启用）。** <em>Note: running a ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury build without [[spell:2948]] is only recommended if you are very comfortable with  the encounter, and you expect to lose very limited DPS to movement. I highly recommend running a build with Scorch specced in almost all cases.</em>

**适用条件：Frostfire（启用）；Scorch（启用）。** <em>Note: [[spell:2948]] is worse than casting [[spell:431044]] in practically all situations, even when the target is below 30% health, so it is purely used as a mobility tool as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire.</em>

1.2.

#### Combustion Priority List

[[spell:190319]] is a powerful cooldown that makes all of your spells critically strike. The goal is to use it as close to on-cooldown as possible, while making sure to use any other damage increasing cooldowns alongside it, like trinkets and racials.

Since all spells are guaranteed critical strikes, you will be rotating instant-cast [[spell:11366]] and Hot Streak builders, like [[spell:319836]].

1. **适用条件：Meteor（启用）；Burnout（未启用）。** Cast [[spell:153561]] at any point during [[spell:190319]], making sure it will land before Combustion expires.
2. **适用条件：Meteor（启用）；Burnout（启用）。** Cast [[spell:153561]] at any point in the last 8 seconds of [[spell:190319]], but ensure it lands before Combustion ends. In practice, this means cast it at any point between 2 to 8 seconds of Combustion left.
3. Cast [[spell:11366]] when you have [[spell:195283]].
4. **适用条件：Pyroclasm（启用）。** Hardcast [[spell:11366]] when you have [[spell:269650]] and [[spell:190319]] has at least 3 seconds left. Do not hardcast Pyroblast if you are capped or close to capped on [[spell:319836]] charges, even if you were to lose the Pyroclasm proc. It is more important to not overcap Fire Blast charges than it is to lose a Pyroclasm proc.
5. **适用条件：Heat Shimmer（启用）。** Cast [[spell:2948]] when you have [[spell:457735]] and no [[spell:195283]].
6. Cast [[spell:319836]] to convert [[spell:48107]] into [[spell:195283]].
7. **适用条件：Frostfire（启用）。** Cast [[spell:431044]] to generate [[spell:195283]] / [[spell:48107]] when out of [[spell:319836]].
8. **适用条件：Scorch（启用）；Sunfury（启用）。** Cast [[spell:2948]] to generate [[spell:195283]] / [[spell:48107]] when out of [[spell:319836]].
9. **适用条件：Sunfury（启用）；Scorch（未启用）。** Cast [[spell:133]] as filler.

**适用条件：Sunfury（启用）。**

After

[[spell:190319]]

ends, you will gain

[[spell:383860]]

.

:::details While [[spell:383860]] is active, cast [[spell:11366]].  - <em>Click for advanced tips</em>
During Hyperthermia, if you have

[[spell:48107]]

, convert it with

[[spell:319836]]

into

[[spell:195283]]

. Even though Hyperthermia guarantees critical strikes, you will still want to convert Heating Up into Hot Streaks via Fire Blast, because Hot Streak greatly increases the

[[spell:12846]]

applied by Pyroblast.

:::

See the below sequence as an example of what a [[spell:190319]] rotation looks like. Note: [[spell:1257349]] impacts how long you can stick to using [[spell:319836]] as [[spell:195283]] / [[spell:48107]] generator, which greatly impacts what the actual sequence will look like in practice:

**适用条件：Sunfury（启用）。**

[[spell:11366]]

[[spell:190319]]

[[spell:319836]]

[[spell:11366]]

[[spell:108853]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:153561]]

[[spell:2948]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:11366]]

[[spell:383860]]

[[spell:11366]]

**适用条件：Frostfire（启用）。**

[[spell:11366]]

[[spell:190319]]

[[spell:319836]]

[[spell:11366]]

[[spell:108853]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:153561]]

[[spell:319836]]

[[spell:11366]]

[[spell:431044]]

[[spell:431044]]

[[spell:11366]]

[[spell:11366]]

1.3.

#### Priority List (Outside Combustion)

1. **适用条件：Firestarter（启用）。** When running [[spell:205026]], delay your first [[spell:190319]] until the target is below 90% health.
2. Cast [[spell:190319]] when ready and then go into the Combustion Priority List above. Cast Combustion near the end of a hard-cast spell. -  <em>Click for hard-cast priority</em>
   
   
   - **适用条件：Pyroclasm（启用）。** [[spell:11366]] with [[spell:269650]]
   - **适用条件：Scorch（启用）。** [[spell:2948]] (when target is below 30% health)
   - **适用条件：Frostfire（未启用）。** [[spell:133]]
   - **适用条件：Frostfire（启用）。** [[spell:431044]]
3. **适用条件：Meteor（启用）；Blast Zone（启用）。** Cast [[spell:153561]] immediately as it becomes available. If you had to delay it more than 10 seconds, skip the usage and save Meteor for Combustion.
4. **适用条件：Frostfire（启用）。** Cast [[spell:11366]] when you have [[spell:195283]]. Cast it after a non instant [[spell:431044]] so they both land at the same time. See the [Pyroblast Chaining section](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities#pyrochaining>) for information as to why.
5. **适用条件：Sunfury（启用）；Scorch（未启用）。** Cast [[spell:11366]] when you have [[spell:195283]]. Cast it after a [[spell:133]] cast so they both land at the same time. See the [Pyroblast Chaining section](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities#pyrochaining>) for information as to why.
6. **适用条件：Scorch（启用）；Sunfury（启用）。** Cast [[spell:11366]] when you have [[spell:195283]]. Cast it after a [[spell:133]] (or [[spell:2948]], in execute) cast so they both land at the same time. See the [Pyroblast Chaining section](<https://www.icy-veins.com/wow/fire-mage-pve-dps-rotation-cooldowns-abilities#pyrochaining>) for information as to why.
7. **适用条件：Pyroclasm（启用）。** Hardcast [[spell:11366]] when [[spell:269650]] procs.
8. **适用条件：Heat Shimmer（启用）；Sunfury（启用）。** Cast [[spell:2948]] if you have a [[spell:457735]] proc, and you do not currently have [[spell:195283]].
9. Cast [[spell:319836]] to convert [[spell:48107]] into [[spell:195283]].
10. **适用条件：Scorch（启用）；Sunfury（启用）。** Cast [[spell:2948]] as your filler to generate [[spell:195283]] / [[spell:48107]] when the target is below 30% health.
11. **适用条件：Frostfire（启用）。** Cast [[spell:431044]] as your filler to generate [[spell:195283]] / [[spell:48107]].
12. **适用条件：Sunfury（启用）。** Cast [[spell:133]] as your filler to generate [[spell:195283]] / [[spell:48107]].
13. **适用条件：Frostfire（启用）；Scorch（启用）。** Cast [[spell:2948]] as filler when on the move and thus unable to cast [[spell:431044]].

### AoE Rotation

1.4.

#### Aoe Rotation

The Fire AoE rotation follows a priority system. Below we list this priority system. You should read from the top to the bottom, and then execute the first action where all conditions match.

The Fire rotation has two distinct phases, a [[spell:190319]] phase, where you will chain a lot of crits together for very high burst DPS, and a non-Combustion phase that does significantly less DPS but tides you over to the next phase.

In AoE, the rotation largely plays the same, with one very critical difference: You cast [[spell:2120]] instead of [[spell:11366]].

1.5.

#### Target Counts for Replacing Pyroblast With Flamestrike

**适用条件：Fuel the Fire（未启用）。** Note: you should always be specced into [[spell:416094]] to make casting [[spell:2120]] worth it.

**适用条件：Frostfire（启用）。** As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire, you only replace [[spell:11366]] for [[spell:2120]] at specific target counts:

**适用条件：Sunfury（启用）。** As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury, you only replace [[spell:11366]] for [[spell:2120]] at specific target counts:

1. You should stick to using [[spell:11366]] over [[spell:2120]] at all target counts if you want to maximize your damage to a specific high priority target.
2. **适用条件：Firestarter（启用）。** When the target is above 90% health with [[spell:205026]] specced: Never use [[spell:2120]]
3. **适用条件：Sunfury（启用）。** Both during and outside of [[spell:190319]]: 4 or more targets
4. **适用条件：Frostfire（启用）。** Both during and outside of [[spell:190319]]: 4 or more targets
5. **适用条件：Frostfire（未启用）。** Only replace [[spell:11366]], never replace a [[spell:133]] cast with [[spell:2120]]!
6. **适用条件：Frostfire（启用）。** Only replace [[spell:11366]], never replace a [[spell:431044]] cast with [[spell:2120]]!

This leads to the following full priority list:

1.6.

#### Combustion Priority List

[[spell:190319]] is a powerful cooldown that makes all of your spells critically strike. The goal is to use it as close to on-cooldown as possible, while making sure to use any other damage increasing cooldowns alongside it, like trinkets and racials.

Since all spells are guaranteed critical strikes, you will be rotating instant-cast [[spell:2120]] and Hot Streak builders, like [[spell:319836]].

1. **适用条件：Meteor（启用）；Burnout（启用）。** Cast [[spell:153561]] at any point in the last 8 seconds of [[spell:190319]], but ensure it lands before Combustion ends. In practice, this means cast it at any point between 2 to 8 seconds of Combustion left.
2. **适用条件：Meteor（启用）；Burnout（未启用）。** Cast [[spell:153561]] at any point during [[spell:190319]], making sure it will land before Combustion expires.
3. Cast [[spell:2120]] when you have [[spell:195283]].
4. **适用条件：Pyroclasm（启用）。** Hardcast [[spell:2120]] when you have [[spell:269650]] and [[spell:190319]] has at least 3 seconds left. Do not hardcast Flamestrike if you are capped or close to capped on [[spell:319836]] charges, even if you were to lose the Pyroclasm proc. It is more important to not overcap Fire Blast charges than it is to lose a Pyroclasm proc.
5. **适用条件：Heat Shimmer（启用）。** Cast [[spell:2948]] when you have [[spell:457735]] and no [[spell:195283]].
6. Cast [[spell:319836]] to convert [[spell:48107]] into [[spell:195283]].
7. **适用条件：Scorch（启用）；Sunfury（启用）。** Cast [[spell:2948]] as your filler to generate [[spell:195283]] / [[spell:48107]].
8. **适用条件：Frostfire（启用）。** Cast [[spell:431044]] as your filler to generate [[spell:195283]] / [[spell:48107]] when out of [[spell:319836]].
9. **适用条件：Sunfury（启用）；Scorch（未启用）。** Cast [[spell:133]] as your filler to generate [[spell:195283]] / [[spell:48107]] when out of [[spell:319836]].

**适用条件：Sunfury（启用）。**

After

[[spell:190319]]

ends, you will gain

[[spell:383860]]

.

:::details While [[spell:383860]] is active, cast [[spell:2120]].  - <em>Click for advanced tips</em>
During Hyperthermia, if you have

[[spell:48107]]

, convert it with

[[spell:319836]]

into

[[spell:195283]]

. Even though Hyperthermia guarantees critical strikes, you will still want to convert Heating Up into Hot Streaks via Fire Blast, because Hot Streak greatly increases the

[[spell:12846]]

applied by Flamestrike.

:::

See the below sequence as an example of what a [[spell:190319]] rotation looks like. Note: [[spell:1257349]] impacts how long you can stick to using [[spell:319836]] as [[spell:195283]] / [[spell:48107]] generator, which greatly impacts what the actual sequence will look like in practice:

**适用条件：Sunfury（启用）。**

[[spell:2120]]

[[spell:190319]]

[[spell:319836]]

[[spell:2120]]

[[spell:108853]]

[[spell:2120]]

[[spell:319836]]

[[spell:2120]]

[[spell:153561]]

[[spell:2948]]

[[spell:2120]]

[[spell:319836]]

[[spell:2120]]

[[spell:2120]]

[[spell:383860]]

[[spell:2120]]

[[spell:2120]]

[[spell:2120]]

[[spell:2120]]

**适用条件：Frostfire（启用）。**

[[spell:11366]]

[[spell:190319]]

[[spell:319836]]

[[spell:11366]]

[[spell:108853]]

[[spell:11366]]

[[spell:319836]]

[[spell:11366]]

[[spell:153561]]

[[spell:319836]]

[[spell:11366]]

[[spell:431044]]

[[spell:431044]]

[[spell:11366]]

[[spell:11366]]

1.7.

#### Priority List (Outside Combustion)

1. **适用条件：Firestarter（启用）。** When running [[spell:205026]], delay your first [[spell:190319]] until the target is below 90% health. Also do not cast [[spell:2120]] whatsoever when the target is above 90% health.
2. Cast [[spell:190319]] when ready and then go into the Combustion Priority List above. Cast Combustion near the end of a hard-cast spell. -  <em>Click for hard-cast priority</em>
   
   
   - **适用条件：Pyroclasm（启用）。** [[spell:2120]] with [[spell:269650]]
   - **适用条件：Scorch（启用）。** [[spell:2948]] (when target is below 30% health)
   - **适用条件：Frostfire（未启用）。** [[spell:133]]
   - **适用条件：Frostfire（启用）。** [[spell:431044]]
3. **适用条件：Meteor（启用）；Blast Zone（启用）。** Cast [[spell:153561]] immediately as it becomes available. If you had to delay it more than 10 seconds, skip the usage and save Meteor for Combustion.
4. Cast [[spell:2120]] when you have [[spell:195283]].
5. **适用条件：Pyroclasm（启用）。** Hardcast [[spell:2120]] when [[spell:269650]] procs.
6. **适用条件：Scorch（启用）；Heat Shimmer（启用）。** Cast [[spell:2948]] if you have a [[spell:457735]] proc, and you do not currently have [[spell:195283]].
7. Cast [[spell:319836]] to convert [[spell:48107]] into [[spell:195283]].
8. **适用条件：Scorch（启用）；Sunfury（启用）。** Cast [[spell:2948]] as your filler to generate [[spell:195283]] / [[spell:48107]] when the target is below 30% health.
9. **适用条件：Frostfire（启用）。** Cast [[spell:431044]] as your filler to generate [[spell:195283]] / [[spell:48107]].
10. **适用条件：Sunfury（启用）。** Cast [[spell:133]] as your filler to generate [[spell:195283]] / [[spell:48107]].

:::details FAQShould I use the targeted [[spell:2120]] or the area targeted Flamestrike?
For most players, the auto-targeted option will be the best choice.
It frees up your cursor and attention to focus on the rest of the game.
However, since it is centered on the mob you're attacking, you will find situations
where this misses some of the mobs in the pack. With practice, you should be
able to squeeze out a little more dps using the area targeted
(via the @cursor macro below) version. Try both, see which you like more.

:::

This macro will cast [[spell:2120]] on your cursor, instead of first showing a targeting circle. This only works if you have selected the manual-cast Flamestrike Talent, not the targeted Flamestrike Talent.

#### Cursor Flamestrike

```wow-macro
#showtooltip Flamestrike
/cast [@cursor] Flamestrike;
```

2.

### Midnight Season 2 Tier Set

The Season 2 Tier Set is focused entirely around
[[spell:269650]]. The 2-set causes [[spell:11366]] and [[spell:2120]]
to be guaranteed critical strikes, making it much more valuable to consume
Pyroclasm procs outside of Combustion, while the 4-set further increases
the damage bonus of Pyroclasm, and reduces the hard-cast cast times of Pyroblast
and Flamestrike, making it easier and quicker to consume the procs.

Our Tier Sets for Season 2 are:

- [[spell:1296583]]: [[spell:269650]] causes
          [[spell:11366]] and [[spell:2120]] to always critically
          strike.
- [[spell:1296584]]: [[spell:269650]] reduces
          [[spell:11366]] and [[spell:2120]] cast time by 20% and increases
          Pyroclasm's damage bonus by 20%.

3.

### Class and Spec Mechanics Explained

In order to better explain the specific usage and benefits of the Fire Mage
kit, we have compiled a more detailed explanation on individual parts of our rotation, from
important rotational mechanics that you need to pay attention to, to cooldowns and how to use them, so you can
reach your full potential when playing Fire Mage.

### Efficiently Chaining Critical Strikes

3.1.

#### Efficiently Chaining Critical Strikes

Understanding how to generate Critical Strikes as efficiently as possible is crucial
to mastering Fire as a specialization. This spec is designed to
crit more often than not, so it is easy to understand why learning to execute
the right combos to create a chain of crits is paramount.

Whenever you get a [[spell:48107]] proc, you should convert it to a
[[spell:195283]] using [[spell:319836]]. Generally, you will
then want to cast a [[spell:133]] and immediately spend your
Hot Streak on a [[spell:11366]] as your Fireball cast finishes. Both of
these spells will strike simultaneously, giving a chance of an
immediate follow-up Hot Streak if both critically strike.
If only one of the spells critically strikes, Heating Up will
proc, and you can immediately Fire Blast and repeat this process.

There is a 0.2-second grace period where [[spell:48107]] will not
be canceled if two spells impact simultaneously and only one critically
strikes. This grace window is why it is so critical to always cast Fireball into
Pyroblast, because normally, if only one of them crits, and the other does not,
you will lose the Heating Up. But if you cast both at the same time, if only
one of them crits, you keep your Heating Up.

This is known as "Pyroblast Fishing" or "Pyroblast Chaining" and is the best
way to create a large chain of crits. The exception to this rule is during
[[spell:190319]], where all spells will crit, allowing you to chain together
various combos that are covered in more detail in the rotation section above.

### Burnout

3.2.

#### Burnout

[[spell:1271177]] is a keystone talent, that causes all your
    active [[spell:12846]]s to explode when [[spell:190319]] ends
    for 75% of their remaining damage. This explosion is purely additional
    damage, it does not remove any of your existing Ignites when it happens.

Burnout greatly increases your burst damage, especially on enemies that
    live short, as it allows you to still get a lot of benefit of your
    Ignites on them, without them having them to live for the entire duration of
    Ignite.

Because Ignite has a 10 second duration, with some complicated rules on
    how it refreshes, what we want to do is make sure that at the end of
    Combustion,
    we have as high of an Ignite as possible, as it takes your active Ignites
    at the end of Combustion and explodes those, not all Ignite damage applied
    during Combustion.

The actual gameplay impact is quite minimal: During [[spell:190319]],
    you delay [[spell:153561]] until there are 8 seconds or less left of
    Combustion. Everything else will naturally work out in such a way
    that your [[spell:12846]] will be very large at the end of Combustion
    without having to make any rotational changes.

### Apex Talent

3.3.

#### Apex Talent For Fire Mage

Fire has the following Apex Talent:

- [[spell:1257343]]: Consuming [[spell:195283]] has a chance to grant
          you a stack of Fired Up, which increases your fire damage. Multiple
          applications may overlap.
- [[spell:1257349]]: Gaining Fired Up reduces your [[spell:319836]]
          cooldown by 2.5 seconds per point, 2 points.
- [[spell:1257348]]: [[spell:190319]] greatly increases the chance of
          getting Fired Up, reducing each time you proc Fired Up. Also causes
          Fired Up to extend Combustion by 1 second.

The Apex Talent for Fire grants a lot of damage for both Hero Specs, and
    is virtually always taken. Fired Up is a new proc which grants a large
    amount of bonus damage whenever it procs, which is just a very nice passive
    bonus. However, even more impactful is the massive 5 second [[spell:319836]]
    cooldown reduction when it procs, which happens quite
    frequently, especially during [[spell:190319]].

This [[spell:319836]] cooldown reduction makes it so you barely run out of
    Fire Blast charges during [[spell:190319]], often only running out
    towards the very end of Combustion. This allows you to chain [[spell:11366]]
    into Fire Blast for almost the entire duration of Combustion without needing
    to weave in any other spells.

All these extra [[spell:319836]] charges do cause a bit of a weird luxury
    "problem", where it relatively devalues [[spell:269650]], because hard-casting
    [[spell:11366]] during [[spell:190319]] risks overcapping Fire Blast
    charges, making it difficult to hard-cast during Combustion.
    Due to this, you often end up having to delay the hard-casts until Combustion
    is over.

### Pyroclasm Usage

3.4.

#### Pyroclasm Usage

[[spell:269650]] is a key proc. When it procs, your next
    non-instant [[spell:11366]] or [[spell:2120]] does greatly
    increased damage. With the Season 2 2-set, they are also
    guaranteed critical strike. At first glance, this is a very simple proc: you just
    hard-cast Pyroblast and it does significantly more damage. However, there
    are some small things we can do to squeeze out extra DPS.

Since the 2-set bonus guarantees a crit, and you usually have a lot
    of [[spell:319836]] charges during [[spell:190319]], you want
    to generally try to make sure you go into Combustion without any
    [[spell:269650]] procs active. This means that you want to make sure
    you consume the procs before going into Combustion.

However, this does not mean you completely ignore the proc during Combustion.
    If it does proc during Combustion itself, you do want to use it, as long
    as it you do not overcap on [[spell:319836]] charges.

In practice, this is quite easy to play around:

- Outside of [[spell:190319]]: Hardcast [[spell:11366]] 
          / [[spell:2120]] the moment [[spell:269650]] procs.
- If [[spell:190319]] is ready, and you have a [[spell:269650]] proc:
          Hardcast [[spell:11366]] / [[spell:2120]] and then cast
          Combustion right at the end of the cast.
- During [[spell:190319]]: Only consume [[spell:269650]] procs
          when you have one or fewer [[spell:319836]] charges to avoid
          overcapping.

4.

### Important Cooldowns for Fire Mage

### Combustion

4.1.

#### Combustion

[[spell:190319]] is Fire's primary DPS cooldown, available every minute
    when talented into [[spell:155148]]. It guarantees all your spells
    critically strike, amongst various other buffs like bonus mastery
    or straight up more damage, based on talents. As ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury, it
    also grants you an Arcane Phoenix while Combustion is active and various
    other benefits after it ends.

Since Fire is all about critically striking to generate [[spell:195283]],
    this is obviously a massive damage buff and makes your rotation very fast
    paced while Combustion is active.

Generally, you will want to use Combustion immediately as it comes up,
    but it can be beneficial to delay it in certain cases, for example if your
    group is about to use [[spell:80353]] or a similar effect soon, or an
    important raid mechanic that needs high DPS is coming soon, or additional
    targets that come up, etc. However, since Combustion is only a minute cooldown,
    delaying it is usually not a good idea as it is very likely to lose you an
    extra usage if you delay it too much.

### Meteor

4.2.

#### Meteor

[[spell:153561]] is a 30 second cooldown when talented into [[spell:416719]],
    that hits hard and activates various other bonuses depending on Talents
    and Hero Talents, like proccing [[spell:431176]] as
    ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire or granting [[spell:269650]] as ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury.

Meteor and [[spell:190319]] have very tight timings, as Meteor has 30
    seconds cooldown and Combustion one minute, meaning you can cast Meteor
    exactly once in-between Combustion usages. Since the timing is so close,
    it is critical you use Meteor immediately as it comes up to ensure
    you do not have to skip a usage, or delay Combustion, both of which
    are bad.

Without [[spell:416719]] talented, [[spell:153561]] timings become a lot
    simpler, because you can no longer fit in any extra Meteors in-between
    [[spell:190319]], so you simply only use it within Combustion
    and do not use it whatsoever outside of it.

### Time Warp

4.3.

#### Time Warp

[[spell:80353]] is an ability which buffs your entire party or raid group
    within 100 yards with 30% haste for 40 seconds. This buff is shared
    with multiple other spells like [[spell:2825]] and [[spell:32182]].
    These all put a debuff on all your group members which blocks them from
    getting the effect again for 10 minutes, so you cannot get this same
    effect from multiple sources multiple times.

As Time Warp applies to the whole group, it is generally decided by the raid
    or party leader when it is used, to optimize usage for the whole group,
    instead of just using it when it is best for your personal usage. However,
    if there is no assigned time or you are in a pick up group without any real
    leadership in terms of strategy, it is generally a safe practice to use
    Time Warp right after combat starts so it is up while everyone has all of
    their DPS cooldowns ready. Of course make sure to only do this
    if there will be enemies active for the entire 40 second duration
    of the buff on the pull, as on some fights bosses might go inactive
    or do some kind of phase change early on in the fight.

5.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **22 May 2026:** Updated Meteor usage slightly, and remove the Frostfire no-pyro rotation due to minimal to no DPS gain.
- **20 Apr. 2026:** Reviewed for Patch 12.0.5.
- **16 Mar. 2026:** Added Tier-set section for season 1 start and added FAQ for Flamestrike usage + Flamestrike macro. Also set default rotation to Frostfire, and added a no-pyroblast rotation for Frostfire due to tuning changes.
- **02 Mar. 2026:** Updated Flamestrike target counts to provide a bit more context.
- **27 Feb. 2026:** Updated Frostfire rotation to provide more Scorch context.
- **26 Feb. 2026:** Updated AoE rotation threshholds for Flamestrike based on latest math.
- **10 Feb. 2026:** Updated default selected talents based on latest optimal talents and updated rotation for improved Flamestrike usage.
- **21 Jan. 2026:** Updated default rotation checkboxes to be set to Sunfury based on latest findings and added full loadouts for both Hero Specs for both AoE and ST.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated best rotation based on 11.2 changes for both single-target and AoE, added tier rotation changes section.
- **17 Jun. 2025:** Updated Combat Assistant damage gains/losses based on latest updated numbers.
- **15 Jun. 2025:** Added Combat Assistant information and tips.
- **21 Apr. 2025:** Updated default single-target rotation to Frostfire.
- **24 Feb. 2025:** Updated for 11.1 changes: New default setup set to sunfury, updated rotation for new optimal rotation due to changes, added a less complex basic rotation.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **26 Nov. 2024:** Updated rotation to have Frostfire as the defaults now that it is better than Sunfury after the buffs.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **24 Sep. 2024:** Updated AoE rotation to include a flamestrike based rotation now that it is more viable due to the latest buffs.
- **09 Sep. 2024:** Updated for The War Within Season 1.
- **28 Aug. 2024:** Fix a typo.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **10 May 2024:** Updated the separate tier section to refer to the correct tier set.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated rotation based on new tier set from Season 4.
- **23 Mar. 2024:** Split Combustion rotation up into two distinct sections, one to enter Combustion, and one during Combustion, for readability. Additionally simplified the opener description.
- **19 Mar. 2024:** Updated for Patch 10.2.6., added Flame Accelerant as default checked rotation checkbox, and added line for using Fireball in Combustion during it. Also cleaned up some typos.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **19 Nov. 2023:** Updated checkboxes to by default has Alexstrasza's Fury enabled due to optimisations found make AF part of the default talent tree.
- **06 Nov. 2023:** Updated rotation for new best talent builds in 10.2, and new tier set.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **15 Jul. 2023:** Updated AoE Flamestrike rotation due to the nerf to Flamestrike.
- **14 Jul. 2023:** Updated AoE Flamestrike rotation based on latest optimisations.
- **10 Jul. 2023:** Updated rotation for the Fire Mage rework of 10.1.5.
- **01 May 2023:** Updated rotation pased on new tier set bonuses and new optimal talents.
- **20 Mar. 2023:** Rewrote parts of the rotation to be easier to follow, and split the SKB/Pyroclasm into its own section. Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **03 Jan. 2023:** Add Shifting Power to the rotation.
- **11 Dec. 2022:** Update AoE rotation to more clearly explain the AoE rotation when you are not talented into Flamestrike/Flamepath.
- **11 Dec. 2022:** Added section explaining rotational changes due to the tier set.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 装备选择

On this page, you will find the best gear, trinkets, and best in slot item recommendations
for your Fire Mage in World of Warcraft 12.1.5.
From crafted items to advice on how to use your Crests to upgrade gear, we got you covered!

1.

### Best in Slot Gear Guide for Fire Mage

Welcome to our Gearing Page for Fire Mage. This
section will cover everything you need to know about equipping your character
correctly.

Upgrading gear in [Midnight](<https://www.icy-veins.com/wow/midnight-expansion-guide>) continues to use the Crest system which lets you
increase the item level of gear along tracks that relate to where you obtained the
item, which harder content dropping gear that can be upgraded to higher Item Levels.
For more information, read up on our dedicated page on how the 
[gearing system](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>) works and what has 
changed in the Midnight expansion.

### Overall

This list contains the highest DPS setup from all sources for Fire Mage. There are often many items for a single slot that are very close or even identical DPS, especially if you simply shuffle secondary stats around between different slots. Due to this, you should only use the list below as a general guideline of what a set of end-game gear looks like, not to make immediate gearing choices.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

<em>In a few slots, I list items from Mythic+, which can only be obtained at Mythic track from [The Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>). Generally these items are only best-in-slot at Mythic track, not in their Heroic track variants. You are usually better off using a higher item level piece than the best-in-slot piece if you cannot obtain it at Mythic track.</em>

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

keeps the item level, stats and any special bonuses of an item, so it does not matter which 4 out of 5 slots you catalyze. Pick any 4 out of 5 you have available from the list below:

- Head — [[item:271874]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders — [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Chest — [[item:273785]] from [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>)
- Hands — [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs — [[item:268236]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)

Note: getting 4-set in any capacity is much more important than getting them on the correct (catalyzed) pieces, so always prioritize getting 4-set over the right pieces.

:::

:::details FAQWhat Items From the Great Vault Should I Pick?
Generally, you will want to focus on picking items that are the biggest upgrade for you by simming

[Top Gear](<https://www.raidbots.com/simbot/topgear>)

. However, there are also some items in general that are very valuable and almost always worth picking up if you see them:

- [[item:271092]]: Best-in-slot Weapon by a large margin and very rare and wanted by all casters, so always pick this up if it is in your vault at Heroic or Mythic.
- Any of the 9/6 Myth track items listed below: All of them are best-in-slot for both Fire Mage and generally all other cloth wearers, so very difficult to obtain otherwise.
- [[item:273796]]: Best-in-slot Trinket which can only be obtained at Myth track from The Great Vault.

:::

:::details FAQWhy are there no Kith'ix's gear pieces?
The Kith'ix gear and their cantrips are not as strong as some of the other cantrip items from Ulatek and Coiled Altar, and the worse stats on the items make them very slightly worse than the best-in-slot options listed below. However, the difference is very small, so depending on your own gear, they can be an upgrade! To be sure, you should sim them yourself.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240893]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

### Mythic+

This list contains the highest DPS setup with farmable gear **from** Season 2 Mythic+ Dungeons. This includes Tier pieces and 2 Embellished items due to their importance, even though they are not technically from Mythic+ Dungeons, since they are obtainable via [The Great Vault](<https://www.icy-veins.com/wow/great-vault-guide>) / [Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>) / Crafting.

This list is by no means a replacement for [simming yourself](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>). Depending on your previous Great Vault choices and the gear you have available, your BiS gear might look different in some spots than the below list.

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

keeps the item level, stats and any special bonuses of an item, so it does not matter which 4 out of 5 slots you catalyze. Pick any 4 out of 5 you have available from the list below:

- Head — [[item:251232]] from [Voidscar Arena](<https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide>)
- Shoulders — [[item:239045]] from [King's Rest](<https://www.icy-veins.com/wow/kings-rest-dungeon-guide>)
- Chest — [[item:251147]] from [Den of Nalorakk](<https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide>)
- Hands — [[item:251129]] from [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>)
- Legs — [[item:193750@JAAIAAQkCYHKvbRLfA]] from [Ruby Life Pools](<https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide>)

Note: getting 4-set in any capacity is much more important than getting them on the correct (catalyzed) pieces, so always prioritize getting 4-set over the right pieces.

:::

:::details TipsWhich Dungeons Should I Farm?
There are a few outstanding dungeons due to specific items dropping in them making them very good dungeons to farm:

- [Altar of Fangs](<https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide>): Drops both the best on-use trinkets ([[item:273796@JAACAAgNyA]]), and the best non-raid Weapon.
- [Murder Row](<https://www.icy-veins.com/wow/murder-row-dungeon-guide>): Drops strong Neck, Hands and Feet, while even dropping some pretty decent Trinkets, making it a Dungeon with a very high likelihood of dropping something useful.
- [Blinding Vale](<https://www.icy-veins.com/wow/blinding-vale-dungeon-guide>): Drops two very strong passive trinkets, including the best non-raid trinket, while also dropping a great Cloak and multiple other useful pieces.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271564@JAACAAgNyA]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:251142@JAAEAAgNygjM]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></div></td></tr><tr><th>Waist</th><td>[[item:239649@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ruby-life-pools-dungeon-guide" rel="noopener noreferrer">Ruby Life Pools</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:251190@JAACAAgNyA]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></div></td></tr><tr><th>Feet</th><td>[[item:251137@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/murder-row-dungeon-guide" rel="noopener noreferrer">Murder Row</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/den-of-nalorakk-dungeon-guide" rel="noopener noreferrer">Den of Nalorakk</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:252258@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/voidscar-arena-dungeon-guide" rel="noopener noreferrer">Voidscar Arena</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:159459@JAACAAgNyA]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:273796@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:250214@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/blinding-vale-dungeon-guide" rel="noopener noreferrer">Blinding Vale</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:273778@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/altar-of-fangs-dungeon-guide" rel="noopener noreferrer">Altar of Fangs</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:159667@JAAEAAgNygjM]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/kings-rest-dungeon-guide" rel="noopener noreferrer">King's Rest</a></span></div></td></tr></tbody></table>

### Raid

This list contains the highest DPS setup, only using gear **from** the Venomous Abyss Raid. This includes 2 Embellished items as well due to their importance.

This list is by no means a replacement for **simming yourself**. Depending on your previous Great Vault choices and the gear you have available to yourself, your BiS gear might look different than this list in some spots.

:::details FAQWhich Tier Set Pieces Do I Want?
In Season 2,

[Catalyst](<https://www.icy-veins.com/wow/catalyst-guide>)

keeps the item level, stats and any special bonuses of an item, so it does not matter which 4 out of 5 slots you catalyze. From Raid, the only chest piece available is

[[item:271567@JAACAAgNyA]]

(from

[Vashnik](<https://www.icy-veins.com/wow/vashnik-raid-guide>)

), which is a tier item, so you would always take that one. Then, pick any 3 out of 4 you have available from the list below to catalyze:

- Head — [[item:271874]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
- Shoulders — [[item:268241]] from [Twin Fangs](<https://www.icy-veins.com/wow/twin-fangs-raid-guide>)
- Hands — [[item:268243]] from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>)
- Legs — [[item:268236]] from [Nek'zali](<https://www.icy-veins.com/wow/nekzali-raid-guide>)

Note: getting 4-set in any capacity is much more important than getting them on the correct (catalyzed) pieces, so always prioritize getting 4-set over the right pieces.

:::

:::details TipsWhat Raid Items Are Most Important?
If you need to submit a list of highly-important items to your raidleader, or simply want to focus on the most important bosses and items, we got you covered!

- [[item:271092@JAACAAAG2A]]: The best weapon by a large margin, due to its higher item level and secondary effect.
- [[item:271874@JAAEAAAG2YhN]]: The best helm by a large margin, due to its higher item level and Venomcursed effect.
- [[item:270164@JAACAAgNyA]]: The best passive trinket.

:::

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Helm</th><td>[[item:271874@JAAEAAAG2YhN]]&#10;&#10;<div>[[item:240967]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:243981]]</span></div></td></tr><tr><th>Hands</th><td>[[item:271565@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></div></td></tr><tr><th>Neck</th><td>[[item:268265@JAAEAAAG2MqN]]&#10;&#10;<div>[[item:240893]][[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></div></td></tr><tr><th>Waist</th><td>[[item:268257@JAACAAAG2A]]&#10;&#10;<div>[[item:240900]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></div></td></tr><tr><th>Shoulders</th><td>[[item:271562@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:243963]]</span></div></td></tr><tr><th>Legs</th><td>[[item:271563@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/nekzali-raid-guide" rel="noopener noreferrer">Nek'zali</a> + <a href="https://www.icy-veins.com/wow/catalyst-guide" rel="noopener noreferrer">Catalyst</a></span><span>[[item:240133]]</span></div></td></tr><tr><th>Cloak</th><td>[[item:268253@JAACAAAG2A]]&#10;&#10;<div><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></div></td></tr><tr><th>Feet</th><td>[[item:268255@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/coiled-altar-raid-guide" rel="noopener noreferrer">Coiled Altar</a></span><span>[[item:244009]]</span></div></td></tr><tr><th>Chest</th><td>[[item:271567@JAACAAgNyA]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/vashnik-raid-guide" rel="noopener noreferrer">Vashnik</a></span><span>[[item:243977]]</span></div></td></tr><tr><th>Ring</th><td>[[item:268266@JAACAAgNyA]]&#10;&#10;<div>[[item:240906]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/midnight-world-bosses-guide" rel="noopener noreferrer">Tidebound Grotto</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Shirt</th><td><span>&#10;<img alt="Empty Shirt inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_shirt.webp"/>&#10;</span></td></tr><tr><th>Ring</th><td>[[item:268252@JAACAAgNyA]]&#10;&#10;<div>[[item:240893]]</div>&#10;<div><span><a href="https://www.icy-veins.com/wow/sszorak-raid-guide" rel="noopener noreferrer">Sszorak</a></span><span>[[item:243957]]</span></div></td></tr><tr><th>Tabard</th><td><span>&#10;<img alt="Empty Tabard inventory slot" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/bis/inventoryslot_tabard.webp"/>&#10;</span></td></tr><tr><th>Trinket</th><td>[[item:270170@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><a href="https://www.icy-veins.com/wow/twin-fangs-raid-guide" rel="noopener noreferrer">Twin Fangs</a></div></td></tr><tr><th>Bracers</th><td>[[item:239648@JAAKAAwt1ENMMYDYwglI]]&#10;&#10;<div>[[item:240916]][[item:240167]]</div>&#10;<div><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-tailoring" rel="noopener noreferrer">Tailoring</a></div></td></tr><tr><th>Trinket</th><td>[[item:270164@JAAEAAgNygjM]]&#10;&#10;<a href="https://www.icy-veins.com/wow/fire-mage-pve-dps-gear-best-in-slot#trinkets" rel="noopener noreferrer"><img alt="Recommended" loading="lazy" referrerpolicy="no-referrer" src="https://static.icy-veins.com/images/wow/tools/recommended.png"/></a>&#10;<div><span><a href="https://www.icy-veins.com/wow/lost-explorers-raid-guide" rel="noopener noreferrer">Lost Explorers</a></span></div></td></tr></tbody></table>

<table><thead><tr><th>部位</th><th>装备与获取说明</th></tr></thead><tbody><tr><th>Main Hand</th><td>[[item:271092@JAACAAAG2A]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/ulatek-raid-guide" rel="noopener noreferrer">Ula'tek</a></span><span>[[item:244029]]</span></div></td></tr><tr><th>Off Hand</th><td>[[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]&#10;&#10;<div><span><a href="https://www.icy-veins.com/wow/professions-making-gold#buying-crafted-gear" rel="noopener noreferrer">Crafted</a> by <a href="https://www.icy-veins.com/wow/professions-inscription" rel="noopener noreferrer">Inscription</a></span></div></td></tr></tbody></table>

Keep in mind that Catalyzed Items now retain the stats of the original item!

2.

### Trinket Recommendations for Fire Mage in Season 2

There are a great number of Trinkets available for Fire.
    Generally, you will want to use a strong on-use Trinket to pair
    it with [[spell:190319]], and then a strong passive Trinket
    as your second Trinket.

Aim to pick up one trinket from each of these categories as a pair:

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_misc_pvp_trinket.jpg>) **Fire Mage Trinkets**
**On-Use -**

[[item:273796]]

, or, alternatively

[[item:270170]]

(slightly weaker)

**Passive -**

[[item:270164]]

, or, alternatively

[[item:250214]]

(slightly weaker)

:::

There are quite a few other valuable trinkets out there, so make sure to click on our
  ranking chart to see if they are worth equipping.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_6_2raid_trinket_3b.jpg>) Click for Fire Mage Trinket         Rankings
<table>&#10;<tr>&#10;<th>Ranking</th>&#10;<th>Trinkets</th>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>S Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:273796]] — Best on-use Trinket</li>&#10;<li>[[item:270164]] — Best passive Trinket</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>A Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:281215]] — Strong Passive Trinket</li>&#10;<li>[[item:270170]] — Strong on-use&#10;                        Trinket on single-target, but loses value on AoE.</li>&#10;<li>[[item:250214]] — Strong passive Trinket</li>&#10;<li>[[item:270167]] — Strong passive Trinket</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>B Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270169]] — Numerically quite strong on-use Trinket, but requires tracking the buff</li>&#10;<li>[[item:250259]] — Strong passive Trinket on single-target, loses value on AoE</li>&#10;<li>[[item:250224]] — Decently strong passive Trinket</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>C Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:270161]]</li>&#10;<li>[[item:273649]]</li>&#10;<li>[[item:273794]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;<tr>&#10;<td>&#10;<span><strong>D Tier</strong></span>&#10;</td>&#10;<td>&#10;<ul>&#10;<li>[[item:250215]]</li>&#10;<li>[[item:158368]]</li>&#10;<li>[[item:193757@JAAIAAQkCYHKvbRLfA]]</li>&#10;<li>[[item:270168]]</li>&#10;</ul>&#10;</td>&#10;</tr>&#10;</table>

:::

3.

### Nebulous Voidcores (Bonus Rolls) and Ascendant Venomstones

[Nebulous Voidcore](<https://www.wowhead.com/currency=3418>) can be used to guarantee items from a specific
    boss or dungeon. Each time you use it, you are guaranteed to obtain one
    item from that boss or dungeon, and that item is then removed from the
    pool of possible items. Then the next time you use it, you are guaranteed
    any of the remaining items, which means that you will
    obtain the item you are after from that boss or dungeon within a few uses.

With the launch of Patch 12.1.5, you will also be granted one
    additional Voidcore for free from
    **Orin Straylight** in Silvermoon, next to The Catalyst.

Additionally, 12.1.5 brings (back) [[item:280562]], which will
    allow you to upgrade the item level of a fully upgraded Season 2 Hero,
    Mythic, or Crafted weapon, trinket, or necklace.

Note: Mythic [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>) and [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>) gear cannot be further
    upgraded since they already surpass the normal maximum item level.

3.1.

#### Recommended Nebulous Voidcore Usage for Fire Mage

The best items to chase after depend entirely on what items you have already
    obtained so far, and which content you are clearing. For example,
    if you have not yet cleared a specific boss on Mythic, but expect to do
    so soon, you should not use the Voidcore on the Heroic version of that boss.
    Below I list a generic priority list of Voidcore items, but for the best
    results tailored to your own character, you should use
    [Raidbots Droptimizer](<https://www.raidbots.com/simbot/droptimizer>).

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_1205_voidforge_fluctuatingvoidcores_green.jpg>) **Voidcore (Bonus Roll) Priority**
1. Mythic or Heroic [[item:271092]] — Best Weapon,
           by a large margin, due to its higher item level and bonus effect. [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>)
           also drops multiple other strong items, making it a very valuable bonus roll boss.
2. Mythic [[item:271874]] — Best helm due to its
           higher item level and Venomcursed bonus effect.
3. Any Myth Track Weapon — None of them will beat
           [[item:271092]] from [Ula'tek](<https://www.icy-veins.com/wow/ulatek-raid-guide>), but if you are not
           planning / expecting to kill Heroic Ulatek, getting a Myth track weapon
           from other sources is important, especially if you did not craft one.
4. Higher item level items from [Coiled Altar](<https://www.icy-veins.com/wow/coiled-altar-raid-guide>), especially
           [[item:268243]].
5. Remaining BiS List items

:::

3.2.

#### Ascendant Venomstones

You will want to use your [[item:280562]] in such a way that you
    get the most amount of power per spent Venomstone:

1. Main-hand Weapon / 2-Handed Weapon
2. On-use Trinket
3. Passive Trinket
4. Off-hand
5. Necklace

In almost all cases, you will only want to use Venomstones on Myth track items,
    unless you are not expecting to get a Myth track item in the same slot, or
    if you otherwise would not have anything to spend Venomstones on.

One exception being [[item:271092]]: If you have this
    at Heroic track, and are unlikely to get it on Mythic track, upgrading it
    is a great choice as the cantrip makes it better than any
    Myth track weapon, especially when upgraded to 340 item level via Venomstones.

4.

### Best Crafted Items for Fire Mage

**What to craft is highly dependent on your own personal goals,
what content you are doing, and what items you have looted so far.**
We strongly suggest you run your own simulations on raidbots by using
droptimizer to figure out your personal best crafting options.

Below we list the best crafted Embellished items, but **make sure to check the
    crafting order below for more context, since the best Embellishments are
    not always the best to craft first!**

- [[item:245769@JAAMAAwt1ENMMYzy1glIcYD]] with [[item:273060]]
- [[item:239648@JAAMAAwt1ENMMYDYwglIcYD]] with [[item:240167]]

4.1.

#### Crafting Order for Fire Mage

As your ability to craft items will be time-gated in the initial stages of
the season, we highly recommend getting a **Weapon** as soon as possible, unless
you can reliably get one elsewhere. Once you have a good weapon, work on your other Embellished
Item next, and then craft whichever pieces you do not have high-item-level versions
of yet.

The below list of priorities can be a bit confusing, but it ultimately
    comes down to this: You want one item with a [[item:273060]]
    and one with [[item:240167]]. Hunter's Ritual Stone can only
    go on Weapons, and [[item:271092]] is extremely strong, so
    if you are able to get Janthrazet the Soul Fang, (or a Myth track weapon)
    you will want the weapon Embellishment on an off-hand, otherwise,
    you just want to stick to a 2-handed crafted weapon.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_12_profession_questandcrafting_sparkwhole_gold.jpg>) **Fire Mage Crafted Gear Priority**
1. [[item:245770]] with [[item:273060]]: Getting a weapon
           craft early provides an immense amount of power. If you expect to get a
           a Heroic (or better) [[item:271092]], you should skip this step.
2. If you skipped the above step, craft
           [[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]
           with [[item:273060]]
3. [[item:239648@JAAMAAwt1ENMMYDYwglIcYD]] with
           [[item:240167]]: Can also craft any other slot,
           the important part is getting Arcanoweave Lining on a piece of gear,
           and replacing a low item level piece. Wrist is best-in-slot, but
           you can re-craft later anyway.
4. Any item you do not have on Myth track yet.
5. When possible, you will want to replace the crafted [[item:245770]]
           for [[item:271092]] (Heroic or higher), and then
           craft [[item:245769@JAAMAAwt1ENMMYzy1glIcYD]]
           with [[item:273060]]. If you are not clearing
           Heroic, you will instead want to stick with the crafted staff
           [[item:245770]] with Hunter's Ritual Stone. If you are
           not clearing Heroic but get lucky and find a Myth track
           weapon in your Vault, you should use that instead and
           craft the off-hand with Hunter's Ritual Stone.

:::

For more information on how you can craft your own gear, you
can visit our [Professions page](<https://www.icy-veins.com/wow/professions>).

4.2.

#### Adding Sockets to Gear

You can add sockets to Helmets, Belts, and Bracers with
the [[item:275707]] consumable that you can get if you do not select any of the choices in
your Great Vault. Not picking a choice will grant you tokens, six of which can be
traded in for the [[item:275707]] item that allows you to add a socket to the above piece
of gear, if you acquired them in Season 2.

5.

### Crest Usage

Early into the season, or if you have just started playing an alt, you will have limited
access to upgrading-crests such as [Myth Mistcrest](<https://www.wowhead.com/currency=3446>). These can be used to [ upgrade gear](<https://www.icy-veins.com/wow/world-of-warcraft-gear-upgrading-guide>)
to higher itemlevels. Since crests are limited each week and upgrading different items
costs the same amount of crests regardless, you will want to prioritize
your usage of them on items you plan on not replacing anytime soon, or that offer the
biggest benefits.

:::details ![](<https://static.icy-veins.com/images/wow/large_icons/inv_120_crest_myth.jpg>) **Fire Mage Crest Upgrade Priority**
**Weapon (Staff to save crests)**

➜

**Trinkets**

➜

**Helmet/Chest/Legs**

➜

**Shoulders/Gloves/Belt/Boots**

:::

This order is determined by the power you get from upgrading these slots.
Of course, which is best to upgrade can be heavily influenced based
on what you loot, as you can avoid using Crests altogether by looting
higher item level items in those slots, so make
sure that you do not blindly follow the provided upgrade order!

6.

### Evaluating Upgrades

Throughout this page and elsewhere in our guide, we regularly refer to the
importance of simming yourself on Raidbots. This is because every character is
unique, and each gear piece you have access to can change what is best
right now for you.

While we do offer recommendations for gear and trinkets, these are not complete
replacements for simming yourself. The only way to truly optimize your character
to that degree is by making use of the tools available!

7.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Added drop location to list of items to catalyze.
- **09 Oct. 2026:** Updated bis gear to show Ascendant Venomstones upgraded item levels, and added Ascendant Venomstones upgrade guidance, and added Kith'ix loot.
- **01 Sep. 2026:** Updated some bonus IDs to ensure they correct tooltips for Venomcursed effects and update neck for bis updates.
- **31 Aug. 2026:** Added the crafted stats to the tooltips of crafted items and aligned the best embellishment list with the crafting order below it.
- **24 Aug. 2026:** Corrected to the correct raid name for a ring drop.
- **23 Aug. 2026:** Updated overall BiS list to include Hunter's Ritual stone and updated crafting priority to more clearly explain the pros and cons of 2h vs off-hand crafts.
- **15 Aug. 2026:** Updated early crafting to use Hunter's Ritual Stone.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **17 Jun. 2026:** Updated bis lists and best trinkets based on updated theorycrafting post-patch.
- **15 Jun. 2026:** Updated bis lists and trinket recommendations for the new Sporefused gear
- **23 May 2026:** Updated best-in-slot gear and trinket rankings slightly due to May 26/27 buffs.
- **20 Apr. 2026:** Added Nebulous Voidcore and Ascendant Voidcore sections and update bis lists for new item level cap on weapons/trinkets.
- **31 Mar. 2026:** Added Crucible of Erratic Energies trinket to trinket tier list.
- **17 Mar. 2026:** Updated trinket priorities because of trinket tuning patch.
- **16 Mar. 2026:** Replaced pre-season BiS list for 3 different season 1 bis lists (overall, raid, m+), updated crafting info for season 1, added trinkets tier list for season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Updated item levels for 11.2.5 (Turbo boost item levels) and added puzzling cartel section and updated crafting recommendations for unlimited crests.
- **16 Aug. 2025:** Updated best trinkets based on trinket tuning and new findings.
- **05 Aug. 2025:** Added more trinkets to the list of trinkets, and updated Mythic+ bis gear slightly.
- **04 Aug. 2025:** Updated best in slot lists, trinket recommendations, crafting order, added Reshii section, for 11.2.0
- **24 Jun. 2025:** Updated DISC Belt information for the changes coming with the reset.
- **17 Jun. 2025:** Slightly update Durable Information Securing Container Belt information to show % gains for the different bonuses.
- **15 Jun. 2025:** Added Durable Information Securing Container Belt information and best bonuses, and updated BiS lists for new belt.
- **20 May 2025:** Updated Puzzling Cartel Chips section to have more context and removed reference to Neural Synapse Enhancer.
- **15 May 2025:** Updated item levels to turbo item levels, and updated recommended trinkets with more context and options, and updated cartel chips with more context and different track recommendations.
- **27 Apr. 2025:** Updated Puzzling Cartel Chips section with latest information.
- **21 Apr. 2025:** Added Counterfeit Dealer's Chips section.
- **15 Mar. 2025:** Updated crafting order to be more organized by clearly splitting the first craft versus the rest.
- **25 Feb. 2025:** Added Frostfire BiS gear and updated trinkets for latest tuning and theorycrafting optimisations.
- **24 Feb. 2025:** Updated best in slot for season 2 / 11.1 gear, updated crafting recommendations due to new bis items, updated trinkets for new trinkets.
- **17 Dec. 2024:** Updated Cyrce's Circlet suggestions after buffs, and updated BiS to include it now that it's better.
- **15 Dec. 2024:** Added Cyrce's Circlet section.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **24 Sep. 2024:** Fixed incorrect profession linked for off-hand craft.
- **16 Sep. 2024:** Updated crafting recommendations for new BiS setup.
- **09 Sep. 2024:** Added 3 bis lists from different sources: Raiding, Mythic+, Overall. Added trinket tier list. Removed disclaimer from crafting text.
- **03 Sep. 2024:** Updated crafting recommendations and bis lists.
- **27 Aug. 2024:** Updated crafting suggestions on updated Embellishments and updated bis lists.
- **21 Aug. 2024:** Updated for The War Within.
- **30 Jul. 2024:** Fixed not having 4 piece in the overall bis list.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated best for Season 4: updated bis lists, tier description, crafting suggestions, etc.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **07 Nov. 2023:** Updated BiS and embellishments due to sporecloak nerf.
- **06 Nov. 2023:** Updated all 3 best-in-slot and gearing lists for 10.2, added tier 31 section and updated crafting suggestions based on new crafting item levels.
- **26 Sep. 2023:** Changed layout.
- **04 Sep. 2023:** Added 3 different best-in-slot builds.
- **10 Jul. 2023:** Updated best-in-slot for reworked Fire and added Dawn of the Infinite gear section.
- **25 May 2023:** Added Timwalking section.
- **08 May 2023:** Updated trinket suggestions based on improved sims and further theorycrafting.
- **01 May 2023:** Updated best in slot, crafting suggestions, embellishments and replaced valor description to the new crest system and updated Onyx Annulet section based on new 10.1 gear.
- **25 Mar. 2023:** Updated Onyx ring suggestions based on hotfixes.
- **22 Mar. 2023:** Updated bis to include Onyx Annulet due to new gem combinations being found.
- **20 Mar. 2023:** Added Onyx Annulet information and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Updated best in slot advice based on updated theorycrafting.
- **17 Dec. 2022:** Updated crafted gear due to bronzed grip changes.
- **13 Dec. 2022:** Further updated crafted gear info with latest theorycrafting knowledge.
- **11 Dec. 2022:** Updated trinket recommendations on further theorycrafting, and added more info for crafted gear.
- **11 Dec. 2022:** Updated for season 1, including crafted gear, m+ gear and raid gear.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 属性优先级

On this page, you will find out the optimal stat priority for your Fire Mage. We first present
the stat priority, before delving into more complex explanations on how the stats
interact with your specialization and gameplay. Our content is updated for
World of Warcraft Patch 12.1.5.

1.

### Fire Mage Stat Priority

You will want to prioritize stats as follows for both single-target and AoE:

Intellect

Haste

Mastery

Versatility

Critical Strike

**All of the secondary (non-Intellect) stats are very close in value despite
the way they are ordered on our list, with the exception of crit, which is usually the worst.**
We encourage players to sim themselves, if possible, to determine what stats you
should aim for according to your current distribution, as this may change
depending on your current values. This is because a deficiency of one stat will
often cause it to become high in value relative to the others until you
reach a "normalized" value. Due to this, **we strongly recommend
using [Raidbots Top Gear](<https://www.raidbots.com/simbot/topgear>)** 
instead to handle your gearing needs (see our [Raidbots guide](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>)).

2.

### In-Depth Stat Breakdown

**Intellect** is your primary stat. It provides you with Spell Power, which
increases the damage of your spells.

**Critical Strike** increases your chance to critically hit, which in
turn increases your chances to get [[spell:195283]]s.

:::details FAQDo I Need a Minimum Amount of Critical Strike to Play Fire Mage?
Since proccing

[[spell:48107]]

/

[[spell:195283]]

requires Critical Strikes,
many people assume you need a lot of Crit to play Fire. However, you do not
need any specific amount of Critical Strike to make Fire
strong. Due to passive talents like

[[spell:390218]]

giving
massive stacking critical strike rating when you do not crit on

[[spell:133]]

,

[[spell:319836]]

being guaranteed crit,

[[spell:2948]]

being guaranteed crit under 30% enemy health,
and various other talents boosting crit, you can play Fire just fine, even on
very low Critical Strike rating. In many cases, crit is actually the worst
stat because of how many guaranteed critical strikes Fire gets.

:::

**Mastery**, through [[spell:12846]], increases the damage of
your [[spell:12846]] DoT.

**Haste** influences the cast speed of your spells. It also influences
the cooldown of [[spell:319836]] and falling speed of [[spell:153561]].

:::details FAQIs There a Haste cap for Fire Mage?
There are no breakpoints or caps for Haste for Fire Mage.
However, there are diminishing returns on all stats, where acquiring more of them
reduces the value, so generally a bit of balancing is valuable.

:::

**Versatility** is a flat-out damage done increase and damage taken
reduction.

2.1.

#### Diminishing Returns on Stats

Every stat has a limit where they will begin to offer less increase per point
gained, which are known as the points of diminishing return. Once you have reached
these amounts, stats will become progressively less valuable and may fall behind
other options. The current breakpoints are:

<table>&#10;<tr>&#10;<th style="text-align: left">Stat</th>&#10;<th style="text-align: left">10% DR Rating</th>&#10;<th style="text-align: left">20% DR Rating</th>&#10;<th style="text-align: left">30% DR Rating</th>&#10;</tr>&#10;<tr>&#10;<td>Mastery</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Critical Strike</td>&#10;<td>1380</td>&#10;<td>1840</td>&#10;<td>2300</td>&#10;</tr>&#10;<tr>&#10;<td>Haste</td>&#10;<td>1320</td>&#10;<td>1760</td>&#10;<td>2200</td>&#10;</tr>&#10;<tr>&#10;<td>Versatility</td>&#10;<td>1620</td>&#10;<td>2160</td>&#10;<td>2700</td>&#10;</tr>&#10;</table>

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated for Midnight Season 1.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Updated for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **03 Mar. 2025:** Removed old paragraph that is no longer relevant, and fixed a typo.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **21 Sep. 2024:** Updated stat weights description to more clearly explain that using top gear is better.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated suggested stats due to changes in 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Updated suggested stats for the Fire Mage rework of 10.1.5.
- **01 May 2023:** Updated suggested stats based on 10.1 changes.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7 and switched mastery to above versatility.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 附魔与消耗品

On this page, we list the best gems, enchants, flasks, potions, and
food you can get for your Fire Mage, based on your [stat priority](<https://www.icy-veins.com/wow/fire-mage-pve-dps-stat-priority>).
We also give budget alternatives. This page is updated for World of Warcraft Patch 12.1.5.

1.

### Recommended Gems

There are both Epic and Rare gems, with Epic gems being
  significantly more powerful. However, you can only equip a single epic gem,
  so you will have to fill out the rest of your slots with rare gems.

There are two epic gems, either of which can be best depending on
  the situation. If you have 5 gem slots or more,
  [[item:240967]] is the best epic gem. However, if you have
  fewer than 5, use [[item:240983]].

**Rare gems are all very close in power, and the best one will
    fluctuate depending on your exact stat distribution.**
  If you have 5 gem slots or more
  and thus using [[item:240967]], you should use one of
  each color. Otherwise, you can just use any gem that sims best, or go
  [[item:240893]] as a safe default. See the list below
  for full details.

- Epic: 
  
  - With 5 sockets or more: [[item:240967]]
  - With fewer than 5 sockets: [[item:240983]]
- Rare with 5 sockets or more: 
  
  - 1x [[item:240893]]
  - 1x [[item:240916]]
  - 1x [[item:240900]]
  - 1x [[item:240906]]
  - Rest of slots [[item:240893]]
- Rare with fewer than 5 sockets: [[item:240893]] in all
      slots

<em>We highly recommend using [Raidbots](<https://www.icy-veins.com/wow/how-to-sim-your-wow-character-a-guide-to-raidbots>) to sim your character's
ideal gems and enchants, as they might differ from our general
recommendations.</em>

2.

### Best Enchants and Weapon Augments

You should be using [[item:243733]] for all content.

<table>&#10;<tr>&#10;<th>Slot</th>&#10;<th>Enchantment</th>&#10;</tr>&#10;<tr>&#10;<td>Helm (non damage)</td>&#10;<td>[[item:243981]]</td>&#10;</tr>&#10;<tr>&#10;<td>Chest</td>&#10;<td>[[item:243977]]</td>&#10;</tr>&#10;<tr>&#10;<td>Shoulders (non damage)</td>&#10;<td>[[item:243963]]</td>&#10;</tr>&#10;<tr>&#10;<td>Legs</td>&#10;<td>[[item:240133]]</td>&#10;</tr>&#10;<tr>&#10;<td>Ring</td>&#10;<td>[[item:243957]] </td>&#10;</tr>&#10;<tr>&#10;<td>Feet (non damage)</td>&#10;<td>[[item:244009]]</td>&#10;</tr>&#10;<tr>&#10;<td>Weapon</td>&#10;<td>[[item:244029]] </td>&#10;</tr>&#10;</table>

Not all Enchants provide damage, like Helm, Shoulders and Feet. You can
    choose between Speed, Avoidance or Leech for these slots. Fire already has good
    mobility, but more speed never hurts, especially as it allows you
    to move further during the instant-cast [[spell:11366]]s or
    [[spell:2948]] casts, allowing you to save mobility spells for when you
    really need them. However, Avoidance Enchants are also a great option for
    these slots to simply reduce the damage you take from various enemy
    abilities. I generally do not recommend the Leech enchants for group content,
    but it can be quite nice for solo content.

3.

### Optimal Consumables

In addition to enchants and improvements to your gear, making sure you come
prepared with the right consumables to endgame content has a big impact on your
performance.

3.1.

#### Flask

For Season 2, you should use [[item:241325]].

3.2.

#### Potions

[[item:241308]] is the best DPS potion for all content, while
    [[item:271883]] is our healing potion of choice.

3.3.

#### Food Buff

[[item:255845]], or [[spell:1278895]] if you are doing
  content with frequent dying, like progressing a raid boss.

3.4.

#### Augment Rune

Augment Runes are often quite expensive, especially early on,
    but do provide roughly a 1% DPS increase when used so can make
    the difference when doing hard content. [[item:259085]]
    is the only available Augment Rune currently.

4.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **17 Aug. 2026:** Updated best Flask.
- **10 Aug. 2026:** Updated for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **23 Mar. 2026:** Removed Tea mention since it does not work in instances.
- **16 Mar. 2026:** Updated best consumables due to latest theorycrafting findings.
- **03 Mar. 2026:** Updated best ring enchant to eyes of the eagle.
- **01 Mar. 2026:** Added Teas for their movement speed bonus to food section.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated for 11.2.0.
- **15 Jun. 2025:** Updated for Patch 11.1.7.
- **21 Apr. 2025:** Added Corruption Enchants section.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **11 Sep. 2024:** Added weapon consumable (oil).
- **09 Sep. 2024:** Added Elusive Blasphemite as an alternative gem.
- **21 Aug. 2024:** Updated for The War Within.
- **23 Jul. 2024:** Updated for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Added new season 4 helm enchant, and minor potion improvements.
- **19 Mar. 2024:** Reviewed for Patch 10.2.6.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Removed sections related to Onyx Annulet as it is now too far behind to be considered.
- **01 Oct. 2023:** Updated food buff suggestion.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **09 Aug. 2023:** Updated gem suggestion to haste + vers instead of mastery.
- **10 Jul. 2023:** Updated for the Fire Mage rework of 10.1.5 and the Primordial Gems nerf.
- **22 May 2023:** Updated leg enchant suggestions.
- **01 May 2023:** Updated Onyx Annulet suggestions based on new 10.1 gear.
- **25 Mar. 2023:** Updated Primordial Stone Gem suggestions based on hotfixes.
- **22 Mar. 2023:** Update Primordial Stone Gem suggestions due to Desirious Blood Stone combinations being very strong.
- **21 Mar. 2023:** Updated Primordial Stone gem suggestions based on Obscure Pastel Stone being Arcane instead of Shadow on live servers.
- **20 Mar. 2023:** Added Primordial Stone gem suggestions and reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **13 Jan. 2023:** Added leg enchant.
- **14 Dec. 2022:** Added weapon imbuement advice.
- **13 Dec. 2022:** Updated phial advice.
- **11 Dec. 2022:** Updated gems advice based on better simulations.
- **11 Dec. 2022:** Updated phial advice.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 大秘境

In this guide, you will find tips and advice to tackle Mythic+ dungeons with your
    Fire Mage in World of Warcraft Patch 12.1.5.

1.

### Fire Mage in Mythic+ in Midnight Season 2

Fire Mage has long been known as a powerhouse when it comes to Mythic+.
Not only does it come with a great damage profile, where you generally do not
have to give up much, or any, single-target damage to do AoE damage, it also
comes with great utility and survivability, making it a very desirable
spec to bring to any Mythic+ group.

If you are unfamiliar with Mythic+ and its associated general mechanics, you
can read more about it on our Midnight Mythic+ page below, or check out our Mythic+ Tier
List if you're curious about the current Mythic+ Meta!

Fire generally has 2 main playstyles in Mythic+, a [[spell:2120]]
based AoE playstyle, where your main spender of [[spell:195283]] is Flamestrike,
or a Cleave based playstyle, where your Hot Streaks are used on [[spell:11366]].
Both builds are generally viable, with the Flamestrike variant doing more
overall DPS and the cleave build doing more single-target and priority-target
DPS.

2.

### Best Mythic+ Talent Builds

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire    Mythic+ Talents

2.1.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/frostfire.webp>) Frostfire Mythic+ Talents

This build can do both priority DPS and maximum AoE DPS
    by simply swapping the rotation depending on the pack. Check out the [priority DPS vs AoE section](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips#prio-vs-aoe>) below for
    more info.

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAmZZGzMLzCAAAYxMDbzMzMjNAAAAAsZmxMDAAmZYmxMzMzCwMDIjxYwMMGA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFhlxdEVFJRBU4QAJ5k5XxmH-CdIBCw02MUWY4KRoquATScemKeklBJC-AAAA-SgEgZR4QhBAhyA-
```

:::

### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury    Mythic+ Talents

2.2.

#### ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Mythic+ Talents

The standard ![](<https://static.icy-veins.com/images/wow/tools/hero-talents/sunfury.webp>) Sunfury Fire Mythic+ build. It has great
    single-target and AoE DPS without compromising on either, making it
    very flexible for all types of dungeons.

This build can do both priority DPS and maximum AoE DPS
    by simply swapping the rotation depending on the pack. Check out the [priority DPS vs AoE section](<https://www.icy-veins.com/wow/fire-mage-pve-dps-mythic-plus-tips#prio-vs-aoe>) below for
    more info.

:::talents 天赋构筑
```json
{
  "code": "C8DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzsgZGZmZGAAAGAwMz0sstMDAwmZmx2MzMzYDAAAAAbmZMzAAgZMmZmZMzsMAMzAjxAmhxA"
}
```
:::

:::details 来源计算器编码
```
#:A-SVWWXdFXWYaEFNhlxd0EVFJR5DUo4QAJ5mH-CdIBCw02MUWYs4KRoqu8ATSceimGKeA-AAAA-DQko0IUY4IDwwC-
```

:::

### Flexible Talents / Dungeon Specific Talents

2.3.

#### Flexible Talents / Dungeon Specific Talents

Depending on the Dungeon, there is a lot of flexibility when it comes to
    talents. The Mage tree has a lot of utility which
    can be either very good or completely useless depending on the dungeon,
    which allows you to switch between those utility spells or defensive talents as needed.

- Swap between [[spell:1244090]] or [[spell:1244087]]
          based on personal preference. Temporal Alignment a very simple passive
          heal when you get low, while Time Walk is better if you
          are good at proactively using [[spell:342245]].
- Spec in/out of [[spell:414664]] depending on if you need it to
          skip any packs.
- Spec in/out of [[spell:475]] depending on if you need to dispell
          any curses.
- Spec in/out of [[spell:30449]] depending on if you need to remove
          any enemy buffs.
- Spec in/out of [[spell:414659]] (and the nodes leading to it) depending
          on if you need the immunity of [[spell:45438]] for the dungeon you are
          doing.
- If you specced out of any of the nodes listed above, you can use the
          points
          to spec into one or some of the following: 
  
  - [[spell:1270827]]: Useful if you often need to
                    dispell the same target multiple times in a row but do not
                    want to give up too many global cooldowns on it.
  - [[spell:1270847]]: Useful if you often need
                    to dispell yourself and someone else at the same time,
                    but no one else. This is generally only recommended if there
                    is a second Curse dispeller in the group. Can be very
                    useful during [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>) weeks
                    to quickly dispell yourself and one other person.
  - [[spell:386763]]: If you need to kite enemy packs.
  - [[spell:382293]]: For speedrunning content.
  - [[spell:210476]]: Can be combined with
                    [[spell:382293]] if you need even more movement
                    speed increases or enemy pack skips with full stealth groups.

3.

### Utility Kit and Abilities

### Interrupts, Stuns and Stops

3.1.

#### Interrupts

[[spell:2139]] is our go-to interrupt for most situations. Not only
    does it interrupt a spell, it also locks the enemy out of casting
    spells of the same school for 7-8 seconds, depending on talents.

To avoid having to switch targets, I highly recommend using either a mouseover
    or focus target macro. The macros below will kick your focus or mouseover
    target if you have one, or your current target if you do not.

#### Mouseover Counterspell

```wow-macro
#showtooltip
/cast [target=mouseover,exists] Counterspell; Counterspell
```

#### Focus Counterspell

```wow-macro
#showtooltip
/cast [target=focus,exists] Counterspell; Counterspell
```

3.2.

#### Stunning and "Stops"

[[spell:157980]] and [[spell:31661]] are the primary method of AoE
    interrupting enemies. You can only pick one, and which one you pick
    depends on the situation. Both of them will usually stop the enemy casts,
    but unlike [[spell:2139]], it will not stop them from immediately
    re-casting the same or a different spell.

Generally, Supernova is easier to use since it can be used without being near
    the enemies, but both are fine choices.

Additionally, [[spell:118]], [[spell:113724]] and [[spell:383121]]
    can be used to interrupt enemies as well (if talented), but in
    most cases the enemies will just immediately start casting again afterwards,
    so it should only be used as a last ditch effort. Polymorph also has the
    downside of it healing enemies.

### Other Utility

3.3.

#### Other Utility

[[spell:1459]] provides the whole group with bonus Intellect,
    increasing the DPS of yourself and other casters, as well as the healing
    of the healer.

[[spell:80353]] is a critical cooldown for any Mythic+ group. Every 10
    minutes
    it allows you to provide a massive haste buff to the group.

[[spell:475]] can be useful to dispel Curses in some
    dungeons. It should also be used to dispel [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>)
    if it is an active affix.

[[spell:30449]] can be used to remove magic buffs on enemies and
    grant them to you instead. Although in many cases, the buffs are not
    actually
    granted to you due to balancing reasons, so it is primarily used as an
    offensive dispel.

[[spell:110959]] can be used to completely drop aggro, while
    additionally it can sometimes completely cancel certain debuffs, targeted
    casts
    on you, or cancel various mechanics.

[[spell:386828]] allows you to remove snare/slow effects. It does
    this by entirely removing the debuff that causes the slow, which means
    it can occasionally be used to completely remove dangerous debuffs,
    if they also apply a slow.

[[spell:414664]] can occasionally be useful to skip certain packs.

4.

### In-Depth Rotation Tips for Mythic+

Listed below are some specific Mythic+ tips that can elevate your gameplay even further,
once you're already familiar with the regular Rotation from our Rotation section.

4.1.

#### Picking Priority DPS or Maximum AoE DPS

With the recommended talent builds, you have a lot of flexibility
    in what type of damage you want to do in Mythic+. Ultimately, it comes
    down to whether you use [[spell:11366]] or [[spell:2120]]
    as your [[spell:195283]] and [[spell:269650]] spender.
    Pyroblast will provide significantly
    more priority target DPS, whereas Flamestrike does significantly more
    AoE DPS. Luckily, you can switch which one you use freely without needing
    to change your talents, allowing you to pick and choose depending
    on the pack.

Generally the choice is quite obvious: If there is a target in the pack
    that is very dangerous if left alive for a long time, you simply use
    [[spell:11366]] as your [[spell:195283]] / [[spell:269650]] spender,
    but if that is not the case, you instead use [[spell:2120]] as your spender.

5.

### Dealing with Affixes

Season 2 of Midnight has four rotating Affixes which require active play
    to deal with, called Xal'ataths Bargains. These rotate every week, with only
    one of them being active at a time. Most other Mythic+ affixes, like
    Fortified or Tyrannical, simply add a passive effect to the keystone, with
    these four exceptions that are themed after Xal'atah:

- [Xal'atath's Bargain: Ascendant](<https://www.wowhead.com/mythic-affix=148>): Three waves of orbs will spawn that
          need to be interrupted or disrupted. You have multiple ways of dealing
          with these: [[spell:157980]] for AoE interrupt if they are close
          together, [[spell:2139]] for singular interrupts, and
          [[spell:30449]] for any remaining ones.
          Since Spellsteal has no cooldown (unless talented into
          [[spell:1270827]]), you can theoretically get rid of all of
          them, but this will take up a lot of time.
- [Xal'atath's Bargain: Voidbound](<https://www.wowhead.com/mythic-affix=158>): Spawns a Void Emissary enemy which
          needs to be quickly killed. After it dies, you get a strong ability
          cooldowns and Versatility buff. Note: You can spread [[spell:12846]]
          to this target if it spawns close to the enemies you already have
          Ignite on, which can provide a lot of free damage to the add.
- [Xal'atath's Bargain: Pulsar](<https://www.wowhead.com/mythic-affix=162>): Orbs will spawn around players and
          circle around them. You have 15 seconds to soak all of these to buff
          your group. Simply run into them to soak them.
- [Xal'atath's Bargain: Devour](<https://www.wowhead.com/mythic-affix=160>): All party members will be affected by a
          healing absorb. You can remove these with [[spell:475]].
          [[spell:1270847]] is very useful to quickly dispell yourself
          and one other player. Health potions or Healthstones also work well if
          your healer is out of resources.

When you successfully deal with these affixes, they grant you a beneficial
    buff, which differs per affix. These effects are usually quite strong, but
    not really played around. It is however very important to deal with them
    correctly, as failing to do so will buff the enemies which can very quickly
    wipe a group.

Note: These affixes go away when doing dungeons of a Keystone level of 12 or
    higher (both the positive and negative effects), instead causing deaths to
    deduct 15 seconds from the timer.

6.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Updated optimal talents for 12.1 / Season 2 and updated rotation info for optimal talents.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **24 Apr. 2026:** Swapped some utility talents around for slightly more common default choices.
- **21 Apr. 2026:** Small typo fix
- **20 Apr. 2026:** Updated utility section layout and added some additional context for interrupts and utility.
- **16 Mar. 2026:** Updated for Season 1 of Midnight: Updated best talents, flexible talents, added seasonal affixes, etc.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated Talent Trees for 12.0.1 tree changes.
- **19 Jan. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Updated best builds for 11.2, added section for season 3 utility spells.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **30 Mar. 2025:** Add warning to not spec into Lessons in Deblitation for TOP+Brew.
- **22 Mar. 2025:** Removed wind up interrupt tip as they cannot be interrupted by disorients.
- **14 Mar. 2025:** Added tips for all dungeons.
- **24 Feb. 2025:** Updated best talents for 11.1 changes, updated affix tips for new affixes.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **26 Nov. 2024:** Updated talents for the latest buffs.
- **21 Oct. 2024:** Updated talents and split viable talents up into 3 different builds. Also added dungeon specific tips.
- **02 Oct. 2024:** Updated Flamestrike vs Ignite choice to further emphasize that Flamestrike does more overall DPS.
- **24 Sep. 2024:** Added Flamestrike based aoe builds now that it is more viable due to the latest buffs
- **09 Sep. 2024:** Updated for TWW Season 1.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Updated best talents based on Season 4 changes.
- **19 Mar. 2024:** Updated for Patch 10.2.6., splitting up the different M+ builds into separate boxes so they take up less space and can be viewed more easily.
- **09 Mar. 2024:** Updated suggested Mythic+ talents slightly, and added more information on picking between Ignite vs Flamestrike builds.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Updated talents for 10.2.
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **01 Aug. 2023:** Updated talent choice between improved scorch and critical mass instead of meteor.
- **10 Jul. 2023:** Updated talents suggestions, rotation and utility for after the 10.1.5 Fire rework.
- **12 Jun. 2023:** Fix talent import string.
- **01 May 2023:** Updated talents based on new optimal talents and removed mentions to the Flamestrike build as it is now too behind to consider, and removed mentions about thundering.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7 and provided some small phrasing tweaks.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Updated for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::


## 宏与插件

On this page, you will find a number of useful macros and addons to make your life easier when playing your Fire Mage in World of Warcraft Patch 12.1.5.

1.

### Best Macros

Listed below is a collection of useful Macros for Mage, and Fire Mage specifically, with
some of them being usable on all three specs, while others are only useful if you're playing
Fire Mage.

1.1.

#### Fire Specific Macros

1.1.1.

##### 1-Button Combustion

#### 1-Button Combustion

```wow-macro
#showtooltip Combustion
/cast Ancestral Call
/cast Berserking
/cast Blood Fury
/cast Combustion
/use 13
/use 14
/use 16
```

This will cast [[spell:190319]] and any of your trinket slots at
the same time. Additionally, it will also activate DPS boosting Racials,
like [[spell:26297]] or [[spell:33697]]. Keep in
mind that you can use Combustion while casting other spells, so you
will have to keep pressing the macro until after the cast finishes to
activate the trinket and racial.

1.1.2.

##### Cast At Cursor Flamestrike

#### Cursor Flamestrike

```wow-macro
#showtooltip Flamestrike
/cast [@cursor] Flamestrike;
```

This macro will cast [[spell:2120]] on your cursor, instead of
first showing a targeting circle. This only works if you have selected the
manual-cast Flamestrike Talent, not the targeted Flamestrike Talent.

:::details FAQShould I Use the Targeted [[spell:2120]] or the Area Targeted Flamestrike?
For most players, the auto-targeted option will be the best choice.
It frees up your cursor and attention to focus on the rest of the game.
However, since it is centered on the mob you're attacking, you will find situations
where this misses some of the mobs in the pack. With practice, you should be
able to squeeze out a little more DPS using the area targeted
(via the @cursor macro) version. Try both, see which you like more.

:::

1.1.3.

##### Cast At Cursor Meteor

#### Cursor Meteor

```wow-macro
#showtooltip Meteor
/cast [@cursor] Meteor;
```

This will cast [[spell:153561]] at the location of your cursor instead of
first showing a targeting circle.

:::details FAQCan I Cast [[spell:153561]] on My Target Instead of Cursor?
Unfortunately not. It is not possible to make a macro to cast

[[spell:153561]]

at your target, and the base game also does not have that functionality.
The @cursor macro shown above is the best solution.

:::

1.2.

#### Generic Macros for Mages

1.2.1.

##### Stopcast Blink

#### Instant Blink

```wow-macro
#showtooltip
/stopcasting
/cast Blink
```

Pressing [[spell:1953]] will now cancel your current spellcast and
causes you to immediately Blink. Note that this should not be used with 
[[spell:212653]] as it will unnecessarily cancel your current cast, nor should
it be used if you are casting something that you can wait to finish casting
before needing to Blink

1.2.2.

##### 1-Button Block

#### 1-Button Ice Block

```wow-macro
#showtooltip
/stopcasting
/cancelaura Ice Block
/cast Ice Block
```

Cancels your current cast and immediately puts you in [[spell:45438]].
Pressing Ice Block again will cancel the effect. Not recommended if you spam your
buttons.

1.2.3.

##### Block Cancel

#### Cancel Aura Ice Block

```wow-macro
/cancelaura Ice Block
```

If you are a button spammer, you can put this on a separate keybind as your 
[[spell:45438]], allowing you to cancel your Ice Block early if you so
desire.

1.2.4.

##### Alter Time Cancel

#### Cancel Aura Alter Time

```wow-macro
/cancelaura Alter Time
```

You can use the above macro to cancel [[spell:342245]] if you do not want to
be teleported back to the location/health where you were when you initially cast
Alter Time.

1.2.5.

##### Mouseover Decurse

#### Mouseover Remove Curse

```wow-macro
#showtooltip
/cast [target=mouseover,exists] Remove Curse; Remove Curse
```

This will remove curses on whatever unit you are mousing over. You can replace
Remove Curse for any other spells you might want to do on mouseover,
like [[spell:30449]]. If you have no mouseover target, it will cast it
on your current target, or yourself if you have neither a mouseover or selected
target.

2.

### Best Addons

:::details FAQWhy Can I Not See My [[spell:195283]] Procs?
In the settings menu, adjust the "Spell Alert Opacity" (use search
functionality to find it). Additionally, if you
prefer to track with an icon, you can enable tracking for

[[spell:195283]]

in the
Blizzard Cooldown Manager and it will track both Hot Streak and

[[spell:48107]]

.

:::

2.1.

#### ElvUI

[ElvUI](<https://www.tukui.org/download.php?ui=elvui>) is a complete replacement of the default
User Interface. It comes with almost everything you need to perform properly:
action bars, unit frames, cooldown timers, proc displays, etc.

2.1.1.

##### Method Raid Tools

[Method Raid Tools](<https://www.curseforge.com/wow/addons/method-raid-tools>) is a useful addon that allows you to track the cooldowns of other raid
members, as well as providing you with a wealth of other useful raid information.

3.

### Changelog

:::details 历史更新记录
- **12 Oct. 2026:** Reviewed for Patch 12.1.5.
- **10 Aug. 2026:** Reviewed for Patch 12.1.
- **15 Jun. 2026:** Reviewed for Patch 12.0.7.
- **20 Apr. 2026:** Updated for Patch 12.0.5.
- **16 Mar. 2026:** Updated Combustion Macro to have all relevant racials/trinket slots by default and added FAQs for not seeing Hot Streak procs and Meteor/Flamestrike macros and usage.
- **09 Mar. 2026:** Fixed mouseover macro for remove curse.
- **26 Feb. 2026:** Updated for Midnight 12.0.1.
- **10 Feb. 2026:** Updated for Midnight Pre-Patch.
- **30 Nov. 2025:** Reviewed for Patch 11.2.7.
- **05 Oct. 2025:** Reviewed for Patch 11.2.5.
- **04 Aug. 2025:** Reviewed for Patch 11.2.
- **15 Jun. 2025:** Reviewed for Patch 11.1.7.
- **21 Apr. 2025:** Reviewed for Patch 11.1.5.
- **24 Feb. 2025:** Updated for Patch 11.1.0.
- **15 Dec. 2024:** Updated for Patch 11.0.7.
- **21 Oct. 2024:** Reviewed for Patch 11.0.5.
- **09 Sep. 2024:** Reviewed for The War Within Season 1.
- **21 Aug. 2024:** Reviewed for The War Within.
- **23 Jul. 2024:** Reviewed for The War Within Pre-Patch.
- **07 May 2024:** Reviewed for 10.2.7.
- **22 Apr. 2024:** Reviewed for Season 4.
- **19 Mar. 2024:** Updated for 10.2.6., updating the default addons to a more relevant set of addons for today's Raiding and Mythic+ climate.
- **15 Jan. 2024:** Reviewed for Patch 10.2.5.
- **06 Nov. 2023:** Reviewed for Patch 10.2
- **04 Sep. 2023:** Reviewed for Patch 10.1.7
- **10 Jul. 2023:** Reviewed for the Fire rework of 10.1.5, and no changes were necessary.
- **28 Apr. 2023:** Added a generic weakaura pack containing all neccesary WeakAuras for all specs.
- **20 Mar. 2023:** Reviewed for Patch 10.0.7.
- **24 Jan. 2023:** Reviewed for Patch 10.0.5.
- **11 Dec. 2022:** Reviewed for Dragonflight Season 1.
- **28 Nov. 2022:** Reviewed for Dragonflight launch.
- **24 Oct. 2022:** Updated for Dragonflight pre-patch.

Show more

Show less

:::
