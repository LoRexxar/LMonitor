## 专精导读

戒律牧师可通过造成伤害触发救赎治疗，同时拥有直接治疗与吸收技能。理解伤害转化为治疗的机制，是掌握这一专精的基础。

本页提供中文简要导读与原文导航；具体天赋、装备和技能优先级请查看对应章节。

## 原文章节

- [专精概览](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-guide>)
- [练级](<https://www.icy-veins.com/wow/discipline-priest-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-macros-addons>)

## 来源信息

- 来源：[Icy Veins](<https://www.icy-veins.com/wow/discipline-priest-pve-healing-guide>)
- 原文作者：Clandon
- 页面版本：12.1.5
- 原文更新：2026-10-12T16:30:00+00:00
- 采集时间：2026-10-22T07:12:23.455283+00:00
