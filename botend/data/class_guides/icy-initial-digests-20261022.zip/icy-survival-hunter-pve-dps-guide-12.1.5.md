## 专精导读

生存猎人是灵活的近战输出专精，也保留一定远程作战能力。构筑能够兼顾单体和范围伤害，需结合战斗环境选择。

本页提供中文简要导读与原文导航；具体天赋、装备和技能优先级请查看对应章节。

## 原文章节

- [专精概览](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-guide>)
- [练级](<https://www.icy-veins.com/wow/survival-hunter-leveling-guide>)
- [快速入门](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-easy-mode>)
- [天赋与构筑](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-spec-builds-talents>)
- [技能循环与冷却](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-rotation-cooldowns-abilities>)
- [装备选择](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gear-best-in-slot>)
- [属性优先级](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-stat-priority>)
- [附魔与消耗品](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-gems-enchants-consumables>)
- [大秘境](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-mythic-plus-tips>)
- [宏与插件](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-macros-addons>)

## 来源信息

- 来源：[Icy Veins](<https://www.icy-veins.com/wow/survival-hunter-pve-dps-guide>)
- 原文作者：Azortharion
- 页面版本：12.1.5
- 原文更新：2026-10-12T16:30:00+00:00
- 采集时间：2026-10-22T07:12:23.455283+00:00
