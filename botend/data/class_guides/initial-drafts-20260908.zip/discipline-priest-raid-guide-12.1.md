欢迎来到魔兽世界12.1版本的**戒律 牧师** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始升级的玩家吗？请查看升级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**总体治疗** · 4/5 · 强

冷却技能强度 · 4/5 · 强

功能性 · 4/5 · 强

生存能力 · 3/5 · 一般

机动性 · 1/5 · 较差



:::

:::

:::column
:::gear **戒律 牧师** 团队副本 最佳装备（BiS）
```json
{
  "source_code": "JQpAICQA3_fABIgJEIIEBAw74OA_sOgF2kjAYFQApfBBAERAAcVrBQBBMWTBUgUwkQgAIUAA1k7ACKgTBcbpDEgxJIBAJkgEwMQ1DEQ4XQAgIEAA8zaBkQQACnQIIthqDkjAOFAGVPQAffBBCgQAA8QAzgDWBEAIoOAhIEAAno6AYAcArB3t1sUABQMJEAACFAggCgVATfBBBAYLEIICBAwL5GQIBsHDBIW2DojEAgxVfQAAIEAAF4BAU1BDE09FNgBFYFQA0LCBBsHAF0weYlAwDQAIBAAdAPAGAPAAAAAAAAwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240892]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240892]] |
| 肩部 | [[item:271553]] | [[item:244021]] |
| 胸部 | [[item:271558]] | [[item:243977]] |
| 腰部 | [[item:268257]] | [[item:240892]] |
| 腿部 | [[item:271554]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:273792]] | [[item:240892]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:244015]] |
| 饰品一 | [[item:270167]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245876]] · [[item:245784]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **戒律 牧师**，你可以使用 驾驭黑暗，它使你的苦修有几率将你的 [[spell:17]] 变为 [[spell:1253593]]。

**等级2**和**等级3**都会使你的暗影伤害和救赎治疗各提高3%。

**等级** 4使你的[[spell:8092]]将你的[[spell:17]]升级为[[spell:1253593]]，并且[[spell:1253593]]会反弹15%的吸收伤害。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-discipline-mxr.webp>)

黑暗大师

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:103712]]
    
    - 你的苦修现在还会附加一个持续伤害效果。
  - [[talent:103718]]
    
    - 引导期间每连续一记 苦修 光箭都会提高其伤害和治疗量。
- **已移除**
  
  - [[spell:34433]]
    
    - 不再是主动技能，因此爆发不再那么剧烈起伏。
  - [[spell:314867]]
    
    - 在冷却技能期间，你将无法再使用暗影版苦修。

## 英雄天赋



### [[talent:123288]]

- 每个 [[spell:8092]] 都会开启一个 [[spell:447444]]，造成大量伤害，并给予你以下增益和收益：
  
  - [[spell:585]] 会变形为 [[spell:450405]]，其 [[spell:81749]] 治疗量额外提高 100%。
  
  
  
  - [[spell:449880]]
    
    - 大幅提升你的 [[spell:81749]] 治疗量。
  - [[spell:451018]]
    
    - 提高移动速度。
  - 当 [[spell:447444]] 结束时，它会坍缩并通过 [[spell:448403]] 造成大量伤害。




### [[talent:123290]]

- [[talent:123290]] 通过以下多个天赋节点大幅强化你的苦修：
  
  1. [[talent:117286@FAQAIdhA]]
     
     - 你的 苦修 拥有 2 层充能
  2. [[talent:117276@FAQAIdhA]]
     
     - 提高每次 苦修 的第一道光束效果。
  3. [[talent:117290]]
     
     - 苦修 在你用它治疗时会向敌人射出额外光束，用它造成伤害时则会射出额外光束治疗盟友。





## 天赋



### 通用 团队副本 天赋

:::talents **戒律 牧师** 通用 团队副本 天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 何时使用该专精

这是进入任何首领战时的默认配置，除非另有说明。你需要根据每次遭遇战所需的辅助能力来调整你的职业天赋树。为了让你的操作更轻松，团队副本章节中提供了针对各个首领的专属天赋配置。

#### 改变游戏玩法的天赋

探索专精和职业天赋树中显著改变你游戏方式的所有天赋。本节将简明概述这些天赋及其应用，如需更详细的了解，请查看下方的循环和深度解析部分。

##### 专精树

- [[talent:103698]]
  
  - 每次 [[spell:47540]] 之后，你的下一个 [[spell:17]] 或 [[spell:585]] 会被强化。

##### 职业树

- [[spell:109186]]
  
  - 这是 戒律 牧师最好的回复手段，因为 快速治疗 是你在友方 苦修 之外最强的直接治疗技能。这个天赋对法力管理和机动性都有显著帮助。
- [[spell:336897]]
  
  - 当你对队友施放 [[spell:10060]] 时，你自己也会获得该效果。
- [[spell:193063]]
  
  - 与 [[spell:368276]] 和 [[spell:109186]] 配合，这个天赋可以为你提供非常容易获得的10%减伤。
- [[talent:103835]]
  
  - 为 牧师 职业工具箱增加了一个新的但较弱的防御技能。不过，与 [[spell:193063]] 结合使用时，它可能救你一命！





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：**‍[[spell:47540]] 伤害和治疗效果提高20%。施放‍[[spell:47540]]会使‍[[spell:8092]]的冷却时间缩短2秒。
- **4件套：**施放‍[[spell:8092]]后，你的下一个‍[[spell:17]]或‍[[spell:1253593]]吸收的伤害提高25%。

### 优先级列表

仅在**任何爆发序列之外**时才遵循此列表。

1. 保持 [[spell:589]] 在目标身上。
2. 冷却好了就施放 [[spell:8092]]。
3. 冷却好了就施放 [[spell:47540]]。
4. 在2层时施放 [[spell:1253593]]。
5. 在2层时施放 [[spell:194509]]。
6. 施放 [[spell:585]]。

### 冷却技能

展示 **戒律 牧师** 在团队副本中使用的所有不同冷却技能序列。

#### 福音

:::rotation **戒律 牧师** 团队副本中的福音爆发序列
```json
{
  "source_code": "IUEUJIUTCAAAAgQbhlmb0FWauBgQNgAABEADClNITEACMKwDCPAAAIQz3LAAAIAnfAAAAIAt5CAAAI0pebAAAAAACdq3GA"
}
```
1. [[spell:589]] 保持
2. [[spell:2061]]
3. [[spell:1253593]]
4. [[spell:246287]]
5. [[spell:194509]]
6. [[spell:8092]]
7. [[spell:47540]]
8. [[spell:450215]]
9. [[spell:450215]]
:::

#### 终极苦修

:::rotation **戒律 牧师** 团队副本中的 终极苦修 序列
```json
{
  "source_code": "IkDEHIUDIAQABwgQNfvABgAnCw5HAAAAC0kbGAAAClNITAAAKkmbgQHalBSYpJHACQbuAAAACdq3GA"
}
```
1. [[spell:2061]]
2. [[spell:194509]]
3. [[spell:8092]]
4. [[spell:421453]]
5. [[spell:1253593]] 空中
6. [[spell:47540]]
7. [[spell:450215]]
:::

- **施放此技能时务必先选定一个敌人作为目标！**

## 深度解析

#### 优化使用 真言术：耀

- 在需要分散站位的团队副本战斗中，如果不考虑整个团队的站位，就无法稳定达到 18–20 个救赎覆盖。想在治疗爆发前的铺垫阶段提高救赎覆盖数量，一个简单的方法是分别对一名远程玩家和一名近战玩家施放 [[spell:194509]]。不建议将 [[spell:194509]] 用于以下这类职业：法师 或 猎人，因为他们往往站在远离团队的位置，使你的 [[spell:194509]] 无法波及 5 名玩家。

#### 极限优化 能量灌注

- 虽然 [[spell:10060]] 是 **你的** 法术，但最佳用法是忽略你自己，转而完全专注于你的队友。为此，你需要了解队友进攻技能冷却的持续时间。建议直接与他们沟通，让他们在确切需要的时候提出请求！

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊



### 内克扎莉

:::talents **戒律 牧师** 内克扎莉 团队副本天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 在房间边缘驱散中了 [[spell:1287322]] 的队友！
- 当首领施放 [[spell:1284103]] 时，不要站在首领和坦克之间。




### 陵寝哨兵

:::talents **戒律 牧师** 陵寝哨兵 团队副本天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 驱散受到 [[spell:1284471]] 影响的玩家。
- [[spell:1284590]] 在恰好达到 4 层时会被无害地中和。




### 迷失的探险者

:::talents **戒律 牧师** 团本中 Lost Explorers（迷途的探险者）的天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 驱散受到 [[spell:1286921]] 影响的玩家。




### 瓦什尼克

:::talents **戒律 牧师** 团本中瓦什尼克的天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 对受到 [[spell:1295224]] 影响的玩家使用单体技能（外部增益）。在受影响期间，他们免疫你的常规治疗。
- 受到 [[spell:1294994]] 影响时请使用个人减伤。




### 斯索拉克

:::talents **戒律 牧师** 斯索拉克 团队副本天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 对受到 [[spell:1286987]] 影响的玩家使用单体技能（外部增益）。




### 双牙

:::talents **戒律 牧师** 团本中双牙天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 当你受到 [[spell:1290809]] 影响时，使用个人防御技能。




### 盘绕祭坛

:::talents **戒律 牧师** 团本中盘绕祭坛天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。




### 乌拉特克

:::talents **戒律 牧师** 乌拉特克 团队副本天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。




### 尼姆瑞莎·唤波者

:::talents **戒律 牧师** 团本中的尼姆瑞莎·唤波者天赋
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

#### 首领攻略技巧

- 当大量 [[spell:1257717]] 被触发时，使用个人防御技能。





## 属性优先级

了解你作为**戒律 牧师**在团队副本首领战斗中实现最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **戒律 牧师** 属性优先级
```json
{
  "source_code": "IoAJFUAJxACKBQwABA"
}
```
**智力 ＞ 急速 ≫ 精通 ≥ 暴击 ＞ 全能**
:::

> 此处的结论是，你通常应当装备装等最高的装备。

- 所有次要属性都会受到**收益递减**的影响。[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)了解更多！

### 第三属性

- **闪避** - 减少受到的范围伤害效果伤害。
- **吸血** - 将你造成的伤害和治疗的一部分以治疗形式返还给你。（不包括自我治疗）
- **加速** - 提高移动速度。（可与其他加速移动技能叠加）

唯一需要考虑选择较低装等装备的情况，是它带有吸血或闪避属性时。加速也不错，但在两件装备之间抉择时不应考虑该属性。

- 下面展示一下吸血对治疗者来说有多强大：史诗难度弗拉希乌斯数据剖析

![](<https://assets-ng.maxroll.gg/wordpress/6o58gMo-1024x362.png>)

魔兽世界战斗日志

## 装备



### 最佳配装

由于**戒律牧师**的属性权重运作方式，并不存在一份严格意义上的最佳配装（BIS）清单。尽管理论上有可能获得所有第三属性都正确的装备，但由于《魔兽世界》的每周重置机制，这需要极强的运气或者好几辈子的时间。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271874@BARAAAQAWYTOCgVA]] | 乌拉特克 |
| 项链 | [[item:268265@BERAAAQAX16wPrDj1kjAYFA]] | 乌拉特克 |
| 肩部 | [[item:239031@AgQAAIoAOFA]]（催化为套装） | 神殿 |
| 披风 | [[item:268253@BgQAAAQACKAWBA]] | 盘绕祭坛 |
| 胸部 | [[item:251139@AgQAAIoAOFA]]（催化为套装） | 密谋小径 |
| 腕部 | [[item:239648@FiQAAAQAno6gBwD_sO3WzSB]] | 制造业 |
| 手套 | [[item:271556@BgQAAAQACKAWBA]] | 套装/催化器 |
| 腰带 | [[item:268257@BiQAAAQA8z6IoAOF]] | 制造业 |
| 腿部 | [[item:251160@AgQAAIoAOFA]]（催化为套装） | 纳洛拉克的洞穴 |
| 脚部 | [[item:268255@DgQAAAQAPk7IoAYF]] | 盘绕祭坛 |
| 戒指1 | [[item:273792@DiQAAAQAvk7wPrjgC4UA]] | 毒牙祭坛 |
| 戒指2 | [[item:252258@DiQAAAQAvk7wPrjgC4UA]] | 虚空之痕竞技场 |
| 饰品1 | [[item:270164@BgQAAAQA5IgTBA]] | 迷失的探险者 |
| 饰品2 | [[item:270167@BgQAAAQA5IgTBA]] | 尼姆瑞莎 |
| 武器 | [[item:271092@DgQAAAQAFk7IoAYF]] | 乌拉特克 |
| 副手 | [[item:245769@FASAAAQA0B8gBwDAAAAAAAwt1sUA]] | 制造业 |

#### 作者的话：

此清单列出了 大秘境 中来自所有来源的最佳治疗装备。请注意，获得带有吸血/闪避的不同套装部件会改变哪件散件对你来说最优。同样，任何其他带有吸血/闪避的非饰品装备都可以替换这里推荐的装备。




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251232@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 颈部 | [[item:251173@AgQAAIoABFA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:239031@AgQAA8rBBFA]] | 神庙 |
| 披风 | [[item:251190@AgQAAIoABFA]] | 耀目谷地 |
| 胸部 | [[item:251139@AgQAAIoABFA]] | 密谋小径 |
| 护腕 | [[item:251127@AgQAAIoABFA]] | 密谋小径 |
| 手套 | [[item:159247@AgQAAIoABFA]] | 神庙 |
| 腰带 | [[item:193691@AgQAAIoABFA]] | 红玉新生法池 |
| 腿部 | [[item:251160@AgQAAIoABFA]] | 纳洛拉克的洞穴 |
| 靴子 | [[item:251219@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 戒指 1 | [[item:252258@DiQAAkGAvk7wPrjgCEUA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:273792@DiQAAAQAvk7wPrjgCEUA]] | 毒牙祭坛 |
| 饰品 1 | [[item:250214@AgQAAIoABFA]] | 耀目谷地 |
| 饰品 2 | [[item:250215@AgQAAIoABFA]] | 密谋小径 |
| 双手武器 | [[item:159636@AgQAAIoABFA]] | 神庙 |
| 单手武器 | [[item:273778@AgQAAIoABFA]] | 毒牙祭坛 |
| 副手 | [[item:251191@AgQAAIoABFA]] | 耀目谷地 |





### 饰品

下面你可以找到可用饰品的主动与被动排名。请注意，根据每个首领战的不同，某些饰品会比其他饰品表现更好。

| 排名 |  |
| --- | --- |
| S级 | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A级** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **B级** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **垃圾级** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### 美化饰品

- [[item:245876]] 
  
  - 属性武器附魔效果非常强力，根据你攻击的目标提供大量的某一二级属性。
- [[item:239664@BiQAAEQA6z6IyLdE]]
  
  - 属性数值严重超模的属性武器附魔。

#### 剩余的火花

- 制造装备的物品等级为331，普通装备的最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则在2件美化装备之外再装备制造装备并无收益。

## 消耗品

- **药瓶**
  
  - [[item:241324]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241288]]
  - [[item:241300]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@BQAAAEEAaB]]
- **插槽**
  
  - [[item:240892]]
  
  
  
  - [[item:240967]] *--* *唯一，每种颜色的宝石各使用一颗来强化你的永恒之歌钻石。*
    
    - [[item:240900]]
    - [[item:240916]]
    - [[item:240906]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAAEQA]]  <br>[[item:243951]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAkG]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAAEQA]] |
| 腰带 | [[item:275707@BAAAAEQA]] |
| 腿部 | [[item:240155@BAAAAkG]] |
| 脚部 | [[item:243983@BAAAAkG]] |
| 戒指1 | [[item:244015@BAAAAAQA]] |
| 戒指2 | [[item:244015@BAAAAAQA]] |
| 武器 | [[item:243973@BAAAAAQA]] |

:::

:::column
:::gear **戒律 牧师** 附魔
```json
{
  "source_code": "IQFZBEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAAT0AEoMRuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243987]] |  |
| 戒指二 | [[item:243987]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> 你可以在宏伟宝库商人处购买 [[item:275707@BAAAAEQA]] 来为你的头部、护腕和腰带添加插槽。

## 种族

对于追求极限优化的 **戒律 牧师** 来说，在史诗团本中，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，那么选择一个符合你个人风格的种族同样可行。

- [[spell:69070]] *-- 地精* 
  
  - 向前跳跃，可在下落或被击退时施放。
- [[spell:256948]] *--* *虚空精灵* 
  
  - 生成一道向你面朝方向飞行的暗影，再次激活即可传送到该位置。
  - 最大距离100码。

### 推荐：

强烈建议玩龙希尔！**牧师** 的移动速度可能相当缓慢，而二段跳带来的额外机动性在那些棘手的处境中真的非常有用。

## 宏

探索**戒律 牧师** 在团队副本战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
为了方便起见，本戒律 牧师 团队副本攻略中的所有法术都以鼠标指向宏的形式提供！

[[spell:47540]]

```wow-macro
/cast [@mouseover, help] 苦修; 苦修
```

[[spell:17]]

```wow-macro
/cast [@mouseover, help] 真言术：盾; 真言术：盾
```

[[spell:194509]]

```wow-macro
/cast [@mouseover, help] 真言术：耀; 真言术：耀
```

[[spell:139]]

```wow-macro
/cast [@mouseover, help] 恢复; 恢复
```

[[spell:2061]]

```wow-macro
/cast [@mouseover, help] 快速治疗; 快速治疗
```

[[spell:10060]]

```wow-macro
/cast [@mouseover,exists] 能量灌注; 能量灌注
```

[[spell:73325]]

```wow-macro
/cast [@mouseover, help] 信仰飞跃; 信仰飞跃
```

[[spell:33206]]

```wow-macro
/cast [@mouseover, help] 痛苦压制; 痛苦压制
```

:::

:::details 推荐宏
如果你在使用这个宏时按下 Shift，[[spell:121536]] 会自动放置在你脚下，省去 Ctrl 点击的步骤。

```wow-macro
/cast [mod:shift, @player] 天堂之羽; 天堂之羽
```

如果你愿意，可以替换你的[[spell:527]]宏。这个宏的作用是：如果你以敌人为目标就驱散敌方魔法，如果以队友为目标就驱散友方负面效果，为你节省一个按键绑定。

```wow-macro
#showtooltip 纯净术
/use [@mouseover, help] 纯净术; [harm] 驱散魔法; [noharm] 纯净术
```

你的[[spell:32375]]在按下按钮时无需确认点击就会立即施放，请谨慎使用。

```wow-macro
#showtooltip
/cast [@cursor] 群体驱散
```

一个不错的仅限牧师的小宏，懂的人自然懂。

```wow-macro
/cast [nomod] 漂浮术
/cancelaura [mod:shift] 漂浮术
```

:::

:::

## 插件

下面你可以看到作者为其**戒律 牧师**所使用的用户界面截图，其中概述了所使用的插件，以及它们在团队副本中如何使用，从而让你的游戏生活更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/e3V7I8v-1024x576.webp>)

**戒律 牧师** 团队副本

:::accordion
:::details 插件
- EllesmereUI —— 全能
  
  - 用于升级暴雪自带 UI 的插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 戒律
  
  - 开发者说明：对于乌拉特克诅咒中的戒律，我们的改动旨在降低该专精对触发效果进行有效治疗的依赖，改善稳定伤害来源，并改善英雄天赋的平衡性。我们认为该专精过于依赖暗影治疗和虚空之盾的触发来进行有效治疗，因此我们将暗影治疗改为快速治疗的被动升级，并新增一种确定性的方式来获取虚空之盾。此外，惩击虽然施放频繁，但造成的伤害偏低，因此我们正在提高其伤害，并调整天赋树以便更容易获得强效惩击。
- 新天赋：冷酷救赎——暗影治疗的治疗量提高30%，并使救赎的持续时间延长4秒，但其施法时间增加0.5秒。
- 暗影治疗的触发几率不再基于暗言术：痛的伤害，并已被重新设计为被动升级——快速治疗升级为暗影治疗，一个治疗量更强但法力消耗更高的治疗法术。
- 顶尖天赋：掌控黑暗（第3级）已更新——心灵震爆现在会将你的下一个真言术：盾升级为虚空之盾。虚空之盾由苦修触发的几率降低至15%（原为33%）。虚空之盾的吸收量降低28%。
- 顶尖天赋：掌控黑暗现在最多可积攒2层。
- 所有治疗和吸收效果提高10%。
- 救赎的治疗量为造成伤害的32%（原为30%）。
- 快速治疗的治疗量提高25%。
- 惩击的伤害提高40%。
- 无尽的折磨伤害降低30%。
- 苦修对友方目标施放时不再施加救赎。
  
  - *开发者说明：我们在进入至暗之夜时更新了苦修，使其施加救赎，但我们感觉这一改动的体验不佳，因为它会在以下三者之间造成过多的冲突：对需要治疗的盟友施放苦修、对需要施加救赎的盟友施放，以及对想要造成伤害的敌人施放。*
- 终极苦修的伤害和治疗量提高30%。
- 强效惩击的持续时间延长至4秒（原为2秒），且现在为1点天赋。
- 英雄天赋
  
  - 神谕者
    
    - 展开的幻象已重新设计——当真言术：盾或虚空之盾在仍有剩余吸收量时到期，它会转而跳转至附近一名受伤的盟友身上。每个护盾只能触发一次。
  - 虚空编织者
    
    - 虚空冲击的伤害提高25%。
    - 虚空怨灵的伤害提高30%。
    - 虚空灌注现在在熵能裂隙激活期间，使虚空冲击和苦修的救赎治疗量提高75%（原为50%）。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我总是死亡？
答：开始把[[spell:33206]]当作你自己的防御冷却技能来使用。

:::

:::details 问：为什么我的法力总是不够用？
答：你浪费了太多公共冷却时间，而且[[spell:314867]]的覆盖率不够高。

:::

:::

---

### 致谢

作者：**Rycn**

审校：**Ftm**

---

:::changelog 更新记录
**2026-08-07** 攻略已更新至12.1版本

**2026-06-19** 攻略已更新至12.0.7版本

**2026-05-01** 攻略已更新至12.0.5版本

**2026-01-18** 攻略已更新至12.0版本

**2025-10-07** 攻略已更新至11.2.5版本

**2025-07-28** 攻略已更新至11.2版本

**2025-06-18** 攻略已更新至11.1.7版本

**2025-04-19** 攻略已更新至11.1.5版本

**2025-02-24** 攻略已更新至11.1版本

**2024-12-17** 攻略已更新至11.0.7版本

**2024-10-20** 攻略已更新至11.0.5版本

**2024-08-17** 攻略编写于11.0.2版本



:::
