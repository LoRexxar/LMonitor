Welcome to the **Brewmaster Monk** raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Brewmaster Monk** Raid Best in Slot
```json
{
  "source_code": "JgfAYyQA3_PAB8JJEIIEFAw74OgDtOQOCchNYFwAmQQApfBBAERAA4QrDUwFYxYNYFQAKU9ACgQAAUTuDIoAOFQAiSCBB8ADJk7A5EwDUUT1DAICBEgMF4BAeGgH8UAAhu7A5IAWBE8FEEASuJQAwAwDN8DCE5mAuADAYAKJEAACBAQBLBYeWPggIEAA1j7AO06A3WzSBEQNtOghIEAAfA8A1j7AhZdFYQwXf0gNMgVAB4VEMAhTBEA2XUAGFoIP3eBBCARAA0TuDIoAWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240910]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240910]] · [[item:240910]] |
| 肩部 | [[item:251146]] | [[item:244021]] |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:251189]] | [[item:240910]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159304]] | [[item:243983]] |
| 腕部 | [[item:159300]] | [[item:240910]] |
| 手部 | [[item:271520]] |  |
| 戒指一 | [[item:251513]] | [[item:240910]] · [[item:243957]] |
| 戒指二 | [[item:240949]] | [[item:240910]] · [[item:245791]] · [[item:243957]] · [[item:251489]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270174]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Brewmaster Monk**, you have access to Bring Me Another, which gives you a 20% chance on your next Brew that you conusme, to give an Empty Barrel, which is then automatically consumed on your next [[spell:121253]] and does additional physical damage.

**Rank 2** makes your [[spell:121253]] cooldown reset and your next [[spell:121253]] cost 50% less energy. While on **Rank 3,** drinking a [[spell:115203]] or [[spell:322507]] gives you a fresh keg, which then, on consumption, provides you with the buff [[spell:1265140]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-brewmaster-mxr.webp>)

Bring Me Another

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:400629]]
    
    - Before, every time you took damage you had a chance to spawn a Healing Sphere, now every time you use [[spell:109080]] you have a chance to spawn a Healing Sphere.
  
  
  
  - [[spell:196736]]
    
    - This got changed so your next [[spell:109080]] only buffs your next [[spell:121253]] or [[spell:100780]].
  
  
  
  - [[spell:1262659]]
    
    - Makes your fire & nature damage heal you for 50% of its damage.
  - [[spell:1263245]]
    
    - Provides us with an additional 5% Mastery during [[spell:132578]].
  - [[spell:1262017]]
    
    - After casting [[spell:325153]], your next 2 [[spell:121253]] are enhanced and summon a whirl of fire around the enemy.
  - [[spell:1262329]]
    
    - Allows us to reactivate [[spell:325153]] after its use to throw 5 additional kegs at nearby enemies and reduce the cooldown of all our brews by 3 seconds.
  - [[spell:383707]]
    
    - On top of giving your [[spell:121253]] another charge, it also gives [[spell:121253]] an additional 10 yards of range, which makes it great for pulling from further away.
  - [[spell:1263345]]
    
    - Drinking one of your brews provides you with more movement speed and auto-attack speed.
- **Class Tree**
  
  - [[spell:1266733]]
    
    - [[spell:119381]] now applies [[spell:116095]] to every enemy hit for 5 seconds.
  
  
  
  - [[spell:1243287]]
    
    - Now isn't an active button anymore and rather build into your [[spell:115203]] with the functionality of being able to transfer back magic debuffs back to your target whenever you press [[spell:115203]].
  - [[spell:1272452]]
    
    - Makes your next [[spell:115080]] heal you for 50% of its damage done.
- **Removed**
  
  - [[spell:122278]] 
    
    - This results in having less major defensive cooldowns against large tank hits.
  
  
  
  - [[spell:310454]]
    
    - The removal of [[spell:310454]] makes us not having an offensive cooldown anymore.
  - [[spell:389577]]

## Hero Talents

- [[talent:125028]] and ‍[[talent:125027]] are both very competitive with each other when it comes to damage output.
- [[talent:125028]] influences your gameplay with [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] and [[spell:451036@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]], while [[talent:125027]] is almost fully passive.
- It is recomended to play [[talent:125028]] as it does slightly more Single Target damage than [[talent:125027]] and it is more tanky against raid bosses mostly because of [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]].

### [[talent:125027]]

- [[talent:125069]]
  
  - Your auto-attacks have chance to generate [[spell:451021]].
  
  
  
  - Casting [[spell:121253]] will unleash all [[talent:125069]].
- [[spell:450989@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Reduces the cooldown of [[spell:132578]] by 25 seconds.
- [[spell:1272821@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]]
  
  - During [[spell:132578]] your next [[spell:115181]] will unleash 3x [[talent:125069]].

- [[talent:125027]] choice node picks are:
  
  - [[talent:125068]]
  - [[spell:1272844]]
  
  
  
  - [[talent:125064]]
    
    - This passive does not have a cooldown and can proc at any time.

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1262603@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]] 
  
  - Everytime you use [[spell:132578]] you will instantly gain 10 stacks of [[spell:450615]].

### [[talent:125028]]

- [[spell:450508@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Damage and effective healing are stored as Vitality.
  - During [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] you don't generate any Vitality.
  - Important: Overhealing does not count as effective healing.
- [[talent:125035]] 
  
  - Important node to never waste any Vitality.
- [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Having 2 charges of [[spell:1241059]] makes it easy to hold/delay the use to optimize for damage and survivability.
- [[spell:451036@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - The extra shield and [[spell:115069]] reduction are strong defensively.
- [[spell:450529@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Increases the damage enemies take by 20% while you are under the effect of [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]].

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1239442]] 
  
  - Everytime you cast [[spell:1241059]] your next 2 [[spell:100780]] are enchanced and will trigger a [[spell:1239442]].
- [[spell:1271048]]
  
  - After every [[spell:121253]] your next [[spell:100780]] will trigger a [[spell:1239442]].

## Talents

### Defensive Build

:::talents **Brewmaster Monk** Raid Defensive Build
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### When to use this spec

This is the default loadout going into any boss unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Raids section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:124864]]
  
  - Shuffle doubles the effectiveness of [[spell:115069]].
- [[spell:400629]]
  
  - Gives your [[spell:109080]] a chance to spawn [[spell:115464]].
- [[spell:212935]]
  
  - Make sure to keep [[spell:115181]] on cooldown before casting [[spell:121253]] to get the cooldown reset from this talent.
- [[spell:383707]]
  
  - [[spell:121253]] now has 2 charges and its range is increased by 10 yards.
- [[spell:389942]]
  
  - [[spell:100780]] becomes way stronger and generates extra brew cooldown reduction.

##### Class Tree

- [[talent:124950]]
  
  - [[spell:115546]] now increases the targets movementspeed by 50%.
- [[talent:124963]]
  
  - Now after rolling you can press double jump and do a small dash forward.

### Damage Build

:::talents **Brewmaster Monk** Raid Damage Build
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDzw2M2wMjBAAAAAAYZBjGzMwMM2YwMzMDz2YmxMLPAbLPwy2sNLmFAAYb2mWmtZWGAgZbWamZmFGWAYmhpxAAAGA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDzw2M2wMjBAAAAAAYZBjGzMwMM2YwMzMDz2YmxMLPAbLPwy2sNLmFAAYb2mWmtZWGAgZbWamZmFGWAYmhpxAAAGA"
}
```
:::

#### When to use this spec

This talent loadout is more for advanced **Brewmaster Monks** that know how to juggle well with their resources. This build is more focused on damage but can also easily survive anything if played well.

#### Talent Adjustments

Listing all the changes within Class and Spec tree compared to the default build.

##### Class Tree

- **Added**
  
  - [[talent:124837]]
    
    - Increases your auto-attack speed which helps with gaining [[spell:451021]].
  - [[spell:196730]]
    
    - Every time you use [[spell:1241059]] or [[spell:119582]] you drop a Keg on the enemy which deals extra damage.
- **Removed**
  
  - [[spell:455139]]
    
    - Provides a very small shield and has no damage gain.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:115181]] ignites your next [[spell:121253]], causing it to explode on contact, dealing additional Flamestrike damage to its primary target and reduced damage to additional targets.
- **4-Set:** Ingnited [[spell:121253]]'s cause enemies struck to take 8% increased damage from your Physical abilities, and leave a patch of flames on the ground, dealing Fire damage each second for 5 sec.

### Opener

- We want to gain a good amount of [[spell:322120]] through [[spell:121253]] and [[spell:205523]] while also getting our debuffs rolling.

:::rotation **Brewmaster Monks** Raid Opener
```json
{
  "source_code": "IUETIIUpZHAAAAQABwprDAAAAAgQwmYAQgAACxaDIQQ7BnAEJgCEAIUI2TgPoAA"
}
```
1. [[spell:121253]]  [[item:241308]]
2. [[spell:100784]]
3. [[spell:100780]]
4. [[spell:115181]]
5. [[spell:121253]]
6. [[spell:325153]]
7. [[spell:100784]]
8. [[spell:100780]]
:::

### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Cast [[spell:121253]] on cooldown.
2. Cast [[spell:100784]] on cooldown.
3. Cast [[spell:100780]] or [[spell:101546]] on 8+ targets.
4. If talented, cast [[spell:115181]].
5. Cast [[spell:325153]].
6. If talented, cast [[spell:123986]].
7. When the pull is about to end make sure to use [[spell:322109]] whenever possible.

### Defensive Cooldowns

- [[spell:1241059]]
  
  - Provides you with a smaller absorb shield & 30% damage reduction during its duration.
  
  
  
  - Gains cooldown reduction from [[spell:121253]] and [[spell:100780]].
  - Now has 2 charges with [[talent:125028]] talent [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]].
- [[spell:322507]] vs. [[spell:1241059]]
  
  - For raiding I recommend to run [[spell:1241059]] since its numerically the better choice over [[spell:322507]].

- [[spell:243435]]
  
  - Crazy long cooldown of 4 minutes that gets reduced by [[spell:121253]] and [[spell:100780]].
  - Gives 20% max health and 20% damage reduction, which makes it your most well-rounded **defensive**.
  - Used mainly against big hits and early on so the cooldown reduction can start working on getting it back.
- [[spell:132578]]
  
  - Used when your [[spell:115069]] is particularly high since it suffers 40% of your [[spell:115069]] damage instead of you.

### Offensive Cooldowns

- [[talent:125001]]
  
  - Causes melee attacks of targets hit to 100% miss you for 3 seconds.
  - Throw a keg that amplifies all your damage with bonus fire damage. Pair with [[spell:101546]] on AoE.
- [[spell:322109]]
  
  - Clears up to 200% [[spell:115069]] when casted. [[spell:325095]] is very good to cast on cooldown for both damage and defensive value.

## Deep Dive

### Stagger

**Brewmaster Monks** rely on their [[spell:115069]] mechanic to passively reduce the damage they take which is an essential part of their damage mitigation.

#### Stagger Phases

Your [[spell:115069]] is split up into 3 different phases.

- [[spell:124275]]
  
  - Total [[spell:115069]] damage amount is equal to 1-29% of your maximum health.
- [[spell:124274]]
  
  - Total [[spell:115069]] damage amount is equal to 30-59% of your maximum health.
- [[spell:124273]]
  
  - Total [[spell:115069]] damage amount is equal to 60% or more of your maximum health.

Using [[spell:119582]] cleanses **50%** of the [[spell:115069]] damage thus reducing your [[spell:115069]] phase and serving as your main mitigation ability. [[spell:119582]] is best used right after receiving a lot of damage to cut the [[spell:115069]] damage in half.

### Managing Celestial Infusion & Purifying Brew

Juggling [[spell:322507]] & [[spell:119582]] is your main task and gameplay when it comes to your survivability on **Brewmaster Monk**.

- [[spell:119582]] is your main tool to cleanse [[spell:115069]] like described above.
  
  - Important to note: [[spell:119582]] **is not on the global cooldown**, so it can be pressed while using any other ability.
- [[spell:1241059]] is your defensive tool.

Here are some tips and tricks on what to keep in mind when using them:

- [[spell:119582]] has a few rules you want to keep in mind when juggling your charges:
  
  - Avoid having both charges ready, you are wasting both defensive value and cooldown reduction value from your abilities.
  
  
  
  - Make sure you always get full cooldown reduction on this from [[spell:121253]].
- General rule on when to use [[spell:119582]] the most efficient way:
  
  - After a big hit so you get the most [[spell:115069]] value cleansed when it is new and at the highest point.
  - The other option is to almost fully cleanse yourself of any dangerous [[spell:115069]] after big hits, this is achieved by getting a very big stagger and then using 2 charges back to back.
- Overall, if you follow a natural flow of gameplay, you should use it quite frequently just to avoid [[spell:124273]] and not overcap charges.
- The biggest mistake you can make is to use all charges on cooldown and then end up with none when the [[spell:115069]] becomes dangerous.
- [[spell:1241059]] is more straightforward to use:
  
  - It's your most frequent active defensive and should be used on most mechanics whenever possible.
  - Try to not hold it for too long since you are wasting cooldown reduction, which results in more damage taken in the long run.
  - However, you have to hold it for dangerous tank mechanics in certain scenarios, so keep that in mind.

### Shuffle

**Brewmaster Monks** need [[spell:115069]] to live any mechanic and what enables it to a large extent is [[talent:124864]].

- [[talent:124864]] is passively generated by pressing [[spell:121253]], [[spell:101546]] and [[spell:205523]].
- If you don't stop pressing buttons, [[talent:124864]] should never drop and you don't need to pay any attention to it. But there are some scenarios where the buff might run out:
  
  - When mechanics force you out of range and you are unable to reach the boss you might end up dropping it, resulting in a lot more damage taken so watch out for that!
  - Starting combat with [[spell:121253]] and running in fast can result in death. Since [[talent:124864]] is triggered by the damage of [[spell:121253]] and not the cast, if you are faster than the keg flying, you might get hit without [[talent:124864]] up and you die.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are applicable to **Mythic Bosses** and how to survive those the best. The recommended builds in this section are going to help you survive each encounter but are not giving you the most damage output.

**← Scroll for more Bosses →**

### Nek'Zali

:::talents **Brewmaster Monk** Raid Nek'Zali
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### Tank mechanics

- The main tank mechanic of this fight is Hollowing Strikes - a debuff that the boss applies with each melee strike, as well as with [[spell:1284103]].
- During [[spell:1284103]], the boss sends spectral echoes towards the active tank, applying extra stacks of Hollowing Strikes. These echoes burst on first impact with any player, dealing reduced raid 
  
  - When targeted by this mechanic, move out of the raid and make sure no one is standing between you and the boss so they don't trigger the echoes too early. Otherwise, they will deal too much damage to the raid.
  - Taunt swap after each cast of [[spell:1284103]].
- Apart from that, the boss will spawn waves of Restless Amani - make sure to move the boss next to them to allow for better cleave.
- During the intermission, the active tank will be targeted by a group soak - [[spell:1289855]]. Try to put it on top of as many Restless Amani corpses as possible to burn them with [[spell:1289875]] to prevent them from awakening again.

### Entombed Sentinals

:::talents **Brewmaster Monk** Raid Entombed Sentinals
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### Tank mechanics

- The bosses have to always be separated by at least 40 yards due to [[spell:1290189]]. At the start of each phase, split the bosses apart by moving them to different sides of the room.
- [[spell:1284458]] and [[spell:1284487]] are the stacking tank debuffs of each of the bosses. Make sure to taunt swap on the bosses each time they meet in the middle of the room during [[spell:1284588]] to reset your stacks.
  
  - [[spell:1284487]] additionally creates a large pool of blood upon expiration. Make sure to drop it off at the edges of the room if possible.
- Don't tank Breath of Ula'tek too close to the existing blood puddles so the [[spell:1284251]] doesn't spawn in the pool and melees can safely attack it.

### Lost Explorers

:::talents **Brewmaster Monk** Raid Lost Explorers
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### Tank mechanics

- All three bosses cannot be positioned within 30 yards of each other due to [[spell:1297645]] - always keep one of the bosses away from the other 2.
- Trader Gebbo just wanders around the room and doesn't follow or attack its threat target. It also doesn't have any tank mechanics.
- Scrollsage Iku casts [[spell:1295854]] at its current target - a series of ice shards, each doing magic damage and increasing damage taken from the next shard for 80 seconds.
- First Mate Nama applies [[spell:1291929]] with each attack to its target, increasing physical damage done to that target for 30 seconds.
- The job of the tanks on this fight is to swap between Scollsage Iku and First Mate Nama, never letting [[spell:1295854]] to be casted at the same target twice and resetting [[spell:1291929]] as often as possible, while always keeping one of the bosses far enough to prevent [[spell:1297645]] from being applied.

### Vashnik

:::talents **Brewmaster Monk** Raid Vashnik
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### Tank mechanics

- There are 3 fountains placed on the sides of the room: Fountain of Blood, Fire, and Shadow. The boss will activate the two closest ones with [[spell:1283164]] throughout the fight, gaining their powers and spawning some adds.
  
  - Each fountain activation empowers the next activation for 1.5 minutes.
  
  
  
  - Your job as a tank is to never let the boss activate the same two fountains in a row by moving the boss to the next fountain before each [[spell:1283164]] cast.
  - Make sure to position the boss on top of the adds coming from the fountain for better cleave. However, be careful with quickly killing all the fire adds, as they apply stacking [[spell:1285979]] when they die.
- Vashnik's tank hit is [[spell:1280935]], taunt swap after each cast.

### Sszorak

:::talents **Brewmaster Monk** Raid Sszorak
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### Fight mechanics

- [[spell:1277025]] is a combination of tank frontals consisting of 2 [[spell:1277002]], 2 [[spell:1277027]], and one [[spell:1287072]], cast in a random order.
  
  - [[spell:1277002]] is a frontal cone that deals heavy physical damage and follows the active tank. Make sure to aim it **away from the raid**.
  - [[spell:1277027]] is a frontal cone that applies a heavy magic DOT, which is reduced by the number of people hit by the cone. Make sure this ability is aimed into one half of the raid, so people can soak it.
  - [[spell:1287072]] spawns a bunch of tornadoes around the boss and sends them outwards at the end of the cast. Make sure you're not under the boss when this happens and dodge the tornadoes.
  - In heroic and mythic difficulties, the boss will cast these in a random order. Since each frontal cone applies a damage taken increase from that ability, make sure that one tank never takes 2 of the same abilities. Keep in mind that you can taunt during the cast so the boss aims the frontal cone at you instead.
- Each cast of [[spell:1306120]] spawns [[spell:1305998]] puddles around the boss. Make sure to move the boss to an edge of the room, ideally opposite the [[spell:1285732]] spawn, so that the puddles get blown off the edge of the room by the winds.
- Apart from that, Sszorak applies a stack of [[spell:1282869]] with each melee attack, increasing physical damage taken by the target. Taunt swapping on each [[spell:1277025]] combo is enough to reset the stacks.

### Twin Fangs

:::talents **Brewmaster Monk** Raid Twin Fangs
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### General mechanics

- The entire fight revolves around managing [[spell:1290336]] stacks
  
  - [[spell:1291404]], [[spell:1291478]], getting hit by poison waves, or soaking [[spell:1289201]] applies a stack of [[spell:1290336]].
  - Reaching 10 stacks in Heroic or 9 in Mythic difficulties immediately kills you.
  - It is crucial to dodge as many poison waves as possible while managing how many [[spell:1289201]] you soak to prevent reaching maximum stacks of this debuff.

#### Tank mechanics

- Being outside of melee range of the boss that you're actively tanking will cause it to cast [[spell:1295107]] or [[spell:1295113]], so make sure to never leave melee or use a big personal if you ever find yourself far from the boss.
- Vexhul's tank ability is [[spell:1289192]], which deals nature damage and pushes you back for 5 seconds.
  
  - It also spawns [[spell:1289201]] around you. These need to be soaked by players before they explode to prevent everyone from getting an [[spell:1290336]] stack.
  - Each hit applies [[spell:1310360]], so taunt swap between every [[spell:1289192]] cast.
  - Be aware of the pushback, especially when the poison waves are coming!
- Ithraz casts [[spell:1288538]], pushing back players close to the boss and spawning 3 soak zones.
  
  - Each zone deals heavy physical damage and increases the damage taken from the next zone by 33%. If it is left unsoaked, it deals raid-wide damage and knocks everyone away. Make sure to taunt swap between each set of [[spell:1288538]] to reset the stacks of the damage increase.
  
  
  
  - The zones spawn in a random order and need to be soaked in the same order that they spawned. Pay attention to the spawns and memorize the spawn order when this ability is happening. The boss will also shortly face towards the zone it will trigger next, so you can use that direction if you can't remember the spawn order.
  - Each second [[spell:1288538]] cast overlaps with poison waves coming - make sure you're not getting hit by waves while soaking the [[spell:1288538]].
  - Watch out for the pushback at the start of this mechanic, as it can push you into an incoming wave or a [[spell:1289201]].

### Coiled Altar

:::talents **Brewmaster Monk** Raid Coiled Altar
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### Phase 1

- Only Zul'jan is active during this phase.
- He casts [[spell:1299960]], which spawns multiple [[spell:1282403]] orbs during this phase. They deal pulsing raid-wide AOE while they're active, and can be picked up and moved by players running into them.
- [[spell:1299684]] is a frontal cone aimed at the active tank that deals physical damage and destroys any [[spell:1282403]] it hits.
  
  - It also increases damage taken by the next [[spell:1299684]] by 200%, so make sure to taunt swap after every cast.
- The goal of this phase is for the raid to group up the [[spell:1282403]] orbs so they can then be destroyed by [[spell:1299684]].
- Additionally, each cast of [[spell:1282487]] empowers the next 23 melees of the boss with [[spell:1300322]], dealing extra nature damage to the tank. 
  
  - Make sure to frontload defensives while the boss has stacks of [[spell:1300322]].

#### Phase 2

- Only Hex Lord Malacrass is active during this phase.
- He casts [[spell:1285640]], which mind-controls selected players, and spawns 2 [[spell:1285842]] per player when the mind control is broken.
  
  - The Manifestations fixate on random players, moving towards them, unless the fixated player looks back at the Manifestation.
- Similar to [[spell:1299684]] in Phase 1, [[spell:1286620]] is a frontal cone aimed at the active tank that deals shadow damage and destroys any [[spell:1285842]] it hits.
  
  - It also increases damage taken by the next [[spell:1286620]] by 200%, so make sure to taunt swap after every cast.
  - Additionally, it applies 3 stacks of [[spell:1286837]], which spawn a Soul Fragment per stack that needs to be picked up in order to remove the stack. If the stacks are not cleared before the debuff expires, the affected player immediately dies.
  - It is important to pay extra attention to finding and collecting all Soul Fragments quickly after each tank frontal.
- Getting hit by a [[spell:1286895]] also applies 3 stacks of [[spell:1286837]]. Don't let it catch you off guard!

#### Intermission

- Malacrass takes 100% extra damage while casting [[spell:1287685]].
- Don't let any Fragments of Malacrass reach the boss by soaking them to prevent them from healing the boss.
  
  - Soaking each fragment deals raid-wide AOE damage, so don't soak them too quickly to give your healers some time to react to the incoming damage.

#### Phase 3

- During this phase, both Zul'jan and Malacrass are active, combining their abilities from Phases 1 and 2.
- Both [[spell:1299960]] and [[spell:1285640]] happen in this phase, meaning both [[spell:1282403]] and the [[spell:1285842]] need to be cleared by the tank frontal.
- The tank frontal cone of this phase is [[spell:1307279]], which deals shadow damage, destroys any [[spell:1282403]] and [[spell:1285842]] hit by it, and applies 3 stacks of [[spell:1286837]].
  
  - Don't forget to collect your Soul Fragments and taunt swap after each cone!
- [[spell:1298381]] is the empowered verision of [[spell:1282487]] from phase 1.
  
  - In this phase, the empowered melee attacks additionally apply a **stacking** shadow DOT. Use big defensives when reaching high stacks.

### Ula'tek

:::talents **Brewmaster Monk** Raid Ula'tek
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

### Nymrissa Wavecaller

:::talents **Brewmaster Monk** Raid Nymrissa Wavecaller
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### General mechanics

- The boss targets random players with Chilling Frost, which drops Frost Orbs under their feet.
  
  - These orbs need to get soaked before they explode and wipe the raid.
  - Soaking an orb applies a stacking debuff that increases the damage taken from soaking Frost Orbs, so don't soak too many in one go.
  - Each orb soak also deals raid-wide AOE, so don't soak them too quickly to give your healers some time to react to the incoming damage.
- Occasionally, murlocs will spawn from the water and start walking towards the bubble in the middle of the room.
  
  - Don't let them reach the bubble, and move the boss on top of them whenever possible to allow for better cleave.

#### Tank mechanics

- A tank-only mechanic of the fight is the Iceblade Flurry - a series of magic slashes, with each slash increasing the damage of the following ones.
  
  - Use a defensive for each cast and taunt swap after each one.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Brewmaster Monk**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Brewmaster Monk** Stat Priorities in Raid
```json
{
  "source_code": "HoAJFMAKgEDJBIQABA"
}
```
**敏捷 ＞ 全能 ＝ 暴击 ＞ 精通 ＞ 急速**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, Leech is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
Avoidance is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

### Overall BiS

| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:271875@BARAAwQACKwF2gVA]]  <br>into [[item:271519@DCRBAwQAvj74QrTOCchNYFwAmQA]] | Catalyst of Ula'tek |
| Neck | [[item:268265@BERAAwQAO064QrTOCwYNYFA]] | Ula'tek |
| Shoulder | [[item:251146@DgQAAwQA1k7IoAOF]] | Den of Nalorakk |
| Cloak | [[item:268248@BgQAAwQACKgTBA]] | Nek'zali the Soulcoiler |
| Chest | [[item:271522@DgQAAwQAJk7kjAOF]] | Vashink the Malignant |
| Wrist | [[item:159300@BiQAAwQAO06IoAOF]] | Kings' Rest |
| Gloves | [[item:271520@BgQAAwQA5IgTBA]] | Entombed Sentinals |
| Belt | [[item:251189@BiQAAwQAO06IoAOF]] | The Blinding Vale |
| Legs | Convert [[item:268225@BgQAAwQA5IAWBA]]  <br>into [[item:271518@DgQBAwQAhu7kjAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:159304@DgQAAwQAPk7IoAOF]] | Kings' Rest |
| Ring 1 | [[item:251513@DiQAAwQA1j74Qrzt1sUA]] | Crafting |
| Ring 2 | [[item:240949@HiQAAwQAfA8UPuTYWPO06cbNLFA]] | Crafting |
| Trinket 1 | [[item:270175@BgQAAwQA5IAWBA]] | Ula'tek |
| Trinket 2 | [[item:270174@BgQAAwQA5IgTBA]] | Sszorak |
| Weapon | [[item:268215@DARAAwQA9k7IoAWYDWB]] | Ula'tek |

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:193751@BgQAAwQACKQQBA]] | Ruby Life Pools |
| Neck | [[item:251234@BgQAAwQACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:251146@BgQAAwQACKQQBA]] | Den of Nalorakk |
| Cloak | [[item:159288@BgQAAwQACKQQBA]] | Kings' Rest |
| Chest | [[item:251226@BgQAAwQACKQQBA]] | Voidscar Arena |
| Wrist | [[item:159300@BgQAAwQACKQQBA]] | Kings' Rest |
| Gloves | [[item:193758@BgQAAwQACKQQBA]] | Ruby Life Pools |
| Belt | [[item:251189@BgQAAwQACKQQBA]] | The Blinding Vale |
| Legs | [[item:251198@BgQAAwQACKQQBA]] | The Blinding Vale |
| Boots | [[item:159304@BgQAAwQACKQQBA]] | Kings' Rest |
| Ring 1 | [[item:251148@BgQAAwQACKQQBA]] | Den of Nalorakk |
| Ring 2 | [[item:251136@BgQAAwQACKQQBA]] | Murder Row |
| Trinket 1 | [[item:250244@BgQAAwQACKQQBA]] | Den of Nalorakk |
| Trinket 2 | [[item:250228@BgQAAwQACKQQBA]] | Murder Row |
| Weapon | [[item:251192@BgQAAwQACKQQBA]] | The Blinding Vale |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons & Raids. Do note that the trinkets recommend above are for optimal damage, if you do not care about your damage and only want to survive I would recommend you to use a trinket like [[item:270160@BgQAAwQA5IgTBA]].

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAAwQA5IAWBA]]  <br>[[item:270174@BgQAAwQA5IgTBA]] |
| **A-Tier** | [[item:270160@BgQAAwQA5IgTBA]]  <br>[[item:270173@BgQAAwQACKAWBA]]  <br>[[item:250244@BgQAAwQACKgTBA]]  <br>[[item:250215@BgQAAwQACKgTBA]]  <br>[[item:250228@BgQAAwQACKgTBA]] |
| **B-Tier** | [[item:270164@BgQAAwQA5IgTBA]]  <br>[[item:250243@BgQAAwQACKgTBA]]  <br>[[item:159617@BgQAAwQACKgTBA]]  <br>[[item:159618@BgQAAwQACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAwQACKgTBA]]  <br>[[item:250259@BgQAAwQACKgTBA]]  <br>[[item:250214@BgQAAwQACKgTBA]]  <br>[[item:193757@BgQAAwQACKgTBA]] |
| **Junkyard** | [[item:270165@BgQAAwQA5IgTBA]]  <br>[[item:250245@BgQAAwQACKgTBA]]  <br>[[item:250225@BgQAAwQACKgTBA]] |

### Embellishments

- [[item:251513@DiQAAwQA1j74Qrzt1sUA]]
  
  - Nice passive secondary stat buff.
- [[item:251489@BAAAAwQA]]
  
  - Doubles the stats all your gems provide and can be put on any item.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stones**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *-- Unique, can only be used once.*
  - [[item:240914]]
  - [[item:240910]]

### Enchantments

:::columns
:::column
| Head | [[item:243949@DAAAAwQAZbAB]]  <br>[[item:275707@BAAAAwQA]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAwQA]] |
| Belt | [[item:275707@BAAAAwQA]] |
| Legs | [[item:244641@BAAAAwQA]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244017@BAAAAwQA]] |
| Ring 2 | [[item:244017@BAAAAwQA]] |
| Weapon | [[item:244029@BAAAAwQA]] |

:::

:::column
:::gear **Brewmaster Monk** Raid
```json
{
  "source_code": "IQFZMEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy ‍[[item:275707@BAAAAwQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Brewmaster Monk** in Raids, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- **[[spell:65116]]** -- Dwarf
  
  - Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  - On top of that using Stoneform gives you 10% physical DR which can be used as a small extra 8 second personal when tanking.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
  - Maximum range of 100 yards.

### Recommendation

As a tank picking a racial for damage is most of the times such a small gain that it's not worth it. If you care about min-maxing your DPS go with the highest DPS racial.

That being said the recommended race for raid tanks is for sure **Dwarf** for the on-use physical damage reduction and the ability to self-dispel when needed. These features are insanely strong and should not be undervalued!

## Macros

Discover recommended macros for **Brewmaster Monk** for Raids and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:115546]]* at your target or your mouseover (very handy to pick up mobs)

```wow-macro
#showtooltip Provoke
/cast [@mouseover,exists,harm][@target,exists,harm] Provoke
```

Boss 1 Taunt --- *Casts* [[spell:115546]] on Boss1

```wow-macro
/cast [@boss1] Provoke
```

Boss 2 Taunt --- *Casts* [[spell:115546]] on Boss2

```wow-macro
/cast [@boss2] Provoke
```

:::

:::details Mouseover Macros
[[spell:116841]] --- *This macro either casts [[spell:116841]] at your target or your mouseover*

```wow-macro
#showtooltip Tiger's Lust
/cast [@mouseover,exists,noharm][@target,exists,noharm] Tiger's Lust
```

[[spell:115078]] --- *Casts [[spell:115078]]* at your mouseover target

```wow-macro
/show tooltip
/use [@mouseover] Paralysis
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Focus Macros
[[spell:115078]] --- *Casts [[spell:115078]]* at your focus target

```wow-macro
/show tooltip
/use [@focus] Paralysis
```

Focus [[spell:116705]] --- *Casts [[spell:116705]]* at your focus target

```wow-macro
#showtooltip Spear Hand Strike
/cast [@focus,harm,nodead][] Spear Hand Strike
```

:::

:::details Utility Macros
[[spell:116844]] Cursor --- *Casts [[spell:116844]]* *at your cursor position without confirmation.*

```wow-macro
/cast [@cursor] Ring of Peace
```

Cancelaura BoP --- *This cancelaura's [[spell:1022]] on you, very useful to have when playing with a paladin*.

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Brewmaster Monk**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Monk-Raid-Interface-1024x607.png>)

**Brewmaster Monk** Interface in Raids

:::accordion
:::details Addons
- **ElvUI *-- Full User Interface replacement*** 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- [](<https://www.curseforge.com/wow/addons/shadowed-unit-frames>)**BigWigs** -- Generic Boss Mod
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring and a lot of customization options.
- **Details** -- In-depth Damage Meter
  
  - Makes your damage meter look more handsome.
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for raiders, especially for raid leaders and officers.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
#### Monk

- Chi Transfer now causes Touch of Death to heal you for 60% of damage it deals (was 50%).
- Vigorous Expulsion increases Expel Harm's healing by 6% (was 5%).
- Silent Sanctuary healing increased by 25%.

#### Brewmaster

- Stagger reduction from Staggering Strikes increased by 25%.
- Spirit of the Ox chance to generate a healing sphere increased by 20%.
- Celestial Brew and Celestial Infusion absorb increased by 150% and cooldown increased by 100%.
- Awakening Spirit's maximum absorb value increased by 25%.
- Vital Flame heals for 50% of Fire or Nature damage dealt (was 40%).
- The following buffs are now tracked in the Cooldown Manager: Fuel on the Fire, Hot Potato, Scorched, Crackling Jade Lightning, and August Blessing.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I just get one-shot?
A: There is a high chance [[spell:322120]] ran out and you lost the ability to use [[spell:115069]] properly.

:::

:::

---

### Credits

Written By: **Skövte**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-11** Updated for Patch 12.1

**2026-06-16** Updated for Patch 12.0.7

**2026-04-21** Updated for Patch 12.0.5

**2026-02-26** Updated for Patch 12.0.1

**2026-01-20** Updated for Midnight 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-05** Updated for patch 11.2



:::
