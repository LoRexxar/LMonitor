欢迎来到魔兽世界12.1版本的**鲜血 死亡骑士** 大秘境攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从80级开始练级的玩家？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 大秘境
**单体** · 5/5 · 优秀

范围伤害 · 4/5 · 强力

功能性 · 5/5 · 优秀

生存能力 · 5/5 · 优秀

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **鲜血 死亡骑士** 大秘境 最佳配装
```json
{
  "source_code": "JsfAAqPA3_PABIHJEIICBAw74Og_sOQOC4UABk-FEAQEBAwVtmgE0wYNYFQAwRCBCgQAAUTuJMCB-eRBPAQCB8AKYFQAjfBBAiQAA4fABBGWBEQckQgAQUAAhu7A5IgF2gVAGYCBBEXLFIDTPk7ACKgTBEgChOAhQEAAVA8AmoaAnRDAAcbNLFQAzRCBAgQAAUwhgMubCIICBAwL5GAIAIYA1ggYZPgOSAABf9RDwwAWBEQVRwAHOFQAog6AEgQEfBwtBoFN1eBBQgQAAUJ_EkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240894]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240894]] |
| 肩部 | [[item:271472]] | [[item:244021]] |
| 胸部 | [[item:268222]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271473]] | [[item:244641]] |
| 脚部 | [[item:273777]] | [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245781]] · [[item:240166]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:159459]] | [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270165]] |  |
| 背部 | [[item:239656]] | [[item:245781]] · [[item:240166]] |
| 主手 | [[item:268213]] | [[spell:326805]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **鲜血 死亡骑士** 你可以使用 至暗之夜之舞。它使你在 [[spell:49028]] 期间招架一次攻击后，有几率让你的下一次 [[spell:79885]] 不消耗符文，并额外造成150%的伤害。

**等级2**会降低你受到的伤害，并且每有一个激活的[[spell:49028]]都会提高你造成的伤害。而**等级3**则使你每消耗一枚符文时有一定几率召唤一个[[spell:49028]]，持续6秒。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-blood-mxr.webp>)

至暗之夜之舞

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[spell:1264235]]
    
    - 使你的[[spell:45470]]现在可以额外命中2个目标。
  - [[spell:108199]]
    
    - 沉默效果现已整合进该技能中，不再需要额外消耗1点天赋点。
  - [[spell:1263743]]
    
    - 使你在[[spell:49028]]期间提高招架几率，并在其持续期间使你的符文能量提高10点。
  - [[spell:1263781]]
    
    - 当[[spell:1263743]]结束时，它会爆炸，对附近的敌人造成伤害，并为你恢复其爆炸伤害15%的生命值。
  - [[spell:1265790]]
    
    - 你的[[spell:79885]]有几率使你的[[spell:50842]]的冷却时间缩短0.25秒。
  - [[spell:1263824]]
    
    - 是一个具有3个阶段的蓄力技能，蓄力时间越长，造成的伤害越高，获得的伤害减免也越多。
- **职业树**
  
  - [[spell:1266819]]
    
    - 你的[[spell:61999]]消耗的符文能量减少30点。
  
  
  
  - [[spell:391571]]
    
    - 现在是2点天赋，投入2点后可获得30%的额外吸收量加成。
  - [[spell:374265]]
    
    - 同样也是2点天赋，最多可为你提供4%的额外急速。

- **已移除**
  
  - [[spell:219809]] 
    
    - 这导致在面对坦克受到的大型攻击时，可用的大型防御冷却技能变少了。
  
  
  
  - [[spell:194844]]
  
  
  
  - [[spell:377640]]
    
    - 在失去[[spell:195181]]层数时不再对敌人造成任何被动伤害。
  - [[spell:194679]]
    
    - 这并不是太大的损失，因为这是一个非常冷门的天赋，玩家很少选择。
  - [[spell:221699]]
  - [[spell:343294]]

## 英雄天赋

- 进入 至暗之夜 第二赛季初期，[[talent:123325]] 目前的表现比 [[talent:123326]] 稍好一些，而且操作也更简单，因此本攻略后续内容将假定你使用的是 [[talent:123325]]。

:::tabs
:::tab [[talent:123326]]
- [[spell:439843]]
  
  - 施放此技能会使目标染上[[spell:439843]]，在达到40层后，或该效果 simply 结束后，你会获得一层[[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]。
- [[talent:117631]]
  
  - 这使你可以对生命值低于35%的目标额外施加一层[[talent:96192]]。
- [[spell:440031@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]和[[talent:117655]]
  
  - 使[[spell:50842]]转化为造成冰霜暗影伤害，并使[[spell:55078]]有几率造成额外的冰霜暗影伤害，从而为[[talent:117659]]提供更多层数。
- [[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] + [[spell:443564@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - 有了这个天赋组合，[[talent:117659]]会强化你的下2次[[talent:96303]]施放。
    
    - [[talent:96303]]现在只需消耗1个符文，并召唤两把镰刀，对目标周围的所有敌人造成伤害，施加[[spell:55078]]并对其造成可观的伤害。
    - 此外，它们有30%的几率对目标施加一层新的[[talent:117659]]。
  
  
  
  - [[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]最多叠加到2层，这意味着你需要在新的[[talent:117659]]爆炸之前用掉所有的触发效果。

#### 防御选择节点

- [[talent:117632]] 或 ‍[[talent:123420]]
  
  - ‍[[talent:117632]]并不够强，不值得考虑。[[talent:123420]]极为强大，因为它是基于你所使用技能的被动减伤。
- ‍[[talent:117646]] 或 ‍[[talent:119140]]
  
  - ‍死亡信使在这里是明确的选择，因为‍反斥之盾在PvE内容中，在真正关键的那些施法上并不生效。

在12.0前夕版本中，你将可以使用新的英雄天赋栏，但可用的点数有限。

- [[spell:1265855@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - 施放[[spell:49028]]会额外提供一层[[spell:441378@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]。

:::

:::tab [[talent:123325]]
- [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - [[spell:49998]] 有几率将你的下一个 [[spell:79885]] 变为 [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]。
  
  
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 会为你恢复相当于最大生命值 1% 的生命，并给予你 1 层 [[spell:433925]]。
- [[talent:117645]]
  
  - 当你站在自己的 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 中时，你受到的物理伤害降低 5%，并且 [[spell:433895]] 的触发几率提升至 5%。
- [[talent:117662]]
  
  - 使 [[spell:433925]] 最多可叠加至 2 层，并且每层使你的 [[spell:49998]] 伤害提高 5%。
- [[spell:434157@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - 消耗 [[spell:81141]] 触发效果时会给予你 12% 的力量，持续 12 秒。
- [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - [[talent:96269]] 现在会给予你 [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]，在其持续期间将 [[spell:79885]] 替换为 [[spell:433895]]。
  - [[spell:433925]] 的效果在 [[talent:96269]] 期间也会提高 200%。

#### 防御选择节点

- [[talent:117892]] 或 [[talent:117661]]
  
  - 默认选择，因为它对机动性是个不错的加成；如果你是团队中主要的战复担当，可以换成[[talent:117661]]。
- [[talent:117891]] 或 [[talent:117653]]
  
  - [[talent:117891]]提升‍[[talent:96210]]的效果实在太好，难以放弃，而2%的**吸血**即使对4名盟友来说有时也只能提高到4%，实在不够好。

在12.0前夕版本中，你将可以使用新的英雄天赋栏，但可用的点数有限。

- [[spell:1234559]]
  
  - [[spell:37788]] 现在有机会造成巨大的 范围伤害 爆发伤害，因为它在持续期间会随机引爆。
- [[spell:1265574]]
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 提升你的 [[talent:96269]] 所造成的伤害。

:::

:::

## 天赋

:::tabs
:::tab 大秘境 配装
:::talents **鲜血 死亡骑士** 大秘境 配装
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 何时使用此专精

除非另有说明，这是进入任何 大秘境 时的默认配置。你需要根据地下城所需的实用功能来调整职业天赋树。为了让你更轻松，地下城专属的天赋配置可在地下城章节中查看。

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若需更详细的解析，请查看下方的循环和 **深度解析** 章节。

#### 专精树

- [[spell:458572]]
  
  - 拉近敌人时获得1层 [[spell:195181]]。
- [[spell:219786]]
  
  - 当 [[spell:195181]] 层数高于5层时，你的 [[spell:49998]] 消耗的符文能量更少。
- [[spell:317133]]
  
  - 全面提升你的 [[spell:55233]] 各方面表现。
- [[spell:221536]]
  
  - 这为你的符文能量获取提供了不错的加成。
- [[spell:273946]]
  
  - [[spell:50842]] 会给予你层数来强化你的 [[spell:49998]]。命中的敌人越多，收益越大。
- [[spell:377637]]
  
  - 降低你的 [[spell:49028]] 的冷却时间。
- [[spell:374737]]
  
  - 有了它，你的 [[spell:195181]] 最多可以拥有12层。
- [[spell:205723]]
  
  - 这为你的 [[spell:55233]] 提供了大幅的冷却缩减。
- [[spell:114556]]
  
  - 每4分钟一次的免死效果。

#### 职业树

- [[spell:374277]]
  
  - 非常重要的天赋，能大幅强化你的 [[spell:49998]]。
- [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - 使 ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 能够对更多目标进行顺劈，并延长你的 ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 持续时间。详见深度解析部分。
- [[spell:205727]]
  
  - 降低你的 [[spell:48707]] 的冷却时间并使其更加强力。
- [[spell:194878]]
  
  - 有了它，你需要维持一个新的增益效果。
- [[spell:273952]]
  
  - [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 现在附带强大的减速效果。
- [[spell:391566]]
  
  - 这会降低敌人的攻击速度，差不多相当于你的队伍增益。
- [[spell:356367]]
  
  - 这使你的 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]][[spell:49576]] 和 [[spell:48265]] 额外获得一层充能，让它们更容易使用和合理安排。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** 当你 [[spell:49998]] 时，获得一层 [[spell:1310372]]。当 [[spell:1310372]] 达到10层时，你的下一个 [[spell:195182]] 会消耗它，授予10%力量，持续10秒。
- **4件套：** 在消耗 [[spell:1310372]] 时，你的下一个 [[spell:195182]] 会额外产生3个 [[spell:195181]]，并对你的目标及附近敌人造成 暗影 伤害。

### 起手爆发

- 你开局的目标是确保获得 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 的收益，同时通过 [[spell:49028]] 达到 [[spell:232049]] 的最大层数。此外，你还想尽可能多地获取符文能量，以便随时准备好 [[spell:49998]]。

:::rotation **鲜血 死亡骑士** 开手 大秘境
```json
{
  "source_code": "IgFkKIQApCACQJXZtAVdsxGACwt-CAgACgftAEAnuOAAAAAACR4vAEACIIgmGHgDI4m-CEgDMIkTDDQABwgQn7pBBgAACkgHkcunGAAAAAgQONM"
}
```
1. [[spell:43265]] 开怪前
2. [[spell:195292]]  [[spell:46584]] · [[item:241308]]
3. [[spell:49028]]
4. [[spell:50842]]
5. [[spell:195182]]
6. [[spell:49998]]
7. [[spell:433895]]
8. [[spell:50842]]
9. [[spell:433895]]
10. [[spell:49998]]
:::

- [[spell:195292]] 有飞行时间，应在跑向开怪点的途中施放。

### 优先级列表

这是标准的优先级列表，除非某个首领或场景要求你保留此处列出的某些技能，否则请照此执行。

1. 千万不要让 [[spell:195181]] 掉落！使用 [[spell:195182]] 或 [[spell:195292]] 来保持其激活。
   
   - 维持 5 层以上的 [[spell:195181]] 以充分利用 [[spell:219788]]，如果 [[spell:49028]] 即将到来，低于 5 层也是可以的。
2. 在冷却时施放 [[spell:46585]] 以获得一些额外伤害。
3. 保持你的 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 增益效果，查看深度解析部分以了解更多信息。
4. 冷却时施放 [[spell:49028]]。
5. 当你即将达到符文能量上限或 [[spell:391477]] 即将消失时，将符文能量用于 [[spell:49998]]。
6. 施放 [[spell:433895]] 以获取符文能量。
7. 如果已选择该天赋，在冷却时施放 [[spell:274156]]，并且总是在你的 [[spell:49028]] 结束后施放。
8. 施放 [[spell:50842]] 以避免层数溢出。
9. 施放 [[spell:79885]] 来消耗符文，作为填充技能。

### 防御技能冷却

- [[spell:55233]] 
  
  - 大多数情况下，当你受到任何形式的伤害时，你都应尽可能多地使用吸血 鲜血。只有在需要硬吃一次大额伤害，或者即将迎来Boss的停机阶段导致它无法发挥全部价值时，才有必要扣住不放。
- [[spell:49028]]
  
  - 一般来说，直接卡CD使用即可，除非你在某些特殊情况下需要招架效果，更详细的信息请查看下方的**深度解析**。
- [[spell:48707]]
  
  - 这是对抗魔法伤害最强的防御技能之一。一般来说，它可以在承受魔法伤害时使用，但在很多情况下，扣住它并用来免疫机制才是这个技能的最佳用法。请务必留意后文中关于具体免疫什么以及如何最大化利用[[spell:48707]]的章节。
- [[spell:48792]]
  
  - 这是一个极为出色的通用减伤防御技能，在一场战斗中应尽可能多地使用，除非必要，不要与其他减伤技能重叠覆盖。它也可以被扣住用来免疫眩晕类机制，但这种情况相当少见。
- [[spell:49039]]
  
  - 这是一个极其微弱的防御技能，为你提供10%的吸血，当你只需要一点点帮助时，它是一个不错的按键选择。在范围伤害场景中它会更有价值，因为吸血在范围伤害中非常强力。另外，如果你因为某种原因被恐惧了，赶紧按它！

## 深度解析

### 灵界打击治疗与吸收

[[spell:49998]]正是让你成为**鲜血 死亡骑士**的核心。这个技能是你职业的核心！理解它的运作机制以及如何正确使用它，对于最大化你的伤害、保持生存，以及凭借你惊人的自我续航成为最优秀的坦克来说至关重要。

- [[spell:49998]] 会为你恢复一定百分比最大生命值的治疗，且该治疗量会根据你过去5秒内受到的伤害而提高。这意味着，如果你在过去5秒内没有受到可观伤害，灵界打击 就会成为一个低效的治疗来源。
  
  - 环境伤害和友方误伤不计入所受伤害的计算公式中，它们是自我治疗出问题的主要原因。环境伤害来源很多，例如首领房间的 范围伤害 伤害，以及风暴等词缀伤害。
- 你来自 [[spell:49998]] 的治疗效果会被许多不同的技能和属性所放大：
  
  - 全能 是 [[spell:49998]] 治疗的乘数。
  - [[spell:273953]] 也会提高你的 [[spell:49998]] 治疗量以及你的 [[spell:77513]] 数值。
  - [[spell:273946]] 只会放大你的 [[spell:49998]] 治疗量，但不会提高你的 [[spell:77513]] 的数值。
- [[spell:77513]] 是 [[spell:49998]] 的另一项重要机制：
  
  - [[spell:77513]] 生成的护盾基于完整的治疗数值，其中包含过量治疗。
  - 该吸收效果纯粹是物理性的，对魔法伤害完全无效。
  - 该吸收效果会受到你的 精通 属性数值的提高。
  - [[spell:273953]] 会提高你的治疗量和护盾数值，而 [[spell:273946]] 则不会。
  - [[spell:77513]] 的最大值为你的最大生命值。该上限会随着 [[spell:55233]] 和 [[spell:97462]] 等生命值增益动态更新。

### 灵界打击的管理

既然你已经了解了[[spell:49998]]的运作机制，接下来我们谈谈如何使用它来从中获得最大的伤害和生存能力。

- 就输出伤害而言，当你即将符文能量溢出，或者你可以放心地把全部符文能量用于对目标造成伤害时，就使用 [[spell:49998]]。
- 如果你想正确使用 [[spell:49998]] 来进行治疗或应对特定机制，关键在于良好的操作节奏：
  
  - 在使用 [[spell:49998]] 时要考虑你过去5秒所受的伤害。大多数情况下，你应该在坦克机制之后或承受大量伤害之后再 [[spell:49998]]。这能让你在使用 [[spell:49998]] 之后立刻获得大量治疗和大型吸收护盾。
  - 大多数时候，连续使用2次 [[spell:49998]] 并不明智，因为只使用1次就足以让你回满血并获得大型吸收护盾。某些情况下确实需要连续使用 [[spell:49998]]，但比起精准时机下只使用1次，这种情况要少见得多。
  - 针对魔法伤害精准把握 [[spell:49998]] 的时机非常重要，因为你的 [[spell:77513]] 对这类伤害完全无效。
  - 提前积攒吸收护盾以应对坦克机制可能很有用，但代价往往很高，因为如果你没有承受足够的伤害来供给 [[spell:49998]] 治疗，生成大型护盾需要很长时间。

掌握所有这些信息后，你就能够完全理解并将 [[spell:49998]] 发挥到极致了。请始终牢记，坦克并不是按照固定的循环或僵硬的技能流程来运作的，良好的游戏节奏和正确的 [[spell:49998]] 使用需要靠经验与练习来积累。

### 枯萎凋零 优化

- 自至暗之夜12.0补丁以来，对[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]保持高覆盖率对你来说已不像以前那么重要了，它仍然会提升你的伤害和治疗效果，因为 **鲜血 死亡骑士** 因为[[spell:391458]]，并通过[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]为你提供额外收益。

- 核心思路是：只要[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]未激活且已冷却完毕，就始终使用它。[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]为你的[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]提供大量额外持续时间以及诸多便利收益。
- 以下是[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]提供的优势：
  
  - 你走出[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]后，其收益会保留4秒。
  - [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]的持续时间耗尽后，随后会出现这个增益。
  - 无论[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]的持续时间如何，进出[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]都会刷新该增益。

- 由于 [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 会为 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 额外提供 4 秒的持续时间，因此即使没有 [[spell:356367]]，维持该效果的循环也极为顺畅。
  
  - 在没有 [[spell:356367]] 的情况下，平均覆盖率约为 93%，这已经非常出色了。
  - 而有了 [[spell:356367]]，只要操作得当，你永远不会失去 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 增益。

- 这里展示了[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]与[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]良好配合的时间线示例。只需在冷却好了就施放即可。

:::timeline **鲜血 死亡骑士** 枯萎凋零 大秘境
```json
{
  "source_code": "H4FT2Z3_8AQIEww_eAAAOAAD_7xDA0RAHggHAwSAHgSLAsDAEIQApCAAAEgBA8QBGAgHFYAKtAABCRf1EAAAZAQCIAgCNgAKoAgQ0XNBAAwNAEA"
}
```
总时长：60 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:43265]] | 上轨 |
| 10 秒 | [[spell:316916]] | 下轨 |
| 15 秒 | [[spell:43265]] | 上轨 |
| 25 秒 | [[spell:316916]] | 下轨 |
| 30 秒 | [[spell:43265]] | 上轨 |
| 40 秒 | [[spell:316916]] | 下轨 |
| 45 秒 | [[spell:43265]] | 上轨 |
| 55 秒 | [[spell:316916]] | 下轨 |
:::

### 符文刃舞

[[spell:49028]] 是 **鲜血 死亡骑士** 武器库中最重要的技能之一，有很多乍看之下并不明显的地方！

无论是在输出还是在防御价值方面，它对该职业的玩法都至关重要，以下是关于该技能你应当了解的关键特性。

- 该武器基本上算作一个不可被选为目标的“守护者”，并且始终跟随你使用该技能的目标。这意味着当该目标死亡后，它会跟随你并攻击你当前的目标。
- [[spell:49028]] 会在目标身后生成，因此在对远处的目标使用时可能会引到更多敌人。
- 你召唤的每把武器都会复制某些法术并给予你其收益，下面我们来逐一介绍：
  
  - [[spell:195182]] 使你获得 9 层 [[spell:195181]]（每把武器 3 层）。
  - [[spell:195292]] 使你获得 6 层 [[spell:195181]]（每把武器 2 层）。
  - [[spell:79885]] 使你获得 15 符文能量而非 5 点（每把武器都会施放 [[spell:79885]]，各产生 5 符文能量）。
  - [[spell:50842]] 现在会施加 3 个独立的 [[spell:55078]] 减益效果（每把额外武器各施加 1 个），生命值转移量不会增加，你仍然只能从自己的 [[spell:55078]] 中获益。
    
    - 由 [[spell:195292]] 施加的 [[spell:55078]] 同理。
  - [[spell:49998]]造成更多伤害，因为该技能被武器复制了，但治疗效果不会提高。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

**← 滚动查看更多首领 →**

:::tabs
:::tab 毒牙祭坛
:::talents **鲜血 死亡骑士** 大秘境 毒牙祭坛
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 首领攻略技巧

#### 拉维

- 房间中散布着3个腐肉堆，确保在boss能量降到0%之前将他拉到其中一个没有发红光的腐肉堆旁，以便他[[spell:1296216]]在其中。
- 在[[spell:1296216]]期间，注意地面上的[[spell:1307703]]，如有需要请进行吸收。

#### 扭缠盘蛇

- boss会对你施放[[spell:1298949]]，造成物理伤害并将你轻微击退。
- 打断[[spell:1310358]]。
- 在[[spell:1299053]]期间，尽可能快且远地远离boss。

#### 祖尔加

- 每当boss施放[[spell:1300872]]时，务必站在他与[[spell:1300894]]之间进行吸收。
- 躲避[[spell:1283832]]所产生的任何斧头。
- [[spell:1301350]]是一个0.5秒的快速施法，造成物理伤害，是本场战斗的坦克重击技能。
- 当队友被[[spell:1301413]]锁定时，移动到boss与被锁定玩家之间的直线上，这会减少你的队友所受到的伤害。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1294557]] - 原始毒蛇
  - [[spell:1307567]] - 乌拉特克神选者

- 额外注意这些施法：
  
  - [[spell:1306911]] - 仪式首领
  - [[spell:1294845]] - 振响的扭缠蛇
  - [[spell:1294934]] - 晋升之蛇

:::

:::tab 纳洛拉克的洞穴
:::talents **鲜血 死亡骑士** 大秘境 纳洛拉克的洞穴
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 首领攻略技巧

#### 囤宝狂人

- 每当boss施放[[spell:1234233]]时，他会在地面上召唤[[spell:1234740]]，务必帮助你的队伍进行吸收。

#### 寒冬哨卫

- 在boss施放[[spell:1235783]]之后，将他拉到一个被召唤的小怪身上，并打断[[spell:1235829]]。

#### 纳洛拉克

- 当首领开始施放 [[spell:1243569]] 时，确保你站在 祖尔加拉 提供的 [[spell:1243856]] 中。施法结束后，首领会立即接一个 [[spell:1297797]]，在他面前生成一个大圈。作为坦克，走进圈中吸收这一击。
- 在 [[spell:1243002]] 期间，跑向任何试图接近 祖尔加拉 的 纳洛拉克的回响，用你的角色触碰它以阻止其靠近她。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1297696]] - 地语看护者
  - [[spell:1309919]] - 酷寒重殴者
  - [[spell:263607]] - 雷缚秘法师
  - [[spell:9532]] - 神灵代言人纳尼亚

- 请格外注意以下施法：
  
  - [[spell:1238687]] - 饥渴之灵

:::

:::tab 密谋小径
:::talents **鲜血 死亡骑士** 大秘境 密谋小径
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 首领攻略技巧

#### 凯斯媞亚·魔力之心

- 咬咬 会对施放正面锥形 [[spell:1253811]]，确保不要把它对准你的小队，施法结束前你也可以跑到侧面躲开。
- 凯丝提亚偶尔会召唤多个 [[spell:1264095]]，它们会施放 [[spell:1264106]]，你可以通过打断或眩晕来取消其施法。

#### 赞恩·刃悲

- 首领会对你施放 [[spell:1222795]]，造成物理伤害并在你身上留下一个持续伤害 [[spell:474515]]。
- 当你被 [[spell:474545]] 点名时，尝试躲在房间里的木桶后面。

#### 歼灭者萨祖克斯

- [[spell:1214781]] 是这场战斗中主要的坦克重击机制，它是一个正面锥形技能，不要把它对准你的小队，它会给你留下一层使你受到的治疗效果降低80%、持续8秒的减益。
- 在 [[spell:1214637]] 之后，尽量在首领的斧头附近拉住他。
- 在 [[spell:1223533]] 期间，尽量沿着房间边缘风筝他，以减少 [[spell:474231]] 的扩散。

#### 利希尔·烬怒

- 首领将使用[[spell:1220899]]，你需要在这场战斗的全程中风筝这只地狱火。
- 尽可能打断[[spell:474375]]。
- 每当[[spell:474408]]出现时，就要抓住它的仇恨。
- 当首领召唤[[spell:1214675]]时，等待它完成[[spell:1217345]]的施法后再进入传送门。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1216570]] - 凶邪的法师
  - [[spell:1201554]] - 诱惑的萨亚德
  - [[spell:1214922]] - 愤怒卫士掠夺者
  - [[spell:1214980]] - 邪能祈求者

- 请格外注意以下施法：
  
  - [[spell:1216529]] - 受贿的队长

:::

:::tab 夺目谷
:::talents **鲜血 死亡骑士** 大秘境 夺目谷
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

#### 光明众花

- 务必对所有三个首领保持仇恨，并尽可能将它们拉在一起，以便进行顺劈输出并提高伤害效率，因为它们共享同一个生命值池。
- 梅提克 会对你施放 [[spell:1234753]]，这是战斗中坦克伤害的主要来源。
- 科兹齐特 会施放 [[spell:1235616]]，尽可能打断它。
- 科兹齐特 还会施放 [[spell:1235564]]，你需要站在三朵光蕾之一中来分摊伤害。

#### 圣光猎手伊库兹

- 每次首领施放 [[spell:1236746]] 时，务必确保自己不被击退到地上的任何树根中。如果你被击退远离团队，请尽快归位，因为该技能发生 4 秒后所有人都会被定身。你需要与团队集合在一起，以便尽快顺劈清理树根。

#### 护光者鲁伊亚

- 这个首领有3个不同的阶段，它总是以枭兽阶段开始。
- 在这个阶段你只需要打断[[spell:1239821]]并躲避由[[spell:1239824]]创造的[[spell:1239830]]。
- 在下一阶段，熊形态 由于 [[spell:1272265]]，他的近战攻击变得更加危险。此外，如果你被 [[spell:1240210]] 选为目标，请确保不要过多移动，这样你和你的队友会更容易躲避。
- 最后一个阶段在40%时开始，此时首领进入哈拉尼尔形态并引导[[spell:1241067]]，快速连发施放它的所有技能。

#### 兹欧凯特

- 每次首领施放 [[spell:1246372]] 时，它会在自己脚下召唤小怪，务必尽快拉住这些小怪的仇恨。
- [[spell:1246858]] 之后会有法球飞向首领，去吸收这些法球，不要让任何一颗碰到首领。
- 此外，首领在战斗中还会使用 [[spell:1247685]] 作为坦克重击技能，造成魔法伤害，将你击退，并给你留下一个流血效果，每秒造成物理伤害，持续 10 秒。
- 当小怪死亡后，你需要调整首领的站位，使其用以你为目标的 [[spell:1246607]] 技能命中所有小怪。当小怪被命中时，它们会被彻底移出战斗；如果没有被命中，下次首领施放 [[spell:1246372]] 时，它们会与新召唤的小怪一起复活。

### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:1301834]] - 光耀播法者
  - [[spell:1238294]] - 光羽瓣翼鸟

- 请格外注意以下施法：
  
  - [[spell:1237855]] - 翠绿林地守护者

:::

:::tab 虚空之痕竞技场
:::talents **鲜血 死亡骑士** 大秘境 虚空之痕竞技场
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 首领攻略技巧

#### 塔兹拉尔

- 每当首领施放 [[spell:1296889]] 时，务必确保你的 [[spell:1222098]] 不要与其他人的重叠。
- 它还会对你施放 [[spell:1297017]]，造成大量魔法伤害并将你击退。
- 每次 [[spell:1300259]] 之后，务必躲避法球。

#### 阿特洛苏斯

- [[spell:1222642]]是这场战斗中的坦克重击机制，它造成魔法伤害，并留下一个持续10秒的减益效果，使你受到更多魔法伤害。
- 每当首领施放[[spell:1262497]]时，它会召唤一个剧毒蠕行者，它会锁定你，尽量将这个剧毒蠕行者与首领一起风筝，以最大化顺劈输出。

#### 煞戎努斯

- 首领会对着你施放 [[spell:1311923]]，这是一个持续5秒的施法，此时尽量不要过多移动，以便队友能够躲避。
- 偶尔首领会用 [[spell:1222755]] 点名你的一名队友。作为坦克，你的职责是站在首领与被点名玩家之间，在弹射物到达队友之前将其拦截。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1299938]] - 虚触法师
  - [[spell:1298899]] - 被统御的斗士
  - [[spell:1249621]] - 暴怒的三叶虫
  - [[spell:1233398]] - 千噬兽尖啸者

- 请格外注意这些施法：
  
  - [[spell:1300243]] - 贪噬残虐者

:::

:::tab 诸王之眠
:::talents **鲜血 死亡骑士** 大秘境诸王之眠
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 首领攻略技巧

#### 塔兹拉尔

- 每当首领施放 [[spell:1296889]] 时，务必确保你的 [[spell:1222098]] 不要与其他人的重叠。
- 它还会对你施放 [[spell:1297017]]，造成大量魔法伤害并将你击退。
- 每次 [[spell:1300259]] 之后，务必躲避法球。

#### 阿特洛苏斯

- [[spell:1222642]]是这场战斗中的坦克重击机制，它造成魔法伤害，并留下一个持续10秒的减益效果，使你受到更多魔法伤害。
- 每当首领施放[[spell:1262497]]时，它会召唤一个剧毒蠕行者，它会锁定你，尽量将这个剧毒蠕行者与首领一起风筝，以最大化顺劈输出。

#### 煞戎努斯

- 首领会对着你施放 [[spell:1311923]]，这是一个持续5秒的施法，此时尽量不要过多移动，以便队友能够躲避。
- 偶尔首领会用 [[spell:1222755]] 点名你的一名队友。作为坦克，你的职责是站在首领与被点名玩家之间，在弹射物到达队友之前将其拦截。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1299938]] - 虚触法师
  - [[spell:1298899]] - 被统御的斗士
  - [[spell:1249621]] - 暴怒的三叶虫
  - [[spell:1233398]] - 千噬兽尖啸者

- 请格外注意这些施法：
  
  - [[spell:1300243]] - 贪噬残虐者

:::

:::tab 红玉新生法池
:::talents **鲜血 死亡骑士** 大秘境 红玉新生法池
```json
{
  "source_code": "CqPAc9ixpxn-sbPhxb6yjRDs6wMzyMzwMmxgZbmZmmZzMzMzMmBAAAAGMzMzMjZmZMAYmZmZGAAAzMbjhxMWWasstMMZbYYBwMGAAMzAAGA",
  "code": "CqPAc9ixpxn+sbPhxb6yjRDs6wMzyMzwMmxgZbmZmmZzMzMzMmBAAAAGMzMzMjZmZMAYmZmZGAAAzMbjhxMWWasstMMZbYYBwMGAAMzAAGA"
}
```
:::

### 首领攻略技巧

#### 梅莉杜莎·寒妆

- 首领会对着你施放[[spell:372808]]，这是一个可打断的施法，因此务必在冷却时就打断它；如果你或队友无法打断，请开启减伤技能。
- 首领偶尔还会施放[[spell:396044]]，施法结束后，将首领带离地面上的圆圈。
- 当首领生命值降至66%和33%时会施放[[spell:373037]]，务必拉住刷新的小怪的仇恨。

#### 柯姬雅·焰蹄

- 该首领的主要坦克机制是[[spell:372858]]，这是一个持续3秒的施法。
- 务必始终将首领拉在[[spell:372863]]所产生的炎缚火焰风暴旁边进行坦克。

#### 基拉卡与厄克哈特·风脉

- 首领会通过[[spell:381512]]对你施加一个负面效果，使你受到的下一次[[spell:381512]]伤害提高，因此请提前与你的治疗沟通好，每次你被此机制命中时他都必须为你驱散。
- 每当巨龙基拉卡落地后，请离开[[spell:381525]]。

### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:372743]] - 闪霜织寒者
  - [[spell:384197]] - 拜荒织烬者
  - [[spell:392576]] - 暴风引导者

- 需要格外注意以下施法：
  
  - [[spell:372730]] - 原始主宰
  - [[spell:372047]] - 亵渎者德拉加尔
  - [[spell:392394]] - 烈焰之咽
  - [[spell:392395]] - 雷霆之颅

:::

:::tab 塞塔里斯神庙
:::talents **鲜血 死亡骑士** 大秘境 塞塔里斯神庙
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### 首领攻略技巧

#### 阿德里斯和阿斯匹克斯

- 每当阿斯匹克斯施放[[spell:1310712]]时，确保不要与队友站在一起。
- 阿德里斯会用[[spell:1288049]]聚焦你的一名队友，尽量帮忙分担这个技能，以分摊伤害并减轻对被点名队友的整体影响。
- 它还会施放[[spell:1288428]]，使其在8秒内造成更多近战伤害，如有必要请使用你的防御技能。

#### 米利克萨

- 首领会周期性地施放[[spell:1290797]]，这是一个坦克重击技能，命中时造成物理伤害，并留下一个持续7秒、每秒跳一次自然伤害的持续伤害效果。
- 在[[spell:264206]]期间，务必迅速对所有被召唤的小怪建立仇恨。

#### 加瓦兹特

- 在这场战斗中，你唯一要做的就是每次[[spell:1309525]]施放后移动首领的位置，因为它会在首领脚下召唤一个[[spell:1291815]]。

#### 塞塔里斯的化身

- 务必抢到堕落守护者的仇恨，它们偶尔会对你施放[[spell:1300803]]。此外，你也可以把它拉到精华污染者上面。

### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:1293307]] - 无信征服者
  - [[spell:9532]] - 灌注能量的唤雷者
  - [[spell:13729]] - 扭曲的妖术师

- 请格外注意以下施法：
  
  - [[spell:1291468]] - 沙怒石拳战士
  - [[spell:1308546]] - 宝珠守望者

:::

:::

### 词缀

词缀系统在进入地心之战第一赛季时进行了重做，退役了大部分词缀，同时引入了新的有利有弊型词缀，并更改了这些词缀出现的钥石等级。

- +2词缀
  
  - 林多尔米的指引
- +5 词缀——每周轮换
  
  - 萨拉塔斯的交易：升腾
  - 萨拉塔斯的交易：虚空之缚
  
  
  
  - 萨拉塔斯的交易：吞噬
  - 萨拉塔斯的交易：脉冲星
- +6词缀
  
  - 移除林多尔米的指引。
- +7 词缀——每周交替出现
  
  - 残暴
  - 强韧
- +10 词缀 *——两个词缀同时存在。*
  
  - 残暴
  - 强韧
- +12词缀
  
  - 萨拉塔斯的诡计 *——替换+5词缀*

以下是作为**应对不同大秘境词缀鲜血 死亡骑士**的一些实用技巧。

- 萨拉塔斯的交易：升腾
  
  - [[spell:207167]] 尽可能多的法球。
- 萨拉塔斯的交易：虚空契约
  
  - **虚空大使**会跟随你，让它紧贴队伍，并在其存在时优先以它为目标。
- 萨拉塔斯的交易：吞噬
  
  - 这是一种可以被驱散的治疗吸收效果，你会被动地处理它。

## 属性优先级

了解你的副属性优先级，以及在地下城中作为**鲜血 死亡骑士**发挥最佳表现所需的第三属性。想要了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **鲜血 死亡骑士** 大秘境属性
```json
{
  "source_code": "IoAJFQAJoASMBIQACA"
}
```
**力量 ＞ 急速 ＝ 全能 ＞ 暴击 ＝ 精通**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 能够有效降低"**范围伤害**"技能所造成的伤害的优秀属性。
- **吸血** - 通过造成伤害来提供额外治疗。
- **加速** - 一种小众的第三属性，但在某些情况下非常有用，过去也曾被证明其实用价值。它能让应对某些机制变得轻松许多。

总体而言，**吸血**对坦克来说非常强力，尤其是在范围伤害环境中，它可能是你所能拥有的最好属性。  
**闪避**很好用，但大多数时候坦克并不难在典型的范围伤害技能下存活。

## 装备

:::tabs
:::tab 总体最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271474@DiQAAoPAvj74PrTOC4UA]] | 双子毒牙 |
| 颈部 | [[item:268265@BERAAoPAX164PrTOCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271472@DgQAAoPA1k7kjAOF]] | 迷失的探险者 |
| 披风 | [[item:239656@FgQAAoPAVA8Yiqzt1sUA]] | 制造业 |
| 胸部 | [[item:268222@DgQAAoPAJk7kjAYF]] | 盘卷祭坛 |
| 腕部 | [[item:237834@FCRAAoPAVA8Yiqj_sOAAwt1sUA]] | 制造业 |
| 手套 | [[item:271475@BgQAAoPA5IgTBA]] | 陵寝哨兵 |
| 腰带 | [[item:268259@BiQAAoPA-z6kjAYF]] | 盘卷祭坛 |
| 腿部 | 将 [[item:271878@BARAAoPACKgF2gVA]]  <br> 转化为 [[item:271473@DARBAoPAhu7kjAWYDWBYgJE]] | 乌拉特克的催化剂 |
| 脚部 | [[item:273777@DgQAAoPAPk7IoAOF]] | 毒牙祭坛 |
| 戒指 1 | [[item:159459@DiQAAoPAvk74PrjgC4UA]] | 诸王之眠 |
| 戒指 2 | [[item:252258@DiQAAoPAvk74PrjgC4UA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:270175@BgQAAoPA5IAWBA]] | 乌拉特克 |
| 饰品 2 | [[item:270165@BgQAAoPA5IgTBA]] | 被埋葬的哨兵 |
| 武器 | [[item:268213@RgQAAoPAVyPB5IAWBA]] | 盘卷祭坛 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:239050@BgQAAoPACKQQBA]] | 诸王之眠 |
| 颈部 | [[item:251173@BgQAAoPACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:239037@BgQAAoPACKQQBA]] | 塞塔里斯神庙 |
| 披风 | [[item:193763@BgQAAoPACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251193@BgQAAoPACKQQBA]] | 夺目谷 |
| 护腕 | [[item:159425@BgQAAoPACKQQBA]] | 塞塔里斯神庙 |
| 手套 | [[item:251221@BgQAAoPACKQQBA]] | 虚空之痕竞技场 |
| 腰带 | [[item:159418@BgQAAoPACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:159435@BgQAAoPACKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:273777@BgQAAoPACKQQBA]] | 毒牙祭坛 |
| 戒指 1 | [[item:159459@BgQAAoPACKQQBA]] | 诸王之眠 |
| 戒指 2 | [[item:251148@BgQAAoPACKQQBA]] | 纳洛拉克的洞穴 |
| 饰品 1 | [[item:250244@BgQAAoPACKQQBA]] | 纳洛拉克的洞穴 |
| 饰品 2 | [[item:250228@BgQAAoPACKQQBA]] | 密谋小径 |
| 武器 | [[item:251181@BgQAAoPACKQQBA]] | 夺目谷 |

:::

:::

### 饰品

以下是从地下城、团队副本和地下堡可获得的毕业饰品排名。请注意，根据大秘境地下城的不同，某些饰品会优于其他饰品。此外，为输出专精设计的饰品会被削弱33%，但依然能提供比坦克专属饰品更高的伤害。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgQAAoPA5IAWBA]]  <br>[[item:270165@BgQAAoPA5IgTBA]] |
| **A级** | [[item:270160@BgQAAoPACKgTBA]]  <br>[[item:270164@BgQAAoPACKgTBA]]  <br>[[item:270173@BgQAAoPACKAWBA]]  <br>[[item:270174@BgQAAoPACKgTBA]] |
| **B级** | [[item:270163@BgQAAoPACKgTBA]]  <br>[[item:273795@BgQAAoPACKgTBA]]  <br>[[item:250243@BgQAAoPACKgTBA]]  <br>[[item:250244@BgQAAoPACKgTBA]]  <br>[[item:250228@BgQAAoPACKgTBA]]  <br>[[item:193762@BgQAAoPACKgTBA]] |
| **C级** | [[item:273796@BgQAAoPACKgTBA]]  <br>[[item:159618@BgQAAoPACKgTBA]]  <br>[[item:250229@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:193757@BgQAAoPACKgTBA]]  <br>[[item:273797@BgQAAoPACKgTBA]] |
| **垃圾级** | [[item:250238@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:158367@BgQAAoPACKgTBA]]  <br>[[item:270168@BgQAAoPACKAWBA]] |

### 美化饰品

- 在披风、护腕、腰带或靴子任选其一打上2个 [[item:240166@BAAAAoP]]。
  
  - 不错的被动主属性增益。

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - [[item:241324@BAAAAoP]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884@BAAAAoP]]
- **武器磨刀石**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240983]] *-- 唯一，只能使用一次。*
  - [[item:240894@BAAAAoP]]
  - [[item:240916@BAAAAoP]]

### 附魔

:::columns
:::column
| 头部 | [[item:243949@DAAAAwQAZbAB]]  <br>[[item:275707@BAAAAoP]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 护腕 | [[item:275707@BAAAAoP]] |
| 腰带 | [[item:275707@BAAAAoP]] |
| 腿部 | [[item:244641@BAAAAwQA]] |
| 靴子 | [[item:243983@BAAAAwQA]] |
| 戒指 1 | [[item:244017@BAAAAwQA]] |
| 戒指 2 | [[item:244017@BAAAAwQA]] |
| 武器 | [[spell:326801]] |

:::

:::column
:::gear **鲜血 死亡骑士** 大秘境
```json
{
  "source_code": "IQFZ6DQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAx0AEoETuDAAAAAgQRyPB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244017]] |  |
| 戒指二 | [[item:244017]] |  |
| 主手 | [[spell:326801]] |  |
:::

:::

:::

> *你可以从宏伟宝库商人处购买 ‍[[item:275707@DAAAAoPAvj7A]]，为你的头盔、护腕和腰带添加宝石插槽。*

## 种族

为了在 **鲜血 死亡骑士**在大秘境地下城中追求极致优化（min-max），不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:65116]] -- 矮人
  
  - 非常有价值，因为你可以驱散自己或移除危险的流血效果。
  - 此外，使用石像形态会给你10%的物理减伤，在坦怪时可以作为一个8秒的小型额外减伤技能。
  - 使用场景示例：
    
    - **基拉卡与厄克哈特·风脉（红玉新生法池）- [[spell:381512]]**
    - **赞恩·刃悲（密谋小径）- [[spell:1222795]]**
    - **兹欧凯特（夺目谷）- [[spell:1247685]]**
- [[spell:58984]] -- 暗夜精灵
  
  - 在大秘境中做任何类型的跳怪时都非常有用
  - 从几乎任何小怪旁边跑过，然后施放[[spell:58984]]让它们重置。即使在[[spell:58984]]之前拉开足够距离，对拥有潜行侦测的小怪也有效
- [[spell:69070]] -- 地精
  
  - 朝角色面向的方向做一个小跳跃。
  - 在[[spell:69070]]动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:25046]] -- 鲜血精灵
  
  - 强大的种族技能，可以驱散或净化敌人，价值非常有限但有时能派上用场。
- [[spell:256948]] -- 虚空精灵
  
  - 向面向的方向放出一道虚空裂隙，再次激活即可传送到裂隙处。
  - 最大距离100码。

### 推荐

作为一名坦克，为了伤害而选择种族只是很小的收益，大多数情况下并不值得。如果你在意将 DPS 优化到极致，那就选择 DPS 最高的种族特性。

话虽如此，大秘境的推荐种族是**暗夜精灵**或**矮人**两者都提供独特的功能：一个是更具战术性的暗夜精灵跳怪，另一个则在生存能力方面更加可靠。

## 宏

了解**鲜血 死亡骑士**为大秘境推荐的宏，并观看一段关于为你的角色创建简单宏的快速视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
嘲讽宏 --- *这个宏会对你的当前目标或鼠标悬停目标施放[[spell:56222]]*（在拉起小怪时非常方便）

```wow-macro
#showtooltip 黑暗命令
/cast [@mouseover,exists,harm][@target,exists,harm] 黑暗命令
```

1号首领嘲讽宏 --- *对1号首领施放* [[spell:56222]]

```wow-macro
/cast [@boss1] 黑暗命令
```

2号首领嘲讽宏 --- *对2号首领施放* [[spell:56222]]

```wow-macro
/cast [@boss2] 黑暗命令
```

:::

:::details 鼠标指向宏
寒冰锁链 --- *此宏会对你的当前目标或鼠标悬停目标施放 [[spell:45524]]*

```wow-macro
#showtooltip 寒冰锁链
/cast [@mouseover,exists,harm][@target,exists,harm] 寒冰锁链
```

鼠标悬停死亡之握 --- *对你的鼠标悬停目标施放 [[spell:49576]]*

```wow-macro
#showtooltip
/use [@mouseover] 死亡之握
```

鼠标悬停焦点 --- *此宏会将你的鼠标悬停目标设为焦点*

```wow-macro
/focus [@mouseover]
```

鼠标悬停战斗复活 --- *此宏使你可以通过鼠标悬停团队框架来使用 [[spell:61999]]*

```wow-macro
#showtooltip 复活盟友
/cast [@mouseover,help,dead][]复活盟友
```

:::

:::details 焦点目标宏
焦点死亡之握 --- *对你的焦点目标施放 [[spell:49576]]*

```wow-macro
#showtooltip
/use [@focus] 死亡之握
```

焦点打断 --- *对你的焦点目标施放 [[spell:47528]]*

```wow-macro
#showtooltip 心灵冰冻
/cast [@focus,harm,nodead][] 心灵冰冻
```

鼠标指向焦点 --- *此宏会将你的鼠标指向目标设置为焦点*。

```wow-macro
/focus [@mouseover]
```

:::

:::details 实用宏
反魔法领域宏 --- *在光标位置施放 [[spell:222791]]*

```wow-macro
/cast [@cursor] 反魔法领域
```

死亡凋零宏 --- *在你的角色脚下施放 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]*

```wow-macro
/cast [@player] 枯萎凋零
```

群体绞杀宏 --- *此宏会将 [[spell:108199]]* 施放在你的鼠标指向目标或角色位置

```wow-macro
#showtooltip 血魔之握
/cast [@mouseover,exists,nodead][@player] 血魔之握
```

控制亡灵 *--- 这使你无需选中宠物即可再次施放控制亡灵。*

```wow-macro
/target pet
/run PetDismiss()
/use 控制亡灵
/petassist
```

取消保护之手的取消光环宏 --- *这条宏会取消你身上的[[spell:1022]]，与圣骑士组队时非常有用*

```wow-macro
/cancelaura 保护祝福
```

:::

:::

## 插件

下面你可以看到作者的 **鲜血 死亡骑士** 的用户界面截图，其中说明了使用了哪些插件，以及如何在 大秘境 中利用它们来让你更轻松。

![](<https://assets-ng.maxroll.gg/wordpress/Death-Knight-M-Interface-1024x606.png>)

**鲜血 死亡骑士** 大秘境界面

:::accordion
:::details 插件
- **ElvUI *-- 完整的界面替换插件*** 
  
  - 一款以用户友好为核心设计的界面插件，附带标准界面所没有的额外功能。
  - 你也可以选择使用 Shadowed Unit Frames (SUF) 加上任意一款动作条插件，当然也可以使用原生界面。
- **LittleWigs *-- 通用首领模块*** 
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件专为特定团队副本战斗触发警报信息、计时条、音效等而设计。
- **Plater** -- 高级姓名板插件
  
  - Plater 是一款设置选项极其丰富的姓名板插件，开箱即用地支持减益效果监控、仇恨染色以及大量自定义选项。
- **Details** -- 深度伤害统计插件
  
  - 让你的伤害统计界面更好看。
- **MPlusTimer** -- 以前是一个 Weakaura，现在是一个美化大秘境计时的插件
  
  - 让你的大秘境计时更加紧凑，并以更清晰的方式展示信息。
  - 你也可以使用名字几乎完全相同的插件 "MythicPlusTimer"，纯粹看个人喜好。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
死亡骑士

- 英雄天赋
  
  - 萨莱因
    
    - 鲜血 野兽自动攻击伤害提高1400%。
    - 血染之地现在使受到的物理伤害降低8%（原为5%）。
- 鲜血
  
  - 顶尖天赋：至暗之夜之舞（等级2）已更新——每个激活的符文刃舞使受到的伤害降低6%（原为4%）。
  - 近战伤害提高20%。
  - 心脏打击伤害提高25%。
  - 精髓分裂伤害提高50%。
  - 符文刃舞现在使招架提高30%（原为25%）。
  - 永久冻结提供的护盾相当于造成伤害的50%（原为40%）。
  - 饮血提供15%的吸血（原为12%）。
  - 品味鲜血的治疗效果提高25%。
  - 迅速分解使血之疫病的治疗效果提高85%（原为50%）。
  - 血腥爆裂为你恢复相当于造成伤害18%的生命值（原为15%）。
  - 永恒脐带吸收的伤害相当于血之疫病所造成伤害的6倍（原为5倍）。
  - 黑锋军团的坚忍现在在消耗赤色天灾时使受到的伤害降低4%。持续时间延长至10秒（原为6秒）。
  - 血丝现在还使鲜血护盾激活期间受到的伤害降低4%。
  - 英雄天赋
    
    - 死亡使者
      
      - 死神印记对主要目标的伤害提高20%。
      - 破灭对主要目标的伤害提高20%。
    - 萨莱因
      
      - 萨莱因契约现在储存所有暗影伤害的15%（原为10%）。
      - 吸血鬼打击伤害提高25%。
      - 脏腑之力现在提供10%的力量（原为12%）。
      - 疯狂嗜血的灵界打击和死亡缠绕伤害加成降低至每层5%（原为6%）。
      - 鲜血即生命现在累积鲜血野兽所造成伤害的15%（原为25%）。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我总是死亡？
答：你没有正确使用 [[spell:49998]]，或者减伤技能按得不够多。请务必阅读 **深度解析** 以了解更多信息！

:::

:::

---

### 致谢

作者：**Skövte**

审校：**Tief**

---

:::changelog 更新记录
**2026-08-11** 已更新至12.1版本

**2026-06-16** 已更新至12.0.7版本

**2026-04-21** 已更新至12.0.5版本

**2026-02-26** 已更新至12.0.1版本

**2026-01-20** 已更新至至暗之夜 12.0

**2025-12-02** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-08-05** 已更新至11.2版本



:::
