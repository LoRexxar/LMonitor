Welcome to the **Survival Hunter** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 2/5 · Weak

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear Survival Hunter Mythic+ Best in Slot
```json
{
  "source_code": "JYpAw_2_Ac__AEAhkQggIEAANk7AX16ACKgTBEQ6XQAAREAA8z6A8z6ACKAj1gVABIIJEIACFAwF5OggCgVAHfBBBcIJEIAEFAQC5OggCwYNYFABmQQAlt7AECSAAciqDgBwDwPrDAAAAAAAAcbNLFQADSCBBEEBhubBBBTzXQQAJfBBCgQAA8QuJYHAoZGPAgRhkQAAIUAAB0JGVHnABIW2DEgsEUPuJAKEOFQAA2SBE3hEI91HEAACDAggCgVAFAQA2chABQVASAQAFUEEB09FEAQBMgEWBEwtXQgAQEAAFk7ACKgF2gVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271492]] | [[item:240983]] · [[item:243981]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271490]] | [[item:243991]] |
| 胸部 | [[item:271495]] | [[item:243977]] |
| 腰部 | [[item:244581]] | [[item:240892]] · [[item:240167]] · [[item:245784]] |
| 腿部 | [[item:271491]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240892]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271493]] |  |
| 戒指一 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:243973]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Survival Hunter**, you have access to Raptor Swipe, which grants [[spell:186270]] a 25% chance to become [[spell:1259003]].

**Rank 2** increases the damage of [[spell:186270]], [[spell:259495]] and [[spell:1259003]] while also making it do more damage to your main target. **Rank 3** enables every second [[spell:186270]] to become a [[spell:1259003]]. Every [[spell:1259003]] you cast while affected by [[spell:260285]] will also trigger an additional [[spell:1251717]] at 300% effectiveness.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-survival-mxr.webp>)

Raptor Swipe

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:135514@AJwACA]]
    
    - New damage cooldown, which makes you and your pet do 20% more damage for 8 seconds. Replacement for [[spell:360952]].
  - [[talent:135515]]
    
    - New short cooldown, which makes you do AoE damage in a frontal cone. Replacement for [[spell:203415]].
  - [[talent:126311]]
    
    - Makes your [[talent:126324]] stronger. When talented into [[talent:135508]] casting [[talent:126324]] has a chance to increase their cooldown recovery rate.
- **Class Tree**
  
  - [[talent:136686]] choice node with [[talent:136685]]
    
    - New capstone talents that let you either gain more passive damage reduction for yourself or an external, which you can also use on your allies.
  - [[talent:136670]]
    
    - Previously only a [[talent:123350]] talent, now made available to both hero talents. Makes your [[talent:135711]] pull back enemies which it stuns.
- **Removed**
  
  - [[spell:459868]], [[spell:268501]] and [[spell:1217429]]
    
    - Losing DoTs greatly reduces [[talent:135497]] value.
  - [[spell:462031]], [[spell:191433]], [[spell:186387]]
    
    - Removal of all knock effects makes Survival Hunter's utility worse, especially in Mythic+ dungeons.
  - [[spell:212431]], [[spell:320976]], [[spell:212436]], [[spell:269751]]
    
    - Due to the pruning of abilities rotation is a lot simpler and doesn't vary as much between Single Target and AoE.

## Hero Talents

- Your hero talents are [[talent:123349]] and [[talent:123350]]. Neither of the hero talents drastically change your rotation.
- Currently the recommended hero talent is [[talent:123349]].

:::tabs
:::tab [[talent:123349]]
The [[talent:123349]] hero talent tree greatly empowers [[spell:259495]].

- Its most important talent is [[talent:117573@AJwACA]] which has a chance to apply a debuff to enemies that make your [[spell:259495]] do extra damage. This chance is increased during [[spell:1250646]] by [[talent:117562@AJwACA]]. Buffing abilities with [[spell:260285]] occurs naturally while doing your rotation so this talent does not impact your gameplay.
- [[talent:136065@AJwACA]] grants you another ability - [[spell:1264949]] which you can cast in a 15 second window after pressing [[spell:1250646]].
- [[talent:117575]] is your hero talent capstone that damages your main target  and nearby enemies after consuming [[spell:1253601]].
- Defensively, [[talent:123349]] offers [[talent:117586]] giving you an absorb shield up to 10% max HP.
- [[talent:117577]] improves your mobility even more.

:::

:::tab [[talent:123350]]
The [[talent:123350]] hero talent tree mostly empowers [[talent:126314@FAQA9i_A]], [[talent:126322]] and your pet's Basic Attack.

- It's signature ability is [[talent:117588]] that makes your [[talent:126314@FAQA9i_A]] spawn one of three beasts every 30 seconds which gets further reduced by [[talent:117589@FJQA5chADIA]]. Each of the beasts provides a passive damage benefit.
- Spawning a beast reduces [[talent:126324]] cooldown by 6 seconds.
- [[talent:117585@AJwACA]] makes your [[talent:135515]] deal more damage.
- [[talent:135514@FJgALl2Eq3yEDIA]] grants an extra beast spawn which summons [[talent:117563@AJwACA]] that does damage in a line in front of you for 7 seconds.
- Defensively, [[talent:123350]] offers [[talent:117564]] which makes your [[talent:126488]] stronger.
- When playing a pet from the Cunning family [[talent:123781]] empowers your [[spell:53271]].

:::

:::

## Talents

:::tabs
:::tab [[talent:123350]]
:::talents [[talent:123350]] Survival Hunter Mythic+ Build
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYxMzMzMjtBAAAAAgZmZmZYGDjZwYaGAAAgBAzYZZmxCzMjxYmBMz2M22gxYmZzA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYxMzMzMjtBAAAAAgZmZmZYGDjZwYaGAAAgBAzYZZmxCzMjxYmBMz2M22gxYmZzA"
}
```
:::

#### Spec Tree

- [[talent:135511]]
  
  - Two points in this talent make [[talent:135514@FJgALl2Eq3yEDIA]] a 1 minute cooldown.

#### Hero Tree

- [[talent:117555@AJwACA]]
  
  - Provides additional critical strike damage when consuming [[talent:126323]].
- [[talent:136521@AJwACA]]
  
  - Additional cooldown reduction for  [[spell:259495]].
- [[talent:128358]]
  
  - Survival has no interactions with Dire Beasts making [[talent:117569]] a weaker choice.

:::

:::tab [[talent:123349]]
:::talents [[talent:123349]] Survival Hunter Mythic+ Build
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA"
}
```
:::

### When to use this Spec

Use this as your default Mythic+ build.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[talent:126323]]
  
  - One of your major talents to play around and buff the correct spells. When casting abilities which are buffed by [[talent:126323]] you also gain the benefit of [[talent:135512]]  which hits up to 3 enemies through [[talent:136684]].
- [[talent:135515]] 
  
  - A 1 minute cooldown, which gets further reduced by [[talent:136683]] and [[talent:126316]]. It also reduces the cooldown of [[spell:259495]] through [[talent:136066]]. Because of [[talent:135510]] it is strong in both single target and aoe situations.
- [[talent:135514@FJgALl2Eq3yEDIA]]
  
  - Your main burst cooldown, which is made stronger by [[talent:136682]]. It grants 3 stacks of  [[talent:126323]] thanks to [[talent:135689]].

#### Class Tree

- [[talent:126470]]
  
  - Combine with [[talent:126454]] to give [[talent:126488]] an additional charge and reduce its cooldown, significantly increasing your survivability.
- [[talent:126465]]
  
  - Provides cooldown reduction to [[spell:109304]], improving your self-healing.
- [[talent:126475]]
  
  - With this talent, [[spell:781]] can now remove all movement impairing effects and give a burst of movement speed for 4 seconds.
- [[talent:136670]]
  
  - Makes your [[talent:135711]] pull stunned enemies to its center giving your tank more opportunities to kite.
- [[talent:136673]]
  
  - Combined with [[talent:126490]] and [[talent:126481@AJwACA]] makes your [[spell:186265]] a strong 2 minute defensive.
- [[talent:136686]]
  
  - 2 minute external defensive, which you can use either on yourself or your allies to reduce their damage taken by 15% for up to 10 seconds as long as your pet's health remains above 25%.
  - Choice node with [[talent:136685]] which provides more sustained damage reduction.

#### Hero Tree

- [[talent:117555@AJwACA]]
  
  - Provides additional critical strike damage when consuming [[talent:126323]].
- [[talent:136521@AJwACA]]
  
  - Additional cooldown reduction for  [[spell:259495]].

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: [[talent:135501]] also increases the damage of [[talent:126324]] by 10%.
- **4-Set**: Each blast of [[talent:135515]] extends the duration of [[talent:135501]] by 1 second. [[talent:135501]] effects are increased by 10%.

### Single-Target

:::tabs
:::tab [[talent:123350]]
### Opener

- The general goal of the **Survival Hunter** rotation is to avoid overcapping your **Focus**, not waste valuable cooldown on abilities such as [[talent:135515]] and [[spell:259489]] and maximizing the value of [[talent:126323]] to buff your most powerful abilities detailed in the **Priority List**.
- When playing [[talent:135689]], you should skip the [[talent:126314@FAQA9i_A]] before [[talent:135514@FJgALl2Eq3yEDIA]].

:::rotation [[talent:123350]] Survival Hunter Single-Target opener in Mythic+
```json
{
  "source_code": "IsGMLI0p1PAAAAAAC551CUACAEaBQwwABgorJgBIyEDBAAQAf9BBF4BCWVxEFgABJ6TCIAQoF4CDAI0p1ngLIsfNTUAIRgBKeetAAAAAAI0p1PA"
}
```
1. [[spell:259495]]
2. [[spell:186270]]
3. [[spell:259489]]  [[item:241288]] · [[spell:274738]] · [[item:270175]]
4. [[spell:1250646]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:1259003]]
9. [[spell:259489]]
10. [[spell:186270]]
11. [[spell:259495]]
:::

- Use [[spell:257284]] before the fight.
- Use your active trinkets, [[item:241308]] or [[item:241289]] and racials like [[spell:274738]] before using [[spell:1250646]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:126314]] when you have no [[talent:126323]] stacks or to summon a [[talent:117588]] animal.
2. Cast [[spell:1261193]] if talented.
3. Cast [[spell:1250646]]. 
   
   - When playing [[talent:135689]] try to have no [[talent:126323]] stacks before entering[[spell:1250646]].
4. Make sure to not overcap your [[talent:126324]] charges.
5. Spend [[talent:126323]] stacks with the following priority:
   
   - [[spell:1261193]] if talented
   
   
   
   - [[spell:1250646]]
   
   
   
   - [[spell:186270]]
   - [[talent:126324]]
6. Cast [[talent:126314]] while below 70 Focus.
7. Cast [[spell:186270]].

:::

:::tab [[talent:123349]]
### Opener

- The general goal of the **Survival Hunter** rotation is to avoid overcapping your **Focus**, not waste valuable cooldown on abilities such as [[spell:259495]] and [[spell:259489]] and maximizing the value of [[talent:126323]] to buff your most powerful abilities detailed in the **Priority List**.
- When not playing [[talent:135689]], you should cast a [[talent:126314@FAQA9i_A]] before [[talent:135514@FJgALl2Eq3yEDIA]].

:::rotation [[talent:123349]] Survival Hunter Single-Target opener in Mythic+
```json
{
  "source_code": "I8GaLIknXLAAAAwABgorDAAAAAgQyEDBAAQAf9BBF4ACWVxEFgANhDyEAAABQJ3bjBgQnWfCqQQi-kAHAEaDQEBGEUtQWhBAIUTTTA"
}
```
1. [[spell:186270]]  [[item:241288]] · [[spell:274738]] · [[item:270175]]
2. [[spell:1250646]]
3. [[spell:1253601]] Proc
4. [[spell:259495]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:1262293]]
9. [[spell:259489]]
10. [[spell:259495]]
11. [[spell:1264949]]
:::

- Use [[spell:257284]] before the fight.
- Use your active trinkets, [[item:241308]] or [[item:241289]] and racials like [[spell:274738]] before using [[spell:1250646]].
- [[talent:123349]] opener can change depending on how many [[spell:1253601]] procs you get. You should firstly consume [[spell:1253601]] by casting a [[talent:126323]] empowered [[spell:259495]] and then proceed with rest of  the opener. If you have no charges of [[spell:259495]], you can use [[spell:1264949]] to reduce their cooldown.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:126314]] when you have no [[talent:126323]] stacks.
2. Spend [[spell:1253601]] procs by casting [[spell:259495]].
3. Make sure to not miss out on casting [[spell:1264949]].
4. Avoid capping [[spell:259495]] charges.
5. Cast [[spell:1261193]] if talented and won't cap your [[spell:259495]] charges when playing [[talent:136066]].
6. Cast [[spell:1250646]] with less than 2 [[spell:259495]] charges and no [[spell:1253601]] on your target. 
   
   - When playing [[talent:135689]] try to have no [[talent:126323]] stacks before entering[[spell:1250646]].
7. Spend [[talent:126323]] stacks with the following priority:
   
   - [[talent:126324]] if you're about to reach 2 stacks
   
   
   
   - [[spell:1261193]] if talented
   - [[spell:1264949]]
   
   
   
   - [[spell:186270]]
8. Cast [[talent:126314]] while below 70 Focus.
9. Cast [[spell:186270]].

:::

:::

### AoE

:::tabs
:::tab [[talent:123350]]
### Opener

- Similar to Single-Target, your goal stays the same but you will be able to cast more [[spell:1261193]] and [[spell:259495]]. Below, you can see an example of how your opener looks like in AoE situations.

:::rotation [[talent:123350]] Survival Hunter AoE opener in Mythic+
```json
{
  "source_code": "IMGZLIknXLAAAAgABgorDAAAAAgQyEDBAAgQnWfCOAQoNgACWVxEF4BBJ6TCIEBGRgCC7XzEFAiPYAACeetA"
}
```
1. [[spell:186270]]  [[item:241288]] · [[spell:274738]]
2. [[spell:259495]]
3. [[spell:259489]]
4. [[spell:1250646]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:1259003]]
9. [[spell:259489]]
10. [[spell:259495]]
11. [[spell:186270]]
:::

- Use [[spell:257284]] before the fight on the highest priority target.
- Use your active trinkets, [[item:241308]] or [[item:241289]] and racials like [[spell:274738]] before using [[spell:1250646]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:126314]] when you have no [[talent:126323]] stacks or to summon a [[talent:117588]] animal.
2. Avoid capping [[spell:259495]] charges.
3. Cast [[spell:1261193]] if talented and won't cap your [[spell:259495]] charges.
4. Cast [[spell:1250646]]. 
   
   - When playing [[talent:135689]] try to have no [[talent:126323]] stacks before entering[[spell:1250646]].
5. Spend [[talent:126323]] stacks with the following priority:
   
   - [[talent:126324]] if you're about to reach 2 stacks
   
   
   
   - [[spell:1261193]] if talented
   
   
   
   - [[spell:1250646]]
   
   
   
   - [[spell:186270]]
6. Cast [[talent:126314]] while below 70 Focus.
7. Cast [[spell:186270]].

:::

:::tab [[talent:123349]]
### Opener

- Similar to Single-Target, your goal stays the same but you will be able to cast more [[spell:1261193]] and [[spell:259495]]. Below, you can see an example of how your opener looks like in AoE situations.

:::rotation [[talent:123349]] Survival Hunter AoE opener in Mythic+
```json
{
  "source_code": "I8GaLIknXLAAAAwABgorDAAAAAgQyEDBAAQAf9BBF4ACWVxEFgANhDyEAAABQJ3bjBgQnWfCqQQi-kAHAEaDQEBGRgQEYgS1CNBAAAAACVTTTA"
}
```
1. [[spell:186270]]  [[item:241288]] · [[spell:274738]] · [[item:270175]]
2. [[spell:1250646]]
3. [[spell:1253601]] Proc
4. [[spell:259495]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:259495]]
9. [[spell:259489]]
10. [[spell:1262293]]
11. [[spell:1264949]]
:::

- Use [[spell:257284]] before the fight.
- Use your active trinkets, [[item:241308]] or [[item:241289]] and racials like [[spell:274738]] before using [[spell:1250646]].
- [[talent:123349]] opener can change depending on how many [[spell:1253601]] procs you get. You should firstly consume [[spell:1253601]] by casting a [[talent:126323]] empowered [[spell:259495]] and then proceed with rest of  the opener. If you have no charges of [[spell:259495]], you can use [[spell:1264949]] to reduce their cooldown.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:126314]] when you have no [[talent:126323]] stacks.
2. Spend [[spell:1253601]] procs by casting [[spell:259495]].
3. Make sure to not miss out on casting [[spell:1264949]].
4. Avoid capping [[spell:259495]] charges.
5. Cast [[spell:1261193]] if talented and won't cap your [[spell:259495]] charges.
6. Cast [[spell:1250646]] with less than 2 [[spell:259495]] charges and no [[spell:1253601]] on your target. 
   
   - When playing [[talent:135689]] try to have no [[talent:126323]] stacks before entering[[spell:1250646]].
7. Spend [[talent:126323]] stacks with the following priority:
   
   - [[talent:126324]] if you're about to reach 2 stacks
   
   
   
   - [[spell:1261193]] if talented
   - [[spell:1264949]]
   
   
   
   - [[spell:186270]]
8. Cast [[talent:126314]] while below 70 Focus.
9. Cast [[spell:186270]].

:::

:::

## Deep dive

### Tip of the Spear

- Your main goal in single target and AoE is to buff as many [[talent:126324]], [[spell:1261193]] and [[spell:1264949]] with the [[talent:126323]] buff as possible.
- Although you may sometimes find yourself getting an excess of [[talent:126323]] stacks, especially outside of [[spell:1250646]], it is more important to keep [[spell:259489]] on cooldown to minimize Focus starvation.

### Stampede!

- If you have chosen the [[talent:123350]] hero talent, when you cast [[talent:135514@AJwACA]] you gain [[talent:117563@AJwACA]]. It will spawn a line of animals from you to your [[spell:259489]] target that will damage enemies over 7 seconds. Take care to position yourself so [[talent:117563@AJwACA]] hits as many targets as possible. Pay attention if the tank is about to move enemies so you can spawn [[talent:117563@AJwACA]] in the direction the tank is moving.

### Finding yourself outside of melee range

- Even though Survival Hunter has many abilities that don't require you to be in melee range, sometimes mechanics can force you outside of it for a prolonged amount of time. In such situations you can use [[spell:186289]], which lets you cast [[spell:186270]] from 40y range and ensures [[spell:263135]] gains maximum benefit.
- [[spell:193265]] is a very weak ability and you should avoid casting it unless you have nothing else to press. It can be useful for helping tank pull far enemies by firstly casting [[talent:126484]] on the tank.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Survival Hunter** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA"
}
```
:::

### Boss Tips

#### Ra'vi

- Use a defensive when targeted by [[spell:1296220]].

#### The Writhing Coil

- Make sure to run away from boss quickly to stretch your tether to stop [[spell:1299053]]. [[spell:781]] can be very useful for this.
- During intermission make sure to use [[talent:135711]] and [[talent:128412]] to stop the fixates from Uncoiled Writhes.
- Interrupt [[spell:1310358]], as it is 3 casts in quick succession it can be good to agree on an interrupt order before starting the dungeon. If a cast does go off you can clear this debuff with [[spell:781]] or [[spell:53271]].

#### Zul'jan

- Make sure to clear your [[spell:1300894]] debuff by standing in [[spell:1301508]]. Use a defensive for this.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1289416]] from **High Evolutionist.** If a cast goes through on you, you can clear it with [[spell:5384]] when talented into [[talent:126452]].
  - [[spell:1294557]] from **Primal Serpent.**
  - [[spell:1307567]] from **Ula'tek's Chosen.**

- Pay extra attention to these casts:
  
  - [[spell:1306385]] from **High Evolutionist.**
    
    - Make sure to stun this cast. If the High Evolutionist manages to get this cast off he will be casting uninterruptable [[spell:1307567]] until you  break his absorb shield.
  - [[spell:1294567]] from **Twinfang Harrower.**
    
    - Will apply a stacking DoT to 2 people, you can clear this debuff with [[spell:781]] or [[spell:53271]].
  - When **Living Venom** dies, it explodes and does party wide AoE damage, make sure to use a defensive when they are dying, especially if it overlaps with **Ula'tek's Chosen's** [[spell:1306853]] cast.

:::

:::tab Den of Nalorakk
:::talents **Survival Hunter** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmhtx0MAAAADAwy2MjFMzMjxMDAzYDMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmhtx0MAAAADAwy2MjFMzMjxMDAzYDMGzMLGA"
}
```
:::

### Boss Tips

#### The Hoardmonger

- When talented into [[talent:126452]] you can use [[spell:5384]] to dispel [[spell:1234846]].

#### Sentinel of Winter

- Make sure to interrupt [[spell:1235829]] from **Fractured Shivercore**. You can also throw a [[spell:187650]] on the second **Fractured Shivercore** and kill them one by one.

#### Nalorakk

- Hide behind Zul'jarra from [[spell:1297792]] but be careful to not get knocked into any **Echoes of Nalorakk** afterwards.
- Make sure to intercept any **Echoes of Nalorakk** who are trying to reach **Zul'jarra**. Use a defensive while doing this.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1297696]] from **Earthwhisper Tender.**
  - [[spell:1309919]] from **Frigid Mauler.**
  
  
  
  - [[spell:1297778]] from **Stormbound Mystic.**

- Pay extra attention to these casts:
  
  - [[spell:1246957]] from **Grizzled Warbringer.** 
    
    - Does strong AoE damage and applies a DoT, make sure you use a defensive for it.
  - [[spell:1238760]] from **Spirit of Hunger.** 
    
    - Spawns a totem, make sure to swap to it and kill it as soon as possible as it will apply a stacking curse which reduces your max health.
    - Soon after the Spirit of Hunger will cast [[spell:1238687]], make sure to use a defensive for this if you have stacks from **Starvation Effigy**.
  - [[spell:1246820]] from **Ruthless Totemcaller.**
    
    - Spawns a totem, make sure to swap to it and kill it.
  - [[spell:1309925]] from **Loa Speaker Nanea**. 
    
    - Spawns multiple totems, make sure to swap to them and kill them quickly.
  - [[spell:1241464]] from **Avatar of Determination**. 
    
    - You can clear this root with [[spell:781]] or [[spell:53271]].

- Useful purges and soothes: 
  
  - [[spell:1238053]] from **Territorial Matriarch.**

:::

:::tab Murder Row
:::talents **Survival Hunter** Mythic+ Build in Murder Row
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmxMMjhxMsNmmBAAAYAAW2mZsgZmZMmZAYGbbwYMzsYA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmxMMjhxMsNmmBAAAYAAW2mZsgZmZMmZAYGbbwYMzsYA"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- You can use [[talent:128412]], [[spell:187650]] and [[talent:100543]] to interrupt the Mirror Images' [[spell:1264106]].
- When **Nibbles** reaches 20% health **Kystia** will get stunned and take 100% increased damage while pulsing AoE damage, make sure to use a defensive in this phase and not use your cooldowns when **Nibbles** is close to reaching 20% health to be able to use them on **Kystia.**

#### Zaen Bladesorrow

- Make sure to destroy the **Fel-Infused Freight** when targeted by [[spell:1214357]].

#### Xathuux the Annihilator

- Use a defensive for either [[spell:1295455]] or [[spell:474197]] as they come in quick succession.

#### Lithiel Cinderfury

- Place [[spell:474457]] near each other to spawn the **Wild Imps** close together for easier cleave.
- Interrupt [[spell:474375]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1201554]] from **Seductive Sayaad.**
  - [[spell:1214922]] from **Wrathguard Flayer.**
    
    - If this cast goes off you can soothe it with [[talent:135712]].

- Pay extra attention to these casts:
  
  - [[spell:1294827]] from Defiled Golem. 
    
    - Does heavy AoE damage, use a defensive.
  - [[spell:1297683]] from **Corrupted Warlock.** 
    
    - You can use [[spell:5384]] to stop the channel on yourself.

:::

:::tab The Blinding Vale
:::talents **Survival Hunter** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Use a defensive when targeted by [[spell:1235640]] and place it slightly away from the other 2 bosses.

#### Ikuzz the Light Hunter

- You can clear [[spell:1236658]] with [[spell:781]] or [[spell:53271]].

#### Lightwarden Ruia

- Spread when [[spell:1240210]] are happening. 
  
  - Pay attention to where the Bear spawns for [[spell:1240210]] when boss is channeling [[spell:1241067]] as the [[spell:1240210]] will come from the Bear.

#### Ziekket

- Cast [[talent:126484]] on the tank when boss is summoning **Lightspawn Lashers.**
- Don't let [[spell:1246858]] reach the boss but be careful of not soaking too many as they apply a stacking DoT.
- Use a defensive when targeted by [[spell:1246607]] and aim it towards the defeated **Lightspawn Lashers.**

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238294]] from **Lightfeather Petalwing.**
  - [[spell:1301834]] from **Radiant Spellsower.**

- Pay extra attention to these casts:
  
  - [[spell:1263628]] from **Sporeblight Belcher.**
    
    - Does heavy party wide AoE, make sure to use a defensive for it, especially when its paired with [[spell:1255205]] from **Virid Grovekeeper**.
  
  
  
  - [[spell:1238463]] from **Overgrown Hydra.** 
    
    - When targeted by it, you can use [[spell:5384]] to stop the channel on yourself.

:::

:::tab Voidscar Arena
:::talents **Survival Hunter** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmBjpZAAAAGAgltZGLYmZGjZGAmx2GMGzMLGA"
}
```
:::

### Boss Tips

#### Taz'Rah

- Place the **Etheral Shades** near each other.

#### Atroxus

- Use a defensive when the **Toxic Creeper** is up, make sure to kill it quickly.
- If you accidentally step in a [[spell:1222484]], you can dispel the debuff with [[spell:5384]] when talented in [[talent:126452]].

#### Charonus

- Slightly spread for [[spell:1300372]].
- Kite your [[spell:1223298]] into [[spell:1264191]].
- When targeted by [[spell:1222755]] kite it away from your allies.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1298899]] from **Dominated Brawler.**
  - [[spell:1299938]] from **Voidtouched Magi.**
  - [[spell:1249621]] from **Angry Krolusk.**
  - [[spell:1233398]] from **Kilivore Screamer.**
- Pay extra attention to these casts:
  
  - [[spell:1289265]] from **Agitated Voidscythe.**
    
    - You can dispel the debuff with [[spell:5384]] when talented in [[talent:126452]].
  - [[spell:1252406]] from **Devouring Brutalizer.** 
    
    - Use a defensive for it.
  - [[spell:1300249]] from **Devouring Brutalizar.** 
    
    - Make sure to kill the target the **Devouring Brutalizer** is devouring, otherwise he will heal.
  - [[spell:1246820]] from **Enthralled Shaman.** 
    
    - Make sure to swap to the totem and kill it.
  - [[spell:1298901]] from **Brutal Overseer.**
    
    - Use a defensive and break the absorb shield quickly to stop the cast.

- Useful soothes:
  
  - [[spell:1249661]] from enemies in the arena before Taz'rah**.**

:::

:::tab Kings' Rest
:::talents **Survival Hunter** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmhlx0MAAAADAwy2MjFMzMjxMDAzYDMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmhZMMmhlx0MAAAADAwy2MjFMzMjxMDAzYDMGzMLGA"
}
```
:::

### Boss Tips

#### The Golden Serpent

- When targeted by [[spell:265773]], place them near other [[spell:265914]] puddles to ensure that **Animated Gold** spawn close together and can be quickly killed.

#### Mchimba the Embalmer

- Use a defensive when targeted by [[spell:267618]].
- Interrupt [[spell:267763]] from Half-Finished Mummies.
- When targeted by [[spell:267702]] make sure to let your team know in which crypt you are trapped. You can do that by either pressing the new [[spell:267764]] ability on your action bar or using the in-game ping system.

#### The Council of Tribes

- Interrupt [[spell:267273]] from Zanazal the Wise.
- When a boss dies, he will keep his signature abilities until all 3 bosses are defeated. You can use [[spell:186265]] to solo [[spell:266951]] if there is an especially difficult overlap.

#### Dazar, The First King

- Interrupt [[spell:269369]] from Reban.
- Make sure to not stand in front of the boss when he is empowered with [[spell:1303372]], use a defensive for [[spell:1303267]].
- You can [[spell:5384]] [[spell:1303324]] by being the furthest person away and pressing [[spell:5384]] as the boss leaps.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:269972]] from **Risen Hexer.**
  - [[spell:270920]] from **Queen Wasi.**
  - [[spell:270901]] from **Seneschal M'bara.**
  - [[spell:267763]] from **Half-Finished Mummy.**
  - [[spell:270492]] from **Phantom Hex Priest.**

- Pay extra attention to these casts:
  
  - [[spell:270293]] from **Purification Construct.** 
    
    - Does heavy AoE damage, make sure to be healthy or use a defensive for this cast.
  - When fighting **Shadow of Zul** take care to not hit your allies with [[spell:1298304]]. If not targeted by this ability, ensure that the **Pools of Darkness** are being soaked.

- Dangerous debuffs to be wary of:
  
  - You can clear [[spell:270499]] with [[spell:781]] or [[spell:53271]] to have an easier time dodging other abilities.
  - You can clear [[spell:1306763]] from **Queen Patlaa** with [[spell:781]], [[spell:53271]] or [[spell:781]] when talented into [[talent:126452]].

- Useful purges and soothes:
  
  - [[spell:1297763]] from **Queen Patlaa or Skeletal Hunting Raptor**.
  - [[spell:1296671]] from **King Rahu'ai or Seneschal M'bara**.
  - [[spell:269976]] from **Shadow-Borne Champion**.
  - [[spell:269935]] from **Minion of Zul.**

:::

:::tab Ruby Life Pools
:::talents **Survival Hunter** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmxMMjhxMsMmmBAAAYAAW2mZsgZmZMmZAYGbbwYMzsYA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmxMMjhxMsMmmBAAAYAAW2mZsgZmZMmZAYGbbwYMzsYA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- Place [[spell:384024]] close to each other.
- When targeted by [[spell:372851]] place it away from your allies and make sure to not be pulled or knocked into [[spell:384024]].
- [[spell:372988]] happens at 66% and 33% of **Melidrussa's** health, make sure to have some damage for it to break it as quickly as possible.

#### Kokia Blazehoof

- When targeted by [[spell:372863]] make sure to place it near the previous fire to reserve space but still have enough room for your party to attack the **Blazebound Firestorm** to kill it as quickly as possible.
- Interrupt [[spell:373017]] from **Blazebound Firestorm.**
- Use a defensive for [[spell:384823]].
- Bait the [[spell:372107]] towards previous fire puddles.

#### Kyrakka and Erkhart Stormvein

- Use a defensive when targeted by [[spell:381862]], especially when **Kyrakka** has landed and [[spell:381516]] happens in quick succession.
- When [[spell:381862]] expires it will spawn puddles, make sure to place them so the [[spell:381517]] can push them off the platform. [[spell:381517]] happen in a counterclockwise pattern.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:372743]] from **Flashfrost Chillweaver.**
  - [[spell:392576]] from **Tempest Channeler.**
  - [[spell:384194]] from **Primalist Cinderweaver.**

- Pay extra attention to these casts:
  
  - [[spell:373692]] from **Blazebound Destroyer.** 
    
    - You can [[spell:5384]] the damage and dot application for it if you [[spell:5384]] close to the cast finish. If that is not possible, use a defensive, especially when targeted by [[spell:373693]].
  - [[spell:1305201]] from **Primal Juggernaut.** 
    
    - Use a defensive, especially if you have [[spell:1307205]] debuff.
  - [[spell:1310363]] from **High Channeler Ryvati.** 
    
    - Make sure to break the shield quickly, use a defensive while its up.
  - [[spell:1307488]] from **Tempest Channeler and High Channeler Ryvati.** 
    
    - When targeted by this ability you can [[spell:5384]] it to stop the channel.
  - Stun [[spell:385567]] from **Ashseer Flamelasher.**
  - Use a defensive when [[spell:392570]] from **Flamegullet** stacks up.

- Dangerous debuffs to be wary of:
  
  - [[spell:392641]] from Thunderhead.
    
    - Debuffs 2 players with a heavy DoT but can be pre-immuned by using [[spell:186265]] while boss is casting the ability. If you get the debuff, make sure to use a defensive, especially if you are gonna be dispelled second.

- Useful purges and soothes:
  
  - [[spell:373972]] from **Ashseer Flamelasher.**
  - [[spell:391031]] from **Primal Thundercloud.**

:::

:::tab Temple of Sethraliss
:::talents **Survival Hunter** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmx2MGGzgx0MAAAADAwy2MjFMzMjxMDAzYDMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWgBmxoxyAYmgtZmZmxMz2MAAAAAAmZmZmx2MGGzgx0MAAAADAwy2MjFMzMjxMDAzYDMGzMLGA"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Have [[spell:257284]] up on the boss which doesn't have [[spell:1310311]] on them.
- Place [[spell:1288864]] away from where you plan to get knocked by [[spell:1289059]].
- Use a defensive if you have [[spell:1288455]] and are soaking [[spell:1288049]].

#### Merektha

- Use [[spell:5384]] when talented into [[talent:126452]] to dispel [[spell:267027]] from yourself.
- [[talent:128412]], especially when talented into [[talent:135704]], can be used on [[spell:263958]] to instantly free the people inside.

#### Galvazzt

- Intercept [[spell:1291618]] to prevent boss from reaching 100 energy.

#### Avatar of Sethraliss

- Use a defensive when soaking [[spell:1300871]].
- Interrupt [[spell:1302158]] from **Twisted Hexxer.**
- When targeted by [[spell:1302153]], place it near the edges of the room.
- Use stuns and slows to keep **Faithless Tormentors** away from their fixate target.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1293307]] from **Faithless Subjugator.**
  - [[spell:1303535]] from **Temple Disruptor.**

- Pay extra attention to these casts:
  
  - Stun [[spell:1308116]] to stop it.
  - [[spell:1303486]] from **Orb Watcher.** 
    
    - Make sure to use a defensive for it.

- Dangerous debuffs to be wary of:
  
  - You can use [[spell:5384]] when talented into [[talent:126452]] to dispel [[spell:1308148]] and [[spell:267027]] from yourself.
  - Use a defensive when you have [[spell:1291399]] debuff.

- Useful purges and soothes:
  
  - [[spell:1310739]] from **Agitated Nimbus.**

:::

:::

### Affixes

The Affix system got updated going into **Midnight Season 1** slightly changing some Affixes as well as introducing new ones in lower key levels.

- +2 Affixes *-- Goes away when you reach +6 or higher keys*
  
  - [[spell:1284818]]
- +5 Affixes *-- Rotates on a weekly basis*
  
  - [[spell:1272893]]
  - [[spell:1272895]]
  - [[spell:1272896]]
  - [[spell:1272894]]
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Alternates between each other on a weekly basis, is always the opposite of the +7 Affix
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - [[spell:1271525]] *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Survival Hunter**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:135712]] with [[talent:126480]] or [[talent:128412]] with [[talent:135704]] are your best tools to deal with the orbs.
- Xal'atath's Bargain: Voidbound
  
  - Switch to the affix mob and kill it as soon as it spawns as it gives damage reduction to the rest of mobs around it.
- Xal'atath's Bargain: Devour
  
  - [[spell:781]] or [[spell:5384]] with [[talent:126452]] allows you to get rid of the debuff on yourself. You can also use [[spell:53271]] to remove the debuff from yourself or an ally.
    
    - [[spell:189949]] is also an option but should be held as a defensive.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Survival Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority Survival Hunter Mythic+ Stat Priorities
```json
{
  "source_code": "IgAHEEDJggSADQA"
}
```
**精通 ＞ 急速 ≥ 暴击 ≫ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
In patch 12.1 when you catalyst an item it will keep its stats and cantrip effects which means you can have the perfect stats on your tier set slots. You should keep using the tier pieces you get from tier tokens until you have enough Venomblight Manaflux charges to catalyst the items with better stats.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271492@DiQAA8PANk7cVrjgC4UA]] | The Twin Fangs |
| Neck | [[item:268265@BERAA8PA8z6wPrjgCwYNYFA]] | Ula'tek |
| Shoulder | Convert [[item:268231@DgQAA8PA7j7IoAYF]]  <br>into [[item:271490@DgQBA8PAXk7IoAYFwxXQ]] | Catalyst of The Coiled Altar |
| Cloak | [[item:268253@BgQAA8PACKAWBA]] | The Coiled Altar |
| Chest | Convert [[item:271876@BARAA8PACKAj1gVA]]  <br>into [[item:271495@DARBA8PAJk7IoAMWDWBQgJE]] | Catalyst of Ula'tek |
| Wrist | [[item:244584@FCSAA8PAno6gBwD_sOAAAAAAAA3WzSB]] | Crafted |
| Gloves | Convert [[item:160213@BgQAA8PACKgTBA]]  <br>into [[item:271493@BgQBA8PACKgTBUdcCA]] | Catalyst of  Kings' Rest |
| Belt | [[item:244581@FCSAA8PAno6gBwD_sOAAAAAAAA3WzSB]] | Crafted |
| Legs | Convert [[item:268237@DgQAA8PAhu7IoAYF]]  <br>into [[item:271491@DgQBA8PAhu7IoAYFQzXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268233@DgQAA8PAPk7IoAOF]] | Sszorak |
| Ring 1 | [[item:252258@DiQAA8PA1j7wPrjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:273792@DiQAA8PA1j7wPrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270175@BgwAA8PACKAWBUAABYzFCA]] | Ula'tek |
| Trinket 2 | [[item:270164@BgQAA8PACKAWBA]] | The Lost Explorers |
| Weapon | [[item:268215@DARAA8PAFk7IoAWYDWB]] | Ula'tek |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251220@BgQAA8PACKQQBA]] | Voidscar Arena |
| Neck | [[item:251234@BgQAA8PACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAA8PACKQQBA]] | Kings' Rest |
| Cloak | [[item:251190@BgQAA8PACKQQBA]] | The Blinding Vale |
| Chest | [[item:251233@BgQAA8PACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251200@BgQAA8PACKQQBA]] | The Blinding Vale |
| Gloves | [[item:160213@BgQAA8PACKQQBA]] | Kings' Rest |
| Belt | [[item:251228@BgQAA8PACKQQBA]] | Voidscar Arena |
| Legs | [[item:159375@BgQAA8PACKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAA8PACKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:252258@BgQAA8PACKQQBA]] | Voidscar Arena |
| Ring 2 | [[item:273792@BgQAA8PACKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:273796@BgQAA8PACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAA8PACKQQBA]] | Murder Row |
| Weapon | [[item:251149@BgQAA8PACKQQBA]] | Den of Nalorakk |
| Option for Dual Wielding | [[item:275070@BgQAA8PACKQQBA]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAA8PACKgTBA]]  <br>[[item:270175@BgwAA8PACKAWBUAABYzFCA]] |
| **A-Tier** | [[item:270173@BgQAA8PACKAWBA]] *-- S-Tier in low target count dungeons, for example Kings' Rest*  <br>[[item:270165@BgQAA8PACKgTBA]]  <br>[[item:273796@BgQAA8PACKgTBA]]  <br>[[item:250228@BgQAA8PACKgTBA]] |
| **B-Tier** | [[item:250214@BgQAA8PACKgTBA]] *-- Need to stand in the light beam to gain maximum value*  <br>[[item:270168@BgQAA8PACKAWBA]] *-- Situationally can be good for big on demand damage*  <br>[[item:273797@BgQAA8PACKgTBA]]  <br>[[item:159617@BgQAA8PACKgTBA]]  <br>[[item:250215@BgQAA8PACKgTBA]] |
| **C-Tier** | [[item:248583@BgQAAcEACKQQBA]] *-- Can't get higher than Hero track*  <br>[[item:251783@BgQAAcEACKQQBA]] *-- Can't get higher than Hero track*  <br>[[item:274493@BgQAA8PACKQQBA]] *-- Can't get higher than Hero track*  <br>[[item:251792@BgQAAcEACKQQBA]] *-- Can't get higher than Hero track*  <br>[[item:265657@BgQAAcEACKQQBA]] -- Can't get higher than Hero track |
| Junkyard | [[item:250259@BgQAA8PACKgTBA]]  <br>[[item:270166@BgQAA8PACKgTBA]]  <br>[[item:274496@BgQAA8PACKQQBA]]  <br>[[item:274497@BgQAA8PACKQQBA]]  <br>[[item:193757@BgQAA8PACKgTBA]]  <br>[[item:158374@BgQAA8PACKgTBA]]  <br>[[item:250225@BgQAA8PACKgTBA]]  <br>[[item:251782@BgwAAcEACKQQBUAABYzFCA]] *-- Can't get higher than Hero track*  <br>[[item:251785@BgQAAcEACKQQBA]] *-- Can't get higher than Hero track*  <br>[[item:251784@BgQAAcEACKQQBA]] *-- Can't get higher than Hero track* |

### Embellishments

- Craft [[item:240167]] on wrists and belt.
- For early progression it can be good to craft [[item:245876]] on weapon or [[item:240167]] on a high stat value piece like head.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level with some items being 344 therefore it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255846]] *-- feast*
  - [[item:242747]] -- personal food which lacks the stamina bonus that feasts provide
- Combat Potion
  
  - [[item:241308]] -- *Grants agility*
  
  
  
  - [[item:241289]] -- Grants secondary stats, currently the recommended choice
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240892]]
  - [[item:240983]] *-- Unique*

### Enchantments

:::columns
:::column
| Head | [[item:244007@BAAAA8P]]  <br>[[item:275707@BAAAA8P]] |
| --- | --- |
| Shoulders | [[item:243991@BAAAA8P]] |
| Chest | [[item:243977@BAAAA8P]] |
| Wrist | [[item:275707@BAAAA8P]] |
| Waist | [[item:275707@BAAAA8P]] |
| Legs | [[item:244641@BAAAA8P]] |
| Boots | [[item:243983@BAAAA8P]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:243973@BAAAA8P]] |

:::

:::column
:::gear **Survival Hunter** Enchantments in Mythic+
```json
{
  "source_code": "IQFZ_DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAABUQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAA8P]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Survival Hunter** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:20594]] -- Dwarf
  
  - Able to dispel a lot of debuffs from you on demand, while also providing you with a 10% physical damage reduction upon use.
- [[spell:59224]] -- Dwarf
  
  - Passively increasing your Critical Damage and Healing done by 2%.

- [[spell:59752]] -- Human
  
  - Can break you out of certain CC, even in PvE scenarios.
- [[spell:20598]] -- Human
  
  - You gain 2% more secondary stats from all sources.

- [[spell:256948]] -- Void Elf
  
  - Throws out a shadowy projectile in front of you, if you press this button again after the projectile is thrown out, you teleport to its current location. Occasionally extremely helpful for movement.
- [[spell:255669]] -- Void Elf
  
  - Occasionally empowering you to deal 5% more damage with all your spells for 12 seconds.

- [[spell:20549]] -- Tauren
  
  - Stuns 5 enemies close to you for 2 seconds.
- [[spell:20550]] -- Tauren
  
  - Increases your maximum health.
- [[spell:154743]] -- Tauren
  
  - Passively increasing your Critical Damage and Healing done by 2%.

- [[spell:274738]] *--* Mag'har Orc
  
  - Increasing one of your two highest stats on a two minute cooldown.

- [[spell:69070]] -- Goblin
  
  - About the same as [[spell:781]], except it launches you forward instead of backwards. Can be very useful on certain encounters with heavy movement.
- [[spell:69042]] -- Goblin
  
  - Increases your Haste by 1%.

- [[spell:107072]] -- Pandaren
  
  - Doubles the stats you get from Well Fed effects.

- [[spell:1238623]] -- Haranir
  
  - Passively increases your Critical Damage and Healing done by 1%.
- [[spell:1238677]] -- Haranir
  
  - Passively increases your damage dealt to Abberations, Beasts and Elementals by 1%.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Survival Hunter**.

## Macros

Discover recommended macros for **Survival Hunters** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:187650]]** -- *Casts [[spell:187650]] on your cursor without confirmation.*

```wow-macro
#showtooltip Freezing Trap    
/cast [@cursor] Freezing Trap
```

**[[talent:126457]] --** *Casts [[talent:126457]] on your cursor without confirmation.*

```wow-macro
#showtooltip Tar Trap    
/cast [@cursor] Tar Trap
```

**[[talent:135711]] --** *Casts [[talent:135711]] on your cursor without confirmation.*

```wow-macro
#showtooltip Binding Shot
/cast [@cursor] Binding Shot
```

:::

:::details Mouseover Macros
**[[talent:126324]]** -- *A macro that can see uses in niche situations where you don't want to change your main target but throwing a bomb from it would result in the bomb not  hitting as many targets as throwing the bomb from another target. A prime example of this type of situation is **Vorasius** in the new Voidspire raid*.

```wow-macro
#showtooltip Wildfire Bomb
/use [@mouseover,exists,harm,nodead][]Wildfire Bomb
```

**[[talent:135712]]** -- *Casts [[talent:135712]] on your mouseover or target.*

```wow-macro
#showtooltip Tranquilizing Shot
/use [@mouseover,exists,harm,nodead][]Tranquilizing Shot
```

**[[spell:53271]]** *-- Casts [[spell:53271]] firstly prioritizing mouseover, then specific player name and lastly yourself. Replace player name and realm in third line with the person who you want to cast [[spell:53271]] on.*

```wow-macro
#showtooltip Master's Call
/cast [@mouseover,exists,help] Master's Call
/cast [@PlayerName-PlayerRealm] Master's Call
/cast [] Master's Call
```

:::

:::details Pet Macros
**[[talent:126322]] pet attack** -- *Casts [[talent:126322]] and your pet's basic attack at your current target*.

```wow-macro
#showtooltip Raptor Strike
/petattack
/cast Raptor Strike
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[talent:126314]]** **pet attack/pet call** -- *Casts [[talent:126314]] and your pet's basic attack at your current target**. If you don't have a pet, it will [[spell:23498]] the first pet on your list. If you want it to call another pet, simply change the number or your pet order.*

```wow-macro
#showtooltip Kill Command
/petattack
/cast [pet] Kill Command; Call Pet 1
/cast Claw
/cast Bite
/cast Smack
```

**[[spell:136]]** *-- Casts [[spell:136]] if your pet is alive and [[spell:982]] if it has died.*

```wow-macro
#showtooltips
/cast [exists, nodead, @pet] Mend Pet; [exists, @pet] Revive Pet
```

:::

:::details Utility Macros
**[[spell:186265]]** -- *Allows you to immediately cancel **[[spell:186265]]*** *when pressing the macro again, useful in situations where you need to only immune a damage instance or to dispel a debuff with  [[talent:126452]]*.

```wow-macro
#showtooltip Aspect of the Turtle
/cancelaura Aspect of the Turtle
/stopcasting
/stopcasting
/cast Aspect of the Turtle
```

**[[talent:126484]]** -- *An all in one macro to misdirect to in order your mouseover, your party's leader, or your pet. If you use it in dungeons make sure the tank is your party leader.*

```wow-macro
#showtooltip Misdirection
/cast [@mouseover,exists,noharm,nodead][@party1,exists,noharm,nodead][@pet] Misdirection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Survival Hunter**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Survival Hunter Mythic+ User Interface](<https://assets-ng.maxroll.gg/wordpress/dungeonuiedited-2-1024x651.png>)

**Survival Hunter** Mythic+ User Interface

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addons for Raiders, especially for Raid leaders and officers.
- **BetterBlizzFrames** -- Unit Frame styling addon
  
  - Provides you with more customization options for default unit frames. Has plenty pre-done profiles which you can try if you don't want to configure your own.
  - Alternatively, you can also use ElvUI or of course the stock UI.
- **BigWigs** + **LittleWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for Raid and Dungeon encounters.
- **BetterBlizzPlates**  -- Nameplate styling addon
  
  - BetterBlizzPlates is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking and threat coloring.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**HUNTER**

- Hero Talents
  
  - Pack Leader
    
    - Hogstrider now lasts for 1 minute (was 20 seconds).
    - Hogstrider is now cancelled when starting a Raid encounter or Mythic+ dungeon.
    - Lethal Barbs has been updated – Auto-attacks now have a very high chance to generate 3 Focus, rather than granting 1 Focus per auto-attack.
    - Fixed an issue where Mastery: Spirit Bond incorrectly affected some summons from the Pack Leader Hero Talents twice.
  
  
  
  - Sentinel
    
    - Open Fire has been redesigned – Fire damage dealt increased by 5%.
    - Scout's Vigil no longer increases stealth detection radius while using Camouflage.
    - Moon’s Blessing now grants 6 seconds of Wildfire Bomb cooldown reduction when applying Sentinel’s Mark (was 4 seconds).
    - Sentinel’s Mark duration increased to 16 seconds (was 12 seconds).
    - Fixed an issue where Raptor Swipe could cause Sentinel's Mark to be applied to a target that was not your currently selected target. If you do not have a target selected when using Raptor Swipe, a target hit by Raptor Swipe will be chosen.

**SURVIVAL**

- New Talent: Razor Edge – Raptor Strike, Raptor Swipe, and Kill Command gain 10% increased critical strike chance and 10% increased critical damage dealt.
- New Talent: Bombardier – Wildfire Bomb damage, critical strike chance, and critical damage dealt increased by 15%.
- Wildfire Imbuement has been redesigned – Throwing a Wildfire Bomb has a chance to imbue your weapon with flames, causing you and your pet’s auto-attacks to deal additional Fire damage for 10 seconds.
- Grenade Juggler has been redesigned – Boomstick increases the cooldown recovery rate of Wildfire Bomb by 60% for 8 seconds.
- Grenade Juggler is now tracked in the Cooldown Manager.
- Lunge now increases your Agility by 3% (was 2%), plus an additional 1% (was 2%) while dual-wielding.
- Wildfire Shells now grants 3 seconds of cooldown reduction to Wildfire Bombs (was 2 seconds).
- Primal Surge has been moved up to an easier to access location in the talent tree.
- Fixed an issue where Outland Venom was not properly applied by various periodic effects from either the Hunter, their current pet, or other summons from the Pack Leader Hero Talents.
- The following talents have been removed:
  
  - Flamefang Pitch
  - Shower of Blood

:::

:::

## FAQ

:::accordion
:::details Q: What is the Best Pet For Survival?
**A:** All pets do the same damage, the only big difference is their family with each giving a different spell:

- The Cunning family provides [[spell:53271]] and [[spell:264656]].
- The Ferocity family provides [[spell:264667]] and [[spell:264663]].
- The Tenacity family provides [[spell:388035]] and [[spell:264662]].

Each family of pet has uses that's why its suggested to have at least a pet of each family and swap them according to your needs.

:::

:::

---

### Credits

Written By: **Heleni**

Reviewed By: **Ftm**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-22** Updated for patch 12.0.5.

**2026-02-20** Updated for patch 12.0.1.

**2026-01-11** Updated for patch 12.0.

**2025-10-06** Updated for patch 11.2.5

**2025-08-02** Updated for patch 11.2.

**2025-02-22** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7.

**2024-10-20** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
