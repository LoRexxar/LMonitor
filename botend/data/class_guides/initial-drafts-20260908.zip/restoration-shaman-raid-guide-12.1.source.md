Welcome to the **Restoration Shaman** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 4/5 · Strong

Cooldown Strength · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 4/5 · Strong

Mobility · 3/5 · Average



:::

:::

:::column
:::gear Restoration Shaman Raid Best in Slot Gear
```json
{
  "source_code": "J4fAwLECBc__BEwekQggIEAAvj7AO06ACKgTBEQ6XQAAJEAAJ16A6z6ACKAWBEQekQgAIEAA1k7ACKAWBEABmQgAIEAAjk7AF4BG4eBBAiQAAExPAoXCtQwGqmQLEI-FF0CAPEQL45UABg2uDQICBAAIAPwJqOgDtOwt1sUABwHJEAACBAQB-BD3XQggIEAA1j7AC06AFIBCAU9ANIBBS0aCSQgUfkBMAQVHMABKoOABIERXAcbAaRA9iUgfAMQA-RDWBEAPVPAAIEAACKgTBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271483]] | [[item:240910]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240969]] · [[item:240890]] |
| 肩部 | [[item:271481]] | [[item:244021]] |
| 胸部 | [[item:271876]] | [[item:244003]] |
| 腰部 | [[item:268216]] | [[item:240910]] |
| 腿部 | [[item:271482]] | [[item:240155]] |
| 脚部 | [[item:268258]] | [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240910]] · [[item:245792]] · [[item:240167]] |
| 手部 | [[item:271484]] |  |
| 戒指一 | [[item:268252]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:251136]] | [[item:240914]] · [[item:243957]] |
| 饰品一 | [[item:270162]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:239656]] | [[item:245792]] · [[item:240167]] |
| 主手 | [[item:271092]] | [[item:243971]] |
| 副手 | [[item:251196]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Restoration Shaman**, you have a chance gain access to [[spell:1267068]] after casting [[spell:61295]], which replaces and is a more powerful version of [[spell:5394]].

**Rank 2** increases the healing of [[spell:1267068]] and  [[spell:5394]]. While **Rank 3** gives and additional use of [[spell:1267068]] any time you cast [[spell:378081]] or [[spell:443454]] and causes [[spell:1267068]] to not consume a stack of [[spell:5394]] when used.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-restosham2-mxr.webp>)

Stormstream Totem

:::

:::

### Core Changes

Below you will find a list of meaningful class changes going patch 12.1 to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**.
  
  - New Talent: Swelling Tides
    
    - Casting [[spell:5394]] or [[spell:1267068]] extends all active [[spell:61295]] by 3 seconds.
  - [[talent:101923]] Cooldown has been decreased to 12 seconds while the duration remains 18 seconds.
  - [[talent:101923]] and [[spell:462603]] heal 6 targets, up from 5.

## Hero Talents

- [[talent:123380]] focuses on consistent single target and AoE healing by providing significant boosts to core healing abilities while also summoning [[talent:117485]] who mimic spells cast by the **Shaman**, while [[talent:123378]] grants an improved version of [[talent:101923]] and various ways for Totems to do extra healing.



### [[talent:123378]]

- [[spell:444995]]
  
  - Summons a totem that maintains [[talent:101923]] around it.
  - [[spell:444995]] has a longer duration of 25 seconds, and lets you utilize [[spell:108287]] to move it and the [[talent:101923]] attached to it, making it more flexible than a regular [[talent:101923]].
- [[talent:117476]]
  
  - Every time you summon [[spell:444995]] you get 3 different element buffs that affect your next healing abilities.
    
    - **Water** - Makes your next [[spell:77472]] cleave an ally inside your [[spell:73920]].
    - **Air** - Cast time of your next healing spell is reduced by 40%.
    - **Earth** - Your next [[talent:127861]] will apply an empowered [[talent:101935]] to all targets hit.




### [[talent:123380]]

- [[talent:117485]]
  
  - Call an Ancestor to your side after casting [[spell:73685]] for 12 seconds.
  
  
  
  - When you cast any healing or damage ability, your Ancestors casts a similar one.
- [[talent:117491]]
  
  - This functions the same way as [[talent:127899]] but has a lower cooldown and empowers your next ability.
  - After casting [[spell:443454]], you also summon an Ancestor for 8 seconds.





## Talents



### [[talent:123378]] Raid Talents

:::talents **Restoration Shaman** Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### When to use this Spec

This [[talent:123378]] build excels at consistent AoE healing, especially when the raid is mostly stacked. You might have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Raid section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:462603]]
  
  - Cast a solid AoE heal inside of your [[spell:73920]] by reactivating it. Can be cast twice with [[talent:128703@FAQAOPvB]]. Make sure to use both charges before they expire.
- Swelling Tides
  
  - Casting [[spell:5394]] or [[spell:1267068]] extends all active [[spell:61295]] by 3 seconds. Try to expend your [[spell:61295]] charges before using [[spell:5394]] or [[spell:1267068]].
- [[talent:127673]]
  
  - Great talent to improve the survivability of your raid. Your core healing spells provide a 10% health increase.
- [[talent:101912]]
  
  - Your main throughput Cooldown. [[spell:1064]] and [[spell:77472]] are significantly empowered during it.
- [[talent:101937@FAQAPdhA]]
  
  - Casts of [[spell:61295]] may proc [[spell:114052]] for 7 seconds. Be sure to pay attention to these procs as [[spell:1064]] and [[spell:77472]] rise in priority while it is active.
- [[spell:382020]]
  
  - This talent makes [[spell:379]] a lot stronger. Make sure to have it up on yourself and another ally at all times while talented into [[spell:383010]].
- [[talent:101922]]
  
  - Causes [[spell:73920]] to do damage to enemies inside of it. Make sure to place it in melee to make the most use of both the healing and damage.

##### Class Tree

- [[spell:383010]]
  
  - You can have [[spell:379]] on yourself and an ally simultaneously. This allows you to focus more on healing others and while yourself through passive healing.
- [[spell:1217622]]
  
  - [[spell:974]] no longer loses charges when triggered and does more healing. This means [[spell:974]] will only have to be applied once before combat.
- [[talent:135591@AJwBCA]]
  
  - Apply [[spell:52127]], [[spell:974]], [[spell:382021]] and [[spell:457481]] with just one cast of [[spell:52127]].

- [[talent:127899]]
  
  - Makes your next [[spell:1064]] or [[spell:77472]] instant and cost no mana. This also grants a charge of [[spell:1267068]].
- [[spell:108287]]
  
  - This allows you to move all your totems, including [[spell:444995]]!

##### Hero Talents

- [[talent:117476]]
  
  - While the Air and Water Motes don't impact your gameplay a lot, the Earth Mote should be consumed by casting [[spell:77472]] at least once during each [[spell:444995]].
- [[talent:117479]]
  
  - Causes all of your healing Totems to fire off a [[spell:1064]] when summoned. This [[spell:1064]] has all the same interactions as your own casts of [[spell:1064]].
- [[talent:125824]]
  
  - A shield enchant that can be applied via [[talent:135591@AJwBCA]]. While this is a sizeable boost to your healing and you should look to equip a shield, if you don't have one you can talent [[talent:117463]] instead.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:1064]] and [[spell:77472]] have a chance to create [[spell:73920]] at their targets location for 8 seconds.
- **4-Set:** [[spell:73920]] creates a shield on 1 target inside of it every 1 second.

The 2-Set creates a significant amount of extra [[spell:73920]]. These have all of the properties of your casted [[spell:73920]] and trigger the effects of [[spell:462424]] and [[spell:383222]].

The 4-Set does not alter Gameplay in any way.

### Priority List

#### For Healing

1. Maintain [[spell:444995]]/[[spell:73920]].
2. Cast [[spell:462603]] if it is about to expire.
3. Cast [[spell:1267068]].
4. Cast [[spell:5394]] at 2 stacks.
5. Cast [[spell:73685]] if talented.
6. Cast [[spell:61295]] at 2 stacks.
7. Cast [[spell:5394]].
8. Cast [[spell:1064]] if in [[spell:114052]] for AoE healing.
9. Cast [[spell:77472]] if in [[spell:114052]] to conserve Mana with the guaranteed critical strikes or for spothealing.
10. Cast [[spell:462603]].
11. Cast [[spell:1064]] or [[spell:77472]] to consume [[spell:73685]] or [[talent:117476]].
12. Cast [[spell:61295]].
13. Cast [[spell:1064]] for AoE healing.
14. Cast [[spell:77472]] for spothealing.

Keep in mind healing is highly situational and following a strict priority list is not always the best way to keep your raid alive.

#### For Damage

1. Cast [[spell:444995]]/[[spell:73920]] on the boss if talented into [[talent:101922]].
2. Cast [[spell:188443]] if it will hit three targets.
3. Maintain [[spell:188389]].
4. Cast [[spell:51505]].
5. Cast [[spell:188196]].

### Cooldowns

#### Ascendance

- [[spell:114052]] is your strongest healing cooldown. It does an initial burst of AoE healing and then provides a boost to [[spell:1064]] and [[spell:77472]] for 15 seconds. Line it up with periods of high incoming raid damage to make the best use of its relatively long duration.

#### Healing Tide Totem

- This is the alternative to [[spell:114052]]. It heals all allies within 40 yards. It's fairly weak in comparison to [[spell:114052]], even as [[talent:123378]].

#### Spirit Link Totem

- This totem is one of the most unique and powerful Cooldowns in the game. When placed and every second thereafter it redistributes your allies health to be the same percentage of maximum health. It also grants your allies a 10% damage reduction while they remain within its effect.
- [[spell:98008]] is an extremely powerful Cooldown to counter overwhelming damage on your raid. It can also be used to keep individual players that are taking more damage than everyone else alive.

## Deep Dive

#### Managing Mana

- Running out of Mana is an issue a lot of **Restoration Shaman** players struggle with. This is often caused by over-using expensive and inefficient heals. The following segment will go over how to make best use of the strongest tools you have available, however it is also important to know what *not* to do.
- Your baseline spells, namely [[spell:1064]] and, in the case of [[talent:123380]], [[spell:73920]] - [[spell:444995]] is extremely Mana efficient despite its high cost - are quite expensive and don't do a lot of healing unless paired with amplifying buffs and abilities such as [[talent:114811]]. Make sure to use your more Mana efficient abilities first before resorting to casting an unempowered [[spell:1064]].
- Often times procs of [[talent:101937@FAQAPdhA]] happen while the raid is not taking a lot of damage. In these situations you can use [[spell:77472]] guaranteed critical strikes to recover Mana with [[talent:101902]].
- Having high critical strike chance is important as [[talent:101902@FAQAV_RA]] accounts for a significant portion of your total Mana pool, especially on longer fights.

#### Call of the Ancestors

- Any time you cast a healing or damaging ability, each of your Ancestors will cast a corresponding one. For [[spell:77472]] they will cast [[spell:1223391]], for all other single target heals, they will cast [[spell:447415]] on your target. For any AoE heal (including totems such as [[talent:127863]]) [[spell:447433]]. [[spell:447419]] for single target damage abilities and [[spell:447425]] for your own [[spell:188443]].
- Try lining up [[spell:443454]] with incoming damage - or your own damage during healing downtime.

#### Ascendance

- With Midnight [[spell:114052]] has been reworked. It now reduces the Mana costs of [[spell:77472]] and [[spell:1064]] by 25%. [[spell:77472]] casts cleave onto a secondary ally at 50% effectiveness and both of these hits are guaranteed to critical strike. [[spell:1064]] casts jump to an additional 3 allies while each consecutive jump for the entire [[spell:1064]] only does 10% less healing rather than the normal 30%.
- The modifications to [[spell:1064]] also apply to [[talent:117479]], meaning you want to stack up as many stacks of [[spell:5394]] and [[spell:1267068]] as possible. We want to line up [[spell:378081]] with [[spell:114052]] as well to gain another use of [[spell:1267068]] and an instant [[spell:1064]].
- Through the two guaranteed critical strikes and the reduced cost, [[spell:77472]] now recovers more Mana than is spend casting it, making it a great option to use even if not playing any of the other talents empowering it.
- As our other abilities are not empowered by [[spell:114052]] anymore this means we want to use as many of them either before or after as with losing casts. [[spell:444995]] should be used up to 10 seconds ahead of  [[spell:114052]] so it won't have to be refreshed during it. This also gives us the opportunity to spend any [[spell:462603]] charges beforehand.
- Use [[spell:73685]] right before going into [[spell:114052]] to further empower [[spell:1064]]. Make sure to spend all [[spell:61295]] before this so they don't consume this buff and to increase the chance of having a [[spell:1267068]] to use during [[spell:114052]]. Casts of [[spell:61295]] while [[spell:114052]] is active should be kept to a minimum, however it is still worth using at 2 stacks to not lose out on a use.

#### Unleash Life

- Increases the healing and reduces the cast time of your next [[spell:77472]], [[spell:1064]] or [[spell:61295]]. For [[talent:123380]] this is your main way of spawning [[talent:117485]].
- Avoid using [[spell:73685]] to buff [[spell:61295]] as it is by far the weakest of the 3 affected abilities. However if playing [[talent:123380]], it is a higher priority to use [[spell:73685]] to spawn Ancestors. As [[spell:73685]] has a 20 second Cooldown and Ancestors spawned by it last 12/16 seconds you have very high uptime on them.
- As [[talent:123380]] [[spell:73685]] can also be used in healing downtime to spawn Ancestors to do damage.

#### Deluge

- If it is not possible to stay stacked inside [[spell:73920]], look to cast [[spell:61295]] primarily on ranged players to fully utilize [[spell:200076]].

#### Coalescing Water

- Any [[spell:77472]] or [[spell:1064]] casted by you will grant you a stack of [[spell:470076]].
- To make the most use out of this talent it is generally best to loosely alternate between [[spell:77472]]/[[spell:1064]] and [[spell:61295]]. However it is not worth losing potential casts of [[spell:61295]] by trying to avoid overcapping on this buff.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to Heroic Bosses. Mythic tips will be released after our progression finishes.

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Restoration Shaman** Nek'Zali Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- The majority of raid damage happens during [[spell:1284033]], however on its own it does not pose enough of a threat to warrant using Cooldowns on.
- On Mythic groups of players will have to enter the Soulwell and take every increasing damage from [[spell:1293212]]. During this phase you will have to heal on the move, making [[spell:79206]] a great tool. This might also be the spot to use throughput Cooldowns on.
- [[spell:1289855]] will cause players outside to soak circle to gain [[spell:1294933]]. As these targets are outside of most AoE heals they might need spothealing.

#### Boss Tips

- Defensives
  
  - Use [[talent:127893]] when targeted by [[spell:1294933]].

- General
  
  - Clear out corpses of killed [[spell:1295397]] by burning them with [[spell:1294933]].
  - Dispel targets that have [[spell:1287322]] on the edge of the Arena, it leaves behind [[spell:1287198]] that will start moving from where the target was dispelled.




### Entombed Sentinels

:::talents **Restoration Shaman** Entombed Sentinels Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- The highest raid damage event on this fight is [[spell:1284257]], use throughput while these [[spell:1284207]] are alive.
- [[spell:1288232]] requires players on the Blood of Ula'tek side to soak split damage and subsequently take damage from [[spell:1288297]]. [[spell:98008]] is a great tool to survive this.

#### Boss Tips

- Defensives
  
  - [[spell:1296878]] does fairly high damage if you are not able to clear it quickly. This can be a good use for [[talent:127893]].

- General
  
  - Dispel [[spell:1284471]] as soon as possible.




### Lost Explorers

:::talents **Restoration Shaman** Lost Explorers Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- [[spell:1290711]] causes somewhat large burst damage on the raid. Other than this the damage intake is fairly flat.

#### Boss Tips

- Defensives
  
  - Use [[talent:127893]] when targeted by or soaking [[spell:1291922]] as it does surprisingly high amounts of damage.
- General
  
  - Be aware of your [[spell:1308853]] stacks when soaking Relics. This is a bleed so you can remove it with [[spell:20594]] if you play a Dwarf character.
  - Use [[spell:1292104]] to jump over [[spell:1296227]] at the right time as Shaman does not have any way of avoiding it.
  - If you're targeted by [[spell:1295893]] make sure to not stack ontop of someone with the opposite element.




### Vashnik

:::talents **Restoration Shaman** Vashnik Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- Burning Venoms cause [[spell:1285979]] on death, which can overlap with damage from [[spell:1282509]]. This can be a good spot to use either [[spell:98008]] or throughput Cooldowns.
- Players with [[spell:1295224]] cannot be healed and are in a lot of danger these tend to overlap with raid damage. [[spell:98008]] can help not only these targets but also the players they are siphoning off of.

#### Boss Tips

- Defensives
  
  - Rotate your defensives when targeted by [[spell:1295224]] or [[spell:1294994]]. Be ready to use healing potions or Healthstones to remove [[spell:1294994]] if in danger.
- General
  
  - A lot of mechanics on this boss require players to leave melee, choosing the right targets to heal will be key to keeping everyone alive.




### Sszorak

:::talents **Restoration Shaman** Sszorak Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- Players soaking [[spell:1277027]] will take more damage than the rest. This DoT will overlap with [[spell:1297707]]. [[spell:114052]] can be a good Cooldown to prio heal these targets.
- When the boss uses [[spell:1286033]] it will start the intermission and push players around with [[spell:1285732]]. The raid will have to explode [[spell:1287008]] to help dealing with the push back. Use [[spell:79206]] to make healing during this easier. This can also be a good spot for throughput Cooldowns and [[spell:98008]].

#### Boss Tips

- Defensives
  
  - Use [[talent:127893]] when targeted by [[spell:1286987]], make sure it is still up for the expiration of the debuff since you will be taking the maximum amount of damage.
- General
  
  - Hold your [[spell:192063]] to cancel the knock up from [[spell:1285419]].




### Twin Fangs

:::talents **Restoration Shaman** Twin Fangs Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- This is a fight with heavy rot damage that ramps up over time. The main damage event is [[spell:1289400]], which does not do a lot of damage on its own but will require throughput in later parts of the fight when players have higher stacks of [[spell:1290336]].
- [[spell:1290505]] allows you to clear 1 stack of [[spell:1290336]] but will do damage and knock you back, afterwards you will have to quickly soak [[spell:1310099]] which leaves a stacking healing absorb.

#### Boss Tips

- Defensives
  
  - Use [[talent:127893]] whenever you are targeted by [[spell:1290809]].
- General
  
  - Avoid being hit by any mechanic as you will receive a stack of [[spell:1290336]]. Some of these stacks are unavoidable which means this ramps up over the encounter and any excess stacks will eventually kill you.
  - The fight has 2 intermission during which you will have to dodge [[spell:1306872]] while moving to a new spot of the platform. You can use [[spell:79206]] to heal on the move and for a small amount of extra speed.




### Coiled Altar

:::talents **Restoration Shaman** Coiled Altar Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- The highest damage intake in P1 and P3 will be when the boss destroys [[spell:1282403]] and causes [[spell:1299838]]. This is is a good spot to use throughput Cooldowns on.
- In P1 and P2 the boss will target a player with [[spell:1283485]] and [[spell:1299266]] respectively, [[spell:98008]] could help the soakers survive the impact.
- During the intermission players will have to soak spirits which causes the entire raid to take damage from [[spell:1287722]]. This will likely be the highest damage taken phase in the fight. Be ready to use any tool available for this. [[spell:79206]] could help to heal while soaking here.

#### Boss Tips

- Defensives
  
  - Use [[talent:127893]] when soaking [[spell:1283485]] or [[spell:1299266]]
  - [[spell:188616]] is a great defensive for the intermission as its duration covers almost all of it.
- General
  
  - The players carrying around [[spell:1282403]] in P1 and P3 will be taking more damage than the rest of the raid while being outside of melee.




### Ula'tek






### Nymrissa Wavecaller

:::talents **Restoration Shaman** Nymrissa Wavecaller Raid Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAgBAAAAzMzsssNzMDMzYegB2WmZxGjZsNN2mZhJzwYzYYmx2YmZa2WmZYGzmZZmxMGMLDAAMgZmBzMAwgZA"
}
```
:::

#### How To Use Your Healing Cooldowns

- The majority of damage on this encounter is caused by Frost Orbs being exploded, this becomes dangerous whenever it overlaps with the boss casting [[spell:1260837]]. You might want to use [[spell:98008]] and any throughput in these spots.

#### Boss Tips

- Defensives
  
  - Use [[talent:127893]] when a high amount of Frost Orbs is about to be exploded.
- General
  
  - When targeted by Chilling Frost you will periodically drop Frost Orbs underneath you. Make sure to place them in a good spot as they leave Ice on the floor, while you keep moving and avoid popping them immediately.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Restoration Shaman**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Restoration Shaman** Stat Priority in Raid
```json
{
  "source_code": "IoAJFUAIoEDJEQwADA"
}
```
**智力 ≫ 暴击 ≫ 全能 ≥ 精通 ≥ 急速**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- Critical Strike is generally significantly more powerful than your other Secondaries due to the extra scaling of [[talent:101920]] and the Mana return from [[talent:101902@FAQAV_RA]]. The exact value of Mastery varies a lot depending on healing requirements, but it is almost always weaker than Versatility as Versatility scales with effects from Trinkets and other healing procs while Mastery does not. Haste only interacts with a small part of the kit and generally has little value as your output is limited by Mana and Cooldowns rather than casting time. However, with 12.1 haste is seeing a slight increase in value due to our [[spell:1296629]].
- Blizzard introduced Stat DRs, which you should be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful Leech is for a Healer

![](<https://assets-ng.maxroll.gg/wordpress/Screenshot-2026-02-21-002710-1-1024x337.png>)

**Restoration Shaman** Warcraftlogs

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | Catalyze [[item:268230@BgQAAgQACKgTBA]] into [[item:271483@DiQBAgQAvj74QrjgC4UAGfBB]] | Nek'Zali + Catalyst |
| Neck | [[item:268265@BkQAAgQAJ16oPrjgCgVA]] | Ula'tek |
| Shoulder | Catalyze [[item:268231@BgQAAgQACKAWBA]] into [[item:271481@DgQBAgQA1k7IoAYFwxXQ]] | Coiled Altar + Catalyst |
| Cloak | [[item:239656@FgQAAgQAgA8ciqzt1sUA]] | Crafted |
| Chest | [[item:271876@DgQAAgQAjk7IoAYF]] | Ula'tek |
| Wrist | [[item:244584@FiQAAgQAgA8ciqjDtO3WzSB]] | Crafted |
| Gloves | [[item:271484@BgQAAgQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:249303@DiQAAgQAZbApPrjgCESA]] | Lightblinded Vanguard |
| Legs | Catalyze [[item:268237@BgQAAgQACKAWBA]] into [[item:271482@DgQBAgQAbo6IoAYFQzXQ]] | Coiled Altar + Catalyst |
| Boots | [[item:268258@DgQAAgQAPk7IoAOF]] | Lost Explorers |
| Ring 1 | [[item:268252@DiQAAgQA1j7IQrjgC4UA]] | Sszorak |
| Ring 2 | [[item:251136@DiQAAgQA1j7IRrjgC4UA]] | Murder Row |
| Trinket 1 | [[item:270162@BgQAAgQACKgTBA]] | Nek'Zali |
| Trinket 2 | [[item:270164@BgQAAgQACKgTBA]] | Lost Explorers |
| Weapon | [[item:271092@DgQAAgQADk7IoAYF]] | Ula'tek |
| Shield | [[item:251196@BgQAAgQACKgTBA]] | The Blinding Vale |




### Farmable Alternatives

Below you are presented with a good list of farm able alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Neck | [[item:251234@BgQAAgQACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:251131@BgQAAgQACKQQBA]] | Murder Row |
| Cloak | [[item:251132@BgQAAgQACKQQBA]] | Murder Row |
| Chest | [[item:239046@BgQAAgQACKQQBA]] | Kings' Rest |
| Wrist | [[item:159380@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Gloves | [[item:251165@BgQAAgQACKQQBA]] | The Blinding Vale |
| Belt | [[item:251155@BgQAAgQACKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Boots | [[item:159388@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Ring 1 | [[item:251136@BgQAAgQACKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Trinket 1 | [[item:250215@BgQAAgQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250214@BgQAAgQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:273780@BgQAAgQACKQQBA]] | Altar of Fangs |
| Shield | [[item:251196@BgQAAgQACKQQBA]] | The Blinding Vale |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Crafting. Do note that some trinkets are better than others depending on each boss fight.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAgQACKgTBA]]  <br>[[item:270162@BgQAAgQACKgTBA]] |
| **A-Tier** | [[item:270167@BgQAAgQACKgTBA]]   <br>[[item:250214@BgQAAgQACKgTBA]] |
| **B-Tier** | [[item:250215@BgQAAgQACKgTBA]] |
| **C-Tier** | [[item:273649@BgQAAgQACKgTBA]]  <br>[[item:273796@BgQAAgQACKgTBA]]  <br>[[item:270169@BgQAAgQACKAWBA]]  <br>[[item:193757@BgQAAgQACKgTBA]]  <br>[[item:250248@BgQAAgQACKgTBA]] |
| **Junkyard** | [[item:250255@BgQAAgQACKgTBA]]  <br>[[item:270171@BgQAAgQACKgTBA]]  <br>[[item:193748@BgQAAgQACKgTBA]]  <br>[[item:250254@BgQAAgQACKgTBA]] |

### Embellishments

- *Early on in the patch or if you struggle to find a good weapon to drop, you can craft a staff with [[item:245875]]. However, long term you want to end up with [[item:271092@DgQAAgQADk7IoAYF]] + a shield.*
- [[item:245875]] - Weapon only
  
  - Gives you a secondary stat depending on creature type healed or attacked. Healing Humanoids provides Mastery.
- [[item:244603]] - Jewellery
  
  - Chance to grant an ally Versatility. This does not grant you any power, however there are not a lot of alternatives here.
- [[item:240166]] - Armor only
  
  - Chance to empower yourself and an ally with Primary Stat. The main benefit of this is on yourself.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 at max item level, therefore it is not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Flask**
  
  - [[item:241326]]
- **Food**
  
  - [[item:255847]] *-- Personal Food*
  - [[item:266996]] -- Raidwide Feast
- Combat Potion
  
  - [[item:241288]] -- Use with your Cooldowns
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[talent:101935]] *--  Default*
  
  
  
  - [[item:243734]] -- If you play without Earthliving
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240910]]
  - [[item:240983]] *--* *Unique, use this as the default Diamond. Only one Diamond can be equipped*!
  - [[item:240969]] *--* *Unique,use this if you have 5 or more gem slots. Equip one of each gem colour to enhance your Diamond.*
    
    - [[item:240910]]
    - [[item:240914]]
    - [[item:240898]]
    - [[item:240890]]

### Enchantments

:::columns
:::column
| Helm | [[item:243951]]  <br>[[item:275707]] |
| --- | --- |
| Shoulder | [[item:244021]] |
| Chest | [[item:244003]] |
| Wrist | [[item:275707]] |
| Belt | [[item:275707]] |
| Legs | [[item:240155]] |
| Boots | [[item:243983]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:243971]] |

:::

:::column
:::gear **Restoration Shaman** Enchantments
```json
{
  "source_code": "JQFZIEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABMSDIgw-0QQBQQwGqmAGA8gOYAAB1jbCYgS94OAAAAAABMQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:244003]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243971]] |  |
:::

:::

:::

> You can buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt. It is highly recommended to prioritize item upgrades from your Great Vault before considering Sockets.

## Races

For min-maxing a **Restoration Shaman** in Mythic Raiding, different racial traits can provide a slight benefit to your character. If this is not your top priority, pick whichever race you prefer.

- [[spell:26297]] -- Troll
  
  - Increases your haste by 10% for 12 sec.
- [[spell:20594]] -- Dwarf
  
  - Dispels Magic, Curse, Poison, Disease and Bleed debuffs without triggering a GCD. Has been useful in the past on some bosses with Bleeds.
  - Increases Critical Strike Damage and Healing by 2%.
- [[spell:69070]] -- Goblin
  
  - Small jump in the direction your character is facing, any mobility is always useful in raids.
  - Increases Haste by 1%.
- [[spell:274738]] *-- Mag'har Orc*
  
  - 2 minute cooldown that grants a high amount of secondary stats.

### Recommendation:

While [[spell:69070]] offers you a quick way to move your character, it is not as crucial any longer due to our Talents allowing us to play [[spell:192063]].   
  
Dwarf's [[spell:20594]] can be very useful to dispel yourself without having to expend a global and Mana and receiving a decent healing boost from the passive increased Critical Healing.

## Macros

Discover recommended macros for **Restoration Shaman** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Restoration Shaman** Raid Guide are available as mouseover macros for your convenience!

**[[spell:1064]]**

```wow-macro
/cast [@mouseover, help, nodead] Chain Heal; Chain Heal
```

**[[spell:61295]]**

```wow-macro
/cast [@mouseover, help, nodead] Riptide; Riptide
```

**[[spell:77472]]**

```wow-macro
/cast [@mouseover, help, nodead] Healing Wave; Healing Wave
```

**[[spell:73685]]**

```wow-macro
/cast [@mouseover, help, nodead] Unleash Life; Unleash Life
```

:::

:::details Recommended Macros
**[[spell:108287]]** at your cursor without confirmation.

```wow-macro
#showtooltip
/cast [@cursor] Totemic Projection
```

**[[talent:101923]]** at your cursor without confirmation. Also works for **[[spell:444995]]**.

```wow-macro
#showtooltip
/cast [@cursor] Healing rain
```

**[[spell:98008]]** at your cursor without confirmation.

```wow-macro
#showtooltip
/cast [@cursor] Spirit Link Totem
```

**[[spell:77130]]** & **[[spell:370]]** **Mouseover Macro** - *macro if you wish to this macro makes it that if you target an enemy you purge if you target an ally you dispel. Save a keybind*

```wow-macro
/use [@mouseover, help, nodead] Purify Spirit; [harm] Purge; [noharm] Purify Spirit
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Restoration Shaman**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/CereShaman_Raid2-1024x496.jpg>)

**Restoration Shaman** Interface in Raids

:::accordion
:::details Addons
- **BigWigs** -- BossMods Addon
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **BetterCooldownManager** -- Cooldown Manager and Castbar
  
  - A cleaner version of the Cooldown Manager with the option to create extra Frames to track Abilities, Racials and Items. Also includes a cleaner Castbar and Resource trackers.
- **Unhalted Unit Frames** -- Unitframe Addon
  
  - Addon to replace your Unitframes (Player,Target,Focus,Boss...) with a more clean look.
  
  
  
  - Alternatively, you can also use BetterBlizzFrames.
- **Plater *-- Advanced Nameplates*** 
  
  - Cleaner and improved Nameplates for both enemy and allied units.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Hero Talents
  
  - Farseer
    
    - Chain Heal from Ancestors now bounces to up to 5 targets (was 3), loses 10% healing per target jump (was 30%), and had its jump distance increased to 20 yards (was 15 yards).
    - Chain Heal from Ancestors healing increased by 50%.
  - Totemic
    
    - Pulse Capacitor now increases the healing done by Surging Totem by 10% (was 25%).
    - Surging Totem now increases the effectiveness of Healing Rain by 10% (was 20%).
- Restoration
  
  - New Talent: Swelling Tides – Healing Stream Totem and Stormstream Totem extend the duration of your active Riptides by 3 seconds when cast.
  - Healing Wave healing increased by 10%.
  - Unleash Life healing increased by 100%.
  - Healing Rain healing increased by 20% and now heals up to 6 targets in its area (was 5).
  - Healing Rain now has a 12 second cooldown and an 18 second duration. Recasting Healing Rain while one is already active will despawn the previous one. This cooldown change does not affect the Surging Totem's Healing Rain from the Totemic Hero Talents.
  - Riptide direct healing increased by 25% and its periodic healing increased by 100%.
  - Acid Rain damage increased by 50%, but now causes damage every 2 seconds (was 1 second).
  - *Midnight* Season 1 2-set bonus has been updated – Unleash Life's direct healing is increased by 50% (was 100%).
  - Earthen Accord now grants an additive +20% to the healing buff from Unleash Life, rather than a multiplicative increase.
  - Current Control now also reduces the mana cost of Chain Heal by 15%.
  - Wavespeaker’s Blessing has been moved up in the talent tree.
  - Calm Waters has been removed.
- **Class** 
  
  - Reactive Warding healing increased by 25%.
  - Ascendance has a new icon for all three specializations.

:::

:::

## FAQ

:::accordion
:::details Q: How do [[spell:974]] and [[spell:1064]] interact?
A: Only the target that has [[spell:974]] receives increased healing regardless whether it's your initial [[spell:1064]] target or the last bounce

:::

:::

---

### Credits

Written By: Cere  
  
Reviewed By: Rycn

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1

**2026-06-16** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-02-21** Updated for patch 12.0.1

**2026-01-17** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-04** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-23** Updated for patch 11.1

**2025-01-05** Updated for patch 11.0.7.

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Guide Written for patch 11.0.2



:::
