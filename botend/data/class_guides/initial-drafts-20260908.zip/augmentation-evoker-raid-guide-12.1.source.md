Welcome to the **Augmentation Evoker** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Augmentation Evoker** Raiding Best in Slot
```json
{
  "source_code": "JAoAwDVwFc__BEQjkQggIEAAnk7AX16ACKgTBEQ6XQAAREAAE06AE06AMWjgCgVABsIJEIACBAwF5OggCgVABQgJEIAEBAQC5OggCwYNYFQAefBBAiQB0UwQAwYCvQQBqmwLIk8FEEgPAkSAvgjTBEAa7OAhIEAAYA8AnoaAkxyt1sUAB4IJEAACBAQB_AS2XQggAEAA3jbAeQhTBEgnqJQAkmAEFICBU9RGuAwVdwABdfRDYQBWBEA9iQQA2BwPBYHTYFQAJA8AEgQAAgXZDQqKEcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271499]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240900]] |
| 腿部 | [[item:271500]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:244009]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] | [[item:222584]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Augmentation** you have access to Duplicate which summons a duplicate of yourself to aid you after casting [[spell:403631]].

**Rank 1:** [[spell:403631]] summons a duplicate of you for 20s, it casts [[talent:115498@FAgARegBviiB]], [[spell:357208]] and [[talent:115502@FAgARegBviiB]].

**Rank 2 - (1/2):** Any time you extend [[talent:115496@FAQAviiB]], you also extend your duplicate at 50% of the amount.

**Rank 2 - (2/2):** Any time you extend [[talent:115496@FAQAviiB]], you also extend your duplicate at 100% of the amount.

**Rank 3:** While your duplicate is active, your [[talent:115496@FAQAviiB]] grants 100% additional stats and [[talent:115502@FAgARegBviiB]] and [[talent:115498@FAgARegBviiB]] deal 25% increased damage.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-augmentation-mxr.webp>)

Duplicate

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115496@FAQAviiB]]
    
    - Now targets all dps players in your raid/group so the targeted buffing is mostly done with [[talent:115675@FAQAmxkB]] for it's passive effect.
  - [[spell:459725]]
    
    - Was changed so that ranking up [[spell:357208]] doesn't give you more damage increase so you most often cast it at Rank 1 now.
    - With 12.0.5 this was completely replaced by [[talent:126305]].
- **Class Tree**
  
  - [[talent:115617]]
    
    - Previously an **Augmentation** only talent that got moved to the Evoker class tree, makes you safer while using [[spell:357210]]!
  - [[talent:115669]]
    
    - Removed as a separate spell and is now tied with [[talent:115613]] as a less powerful effect.
- **Moved**
  
  - [[talent:115690]] 
    
    - This was removed from the Class Tree and moved to the DPS Spec Trees to replace the cooldown reduction talent, which means that you now have to pick the talent point there to have an interrupt at all, rather than just having a longer cooldown interrupt.

## Hero Talents

- [[talent:123331]] performs better in constant big AoE situations while [[talent:123334]] is the stronger choice everywhere else.



### [[talent:123334]]

- [[talent:117552]] turns [[spell:370553]] into a strong offensive cooldown that increases your Haste and cooldown recovery rate.
  
  - The increased Haste, movement Speed and cooldown recovery rate buff effect is reduced by 1% every second throughout the 30s duration.
  - The total reduced cooldown of your abilities is 4.65 seconds.
  - Grants [[talent:115520]] every 6 seconds with [[talent:135742]].
- [[talent:117545]] transforms your normal [[spell:358267]] into a Blink
  
  - Be cautious as this has a small delay.
  - This currently only works when you are on or close to solid ground, if you are too high up in the air it will become a normal [[spell:358267]].

- When timed correctly [[talent:117532]] can be used as a minor defensive cooldown whenever you are out of everything else.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:135743]]
  
  - [[talent:115665]] cooldown is reduced by 30 seconds
- [[talent:135742]]
  
  - Improves [[spell:361469]].
- [[talent:135741@FJQAnxzENIA]]
  
  - [[talent:117551@FJQAnxzENIA]] maximum damage or healing is increased by 40%.




### [[talent:123331]]

- [[talent:122279]]
  
  - [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] and [[talent:115502]] changes your next [[talent:115498]] into a [[talent:122279]] that strikes multiple targets or deals increased damage for each target less than 3.
  - [[talent:122279]] can stack up to 2 which means you can cast both empower abilities back to back.
- [[talent:117533]] 
  
  - Gets applied to the target of your [[talent:122279]] casts.
  
  
  
  - [[talent:117533]] does not pandemic which allows you to cast two [[talent:122279]] in a row without losing debuff uptime.
  
  
  
  - This also maximizes [[talent:117550]] and allows you to bring down the cooldown of  [[talent:115536]] to a range of 60-90s depending on how many targets you are fighting.

- [[talent:120123]]
  
  - Restores one charge of [[spell:358267]].
  
  
  
  - This was nerfed to only restoring one charge instead of two in the **patch 12.0** so [[talent:117540]] can be a more viable option now in certain fights.

- [[talent:117538]]
  
  - Causes your [[talent:115536]] to always be aimed in front of your character and can now be steered.
  - This also makes [[talent:115536]] fly the entire duration unless you cancel it early by pressing the ability once more.
  - Be careful to not spam your [[talent:115536]] keybind as you might cancel it before it hits your target while still going on cooldown, I recommend casting it using a macro with /cast !Breath of Eons to make it non-cancellable and instead have /cancelaura Breath of Eons included in macros for your other spells for smoother gameplay.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:136053]]
  
  - While flying during [[talent:115536@FAQARegB]] 2 Dracthyr Commandos fly along you and damage nearby enemies with Pyres up to 8 times.
- [[talent:136052@AJQD]]
  
  - [[talent:122279]] hits 1 additional target.
- [[talent:136051]]
  
  - Essence abilities deal 15% additional damage.





## Talents



### [[talent:123334]]

:::talents [[talent:123334]] **Augmentation Evoker** talents in Raids
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### When to use this Spec

Used almost everywhere.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look, check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:115496]]
  
  - Your gameplay as an Augmentation Evoker revolves around optimizing and extending this buff.
- [[talent:115675]]
  
  - A rotational spell that buffs your target with Crit chance and some additional damage output.
  
  
  
  - Has a chance to grant [[talent:115520]] with [[talent:115523]].
- [[talent:115536]]
  
  - Your major offensive cooldown that applies a ~10 second debuff to targets hit by your breath which checks damage done by allies with your [[talent:115496@FAQAviiB]] during that time window and does burst damage based on that when the debuff expires.
- [[talent:115520]]
  
  - Causes a [[talent:115498]] cast to cost no essence, major synergies with [[talent:115688]] and [[talent:115506]].
- [[talent:126304@FAQAviiB]] and [[talent:115527@FAQAviiB]]
  
  - These talents juice up your [[talent:115536@FAgARegBviiB]] windows, granting reduced Essence cost for [[talent:115498@FAgARegBviiB]] and [[spell:390386]] for 15 seconds respectively.
- [[talent:115706]]
  
  - Your [[talent:115496]] buffed targets are given a shield based on their damage done during [[talent:115536]].
- [[talent:115528]]
  
  - [[talent:115498@FAgARegBviiB]] has a 25% chance to form a mote, allies that come in contact with said mote gain a buff listed below.
    
    - [[talent:115515]]
    - [[talent:115495]]
    - [[spell:413984]]
  - The chance gets increased to 35% and [[talent:115675@FAQAmxkB]] is applied to the buff pool when [[talent:115528]] is talented.
- [[talent:115533]]
  
  - A channeled spell that causes your cooldowns to recover at an increased rate, often "made passive" through the follow-up talent [[talent:115686]], which just gives overall 10% cooldown reduction.

##### Class Tree

- [[talent:115596]]
  
  - A movement ability that let's you grab a friendly player and move them and yourself swiftly to another position, often used for clearing movement impairing effects.
- [[talent:115661]]
  
  - Used to reduce AoE damage for you and 4 nearest allies, very impactful with the defensive cooldown pruning that happened across all classes for Midnight.
- [[talent:115665]]
  
  - Used to activate [[talent:117552]]
  - Used generally with [[talent:115502@FAgARegBviiB]].
- [[talent:115658]]
  
  - [[talent:116103]] buffs a friendly healer.
- [[talent:125610]]
  
  - A great utility tool to help out a healer during periods of heavy movement, can also be very important for increasing the range of your own spells in certain situations where it is needed. This is a choice node with [[talent:115666]], which might be needed by your raid.




### [[talent:123331]]

:::talents [[talent:123331]] **Augmentation Evoker** talents in Raids
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MmZmZbmZGM8AzMLzYMMDAAAAAAAAmZYMDGTNmZmBAAAAzYGjZmlxMDMzmxwsMDLjhZWGGMz0I2wMjZmZGAD",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MmZmZbmZGM8AzMLzYMMDAAAAAAAAmZYMDGTNmZmBAAAAzYGjZmlxMDMzmxwsMDLjhZWGGMz0I2wMjZmZGAD"
}
```
:::

#### When to use this Spec

Can be played in Mythic+ but performs significantly worse in Raids compared to [[talent:123334]].

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added** 
  
  - [[talent:115686]]
- **Removed** 
  
  - [[talent:115531]]

##### Class tree

- **No changes**

##### Hero Talents

Switched [[talent:123334]] to [[talent:123331]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:408092]] cooldown is reduced by 10 sec.
- **4-Set:** [[spell:408092]] magnifies your [[talent:115685]] effects for 8 sec, increasing the amount of damage echoed from 15% to 45%.

### Single-Target



#### [[talent:123334]]

##### Opener

:::rotation [[talent:123334]] **Augmentation Evoker Raid Opener**
```json
{
  "source_code": "JsGSNIAkHYAABEAiuOAAAAAAC8tPGUhBY-KKGAgACl3pFAAABk1HEAACBAggCgVACg1cFAAAC4_CGAAACFfLGIEOAAg_BoRCmwiQYegBAAAAAIEmHYA"
}
```
1. [[spell:395152]]  [[item:241288]]
2. [[spell:409311]]
3. [[spell:409311]]
4. [[spell:403631]]  [[spell:370553]] · [[item:270169]]
5. [[spell:357208]]
6. [[spell:396286]]
7. [[spell:404977]]
8. [[spell:409311]]
9. [[spell:409311]]
10. [[spell:396286]]
11. [[spell:357208]]
12. [[spell:395160]]
13. [[spell:395160]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:115496]] *- If refreshing, start cast at 5.5s or less remaining.*
2. Cast [[talent:115675]] - *with 2 charges.*
3. Cast [[talent:115665]] *- Use on [[spell:396286]] with the recommended build, Check Deep Dive section for additional tips.*
4. Cast [[spell:403631]]
5. Cast [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] *- Rank 1*
6. Cast [[spell:396286]] *Rank 1*
7. Cast [[spell:404977]] *- Use to get your abilities higher on the priority list back as often as possible in fights.*
8. Cast [[spell:395160]] - *with **2** stacks of [[spell:396187]].*
9. Cast [[talent:115675]] *- with 1 charge*.
10. Cast [[spell:395160]]
11. Cast [[talent:117551@AJQDCA]]




#### [[talent:123331]]

##### Opener

:::rotation [[talent:123331]] **Augmentation Evoker** opener in Raid
```json
{
  "source_code": "JcESJIAkHYAABEAiuOAAAAAAC8tPGUhB08KKGAQACl3pFAAACg1cBYAI-vgBAAgQYegBBwCLCh5BGAAAAAgQYegB"
}
```
1. [[spell:395152]]  [[item:241288]]
2. [[spell:409311]]
3. [[spell:409311]]
4. [[spell:403631]]  [[spell:370553]]
5. [[spell:357208]]
6. [[spell:396286]]
7. [[spell:395160]]
8. [[spell:395160]]
9. [[spell:395160]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:115496]] *- If refreshing, cast at 5.5s or less remaining.*
2. Cast [[talent:115675]] - *with 2 charges.*
3. Cast [[spell:403631]]
4. Cast [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] *- Rank 1*
5. Cast [[spell:396286]] Rank 1 *-- Use* [[talent:115665]] when available
6. Cast [[spell:395160]] - *with **2** stacks of [[spell:396187]].*
7. Cast [[talent:115675]] *- with 1 charge*.
8. Cast [[spell:395160]]
9. Cast [[spell:361469]]





## Deep Dive

### Tip the Scales usage

- [[talent:123334]]
  
  - With this hero spec [[talent:115665]]  is tied to [[talent:117552]] and should be used immediately on cooldown to maximize uptime of the buff.
  - With [[talent:126305]] build either use it on [[spell:396286]] if the cooldowns line up or just use a /cancelaura Tip the Scales macro to immediately cancel it so the cooldown starts progressing down.
  - With [[talent:115531]] build you ideally want to use it with [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] for instant [[talent:115657]] value but if the cooldowns don't line up use a /cancelaura Tip the Scales macro to immediately cancel it.
- [[talent:123331]]
  
  - Not a major ability on this hero spec, use only for instant empower casts while moving or to cast [[spell:396286]] faster.

### Shifting Sands and Prescience

- [[spell:413984]] is an **Augmentation Evoker** [[spell:406380]] effect which is a Versatility buff that you give out after casting an **Empower** spell, [[spell:357208]] or [[talent:115502@FAgARegBviiB]].
- Applies to the closest DPS player without an existing [[spell:413984]] buff (prioritizing your [[talent:115496@FAQAviiB]] targets, but with Midnight this is every DPS player in your party/raid almost always.)
- With the Ebon Might change, (proximity) targeting [[spell:413984]] and [[talent:115675@FAQAmxkB]] to players who are doing the most damage in any given situation are the only main optimizations left for Augmentation apart from your own (simple) rotation.
- Very high-end full optimized gameplay in raids still requires pre-planning with your [[talent:115675@FAQAmxkB]] targets and ideally trying to be nearby to players in their cooldown windows when casting Empower spells to get your [[spell:413984]] buff on them, but especially the proximity targeting is not always feasible mid-fight, on pull you should always try to stand next to the highest burst classes though.
- In many circumstances it is totally acceptable to just permanently target the highest performing DPS players in your group with [[talent:115675@FAQAmxkB]] and leave it at that!

### Rescue

- [[spell:370665]] is a great part of your toolkit as an **Evoker**, using it optimally requires fight awareness, especially in raids it can often save your less mobile allies from sticky situations.
- **12.0 Patch** has this change: 
  
  - [[spell:370888]] has been redesigned – [[spell:370665]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  
  
  
  - Means that [[spell:370665]] no longer has a defensive cooldown tied to it, but is even more potent as a movement ability!

### Hover

- Managing and timing your [[spell:358267]] uses correctly in combat to get more casts in while dealing with mechanics is where you see the biggest difference in your DPS as the actual rotational optimization is not that complex for **Augmentation Evoker**.
- Starting a cast of a spell such as [[talent:115498]] at the very end of a [[spell:358267]] buff still lets you finish that specific cast while moving. Keep this in mind to get more benefit from each use of [[spell:358267]]!
- Make sure you are tracking your uptime and charges of [[spell:358267]] on your UI. Get really comfortable with utilizing this ability as it is the most significant unique strength of an **Evoker**.
- With the **patch 12.0** [[spell:358267]] can now be used during normal casts (mostly [[spell:361469]] and [[talent:115498@FAQARegB]] on **Augmentation**) without interrupting them.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents [[talent:123331]] **Augmentation Evoker** Raid build for Nek'Zali
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Do not stand between the boss and your tank during [[spell:1284103]]!
- Pre-position on top of **Restless Amani** corpses slightly before [[spell:1294742]] to easier coordinate the clearing of them.




### Entombed Sentinels

:::talents [[talent:123334]] **Augmentation Evoker** Raid build for Entombed Sentinels
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Be active with stomping on [[spell:1284434]] whenever they spawn, use a defensive cooldown if soaking a lot in a row.
- Spread out and prepare to solve [[spell:1284590]] when the bosses reach 100 energy, this is the key mechanic of the fight and main wipe cause so really focus on this!
- You can hit [[talent:115536@FAQARegB]] on both of the bosses on pull and after [[spell:1284590]] have been solved.




### Lost Explorers

:::talents [[talent:123334]] **Augmentation Evoker** Raid build for Lost Explorers
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Keep track of the [[spell:1296062]] casts and check which direction they are being shot at.
- You can dispel the **Bleed** debuff from soaking [[spell:1291934]] with [[talent:115602]] so try to soak a bunch and dispel yourself afterwards or look out for other players with high stacks.
- Be very careful not to trigger the **Bouncy Mushrooms** from [[spell:1292105]] too early before the [[spell:1296235]] as this makes them disappear after a short while.




### Vashnik

:::talents [[talent:123334]] **Augmentation Evoker** Raid build for Vashnik
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Pre-spread for [[spell:1281907]] for less confusion and try not to shoot towards the melee camp.
- Use a defensive cooldown when the **Burning Venoms** explode.
- Be active with soaking any player afflicted with [[spell:1295224]].




### Sszorak

:::talents [[talent:123331]] **Augmentation Evoker** Raid build for Sszorak
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Remember that you can easily cancel the knockbacks from [[spell:1285419]] and [[spell:1287008]] with [[spell:358733]].
- [[talent:115666]] is great during [[spell:1285732]] for your raid to optimize dps.
- Really focus on [[spell:1305959]] whenever it happens, it's crucial to know exactly where to go if you get targeted.
- You can dispel anyone hit by [[spell:1287072]] with either [[spell:365585]] or [[talent:115602]].




### Twin Fangs

:::talents [[talent:123331]] **Augmentation Evoker** Raid build for Twin Fangs
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Keep good track of your [[spell:1290336]] stacks throughout the fight.
- Don't move around too much if targeted by [[spell:1291478]] and try to move along the line if absolutely needed.
- Look out for the waves from  [[spell:1290956]] whenever they are up, they can catch you off-guard especially during the knockback from [[spell:1290516]].
- When **Vexhul** submerges and appears in the middle of the arena to cast [[spell:1294293]] look at the small green orbs around him that indicate the rotation direction to determine if you should dodge left or right (you should dodge "against" the rotation.)




### Coiled Altar

:::talents [[talent:123331]] **Augmentation Evoker** Raid build for Coiled Altar
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Help out with moving and stacking up [[spell:1282403]] as needed.
- After each [[spell:1285643]] check if you get fixated by any of the spawned ghosts and if you do, really focus on maneuvering it to the intended tank cleave spot for getting rid of it.
- Interrupt the [[spell:1286399]] from **Spiteful Soulcoilers**.
- Use [[talent:115613]] if targeted by [[spell:1286895]] and remember to pick-up your souls afterwards!




### Ula'tek

:::talents [[talent:123334]] **Augmentation Evoker** Raid build for Ula'tek
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Defeat the angry ancient snake.




### Nymrissa Wavecaller

:::talents [[talent:123334]] **Augmentation Evoker** Raid build for Nymrissa Wavecaller
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### Boss Tips

- Rotate [[spell:363916]] and [[spell:374227]] when available for when [[spell:1281393]] are cleared.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Augmentation Evoker**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.



### [[talent:123334]]

:::priority [[talent:123334]] Augmentation Evoker  Stat Priority in Raids
```json
{
  "source_code": "JoAJFUQMgQCKBEgAEA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＝ 急速 ≫ 全能**
:::




### [[talent:123331]]

:::priority [[talent:123331]] Augmentation Evoker Stat Priority in Raids
```json
{
  "source_code": "IoAJFUAIkEDKBMABBA"
}
```
**智力 ＞ 暴击 ≥ 急速 ≫ 精通 ＞ 全能**
:::





:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing. Most of your damage comes from buffed players, thus it becomes not optimal.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271501@DiQAAEcBnk7cVrjgC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAsbBE06QQrDj1IoAYFA]] | Ula'tek |
| Shoulder | Catalyst [[item:268231@AgQAAIoAYFA]]  <br>into [[item:271499@DgQAAEcBXk7IoAYF]] | Coiled Altar / Catalyst |
| Cloak | [[item:268253@BgQAAsbBCKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DARAAsbBJk7IoAMWDWB]] | Ula'tek |
| Wrist | [[item:244584@FiQAAsbBYA8ciqDBtO3WzSB]] | Crafting |
| Gloves | [[item:271502@BgQAAEcBCKgTBA]] | Tier / Catalyst |
| Belt | [[item:268254@BiQAAEcBE06IoAOF]] | Vashnik |
| Legs | Catalyst [[item:268237@AgQAAIoAYFA]]  <br>into [[item:271500@DgQAAEcBFo6IoAYF]] | Coiled Altar / Catalyst |
| Boots | [[item:268233@DgQAAsbBpk7IoAOF]] | Sszorak |
| Ring 1 | [[item:268249@DCQAAEcB3j7QQrjTBA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAEcB3j7QQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAsbBCKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAEcBCKgTBA]] | Altar of Fangs |
| Weapon | [[item:271092@DgQAAsbB_k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@FgQAAsbB4V2QqK0t1sUA]] | Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAAsbBCKQQBA]] | King's Rest |
| Cloak | [[item:251132@BgQAAsbBCKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAAsbBCKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAAsbBCKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAsbBCKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250224@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Trinket 2 | [[item:273796@BgQAAsbBCKQQBA]] | Altar of Fangs |
| Weapon | [[item:193761@BgQAAsbBCKQQBA]] | Ruby Life Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270164@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **B-Tier** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]] |

### Embellishments / Crafting

- With your first 4 [[item:274476]] it is recommended to craft [[item:245770@CARAAgBwDAAcbNLF]] as it is very efficient usage of your mythic crests!

For end game optimized crafted gear you should have:

- 1x [[item:240167]]
  
  - The optimal slot to craft on is **Wrist**, **Back, Boots** or **Waist** depending on your available gear.

- 1x [[item:273060]]
  
  - Great embellishment if you are using a crafted weapon or off-hand.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, it is not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

- **DO NOT** use Stat Weights Sims, they only affect your personal damage. As such, you won't be given relevant results.
- Use only Top Gear and Droptimizer.
- RDPS or "Raid DPS" is the damage dealt by your entire group. This is done because Augmentation is a support that buffs other DPS therefore they are required for it to operate. Due to this and a few factors mentioned below, sims do not output the contribution of the Augmentation Evoker individually and can only provide comparisons. Thankfully, comparisons are all you need to optimize gear or talent choices.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
- **Food**
  
  - [[item:255845]]
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] *-- a big burst of healing - upgraded version from 12.1*
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *- You can only have one Eversong Diamond socketed in your gear.*
  - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:275707]]  <br>[[item:244007]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsbB]] |
| Chest | [[item:243977@BAAAAsbB]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:240133@BAAAAsbB]] |
| Boots | [[item:244009@BAAAAsbB]] |
| Ring 1 | [[item:243959]] |
| Ring 2 | [[item:243959]] |
| Weapon | [[item:244031@BAAAAEcB]] |

:::

:::column
:::gear **Augmentation Evoker** Enchantments in Raids
```json
{
  "source_code": "JQFZBXQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB3jbCYgy94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Macros

Discover recommended macros for **Augmentation Evoker** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[talent:115536]] -- *Casts [[talent:115536]] on your cursor without confirmation.***

```wow-macro
#showtooltip 
/cast [@cursor] Breath of Eons(Bronze)
```

:::

:::details Mouseover Macros
**[[talent:115675]] -- *Uses [[talent:115675]]* on your mouseover or your target.**

```wow-macro
#showtooltip Prescience
/cast [@mouseover,help,nodead][] Prescience
```

**[[talent:115602]] -- *Uses [[talent:115602]]* on your mouseover or your target.**

```wow-macro
#showtooltip Cauterizing Flame(Red)
/cast [@mouseover,help,nodead][] Cauterizing Flame(Red)
```

[[talent:115666]] and **[[talent:125610]] -- *Uses [[talent:115666]]* or *[[talent:125610]]* on your mouseover.**

```wow-macro
#showtooltip
/cast [known:374968] Time Spiral; [@mouseover] Spatial Paradox
```

**[[talent:115508]] -- *Uses [[talent:115508]]* on your mouseover or your target.**

```wow-macro
#showtooltip Blistering Scales
/cast [@mouseover,help,nodead][] Blistering Scales
```

:::

:::details Generic and Cancelaura macros
**[[spell:403264]]** ***-- Removes the need for manually casting [[spell:403264]] and if playing [[talent:123331]]** allows you to cancel [[talent:115536@FAgARegBviiB]] early**.***

```wow-macro
#showtooltip Eruption
/cast [nostance:1] Black Attunement
/cancelaura Breath of Eons
/cast Eruption
```

**[[talent:115665]]** Cancelaura -- *Casts [[talent:115665]] on first press and cancels the buff on second press.*

```wow-macro
/cancelaura Tip the Scales(Bronze)
/cast Tip the Scales(Bronze)
```

:::

:::details Utility Macros
**[[spell:370665]] Mouseover -- *Casts [[spell:370665]]* on your focus target with the end position being your cursor.**

```wow-macro
#showtooltip Rescue
/tar [@focus]
/cast [@cursor] Rescue
/targetlasttarget
```

**[[spell:370665]] Mouseover -- *Casts [[spell:370665]]* on your target with the end position being your cursor.**

```wow-macro
#showtooltip 
/cast [@cursor] Rescue
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Augmentation Evoker**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![Augmentation Evoker Interface in Raids](<https://assets-ng.maxroll.gg/wordpress/AugmentationRaidMidnightUI-1-1024x617.webp>)

**Augmentation Evoker** Interface in Raids

:::accordion
:::details Addons
- **BetterCooldownManager / BCDM** *--* Cooldown Manager customization
  
  - Provides additional customization to the Cooldown Manager.
- **Unhalted Unit Frames / UUF** *-- Unit frame addon* 
  
  - Adds custom player, target and boss frame customization.
  - Alternatively, you can also use ElvUI
- Plater -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking and threat coloring.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Bartender4** -- Action Bar addon
  
  - Replacement for the default action bars, allowing more customization and extra options.
- **RaidFrameSettings / RFS** -- Blizzard Raid frames customization
  
  - Provides additional customization to the default Blizzard raid frames.
- **NorskenUI** *-- Collection of Skinning, QoL and Features.*
  
  - One of the many "collection" addons available with multiple quality of life improvements, UI skinning and other useful functionalities.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Evoker**

- Panacea healing increased by 25%

**Hero Talents**

- **[[talent:123333]]**
  
  - *Developers’ notes: Wingleader’s cooldown reduction mechanic strongly incentivized spreading Bombardment applications across multiple targets. We feel that this gameplay is unintuitive in isolation, and additionally creates unhealthy behaviors such as Disintegrate clipping and Mass Disintegrate/Eruption pooling. This redesign is intended to retain the multitarget focus of the talent, while addressing those issues. We are increasing some of Scalecommander’s sources of area damage to compensate for the lessened cooldown reduction the new Wingleader will provide.*
  
  
  
  - Wingleader has been redesigned – Mass Disintegrate/Mass Eruption reduces the remaining cooldown of Deep Breath/Breath of Eons by 0.5 seconds/1 second for each target struck.
  - Command Squadron’s Pyre damage increased by 40%.
  - Maneuverability’s damage over time increased by 40%.

**Augmentation**

- *Developers' notes: The additional stopping power created by Duplicate-cast Upheavals was more warping to dungeon gameplay than desired, and could be frustrating in some situations due to its uncontrolled timing.*
- Apex Talent: Duplicate – Upheaval casts by your Duplicate no longer knock enemies into the air.
- All ability and pet damage increased by 3%.
- Living Flame healing increased by 25%.
- Verdant Embrace healing increased by 25%.
- Emerald Blossom healing increased by 25%.
- Defy Fate healing increased by 25%.
- Molten Blood healing increased by 25%.
- The *Midnight* Season 1 2-set bonus no longer increases the duration that Eruption extends Ebon Might.
- **Hero Talents**
  
  - **[[talent:123334]]**
    
    - Double-time has been updated - The additional stats granted when Ebon Might critically strikes now last 15 seconds (modified by Mastery: Timewalker), and Double-time is extended if Ebon Might reapplies it while it is already active. Double-time's functionality with Prescience is unchanged.
  
  
  
  - **[[talent:123333]]**
    
    - Wingleader now reduces the cooldown of Breath of Eons by 1.5 seconds per target struck (was 1 second).

:::

:::

:::accordion
:::details Patch 12.0.5
**Evoker**

- New Ability: Battle Visage – Activate to automatically assume your Visage whenever you are not casting draconic spells such as Fire Breath and Soar.
  
  - Full list of abilities that temporarily shift you to Dracthyr: Deep Breath, Dream Flight, Breath of Eons, Fire Breath, Eternity Surge, Dream Breath, Upheaval, Hover, Spatial Paradox, Rescue, Zephyr, Verdant Embrace (without Dream Simulacrum talented), and Soar.
  - Many abilities that used to force a shift to Dracthyr have adjusted visual treatments for Visage form.
  - While active, Battle Visage also applies a camera height override to Dracthyr form to prevent the camera from adjusting rapidly when shifting between forms.
- Unravel damage increased by 300%.
- Blessing of the Bronze is now castable on friendly players who are not in your party or raid group, similar to other group buffs like Arcane Intellect.
- Fixed an issue where Twin Guardian was applying its bonus at the start of Rescue rather than upon landing.

- Augmentation
  
  - New Talent: Mighty Inferno – Inferno’s Blessing’s damage is increased by 40%, and your effects that extend Ebon Might also extend Inferno’s Blessing.
  - Inferno’s Blessing will now correctly always apply to the casting Evoker, and will no longer apply to pets.
  - Regenerative Chitin has a new icon.
  - Molten Embers has been removed.
  - **[[talent:123334]]**
    
    - New Talent: Chronal Dynamo – Living Flame’s cast time is reduced by 0.2 seconds, and it deals 50% increased damage or healing when it is a non-instant cast.
    - Energy Cycles has been removed.

:::

:::

:::accordion
:::details Patch 12.0.1
**Evoker**

- [[spell:357208]] total damage, instant and periodic, should now be consistent at all Empower ranks, with all combinations of Fire Breath-affecting talents.
- [[talent:115663]] healing increased by 60%.

- **Augmentation**
  
  - [[spell:395152]] can no longer be aura canceled.
  - [[spell:395152]] extension range now matches [[spell:395152]] application range.
  - [[spell:361021]] now dynamically updates its duration if a cooldown is extended.
  - [[spell:361021]] and [[talent:115675]] have been updated to correctly detect all major throughput cooldowns, and will no longer activate on tank or healer specializations.
  - [[talent:115655]] healing increased by 50%.
  - [[spell:355913]] healing increased by 50%.

:::

:::

:::accordion
:::details Patch 12.0
**Evoker**

- **[[talent:123334]]**
  
  - New Talent: [[talent:135743]] – [[talent:115665]] cooldown is reduced by 30 seconds.
  - New Talent: [[talent:135741@AJQDCA]] – [[talent:117551@AJQDCA]] maximum damage or healing is increased by 40%, up to 350%.
  - New Talent: [[talent:135742]] – [[talent:117552@AJQDCA]] grants [[spell:392268]] every 6 seconds.
  - New Talent: [[talent:117544@AJQDCA]] – [[talent:115675]] cooldown reduced by 2 seconds and it grants 1% additional critical strike chance.
  - [[talent:117539@AJQDCA]] has been redesigned – Now increases the duration of [[talent:115675]] by 15%.
  - Threads of Fate has been removed.
- **[[talent:123333]]**
  
  - New Talent: [[talent:136053]] – While flying during [[talent:115536@FAQARegB]] or [[spell:357210]] you are assisted by a squadron of Dracthyr who assault enemies with Pyre, dealing Fire damage to nearby enemies up to 8 times.
  - New Talent: [[talent:136052@AJQD]] – [[talent:117536]] or [[talent:122279]] strikes 1 additional target.
  - New Talent: [[talent:136051]] – Essence abilities deal 15% more damage.
  - [[talent:120123]] now grants a charge of [[spell:358267]] instead of granting full charges.
- Class
  
  - New Talent: [[talent:115617]] – While flying during [[talent:115536@FAQARegB]] or  [[spell:357210]], 100% of damage you would take is instead dealt over 10 seconds.
  - New Talent: [[talent:136560]] – [[spell:358733]] speed and height increased by 10%.
  - New Talent: [[talent:115620]] – Your [[spell:361469]] and [[spell:367979]] are 30% more effective on yourself.
  - [[talent:115595]] has been redesigned – [[talent:115596]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  - [[talent:115669]] has been redesigned – Now upgrades [[talent:115613]], causing it to heal you over 8 seconds equal to the amount of damage it reduced.
  - [[talent:115616]] has been redesigned as a passive effect – [[spell:357208]] consumes absorb shields from enemies, dealing additional Spellfrost damage to them.
  - [[spell:362969]] damage increased by 50%.
  - [[talent:115657]] now changes the icon for [[spell:361469]] while active.
  - Fixed an issue where [[spell:357208]] could engage enemies if the player died and resurrected while it was active.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - [[spell:375577]]
    - [[talent:115645]] (moved to the Augmentation and Devastation talent trees
- Augmentation
  
  - New Talent: [[talent:115528]] – [[talent:115531]] may now grant [[talent:115675]] to allies and have a 10% increased chance to activate.
  - New Talent: [[talent:115493]] – [[talent:115522]] healing increased by 100% and its cooldown is reduced by 1 minute.
  - [[talent:115511]] has been redesigned – [[talent:115508]] no longer loses charges and deals 20% more damage.
  - [[talent:126304]] has been redesigned – [[talent:115536@FAQARegB]] reduces the Essence cost of your next 6 [[talent:115498@FAQARegB]] by 1.
  - [[talent:126305]] has been redesigned – Enemies affected by [[spell:357208]] damage over time effect take 25% increased damage from your Black spells.
  - [[talent:115690]] is now learned in the Augmentation specialization tree (was a class talent).
  - [[talent:115496]] now grants 8% primary stat (was 5%).
  - [[talent:115496]] is now applied to all damage dealing allies within 100 yards.
  - [[talent:115496]] now splits its effect when applied to more than 2 other allies and is no longer is limited to 2 maximum applications.
  - [[spell:409560]] now reduces its effect when [[talent:115496]] is applied to more than 2 allies.
  - [[talent:115536@FAQARegB]] debuff [[spell:409560]] is now visible to all allies, and indicates how much damage it accumulates on the aura tooltip.
  - [[talent:115536@FAQARegB]] accumulates 15% of damage (was 10%).
  - All spell and ability damage reduced by 23%.
  - Damage dealt by pets and minions reduced by 15%.
  - [[talent:115522]] healing increased by 100%.
  - [[talent:115510]] absorption increased by 30%.
  - [[talent:115495]] now only targets you and 1 nearby ally (was all allies with [[talent:115496]]). New visual of a flame sprite added to represent the blessing.
  - [[talent:115495]] damage increased to 350% spell power (was 88% spell power).
  - [[talent:115688]] now increases the damage of [[talent:115498@FAQARegB]] by 20%.
  - The cooldown manager has been updated to reflect changes made to Augmentation and can now be used to track the duration of [[spell:357208]], [[talent:115536@FAQARegB]], and [[talent:117533@AJQDCA]] on targets.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed: 
    
    - [[spell:371016]]
    
    
    
    - [[talent:115620]] *(moved to the* *class* *talent tree)*
    
    
    
    - [[spell:1219236]]
    - [[talent:115617]] *(moved to the* *class* *talent tree)*

:::

:::

## FAQ

:::accordion
:::details Q: Do you play around [[spell:408004]]?
Yes, you want to attempt to snipe gaining [[talent:115520]] for [[talent:115506]] as more often than not you don't lose anything by attempting to do so.

F.e. If you end up with 2x [[talent:115520]] and 6 essence you want to

- Cast [[talent:115498]] with [[talent:115520]]
- Cast [[talent:115498]] with [[talent:115520]]
- Cast [[talent:115498]]  
  Cast [[spell:361469]] attempting to snipe an [[talent:115520]] for a [[talent:115506]] extension

:::

:::

---

### Credits

Written By: **fraggo**

Reviewed by: **Ftm**

---

:::changelog 更新记录
**2026-08-06** Updated for 12.1

**2026-06-16** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-22** Updated for Midnight Launch

**2026-02-10** Updated for patch 12.0.1

**2026-01-15** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-04** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-18** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7.

**2024-10-23** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
