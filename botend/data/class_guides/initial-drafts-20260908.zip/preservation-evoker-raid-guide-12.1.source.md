Welcome to the **Preservation Evoker** Raid guide for the World of Warcraft patch 12.1.0! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 5/5 · Excellent

Cooldown Strength · 5/5 · Excellent

Utility · 4/5 · Strong

Survivability · 3/5 · Average

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Preservation Evoker** Raid Best in Slot Gear
```json
{
  "source_code": "J4oAIybB3_fAB0IJEIICBAw74OwVtOggC4UABk-FEAQEBAgAtOgABIBiMWDWBEwikQgAIUAA1k7ACKAWBc8FEEABmQgAQEAAJk7AMWTAUQRATU9AAiQB3UgRAwYCyQwGqWgMQ18FEEQY7OgBgEAAeA8Ano6APk7AAUQAkcbNLFQAot7AEiQEbggAtOQBVghjkQAAIEAAF4EBZfRBmSw94GgHFIBCeqmABgbHSQAVfkBMAcVHMQQ3X0AGogVABQvIEIACBAQPJgMLBc-FEAACBAggC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271499]] | [[item:244021]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:251155]] | [[item:240898]] |
| 腿部 | [[item:271500]] | [[item:240155]] |
| 脚部 | [[item:244577]] | [[item:245790]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:268263]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Preservation Evoker**, you have access to [[spell:1256577]], which gives your essence abilities a chance to turn your next [[spell:366155]] into an empowered version.

**Rank 2** of this hero talent gives all your [[spell:367364]] buffs an effect that heals them based off of the damage they take. While **Rank 3** enables that your [[spell:355936]] has 100% chance to empower your next reversion and its initial healing is buffed by 125%

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-preservation-mxr.webp>)

Merithra's Blessing

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:373267]]
    
    - This talent used to have the ability to have multiple applications out due to it applying from copied [[spell:360995]] hits. This is no longer an option and removes the ability for large lifebind ramps.
  - [[spell:1242031]]
    
    - A new talent that synergises well with our tierset as it just gives you a lot of value through gaining an additional [[spell:364343]] every time you press [[spell:360995]].
  - [[spell:373834]]
    
    - This talent was changed and no longer has any interaction with [[spell:360995]] and this makes it so the ability can be cast a lot more freely and isnt tied to buffing [[spell:355936]].
- **Class Tree**
  
  - [[spell:374348]]
    
    - This ability was changed from an active button and is now baked into your [[spell:363916]] and is a lot weaker overall.
  - [[spell:410352]]
    
    - This new talent is a nice niche defensive option against very large hits and potential one shots.
  - [[spell:370889]]
    
    - This talent used to give an absorb shield, now it gives a cast while moving effect to you and your ally.
  
  
  
  - [[spell:370665]]
    
    - This talent got an added effect of removing movement impairing effects from you and your ally.
- **Removed**
  
  - [[spell:367226]] 
    
    - This ability was never a big part of our healer in raids, but it was a nice filler for when you were out of options and needed something small to fill a gap. Especially in scenarios where your raid is split into smaller groups
  - [[spell:370960]]
    
    - This ability was usually used in combination with [[spell:373267]] and having the healing copy to a majority of the raid.
  - [[spell:443328]]
    
    - This hero talent ability made up a lot of our burst healing in the last expansion. The removal of it has removed most of our 1 button option to heal everyone in the raid for a large burst.

## Hero Talents

- [[talent:123335]] buffs a lot of your healing abilities and turns [[talent:115665]] into a strong cooldown.
- [[talent:123332]] also buffs a lot of your healing abilities and gives you 2 charges of [[spell:363922]] and [[spell:357208]]. Additionally it makes [[spell:360995]] and [[spell:355913]] consume a portion of your [[spell:363922]] heals over times for additional healing.
- Overall I recommend playing [[talent:123332]] because it is very strong right now with all the buffs to your healing abilities, the build will focus around your apex talent and getting consistent value out of your tierset. So this guide will focus on playing that build.



### [[talent:123332]]

- [[spell:1264269]]
  
  - [[spell:363922]] and [[spell:357208]] now have an additional charge.
- [[talent:117534]]
  
  - [[spell:358267]], [[spell:357210]] and [[spell:359816]] travels 40% faster, [[spell:358267]] also travels 40% further.
- [[talent:117546]]
  
  - Critical Strike Chance against targets above 50% health increased
- [[spell:1264365]]
  
  - The cooldown of  [[spell:357208]] is reduced by 5 seconds.
- [[spell:1264321]]
  
  - [[spell:357208]] damage over time effect lasts 4 seconds longer and [[spell:363922]] heal over time effect lasts 6 seconds longer.
- [[spell:1218447]]
  
  - [[spell:363922]] and [[spell:357208]] deal their damage and healing more often

- [[talent:117543]]
  
  - [[spell:363922]] and [[spell:357208]] now reach their maximum empowerment charge faster.
- [[talent:123767]]
  
  - [[spell:357208]] damage over time and [[spell:355936]] heal over time is increased.
- [[talent:117517]]
  
  - [[spell:361469]] have an extra chance to give you [[spell:369297]] when they Crit.
- [[talent:117528]]
  
  - Allows you to use [[talent:115669]] as an external if the situation requires it.
- [[spell:1265993]]
  
  - [[spell:363922]] and [[spell:357208]] have a 50% chance to grant [[spell:359565]].
- [[spell:1265979]]
  
  - Consuming [[spell:359565]] does an extra burst of healing to your target.
- [[spell:1265992]]
  
  - [[spell:1265979]] bounces to up to 2 extra targets.
- [[talent:117519]]
  
  - Through casting [[spell:355913]] or [[spell:360995]] on targets with [[talent:115542]] you now consume a portion of the heal over time effect to do additional healing.




### [[talent:123335]]

- [[talent:117551]]‍ 
  
  - Makes your [[spell:361469]] turn into [[spell:431442]] which is a Bronze spell, which will give you stacks towards [[talent:115543]], and will repeat 15% of the damage or healing you dealt to the target in the last 5 seconds.
- ‍[[talent:117545]] transforms your normal ‍Hover into a [[spell:1953]]
  
  - This currently only works when you are on or close to solid ground, if you are too high up in the air it functions like a normal [[spell:358267]]. Be cautious, as this has a small delay.
- [[talent:117552]]
  
  - Turns ‍your [[talent:115665]] into a strong cooldown, increasing Haste, Movement Speed, and Cooldown recovery rate by 30%, decreasing by 1% every second during the 30s duration of ‍[[talent:117552]].
- [[spell:1260484]]
  
  - The cooldown of [[talent:115665]] is reduced by 30 seconds.
- [[talent:117522@AJQDBA]]
  
  - [[spell:360995]] heals for an additional 60% over 8 seconds.
- [[talent:117532]]
  
  - If timed correctly [[talent:117532]] can be very strong as a minor defensive cooldown whenever you are out of everything else.
- [[spell:431715]]
  
  - [[spell:373861]] mana cost reduced by 15% and cooldown reduced by 4 seconds.
- [[talent:117548@AJQDBA]]
  
  - Gain haste for each heal over time effect you have out from [[spell:360995]] up to 3.
- [[talent:117529]]
  
  - [[spell:355936]] and [[spell:357208]] duration is extended by 2 sec, up to 12 sec, when they Crit.
- [[talent:126310]]
  
  - Your empowered spell gets reduced by up to 6 sec when you cast it.
- [[spell:1260647]]
  
  - Empowers [[spell:431442]] making it do more damage and healing by up to 40%.
- [[talent:117539@AJQDBA]]
  
  - [[spell:364343]] lasts 10% longer.
- [[talent:117526]] 
  
  - Each time you cast an empowered spell, up to 3 targets that you hit additionally get a [[talent:117551]]‍ cast onto them.





## Talents



### [[talent:123332]]

:::talents **Preservation Evoker** Chronowarden Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### When to use this Spec

This is the [[talent:123332]] loadout going into any encounter. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Raid section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:363534]]
  
  - Heal 33% of the damage taken in the last 5 seconds.
- [[spell:357170]]
  
  - Your external cooldown staggers 50% of the damage taken over the next 8 seconds.
- [[spell:370537]]
  
  - Duplicate and store your next 3 healing spells. the following order of spells is the recommended abilities to copy for your stasis uses. [[spell:355936]] [[spell:373861]] [[spell:364343]]
- [[talent:115573]]
  
  - Take a deep breath and fly over your allies to heal them and give them a hot for 15 seconds.
- [[spell:1242031]]
  
  - This talent gives you additional [[spell:364343]] and synergises with the [[spell:355913]] that gets placed from your tier set whenever you cast [[spell:360995]]

##### Class Tree

- [[spell:374227]]
  
  - Reduce damage taken from AoE effects by 20% for all allies within 20 yards for 8 seconds, also increase movement speed by 30%.
- [[spell:370553]]
  
  - Makes your next Empowered spell cast instantly at maximum rank. And gives you a good chunk of [[spell:359565]] buffs through your hero talent [[spell:431695]]
- [[spell:374251]]
  
  - Unique dispel that removes bleeds, in addition to poisons, curses, and diseases.
- [[spell:374968]]
  
  - Gives you and your allies a free charge of your major movement cooldown, in your own case this ability is [[spell:358267]].

##### Hero Talents

- [[talent:117532]]
  
  - If timed correctly [[talent:117532]] can be very strong as a minor defensive cooldown whenever you are out of everything else.
- [[talent:126310]]
  
  - Your empowered spell gets reduced by up to 6 sec when you cast them. This makes your [[spell:355936]] naturally line up with [[spell:373861]] and allows you to copy a lot more [[spell:1256581]]





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: Consuming [[spell:369297]] sends forth a [[spell:361469]] at your target at 100% effectiveness, or a nearby injured target if they are at full health.
- **4-Set**: Green spells restore 5% more health, and [[spell:360995]] has a 100% chance to grant [[spell:369297]]



#### [[talent:123332]]

##### Priority List

###### For Healing

1. Cast rank 1 [[spell:355936]] if you dont have a proc of [[spell:1256581]]
2. Cast [[spell:360995]] with no [[spell:364343]] currently out to gain [[spell:369297]]
3. Cast [[spell:373861]] to apply [[spell:364343]].
4. Cast [[spell:1256581]] if any [[spell:364343]] are about to run out.
5. Cast [[spell:366155]] before any [[spell:364343]] runs out.
6. Cast [[spell:355913]] if you have an [[spell:369297]] proc to benefit from [[spell:1242031]]
7. Spend Essence on [[spell:364343]].
8. Cast [[spell:1256581]]
9. Cast [[spell:366155]]
10. Cast [[spell:360995]] for an immediate targeted heal
11. Cast [[spell:361469]] or [[spell:382266]] to gain [[spell:369297]] for free [[spell:355913]] casts that proc [[spell:1242031]].

###### For Damage

1. Cast [[spell:382266]] on cooldown.
2. Cast [[spell:361469]].

##### Cooldowns

###### Dream Flight

- Fly over your allies and apply a HoT as well as direct healing, during this time you are immune to any movement and loss of control effects, you can use this for movement around a encounter, break roots, or simply as a decent healing cooldown, be careful to not fly into frontals or other boss mechanics that can get you killed!

###### Time Dilation

- [[spell:357170]] is your go-to external whenever an ally is in danger.

###### Stasis

- [[spell:370537]] is a powerful cooldown in raids, offering significant utility. You should default to copying 2 charges of [[spell:355936]] and [[spell:373861]] when you use this ability.
- Additionally whenever it makes sense for the fight you can spend a significant portion of time to prepare a [[spell:370537]] with 2-3 uses of [[spell:373861]] stored up to cover a majority of the raid with [[spell:364343]]. These echoes can be spent on either [[spell:355936]], [[spell:366155]] or [[spell:360995]]
  
  - Do this pre-pull whenever there's a healing requirement early in the fight.

###### Tip the Scales

- [[spell:370553]] is great for on-demand burst healing when used with[[spell:355936]] or for casting [[spell:382266]] without having to spend the time channeling to the max rank.

###### Rewind

- [[spell:363534]] is the strongest cooldown Evoker has by far and can single-handedly salvage almost any dangerous situation. Due to its massive cooldown it's best to carefully plan when you want use it.





## Deep Dive

#### Min maxing Rewind

- The more damage you have taken, the more healing [[spell:363534]] does. Try and hold off using it so your raid takes as much damage as possible but instantly cast it if someone drops below 30% hp. Don't let anyone die by greeding this cooldown!

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Preservation Evoker** Nek'Zali Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1287322]] at the edge of the room!
- Do not be inbetween the boss and the tank when the boss casts [[spell:1284103]].




### Entombed Sentinels

:::talents **Preservation Evoker** Entombed Sentinels Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- Dispel players affected with [[spell:1284471]].
- [[spell:1284590]] is neutralized harmlessly upon reaching exactly 4 stacks.




### Lost Explorers

:::talents **Preservation Evoker** Lost Explorers Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1286921]].




### Vashnik

:::talents **Preservation Evoker** Vashnik Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- External players affected with [[spell:1295224]]. While affected, they are immune to your regular healing.
- Use a personal defensive when affected by [[spell:1294994]].




### Sszorak

:::talents **Preservation Evoker** Sszorak Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- External people with [[spell:1286987]].




### Twin Fangs

:::talents **Preservation Evoker** Twin Fangs Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- Defensives
  
  - Use a personal defensive when affected by [[spell:1290809]].




### Coiled Altar

:::talents **Preservation Evoker** Coiled Altar Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.




### Ula'tek

:::talents **Preservation Evoker** Ula'tek Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.




### Nymrissa Wavecaller

:::talents **Preservation Evoker** Nymrissa Wavecaller Raid Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

#### Boss Tips

- Use a personal defensive when many [[spell:1257717]] get popped.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Preservation Evoker**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Preservation Evoker** Raid Stat Priorities
```json
{
  "source_code": "IoAJFUQMgQCKBEQABA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- Blizzard introduced Stat drs, which you should be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self-healing)
- **Speed** - Increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has **Leech** or **Avoidance**. **Speed** is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful **Leech** is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/PresEvokerBreakdown-1024x342.png>)

**Preservation Evoker** healing breakdown from Warcraftlogs

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271501@DiQAAwbBvj7cVrjgC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAwbBC06IQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:268231@DgQAAwbB1k7IoAYF]] Catalysed into [[item:271499@DgQBAwbB1k7IoAYFwxXQ]] | Coiled Altar |
| Cloak | [[item:268253@BgQAAwbBCKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DARAAwbBJk7wYNCKAWB]] | Ula'tek |
| Wrist | [[item:244584@FiQAAwbBeA8ciqjAtO3WzSB]] | Crafted |
| Gloves | [[item:271502@BgQAAwbBCKgTBA]] | Tier / Catalyst |
| Belt | [[item:251155@BiQAAwbBC06IoAOF]] | Den of Nalorakk |
| Legs | [[item:268237@DgQAAwbBbo6IoAYF]] Catalysed into [[item:271500@DgQBAwbBbo6IoAYFQzXQ]] | Coiled Altar |
| Boots | [[item:244577@HASAAwbBeA8ciqzD5OAAAAAAAA3WzSB]] | Crafted |
| Ring 1 | [[item:268249@DiQAAwbB3j7IQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAwbB3j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAwbBCKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAwbBCKgTBA]] | Nymrissa Wavecaller |
| One-Handed Weapon | [[item:271092@DgQAAwbB9k7IoAYF]] | Ula'tek |
| Off-Hand | [[item:268263@BgQAAwbBCKgTBA]] | Nymrissa Wavecaller |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAAwbBCKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAAwbBCKQQBA]] | Kings Rest |
| Cloak | [[item:251132@BgQAAwbBCKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAAwbBCKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAAwbBCKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAAwbBCKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAwbBCKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250215@BgQAAwbBCKQQBA]] | Murder Row |
| Trinket 2 | [[item:250214@BgQAAwbBCKQQBA]] | The Blinding Vale |
| Two-Hand Weapon | [[item:193761@BgQAAwbBCKQQBA]] | Ruby Life Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAEEACKgTBA]]  <br>[[item:270167@BgQAAEEACKgTBA]] |
| **A-Tier** | [[item:250214@BgQAAEEACKgTBA]]  <br>[[item:270162@BgQAAEEACKgTBA]]  <br>[[item:250215@BgQAAEEACKgTBA]] |
| **B-Tier** | [[item:273649@BgQAAEEACKgTBA]]  <br>[[item:270171@BgQAAEEACKgTBA]]  <br>[[item:270169@BgQAAwbBCKAWBA]]  <br>[[item:273794@BgQAAEEACKgTBA]]  <br>[[item:273796@BgQAAEEACKgTBA]] |
| **C-Tier** | [[item:250254@BgQAAEEACKgTBA]]  <br>[[item:250224@BgQAAEEACKgTBA]]  <br>[[item:193748@BgQAAEEACKgTBA]]  <br>[[item:193757@BgQAAEEACKgTBA]] |
| **Junkyard** | [[item:250248@BgQAAEEACKgTBA]]  <br>[[item:250259@BgQAAEEACKgTBA]]  <br>[[item:250255@BgQAAEEACKgTBA]] |

### Embellishments

- [[item:240167]] 2x
  
  - A generic embellishment you can put on any crafted armorpiece, it is generally recommended to craft embellishments with [[item:240167]] on the cloak and wrists slots as crafted items are lower item level and these 2 slots have the lowest amounts of stats on them. Since the cloak slot has a 344 item on its slot, the usual cloak craft is replaced by a craft on the boots slot instead.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Flask**
  
  - [[item:241322]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241300]]
  - [[item:241288]] -- Recommended
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240898]]
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:243951@DAAAAwbBZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwbB]] |
| Chest | [[item:243977@BAAAAwbB]] |
| Wrist | [[item:275707]] |
| Belt | [[item:275707]] |
| Legs | [[item:240155@BAAAAwbB]] |
| Boots | [[item:243983@BAAAAwbB]] |
| Ring 1 | [[item:243959@BAAAAwbB]] |
| Ring 2 | [[item:243959@BAAAAwbB]] |
| Weapon | [[item:244031@BAAAAwbB]] |

:::

:::column
:::gear **Preservation Evoker** Enchantments
```json
{
  "source_code": "JQFZ8WQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Macros

Discover recommended macros for **Preservation Evoker** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Preservation Evoker** Raid Guide are available as mouseover macros for your convenience!

**[[spell:355913]]**

```wow-macro
/cast [@mouseover, help] Emerald Blossom; Emerald Blossom
```

**[[spell:364343]]**

```wow-macro
/cast [@mouseover, help] Echo; Echo
```

**[[spell:360823]]**

```wow-macro
/cast [@mouseover, help] Naturalize; Naturalize
```

**[[spell:374251]]**

```wow-macro
/cast [@mouseover, help] Cauterizing Flame; Cauterizing Flame
```

**[[spell:366155]]**

```wow-macro
/cast [@mouseover, help] Reversion ; Reversion
```

**[[spell:360995@FJQBKHXBOLZB2vYB7zwB-zwBNEA]]**

```wow-macro
/cast [@mouseover, help] Verdant Embrace; Verdant Embrace
```

:::

:::details Recommended Macros
**[[spell:370665]] specific player** --- *Replace PLAYERNAME with one of your group members.*

```wow-macro
/cast [@PLAYERNAME, @Cursor] Rescue
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Preservation Evoker**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/euiEvoker-1-1024x576.png>)

Preservation Evoker Interface in Raids

:::accordion
:::details Addons
- **EllesmereUI**-- Full UI Replacement Addon
  
  - The entire ui is made with Ellesmere ui and it controls raidframes, damage meter, nameplates, action bars and cooldown manager. Plus adds a lot of additional small quality of live features and is highly customizeable

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1.0
**EVOKER**

- Preservation
  
  - Apex Talent: Merithra's Blessing has been updated – Now increases all healing of Dream Breath by 60% (was 250%, and previously applied only to its instant healing).
  - Font of Magic has been updated – Now also reduces the empower time of Dream Breath and Fire Breath by 20%.
  - Dream Breath instant healing reduced by 50%.
  - Dream Breath periodic healing increased by 118%.
  - Temporal Barrier absorption increased by 30%.
  - Inner Flame increases periodic healing by 50% (was 60%).
  - Spiritual Clarity reduces the cooldown of Dream Breath by 6 seconds (was 10 seconds).
  - Fluttering Seedlings healing is now also increased by Titan's Gift.
  - Fixed an issue that could cause Time Dilation to not clear its stored damage on death.
  - Fixed an issue where Consume Flame healing was not being increased by Grace Period or similar effects.
  - Hero Talents
    
    - Flameshaper
      
      - Expanded Lungs increases the healing of Dream Breath by 20% (was 30%).
      - Conduit of Flame increases critical chance by 10% (was 15%). Does not affect Devastation Evoker.
      - Fulminous Roar causes Fire Breath and Dream Breath to deal their damage 15% more often (was 20%). Does not affect Devastation Evoker.
      - Fluttering Seedlings can now trigger Consume Flame.
      - Emerald Blossom and Fluttering Seedlings now prefer to heal injured allies with Dream Breath active while talented into Consume Flame.
      - Consume Flame heals for 240% of the amount consumed (was 200%).
      - Fixed an issue where Consume Flame's healing component could not critically heal.
      - Twin Flame damage and healing reduced by 20%.
      - Fixed an issue where Twin Flame was not scaling with Mastery.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I run out of Mana?
A: You cast too many [[spell:355913]] and [[spell:373861]].

:::

:::details Q: Why do people die if I don't have my cooldowns?
A: You need to make good use of [[spell:364343]] ramps into [[spell:366155]] more.

:::

:::details Q: What spell do I use with [[spell:364343]]?
A: Maintain [[spell:366155]] generally, then you can use [[spell:355936]] for big heals.

:::

:::

---

### Credits

Written By: **Ftmjgtde**

Reviewed By: **Rycn**

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1.0

**2026-06-16** Updated for patch 12.0.7

**2026-04-25** Updated for patch 12.0.5

**2026-02-21** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0



:::
