欢迎来到魔兽世界12.1版本的**噬灭 恶魔猎手** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切知识！如果你是刚起步、从80级开始练级的玩家？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体目标** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 5/5 · 优秀

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **噬灭 恶魔猎手** 团队副本 最佳配装
```json
{
  "source_code": "J8pAQicB3_fABMgJEIIGBAw74OA_sOAZ1chNCKAWBEQ6XQAAZEAAX1aCWQAj1UgFI9KJEIACFAwM5OggC4UAXV9ABQbCSAQCJIBKXU9ABA-FEAIEBAQBNVQNAAbCjgQBqOQAPAPSBfBBBk1uDQAMBAwD5OAGAPAAjY7LgBzt1wgNbWySBEAY7OggIEAAYA8A8z6A3WzSBEgskQAAIUAACKgTBo8FEEQ2XQggQEAA13AsBcBEB4paCIYFUAgtJQBGnF9AAgQAAUAIIQ1HEUBDE09FNwALYFQA0LCBCgQAA8TuFsJOBM7FEIACBAwP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240892]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240892]] |
| 肩部 | [[item:271535]] | [[item:244019]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271536]] | [[item:240133]] |
| 脚部 | [[item:244569]] | [[item:243983]] · [[item:245784]] |
| 腕部 | [[item:244576]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268211]] | [[item:244031]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **噬灭 恶魔猎手**，你可以使用 至暗之夜，它使 [[talent:132281@FAgAMyuE2VvE]] 成为一个真正可以按下的按钮，第一级使 [[talent:132281@FAgAMyuE2VvE]] 总是暴击，这与 [[talent:136691]] 等天赋配合得非常好。

**等级2** 使你造成的所有宇宙伤害提高6%，并进一步提高 [[talent:132281@FAgAMyuE2VvE]] 的伤害，因为它反正总是造成暴击  
  
等级3 使你在进入 [[talent:132281@FAgAMyuE2VvE]] 后立即可使用 [[talent:132282]]，并在进入 [[talent:132282]] 时额外获得5个灵魂。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-devourer-mxr.webp>)

至暗之夜

:::

:::

## 英雄天赋

- [[talent:134251]]和[[talent:136623]]是新的英雄天赋树选项。[[talent:134251]]目前在范围伤害和单体目标场景中略微领先于[[talent:136623]]。



### [[talent:134251]]

- [[talent:134253]]天赋树的核心机制围绕生成和消耗[[talent:135667@FAQAF6zA]]层数展开。
- [[talent:135672]]、[[talent:135670]]提高急速并使受到的伤害降低2%，最多叠加3层。
- [[talent:135673@AJADCA]]提供一层[[talent:135667]]，请务必在施放[[spell:1213649]]之前消耗掉已有的层数，以避免溢出。这种情况尤其容易发生在你进入[[talent:132282]]时，因为玩家往往会尽快施放[[spell:1213649]]让它尽早进入冷却。




### [[talent:136623]]

- [[talent:136623]] 天赋树整体上朝着比 [[talent:134251]] 天赋树更频繁地处于近战范围内的方向演进，因为它会将你施放的前一个 [[talent:134272@FAQAiVwE]] 和 [[spell:1239123]] 转化为围绕你自身的大型 [[talent:136613@FAgAtByAOSOB]] 爆炸。
- 对于像 [[talent:136615]] 和 [[talent:136608]] 这样的特质来说，这有点反直觉，因为你通常希望尽可能长时间地处于 [[talent:132282]] 中，但它会大幅提升你在该状态之外的伤害。





## 天赋



### [[talent:134251]]

:::talents [[talent:134251]] **噬灭 恶魔猎手** 团队副本 配装
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 改变游戏玩法的天赋

探索专精天赋树和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若想了解更多细节，请查看下方的循环和 **深入解析** 部分。

##### 专精树

- [[talent:132282]]
  
  - 在收集50个灵魂后进入[[talent:132282]]（如果点了[[talent:134331]]天赋则为35个）会强化你的吞噬和收割，同时你停留在[[talent:132282]]中的时间越长，狂怒会被缓慢消耗，此外[[spell:1242157]]现在会产生怒气而不是消耗怒气。
- [[talent:132281@FAQAMyuE]]
  
  - 在[[talent:132282]]期间每收集30个灵魂就能获得一次[[talent:132281@FAQAMyuE]]的施放机会，对你的主要目标及其周围造成大量伤害，此外在此期间怒气消耗会显著减缓。

- [[talent:133106]]
  
  - 在施放[[spell:1226019]]后重置你的[[spell:1213649]]。
- [[talent:133110]]
  
  - [[spell:1213649]]在只命中一个目标时造成显著更高的伤害，如果不想分散伤害，请避免命中其他目标。
- [[talent:132287]]
  
  - [[spell:1226019]]在完整引导一次[[talent:132287]]后会变成[[spell:1213649]]，大幅提高伤害并为其增加一个正面范围伤害成分。
- [[talent:133512]]
  
  - 使你能够显著更长时间地保持[[talent:132282]]状态，并且每收集一个灵魂都会提高你的急速。

##### 职业树

- [[spell:196718]] 
  
  - 这个团队范围的防御冷却技能会在[[spell:196718]]**噬灭 恶魔猎手的**位置创建一片区域，为其中的所有盟友提供15%的几率完全闪避来袭攻击的伤害。

##### 英雄天赋

- [[talent:135667]]
  
  - 吞噬 有 35% 的几率使你获得一层 voidfall，叠到 3 层后，你的下一个 reap 会对其周围造成巨大的 范围伤害 伤害。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** 使用‍收割收割4个或以上‍灵魂碎片‍时，有20%的几率使你的下一个‍吞噬变为瞬发并引爆为一次‍灵魂爆裂‍，对附近的敌人造成宇宙伤害。
- **4件套：** ‍灵魂爆裂‍会产生8个‍灵魂碎片‍并赋予‍噬欲时刻。‍收割‍造成的伤害提高20%。

### 单体目标



#### [[talent:134251]]

##### 起手爆发

- **噬灭 恶魔猎手** 的开局手法相当简单，你只需连按 consumes 直到 100 怒气，用 虚空射线 释放掉怒气，并以一个 eradicate 收尾，重复这个过程直到你可以进入 [[talent:132282]]。

:::rotation **噬灭 恶魔猎手** 在大秘境中的单体起手
```json
{
  "source_code": "JoZAwLXCC5jOHAAAXUlb0lGbgQDIhZXYpxWYixWZgM3b1x2cBI0I1KBAAIEg6cAAAAAACJGtSAAAkIVZwVWY0BCdol2cgMXZxVXZuNWZgUnb0lGbsBSNwAyUvVHbzBgQFRpEAAAACEwZRPAAIEAACKgTBEAiuOAABgUBWBAAZgFBeIaAsADACJGtSAAAAAgQKRpE"
}
```
1. [[spell:473662]] 在可用灵魂不足4个之前 [[spell:1226019]]
2. [[spell:473728]]
3. [[spell:1225826]] 重复此循环直至50层灵魂
4. [[spell:1217605]]  [[item:250215]] · [[item:241288]]
5. [[spell:1226019]]
6. [[spell:473728]]
7. [[spell:1221150]]
8. [[spell:1225826]]
9. [[spell:1217610]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

- 在达到50层灵魂后进入[[talent:132282]]
- 在[[talent:132282]]中冷却好了就施放[[spell:1213649]]。
- 施放[[talent:132281@FAQAMyuE]]
- 施放[[talent:132287]]
- 在[[talent:132282]]之外施放[[spell:1213649]]
- 如果你处于4层灵魂，施放[[spell:1226019]]以钓取高阶触发。
- 如果你有3层[[talent:135667]]，施放[[spell:1226019]]。
- 施放[[spell:1217610]]
- 施放[[spell:473662]]





### 多目标



#### [[talent:134251]]

##### 起手爆发

- **噬灭 恶魔猎手** 的开局手法相当简单，你只需连按 consumes 直到 100 怒气，用 虚空射线 释放掉怒气，并以一个 eradicate 收尾，重复这个过程直到你可以进入 [[talent:132282]]。

:::rotation **噬灭 恶魔猎手** 在大秘境中的范围伤害起手
```json
{
  "source_code": "JoZAwLXCC5jOHAAAXUlb0lGbgQDIhZXYpxWYixWZgM3b1x2cBI0I1KBAAIEg6cAAAAAACJGtSAAAkIVZwVWY0BCdol2cgMXZxVXZuNWZgUnb0lGbsBSNwAyUvVHbzBgQFRpEAAAACEwZRPAAIEAACKgTBEAiuOAABgUBWBAAZgFBeIaAsADACJGtSAAAAAgQKRpE"
}
```
1. [[spell:473662]] 在可用灵魂不足4个之前 [[spell:1226019]]
2. [[spell:473728]]
3. [[spell:1225826]] 重复此循环直至50层灵魂
4. [[spell:1217605]]  [[item:250215]] · [[item:241288]]
5. [[spell:1226019]]
6. [[spell:473728]]
7. [[spell:1221150]]
8. [[spell:1225826]]
9. [[spell:1217610]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

- 在达到50层灵魂后进入[[talent:132282]]
- 在[[talent:132282]]中冷却好了就施放[[spell:1213649]]。
- 施放[[talent:132281@FAQAMyuE]]
- 施放[[talent:132287]]
- 在[[talent:132282]]之外施放[[spell:1213649]]
- 如果你处于4层灵魂，施放[[spell:1226019]]以钓取高阶触发。
- 如果你有3层[[talent:135667]]，施放[[spell:1226019]]。
- 施放[[spell:1217610]]
- 施放[[spell:473662]]





## 深度解析

### 生死一线

打出伤害并成为团队有用一员的最重要的一点就是活着。由于移动是你输出循环的核心部分，你必须时刻留意周围环境。切勿[[spell:1234796]]、[[spell:1245412]]或[[spell:198793]]进入正面技能或范围伤害区域。

你死了就无法输出，也无法阻止敌方技能生效。

如果你已经倒在地板上，或者需要占用坦克本可获得的外部减伤/治疗，那么再完美的循环操作也无济于事。

### 充分利用灵魂残片

请永远记住，灵魂残片的管理是作为 **噬灭 恶魔猎手** 最大化 DPS 的关键一环，尽可能长时间地保持在 [[talent:132282]] 中应当是你的目标。  
话虽如此：收集灵魂有 3 种方式，

1. 施放 [[spell:1226019]]
2. 由于地上灵魂过多而自动收集
3. 从它们上面跑过  
   人们往往忘记第二种和第三种方式，这导致他们在 [[talent:132282]] 中浪费大量怒气并严重超出怒气上限，损失大量的有效时间。  
   即使你的收割或根除伤害会随着收集的灵魂数量提高这一点听起来很诱人，但有时手动拾取它们以更快地挤进另一次 [[talent:132281@FAQAMyuE]] 从而不浪费 [[talent:132278]] 的冷却，或者在邪恶魔典结束前挤进另一次 [[talent:132281@FAQAMyuE]] 同时连续使用 [[spell:1217610]] 并跑过灵魂以获取怒气、不把公共冷却浪费在收割这种不产生灵魂的技能上，才是明智之举。  
   另外，施放收割后灵魂在被收集时需要一些时间才能到达你身上，朝它们走过去会有所帮助。

### 急速?!

尽管 **急速** 在模拟数据纸面上表现很差，但在多目标场景中它是一个极佳的属性，因为它能让你的操作流畅许多。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下提示主要适用于英雄和史诗难度的首领。

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **噬灭 恶魔猎手** 内克扎莉
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 注意[[spell:1284103]]的计时条，切勿站在首领与其技能目标坦克之间。
- 提前观察小怪的尸体位置，以便更轻松地应对[[spell:1294742]]净化它们的减益效果。




### 陵寝哨兵

:::talents **噬灭 恶魔猎手** 陵寝哨兵
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 需要注意的是，[[spell:1284434]]也可能出现在另一个首领身上，所以尽量不要站在两个首领之间，并在[[spell:1284434]]出现时保持警惕。
- 留意首领的能量值，当其接近100时务必分散站位，以便更轻松地度过中场阶段。
- 总体而言，注意自己的站位，尽量靠近首领输出，这样就不用担心[[spell:1284494]]和[[spell:1284503]]的层数叠加。




### 迷失的探险者

:::talents **噬灭 恶魔猎手** 迷途的探险者
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 注意 [[spell:1296062]] 的施法，这样更容易躲避它们。
- 不要过量吸收 [[spell:1291934]]，因为它会给你叠加一层 **流血** 减益效果。
- 小心 [[spell:1292105]] 产生的蘑菇，因为它们被使用一次后就会被消耗掉。




### 瓦什尼克

:::talents **噬灭 恶魔猎手** 瓦什尼克
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 每当 [[spell:1281907]] 减益效果即将到来时，务必提前分散，并尽可能不要将它对准首领。
- 请记住，击杀 **燃烧毒液** 会给你叠加一层减益效果，所以要避免同时击杀它们。




### 斯索拉克

:::talents **噬灭 恶魔猎手** 斯索拉克
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 如果你找不到队友来处理 [[spell:1285419]]，请记住你也可以通过二段跳来规避它。
- 非常重要的是要留意 [[spell:1305959]] 的计时器，一旦临近，提前扫视平台，看看你需要将其放置在哪里。
- 如果你被 [[spell:1287072]] 命中，请使用防御冷却技能，因为它会对你施加一个可叠加的 **中毒** 减益效果。




### 双牙

:::talents **噬灭 恶魔猎手** 双蛇之牙
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 在这场战斗中，拥有一个良好的负面效果监控手段极其重要，因为[[spell:1290336]]在达到一定层数后必定会致死，具体层数取决于难度。
- 当你成为[[spell:1291478]]的目标时，尽量不要到处乱跑。如果需要躲避什么，最好沿自己的直线移动。
- 别忘了吸收[[spell:1290516]]也会将你击退，所以在那期间要小心[[spell:1290956]]产生的波纹。
- 每当[[spell:1294293]]发生时，观察场地中央的**维克苏尔** ，你会发现有一些围绕他旋转的小球，它们指示了他施放光束的方向。




### 盘绕祭坛

:::talents **噬灭 恶魔猎手** 盘绕祭坛
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 小心 [[spell:1282403]]，如果有需要，确保协助将它们移动到别处。
- 要格外注意 [[spell:1285643]] 之后刷新的幽灵，因为处理它们将是这个阶段最难的部分。
  
  - 即使你没有被幽灵点名，也请确保不要停留在它们附近，因为它们会被 [[spell:1286620]] 的正面劈砍清理掉，这是消灭它们的唯一办法。
- 每当你被 [[spell:1286895]] 点名时，使用一个防御冷却技能。




### 乌拉特克

:::talents **噬灭 恶魔猎手** 乌拉特克
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

-




### 尼姆瑞莎·唤波者

:::talents **噬灭 恶魔猎手** 尼姆瑞莎·唤波者
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

#### 首领攻略技巧

- 请记住，[[spell:1258673]] 结束后，[[spell:1258150]] 会把你从中间击退，因此请提前调整站位，或准备好用 [[talent:80163]] 或 [[talent:80174]] 来抵消击退效果。
- 当 [[spell:1281393]] 爆发时，请使用防御冷却技能。





## 属性优先级

了解你的副属性优先级以及 团队副本 首领战中作为一名 **噬灭 恶魔猎手** 所需的第三属性，以获得最佳表现。欲了解更多详细信息，请查阅 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority **噬灭 恶魔猎手** 团队副本 属性优先级
```json
{
  "source_code": "IoAJFUQMkACKBMQABA"
}
```
**智力 ＞ 精通 ≥ 急速 ＞ 暴击 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可减少“**范围效果**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外的治疗。
- **加速** - 小众副属性，但可能非常有用，过去已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 插槽 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAgcBvj7wPrDZ1chNYFA]] | 乌拉特克 |
| 项链 | [[item:268265@BERAAgcBX16wPrDZ1wYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271535@DAQBAgcBzk74UAXV9A]] | 套装 |
| 披风 | [[item:268253@BAQAAgcBYFA]] | 盘卷祭坛 |
| 胸部 | [[item:271540@DAQBAgcBJk74UAXU9A]] | 套装 |
| 护腕 | [[item:244576@DiQAAgcBYA8wPrzt1sUA]] | 制造业 |
| 手套 | [[item:271538@BAQBAgcBOFgyXQA]] | 套装 |
| 腰带 | [[item:268256@BiQAAgcB8z6QWNYF]] | 盘卷祭坛 |
| 腿部 | [[item:271536@DAQBAgcBFo6gVABfBB]] | 套装 |
| 靴子 | [[item:244569@FATAAgcBPk7gBwDAjY7LgBzt1wgNbWySBA]] | 制造业 |
| 戒指 1 | [[item:268249@DiQAAgcB1j7wPrDZ14UA]] | 瓦什尼克 |
| 戒指 2 | [[item:158366@DCRAAgcB1j7wPrjt1IoAOFA]] | 塞特拉利斯神庙 |
| 饰品 1 | [[item:250215@BgQAAgcBCKgTBA]] | 密谋小径 |
| 饰品 2 | [[item:270164@BAQAAgcBOFA]] | 迷失的探险者 |
| 武器 | [[item:271092@DAQAAgcB_k7gVA]] & [[item:268211@DAQAAgcB_k7gVA]] | 乌拉泰克 & 盘卷祭坛 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251140@BgQAA0QACKQQBA]] | 密谋小径 |
| 颈部 | [[item:251173@BgQAA0QACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:251223@BgQAA0QACKQQBA]] | 虚空之巢竞技场 |
| 披风 | [[item:251132@BgQAA0QACKQQBA]] | 密谋小径 |
| 胸部 | [[item:251159@BgQAA0QACKQQBA]] | 纳洛拉克的洞穴 |
| 护腕 | [[item:251135@BgQAA0QACKQQBA]] | 密谋小径 |
| 手套 | [[item:251124@BgRAA0QA2IjX1caJBFA]] | 密谋小径 |
| 腰带 | [[item:159317@BgQAA0QACKQQBA]] | 塞塔里斯神庙 |
| 腿部 | [[item:251130@BgQAA0QACKQQBA]] | 密谋小径 |
| 靴子 | [[item:159327@DgQAA0QApk7IoABF]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:273792@BgQAA0QACKQQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:252258@BASAA0QAkVjNy4VNWiSQBA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:250215@BgQAA0QACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250259@BgQAA0QACKQQBA]] | 夺目谷 |
| 武器 | 2把 [[item:273778@AgQAAIoAOFA]] | 毒牙祭坛 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A级** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B级** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C级** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **垃圾级** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### 美化饰品

- 1个 [[item:251513@DiQAAgcBvk7wPrjIv0RA]]
  
  - 属性预算的最佳综合选择。
- [[item:240166]]

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - **[[item:241322]] *——最高输出。***
  
  
  
  - **[[item:241320]] *——输出略低但生存能力更强。***
- **食物**
  
  - **[[item:242272]]**
  - **[[item:255845]]**
- **战斗药水**
  
  - **[[item:241288]]**
- **治疗药水**
  
  - [[item:271884]] ——一次大量的治疗
- 武器油
  
  - **[[item:243734]] *——默认选择***
  - **[[item:243738]]**
- **强化符文**
  
  - **[[item:259085@AQAAAoF]]**
- **宝石插槽**
  
  - **[[item:240967]] *——唯一***
    
    - **[[item:240890]]**
    - **[[item:240898]]**
    - **[[item:240906]]**
    - **[[item:240914]]**

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAAsQA]]  <br>[[item:244007@BAAAAsQA]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAsQA]] |
| 胸部 | [[item:243977@BAAAAsQA]] |
| 护腕 | [[item:275707@BAAAAsQA]] |
| 腰部 | [[item:275707@BAAAAsQA]] |
| 腿部 | [[item:240133@BAAAAsQA]] |
| 靴子 | [[item:244009@BAAAAsQA]] |
| 戒指 1 | [[item:243957@BAAAAsQA]] |
| 戒指 2 | [[item:243957@BAAAAsQA]] |
| 武器 | [[item:244031@BAAAAsQA]] |

:::

:::column
:::gear **噬灭 恶魔猎手** 团队副本中的附魔
```json
{
  "source_code": "JwFZIXQ9NGQAnk7ACAAAAsPNEEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYEBCo8TuDAAAAAQA_k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:244007]] | [[item:275707]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAsQA]]，为你的 **头盔**、**护腕** 和 **腰带** 添加插槽。

## 种族

对于追求 **噬灭 恶魔猎手** 极限优化（追求极致输出）的玩家来说，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:58984]] —— 暗夜精灵
  
  - 在 团队副本 中没有任何作用，但在 大秘境 的极少数特殊情况下可能有用。
- [[spell:202719]] —— 血精灵
  
  - 移除你周围敌对目标身上的 1 个有益效果。
  - 产生 15 点 狂怒。
- [[spell:256948]] —— 虚空精灵
  
  - 在空间中撕开一道裂隙。再次激活该技能可穿越裂隙进行传送。

### 推荐

对于 **噬灭 恶魔猎手** 来说，选择哪个种族其实并没有太大影响，两者提供的 DPS 收益大致相同。不过建议选择血精灵，因为在某些需要快速 范围伤害 驱散的情况下 [[spell:202719]] 可能会派上用场，而且当你战斗中远离任何目标时，还可以用它来获得 15 点 狂怒。

## 宏

了解 **噬灭 恶魔猎手** 在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**@Cursor [[spell:1234796]] 宏 - *在你的鼠标指针位置使用你的 [[spell:1234796]]***

```wow-macro
/cast [@Cursor] 变换
```

**@Cursor [[spell:207684]] 宏 - *在你的鼠标指针位置使用你的 [[spell:207684]]***

```wow-macro
/cast [@Cursor] 悲苦咒符
```

:::

:::details 鼠标指向宏
**@鼠标指向打断宏 - *如果你有鼠标指向目标，则打断该目标；如果没有鼠标指向目标，则打断你当前的目标。***

```wow-macro
/cast [@mouseover,harm,nodead][] 瓦解
```

**@鼠标指向[[spell:217832]]宏** **-** *[[spell:217832]]*的***如果你有鼠标指向目标，则对该目标使用[[spell:217832]]***的***；如果没有鼠标指向目标，则对你当前的目标使用。***

```wow-macro
/cast [@mouseover,harm,nodead] [] 禁锢
```

**@鼠标指向[[spell:1234195]]宏 - *如果你有鼠标指向目标，则将其眩晕；如果没有鼠标指向目标，则眩晕你当前的目标。***

```wow-macro
/cast [@mouseover,harm,nodead] [] 虚空新星
```

:::

:::details 通用宏
**@玩家[[spell:207684]]宏 - *在你当前所在位置使用你的[[spell:207684]]***

```wow-macro
/cast [@Player] 悲苦咒符
```

:::

:::

## 插件

下方是作者的**噬灭 恶魔猎手**的用户界面截图，其中列出了所使用的插件，以及它们在团队副本中如何使用才能让你的游戏体验更轻松。

![](<https://assets-ng.maxroll.gg/wordpress/nicememesuimidnight-1-1024x681.png>)

:::accordion
:::details 插件
- **MRT** —— 记事、团队副本 冷却监控等
  
  -
- **BigWigs** *—— 通用首领模块*  
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些微型插件旨在为某场特定的 团队副本 战斗触发警报信息、计时条、音效等。
- **Plater**  —— 进阶姓名版
  
  - Plater 是一个设置选项极其丰富的姓名版插件，开箱即用的减益监控、仇恨着色，并支持类似 WeakAuras 的脚本功能，以及通过 wago.io 和 WeakAuras-Companion 更新模块/脚本/配置文件。
- **Details** —— 深度伤害统计
  
  - 最强大、最可靠、最美观的伤害统计插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
恶魔猎手现在可以装备匕首了。

- *开发者说明：这将允许噬灭恶魔猎手获取并使用带有智力的匕首。*

**噬灭**

- *开发者说明：我们正在降低噬灭的精通：内在恶魔的收益缩放，以帮助其他属性与其竞争，并通过整体技能伤害加成进行补偿。结合这一改动以及其他一些针对性调整，我们预计虚空变形期间的伤害将略有降低，而恶魔形态之外的伤害将显著提升。*
- 精通：内在恶魔已更新——虚空变形期间的伤害加成降低66%。
- 所有技能伤害提高32%。
- 坍缩之星伤害提高12%。
- 根除伤害降低6%，次要目标伤害降低15%。
- 吞噬伤害提高60%（不影响吞噬）。
- 虚空变形现在使虚空射线伤害提高40%（原为67%）。
- 末日将至现在使每个坍缩之星为下一个提供20%的伤害加成（原为30%）。
- 饥渴斩击现在会正确地给予一层临时复仇回避充能，而不是提供一次免费施放并重置其冷却时间。
- 英雄天赋
  
  - 歼灭者
    
    - 异界专注现在使坍缩之星和虚落陨石对单一目标造成的伤害提高30%（原为35%）。
    - 最终时刻现在使虚落的加成持续6秒（原为8秒）。

:::

:::

---

### 致谢

作者：**Nicememes**

审校：**Verb**

---

:::changelog 更新记录
**2026-08-08** 已更新至12.1版本

**2026-06-22** 已更新至12.0.7版本

**2026-04-23** 已更新至12.0.5版本

**2026-01-20** 已更新至12.0版本



:::
