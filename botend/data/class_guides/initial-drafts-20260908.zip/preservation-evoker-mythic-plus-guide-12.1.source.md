Welcome to the **Preservation Evoker** Mythic+ guide for the World of Warcraft patch 12.1.0! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 4/5 · Strong

Damage · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 3/5 · Average

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Preservation Evoker** Mythic+ Best in Slot Gear
```json
{
  "source_code": "J4oAIybB3_fAB0IJEIICBAw74OwVtOggC4UABk-FEAQEBAgAtOgABIBiMWDWBEwikQgAIUAA1k7ACKAWBc8FEEABmQgAQEAAJk7AMWTAUQRATU9AAiQB3UgRAwYCyQwGqWgMQ18FEEQY7OgBgEAAeA8Ano6APk7AAUQAkcbNLFQAot7AEiQEbggAtOQBVghjkQAAIEAAF4EBZfRBmSw94GgHFIBCeqmABgbHSQAVfkBMAIVHMQQ3X0AGogVABQvIEIACBAQPJgMLBc-FEAACBAggC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271499]] | [[item:244021]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:251155]] | [[item:240898]] |
| 腿部 | [[item:271500]] | [[item:240155]] |
| 脚部 | [[item:244577]] | [[item:245790]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270162]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:268263]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Preservation Evoker**, you have access to [[spell:1256577]], which gives your essence abilities a chance to turn your next [[spell:366155]] into an empowered version.

**Rank 2** of this hero talent gives all your [[spell:367364]] buffs an effect that heals them based off of the damage they take. While **Rank 3** enables that your [[spell:355936]] has 100% chance to empower your next reversion and its initial healing is buffed by 125%

:::

:::column
:::group
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-preservation-mxr.webp>)

Merithra's Blessing

:::

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:373267]]
    
    - This talent used to have the ability to have multiple applications out due to it applying from copied [[spell:360995]] hits. This is no longer an option and removes the ability to copy lifebind to the entire party.
  - [[spell:1242031]]
    
    - A new talent that synergises well with our tierset as it just gives you a lot of value through gaining an additional [[spell:364343]] every time you press [[spell:360995]].
  - [[spell:373834]]
    
    - This talent was changed and no longer has any interaction with [[spell:360995]] and this makes it so the ability can be cast a lot more freely and isnt tied to buffing [[spell:355936]].
- **Class Tree**
  
  - [[spell:374348]]
    
    - This ability was changed from an active button and is now baked into your [[spell:363916]] and is a lot weaker overall.
  - [[spell:410352]]
    
    - This new talent is a nice niche defensive option against very large hits and potential one shots.
  - [[spell:370889]]
    
    - This talent used to give an absorb shield, now it gives a cast while moving effect to you and your ally.
  - [[spell:370665]]
    
    - This talent got an added effect of removing movement impairing effects from you and your ally.
- **Removed**
  
  - [[spell:367226]] 
    
    - This ability was really good to rotate with [[spell:355936]] and to pair with [[spell:373267]] to do good burst healing on a short cooldown.
  - [[spell:370960]]
    
    - This ability was usually used in combination with [[spell:373267]] and having the healing copy to the entire party.
  - [[spell:443328]]
    
    - This hero talent ability made up a lot of our burst healing in the last expansion. The removal of it has removed most of our 1 button option to heal everyone in the group for a large burst.

## Hero Talents

- [[talent:123335]] buffs a lot of your healing abilities and turns [[talent:115665]] into a strong cooldown.
- [[talent:123332]] also buffs a lot of your healing abilities and gives you 2 charges of [[spell:363922]] and [[spell:357208]]. Additionally it makes [[spell:360995]] and [[spell:355913]] consume a portion of your [[spell:363922]] heals over times for additional healing.
- Overall I recommend playing [[talent:123335]] because it is very strong right now with all the buffs to your healing abilities and the DPS output it provides. So this guide will focus on playing that build.



### [[talent:123335]]

- [[talent:117551]]‍ 
  
  - Makes your [[spell:361469]] turn into [[spell:431442]] which is a Bronze spell, which will give you stacks towards [[talent:115543]], and will repeat 15% of the damage or healing you dealt to the target in the last 5 seconds.
- ‍[[talent:117545]] transforms your normal ‍Hover into a [[spell:1953]]
  
  - This currently only works when you are on or close to solid ground, if you are too high up in the air it functions like a normal [[spell:358267]]. Be cautious, as this has a small delay.
- [[talent:117552]]
  
  - Turns ‍your [[talent:115665]] into a strong cooldown, increasing Haste, Movement Speed, and Cooldown recovery rate by 30%, decreasing by 1% every second during the 30s duration of ‍[[talent:117552]].
- [[spell:1260484]]
  
  - The cooldown of [[talent:115665]] is reduced by 30 seconds.
- [[talent:117522@AJQDBA]]
  
  - [[spell:360995]] heals for an additional 60% over 8 seconds.
- [[talent:117532]]
  
  - If timed correctly [[talent:117532]] can be very strong as a minor defensive cooldown whenever you are out of everything else.
- [[spell:431715]]
  
  - [[spell:373861]] mana cost reduced by 15% and cooldown reduced by 4 seconds.
- [[talent:117548@AJQDBA]]
  
  - Gain haste for each heal over time effect you have out from [[spell:360995]] up to 3.
- [[talent:117529]]
  
  - [[spell:355936]] and [[spell:357208]] duration is extended by 2 sec, up to 12 sec, when they Crit.
- [[talent:126310]]
  
  - Your empowered spell gets reduced by up to 6 sec when you cast it.
- [[spell:1260647]]
  
  - Empowers [[spell:431442]] making it do more damage and healing by up to 40%.
- [[talent:117539@AJQDBA]]
  
  - [[spell:364343]] lasts 10% longer.
- [[talent:117526]] 
  
  - Each time you cast an empowered spell, up to 3 targets that you hit additionally get a [[talent:117551]]‍ cast onto them.





## Talents



### [[talent:123335]]

:::talents **Preservation Evoker** General Mythic+ Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### When to use this Spec

This is the default loadout going into any dungeon. You have to adjust the class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, Dungeon specific talent loadouts are available in the Dungeons section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:363534]]
  
  - Applies to 33% of the damage taken in the last 5 seconds, you heal that amount back.
- [[spell:357170]]
  
  - Your external cooldown staggers 50% of the damage taken over the next 8 seconds.
- [[spell:370537]]
  
  - Duplicate and store your next 3 healing spells.
- [[talent:115566]]
  
  - [[spell:356995]] deals 35% more damage and generates 126k mana.
- [[spell:371426]]
  
  - Turns your [[spell:357208]] into a solid bit of passive healing during aoe pulls.

##### Class Tree

- [[spell:374227]]
  
  - Reduce damage taken from AoE effects by 20% to all allies within 20 yards for 8 seconds. Also increases movement speed by 30%.
- [[spell:370553]]
  
  - Makes your next Empowered spell cast instantly at maximum rank. And gives you a good chunk of [[spell:359565]] buffs through your hero talent [[spell:431695]]
- [[spell:374251]]
  
  - Unique dispel that removes bleeds, as well as poison, curse, and disease.
- [[spell:372048]]
  
  - A frontal cone that increases CC duration by 50% on enemies hit.
  - If talented into [[spell:374346]] this ability also dispels all Enrage effects on enemies hit. It also has its cooldown reduced based on the amount of targets hit.

##### Hero Talents

- [[talent:117532]]
  
  - If timed correctly [[talent:117532]] can be very strong as a minor defensive cooldown whenever you are out of everything else.
- [[talent:126310]]
  
  - Your empowered spell gets reduced by up to 6 sec when you cast them. This makes your [[spell:355936]] naturally line up with [[spell:373861]] and allows you to copy a lot more [[spell:1256581]]





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: Consuming [[spell:369297]] sends forth a [[spell:361469]] at your target at 100% effectiveness, or a nearby injured target if they are at full health.
- **4-Set**: Green spells restore 5% more health, and [[spell:360995]] has a 100% chance to grant [[spell:369297]]



#### [[talent:123335]]

##### Priority List

###### For Healing

1. Cast max rank [[spell:357208]] to gain [[talent:115657]] and to heal through [[spell:371426]].
2. Cast [[spell:1256581]] for a large amount of burst healing, preferably with [[spell:364343]] applied to a majority of your party.
3. Cast [[spell:355936]], empower it according to how urgent the healing is.
4. Cast [[spell:373861]] to apply [[spell:364343]].
5. Spend Essence on [[spell:364343]].
6. Cast [[spell:360995@FJQBKHXBOLZB2vYB7zwB-zwBNEA]] for high burst healing
7. Cast [[spell:366155]] on whatever target requires healing
8. Cast [[spell:361469]] to gain [[spell:369297]] for free Essence casts.

###### For Damage

1. Cast [[spell:382266]] on cooldown.
2. Cast [[spell:357210]] if 3 or more targets and there's no danger of dying during the animation.
3. Cast [[spell:356995]] to gain mana back through [[talent:115566]] and if you don't need to use Essence for healing.
4. Cast [[spell:361469]].

###### Cooldowns

###### Time Dilation

- [[spell:357170]] is your go-to external whenever there's an ally in danger.

###### Stasis

- [[spell:370537]] is a good gap filler between your other healing cooldowns. If there's a dangerous damage event coming up and your [[spell:355936]] [[spell:373861]][[spell:1256581]] combo is needed twice in short succession [[spell:370537]] should be used to copy these spells in the order listed previously.

###### Tip the Scales

- [[spell:370553]] is a good panic button in combination with [[spell:355936]]. As [[talent:123335]] you also get a very nice big haste buff from [[talent:117552]].

###### Rewind

- [[spell:363534]] is the strongest cooldown Evoker has by far and can single-handedly salvage almost any dangerous situation. Due to its massive cooldown, it's best to plan for when you want to use it.





## Deep Dive

#### Min maxing Rewind

- The more damage you have taken, the more healing [[spell:363534]] will do. Try and hold off using it so your party takes as much damage as possible but if someone drops below say 30% hp, then you should use it, don't let anyone die by greeding this cooldown.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Preservation Evoke** Mythic+ Altar of Fangs Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.




### Den of Nalorakk

:::talents **Preservation Evoker** Mythic+ Den of Nalorakk Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]].
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Preservation Evoker** Mythic+ Murder Row Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Preservation Evoker** Mythic+  The Blinding Vale Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Preservation Evoker** Mythic+ Voidscar Arena Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Preservation Evoker** Mythic+ Kings' Rest Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Preservation Evoker** Mythic+ Ruby Life Pools Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Preservation Evoker** Mythic+ Temple of Sethraliss Talents
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAMzMz22ADzMzsZGjx2AAAYGzYGjxDMTMzMAAAgZmZaGmZMLzMDAMmZMjNWswwMzMN0sZYxwYmBGjB"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system didnt change much going into **Midnight Season** 2 mostly just changing at which keystone levels affixes start at and adding a helper affix for routing at lower key levels.

- +2 Affix
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Preservation Evoker**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:357214]] and [[spell:368970]] on any big stack of orbs.
- Xal'atath's Bargain: Voidbound
  
  - [[talent:115617]] does a lot of damage to the **Void Emissary**.
- Xal'atath's Bargain: Devour
  
  - Use [[spell:360823]] or [[spell:374251]] on cooldown whenever this is active.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Preservation Evoker**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Preservation Evoker** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUQMgQCKBEQABA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> The conclusion here is that you want to equip the highest item level generally.

Blizzard introduced Stat DRs that you need to be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has **Leech** or **Avoidance**. **Speed** is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful **Leech** is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/PresEvokerBreakdown-1-1024x342.png>)

**Preservation Evoker** healing breakdown from Warcraftlogs

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271501@DiQAAwbBvj7cVrjgC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAwbBC06IQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:268231@DgQAAwbB1k7IoAYF]] Catalysed into [[item:271499@DgQBAwbB1k7IoAYFwxXQ]] | Coiled Altar |
| Cloak | [[item:268253@BgQAAwbBCKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DARAAwbBJk7wYNCKAWB]] | Ula'tek |
| Wrist | [[item:244584@FiQAAwbBeA8ciqjAtO3WzSB]] | Crafted |
| Gloves | [[item:271502@BgQAAwbBCKgTBA]] | Tier / Catalyst |
| Belt | [[item:251155@BiQAAwbBC06IoAOF]] | Den of Nalorakk |
| Legs | [[item:268237@DgQAAwbBbo6IoAYF]] Catalysed into [[item:271500@DgQBAwbBbo6IoAYFQzXQ]] | Coiled Altar |
| Boots | [[item:244577@HASAAwbBeA8ciqzD5OAAAAAAAA3WzSB]] | Crafted |
| Ring 1 | [[item:268249@DiQAAwbB3j7IQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAwbB3j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAwbBCKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270162@BgQAAEEACKgTBA]] | Nek'Zali |
| One-Handed Weapon | [[item:271092@DgQAAwbB9k7IoAYF]] | Ula'tek |
| Off-Hand | [[item:268263@BgQAAwbBCKgTBA]] | Nymrissa Wavecaller |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAAwbBCKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAAwbBCKQQBA]] | Kings Rest |
| Cloak | [[item:251132@BgQAAwbBCKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAAwbBCKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAAwbBCKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAAwbBCKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAwbBCKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAwbBCKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250215@BgQAAwbBCKQQBA]] | Murder Row |
| Trinket 2 | [[item:250214@BgQAAwbBCKQQBA]] | The Blinding Vale |
| Two-Hand Weapon | [[item:193761@BgQAAwbBCKQQBA]] | Ruby Life Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAEEACKgTBA]]  <br>[[item:270167@BgQAAEEACKgTBA]]  <br>[[item:270162@BgQAAEEACKgTBA]] |
| **A-Tier** | [[item:250214@BgQAAEEACKgTBA]]  <br>[[item:250215@BgQAAEEACKgTBA]] |
| **B-Tier** | [[item:273649@BgQAAEEACKgTBA]]  <br>[[item:270171@BgQAAEEACKgTBA]]  <br>[[item:270169@BgQAAwbBCKAWBA]]  <br>[[item:273794@BgQAAEEACKgTBA]]  <br>[[item:273796@BgQAAEEACKgTBA]] |
| **C-Tier** | [[item:250254@BgQAAEEACKgTBA]]  <br>[[item:250224@BgQAAEEACKgTBA]]  <br>[[item:193748@BgQAAEEACKgTBA]]  <br>[[item:193757@BgQAAEEACKgTBA]] |
| **Junkyard** | [[item:250248@BgQAAEEACKgTBA]]  <br>[[item:250259@BgQAAEEACKgTBA]]  <br>[[item:250255@BgQAAEEACKgTBA]] |

### Embellishments

- [[item:240167]] 2x
  
  - A generic embellishment you can put on any crafted armorpiece, it is generally recommended to craft embellishments with [[item:240167]] on the cloak and wrists slots as crafted items are lower item level and these 2 slots have the lowest amounts of stats on them. Since the cloak slot has a 344 item on its slot, the usual cloak craft is replaced by a craft on the boots slot instead.

### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Flask**
  
  - [[item:241322]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241300]]
  - [[item:241288]] -- Recommended
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240898]]
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:243951@DAAAAwbBZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwbB]] |
| Chest | [[item:243977@BAAAAwbB]] |
| Wrist | [[item:275707]] |
| Belt | [[item:275707]] |
| Legs | [[item:240155@BAAAAwbB]] |
| Boots | [[item:243983@BAAAAwbB]] |
| Ring 1 | [[item:243959@BAAAAwbB]] |
| Ring 2 | [[item:243959@BAAAAwbB]] |
| Weapon | [[item:244031@BAAAAwbB]] |

:::

:::column
:::gear **Preservation Evoker** Enchantments
```json
{
  "source_code": "JQFZ8WQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Macros

Discover recommended macros for **Preservation Evoker** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Preservation Evoker** Mythic+ Guide are available as mouseover macros for your convenience!

**[[spell:355913]]**

```wow-macro
/cast [@mouseover, help] Emerald Blossom; Emerald Blossom
```

**[[spell:364343]]**

```wow-macro
/cast [@mouseover, help] Echo; Echo
```

**[[spell:360823]]**

```wow-macro
/cast [@mouseover, help] Naturalize; Naturalize
```

**[[spell:374251]]**

```wow-macro
/cast [@mouseover, help] Cauterizing Flame; Cauterizing Flame
```

**[[spell:366155]]**

```wow-macro
/cast [@mouseover, help] Reversion ; Reversion
```

**[[spell:360995@FJQBKHXBOLZB2vYB7zwB-zwBNEA]]**

```wow-macro
/cast [@mouseover, help] Verdant Embrace; Verdant Embrace
```

:::

:::details Recommended Macros
**[[spell:370665]] specific player** --- *Replace PLAYERNAME with one of your group members.*

```wow-macro
/cast [@PLAYERNAME, @Cursor] Rescue
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Preservation Evoker**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/euiEvoker-1024x576.png>)

Preservation Evoker Interface in Mythic+

:::accordion
:::details Addons
- **EllesmereUI**-- Full UI Replacement Addon
  
  - The entire ui is made with Ellesmere ui and it controls raidframes, damage meter, nameplates, action bars and cooldown manager. Plus adds a lot of additional small quality of live features and is highly customizeable

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1.0
- EVOKER
- Preservation
  
  - Apex Talent: Merithra's Blessing has been updated – Now increases all healing of Dream Breath by 60% (was 250%, and previously applied only to its instant healing).
  - **Font of Magic has been updated – Now also reduces the empower time of Dream Breath and Fire Breath by 20%.**
  - **Dream Breath instant healing reduced by 50%.**
  - **Dream Breath periodic healing increased by 118%.**
  - **Temporal Barrier absorption increased by 30%.**
  - **Inner Flame increases periodic healing by 50% (was 60%).**
  - **Spiritual Clarity reduces the cooldown of Dream Breath by 6 seconds (was 10 seconds).**
  - **Fluttering Seedlings healing is now also increased by Titan's Gift.**
  - **Fixed an issue that could cause Time Dilation to not clear its stored damage on death.**
  - **Fixed an issue where Consume Flame healing was not being increased by Grace Period or similar effects.**
  - Hero Talents
    
    - Flameshaper
      
      - Expanded Lungs increases the healing of Dream Breath by 20% (was 30%).
      - **Conduit of Flame increases critical chance by 10% (was 15%). Does not affect Devastation Evoker.**
      - **Fulminous Roar causes Fire Breath and Dream Breath to deal their damage 15% more often (was 20%). Does not affect Devastation Evoker.**
      - **Fluttering Seedlings can now trigger Consume Flame.**
      - **Emerald Blossom and Fluttering Seedlings now prefer to heal injured allies with Dream Breath active while talented into Consume Flame.**
      - **Consume Flame heals for 240% of the amount consumed (was 200%).**
      - **Fixed an issue where Consume Flame's healing component could not critically heal.**
      - **Twin Flame damage and healing reduced by 20%.**
      - **Fixed an issue where Twin Flame was not scaling with Mastery.**

:::

:::

## FAQ

:::accordion
:::details Q: Why do I run out of Mana?
A: You cast too many [[spell:355913]] and [[spell:373861]].

:::

:::details Q: Why do people die if I don't have my cooldowns?
A: You need to make good use of [[spell:364343]] ramps into [[spell:366155]] more.

:::

:::details Q: What spell do I use with [[spell:364343]]?
A: Maintain [[spell:366155]] generally, then you can use [[spell:355936]] for big heals.

:::

:::

---

### Credits

Written By: **Ftmjgtde**

Reviewed By: **Rycn**

---

:::changelog 更新记录
**2026-08-09** Updted for patch 12.1.0

**2026-06-16** Updted for patch 12.0.7

**2026-04-25** Updted for patch 12.0.5

**2026-02-22** Updted for patch 12.0.1

**2026-01-18** Updated for patch 12.0



:::
