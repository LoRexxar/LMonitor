Welcome to the **Protection Warrior** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 5/5 · Excellent

AoE · 5/5 · Excellent

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Protection Warrior** Mythic+ Best in Slot
```json
{
  "source_code": "JkpAomEA3_fABAGJEIACBAw74OggC4UABk-FEAQEBAgCtOgCtOggCwYNYFQAeRSBjgQN5OQBjAwYBIDCFAQCB8AKYFgvXQQAjfBBAiQB1glgCgVAB8FJEIAKFAwo7OQf1IYNWYDG2EwFgagJEEABhOgA4EAAPk7A2-CD2cbNbWCAjAGMZJySBEgChOAgAFAAX16ARsBB2WTFdwhTVPAAIEAACGgogIW2DIICBAw94mgoU4UABAYLEojEAgQXfQQCwwAWBEwXdwABdfRGYQQsXUg1A0TCHzSAkeBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271456]] | [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240906]] · [[item:240906]] |
| 肩部 | [[item:271454]] | [[item:244021]] |
| 胸部 | [[item:271459]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240906]] |
| 腿部 | [[item:271455]] | [[item:244643]] |
| 脚部 | [[item:237828]] | [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240983]] |
| 手部 | [[item:251214]] |  |
| 戒指一 | [[item:252258]] | [[item:240906]] · [[item:243959]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243959]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:268196]] |  |
:::

:::

:::

## Midnight Changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Protection Warrior**, you have access to Phalanx, which gives you 5% damage reduction at basically 100% uptime and a bunch of damage bonuses on [[talent:112205@FAwAYdhAjnqBEMA]] and [[spell:23922]].

**Rank 2** increases the damage of [[talent:112205@FAwAYdhAjnqBEMA]] and Phalanx by 10% per point. While **Rank 3** increases [[spell:23922]] damage by 10% and crit chance by 20%. Enemies hit by [[spell:1269311]] deal 5% reduced damage to you for 8 sec.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-protwarrior-mxr.webp>)

Phalanx

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:132879]]
    
    - Got reworked from an active ability to a passive bonus to your [[talent:112156]].
- **Class Tree**
  
  - [[talent:134031@AJQABA]]
    
    - Can provide a massive survivability boost if you are taking frequent big hits and utilizing your [[talent:114644]].
    - The offensive part of the talent provides only a very small damage increase, making this talent often a damage loss to pick compared to alternatives.
  
  
  
  - [[talent:136627]]
    
    - Now additionally increases the movement speed of allies within 12y(or 24y) by 30% for 4 seconds!
  - [[talent:134033]]
    
    - Improves all your shout abilities.
- **Removed**
  
  - [[spell:384318]]
  
  
  
  - [[spell:383762]]

## Hero Talents

- [[talent:123388]] buffs your baseline rotation and brings in more rage without adding an extra ability.
- [[talent:123391]] has higher burst damage than [[talent:123388]] but comes at the cost of less defensive value and a worse playstyle.
- [[talent:123388]] is the recommended choice currently as it outperforms [[talent:123391]] in all scenarios.

### [[talent:123388]]

- [[talent:117400]]
  
  - Your [[talent:117400]] deal damage, and have a chance to proc [[talent:117404]].
- [[talent:117404]]
  
  - A low chance on [[talent:117400]] to get a significant [[talent:112261]] buff, and temporarily remove the cooldown of the ability.
- [[talent:117413]]
  
  - [[talent:112205]] is with this trait a better way to apply [[talent:112298]] and enable cleave, compared to [[spell:190411]].
  - With [[talent:112205]] being so strong, you barely lose single-target damage while cleaving, which is something [[talent:123390]] struggles with in comparison to [[talent:123392]].
- [[talent:117382]]
  
  - Transforms your [[talent:112205]] into [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]], dealing Stormstrike damage that ignores armor.
  - Has a chance to proc from [[talent:112261]].
- [[talent:117402]]
  
  - A reliable way to get [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]].
- [[talent:136070@AJQACA]]
  
  - Replaced a Class Tree talent, raises the priority of [[talent:112205]] during [[talent:112305@AJQACA]].
- [[talent:136068]]
  
  - You can extend [[talent:112285@AJQABA]] by using [[spell:435222]]. You can have [[talent:112285@AJQABA]] active for a majority of the time by prioritizing [[spell:435222]]  usage.

### [[talent:123391]]

- [[talent:117415]]
  
  - Gets significantly buffed by [[talent:117416]] damage wise.
  - Can be used in niche scenarios to immune stuns and knockbacks or as another small defensive.
- [[talent:117396]], [[talent:117393]] and [[talent:117408]]
- With all of these **Hero** **Talents** combined your [[talent:112152]] becomes your highest damage ability by far during AoE.
- [[talent:117390]]
  
  - [[talent:117415]] gets its cooldown reduced, significantly increased when you're pressing [[talent:112152]] a lot during AoE.
- [[talent:136073]]
  
  - Applies [[talent:135940]] to all targets hit by [[talent:117415]].
- [[talent:136072@AJQA]]
  
  - Further emphasizes [[talent:123393]] bleed damage that was already increased from [[talent:119856@AJQA]].
- [[talent:136071@AJQA]]
  
  - Increases your burst damage significantly with [[talent:117415]].

## Talents

### [[talent:123388]] Mythic+ Build

:::talents **Protection Warrior** [[talent:123388]] Mythic+ Build
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### When to use this spec

This is the default loadout going into any dungeon unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the dungeon. To make your life easier, dungeon-specific talent loadouts are available in the **Dungeons** section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:132885]]
  
  - This talent makes it important to stay in the vicinity of your teammates as much as possible to gain the maximum benefit.
- [[talent:112170]]
  
  - Gives your [[talent:112159]] a big offensive component, pair it up with your other offensive cooldowns.
- [[talent:112162]]
  
  - Significant cooldown reduction on [[talent:112159]] which is both a defensive and offensive gain.

##### Class Tree

- [[talent:112249]]
  
  - This is an incredible boost to your mobility, it gives you 2 charges of [[spell:100]].
- [[talent:112242]]
  
  - 2 second AoE stun.
- [[talent:112198]]
  
  - Single-target 4 second stun.
- [[talent:134032@AJQACA]]
  
  - Makes it very important to never overcap on Rage and also to use [[talent:112305@AJQACA]] on cooldown when possible to maximize the cooldown reduction.

##### Hero Talents

- [[talent:117414]]
  
  - Default pick because [[talent:112198]] is used a lot in Mythic+.
  - Can be swapped out for [[talent:118835]] if it's useful for the rest of your group.
- [[talent:117395]]
  
  - Default pick as [[talent:118836]] is not very useful.
- [[talent:118834]]
  
  - Very nice boost to Rage generation which is great for both defense and offense.
- [[talent:117394]]
  
  - Simply outperforms the other option as more [[talent:117400]] synergises well with [[talent:117404]].

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Free [[spell:5302]] deal 15% additional damage and cause your next [[spell:23922]] to deal 20% additional damage.
- **4-Set:** [[spell:228920]] and your free [[spell:5302]] cause all targets to bleed for X damage over 12 sec. [[spell:228920]] cooldown is reduced by 30 seconds.

#### [[talent:123388]]

##### Opener

- The goal of the opener is to get [[spell:2565]] active as soon as possible to avoid the possibility of getting one shot after [[spell:100]] in while also getting all your offensive cooldowns rolling.

- Below, you can see an example of how your opener might look, depending on when you get your first [[spell:437118@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]] proc among other factors.

:::rotation [[talent:123388]] **Protection Warrior** Opener in Mythic+
```json
{
  "source_code": "IkcAMcgQkBQBBAvXCYDpBAQACUgCAIAiEAAAAIkFkaQRCwwBSFQOsEAOEHwRAAAWXIQtUAgB4Jgj7JwpJOAjRYAJNcwJNcQACAAACIXXAAAAC53qGAAAEAlcvNGgDIgcdBAABIE-nLAAAIQAM4LVAI7gAA"
}
```
1. [[spell:100]]
2. [[spell:107574]]  [[spell:2565]]
3. [[spell:1160]]
4. [[spell:435222]]
5. [[spell:23922]]
6. [[spell:437118]] Proc 
   
   1. [[spell:23922]]  [[spell:190456]]
   2. [[spell:23922]]
   3. [[spell:435222]]
7. [[spell:435222]]
:::

##### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Cast [[spell:190456]] as your main Rage spender.
2. Maintain [[spell:2565]] at 100% uptime.
3. Cast [[talent:112304]] on cooldown if talented.
4. Cast [[talent:112305@AJQACA]] on cooldown.
5. Cast [[spell:1160]] on cooldown.
6. Cast [[spell:435222@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]] if you are at 2 stacks.
7. Cast [[spell:23922]] if [[spell:437118@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]] is active.
8. Cast [[spell:435222@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]].
9. Cast [[spell:23922]] on cooldown.
10. Cast[[spell:6572]] on AoE.
11. Cast [[spell:163201]] on 2 or less targets.

#### [[talent:123391]]

##### Opener

- The goal of the opener is to get [[spell:2565]] active as soon as possible to avoid the possibility of getting one shot after [[spell:100]] in while also getting all your offensive cooldowns rolling.

- Below, you can see an example of how your opener might look, depending on proc and other factors.

:::rotation [[talent:123391]] **Protection Warrior** Opener in Mythic+
```json
{
  "source_code": "IMEDIIEZAUQAkJgNkGAABIQBKAgAISAAAEgQ4fuAAAgAgOeBVwAWy1FAAAgQGiqBAAAAAIgcdBAAAIEoDaA"
}
```
1. [[spell:100]]
2. [[spell:107574]]  [[spell:2565]]
3. [[spell:1160]]  [[spell:190456]]
4. [[spell:385952]]  [[spell:190456]]
5. [[spell:23922]]
6. [[spell:436358]]
7. [[spell:23922]]
8. [[spell:426912]]
:::

##### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Cast [[spell:190456]] as your main Rage spender.
2. Maintain [[spell:2565]] at 100% uptime.
3. Cast [[talent:112304]] on cooldown.
4. Cast [[talent:112305@AJQACA]] on cooldown.
5. Cast [[spell:1160]] on cooldown.
6. Cast [[spell:385952]] on cooldown.
7. Cast [[spell:23922]] on cooldown.
8. Cast [[talent:117415]] on cooldown.
9. Cast [[spell:426912]] on cooldown.
10. Cast[[spell:6572]] on AoE.
11. Cast [[spell:163201]] on 2 or less targets.

### Defensive Stance vs. Battle Stance

- When swapping stances there are some factors you need to keep in mind:
  
  - [[spell:386208]] provides you with a 20% flat damage reduction and an additional 5% magic damage reduction.
  - [[spell:386164]] provides you with a 3% critical chance and a 10% reduction on slow and cc effects.
- Stay in [[spell:386208]] at all times when taking any damage since the 3% crit chance is just not worth it losing 20% or 25% damage reduction.
  
  - If you are not tanking anything and don't have any debuffs that do heavy damage to you, swapping to [[spell:386164]] is totally fine and provides a small DPS gain.

### Defensive Cooldowns

- [[spell:1160]] 
  
  - Most of the time you should use this on cooldown as it's a DPS increase when talented into [[spell:202743]]. You also have [[spell:335229]] that heavily reduces the cooldown which further incentivizes using it as much as possible.
- [[spell:871]]
  
  - This should be your first go-to when you need a big defensive as this spell also gets heavily reduced cooldown from [[spell:152278]] & [[spell:384072]].
- [[spell:202168]]
  
  - Not necessarily a defensive cooldown but a very nice self-heal tool. Just press it whenever you feel like a small heal would be useful.

### Offensive Cooldowns

- [[spell:385952]] 
  
  - Use on cooldown preferably while under the effect of [[spell:107574]] and [[spell:202743]].
- [[talent:112304]] 
  
  - Usually lines up with every 2nd [[talent:112305@AJQACA]].
- [[talent:112305@AJQACA]]
  
  - Use on cooldown as much as possible, extra important because of cooldown reduction from [[spell:152278]].

## Deep Dive

### Spell Reflection

- [[spell:23920]] is highly complex in the sense that it works differently for every mechanic and is often times the difference between **Protection Warrior** being very strong or mediocre.
- There is no one way to know at first glance if a spell cast on you is reflectable or not outside of just knowing beforehand through knowledge. 
  
  - To acquire this knowledge I highly recommend this [Spell Reflect Guide](<https://maxroll.gg/wow/resources/spell-reflect-guide>).

- Some important notes about [[spell:23920]]:
  
  - A spell does not always have to target you to be reflectable.
  - [[spell:23920]] provides 20% magic damage taken reduction for 5 seconds.
    
    - If a spell gets reflected and consumes the buff you still keep the 20% magic damage reduction for the full 5 seconds.

### Managing Ignore Pain

- [[spell:190456]] is your primary Rage spender together with [[spell:6572]], one is full damage where the other one is full defensive value.
- Juggling both is your main job when it comes to how you spend your rage.
  
  - [[spell:190456]] as the ability is different from all the others it does not occur a GCD when pressed but has its own small internal GCD, making it so you can press it while normally playing your rotation.
  - Where on the other hand [[spell:6572]] is a normal spender and also a GCD.
- As a rule of thumb, you want to always use [[spell:190456]] when reaching your Rage cap to not overcap and while taking any damage to just become tankier.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but numerous other key mechanics influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

[[spell:23920]] is a powerful tool for **Protection Warriors** in Mythic+ dungeons.

[**Spell Reflect Guide**](<https://maxroll.gg/wow/resources/spell-reflect-guide>) – Per-dungeon tables for every reflectable ability (bosses + trash).

**← Scroll for more Dungeons →**

### Altar of Fangs

:::talents **Protection Warrior** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### Rav'i

- Before [[spell:1296216]] happens you should move the boss to a **Carrion Pile** without [[spell:1307703]] to prevent the boss from getting buffed.
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- After the boss casts [[spell:1299053]] you need to break the [[spell:1287797]] with [[spell:6544]].
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.
  
  - In the regular phase it casts this 3 times with no lockout period between the casts.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal.

### Den of Nalorakk

:::talents **Protection Warrior** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
  
  - As a tank you want to do the majority of the soaking during this to reduce group damage, especially if there are soaks in the previous frontal.

##### Sentinel of Winter

- Move the boss to one of the adds and make sure to interrupt it. When you kill either add there is a soak that can be any group member, usually the group soaks the first one so the boss can be moved to the 2nd add. 
  
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you and stays in that area.

##### Nalorakk

- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.
  
  - When this cast finishes you get knocked away and a soak spawns that you have to get into or you wipe.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:115877]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.

### Murder Row

:::talents **Protection Warrior** Mythic+ Build in Murder Row
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him.
  
  - **Nibbles** dies at 20% and then **Kystia** gets affected by [[spell:1265412]].
- [[spell:1253811]] is a frontal that's always aimed at the tank, so try to aim it away from the group.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].
  
  - [[talent:112215]] is very good for this if you have [[talent:136625]].

##### Zaen Bladesorrow

- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during the actual cast.
  
  - If you have accidentally broken too many barrels earlier in the fight, you can stay out as the tank and live to let others take the barrels.

##### Xathuux the Annihilator

- [[spell:473898]] is a frontal that is always aimed at the tank, try to make it easy for the rest of the group.
- During [[spell:474197]] it's very important that you move the boss as little as possible but still move the boss out of the pools, recommend bac
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Ypu need to move the boss a lot early to get distance from the **Infernal** cause later on the boss casts a lot of spells and barely moves.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates unless you are getting a **Curse** dispel.

### The Blinding Vale

:::talents **Protection Warrior** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively.

##### Lightwarden Ruia

- When you get [[spell:1239824]] try to aim it so it's as easy as possible for your group.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]].

##### Ziekket

- When you get targeted by [[spell:1246607]] frontal make sure to hit the dead **Lashers** to remove them.
- Soak the light orbs flying towards the boss, they give you [[spell:1247052]] stacking buff, which increases your damage done but also deals a lot of DoT damage.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

### Voidscare Arena

:::talents **Protection Warrior** Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.

##### Atroxus

- Move the boss towards either of the pools where the **Toxic Creeper** spawns so that it can get cleaved.

##### Charonus

- [[spell:1227247]] can either be soaked by you as a tank, or they can outrun it with a big movement speed buff.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

### Kings' Rest

:::talents **Protection Warrior** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Your group members get [[spell:1306736]] debuffs which spawns a pool on the ground. When the boss casts [[spell:265923]] each poll spawns an **Animated Gold** add.
  
  - The only thing to worry about as a tank is that no adds can reach the boss.

##### Mchimba the Embalmer

- Most important thing is to kick [[spell:267763]] from any **Half-Finished Mummy**.

##### The Council of Tribes

- Group up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

### Ruby Life Pools

:::talents **Protection Warrior** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- When the boss casts [[spell:373046]] you need to be ready to get aggro on all of the **Whelps** very quickly, this is a healing intense part of the fight so your healer especially might have a lot of threat.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Tank **Erkhart** close to the 2 pillars in the boss room during phase 1, this makes it more likely that **Kyrakka** lands on the ground so you can cleave the bosses.
- Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful how you position the boss.
  
  - The winds rotate counter-clockwise looking from the entrance of the room.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

### Temple of Sethraliss

:::talents **Protection Warrior** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAGzwMzMzMmNzMLzYMGNzMGWMmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGYmZGGbAwMDAAzAjBA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to use [[talent:112242]] to cancel it on your group.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Interrupt [[spell:267027]] during the intermission.
- The intermission ends as soon as you kill the adds so it's not a bad idea to use your cooldowns there if they come up.

##### Galvazzt

- You can soak pillars as a tank but it's very risky since you get a 250% physical damage taken amp while doing it.

##### Avatar of Sethraliss

- Kite away the **Corrupted Guardian** as he is about to die cause he leaves behind [[spell:1302761]] which you don't want on top of the **Twister Hexxers**.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Protection Warrior**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:112242]] and [[talent:134254]] as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - The **Void Emissary** follows you, keep it close to cleave and target it whenever its up.
- Xal'atath's Bargain: Devour
  
  - This is just a healing absorb, the only tool you have is [[talent:112183]].
- Xal'atath's Bargain: Pulsar
  
  - Pay attention to your group members positions.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic + dungeons as a **Protection Warrior**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Protection Warrior** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFQAJxACKBEgABA"
}
```
**力量 ＞ 急速 ＞ 精通 ＝ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
**Avoidance** is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

### Overall BiS

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271456@DgQAAkEAvj7IoAOF]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAkEAK06oQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271454@DgQAAkEA1k7IoAOF]] | Tier / Catalyst |
| Cloak | [[item:268253@BgQAAkEACKAWBA]] | The Coiled Altar |
| Chest | Convert [[item:268222@AgQAAIoAYFA]]  <br>into [[item:271459@DgQBAkEAJk7IoAYFgvXQ]] | Catalyst of The Coiled Altar |
| Wrist | [[item:237834@BCUAAkEAX16Y7LMYzt1sZJ2WDAjAGMZJySB]] | Crafting |
| Gloves | [[item:251214@BgQAAkEACKgTBA]] | Den of Nalorakk |
| Belt | [[item:268259@BiQAAkEAK06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:271878@AARAAIoAWYDWBA]]  <br>into [[item:271455@DgSBAkEAju70XNCWjF2ghNCKAWBYgJE]] | Catalyst of Ula'tek |
| Boots | [[item:237828@DgTAAkEAPk7Y7LMYzt1sZJAMCYwklILF]] | Crafting |
| Ring 1 | [[item:252258@DiQAAkEA3j7oQrjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:273792@DiQAAkEA3j7oQrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270173@BgQAAkEACKAWBA]] | The Coiled Altar |
| Trinket 2 | [[item:270175@BgQAAkEACKAWBA]] | Ula'tek |
| Weapon | [[item:268209@DgQAAkEA9k7IoAYF]] | The Coiled Altar |
| Shield | [[item:268196@BgQAAkEACKgTBA]] | The Lost Explorers |

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@AgQAAIoABFA]] | Murder Row |
| Neck | [[item:273781@AgQAAIoABFA]] | Altar of Fangs |
| Shoulder | [[item:251138@AgQAAIoABFA]] | Murder Row |
| Cloak | [[item:193763@AgQAAIoABFA]] | Ruby Life Pools |
| Chest | [[item:193753@AgQAAIoABFA]] | Ruby Life Pools |
| Wrist | [[item:251133@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:159413@AgQAAIoABFA]] | Kings' Rest |
| Belt | [[item:159418@AgQAAIoABFA]] | Kings' Rest |
| Legs | [[item:273776@AgQAAIoABFA]] | Altar of Fangs |
| Boots | [[item:159412@AgQAAIoABFA]] | Kings' Rest |
| Ring 1 | [[item:273792@AgQAAIoABFA]] | Altar of Fangs |
| Ring 2 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Trinket 1 | [[item:273796@AgQAAIoABFA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@AgQAAIoABFA]] | Murder Row |
| Weapon | [[item:251195@AgQAAIoABFA]] | The Blinding Vale |
| Shield | [[item:159664@AgQAAIoABFA]] | The Blinding Vale |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAIEACKgTBA]]  <br>[[item:270175@BgQAAIEACKAWBA]]  <br>[[item:270173@BgQAAIEACKAWBA]] |
| **A-Tier** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:158367@BgQAAIEACKgTBA]]  <br>[[item:270174@BgQAAIEACKgTBA]]  <br>[[item:270160@BgQAAIEACKgTBA]]  <br>[[item:250228@BgQAAIEACKgTBA]] |
| **B-Tier** | [[item:250243@BgQAAIEACKgTBA]]  <br>[[item:159618@BgQAAIEACKgTBA]]  <br>[[item:250229@BgQAAIEACKgTBA]]  <br>[[item:193762@BgQAAIEACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAIEACKgTBA]]  <br>[[item:270163@BgQAAIEACKgTBA]]  <br>[[item:273795@BgQAAIEACKgTBA]]  <br>[[item:250259@BgQAAIEACKgTBA]]  <br>[[item:250244@BgQAAIEACKgTBA]]  <br>[[item:193757@BgQAAIEACKgTBA]]  <br>[[item:270168@BgQAAIEACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAIEACKgTBA]]  <br>[[item:250238@BgQAAIEACKgTBA]]  <br>[[item:273797@BgQAAIEACKgTBA]] |

### Embellishments

- 2x [[item:240166]]
  
  - Proc that gives you primary stat, also gives a small buff to an ally.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334-344 on max item level, therefore it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Flask**
  
  - [[item:241326]]
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:259085@AQAAAoF]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085]]
- **Sockets**
  
  - [[item:240906]]
  
  
  
  - [[item:240983]] *-- Unique*

### Enchantments

:::columns
:::column
| Head | [[item:243951@DAAAAkEAZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulders | [[item:244021]] |
| Chest | [[item:243977@BAAAAoQA]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:244643@BAAAAkE]] |
| Boots | [[item:243983@BAAAAkE]] |
| Ring 1 | [[item:243959]] |
| Ring 2 | [[item:243959]] |
| Weapon | [[item:243973@BAAAAkE]] |

:::

:::column
:::gear **Protection Warrior** Mythic+ Enchantments
```json
{
  "source_code": "IQFZJBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwo7mAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244643]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy ‍[[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Protection Warrior** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  - On top of that using Stoneform gives you 10% physical DR which can be used as a small extra 8 second personal when tanking.
- [[spell:58984]] -- Night Elf
  
  - Can be very useful when doing any kind of skip in Mythic+
  - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]]
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
  - Maximum range of 100 yards.

### Recommendation

As a tank picking a racial for damage is a small gain that is not worth it most of the time. If you care about min-maxing your DPS go with the highest DPS racial.

That being said the recommended race for Mythic+ is either Night Elf or Dwarf both offer unique features one being more tactical with Night Elf skips and the other being more reliable when it comes to your survivability.

## Macros

Discover recommended macros for **Protection Warrior** for Mythic+ and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:355]]* at your target or your mouseover (very handy to pick up mobs)

```wow-macro
#showtooltip Taunt
/cast [@mouseover,exists,harm][@target,exists,harm] Taunt
```

Boss 1 Taunt --- *Casts* [[spell:355]] on Boss1

```wow-macro
/cast [@boss1] Taunt
```

Boss 2 Taunt --- *Casts* [[spell:355]] on Boss2

```wow-macro
/cast [@boss2] Taunt
```

:::

:::details Mouseover Macros
**[[spell:100]]** *-- Charge your target unless your mouse is over another enemy, then it targets that enemy and charges it.*

```wow-macro
/target [@mouseover, harm, nodead]
/cast Charge
```

**[[spell:3411]]** *--- This macro makes you Intervene a friendly player your mouse is over.*

```wow-macro
/cast [@mouseover,help] Intervene
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Cursor Macros
**[[spell:228920]]**

```wow-macro
/cast [@cursor] Ravager
```

**[[spell:376079]]**

```wow-macro
/cast [@cursor] Champion's Spear
```

**[[spell:6544]]**

```wow-macro
/cast [@cursor] Heroic Leap
```

:::

:::details Recommended Macros
**[[spell:386208]] and [[spell:386164]]** *--- With this you can swap stances from 1 keybind.*

```wow-macro
/cast [stance:2] Defensive Stance; stance[:3] Battle Stance
```

**[[spell:3411]]** *--- This macro makes you Intervene a friendly player in the direction you are facing. It is less precise than a mouse over macro, but easier to use.*

```wow-macro
/targetfriendplayer
/cast Intervene
/targetlasttarget
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Protection Warrior**, outlining which addons are used and how they are utilized in Mythic+ to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/ProtmidnightdungeonUI-ezgif.com-png-to-webp-converter-1-1024x682.webp>)

**Protection Warrior** User Interface in Mythic+

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI** -- Additional customization for the Cooldown Manager
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI. With EllesmereUI you can easily disable modules you don't want and only use it for the CDM in this case.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripts.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Warrior
  
  - Developers' notes: Rend is an iconic and core Warrior ability with a different relationship to each spec. Our approach to Rend in Midnight hasn't worked out as we hoped, so we're making changes to how each spec applies and interacts with Rend in Curse of Ula'tek.
  - The Rend ability is now exclusive to Arms, has returned to being a single-target ability, and its Rage cost is reduced to 10. Cleave will apply Rend to all targets if the Warrior knows Rend.
  - New Talent (Fury): Storm of Blood – Whirlwind applies Rend to all targets. Crashing Thunder causes Storm of Blood to also apply to Thunder Clap for Mountain Thane.
  - New Talent (Protection): Blood and Thunder – Thunder Clap applies Rend to all targets.
  - Thunder Clap no longer innately applies Rend if known.
  - Javelineer has a new icon.
  - **Hero Talents**
    
    - **[[talent:123391]]**
      
      - *Developers' notes: Demolish's variable cooldown has proven to be more frustrating than interesting, so we're changing it to align closely with Colossus Smash, enabling Arms Colossus Warriors to coordinate their use for maximum devastation.*
      - No Stranger to Pain has been updated – Damage prevented by each use of Ignore Pain increased by 30% (was 20%).
      - Dominance of the Colossus has been updated – Enemies damaged by Demolish deal 20% reduced damage to you for 10 seconds (was 10%) and no longer reduces the cooldown of Demolish.
      - Demolish cooldown reduced to 30 seconds (was 45 seconds).
    - **[[talent:123388]]**
      
      - *Developers' notes: Thunder Clap's base damage increased significantly in Midnight, causing overall Thunder Clap damage to rise significantly for Mountain Thane, which in turn devalued Thunder Blast. We're moving the Crashing Thunder damage bonus into Thunder Blast itself to keep Thunder Blast feeling special and powerful.*
      - Thunder Blast damage increased by 20%.
      - Crashing Thunder increases Thunder Clap damage by 10% (was 30%).
  - Protection
    
    - Devastating Focus has been updated – Now increases Revenge and Execute damage dealt to the target (was Revenge only).
    - Bloodborne has been updated – Now increases all Bleed damage (was only Rend and Deep Wounds).
    - Ravager has been updated –
      
      - Ravager damage increased by 50% and its duration is no longer reduced by Haste.
      - Ravager no longer increases Revenge and Thunder Clap damage while active. Ravager now causes all enemies it damages to take 50% increased damage from your Bleeds for 12 seconds. Duration reduced to 4 seconds with Whirling Blade.
      - *Developers' notes: Ravager is a unique ability and we want the Ravager itself and its positioning to be important, but the current design puts more emphasis on its value as an AOE damage amp rather than the Ravager itself. We're redesigning Ravager slightly to address this, as well as to increase Ravager's value in all combat situations.*
    - Revenge has been updated – Your successful dodges, parries, and auto-attacks have a chance to make your next Revenge cost no Rage (was only dodges and parries). Damage increased by 20%.
      
      - *Developers' notes: Protection’s free Revenge counter-attack mechanic has existed for a long time, and we love it, but we don’t love how wildly its frequency and impact vary depending on what content you are doing. In dungeons, Revenge! triggers very frequently, contributing to many buttons being highlighted at once and overwhelming the rotation, but in raids and solo content, Revenge! frequency is so low as to feel weak and exacerbate Rage starvation issues. Our goal here is to shrink the gap between these extremes and make sure Revenge! procs feel meaningful while not crowding your rotation.*
    - All ability damage increased by 11%.
    - Fueled by Violence heals you for 125% of Bleed damage dealt (was 110%).
    - Ignore Pain absorb amount increased by 25%.
    - Brutal Vitality adds 10% of damage dealt to Ignore Pain (was 8%).
    - Unyielding increases the damage reduction bonus of Defensive Stance by 6% (was 4%).
    - **Hero Talents**
      
      - **[[talent:123391]]**
        
        - Practiced Strikes has been updated – Shield Slam generates an additional 4 Rage (was 3).
        - Tide of Battle increases the damage of Revenge and Execute (was Revenge only).

:::

:::details Patch 12.0.1
- Warrior
  
  - Hero Talents
    
    - [[talent:123391]]
      
      - *Developers' notes: We want Demolish to feel satisfying to use even at low or no Colossal Might stacks, so we’re moving some of the Colossal Might damage into the ability’s baseline damage.*
      - Demolish damage increased by 65%.
      - Colossal Might increases damage of your next Demolish by 5% per stack (was 10%).
      - Protection
        
        - Practiced Strikes damage bonus increased to 15% (was 10%).
  
  
  
  - Protection
    
    - Ground Current damage increased by 150%.
    - Lightning Strike damage increased by 50%.
    - Thunder Blast damage reduced by 30%.

:::

:::details Patch 12.0
- Warrior
  
  - New Talent: Resonant Voice – The duration of your shouts is increased by 20%.
  - New Talent: Retaliation – When you take any damage from an enemy within melee range, you have a chance to strike that enemy for Physical damage.
  - New Talent: Stance Mastery – Your stances have additional effects.
    
    - Battle Stance: Increases the critical strike damage of your abilities by 3%.
    - Berserker Stance: Increases your auto-attack speed by 3%.
    - Defensive Stance: When an attack deals 20% or more of your maximum health in damage, that damage is reduced by 15%.
  - New Talent: Battlefield Commander – Your Shout abilities have additional effects.
    
    - Battle Shout: Grants you an additional 3% attack power.
    - Rallying Cry: Grants an additional 2% health and duration increased by 3 seconds.
    - Piercing Howl: Radius increased by 100%.
    - Berserker Shout: Radius increased by 100%.
    - Intimidating Shout: Cooldown reduced by 15 seconds.
  - New Talent: Anger Management – Every 20 Rage you spend reduces the remaining cooldown on Avatar, Colossus Smash, Recklessness, and Shield Wall by 1 second.
  - New Talent: Field Dressing – Healing received increased by 3% and all self-healing increased by an additional 10%.
  - New Talent: Fearless – Cooldown of Berserker Rage is reduced by 50% and Berserker Rage removes all movement speed-impairing effects.
  - New Talent: Javelineer – Range of your thrown abilities is increased by 5 yards. Damage dealt by Champion's Spear, Shattering Throw, and Wrecking Throw increased by 20%. Shattering Throw and Wrecking Throw silence non-players for 3 seconds.
  - New Arms and Fury Talent: Interpose – Run at high speed toward a target location near your allies, taking 30% of all damage dealt to allies within 3 yards for 8 seconds or until you take at least 20% of your max health in damage from this effect.
  - New Arms and Fury Talent: Rend – Lash out with your weapon, striking all targets within 8 yards for Physical damage and wounding them for additional Bleed damage over 15 seconds.
  - Champion's Spear has been redesigned – Throw a spear at the target location, chaining all enemies in the area to the spear's location and dealing Physical damage instantly and additional Physical damage over 6 seconds. While the spear is active, activating this ability will cause you to leap to the spear, slamming down to deal Physical damage to all targets. All damage dealt reduced beyond 5 targets. Generates 10 Rage.
  - Intimidating Shout now reduces the movement speed of all targets by 70% and causes all enemies other than your primary target in range to flee. Was previously 8 targets.
  - Rallying Cry has been updated – Health granted is increased by 50% when not in a raid.
  - Honed Reflexes now reduces cooldowns by 10% (was 5%) and has an additional effect – Successfully interrupting an enemy increases the damage you deal to them by 5% for 10 seconds.
  - Piercing Howl now also spurs all allies within 12 yards, increasing their movement speed by 30% for 4 seconds.
  - Barbaric Training now increases damage dealt by 10% and critical strike damage by 5% for Slam, Whirlwind, Thunder Clap, Raging Blow, and Revenge.
  - Shattering Throw and Wrecking Throw range reduced to 25 yards (was 30 yards).
  - Thunder Clap damage increased by 150% and applies Rend to all targets if talented.
  - Shield Slam damage increased by 140%.
  - Second Wind healing while you are below 35% health increased by 100%.
  - Crushing Force is now a 1-point talent.
  - Many talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Avatar *(moved to each specialization's talent tree)*
    - Berserker's Torment
    - Blademaster's Torment
    - Cacophonous Roar
    - Challenger's Might
    - Concussive Blows
    - Immovable Object
    - Menace
    - Piercing Challenge
    - Seismic Reverberation
    - Thunderous Roar
    - Thunderous Words
    - Titan's Torment
    - Unstoppable Force
    - Uproar
    - Warlord's Torment
- Mountain Thane
  
  - New Talent: Storm Surge – Avatar increases the damage of Thunder Clap by 50% and reduces its cooldown by 50%.
  - New Talent: Conductivity – Lightning Strike damage increased by 10% and critical strike damage increased by 10%.
  - New Talent: Capacitance –During Avatar Thunder Blast extends Avatar's duration by 2 seconds.
  - Thunder Blast damage increased by 150%.
- Colossus
  
  - New Talent: Decimator – Demolish's final strike applies Deep Wounds to all targets at 100% effectiveness.
  - New Talent: Cut to the Bone
    
    - Arms: Mortal Strike critical strikes increase your Rend and Deep Wounds damage by 25% for 8 seconds.
    - Protection: Shield Slam critical strikes increase your Rend and Deep Wounds damage by 25% for 8 seconds.
  - New Talent: Celeritous Conclusion
    
    - Arms: Demolish's final strike grants 10% Haste for 10 seconds and increases the critical strike chance of your next Mortal Strike by 100%.
    - Protection: Demolish's final strike grants 10% Haste for 10 seconds and increases the critical strike chance of your next Shield Slam by 100%.
  - Demolish now makes the Warrior immune to movement forces during the channel.
  - Tide of Battle's Colossal Might increases damage of Revenge by 3% per stack (was 7%).
  - One Against Many no longer affects Whirlwind.

- Protection
  
  - New Talent: Devastating Focus – You focus on the target struck by your Devastator, dealing 30% additional Revenge damage to them. Only one target can have your focus at a time.
  - Avatar moved to the Protection specialization tree and has been updated – Transform into a colossus, increasing all damage you deal by 20% and reducing all damage you take by 3% for 20 seconds.
  - Deep Wounds is now a talent (was learned at level 10) and has been redesigned – Execute inflicts Deep Wounds on the target, causing high damage over 6 seconds.
  - Last Stand has been redesigned – Activating Shield Wall increases your maximum health by 30% for 8 seconds and instantly heals you for that amount.
  - Ravager has been updated – Additional effect: Revenge and Thunder Clap deal 50% increased damage while Ravager is active. Ravager is now thrown at your target.
  - Auto-attack damage increased by 100%.
  - Devastator damage increased by 100%.
  - Devastate damage increased by 100%.
  - Shield Charge damage increased by 100%.
  - Tough as Nails damage increased by 100%.
  - Revenge damage increased by 200%.
  - Violent Outburst now only buffs your next Shield Slam (was Shield Slam and Thunder Clap).
  - Bloodsurge has a chance to generate 5 Rage every time Rend deals damage (was Deep Wounds).
  - Fueled By Violence now heals for Bleed damage from Rend and Deep Wounds.
  - Several talents has changed positions in the talent tree.
  - The following talents have been removed:
    
    - Anger Management *(moved to the class talent tree)*
    - Bolster
    - Red Right Hand
    - Rend *(moved to the class talent tree)*
    - Sweeping Revenge
    - Unnerving Focus

:::

:::

## FAQ

:::accordion
:::details Q: How do I not get tired from spamming [[spell:190456]] all the time?
A: I recommend binding [[spell:190456]] to something like Scroll Wheel.

:::

:::

---

### Credits

Written by: **Wolfdisco**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-04** Updated for patch 12.1

**2026-06-17** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-19** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-07-22** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-20** Updated for patch 11.1

**2024-12-17** Updated for Patch 11.0.7

**2024-10-27** Updated for Patch 11.0.5

**2024-08-17** Updated for Patch 11.0.2

**2024-07-28** Guide Written for patch 11.0.



:::
