欢迎阅读**神圣 圣骑士**《魔兽世界》12.1.0 版本团队副本攻略！本攻略涵盖了理解该角色所需的全部知识。如果你刚刚开始，正在从 80 级升级，请先查看升级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**整体治疗** · 4/5 · 强

冷却技能强度 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 4/5 · 强

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **神圣 圣骑士** 团队副本 最佳装备
```json
{
  "source_code": "JsoAIGEA3_fABkGJEIICBAw74OwVtOggC4UABk-FEAQEBAgAtOgABIBNMWDWBEwZkQgAIEAA1kbCjAAbB8ACFAQCB8AKYFgvXQQAjfBBAiQB1AkgCgVABYgJEIAEBAwGqOgF2UQEARQoDYAIBAgHAPwJqOwD5OAAFEAJ3WzSBEgChOAhIExGIIQrDUQFcoGJEAACBAggBEJBZfRBjSw94GgHFIBFeqmACiQAuIBAEQ1HZADAX1BDE09FNgBEYFQAzeRBFDQPJYLLBY-FEAACBAggC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240898]] |
| 腿部 | [[item:271878]] | [[item:240155]] |
| 脚部 | [[item:237828]] | [[item:245790]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268211]] | [[item:244029]] |
| 副手 | [[item:268262]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**巅峰天赋**的3级。

作为 **神圣 圣骑士**，你可以使用 [[spell:1244878]]，它会自动对低血量的盟友施加圣光信标，当附近其他盟友血量降低时，该信标会转移目标。

**第2级** 使 [[spell:1244878]] 更强大，你的治疗额外转移10%到信标中，并使拥有你 [[spell:1244878]] 的盟友从你这里受到的治疗提高20%。而 **第3级** 使 [[spell:1244878]] 每8秒或每次转移到新盟友时提供吸收护盾。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-holypala-mxr.webp>)

救世道标

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[spell:461287]]
    
    - 这个天赋为我们提供了可观的被动伤害
  - [[spell:1277651]]
    
    - 这个天赋过去会在施放 [[spell:375576]] 或 [[spell:31884]] 后强化我们的 [[spell:25912]]。现在它只是对你信标的一个修正效果。
  - [[spell:1241714]]
    
    - 将我们终结技的部分治疗转化为吸收。除非你的法术大量过量治疗，否则这不是一个很强的天赋。
  - [[spell:248033]]
    
    - 这个天赋现在与 [[spell:1241358]] 配合得非常好
  - [[spell:414273]]
    
    - [[spell:31884]] 现在会强化你的下2次 [[spell:82326]] 施法。
- **职业天赋树**
  
  - [[spell:1277443]]
    
    - 这个天赋大幅提升了我们的被动坦度。
  - [[spell:1241945]] 和 [[spell:183416]]
    
    - 这两个天赋已被拆分，现在是两个独立的顶级天赋。暮光降低我们受到的伤害，而黎明则在你处于高血量时将盟友受到的伤害转移给你，相当于为盟友提供一种减伤手段。
  - [[spell:1265549]]
    
    - 当你攻击过的小怪死亡时提供一小段治疗爆发。在有大量小怪的场合表现良好。
- **已移除**
  
  - [[spell:35395]]
    
    - 这个技能现在成为 [[spell:216331]] 的一部分，不再是独立技能，稍微限制了我们的圣能获取。

## 英雄天赋

- [[talent:123362]] 专注于治疗和冷却技能强度，而 [[talent:123359]] 专注于生存能力和输出伤害。
- 在 团队副本 环境中，[[talent:123362]] 在任何情况下都优于 [[talent:123359]]。因此本攻略只专注于更好的那个选项。

### [[talent:123362]]

- 在使用 [[spell:114165]] 或 [[spell:375576]] 后，你可以通过 神圣 能量终结技施加2层 [[spell:431377]]。当 [[spell:31884]] 或 [[spell:216331]] 处于激活状态时，你会与所有带有 [[spell:431377]] 的目标以光束相连，治疗/伤害任何穿过光束的单位。
  
  - 当 [[spell:431377]] 激活时，得益于 [[talent:117778]]，你的 神圣 能量终结技效果提高3%。
  - 拥有 [[talent:117691]] 时，当 [[spell:431377]] 激活期间你的急速提高。此效果可叠加。
- 你的核心专精技能会受到以下节点强化：
  
  - [[spell:85673]] 被 [[spell:156322]] 取代，变得更加强大，并额外附带持续治疗效果。
  - [[spell:20473]] 和 [[spell:85222]] 会获得以下强化：
    
    - [[talent:117677@AJgA]] 使爆击几率提高5%。
    - [[talent:117669@AJgA]] 会在爆击时触发。
    - [[talent:117683@AJgA]] 提供15%几率以30%效果再次施放。

### [[talent:123359]]

- [[talent:117882]] 在 [[spell:432472]] 和 [[spell:432459]] 之间轮流切换，使你可以用当前的武装为自己和目标提供增益。这些技能会替换 [[spell:114165]] 或 [[spell:375576]]
  
  - 持有 [[spell:432472]] 时，你的法术和技能有几率造成额外的伤害或治疗。
  - 在 [[spell:432459]] 生效期间，你获得相当于最大生命值15%的吸收量，并且每2秒额外获得2%的吸收量。
  - [[talent:117877]]、[[talent:117876]]、[[talent:117885]] 和 [[talent:117874]] 让你能够拥有更高的武装覆盖率。
  - 激活 [[spell:31884]] 会召唤另一个 [[spell:432472]]。当 [[spell:31884]] 处于激活状态时，[[spell:432472]] 会回响你的 神圣 之力消耗技能。
  - 多亏了 [[talent:117886]]，你当前激活的光环对拥有武装的盟友效果提高33%。
- 少数技能会被以下节点强化： 
  
  - 当 [[spell:20271]] 造成暴击时，[[talent:117887]] 会在你的目标周围引发一次巨大的伤害/治疗爆发。
  
  
  
  - [[talent:117881]] 附魔在你的武器上时，使你的护甲提高5%，主属性额外提高2%。

## 天赋

### [[spell:31884]]

:::talents **神圣 圣骑士** 默认 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 何时使用该专精

这是进入任何首领战时的默认配置，除非另有说明。你需要根据战斗所需的团队辅助能力来调整职业天赋树。为了让你的生活更轻松，在欧米茄法力熔炉部分提供了针对特定首领的天赋配置。

#### 改变游戏玩法的天赋

探索专精和职业天赋树中显著改变你游戏方式的所有天赋。本节将简明概述这些天赋及其应用，如需更详细的了解，请查看下方的循环和深度解析部分。

##### 专精树

- [[spell:200025]] 或 [[spell:156910]]
  
  - [[spell:200025]] 是默认选择，因为它提供更高的治疗量，但代价是会干扰你的输出循环，并且法力消耗更高。[[spell:156910]] 是一个极强的选项，当你需要长时间持续治疗同样的2个目标，或者法力即将耗尽时，可以切换到它。
- [[spell:114165]] 或 [[spell:375576]]
  
  - 它本身已不如从前强大，但作为 [[talent:123362]] 它们使我们能够使用 [[spell:431377]]，这使它们变得非常重要。理想情况下，你想将它与 [[spell:31884]] 配合使用，来强化本已强大的技能。

##### 职业树

- [[spell:1277443]] 和 [[spell:402964]]
  
  - 这些天赋使圣骑士 即使没有开启防御技能也超级坦。
- [[talent:115466]]
  
  - 这个天赋使你的 [[spell:375576]] 和 [[spell:114165]] 窗口期更加强大。注意在这个增益期间不要让 神圣 能量溢出！

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：**[[spell:53576]] 使 [[spell:19750]] 的治疗量额外提高100%，[[spell:218178]] 的吸收量额外提高100%
- **4件套：**[[spell:20271]] 现在有20%的几率给予 [[spell:53576]]。[[spell:82326]] 现在有100%的几率给予 [[spell:53576]]，但其法力消耗提高50%。

### 优先级列表

- **切勿** 让 神圣 能量溢出。你的能量消耗技能非常强大，即使没有多少需要治疗的目标，你也总是可以使用 [[spell:53600]]。
- 尽可能多地施放 [[spell:20473]]。它是 神圣 圣骑士 的核心手段。
- 将你的 [[spell:53576]] 增益用于 [[spell:19750]] 以返还 [[spell:20473]]，而且它本身就是一个相当大的治疗量

#### [[spell:31884]]

1. 如果点了该天赋，需要时可施放 [[spell:200025]] 进行 范围伤害 治疗，否则可以跳过以节省法力。
2. 如果达到5层 神圣 能量，就消耗 神圣 能量。
3. 如果法力充足就施放 [[spell:82326]]。这是一个非常昂贵但极其强大的法术
4. 施放 [[spell:20473]] 的第一层充能。
5. 对敌人施放 [[spell:114165]] 进行 范围伤害 治疗，或对盟友施放 [[spell:375576]] 达到相同效果。
6. 将 [[spell:53576]] 用于 [[spell:19750]]。
7. 施放 [[spell:20473]] 的第二层充能。
8. 消耗 神圣 能量。
9. 如果需要立即治疗，施放 [[spell:19750]]。
10. 施放 [[spell:20271]]。

### 冷却技能

#### 复仇之怒

- 一个标志性的圣骑士冷却技能，如今凭借[[talent:123362]]本身已非常强大。你想将它与其他较小的冷却技能如 [[spell:304971]] 和 [[spell:114165]] 搭配使用，以增强它们的效果。

#### 圣洁鸣钟

- 你的主要短冷却技能，应每2分钟与[[spell:31884]]一起使用，以充分利用[[spell:1263920]]等各类天赋，这些天赋最终会相互增益，提供额外的治疗量。

#### 光环掌握

- 主要与[[spell:465]]配合使用，提供全团伤害减免冷却技能之一。它不像以前那么强力了，但在应对某些机制时仍可能扭转战局。务必在伤害事件发生之前主动使用它；否则可能会浪费一个公共冷却。

## 深度解析

#### 冷却技能管理

- 要最大化神圣 圣骑士的潜力，关键在于合理组合你的冷却技能。你应该在进入战斗前规划好[[spell:114852]] / [[spell:375576]]以及[[spell:31884]]的施放，并评估是否要使用[[spell:379391]]这类天赋来更容易地同步你的冷却技能。如果你在[[spell:31884]]的持续时间内没有施放[[spell:114852]] / [[spell:375576]]，由于[[spell:1263920]]以及其他各种增益的叠加，你会损失大量价值。因此提前规划并思考每个技能的施放时机非常重要。下面是一个示例规划的时间线，未使用[[spell:379391]]天赋。

:::timeline
```json
{
  "source_code": "IUFX29P_SDgAA0gAMyHAPAgAYsbBPAgA13bAJYAN8AgAYsbB8AgA13bApBQAkAglFIBApVgEJwQCGAzwAIQ99GwwAIAG7Www"
}
```
总时长：210 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 15 秒 | [[spell:114165]] | 上轨 |
| 15 秒 | [[spell:31884]] | 上轨 |
| 15 秒 | [[spell:375576]] | 上轨 |
| 60 秒 | [[spell:114165]] | 上轨 |
| 60 秒 | [[spell:375576]] | 上轨 |
| 105 秒 | [[spell:114165]] | 上轨 |
| 105 秒 | [[spell:375576]] | 上轨 |
| 150 秒 | [[spell:114165]] | 上轨 |
| 150 秒 | [[spell:31884]] | 上轨 |
| 150 秒 | [[spell:375576]] | 上轨 |
| 195 秒 | [[spell:114165]] | 上轨 |
| 195 秒 | [[spell:375576]] | 上轨 |
| 195 秒 | [[spell:375576]] | 上轨 |
:::

#### 优化终结技能

- 目前，在团队副本中[[spell:85222]]提供的治疗量高于[[spell:156322]]。但借助[[spell:156322]]，你可以完全掌控哪些目标接受你所有的治疗。因此你需要判断是否有人处于危险之中，以及按下[[spell:156322]]来保住某个特定的人是否划算。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下技巧主要适用于英雄难度首领。史诗难度技巧将在我们的开荒进度结束后发布。

**← 滚动查看更多首领 →**

### 内克扎莉

:::talents **神圣 圣骑士** 内克扎莉 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 在房间边缘驱散中了 [[spell:1287322]] 的队友！
- 当首领施放 [[spell:1284103]] 时，不要站在首领和坦克之间。

### 陵寝哨兵

:::talents **神圣 圣骑士** 陵寝哨兵 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 驱散受到[[spell:1284471]]影响的玩家。
- [[spell:1284590]] 在恰好叠到4层时会无害地被中和。

### 迷失的探险者

:::talents **神圣 圣骑士** 迷失的探险者 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 驱散受到[[spell:1286921]]影响的人。

### 瓦什尼克

:::talents **神圣 圣骑士** Vashnik 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 对受到 [[spell:1295224]] 影响的玩家使用单体技能（外部增益）。在受影响期间，他们免疫你的常规治疗。
- 受到 [[spell:1294994]] 影响时请使用个人减伤。

### 斯索拉克

:::talents **神圣 圣骑士** 斯索拉克 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 对受到 [[spell:1286987]] 影响的玩家使用单体技能（外部增益）。

### 双生利牙

:::talents **神圣 圣骑士** 双生利牙 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 防御技能
  
  - 在受到[[spell:1290809]]影响时使用个人防御技能。

### 盘绕祭坛

:::talents **神圣 圣骑士** 蟠曲祭坛 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。

### 乌拉特克

:::talents **神圣 圣骑士** 乌拉特克 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。

### 尼姆瑞莎·唤波者

:::talents **神圣 圣骑士** 尼姆瑞莎·唤波者 团队副本 天赋
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### 首领攻略技巧

- 当大量 [[spell:1257717]] 被触发时，使用个人防御技能。

## 属性优先级

了解你作为**神圣圣骑士**在团队副本首领战中获得最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问**[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **神圣中的圣骑士**团队副本
```json
{
  "source_code": "IoAJFUQMkgCIBEQABA"
}
```
**智力 ＞ 精通 ＞ 急速 ＞ 全能 ＞ 暴击**
:::

> 此处的结论是，你通常应当装备装等最高的装备。

- 暴风雪 引入了属性收益递减机制，你应当对此有所了解。想了解它们是什么以及为什么需要关注，请点击[这里](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) 查看我们详细的属性递减机制资源帖！

### 第三属性

- **闪避** - 减少受到的范围伤害效果伤害。
- **吸血** - 将你造成的伤害和治疗的一部分以治疗形式返还给你。（不包括自我治疗）
- **加速** - 提高移动速度。（可与其他加速移动技能叠加）

唯一需要考虑选择较低装等装备的情况，是它带有吸血或闪避属性时。加速也不错，但在两件装备之间抉择时不应考虑该属性。

- 以下展示吸血对治疗者来说有多强大：来自弗拉希乌斯团队测试的详细数据

![](<https://assets-ng.maxroll.gg/wordpress/HpalBreakdown-1-1024x572.png>)

神圣 **圣骑士** 来自 Warcraftlogs 的治疗数据

## 装备

### 最佳配装

由于 **神圣 圣骑士**的属性权重运作方式，并不存在严格意义上的最佳配装（BiS）列表。虽然理论上可以获得所有副属性都正确的物品，但由于《魔兽世界》的每周重置机制，这需要极好的运气或几代人的时间才能实现。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271465@DiQAAEEAvj7cVrjgC4UA]] | 套装/催化 |
| 项链 | [[item:268265@BERAAEEAC06IQrjgCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271463@DgQAAEEA1k7IoAOF]] | 套装/催化 |
| 披风 | [[item:268253@BgQAAEEACKAWBA]] | 盘曲祭坛 |
| 胸部 | [[item:268222@BgQAAEEACKAWBA]] 催化为 [[item:271468@DgQBAEEAJk7IoAYFgvXQ]] | 盘曲祭坛 |
| 护腕 | [[item:237834@FiQAAEEAeA8ciqjAtO3WzSB]] | 制造 |
| 手套 | [[item:271466@BgQAAEEACKgTBA]] | 套装/催化 |
| 腰带 | [[item:268259@BiQAAEEAC06IoAYF]] | 盘曲祭坛 |
| 腿部 | [[item:271878@DARAAEEAbo6YhNCKAWB]] | 乌拉特克 |
| 靴子 | [[item:237828@HASAAEEAeA8ciqzD5OAAAAAAAA3WzSB]] | 制造 |
| 戒指 1 | [[item:268249@DiQAAEEA3j7IQrjgC4UA]] | 瓦什尼克 |
| 戒指 2 | [[item:158366@DiQAAEEA3j7IQrjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:270164@BgQAAEEACKgTBA]] | 迷失的探险者 |
| 饰品 2 | [[item:270167@BgQAAEEACKgTBA]] | 尼姆瑞莎·唤波者 |
| 单手武器 | [[item:268211@DgQAAEEA9k7IoAYF]] | 盘曲祭坛 |
| 副手 | [[item:268262@BgQAAEEACKgTBA]] | 尼姆瑞莎·唤波者 |

#### 作者的话：

此清单列出了 大秘境 中来自所有来源的最佳治疗装备。请注意，获得带有吸血/闪避的不同套装部件会改变哪件散件对你来说最优。同样，任何其他带有吸血/闪避的非饰品装备都可以替换这里推荐的装备。

### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251126@BgQAAEEACKQQBA]] | 密谋小径 |
| 项链 | [[item:251234@BgQAAEEACKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:251138@BgQAAEEACKQQBA]] | 密谋小径 |
| 披风 | [[item:251132@BgQAAEEACKQQBA]] | 密谋小径 |
| 胸部 | [[item:251151@BgQAAEEACKQQBA]] | 纳洛拉克的洞穴 |
| 护腕 | [[item:159409@BgQAAEEACKQQBA]] | 诸王之眠 |
| 手套 | [[item:159413@BgQAAEEACKQQBA]] | 诸王之眠 |
| 腰带 | [[item:159418@BgQAAEEACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:273776@BgQAAEEACKQQBA]] | 毒牙祭坛 |
| 靴子 | [[item:159412@BgQAAEEACKQQBA]] | 诸王之眠 |
| 戒指 1 | [[item:251136@BgQAAEEACKQQBA]] | 密谋小径 |
| 戒指 2 | [[item:158366@BgQAAEEACKQQBA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:250214@BgQAAEEACKQQBA]] | 夺目谷 |
| 饰品 2 | [[item:273649@BgQAAEEACKQQBA]] | 诸王之眠 |
| 单手武器 | [[item:160216@BgQAAEEACKQQBA]] | 诸王之眠 |
| 副手 | [[item:251150@BgQAAEEACKQQBA]] | 纳洛拉克的洞穴 |

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAEEACKgTBA]]  <br>[[item:270167@BgQAAEEACKgTBA]] |
| **A级** | [[item:273649@BgQAAEEACKgTBA]]  <br>[[item:250214@BgQAAEEACKgTBA]]  <br>[[item:270162@BgQAAEEACKgTBA]] |
| **B级** | [[item:270171@BgQAAEEACKgTBA]]  <br>[[item:270169@BgQAAEEACKAWBA]]  <br>[[item:273794@BgQAAEEACKgTBA]]  <br>[[item:273796@BgQAAEEACKgTBA]]  <br>[[item:250215@BgQAAEEACKgTBA]] |
| **C级** | [[item:250254@BgQAAEEACKgTBA]]  <br>[[item:250224@BgQAAEEACKgTBA]]  <br>[[item:193748@BgQAAEEACKgTBA]]  <br>[[item:193757@BgQAAEEACKgTBA]] |
| **垃圾级** | [[item:250248@BgQAAEEACKgTBA]]  <br>[[item:250259@BgQAAEEACKgTBA]]  <br>[[item:250255@BgQAAEEACKgTBA]] |

### 美化饰品

- [[item:240167]] x2
  
  - 一种可以添加到任何制造护甲上的通用美化，通常建议将带 [[item:240167]] 的美化做在披风和护腕部位，因为制造装备的装等较低，且这两个部位的属性加成最少。由于披风部位有一件装等提升的物品，最佳配装已将制造装备从披风部位转移到了靴子上

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

## 消耗品

- **合剂**
  
  - [[item:241322]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241300]]
  - [[item:241288]] —— 推荐
- 治疗药水
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240900]]
  - [[item:240983]]

### 附魔

:::columns
:::column
| 头盔 | [[item:243951@DAAAAwbBZbAB]]  <br>[[item:275707]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwbB]] |
| 胸部 | [[item:243977@BAAAAwbB]] |
| 护腕 | [[item:275707]] |
| 腰带 | [[item:275707]] |
| 腿部 | [[item:240155@BAAAAwbB]] |
| 靴子 | [[item:243983@BAAAAwbB]] |
| 戒指 1 | [[item:243959@BAAAAwbB]] |
| 戒指 2 | [[item:243959@BAAAAwbB]] |
| 武器 | [[item:244031@BAAAAwbB]] |

:::

:::column
:::gear **神圣 圣骑士** 附魔
```json
{
  "source_code": "JQFZBBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707]] 来为你的头盔、护腕和腰带添加插槽。

## 种族

若要在 **神圣 圣骑士** 中进行极限优化并参与史诗团队副本，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的最高目标，那么选择一个符合你个人风格的种族同样完全可行。

- [[spell:20594]] *—— 矮人* 
  
  - 额外的流血/魔法驱散在某些战斗中非常关键
- [[spell:25046]] —— 鲜血精灵
  
  - 历史上，[[spell:25046]] 的 范围伤害 驱散在某些时期曾非常强力

### 推荐：

推荐游玩矮人！[[spell:59224]]与[[spell:20594]]的组合使其总体上成为一个非常强大的种族。

## 宏

探索 **神圣 圣骑士** 在 团队副本 遭遇战中的推荐宏，并观看一段关于为你的角色创建简单宏的快速视频指南。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
为方便使用，本**神圣 圣骑士** 团队副本攻略中的所有法术均可制作为鼠标指向宏！

[[spell:20473]]

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] 神圣震击; [harm] 神圣震击 ; 神圣震击
```

[[spell:19750]]

```wow-macro
/cast [@mouseover,help,nodead] 圣光闪现 ; 圣光闪现
```

[[spell:82326]]

```wow-macro
/cast [@mouseover,help,nodead] 圣光术 ; 圣光术
```

[[spell:85673]]

```wow-macro
/cast [@mouseover,help,nodead] 荣耀圣令 ; 荣耀圣令
```

[[spell:1022]]

```wow-macro
/cast [@mouseover,help,nodead] 保护祝福 ; 保护祝福
```

[[spell:1044]]

```wow-macro
/cast [@mouseover,help,nodead] 自由祝福 ; 自由祝福
```

[[spell:6940]]

```wow-macro
/cast [@mouseover,help,nodead] 牺牲祝福 ; 牺牲祝福
```

[[spell:633]]

```wow-macro
/cast [@mouseover,help,nodead] 圣疗术 ; 圣疗术
```

[[spell:4987]]

```wow-macro
/cast [@mouseover,help,nodead] 清洁术 ; 清洁术
```

[[spell:114165]]

```wow-macro
/cast [@mouseover,help,nodead] 神圣棱镜; [harm] 神圣棱镜 ; 神圣棱镜
```

[[spell:304971]]

```wow-macro
/cast [@mouseover,help,nodead] 圣洁鸣钟; [harm] 圣洁鸣钟 ; 圣洁鸣钟
```

[[spell:391054]]

```wow-macro
/cast [@mouseover,help] 代祷
```

[[spell:7328]]

```wow-macro
/cast [@mouseover,help] 救赎
```

[[spell:53563]] + [[spell:200025]]

```wow-macro
/cast [@mouseover,help,nodead] 圣光道标 ; 圣光道标
/cast [@mouseover,help,nodead] 美德道标 ; 美德道标
```

[[spell:156910]]

```wow-macro
/cast [@mouseover,help,nodead] 信仰道标 ; 信仰道标
```

:::

:::details 推荐宏
使用这个宏，你就不会在施法中途尝试使用免疫技能时死掉了。

```wow-macro
#showtooltip
/stopcasting
/cast 圣盾术
```

有时你可能需要提前取消你的免疫效果。

```wow-macro
/cancelaura 圣盾术
/cancelaura 保护祝福
```

:::

:::

## 插件

下方是作者为其 **神圣 圣骑士**所用用户界面的截图，其中概述了使用了哪些插件以及它们在团队副本中如何帮助你更轻松地进行游戏。

![](<https://assets-ng.maxroll.gg/wordpress/euiHpal-1-1024x576.png>)

**神圣 圣骑士** 团队副本用户界面

:::accordion
:::details 插件
- **EllesmereUI**—— 整合界面替换插件
  
  - 整个界面由 Ellesmere ui 构建，它控制团队框架、伤害统计、姓名板、动作条和冷却管理器。此外还添加了许多额外的小型便利功能，并且可自定义程度极高

:::

:::

## 本次版本改动

:::accordion
:::details 12.1.0 版本
**圣骑士**

- 金色小径的治疗效果提高25%。
- 光铸祝福的治疗效果提高25%。
- 皈依圣光的治疗效果提高25%。
- 神圣
  
  - 所有治疗效果提高19%。
  - 永恒之火的治疗效果提高20%。
  - 荣耀圣令的治疗效果提高20%。
  - 神圣震击的治疗效果提高10%。
  - 所有伤害提高20%。
  - 审判的伤害提高25%。
  - 愤怒之锤的伤害提高25%。
  - 复仇十字军现在转移55%的治疗量（原为80%）。
  - 圣光之柱的美德道标治疗效果提高50%。
  - 正义盾击的法力返还提高25%。
  - 无有价值减益效果现在持续18秒（原为15秒）。
  - 天界回响现在以200%的效果施放圣洁鸣钟（原为100%）。
  - 真理必胜的治疗效果提高30%。
  - 圣光救赎的吸收量提高50%。
  - 提里奥的奉献现在使圣疗术的冷却时间缩短40%（原为30%）。
  - 觉醒现在有15%的几率触发（原为10%）。
  - 闪耀光辉现在吸收2%的最大生命值，上限为6%（原为1%，上限为5%）。
  - 溢流之光现在转移神圣震击治疗量的50%（原为30%）。
  - 正义者召唤现在使复仇之怒的持续时间缩短3秒（原为4秒），并使复仇十字军的持续时间每点缩短2秒（原为2.5秒）。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我总是死亡？
A：当 [[spell:6940]] 生效时注意你的生命值，或将它与 [[spell:642]] 结合使用。

:::

:::details 问：为什么我的法力总是不够用？
A：你使用[[spell:82326]]的频率太高了。

:::

:::

---

### 致谢

作者：**Ftmjgtde**

审校：**Rycn**

---

:::changelog 更新记录
**2026-08-09** 已更新至12.1.0版本

**2026-06-16** 已更新至12.0.7版本

**2026-04-25** 已更新至12.0.5版本

**2026-02-21** 已更新至12.0.1版本

**2026-01-18** 已更新至12.0版本



:::
