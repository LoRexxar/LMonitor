Welcome to the **Assassination Rogue** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Assassination Rogue** Raid Best in Slot
```json
{
  "source_code": "JUpAwT1ABc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOA_sOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADQgt7AECSAAkBwDYiqDIQrDAQBBwiIvsUABcJJEAACBAQBmBC3XQggIEAA1jbAKWgEAkdFSAgCBwGJOFQAf9BBAgwAAEQacUAABo0FCEAWBIRAChBWBEA24PAAFwAEOFQA1LSBECQBBQIHYFQANE6AGgQBESyA5OApqQgIvsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240892]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270168]] |  |
| 背部 | [[item:260312]] |  |
| 主手 | [[item:271093]] | [[item:243973]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Assassination Rogue**, you have access to Implacable, which increases your [[spell:32645]] damage by 10%, and and [[spell:32645]]  restores 2 energy per Combo Point.

**Rank 2** increases your Nature and Bleed damage by 20%.

While **Rank 3** makes your [[spell:192759]] build 6 Combo Points.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-assassination-mxr.webp>)

Implacable

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

The spec talent tree had a lot of changes.

- **Spec Tree**
  
  - [[talent:117139]]
    
    - Is no longer a dot, instead, applies both of your [[spell:703]] and your [[spell:1943]] on 2 nearby enemies.
  - [[talent:112660]] / [[talent:134835]].
    
    - Both of these are fairly strong. [[talent:112660]] is a decent amp, especially in aoe, while [[talent:134835]] is great at Combo Point generation.
  - [[talent:117130]]
    
    - Haste buff after your [[talent:112663]] expires.
  - [[talent:112672]]
    
    - Is its own talent now.
  - [[talent:112511]]
    
    - Extra amp during your [[talent:112662]].
  
  
  
  - [[talent:112673]]
    
    - Increases [[spell:703]] duration by 6s.

- **Class Tree**
  
  - [[talent:112636]]
    
    - Increases agility by 3%.
  - [[talent:112639]]
    
    - No longer a button, now it procs from your generators and increases your next finisher crit by 10%.
  - [[talent:112644]]
    
    - Extra attack speed from your [[spell:5171]].
- **Removed**
  
  - [[spell:324073]]
  
  
  
  - [[spell:455143]]
  - [[spell:170882]]
  - [[spell:341534]]
  - [[spell:455131]]
  - [[spell:400783]]
  - [[spell:381802]]
  - [[spell:394983]]
  - [[spell:255989]]
  - [[spell:200806]]
  - [[spell:340078]]
  - [[spell:273488]]
  - [[spell:381634]]

## Hero Talents

:::tabs
:::tab [[talent:123375]]
- Your [[spell:703]] marks your target with 3 stacks of [[talent:117733]]. 
  
  - You can only have 1 [[talent:117733]] active.
  - Consume a stack of [[talent:117733]] by using a 5 Combo Point or more finisher.
  - You can only apply the [[talent:117733]] with [[spell:703]]

- After consuming the last stack of [[talent:117733]], or if a mob dies while the [[talent:117733]] is active, you gain [[talent:117739]].
  
  - When [[talent:117739]] is up, always make sure your next finisher is an [[spell:32645]] with 7 Combo Points.
  
  
  
  - When you consume [[talent:117739]], you apply [[talent:117733]] on the mob you have targetted.
- With [[spell:1293340]], you can move your [[talent:117733]] manually to a different mob.

Additionally, there are a few more capstones in the tree that are important.

- [[talent:117707]]
- [[talent:117732]].
- [[talent:126029]]
  
  - A defensive node that makes [[talent:112657]] even stronger. [[talent:117703]] is also interesting but much more fight specific.
- [[talent:136020]]
  
  - Passive crit bonus.
- [[talent:136019]]
  
  - A little bit of extra flavor every time you apply mark, but realistically not a big thing.
- [[talent:136018@AJAB]]
  
  - Adds a bit of extra damage in aoe or cleave scenarios, ignoring your main target.
- [[spell:457055]]
  
  - A bit of extra funnel on your main target.

:::

:::tab [[talent:123371]]
- Much like in the [[talent:123375]] tree, every 5 Combo Point or more finisher that you use has a chance to flip a coin.
  
  - Landing on [[spell:452923]] increases your damage by 10%. Additional flips landing on [[spell:452923]] increase damage by 2%. -- Stacking
  - Landing on [[spell:452538]] does Cosmic damage. Additional flips increase [[spell:452538]] damage by 10%. --- *Stacking*
- [[talent:117724]]
  
  - Every 7 coin flips, you gain a 4% agility buff, plus:
    
    - Both [[spell:452923]] and [[spell:452923]] bonuses increase by 50%.
    - Coin flips are 15% more likely to match the same flip as the previous one.

Neither of these flips offer much in terms of gameplay, and you could do without tracking any of them, but there is some minmaxing you can do with the talents in the Fatebound tree.

- [[talent:117736]].
  
  - Rolling both flips after you use your [[talent:112662]].
- [[talent:117717]]
  
  - Makes your [[talent:112672]] hit 5% harder.
- [[talent:136025]]
  
  - Passive crit.
- [[talent:136026]]
- [[talent:136024]]

:::

:::

## Talents

:::tabs
:::tab [[talent:123375]] Single-Target
:::talents [[talent:123375]] **Assassination Rogue** Single-Target talents in Raids
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYxsMwAWC2GmADLGMzAMGD",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYxsMwAWC2GmADLGMzAMGD"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:381798]] 
  
  - This is your execute talent. Ideally in a fight, you always want to use at least one set of cooldowns with it. If you can only get 1 more use of [[spell:360194]] for the remainder of the fight, it is advised that you save it for when the boss hits 35% or below.
- [[spell:385627]]
  
  - Your shorter cooldown burst ability. This is particularly strong when combined with [[spell:360194]] every two minutes.
- [[spell:360194]]
  
  - Your big cooldown. Increases the damage of your [[spell:703]], [[spell:1943]], and Lethal Poisons on your target by 100%, while allowing for your Lethal Poisons to stack twice.
- [[talent:117131]]
  
  - Enables the use of an additional lethal poison.
- [[talent:112679]]
  
  - A proc that can save you a lot of Energy as it makes your next [[spell:8676]] free. It is especially good in execute range as it procs more often.
- [[talent:112649]]
  
  - Helps with building up your Combo Points for a finisher which is another reason why Crit is a good stat for you.
- [[talent:134835]].
  
  - This talent is great at Combo Point generation.

#### Class Tree

- [[talent:112648]]
- [[talent:112655]] / [[talent:112656]]
  
  - In a Raid environment, [[talent:112655]] is always your primary choice unless you have more than 1 Rogue. The damage reduction it provides, coupled with [[talent:112521]] is simply too strong. On the other hand, [[talent:112656]] stacks with similar abilities from other classes, making it an inferior choice.
- [[talent:114737]] / [[talent:112632]]
  
  - For Raid, [[spell:31230]] is usually recommended unless specified otherwise.

#### Hero Talents

- [[talent:117706]]
  
  - Significantly better than [[talent:126030]].
- [[talent:117720]]
  
  - This is very useful when you have to move around a lot. Meanwhile the alternative, [[talent:126027]], doesn't offer much, especially in a raid enviroment.
- [[talent:126029]]
  
  - A very nice addition to our kit that makes [[talent:112657]] useful in a raid enviroment.
  - [[talent:117703]] can also be decent if you need a longer [[talent:112585]] for a specific mechanic.

### Poisons

- This build uses the following Poisons: 
  
  - [[talent:112676]]
  - [[talent:112670]]
  - [[talent:112655]] -or- [[talent:112656]].

:::

:::tab [[talent:123375]] Cleave
:::talents [[talent:123375]] **Assassination Rogue** AoE talents in Raids
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhFDmZwMzYMA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhFDmZwMzYMA"
}
```
:::

### When to use this Spec

Use this spec if you're fighting 3 or more enemies for an extended period of the fight.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[talent:117139]]
  - [[talent:112672]]
- **Removed**
  
  - [[talent:112519]]
  - [[talent:117137]]

:::

:::tab [[talent:123371]] Single-Target
:::talents [[talent:123371]] **Assassination Rogue** Single-Target talents in Raids.
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxYbmZmtZWmZmBjZmxYmxwAsMzyYhxMmlGzy2wkthhNDmZwMzYM",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxYbmZmtZWmZmBjZmxYmxwAsMzyYhxMmlGzy2wkthhNDmZwMzYM"
}
```
:::

#### Fatebound variation.

:::

:::tab [[talent:123371]] Cleave
:::talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhNDmZwMzYMA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhNDmZwMzYMA"
}
```
:::

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:32645]] damage increased by 10% and it increases your damage dealt by 3%.
- **4-Set:** [[spell:2818]] increases your bleed damage on the target by 10%. Auto-attacks to targets with your [[spell:381664]] deal 3% increased damage per stack. [[spell:8679]] hits a second time.

### Single-Target

:::tabs
:::tab [[talent:123375]]
### Opener

- Your goal is to keep [[spell:32645]]. Below, you see an example of how your opener looks when using the recommended **Single Target** talent spec

:::rotation [[talent:123375]] **Assassination Rogue** single-target opener in Raids
```json
{
  "source_code": "J0GELI0vCAQABggQxUQAHwAACd5BJgQEQkAIQIQAc66ABkBTB81HEAADCAAWCKQBAEgSXIgQF-XAYABACJwfFEQCMI09wLQBIEBGkETBAAAAAAgQF-H"
}
```
1. [[spell:703]]
2. [[spell:1329]]
3. [[spell:1943]]
4. [[spell:1329]]
5. [[spell:703]]  [[item:241308]] · [[item:270175]]
6. [[spell:32645]]
7. [[spell:360194]]
8. [[spell:192759]]
9. [[spell:32645]]
10. [[spell:1329]]
11. [[spell:32645]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. [[spell:703]] first global to apply [[talent:117733@AJAB]].
2. Keep up [[spell:1943]] and [[spell:703]] throughout the fight.
   
   1. Do not overwrite your [[talent:112673]] and instead apply [[spell:703]] as soon as the buffed one expires.
3. Always [[spell:32645]] at 7 Combo Points with [[talent:117739]] up.
4. Be ready to refresh your bleeds before your [[spell:360194]] and [[spell:385627]] come off cooldown, start preparing for them once they have approximately 8 seconds remaining on their cooldown.
5. Press [[spell:1329]] if not at 5 Combo Points.

:::

:::tab [[talent:123371]]
### Opener

- Your goal is to keep [[spell:32645]] and [[spell:5938]] up for the entire duration of your cooldowns. Below, you see an example of how your opener looks when using the recommended **Single Target** talent spec.
- *This is one variation of the* [[talent:123371]] opener, more on this under the **Deep Dive** section.

:::rotation [[talent:123371]] **Assassination Rogue** single-target opener in Raids
```json
{
  "source_code": "J0GELI0vCAQABggQxUQAHwAACd5BJgQEQkAIQIQAc66ABkBTB81HEAADCAAWCKQBAEgSXIgQF-XAYABACJwfFEQCMI09wLQBIEBGkETBAAAAAAgQF-H"
}
```
1. [[spell:703]]
2. [[spell:1329]]
3. [[spell:1943]]
4. [[spell:1329]]
5. [[spell:703]]  [[item:241308]] · [[item:270175]]
6. [[spell:32645]]
7. [[spell:360194]]
8. [[spell:192759]]
9. [[spell:32645]]
10. [[spell:1329]]
11. [[spell:32645]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:1943]] and [[spell:703]] throughout the fight.
   
   - Do not overwrite your [[talent:112673]] and instead apply [[spell:703]] as soon as the buffed one expires.
2. Be ready to use your [[spell:360194]] and [[spell:385627]] as soon as they come off cooldown, start preparing for them once they have approximately 8 seconds remaining on their cooldown.
3. [[spell:32645]] with 5 Combo Points.
4. Press [[spell:1329]] if not at 5 Combo Points without [[talent:112525]].

:::

:::

### Multi-Target

:::tabs
:::tab [[talent:123375]]
*On Multi Target fights, referring to ones where you get adds spawning throughout the fights occasionally, your rotation and build remains largely unchanged. The only thing to keep in mind is [[spell:421975]]*, *and, in some cases, [[talent:112517]]*.

- How to utilize [[spell:421975]]:
  
  - [[spell:421975]] cleaves from your target, unlike [[spell:13877]].
  
  
  
  - Keep track of your [[spell:421975]] debuff on your target. Refresh it  before it runs out.
  - [[spell:360194]] and [[spell:385627]] augment your [[spell:421975]] damage. Always use them on a mob that survives for the full duration.

### Opener

:::rotation [[talent:123375]] **Assassination Rogue** Multi-Target opener in Raids
```json
{
  "source_code": "IEFEKI0vCAQABggQLocAHwAACd5BJgQEYAy-HMBAAIwMUBQDKQQNUlBLIU4fAEQAsIkA_VAAAAAACdP8CA"
}
```
1. [[spell:703]]
2. [[spell:51723]]
3. [[spell:1943]]
4. [[spell:703]]
5. [[spell:1247227]] 3T
6. [[spell:1247227]] 5T
7. [[spell:51723]]
8. [[spell:32645]]
9. [[spell:360194]]
10. [[spell:192759]]
:::

### Multi-Target Priority List

1. [[spell:703]] first global to apply [[talent:117733@AJAB]].
2. Keep up [[spell:1943]] and [[spell:703]] throughout the fight.
   
   1. Do not overwrite your [[talent:112673]] and instead apply [[spell:703]] as soon as the buffed one expires.
3. Always [[spell:32645]] at 7 Combo Points with [[talent:117739]] up.
4. Be ready to refresh your bleeds before your [[spell:360194]] and [[spell:385627]] come off cooldown, start preparing for them once they have approximately 8 seconds remaining on their cooldown.
5. Press [[spell:1329]] if not at 5 Combo Points.

:::

:::tab [[talent:123371]]
*On Multi Target fights, referring to ones where you get adds spawning throughout the fights occasionally, your rotation and build remains largely unchanged. The only thing to keep in mind is [[spell:421975]], and, in some cases, [[talent:112517]].*

1. How to utilize [[spell:421975]]:
   
   - [[spell:421975]] cleaves from your target, unlike [[spell:13877]].
   
   
   
   - Keep track of your [[spell:421975]] debuff on your target. Refresh it  before it runs out.
   - [[spell:360194]] and [[spell:385627]] augment your [[spell:421975]] damage. Always use them on a mob that survives for the full duration.

### Opener

:::rotation [[talent:123371]] **Assassination Rogue** Multi-Target opener in Raids
```json
{
  "source_code": "IEFEKI0vCAQABggQLocAHwAACd5BJgQEYAy-HMBAAIwMUBQDKQQNUlBLIU4fAEQAsIkA_VAAAAAACdP8CA"
}
```
1. [[spell:703]]
2. [[spell:51723]]
3. [[spell:1943]]
4. [[spell:703]]
5. [[spell:1247227]] 3T
6. [[spell:1247227]] 5T
7. [[spell:51723]]
8. [[spell:32645]]
9. [[spell:360194]]
10. [[spell:192759]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:1943]] and [[spell:703]] throughout the fight.
   
   - Do not overwrite your [[talent:112673]] and instead apply [[spell:703]] as soon as the buffed one expires.
2. Be ready to use your [[spell:360194]] and [[spell:385627]] as soon as they come off cooldown, start preparing for them once they have approximately 8 seconds remaining on their cooldown.
3. [[spell:32645]] with 5 Combo Points.
4. Press [[spell:1329]] if not at 5 Combo Points without [[talent:112525]].

:::

:::

## Deep Dive

### When to Refresh Your Garrote and Rupture

- With [[spell:169629]] removed from **Assassination Rogues**, you are no longer able to snapshot your bleeds, with the exception of [[spell:703]] with [[talent:112673]]. Because of this, you need to follow a few rules when refreshing [[spell:703]].
  
  - If your current [[spell:703]] is buffed with [[talent:112673]], do not overwrite it and leave it to expire before applying it again.
  - If your current [[spell:703]] is not buffed with [[talent:112673]], you do not have cooldowns running, and it has less than 5.2s left on it, refresh it.
- With [[spell:1943]] being a Combo Point based finisher, it uses a flexible pandemic. This means that regardless of how many Combo Points the current [[spell:1943]] on your target was used with, the pandemic is calculated with the Combo Points of the new cast of [[spell:1943]]. The list below are the rules to follow for optimal refreshing:
  
  - If you currently have 5 Combo Points, you can safely refresh your [[spell:1943]] at 7.2s or less.
  - If you currently have 6 Combo Points, you can safely refresh your [[spell:1943]] at 8.4s or less.
  - 1: 2.4s
  - 2: 3.6s
  - 3: 4.8s
  - 4: 6s
  - 7: 9.6s
  - 8: 10.8s
  - 9: 12s
  - 10: 13.2s

### Maximizing Your Deathmark and Kingsbane window.

- [[spell:32645]] needs to have 100% uptime during your cooldowns.

Outside of your Opener, your 2 minute cooldown usage is very similar, this is the most important rule to follow when setting up for [[spell:360194]]:

1. Always refresh your bleeds before using [[spell:360194]] if they have 18 seconds or less at the moment that you press it. In particular:
   
   - Refresh your [[spell:1943]] at 6+ Combo Points.
   
   
   
   - [[spell:1329]] to 6 Combo Points then [[spell:32645]] before pressing your [[spell:360194]].

Below is an example of using your [[spell:360194]] correctly in the middle of an encounter **in Raids**.

:::rotation **Assassination Rogue** Cooldown Usage in Raid as [[talent:123375]]
```json
{
  "source_code": "IQFEKI0lHAQABggQ_KQAHwAACFTBugAAsEQAc66AAAAAAIUh_FwBMAgQC8XBhggQ3DfBxUBGkETBAAAAAAgQxUA"
}
```
1. [[spell:1943]]
2. [[spell:703]]
3. [[spell:1329]]
4. [[spell:1329]]  [[item:241308]]
5. [[spell:32645]]
6. [[spell:360194]]
7. [[spell:192759]]
8. [[spell:32645]]
9. [[spell:1329]]
10. [[spell:1329]]
:::

- **This is not a fixed rotation**; This is just one example of how to play during your [[spell:360194]] window. [[spell:111240]] procs and critical hits can potentially alter the ability usage.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Assassination Rogue** Nek'Zali Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.

:::

:::tab Entombed Sentinels
:::talents **Assassination Rogue** Entombed Sentinels Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZmZwMzMjxMDjBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZmZwMzMjxMDjBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

### Boss Tips

- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].
- Look at your raid frames and use your [[spell:36554]] in the intermission to clear the stacking buff.

:::

:::tab Lost Explorers
:::talents **Assassination Rogue** Lost Explorers Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB"
}
```
:::

### Boss Tips

- Pay attention to [[spell:1296062]], try to bait them on the outside of the room.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed after being used once.

:::

:::tab Vashnik
:::talents **Assassination Rogue** Vashnik Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB"
}
```
:::

### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.

:::

:::tab Sszorak
:::talents **Assassination Rogue** Sszorak Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

### Boss Tips

- In case you fail to find a partner to deal with [[spell:1285419]], keep in mind that you can also negate it with [[spell:36554]] or [[spell:31224]].
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.

:::

:::tab Twin Fangs
:::talents **Assassination Rogue** Twin Fangs Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZm5BwMzMzMMzYMALzsMWYMjZpxstNMZbYYxgZGMzMGDA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZm5BwMzMzMMzYMALzsMWYMjZpxstNMZbYYxgZGMzMGDA"
}
```
:::

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.

:::

:::tab Coiled Altar
:::talents **Assassination Rogue** Coiled Altar Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].

:::

:::tab Ula'tek
:::talents **Assassination Rogue** Ula'tek Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents **Assassination Rogue** Nymrissa Wavecaller Talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB"
}
```
:::

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle, so position accordingly or be ready to negate the knockback with [[spell:36554]].
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Assassination Rogue**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Assassination Rogue** Stat Priorities in Raid
```json
{
  "source_code": "IoAJFMAIkEDKBMwABA"
}
```
**敏捷 ＞ 暴击 ≥ 急速 ≥ 精通 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271508@DwQAAMQAXk74kgC4UA]] | The Lost Explorers / Catalyst |
| Cloak | [[item:251190@BgQAAMQACKgTBA]] | The Blinding Vale |
| Chest | [[item:271513@DgQAAMQAJk7IoAOF]] | Vashnik the Malignant / Catalyst |
| Wrist | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | Crafting |
| Gloves | [[item:271511@BgQAAMQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:268256@BiQAAMQAS06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]] into [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268261@DgQAAMQAPk7IoAOF]] | The Twin Fangs |
| Ring 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:268249@DiQAAMQA1j7oQrjgC4UA]] | Vashnik the Malignant |
| Trinket 1 | [[item:270175@BwgAAMQAYJoAFAQAKdhA]] | Ula'tek |
| Trinket 2 | [[item:270168@BgQAAMQACKAWBA]] | Ula'tek |
| Weapon | [[item:271093@DgQAAMQADk7IoAYF]] | Ula'tek |
| Weapon | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | Crafting |

Assassination Rogue BiS list in Raids

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | Altar of Fangs |
| Neck | [[item:273781@BiQAAMQAH16IoABF]] | Altar of Fangs |
| Shoulder | [[item:251223@DgQAAMQAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:251190@BgQAAMQACKQQBA]] | The Blinding Vale |
| Chest | [[item:251159@DgQAAMQAJk7IoABF]] | Den of Nalorakk |
| Wrist | [[item:251135@BiQAAMQAU06IoABF]] | Murder Row |
| Gloves | [[item:251124@BgQAAMQACKQQBA]] | Murder Row |
| Belt | [[item:159317@BiQAAMQAE06IoABF]] | Temple of Sethraliss |
| Legs | [[item:251130@DgQAAMQAhu7IoABF]] | Murder Row |
| Boots | [[item:159327@DgQAAMQAPk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@DiQAAMQA1j7wPrjgCEUA]] | Temple of Sethraliss |
| Ring 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:250215@BgQAAMQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAAMQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAMQACKAWBUAABo0FCA]] |
| **A-Tier** | [[item:270168@BgQAAMQACKAWBA]]  <br>[[item:270173@AgQAAIoAYFA]] |
| **B-Tier** | [[item:270164@AgQAA8rBOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **Junkyard** | [[item:270166@AgQAAIoAOFA]]  <br>[[item:159617@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]] |

### Embellishments

- [[item:273059]]
- [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS*.
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240898]]
  - [[item:240914]] x1
  - [[item:240906]] x1
  - [[item:240890]] x1
  - [[item:240966]] *-- Unique, use one of each gem color to enhance your [[item:240966]].*
- As always, sim your character to check for the best gems with your current gear.

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAMQAnk7A]]- [[item:243949]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAMQA]] |
| Cloak |  |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@DAAAAMQAnk7A]] |
| Waist | [[item:275707@DAAAAMQAnk7A]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:243957@BAAAAMQA]] |
| Ring 2 | [[item:243957@BAAAAMQA]] |
| Weapon | [[item:243973@BAAAAMQA]] |
| Weapon | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **Assassination Rogue** Enchantments in Raids
```json
{
  "source_code": "JwFZDEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCoUQuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAMQAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing as an **Assassination Rogue** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial but lines up poorly with [[talent:112662]]
- [[spell:33702]] *-- Orc* 
  
  - Strong racial for damage that very competitive now since it scales with level and lines up with your [[talent:112662]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.
- [[spell:255669]] -- Void Elf
  
  - Decent passive trait.
- [[spell:312923]] -- Mechagnome
  
  - Fairly strong passive trait that scales with level, hence why it's so strong now.

:::columns
:::column


:::

:::

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for Assassination Rogues during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
**[[spell:703]]** -- *Casts [[spell:703]] on your mouseover or target.*

```wow-macro
#showtooltip Garrote
/cast [@mouseover,exists] Garrote;Garrote
```

**[[spell:1943]]** -- *Casts [[spell:1943]] on your mouseover target if it exists, is not dead and is hostile, else Rupture is cast on your target*.

```wow-macro
#showtooltip
/cast [@mouseover,exists,nodead,harm] Rupture;Rupture
```

*Sets your **focus** and **places a marker** on them when you mouseover a mob. This is great for letting you teammates know what you are planning on using your* **[[spell:1766]]** *on**.***

```wow-macro
/focus [@mouseover][]
/run SetRaidTarget("mouseover",6)
```

**[[spell:36554]]** *on your mouseover target*

```wow-macro
#showtooltip Shadowstep
/cast [@mouseover] Shadowstep
```

*Mouseover* **[[spell:1766]]** *if you prefer that over focus target.*

```wow-macro
#showicon Kick
/cast [target=mouseover] Kick
```

:::

:::details Focus Macros
**[[spell:36554]] + [[spell:1766]]** *on your focus mob. This macro is used as a "ranged" [[spell:1766]].*

```wow-macro
/cast [@focus] Shadowstep
/cast [@focus] Kick
```

**[[spell:1766]]** *your focus target*

```wow-macro
#Show Kick
/cast [target=focus] Kick
```

*Cast* **[[talent:112631]]** *on your focus*

```wow-macro
#showicon Gouge
/cast [target=focus] Gouge
```

*Focus* **[[spell:408]]** *for extra CC*

```wow-macro
#showicon Kidney Shot
/cast [@focus] Kidney Shot
```

*Focus* **Cheap Shot**

```wow-macro
#showicon Cheap Shot
/cast [@focus] Cheap Shot
```

---

:::

:::details Utility Macros
**[[spell:360194]]** + **[[spell:10060]]** **Macro** - *Replace "Rycn-Tarrenmill" and "Give PI plz" with the priest you are getting the PI from and what they tell you their PI macro triggers from.*

```wow-macro
#show Deathmark
/w Rycn-TarrenMill Give PI plz
/cast Deathmark
```

*On this macro you can replace the names with the tanks in your group to make using* **[[talent:112574]]** *much easier.*

```wow-macro
#show Tricks of the Trade
/cast [@Meeresdh] Tricks of the Trade
/cast [@Meeresmana] Tricks of the Trade
/cast [@Méèrès] Tricks of the Trade
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Assassination Rogue**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://i.gyazo.com/737a316d3f0b0d850b3ce2b4b3e1f6af.jpg>)

**Assassination Rogue** Interface

:::accordion
:::details Addons
- **Ellesmere UI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Class
  
  - Thistle Tea is now a choice talent – Players may now choose between the existing version, which casts automatically at low Energy in addition to being usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds). Duration remains unchanged in PvP combat.
- Hero Talents
  
  - Fatebound
    
    - Deal Fate now has a 60% chance to grant an extra combo point when you Seal Fate (was 100%).
  - Deathstalker
    
    - Fixed an issue that caused Unshakable Drive's bonus to multiply with each stack.
    - Fixed an issue that often caused Unshakable Drive to remove more than one stack per ability use.
- Assassination
  
  - Developers' notes We're making some updates to Assassination's Energy economy in Curse of Ula'tek. We aren't happy with how the Rank 1 Implacable apex talent is playing – it's unintuitive for optimal play to intentionally let Envenom drop. We're updating its design so refreshing Envenom late is consistently the best way to play and giving it consistent Energy recovery value. We're also making some changes aimed at increasing talent build options.
  - New Talent: Unstable Toxin – Envenom damage increased by 18%, but its duration is reduced by 2 seconds.
  - Apex Talent: Implacable (Rank 1) has been updated – Envenom damage increased by 10%. Envenom now restores 2 Energy per combo point spent.
  - Apex Talent: Implacable (Rank 3) – Implacable Strike damage increased by 15%.
  - Internal Bleeding has been updated – Now triggers from casting Kidney Shot and Rupture, rather than also being applied when copying Ruptures with Crimson Tempest. Damage increased by 10%.
  - Iron Wire has been updated – Garrotes applied from stealth or during the Improved Garrote window now silence the target for 5 seconds. Damage reduction behavior unchanged.
  - Dashing Scoundrel has been updated – Envenom's effect now also increases the critical strike chance of your weapon poisons by 10% (was 5%). Your Energy generation is increased by 4% for each lethal poison on your weapons.
  - All damage dealt increased by 20%.
  - Deathmark increases the damage of your Rupture, Garrote, and Lethal Poisons by 75% (was 100%).
  - Kingsbane damage reduced by 15%.
  - Shrouded Suffocation increases Garrote damage by 30% (was 20%).
  - Avulsion increases Rupture damage by 25% (was 20%).
  - Motivated Murderer Energy increased to 30% (was 20%).
  - Rapid Injection damage bonus increased to 20%/40% (was 15%/30%).
  - Venomous Wounds generates more Energy when multiple targets are affected by your bleeds.
  - Blindside's chance to trigger reduced to 10% (was 15%), and 20% when the target is at low health (was 30%).
  - Poison Bomb's visual has been adjusted to make other important visuals on top of it easier to see.
  - Lethality and Cold Blooded-Killer now work correctly with the strikes dealt by Implacable (Rank 3).
  - Several talents have changed positions in the talent tree.
  - Deadly Momentum has been removed.

:::

:::

## FAQ

:::accordion
:::details


:::

:::

---

### Credits

Written By: **Perfecto**

Reviewed By: **Stove**

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-10** Updated for patch 12.0.1.

**2026-01-13** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-07-29** Updated for patch 11.2.

**2025-06-19** Updated for patch 11.1.7.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-14** Updated for patch 11.1.

**2024-12-16** Updated for patch 11.0.7.

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
