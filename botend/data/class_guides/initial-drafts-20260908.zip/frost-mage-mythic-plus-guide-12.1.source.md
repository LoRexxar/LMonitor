Welcome to the **Frost Mage** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 3/5 · Average

Survivability · 3/5 · Average

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Frost Mage** Mythic+ Best in Slot
```json
{
  "source_code": "JsqAQCEA3_fABIgJEIIEBAwJ5OwVtOggCYhNYFQApfBBAERAAQQrDQQAUAFj1gVABoMJEIACBAwF5OggC4UAB8cCPAQCN8AEJTCBAiQByUgHAscCeQQBqmwDc99FEIAGBAQ84OAG24VN5IAWBEAIoOAgIVQMIb7LjVT0wAwIgBTWiwgN3Wjt1sUAB0MJEAAIFAwe1EYNYYTOCgVATfBBBk9FEIICBAQ94mwlc4UAB4paCIIIRIBR2IjX1YbNnWiTBEAVfQAAIEAAFwICnF9AVwAGdfBBAgRAAUhhIQvIEEQ1A8TAGjCWBEQCAPAAAFAA2WgkscbNZJCD2scNAMySBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271562]] | [[item:243991]] |
| 胸部 | [[item:271567]] | [[item:243977]] |
| 腰部 | [[item:271561]] | [[item:240900]] |
| 腿部 | [[item:271563]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:243953]] |
| 腕部 | [[item:239648]] | [[item:240900]] |
| 手部 | [[item:271565]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:250215]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex Talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As a **Frost Mage**, you have access to Hand of Frost, which gives you a chance to summon a [[spell:1262935]] that deals frost damage and applies [[spell:1221389]] stacks.

**Rank 2** increases your chance to summon a [[spell:1262935]] and also your spell damage by dealing damage with it. While **Rank 3** grants your [[talent:80216]] an additional charge, increases its damage and allows it to summon 4 [[spell:1262935]] over its duration.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-frostmage-mxr.webp>)

Hand of Frost

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:1246769]]
    
    - New passive that changes your mastery and how you interact with your rotation.
  - [[talent:80251]]
    
    - Now built-in together with [[talent:80216]] and is available right after it.
  - [[talent:134180]]
    
    - Gives you an additional charge of [[talent:80181]] and [[talent:80176]] which improves you survivability greatly.
  
  
  
  - [[talent:134406]]
    
    - [[talent:134406]] is back!
- **Class Tree**
  
  - [[talent:134182]]
    
    - Restores you some health when you drop low and casts [[talent:80174]]. One of the weakest passive defensives but still something and has an interesting concept.
  - [[talent:136581]]
    
    - Casts [[talent:80140]] a second time on its own but adds a cooldown to it.
  - [[talent:136576]]
    
    - Allows your [[talent:80175]] to be casted on yourself automatically whenever you use it on another friendly target.
  - [[talent:134185]]
    
    - Improves your [[talent:80176]] and makes it a much stronger defensive ability.
- **Removed**
  
  - [[spell:76613]]
    
    - Mastery being reworked results in a big change of the way you play the spec and changes many interactions within it.
  - [[spell:12472]]
    
    - Major cooldown being removed leaves you only with [[talent:80216]] as your only offensive ability that you can manage throughout encounters.
  - [[spell:385305]]
    
    - Same as your mastery, this concept was also reworked and changes many interactions.
  
  
  
  - [[spell:382440]]
    
    - One of the greatest abilities Mage ever had and its removal affects all aspects like damage, utility or survivability.
  - [[spell:414660]]
    
    - Great personal and party defensive ability, combined with [[talent:80147]], made this a very strong spell overall. Its removal together with [[spell:382440]] and removed damage reduction from [[talent:80183]] and [[talent:115877]] results in a much weaker defensive state of Mage coming into Midnight.
  - [[spell:157981]]
    
    - One of the strongest utility spells is also gone, doesn't affect you much directly, but makes you quite a bit more useless in any meaningful content of the game.

## Hero Talents

- [[talent:123339]] is the main hero talent used in both single and AoE scenarios as it currently outperforms [[talent:123342]].



### [[talent:123339]]

- Main feature of the [[talent:123339]] hero talent tree is the addition of a new passive spell, [[spell:443722]], and your interaction with it. [[spell:443722]] is a projectile that deals frost damage and shoots automatically into your target.

- You can trigger it with a variety of ways: 
  
  - [[talent:117266@AJACCA]] makes [[talent:80241]] to conjure a [[spell:443722]] for every 2 [[spell:1221389]] stacks [[spell:1246769]] from its primary target.
  - [[talent:117264@AJACCA]] allows your [[talent:80242]] to conjure up to 4 [[spell:443722]] when damaging enemies.
  - [[talent:135920@AJACCA]] makes your [[talent:134406]] to have a chance to conjure a [[spell:443722]] alongside its [[spell:31707]].
  - [[talent:135946@AJACCA]] causes [[talent:80244]] to conjure 2 [[spell:443722]].
  
  
  
  - Due to [[talent:117265@AJACCA]] you have a chance to conjure a burst of [[spell:443722]] when conjuring one or more of them.
  - [[talent:117257@AJACCA]] makes your [[talent:80216]] to generate 1 [[spell:443722]] each time it does damage to one or more enemies. Additionally, for 10 seconds after casting [[talent:80216]], your chance to conjure an additional [[spell:443722]] is increased.

- On top of that, there are a bunch of passive interactions that grant you some additional damage, cooldown reductions and other stuff:
  
  - [[talent:135919@AJACCA]] makes your direct damage from [[spell:443722]] to have a chance to apply 1 stack of [[spell:1221389]].
  - [[talent:135918@AJACCA]] causes [[talent:80241]] to shatter 1 additional stack of [[spell:1221389]] and increases Shatter damage.
  - [[talent:128267@AJACCA]] increases damage of your [[spell:116]] and [[talent:134421]] and makes your [[spell:199786]] to conjure 2 additional [[spell:443722]].
  - [[talent:117258@AJACCA]] reduces the cooldown of [[talent:80242]] with each direct damage from [[spell:443722]].
  - [[talent:117261@AJACCA]] increases [[talent:80216]] damage and your chance to gain [[talent:80244]] from [[spell:116]].
  - [[talent:117259@AJACCA]] makes direct damage of your [[spell:443722]] to also deal damage to nearby enemies.




### [[talent:123342]]

- [[talent:123342]] hero talent tree revolves around passively gaining additional damage from your spells by transforming your [[spell:116]] to [[spell:431044]], making [[talent:80243]] deal frostfire damage with [[talent:117241@FAQA8chA]] and causing [[talent:80251]] to also call down a [[spell:153561]] alongside other passive damage increase talent nodes. To top it off, you also gain [[talent:135922@AJACCA]] passive that makes frostfire damage to also apply ignite, dealing additional damage over 9 seconds.

- At last, the only thing that actively interacts with your gameplay is the [[talent:117244@AJACCA]] talent node. It causes your Frostfire spells to have a chance for your next [[spell:431044]] to be instant cast, deal increased damage and explode to nearby enemies.
  
  - On top of it, you may also gain it by casting [[spell:199786]] due to [[talent:117235@FAQA8chA]].





## Talents



### [[talent:123339]]

:::talents [[talent:123339]] **Frost Mage** Mythic+ Build
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### When to use this Spec

This is a default talent build to use in low, mid and high Mythic+ keys.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:80227]]
  
  - Causes your next [[talent:80241]] to deal Shatter damage equal to 4 stacks of [[spell:1221389]] and not consume [[spell:1221389]] stacks.
- [[talent:136182]]
  
  - Generates an [[spell:148012]] every 6 seconds. Upon generating 5 [[spell:148012]], [[spell:116]] transforms to a [[spell:199786]] for its next cast.
- [[talent:134416]]
  
  - Makes your [[talent:134421]] be an instant cast during[[talent:80242]].
- [[talent:80250]]
  
  - When [[talent:80241]] Shatters a stack of [[spell:1221389]], the cooldown of [[talent:80216]] is reduced by 0.1 seconds.
- [[talent:80248]]
  
  - Consuming [[talent:80244]] has a chance to cause your next [[talent:80241]] to Shatter additional stacks of [[spell:1221389]].
- [[talent:80237]]
  
  - [[talent:80242]] grants you [[talent:80244]].

##### Class Tree

- [[talent:80141]]
  
  - Grants you a damage taken reduction by 70% for 6 seconds instead of immunity from [[talent:80181]].
- [[talent:80174]]
  
  - Returns you to your current location and health when cast a second time, or after 10 seconds. Effect negated by long distance or death. Very versatile spell and should be used both for improving your survivability and movement.
- [[talent:80163]]
  
  - Teleports you forward, unaffected by the global cooldown and castable while casting.
- [[talent:115877@FAgAVVdBvFbA]]
  
  - Makes you invisible and untargetable for 20 seconds, removing all threat. Any action taken cancels this effect.
- [[talent:134185]]
  
  - Makes [[talent:80176]] to reduce your physical damage taken and absorbs an additional amount of your maximum health. Additionally, gains you an extra charge.
- [[talent:80183]]
  
  - Creates 3 copies of you nearby for 15 seconds. While active, you generate significantly reduced threat. Taking direct damage causes one of the copies to dissipate.
- [[talent:125819]]
  
  - Enemies in a 12 yard cone in front of you take fire damage and are disoriented for 4 seconds. Damage cancels the effect.

#### Hero Talents

- [[talent:117262]]
  
  - Much more useful utility node compared to the other option.
- [[talent:117263@AJACCA]]
  
  - Better survivability option than the other talent.
- [[talent:135946@AJACCA]]
  
  - Outperforms [[talent:135920@AJACCA]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Each stack of [[spell:1221389]] Shattered has a 4% chance to generate an [[spell:148012]]. [[spell:199786]] damage increased by 20%.
- **4-Set:** Casting [[spell:199786]] has a chance to rapidly generate 5 [[spell:148012]] over 1 second. [[spell:1246769]] damage increased by 5%.

### Single-Target and Cleave



#### [[talent:123339]]

##### Opener

- Your goal is to start rolling your major cooldowns as soon as possible while also simultaneously spending your procs such as [[talent:80227]] and [[talent:80243]] with [[talent:80244]]. Below, you can see an example of how your opener may look like using our recommended ‍[[talent:123339]] talent build:

:::rotation **Frost Mage** Single-Target and Cleave opener in Mythic+
```json
{
  "source_code": "IAFoJIEdAAAAAcAUyV2YhNHdCEAiuOAAAAAACFeOBAAAC1NIDAAAAAgA3bXAUgg6KFQAcggAG5aFUAgAFoBJCcvdAAAACpGDDA"
}
```
1. [[spell:116]] Precast [[item:241288]] · [[spell:80353]]
2. [[spell:205021]]
3. [[spell:30455]]
4. [[spell:84714]]
5. [[spell:44614]]
6. [[spell:30455]]
7. [[spell:30455]]
8. [[spell:30455]]
9. [[spell:199786]]
:::

- Opener may slightly vary depending on your procs.
- Always keep an eye on your [[spell:190447]] or [[spell:112965]] procs and make sure to spend them and not overcap.
- Keep in mind that [[spell:1221389]] stacks are capped at 20 so try to never waste them as shattering them is one of your primary source of damage.

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:80243]] if you have [[talent:80244]] proc and [[talent:80248]] is not active.
2. Cast [[talent:80241]] if you have 2 stacks of [[spell:112965]].
3. Cast [[talent:80242]] on cooldown.
4. Cast [[spell:199786]] on cooldown.
5. Cast [[talent:80241]] if you have [[spell:112965]] active or your target has 6 or more stacks of [[spell:1221389]].
6. Cast [[talent:80243]] on cooldown.
7. Cast [[talent:80216]] on cooldown.
   
   - Although its priority is very low and used mainly to apply [[spell:1221389]] stacks, it still does significant amount of damage by itself. Thus, if the fight is about to end, you want to priorotise casting [[talent:80216]] over anything else to maximise amount of casts of it.
8. Cast [[spell:116]].





### AoE



#### [[talent:123339]]

##### Opener

- Below, you can see an example of how your opener looks like using the recommended **[[talent:123339]]** spec in AoE with 5 enemies:

:::rotation **Frost Mage** AoE opener in Mythic+
```json
{
  "source_code": "IkFoKIElnLAAAcAUyV2YhNHdCEAiuOAAAAAACFeOBAAACYkrAAAACpuSBAQAIgQ3gMQAckgFIIw92FAFEoGDFQBACVwRoAAACcvdAAAACcvd"
}
```
1. [[spell:190356]] Precast [[item:241288]] · [[spell:80353]]
2. [[spell:44614]]
3. [[spell:84714]]
4. [[spell:205021]]
5. [[spell:44614]]
6. [[spell:30455]]
7. [[spell:199786]]
8. [[spell:190356]]
9. [[spell:30455]]
10. [[spell:30455]]
:::

- AoE for [[talent:123339]] is considered to be a fight with 3+ targets.
- AoE rotation is pretty much the same as single target and cleave with the only exception of adding [[talent:134421]] into your priority list.

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:190356]] on cooldown if [[spell:270233]] is active.
2. Cast [[talent:80243]] if you have [[talent:80244]] proc and [[talent:80248]] is not active.
3. Cast [[talent:80241]] if you have 2 stacks of [[spell:112965]].
4. Cast [[talent:80242]] on cooldown.
5. Cast [[spell:199786]] on cooldown.
6. Cast [[talent:80241]] if you have [[spell:112965]] active or your target has 6 or more stacks of [[spell:1221389]].
7. Cast [[talent:80243]] on cooldown.
8. Cast [[talent:80216]] on cooldown.
   
   - Although its priority is very low and used mainly to apply [[spell:1221389]] stacks, it still does significant amount of damage by itself. Thus, if the fight is about to end, you want to priorotise casting [[talent:80216]] over anything else to maximise amount of casts of it.
9. Cast [[spell:116]].





## Deep dive

### Freeze and Shatter

Due to a new [[spell:1246752]], gameplay loop is going to revolve around accumulating [[spell:1221389]] stacks with [[spell:116]] and [[talent:80243]] and [[spell:1246769]] them with [[talent:80241]]. Since we also don't have any major cooldowns anymore, maintaining a proper rotation without overcapping [[spell:1221389]] stacks and wasting our other procs is going to be very crucial to have a solid output.

### Min-maxing Cleave

Because of how easy it is to overcap [[spell:1221389]] stacks, it is a damage gain to try and spread it across your targets so you can clear multiple of them with each cast of [[spell:30455]]. This way you can spend 12 stacks of [[spell:1221389]] at a time instead of usual 6, for example.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Frost Mage** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[talent:80176]] with [[talent:80157]].




### Den of Nalorakk

:::talents **Frost Mage** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:115877]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Frost Mage** Mythic+ Build in Murder Row
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Frost Mage** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots with a [[talent:115877]].
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Frost Mage** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Frost Mage** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Frost Mage** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Frost Mage** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFegZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwCAbLjZMDmthxMjFAAAmZDYGGDYGMM"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system stays the same going into **Midnight** with the only exception of adding [[spell:1284818]] to the lower keys.

- +2 Affix 
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Alternates between each other on a weekly basis, is always the opposite of the +7 Affix
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Frost Mage**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:125819]] and [[talent:125818]] are great tools for this affix.
- Xal'atath's Bargain: Voidbound
  
  - Important to kill this instantly as it reduces damage taken for all nearby enemies.
- Xal'atath's Bargain: Devour
  
  - Can't do much on this affix, [[talent:80158]] is a decent talent so that your healer can prioritize dispelling other players in the group.
- Xal'atath's Bargain: Pulsar
  
  - Nothing special you can do with this affix. Just make sure to not run after your own orb but look for orbs from your teammates instead.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Frost Mage**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Frost Mage** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUAIxQCKEMABEA"
}
```
**智力 ≫ 暴击 ≥ 精通 ≫ 急速 ≫ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** **-** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -** Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DCRAAAEAnk7cVrjgCYhNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAAEAE06QQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271562@DgQAAAEAXk7IoAOF]] | Tier / Catalyst |
| Cloak | [[item:268253@BgRAAAEAYYjX1kjAYFA]] | The Coiled Altar |
| Chest | [[item:271567@DgQAAAEAJk7IoAOF]] | Tier / Catalyst |
| Wrist | [[item:239648@BiUAAAEAE06Y7LjVT0wAwIgBTWiwgN3Wjt1sUA]] | Crafting |
| Gloves | Convert [[item:268243@AgQAAIoAYFA]]  <br>into [[item:271565@BASAA4DA7VTg1ghNCKAWBA]] | Catalyst of The Coiled Altar |
| Belt | [[item:271561@BiQAAAEAE06IoAOF]] | Catalyst |
| Legs | [[item:271563@DgQAAAEAFo6IoAOF]] | Tier / Catalyst |
| Boots | [[item:268255@DgRAAAEAxj7ghNeVTOCgVA]] | The Coiled Altar |
| Ring 1 | [[item:268249@DiQAAAEA1j7QQrjgC4UA]] | Vashnik the Malignant |
| Ring 2 | [[item:158366@DCSAAAEA1j7QQrjNy4VN2Wzpl4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAAEACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:250215@BgQAAAEACKgTBA]] | Murder Row |
| Main-hand | [[item:271092@DgQAAAEA_k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@BAUAAAEA2-yY1ENM3WTWiwgNLXDAjsUA]] | Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251232@AgQAAIoABFA]] | Voidscar Arena |
| Neck | [[item:251234@AgQAAIoABFA]] | Voidscar Arena |
| Shoulder | [[item:239031@AgQAAIoABFA]] | Temple of Sethraliss |
| Cloak | [[item:251190@BgQAAAEACKQQBA]] | The Blinding Vale |
| Chest | [[item:239032@AgQAAIoABFA]] | Temple of Sethraliss |
| Wrist | [[item:251154@AgQAAIoABFA]] | Den of Nalorakk |
| Gloves | [[item:273773@AgQAAIoABFA]] | Altar of Fangs |
| Belt | [[item:159255@AgQAAIoABFA]] | Temple of Sethraliss |
| Legs | [[item:193750@AgQAAIoABFA]] | Ruby Life Pools |
| Boots | [[item:251137@AgQAAIoABFA]] | Murder Row |
| Ring 1 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Ring 2 | [[item:158366@AgQAAIoABFA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | The Blinding Vale |
| Trinket 2 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Weapon | [[item:159636@AgQAAIoABFA]] | Temple of Sethraliss |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **B-Tier** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]] |
| **C-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Only crafted on your **weapon** or **off-hand**.
- 1x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists** or **Cloak** depending on your available gear.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]] -- default
- Combat Potion
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] -- default
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- *unique, can use only one*
  
  
  
  - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAAEAZbAB]]  <br>[[item:275707@BAAAAAE]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAAE]] |
| Chest | [[item:243977@BAAAAAE]] |
| Wrist | [[item:275707@BAAAAAE]] |
| Waist | [[item:275707@BAAAAAE]] |
| Legs | [[item:240133@BAAAAAE]] |
| Boots | [[item:243953@BAAAAAE]] |
| Ring 1 | [[item:243957@BAAAAAE]] |
| Ring 2 | [[item:243957@BAAAAAE]] |
| Weapon | [[item:244031@BAAAAAE]] |

:::

:::column
:::gear **Frost Mage** Enchantments in Mythic+
```json
{
  "source_code": "IQFZABQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAAEAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Frost Mage** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:33702]] -- Orc
  
  - Strong DPS.
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation, you are placed on a global cooldown until your character lands.
- [[spell:26297]] -- Troll
  
  - Strong DPS.
  - Reduce the duration of movement impairing effects by 20%.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Frost Mage**.

## Macros

Discover recommended macros for Frost Mages during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**Cursor [[spell:190356]] --** *Casts [[spell:190356]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Blizzard
```

:::

:::details Mouseover Macros
**Mouseover [[spell:475]] -** *Uses [[spell:475]] on your mouseover, your target if there are no targets under your cursor or, lastly, yourself*.

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][exists,nodead][@player] Remove Curse
```

:::

:::details Utility Macros
**Cancel [[spell:342245]] --** *Cancels your [[spell:342245]] buff in case you used it poorly - on low health or in bad position.*

```wow-macro
#showtooltip Alter Time
/cancelaura Alter Time
```

**[[spell:1953]] during [[spell:45438]] --** *Cancels your [[spell:45438]] and immediately [[spell:1953]]. Useful when you've used [[spell:45438]] in a void zone and it's not gone by the end of it.*

```wow-macro
#showtooltip
/cancelaura Ice Block
/cast Blink
```

**[[spell:116]] --** *Cancels your [[spell:45438]] if you try to cast [[spell:116]], can replace your usual keybind with it to have an easier time cancelling your [[spell:45438]], normal keybind for it usually takes a global to happen but with cancelaura macro you can do it instantly. Additionally, [nochanneling] part allows you to spam the keybind during channeling casts like [[spell:382440]] and not interrupt it until the cast is done.*

```wow-macro
#showtooltip Frostbolt
/cancelaura Ice Block
/cast [nochanneling] Frostbolt
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Frost Mage**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Frost-Mythic-UI-1024x616.png>)

**Frost Mage** **Mythic+ User Interface**

:::accordion
:::details Addons
- **EllesmereUI** -- Unit frames, nameplates, cooldown manager replacement, and many more
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **LittleWigs** *-- Generic Boss Mod* 
  
  - This is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger +alert messages, timer bars, sounds, and so forth, for one specific boss encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- *Developers' notes: We've made some adjustments to Mage defensives with the goal of improving Mage survivability as a whole. To accomplish this, we are unifying the functionality of Improved Barrier to give all specs an additional charge of their Barrier spell, plus one “rider” effect that is spec-specific.*
- New Talent: Improved Warding – Damage taken from area of effect attacks reduced by 4%.
- Improved Prismatic Barrier has been redesigned – Prismatic Barrier gains an additional charge and further reduces magic damage taken by 5%.
- Improved Blazing Barrier has been redesigned – Blazing Barrier gains an additional charge and cauterizes your wounds, healing you for 15% of the damage it absorbs.
- Improved Ice Barrier has been redesigned – Ice Barrier gains an additional charge and reduces your physical damage taken by 10%.
- Temporal Realignment has been updated – Now immediately heals 20% of your health and heals an additional 30% over 6 seconds.
- Frost
  
  - Glacial Bulwark has been updated – No longer grants an additional charge of Ice Barrier.
  - Splitting Ice has been updated – Flurry and Frostbolt effectiveness against the second target reduced to 50% (was 80%).
  - Fractured Frost has been updated – Ice Lance effectiveness against the second target reduced to 50% (was 100%).
  - All ability and pet damage increased by 7%.
  - Apex Talent: Hand of Frost (Rank 2) now grants 0.5%/1% increased spell damage (was 1%/2%).
    
    - *Developers' notes: Hand of Frost in combination with Frost's Hero Talents was providing more burst than we'd like.*

:::

:::

:::accordion
:::details Patch 12.0.1
- Mage
  
  - Hero Talents
    
    - [[talent:123342]]
      
      - Flash Freezeburn has been updated – Glacial Spike cleave percentage reduced to 25% (was 50%).
      - Frostfire Empowerment damage bonus reduced to 60% (was 80%).
      - Frostfire Bolt damage reduced by 20%.
      - Isothermic Core's Meteor now Shatters 1 Freezing stack (was 2).
      - Duality's Pyroblast damage increased by 100%.
      - Molten Chill Ignite effectiveness increased to 30% (was 15%).
    - [[talent:123339]]
      
      - Controlled Instincts damage effectiveness increased to 60% (was 40%).
      - Frost Splinter damage increased by 20%.
  - Frost
    
    - Developers' notes: We're reducing the power of Frostbolt and Flurry to help Ice Lance and Shatter continue to be the rotational priority. We're moving some of that lost power into Ice Lance and Shatter to mitigate the throughput impact of these changes in low-target scenarios. We're also tamping down Frostfire's performance in AOE, since it has been overperforming.
    - All damage dealt increased by 5%.
    - Ice Lance damage increased by 25%.
    - Shatter primary target damage increased by 54%.
    - Flurry damage reduced by 28%.
    - Frostbolt damage reduced by 15%.
    - Frozen Orb damage reduced by 20%.
    - Glacial Assault chance to trigger reduced to 12% (was 25%).
    - Splitting Ice now causes Flurry and Frostbolt to strike an additional target at 80% effectiveness (was 100%).
    - Comet Storm now Shatters 1 Freezing stack per Missile (was 2).
    - Icicles visual effects now automatically hide and reappear based on whether you're in combat or not.
    - Fixed an issue that caused all Water Elemental glyphs to not be properly applied to the Water Elemental spell.

:::

:::

:::accordion
:::details Patch 12.0
- Mage
  
  - New Talent: Improved Conjuration – Mirror Image's cooldown is reduced by 30 seconds/60 seconds.
  - New Talent: Time Walk – Alter Time resets the cooldown of Blink and Shimmer when you return to your original location.
  - New Talent: Spatial Manipulation – Blink gains an additional charge.
  - New Talent: Temporal Realignment – Upon dropping below 25% health, your past self corrects your timeline, casting Alter Time and instantly returning 50% of your maximum health.
  - New Talent: Improved Ice Barrier – Ice Barrier's absorb is increased by 5% of your maximum health and it now reduces your physical damage taken by 10%. Frost Mage only.
  - New Talent: Improved Blazing Barrier – Blazing Barrier's damage is increased by 200% and it now cauterizes your wounds, healing you for 15% of the damage it absorbs. Fire Mage only.
  - New Talent: Charm of Aegwynn – The critical strike damage of your spells is increased by 5%.
  - New Talent: Charm of Medivh – Mastery increased by 3%.
  - New Talent: Improved Blink – Blink's cooldown is reduced by 2 seconds.
  - New Talent: Permafrost Bauble - The cooldown of Ice Block and Ice Cold is reduced by 30 seconds.
  - New Talent: Master of Escape – Reduces the cooldown of Greater Invisibility by 45 seconds.
  - New Talent: Brainstorm – Hot Streak, Clearcasting, and Brain Freeze increase your Intellect by 1% for 8 seconds. Multiple applications may overlap.
  - New Talent: Improved Spellsteal – Spellsteal repeats its effect after 4 seconds, but it now has a cooldown of 4 seconds.
  - New Talent: Improved Counterspell – Counterspell prevents casting for an additional 1 second.
  - New Talent: Improved Remove Curse – Casting Remove Curse on a friendly target also casts it on yourself, but its cooldown is increased by 20 seconds.
  - New Talent: Mana Confluence – Your mana costs are reduced by 5%.
  - New Talent: Reflection – After casting Blink, it is replaced with Reflection for 8 seconds.Reflection: Teleports you back to where you last Blinked. Castable while casting and unaffected by the global cooldown.
  - Master of Time has been updated – Reduces Alter Time cooldown by 5 seconds/10 seconds. No longer grants an additional charge of Blink/Shimmer after casting Alter Time.
  - Overflowing Energy has been updated – Now increases the critical strike chance of Arcane Barrage, Fireball, and Frostbolt only. Now grants 20% increased Fireball critical strike chance per stack (was 10%).
  - Quick Witted has been updated – Counterspell's cooldown is reduced by 5 seconds.
  - Time Manipulation has been updated – Now reduces the cooldown of your loss of control spells by 5 seconds.
  - Incantation of Swiftness has been updated – Invisibility now increases your movement speed by 20%/40% for 6 seconds.
  - Mirror Image has been updated – No longer reduces the damage you take. Tooltip now correctly communicates its threat reduction effect.
  - Mirror Image duration reduced to 15 seconds (was 40 seconds).
  - All Barrier spells have had their cooldowns increased to 30 seconds (was 25 seconds).
  - Barrier spells now have a reduced global cooldown and now shield you for 25% of your maximum health (was 20%).
  - Blink cooldown increased to 15 seconds inherently.
  - Shimmer cooldown increased to 30 seconds (was 25 seconds) and no longer has 2 charges inherently.
  - Greater Invisibility no longer reduces damage you take by 60%.
  - Counterspell cooldown increased to 25 seconds (was 24 seconds).
  - Cone of Cold cooldown increased to 25 seconds (was 12 seconds) and now applies Chilled.
  - Ice Nova now replaces Cone of Cold when talented.
  - Flow of Time is now a 1-point talent.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Accumulative Shielding
    
    
    
    - Blast Wave
    - Displacement
    - Diverted Energy
    - Frigid Winds
    - Ice Floes *(moved to the Frost talent tree)*
    - Incanter's Flow
    - Mass Barrier
    - Reabsorption
    
    
    
    - Reduplication
    - Rigid Ice
    - Shifting Power
    - Slow
    - Supernova
    - Tempest Barrier
    - Temporal Velocity
    - Volatile Destruction
  - Hero Talents
    
    - [[talent:123342]]
      
      - New Talent: Duality – Casting Glacial Spike also casts a Pyroblast, dealing moderate Fire damage.
      - New Talent: Molten Chill – Your Frostfire spells apply Ignite, dealing an additional 15% of their damage over 9 seconds.
      - New Talent: Elemental Conduit – Comet Storm, Glacial Spike, Pyroblast, and Meteor now apply Ignite. Your Haste is increased by 8%.
      - New Talent: Heat Sink – Flurry now deals Frostfire damage and its damage is increased by 10%.
      - New Talent: Dualcasting Adept – Your Fire spells deal 20% increased critical strike damage. Shatter and Blizzard damage increased by 10%.
      - New Talent: Blast Radius – Comet Storm damage increased by 20%. Meteor damage increased by 20%.
      - Flash Freezeburn has been redesigned – Glacial Spike damage increased by 25% and it now explodes on impact, dealing 50% of its damage to up to 5 nearby enemies. Additionally, Glacial Spike now grants Frostfire Empowerment.
      - Frostfire Infusion has been updated – Frostfire Bolt has an additional 5% chance to grant Brain Freeze. The damage of your Frost and Fire spells are increased by 4%.
      - Severe Temperatures has been updated – Frostfire Empowerment stacks 1 additional time and it causes Frostfire Bolt to explode for an additional 20% of its damage.
      - Frostfire Empowerment has been updated – Now triggered from casting Frostfire spells (was Frostfire spell damage).
      - Isothermic Core's Meteor and Comet Storm damage increased by 35%.
      - Isothermic Core tooltip updated to show the actual damage values of the Meteor/Comet Storms summoned and is now conditionalized based on your specialization.
      - Frostfire Bolt cast time reduced to 1.75 seconds (was 2 seconds).
      - Frostfire Bolt direct damage increased by 95%.
      - Frostfire Bolt periodic damage increased by 123%.
      - Frostfire Bolt's tooltip now has two specialization specific versions that only can be seen and selected by Frost or Fire. They now override only Frostbolt or Fireball based on your specialization.
      - Several talents have changed positions in the talent tree.
      - The following talents have been removed:
        
        - Excess Fire
        - Excess Frost
        - Frostfire Mastery
      - Flame and Frost has been updated – Now triggers from Ice Block and Ice Cold (was Cold Snap).
      - Dualcasting Adept has been updated – Now increases Shatter damage (was Ice Lance damage).
      - Meteors summoned via Isothermic Core now Shatters up to 2 stacks of Freezing.
      - Frostfire Empowerment no longer affects Glacial Spike.
    - [[talent:123339]]
      
      - New Talent: Attuned Familiar – Your Water Elemental has a 50% chance to conjure a Splinter alongside its Waterbolt.
      - New Talent: Infused Splinters – Direct damage from Frost Splinters have a 15% chance to apply 1 stack of Freezing.
      - New Talent: Polished Focus – Ice Lance Shatters 1 additional stack of Freezing. Shatter damage increased by 15%.
      - New Talent: Archmage's Wrath – Ray of Frost damage increased by 20%. Your chance to gain Brain Freeze from Frostbolt is increased by 5%
      - Splinterstorm has been redesigned – Each time Ray of Frost damages one or more enemies, it conjures 1 Frost Splinter. For 10 seconds after casting Ray of Frost, your chance to conjure an additional Frost Splinter is increased to 100%.
      - Look Again has been redesigned – While in combat, Blink summons a Mirror Image at your previous location.
      - Augury Abounds has been redesigned – Conjuring one or more Splinter has a 10% chance to conjure a burst of 8 Splinters.
      - Shifting Shards has been updated – Gaining Brain Freeze conjures 2 Frost Splinters.
      - Force of Will has been updated – Ice Lance conjures a Frost Splinter for every 2 Freezing stacks Shattered from its primary target.
      - Signature Spell has been updated – Frostbolt and Blizzard damage increased by 15%. Glacial Spike conjures 2 additional Frost Splinters.
      - Spellfrost Teachings has been updated – Frozen Orb cooldown reduction reduced to 0.25 seconds (was 0.5 seconds).
      - Splintering Sorcery has been updated – Splinters no longer apply a damage over time effect.
      - Controlled Instincts has been updated – Splinter cleave percentage increased to 30% (was 20%). No longer requires your target to have been recently damaged by Blizzard.
      - Splinters will now prefer targeting enemies that you have recently targeted with your spells.
      - When more than 1 Splinter is generated in a single event, Splinters will now fire on a delayed cadence, similar to how Splinterstorm used to function.
      - Reactive Barrier absorb amount reduced to 25% (was 50%).
      - Embedded Splinters are no longer tracked on nameplates.
      - Several talents have changed positions in the talent tree.
      - The following talents have been removed:
        
        - Unerring Proficiency
        - Volatile Magic
      - Splintering Sorcery has been updated – Casting Frostbolt or Flurry conjures a Frost Splinter.
  - Frost
    
    - New Passive Ability: Shatter – Damage from Frostbolt and Flurry applies Freezing to their targets. Stacks up to 20 times. Damage from Ice Lance shatters your enemies, consuming 4 stacks of Freezing and dealing Frost damage for each stack removed.
    - New Passive Ability: Winter's End – When an enemy affected by Freezing dies, it explodes, dealing Frost damage to nearby enemies for each stack of Freezing it had. Damage reduced beyond 5 targets. Learned at level 40.
    - Mastery has been redesigned and renamed Freeze and Shatter – Now increases the damage of spells that Freeze your enemies and increases the damage of spells that Shatter.
    - New Talent: Improved Shatter – Shatter damage has a 50% increased chance to critically strike.
    - New Talent: Icicles – Frost crystallizes around you, generating an Icicle every 6 seconds. Upon generating 5 Icicles, Frostbolt upgrades to Glacial Spike for its next cast. Icicles generate rapidly out of combat. Icicle generation is increased by Haste.
    - New Talent: Glacial Bulwark – Ice Block and Frost Barrier now have an additional charge.
    - New Talent: Summon Water Elemental – Summons a Water Elemental to follow and fight for you.
      
      - Waterbolt damage increased by 100%.
      
      
      
      - Water Jet damage increased by 100% and no longer grants Brain Freeze.
    - New Talent: Cone of Frost – Cone of Cold/Ice Nova now applies 3 stack of Freezing to up to 5 enemies.
    - New Talent: Crystalline Refraction – Ray of Frost generates 2 stacks of Fingers of Frost over its duration.
    - New Talent: Heart of Ice – Ice Lance shatters 1 additional stack of Freezing.
    - New Talent: Rimecaster – Frostbolt and Glacial Spike damage increased by 10%/20%.
    - New Talent: Glaciate – When Ice Lance shatters a stack of Freezing, the cooldown of Ray of Frost is reduced by 0.1 second.
    - New Talent: Frigid Focus – Ray of Frost damage increased by 30%.
    - New Talent: Improved Flurry – Flurry fires 1 additional missile.
    - New Talent: Glacial Chill – Glacial Spike damage increased by 5% and it now applies 2 additional stacks of Freezing.
    - New Talent: Glacial Shatter – Glacial Spike no longer applies Freezing and it now Shatters 5 stacks of Freezing.
    - New Talent: White Out – Ice Lance reduces the cooldown of Frozen Orb by 0.5 seconds, increased by 0.1 second for each stack of Freezing Shattered.
    - Ice Lance has been updated - Now Shatters 4 stacks of Freezing.
    - Permafrost Lances has been updated – Now increases Shatter damage by 10% for the duration of Frozen Orb (was Ice Lance damage).
    - Glacial Attunement has been updated – Now increases Flurry and Blizzard damage (was Flurry and Ice Lance).
    - Fingers of Frost has been updated – No longer triggers from Frozen Orb inherently. Now causes your next Ice Lance to Shatter the maximum number of Freezing stacks Ice Lance is capable of Shattering without consuming Freezing stacks.
    - Everlasting Frost has been redesigned – Casting Frozen Orb grants 1 stack of Fingers of Frost. Damaging one or more enemies with Frozen Orb has a 3% chance to grant Fingers of Frost.
    - Deep Shatter has been updated – Shatter's critical strike damage is increased by 50% of your critical strike chance.
    - Hailstones has been updated – The time it takes to generate an Icicle is reduced by 1 second.
    - Wintertide has been redesigned – Frozen Orb has a 100% chance to grant Brain Freeze.
    - Glacial Assault has been updated – Damage increased by 260% and no longer applies a damage received bonus. Now applies 1 stack of Freezing. No longer affects Comet Storm.
    - Freezing Winds has been redesigned – Shattering enemies inside your Blizzard increases Shatter's area damage by 15%.
    - Winter's Blessing has been updated – Now grants 3% Haste and grants 5% additional Haste from all Haste sources.
    - Splitting Ice has been updated – Your Flurry and Frostbolt spells strike 1 additional target at 100% effectiveness.
    - Ray of Frost has been updated – Damage increased by 66% and damage tick rate improved to 0.5 seconds (was 1 second). Each time Ray of Frost deals damage, it applies a stack of Freezing. No longer grants Fingers of Frost inherently.
    - Ray of Frost duration reduced to 4 seconds, tick rate reduced to 0.5 seconds (was 5 second duration, 0.625 seconds tick rate).
    - Freezing Rain has been updated – Now increases Blizzard damage by 20% (was 60%).
    - Comet Storm has been updated – Casting Ray of Frost replaces your Ray of Frost with Comet Storm, calling down a series of 7 icy comets on and around your target, that deals Frost damage to all enemies within 8 yards of its impacts. Each Comet Shatters 2 stacks of Freezing. Comet Storm damage increased by 88%.
    - Flash Freeze has been updated – Casting Glacial Spike has a 100% chance to grant you Fingers of Frost.
    - Frostbite has been updated – When Frostbolt critically strikes, it applies 1 additional stack of Freezing. Now causes Shatter to deal damage to nearby enemies, damage reduced beyond 5 enemies.
    - Piercing Cold has been updated – Now increases Flurry and Frostbolt critical strike damage.
    - Fractured Frost has been redesigned – Your Ice Lance strikes 1 additional target at 100% effectiveness, preferring enemies with more Freezing stacks.
    - Thermal Void has been redesigned – Consuming Brain Freeze has a 100% chance to cause your next Ice Lance to Shatter 4 additional stacks of Freezing.
    - Lonely Winter has been redesigned – Spell damage increased by 3%.
    - Blizzard and Cold Snap are now located in the Frost talent tree (was learned automatically when specialized as Frost).
    - Ice Floes is now a passive ability and moved to the Frost talent tree (was in the class tree).
    - Ice Lance now replaces Fire Blast upon activating the Frost Mage specialization.
    - Ice Lance damage increased by 102%.
    - Frostbolt damage increased by 200%.
    - Frostbolt cast time reduced to 1.75 seconds (was 2 seconds).
    - Flurry damage increased by 181% and it now has a new icon.
    - Frozen Orb damage increased by 800% and no longer grants Fingers of Frost when cast.
    - Frozen Orb now slowly follows its target shortly after being cast.
    - Blizzard damage increased by 305%.
    - Blizzard now has an additional talent option to cast Blizzard at your target.
    - Glacial Spike damage increased by 100%.
    - Haste now reduces the cooldown of Flurry, Frozen Orb, and Ray of Frost.
    - Cold Snap is now a Frost spell.
    - Many talents have changed positions in the talent tree.
    - The Starter Build has been updated.
    - The following talents have been removed:
      
      - Bone Chilling
      
      
      
      - Chain Reaction
      - Coldest Snap
      - Cold Front
      - Cryopathy
      - Death's Chill
      - Glacial Spike *(effect moved to the Icicles talent)*
      - Ice Caller
      - Icy Veins
      - Slick Ice
      - Splintering Cold
      - Subzero

:::

:::

## FAQ

:::accordion
:::details Q: Why is my [[spell:135029]] always on cooldown?
**A:** [[spell:135029]] is by default on auto-cast and is used off cooldown by your water elemental pet. Right click on it on the pet bar to turn it off. Don't forget to press it manually afterwards when you need it.

:::

:::

---

### Credits

Written By: **Wexi**

Reviewed By: **Xerwo**

:::changelog 更新记录
**2026-08-03** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-21** Updated for patch 12.0.1.

**2026-01-16** Updated for patch 12.0.



:::
