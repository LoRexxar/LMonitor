欢迎来到魔兽世界12.1版本的**湮灭 唤魔师** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始练级的玩家吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 4/5 · 强

生存能力 · 4/5 · 强

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **湮灭 唤魔师** 团队副本最佳配装
```json
{
  "source_code": "JAoAwD1uFc__BEQjkQggIEAAnk7AX16ACKgTBEQ6XQAAREAAE06AE06AMWjgCgVABsIJEIACBAwF5OggCgVABQgJEIAEBAQC5OggCwYNYFQAefBBAiQB0UwQAwYCvQQBqmwLIk8FEEgPAkSAvgjTBEAa7OAhIEAAYA8AnoaAkxyt1sUAB4IJEAACBAQB_AS2XQggAEAA1jbAeQhTBEgnqJQAkmAEFICBU9RGuQAhtkBDE09FNwAFYFQA0LCBBYHA_EgdMhVABkAwDQACBAAelNApqQwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271499]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240900]] |
| 腿部 | [[item:271500]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:244009]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:273796]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] | [[item:222584]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为 **湮灭**，你可以使用 冲天怒火，它会给予你一个可叠加的 急速 增益，并在 [[talent:115643@FAQA4AcB]] 期间及结束后提高你的伤害。

**第1级：** 当 [[talent:115643@FAQA4AcB]] 处于激活状态时，你每6秒获得一层 [[spell:1271687]]，每层提供4% 急速，最多叠加5次。

**等级2 - (1/2)：** 当[[spell:1271687]]达到5层时，造成的所有伤害提高8%。

**等级2 - (2/2)：** 当[[spell:1271687]]达到5层时，造成的所有伤害提高15%。

**第3级：**当[[talent:115643@FAQA4AcB]]结束时，[[spell:1271687]]每层可持续4秒，并且[[talent:115643@FAQA4AcB]]变为[[spell:1292321]]。[[spell:1292321]]可以在[[talent:115643@FAQA4AcB]]冷却结束前施放4次。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-devastation-mxr.webp>)

冲天怒火

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:115579]]
    
    - 一项新的专注于 范围伤害 的天赋，在施放 [[talent:115581]] 后将你的下一个 [[spell:362969]] 升级为更强大的版本。
    - 在第一赛季套装的强力加持下，它成为所有情况下的核心循环法术。
  - [[talent:115623]]
    
    - 允许你在初次施放后的 18 秒内再次施放 [[spell:357210]]。
    - 与 [[talent:115639]] 和 [[talent:117550@AJQD]] 作为 [[talent:123333]] 有强大的协同效果。
- **职业天赋树**
  
  - [[talent:115617]]
    
    - 此前是一个 **增辉** 专属天赋，后来被移到了 唤魔师 职业天赋树，让你在使用 [[spell:357210]] 时更加安全！
  - [[talent:115669]]
    
    - 不再作为独立法术存在，现在与 [[talent:115613]] 绑定为效果较弱的机制。
- **已移除**
  
  - [[spell:370962]]
    
    - [[spell:357211]] 现在造成更多伤害，但施放需要消耗 3 点精华，除非你已激活 [[talent:115638]]。
  - [[spell:368847]]
    
    - 不再作为独立法术存在，只会由 [[talent:115584]] 触发。
  - [[spell:370452]]
    
    - 不再作为独立法术存在，因为它被改为被动效果 [[talent:115627]]。

## 英雄天赋

- [[talent:123333]]在除长时间范围伤害情况外的所有场景中都强于[[talent:123336]]。

:::tabs
:::tab [[talent:123333]]
[[talent:123333]]英雄天赋主要围绕两个关键法术：[[spell:436335]]和[[spell:357210]]。

#### 群体裂解

- [[spell:357208]]和[[spell:359073]]会将你的下一次[[spell:356995]]施放变为[[spell:436335]]，后者最多可命中3-4个目标，或在目标较少时造成更高的伤害。

- [[spell:434300@FJQBJHXBknYBNLZB7zwB8zwBNA]]
  
  - 是另一个与 [[talent:123333]] 相关联的 [[spell:436335]] 天赋。
  - 在目标身上施加一个减益效果，当你和你的盟友攻击该目标时，会触发轰炸。
  - 可被 [[spell:441206@FJQBJHXBknYBNLZB7zwB8zwBNA]] 和 [[talent:117525]] 进一步强化。

#### 深呼吸

- 另一个受到[[talent:123333]]天赋树大幅增强的能力。

- [[talent:117518]]
  
  - [[spell:357210]] 现在会使敌人受到来自 [[spell:434300@FJQBJHXBknYBNLZB7zwB8zwBNA]]、[[spell:356995]] 和 [[spell:357211]] 的伤害提高 20%。
- [[talent:120123]]
  
  - [[spell:357210]]会返还你一层 [[spell:358267]]。由于你在新天赋 [[spell:357210]] 下会非常频繁地使用 [[talent:115623]]，这是一项巨大的机动性提升。
- [[talent:117538]]
  
  - [[spell:357210]] 现在可以在飞行途中转向和取消，并附加一个持续 12 秒的额外持续伤害效果。

在 12.0 版本中，暴风雪 移除了原本的《地心之战》第三赛季套装，并新增了 3 个英雄天赋点。

- [[talent:136053]]
  
  - 在 [[spell:357210]] 飞行期间，2名龙希尔突击队员会伴随你飞行，并用火炮攻击附近的敌人，最多8次。
  - 你应该至少保持一定的飞行时间，好让突击队员有机会施放他们的法术。
- [[talent:136052@AJQD]]
  
  - [[talent:117536]] 会额外命中1个目标。
- [[talent:136051]]
  
  - 精粹法术的伤害提高15%。

:::

:::tab [[talent:123336]]
在 至暗之夜 中，[[spell:443328]]，[[talent:123336]] 之前的核心技能已被移除，游戏玩法转而围绕 [[spell:357208]] 展开。

#### 火焰吐息

该法术与英雄天赋树中的大多数天赋存在互动或被其增强。

- [[talent:117547@AJQD]]
  
  - [[spell:357208]] 获得额外一层充能。
- [[talent:123416]]
  
  - [[spell:357208]] 冷却时间缩短5秒。
- [[talent:117543@AJQD]]
  
  - [[spell:357208]] 达到最高蓄力等级的速度加快20%。
- [[talent:117542@AJQD]]
  
  - [[spell:357208]] 持续伤害效果的持续时间延长4秒。
- [[talent:128713]]
  
  - [[spell:357208]] 持续伤害效果提高30%。
- [[talent:117520@AJQD]]
  
  - [[spell:357208]] 造成伤害的频率提高15%。
- [[talent:136055@AJQD]]
  
  - [[spell:357208]] 有50%的几率产生 [[spell:359565]]
- [[talent:117519@AJQD]]
  
  - [[spell:356995]]，且 [[spell:357211]] 的施放会消耗敌人身上的 [[spell:357208]] 持续时间，从而对其造成伤害。

##### 其他值得注意的天赋

- [[talent:117546]]
  
  - 对生命值高于50%的目标，你的爆击几率提高10%，这是相当可观的伤害提升，因此在合适的情况下应尽量以高生命值的目标为攻击对象。

你可以在以下防御天赋中进行选择：

- [[talent:117528]]
  
  - 由于[[spell:374348]]不再是独立法术，此天赋现在会以50%的效果施加[[spell:363916]]，也就是说这是一个带有少量治疗效果的15%减伤冷却技能。在大多数情况下，你应该在这两个天赋中选择它。
- [[talent:123405]]
  
  - 受到伤害时有小概率获得相当于所受伤害30%的治疗，平均下来大约能治疗你所受总伤害的5%。如果你是队伍中最脆弱的目标，这有时会是一个不错的选择。

在 12.0 版本中，暴风雪 移除了原本的《地心之战》第三赛季套装，并新增了 3 个英雄天赋点。

- [[talent:136055@AJQD]]
  
  - 施放 [[spell:357208]] 后有 50% 的几率触发 [[spell:359565]]
- [[talent:136056@AJQD]]
  
  - 消耗 [[spell:359565]] 会对你的目标造成伤害。
- [[talent:136054]]
  
  - [[talent:136056@AJQD]] 会对最多 2 个额外目标造成伤害。

:::

:::

## 天赋

:::tabs
:::tab [[talent:123336]] 单体
:::talents [[talent:123336]] **湮灭 唤魔师** 副本中的单体天赋
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZGmZYGzMMGYMTjZmJjx2YmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZGmZYGzMMGYMTjZmJjx2YmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM"
}
```
:::

### 何时使用该专精

这是团队副本中默认的 [[talent:123336]] 单体天赋构建。

### 改变游戏玩法的天赋

探索专精天赋树和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若想了解更多细节，请查看下方的循环和 **深入解析** 部分。

#### 专精树

- **[[talent:115579]]**
  
  - 一个新的循环技能，在每次 [[talent:115581@FAQANvbB]] 之后施放一次强化过的 碧蓝打击。
  - **在你获得第一赛季套装之前，你应该选择 [[talent:115582]]** **来替代它。**
- [[talent:115647]] 
  
  - 你的 范围伤害 精华消耗技能。
- [[talent:115581]] 
  
  - 你的专精专属蓄力法术，受 [[talent:115632]] 强化。
  - 它与 [[talent:115636]] 有额外的AoE协同效果。
- [[talent:115643]] 
  
  - 你的主要DPS冷却技能，受 [[talent:115642]] 和 [[talent:115640]] 强化。
- [[talent:115624]]
  
  - [[spell:357208]] 的伤害跳数有几率使你的下一次 [[spell:361469]] 变为瞬发。这在移动中优化伤害输出时尤其有用。
- [[talent:115683]] 
  
  - 使 [[spell:356995]] 和 [[spell:357211]] 减少你蓄力法术的冷却时间。
- [[talent:115622]]
  
  - 使你的 红 系法术对受 [[spell:357208]] 影响的目标造成的伤害提高25%。

#### 职业树

- [[talent:115654]]
  
  - 通常因能带来少量DPS提升而被选用，可通过被动治疗和主动副治疗叠加层数。你可以在空闲时间使用治疗法术来获得一些伤害。
- [[talent:115595]]
  
  - 在至暗之夜中，该天赋的伤害吸收护盾被移除，改为使你和 [[talent:115596]] 的目标获得短暂增益，移动速度提高 100%，并且可以在移动时施法。
- [[talent:115657]]
  
  - 每次施放 [[spell:357208]] 后，每个蓄力等级都会使你额外发射一道 [[spell:361469]]，带来无需额外消耗的顺劈伤害。敌人数量不足时，这些额外的 [[spell:361469]] 会自动治疗盟友，也能因此触发 [[spell:396187]]，并且还可能获得 [[talent:115654]] 的收益。
- [[talent:125610]]
  
  - 这是一个出色的功能性技能，能在需要大量移动时帮助治疗者；在某些需要更远施法距离的场景中，它对提高你自身的法术射程也非常重要。它与 [[talent:115666]] 构成二选一天赋节点，团队也可能需要后者。

:::

:::tab [[talent:123336]] 多目标
:::talents [[talent:123336]] **湮灭 唤魔师** 多目标 团本天赋
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZwMDzYmhxAjZaMzMZM2mZmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZwMDzYmhxAjZaMzMZM2mZmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM"
}
```
:::

### 何时使用该专精

在玩[[talent:123336]]时，如果战斗需要顺劈或范围伤害，请使用此配装。

### 天赋调整

列出与[[talent:123336]] 单体配装相比，职业和专精天赋树中的所有改动。

#### 专精树

**[[talent:115579]]**

- **在获得第一赛季套装之前，你应该选择[[talent:115627]]** **而不是这套配装。**

- **新增** 
  
  - [[talent:115632]]
    
    - 使[[spell:359073]]每等级可命中2个目标。
    - 与[[talent:115636]]有额外的顺劈协同效果。
  - [[talent:115591]] 2点
    
    - 配合[[talent:115647]]
    - 可造成更多范围伤害伤害。如果只是2目标的战斗，你可以把这两点加回[[talent:115641]]和[[talent:115582]]。
- **移除** 
  
  - [[talent:115641]] 1点
    
    - 损失2%爆击几率
  - [[talent:115627]]
    
    - 轻微的单体伤害损失。
  - [[talent:115582]]
    
    - 由于精华更容易溢出，会有轻微的伤害损失。

:::

:::tab [[talent:123333]] 单体
:::talents [[talent:123333]] **湮灭 唤魔师** 团本单体天赋
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 何时使用该专精

这是[[talent:123333]]团本默认的单体配装。

### 天赋调整

列出与[[talent:123336]] 单体配装相比，职业和专精天赋树中的所有改动。

#### 专精树

**[[talent:115579]]**

- **在获得第一赛季套装之前，你应该选择[[talent:115627]]** **而不是这套配装。**

- **新增** 
  
  - [[talent:115639]]
  - [[talent:115638]]
  - [[talent:115623]]
    
    - 选择了与[[talent:123333]]有协同效果的天赋。
- **移除** 
  
  - [[talent:115586]]
  - [[talent:115622]]
  - [[talent:115633]]
    
    - 移除了与[[talent:123336]]有协同效果的天赋。

#### 英雄天赋

将 [[talent:123336]] 换成了 [[talent:123333]]。

:::

:::tab [[talent:123333]] 多目标
:::talents [[talent:123333]] **湮灭 唤魔师** 团本中的多目标天赋
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 何时使用该专精

在玩[[talent:123333]]时，面对顺劈斩或范围伤害的战斗请使用此构建。

### 天赋调整

列出了与[[talent:123333]]单体输出构建相比，职业树和专精树中的所有改动。

#### 专精树

**[[talent:115579]]**

- **在获得第一赛季套装之前，你应该选择[[talent:115627]]** **而不是这套配装。**

- **已添加** 
  
  - [[talent:115632]]
    
    - 使 [[spell:359073]] 每级可命中 2 个目标。
    - 与 [[talent:115636]] 有额外的顺劈协同效果。
- **已移除** 
  
  - [[talent:115627]]
    
    - 牺牲少量单体伤害，换取顺劈伤害。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:1265802]] 的伤害提高50%，并且总是以你达到最大强化等级的状态施放。
- **4件套：** 每次触发效果时，会使你的 [[talent:115683]] 和 [[spell:357208]] 的剩余冷却时间额外缩短0.1秒。[[spell:359073]] 造成的伤害提高10%。[[spell:359073]]

### 单体目标

:::tabs
:::tab [[talent:123336]]
#### 起手循环

- 起手的目标是最大化你的 [[spell:375087]] 窗口，并用 [[spell:375797]] 延长它，同时尽量避免精华或 [[spell:396187]] 溢出。

:::rotation [[talent:123336]] **湮灭 唤魔师** 在 团队副本 中的单体起手式
```json
{
  "source_code": "JMZAwlgA9PYBHAlclBXdsxGAC8SuFAQACl3pFAAACEqeBYAb4kZBAIQAI66AAAAAAEAhtQAAIEAACKgTBIwgyFAIBYAWAWgQLD1EAAQD3lGdoBCVpVmcgMXZ0BgUVAQBx4SXAAEAC0_gFAAACMocFAAACgTmFA"
}
```
1. [[spell:361469]] 开战前
2. [[spell:375087]]  [[spell:370553]]
3. [[spell:359073]]
4. [[spell:366904]]  [[item:241288]] · [[item:273796]]
5. [[spell:356995]]
6. [[spell:356995]]  
   
   1. [[spell:1265867]] 配合套装加成
   2. [[spell:1265867]] 配合套装加成
   3. [[spell:356995]]
   4. [[spell:359073]]
   5. [[spell:366904]]
7. [[spell:361469]]
8. [[spell:356995]]
9. [[spell:366904]]
:::

#### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 若目标身上没有 [[spell:357208]] 则施放它 *- 等级 1*
2. 施放 [[spell:359073]] *- 等级 1*.
3. 持续施放 [[spell:356995]]，直到你的精华达到上限或目标身上的 [[spell:357208]] 结束为止
4. 施放 [[talent:115579]] - 配合第1赛季套装
5. 施放 [[spell:1292321]]
6. 施放 [[spell:361469]] - *如果你有 [[spell:375801]]。*
7. 持续施放 [[spell:356995]]，直到没有精华可施放或目标身上的 [[spell:357208]] 结束为止
8. 施放 [[spell:361469]]。

:::

:::tab [[talent:123333]]
#### 起手循环

- 起手的目标是最大化你的 [[spell:375087]] 窗口，并用 [[spell:375797]] 延长它，同时尽量避免精华或 [[spell:396187]] 溢出。

:::rotation [[talent:123333]] **湮灭 唤魔师** 在团队副本中的单体起手
```json
{
  "source_code": "JcaAw7jCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogxboaAAAAAANgAWASgQLD1EAAQD3lGdoBCVpVmcgMXZ0BgUVAAKCMocFAQACdeUTAQEvxAAC0_gBMIODKXBAEgQnH1EAAgQfXWB"
}
```
1. [[spell:361469]] 开战前
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]]
7. [[spell:436335]]  
   
   1. [[spell:1265867]] 配合套装加成
   2. [[spell:1265867]] 配合套装加成
   3. [[spell:356995]]  [[spell:1266151]]
   4. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:356995]]  [[spell:1266151]]
10. [[spell:353759]]
:::

- 请在下方查看起手之后的 狂龙之怒 窗口优先级。

#### 狂龙之怒 优先级列表

这是你的狂龙之怒窗口期的一般优先级。

1. 施放 [[spell:357210]] *- 当目标身上没有 [[talent:117518@AJQD]] 或 [[talent:115623]]* *即将结束时。*
2. 施放 [[spell:359073]] *- 等级 1*。
3. 施放 [[spell:357208]] *- 等级 1*。
4. 施放 [[spell:356995]]，直到你的精粹不再溢出。
5. 施放 [[talent:115579]] - 搭配第一赛季套装
6. 施放 [[spell:361469]] 以触发 [[spell:396187]] *- 如果你拥有 [[spell:375801]] 或 [[spell:369939]] 之一。*
7. 施放 [[spell:356995]]，直到你没有精粹可以再施放它为止。
8. 施放 [[spell:362969]] 以触发 [[spell:396187]]。

#### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:357210]] *- 当目标身上没有 [[talent:117518@AJQD]] 或 [[talent:115623]] 即将结束时。*
2. 施放 [[spell:359073]] *- 等级 1*。
3. 施放 [[spell:357208]] *- 等级 1*。
4. 施放 [[spell:356995]]，直到你的精粹不再溢出。
5. 施放 [[talent:115579]] *- **搭配 第一赛季***套装
6. 施放 [[spell:1292321]]
7. 施放 [[spell:361469]] *- 如果你拥有 2 层 [[spell:375801]]，或仅剩一层且即将结束。*
8. 施放 [[spell:356995]]，直到你没有精粹可以再施放它为止。
9. 施放 [[spell:361469]]，直到你拥有足够的精粹来施放 [[spell:356995]]。

:::

:::

### 多目标

:::tabs
:::tab [[talent:123336]]
#### 双目标起手

- 起手的目标是最大化你的 [[spell:375087]] 窗口，并用 [[spell:375797]] 延长它，同时尽量避免精华或 [[spell:396187]] 溢出。

:::rotation [[talent:123336]] **湮灭 唤魔师** 在团队副本中的双目标起手
```json
{
  "source_code": "JUcAYzgA9PYBHAlclBXdsxGACgTmFAgABgorDAAAAAQAE2CBAgQAAIoAOFgAvkbBAEgQ5daBAAgAhqXAGEALMAgADKXAMEgBYBYBCtMUTAAANcXa0hGIUlWZyByclRHASVBABEDIIQVYydWZ0BiM-4AAJkFB9PYEZ5DIAA0gyVACUFmcnVGdgIDACgTmFA"
}
```
1. [[spell:361469]] 开怪前
2. [[spell:366904]]  [[item:241288]] · [[item:273796]]
3. [[spell:375087]]  [[spell:370553]]
4. [[spell:359073]]
5. [[spell:366904]]
6. [[spell:356995]]
7. [[spell:356995]]  
   
   1. [[spell:1265867]] 有套装时
   2. [[spell:1265867]] 有套装时
   3. [[spell:356995]] 目标2
   4. [[spell:356995]] 目标2
   5. [[spell:366904]]
8. [[spell:361469]]
9. [[spell:356995]]
10. [[spell:356995]] 目标2
11. [[spell:356995]] 目标2
12. [[spell:366904]]
:::

- 在2个目标上，你的起手和循环与单体非常相似，只不过你 ideally 要在施放下一个之前，先用 [[talent:117519@AJQD]] 将两个目标的 火焰吐息 都尽量耗尽。

#### 3+ 目标起手

:::rotation [[talent:123336]] **湮灭 唤魔师** 在团队副本中的3+目标起手
```json
{
  "source_code": "JEaAYvgA9PYBHAlclBXdsxGACgTmFAgABgorDAAAAAQAE2CBAgQAAIoAOFgAvkbBAEgQ5daBAAgAhqXAGEALQAgQbNXBBwSDIgFgEI0yQNBAA0wdpRHagQValJHIzVGdAYVFA0wOAIQBJBhA9PYBAExRoAgA4kZBAAgQbNXB"
}
```
1. [[spell:361469]] 战前
2. [[spell:366904]]  [[item:241288]] · [[item:273796]]
3. [[spell:375087]]  [[spell:370553]]
4. [[spell:359073]]
5. [[spell:366904]]
6. [[spell:357211]]
7. [[spell:357211]]  
   
   1. [[spell:1265867]] 配合套装奖励
   2. [[spell:1265867]] 配合套装奖励
   3. [[spell:357211]]
   4. [[spell:366904]]
8. [[spell:361469]]
9. [[spell:357211]]
10. [[spell:366904]]
11. [[spell:357211]]
:::

- 在 3+ 目标时，你的起手和优先级会改为以 [[spell:357211]] 作为能量消耗技能，其余规则不变。
- 如果对次要目标造成的伤害无关紧要（这种情况很常见），你应该继续使用单体优先级列表，专注于对主目标输出伤害。

#### 3+ 目标优先级列表

1. 施放 [[spell:357208]] 如果目标身上没有它 *- 等级 1*
2. 施放 [[spell:359073]]
3. 施放 [[spell:357211]]，直到你的精粹不再溢出或目标身上的 [[spell:357208]] 即将结束
4. 施放 [[talent:115579]] - 搭配第一赛季套装
5. 施放 [[spell:1292321]]
6. 施放 [[spell:361469]] *- 如果你拥有 [[spell:375801]] 或 [[spell:369939]] 之一。*
7. 施放 [[spell:357211]]，直到你没有精粹可以再施放它为止。
8. 施放 [[spell:362969]]。

:::

:::tab [[talent:123333]]
#### 双目标起手

- 起手的目标是最大化你的 [[spell:375087]] 窗口，并用 [[spell:375797]] 延长它，同时尽量避免精华或 [[spell:396187]] 溢出。

:::rotation [[talent:123333]] **湮灭 唤魔师** 在团队副本中的双目标起手
```json
{
  "source_code": "JcbAw7jCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogzboaAAAgAVhJ3ZlRHIxAgNQAAXyAIBCtMUTAAANcXa0hGIUlWZyByclRHASVBAoIwgyVAABI05RNBAR8HDAIQ_DGwk4MocFAQACdeUTAAAC9dZFA"
}
```
1. [[spell:361469]] 战前准备
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]] 目标 1
7. [[spell:436335]] 目标 2 
   
   1. [[spell:1265867]] 有套装
   2. [[spell:1265867]] 有套装
   3. [[spell:356995]]  [[spell:1266151]]
   4. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:356995]]  [[spell:1266151]]
10. [[spell:353759]]
:::

- 作为 **[[talent:123333]]，在双目标情况下，** 与单目标的唯一区别在于：开局时，你应该在最初两个强化法术之后的两连发 [[talent:117536]] 中分别选择不同的目标，以将 [[talent:117533]] 施加到两个目标上。这样你就能从 [[talent:117525]] 中获得更多收益，因为它会延长两次轰炸的持续时间。

#### 4+目标起手

:::rotation [[talent:123333]] **湮灭 唤魔师** 在团队副本中的4+目标起手
```json
{
  "source_code": "JccAw7zCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogzboaAAAgAVhJ3ZlRHIxAgNQAAXyAYBCtMUTAAANcXa0hGIUlWZyByclRHAWVBAQwClGAAANEIFBI05RNBARcIDAIQ_DGQbaJCA"
}
```
1. [[spell:361469]] 战前准备
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]] 目标 1
7. [[spell:436335]] 目标 2 
   
   1. [[spell:1265867]] 有套装
   2. [[spell:1265867]] 有套装
   3. [[spell:431148]]
   4. [[spell:359073]]  [[spell:1266151]]
   5. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:431148]]
10. [[spell:359073]]  [[spell:1266151]]
11. [[spell:353759]]
:::

- **即使在面对更多目标时，也务必在增能法术之后使用** [[spell:436335]]。

#### 4+目标优先级列表

1. 施放 [[spell:357210]] *- 当目标身上没有 [[talent:117518@AJQD]] 或 [[talent:115623]] 即将耗尽时。*
2. 施放 [[spell:359073]] *- 根据目标数量进行强化。*
3. 施放 [[spell:357208]] *- 根据目标数量进行强化。*
4. 施放 [[spell:357211]] 作为 ⟦WOWTERM_0⟧ 消耗技能
5. 施放 [[talent:115579]] - 配合第1赛季套装
6. 施放 [[spell:1292321]]
7. 施放 [[spell:361469]] *- 如果你拥有 [[spell:375801]] 或 [[spell:369939]] 中的任意一个。*
8. 持续施放 [[spell:362969]]，直到你拥有足够的 ⟦WOWTERM_0⟧ 来施放消耗技能。

:::

:::

## 深度解析

### 强化法术

#### 火焰吐息

[[talent:123336]]

- 在几乎所有情况下都应施放1阶，因为 [[talent:117519@AJQD]] 和 [[talent:115622]]

[[talent:123333]]

- 在单体目标时通常以 1 级强化施放，因为你需要让持续伤害效果全程保持，以触发 [[spell:375801]] 并与 [[spell:386283]] 形成协同。
- 以更高的强化等级使用 [[spell:357208]] 会缩短持续伤害效果，换取更高的直接伤害；当你的目标存活时间不长时，应利用这一点。
- 一般也建议在 范围伤害 环境下将 [[spell:357208]] 强化到更高等级，因为 [[spell:375777]] 在配合 [[spell:357211]] 刷施时会大幅缩短该技能的冷却时间，否则你会覆盖已有的持续伤害效果并浪费伤害。此外，你还能从 [[talent:115657]] 中获得更高收益。

#### 永恒之涌

- 决定 [[spell:359073]] 使用什么等级非常简单，因为每提升一阶只增加1个受击目标（在有 [[spell:375757]] 时为2个）。
- 1-4阶： **1/2/3/4** 或 **2/4/6/8** 个受击目标（配合[[spell:375757]]）。
- 特别是在 [[talent:123336]] 时，通常不值得以更高等级施放此法术，即使面对更多目标，因为你本可以利用那段时间施放更多 [[spell:357211]]。

一般来说，当 [[spell:375087]] 即将冷却完毕时，你应该保留两个强化法术，以便正确延长 [[talent:115642]] 的持续时间。

### 裂解 机制

- 基础技能 [[spell:356995]] 的施法时间为 **两个** 公共冷却时间，在此期间会发生 **四次伤害跳** 在此时间范围内发生。
- 利用 **泛戴密克** 机制，你可以在[[spell:356995]]之后开始一次新的施法 **第三次伤害跳** 发生了一件事，它会将 **剩余持续时间** 和 **第4次伤害跳数** 从 **上一次施法** 转移到 **下一次** 施法上。
- 这就是你对 [[spell:356995]] 进行法术队列操作的方法，可以最大限度地减少空档时间，并让你稍快地消耗掉能量（Essence），以防止 **能量溢出**.
- 正因如此，理想情况下你会拥有 **[[spell:356995]] 的跳数** ，以便在正确的时机 **重新施放** 在恰当的时机使用。

### 使用 营救

- [[spell:370665]] 是你作为 **唤魔师** 的重要工具之一，要发挥其最佳效果需要对战斗有清晰意识，尤其是在团本中，它常常能把你那些机动性较差的队友从困境中解救出来。
- **12.0 补丁** 带来了这项改动：
  
  - [[spell:370888]] 已被重新设计——[[spell:370665]] 使移动速度提高 100%，并允许在移动中施法，持续 3 秒。
  - 这意味着 [[spell:370665]] 不再附带防御冷却，但作为机动技能变得更加强力了！

### 使用 悬空

- 在战斗中正确管理和把握 [[spell:358267]] 的施放时机，以便在处理机制的同时打出更多次施放，是你在 DPS 上看到最大差异的地方，因为实际的循环优化对于 **湮灭 唤魔师**.
- 在 [[spell:358267]] 增益即将结束时开始施放诸如 [[spell:356995]] 之类的法术，即使增益在施法过程中耗尽，你仍可在移动中完成该次施法，请牢记这一点，以便从每次 [[spell:358267]] 的使用中获得更多收益！
- 在你的界面上好好追踪 [[spell:358267]] 的覆盖时间和充能层数，并熟练运用这个技能，因为它是 **唤魔师**.
- 有了 **12.0版本** [[spell:358267]] 现在可以在正常施法过程中使用（主要是 [[spell:361469]] 和 [[spell:356995]]，用于 **湮灭**）而不会打断施法。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 流派攻略（适用 内克扎莉）
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 切勿在 [[spell:1284103]] 期间站在首领与你方坦克之间！
- 提前站在 **不安分的阿曼尼** 的尸体上方，紧接在 [[spell:1294742]] 之前，以便更轻松地协调清理它们。

:::

:::tab 陵寝哨兵
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 陵寝哨兵配置
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 每当 [[spell:1284434]] 出现时要积极去踩掉，如果连续吸收多次伤害就使用一个防御技能。
- 分散站位，并在首领能量达到100时准备解谜 [[spell:1284590]]，这是本场战斗的关键机制，也是团灭的主要原因，所以务必高度专注！

:::

:::tab 迷失的探险者
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 迷失的探险者的配装
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 留意 [[spell:1296062]] 的施放，并检查它们被射向哪个方向。
- 你可以移除 **流血** 减益：这是承受 [[spell:1291934]] 后获得的效果，可用 [[talent:115602]] 移除。因此可以先承受多次，再为自己驱散，也可以留意层数较高的其他玩家。
- 务必注意，别过早触发 **弹力蘑菇** （由 [[spell:1292105]] 产生）；应等到 [[spell:1296235]] 即将到来时再触发，否则它们会在短时间后消失。

:::

:::tab 瓦什尼克
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 瓦什尼克的配装
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 提前为 [[spell:1281907]] 分散站位以减少混乱，并尽量不要朝近战区域射击。
- 当 **燃烧毒液** 爆炸时使用一个防御冷却技能。
- 积极为受到 [[spell:1295224]] 影响的玩家吸收伤害。

:::

:::tab 斯索拉克
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 配装，适用于 斯索拉克
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 请记住，你可以用 [[spell:358733]] 轻松取消 [[spell:1285419]] 和 [[spell:1287008]] 的击退效果。
- [[talent:115666]] 在 [[spell:1285732]] 期间使用效果极佳，可帮助你的团队优化输出。
- 每当 [[spell:1305959]] 发生时一定要集中注意力，如果你被点名，准确知道该去哪里至关重要。
- 你可以用 [[spell:365585]] 或 [[talent:115602]] 驱散任何被 [[spell:1287072]] 命中的人。

:::

:::tab 双牙
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 双牙的配装
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 在整场战斗中，请密切留意你的 [[spell:1290336]] 层数变化。
- 可以考虑略微保留/积攒 [[spell:353759]] 和 [[spell:436336]]，等 [[spell:1291397]] 召唤的小怪出现时再使用。
- 如果你被 [[spell:1291478]] 点名，尽量不要过多移动；如果实在必须移动，请沿着直线的方向移动。
- 时刻注意 [[spell:1290956]] 释放的波次，它们随时可能出现，尤其是在 [[spell:1290516]] 的击退过程中，很容易让你措手不及。
- 当 **维克苏尔** 潜入地下并在场地中央现身施放 [[spell:1294293]] 时，观察它周围的小绿球来判断旋转方向，从而决定你应该向左还是向右躲避（你应该“逆着”旋转方向躲避）。

:::

:::tab 盘绕祭坛
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 盘绕祭坛配装
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 需要时协助移动和集合 [[spell:1282403]]。
- 每次 [[spell:1285643]] 后检查你是否被任何生成的幽灵盯上，如果被盯上，一定要专注于将其引导到预定的坦克顺劈位置以摆脱它。
- 打断 [[spell:1286399]]，来自 **怨毒缠魂者**.
- 如果被 [[spell:1286895]] 点名，使用 [[talent:115613]]，并记得之后拾取你的灵魂！

:::

:::tab 乌拉特克
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 的 乌拉特克 配装
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 击败愤怒的上古巨蛇。

:::

:::tab 尼姆瑞莎·唤波者
:::talents [[talent:123331]] **湮灭 唤魔师** 团队副本 的 尼姆瑞莎·唤波者 配装
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

### 首领攻略技巧

- 在[[spell:1281393]]被清除时，在可用时轮换使用[[spell:363916]]和[[spell:374227]]。

:::

:::

## 属性优先级

了解你作为**湮灭 唤魔师**在团队副本首领战斗中的次要属性优先级以及发挥最佳表现所需的第三属性。如需更详细的信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **团队副本中的湮灭 唤魔师**属性优先级
```json
{
  "source_code": "JoAJFUAIxQCKBMgABA"
}
```
**智力 ＞ 暴击 ≥ 精通 ＝ 急速 ＞ 全能**
:::

:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避 -** 极好的属性，可减少“范围效果（AoE）”技能受到的伤害。
- **吸血 -** 通过造成伤害提供额外治疗。
- **加速 -**  较为冷门的第三属性，但可能非常有用，过去已被证明其实用性。能大幅降低应对特定机制的难度。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271501@DiQAAsbBnk7cVrjgC4UA]] | 套装 / 催化 |
| 颈部 | [[item:268265@BERAAsbBE06QQrDj1IoAYFA]] | 乌拉特克 |
| 肩部 | 催化 [[item:268231@AgQAAIoAYFA]]  <br>转化为 [[item:271499@DgQAAsbBXk7IoAYF]] | 盘绕祭坛 / 催化 |
| 披风 | [[item:268253@BgQAAsbBCKAWBA]] | 盘绕祭坛 |
| 胸部 | [[item:271876@DARAAsbBJk7IoAMWDWB]] | 乌拉特克 |
| 护腕 | [[item:244584@FiQAAsbBYA8ciqDBtO3WzSB]] | 制造业 |
| 手套 | [[item:271502@BgQAAsbBCKgTBA]] | 套装 / 催化 |
| 腰带 | [[item:268254@BiQAAsbBE06IoAOF]] | 瓦什尼克 |
| 腿部 | 催化 [[item:268237@AgQAAIoAYFA]]  <br>转化为 [[item:271500@DgQAAsbBFo6IoAYF]] | 盘绕祭坛 / 催化 |
| 靴子 | [[item:268233@DgQAAsbBpk7IoAOF]] | 斯索拉克 |
| 戒指 1 | [[item:268249@DCQAAsbB1j7QQrjTBA]] | 瓦什尼克 |
| 戒指 2 | [[item:158366@DiQAAsbB1j7QQrjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:270164@BgQAAsbBCKgTBA]] | 迷失的探险者 |
| 饰品 2 | [[item:273796@BgQAAsbBCKgTBA]] | 毒牙祭坛 |
| 武器 | [[item:271092@DgQAAsbB_k7IoAYF]] | 乌拉特克 |
| 副手 | [[item:245769@FgQAAsbB4V2QqK0t1sUA]] | 制造业 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:239035@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 项链 | [[item:251234@BgQAAsbBCKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:239049@BgQAAsbBCKQQBA]] | 诸王之眠 |
| 披风 | [[item:251132@BgQAAsbBCKQQBA]] | 密谋小径 |
| 胸部 | [[item:251233@BgQAAsbBCKQQBA]] | 虚空之痕竞技场 |
| 护腕 | [[item:159380@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 手套 | [[item:193752@BgQAAsbBCKQQBA]] | 红玉新生法池 |
| 腰带 | [[item:251155@BgQAAsbBCKQQBA]] | 纳洛拉克的洞穴 |
| 腿部 | [[item:159375@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:159388@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251136@BgQAAsbBCKQQBA]] | 密谋小径 |
| 戒指 2 | [[item:158366@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:250224@BgQAAsbBCKQQBA]] | 虚空之痕竞技场 |
| 饰品 2 | [[item:273796@BgQAAsbBCKQQBA]] | 毒牙祭坛 |
| 武器 | [[item:193761@BgQAAsbBCKQQBA]] | 红玉新生法池 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@AgQAAIoAOFA]] |
| **A级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **B级** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **C级** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **垃圾级** | [[item:158368@AgQAAIoAOFA]] |

### 美化饰品

- 拿到你的前 4 个 [[item:274476]] 后，建议制作 [[item:245770@CARAAgBwDAAcbNLF]]，这是非常高效利用你的史诗纹章的方式！

- 1个 [[item:240167]]
  
  - 最适合制造的部位是 **护腕**、**披风、靴子** 或 **腰带**，取决于你现有的装备情况。

- 1个 [[item:273060]]
  
  - 如果你使用制造的武器或副手物品，这是一个极佳的装饰强化。

#### 剩余的火花

- 制造业制造的物品为331装等，而普通物品的最高装等为334，因此除非你在该部位没有其他高装等装备可用，否则装备两件美化之外的制造业物品并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药剂**
  
  - [[item:241326]] *——最高DPS。*
  
  
  
  - [[item:241320]] *——DPS略低，但生存能力更强。*
- **食物**
  
  - [[item:255845]]
  - [[item:255846]]
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]] *——一次大量的治疗爆发——12.1版本的升级版*
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **插槽**
  
  - [[item:240983]] *- 你的装备上只能镶嵌一颗永歌钻石。*
  
  
  
  - [[item:240900]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707]]  <br>[[item:244007]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAsbB]] |
| 胸部 | [[item:243977@BAAAAsbB]] |
| 护腕 | [[item:275707]] |
| 腰部 | [[item:275707]] |
| 腿部 | [[item:240133@BAAAAsbB]] |
| 脚部 | [[item:244009@BAAAAsbB]] |
| 戒指 1 | [[item:243957@BAAAAsbB]] |
| 戒指 2 | [[item:243957@BAAAAsbB]] |
| 武器 | [[item:244031]] |

:::

:::column
:::gear **湮灭 唤魔师** 团本中的附魔
```json
{
  "source_code": "JQFZ7WQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYgS94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买[[item:275707]]，为你的**头盔**、**护腕**和**腰带**添加插槽。

## 宏

了解 湮灭 唤魔师在 团队副本 战斗中推荐的宏，并观看一段关于如何为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:357210]]** —— *让你只需按一个键即可施放[[spell:357210]]，以鼠标指针为目标，而无需先用地面指示器瞄准再激活。* ***由于[[talent:117538]]的存在，玩鳞长时你将不再需要这个宏！***

```wow-macro
#showtooltip 
/cast [@cursor] 深呼吸
```

:::

:::details 鼠标指向宏
**[[spell:365585]]** —— *对你的鼠标悬停目标或当前目标施放[[spell:365585]]。*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] 净除
```

**[[spell:374251]]** —— *对你的鼠标悬停目标施放[[spell:374251]]。*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] 灼烧之焰(红龙)
```

**[[spell:406732]]** / **[[spell:374968]]** *--* *对你的鼠标悬停目标施放[[spell:406732]]或[[spell:374968]]* *具体取决于你的天赋选择。*

```wow-macro
#showtooltip [known:空间悖论] 空间悖论; 时间螺旋
/cast [@mouseover, help, nodead, known:空间悖论] 空间悖论
/cast [known:时间螺旋] 时间螺旋
```

**[[spell:360995]]** -- *对鼠标悬停目标施放 [[spell:360995]]。*

```wow-macro
#showtooltip 
/cast [@mouseover,help,nodead][] 青翠之拥
```

:::

:::details 营救 宏
> 这些宏能让 [[spell:370665]] 更容易使用。

**对玩家施放** [[spell:370665]] 宏 -- *这个宏能让 [[spell:370665]] 将你的友方目标移动到你的位置，你需要按下宏按钮，然后在单位框体上点击所选目标。*

```wow-macro
#showtooltip
/cast [@player] 营救
```

**对光标位置施放 [[spell:370665]] 宏** -- *这个宏能让 [[spell:370665]] 将你和你友方目标一起移动到光标所在位置，你需要先选定目标，用光标瞄准，然后按下宏按钮。*

```wow-macro
#showtooltip
/cast [@cursor] 营救
```

:::

:::details 实用 宏
**[[spell:358734]]** -- *激活或取消 唤魔师 二段跳 / 缓落 能力 [[spell:358734]]*，*我建议将其绑定到鼠标滚轮向下，方便取消击退位移并灵活运用机动性。*

```wow-macro
#showtooltip 滑翔
/cancelaura 滑翔
/use 滑翔
/script UIErrorsFrame:Clear()
```

**[[spell:360995]]**、**[[spell:361469]]**和**[[spell:355913]]**自愈宏 -- *也可以使用自施法按键修饰符，但我建议为这些技能单独设置快捷键，这样无需选中自己就能轻松自我治疗。*

```wow-macro
#showtooltip 
/cast [@player] 青翠之拥
```

```wow-macro
#showtooltip 
/cast [@player] 活化烈焰
```

```wow-macro
#showtooltip 
/cast [@player] 翡翠之花
```

:::

:::

## 插件

下面你可以看到作者的 **湮灭 唤魔师** 的用户界面截图，其中说明了使用了哪些插件，以及如何在团队副本中利用它们来让你的操作更加轻松。

![Devastation Evoker Interface in Raids](<https://assets-ng.maxroll.gg/wordpress/DevastationRaidMidnightUI-1-1024x616.webp>)

**湮灭 唤魔师** 团队副本界面

:::accordion
:::details 插件
- **BetterCooldownManager / BCDM** *--* 冷却管理器自定义插件
  
  - 为冷却管理器提供额外的自定义选项。
- **Unhalted Unit Frames / UUF** *-- 单位框体插件* 
  
  - 为玩家、目标和首领框体提供自定义选项。
  - 另外，你也可以使用 ElvUI
- Plater -- 高级姓名板插件
  
  - Plater 是一款拥有海量设置选项的姓名板插件，开箱即用，支持减益效果监控和仇恨着色。
- **Details** -- 深度伤害统计插件
  
  - 最强大、最可靠、最漂亮的伤害统计插件。
- **BigWigs** *-- 通用首领模块插件* 
  
  - BigWigs 是一款首领战斗插件。它由许多独立的*战斗脚本*（或称*首领模块*）组成；这些小型插件旨在为某个特定的 团队副本 战斗触发警报信息、计时条、音效等内容。
- **Bartender4** -- 动作条插件
  
  - 替代默认动作条，提供更多自定义选项和额外功能。
- **RaidFrameSettings / RFS** -- 暴风雪 团队副本 框体自定义插件
  
  - 为默认的 暴风雪 团队框体提供额外的自定义选项。
- **NorskenUI** *-- 集换肤、便利功能与特性于一身*
  
  - 众多"整合型"插件之一，包含多项便利性改进、界面换肤以及其他实用功能。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**唤魔师**

- 万应灵药 治疗效果提高25%

**英雄天赋**

- **[[talent:123333]]**
  
  - *开发者注：群龙之首的冷却缩减机制强烈鼓励将轰炸效果分散到多个目标上。我们认为这种玩法单独来看不够直观，而且还会导致一些不健康的行为，例如裂解打断（clip）以及囤积群体裂解/爆发的资源。此次重做旨在保留该天赋的多目标侧重，同时解决上述问题。我们正在提高鳞长的部分范围伤害来源，以补偿新版群龙之首所提供的冷却缩减降低带来的损失。*
  
  
  
  - 群龙之首已重做——群体裂解/大规模喷发每击中一个目标，使深呼吸/亘古吐息的剩余冷却时间缩短0.5秒/1秒。
  - 特遣动员的葬火伤害提高40%。
  - 战术机动的持续伤害提高40%。

**湮灭**

- *开发者注：湮灭的顶尖天赋虽然强大，但并未如我们期望的那样对玩法产生足够影响。我们重新设计了第3阶效果，使狂龙之怒结束后替换为有限次数使用的新强力法术释缚烈焰。此外，冲天怒火与复生的狂怒已被简化为同一个增益效果。*
- 顶尖天赋：冲天怒火（第3阶）已重做——当狂龙之怒结束时，冲天怒火每层可持续4秒，且狂龙之怒变为释缚烈焰。在狂龙之怒冷却完毕之前，释缚烈焰可施放4次。
  
  - 释缚烈焰——喷吐毁灭之焰，对你的目标及附近敌人造成必定爆击的火焰伤害。超过5个目标后伤害降低。产生1层精华迸发。瞬发，25码射程。
- 残暴已更新——现在与释缚烈焰互动，使释缚烈焰无论目标生命值如何，必定获得精通：巨兽杀手的最大收益。
- 深呼吸伤害提高30%。
- 葬火伤害提高10%。
- 裂解伤害提高40%。
- 活化烈焰伤害提高50%，治疗效果提高25%。
- 青翠之拥治疗效果提高25%。
- 翡翠之花治疗效果提高25%。
- 因能量闪烁而从永恒之涌中释放的碎裂星辰，现在受能量闪烁的40%效果倍率影响。
- 复生的狂怒已被移除。
- **英雄天赋**
  
  - **[[talent:123336]]**
    
    - 孪生烈焰伤害和治疗效果降低20%。
    - 修复了孪生烈焰未受精通加成的问题。
  
  
  
  - **[[talent:123333]]**
    
    - 群龙之首现在每击中一个目标，使深呼吸的冷却时间缩短1秒（原为0.5秒）。

:::

:::

:::accordion
:::details 12.0.5 补丁
**唤魔师**

- 新技能：战斗幻象——激活后，当你没有施放龙类法术（如火焰吐息和振翅高飞）时会自动变回幻象形态。
  
  - 会临时变回龙希尔形态的技能完整列表：深呼吸、梦境飞行、亘古吐息、火焰吐息、永恒之涌、梦境吐息、地动崛起、悬空、空间悖论、营救、微风、青翠之拥（未点出梦境幻象天赋时）以及振翅高飞。
  - 许多过去会强制变回龙希尔形态的技能，现已调整为在幻象形态下拥有专属视觉效果。
  - 战斗幻象激活期间，还会对龙希尔形态应用摄像机高度覆盖，防止在两种形态之间切换时摄像机快速调整。
- 拆解伤害提高300%。
- 青铜祝福现在可以施放在不在你小队或团队中的友方玩家身上，与其他团队增益（如奥术智力）类似。
- 修复了双生护卫在营救开始时而非落地时施加其加成的问题。

:::

:::

:::accordion
:::details 补丁12.0.1
**唤魔师**

- [[spell:357208]]的总伤害（即时伤害和周期性伤害）现在在所有强化等级下，以及所有影响火焰吐息的天赋组合下都应保持一致。
- [[talent:115663]]治疗效果提高60%。
- **湮灭**
  
  - [[spell:356995]]伤害提高32%。
  
  
  
  - [[talent:115655]]治疗效果提高50%。
  - [[spell:355913]]治疗效果提高50%。

- **英雄天赋**
  
  - **[[talent:123336]]**
    
    - [[talent:117519@AJQD]]现在以115%的效果造成[[spell:357208]]伤害（原为150%）。
    - [[talent:117519@AJQD]]现在使葬火消耗[[spell:357208]]的4秒（原为10秒），并从[[spell:356995]]伤害中消耗[[spell:357208]]的1秒（原为2秒）。
  
  
  
  - **[[talent:123333]]**
    
    - ***开发者说明：我们正在减少通过[[talent:117550@AJQD]]获得的[[spell:357210]]的使用次数，针对 [[talent:123333]] 以减少滞空时间，因为这段时间内操作可能较为困难。我们通过对其他 [[talent:123333]] 天赋的加强来弥补伤害损失。***
    - **[[talent:117550@AJQD]]现在使[[talent:117533@AJQD]]减少[[spell:357210]]0.5秒的冷却时间（原为1秒），最多1.5秒（原为3秒）。**
    - **[[talent:117549]]现在使黑曜法术伤害提高30%（原为20%）。**
    - **[[talent:136051]]现在使精华技能伤害提高25%（原为15%）。**

:::

:::

:::accordion
:::details 补丁12.0
**唤魔师**

- **[[talent:123333]]**
  
  - 新天赋：[[talent:136053]] – 在[[talent:115536@FAQARegB]]或[[spell:357210]]期间飞行时，一队龙希尔会协助你，用葬火攻击敌人，对附近敌人造成火焰伤害，最多8次。
  - 新天赋：[[talent:136052@AJQD]] – [[talent:117536]]或[[talent:122279]]额外打击1个目标。
  - 新天赋：[[talent:136051]] – 精华法术造成的伤害提高15%。
  - [[talent:120123]]现在改为赋予一层[[spell:358267]]，而不是恢复全部充能。
  - **湮灭**
    
    - [[talent:117518@AJQD]]和[[talent:117538@AJQD]]的伤害效果现在会在效果生效期间多次施放[[spell:357210]]时延长持续时间。
    - [[spell:356995]]的图标现在会在[[talent:117536]]激活时改变。
- **[[talent:123336]]**
  
  - 新天赋：[[talent:123416]] – [[spell:357208]]的冷却时间缩短5秒。
  - 新天赋：[[talent:117542@AJQD]] – [[spell:357208]]的持续伤害持续时间延长4秒。
  - 新天赋：[[talent:136055@AJQDBA]] – [[spell:355936]]和[[spell:357208]]有50%的几率产生[[spell:359565]]。
  - 新天赋：[[talent:136056@AJQD]] – 消耗[[spell:359565]]时会发射一枚孪生烈焰，对目标造成390%法术强度的治疗或伤害。
  - 新天赋：[[talent:136054]] – [[talent:136056@AJQD]]最多可弹射至2个额外目标。
  - [[talent:117543@AJQD]]已被重新设计 – [[spell:357208]]达到最大蓄力等级的速度加快20%。
  - 以下天赋已被移除：
    
    - [[spell:443328]]
    - [[spell:444140]]
    - [[spell:444081]]
  - 湮灭
    
    - 新天赋：[[talent:117547@AJQD]] – [[spell:357208]]获得一层额外充能。
    - [[talent:117519@AJQD]]已被重新设计 – [[spell:356995]]的伤害会消耗受其伤害的敌人身上2秒的[[spell:357208]]，并引爆消耗的量，造成150%的伤害。[[spell:357211]]会消耗受其伤害的敌人身上10秒的[[spell:357208]]，并引爆消耗的量，造成150%的伤害。
- 职业
  
  - 新天赋：[[talent:115617]] – 在[[talent:115536@FAQARegB]]或[[spell:357210]]期间飞行时，你将要承受伤害的100%改为在10秒内持续承受。
  - 新天赋：[[talent:136560]] – [[spell:358733]]的速度和高度提高10%。
  - 新天赋：[[talent:115620]] – 你的[[spell:361469]]和[[spell:367979]]对自身的效果提高30%。
  - [[talent:115595]]已被重新设计 – [[talent:115596]]使移动速度提高100%，并允许在3秒内移动施法。
  - [[talent:115669]]已被重新设计 – 现在升级[[talent:115613]]，使其在8秒内治疗你，治疗量等于其减免的伤害量。
  - [[talent:115616]]已被重新设计为被动效果 – [[spell:357208]]会吞噬敌人的吸收护盾，对其造成额外的法霜伤害。
  - [[spell:362969]]伤害提高50%。
  - [[talent:115657]]现在会在激活时改变[[spell:361469]]的图标。
  - 修复了[[spell:357208]]在玩家死亡并在其激活期间复活后可能会引来敌人的问题。
  - 若干天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - [[spell:375577]]
    - [[talent:115645]] *（移至增辉和湮灭天赋树）*
- 湮灭
  
  - 新天赋：[[talent:115626]] – 使[[spell:1265804]]伤害提高35%。[[spell:1265804]]会喷向你的所有[[talent:115581]]目标。
  - 新天赋：[[talent:115579]] – [[talent:115581]]将你的下一个[[spell:362969]]升级为[[talent:115579]]，对附近所有敌人造成伤害并额外造成75%的伤害。
  - 新天赋：[[talent:115623]] – [[spell:357210]]造成的伤害提高20%，并且在使用后的18秒内可以再次施放。如果选择了相应天赋，第二次施放后[[talent:115610]]将可用。在PvP中，[[spell:357210]]的伤害改为降低20%。
  - [[spell:370452]]已被重新设计为名为[[talent:115627]]的被动效果 – [[talent:115581]]向你的目标释放一枚[[spell:1265804]]，每达到一个蓄力等级伤害提高50%。
  - [[talent:115641]]已被重新设计 – 使你的法术爆击几率提高2%/4%。
  - [[talent:115585]]已被重新设计 – 现在使[[spell:361469]]的伤害提高10%，施法时间缩短0.3秒。
  - [[talent:115638]]已被重新设计 – 深呼吸使你的下4次[[spell:356995]]或[[spell:357211]]的精华消耗减少1点。最多叠加8次。
  - [[talent:115622]]已被重新设计 – 受[[spell:357208]]持续伤害效果影响的敌人，受到你红法术的伤害提高25%。
  - [[talent:115647]]伤害提高20%。
  - [[talent:115628]]现在每层使[[spell:357211]]的伤害提高2%（原为5%）。
  - [[talent:115584]]现在改为在施放6次[[spell:357211]]后激活（原为9次）。
  - [[spell:369372]]不再提高[[spell:356995]]和[[spell:357211]]的伤害。
  - [[spell:369372]]伤害提高25%。
  - [[talent:115580]]现在还会提高[[spell:362969]]的伤害。
  - [[talent:115632]]现在只影响[[talent:115581]]。
  - [[talent:115642]]的效果现在在[[spell:375087]]期间每施放一个蓄力法术衰减25%。
  - [[talent:115645]]现在改为在湮灭专精天赋树中学习（原为职业天赋）。
  - [[talent:136056@AJQD]]现在被视为红法术。
  - 若干天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - [[spell:386342]]
    - [[spell:370962]]
    - [[spell:368847]]
    - [[spell:386336]]
    - [[spell:371016]]
    - [[spell:386405]] *（移至职业天赋树）*
    - [[spell:370783]]

:::

:::

---

## 常见问题

:::accordion
:::details Q: 为什么你们把湮灭的生存能力评为 4/5，我却觉得自己这么脆？
**A:** 你拥有大量防御手段，但其中大多数都是主动性的，因此你必须预判即将受到的伤害，并使用你众多可用的选项之一来减伤！

:::

:::

---

### 致谢

作者：**fraggo**

审校：**Ftm**

---

:::changelog 更新记录
**2026-08-06** 更新至 12.1

**2026-06-16** 更新至 12.0.7 版本

**2026-04-21** 更新至 12.0.5 版本

**2026-02-22** 更新以适配《至暗之夜》上线。

**2026-02-10** 更新至 12.0.1 版本

**2026-01-15** 更新至 12.0 版本

**2025-12-02** 更新至 11.2.7 版本

**2025-10-07** 更新至 11.2.5 版本

**2025-08-04** 更新至 11.2 版本

**2025-06-17** 更新至 11.1.7 版本

**2025-04-21** 更新至 11.1.5 版本

**2025-02-25** 更新至 11.1 版本

**2024-12-17** 更新至 11.0.7 版本

**2024-10-23** 更新至 11.0.5 版本

**2024-08-17** 更新至 11.0.2 版本

**2024-07-24** 攻略撰写于 11.0.1 前夕版本



:::
