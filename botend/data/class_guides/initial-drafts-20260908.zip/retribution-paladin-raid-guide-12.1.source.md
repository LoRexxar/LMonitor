Welcome to the **Retribution Paladin** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Strong

AoE · 4/5 · Average

Utility · 2/5 · Average

Survivability · 5/5 · Excellent

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Retribution Paladin** Raid Best in Slot
```json
{
  "source_code": "JUfAwHrRAc__AEQakQggAEAAvj7AH16AOFQApfBBAkCAAQQrDQRrDkjAkVDG24VNWYTAnRCBCgQAAUTuDIcAOFQAsRCBCgQAAkQuDkjAOFQAmRCBAiQAAoQrDkjAOFQAGYCBQARAAg0-SkjAWYjTBEABhOABIAAA5V2AkqCB3WTAKE6AEiQAAkXZDQqKEQQrDcbNLFQAqRCBAgQAAkjAOFQAcfBBCiQAAUPuDQQrDkjAOFQAZfBB6IBA481HEAAGAAAG24VN5IQAdJjDAwV3XQAAAEAAYFQA1eBBCgQAA0TuDkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240967]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240916]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:271462]] | [[item:240906]] |
| 腿部 | [[item:271878]] | [[spell:1243976]] |
| 脚部 | [[item:237828]] | [[item:222585]] · [[item:273060]] |
| 腕部 | [[item:237834]] | [[item:240900]] · [[item:222585]] · [[item:273060]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268252]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:244029]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Retribution Paladin**, you have access to Light Within, which enchanes most of your powerful spells such as [[spell:184575]], [[spell:383328]] and [[spell:53385]].

**Rank 2** Increases the damage of [[spell:383328]] and [[spell:53385]] by a total of 20% during [[talent:102519@FJQA41dBCIA]]. While **Rank 3** further increases your [[spell:184575]] to now deal Holy damage in a frontal cone while you have a [[spell:231843]] proc.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-retribution.webp>)

Light Within

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115435]]
    
    - Now has [[spell:343721]] built into it. On top of that, it's been reworked a bit, now applying to all targets hit instead of just 1.
  - [[talent:102511]]
    
    - Refunds the Holy power spent on your first use of a holy power spender after you press [[talent:102519@FJQA41dBCIA]].
- **Class Tree**
  
  - [[talent:136127]]
    
    - Now your [[spell:498]] also grants  [[spell:1261562]].
  - [[talent:128259]]
    
    - 10% reduced damage taken.
- **Removed**
  
  - [[spell:343721]]
  - [[talent:136005]]
    
    - Is now moved into templar hero talent.

## Hero Talents

[[talent:123357]] is focused on Single target with stacked cleave from [[talent:117823]], while [[talent:123360]] is focused on buffing your [[talent:102499]] and dealing damage via dots from [[talent:117696]].

:::tabs
:::tab [[talent:123357]]
- Casting [[talent:102497]] Grants you [[spell:427453]] - a 5 Holy Power spender that replaces [[talent:102497]] until it’s used.
- Over time, you gain stacks of [[talent:117815]]. At 60 Stacks, you gain a free[[spell:427453]] that you must cast before [[talent:102497]] since they have the same key bind.

#### Shake the Heavens Interactions

- After casting [[spell:427453]], you gain [[talent:117823]], which casts an [[spell:431625]] on your target every 2 seconds for 8 seconds, which can be extended by [[talent:117811]]
- [[talent:117823]] also grants you 12% haste for 6 seconds.

#### Empyrean Hammer Interactions

- Casting any Holy Power spender triggers an [[spell:431625]] which activates [[talent:117810]] if it crits. [[talent:117823]] triggers an additional [[spell:431625]].
  
  - After casting [[spell:427453]], you instantly trigger 2 [[spell:431625]] on your main target.
- [[talent:117819]]
  
  - Trying to maintain high stacks is very important, casting [[talent:102465]] grants you 1 stack per enemy hit.

#### Defensive Traits

- [[talent:117812]]
  
  - [[talent:102497]] grants you an absorb shield while [[spell:427453]] heals you upon use.

:::

:::tab [[talent:123360]]
#### Dawnlight Interactions

- [[talent:102497]] causes your 2 next Holy Power spenders to apply [[talent:117696@AJgACA]] to your target. This debuff radiates damage around the target for 8 seconds. Additionally, when you activate [[talent:102593]] or [[talent:125129]] ,you also apply [[talent:117696@AJgACA]] on 4 nearby targets and start [[talent:117702]].
- As long as there is any [[talent:117696@AJgACA]] DoT active, your Holy Power spenders gain 5% additional damage. On top of this, every time you apply any [[talent:117696@AJgACA]], you gain 2% Haste for 12 seconds, which can overlap.
- [[talent:102497]] grants you [[spell:408458]].

#### Divine Storm and Hammer of Wrath gain some new passives

- [[talent:117677@AJgACA]]
  
  - They both gain 10% increased damage.
- [[talent:117669@AJgACA]]
  
  - When they critical strike any target, they burn the target for some radiant damage for 4 seconds.
- [[talent:117668@AJgACA]]

#### Defensive Traits

- [[talent:117692]]
  
  - Replaces [[spell:85673]] and also heals a small amount over 16 seconds, and its healing is increased by 25% when used on yourself.
- [[talent:117695@AJgACA]]
  
  - When you have [[talent:117696]] on a target, it is now slowed by 50%.

:::

:::

## Talents

:::tabs
:::tab Single Target   [[talent:123357]]
:::talents **Retribution Paladin** Single Target Build in Raid With [[talent:123357]]
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### When to use this Spec

Use this spec for single-target raid encounters, as it is your standard build for single-target damage. It leverages the combo of  [[talent:115435]] for single-target burst damage. For a detailed guide on playstyles and priority lists, check the deep dive section below to learn how to fully optimize this build!

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section provides a concise overview of these talents and their applications. For a more detailed look, check out the Rotation and Deep Dive sections below.

#### Spec Tree

- [[talent:115435]]
  
  - A strong single-target burst cooldown.
  
  
  
  - Every time [[talent:102497]] is ready, make sure to combo this.
- [[talent:102504@FAQAQjiB]]
  
  - Your main single-target Holy Power spender.
- [[talent:115021]]
  
  - Tiggers your mastery more often.
- [[talent:102493]]
  
  - Your auto attacks have a 15% chance to reset [[talent:102498]].
- [[talent:115438]]
  
  - If a target has [[talent:114830]], you deal 5% increased holy damage to it.

#### Class Tree

- [[talent:135564@FJQADdhACIA]]
  
  - Casts [[spell:20271]] on your target.
  - Mainly used for its Holy Power gain.
- [[talent:102625]]
  
  - Move at 100% movement speed for 3 seconds.
  
  
  
  - [[talent:102592]] Grants you 2 charges instead of 1.
- [[talent:102583]]
  
  - A strong single-target heal that can be used to save friendly targets.
- [[talent:102604@AJgACA]]
  
  - Great way to avoid aggro or prevent Physical damage.
- [[talent:102602]]
  
  - Perfect to use on tanks or players dealing with certain spells during boss fights.
- [[talent:136594]]
  
  - A kick to interrupt any spell.
- [[talent:128251]]
  
  - You become immune to slow effects for 8 sec.
  - [[talent:115454]]
  
  
  
  - When you cast [[talent:128251]] on another player, you also gain it, and both of you also gain 30% movement speed
- [[talent:128257]]
  
  - 10% of any healing you get is put on your melee camp as well.
- [[talent:128259]]
  
  - Reduce damage taken by 10%

#### Hero Talents

For more info, visit the **Hero Talent** section above.

- [[talent:136005]]
- [[talent:136004]]
- [[talent:136184@FAQAgldB]]

:::

:::tab Aoe   [[talent:123357]]
:::talents **Retribution Paladin** Aoe Build in Raid With [[talent:123357]]
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxYMGmxGbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxMzGWmZmZMjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxYMGmxGbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxMzGWmZmZMjhBDA"
}
```
:::

### When to use this Spec

This build is utilized when the fight needs more AOE or cleave.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

Added:

- [[talent:102521@FAQAyliB]]
- [[talent:102515]]
- [[talent:115452]]

Removed:

- [[talent:115440@FAwAbHNBvj4AQjiB]]
- [[talent:115483]] 2x

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:223817]] has an additional 10% chance to activate and consuming it grants [[spell:1305230]], increasing Holy damage done by 10% for 12 seconds.
- **4-Set:** Consuming [[spell:223817]] grants [[spell:1306161]], empowering your other Holy Power spenders to unleash an arbiter of light at their primary target, dealing Holy damage and Holy damage to enemies withing 8 yards. Cannot occur while [[spell:1306161]] is active.

### Single-Target

:::tabs
:::tab [[talent:102525]]
To read more about [[talent:102525]] head down to the Deep Dive section!

### Opener

Your main goal in your opener should be to get to 3 Holy Power by using [[spell:184575]] followed up by [[spell:315867]].

The [[talent:136809@FAQAQjiB]] trait has an RNG factor that affects when you gain Holy Power. Specifically, Holy Power is gained on the 2nd auto attack, but this can vary due to the RNG factor. During your opener, be aware of this variability. Suppose you don't gain Holy Power as expected. In that case, you may need to use a generator ability to fill in the gaps or skip 1 generator as [[talent:136809@FAQAQjiB]] as already gained you the Holy Power that's needed to cast [[spell:85256]] in your [[talent:115435]] window.

#### Retribution Paladin Standard Opener

:::rotation **Retribution Paladin** Standard Opener
```json
{
  "source_code": "IUEMJI0_QLAAAAAACdePFUACIE85DUACI0bhGUACIgQTBUACIs0pEUACE8yTBcAMAIECNFAAAAAAC9P0CA"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
5. [[spell:85256]]
6. [[spell:304971]]
7. [[spell:20271]]
8. [[spell:85256]]
9. [[spell:184575]]
:::

#### Quick Divine Toll Opener.

:::rotation **Retribution Paladin** Fast Opener
```json
{
  "source_code": "I0DMII0_QLAAAAAACt0pEUACIcePFUACIE85DUACI0bhGUACIgQTBUACo8P0CAAAAAgQI0UA"
}
```
1. [[spell:184575]]
2. [[spell:304971]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:85256]]
7. [[spell:184575]]
8. [[spell:85256]]
:::

#### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:85256]] (When close to 5 Holy Power, to not mess up your burst windows with overcapped Holy Power).
2. Cast [[talent:115435]] on cooldown.
3. Cast [[talent:102497]] on cooldown to proc [[talent:102525]] (with 2 Holy Power). If talent is chosen!!
4. Cast [[spell:427453]] to proc [[talent:117823]].
5. Cast [[talent:102498]] (to keep up [[talent:114830]] and [[talent:115438]]).
6. Cast [[talent:102465]] on cooldown.
7. Cast [[spell:315867]] (if 3 Holy Power or below).
8. Cast [[talent:102498]] (if 3 Holy Power or below).

:::

:::tab [[spell:339044]]
To read more about [[spell:339044]], head down to the Deep Dive section!

Your main goal in your opener should be to get to 3 Holy Power by using [[spell:184575]] followed up by [[spell:315867]].

The [[talent:136809@FAQAQjiB]] trait has an RNG factor that affects when you gain Holy Power. Specifically, Holy Power is gained on the 2nd auto-attack, but this can vary due to RNG. During your opener, be aware of this variability. Suppose you don't gain Holy Power as expected. In that case, you may need to use a generator ability to fill in the gaps or skip 1 generator as [[talent:136809@FAQAQjiB]] as already gained you the Holy Power that's needed to cast [[spell:85256]] in your [[talent:115435]] window.

### Retribution Paladin Standard Opener

:::rotation **Retribution Paladin** Standard Opener
```json
{
  "source_code": "I0ELKI0_QLAAAAAACxIfBcAEAI059UQAJwgQBf-AFgAC9WoBFgACI0UAFgACLdKBFgABv8UAHADAChQTBAAAAAgQ_DtA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:85256]]
7. [[spell:304971]]
8. [[spell:20271]]
9. [[spell:85256]]
10. [[spell:184575]]
:::

#### Quick Divine Toll Opener.

:::group
:::rotation **Retribution Paladin** Fast Opener
```json
{
  "source_code": "IUELJI0_QLAAAAAACxIfBcAEAI0SnSQAJwgQn3TBFgACBf-AFgAC9WoBFgACI0UAFgAK_DtAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:343527]]
5. [[spell:255937]]
6. [[spell:427453]]
7. [[spell:85256]]
8. [[spell:184575]]
9. [[spell:85256]]
:::

:::

#### Delayed Divine Toll Opener

#### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:85256]] (When close to 5 Holy Power, to not mess up your burst windows with overcapped Holy Power).
2. Cast [[talent:115435]] on cooldown.
3. Cast [[talent:102497]] on cooldown to proc [[talent:102525]] (with 2 Holy Power). If talent is chosen!!
4. Cast [[spell:427453]] to proc [[talent:117823]].
5. Cast [[talent:102498]] (to keep up [[talent:114830]] and [[talent:115438]]).
6. Cast [[talent:102465]] on cooldown.
7. Cast [[spell:315867]] (if 3 Holy Power or below).
8. Cast [[talent:102498]] (if 3 Holy Power or below).

:::

:::

### AoE

:::tabs
:::tab [[talent:102525]]
To read more about [[talent:102525]] head down to the Deep Dive section!

### Opener

If you are going to overcap on Holy Power by using [[spell:304971]] early in the combo, you can delay it to after your [[spell:427453]] in some situations.

#### Retribution Paladin Standard Opener

:::rotation **Retribution Paladin Standard Opener**
```json
{
  "source_code": "IUEMJI0_QLAAAAAACdePFUACIE85DUACI0bhGUACEkI0BcAEAI0SnSQAJggQv8UAHADAClI0AAAAAAgQ_DtA"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
5. [[spell:53385]]
6. [[spell:304971]]
7. [[spell:20271]]
8. [[spell:53385]]
9. [[spell:184575]]
:::

#### Quick Divine Toll Opener.

:::rotation
```json
{
  "source_code": "IwDMII0_QLAAAAAACt0pEUACIcePFUACIE85DUACI0bhGUACEkI0BcALAI0_QLAAAAAAClI0"
}
```
1. [[spell:184575]]
2. [[spell:304971]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:53385]]
7. [[spell:184575]]
8. [[spell:53385]]
:::

#### Multitarget / AoE Priority List

1. Cast [[talent:102499]] if you’re close to 5 Holy Power.
2. Cast [[talent:102497]] on cooldown to proc [[talent:102525]] if you are at <=2 Holy Power.
3. Cast [[spell:427453]] to proc [[talent:117823]].
4. Cast [[talent:102498]] to keep up [[talent:114830]] and [[talent:115438]].
5. Cast [[talent:102465]] on cooldown.
6. Cast [[spell:315867]] if you are low on Holy Power or to keep up [[talent:117819]].
7. Cast [[talent:102499]] if you have 3 Holy Power.

:::

:::tab [[spell:339044]]
To read more about [[spell:339044]], head down to the Deep Dive section!

### Opener

If you are going to overcap on Holy Power by using [[spell:304971]] early in the combo, you can delay it to after your [[spell:427453]] in some situations.

#### Retribution Paladin Standard Opener

:::rotation **Retribution Paladin Standard Opener**
```json
{
  "source_code": "I0ELKI0_QLAAAAAACxIfBcAEAI059UQAJwgQBf-AFgAC9WoBFgABJCdAHABACt0pEEQCII0LPFwBwAgQJCNAAAAAAI0_QLA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:53385]]
7. [[spell:304971]]
8. [[spell:20271]]
9. [[spell:53385]]
10. [[spell:184575]]
:::

#### Quick Divine Toll Opener.

:::rotation
```json
{
  "source_code": "IQELJI0_QLAAAAAACxIfBcAEAI0SnSQAJwgQn3TBFgACBf-AFgAC9WoBFgABJCdAHwCAC9P0CAAAAAgQJCN"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:343527]]
5. [[spell:255937]]
6. [[spell:427453]]
7. [[spell:53385]]
8. [[spell:184575]]
9. [[spell:53385]]
:::

#### Multitarget / AoE Priority List

1. Cast [[talent:102499]] if you’re close to 5 Holy Power.
2. Cast [[talent:102497]] on cooldown to proc [[talent:102525]] if you are at <=2 Holy Power.
3. Cast [[spell:427453]] to proc [[talent:117823]].
4. Cast [[talent:102498]] to keep up [[talent:114830]] and [[talent:115438]].
5. Cast [[talent:102465]] on cooldown.
6. Cast [[spell:315867]] if you are low on Holy Power or to keep up [[talent:117819]].
7. Cast [[talent:102499]] if you have 3 Holy Power.

:::

:::

## Deep Dive

:::tabs
:::tab [[talent:102525]]
- When talented into [[talent:102525]], you cannot use [[talent:102593]] or [[talent:125129]] directly. Instead, using [[talent:102497]] triggers the cooldown you have chosen in your talents for a few seconds. Additionally, there is a small chance that any Holy Power spender can proc your chosen talent for an additional 5 seconds, this extends your [[talent:125129]] or [[talent:102593]] if it procs while the spell is active.
- Never sit on [[talent:102497]] since [[talent:102513]] has a 1-minute cooldown and [[talent:115435]] has a 30-second cooldown. Delaying Wake of Ashes also delays all of your other cooldowns.

#### Execution Sentence

- When you have chosen [[talent:115435]] as your minor cooldown, it is optimal to use [[talent:102497]] after [[talent:115435]]. This is because the gain from getting [[talent:102593]] does not affect [[talent:115435]], and you want the full uptime on wings during the [[talent:115435]] window. Try to have 3 Holy Power ready right before [[talent:115435]] goes off cooldown so you can use it instantly.

#### With Hero Talent Templar

:::rotation **Retribution Paladin** [[talent:115435]] sequence in Raid
```json
{
  "source_code": "H0BMEI0_QLAAAAAACdePFUACoE85DAAAAAgQ9WoB"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
:::

#### With Hero Talent Herald of the Sun

:::rotation **Retribution Paladin** [[talent:115435]] sequence in Raid
```json
{
  "source_code": "HUDLHI0_QLAAAAAAC9yTBcAEAI059UQAJwgQI0UAFgACBf-AFgAKI0UAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:20271]]
3. [[spell:343527]]
4. [[spell:85256]]
5. [[spell:255937]]
6. [[spell:85256]]
7. [[spell:85256]]
:::

:::

:::tab [[talent:102519@FJQA41dBCIA]]
- Choose this talent when boss fights or dungeons allow you to never miss a cooldown window.
- Never sit on [[talent:102519@FJQA41dBCIA]] for more than a few seconds, as most of your damage comes from combining it with other 1-minute cooldowns. As mentioned earlier, always use [[talent:102519@FJQA41dBCIA]] first unless you are using [[spell:343527]], in which case follow the specific strategy explained below.
- Delaying [[talent:102519@FJQA41dBCIA]] also delays your other minor cooldowns.
- When using trinkets, do not hold your [[talent:102519@FJQA41dBCIA]], as it does not significantly buff the overall damage of trinkets, but it does increase their crit chance.
- For trinkets with a 90-second cooldown, use them on cooldown unless you have a trinket that provides a massive mastery or strength buff. In that case, try to align it with [[talent:102519@FJQA41dBCIA]].

:::rotation **Retribution Paladin** [[talent:115435]] Prio List
```json
{
  "source_code": "HkBYEIkpHRAAAAAACwIfAAAACs0pEAAACE85DA"
}
```
1. [[spell:280486]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:255937]]
:::

:::

:::

### Minor Cooldown

To reach your full potential, you must also know how to maximize your minor cooldowns.

:::tabs
:::tab [[talent:115435]]
- Your plan during [[spell:343527]] is to fit as many spenders as possible within its duration. It's not strong outside of [[talent:102593]] or [[spell:384392]] due to its short burst window and lack of initial damage.
- Always cast [[spell:343527]] before [[talent:102593]].
- Use [[spell:343527]] on cooldown to ensure it aligns with other cooldowns.
- If you are playing [[talent:102525]], make sure to use [[spell:343527]] before [[spell:255937]].

#### With Hero Talent Templar

:::rotation **Retribution Paladin** Quick Prio list for [[spell:343527]]
```json
{
  "source_code": "H0BMEIEeGTAAAAAACdePFUACoE85DAAAAAgQ9WoB"
}
```
1. [[spell:312952]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
:::

#### With Hero Talent Herald of the Sun

:::rotation **Retribution Paladin** [[spell:343527]] without [[talent:102593]] and [[talent:102465]]
```json
{
  "source_code": "HUDLHI0_QLAAAAAAC9yTBcAEAI059UQAJwgQI0UAFgACBf-AFgAKI0UAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:20271]]
3. [[spell:343527]]
4. [[spell:85256]]
5. [[spell:255937]]
6. [[spell:85256]]
7. [[spell:85256]]
:::

:::

:::

### General Retribution Mechanics

If you don't respect the basics, you cannot master **Retribution Paladin**.

#### Crusading Strikes

- This replaces your auto-attacks and your normal [[spell:35395]] spell, becoming its own auto-attack that generates 1 Holy Power every 2nd attack.
- During your opener or any cooldowns during a fight, your Holy Power might vary. You could start with 4-5 Holy Power right before [[talent:115435]], which means you need to press [[spell:85256]] instantly before any other spell. This might change how your opener looks, so it's important to understand the priority list to know which buttons to press and when.

#### Mastery

- **Retribution Paladins** [[spell:267316]] has been reworked. It now makes [[spell:315867]] not only buff your spenders but also have a chance to proc extra holy damage to your main target. As mastery has been a weak point for a long time, this change is significantly beneficial.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Offensive Cooldown Usage

- It can be beneficial to have cooldowns ready for **Restless Amani** add spawns, but only hold cooldowns if you can see the BigWigs timer with adds about to spawn, it is not worth holding long.

### Defensive Cooldown Usage

- Use a defensive cooldown when **Nek'zali** casts [[spell:1288772]].

### Boss Tips

- Beware of where the tank is when **Nek'zali** casts [[spell:1292034]]. Do not be in between her and her target.

:::

:::tab Entombed Sentinels
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Offensive Cooldown Usage

- Keep an eye out for when the **Entombed Sentinels** reach 100 energy and cast [[spell:1284606]] , as you don't want to just have popped cooldowns when that happens and be unable to deal any damage.

### Defensive Cooldown Usage

- Use a defensive cooldown when soaking [[spell:1288282]].

### Boss Tips

- During [[spell:1284606]] you get marked with either 1, 2 or 3 Venom Blobs over your head. Combine 1 with 3, and 2 with 2 with the goal of reaching 4.

:::

:::tab Lost Explorers
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Defensive Cooldown Usage

- Use a defensive cooldown if soaking a [[spell:1300237]] with not many people in it to split the damage.

### Boss Tips

- You can [[spell:642]] to get over [[spell:1297650]] if needed, but there is not really a benefit compared to playing with the group, jumping on the mushroom. Use it if you get out of position and the wave is coming.

:::

:::tab Vashnik
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Defensive Cooldown Usage

- Use defensive cooldowns when affected by [[spell:1285979]] from killing the fire adds, especially if you get more than 1 stack.

### Boss Tips

- Help allies affected by [[spell:1295224]] to clear their circle and be healable again.

:::

:::tab Sszorak
:::talents [[talent:123357]] **Retribution Paladin** Single-Target Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Offensive Cooldown Usage

- **Sszorak** takes increased damage during [[spell:1286033]].

### Defensive Cooldown Usage

- Use a defensive cooldown if you got hit by a [[spell:1287083]] tornado.

### Boss Tips

- When affected by [[spell:1285616]], place yourself in a way that you collide with another player. If needed use [[spell:642]] to save yourself from flying off.

:::

:::tab The Twin Fangs
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Defensive Cooldown Usage

- Use a defensive cooldown when affected by [[spell:1290878]].

### Boss Tips

- Help soak [[spell:1289201]] as much as you can, but don't take too many stacks of [[spell:1292348]].
- Avoid getting hit by [[spell:1292806]] waves.

:::

:::tab The Coiled Altar
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Offensive Cooldown Usage

- Make sure to have all your offensive cooldowns available for the intermission after phase 2, where **Zul'jan** takes 100% increased damage through [[spell:1304033]].

### Defensive Cooldown Usage

- Use defensive cooldowns when affected by [[spell:1286901]].

### Boss Tips

- Absolutely prioritize and make sure to pick up all your **Soul Fragments** if you were hit by [[spell:1286901]], otherwise you will be [[spell:1286837]].

:::

:::tab Ula'tek
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

Ula'tek was not seen on the 12.1 PTR servers, and will first be seen on patch launch and season start. The talents provided above should be a good starting point.  
Ula'tek and updates to all bosses will follow soon after the conclusion of the upcoming Race to World First.

:::

:::tab Nymrissa Wavecaller
:::talents [[talent:123357]] **Retribution Paladin** Single-Target / Cleave  Talents for Raids
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### Offensive Cooldown Usage

- It can be beneficial to have cooldowns ready for **Restless Amani** add spawns, but only hold cooldowns if you can see the BigWigs timer with adds about to spawn, it is not worth holding long.

### Defensive Cooldown Usage

- Use a defensive cooldown when **Nek'zali** casts [[spell:1288772]].

### Boss Tips

- Beware of where the tank is when **Nek'zali** casts [[spell:1292034]]. Do not be in between her and her target.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Retribution Paladin**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Retribution Paladin** Stat Priorities in Raid
```json
{
  "source_code": "HoAJFQQMgQCKBEQABA"
}
```
**力量 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271465@BgQAAYEA5IgTBA]] | Tier |
| Neck | [[item:268265@BkCAAYEAE06QRrTOCQWNYYjX1YhN]] | Ula'tek |
| Shoulder | [[item:271463@BgQAAYEACHgTBA]] | Tier |
| Cloak | [[item:268253@BAQAAYEAYFA]] | The Coiled Altar |
| Chest | [[item:271468@BgQAAYEA5IgTBA]] | Tier |
| Wrist | [[item:268239@BgQAAYEA5IgTBA]] | The Lost Explorers |
| Gloves | [[item:271466@BgQAAYEA5IgTBA]] | Tier |
| Belt | [[item:271462@BgQAAYEA5IgTBA]] | Catalyst |
| Legs | [[item:271878@RARAAYEAItvE5IgF24UA]] | Ula'tek |
| Boots | [[item:268260@BgQAAYEA5IgTBA]] | Vashnik |
| Ring 1 | [[item:268252@BgQAAYEA5IgTBA]] | Sszorak |
| Ring 2 | [[item:268249@BgQAAYEA5IgTBA]] | Nexus-Point Xenas |
| Trinket 1 | [[item:270175@BgBAAYEAYYjX1kjA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgBAAYEAYYjX1kjA]] | The Coiled Altar |
| Weapon | [[item:268213@DgQAAYEA9k7kjAYF]] | The Coiled Altar |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@DARAAcEANk74iMeVTQB]] | Murder Row |
| Neck | [[item:273781@BgQAAYEACKQQBA]] | Altar of Fangs |
| Shoulder | [[item:251138@DARAAcEA7j74iMeVTQB]] | Murder Row |
| Cloak | [[item:193763@BgQAAYEACKQQBA]] | Ruby Life Pools |
| Chest | [[item:193753@AgQAAIoABFA]] | Ruby Life Pools |
| Wrist | [[item:251133@BgQAAYEACKQQBA]] | Murder Row |
| Gloves | [[item:159413@BARAAcEAuIjX1EUA]] | Kings' Rest |
| Belt | [[item:159418@BgQAAYEACKQQBA]] | Kings' Rest |
| Legs | [[item:273776@DARAAcEAju74iMeVTQB]] | Altar of Fangs |
| Boots | [[item:159412@BgQAAYEACKQQBA]] | Kings' Rest |
| Ring 1 | [[item:273792@BgQAAYEACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:251136@BgQAAYEACKQQBA]] | Murder Row |
| Trinket 1 | [[item:273796@BgQAAYEACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAAYEACKQQBA]] | Murder Row |
| Weapon | [[item:273782@BgQAAYEACKQQBA]] | Altar of Fangs |

:::

:::

### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on each boss fight.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270165@AgQAAIoAOFA]] |
| **B-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C-Tier** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *-- Great for AoE, Junkyard for single-target.* |
| **Junkyard** |  |

### Embellishments

- All in this section is very likely to change, so check back before you do any important craft, check to see if this text is removed. If it is then I am more confident in the recommendations.
- [[item:245876]] is the best embellishment.. Since crafted items are 331 item level instead of  334, that means you are using lower item-level weapons to get [[item:245876]].
  
  - For initial gearing, going for a crafted weapon with [[item:245876]] is by far the best option, unless you somehow have 2 high item level mythic weapons already.
- For your second embellishment there are many viable options, [[item:240167]] is the one recommended for now.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241324]] or**
  
  
  
  - **[[item:241326]] or**
  - **[[item:241322]] *-- Ret Paladins want a balance of stats of Mastery and Critical Strike, with having Haste at a decent % where it feels fluid to play.You can achieve this balance with gearing, but also using consumables.* *If you want to find out your own stat balance and what you need more of, I recommend checking out our [Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>).***
- **Food**
  
  - **[[item:255846]]**
- **Combat Potion**
  
  - **[[item:241288]]**
- **Health Potion**
  
  - **[[item:241304]]**
- **Weapon Temporary Enchant**
  
  - **[[item:243734]]**
- **Augment Rune**
  
  - **[[item:259085@AQAAAoF]]**
- **Sockets**
  
  - **[[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].***
    
    - **[[item:240890]]**
    - **[[item:240906]]**
    - **[[item:240916]]**
    - **[[item:240900]]**

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@DAAAAYEAvj7A]] |
| --- | --- |
| Shoulders | [[item:244021]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAYE]] |
| Waist | [[item:275707@BAAAAYE]] |
| Legs | [[item:244641@BAAAAYE]] |
| Boots | [[item:243983]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:244029@BAAAAYE]] |

:::

:::column
:::gear **Retribution Paladin** Enchantments in Raids
```json
{
  "source_code": "JQFZGBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

- You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Retribution Paladin** in Raid, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style or transmog works just as well since the DPS gain is not as massive as people make it out to be.

- [[spell:65116]] -- Dwarf
  
  - Can dispel Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:20549]] -- Tauren
  
  - An AoE stun is beneficial since paladins currently lack one. Additionally, [[spell:20550]] is very useful when doing high-level content.
- [[spell:265221]] *-- Dark Iron Dwarf* 
  
  - It can remove almost any debuff for a small damage buff.
- [[spell:25046]] *-- Blood Elf* 
  
  - Removes 1 buff from a target around you.
- [[spell:292361]] -- Zandalari Troll
  
  - Provides a small crit buff with an RNG proc rate. A great benefit of being Zandalari is that you can combo [[spell:291944]] and [[spell:642]] to heal yourself fully.
- [[spell:59752]] *-- Human* 
  
  - Removes any stun effect on you, similar to a PvP trinket. [[spell:20598]] is the main reason to play as a human.
- [[spell:28880]] *-- Draenei* 
  
  - No particularly useful racial except for [[spell:6562]].
- [[spell:255647]] *-- Lightforged Draenei* 
  
  - More of a just-for-fun racial, but don't forget [[spell:255652]] – it explodes for a small amount of damage when you die!

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS you should go with the highest DPS racial. That being said the story is a bit different if it's about pushing endgame Raid progression. Some help out massively to speed up the progression of certain bosses in dungeons or raids. Notably **Dwarf** with their [[spell:65116]] helped out on  **Tindral Sageswift** & **Fyrakk the Blazing** in the latest **Race to World First** by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Retribution Paladins** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor macro / Focus Marcos
**Cast [[spell:96231]] on your Focus without targeting it.**

```wow-macro
#showtooltip Rebuke
/cast [@focus] Rebuke
```

**Cast [[spell:853]] on your Focus without ever targeting it.**

```wow-macro
#showtooltip Hammer of Justice
/cast [@focus] Hammer of Justice
```

:::

:::details Mouseover Macros
**For all of these Marcos If you hold down Right click on your mouse this is cast on you instead of your mouseover.**

**Moseover for** [[spell:19750]]

```wow-macro
#showtooltip flash of light
/cast [@mouseover,exists,help] Flash of Light [@player] Flash of Light
```

**Moseover for [[spell:85673]]**

```wow-macro
#showtooltip Word of Glory
/cast [@mouseover,exists,help] Word of Glory [@player] Word of Glory
```

**Moseover for [[spell:633]]**

```wow-macro
#showtooltip Lay on Hands
/cast [@mouseover,exists,help] Lay on Hands [@player] Lay on Hands
```

**Moseover for[[spell:305394]]**

```wow-macro
#showtooltip Blessing of Freedom
/cast [@mouseover,exists,help] Blessing of Freedom [@player] Blessing of Freedom
```

**Moseover for [[spell:6940]]**

```wow-macro
#showtooltip Blessing of sacrifice
/cast [@mouseover,exists,help] Blessing of sacrifice; Blessing of sacrifice
```

**Moseover for [[spell:1022]]**

```wow-macro
#showtooltip Blessing of Protection
/cast [@mouseover,exists,help] Blessing of Protection [@player] Blessing of Protection
```

**Moseover for [[spell:213644]]**

```wow-macro
#showtooltip Cleanse Toxins
/cast [@mouseover,exists,help] Cleanse Toxins [@player] Cleanse Toxins
```

:::

:::details Cooldown Marcos
**Marco to use a trinket into [[talent:102593]]**

```wow-macro
#showtooltip Avenging wrath
#show Avenging wrath
/cast Avenging wrath
/use Ashes of the Embersoul
/use 14
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Retribution Paladin**, outlining which addons are used and how they are utilized in Raids to make your life easier.

A new ui will be posted once we know what addons are going to be fully in and what I will be using. Check back either before the raid tier or for the update afterwards for the full breakdown

![](<https://assets-ng.maxroll.gg/wordpress/dddd-1-1024x651.jpg>)

**Retribution Paladin** UI in Raid.

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- **Retribution**:

- Apex Talent: Light Within (Rank 1) now has an additional effect – Art of War and Righteous Cause can now each accumulate an additional time.
- Art of War has been updated – Now increases Blade of Justice damage by 80% (was 150%).
- Blade of Justice damage increased by 40%.
- Final Verdict damage increased by 15%.
- Divine Storm damage increased by 15%.
- Avenging Wrath now increases damage done and critical strike chance by 15% (was 20%).
- Templar Strike damage increased by 50%.
- Templar Slash damage increased by 50%.
- Judgment damage increased by 50%.
- Hammer of Wrath damage increased by 50%.
- Divine Toll’s Judgment now deals 50% increased damage (was 100%).
- Apex Talent: Light Within (Rank 3) damage reduced by 25%.
- Flash of Light healing increased by 25%.
- Word of Glory healing increased by 25%.
- Eternal Flame healing increased by 25%.
- Art of War no longer activates from additional Skyfury attacks.
- Additional Skyfury attacks no longer generate Holy Power when talented into Crusading Strikes.
- Crusading Strikes now increases auto-attack speed by 15% (was decreasing by 20%).
- Execution Sentence area of effect radius increased to 10 yards and now includes the bounding radius of the target (was 8 yards).
- Hero Talents
  
  - Templar
    
    - Hammer of Light damage reduced by 30%. Does not affect PvP combat.
    - Hammer of Light now costs 3 Holy Power (was 5).

:::

:::details Patch 11.0.2
- Developers’ note: New Talent: Holy Flames – Divine Storm deals 10% increased damage and when it hits an enemy affected by your Expurgation, it spreads the effect to up to 4 targets hit. You deal 3% increased Holy damage to targets burning from your Expurgation.
- Crusader Aura talent is no longer granted by default in the Class tree for Retribution.
- Greater Judgment talent is now granted by default in the Class tree for Retribution.
- Consecrated Blade is no longer a talent and now learned at level 11.
- Word of Glory healing increased by 44%.
- Final Verdict damage reduced by 10%.
- Templar's Verdict damage reduced by 10%.
- Justicar's Vengeance damage reduced by 10% and now heals for 3% of maximum health (was 5%).
- Hammer of Wrath damage reduced by 15%.
- Blade of Justice damage reduced by 20%. Does not effect Blade of Vengeance.
- Blade of Vengeance damage increased by 25%.
- Expurgation damage reduced by 10%.
- Divine Storm damage increased by 25%.
- Templar Strike damage reduced by 10%.
- Templar Slash damage reduced by 10%.
- Crusading Strikes damage reduced by 10%.
- Crusader Strike damage reduced by 10%.
- Blessed Champion now deals 25% reduced damage to secondary targets (was 50% reduced damage) and is now a 1-point talent (was 2).
- An issue causing Radiant Glory to not function with fast back to back procs has been resolved.
- The following talents are now 2 points (was 1):Heart of the Crusader
- Zealot’s Fervor
- Vanguard of Justice has been removed.
- Empyrean Legacy moved to where Vanguard of Justice was on the talent tree.
- Holy Flames is now in a choice node with Blade of Vengeance.

:::

:::details Patch 11.1
- Developers’ note
- Divine Hammer has been redesigned -- Divine Hammers spin around you, striking enemies nearby for Holy damage every 2 seconds for 8 seconds. While active, each Holy Power spent increases the duration of Divine Hammer by 0.5 seconds. Deals reduced damage beyond 8 targets. Costs 3 Holy Power and has a 1 minute cooldown.
- All ability damage increased by 5%.
  
  - *Developers' notes: Empyrean Hammer's damage output was higher than desired on the overall breakdown. We're redistributing the power across the rest of the abilities.*
- Final Reckoning damage increased by 75%.
- Flash of Light healing increased by 35%.
- Word of Glory’s mana cost has been increased to 15% (was 10%).
- Healing Hands now only functions to increase Word of Glory’s healing on the Paladin themselves (was increased healing on allies).
- Divine Toll will now cast Judgments at units near your main target, even if you're not in combat with them.
- Crusade will now consistently display the correct spell visual when Glyph of Winged Vengeance is being used.
- Herald of the Sun
  
  - Second Sunrise has been updated – Divine Storm and Hammer of Wrath has a 20% chance to cast again at 50% effectiveness (was 15% chance at 30% effectiveness).
  - Sun's Avatar damage increased by 50%.
- Templar
  
  - Empyrean Hammer damage reduced by 30%.
  - Hammer of Light now benefits from Undisputed Ruling Judgment.
  - Hammer of Light now benefits from the stacks it adds to Crusade.
    
    - *Developers’ notes: The reimplementation of Hammer of Light inadvertently altered its interactions with Crusade and Judgment. We have now adjusted these interactions to match the current live versions.*
  - Hammer of Light initial hit now benefits from Final Reckoning.

:::

:::

## FAQ

:::accordion
:::details Q: Is it worth to [[spell:315867]] on 4 holy power and go above 5?
**A: If you are setting up for [[talent:115435]] then yes, if not try to get a [[talent:102504]] out first then use it!**

:::

:::details Q: Mobs target me after [[spell:1022]] - [[spell:642]] why?
A: You still generate aggro while using these two, so be careful when they drop, as mobs might instantly target you if you keep pumping.

:::

:::

---

### Credits

Written By: **Narcolies**

Reviewed By: **Tief**

---

:::changelog 更新记录
**2026-08-04** Updated for patch  12.1

**2026-02-21** Updated for patch  12.0.1

**2026-01-15** Updated for patch  12.0

**2025-10-07** Updated for patch 11.2.5

**2025-02-20** Updated for patch 11.1.7

**2024-12-17** Updated for patch 11.0.7.

**2024-10-23** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch



:::
