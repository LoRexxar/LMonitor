Welcome to the **Holy Paladin** Raid guide for the World of Warcraft patch 12.1.0! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 4/5 · Strong

Cooldown Strength · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Holy Paladin** Raid Best in Slot Gear
```json
{
  "source_code": "JsoAIGEA3_fABkGJEIICBAw74OwVtOggC4UABk-FEAQEBAgAtOgABIBNMWDWBEwZkQgAIEAA1kbCjAAbB8ACFAQCB8AKYFgvXQQAjfBBAiQB1AkgCgVABYgJEIAEBAwGqOgF2UQEARQoDYAIBAgHAPwJqOwD5OAAFEAJ3WzSBEgChOAhIExGIIQrDUQFcoGJEAACBAggBEJBZfRBjSw94GgHFIBFeqmACiQAuIBAEQ1HZADAX1BDE09FNgBEYFQAzeRBFDQPJYLLBY-FEAACBAggC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240898]] |
| 腿部 | [[item:271878]] | [[item:240155]] |
| 脚部 | [[item:237828]] | [[item:245790]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268211]] | [[item:244029]] |
| 副手 | [[item:268262]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Holy Paladin**, you have access to [[spell:1244878]], which automatically applies a beacon to low health allies, this beacon jumps around if other nearby allies drops low.

**Rank 2** makes the [[spell:1244878]] stronger by having additional 10% of your healing transfer into it and makes allies with your [[spell:1244878]] take 20% increased healing from you. While **Rank 3** enables the [[spell:1244878]] to grant an absorb shield every 8 seconds or whenever it jumps to a new ally.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-holypala-mxr.webp>)

Beacon of the Savior

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:461287]]
    
    - This talent provides us with a good chunk of passive damage
  - [[spell:1277651]]
    
    - This talent used to empower our [[spell:25912]] after casting [[spell:375576]] or [[spell:31884]]. Now it is just a modifier on your beacons.
  - [[spell:1241714]]
    
    - Converts some of the healing from our spenders into absorbs. Not a very strong talent unless youre in a situation where your spells are overhealing a lot.
  - [[spell:248033]]
    
    - This talent now synergises very well with [[spell:1241358]]
  - [[spell:414273]]
    
    - [[spell:31884]] now amplifies your next 2 [[spell:82326]] casts.
- **Class Tree**
  
  - [[spell:1277443]]
    
    - This talent buffs our passive tankiness by a nice amount.
  - [[spell:1241945]] and [[spell:183416]]
    
    - These talents have been split apart and are now two seperate capstones. Dusk reduces our damage taken, and dawn redirects allies damage to you as long as youre at high hp, acting as a form of damage reduction for your allies.
  - [[spell:1265549]]
    
    - Provides a small burst of healing whenever a mob youve attacked dies. Good in situations where the is a lot of small mobs.
- **Removed**
  
  - [[spell:35395]]
    
    - This ability is now apart of [[spell:216331]] and is no longer a standalone ability. Limiting our holy power generation slightly.

## Hero Talents

- [[talent:123362]] focuses on healing and Cooldown strength, while [[talent:123359]] focuses on survivability and damage done.
- In a Raid environment  [[talent:123362]] outperforms [[talent:123359]] in any scenario. Therefore this Guide focuses solely on the better option.

### [[talent:123362]]

- After using [[spell:114165]] or [[spell:375576]] you can apply 2 [[spell:431377]] with your Holy Power spenders. While [[spell:31884]] or [[spell:216331]] is active you are linked with beam lines to all targets with [[spell:431377]] healing/damaging anything crossing them.
  
  - While [[spell:431377]] is active your Holy Power spenders are 3% stronger thanks to [[talent:117778]].
  - With [[talent:117691]] your haste is increased while [[spell:431377]] is active. This effect stacks.
- Your core spec abilities are enhanced by the following nodes:
  
  - [[spell:85673]] is replaced by [[spell:156322]] making it even stronger with extra HoT effect on top.
  - [[spell:20473]] and [[spell:85222]] are empowered with:
    
    - [[talent:117677@AJgA]] that increases critical strike chance by 5%.
    - [[talent:117669@AJgA]] which procs on critical strikes.
    - [[talent:117683@AJgA]] giving 15% chance to cast again at 30% effectiveness.

### [[talent:123359]]

- [[talent:117882]] rotates between [[spell:432472]] and [[spell:432459]] allowing you to buff both yourself and your target  with current Armament. These abilities replace [[spell:114165]] or [[spell:375576]]
  
  - While wielding [[spell:432472]] your spells and abilities have a chance to deal extra damage or healing.
  - With [[spell:432459]] up you get 15% max health absorb and an extra 2% absorb every 2 seconds.
  - [[talent:117877]], [[talent:117876]], [[talent:117885]] and [[talent:117874]] allow you to have higher uptime on Armaments.
  - Activating [[spell:31884]] summons another [[spell:432472]]. While [[spell:31884]] is active [[spell:432472]] echoes your Holy Power spenders.
  - Your active aura is 33% stronger on allies with Armaments thanks to [[talent:117886]].
- Few abilities are enhanced by the following nodes: 
  
  - [[talent:117887]] triggers a big burst of damage/healing around your target when [[spell:20271]] critically strikes.
  
  
  
  - [[talent:117881]] increases your armor by 5% and primary stat by extra 2% while imbued on your weapon.

## Talents

### [[spell:31884]]

:::talents **Holy Paladin** Default Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### When to use this Spec

This is the default loadout going into any boss unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Manaforge Omega section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:200025]] or [[spell:156910]]
  
  - [[spell:200025]] is the default choice since it offers higher throughput, but it does come at the cost of interfering with your rotation and a higher mana cost. [[spell:156910]] is a very strong option and can be swapped to in scenarios where you would benefit from healing the same 2 targets over a long period of time or youre running out of mana.
- [[spell:114165]] or [[spell:375576]]
  
  - On its own it is not as strong as it used to be, but as [[talent:123362]] they give us access to [[spell:431377]] which makes them very important. Ideally you want to use it with [[spell:31884]] to buff the already strong abilities.

##### Class Tree

- [[spell:1277443]] and [[spell:402964]]
  
  - Are talents that makes Paladins super tanky even without a defensive cooldown up.
- [[talent:115466]]
  
  - This talent makes your [[spell:375576]] and [[spell:114165]] windows even stronger. Watch out to not overcap Holy Power during this buff !

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:53576]] Increases the healing of [[spell:19750]] by an additional 100% and the absorb from [[spell:218178]] by an additional 100%
- **4-Set:** [[spell:20271]] now has a 20% chance to grant [[spell:53576]]. [[spell:82326]] now has a 100% chance to grant [[spell:53576]] but its mana cost is increased by 50%.

### Priority List

- **DO NOT** overcap Holy Power. Your spenders are really strong, even if there isn't much to heal you can always use [[spell:53600]].
- Cast [[spell:20473]] as much as possible. It is the bread and butter of Holy Paladin.
- Spend your [[spell:53576]] buffs on [[spell:19750]] to refund [[spell:20473]] and since it is a quite large heal on its own

#### [[spell:31884]]

1. If talented cast [[spell:200025]] for Aoe healing if needed otherwise can skip it to save Mana.
2. Spend Holy Power if at 5 Holy Power.
3. Cast [[spell:82326]] if you have mana for it. This is a very costly spell but extremely powerful
4. Cast 1st charge of [[spell:20473]].
5. Cast [[spell:114165]] on an enemy for Aoe healing or cast [[spell:375576]] on an ally for the same effect.
6. Spend [[spell:53576]] on [[spell:19750]].
7. Cast 2nd charge of [[spell:20473]].
8. Spend Holy Power.
9. Cast [[spell:19750]] if you need an immediate heal.
10. Cast [[spell:20271]].

### Cooldowns

#### Avenging Wrath

- An iconic paladin cooldown which now is very strong on its own thanks to[[talent:123362]]. You want to pair it up with other smaller cooldowns like [[spell:304971]] and [[spell:114165]] to increase their power.

#### Divine Toll

- Your main short cooldown that should be used every 2 minutes with [[spell:31884]] to make use of various talents like [[spell:1263920]] that all end up buffing each other for additional healing.

#### Aura Mastery

- Mostly used with [[spell:465]] to provide one of the raid-wide damage reduction cooldowns. It's not as strong as it used to be but can still be a game changer against some mechanics. Make sure to use it proactively before damage events happen; otherwise, it might be a waste of a global cooldown.

## Deep Dive

#### Cooldown Management

- Maximizing your **Holy Paladin's** potential involves properly combining your cooldowns. You should plan out your [[spell:114852]] / [[spell:375576]] and [[spell:31884]] casts before going into an encounter and evaluate if you would get use of a talent like [[spell:379391]] to make it easier to synchronize your cooldowns. You lose a lot of value if you dont end up casting a [[spell:114852]] / [[spell:375576]] in your [[spell:31884]] window due to [[spell:1263920]] and other various buffs that all add up, so its important to plan ahead and think about when youre gonna cast each ability, below is a timeline of an example of what a plan could look like, without making use of the [[spell:379391]] talent.

:::timeline
```json
{
  "source_code": "IUFX29P_SDgAA0gAMyHAPAgAYsbBPAgA13bAJYAN8AgAYsbB8AgA13bApBQAkAglFIBApVgEJwQCGAzwAIQ99GwwAIAG7Www"
}
```
总时长：210 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 15 秒 | [[spell:114165]] | 上轨 |
| 15 秒 | [[spell:31884]] | 上轨 |
| 15 秒 | [[spell:375576]] | 上轨 |
| 60 秒 | [[spell:114165]] | 上轨 |
| 60 秒 | [[spell:375576]] | 上轨 |
| 105 秒 | [[spell:114165]] | 上轨 |
| 105 秒 | [[spell:375576]] | 上轨 |
| 150 秒 | [[spell:114165]] | 上轨 |
| 150 秒 | [[spell:31884]] | 上轨 |
| 150 秒 | [[spell:375576]] | 上轨 |
| 195 秒 | [[spell:114165]] | 上轨 |
| 195 秒 | [[spell:375576]] | 上轨 |
| 195 秒 | [[spell:375576]] | 上轨 |
:::

#### Optimizing spenders

- Currently [[spell:85222]] offers more healing in raid than [[spell:156322]]. But with [[spell:156322]] you have full control over which targets receive all of your healing. So you need to decide if someone is in danger and if you would get value out of pressing [[spell:156322]] to keep a specific person alive.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to Heroic Bosses. Mythic tips will be released after our progression finishes.

**← Scroll for more Bosses →**

### Nek'Zali

:::talents **Holy Paladin** Nek'Zali Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1287322]] at the edge of the room!
- Do not be inbetween the boss and the tank when the boss casts [[spell:1284103]].

### Entombed Sentinels

:::talents **Holy Paladin** Entombed Sentinels Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- Dispel players affected with [[spell:1284471]].
- [[spell:1284590]] is neutralized harmlessly upon reaching exactly 4 stacks.

### Lost Explorers

:::talents **Holy Paladin** Lost Explorers Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1286921]].

### Vashnik

:::talents **Holy Paladin** Vashnik Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- External players affected with [[spell:1295224]]. While affected, they are immune to your regular healing.
- Use a personal defensive when affected by [[spell:1294994]].

### Sszorak

:::talents **Holy Paladin** Sszorak Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- External people with [[spell:1286987]].

### Twin Fangs

:::talents **Holy Paladin** Twin Fangs Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- Defensives
  
  - Use a personal defensive when affected by [[spell:1290809]].

### Coiled Altar

:::talents **Holy Paladin** Coiled Altar Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.

### Ula'tek

:::talents **Holy Paladin** Ula'tek Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.

### Nymrissa Wavecaller

:::talents **Holy Paladin** Nymrissa Wavecaller Raid Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAAw2MzMjZMzYxYmZYZYmZxMNxwYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAAbGGzYGMAAmZYGjRD"
}
```
:::

#### Boss Tips

- Use a personal defensive when many [[spell:1257717]] get popped.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Holy Paladins**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Holy Paladin** in Raid
```json
{
  "source_code": "IoAJFUQMkgCIBEQABA"
}
```
**智力 ＞ 精通 ＞ 急速 ＞ 全能 ＞ 暴击**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- Blizzard introduced Stat drs, which you should be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful Leech is for a Healer: Breakdown from raid testing of Vorasius

![](<https://assets-ng.maxroll.gg/wordpress/HpalBreakdown-1-1024x572.png>)

Holy **Paladin** healing breakdown from Warcraftlogs

## Gear

### Best in Slot

Due to the way stat weights work for **Holy Paladin**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271465@DiQAAEEAvj7cVrjgC4UA]] | Tier/Catalyst |
| Neck | [[item:268265@BERAAEEAC06IQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271463@DgQAAEEA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAEEACKAWBA]] | Coiled Altar |
| Chest | [[item:268222@BgQAAEEACKAWBA]] Catalyst into [[item:271468@DgQBAEEAJk7IoAYFgvXQ]] | Coiled Altar |
| Wrist | [[item:237834@FiQAAEEAeA8ciqjAtO3WzSB]] | Crafted |
| Gloves | [[item:271466@BgQAAEEACKgTBA]] | Tier/Catalyst |
| Belt | [[item:268259@BiQAAEEAC06IoAYF]] | Coiled Altar |
| Legs | [[item:271878@DARAAEEAbo6YhNCKAWB]] | Ula'tek |
| Boots | [[item:237828@HASAAEEAeA8ciqzD5OAAAAAAAA3WzSB]] | Crafted |
| Ring 1 | [[item:268249@DiQAAEEA3j7IQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAEEA3j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAEEACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAEEACKgTBA]] | Nymrissa Wavecaller |
| 1h Weapon | [[item:268211@DgQAAEEA9k7IoAYF]] | Coiled Altar |
| Off hand | [[item:268262@BgQAAEEACKgTBA]] | Nymrissa Wavecaller |

#### Authors Note:

This list shows the best items for healing in Mythic+ from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@BgQAAEEACKQQBA]] | Murder Row |
| Neck | [[item:251234@BgQAAEEACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:251138@BgQAAEEACKQQBA]] | Murder Row |
| Cloak | [[item:251132@BgQAAEEACKQQBA]] | Murder Row |
| Chest | [[item:251151@BgQAAEEACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:159409@BgQAAEEACKQQBA]] | King's Rest |
| Gloves | [[item:159413@BgQAAEEACKQQBA]] | King's Rest |
| Belt | [[item:159418@BgQAAEEACKQQBA]] | King's Rest |
| Legs | [[item:273776@BgQAAEEACKQQBA]] | Altar of Fangs |
| Boots | [[item:159412@BgQAAEEACKQQBA]] | King's Rest |
| Ring 1 | [[item:251136@BgQAAEEACKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAEEACKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250214@BgQAAEEACKQQBA]] | The Blinding Vale |
| Trinket 2 | [[item:273649@BgQAAEEACKQQBA]] | King's Rest |
| One-Hand Weapon | [[item:160216@BgQAAEEACKQQBA]] | King's Rest |
| Off-Hand | [[item:251150@BgQAAEEACKQQBA]] | Den of Nalorakk |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAEEACKgTBA]]  <br>[[item:270167@BgQAAEEACKgTBA]] |
| **A-Tier** | [[item:273649@BgQAAEEACKgTBA]]  <br>[[item:250214@BgQAAEEACKgTBA]]  <br>[[item:270162@BgQAAEEACKgTBA]] |
| **B-Tier** | [[item:270171@BgQAAEEACKgTBA]]  <br>[[item:270169@BgQAAEEACKAWBA]]  <br>[[item:273794@BgQAAEEACKgTBA]]  <br>[[item:273796@BgQAAEEACKgTBA]]  <br>[[item:250215@BgQAAEEACKgTBA]] |
| **C-Tier** | [[item:250254@BgQAAEEACKgTBA]]  <br>[[item:250224@BgQAAEEACKgTBA]]  <br>[[item:193748@BgQAAEEACKgTBA]]  <br>[[item:193757@BgQAAEEACKgTBA]] |
| **Junkyard** | [[item:250248@BgQAAEEACKgTBA]]  <br>[[item:250259@BgQAAEEACKgTBA]]  <br>[[item:250255@BgQAAEEACKgTBA]] |

### Embellishments

- [[item:240167]] 2x
  
  - A generic embellishment you can put on any crafted armorpiece, it is generally recommended to craft embellishments with [[item:240167]] on the cloak and wrists slots as crafted items are lower item level and these 2 slots have the lowest amounts of stats on them. Since the cloak slot has an item with increased item level the best in slot setup has moved the crafted item away from the cloak slot and onto the boots

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Flask**
  
  - [[item:241322]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241300]]
  - [[item:241288]] -- Recommended
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:243951@DAAAAwbBZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwbB]] |
| Chest | [[item:243977@BAAAAwbB]] |
| Wrist | [[item:275707]] |
| Belt | [[item:275707]] |
| Legs | [[item:240155@BAAAAwbB]] |
| Boots | [[item:243983@BAAAAwbB]] |
| Ring 1 | [[item:243959@BAAAAwbB]] |
| Ring 2 | [[item:243959@BAAAAwbB]] |
| Weapon | [[item:244031@BAAAAwbB]] |

:::

:::column
:::gear **Holy Paladin** Enchantments
```json
{
  "source_code": "JQFZBBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Holy Paladin** in Mythic Raiding, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:20594]] *-- Dwarf* 
  
  - Extra Bleed/Magic dispel comes clutch on some fights
- [[spell:25046]] -- Blood Elf
  
  - Historically aoe purge from [[spell:25046]] was very strong at times

### Recommendation:

It is recommended to play a Dwarf! The combination of [[spell:59224]] and [[spell:20594]] makes it a very strong race overall.

## Macros

Discover recommended macros for **Holy Paladin** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Holy Paladin** Raid guide are available as mouseover macros for your convenience!

[[spell:20473]]

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] Holy Shock; [harm] Holy Shock ; Holy shock
```

[[spell:19750]]

```wow-macro
/cast [@mouseover,help,nodead] Flash of Light ; Flash of Light
```

[[spell:82326]]

```wow-macro
/cast [@mouseover,help,nodead] Holy Light ; Holy Light
```

[[spell:85673]]

```wow-macro
/cast [@mouseover,help,nodead] Word of Glory ; Word of Glory
```

[[spell:1022]]

```wow-macro
/cast [@mouseover,help,nodead] Blessing of Protection ; Blessing of Protection
```

[[spell:1044]]

```wow-macro
/cast [@mouseover,help,nodead] Blessing of Freedom ; Blessing of Freedom
```

[[spell:6940]]

```wow-macro
/cast [@mouseover,help,nodead] Blessing of Sacrifice ; Blessing of Sacrifice
```

[[spell:633]]

```wow-macro
/cast [@mouseover,help,nodead] Lay on Hands ; Lay on Hands
```

[[spell:4987]]

```wow-macro
/cast [@mouseover,help,nodead] Cleanse ; Cleanse
```

[[spell:114165]]

```wow-macro
/cast [@mouseover,help,nodead] Holy Prism; [harm] Holy Prism ; Holy Prism
```

[[spell:304971]]

```wow-macro
/cast [@mouseover,help,nodead] Divine Toll; [harm] Divine Toll ; Divine Toll
```

[[spell:391054]]

```wow-macro
/cast [@mouseover,help] Intercession
```

[[spell:7328]]

```wow-macro
/cast [@mouseover,help] Redemption
```

[[spell:53563]] + [[spell:200025]]

```wow-macro
/cast [@mouseover,help,nodead] Beacon of Light ; Beacon of Light
/cast [@mouseover,help,nodead] Beacon of Virtue ; Beacon of Virtue
```

[[spell:156910]]

```wow-macro
/cast [@mouseover,help,nodead] Beacon of Faith ; Beacon of Faith
```

:::

:::details Recommended Macros
With this macro, you never die when trying to use your immunity mid cast.

```wow-macro
#showtooltip
/stopcasting
/cast Divine Shield
```

Sometimes you might have to cancel your immunity early.

```wow-macro
/cancelaura Divine Shield
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Holy Paladin**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/euiHpal-1-1024x576.png>)

**Holy Paladin** Raid User Interface

:::accordion
:::details Addons
- **EllesmereUI**-- Full UI Replacement Addon
  
  - The entire ui is made with Ellesmere ui and it controls raidframes, damage meter, nameplates, action bars and cooldown manager. Plus adds a lot of additional small quality of live features and is highly customizeable

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1.0
**PALADIN**

- Golden Path healing increased by 25%.
- Lightforged Blessing healing increased by 25%.
- Brought to Light healing increased by 25%.
- Holy
  
  - All healing increased by 19%.
  - Eternal Flame healing increased by 20%.
  - Word of Glory healing increased by 20%.
  - Holy Shock healing increased by 10%.
  - All damage increased by 20%.
  - Judgment damage increased by 25%.
  - Hammer of Wrath damage increased by 25%.
  - Avenging Crusader now transfers 55% of healing done (was 80%).
  - Pillar of Light's Beacon of Virtue healing increased by 50%.
  - Shield of the Righteous mana return increased by 25%.
  - Unworthy debuff now lasts for 18 seconds (was 15 seconds).
  - Ringing of the Heavens now casts Divine Toll at 200% effectiveness (was 100%).
  - Truth Prevails healing increased by 30%.
  - Saved by the Light absorb increased by 50%.
  - Tirion's Devotion now reduces the cooldown of Lay on Hands by 40% (was 30%).
  - Awakening now activates on a 15% chance (was 10%).
  - Glistening Radiance now absorbs 2% of max health, up to 6% (was 1%, up to 5%).
  - Overflowing Light now transfers 50% of Holy Shock's healing (was 30%).
  - Call of the Righteous now decreases the duration of Avenging Wrath by 3 seconds (was 4 seconds) and decreases the duration of Avenging Crusader by 2 seconds per point (was 2.5 seconds).

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Watch for your health when [[spell:6940]] is up or combine it with [[spell:642]].

:::

:::details Q: Why do I keep running out of mana?
A: You are using [[spell:82326]] too often.

:::

:::

---

### Credits

Written By: **Ftmjgtde**

Reviewed By: **Rycn**

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1.0

**2026-06-16** Updated for patch 12.0.7

**2026-04-25** Updated for patch 12.0.5

**2026-02-21** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0



:::
