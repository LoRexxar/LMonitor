欢迎来到**守护 德鲁伊**团队副本攻略，适用于魔兽世界 12.1 版本！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从 80 级开始练级的玩家？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 3/5 · 中等

生存能力 · 4/5 · 强

机动性 · 2/5 · 弱



:::

:::

:::column
:::gear **守护 德鲁伊 团队副本 最佳配装**
```json
{
  "source_code": "JUoAwDEaAc__AEwAmQggQEAAvj7AX16ACKwF2gVABk-FEAQEBAg_sOg_sOAj1kjAYFQAmSCBCgQBAUTuDIoAOFwVVPQArGgE4EAAJk7ACKgTBEA4XQAgIUQNUIoAYFQAnGgHMUAAhubBPAXwXQQAZt7AGgQAAYBwDciqDEPuDIoALFQAgt7AEWRF44PrDcbNLFQApSCBAgQBAEwV8QP1DEg6XQgAJEAAvk7A-zaADEAGMEw4uJgRVAAFU9BBAgQAFkDBB0VEMABWBEQ3X0AGAhVABc7FEIACBAQP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240894]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245782]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**守护 德鲁伊**，你可以使用野性守护，当你使用[[spell:77758]]和[[spell:33917]]时，有几率召唤一个守护之魂来攻击你的目标。

**等级2** 使你的精通和[[talent:103191]]伤害提高。 **等级3** 重置你的 [[spell:77758]] 和 [[spell:33917]] 的冷却时间，每当你触发一次 野性守护。此外，你还会获得一次使用机会：野性守护在每次 [[talent:103201]] 之后，你可以按需将其激活。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-guardian-mxr.webp>)

野性守护

:::

:::

### 核心改动

以下为你整理从《地心之战》到 至暗之夜 的重要职业改动，帮你保持信息更新。如果想更详细地了解 **全部** 改动，请查看我们的 **本补丁改动** 部分。

- 专精天赋树
  
  - 新技能 [[talent:135336]]
    
    - 对目标施加一个持续 8 秒的 DOT，每次你施放 [[spell:33917]] 时其持续时间延长 1 秒。
    - 取代了 [[spell:8921]]，这使得拉取多个小怪变得困难得多。在不存在此问题的单体战斗中表现最佳。
  
  
  
  - 新被动 [[talent:135490]]
    
    - 使 [[spell:33917]] 获得第二层充能。
    - 在 80 点或以上怒气施放时，[[talent:103191]] 触发 [[talent:103190]] 的几率翻倍。
    - 这极大地提升了怒气生成，并因为有了更多有影响力的按键而减少了填充 [[talent:103301]] 的施放次数。
  - 新被动 [[talent:103222]]
    
    - 允许 [[talent:103191]] 消耗至多多 50% 的怒气并造成至多多 100% 的伤害。
    - 在高怒气水平施放时提升 [[talent:103191]] 的效果。
    - 与 [[talent:135490]] 一起，强烈促使你只在 80 点以上怒气时才施放 [[talent:103191]]。
  - 新技能 [[talent:114701]]
    
    - 重置 [[spell:77758]] 的冷却时间，并允许其在 12 秒内额外叠加 5 次。
    - 当其结束时，多余的 [[spell:77758]] 层数会立即造成伤害。
    - 由于 [[spell:77758]] 在单体目标中优先级较低，在团队副本战斗中很难从这个天赋中获得良好收益。
  
  
  
  - [[talent:114700]] 
    
    - 天赋树中的位置已调整，即使在游玩 [[talent:123301]] 时也更容易选取它
  - [[talent:114698]]
    
    - 现在最多可叠加 4 次，这是一个很好的便利性改进。
- **职业天赋树**
  
  - [[talent:103309@AJwCCA]] 重做了。它现在是一个 2 分钟冷却的技能，其效果取决于你当前的形态：
    
    - 在人类形态下，它会向目标及其周围至多 5 名盟友施放强化的 [[talent:103283]]。
    - 在 [[spell:768]] 下，它会向你的目标施加强化的 [[spell:274837]]——一个高伤害的单体流血效果。
    - 在 [[talent:103286@AJwCCA]] 下，它会在 8 秒内对你周围 40 码范围内的敌人造成 范围伤害 伤害，类似于 [[spell:191034]]。
- [[talent:123301]]
  
  - [[talent:117209]] 被削弱了，现在只会使 [[talent:103300]] 或 [[spell:22568]] 的伤害提高 50%，而不是 200%。
  - 这使得猫形态穿插打法的效率大大降低。现在，为了最大化伤害输出，更优的选择是选取 [[talent:117210]] 并在整个战斗中保持 [[spell:5487]]。
- **已移除**
  
  - [[spell:400222]] 
    
    - 没有这个天赋，[[talent:103305]] 就变成了一个纯粹防御性的怒气消耗技能，不造成任何伤害。
  - [[spell:135288]]
    
    - [[talent:103191]] 没有免费触发，加上 [[spell:400222]] 的移除，意味着你现在必须将怒气用于 [[talent:103191]] 才能主动造成伤害。

## 英雄天赋

- 尽管巅峰天赋改动与第二赛季新套装加成的协同效果与 [[talent:123295]] 配合更好，但 [[talent:123301]] 仍能提供更强的单体爆发输出。[[talent:123295]] 紧随其后，且循环手法更简单。我们推荐在团队副本中使用 [[talent:123295]]，但也将 [[talent:123295]] 视为一个有竞争力的替代选择。



### [[talent:123301]]

- [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 当它触发时，[[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 会在20秒内或直至使用前替换你的 [[spell:6807]]。
- [[talent:117218]]
  
  - 生命值的提升仅在 [[spell:22842]] 增益存在期间生效。
- [[talent:117220]] + [[talent:117216]]
  
  - [[talent:117220]] 会施加于所有被 [[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 命中的目标，并为你提供10%的伤害减免。
  - 通过这一天赋组合，[[talent:117216]] 只需按正常循环操作即可被动延长该流血效果和伤害减免。
- [[talent:117207]]
  
  - [[spell:441685]] 在你变出 [[spell:5487]] 时提供生命值和护甲，例如为了使用 [[talent:103309@AJwCCA]] 而变形时。
    
    - 当你变回 [[spell:5487]] 时，该增益会被取消。
  
  
  
  - [[talent:103298]] 和 [[talent:103305]] 在脱离 [[spell:5487]] 后均不会消失。
- [[spell:441835@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 该提示文字具有误导性，每个受到初始伤害命中的目标都有25%的几率触发 [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]。这意味着在大规模拉怪时，你很可能会在每次施放技能后都获得一次触发。

12.0版本新增了3个英雄天赋。

- [[talent:135980@FJQA-thBLIA]] 使你的自动攻击触发 [[talent:117206@FAQAychA]] 的几率提高 30%。
- [[talent:117219@AJwCCA]] 使受到 [[talent:117220]] 影响的目标受到你的其他流血效果（例如 [[talent:103277@FAQAKFjB]]、[[talent:103300]] 和 [[spell:77758]]）的伤害提高 15%。
- [[talent:135979@AJwCCA]] 可以从你的单体近战技能中随机触发，造成物理伤害并产生 5 点怒气。




### [[talent:123295]]

- [[spell:424058@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 这使得将所有敌人拉在 [[talent:114700]] 区域内坦住变得非常重要。
- [[talent:117204]]
  
  - 当敌人处于你的 [[talent:114700]] 区域内时，该效果会被持续刷新，这意味着在效果结束或敌人走出区域后，它还会再持续 6 秒。
- [[talent:117192]] 
  
  - 由于 [[spell:8921@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 几乎一直存在于敌人身上，这是一个非常不错的、方便的被动减速。
- [[talent:117183]] + [[talent:117177]]
  
  - 这个天赋组合使 [[spell:77758]] 能够为 [[talent:114700]] 提供冷却缩减，大幅提高其使用频率。
- [[talent:117176]]
  
  - 触发的 [[spell:211545@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 没有内部冷却时间，并且还会对被击中的目标施加 [[talent:117204]]。
- [[spell:424113@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 你身上的 [[talent:114700]] 增益不依赖于地面区域，即使你离开地上的区域，它也能同时提供治疗和精通加成。
  - 其他收益，例如上文提到的那些天赋，只在敌人处于区域内时生效。

12.0版本新增了3个英雄天赋。

- [[talent:135978@AJwCCA]] 使 [[spell:77758]] 有几率向你的目标施放一个 [[talent:103278]]。
- [[talent:135977@AJwCCA]] 使 [[talent:114700]] 将你造成的 奥术 伤害提高10%。
- [[talent:135976@FJQA-thBLIA]]
  
  - 使 [[talent:103191]] 的伤害提高10%
  - 使 [[talent:114700]] 对你的主要目标造成的伤害提高30%





## 天赋



### [[talent:123301]]

:::talents **守护 德鲁伊** 团队副本 [[talent:123301]] 配装
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 何时使用此专精

除非另有说明，这是任何首领战的默认配装。你需要根据战斗所需的团队功能性来调整职业天赋树。为了让你更轻松，各首领专属天赋配装可在 **团队副本** 部分查看。

#### 改变游戏玩法的天赋

探索专精和职业天赋树中所有显著改变你玩法的天赋。本节提供了这些天赋及其应用的简明概述。如需更详细的了解，请查看下方的工作循环和**深度解析**部分。

##### 专精树

- [[spell:377811]]
  
  - 使你额外获得一层 [[spell:22842]] 充能，并根据你已损失的生命值提高治疗量。这对冷却管理和额外治疗都非常出色。
- [[spell:204053]]
  
  - 使维持 [[spell:77758]] 层数的同时也能提高你造成的伤害，并提供防御价值。
- [[spell:393414]]
  
  - 当你消耗怒气时，会为 [[spell:102558]] 提供冷却缩减

##### 职业树

- [[talent:103309@AJwCCA]]:
  
  - 确保在单目标战斗中使用 [[spell:768]] 之前先切换过去，以便施加 [[spell:274837]]。
- [[talent:103326]] 允许你切换到 [[spell:768]] 再切换回 [[spell:5487]] 而不损失一个 GCD：
  
  - 在 [[spell:5487]] 中使用 [[talent:103277@FAQAKFjB]] 会将你变为 [[spell:768]]。
  - 在 [[spell:768]] 中使用 [[spell:33917]] 会将你变回 [[spell:5487]]
  - 每当你打算使用 [[talent:103309@AJwCCA]] 时都要使用它。
- [[spell:377847]]
  
  - 这个技能有 120 秒冷却时间，当你的生命值降到 45% 以下时会触发一个 [[spell:22842]]。需要注意的是，它会覆盖当前任何激活的 [[spell:22842]]，也可能被任何新施加的 [[spell:22842]] 覆盖。 
    
    - 随时留意冷却时间并避免重叠非常重要。
    - [[talent:128586]] 将冷却时间缩短至 90 秒




### [[talent:123295]]

:::talents **守护 德鲁伊** 团队副本 [[talent:123295]] 配装
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

#### 何时使用此专精

这是 团队副本 配装的 [[talent:123295]] 版本。

为了让你的游戏体验更轻松，**团队副本** 部分提供了针对各个首领的专用天赋配置。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 职业树

- **新增**
  
  - [[talent:103203]]
  - [[talent:103198]]
- **移除**
  
  - [[talent:103223]]
  - 从 [[talent:103226]] 中移除1点

##### 英雄天赋

**已将**  更改为 [[talent:123295]]。更多信息请访问上方的 **英雄天赋** 部分。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:77758]] 有20%的几率使你的下一个 [[spell:33917]] 造成的伤害提高100%。
- **4件套：** [[spell:77758]] 会召唤3根荆棘，每根刺穿一个目标造成自然伤害，并对附近最多5个敌人造成额外的自然伤害，同时使 [[spell:102558]] 的持续时间延长0.5秒，最多延长5秒。



#### [[talent:123295]]

##### 起手爆发

- 开场的目标是尽快施放 [[spell:192081]]，以便尽早激活持续性的防御效果。

:::rotation **守护 德鲁伊** [[talent:123295]] 团队副本中的开场
```json
{
  "source_code": "IoFEKI0iaAQABwgQ--SAFgACi0xAFgABeCZAQwQABwprJAREgQyBeMBAAAAAC1HhBcAFBIUUuLAAZ4DJ9RIAAAAAAI0laA"
}
```
1. [[spell:6795]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:1252871]]
7. [[spell:33917]]  [[spell:192081]]
8. [[spell:77758]]
9. [[spell:33917]]
10. [[spell:6807]]
:::

##### 优先级列表

请务必牢记这份清单，除非某些首领或场景需要你保留这里列出的一些技能

1. 在冷却时使用[[talent:114700]]和[[spell:102558]]，除非在战斗后期需要将其留作防御用途。
2. 激活 野性守护 当[[spell:77758]]和[[spell:33917]]都在冷却时。
3. 在冷却时使用[[talent:135336]]。
4. 在[[talent:135336]]激活时，在2层充能时使用[[spell:33917]]。
5. 确保在主动坦克期间保持至少1层[[spell:192081]]持续生效。根据预期的伤害承受量，你可能需要叠到更高的层数。
6. 在2层充能时使用[[spell:33917]]。
7. 保持[[spell:77758]]处于冷却转好就用的状态。
8. 当怒气高于80时，将怒气用于[[talent:103191]]以获得[[talent:135490]]的收益。使用[[spell:33917]]。
9. 使用[[talent:103191]]。
10. 将[[spell:27554]]作为填充技能使用。




#### [[talent:123301]]

##### 起手爆发

- 起手的目标是尽快施放[[spell:192081]]，以便尽早启动主动防御。随后，消耗[[talent:117206]]的触发效果，并让产生怒气的技能保持在冷却中。

:::rotation **守护 德鲁伊** [[talent:123301]] 团队副本中的开场
```json
{
  "source_code": "IoYAQogQLqBABEADC57LBUACIISHDUACE4JkBABDBEAnumAERACJH4xEAAAAAIUfEGwBUEgQR5uAAkhPJYBzAIUB9aQRC4AUQFwhgJw2tJgMXIwBnJAj7JQmGOAFfQgcDMgOVSgSxYQ9Mcw9McQIuMxCCA"
}
```
1. [[spell:6795]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:1252871]]
7. [[spell:33917]]  [[spell:192081]]
8. [[spell:77758]]
9. [[spell:33917]]
10. [[spell:441605]]
:::

##### 优先级列表

请务必牢记这份清单，除非某些首领或场景需要你保留这里列出的一些技能

1. 在冷却时使用[[talent:114700]]和[[spell:102558]]，除非在战斗后期需要将其留作防御用途。
2. 激活 野性守护 当[[spell:77758]]和[[spell:33917]]都在冷却时。
3. 在冷却时使用[[talent:135336]]。
4. 在[[talent:135336]]激活时，在2层充能时使用[[spell:33917]]。
5. 确保在主动坦克期间保持至少1层[[spell:192081]]持续生效。根据预期的伤害承受量，你可能需要叠到更高的层数。
6. 使用 [[talent:117206]]。
7. 在2层充能时使用[[spell:33917]]。
8. 保持[[spell:77758]]处于冷却转好就用的状态。
9. 当怒气高于 80 时，将怒气用于 [[talent:103191]] 以受益于 [[talent:135490]]。
10. 使用 [[spell:33917]]。
11. 使用[[talent:103191]]。
12. 将[[spell:27554]]作为填充技能使用。





### 防御技能冷却

- [[spell:22812]]
  
  - 这是你冷却时间较短的主力防御技能。在走进首领、小怪或任何会造成伤害的东西时开启它绝不是坏事，而且由于冷却时间短，如果你需要一个减伤技能，它是你首先按下的防御技能。
- [[spell:61336]]
  
  - 你最强大的（提供 50% 伤害减免）也是持续时间最短的防御技能，持续 6 秒。明智地选择何时使用这个防御技能，但也不要囤着 2 层充能不用。留 1 层充能应对紧急情况总是好的，但囤着 2 层就是很大的浪费。
- [[spell:22842]] 
  
  - 你的大型自我治疗技能。你可以主动使用它，也可以在受伤后反应式使用，唯一重要的是你要尽最大努力发挥它的全部潜力。不要仅仅因为它 ready 就使用，如果你只是受到一些轻微伤害。是的，这个法术冷却时间很短，但如果你在任何受伤时都倾向于一直用它，你可能会在承受一次大型坦克伤害后发现没有任何充能了。总体而言，在任何坦克机制之后或聚怪时使用它是正确的做法，因为它有助于在你的其他防御技能和 [[spell:192081]] 生效之前把你的血量拉起来。
- [[spell:192081]] 
  
  - 你的主动减伤和怒气消耗技能。更多细节请查看**深度解析**。

### 化身：乌索克的守护者

- [[spell:102558]] 或 [[spell:50334]] 有很多用途，既可以作为输出冷却技能，也可以作为防御冷却技能。因此，通常情况下冷却好了就用。只有在特殊情况下才需要保留它，因为留着不用会让你损失大量收益。
  
  1. 它是一个强力的防御技能，可以帮你扛过一波伤害爆发。
  2. 保留它会导致 [[spell:393414]] 的冷却缩减进一步被浪费，所以一定要记得按这个按键。
  3. 它的进攻性收益也不容小觑。

## 深度解析

这篇深度解析讲解了 **守护 德鲁伊的** 生存能力**方面**

### 铁鬃的优化

[[spell:192081]]是你的怒气消耗技能和主动减伤。按下后会在 7 秒（若有 [[talent:135568]] 则为 9 秒）内基于你的敏捷提高你的护甲。需要注意的是，多次施放 [[spell:192081]] 会相互重叠并叠加，但持续时间不会增加、刷新或延长。

- 1. [[spell:192081]] 在第 0 秒按下
- 2. [[spell:192081]] 在第 3 秒
- 3. [[spell:192081]] 在第 5 秒
  
  - 现在你拥有 3 层 [[spell:192081]]，三层的持续时间各不相同，会像下方时间轴图标所示的那样在不同时间结束。
- 12 秒后，你将不再拥有任何 [[spell:192081]] 层数，尽管你在战斗的前 5 秒里按了 3 次。
- 理解 守护 德鲁伊 的主动减伤机制至关重要，因为你的护甲值以及相应的伤害减免会随着当前生效的 [[spell:192081]] 层数不断变化。

这里有一张图片展示 [[spell:192081]] 的运作方式。

:::timeline **守护 德鲁伊** 团队副本 铁鬃的优化
```json
{
  "source_code": "HYFu2Z3_UAQAEww_eAAAHAQndi4AAoAA_DHAFAADA8Pg_3AAUAABCEl7CAAACEl7CMQBGAQBFYABNAQBZAwBF0AOKAgAR5uAMAgAR5uAUAQA"
}
```
总时长：20 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:192081]] | 上轨 |
| 3 秒 | [[spell:192081]] | 上轨 |
| 5 秒 | [[spell:192081]] | 上轨 |
| 7 秒 | [[spell:192081]] | 下轨 |
| 10 秒 | [[spell:192081]] | 下轨 |
| 12 秒 | [[spell:192081]] | 下轨 |
| 13 秒 | [[spell:192081]] | 上轨 |
| 20 秒 | [[spell:192081]] | 下轨 |
:::

### 铁鬃 护甲

- [[spell:192081]] 护甲正在减少你受到的物理伤害，在大多数情况下这只是近战挥击。流血和魔法 DOT 不受护甲影响。
- 物理伤害减免有 85% 的硬上限。这相当于同时保持约 7-8 层 [[spell:192081]]（有 [[spell:360827]] 时约 4 层），因此达到该数值后再无脑刷 [[spell:192081]] 是无用的。
- 然而，由于护甲缩放机制，持续保持 1 层 [[spell:192081]] 比瞬间用掉 3 层然后没有任何层数拥有更高的整体防御价值。你叠加的护甲越多，每一层新增护甲的效果就越低。
- 因为你的物理伤害减免很高，所以在应对魔法伤害、流血和其他 DOT 时会吃力得多。对于这些伤害，正确使用 [[spell:22842]] 非常重要。

### 狂暴回复

- [[spell:22842]] 是你作为守护 德鲁伊 唯一的自疗技能，对保命非常重要。
- 一般来说，[[spell:22842]] 的冷却时间相对较短，只有36秒（受急速影响降低），这让你很容易一受到伤害就想按它。这往往会导致问题：之后你受到的伤害太大，治疗者无法覆盖，或者你需要一种快速回血的方式。使用它时，留意接下来可能发生的情况非常重要。
- 此外，你还需要决定如何使用 [[spell:22842]]：是主动使用，在应对机制前保持满血；还是在机制之后被动使用，把自己奶回安全血线。通常，这完全取决于你当前面对的战斗所造成的伤害量。如何抉择来自于游戏经验和临场判断。
- 当你使用 [[spell:377811]] 时，你有2层 [[spell:22842]]，一般来说最好始终保留一层以备紧急情况，另一层则更自由地使用，这样就不会浪费冷却回复。
- 关于 [[spell:22842]] 的注意事项：
  
  - [[spell:377847]] 不会消耗你的 [[spell:22842]] 的层数，但如果你在它触发前一刻按下，会覆盖掉当前的那个 + 如果你使用 [[spell:22842]]，而它在你的触发效果覆盖了你之前按下的那个之后触发，基本上就浪费了大量价值。
  - [[spell:102558]] 会返还 [[spell:22842]] 的全部两层，并使其在持续时间内完全没有冷却。记住这一点，它可能会救你一命。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 梦隙、虚空尖塔与 Maiden's Fate（MoQ）

以下提示适用于 **英雄难度首领**，以及如何尽可能有效地在其中生存下来。本节推荐的配置会帮助你在每个遭遇战中存活，但不一定能给你最高的伤害输出。

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **守护 德鲁伊 团队副本 内克扎莉**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 坦克机制

- 这场战斗的主要坦克机制是蚀空打击——首领每次近战攻击以及施放 [[spell:1284103]] 时都会施加的一种减益效果。
- 在 [[spell:1284103]] 期间，首领会向当前坦克发射幽灵回响，额外施加蚀空打击层数。这些回响在首次接触到任意玩家时会爆炸，对团队造成降低后的 
  
  - 当你成为该机制的目标时，走出团队，并确保你和首领之间没有任何人，以免他们过早触发回响。否则，回响会对团队造成过多伤害。
  - 每次 [[spell:1284103]] 施放完毕后进行嘲讽换坦。
- 此外，首领还会召唤成群的不安阿曼尼——务必将首领拉到它们旁边，以便更好地进行顺劈。
- 在过渡阶段，当前坦克会成为一次群体分担——[[spell:1289855]] 的目标。尽量将它放在尽可能多的不安阿曼尼尸体上，利用 [[spell:1289875]] 将其烧毁，防止它们再次苏醒。




### 陵寝哨兵

:::talents **守护 德鲁伊 团队副本 陵寝哨兵**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 坦克机制

- 由于 [[spell:1290189]]，首领们必须始终保持至少40码的距离。在每个阶段开始时，将首领们移到房间的不同两侧使其分开。
- [[spell:1284458]] 和 [[spell:1284487]] 是各个首领的叠加坦克减益效果。在 [[spell:1284588]] 期间，每当首领们在房间中央相遇时，务必进行嘲讽换坦以重置你的层数。
  
  - [[spell:1284487]] 额外会在到期时产生一个大型血泊。如果可能，请务必将其放置在房间的边缘。
- 不要将 乌拉特克之息 坦克在现有的血泊太近的位置，这样 [[spell:1284251]] 就不会在血泊中生成，近战职业就可以安全地攻击它。




### 迷失的探险者

:::talents **守护 德鲁伊** **团队副本 迷失的探险者**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 坦克机制

- 由于 [[spell:1297645]]，三个首领彼此都不能处于 30 码以内——始终让其中一个首领远离另外两个。
- 商人盖博 只会在房间里游荡，不会跟随或攻击其仇恨目标。它也没有任何坦克机制。
- 书卷贤者伊库 会对其当前目标施放 [[spell:1295854]]——一连串冰碎片，每片造成魔法伤害，并使后续碎片受到的伤害提高，持续 80 秒。
- 大副纳玛 每次攻击都会对其目标施加 [[spell:1291929]]，使该目标受到的物理伤害提高，持续 30 秒。
- 这场战斗中坦克的职责是在Scrollsage伊库和 大副纳玛 之间来回换坦，绝不让 [[spell:1295854]] 连续两次施放在同一目标身上，并尽可能频繁地重置 [[spell:1291929]]，同时始终让其中一个首领距离足够远，以防止 [[spell:1297645]] 被施加。




### 瓦什尼克

:::talents **守护 德鲁伊 团队副本 瓦什尼克**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 坦克机制

- 房间两侧放置着 3 座喷泉：鲜血之泉、火焰和 暗影。整场战斗中，首领会通过 [[spell:1283164]] 激活最近的两座喷泉，获得它们的力量并召唤一些小怪。
  
  - 每座喷泉被激活后，会使下一次激活强化 1.5 分钟。
  
  
  
  - 作为坦克，你的职责是通过在每次 [[spell:1283164]] 施放前将首领拉到下一座喷泉处，绝不让首领连续激活相同的两座喷泉。
  - 务必将首领定位在从喷泉出来的小怪上方，以便更好地顺劈。但是，要小心不要过快杀死所有火焰小怪，因为它们死亡时会施加可叠加的 [[spell:1285979]]。
- 瓦什尼克的坦克打击技能是 [[spell:1280935]]，每次施放后进行嘲讽换坦。




### 斯索拉克

:::talents **守护 德鲁伊 团队副本 斯索拉克**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 战斗机制

- [[spell:1277025]] 是一组坦克正面机制的组合，由 2 次 [[spell:1277002]]、2 次 [[spell:1277027]] 和 1 次 [[spell:1287072]] 组成，以随机顺序施放。
  
  - [[spell:1277002]] 是一个正面锥形范围技能，造成高额物理伤害并跟随当前坦克。务必将其指向**远离团队**的方向。
  - [[spell:1277027]] 是一个正面锥形范围技能，会施加一个强力的魔法持续伤害效果，其效果会被锥形范围内被击中的人数所分摊减弱。务必将此技能指向团队的一半人马，让他们来分担。
  - [[spell:1287072]] 会在首领周围生成一群龙卷风，并在施法结束时将其向外发射。当此技能发生时，确保你不在首领下方，并躲避龙卷风。
  - 在英雄和史诗难度下，首领会以随机顺序施放这些技能。由于每个正面锥形技能都会施加来自该技能的伤害提高效果，务必确保同一个坦克绝不承受 2 次相同技能。请记住，你可以在施法期间嘲讽，让首领将正面锥形技能对准你。
- 每次施放 [[spell:1306120]] 都会在首领周围生成 [[spell:1305998]] 个水坑。务必将首领拉到房间边缘，理想情况下是与 [[spell:1285732]] 刷新点相对的一侧，这样水坑就会被风吹出房间边缘。
- 除此之外，斯索拉克 每次近战攻击都会施加一层 [[spell:1282869]]，使目标受到的物理伤害提高。在每次 [[spell:1277025]] 连击后进行嘲讽换坦就足以重置层数。




### 双牙

:::talents **守护 德鲁伊** **团队副本 双牙**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

#### 通用机制

- 整场战斗的核心在于管理 [[spell:1290336]] 层数
  
  - [[spell:1291404]]、[[spell:1291478]]、被毒波命中或吸收 [[spell:1289201]] 都会施加一层 [[spell:1290336]]。
  - 在英雄难度下达到 10 层或史诗难度下达到 9 层会立即死亡。
  - 尽可能躲开毒波，同时控制好吸收 [[spell:1289201]] 的数量，以避免该减益效果达到最大层数，这一点至关重要。

#### 坦克机制

- 当你主动坦住的首领脱离近战范围时，它会施放 [[spell:1295107]] 或 [[spell:1295113]]，所以千万不要离开近战范围；如果发现自己离首领太远，请使用一个大型个人减伤。
- 维克苏尔 的坦克技能是 [[spell:1289192]]，造成自然伤害并将你击退 5 秒。
  
  - 它还会在你周围生成 [[spell:1289201]]。这些需要由玩家吸收，以免爆炸后给所有人叠加一层 [[spell:1290336]]。
  - 每次被击中都会施加 [[spell:1310360]]，因此每次 [[spell:1289192]] 施放后都要进行嘲讽换坦。
  - 注意击退效果，尤其是毒波即将到来的时候！
- 伊斯拉兹 会施放 [[spell:1288538]]，击退靠近首领的玩家并生成 3 个吸收区域。
  
  - 每个区域会造成高额物理伤害，并使下一个区域造成的伤害提高 33%。如果无人吸收该区域，它会对全团造成伤害并将所有人击飞。务必在每组 [[spell:1288538]] 之间进行嘲讽换坦，以重置伤害增加的层数。
  
  
  
  - 这些区域以随机顺序生成，并且必须按照生成的先后顺序依次吸收。在这一技能进行时，请密切关注区域的生成并记住生成顺序。首领在触发下一个区域前会短暂地面朝该区域的方向，所以如果你记不住生成顺序，可以参考首领的朝向。
  - 每隔一次 [[spell:1288538]] 施放都会与毒波重合——吸收 [[spell:1288538]] 时务必确保不被毒波击中。
  - 小心该机制开始时的击退，因为它可能把你推入袭来的毒波或某个 [[spell:1289201]] 中。




### 盘绕祭坛

:::talents **守护 德鲁伊 团队副本 盘绕祭坛**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

#### 第一阶段

- 该阶段中只有 祖尔加 处于激活状态。
- 他会施放 [[spell:1299960]]，在该阶段中生成多个 [[spell:1282403]] 法球。法球存在期间会持续对全团造成 范围伤害 伤害，玩家可以撞入法球来拾取并移动它们。
- [[spell:1299684]] 是一个指向当前坦克的正面锥形技能，造成物理伤害，并摧毁任何被它命中的 [[spell:1282403]]。
  
  - 它还会使下一次 [[spell:1299684]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
- 该阶段的目标是让团队将 [[spell:1282403]] 法球聚集到一起，然后用 [[spell:1299684]] 将其摧毁。
- 此外，每次施放 [[spell:1282487]] 都会强化首领接下来的 23 次近战攻击，附带 [[spell:1300322]]，对坦克造成额外的自然伤害。
  
  - 当首领身上有 [[spell:1300322]] 层数时，务必提前开启减伤技能。

#### 第二阶段

- 该阶段中只有 妖术领主玛拉卡斯 处于激活状态。
- 他会施放 [[spell:1285640]]，对被选中的玩家进行精神控制，并且每当精神控制被打断时，每名玩家会生成 2 个 [[spell:1285842]]。
  
  - 这些具象会锁定随机玩家并向其移动，除非被锁定的玩家回头面对该具象。
- 与第一阶段的 [[spell:1299684]] 类似，[[spell:1286620]] 是一个指向当前坦克的正面锥形技能，造成暗影伤害，并摧毁任何被它命中的 [[spell:1285842]]。
  
  - 它还会使下一次 [[spell:1286620]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
  - 此外，它会施加 3 层 [[spell:1286837]]，每层会生成一个灵魂碎片，必须拾取灵魂碎片才能移除对应的层数。如果在减益效果到期前没有清空层数，受影响的玩家会立即死亡。
  - 在每次坦克正面锥形技能之后，务必格外注意迅速找到并收集所有灵魂碎片。
- 被 [[spell:1286895]] 命中同样会施加 3 层 [[spell:1286837]]。千万不要掉以轻心！

#### 阶段转换

- 马拉克拉斯在施放 [[spell:1287685]] 期间受到 100% 的额外伤害。务必为间歇阶段保留你的 [[talent:103201]]！
- 不要让任何马拉克拉斯之碎片靠近首领，通过吸收它们来防止其治疗首领。
  
  - 吸收每块碎片会对全团造成 范围伤害 伤害，所以不要吸收得太快，给你的治疗者们一些反应即将到来伤害的时间。

#### 第三阶段

- 在该阶段中，祖尔加 和马拉克拉丝同时激活，并结合了第一阶段和第二阶段的技能。
- 该阶段中 [[spell:1299960]] 和 [[spell:1285640]] 都会出现，这意味着 [[spell:1282403]] 和 [[spell:1285842]] 都需要由坦克的正面锥形技能来清除。
- 该阶段的坦克正面锥形技能是 [[spell:1307279]]，造成暗影伤害，摧毁任何被它命中的 [[spell:1282403]] 和 [[spell:1285842]]，并施加 3 层 [[spell:1286837]]。
  
  - 别忘了收集你的灵魂碎片，并在每次锥形技能后进行嘲讽换坦！
- [[spell:1298381]] 是第一阶段 [[spell:1282487]] 的强化版本。
  
  - 在该阶段中，被强化的近战攻击还会额外施加可叠加的  暗影持续伤害。当层数较高时，请使用大型减伤技能。




### 乌拉特克

:::talents **守护 德鲁伊 团队副本 乌拉特克**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::




### 尼姆瑞莎·唤波者

:::talents **守护 德鲁伊 团队副本 尼姆瑞莎·唤波者**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

#### 通用机制

- 首领会用刺骨的 冰霜 随机标记玩家，在其脚下生成 冰霜 法球。
  
  - 这些法球必须在爆炸并团灭团队之前被吸收。
  - 吸收法球会施加一个可叠加的减益效果，使吸收 冰霜 法球时受到的伤害增加，所以不要一次吸收太多。
  - 每次吸收法球还会对全团造成 范围伤害，因此不要吸收得太快，给治疗者一些时间来应对即将到来的伤害。
- 鱼人会不时从水中出现，并开始走向房间中央的气泡。
  
  - 不要让它们到达气泡处，并尽可能将首领移动到它们上方，以便更好地进行顺劈。

#### 坦克机制

- 这场战斗中坦克专属的机制是冰刃连斩——一系列魔法斩击，每一斩都会增加后续斩击的伤害。
  
  - 每次施放时使用一个防御技能，并在每次结束后换坦嘲讽。





## 属性优先级

作为 团队副本 首领战斗中的一名 **，了解你的副属性优先级以及实现最佳表现所需的第三属性守护 德鲁伊**。欲了解更多详细信息，请访问 **[属性与属性值](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **守护 德鲁伊** 团队副本 属性
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 可有效降低“**范围伤害**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外治疗。
- **加速** - 小众的第三属性，但可能非常有用，过去也曾多次证明其价值。它能让应对某些机制变得轻松许多。

总的来说，**吸血** 对坦克来说非常强力，尤其是在范围伤害环境下，它可能是你能拥有的最好的属性。  
闪避很不错，但大多数时候坦克并不太需要在普通的范围伤害技能下挣扎求生。

## 装备



### 最佳配装

| 部位 | 物品 | 获取位置 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | 乌拉特克 |
| 项链 | [[item:268265@BERAAgGA-z64PrDj1kjAYFA]] | 乌拉特克 |
| 肩部 | 将 [[item:251223@DgQAAgGAJk7IoAOF]] 转换为 [[item:271526@DgQBAgGA1k7IoAOFwVVP]] | 虚空之痕竞技场 的催化器 |
| 披风 | [[item:268253@BgQAAgGACKAWBA]] | 盘卷祭坛 |
| 胸部 | [[item:271531@DgQAAgGAJk7IoAOF]] | 套装 / 催化器 |
| 腕部 | [[item:244576@FiQAAgGAWA8ciqj_sO3WzSB]] | 制造业 |
| 手套 | 将 [[item:251124@BgQAAgGACKgTBA]] 转换为 [[item:271529@BgQBAgGACKgTBQP1DA]] | 密谋小径 的催化器 |
| 腰带 | [[item:268256@BiQAAgGA-z6IoAYF]] | 盘卷祭坛 |
| 腿部 | 将 [[item:268225@DgQAAgGAhu7IoAYF]] 转换为 [[item:271527@DgQAAgGAhu7IoAOF]] | 盘卷祭坛 的催化器 |
| 脚部 | [[item:244569@HgQAAgGAWA8ciqT84OCKwSB]] | 制造业 |
| 戒指 1 | [[item:268266@DkQAAgGAvk74Prj_sOCKgTB]] | 尼姆瑞莎·唤波者 |
| 戒指 2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | 诸王之眠 |
| 饰品 1 | [[item:270164@BgQAAgGACKgTBA]] | 迷失的探险者 |
| 饰品 2 | [[item:270173@BgQAAgGACKAWBA]] | 盘卷祭坛 |
| 武器 | [[item:268215@DgQAAgGA9k7IoAYF]] | 乌拉特克 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取位置 |
| --- | --- | --- |
| 头部 | [[item:273791@BgQAAgGACKQQBA]] | 毒牙祭坛 |
| 颈部 | [[item:251173@BgQAAgGACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:251223@BgQAAgGACKQQBA]] | 虚空之痕竞技场 |
| 披风 | [[item:193763@BgQAAgGACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251226@BgQAAgGACKQQBA]] | 虚空之痕竞技场 |
| 护腕 | [[item:251135@BgQAAgGACKQQBA]] | 密谋小径 |
| 手套 | [[item:251124@BgQAAgGACKQQBA]] | 密谋小径 |
| 腰带 | [[item:159301@BgQAAgGACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:159313@BgQAAgGACKQQBA]] | 诸王之眠 |
| 靴子 | [[item:251153@BgQAAgGACKQQBA]] | 纳洛拉克的洞穴 |
| 戒指 1 | [[item:273792@BgQAAgGACKQQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:159459@BgQAAgGACKQQBA]] | 诸王之眠 |
| 饰品 1 | [[item:250228@BgQAAgGACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250215@BgQAAgGACKQQBA]] | 密谋小径 |
| 武器 | [[item:158370@BgQAAgGACKQQBA]] | 塞塔里斯神庙 |





### 饰品

以下是从地下城和团队副本中可获得的后毕业阶段饰品的排名。请注意，上文推荐的饰品是以伤害最优为目标的；如果你不在乎伤害、只想活下去，建议使用类似 [[item:270160@BgQAAIEACKgTBA]] 这样的饰品。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270173@BgQAAgGACKAWBA]] |
| **A级** | [[item:270175@BgQAAgGACKAWBA]]  <br>[[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270165@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B级** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C级** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:270173@BgQAAgGACKgTBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **垃圾级** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### 美化饰品

- 2 个 [[item:240167]] 是你的最佳毕业选择。
  
  - 为你和你的队友提供随机主属性触发效果。
  - 最好制作在护腕和靴子上；不过，它也可以制作在任何一件护甲部位上。

在赛季初期，或者当你无法获得 334 或 344 装等的武器时，一个不错的选择是制作一把 331 装等的武器[[item:245876]]，而不是用 [[item:240167]] 制作散件。一旦你能获得 334 或 344 的武器，这个选择相比 2 个 [[item:240167]] 就会失去价值。

- [[item:245876]]
  
  - 被动提供次要属性 ，具体取决于你正在与之作战的怪物类型。
  - 必须制作在武器上。

#### 剩余的火花

- 制造业装备为 331 装等，而普通装备的最高装等为 334；因此，除了 2 件装饰品之外，装备制造业装备会有少量损失，除非你在该部位没有其他高装等的装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药水（瓶）**
  
  - [[item:241324]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器磨刀石/涂油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@BQAAAgGAaB]]
- **宝石插槽**
  
  - [[item:240967]] *—— 唯一，每种颜色的宝石各用一颗，以强化你的亵渎石。*
    
    - [[item:240910]]
    - [[item:240914]]
    - [[item:240890]]
    - [[item:240900]]

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 护腕 | [[item:275707@BAAAAIE]] |
| 腰带 | [[item:275707@BAAAAIE]] |
| 腿部 | [[item:244641@BAAAAIE]] |
| 靴子 | [[item:243983@BAAAAwQA]] |
| 戒指1 | [[item:244015@BAAAAIE]] |
| 戒指2 | [[item:244015@BAAAAIE]] |
| 武器 | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **守护 德鲁伊** **团队副本**
```json
{
  "source_code": "IQFZoBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *你可以从宏伟宝库商人处购买[[item:275707@BAAAAIE]] ，为你的头盔、护腕和腰带添加插槽。*

## 种族

为了在团队副本中极限优化 **守护 德鲁伊**，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:255654]] *-- 高岭牛头人*
  
  - [[spell:255654]] 可以用来眩晕一群敌人，即使目标已处于眩晕递减状态也可以使用，因为它被视为击倒效果，在这些情况下非常有用。
  
  
  
  - 拥有 [[spell:255659]] 和 [[spell:255658]] 等强大的生存被动技能。
- [[spell:287712]] *-- 库尔提拉斯人*
  
  - [[spell:287712]] 可以被移动用来把敌人击出危险位置，但用途有限。
  
  
  
  - 凭借[[spell:291628]]和[[spell:291417]]，拥有非常优秀的防御被动。
- **[[spell:20549]]** *-- 牛头人*
  
  - **[[spell:20549]]** 会很强大，因为你没有其他方式来眩晕敌人。可惜它最多只能命中5个目标，所以要记住这一点。
  
  
  
  - 除此之外，你还能获得不错的被动效果 [[spell:20550]]、[[spell:154743]] 和 [[spell:20551]]。
- [[spell:26297]] *-- 巨魔* 
  
  - 巨魔是目前爆发伤害的最佳选择，因为你可以在化身期间使用[[spell:26297]]来获得额外的急速，但如果想提高生存能力，与其他选项相比这是最差的选择。

### 推荐

- 高岭牛头人 和库尔提拉斯人 的种族天赋在DPS方面并非整体最优，但作为一名 **守护 德鲁伊，他们的生存能力技能在团队副本中相当不错。**
- 暗夜精灵 对DPS非常有利，但在 团队副本 中没有其他实用的收益，作为一名 **守护 德鲁伊。**

## 宏

了解**守护 德鲁伊**的推荐宏，并观看一段关于为你的角色制作简单宏的简短视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
嘲讽宏 --- *此宏会对你的当前目标或鼠标悬停目标施放[[spell:2649]]（在拉怪时非常方便）*

```wow-macro
#showtooltip 低吼
/cast [@mouseover,exists,harm][@target,exists,harm] 低吼
```

首领1嘲讽 --- *对首领1施放[[spell:2649]]*

```wow-macro
/cast [@boss1] 低吼
```

2号首领嘲讽 --- *对2号首领施放[[spell:2649]]*

```wow-macro
/cast [@boss2] 低吼
```

:::

:::details 鼠标指向宏
鼠标指向乌索尔旋风/群体缠绕 *--- 如果已选择相应天赋，则对鼠标光标位置施放[[spell:102793]]* *，并对鼠标指向目标施放[[spell:102359]]；如果没有鼠标指向目标，则改为对当前目标施放。*

```wow-macro
/cast [@cursor] 乌索尔旋风
/cast [@mouseover,exists] [] 群体缠绕
```

鼠标指向[[spell:2782]] *--- 如果没有可用的鼠标指向目标则对当前目标施放，如果没有目标则对你自己施放。*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] 清除腐蚀
```

鼠标指向愈合 --- *对鼠标指向目标或你自己施放[[spell:16561]]。*

```wow-macro
#showtooltip 愈合
/cast [@mouseover,exists][] 愈合
```

鼠标指向[[spell:29166]]

```wow-macro
/cast  [@mouseover] 激活
```

鼠标指向野性冲锋 *--- 对鼠标指向目标或当前目标施放[[spell:16979]]。*

```wow-macro
#showtooltip 野性冲锋
/cast [@mouseover][] 野性冲锋
```

鼠标指向安抚 *--- 对鼠标指向目标或当前目标施放[[spell:2908]]。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] 安抚
```

鼠标指向战斗复活 --- *这使你可以将[[spell:20484]]*以鼠标指向方式用在你的团队框体上

```wow-macro
#showtooltip
/cast [@mouseover,help,dead][] 复生
```

:::

:::details 焦点目标宏
焦点打断 --- *对焦点目标施放 [[spell:106839]]*

```wow-macro
/cast [@focus] 迎头痛击
```

鼠标指向焦点 --- *此宏将鼠标指向的目标设为焦点*

```wow-macro
/focus [@mouseover]
```

:::

:::details 实用宏
Cancelaura BoP --- *这个宏会取消你身上的 [[spell:1022]]，在与圣骑士组队时非常实用*

```wow-macro
/cancelaura 保护祝福
```

:::

:::

## 插件

下方是作者的 **守护 德鲁伊** 的用户界面截图，其中说明了使用了哪些插件，以及如何在团队副本中利用这些插件让你的游戏体验更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/pala-1-1024x623.png>)

**守护 德鲁伊** 用户界面

:::accordion
:::details 插件
- EllesmereUI
  
  - 一款以易用性为核心设计的用户界面，附带标准界面中不包含的额外功能。
- **BigWigs** 
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些迷你插件旨在为某一个特定的 团队副本 战斗触发警报消息、计时条、音效等内容。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
#### 德鲁伊

- 厚实毛皮的吸收量提高25%。
- 野性之心 强化的 野性成长 治疗量提高25%。
- 撕碎和 猎豹形态 横扫 伤害提高10%。

- 艾露恩钦选者
  
  - 天涯共银辉 – 明月普照 现在使你从对受影响敌人造成的伤害中吸取 12%（原为 10%）。

#### 守护

- 血腥毛皮已被重新设计 – 铁鬃 有几率使你的下一次 重殴、挫志或撕碎免费。重殴、挫志或撕碎有几率使你的下一次 铁鬃 免费。
- 顶尖天赋：野性 ⟦WOWTERM_00003⟫ 已被重新设计 –
  
  - 第 1 阶：消耗怒气有 10% 的几率唤醒一个 守护之魂，持续 8 秒，当你施放 痛击 或 裂伤 时它会攻击附近的一名敌人。
  - 第 2 阶：裂伤、撕碎、挫志和 重殴 在 12 秒内额外造成 20%/40% 的自然伤害。你的精通提高 3%/6%。
  - 第 3 阶：当一个灵魂被唤醒时，痛击 和 裂伤 的冷却时间会被重置，并且在该灵魂陪伴你期间它们造成的伤害提高 30%。灵魂每次攻击时，你会额外产生 8 点怒气。施放 狂暴 或 化身：乌索克的守护者 后，获得 1 层野性 守护 充能：
    
    - 野性 守护：你的下一次撕碎、挫志或 重殴 施放必定唤醒一个灵魂。
- 所有伤害提高 8%。
- 荆棘吸收量提高 25%。
- 野火之后治疗量提高 25%。
- 明月普照 治疗量提高 25%。
- 朔望 使 明月普照 的冷却时间缩短 20 秒（ previously 为每个 奥术 技能 3 秒）。
- 乌索克 的 狂怒 提供一个相当于 痛击 和 重殴 伤害 35% 的吸收盾（ previously 为 30%）。
- 艾露恩的青睐 为你恢复 奥术 所造成伤害的 18%（ previously 为 15%）。
- 修复了梦境指引被通过 重焕活力 施放的重生错误消耗的问题。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我会随机被秒杀？
A：你很可能是因为按下了会使你脱离形态的按钮而离开了[[spell:5487]]，最常见的错误是在没有[[spell:158497]]触发的情况下按下[[spell:339]]和[[spell:8936]]。

:::

:::

---

### 致谢

作者：Tief

审校：**Meeres**

---

:::changelog 更新记录
**2026-08-08** 已更新至12.1版本

**2026-06-21** 已更新至12.0.7版本

**2026-04-26** 已更新至12.0.5版本

**2026-02-21** 已更新至12.0.1版本

**2026-01-18** 已更新至12.0版本

**2025-12-01** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-07-28** 已更新至11.2版本

**2025-06-18** 已更新至11.1.7版本

**2025-04-20** 已更新至11.1.5版本

**2025-02-25** 已更新至11.1版本

**2024-12-17** 已更新至11.0.7版本

**2024-10-27** 已更新至11.0.5版本

**2024-08-17** 已更新至11.0.2版本

**2024-07-28** 攻略撰写于11.0版本。



:::
