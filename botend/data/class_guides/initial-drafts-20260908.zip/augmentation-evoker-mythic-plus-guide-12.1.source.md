Welcome to the **Augmentation Evoker** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 3/5 · Average

Utility · 5/5 · Excellent

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Augmentation Evoker** Mythic+ Best in Slot
```json
{
  "source_code": "JAoAwDVwFc__BEQjkQggIEAAnk7AX16ACKgTBEQ6XQAAREAAE06AE06AMWjgCgVABsIJEIACBAwF5OggCgVABQgJEIAEBAQC5OggCwYNYFQAefBBAiQB0UwQAwYCvQQBqmwLIk8FEEgPAkSAvgjTBEAa7OAhIEAAYA8AnoaAkxyt1sUAB4IJEAACBAQB_AS2XQggAEAA3jbAeQhTBEgnqJQAkmAEFICBU9RGuAwVdwABdfRDYQBWBEA9iQQA2BwPBYHTYFQAJA8AEgQAAgXZDQqKEcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271499]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240900]] |
| 腿部 | [[item:271500]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:244009]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] | [[item:222584]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Augmentation** you have access to Duplicate, which summons a duplicate of yourself to aid you after casting [[spell:403631]].

**Rank 1:** [[spell:403631]] summons a duplicate of you for 20s, it casts [[talent:115498@FAgARegBviiB]], [[spell:357208]] and [[talent:115502@FAgARegBviiB]].

**Rank 2 - (1/2):** Any time you extend [[talent:115496@FAQAviiB]], you also extend your duplicate at 50% of the amount.

**Rank 2 - (2/2):** Any time you extend [[talent:115496@FAQAviiB]], you also extend your duplicate at 100% of the amount.

**Rank 3:** While your duplicate is active, your [[talent:115496@FAQAviiB]] grants 100% additional stats and [[talent:115502@FAgARegBviiB]] and [[talent:115498@FAgARegBviiB]] deal 25% increased damage.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-augmentation-mxr.webp>)

Duplicate

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115496@FAQAviiB]]
    
    - Now targets all dps players in your raid/group so the targeted buffing is mostly done with [[talent:115675@FAQAmxkB]] for it's passive effect.
  - [[spell:459725]]
    
    - Was changed so that ranking up [[spell:357208]] doesn't give you more damage increase so you most often cast it at Rank 1 now.
    - With 12.0.5 this was completely replaced by [[talent:126305]].
- **Class Tree**
  
  - [[talent:115617]]
    
    - Previously an **Augmentation** only talent that got moved to the Evoker class tree, makes you safer while using [[spell:357210]]!
  - [[talent:115669]]
    
    - Removed as a separate spell and is now tied with [[talent:115613]] as a less powerful effect.
- **Moved**
  
  - [[talent:115690]] 
    
    - This was removed from the Class Tree and moved to the DPS Spec Trees to replace the cooldown reduction talent, which means that you now have to pick the talent point there to have an interrupt at all, rather than just having a longer cooldown interrupt.

## Hero Talents

- [[talent:123331]] performs better in constant big AoE situations while [[talent:123334]] is the stronger choice everywhere else.



### [[talent:123334]]

- [[talent:117552]] turns [[spell:370553]] into a strong offensive cooldown that increases your Haste and cooldown recovery rate.
  
  - The increased Haste, movement Speed and cooldown recovery rate buff effect is reduced by 1% every second throughout the 30s duration.
  - The total reduced cooldown of your abilities is 4.65 seconds.
  - Grants [[talent:115520]] every 6 seconds with [[talent:135742]].
- [[talent:117545]] transforms your normal [[spell:358267]] into a Blink
  
  - Be cautious as this has a small delay.
  - This currently only works when you are on or close to solid ground, if you are too high up in the air it will become a normal [[spell:358267]].

- When timed correctly [[talent:117532]] can be used as a minor defensive cooldown whenever you are out of everything else.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:135743]]
  
  - [[talent:115665]] cooldown is reduced by 30 seconds
- [[talent:135742]]
  
  - Improves [[spell:361469]].
- [[talent:135741@FJQAnxzENIA]]
  
  - [[talent:117551@FJQAnxzENIA]] maximum damage or healing is increased by 40%.




### [[talent:123331]]

- [[talent:122279]]
  
  - [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] and [[talent:115502]] changes your next [[talent:115498]] into a [[talent:122279]] that strikes multiple targets or deals increased damage for each target less than 3.
  - [[talent:122279]] can stack up to 2 which means you can cast both empower abilities back to back.
- [[talent:117533]] 
  
  - Gets applied to the target of your [[talent:122279]] casts.
  
  
  
  - [[talent:117533]] does not pandemic which allows you to cast two [[talent:122279]] in a row without losing debuff uptime.
  
  
  
  - This also maximizes [[talent:117550]] and allows you to bring down the cooldown of  [[talent:115536]] to a range of 60-90s depending on how many targets you are fighting.

- [[talent:120123]] 
  
  - Restores one charge of [[spell:358267]].
  
  
  
  - This was nerfed to only restoring one charge instead of two in the **patch 12.0** so [[talent:117540]] can be a more viable option now in certain fights.

- [[talent:117538]]
  
  - Causes your [[talent:115536]] to always be aimed in front of your character and can now be steered.
  - This also makes [[talent:115536]] fly the entire duration unless you cancel it early by pressing the ability once more.
  - Be careful to not spam your [[talent:115536]] keybind as you might cancel it before it hits your target while still going on cooldown, I recommend casting it using a macro with /cast !Breath of Eons to make it non-cancellable and instead have /cancelaura Breath of Eons included in macros for your other spells for smoother gameplay.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:136053]]
  
  - While flying during [[talent:115536@FAQARegB]] 2 Dracthyr Commandos fly along you and damage nearby enemies with Pyres up to 8 times.
- [[talent:136052@AJQD]]
  
  - [[talent:122279]] hits 1 additional target.
- [[talent:136051]]
  
  - Essence abilities deal 15% additional damage.





## Talents



### [[talent:123331]]

:::talents [[talent:123331]] **Augmentation Evoker** In Mythic+
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MmZmZbmZGMYmZZGjhZ2AAAAAAAAYmBGGjpGzMzAAAAAzMjxMz2MzMwMbGDWglxwYZAMTEbYmZwMDGM",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MmZmZbmZGMYmZZGjhZ2AAAAAAAAYmBGGjpGzMzAAAAAzMjxMz2MzMwMbGDWglxwYZAMTEbYmZwMDGM"
}
```
:::

#### When to use this Spec

If you want to play [[talent:123331]], in Mythic+ each hero spec performs relatively close to each other.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:115496]]
  
  - Your gameplay as an Augmentation Evoker revolves around optimizing and extending this buff.
- [[talent:115675]]
  
  - A rotational spell that buffs your target with Crit chance and some additional damage output.
  
  
  
  - Has a chance to grant [[talent:115520]] with [[talent:115523]].
- [[talent:115536]]
  
  - Your major offensive cooldown that applies a ~10 second debuff to targets hit by your breath which checks damage done by allies with your [[talent:115496@FAQAviiB]] during that time window and does burst damage based on that as the debuff expires.
- [[talent:115520]]
  
  - Causes [[talent:115498]] cast to cost no essence, major synergies with [[talent:115688]] and [[talent:115506]].
- [[talent:126304@FAQAviiB]] and [[talent:115527@FAQAviiB]]
  
  - These talents juice up your [[talent:115536@FAgARegBviiB]] windows, granting reduced Essence cost for [[talent:115498@FAgARegBviiB]] and [[spell:390386]] for 15 seconds respectively.
- [[talent:115706]]
  
  - Your [[talent:115496]] buffed targets are given a shield based on their damage done during [[talent:115536]].
- [[talent:115533]]
  
  - A channeled spell that causes your cooldowns to recover at an increased rate, often "made passive" though with the follow-up talent [[talent:115686]] which just gives overall 10% cooldown reduction.

##### Class Tree

- [[talent:115596]]
  
  - A movement ability that let's you grab a friendly player and move them and yourself swiftly to another position, often used for clearing movement impairing effects.
- [[talent:115661]]
  
  - Used to reduce AOE damage for you and 4 nearest allies, very impactful with the defensive cooldown pruning that happened across all classes for Midnight.
- [[talent:115665]]
  
  - Used to activate [[talent:117552]] on [[talent:123334]]
  - Used generally with [[talent:115502@FAgARegBviiB]].
- [[talent:115602]]
  
  - A long cooldown dispel for many different debuffs, often utilized as a bleed dispel for (tank) mechanics.
- [[talent:115607]]
  
  - Combine this with either [[talent:115656]] or another friendly CC.




### [[talent:123334]]

:::talents [[talent:123334]] **Augmentation Evoker** in Mythic+
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### When to use this Spec

This should be your default spec in M+.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the [[talent:123331]] build.

##### Spec Tree

- **No changes**

##### Class tree

- **No changes**

#### Hero Talents

Switched from [[talent:123331]] to [[talent:123334]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:408092]] cooldown is reduced by 10 sec.
- **4-Set:** [[spell:408092]] magnifies your [[talent:115685]] effects for 8 sec, increasing the amount of damage echoed from 15% to 45%.

### Single-Target



#### [[talent:123334]]

##### Opener

- Your goal in the opener is to quickly cast all your buffs and then start extending your [[spell:1259171]]. Below, you can see an example of how your opener looks when using the recommended [[talent:123334]] spec.

:::rotation [[talent:123334]]  **Augmentation Evoker** opener in Mythic+
```json
{
  "source_code": "JsGSNIAkHYAABEAiuOAAAAAAC8tPGUhBY-KKGAgACl3pFAAABk1HEAACBAggCgVACg1cFAAAC4_CGAAACFfLGIEOAAg_BoRCmwiQYegBAAAAAIEmHYA"
}
```
1. [[spell:395152]]  [[item:241288]]
2. [[spell:409311]]
3. [[spell:409311]]
4. [[spell:403631]]  [[spell:370553]] · [[item:270169]]
5. [[spell:357208]]
6. [[spell:396286]]
7. [[spell:404977]]
8. [[spell:409311]]
9. [[spell:409311]]
10. [[spell:396286]]
11. [[spell:357208]]
12. [[spell:395160]]
13. [[spell:395160]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:115496]] If refreshing, cast at 5.5s or less remaining.
2. Cast [[talent:115675]] - *with 2 charges.*
3. Cast [[spell:403631]]
4. Cast [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] *- Rank 1*
5. Cast [[spell:395160]] - *with **2** stacks of [[spell:396187]].*
6. Cast [[spell:396286]] Rank 1 *-- Use* [[talent:115665]] when available
7. Cast [[spell:395160]] - *when capped on essence.*
8. Cast [[talent:115675]] *- with 1 charge*.
9. Cast [[spell:395160]].
10. Cast [[talent:117551@AJQDCA]].




#### [[talent:123331]]

##### Opener

- Your main goal with the [[talent:123331]] opener is to quickly cast all your buffs and start extending your [[spell:1259171]].

:::rotation [[talent:123331]] **Augmentation Evoker** opener in Mythic+
```json
{
  "source_code": "JcESJIAkHYAABEAiuOAAAAAAC8tPGUhB08KKGAQACl3pFAAACg1cBYAI-vgBAAgQYegBBwCLCh5BGAAAAAgQYegB"
}
```
1. [[spell:395152]]  [[item:241288]]
2. [[spell:409311]]
3. [[spell:409311]]
4. [[spell:403631]]  [[spell:370553]]
5. [[spell:357208]]
6. [[spell:396286]]
7. [[spell:395160]]
8. [[spell:395160]]
9. [[spell:395160]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:115496]] *- If refreshing, cast at 5.5s or less remaining.*
2. Cast [[talent:115675]] - *with 2 charges.*
3. Cast [[spell:403631]]
4. Cast [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] *- Rank 1*
5. Cast [[spell:395160]] - *with **2** stacks of [[spell:396187]].*
6. Cast [[spell:396286]] Rank 1 *-- Use* [[talent:115665]] when available
7. Cast [[spell:395160]] - *when capped on essence.*
8. Cast [[talent:115675]] *- with 1 charge*.
9. Cast [[spell:395160]].
10. Cast [[spell:361469]].





### Multi Target

Generally, there are no changes to your rotation based on target count, the only possible change is for you to adapt to how long a pack lives and accordingly hold off using [[talent:115496]] and Empowered abilities.

## Deep dive

### Shifting Sands and Prescience

- [[spell:413984]] is an **Augmentation Evoker** [[spell:406380]] effect which is a Versatility buff that you give out after casting an **Empower** spell, [[spell:357208]] or [[talent:115502@FAgARegBviiB]].
- Applies to the closest DPS player without an existing [[spell:413984]] buff (prioritizing your [[talent:115496@FAQAviiB]] targets, but with Midnight this is every DPS player in your party/raid almost always.)
- With the Ebon Might change, (proximity) targeting [[spell:413984]] and [[talent:115675@FAQAmxkB]] to players who are doing the most damage in any given situation are the only main optimizations left for Augmentation apart from your own (simple) rotation.
- Very high-end full optimized gameplay in raids still requires pre-planning with your [[talent:115675@FAQAmxkB]] targets and ideally trying to be nearby to players in their cooldown windows when casting Empower spells to get your [[spell:413984]] buff on them, but especially the proximity targeting is not always feasible mid-fight, on pull you should always try to stand next to the highest burst classes though.
- In many circumstances, it is totally acceptable to just permanently target the highest performing DPS players in your group with [[talent:115675@FAQAmxkB]] and leave it at that!

### Rescue

- [[spell:370665]] is a great part of your toolkit as an **Evoker**, using it optimally requires fight awareness, especially in raids it can often save your less mobile allies from sticky situations.
- **12.0 Patch** has this change: 
  
  - [[spell:370888]] has been redesigned – [[spell:370665]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  
  
  
  - Means that [[spell:370665]] no longer has a defensive cooldown tied to it but is even more potent as a movement ability!

### Hover

- Managing and timing your [[spell:358267]] uses correctly in combat to get more casts in while dealing with mechanics is where you see the biggest difference in your DPS as the actual rotational optimization is not that complex for **Augmentation Evoker**.
- Starting a cast of a spell such as [[talent:115498]] at the very end of a [[spell:358267]] buff still lets you finish that specific cast while moving. Keep this in mind to get more benefit from each use of [[spell:358267]]!
- Make sure you are tracking your uptime and charges of [[spell:358267]] on your UI. Get really comfortable with utilizing this ability as it is the most significant unique strength of an **Evoker**.
- With the **patch 12.0** [[spell:358267]] can now be used during normal casts (mostly [[spell:361469]] and [[talent:115498@FAQARegB]] on **Augmentation**) without interrupting them.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Altar of Fangs
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### Rav'i

- Use [[spell:363916]] or be ready to health potion if needed whenever you get the [[spell:1296220]] debuff.
- Look out for the waves that the boss shoots out with [[spell:1296058]], these have a clear indicator in front of the boss during the cast.
- You can [[spell:374227]] either [[spell:1307894]] or [[spell:1296220]] in this fight.

##### The Writhing Coil

- The boss always follows up [[spell:1299130]] with a [[spell:1300044]] frontal cone so try to stay close to the boss for easier dodging.
- You can break [[spell:1287797]] from [[spell:1299053]] easily with [[spell:370665]] every time. This is also a good timing to use a defensive cooldown.
- Consider holding [[talent:115536@FAgARegBviiB]] for the **Uncoiled Writhe** AoE phase as it is way more impactful there compared to single-target, it should line-up quite naturally though with one use in each phase.
- [[spell:1310358]] requires three single-target kicks during the normal phase so coordinate these with your group, during the **Uncoiled Writhe** phase you can use AoE stops for the casts.

##### Zul'jan

- You should soak one of the lanes for [[spell:1300876]] every time it happens and clear it later with [[spell:1301413]] - use [[spell:363916]] when clearing your debuff.
- Dodge [[spell:1301111]], they are quite fast and bounce around from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Always stop this cast!
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use [[spell:363916]] or [[spell:374227]] for this.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use [[spell:363916]] or [[spell:374227]] for this.
  - [[spell:1303366]] from Living Venom
    
    - They explode on death, use [[spell:363916]] or [[spell:374227]] for this.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with [[spell:370665]] if your healer doesn't dispel you.




### Den of Nalorakk

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Den of Nalorakk
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Use either [[spell:363916]] or [[spell:374227]] for every [[spell:1234681]].
- Coordinate with your group to soak [[spell:1234740]], you can also dispel the [[spell:1234846]] with either [[spell:365585]] or [[talent:115602]].
- Try to stay close to the boss as this makes the [[spell:1234021]] cone much easier to dodge.

##### Sentinel of Winter

- The healer can always instantly dispel only one of the two [[spell:1235549]] debuffs so be prepared to use a defensive cooldown or health potion as needed.
- Whenever the **Fractured Shivercores** spawn take the ranged one in focus target and remember to kick it.
- The adds also spawn a soak circle as they die, try to be active with helping soak these if you are nearby!
- Pre-position yourself for [[spell:1235623]] as the tornadoes spawns under players and you don't want them near the snow piles.
- You can use [[spell:374227]] for the [[spell:1235656]].

##### Nalorakk

- Time the use of your Obsidian Scales precisely for [[spell:1243569]] as then it also covers the following [[spell:1242860]].
- [[spell:1242860]] spawns an image your group has to soak later on so position them nicely.
- Help your group soak the charging bears during [[spell:1243002]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - This can be dispelled with [[spell:370665]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - If your tank and healer aren't handling these you can kill each with just one [[spell:362969]].
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Prioritize killing the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Murder Row
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- The fight rotates between killing **Nibbles** and then having a 20 second burst window on **Kystia Manaheart** , try to pool some damage for this as **Nibbles** is getting low.
- [[spell:1253811]] is aimed at the tank and rotates to a random direction, stay close to the boss for easier dodging.
- Try to bait [[spell:474240]] so the boss doesn't move too much as it jumps to an random player.
- Help stop the **Mirror Images** that cast [[spell:1264106]], you can use your interrupt or other stops.

##### Zaen Bladesorrow

- Use a defensive when targeted by [[spell:1217123]] and hit a green barrel with it if one is up.
- Pre-position and "claim" a barrel to hide behind for [[spell:734276]] slightly ahead of time to prevent any confusion.

##### Xathuux the Annihilator

- Place [[spell:1214637]] close to the boss if targeted by it for more efficient cleaving.
- [[spell:474197]] increases the damage taken of the boss for 15 seconds, try to optimize your dps timings for this.
- [[spell:1295453]] and [[spell:474197]] are usually casted in quick succession dealing heavy damage, rotate defensive cooldowns for this.

##### Lithiel Cinderfury

- Use a defensive for [[spell:474462]] and do a tight spread with your group to help with handling the adds that spawn after.
- As the boss jumps away to cast [[spell:1217345]] you need to time the use of [[spell:1214675]] to jump over it.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
    
    - This deals heavy damage, use defensive cooldowns as needed and be ready with your health potion.
  - [[spell:1294824]] from **Defiled Golem**.
    
    - Use [[spell:374227]] for this.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - You can dispel every second cast with [[spell:374251]], if there is no dispel available use [[spell:363916]] and [[spell:374227]] if targeted.




### The Blinding Vale

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for The Blinding Vale
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Pre-position near a flower to soak it during [[spell:1235564]].
- Try to move the boss as little as possible when targeted by [[spell:1235640]] and rotate defensives for the following [[spell:1261011]].
- Interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- If you don't have [[talent:115536@FAgARegBviiB]] or [[spell:370665]] ready for a dispel, position yourself under the boss after [[spell:1236746]] to cleave down the roots.
- Group up during [[spell:1236709]] to help out the healer.
- Save defensive cooldowns for when the boss is under 50% health as it gains [[spell:1237073]].

##### Lightwarden Ruia

- You can either stack on other players with [[spell:1239824]] or run out and aim  away from the boss.
- Spread out around the boss during the [[spell:1239885]] as each player gets targeted by [[spell:1240257]].
- Try to have defensive and offensive cooldowns ready for the last [[spell:1239883]] phase as this is by far the most difficult part of the fight.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- The boss spawns light orbs around the arena with [[spell:1246858]], intercept them as they try to reach the boss and you will receive a stacking DoT debuff that increases your damage done, considering giving other dps players the priority as you benefit from it less though - use a defensive cooldown if you get multiple stacks.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.
    - You can dispel this with either [[talent:115602]] or [[spell:365585]].

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Voidscar Arena
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Move around the arena with your group to bait and run away from the [[spell:1296967]] for easier dodging after [[spell:1300259]].
- Use [[talent:115661]] for [[spell:1300259]] when available.
- Use [[talent:115613@FAQAMZbB]] or be ready to top yourself off with a healing potion for [[spell:1222100]].

##### Atroxus

- Stay close to the boss to dodge [[spell:1222721]] easily.
- Use [[talent:115661]] for [[spell:1262497]] when available.
- Focus down **Toxic Creeper** as soon as he spawns and use [[talent:115613@FAQAMZbB]].
- If someone stands in a poison pool you can dispel the debuff from them.

##### Charonus

- Rotate [[talent:115613@FAQAMZbB]] and [[talent:115661]] for each [[spell:1227197]].
- You can strafe to dodge [[spell:1227247]] while playing at max range with [[spell:358267]] up.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - If your tank and healer aren't handling these you can kill each with just one [[spell:362969]].
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
    
    - Focus him down and use defensives for this.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Kings' Rest
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Place the puddle you spawn as [[spell:1306736]] expires next to others for more efficient cleaving as they spawn adds later. You can also use a defensive cooldown when you get targeted by this.

- Use [[talent:115661]] for [[spell:1311987]] when available.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by [[spell:267618]].
- Position yourself on an edge when targeted by [[spell:267639]] as it leaves behind a puddle.

##### The Council of Tribes

- You can dispel the [[spell:266231]] bleed with [[talent:115602]].
- Group soak the [[spell:267494]].
- During the last phase focus down the **Explosive Totem** first after each [[spell:267060]] cast.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** but only with **T'zala** who appears when **King Dazar** drops below 80%.
- Rotate [[spell:363916]] and [[spell:374227]] for each [[spell:1303267]] cast.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected by standing behind the shield.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at player locations so group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Ruby Life Pools
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- [[spell:396044]] spawns under players so don't place it in a bad spot.
- Don't damage [[spell:373046]] too fast and let your tank pick them up.
- Use a defensive cooldown if targeted by [[spell:372851]].

##### Kokia Blazehoof

- Interrupt **Blazebound Firestorm** when it casts [[spell:373017]].
- Rotate [[spell:363916]] and [[spell:374227]] for each [[spell:384823]] cast.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Try to position yourself relatively close to **Kyrakka** whenever it lands as it can be difficult to dodge the [[spell:381525]] otherwise.
- If you get targeted by [[spell:381602]] use a defensive cooldown when available. As it expires it spawn fire pools in the ground that move around with [[spell:381517]] so be mindful of your positioning.
- Look out for [[spell:381516]] and stop your cast accordingly.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.
    
    - Use a defensive or be ready to health potion when you get this debuff.




### Temple of Sethraliss

:::talents [[talent:123334]] **Augmentation Evoker** Mythic+ Build for Temple of Sethraliss
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbjZGMDzMLzYmZMzGAAAAAAAAzMwwYM1YmZGAAAAMzMjxMjZmZgZ2MGmlZswygxwMMz0IWwYmZmZGMYA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Pay attention to which boss has [[spell:1310311]] buff and damage the other one, this swaps between them every 33% health intervals.
- Get back to the boss after [[spell:1289062]] knock to soak [[spell:1288092]] - you also need to run out after the soak, consider using [[talent:115596]] to help out slower party members.
- Use [[talent:115661]] for [[spell:1288092]] when available.
- [[spell:1288864]] puddles linger for a long time so place them nicely to always have space to get knocked back by [[spell:1289062]].

##### Merektha

- Get close to the boss before the end of [[spell:1290031]] so your group has easier time handling them.
- Use a defensive cooldown for each [[spell:1293048]] cast.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- You should soak a pillar most waves, coordinate your defensives for when your healer has less healing.
- Use [[talent:115661]] for [[spell:1290531]] when available.

##### Avatar of Sethraliss

- When targeted by [[spell:1302153]] it spawns a puddle as it expires so considering your positioning.
- Rotate [[spell:363916]] and [[spell:374227]] when soaking [[spell:1300869]]
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
    
    - You can dispel this with [[talent:115602]] when needed.
  - [[spell:1308148]] from **Poisonous Viper**.
    
    - You can dispel this with [[spell:365585]].





### Affixes

The Affix system had some minor changes going from **The War Within** to **Midnight** but stays largely the same:

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix 
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  
  
  
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following are some useful tips for handling different Mythic+ Affixes as a **Augmentation Evoker**.

- Xal'atath's Bargain: Ascendant
  
  - [[spell:368970]] and [[spell:357214]]
  - Be careful to not carelessly pushback the mob pack you are currently fighting.
- Xal'atath's Bargain: Voidbound
  
  - Make sure to target the **Void Emissary** and kill it
  - If needed, you can talent into [[talent:115617]] for this affix.
- Xal'atath's Bargain: Devour
  
  - You can dispel it with [[talent:115615]] and [[talent:115602]].

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Augmentation Evoker**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.



### [[talent:123334]]

:::priority [[talent:123334]] Augmentation Evoker Stat Priority in Mythic+
```json
{
  "source_code": "JoAJFUQMgQCKBEgAEA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＝ 急速 ≫ 全能**
:::




### [[talent:123331]]

:::priority [[talent:123331]] Augmentation Evoker Stat Priority in Mythic+
```json
{
  "source_code": "IoAJFUAIkEDKBMABBA"
}
```
**智力 ＞ 暴击 ≥ 急速 ≫ 精通 ＞ 全能**
:::





:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. Most of your damage comes from buffed players, thus it becomes not optimal.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271501@DiQAAEcBnk7cVrjgC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAsbBE06QQrDj1IoAYFA]] | Ula'tek |
| Shoulder | Catalyst [[item:268231@AgQAAIoAYFA]]  <br> into [[item:271499@DgQAAEcBXk7IoAYF]] | Coiled Altar / Catalyst |
| Cloak | [[item:268253@BgQAAsbBCKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DARAAsbBJk7IoAMWDWB]] | Ula'tek |
| Wrist | [[item:244584@FiQAAsbBYA8ciqDBtO3WzSB]] | Crafting |
| Gloves | [[item:271502@BgQAAEcBCKgTBA]] | Tier / Catalyst |
| Belt | [[item:268254@BiQAAEcBE06IoAOF]] | Vashnik |
| Legs | Catalyst [[item:268237@AgQAAIoAYFA]]   <br>into [[item:271500@DgQAAEcBFo6IoAYF]] | Coiled Altar / Catalyst |
| Boots | [[item:268233@DgQAAsbBpk7IoAOF]] | Sszorak |
| Ring 1 | [[item:268249@DCQAAEcB3j7QQrjTBA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAEcB3j7QQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAsbBCKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAEcBCKgTBA]] | Altar of Fangs |
| Weapon | [[item:271092@DgQAAsbB_k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@FgQAAsbB4V2QqK0t1sUA]] | Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAAsbBCKQQBA]] | King's Rest |
| Cloak | [[item:251132@BgQAAsbBCKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAAsbBCKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAAsbBCKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAsbBCKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250224@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Trinket 2 | [[item:273796@BgQAAsbBCKQQBA]] | Altar of Fangs |
| Weapon | [[item:193761@BgQAAsbBCKQQBA]] | Ruby Life Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:270164@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]] |

### Embellishments / Crafting

- With your first 4 [[item:274476]] it is recommended to craft [[item:245770@CARAAgBwDAAcbNLF]] as it is very efficient usage of your mythic crests!

For end game optimized crafted gear you should have:

- 1x [[item:240167]]
  
  - The optimal slot to craft on is **Wrist**, **Back, Boots** or **Waist** depending on your available gear.

- 1x [[item:273060]]
  
  - Great embellishment if you are using a crafted weapon or off-hand.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, it is not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

- **DO NOT** use Stat Weights Sims, they only affect your personal damage. As such, you won't be given relevant results.
- Use only Top Gear and Droptimizer.
- RDPS or "Raid DPS" is the damage dealt by your entire group. This is done because Augmentation is a support that buffs other DPS therefore they are required for it to operate. Due to this and a few factors mentioned below, sims do not output the contribution of the Augmentation Evoker individually and can only provide comparisons. Thankfully, comparisons are all you need to optimize gear or talent choices.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
- **Food**
  
  - [[item:255845]]
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] *-- a big burst of healing - upgraded version from 12.1*
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *- You can only have one Eversong Diamond socketed in your gear.*
  
  
  
  - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:275707]]  <br>[[item:244007]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsbB]] |
| Chest | [[item:243977@BAAAAsbB]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:240133@BAAAAsbB]] |
| Boots | [[item:244009@BAAAAsbB]] |
| Ring 1 | [[item:243959]] |
| Ring 2 | [[item:243959]] |
| Weapon | [[item:244031@BAAAAEcB]] |

:::

:::column
:::gear **Augmentation Evoker** Enchantments in Mythic+
```json
{
  "source_code": "JQFZBXQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB3jbCYgy94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Macros

Discover recommended macros for **Augmentation Evoker** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[talent:115536]] -- *Casts [[talent:115536]] on your cursor without confirmation.***

```wow-macro
#showtooltip 
/cast [@cursor] Breath of Eons(Bronze)
```

:::

:::details Mouseover Macros
**[[talent:115675]] -- *Uses [[talent:115675]]* on your mouseover or your target.**

```wow-macro
#showtooltip Prescience
/cast [@mouseover,help,nodead][] Prescience
```

**[[talent:115602]] -- *Uses [[talent:115602]]* on your mouseover or your target.**

```wow-macro
#showtooltip Cauterizing Flame(Red)
/cast [@mouseover,help,nodead][] Cauterizing Flame(Red)
```

**[[talent:115666]] and [[talent:125610]] -- *Uses [[talent:115666]]* or *[[talent:125610]]* on your mouseover.**

```wow-macro
#showtooltip
/cast [known:374968] Time Spiral; [@mouseover] Spatial Paradox
```

**[[talent:115601]]** -- *Casts [[talent:115601]] on your mouseover target if it exists.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] Sleep Walk; [harm,nodead] Sleep Walk
```

:::

:::details Generic and Cancelaura macros
**[[spell:403264]] *-- Removes the need for manually casting [[spell:403264]] and if playing [[talent:123331]] allows you to cancel [[talent:115536@FAgARegBviiB]] early.***

```wow-macro
#showtooltip Eruption
/cast [nostance:1] Black Attunement
/cancelaura Breath of Eons
/cast Eruption
```

:::

:::details Utility Macros
**[[spell:370665]] Mouseover -- *Casts [[spell:370665]]* on your focus target with the end position being your cursor.**

```wow-macro
#showtooltip Rescue
/tar [@focus]
/cast [@cursor] Rescue
/targetlasttarget
```

**[[spell:370665]] Mouseover -- *Casts [[spell:370665]]* on your target with the end position being your cursor.**

```wow-macro
#showtooltip 
/cast [@cursor] Rescue
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Augmentation Evoker**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Augmentation Evoker Interface in Mythic+](<https://assets-ng.maxroll.gg/wordpress/AugmentationDungeonMidnightUI-1024x615.webp>)

**Augmentation Evoker** Interface in Mythic+

:::accordion
:::details Addons
- **BetterCooldownManager / BCDM** *--* Cooldown Manager customization
  
  - Provides additional customization to the Cooldown Manager.
- **Unhalted Unit Frames / UUF** *-- Unit frame addon* 
  
  - Adds custom player, target and boss frame customization.
  - Alternatively, you can also use ElvUI
- Plater -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking and threat coloring.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Bartender4** -- Action Bar addon
  
  - Replacement for the default action bars, allowing more customization and extra options.
- **RaidFrameSettings / RFS** -- Blizzard Raid frames customization
  
  - Provides additional customization to the default Blizzard raid frames.
- **NorskenUI** *-- Collection of Skinning, QoL and Features.*
  
  - One of the many "collection" addons available with multiple quality of life improvements, UI skinning and other useful functionalities.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Evoker**

- Panacea healing increased by 25%

**Hero Talents**

- **[[talent:123333]]**
  
  - *Developers’ notes: Wingleader’s cooldown reduction mechanic strongly incentivized spreading Bombardment applications across multiple targets. We feel that this gameplay is unintuitive in isolation, and additionally creates unhealthy behaviors such as Disintegrate clipping and Mass Disintegrate/Eruption pooling. This redesign is intended to retain the multitarget focus of the talent, while addressing those issues. We are increasing some of Scalecommander’s sources of area damage to compensate for the lessened cooldown reduction the new Wingleader will provide.*
  
  
  
  - Wingleader has been redesigned – Mass Disintegrate/Mass Eruption reduces the remaining cooldown of Deep Breath/Breath of Eons by 0.5 seconds/1 second for each target struck.
  - Command Squadron’s Pyre damage increased by 40%.
  - Maneuverability’s damage over time increased by 40%.

**Augmentation**

- *Developers' notes: The additional stopping power created by Duplicate-cast Upheavals was more warping to dungeon gameplay than desired, and could be frustrating in some situations due to its uncontrolled timing.*
- Apex Talent: Duplicate – Upheaval casts by your Duplicate no longer knock enemies into the air.
- All ability and pet damage increased by 3%.
- Living Flame healing increased by 25%.
- Verdant Embrace healing increased by 25%.
- Emerald Blossom healing increased by 25%.
- Defy Fate healing increased by 25%.
- Molten Blood healing increased by 25%.
- The *Midnight* Season 1 2-set bonus no longer increases the duration that Eruption extends Ebon Might.
- **Hero Talents**
  
  - **[[talent:123334]]**
    
    - Double-time has been updated - The additional stats granted when Ebon Might critically strikes now last 15 seconds (modified by Mastery: Timewalker), and Double-time is extended if Ebon Might reapplies it while it is already active. Double-time's functionality with Prescience is unchanged.
  
  
  
  - **[[talent:123333]]**
    
    - Wingleader now reduces the cooldown of Breath of Eons by 1.5 seconds per target struck (was 1 second).

:::

:::

:::accordion
:::details Patch 12.0.5
**Evoker**

- New Ability: Battle Visage – Activate to automatically assume your Visage whenever you are not casting draconic spells such as Fire Breath and Soar.
  
  - Full list of abilities that temporarily shift you to Dracthyr: Deep Breath, Dream Flight, Breath of Eons, Fire Breath, Eternity Surge, Dream Breath, Upheaval, Hover, Spatial Paradox, Rescue, Zephyr, Verdant Embrace (without Dream Simulacrum talented), and Soar.
  - Many abilities that used to force a shift to Dracthyr have adjusted visual treatments for Visage form.
  - While active, Battle Visage also applies a camera height override to Dracthyr form to prevent the camera from adjusting rapidly when shifting between forms.
- Unravel damage increased by 300%.
- Blessing of the Bronze is now castable on friendly players who are not in your party or raid group, similar to other group buffs like Arcane Intellect.
- Fixed an issue where Twin Guardian was applying its bonus at the start of Rescue rather than upon landing.

- Augmentation
  
  - New Talent: Mighty Inferno – Inferno’s Blessing’s damage is increased by 40%, and your effects that extend Ebon Might also extend Inferno’s Blessing.
  - Inferno’s Blessing will now correctly always apply to the casting Evoker, and will no longer apply to pets.
  - Regenerative Chitin has a new icon.
  - Molten Embers has been removed.
  - **[[talent:123334]]**
    
    - New Talent: Chronal Dynamo – Living Flame’s cast time is reduced by 0.2 seconds, and it deals 50% increased damage or healing when it is a non-instant cast.
    - Energy Cycles has been removed.

:::

:::

:::accordion
:::details Patch 12.0.1
**Evoker**

- [[spell:357208]] total damage, instant and periodic, should now be consistent at all Empower ranks, with all combinations of Fire Breath-affecting talents.
- [[talent:115663]] healing increased by 60%.

- **Augmentation**
  
  - [[spell:395152]] can no longer be aura canceled.
  - [[spell:395152]] extension range now matches [[spell:395152]] application range.
  - [[spell:361021]] now dynamically updates its duration if a cooldown is extended.
  - [[spell:361021]] and [[talent:115675]] have been updated to correctly detect all major throughput cooldowns, and will no longer activate on tank or healer specializations.
  - [[talent:115655]] healing increased by 50%.
  - [[spell:355913]] healing increased by 50%.

:::

:::

:::accordion
:::details Patch 12.0
**Evoker**

- **[[talent:123334]]**
  
  - New Talent: [[talent:135743]] – [[talent:115665]] cooldown is reduced by 30 seconds.
  - New Talent: [[talent:135741@AJQDCA]] – [[talent:117551@AJQDCA]] maximum damage or healing is increased by 40%, up to 350%.
  - New Talent: [[talent:135742]] – [[talent:117552@AJQDCA]] grants [[spell:392268]] every 6 seconds.
  - New Talent: [[talent:117544@AJQDCA]] – [[talent:115675]] cooldown reduced by 2 seconds and it grants 1% additional critical strike chance.
  - [[talent:117539@AJQDCA]] has been redesigned – Now increases the duration of [[talent:115675]] by 15%.
  - Threads of Fate has been removed.
- **[[talent:123333]]**
  
  - New Talent: [[talent:136053]] – While flying during [[talent:115536@FAQARegB]] or [[spell:357210]] you are assisted by a squadron of Dracthyr who assault enemies with Pyre, dealing Fire damage to nearby enemies up to 8 times.
  - New Talent: [[talent:136052@AJQD]] – [[talent:117536]] or [[talent:122279]] strikes 1 additional target.
  - New Talent: [[talent:136051]] – Essence abilities deal 15% more damage.
  - [[talent:120123]] now grants a charge of [[spell:358267]] instead of granting full charges.
- Class
  
  - New Talent: [[talent:115617]] – While flying during [[talent:115536@FAQARegB]] or  [[spell:357210]], 100% of damage you would take is instead dealt over 10 seconds.
  - New Talent: [[talent:136560]] – [[spell:358733]] speed and height increased by 10%.
  - New Talent: [[talent:115620]] – Your [[spell:361469]] and [[spell:367979]] are 30% more effective on yourself.
  - [[talent:115595]] has been redesigned – [[talent:115596]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  - [[talent:115669]] has been redesigned – Now upgrades [[talent:115613]], causing it to heal you over 8 seconds equal to the amount of damage it reduced.
  - [[talent:115616]] has been redesigned as a passive effect – [[spell:357208]] consumes absorb shields from enemies, dealing additional Spellfrost damage to them.
  - [[spell:362969]] damage increased by 50%.
  - [[talent:115657]] now changes the icon for [[spell:361469]] while active.
  - Fixed an issue where [[spell:357208]] could engage enemies if the player died and resurrected while it was active.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - [[spell:375577]]
    - [[talent:115645]] (moved to the Augmentation and Devastation talent trees
- Augmentation
  
  - New Talent: [[talent:115528]] – [[talent:115531]] may now grant [[talent:115675]] to allies and have a 10% increased chance to activate.
  - New Talent: [[talent:115493]] – [[talent:115522]] healing increased by 100% and its cooldown is reduced by 1 minute.
  - [[talent:115511]] has been redesigned – [[talent:115508]] no longer loses charges and deals 20% more damage.
  - [[talent:126304]] has been redesigned – [[talent:115536@FAQARegB]] reduces the Essence cost of your next 6 [[talent:115498@FAQARegB]] by 1.
  - [[talent:126305]] has been redesigned – Enemies affected by [[spell:357208]] damage over time effect take 25% increased damage from your Black spells.
  - [[talent:115690]] is now learned in the Augmentation specialization tree (was a class talent).
  - [[talent:115496]] now grants 8% primary stat (was 5%).
  - [[talent:115496]] is now applied to all damage dealing allies within 100 yards.
  - [[talent:115496]] now splits its effect when applied to more than 2 other allies and is no longer is limited to 2 maximum applications.
  - [[spell:409560]] now reduces its effect when [[talent:115496]] is applied to more than 2 allies.
  - [[talent:115536@FAQARegB]] debuff [[spell:409560]] is now visible to all allies, and indicates how much damage it accumulates on the aura tooltip.
  - [[talent:115536@FAQARegB]] accumulates 15% of damage (was 10%).
  - All spell and ability damage reduced by 23%.
  - Damage dealt by pets and minions reduced by 15%.
  - [[talent:115522]] healing increased by 100%.
  - [[talent:115510]] absorption increased by 30%.
  - [[talent:115495]] now only targets you and 1 nearby ally (was all allies with [[talent:115496]]). New visual of a flame sprite added to represent the blessing.
  - [[talent:115495]] damage increased to 350% spell power (was 88% spell power).
  - [[talent:115688]] now increases the damage of [[talent:115498@FAQARegB]] by 20%.
  - The cooldown manager has been updated to reflect changes made to Augmentation and can now be used to track the duration of [[spell:357208]], [[talent:115536@FAQARegB]], and [[talent:117533@AJQDCA]] on targets.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed: 
    
    - [[spell:371016]]
    
    
    
    - [[talent:115620]] *(moved to the* *class* *talent tree)*
    
    
    
    - [[spell:1219236]]
    - [[talent:115617]] *(moved to the* *class* *talent tree)*

:::

:::

## FAQ

:::accordion
:::details Q: Do you play around [[spell:408004]]?
Yes, you want to attempt to snipe gaining [[talent:115520]] for [[talent:115506]] as more often than not you don't lose anything by attempting to do so.

F.e. If you end up with 2x [[talent:115520]] and 6 essence you want to

- Cast [[talent:115498]] with [[talent:115520]]
- Cast [[talent:115498]] with [[talent:115520]]
- Cast [[talent:115498]]  
  Cast [[spell:361469]] attempting to snipe an [[talent:115520]] for a [[talent:115506]] extension

:::

:::

---

### Credits

Written By: **fraggo**

Reviewed by: **Ftm**

:::changelog 更新记录
**2026-08-06** Updated for 12.1

**2026-06-16** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-22** Updated for Midnight launch.

**2026-02-10** Updated for patch 12.0.1

**2026-01-15** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-04** Updated for patch 11.2

**2025-06-17** Updated for Patch 11.1.7.

**2025-04-22** Updated for Patch 11.1.5.

**2025-02-25** Updated for Patch 11.1.

**2024-12-17** Updated for patch 11.0.7.

**2024-10-23** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
