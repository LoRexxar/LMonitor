欢迎来到《魔兽世界》12.1版本 **恢复 德鲁伊** 团队副本 攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从80级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**整体治疗** · 4/5 · 强

冷却技能强度 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 3/5 · 一般

机动性 · 4/5 · 强



:::

:::

:::column
:::gear **恢复 德鲁伊** 团队副本 最佳装备（BiS）
```json
{
  "source_code": "JwpAwzUaAc__BEwAmQggQEAAvj7AJ16ACKwF2gVABYQ1DAICBAA_sOggC4UABYKJEIACBAQN5OggC4UABsKJEIACFAwI5OggC4UALfBBBA-FEUBMMgVABcaChA5GqOggCgVABfBBBk1uDQAEBAAGAPwD5OAAAcbNLFQAgt7AECSABQBGno6AE06AAUQAFsBGpSCBAgQBAEgb4QP1DEgYZPggIEAAvk7AUEwoY4UABUTrDQYCQxwL5OgCBwDA3GwUUQ1HEAACBUAOEEwVdwABdfRDYABWBEA9iUQzMUQuDkTAPgVCAPABgEAAzB8AYA8AAAAAAAAA3WzSBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240969]] · [[item:243951]] |
| 项链 | [[item:251142]] | [[item:240892]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:244003]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271527]] | [[item:240155]] |
| 脚部 | [[item:244569]] | [[item:245784]] · [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:252258]] | [[item:240916]] · [[item:244015]] |
| 戒指二 | [[item:240949]] | [[item:240906]] · [[item:245784]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245875]] · [[item:245784]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**恢复 德鲁伊**，你可以使用永绽，它使你的[[spell:33763]]最多可叠加3次，并使其绽放可以范围伤害多个目标。

**4级时，当你施放**  会使你的 [[spell:33763]] 绽放3次[[spell:18562]]。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-restodruid-mxr.webp>)

永绽

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:103106]]
    
    - 由主动技能改为被动效果，在引导[[spell:740]]时使你的所有持续治疗效果延长最多14秒。
  - [[talent:103121]]
    
    - 现在使你的[[talent:103109]]对2个额外目标施加[[spell:774]]或[[spell:8936]]。
  - [[talent:117104]]
    
    - 不再作为主动技能，改为使[[spell:18562]]和[[spell:48438]]生成一个[[talent:117104]]。
  - [[talent:103105]]
    
    - 愈合的爆伤从200%提高至260%。
- **职业天赋树**
  
  - [[talent:103309@AJwCDA]]
    
    - 现在是主动技能，你更适合在[[spell:768]]中按下它来提升伤害。
- **已移除**
  
  - [[spell:392301]] 
    
    - [[spell:33763]]现在又变回始终只能作用于一个目标。

## 英雄天赋

- [[talent:123299]] 专注于 范围伤害 治疗和爆发技能强度，而 [[talent:123298]] 专注于单体目标治疗以及在 [[spell:768]] 中造成的伤害。
- 在 团队副本 环境下，[[talent:123299]] 在任何情况下都优于 [[talent:123298]]。因此本攻略仅专注于更优的选择。



### [[talent:123299]]

- 每当你召唤一个 [[spell:102693]] 时，你将获得以下所有收益：
  
  - [[talent:117203]]
    
    - 每个激活的 [[spell:102693]] 使你的治疗量提高5%。
  
  
  
  - [[spell:428859]]
    
    - [[spell:774]]、[[spell:145205]] 和 [[spell:33763]] 的治疗量每个激活的 林莽卫士 提高10%。
  
  
  
  - [[talent:117194]]
    
    - 你的 [[spell:102693]] 会被动造成伤害。
  
  
  
  - [[talent:117195]]
    
    - 你的下一个直接治疗法术会创造3朵梦境花瓣，每朵花瓣最多可为3名盟友进行治疗。这些直接治疗受你的 精通 加成。
    - 可由 [[talent:117185]] 进一步增强。




### [[talent:123298]]

- [[spell:48438]]、[[spell:8936]]和[[spell:81262]]的治疗有几率在目标身上生成一个[[spell:439530]]，大幅提高你对该目标的治疗量。
- [[spell:439530]]可被以下节点强化：
  
  - [[talent:117227]]
    
    - 对带有[[spell:439530]]的目标造成的治疗量提高20%。
  
  
  
  - [[talent:117234]]
    
    - 使[[spell:439530]]的持续时间延长其总持续时间的三分之一。
  
  
  
  - [[talent:117232]]
    
    - 当你对带有[[spell:439530]]或[[spell:439530]]的目标施放[[spell:774]]时，会触发一次小型范围伤害治疗。





## 天赋



### 通用 团队副本 天赋

:::talents **恢复 德鲁伊** 通用 团队副本 天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 何时使用该专精

- 这是进入任何首领战的默认配置，除非另有说明。你需要根据首领战所需的辅助功能来调整职业天赋树。

#### 改变游戏玩法的天赋

- 探索专精和职业天赋树中所有会显著改变你游戏方式的天赋。本节将简要介绍这些天赋及其应用，但如需更详细的了解，请查看下方的输出循环和深度解析部分。

##### 专精树

- [[spell:114108]]
  
  - 强化你的下一个 [[spell:8936]] 或 [[spell:774]]，在每次施放 [[spell:18562]] 之后，使其更强并作用于两个额外目标。
- [[talent:128708]]
  
  - 将你的 [[talent:103111]] 融入你的 [[talent:103100]]。
- [[talent:103128]]
  
  - 此天赋使你的 [[spell:8936]] 顺劈到所有受 [[spell:8936]] 影响的其他目标。
- [[spell:200383]]
  
  - 你的 [[spell:18562]] 拥有 2 层充能。
- [[spell:207383]]
  
  - 此天赋大幅提升你的法力效率：当你有 5 个或更多活跃的 [[spell:774]] 时，使你的 [[spell:8936]] 消耗降低 50%，并且其爆击几率提高 50%。
- [[spell:155675]]
  
  - 使你能够在目标身上放置第二个 [[spell:774]]。
- [[spell:278515]]
  
  - 对所有活跃的 [[spell:33763]] 目标施放 [[spell:8936]]，让你可以通过单次施放施加多个 [[spell:8936]] HoT。此外，持续时间的延长也会大幅提升你从精通中获得的价值。

##### 职业树

- [[spell:197524]] 
  
  - 使你所有技能的施法距离增加 5 码，是让你保持在团队施法范围内的强大工具。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：**‍[[spell:774]] 有15%的几率、‍[[spell:132158]] 有100%的几率赋予 ‍[[spell:1302255]]，使你的所有持续治疗效果在8秒内提高25%。多次施加可以叠加。
- **4件套：**‍[[spell:132158]]、‍[[talent:103108]] 和 ‍[[talent:103120]] 或 ‍[[talent:103119]] 有100%的几率赋予 ‍[[spell:1302255]]，并且 ‍[[spell:1302255]] 的持续时间延长4秒。

### 优先级列表

1. 保持 [[spell:33763]] 处于激活状态，剩余时间不少于 4.5 秒时即可刷新。
2. 在你的 [[spell:33763]] 目标上保持 2 层 [[spell:774]] 处于激活状态。
3. 在冷却时施放 [[spell:18562]]，同时消耗 [[spell:48438]] 或 [[spell:8936]]。
4. 在冷却时施放 [[spell:48438]]。
5. 持续施放 [[spell:774]]，直到 [[talent:128277]] 处于激活状态。
6. 获得任何 [[spell:16870]] 触发效果时施放 [[spell:8936]]。
7. 对任何正在受到伤害的目标施放 [[spell:8936]]，优先选择已有持续治疗效果但没有 [[spell:8936]] 持续治疗效果的目标。
8. 如有空闲时间，施放一些 [[spell:5176]] 来恢复法力值。

### 冷却技能

#### 繁盛

:::rotation **恢复 德鲁伊** 繁盛 蓄爆发
```json
{
  "source_code": "IsGiMI04DCAAAcgUlZmclNHaAIggIBAAAIgBDAwB15GdpxGI1AQDTwC6iAgA0gHAClhJFAQAjwhN9CAAAIE5CEQDAAQAewRB40SMwgHACVgQIBQAC5DBCAAAChuIAAAAAAgAoLC"
}
```
1. [[spell:33763]] 刷新
2. [[spell:18562]]
3. [[spell:774]] 直到 5 层
4. [[spell:18562]]
5. [[spell:8936]] 4 次
6. [[spell:337433]]
7. [[spell:48438]]
8. [[spell:740]]
9. [[spell:8936]] 8-10 次
10. [[spell:18562]]  [[spell:132158]]
11. [[spell:8936]]
12. [[spell:8936]]
:::

- [[spell:197721]] 已被整合进 [[talent:103108]] 中，因此依然存在蓄力（ramp）循环，只是你不能再像以前那样频繁地使用它了。

## 深度解析

#### 

#### 丛林之魂

- 对 [[talent:103121]] 的改动使这成为定义该专精的核心天赋，因为它是影响最大的工具：既可以通过将其用于 [[spell:774]] 来为一次大型爆发铺垫，也可以通过将其用于 [[spell:8936]] 来进行实际的治疗。知道如何在每场遭遇战中使用好它的每一次机会，将决定你是一名优秀的还是卓越的 德鲁伊。

#### 野性之心

- 这既是你打出伤害的手段，也是一个强大的防御技能。在 [[spell:768]] 中使用它来输出伤害，或者在 [[spell:5487]] 中使用它来获得30%最大生命值，且即使你变身离开该形态，这部分生命值依然保留！

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊



### 内克扎莉

:::talents **恢复 德鲁伊** 内克扎莉 团队副本天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 在房间边缘驱散中了 [[spell:1287322]] 的队友！
- 当首领施放 [[spell:1284103]] 时，不要站在首领和坦克之间。




### 陵寝哨兵

:::talents **恢复 德鲁伊** 陵寝哨兵 团队副本天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 驱散受到 [[spell:1284471]] 影响的玩家。
- [[spell:1284590]] 在恰好达到 4 层时会被无害地中和。




### 迷失的探险者

:::talents **恢复 德鲁伊** 迷失的探险者团本天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 驱散受到 [[spell:1286921]] 影响的玩家。




### 瓦什尼克

:::talents **恢复 德鲁伊** 瓦什尼克团本天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 对受到 [[spell:1295224]] 影响的玩家使用单体技能（外部增益）。在受影响期间，他们免疫你的常规治疗。
- 受到 [[spell:1294994]] 影响时请使用个人减伤。




### 斯索拉克

:::talents **恢复 德鲁伊** 斯索拉克 团队副本天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 外部玩家需要使用[[spell:1286987]]。
- 使用[[talent:103276]]来应对[[spell:1285419]]。




### 双牙

:::talents **恢复 德鲁伊** 团本中的双生毒牙天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 当你受到 [[spell:1290809]] 影响时，使用个人防御技能。




### 盘绕祭坛

:::talents **恢复 德鲁伊** 团本中的盘绕祭坛天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。




### 乌拉特克

:::talents **恢复 德鲁伊** 乌拉特克 团队副本天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。




### 尼姆瑞莎·唤波者

:::talents **恢复 德鲁伊** 团本中的 尼姆瑞莎·唤波者 天赋
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### 首领攻略技巧

- 当大量 [[spell:1257717]] 被触发时，使用个人防御技能。





## 属性优先级

作为**恢复 德鲁伊**，了解你的次要属性优先级以及实现团队副本首领战斗最佳表现所需的第三属性。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **恢复 德鲁伊** 团队副本中的属性优先级
```json
{
  "source_code": "DoAJFUAJxgCIBEQABA"
}
```
**智力 ＞ 急速 ＞ 精通 ＞ 全能 ＞ 暴击**
:::

> 此处的结论是，你通常应当装备装等最高的装备。

- 所有次要属性都会受到**收益递减**的影响。[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)了解更多！

### 第三属性

- **闪避** - 减少受到的范围伤害效果伤害。
- **吸血** - 将你造成的伤害和治疗的一部分以治疗形式返还给你。（不包括自我治疗）
- **加速** - 提高移动速度。（可与其他加速移动技能叠加）

唯一需要考虑选择较低装等装备的情况，是它带有吸血或闪避属性时。加速也不错，但在两件装备之间抉择时不应考虑该属性。

- 下面展示一下吸血对治疗者来说有多强大：史诗难度弗拉希乌斯数据剖析

![](<https://assets-ng.maxroll.gg/wordpress/PmriF2i-1024x509.png>)

**恢复 德鲁伊**来自 Warcraftlogs 的治疗数据分解

## 装备



### 最佳配装

由于 **恢复 德鲁伊** 的属性权重运作方式，并不存在严格意义上的最佳配装（BiS）列表。虽然理论上可以获得拥有全部正确第三属性的装备，但由于《魔兽世界》的每周重置机制，这需要非同寻常的运气或者好几辈子的时间。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAkGAvj7kUrjgCchNYFA]] | 乌拉特克 |
| 颈部 | [[item:251142@BiQAAkGA8z6IoAOF]] | 密谋小径 |
| 肩部 | [[item:271526@DgQAAkGA1k7IoAOF]] | 套装/催化剂 |
| 披风 | [[item:268253@BgQAAkGACKAWBA]] | 盘绕祭坛 |
| 胸部 | [[item:268235@AgQAAIoAOFA]]（通过催化剂转化为套装） | 内克扎莉 |
| 腕部 | [[item:244576@FCSAAkGAYA8ciqDBtOAAAAAAAA3WzSB]] | 制造 |
| 手套 | [[item:251124@AgQAAIoAOFA]] | 密谋小径 |
| 腰带 | [[item:268256@BiQAAkGA8z6IoAYF]] | 盘绕祭坛 |
| 腿部 | [[item:271527@DgQAAkGAbo6IoAYF]] | 盘绕祭坛 |
| 脚部 | [[item:244569@FARAAkGAYA88QuDAAcbNLFA]] | 制造 |
| 戒指1 | [[item:252258@DiQAAkGAvk7wPrjgC4UA]] | 虚空之痕竞技场 |
| 戒指2 | [[item:240949@FCRAAkGAYA88SuD_sOAAwt1sUA]] | 制造 |
| 饰品1 | [[item:270164@BgQAAkGACKgTBA]] | 迷失的探险者 |
| 饰品2 | [[item:270167@BgQAAkGACKgTBA]] | 尼姆瑞莎 |
| 武器 | [[item:271092@DgQAAkGAFk7kjAYF]] | 乌拉特克 |
| 副手 | [[item:245769@FASAAkGAzB8gBwDAAAAAAAwt1sUA]] | 制造 |

#### 作者的话：

此清单列出了来自所有来源、适合团队副本治疗的最佳物品。请注意，获取带有吸血/闪避的不同套装部件会改变哪件散件对你来说最优。同样地，任何其他带有吸血/闪避的非饰品物品都可以替换此处推荐的物品。




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 来源 |
| --- | --- | --- |
| 头部 | [[item:251140@AgQAAIoABFA]] | 密谋小径 |
| 项链 | [[item:251142@BiQAAkGA8z6IoABF]] | 密谋小径 |
| 肩部 | [[item:251223@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 披风 | [[item:251190@AgQAAIoABFA]] | 炫目谷地 |
| 胸部 | [[item:251159@AgQAAIoABFA]] | 纳洛拉克的洞穴 |
| 护腕 | [[item:251135@AgQAAIoABFA]] | 密谋小径 |
| 手套 | [[item:251124@AgQAAIoABFA]] | 密谋小径 |
| 腰带 | [[item:251166@AgQAAIoAUEA]] | 迈萨拉洞窟 |
| 腿部 | [[item:159313@AgQAAIoABFA]] | 萨隆矿坑 |
| 靴子 | [[item:251153@AgQAAIoABFA]] | 纳洛拉克的洞穴 |
| 戒指 1 | [[item:252258@DiQAAkGAvk7wPrjgCEUA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:159459@AgQAAIoABFA]] | 诸王之眠 |
| 饰品 1 | [[item:250214@AgQAAIoABFA]] | 炫目谷地 |
| 饰品 2 | [[item:273649@AgQAAIoABFA]] | 诸王之眠 |
| 双手武器 | [[item:159636@AgQAAIoABFA]] | 神殿 |
| 单手武器 | [[item:273778@AgQAAIoABFA]] | 毒牙祭坛 |
| 副手 | [[item:251191@AgQAAIoABFA]] | 炫目谷地 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A级** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]] |
| **B级** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **垃圾级** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### 美化饰品

- [[item:245876]]
  
  - 非常强力的属性神器，根据你命中的目标提供大量的某项次要属性。
- [[item:240167]]
  
  - 非常强力的属性神器，同时还能强化你的盟友。

#### 剩余的火花

- 制造装备的物品等级为331，普通装备的最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则在2件美化装备之外再装备制造装备并无收益。

## 消耗品

- **药瓶**
  
  - [[item:241324]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@BQAAAkGAaB]]
- **宝石插槽**
  
  - [[item:240892]]
  - [[item:240969]]
    
    - [[item:240900]]
    - [[item:240906]]
    - [[item:240916]]

### 附魔

:::columns
:::column
| 头盔 | [[item:275707@DAAAAkGAvj7A]]  <br>[[item:243951]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAkG]] |
| 胸部 | [[item:244003@BAAAAkG]] |
| 护腕 | [[item:275707@DAAAAkGAvj7A]] |
| 腰带 | [[item:275707@DAAAAkGAvj7A]] |
| 腿部 | [[item:240155@BAAAAkG]] |
| 靴子 | [[item:243983@BAAAAkG]] |
| 戒指 1 | [[item:244015@BAAAAkG]] |
| 戒指 2 | [[item:244015@BAAAAkG]] |
| 武器 | [[item:243973@BAAAAkG]] |

:::

:::column
:::gear **恢复 德鲁伊** 附魔
```json
{
  "source_code": "IQFZpBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABMSDIgw-0QQBQQwGqmAGA8gOYAAAv0AEo8SuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:244003]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买[[item:275707@BAAAAkG]]，为你的头盔、护腕和腰带添加插槽。

## 种族

对于想在史诗团本中对**恢复 德鲁伊**进行极限优化的玩家来说，不同的种族特性可以为你的角色带来巨大的收益。如果这并不是你的首要目标，那么选择一个符合你个人风格的种族同样可行。

- [[spell:26297]] -- 巨魔
  
  - 使你的急速提高10%，持续12秒。

### 推荐：

虽然 巨魔的 [[spell:26297]] 理论上在团队副本中提供最高的输出加成，但仍推荐选择 牛头人，以获得少许生存能力加成。这些加成都非常微小，所以你完全不必为此担心。

## 宏

了解 **恢复 德鲁伊** 在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
为了方便起见，本 **恢复 德鲁伊** 团队副本 攻略中的所有法术都提供了鼠标指向宏！

[[spell:774]]

```wow-macro
/cast [@mouseover, help] 回春术; 回春术
```

[[spell:8936]]

```wow-macro
/cast [@mouseover, help] 愈合; 愈合
```

[[spell:18562]]

```wow-macro
/cast [@mouseover, help] 迅捷治愈; 迅捷治愈
```

[[spell:33763]]

```wow-macro
/cast [@mouseover, help] 生命绽放; 生命绽放
```

[[spell:48438]]

```wow-macro
/cast [@mouseover, help] 野性成长; 野性成长
```

[[spell:102401]]

```wow-macro
/cast [@mouseover, help] 野性冲锋; 野性冲锋
```

[[spell:102342]]

```wow-macro
/cast [@mouseover, help] 铁木树皮; 铁木树皮
```

[[spell:20484]]

```wow-macro
/cast [@mouseover, help] 复生; 复生
```

:::

:::details 推荐宏
确保你的 [[spell:29166]] 始终施放在自己身上，无需操心目标选择或鼠标指向的调整。

```wow-macro
/cast [@player] 激活
```

取消你当前的形态，以确保你使用的是人类形态的版本，使你可以立即切换到你的某个 [[spell:102693]]。

```wow-macro
#showtooltip 野性冲锋
/tar 树人
/cancelaura [mod:ctrl] 旅行形态
/cancelaura [mod:ctrl] 猎豹形态
/cancelaura [mod:ctrl] 熊形态
/cancelaura [mod:ctrl] 枭兽形态
/cast 野性冲锋
```

更快的紧急治疗方式

```wow-macro
/Cast 自然迅捷
/cast [@mouseover, help] 愈合; 愈合
```

更快的战斗复活方式

```wow-macro
/Cast 自然迅捷
/cast [@mouseover, help] 复生; 复生
```

直接放置你的[[spell:145205]]，无需点击确认。在你没有点出[[talent:128708]]天赋时很有用。

```wow-macro
/cast [@cursor] 百花齐放
```

:::

:::

## 插件

下方是作者为其**恢复 德鲁伊**的界面截图，其中概述了所使用的插件以及它们在团队副本中如何帮助你更轻松地游戏。

![](<https://assets-ng.maxroll.gg/wordpress/f9BRME4-1024x576.webp>)

**恢复 德鲁伊** 团队副本

:::accordion
:::details 插件
- EllesmereUI —— 全能
  
  - 用于升级暴雪自带 UI 的插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 恢复
  
  - 开发者说明：在本次更新中，我们对 恢复 德鲁伊 进行了数项便利性调整，旨在解决 宁静、自然迅捷 和 化身：生命之树 的易用性问题。我们还对 迅捷治愈 做了一些调整，以恢复其作为强力单体治疗的一部分实力。最后，我们希望通过重新设计 丰饶 来解决其存在的问题，使其有一个明确的使用 愈合 的时机门槛。
- 新天赋：过度生长——自然迅捷 使你的下一个 愈合 对一名盟友施加 生命绽放、回春术 和 野性成长 的持续治疗效果。
- 新天赋：清晰预兆——清晰预兆 使 愈合 的治疗量提高40%。现在位于天赋树中先前「耕耘」所在的位置。
- 「耕耘」现在位于天赋树中「清晰预兆」的下方。
- 激活 已重新设计——现在会在8秒内恢复目标25%的最大法力值，而不再是使法术在8秒内免费施放。
- 丰饶 已重新设计——当你拥有至少5个激活的回春术时，愈合 的爆击几率提高50%，法力消耗降低50%。
- 宁静 已更新——现在会在你脚下生长出保护性的根须，吸收相当于你60%生命值的伤害，并防止被击退。
- 化身：生命之树 已更新——现在当你初次变形时，会对附近最多3名受伤的盟友施放 愈合。
- 迅捷治愈 已更新——治疗量提高所消耗的持续治疗效果的40%。
- 永绽（等级3）已更新——其治疗效果现在在你按下 迅捷治愈 时触发（原为 丛林之魂）。
- 翠绿灌注已更新——不再延长持续治疗效果。
- 萌芽 已更新——不再使 回春术 的持续时间延长2秒。
- 伊瑟拉之赐已更新——如果其治疗会对 德鲁伊 产生过量治疗，则过量的治疗量将转移给附近的一名盟友。
- 精通：和谐的治疗加成提高15%。
- 所有法术和技能的治疗量提高6%。
- 野性成长 治疗量提高20%，法力消耗提高15%。
- 新绿的治疗量提高40%。
- 回春术 法力消耗降低10%。
- 愈合 治疗量降低20%，法力消耗降低10%。
- 生命绽放 法力消耗降低20%。
- 四季轮转使 自然迅捷 的冷却时间缩短15秒（原为12秒）。
- 共生关系现在在其未激活时会在动作条上高亮显示自身。
- 萌芽 和新绿在天赋树中互换了位置。
- 自然之光已被移除。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我总是死亡？
答：开始将[[spell:102342]]作为个人防御冷却技能使用。

:::

:::details 问：为什么我的法力总是不够用？
答：保持[[spell:33763]]的覆盖率达到100%，并且不要浪费任何一次[[spell:113043]]触发。

:::

:::

---

### 致谢

作者：**Rycn**

审校：**Ftm**

---

:::changelog 更新记录
**2026-08-07** 攻略已更新至12.1版本

**2026-06-19** 攻略已更新至12.0.7版本

**2026-04-22** 攻略已更新至12.0.5版本

**2026-02-11** 攻略已更新至12.0.1版本

**2026-01-09** 攻略已更新至12.0版本

**2025-10-07** 攻略已更新至11.2.5版本

**2025-07-14** 攻略已更新至11.2版本

**2025-06-18** 攻略已更新至11.1.7版本

**2025-04-19** 攻略已更新至11.1.5版本

**2024-12-17** 攻略已更新至11.0.7版本

**2024-10-20** 攻略已更新至11.0.5版本

**2024-08-17** 攻略编写于11.0.2版本



:::
