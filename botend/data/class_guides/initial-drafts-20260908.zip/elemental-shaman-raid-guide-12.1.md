欢迎来到魔兽世界12.1版本的**元素 萨满祭司** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从80级开始练级的玩家？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 5/5 · 极佳

范围伤害 · 4/5 · 强势

功能性 · 4/5 · 强势

生存能力 · 3/5 · 一般

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **元素 萨满祭司** 团队副本 最佳配装
```json
{
  "source_code": "I8fAQbQA3_fABsHJEIICBAwJ5OwVtOQOC4UABk-FEAQEBAA_sOA_sOQOCwYNYFQA5RCBCgQAAcRuJMCJEYCBCARAAkQuD0AIQ49FEAICFQTBDBgeJ8CBFoaCPgQyXQQA-QQ84mwDIg2uDEwcEgBwBEGL3WzSBEAfkQAAIEAAFwDBZfRBRSQ94GgHFIBCil9ABATCSAggBMKBU9RGwAwVdwADog6AEEQzMo6AYAcCaRA9iUweI9TuDkjAYFQAmfBBAgQAAkjAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271483]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271481]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240892]] |
| 腿部 | [[item:271482]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271484]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:239656]] | [[item:240167]] · [[item:245784]] |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268262]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**元素 萨满祭司**，你可以使用反馈回路，它会提高你的[[spell:168534]]伤害。

**第2阶**提高你的爆击几率，并使你的[[talent:101853]]提高你的法术爆击伤害。

**第3阶**使你的[[spell:168534]]有25%的几率再次触发。

:::

:::column
:::group
反馈回路

![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-elemental-mxr.webp>)

:::

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:101883@FAQAt6TB]]
    
    - 使你的 [[spell:13729]] 范围伤害。
  - [[talent:101884]]
    
    - 在你施放 [[talent:101883@FAQAt6TB]] 后，使你的 [[talent:127873@FAQAt6TB]] 范围伤害。
- **职业天赋树**
  
  - [[talent:127868@AJwB]]
    
    - 使你的[[talent:127871@FJgAWRpEigdBHA]]不再损失层数，并治疗更多生命值。
  
  
  
  - [[talent:135591@AJwB]]
    
    - 被动获得智力，并自动施放你所有的附魔和护盾。
- **已移除**
  
  - [[spell:378270@FJwCcBVAQdhALunAWJpA02tAt6TBa0wBb0wB8-SAYecBcusEHA]]
    
    - 移除 [[spell:114049]] 的随机触发效果。
  - [[spell:210714]]
  - [[spell:336215]]
  - [[spell:375982]]

## 英雄天赋



### [[talent:123377]]

- 在至暗之夜中，英雄树新增了3个天赋：
  
  - [[talent:135990]] - 根据你召唤出的先祖数量获得智力。
  - [[talent:135989@AJwB]] - [[talent:127873@FAQAt6TB]]、[[talent:127861]]和[[spell:8004]]的施法时间缩短。
  - [[talent:135988@AJwB]] - 提高[[spell:77756]]的触发几率。
- [[spell:443450@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - 当你使用[[talent:117491@FAQAQdhA]]或[[talent:101859@AJwB]]时，先祖会出现。
  
  
  
  - 这些先祖会根据你施放的法术来施放技能。 
    
    - 如果你施放任何单体法术，先祖会对你的目标施放一个[[spell:51505]]。
    - 如果你施放任何范围伤害法术，先祖会对你的目标施放一个[[spell:188443]]。
- [[talent:117459]]或[[talent:123632@FAQAQdhA]]
  
  - [[talent:117459]]
    
    - 你的先祖的法术更加强大。
  - [[talent:123632@FAQAQdhA]]
    
    - 当先祖消失时，你有几率在短时间内召唤另一个先祖。
- [[talent:117481]]或[[talent:123630@FAQAQdhA]]
  
  - [[talent:117481]]
    
    - 先祖的持续时间更长。
  - [[talent:123630@FAQAQdhA]]
    
    - 某些法术有额外几率在短时间内将一位先祖召唤到你身边。
- 当先祖消失时，由于[[spell:443446@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]的效果，它会对附近的一个目标施放一个[[spell:117014]]。这个[[spell:117014]]也会为你提供 爆击, 急速 或 精通 也是。
- 这个天赋树的其余部分是不会对你的游戏玩法产生太大影响的被动技能。
  
  - [[spell:443448@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - 提高你的最大 漩涡值.
  - [[spell:443447@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - 提高你的消耗技能的伤害。
  - [[spell:443418@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - [[spell:51505]]获得1层额外充能，并造成更高的伤害。




### [[talent:123376]]

- 在至暗之夜中，英雄树新增了3个天赋：
  
  - [[talent:135987@AJwB]] - 使 [[talent:101864]] 延长 2 秒，并使你的 [[talent:101859@AJwB]] 给你 10 点漩涡值。
  - [[talent:135986]] - 被动提升自然伤害。
  - [[talent:135985@AJwB]] - 施放 [[talent:101860]] 后你获得一层 [[talent:117489@FAQAQdhA]]。
- [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - 你的 [[spell:188196]] 有几率在你花费后变为 [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] 漩涡值
- [[talent:117482@FAQAQdhA]]
  
  - 施放 [[talent:117489@FAQAQdhA]] 会给予你一层 [[talent:101859@AJwB]]。
- [[talent:117470]] 或 [[talent:128225@FAQAQdhA]]
  
  - [[talent:117470]]
    
    - [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] 给你额外的 精通.
  - [[talent:128225@FAQAQdhA]]
    
    - [[spell:188196]]、[[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] 和 [[spell:188443]] 有几率触发一次额外的过载。
- [[spell:454026@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - 降低 [[talent:101859]] 的冷却时间。
- [[spell:455123@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - 施放 [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] 会对你的目标施加 [[spell:210689]]。
- 这个天赋树的其余部分是被动效果，对你的玩法影响不大。
  
  - [[spell:454391@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - 消耗 漩涡值 会给予你 急速.
  - [[spell:454919@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - 提升你的 ‍地震术 和 ‍闪电链 的伤害。
  - [[spell:454021@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - 使你的自然法术的爆击几率和爆击伤害提高 5%。





## 天赋



### [[talent:123377]]

:::talents [[talent:123377]] **元素 萨满祭司**在团本中的天赋选择
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

##### 专精树

- [[spell:392714]]
  
  - 强化你的下2次[[spell:188196]]或[[spell:188443]]。
- [[talent:101860]]
  
  - 3分钟冷却。使你的[[spell:168534]]伤害提高150%，且你的法术会额外触发1次[[spell:168534]]。

##### 职业树

- [[spell:79206]]
  
  - 允许你在15秒内移动施法，这在某些场景下可以为你挽回大量原本可能损失的DPS。
- [[spell:378081]]
  
  - 使你的下一个自然法术变为瞬发。当你使用[[talent:123377]]时，它会变为[[spell:448861@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]，同时还会召唤一位先祖。

##### 英雄天赋

- [[spell:443450@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - 当你施放[[talent:101859@AJwB]]和[[spell:448861@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]时，会召唤先祖。
- [[talent:117472@FAQAQdhA]]
  
  - 当一位先祖消失时，它会施放一个[[talent:127924@FAgAg_wBxkM]]，同时还会给予你爆击、急速或精通。




### [[talent:123376]]

:::talents [[talent:123377]] **元素 萨满祭司**在团本中的天赋选择
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

##### 专精树

- [[spell:392714]]
  
  - 强化你的下2次[[spell:188196]]或[[spell:188443]]，使其变为瞬发。
- [[talent:101860]]
  
  - 3分钟冷却。使你的[[spell:168534]]伤害提高150%，并且你的法术会额外触发1次[[spell:168534]]。

##### 职业树

- [[spell:79206]]
  
  - 允许你在15秒内移动施法，这在某些场景下可以为你挽回大量原本可能损失的DPS。
- [[spell:378081]]
  
  - 使你的下一个自然法术变为瞬发。

##### 英雄天赋树

- [[talent:117482@FAQAQdhA]]
  
  - 施放[[talent:117489@FAQAQdhA]]会获得一层[[talent:101859@AJwB]]。
- [[talent:117486@FAQAQdhA]]
  
  - 使[[talent:101859]]的冷却时间缩短15秒。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** 施放 ‍[[spell:191634]] 使你的急速提高15%，持续10秒。
- **4件套： ‍**[[spell:191634]] 施放时获得一层额外充能。‍[[spell:191634]] 使 ‍[[spell:8246]] 和 ‍[[spell:12058]] 的伤害提高25%。

### 单体目标



#### [[talent:123377]]

##### 起手爆发

:::rotation [[talent:123377]] **元素 萨满祭司** 团本单体开局输出循环
```json
{
  "source_code": "IsEaHIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAABIgzFgADCJYvBEAEMIkPEbQBIQQMJHwBMAgQDHQCYQSMJDAAAAAACp2H"
}
```
1. [[spell:392714]] 开怪前 [[item:241308]] · [[item:249346]]
2. [[spell:114050]]
3. [[spell:443454]]
4. [[spell:51505]]
5. [[spell:65987]]
6. [[spell:51505]]
7. [[spell:8042]]
:::

- 除非你必须移动，否则不要在[[talent:101860]]中施放[[talent:127879@FAQAt6TB]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在冷却完毕时施放 [[spell:392714]]。
2. 在冷却完毕时施放 [[talent:101860]]。
3. 在冷却完毕时施放 [[talent:117491@FAQAQdhA]]。
4. 在以下情况施放 [[talent:101854]]：
   
   1. 你拥有激活的 [[talent:101879]]。
   2. 你的 漩涡 即将溢出。
5. 施放 [[spell:51505]]。
6. 施放 [[spell:188196]]。
7. 在移动时施放 [[talent:135718@FAQAt6TB]]。




#### [[talent:123376]]

##### 起手爆发

:::rotation [[talent:123376]] **元素 萨满祭司** 团本中的单体起手
```json
{
  "source_code": "IwEaHIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAABIgzFgADCJYvBEAEIIUMJHwBQAgQ51uBBkQFQgCJfLAAAAAACRy3CA"
}
```
1. [[spell:392714]] 开怪前 [[item:241308]] · [[item:249346]]
2. [[spell:114050]]
3. [[spell:51505]]
4. [[spell:454009]]
5. [[spell:51505]]
6. [[spell:188196]]
7. [[spell:188196]]
:::

- 尽快使用 [[talent:127924@FAQAxkM]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在冷却时施放 [[spell:392714]]。
2. 在冷却时施放 [[talent:101860]]。
3. 在以下情况施放 [[talent:127924@FAQAxkM]]：
   
   1. 你的 [[talent:136714]] 处于激活状态。
   2. 你即将超出上限 漩涡值.
4. 搭配 [[talent:136714]] 施放 [[talent:117489@FAQAQdhA]]。
5. 施放 [[spell:51505]]。
6. 施放 [[spell:188196]]。





### 多目标



#### [[talent:123377]]

##### 起手爆发

:::rotation **[[talent:123377]] 元素 萨满祭司** 团本中的多目标起手
```json
{
  "source_code": "IQEaGIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAABIgzFgADCJYvBEAEMIUetbQBIQgGvEwBwAgQa8CAAAAAAIkpuEA"
}
```
1. [[spell:392714]] 开战前 [[item:241308]] · [[item:249346]]
2. [[spell:114050]]
3. [[spell:454009]]
4. [[spell:12058]]
5. [[spell:12058]]
6. [[spell:77478]]
:::

##### 多目标优先级列表

1. 在冷却时施放 [[spell:392714]]。
2. 在冷却时施放 [[talent:101860]]。
3. 对没有 [[talent:101889@FAgAQdhA51uB]] 的目标施放 [[talent:117489@FAQAQdhA]]。
4. 施放 [[talent:127925@FAQAQdhA]]。
5. 施放 [[talent:127856@FAQAt6TB]]。
6. 施放 [[talent:135718@FAQAt6TB]]。




#### [[talent:123376]]

##### 起手爆发

:::rotation **[[talent:123376]] 元素 萨满祭司** 团本中的多目标起手
```json
{
  "source_code": "IMEaGIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAABIgzFgADCJYvBEAEMIUambQBIgwGgLgMIAAB6GP"
}
```
1. [[spell:392714]] 开战前 [[item:241308]] · [[item:249346]]
2. [[spell:114050]]
3. [[spell:452201]]
4. [[spell:188443]]
5. [[spell:188443]]
6. [[spell:61882]]
:::

- 在开场阶段，你要尽量在 [[talent:101860]] 期间施放尽可能多的 [[talent:101855@FAgAQdhAWkcA]] 和 [[talent:127856@FAQAt6TB]]。

##### 多目标优先级列表

1. 施放 [[spell:392714]]。
2. 施放 [[talent:101860]]。
3. 对没有 [[talent:101889@FAgAQdhA51uB]] 的目标施放 [[talent:117489@FAQAQdhA]]。
4. 施放 [[talent:127925@FAQAQdhA]]。
5. 施放 [[talent:127856@FAQAt6TB]]。
6. 施放 [[spell:51505]]。
7. 施放 [[talent:135718@FAQAt6TB]]。





## 深度解析

### 引雷针

[[talent:127924@FAwAg_wB51uBxkM]]、[[talent:101854]]、[[talent:101855@FAgAQdhAWkcA]] 和 [[talent:117489@FAQAQdhA]] 会施加 [[talent:101889@FAgAQdhA51uB]]，它会将你大量的 [[talent:127856@FAQAt6TB]]、[[spell:188196]] 和 [[talent:117489@FAQAQdhA]] 伤害复制到受 [[talent:101889@FAgAQdhA51uB]] 影响的目标身上。

[[talent:127924@FAwAg_wB51uBxkM]] 和 [[talent:101854]] 总是会对你的目标施加 [[talent:101889@FAgAQdhA51uB]]。

[[talent:101855@FAgAQdhAWkcA]]会优先作用于你的当前目标，但如果目标身上已经带有[[talent:101889@FAgAQdhA51uB]]，则会将其施加给附近的一名敌人。

大多数情况下你不需要在意[[talent:101889@FAgAQdhA51uB]]，因为在单体目标时它会直接施加到你的目标身上，而在范围伤害时你的[[talent:101855@FAgAQdhAWkcA]]会自动施加到其他目标上；然而在范围伤害时，你需要思考如何使用[[talent:117489@FAQAQdhA]]。每当你施放它时，都应尽量选择一个身上没有[[talent:101889@FAgAQdhA51uB]]或即将失效的目标。如果存在没有[[talent:101889@FAgAQdhA51uB]]的高优先级目标，你也可以尝试将施放目标转为该目标。

### 理解漩涡值

漩涡值是需要围绕其运转的核心资源。由于我们的精通[[spell:168534]]，你会随机产生漩涡值，因此你必须时刻做好准备，避免资源溢出。这就是为什么尽快消耗漩涡值如此重要。

在某些范围伤害场合中，你会使用[[talent:101893]]，它会降低溢出的几率。

在游戏过程中，尽量提前预估你的法术会产生多少漩涡值，并学会判断一到两个公共冷却时间后你将拥有多少资源，这样你就可以提前规划你的输出循环。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents [[talent:123377]] **元素 萨满祭司** 内克扎莉 团本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 陵寝哨兵

:::talents [[talent:123377]] **元素 萨满祭司** 陵寝哨兵 团本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 迷失的探险者

:::talents [[talent:123377]] **元素 萨满祭司** 迷失的探险者团队副本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 瓦什尼克

:::talents [[talent:123377]] **元素 萨满祭司** 瓦什尼克团队副本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 斯索拉克

:::talents [[talent:123377]] **元素 萨满祭司** 斯索拉克 团本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 双牙

:::talents [[talent:123377]] **元素 萨满祭司** 双牙团队副本天赋
```json
{
  "source_code": "CaQAzgeAFxuEqbGMnx9WPPTYVCAAAAzMbLzMGjZZZZMmhBAAAAYxMbwAGwsxEysAAz2MzMGbLm2YmZbsMjZGDLWmxyMzYmZBAYGDgZGDDD",
  "code": "CaQAzgeAFxuEqbGMnx9WPPTYVCAAAAzMbLzMGjZZZZMmhBAAAAYxMbwAGwsxEysAAz2MzMGbLm2YmZbsMjZGDLWmxyMzYmZBAYGDgZGDDD"
}
```
:::




### 盘绕祭坛

:::talents [[talent:123377]] **元素 萨满祭司** 盘绕祭坛团队副本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 乌拉特克

:::talents [[talent:123377]] **元素 萨满祭司** 乌拉特克 团队副本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::




### 尼姆瑞莎·唤波者

:::talents [[talent:123377]] **元素 萨满祭司** 尼姆瑞莎·唤波者 团队副本天赋
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbLzMmZmZZZZMMjBAAAAsYmNYADY2YCZWAgZbmZGjtFTbMzsNWmxMjhFLzYxMDzsMAgZMAmZMMMA"
}
```
:::





## 属性优先级

了解你的副属性优先级以及**元素 萨满祭司**在 团队副本 首领战中获得最佳表现所需的副属性。欲了解更多详细信息，请访问 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **元素 萨满祭司** 团队副本 中的属性优先级
```json
{
  "source_code": "IoAJFUQMkACKBEQAEA"
}
```
**智力 ＞ 精通 ＞ 急速 ＞ 暴击 ≫ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可减少“**范围效果**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外的治疗。
- **加速** - 小众副属性，但可能非常有用，过去已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271483@DiQAAYQAnk7cVrTOC4UA]] | 套装 / 催化 |
| 项链 | [[item:268265@BERAAYQA8z6wPrTOCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271481@DgQAAYQAXk7kjAOF]] | 套装 / 催化 |
| 披风 | [[item:239656@FgQAAYQAno6gBwzt1sUA]] | 制造业 |
| 胸部 | [[item:271876@DARAAYQAJk7kjAMWDWB]] | 套装 / 催化 |
| 护腕 | [[item:244584@DiQAAYQAYA8wPrzt1sUA]] | 制造业 |
| 手套 | [[item:271484@BgQAAYQA5IgTBA]] | 套装 / 催化 |
| 腰带 | [[item:268254@BiQAAYQA8z6kjAOF]] | 瓦什尼克 |
| 腿部 | [[item:271482@DgQAAYQAFo6kjAOF]] | 套装 / 催化 |
| 靴子 | [[item:268233@DgQAAYQAxj7kjAOF]] | 斯索拉克 |
| 戒指 1 | [[item:268249@DiQAAYQA1j7wPrTOC4UA]] | 瓦什尼克 |
| 戒指 2 | [[item:252258@DiQAAYQA1j7wPrjgC4UA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:270164@BgQAAYQA5IgTBA]] | 迷失的探险者 |
| 饰品 2 | [[item:270167@BgQAAYQA5IgTBA]] | 尼姆瑞莎·唤波者 |
| 主手 | [[item:271092@DgQAAYQA_k7kjAYF]] | 乌拉特克 |
| 副手 | [[item:268262@BgQAAYQA5IgTBA]] | 尼姆瑞莎·唤波者 |




### 可刷取的替代装备

下面为你提供一份不错的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁CD系统之外获取。虽然随着你的进度推进它们最终会被替换，但能立即提升角色强度。

| 部位 | 物品 | 获取途径 |
| --- | --- | --- |
| 头部 | [[item:251220@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 项链 | [[item:251142@AgQAAIoABFA]] | 密谋小径 |
| 肩部 | [[item:239049@AgQAAIoABFA]] | 诸王之眠 |
| 披风 | [[item:251190@AgQAAIoABFA]] | 夺目谷 |
| 胸部 | [[item:251233@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 护腕 | [[item:251200@AgQAAIoABFA]] | 夺目谷 |
| 手套 | [[item:160213@AgQAAIoABFA]] | 诸王之眠 |
| 腰带 | [[item:251228@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 腿部 | [[item:159375@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 靴子 | [[item:159388@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:252258@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:273792@AgQAAIoABFA]] | 毒牙祭坛 |
| 饰品 1 | [[item:273649@AgQAAIoABFA]] | 诸王之眠 |
| 饰品 2 | [[item:250224@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 主手 | [[item:273778@AgQAAIoABFA]] | 毒牙祭坛 |
| 副手 | [[item:251150@AgQAAIoABFA]] | 纳洛拉克的洞穴 |





### 饰品

下面你可以找到可用饰品的主动与被动排名。请注意，根据每个首领战的不同，某些饰品会比其他饰品表现更好。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270167@BgQAAYQA5IgTBA]]  <br>[[item:270164@BgQAAYQA5IgTBA]] |
| **A级** | [[item:273649@AgQAAIoABFA]]  <br>[[item:270169]]  <br>[[item:250215@AgQAAIoABFA]] |
| **B级** | [[item:250224@AgQAAIoABFA]] |
| **C级** | [[item:193757@AgQAAIoABFA]] |
| **垃圾级** | [[item:250259@AgQAAIoABFA]]  <br>[[item:158368@AgQAAIoABFA]] |

### 美化饰品

- 2x [[item:240166]]

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **瓶装合剂**
  
  - [[item:241324]]
  - [[item:241322]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]] *-- 默认*
  - [[spell:318038]] 如果你点出了该天赋。
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240892]]
  
  
  
  - [[item:240983]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAAYQA]] |
| --- | --- |
| 肩部 | [[item:243991]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAAYQA]] |
| 腰带 | [[item:275707@BAAAAYQA]] |
| 腿部 | [[item:240133@BAAAAYQA]] |
| 靴子 | [[item:243953@BAAAAYQA]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 武器 | [[item:244031]] |

:::

:::column
:::gear **元素 萨满祭司** 团队副本 中的附魔
```json
{
  "source_code": "IQFZGEQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAYQA]]，为你的 **头盔**、**护腕** 和 **腰带** 添加插槽。

## 种族

对于想要在 **元素 萨满祭司** 团本中追求极致优化（min-max）的玩家来说，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族也同样可行。

- [[spell:65116]] -- 矮人
  
  - 驱散魔法和流血减益效果。在过去某些有流血机制的首领战中曾经很有用。
- [[spell:69070]] -- 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在[[spell:69070]]动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:26297]] *-- 巨魔* 
  
  - 强力的 DPS 主动种族技能，与[[talent:101860]]配合得很好。
  - 使移动限制效果的持续时间缩短 20%。在近期的开荒团队副本历史中只用上过一次，但仍值得一提。
- [[spell:33702]] *-- 兽人* 
  
  - 强力的 DPS 主动种族技能。
  - 使你受到的眩晕持续时间缩短 20%，在某些情况下很有用。

### 推荐

总的来说，可以肯定地说，如果你在意将 DPS 优化到极致，你应该选择 DPS 最高的种族。话虽如此，如果是针对开荒团本，情况就有所不同了。某些种族特性可以在特定首领战中极大加快开荒进度。

矮人 是推荐种族，因为它既是 DPS 最强的种族，也是 大秘境 的最佳种族。

## 宏

了解元素萨满在团队副本战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:61882]]** -- *在无需确认的情况下，将 [[spell:61882]] 施放在你的鼠标光标处。*

```wow-macro
#showtooltip
/cast [@cursor] 地震术
```

**[[spell:192077]] --** *在无需确认的情况下，将 [[spell:192077]] 施放在你的鼠标光标处。*

```wow-macro
#showtooltip
/cast [@cursor] 狂风图腾
```

**[[spell:108287]]** -- *无需确认，直接对光标位置施放[[spell:108287]]。*

```wow-macro
#showtooltip
/cast [@cursor] 图腾投射
```

:::

:::details 鼠标指向宏
**[[spell:188389]]** -- *对鼠标指向的目标施放[[spell:188389]]。*

```wow-macro
#showtooltip 烈焰震击
/cast [@mouseover, exists] 烈焰震击; 烈焰震击
```

:::

:::details 实用 宏
**[[spell:51514]]**  -- *对鼠标指向的目标或当前目标施放[[spell:51514]]。*

```wow-macro
#showtooltip 妖术
/cast [@mouseover, exists] 妖术; 妖术
```

**[[spell:8004]]** *-- 通过鼠标指向或选中目标，快速对队友施放[[spell:8004]]*。

```wow-macro
#showtooltip 治疗之涌
/cast [@mouseover, exists] 治疗之涌; 治疗之涌
```

:::

:::

## 插件

下方是作者为其**元素 萨满祭司**的用户界面截图，其中标明了使用了哪些插件，以及在团队副本中如何利用这些插件来让你的游戏体验更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/wolf-ele-raid-1-1024x681.webp>)

**元素 萨满祭司**在团队副本中的界面

:::accordion
:::details 插件
- **MRT** -- 备注、团队副本冷却技能等
  
  - 对团队副本玩家很有帮助的插件，尤其适合团队副本团长和官员。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件旨在为某个特定的团队副本战斗触发警报信息、计时条、音效等。
- **Plater**  -- 高级姓名版
  
  - Plater 是一个姓名版插件，拥有极其丰富的设置项，开箱即用的减益效果监控、威胁着色，并支持类似 WeakAuras 的脚本功能，还可通过 wago.io 和 WeakAuras-Companion 更新模组/脚本/配置文件。
- **Details** -- 深度伤害统计
  
  - 最强大、最可靠、最漂亮的伤害统计插件。
- **Bartender4** -- 动作条插件
  
  - Bartender4 为你提供可自定义程度更高的动作条。

:::

:::

## 本次版本改动

:::accordion
:::details **12.1版本**
**英雄天赋**

- 先知
  
  - 开发者说明：在之前针对元素 萨满祭司的一次调整热修中，先知之魂得到了一个小改动，使其随元素之怒天赋缩放。我们正在修改其他几个它们未能与萨满祭司技能保持相同缩放方式的地方。
  - 闪电链现在最多可命中5个目标（原为3个）。
  - 熔岩爆裂现在还会使伤害提高，百分比数值等于你的爆击几率。

**元素**

- *开发者说明：由于⟦WOWTERM_00004⟫中的改动，元素萨满祭司在升腾窗口期间的爆发伤害高于我们的预期。我们不想让升腾不再是一个显著的伤害放大器，但那些同时提升升腾和顶尖天赋中元素超载伤害的复合效果相互叠加在了一起。我们将把更多的伤害分散到你的法术中，以造成更稳定的高伤害，同时在升腾期间仍能获得不错的伤害峰值。*
- 漩涡之力已重新设计——闪电箭和闪电链有15%的几率使你的下一个熔岩爆裂伤害提高20%，最多可叠加2次。熔岩爆裂每次消耗一层。
  
  - *开发者说明：超荷充能和漩涡之力原本都是额外的、随机的元素超载。我们认为其他改动会让你的伤害更加稳定，同时仍允许你天赋树的其他部分继续增加元素超载法术的数量或威力。*
- 风暴守护者已更新——不再使闪电箭产生额外的元素超载。
- 熔岩爆裂伤害提高30%。该改动不适用于PvP战斗。
- 闪电箭伤害提高30%。该改动不适用于PvP战斗。
- 闪电链伤害提高60%。
- 烈焰震击伤害提高60%。
- 狂风怒号直接伤害降低20%。
- 治疗之涌治疗量提高25%。
- 大地之盾治疗量提高25%。
- 治疗之泉图腾治疗量提高25%。
- 升腾现在使元素超载的伤害提高30%（原为75%）。
- 激活升腾时获得的额外熔岩爆裂现在为其正常数值的50%（原为100%）。
- 熔岩之怒现在使熔岩爆裂的伤害提高10%（原为15%）。
- 顶尖天赋：反馈循环（等级1）现在使元素超载伤害提高10%（原为35%），同时使元素造成的伤害提高10%。
- 顶尖天赋：反馈循环（等级2）现在提供15%/30%的暴击伤害加成（原为25%/50%）。
- 由元素融合施放的元素冲击现在只提供元素冲击属性增益正常持续时间的40%（原为100%）。
- 修复了流电炽焰未正确受到元素之怒暴击伤害加成影响的问题。
- 修复了元素共鸣未影响元素周期性伤害的问题。
- 修复了顶尖天赋：反馈循环（等级2）未正确提高若干元素萨满祭司法术暴击伤害的问题。
- 英雄天赋
  
  - 先知
    
    - 先祖的熔岩爆裂伤害降低20%。
    - 先祖的闪电链伤害降低20%。
  - 风暴使者
    
    - 超荷充能已重新设计——闪电箭、闪电链和狂风怒号超载额外造成10%的伤害。

:::

:::

:::accordion
:::details **12.0版本**.1
- **所有伤害降低5%。**
- **闪电箭伤害降低10%。**
- **治疗之涌治疗效果提高130%。**
- **治疗之泉图腾治疗效果提高50%。**
- **大地之盾治疗效果提高50%。**

:::

:::

:::accordion
:::details **12.0版本**
- **英雄天赋** 
  
  - 先知
    
    - 新天赋：  **先祖加持 – 每有一名先祖激活，你的智力提高1%。**
    
    
    
    - **新天赋：风语者 元素：治疗之涌、治疗链和熔岩爆裂的施法时间缩短10%。**
    
    
    
    - **新天赋：灵性学识 元素：使熔岩奔腾的发生几率提高20%。**
    
    
    
    - **元素余响现在使熔岩爆裂的伤害提高10%（原为20%）。**
    
    
    
    - **所有先祖的治疗量降低40%。**
    
    
    
    - **元素 先祖的召唤已更新——风暴守护者会召唤一名先祖到你身旁，持续8秒。**
- **例行交流现在可以由烈焰震击和流电炽焰触发。**
- **“来自彼方的献礼”现在改为：当有先祖被召唤时，使风暴守护者的冷却时间缩短3秒（原为使火焰/风暴元素的冷却时间缩短5秒）。**
  
  - **风暴使者** 
    
    - **新天赋：自然赠礼 – 自然伤害提高2%。**
    - **新天赋：天穹崩落 – 升腾会将你的下一个闪电箭升级为狂风怒号。**
    - **新天赋：风暴之井 元素：风暴元素的持续时间延长2秒，且风暴守护者会产生10点漩涡值。**
  - **元素 狂风怒号的发生几率已被重新设计——不再根据消耗的漩涡值总量触发，现在每消耗1点漩涡值有0.3%的几率发生。**
  - **狂风怒号的单体伤害提高25%。**
  - **弧形放电已被重新设计——现在使狂风怒号给予一层风暴守护者。**
  - **滚雷已被重新设计——现在使风暴守护者的冷却时间缩短15秒。**
  - **“觉醒风暴”已被重新设计——现在每消耗1点漩涡值，额外提高0.3%获得狂风怒号的几率。**

:::

:::

## 常见问题

:::accordion
:::details 问：推荐选择哪个[[spell:61882]]？
**A：** 总体而言，用鼠标来定位的那个更好，因为如果怪物正在被移动，你可以提前把它放到怪物前方；而释放在你目标身上的那个用起来可能更顺手。

:::

:::

---

### 致谢

作者：**Stove**

审校：**Rycn**

---

:::changelog 更新记录
**2026-08-07** 更新至12.1版本

**2026-06-23** 更新至12.0.7版本

**2026-04-25** 更新至12.0.5版本

**2026-01-18** 更新至12.0版本

**2025-12-03** 更新至11.2.7版本

**2025-10-08** 更新至11.2.5版本

**2025-08-06** 更新至11.2版本

**2025-06-16** 更新至11.1.7版本

**2025-04-21** 更新至11.1.5版本

**2025-02-23** 更新至11.1版本

**2024-12-17** 更新至11.0.7版本

**2024-10-23** 更新至11.0.5版本。

**2024-08-17** 更新至11.0.2版本。

**2024-07-24** 攻略撰写于11.0.1前夕版本。



:::
