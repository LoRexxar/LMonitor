Welcome to the **Protection Paladin** raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 2/5 · Weak

Mobility · 2/5 · Weak



:::

:::

:::column
:::gear **Protection Paladin Raid Best in Slot**
```json
{
  "source_code": "JQpAgLEA3_fABkGJEIICFAw74OwVtOggC4UAKX6ABk-FEAQEBAg_sOg_sOAj1kjAYFQAnRCBCgQBAUTuDEgJU0bpDEAbkUgEAkQASgCWB47FEEw4XQAgIUAOAIYAzAjBmQgAQEAAhu7AWYTOBEBdEE6AGgQAAUXZDciqD8QuDcbNLFQAKE6AEiQAAYBwBUBB-zaCVQmakQAAIUAACKgTB4U1DEg6XQgAJEAAvk7A-XAlBgBDBMubCYUFAQBVfQAAIEQB5QQAdFBDQgVAB09FNgBLYFQAxeBBCgQAA0TuJcKKkeBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271878]] | [[item:244641]] |
| 脚部 | [[item:237828]] | [[item:222581]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:268196]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Protection Paladin**, you have access to Glory of the Vanguard, which gives [[spell:275779]] a chance to grant [[spell:1268810]], that empowers your next [[talent:102471]] to deal additional AOE damage in a line between you and your target.

**Rank 2** increases damage done by [[spell:275779]] and makes consuming [[spell:1268810]] generate Holy Power. While **Rank 3** makes [[spell:53600]] deal more damage after consuming [[spell:1268810]], and causes [[talent:102471]] to always benefit from [[spell:1268810]] during [[talent:102448@FJQA41dBCEA]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-protpala-mxr.webp>)

Glory of the Vanguard

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look at **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:76671@FJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEA]] 
    
    - Does not provide damage reduction while standing in your [[spell:26573]] anymore, which allows you to move more freely. The only incentives to stay in [[spell:26573]] now are keeping the mobs in it for AOE damage, and 5% damage reduction from [[talent:102436]], which are not as crucial as damage reduction from [[spell:76671@FJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEA]] used to be.
    - Now allows you to block spells baseline. Basically includes the effect of [[spell:152261]], which was removed.
  
  
  
  - [[spell:1246481]]
    
    - Grants [[talent:102456]] a second charge. With other class changes that make defensive cooldowns more sparse, this talent is mandatory in any challenging content.
  - [[spell:1246488]]
    
    - New talent that makes your [[spell:275779]] chain to 2 additional targets for 50% damage.
- **Class Tree**
  
  - [[spell:1241288]]
    
    - Instead of being a separate spell, it now passively empowers [[spell:275779]] during [[talent:102448]] to deal more damage. Additionally, [[spell:1241958]] increases the damage done based on your target's missing health.
  - [[spell:1241945]]
    
    - Now reduces damage taken by up to 10%, increasing with your missing health.
  - [[spell:183416]]
    
    - Redirects 5% damage taken by your allies to you while you're above 85% HP, instead of boosting your holy power spending abilities
- Removed
  
  - Resolute Defender
    
    - Was reducing cooldown of [[talent:102445]] and [[spell:642]] when spending Holy Power.
    
    
    
    - Together with [[spell:204074]] rework, this results in the complete removal of the cooldown reduction aspect of Protection Paladin gameplay. All defensive and offensive cooldowns are now static, making their usage more predictable and easier to plan around.
  - [[spell:387174]]
    
    - Removes a short defensive cooldown from our toolkit.
  - [[spell:378974]] and [[spell:327193]]
    
    - These were almost always used on cooldown without greatly altering the rotation, resulting in 2 fire-and-forget buttons that did not make the rotation much more interesting.
  - [[spell:385724]] and [[spell:379043]] 
    
    - These changes remove the gameplay around maintaining 100% spell block chance for big magic hits.

## Hero Talents

- Both [[talent:123361]] and [[talent:123358]] are very competitive choices. Currently [[talent:123361]] performs better both on ST and cleave fights. Therefore, for raiding as a Protection Paladin, we recommend [[talent:123361]].

:::tabs
:::tab [[talent:123361]]
- As [[talent:123361]] you receive [[talent:117882]], which alternates between:
  
  - [[spell:432459]]: An absorb shield for 15% your maximum health, gaining an additional 2% absorb every 2 seconds for 20 seconds.
  - [[spell:432472]]: A damaging buff that has a chance to deal Holy damage to nearby enemies and lasts 20 seconds. The effect is increased on single-target and reduced when striking more than 5 targets.
- [[talent:117882]] has 2 charges and rotates from [[spell:432459]] to [[spell:432472]].
  
  - Both armaments can be cast on yourself or an ally. With [[talent:117873]], casting it on an ally also grants you the effect, and vice versa.
- [[talent:117875]]:
  
  - Activating [[spell:31884]] summons an additional [[spell:432472]].
  - This additional [[spell:432472]] deals extra damage by echoing your Holy Power abilities.
  - This makes [[spell:31884]] an even stronger cooldown.
- [[talent:117877]] can randomly trigger a [[talent:117882]] effect on a nearby ally.
- [[talent:117883]] increases the damage of [[talent:102430]] / [[talent:102431]] by 100% after casting a Holy Power ability.
- [[talent:117881]] is a buff to armor and primary stat that replaces weapon oils.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:136000]] makes your next 3 abilities after casting [[talent:117882]] summon a lesser version of it.
- [[talent:136002@AJgABA]] makes [[talent:136496@FJQAEdhACEA]] also trigger [[talent:136001@AJgABA]].
- [[talent:117887@AJgABA]] gives you a chance to gain [[talent:102453]] whenever your [[talent:117882]] absorb or do damage.

:::

:::tab [[talent:123358]]
- After casting [[talent:136496@FJQAEdhACEA]], it is replaced with [[spell:427453]] for 12 seconds. 
  
  - [[spell:427453]] costs 3 Holy Power and deals high AoE damage.
  
  
  
  - You should cast [[talent:136496@FJQAEdhACEA]] and then use [[spell:427453]] on cooldown.
- [[talent:117823]] triggers an [[spell:431398]] on a nearby target every 2 seconds, for 8 seconds after using [[spell:427453]].
- [[talent:117811@FAQAEdhA]] extends [[talent:117823]] by 1 second every time you cast:
  
  - [[talent:102430]] / [[talent:102431]]
  - [[spell:275779]] or [[talent:133481@AJgABA]]
- [[talent:117818@FAQAEdhA]] causes your [[spell:53600]] and [[spell:85673]] to call down an [[spell:431398]] on a nearby target. While [[talent:117823]] is active, this effect calls down **an additional** [[spell:431398]].
- [[talent:117815]] allows you to cast [[spell:427453]] for free after triggering [[spell:431398]] 60 times.
- [[talent:117822@FAQAEdhA]] makes [[spell:427453]] to:
  
  - Give you 12% haste for 6 seconds.
  - Grant [[spell:53600]].
  - Place a [[spell:26573]] under your target.
- [[talent:117810]] causes [[spell:431398]] critical strikes to cleave to another target and grants you 5% damage reduction for 8 seconds against affected mobs. This effect significantly increases the value of critical strike in cleave and AoE situations.
- [[talent:117858]] fixes a lot of mobility issues for Protection Paladin by providing a 2 second longer [[talent:102625]] and increasing your movement speed by an additional 30% for the first 3 seconds.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:136005]] makes [[talent:136496@FJQAEdhACEA]] summon Divine Hammers that deal AOE damage around you for 8 seconds.
- [[talent:136004@FAQAEdhA]] makes your [[spell:431398]] to do increased critical strike damage and grant an additional stack of [[talent:117815@FAQAEdhA]] when it crits.
- A new choice node:
  
  - [[talent:136003]] makes [[talent:136003]] to be cast 2 additional times on your target.
  - [[talent:136184@FAQAEdhA]] increases [[spell:275779]] damage by 30%.

:::

:::

## Talents

:::tabs
:::tab [[talent:123361]] Single Target
:::talents **Protection Paladin** Raid [[talent:123361]] Single Target Build
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxMGAgBAAAAAANNzsMzYGMmt2AwAAGsBAAmZabmZbmZmltlWmZsYbjZAMGzwYAwMz2MAzMgxC",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxMGAgBAAAAAANNzsMzYGMmt2AwAAGsBAAmZabmZbmZmltlWmZsYbjZAMGzwYAwMz2MAzMgxC"
}
```
:::

### When to use this spec

This is the default loadout going into pure single-target boss encounters. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Raids section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[spell:204074]]
  
  - Reduces cooldown of [[talent:102448@FJgA41dBACNACEA]] by 50% and it's duration by 40%, making it a shorter 1 minute cooldown.
- [[spell:204018]]
  
  - Used to completely immune magic damage and prevent debuff applications on yourself or your allies .
- [[talent:102466]]
  
  - Grants [[talent:102456]] an additional charge.
- [[spell:182104]]
  
  - Makes your [[spell:85673]] free after 3 [[spell:53600]] casts, stacking up to 2 free uses.

#### Class Tree

- [[talent:102596]]
  
  - Allows the use of [[spell:642]] even when you have [[spell:25771]] debuff.

- [[talent:102603@FAQAqxH]]
  
  - Significantly increases uptime on your strongest defensive cooldowns - [[spell:31850]] and [[spell:642]].
- [[talent:136503]]
  
  - Casts a free [[spell:85673]] at 60% effectiveness when dropping below 25% health. This effect has a 1 minute cooldown.
- [[spell:223817]]
  
  - Holy Power spenders have a chance to make your next [[spell:85673]] or [[spell:53600]] free and deal 15% increased damage and healing.
- [[talent:102465@FJQAEdhACEA]]
  
  - Casts [[talent:102471]] on up to 5 targets, generating 1 Holy Power for every target hit.
  - Instantly casts an [[talent:102471]] every 5 seconds for 15 seconds via [[spell:384027]] (if talented).
  - Powerful burst for AoE threat, Holy Power generation, and utility.

:::

:::tab [[talent:123361]] Cleave
:::talents **Protection Paladin** Raid [[talent:123361]] Cleave Build
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB"
}
```
:::

### When to use this spec

Use this build on any cleave fight, where you either can't benefit from [[talent:102435]] for the majority of the fight, or AOE damage is needed for dealing with a large number of adds.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[talent:102434]]
  - [[talent:102461]]
  - [[talent:102474@FAgAbHNBvj4A]]
- **Removed**
  
  - [[talent:102435]]
  - [[talent:102446]]

:::

:::tab [[talent:123358]]
:::talents **Protection Paladin** Raid [[talent:123358]] **Build**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGb22YGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGb22YGAjxMMGAMzsNDwMDYsA"
}
```
:::

### When to use this spec

This is the [[talent:123358]] version of the raid build. Use it if you prefer [[talent:123358]] playstyle, or want to have more mobility with [[talent:117858]].

### Talent Adjustments

#### Hero Talents

**Changed** to [[talent:123358]]. For more info, visit the **Hero Talent** section above.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:26573]] is 30% larger and enemies within your [[spell:26573]] are illuminated, increasing the chance for your abilities to critically strike them by 5%.
- **4-Set:** Enemies struck by [[spell:20271]] or [[spell:204019]] take 20% additional Holy damage. If they are struck by a critical strike, the additional damage is increased by 100%.

### Opener

- The goal of your rotation as a **Protection Paladin** is generating and spending as much Holy Power as possible, while not losing out on [[talent:102471@FAgAtWcBtHzA]] casts.

:::tabs
:::tab [[talent:123361]]
:::rotation **Protection Paladin** [[talent:123361]] Opener in Raid
```json
{
  "source_code": "JQaAQxgQLlpBAAACQJXZtAVdsxGAC18ZA0BE8NQAd66AAAAAAI0oxXAAAI0N2MAAAIEG7WAAAAQACBW0BoBC_yHAd4ABT7VAOwAAC1gHJgTCQEBLJYBBBIUCkkAHRwSEkYDUAQQznB"
}
```
1. [[spell:432459]] Pre-Pull
2. [[spell:26573]] Pre-Pull [[item:241309]] · [[spell:389539]] · [[spell:210487]]
3. [[spell:375576]]  [[spell:53600]]
4. [[spell:31935]]  [[spell:53600]]
5. [[spell:24275]]
6. [[spell:204301]]
7. [[spell:24275]]  [[spell:53600]]
8. [[spell:204301]]
9. [[spell:24275]]
10. [[spell:204301]]  [[spell:53600]]
11. [[spell:31935]]  [[spell:53600]]
12. [[spell:26573]]
:::

- Important thing to note when using [[spell:432472]] is that it cannot stack. This means that the [[spell:432472]] that spawns from [[spell:31884]] should be used first, and the normal cast one used later after the first one has run out. 
  
  - This can also occur with [[talent:117877]], so be careful and make sure you track this buff well.
  - Other than the above, use [[talent:117882]] off cooldown.

:::

:::tab [[talent:123358]]
:::rotation **Protection Paladin** [[talent:123358]] Opener in Raid
```json
{
  "source_code": "JgFwHIUznBAAAgAUyVWLQVHbsJQAd66AAAAAAI0oxXAAAIEG7WAAAAQACBW0AAAAC9LfAUAHI0bhGUACEMtXBcADAI08ckANkMtXAAAAAEgQgFN"
}
```
1. [[spell:26573]] Pre-Pull [[item:241309]] · [[spell:389539]]
2. [[spell:375576]]  [[spell:53600]]
3. [[spell:31935]]
4. [[spell:427453]]
5. [[spell:24275]]
6. [[spell:204019]]
7. [[spell:24275]]  [[spell:53600]]
:::

- Cast [[talent:136496@FJQAEdhACEA]] on cooldown to be able to cast [[spell:427453]] as often as possible and keep high uptime on [[talent:117823]].

:::

:::

### Priority List

:::tabs
:::tab [[talent:123361]]
1. Use [[spell:31884]] with [[spell:375576]] on cooldown.
2. Use [[spell:53600]] at 3-5 Holy Power.
3. Use [[spell:31935]] during [[spell:31884]] or with a [[spell:1268810]] proc under 3 Holy Power.
4. Use [[spell:20271]] if you have 2 charges.
5. Consume 5 [[talent:117884]] stacks with [[spell:26573]].
6. Use [[spell:432472]] if the remaining cooldown on [[spell:31884]] is more than 20 seconds and you don't already have a [[spell:432472]] active.
7. Use [[spell:31935]].
8. Use [[spell:26573]].
9. Use [[spell:20271]].
10. Use [[spell:204019]].

:::

:::tab [[talent:123358]]
1. Use [[spell:31884]] with [[spell:375576]] on cooldown.
2. Use [[spell:427453]] if you do not already have [[talent:117822@FAQAEdhA]] buff.
3. Use [[spell:53600]] at 3-5 Holy Power.
4. Use [[spell:31935]] during [[spell:31884]] or with a [[spell:1268810]] proc under 3 Holy Power.
5. Use [[spell:20271]] if you have 2 charges.
6. Use [[talent:102431]] if you have 3 charges.
7. Use [[spell:31935]].
8. Use [[spell:26573]].
9. Use [[spell:20271]].
10. Use [[spell:204019]].

:::

:::

### Defensive Cooldowns

- [[spell:31850]]
  
  - Your primary defensive cooldown.
  
  
  
  - Includes a cheat death component, allowing survival against extreme hits.
- [[spell:86659]]
  
  - The biggest damage reduction ability in your toolkit.
  - Has 2 charges with [[talent:102466]].
- [[spell:204018]]
  
  - Grants immunity to magic damage and prevents the application of magic debuffs.
  
  
  
  - Can be used for yourself or for other players.
  - Does not cause you to lose threat while active, unlike [[spell:1022]].
- [[spell:642]]
  
  - If used appropriately, this is the most powerful defensive ability that allows you to be completely immune to some mechanics. For more details, check out the **Deep Dive**.
  - [[spell:204077]] allows you to keep threat of nearby enemies while [[spell:642]] is active.

## Deep Dive

### Utilizing Blessing of Protection and Blessing of Spellwarding

- Properly utilizing [[spell:1022]] and [[spell:204018]] allows you to **immune** dangerous mechanics entirely, even if they are not targeted at you.
- Both [[spell:1022]] and [[spell:204018]] share a cooldown.
- [[spell:1022]] can be used to make a player that is fixated by enemies immune to physical damage, allowing them to maintain uptime on the boss and focus on DPS or healing instead of kiting.
- It removes existing **physical debuffs** (e.g., bleeds) and **stuns**, and prevents new ones from being applied.
- [[spell:204018]], on the other hand, does **not** remove existing **magical debuffs** — it only prevents **new** ones from being applied while active.
- Clever use of [[spell:204018]] or [[spell:1022]] can save your teammates, often preventing wipes and accelerating boss progression.
- Note that [[spell:1022]] causes threat loss for its duration. [[spell:204018]] does not have the same effect, so you can safely use it on yourself while actively tanking.

### Using Hand of Reckoning with Divine Shield and Blessing of Protection

- Using [[spell:62124]] right before or during the effect of [[spell:642]] or [[spell:1022]] allows you to keep threat of your target for the duration of [[spell:62124]].
- This leads to you being immune - fully in case of [[spell:642]], or against physical damage in case of [[spell:1022]] - while still tanking the boss. It allows you to achieve the effect of [[talent:102473]] on a **single target** without the need of talenting into it, but only for 3 seconds.
- In most typical boss fights, these 3 seconds are enough to cheese tank mechanics - for example, immune bursty tank hits or avoid tank debuff applications.
- To safely achieve this effect:
  
  1. Briefly before the tank mechanic (less than 3 seconds), use [[spell:62124]] on the boss.
  2. Use [[spell:642]] or [[spell:1022]]  on yourself.
  3. Wait for the boss to cast the mechanic you want to immune.
  4. Cancel [[spell:642]] or [[spell:1022]] before the effect of [[spell:62124]] expires using a following macro:

```wow-macro
/cancelaura Blessing of Protection  
/cancelaura Divine Shield
```

- Keep in mind that [[spell:1022]] will only immune **purely physical hits**. It will only negate the **physical part** of the damage on mechanics of mixed type, and will **not** work at all against magic damage.
- Note that you will only keep threat on the target affected by your [[spell:62124]], which makes this technique only applicable on single target encounters.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips apply to **Heroic Bosses** and to surviving them as effectively as possible. The recommended builds in this section are going to help you survive each encounter, but do not necessarily give you the highest damage output.

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Protection Paladin Raid Nek'Zali**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA"
}
```
:::

### Tank mechanics

- The main tank mechanic of this fight is Hollowing Strikes - a debuff that the boss applies with each melee strike, as well as with [[spell:1284103]].
- During [[spell:1284103]], the boss sends spectral echoes towards the active tank, applying extra stacks of Hollowing Strikes. These echoes burst on first impact with any player, dealing reduced raid 
  
  - When targeted by this mechanic, move out of the raid and make sure no one is standing between you and the boss so they don't trigger the echoes too early. Otherwise, they will deal too much damage to the raid.
  - Taunt swap after each cast of [[spell:1284103]].
- Apart from that, the boss will spawn waves of Restless Amani - make sure to move the boss next to them to allow for better cleave.
- During the intermission, the active tank will be targeted by a group soak - [[spell:1289855]]. Try to put it on top of as many Restless Amani corpses as possible to burn them with [[spell:1289875]] to prevent them from awakening again.

:::

:::tab Entombed Sentinels
:::talents **Protection Paladin Raid Entombed Sentinels**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA"
}
```
:::

### Tank mechanics

- The bosses have to always be separated by at least 40 yards due to [[spell:1290189]]. At the start of each phase, split the bosses apart by moving them to different sides of the room.
- [[spell:1284458]] and [[spell:1284487]] are the stacking tank debuffs of each of the bosses. Make sure to taunt swap on the bosses each time they meet in the middle of the room during [[spell:1284588]] to reset your stacks.
  
  - [[spell:1284487]] additionally creates a large pool of blood upon expiration. Make sure to drop it off at the edges of the room if possible.
- Don't tank Breath of Ula'tek too close to the existing blood puddles so the [[spell:1284251]] doesn't spawn in the pool and melees can safely attack it.

:::

:::tab Lost Explorers
:::talents **Protection Paladin Raid Lost Explorers**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA"
}
```
:::

### Tank mechanics

- All three bosses cannot be positioned within 30 yards of each other due to [[spell:1297645]] - always keep one of the bosses away from the other 2.
- Trader Gebbo just wanders around the room and doesn't follow or attack its threat target. It also doesn't have any tank mechanics.
- Scrollsage Iku casts [[spell:1295854]] at its current target - a series of ice shards, each doing magic damage and increasing damage taken from the next shard for 80 seconds.
- First Mate Nama applies [[spell:1291929]] with each attack to its target, increasing physical damage done to that target for 30 seconds.
- The job of the tanks on this fight is to swap between Scollsage Iku and First Mate Nama, never letting [[spell:1295854]] to be casted at the same target twice and resetting [[spell:1291929]] as often as possible, while always keeping one of the bosses far enough to prevent [[spell:1297645]] from being applied.

:::

:::tab Vashnik
:::talents **Protection Paladin Raid Vashnik**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB"
}
```
:::

### Tank mechanics

- There are 3 fountains placed on the sides of the room: Fountain of Blood, Fire, and Shadow. The boss will activate the two closest ones with [[spell:1283164]] throughout the fight, gaining their powers and spawning some adds.
  
  - Each fountain activation empowers the next activation for 1.5 minutes.
  
  
  
  - Your job as a tank is to never let the boss activate the same two fountains in a row by moving the boss to the next fountain before each [[spell:1283164]] cast.
  - Make sure to position the boss on top of the adds coming from the fountain for better cleave. However, be careful with quickly killing all the fire adds, as they apply stacking [[spell:1285979]] when they die.
- Vashnik's tank hit is [[spell:1280935]], taunt swap after each cast.

### General tips

- [[talent:102583@FAQAPreB]] with [[talent:128255]] talented heals through the heal absorb from [[spell:1295224]], which is very useful to help your teammates out.

:::

:::tab Sszorak
:::talents **Protection Paladin Raid Sszorak**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftNjtZZmZMzMzMWGjxswwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftNjtZZmZMzMzMWGjxswwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA"
}
```
:::

### Fight mechanics

- [[spell:1277025]] is a combination of tank frontals consisting of 2 [[spell:1277002]], 2 [[spell:1277027]], and one [[spell:1287072]], cast in a random order.
  
  - [[spell:1277002]] is a frontal cone that deals heavy physical damage and follows the active tank. Make sure to aim it **away from the raid**.
  - [[spell:1277027]] is a frontal cone that applies a heavy magic DOT, which is reduced by the number of people hit by the cone. Make sure this ability is aimed into one half of the raid, so people can soak it.
  - [[spell:1287072]] spawns a bunch of tornadoes around the boss and sends them outwards at the end of the cast. Make sure you're not under the boss when this happens and dodge the tornadoes.
  - In heroic and mythic difficulties, the boss will cast these in a random order. Since each frontal cone applies a damage taken increase from that ability, make sure that one tank never takes 2 of the same abilities. Keep in mind that you can taunt during the cast so the boss aims the frontal cone at you instead.
- Each cast of [[spell:1306120]] spawns [[spell:1305998]] puddles around the boss. Make sure to move the boss to an edge of the room, ideally opposite the [[spell:1285732]] spawn, so that the puddles get blown off the edge of the room by the winds.
- Apart from that, Sszorak applies a stack of [[spell:1282869]] with each melee attack, increasing physical damage taken by the target. Taunt swapping on each [[spell:1277025]] combo is enough to reset the stacks.

:::

:::tab Twin Fangs
:::talents **Protection Paladin Raid Twin Fangs**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA"
}
```
:::

### General mechanics

- The entire fight revolves around managing [[spell:1290336]] stacks
  
  - [[spell:1291404]], [[spell:1291478]], getting hit by poison waves, or soaking [[spell:1289201]] applies a stack of [[spell:1290336]].
  - Reaching 10 stacks in Heroic or 9 in Mythic difficulties immediately kills you.
  - It is crucial to dodge as many poison waves as possible while managing how many [[spell:1289201]] you soak to prevent reaching maximum stacks of this debuff.

### Tank mechanics

- Being outside of melee range of the boss that you're actively tanking will cause it to cast [[spell:1295107]] or [[spell:1295113]], so make sure to never leave melee or use a big personal if you ever find yourself far from the boss.
- Vexhul's tank ability is [[spell:1289192]], which deals nature damage and pushes you back for 5 seconds.
  
  - It also spawns [[spell:1289201]] around you. These need to be soaked by players before they explode to prevent everyone from getting an [[spell:1290336]] stack.
  - Each hit applies [[spell:1310360]], so taunt swap between every [[spell:1289192]] cast.
  - Be aware of the pushback, especially when the poison waves are coming!
- Ithraz casts [[spell:1288538]], pushing back players close to the boss and spawning 3 soak zones.
  
  - Each zone deals heavy physical damage and increases the damage taken from the next zone by 33%. If it is left unsoaked, it deals raid-wide damage and knocks everyone away. Make sure to taunt swap between each set of [[spell:1288538]] to reset the stacks of the damage increase.
  
  
  
  - The zones spawn in a random order and need to be soaked in the same order that they spawned. Pay attention to the spawns and memorize the spawn order when this ability is happening. The boss will also shortly face towards the zone it will trigger next, so you can use that direction if you can't remember the spawn order.
  - Each second [[spell:1288538]] cast overlaps with poison waves coming - make sure you're not getting hit by waves while soaking the [[spell:1288538]].
  - Watch out for the pushback at the start of this mechanic, as it can push you into an incoming wave or a [[spell:1289201]].

:::

:::tab Coiled Altar
:::talents **Protection Paladin Raid Coiled Altar**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA"
}
```
:::

### Phase 1

- Only Zul'jan is active during this phase.
- He casts [[spell:1299960]], which spawns multiple [[spell:1282403]] orbs during this phase. They deal pulsing raid-wide AOE while they're active, and can be picked up and moved by players running into them.
- [[spell:1299684]] is a frontal cone aimed at the active tank that deals physical damage and destroys any [[spell:1282403]] it hits.
  
  - It also increases damage taken by the next [[spell:1299684]] by 200%, so make sure to taunt swap after every cast.
- The goal of this phase is for the raid to group up the [[spell:1282403]] orbs so they can then be destroyed by [[spell:1299684]].
  
  - **Protection Paladin** is especially good for collecting the orbs while not actively tanking, due to high mobility with [[talent:102625]].
- Additionally, each cast of [[spell:1282487]] empowers the next 23 melees of the boss with [[spell:1300322]], dealing extra nature damage to the tank. 
  
  - Make sure to frontload defensives while the boss has stacks of [[spell:1300322]].

### Phase 2

- Only Hex Lord Malacrass is active during this phase.
- He casts [[spell:1285640]], which mind-controls selected players, and spawns 2 [[spell:1285842]] per player when the mind control is broken.
  
  - The Manifestations fixate on random players, moving towards them, unless the fixated player looks back at the Manifestation.
- Similar to [[spell:1299684]] in Phase 1, [[spell:1286620]] is a frontal cone aimed at the active tank that deals shadow damage and destroys any [[spell:1285842]] it hits.
  
  - It also increases damage taken by the next [[spell:1286620]] by 200%, so make sure to taunt swap after every cast.
  - Additionally, it applies 3 stacks of [[spell:1286837]], which spawn a Soul Fragment per stack that needs to be picked up in order to remove the stack. If the stacks are not cleared before the debuff expires, the affected player immediately dies.
  - It is important to pay extra attention to finding and collecting all Soul Fragments quickly after each tank frontal.
- Getting hit by a [[spell:1286895]] also applies 3 stacks of [[spell:1286837]]. Don't let it catch you off guard!

### Intermission

- Malacrass takes 100% extra damage while casting [[spell:1287685]]. Make sure to save your [[talent:102466@AJgABA]] and [[talent:136496@FJQAEdhACEA]] for the intermission!
- Don't let any Fragments of Malacrass reach the boss by soaking them to prevent them from healing the boss.
  
  - Soaking each fragment deals raid-wide AOE damage, so don't soak them too quickly to give your healers some time to react to the incoming damage.

### Phase 3

- During this phase, both Zul'jan and Malacrass are active, combining their abilities from Phases 1 and 2.
- Both [[spell:1299960]] and [[spell:1285640]] happen in this phase, meaning both [[spell:1282403]] and the [[spell:1285842]] need to be cleared by the tank frontal.
- The tank frontal cone of this phase is [[spell:1307279]], which deals shadow damage, destroys any [[spell:1282403]] and [[spell:1285842]] hit by it, and applies 3 stacks of [[spell:1286837]].
  
  - Don't forget to collect your Soul Fragments and taunt swap after each cone!
- [[spell:1298381]] is the empowered verision of [[spell:1282487]] from phase 1.
  
  - In this phase, the empowered melee attacks additionally apply a **stacking** shadow DOT. Use big defensives when reaching high stacks.

:::

:::tab Ula'tek
:::talents **Protection Paladin Raid Ula'tek**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents **Protection Paladin Raid Nymrissa Wavecaller**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA"
}
```
:::

### General mechanics

- The boss targets random players with Chilling Frost, which drops Frost Orbs under their feet.
  
  - These orbs need to get soaked before they explode and wipe the raid.
  - Soaking an orb applies a stacking debuff that increases the damage taken from soaking Frost Orbs, so don't soak too many in one go unless you have [[spell:642]] or [[talent:111886]] ready.
  - Each orb soak also deals raid-wide AOE, so don't soak them too quickly to give your healers some time to react to the incoming damage.
- Occasionally, murlocs will spawn from the water and start walking towards the bubble in the middle of the room.
  
  - Don't let them reach the bubble, and move the boss on top of them whenever possible to allow for better cleave.

### Tank mechanics

- A tank-only mechanic of the fight is the Iceblade Flurry - a series of magic slashes, with each slash increasing the damage of the following ones.
  
  - Use a defensive for each cast and taunt swap after each one.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid as a **Protection Paladin**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Protection Paladin** Stats in Raids
```json
{
  "source_code": "JoAJFQAJoASMBEwAEA"
}
```
**力量 ＞ 急速 ＞ 全能 ≥ 暴击 ≫ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- Speed - Niche tertiary that can be very useful and has proven so in the past. Makes playing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks. **Avoidance** is great, but most of the time, tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:239050@CiQAA8OuzVtOCKgTBA]]  <br>into [[item:271465@DiQBAIEAvj7cVrjgC4UAKX6A]] | Catalyst of Kings' Rest |
| Neck | [[item:268265@BERAAIEA-z64PrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:239037@DgQAAIEA1k7IoAOF]]  <br>into [[item:271463@DgQBAIEA1k7IoAOFQvlO]] | Catalyst of Temple of Sethraliss |
| Cloak | [[item:268253@BgQAAIEACKAWBA]] | The Coiled Altar |
| Chest | Convert [[item:268222@DgQAAIEAJk7IoAYF]]  <br>into [[item:271468@DgQBAIEAJk7IoAYFgvXQ]] | Catalyst of The Coiled Altar |
| Wrist | [[item:237834@FiQAAIEAWA8ciqj_sO3WzSB]] | Crafting |
| Gloves | Convert [[item:251214@BgQAAIEACKgTBA]]  <br>into [[item:271466@BgQBAIEACKgTB4U1DA]] | Catalyst of Den of Nalorakk |
| Belt | [[item:268259@BiQAAIEA-z6IoAYF]] | The Coiled Altar |
| Legs | [[item:271878@DARAAIEAhu7YhN5IAWB]] | Ula'tek |
| Boots | [[item:237828@HgQAAIEA1V2ciqzD5O3WzSB]] | Crafting |
| Ring 1 | [[item:268266@DkQAAIEAvk74Prj_sOCKgTB]] | Nymrissa Wavecaller |
| Ring 2 | [[item:159459@DkQAAIEAvk74Prj_sOCKgTB]] | Kings' Rest |
| Trinket 1 | [[item:270164@BgQAAIEACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270173@BgQAAIEACKAWBA]] | The Coiled Altar |
| Weapon | [[item:268209@DgQAAIEA9k7IoAYF]] | The Coiled Altar |
| Shield | [[item:268196@BgQAAIEACKgTBA]] | The Lost Explorers |

:::

:::tab Farmable Alternatives
Below, you will find a good list of farmable alternatives available outside WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239050@BgQAAIEACKQQBA]] | Kings' Rest |
| Neck | [[item:251173@BgQAAIEACKQQBA]] | Den Of Nalorakk |
| Shoulder | [[item:239037@BgQAAIEACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAIEACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251193@BgQAAIEACKQQBA]] | The Blinding Vale |
| Wrist | [[item:159425@BgQAAIEACKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:251214@BgQAAIEACKQQBA]] | Den of Nalorakk |
| Belt | [[item:159418@BgQAAIEACKQQBA]] | Kings' Rest |
| Legs | [[item:273776@BgQAAIEACKQQBA]] | Altar of Fangs |
| Boots | [[item:273777@BgQAAIEACKQQBA]] | Altar of Fangs |
| Ring 1 | [[item:159459@BgQAAIEACKQQBA]] | Kings' Rest |
| Ring 2 | [[item:273792@BgQAAIEACKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:158367@BgQAAIEACKQQBA]] | Temple of Sethraliss |
| Trinket 2 | [[item:250228@BgQAAIEACKQQBA]] | Murder Row |
| Weapon | [[item:251195@BgQAAIEACKQQBA]] | The Blinding Vale |
| Shield | [[item:159664@BgQAAIEACKQQBA]] | Temple of Sethraliss |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons & Raids. Do note that the trinkets recommended above are for optimal damage; if you do not care about your damage and only want to survive, it is recommended to use a trinket like [[item:270160@BgQAAIEACKgTBA]].

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAIEACKgTBA]]  <br>[[item:270173@BgQAAIEACKAWBA]] |
| **A-Tier** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:158367@BgQAAIEACKgTBA]]  <br>[[item:270174@BgQAAIEACKgTBA]]  <br>[[item:270160@BgQAAIEACKgTBA]]  <br>[[item:250228@BgQAAIEACKgTBA]] |
| **B-Tier** | [[item:270175@BgQAAIEACKAWBA]]  <br>[[item:250243@BgQAAIEACKgTBA]]  <br>[[item:159618@BgQAAIEACKgTBA]]  <br>[[item:270168@BgQAAIEACKgTBA]]  <br>[[item:250229@BgQAAIEACKgTBA]]  <br>[[item:193762@BgQAAIEACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAIEACKgTBA]]  <br>[[item:270163@BgQAAIEACKgTBA]]  <br>[[item:273795@BgQAAIEACKgTBA]]  <br>[[item:250259@BgQAAIEACKgTBA]]  <br>[[item:250244@BgQAAIEACKgTBA]]  <br>[[item:193757@BgQAAIEACKgTBA]] |
| **Junkyard** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:250245@BgQAAIEACKgTBA]]  <br>[[item:250238@BgQAAIEACKgTBA]]  <br>[[item:273797@BgQAAIEACKgTBA]] |

### Embellishments

- 2x [[item:240167]] is your best in slots option.
  
  - Random main stat proc for you and your teammates.
  - Preferably on Wrists and Boots; however, it can be crafted on any armor piece.

A good option for early season or if you don't have access to a 334 or 344 weapon is crafting a 331 weapon[[item:245876]] instead of an offpiece with [[item:240167]]. As soon as you get access to a 334 or 344 weapon, this option loses value compared to 2x [[item:240167]].

- [[item:245876]]
  
  - Passively gives secondary stats depending on the mob type you're fighting.
  - Has to be crafted on a weapon.

#### Remaining Sparks

- Crafted items are 331 item level, and regular items are 334 on max item level; therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear in that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stone/Oil**
  
  - [[talent:117881]] *-- as [[talent:123361]]*
  - [[item:243734]]-- as [[talent:123358]]
- **Augment Rune**
  
  - [[item:259085@BQAAAIEAaB]]
- **Sockets**
  
  - [[item:240983]] *-- Unique, can only be used once*
  
  
  
  - [[item:240894]]
  - [[item:240916]]

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAIE]] |
| Belt | [[item:275707@BAAAAIE]] |
| Legs | [[item:244641@BAAAAIE]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244015@BAAAAIE]] |
| Ring 2 | [[item:244015@BAAAAIE]] |
| Weapon | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **Protection Paladin** **Mythic+**
```json
{
  "source_code": "IQFZCBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy [[item:275707@BAAAAIE]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt*.

## Races

In this section of the **Protection Paladin** Raid Guide, we showcase and explain how impactful certain racials can be in World of Warcraft:

- [[spell:65116]] -- ***Dwarf***
  
  - [[spell:59224]] gives 2% crit damage and healing, which is very strong for **Protection Paladin**.
  
  
  
  - Valuable due to the fact that you can dispel yourself or remove dangerous bleed effects.
  - Gives  10% physical DR which can be like a small extra personal as a tank for 8 seconds.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:20549]] -- Tauren
  
  - Strong AoE stun that can be used as a stop that lasts for 2 seconds.
  - [[spell:154743]] gives 2% crit damage and healing

### Recommendation

I almost always play Dwarf since they are the overall strongest offensive (tied with Tauren) race, as well as being the strongest defensively because of **[[spell:65116]]** ability to remove nasty debuffs.

## Macros

Discover recommended macros for **Protection Paladin** for Raids and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
**Taunt at Mouseover** --- *Mouseover macro for [[spell:62124]] (Taunt) that allows you to get aggro easily from targets that just come into view or spawn without having to change target. If you have no mouseover it taunts your primary target.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]Hand of Reckoning
```

Boss 1 Taunt --- *Casts [[spell:62124]]* on Boss1

```wow-macro
/cast [@boss1] Hand of Reckoning
```

Boss 2 Taunt --- *Casts [[spell:62124]]* on Boss2

```wow-macro
/cast [@boss2] Hand of Reckoning
```

:::

:::details Mouseover Macros
**Blessing of Freedom Mouseover** --- *Mouseover macro for Blessing of Freedom to use on allies (do not use this on yourself as it's less efficient than the next macro)*

```wow-macro
#showtooltip
/cast [@mouseover] Blessing of Freedom
```

**Blessing of Sacrifice Mouseover**--- *Mouseover macro for Blessing of Sacrifice that allows you to external someone quickly.*

```wow-macro
#showtooltip
/cast [@mouseover] Blessing of Sacrifice
```

**[[spell:85673]] Mouseover** --- *Mouseover macro to use Word of Glory on allies, as with Blessing of Freedom, do not use this on yourself as it is less efficient.*

```wow-macro
#showtooltip Word of Glory
/cast [@mouseover] Word of Glory
```

**Lay on Hands Mouseover** --- *Mouseover macro to use Lay on Hands on allies.*

```wow-macro
#showtooltip Lay on Hands
/cast [@mouseover] Lay on Hands
```

**Cleanse Toxins Mouseover** --- *Mouseover macro to use dispell on allies.*

```wow-macro
#showtooltip Cleanse Toxins
/cast [@mouseover] Cleanse Toxins
```

:::

:::details Focus Macros
**Focus Target Macro** --- *Sets a mouseovered target as your focus target*

```wow-macro
/focus [@mouseover,exists]
```

**Focus Interupt** --- *This macro casts "Rebuke" or interrupt on* your focus target. It also interrupts your main target if your focus target is out of range or if you do not have a focus target. Very solid macro for general use play.

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] Rebuke
```

**Focus [[spell:31935]]** --- *Macro that puts your [[spell:31935]] on focus target if you need to kick or silence your focus target*

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] Avenger's Shield
```

:::

:::details Utility Macros
**Cancelaura macro** --- *Here is a very important macro that you want to fill with any buff that is an immunity that you would need to cancel in a given scenario. For example; [[spell:642]] Taunt fails and doesn't taunt so you need to cancel [[spell:642]], or you used [[spell:1022]] to get rid of a debuff quickly and need to cancel so that you can continue being the primary aggro target before your allies are tanking instead.* In the case of [[spell:204018]], sometimes certain mobs fail to do their primary threat ability on the tank if you are protected by [[spell:204018]], although this is rare.

```wow-macro
/cancelaura Blessing of Protection
/cancelaura Blessing of Spellwarding
/cancelaura Divine Shield
```

:::

:::details Player Macros
[[spell:85673]] at Self--- *This macro casts [[spell:85673]] on yourself which is very efficient when you want to use [[spell:85673]] as a self heal. I recommend using two binds for [[spell:85673]], just like Blessing of Freedom.*

```wow-macro
#showtooltip Word of Glory
/cast [@player] Word of Glory
```

**Blessing of Freedom on Self** --- *This macro puts Blessing of Freedom on yourself instantly, which is more efficient in terms of pressing faster than if you used a mouseover macro for yourself. In general, it is good to have two binds for Blessing of Freedom, one for mouseover and one for player (self) as it is a lot more efficient.*

```wow-macro
#showtooltip Blessing of Freedom
/cast [@player] Blessing of Freedom
```

**Lay on Hands Self** --- *This macro you should use in order to use Lay on Hands as a "self heal".*

```wow-macro
#showtooltip
/cast [@player] Lay on Hands
```

**Cleanse Toxins Self** --- *This macro you should use for dispelling yourself as it is more efficient.*

```wow-macro
#showtooltip Cleanse Toxins
/cast [@player] Cleanse Toxins
```

:::

:::

## Addons

Below is a screenshot of the author's User Interface for **Protection Paladin**, outlining which addons are used and how they are used in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/pala-1024x623.png>)

**Protection Paladin** Interface

:::accordion
:::details Addons
- EllesmereUI
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

:::accordion


:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Class
  
  - Golden Path healing increased by 25%.
  - Lightforged Blessing healing increased by 25%.
  - Brought to Light healing increased by 25%.
- **[[talent:123361]]**
  
  - Rite of Adjuration healing increased by 25%.
  - Divine Guidance redesigned — For each Holy Power ability cast, your next Consecration deals Holy damage immediately, split across all enemies. Up to 3 nearby allies are each healed for a percentage of the total damage.
  - Blessed Assurance now increases the damage and healing of your next Blessed Hammer or Hammer of the Righteous by 100% (was 200%).
- Protection
  
  - New Talent: Blessed Word — Word of Glory can no longer critically strike, but its healing is increased by your critical strike chance and 80% of its overhealing done to you instead shrouds you in Light, granting an absorb shield.
  - Improved Ardent Defender has been redesigned – Now increases maximum HP by 20% while active and no longer cancels remaining duration if fatal damage is sustained.
  - Seal of Reprisal has been redesigned – Blessed Hammer reduces enemy damage dealt to you by 10% for 8 seconds.
  - Masterwork has been updated – After casting a Holy Armament, your next 3 casts of Hammer of the Righteous/Blessed Hammer/Crusader Strike bestow a Lesser Armament of the same kind on a nearby ally.
  - Judgment damage increased by 51%.
  - Consecration damage increased by 100%.
  - Shield of the Righteous damage increased by 150%.
  - Hammer of the Righteous primary damage increased by 50%.
  - Avenging Wrath increases damage and healing done by 10%, and critical strike by 10%.
  - Avenger's Shield damage increased by 30%.
  - Lesser Weapon damage increased by 50%.
  - Hammer of Light damage reduced by 33%.
  - Empyrean Hammer damage reduced by 33%.
  - Hammer and Anvil damage reduced by 20%.
  - Divine Exaction's Divine Toll effectiveness reduced to 80% (was 150%).
  - Sentinel duration increased to 20 seconds.
  - Greater Judgment debuff now lasts for 18 seconds (was 15 seconds).
  - Guardian of Ancient Kings now has a 8 second initial cooldown.
  - Undying Embers heals you for 125% of damage dealt by Refining Fire (was 100%).
  - Bulwark of Order absorb increased to 75% of Avenger's Shield damage (was 60%).
  - Solace causes Consecration to heal you for 375% of damage it deals (was 300%).
  - Bulwark of Righteous Fury increases the damage of your next Shield of the Righteous by 10% per stack (was 20%).
  - Sacred Weapon and Holy Bulwark extend their duration when reapplied by the same caster.
  - Glory of the Vanguard now deals damage as a percentage of Avenger's Shield's initial damage.
  - Sentinel now inherits Avenging Wrath's critical strike bonus.
  - Valiant Crusade no longer cancels on death.
  - Reflection of Radiance’s chance to activate has been significantly reduced.
  - Improved Ardent Defender now applies a debuff to indicate when fatal damage has been sustained.
  - Hammer of Light, Divine Resonance, Sacrosanct Crusade, Bulwark of Order, Empyreal Ward, Strength in Adversity, and Seal of Reprisal can now be tracked with the Cooldown Manager.
  - Fixed an issue where Authoritative Rebuke was incorrectly reducing Rebuke’s cooldown from Avenger’s Shield casts.
  - Fixed an issue where Instrument of the Divine was causing Shield of the Righteous to extend Sentinel’s stacks by an incorrect amount.
  - Fixed an issue where Quickened Invocation was incorrectly reducing the cooldown of Holy Armaments.
  - Fixed an issue where abilities that knocked enemies into the air could cause Glory of the Vanguard to deal its damage additional times.
  - Fixed an issue where casting Hammer of Light in between direct casts of Consecration could allow Consecration to exceed its limit.
  - Many talents have changed position in the talent tree.
  - Sanctified Wrath has been removed.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
The biggest tip I can give is to always figure out why you died in any given scenario and how you can improve. Tanking is tough, with constant opportunities to better use your externals, rotation, and defensives. Recording your gameplay and reviewing Warcraft Logs are great methods. Being good at tanking requires cognitive flexibility—focus on what you could have done better instead of blaming others. This mindset is more rewarding and healthier for becoming a better tank!

:::

:::

---

### Credits

Written By: **Tief**

Reviewed by: **Meeres**

---

:::changelog 更新记录
**2026-08-06** Updated for Patch 12.1

**2026-06-21** Updated for Patch 12.0.7

**2026-04-26** Updated for Patch 12.0.5

**2026-02-21** Updated for Patch 12.0.1

**2026-01-16** Updated for Patch 12.0

**2025-12-01** Updated for Patch 11.2.7

**2025-10-07** Updated for Patch 11.2.5

**2025-07-30** Updated for Patch 11.2

**2025-06-18** Updated for Patch 11.1.7

**2025-04-20** Updated for Patch 11.1.5

**2025-02-25** Updated for Patch 11.1.

**2024-12-17** Updated for Patch 11.0.7.

**2024-10-26** Updated for Patch 11.0.5.

**2024-08-17** Updated for Patch 11.0.2

**2024-07-28** Guide Written for patch 11.0.



:::
