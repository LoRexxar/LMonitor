Welcome to the Fire Mage Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single Target** · 2/5 · Weak

AoE · 3/5 · Average

Utility · 3/5 · Average

Survivability · 2/5 · Weak

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Fire Mage** Mythic+ Best in Slot
```json
{
  "source_code": "JsqAwj0PAc__BEgAmQggQEAAnk7AX16ACKgF2gVABs9FEAIIBAAFtOAZ1YjMeVjgC4UABoMJEIACBAwF5OggC4UAB8MJEIACBAQC5OggB4BEJTCBAiQBzUgHAscCeQQBqmwDo_9FEIAEBAQ84OAG2IoAYFQAgg6ACiTAAgBwDQRrDY7LMYzt1sZJ2WDAjAGMLFQANTCBAASBAsXNBWDGFADMTfBBBMubCIIGBAQ94GwMsYjMASjt14UABIW2DkhFEQWNBgBJOFQAU9BBAgQAAUwigc1HEAAEBAgLyUgDE09FF4AAYUwVMEA9iQQAFjQP5OQBWCWCAPAAAFAA2-yY1ENM3WTWiwgNLXDAjsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268251]] | [[item:240916]] |
| 肩部 | [[item:271562]] | [[item:243991]] |
| 胸部 | [[item:271567]] | [[item:243977]] |
| 腰部 | [[item:271561]] | [[item:240916]] |
| 腿部 | [[item:271563]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:243953]] |
| 腕部 | [[item:239648]] | [[item:240916]] · [[item:245784]] |
| 手部 | [[item:271565]] |  |
| 戒指一 | [[item:159459]] | [[item:240916]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240916]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:245769]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As a **Fire Mage**, you have access to Fired Up, which has a chance to grant you a stacking fire damage increase buff each time you consume a [[spell:195283]].

**Rank 2** reduces the cooldown of [[talent:124750]] each time you gain [[spell:1257343]] and also increases all fire damage dealt. While **Rank 3** enables that you have increased chance of gaining [[spell:1257343]] during [[talent:124756@FAQAwRyE]], reducing each time you gain [[spell:1257343]]. Additionally, [[spell:1257343]] now extends [[talent:124756@FAQAwRyE]] duration.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-fire-mxr.webp>)

Fired Up

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:124789]]
    
    - Reworked into a static cooldown reduction.
  - [[talent:124778]]
    
    - Used to be a built-in ability within [[spell:383886]] but now is reworked and doesn't proc [[talent:124756@FAQAwRyE]] anymore.
  - [[talent:136589]]
    
    - Improves the ability to do burst damage in a short amount of time.
  
  
  
  - [[talent:135617]]
    
    - Partially reworked and now also improves [[spell:133]] when hitting low health enemies.
- **Class Tree**
  
  - [[talent:134182]]
    
    - Restores you some health when you drop low and casts [[talent:80174]]. One of the weakest passive defensives but still something and has an interesting concept.
  
  
  
  - [[talent:136581]]
    
    - Casts [[talent:80140]] a second time on its own but adds a cooldown to it.
  - [[talent:136576]]
    
    - Allows your [[talent:80175]] to be casted on yourself automatically whenever you use it on another friendly target.
  - [[talent:134186]]
    
    - Improves your [[talent:80178]] and makes it a much stronger defensive ability.
- **Removed**
  
  - [[spell:383886]]
    
    - Results in less overall uptime of [[talent:124756@FAQAwRyE]] you are going to have.
  - [[spell:257541]]
    
    - Losing this means that, aside from reduced mobility, it's now more important not to waste any [[talent:124750]] charges.
  - [[spell:382440]]
    
    - One of the greatest abilities **Mage** ever had and its removal affects all aspects like damage, utility or survivability.
  
  
  
  - [[spell:414660]]
    
    - Great personal and party defensive ability that in combination with [[talent:80147]] was a very strong spell overall. Its removal together with [[spell:382440]] and removed damage reduction from [[talent:80183]] and [[talent:115877]] results in a much weaker defensive state of **Mage** coming into Midnight.
  - [[spell:157981]]
    
    - One of the strongest utility spells also gone, doesn't affect you much directly but makes you quite a bit more useless in any meaningful content of the game.

## Hero Talents

#### Sunfury

- [[talent:123341]] is the main hero talent used in both single and AoE scenarios.

:::tabs
:::tab [[talent:123341]]
- [[talent:123341]] hero talent tree mainly revolves around [[talent:117250@AJACBA]] and [[talent:117255@AJACBA]]. They both interact with you and each other, granting additional damage, haste buffs and even cooldown reduction to [[talent:124750]].

- [[talent:117250@AJACBA]] have a chance to proc after consuming a [[spell:48108]]. They increase your spell damage and stack up to 5.
  
  - Thanks to [[talent:135926@AJACBA]] and [[talent:135925@AJACBA]], conjuring a [[talent:117250@AJACBA]] causes your next [[talent:124750]] to call down a storm of Meteorites on its target, each reducing the cooldown of [[talent:124750]].

- When casting [[talent:124756@FAQAwRyE]], you summon an [[spell:448659]] aiding you in battle casting random arcane and fire spells. 
  
  - With [[talent:117248@AJACBA]], when [[spell:448659]] is summoned, it consumes all your [[talent:117250@AJACBA]], increasing your spell damage during [[talent:124756@FAQAwRyE]] and causing [[spell:448659]] to cast an exceptional arcane or fire spell over its duration.
  - Additionally, after [[spell:448659]] expires, due to [[talent:117246]], you gain a [[spell:1260277]] for 10 seconds.

- On top of that, you also gain multiple of other buffs such as [[talent:117249@AJACBA]] that grants you [[spell:383860]] after [[talent:124756@FAQAwRyE]] ends, [[talent:117256@AJACBA]] that grants you stacking haste each time you consume a [[spell:48108]] and few other minor buffs.

:::

:::tab [[talent:123343]]
- [[talent:123342]] hero talent tree revolves around passively gaining additional damage from your spells by transforming your [[spell:133]] to [[spell:431044]], making [[talent:124750]] deal frostfire damage with [[talent:117241@FAQA7chA]] and causing [[talent:124786@FAQAJXyE]] to also call down a [[talent:80251]] alongside other passive damage increase talent nodes. Due to [[talent:135923@AJACBA]], your [[talent:124759]] also has a chance to cast a [[spell:199786]]. 
  
  - Additionally, [[talent:135921@AJACBA]] lets your [[talent:80251]] and [[spell:199786]] apply [[spell:12846]].

- At last, the only thing that actively interacts with your gameplay is a [[talent:117244@AJACBA]] talent node. It grants your Frostfire spells a chance for your next [[spell:431044]] to be instant cast, deal increased damage and explode to nearby enemies.
  
  - On top of it, you also gain it by casting [[talent:124786@FAQAJXyE]] due to [[talent:117235]].

:::

:::

## Talents

:::tabs
:::tab [[talent:123341]]
:::talents [[talent:123341]] **Fire Mage** Mythic+ Build
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### When to use this Spec

This is the main spec used by **Fire Mages** in Mythic+. This should be your default talent tree.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[talent:135617]]
  
  - Makes your [[spell:133]] to always critically strike enemies below 30% health. When [[spell:133]] or [[talent:136879]] damage an enemy below 30%, [[spell:133]] and [[talent:136879]] deal increased damage.
- [[talent:135604]]
  
  - While [[talent:124756@FAQAwRyE]] is active, [[talent:124750]] recharges faster.
- [[talent:135600]]
  
  - Makes your direct damage spells reduce the cooldown of [[talent:124750]].
- [[talent:136589]]
  
  - Explodes your [[spell:12846]] whenever [[talent:124756@FAQAwRyE]] ends.
- [[talent:124756@FAQAwRyE]]
  
  - Your major cooldown increases your critical strike chance by 100%. On top of it, grants you increased spell damage and an additional 20% of your critical strike chance as spell damage due to [[talent:135618]].

#### Class Tree

- [[talent:80141]]
  
  - Grants you a damage taken reduction by 70% for 6 seconds instead of immunity from [[talent:80181]].
- [[talent:80174]]
  
  - Returns you to your current location and health when cast a second time, or after 10 seconds. Effect negated by long distance or death. Very versatile spell and should be used both for improving your survivability and movement.
- [[talent:80163]]
  
  - Teleports you forward, unaffected by the global cooldown and castable while casting.
- [[talent:115877@FAgAVVdBvFbA]]
  
  - Makes you invisible and untargetable for 20 seconds, removing all threat. Any action taken cancels this effect.
- [[talent:134186]]
  
  - Makes [[talent:80178]] damage increased and it now cauterizes your wounds, healing you for part of the damage it absorbs. Additionally, gains you an extra charge.
- [[talent:80183]]
  
  - Creates 3 copies of you nearby for 15 seconds. While active, you generate significantly reduced threat. Taking direct damage causes one of the copies to dissipate.
- [[talent:125819]]
  
  - Enemies in a 12 yard cone in front of you take fire damage and are disoriented for 4 seconds. Damage cancels the effect.

### Hero Talents

- [[talent:134249@AJACBA]]
  
  - Both options are pretty useless.
- [[talent:117252@AJACBA]]
  
  - Both options can be used for different purposes. Pick whatever you feel like is more useful.
- [[talent:123867@AJACBA]]
  
  - Currently outperforms [[talent:117253@AJACBA]].

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:124778]] causes [[talent:135619]] and [[talent:124759]] to always critically strike.
- **4-Set:** ‍[[talent:124778]] reduces the cast time of [[talent:135619]] and [[talent:124759]] by 20% and its damage bonus is increased by 25%.

### Single-Target and Cleave

:::tabs
:::tab [[talent:123341]]
### Opener

- The goal of your opener rotation is to enter [[spell:190319]] right after your target drops below 90% health due to [[talent:136878]] talent. Below, you can see an example of how your opener may look like using our recommended ‍‍[[talent:123341]] talent build:

:::rotation **Fire Mage** Single-Target opener in Mythic+
```json
{
  "source_code": "IcZA8tgQmxCAAAwBQJXZjF2c0JgQhnTAAAQAc66AAAAAAIUhBYAHAEgQ1kaAAAQCrUBC-YBAJwSD0ApFUFmcnVGdgQmcvB3cgIWZs92dgkDMlAgQUtcAAAAABI0bnLAAmJFA"
}
```
1. [[spell:11366]] Precast [[spell:80353]] · [[item:241308]]
2. [[spell:133]]  [[spell:108853]]
3. [[spell:11366]]
4. [[spell:11366]]  [[spell:108853]]
5. [[spell:11366]]
6. [[spell:133]]
7. [[spell:133]] Target drops below 90%
8. [[spell:117588]]  [[spell:190319]]
9. [[spell:11366]]
10. [[spell:11366]]  [[spell:108853]]
11. [[spell:11366]]
:::

- Make sure to use your potion that way so it covers both your [[talent:136878]] and [[spell:190319]] with [[spell:383874]] windows.
- Keep in mind that both [[spell:190319]] and [[spell:108853]] are not on a GCD and usable during casting other spells like [[spell:133]].
- Main goal of every [[spell:190319]] window is to spend as little time casting [[talent:136879]] as possible. Thus entering it with maximum amount of [[spell:108853]] and potentially even with a [[spell:48108]] or [[spell:48107]] is very beneficial.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:190319]] on cooldown.
2. Cast [[spell:153561]] on cooldown.
   
   - Except for the delay in your opener, if you cast it on cooldown, then every other cast will be lined up with your [[spell:190319]], either right before or during it. Keep in mind that casting [[spell:190319]] before your [[spell:153561]] actually lands will also grant it a guaranteed critical effect.
3. Cast [[spell:11366]] with a [[spell:48108]], [[talent:124778]] or during [[spell:383874]].
4. Cast [[spell:108853]] with [[spell:48107]].
5. Cast [[spell:133]].
6. Cast [[spell:2948]] during movement.

:::

:::

### AoE

:::tabs
:::tab [[talent:123341]]
### Opener

- The goal of your opener rotation is to enter [[spell:190319]] right after your target drops below 90% health due to [[talent:136878]] talent. Below, you can see an example of how your opener may look like using our recommended ‍‍[[talent:123341]] talent build:

:::rotation **Fire Mage** AoE opener in Mythic+
```json
{
  "source_code": "IcZA8tgQmxCAAAwBQJXZjF2c0JgQhnTAAAQAc66AAAAAAIUhBYAHAEgQ1kaAAAQCrUBC-YBAJwSD0gqFUFmcnVGdgQmcvB3cgIWZs92dgkDMlAgQZflAAAAABI0bnLAAAIESIAAABIVCIQSACVTqBAAAChEC"
}
```
1. [[spell:11366]] Precast [[spell:80353]] · [[item:241308]]
2. [[spell:133]]  [[spell:108853]]
3. [[spell:11366]]
4. [[spell:11366]]  [[spell:108853]]
5. [[spell:11366]]
6. [[spell:133]]
7. [[spell:133]] Target drops below 90%
8. [[spell:153561]]  [[spell:190319]]
9. [[spell:2120]]
10. [[spell:2120]]  [[spell:108853]]
11. [[spell:2120]]
:::

- AoE is considered to be a fight with 4+ enemies.
- AoE rotation is identical to Single-Target and Cleave rotation with the exception of replacing your [[talent:124759]] with a [[talent:135619]].
- During the [[talent:136878]] window you are still casting [[talent:124759]] because it has a guaranteed critical chance unlike [[talent:135619]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:190319]] on cooldown.
2. Cast [[spell:153561]] on cooldown.
   
   - Except for the delay in your opener, if you cast it on cooldown, then every other cast will be lined up with your [[spell:190319]], either right before or during it. Keep in mind that casting [[spell:190319]] before your [[spell:153561]] actually lands will also grant it a guaranteed critical effect.
3. Cast [[talent:135619]] with a [[spell:48108]], [[talent:124778]] or during [[spell:383874]].
4. Cast [[spell:108853]] with [[spell:48107]].
5. Cast [[spell:133]].
6. Cast [[spell:2948]] during movement.

:::

:::

## Deep dive

### Optimizing Combustion windows

While your overall main goal is to press everything on cooldown and just react to procs with crits, you still need to remember to save as many resources as you can whenever a [[spell:190319]] is about to come off cooldown. That means that you want to enter it with at the very least of 2 stacks of [[spell:108853]] and preferably with a [[spell:48108]] or [[spell:48107]] proc available.

Doesn't mean that you need to hold them off for 10 seconds or longer, just keep in mind that if you have [[spell:190319]] back in like a few seconds, it might be good to hold on spending your procs. Same goes for [[spell:269650]] proc, having it to guarantee a crit with [[spell:190319]] is very good.

At the end of the day, you just have to have a good balance between not wasting any procs but at the same time saving as much stuff as you can for every [[spell:190319]] window.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Fire Mage** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

#### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

#### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as[[talent:80178]] with [[talent:80157]].

:::

:::tab Den of Nalorakk
:::talents **Fire Mage** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

#### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

#### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:115877]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Fire Mage** Mythic+ Build in Murder Row
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

#### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

#### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

#### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Fire Mage** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

#### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots with a [[talent:115877]].
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

#### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

#### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents **Fire Mage** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

#### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

#### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents **Fire Mage** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

#### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

#### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

#### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents **Fire Mage** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

#### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

#### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Fire Mage** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "C-DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA",
  "code": "C+DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzMLAAAAAYxMjZAAgZMmZmZMzsAgZGyYMgBjBA"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

#### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

#### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

#### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

The Affix system stays the same going into **Midnight** with the only exception of adding [[spell:1284818]] to the lower keys.

- +2 Affix 
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Alternates between each other on a weekly basis, is always the opposite of the +7 Affix
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Fire Mage**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:125819]] and [[talent:125818]] are all great tools for this affix.
- Xal'atath's Bargain: Voidbound
  
  - Important to kill this instantly as it reduces damage taken for all nearby enemies, also plan your cooldowns around this affix so you're not forced to swap target during your [[spell:190319]].
- Xal'atath's Bargain: Pulsar
  
  - Use your mobility to help your teammates if needed.
- Xal'atath's Bargain: Devour
  
  - Make sure to [[talent:80175]] yourself every time this affix goes off.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Fire Mage**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Fire Mage** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUAJxgCIEEABEA"
}
```
**智力 ≫ 急速 ＞ 精通 ≫ 全能 ≫ 暴击**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed** **-**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DCRAA8DAnk7cVrjgCYhNYFA]] | Ula'tek |
| Neck | [[item:268251@BCSAA8DAU06QWN2IjX1IoAOF]] | The Twin Fangs |
| Shoulder | [[item:271562@DgQAA8DAXk7IoAOF]] | Tier / Catalyst |
| Cloak | [[item:268253@BARAA8DAYYjgCgVA]] | The Coiled Altar |
| Chest | [[item:271567@DgQAA8DAJk7IoAOF]] | Tier / Catalyst |
| Wrist | [[item:239648@DiTAA8DAYA8QRrjtvwgN3WzmlYbNAMCYwsUA]] | Crafting |
| Gloves | Convert [[item:268243@AgQAAIoAYFA]]  <br>into [[item:271565@BASAA4DA7VTg1ghNCKAWBA]] | Catalyst of The Coiled Altar |
| Belt | [[item:271561@BiQAA8DAU06IoAOF]] | Catalyst |
| Legs | [[item:271563@DgQAA8DAFo6IoAOF]] | Tier / Catalyst |
| Boots | [[item:268255@DARAA8DAxj7ghNCKAWB]] | The Coiled Altar |
| Ring 1 | [[item:159459@DiRAA8DA1j7QRrjNyAIN2WjTBA]] | Kings' Rest |
| Ring 2 | [[item:252258@DiRAA8DA1j7QRrDZ1YjMASjTBA]] | Voidscar Arena |
| Trinket 1 | [[item:270164@BgQAA8DACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270167@BARAA8DAuIjgC4UA]] | Nymrissa Wavecaller |
| Main-hand | [[item:271092@DgQAA8DA9k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@BAUAA8DA2-yY1ENM3WTWiwgNLXDAjsUA]] | Crafting |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251232@BARAA8DAyIDg0EUA]] | Voidscar Arena |
| Neck | [[item:251142@BgRAA8DAkVjMyAINBFA]] | Murder Row |
| Shoulder | [[item:239045@BARAA8DAyIDg0EUA]] | Kings' Rest |
| Cloak | [[item:159288@BARAA8DAyIDg0EUA]] | Kings' Rest |
| Chest | [[item:251147@BARAA8DAyIDg0EUA]] | Den of Nalorakk |
| Wrist | [[item:251127@BARAA8DAyIDg0EUA]] | Murder Row |
| Gloves | [[item:251129@BARAA8DAyIDg0EUA]] | Murder Row |
| Belt | [[item:251185@BARAA8DAyIDg0EUA]] | The Blinding Vale |
| Legs | [[item:193750@BARAA8DAyIDg0EUA]] | Ruby Life Pools |
| Boots | [[item:159243@BARAA8DAyIDg0EUA]] | Kings' Rest |
| Ring 1 | [[item:159459@BgRAA8DAyIDg0YbNBFA]] | Kings' Rest |
| Ring 2 | [[item:252258@BgRAA8DAkVjMyAINBFA]] | Voidscar Arena |
| Trinket 1 | [[item:250214@BARAA8DAyIDg0EUA]] | The Blinding Vale |
| Trinket 2 | [[item:250224@BARAA8DAyIDg0EUA]] | Voidscar Arena |
| Main-hand | [[item:273778@BARAA8DAyIDg0EUA]] | Altar of Fangs |
| Off-hand | [[item:159667@BARAA8DAyIDg0EUA]] | Kings' Rest |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:250224@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **B-Tier** | [[item:273649@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270161@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **C-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273796@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Only crafted on your **weapon** or **off-hand**.
- 1x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists** or **Cloak** depending on your available gear.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]] -- default
- Combat Potion
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] -- default
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- *Unique, can only use one*
  - [[item:240916]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAAEAZbAB]]  <br>[[item:275707@BAAAAAE]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAA8D]] |
| Chest | [[item:243977@BAAAAAE]] |
| Wrist | [[item:275707@BAAAAAE]] |
| Waist | [[item:275707@BAAAAAE]] |
| Legs | [[item:240133@BAAAAAE]] |
| Boots | [[item:243953@BAAAA8D]] |
| Ring 1 | [[item:243957@BAAAA8D]] |
| Ring 2 | [[item:243957@BAAAA8D]] |
| Weapon | [[item:244029@BAAAAAE]] |

:::

:::column
:::gear **Fire Mage** Enchantments in Mythic+
```json
{
  "source_code": "IQFZ_AQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAAEAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Fire Mage** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic, Bleed posion and disease debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial that lines up with [[talent:124756]].
  - Reduce the duration of movement-impairing effects by 20%. This is rarely useful in Mythic+.
- [[spell:33702]] *-- Orc* 
  
  - Strong DPS racial that lines up with [[talent:124756]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:312924]] -- Mechagnome
  
  - Works the same way as [[spell:55342]] in terms of threat.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Fire Mage**.

## Macros

Discover recommended macros for **Fire Mages** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:2120]]**

```wow-macro
#showtooltip
/use [@cursor] Flamestrike
```

:::

:::details Mouseover Macros
**[[spell:475]]**

```wow-macro
#showtooltip
/cast [@mouseover] Remove Curse
```

**[[spell:118]]**

```wow-macro
#showtooltip
/cast [@mouseover] Polymorph
```

:::

:::details Recommended Macros
**[[spell:108978]] cancel -** *must have macro for whenever your Alter is putting you back to lower hp than you currently have.*

```wow-macro
#showtooltip
/cancelaura Alter Time
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Fire Mage**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Fire-Mythic-UI-1024x616.png>)

**Fire Mage** Mythic+ User Interface

:::accordion
:::details Addons
- **EllesmereUI** *-- Unit frames, nameplates, cooldown manager replacement, and many more* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **LittleWigs** *-- Generic Boss Mod* 
  
  - This is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific boss encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- *Developers' notes: We've made some adjustments to Mage defensives with the goal of improving Mage survivability as a whole. To accomplish this, we are unifying the functionality of Improved Barrier to give all specs an additional charge of their Barrier spell, plus one “rider” effect that is spec-specific.*
- New Talent: Improved Warding – Damage taken from area of effect attacks reduced by 4%.
- Improved Prismatic Barrier has been redesigned – Prismatic Barrier gains an additional charge and further reduces magic damage taken by 5%.
- Improved Blazing Barrier has been redesigned – Blazing Barrier gains an additional charge and cauterizes your wounds, healing you for 15% of the damage it absorbs.
- Improved Ice Barrier has been redesigned – Ice Barrier gains an additional charge and reduces your physical damage taken by 10%.
- Temporal Realignment has been updated – Now immediately heals 20% of your health and heals an additional 30% over 6 seconds.
- Hero Talents
  
  - Sunfury
    
    - Developers' notes: We're redesigning Rondurmancy to lean into making your 3 orbs better, rather than giving you 5 orbs, to align more closely with the inspirations for Sunfury and reduce visual clutter on your character. We're also uncapping Mana Cascade to match other "applications may overlap" effects.
    - Rondurmancy has been redesigned – Your chance to generate a Spellfire Sphere is increased by 6%/12%. Spellfire Spheres grant an additional 1% spell damage.
    - Ashes of Inspiration has been redesigned – Each time your Phoenix casts a spell, gain 1 stack of Mana Cascade. Exceptional Spells grant 1 additional stack.
    - Memory of Al'ar has been updated – Combustion and Arcane Surge no longer cause the Mage to gain twice as many stacks of Mana Cascade.
    - Spellfire Spheres orb generation chance reduced to 6% for Arcane Mages and 12% for Fire Mages (was 12% and 25%).
    - Mana Cascade no longer has a stack cap.
    - Mana Cascade is now also gained when the Mage casts Arcane Pulse or Prismatic Bolt.
    - Fixed an issue for Arcane that caused Mana Cascade to be gained from some unintended spells.
- Fire
  
  - Developers' notes: Our goal with these changes is to shift the relative value of Fire's steady-state damage versus Combustion window burst. It is important that time spent outside of Combustion remains meaningful and impactful to your overall performance.
  - All damage increased by 19%.
  - Pyroblast damage increased by 15%.
  - Flamestrike damage increased by 15%.
  - Apex Talent: Fired Up (Rank 1) now grants 2% increased Fire damage for 8 seconds (was 4% for 12 seconds).
  - Apex Talent: Fired Up (Rank 2) now increases Fire damage by 5%/10% (was 3%/6%).
  - Apex Talent: Fired Up (Rank 3) chance to occur during Combustion has been slightly reduced.
  - Pyroclasm duration increased to 20 seconds (was 15 seconds).

:::

:::

:::accordion
:::details Patch 12.0.1
- Mage
  
  - Hero Talents
    
    - [[talent:123342]]
      
      - Frostfire Empowerment damage bonus reduced to 60% (was 80%).
      - Heat Sink now increases Fire Blast damage by 15% (was 30%).
      - Dualcasting Adept now increases Pyroblast damage by 15% (was 10%).
    - [[talent:123340]]
      
      - Spellfire Sphere chance to trigger increased to 25% (was 20%).
      - Hyperthermia duration reduced to 4 seconds (was 6 seconds).
      - Ashes of Inspiration Haste reduced to 15% (was 20%) and duration reduced to 6 seconds (was 10 seconds).
  - Fire
    
    - Developers' notes: We're reducing Sunfury Fire's single target effectiveness slightly and compensating with some area damage bonuses by putting some more power into Ignite's Mastery scaling.
    - Mastery: Ignite effectiveness increased by 15%.
    - Pyroblast damage increased by 15%.
    - Fire Blast damage reduced by 40%.
    - Scald now increases Fireball's damage by 25% (was 50%).

:::

:::

:::accordion
:::details Patch 12.0
- Mage
  
  - New Talent: Improved Conjuration – Mirror Image's cooldown is reduced by 30 seconds/60 seconds.
  - New Talent: Time Walk – Alter Time resets the cooldown of Blink and Shimmer when you return to your original location.
  - New Talent: Spatial Manipulation – Blink gains an additional charge.
  - New Talent: Temporal Realignment – Upon dropping below 25% health, your past self corrects your timeline, casting Alter Time and instantly returning 50% of your maximum health.
  - New Talent: Improved Ice Barrier – Ice Barrier's absorb is increased by 5% of your maximum health and it now reduces your physical damage taken by 10%. Frost Mage only.
  - New Talent: Improved Blazing Barrier – Blazing Barrier's damage is increased by 200% and it now cauterizes your wounds, healing you for 15% of the damage it absorbs. Fire Mage only.
  - New Talent: Charm of Aegwynn – The critical strike damage of your spells is increased by 5%.
  - New Talent: Charm of Medivh – Mastery increased by 3%.
  - New Talent: Improved Blink – Blink's cooldown is reduced by 2 seconds.
  - New Talent: Permafrost Bauble - The cooldown of Ice Block and Ice Cold is reduced by 30 seconds.
  - New Talent: Master of Escape – Reduces the cooldown of Greater Invisibility by 45 seconds.
  - New Talent: Brainstorm – Hot Streak, Clearcasting, and Brain Freeze increase your Intellect by 1% for 8 seconds. Multiple applications may overlap.
  - New Talent: Improved Spellsteal – Spellsteal repeats its effect after 4 seconds, but it now has a cooldown of 4 seconds.
  - New Talent: Improved Counterspell – Counterspell prevents casting for an additional 1 second.
  - New Talent: Improved Remove Curse – Casting Remove Curse on a friendly target also casts it on yourself, but its cooldown is increased by 20 seconds.
  - New Talent: Mana Confluence – Your mana costs are reduced by 5%.
  - New Talent: Reflection – After casting Blink, it is replaced with Reflection for 8 seconds.Reflection: Teleports you back to where you last Blinked. Castable while casting and unaffected by the global cooldown.
  - Master of Time has been updated – Reduces Alter Time cooldown by 5 seconds/10 seconds. No longer grants an additional charge of Blink/Shimmer after casting Alter Time.
  - Overflowing Energy has been updated – Now increases the critical strike chance of Arcane Barrage, Fireball, and Frostbolt only. Now grants 20% increased Fireball critical strike chance per stack (was 10%).
  - Quick Witted has been updated – Counterspell's cooldown is reduced by 5 seconds.
  - Time Manipulation has been updated – Now reduces the cooldown of your loss of control spells by 5 seconds.
  - Incantation of Swiftness has been updated – Invisibility now increases your movement speed by 20%/40% for 6 seconds.
  - Mirror Image has been updated – No longer reduces the damage you take. Tooltip now correctly communicates its threat reduction effect.
  - Mirror Image duration reduced to 15 seconds (was 40 seconds).
  - All Barrier spells have had their cooldowns increased to 30 seconds (was 25 seconds).
  - Barrier spells now have a reduced global cooldown and now shield you for 25% of your maximum health (was 20%).
  - Blink cooldown increased to 15 seconds inherently.
  - Shimmer cooldown increased to 30 seconds (was 25 seconds) and no longer has 2 charges inherently.
  - Greater Invisibility no longer reduces damage you take by 60%.
  - Counterspell cooldown increased to 25 seconds (was 24 seconds).
  - Cone of Cold cooldown increased to 25 seconds (was 12 seconds) and now applies Chilled.
  - Ice Nova now replaces Cone of Cold when talented.
  - Flow of Time is now a 1-point talent.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Accumulative Shielding
    
    
    
    - Blast Wave
    - Displacement
    - Diverted Energy
    - Frigid Winds
    - Ice Floes *(moved to the Frost talent tree)*
    - Incanter's Flow
    - Mass Barrier
    - Reabsorption
    
    
    
    - Reduplication
    - Rigid Ice
    - Shifting Power
    - Slow
    - Supernova
    - Tempest Barrier
    - Temporal Velocity
    - Volatile Destruction
  - Hero Talents
    
    - [[talent:123342]]
      
      - New Talent: Duality – Casting Pyroblast has a 25% chance to fire a Glacial Spike, dealing heavy Frost damage.
      - New Talent: Molten Chill – Your Frostfire spells apply Ignite at 10% increased effectiveness.
      - New Talent: Elemental Conduit – Comet Storm, Glacial Spike, Pyroblast, and Meteor now apply Ignite. Your Haste is increased by 8%.
      - New Talent: Heat Sink – Fire Blast now deals Frostfire damage and its damage is increased by 30%.
      - New Talent: Dualcasting Adept – Your Frost spells deal 20% increased critical strike damage. Pyroblast and Flamestrike damage increased by 10%.
      - New Talent: Blast Radius – Comet Storm damage increased by 20%. Meteor damage increased by 20%.
      - Flash Freezeburn has been redesigned – Meteor damage increased by 25%. Meteor now grants Frostfire Empowerment.
      - Frostfire Infusion has been updated – Frostfire Bolt's critical strike chance is increased by 15%. The damage of your Frost and Fire spells are increased by 4%.
      - Severe Temperatures has been updated – Frostfire Empowerment stacks 1 additional time and it causes Frostfire Bolt to explode for an additional 20% of its damage.
      - Frostfire Empowerment has been updated – Now triggered from casting Frostfire spells (was Frostfire spell damage).
      - Isothermic Core's Meteor and Comet Storm damage increased by 35%.
      - Isothermic Core tooltip updated to show the actual damage values of the Meteor/Comet Storms summoned and is now conditionalized based on your specialization.
      - Frostfire Bolt cast time reduced to 1.75 seconds (was 2 seconds).
      - Frostfire Bolt direct damage increased by 95%.
      - Frostfire Bolt periodic damage increased by 123%.
      - Frostfire Bolt's tooltip now has two specialization specific versions that only can be seen and selected by Frost or Fire. They now override only Frostbolt or Fireball based on your specialization.
      - Several talents have changed positions in the talent tree.
      - The following talents have been removed:
        
        - Excess Fire
        - Excess Frost
        - Frostfire Mastery
    - [[talent:123340]]
      
      - New Talent: Ashes of Inspiration – When your Arcane Phoenix expires, it grants you Lesser Time Warp for 10 seconds.Lesser Time Warp: Warp the flow of time, increasing your Haste by 20%.
      - New Talent: Spellfire Salvo – Fire Blast cooldown reduced by 1 second. Meteorite damage increased by 15%.
      - New Talent: Pyrocosm – Damage from Fireball has a 20% chance to summon a Meteorite. When a Meteorite lands, the cooldown of Fire Blast is reduced by 0.5 seconds.
      - New Talent: Explosive Potential – After casting Combustion, your next Blink will cause a Blast Wave at your previous location, dealing Fire damage, knocking enemies back 8 yards, and slowing them by 70% for 6 seconds.
      - New Talent: Time Twist – The cooldown of Alter Time is reduced by 10 seconds.
      - Codex of the Sunstriders has been redesigned – When your Arcane Phoenix is summoned, it consumes all your Spellfire Spheres. Each Sphere consumed increases your spell damage during Combustion by 2% and causes your Arcane Phoenix to cast an exceptional Arcane or Fire spell over its duration.
      - Merely a Setback has been redesigned – The bonuses provided by your Barrier spells persist an additional 8 seconds after your Barrier is removed. Additionally, Cauterize no longer deals damage to you.
      - Glorious Incandescence has been updated – Now granted upon generating a Spellfire Sphere. No longer causes Fire Blast to hit additional targets.
        
        - Tooltip updated to better reflect the damage value of Meteorites.
      - Memory of Al'ar has been updated – No longer extends the duration of Hyperthermia based on the number of exceptional spells cast. Base duration of Hyperthermia increased to 6 seconds (was 2 seconds).
      - Sunfury Execution has been updated – Now increases Pyroclasm's damage bonus by 20% and Meteor grants Pyroclasm if talented.
      - Burden of Power has been updated – Now increases Pyroblast and Flamestrike damage by 5%.
      - Savor the Moment has been updated – Now grants 0.4 seconds of Combustion duration per Orb (was 0.5 seconds).
      - Several talents have changed positions in the talent tree.
      - Ignite the Future has been removed.
      - Spellfire Spheres has been updated – Consuming Hot Streak now has a 20% chance to generate a Spellfire Sphere (was 12%).
  - Fire
    
    - New Talent: Ignition – Fire Blast now spreads 50% of your target's Ignite to 1 nearby enemy. Flamestrike applies 50% more Ignite.
    - New Talent: Slow Burn – Combustion grants mastery equal to 75% of your Critical Strike stat. Combustion causes your spells to apply Ignite at 15% increased effectiveness.
    - New Talent: Burn It All – Combustion grants you 10% increased spell damage plus an additional 20% of your critical strike chance as spell damage.
    - New Talent: Pyroclasm – Consuming Hot Streak has a 15% chance to make your next non-instant Pyroblast or Flamestrike cast within 15 seconds to deal 230% increased damage. Stacks up to 2 times.
    - New Talent: Cinderstorm - Casting Pyroblast or Flamestrike has a 8% chance to summon a storm of 5 cinders that pursue your target. Upon reaching your target, each cinder deals moderate Fire damage, applies Ignite at 100% effectiveness, and spreads 50% of your Ignite to up to 1 nearby target.
    - New Talent: Conflagration – Fire Blast deals additional damage to up to 8 nearby enemies.
    - New Talent: Burnout - When Combustion expires, all of your active Ignites explode, dealing 75% of their remaining damage.
    - New Talent: Mote of Flame – All Fire damage dealt increased by 3%.
    - Mastery: Ignite has been updated – Effectiveness reduced by 25% and no longer causes Fire Blast to spread Ignite inherently.
    - Flame On has been updated – Now grants Fire Blast 1 additional charge and reduces its cooldown by 2 seconds.
    - Critical Mass has been updated – Now grants 4%/8% increased chance to deal a critical strike. You gain 10%/20% more critical strike stat from all sources.
    - Molten Fury has been updated – Now grants 15% increased damage on enemies below 30% health (was 7%).
    - Flame Accelerant has been updated – Now reduces Pyroblast and Flamestrike cast time by 20%.
    - Inflame has been updated – Ignite bonus increased to 25% (was 10%).
    - Kindling has been redesigned – Combustion's cooldown is reduced by 60 seconds.
    - Scald has been updated – Fireball always critically strikes enemies below 30% health. When Fireball or Scorch damage an enemy below 30% health, Fireball deals 50% increased damage and Scorch deals 250% increased damage.
    - Feel the Burn has been updated – Fire Blast now grants 2% Mastery per stack for 4 seconds (was 5 seconds). Each stack now has its own duration, multiple applications may overlap, and it no longer has a stack cap.
    - Wildfire has been updated – Now a 2-point talent. Fire Blast spreads Ignite to 1/2 additional targets. Additionally increases Fire Blast damage by 10%/20%.
    - Blast Zone has been updated – Now reduces Meteor's cooldown by 15 seconds.
    - Controlled Destruction has been updated – Now also triggered by Flamestrike in addition to Pyroblast and Fireball.
    - Master of Flame has been updated – No longer increases the number of targets Ignite spreads to during Combustion and no longer increases Fireball's damage. Now additionally causes your Fire Blast to spread an additional 50% of your Ignite.
    - Heat Shimmer has been redesigned – While Combustion is not active, damage from Ignite has a small chance to make your next Scorch instant, deal 100% increased damage, and deal damage as though your target is below 30% health.
    - From the Ashes has been updated – Fire Blast damage increased by 15%. Your direct-damage spells reduce the cooldown of Fire Blast by 0.5 seconds.
    - Fervent Flickering has been updated – Now grants 1 additional Fire Blast charge and increases Fire Blast's damage by 25%.
    - Deep Impact has been updated – Now causes Meteor to deal 75% increased damage to the enemy closest to Meteor's center.
    - Meteor has been updated – No longer deals 40% increased damage to the enemy closest to Meteor's center inherently.
    - Meteor ground effect duration reduced to 4 seconds (was 8 seconds), damage increased proportionally.
    - Meteor direct damage increased by 95% and its damage over time increased by 200%.
    - Fuel the Fire has been updated – Now additionally causes Flamestrike to deal 5% increased damage for each enemy it damages, up to 25%.
    - Flamestrike, Fuel the Fire, and Cauterize are now located in the Fire talent tree (was learned automatically when specialized as Fire).
    - Fireball now replaces Frostbolt upon activating the Fire specialization.
    - Fireball damage increased by 125%.
    - Fireball cast time reduced to 1.75 seconds (was 2.25 seconds).
    - Flamestrike damage increased by 156% and no longer slows affected enemies by 20%.
    - Flamestrike now has a unit-targeted variant accessible via a choice node on Flamestrike.
    - Pyroblast damage increased by 52%.
    - Cauterize cooldown increased to 6 minutes (was 5 minutes).
    - Intensifying Flame damage bonus increased to 30% (was 20%).
    - Intensifying Flame is now correctly treated as a periodic effect.
    - Combustion's tooltip and aura tooltip have been updated to better reflect its various bonuses.
    - Many talents have changed positions in the talent tree.
    - The following talents have been removed:
      
      - Alexstrasza's Fury
      - Ashen Feather
      - Call of the Sun King
      - Convection
      - Cratermaker
      - Explosive Ingenuity
      - Firefall
      - Flame Patch
      - Hyperthermia
      - Improved Scorch
      - Lit Fuse
      - Majesty of the Phoenix
      - Phoenix Flames
      - Phoenix Reborn
      
      
      
      - Pyrotechnics (*effect moved to the Class tree via Overflowing Energy)*
      - Quickflame
      - Sparking Cinders
      - Sun King's Blessing
      - Surging Blaze
      - Unleashed Inferno

:::

:::

## FAQ

:::accordion
:::details Q: Why can I sometimes not do double [[spell:11366]] after a [[spell:2948]]?
A: If you have too much haste this is no longer possible. This problem only occurs during [[spell:80353]]. To remedy this issue, simply replace [[spell:2948]] with [[spell:133]].

:::

:::

---

### Credits

Written By: **Wexi**

Reviewed By: **Xerwo**

:::changelog 更新记录
**2026-08-03** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-21** Updated for patch 12.0.1.

**2026-01-16** Updated for patch 12.0.



:::
