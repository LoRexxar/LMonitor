Welcome to the **Vengeance Demon Hunter** raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Vengeance Demon Hunter** Raid BIS
```json
{
  "source_code": "J8fAwTVRCc__BEQskQggYUAAvj7AX16AkVzF2IoAYFwAmQQApfBBAkQAAQRrDQRrDIoAYFQAvSCBCgQAAUTuDIoAOFQA0SCBCgQAAkQuDIoAOFQAgfBBAiQABATACRQAwmgHEE6uJ8ACRU9AB0CAp0APYB2uDQAABAgFAPgJqOwSBEgskQAAIEAAFgFMcfBBCiQAA8SuDQRrDUgEIMubCojEAQAVfkBMA0VEMABWBEQ3X0AGEiVABE7FEIAABAQP5OAWBEAEhOgBAEAA9k7AVA8AkqCBLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271537]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240916]] |
| 肩部 | [[item:271535]] | [[item:244021]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240916]] |
| 腿部 | [[item:271536]] | [[item:244641]] |
| 脚部 | [[item:251153]] | [[item:244009]] |
| 腕部 | [[item:244576]] | [[item:245782]] · [[item:240166]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268252]] | [[item:240916]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240916]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:237840]] | [[item:244029]] · [[item:245781]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As  **Vengeance Demon Hunter**, you have access to Untethered Rage, which grants a chance per soul fragment consumed by [[spell:228477]] and [[spell:247454]] to give you a free [[spell:187827]] use.

**Rank 2** increases the damage of [[spell:228477]] and [[spell:247454]] and grants them a chance to consume an extra soul. While **Rank 3** enables that every consumed soul that did not trigger a free [[spell:187827]] gives you a stacking Agility buff and increases the chance of proccing a free [[spell:187827]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-vengeance-mxr.webp>)

Untethered Rage

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:112894]]
    
    - Big AoE damage cooldown that grants souls and was moved from Class Tree to Spec tree.
  - [[talent:112907]]
    
    - [[talent:112907]] was turned from an AoE soul spender to a small AoE cooldown that synergizes with [[talent:112870]] and grants you a big shield.
  - [[talent:112899]]
    
    - Turns your [[spell:187827]] in an actual damage cooldown now, as it increases the damage of all your main rotational abilities by 20% inside of [[spell:187827]].
  - [[talent:112870]]
    
    - Grants you a fancy shield whenever you press [[talent:112907]].

- **Class Tree**
  
  - [[talent:112838]]
    
    - Decreases magic damage taken whenever you interrupt a spell.
  - [[talent:136501@FAQAF6zA]]
    
    - Significantly increases the damage of your [[talent:112908@FAQA_ROB]].
  - [[talent:117758@FAQAF6zA]]
    
    - [[spell:189110]] now grants you a small temporarily shield that decays over time.
  - [[talent:112837@AJADBA]] & [[talent:136502@AJADBA]]
    
    - Allows you to pick a choice node where [[spell:195447]] either clears a curse or a disease effect of you.
  - [[talent:136500]]
    
    - Insane talent that makes you go very fast while gliding.
- **Removed**
  
  - [[spell:321453]]
    
    - You no longer have the ability to enter [[spell:187827]] when casting [[talent:112908@FAQA_ROB]] which turns this into a pure damage cooldown now.

## Hero Talents

- For Raiding I recommend [[talent:134253]] as it offers more ST damage than [[talent:123328]], as well as greater overall survivability.



### [[talent:134253]]

- The [[talent:134253]] talent tree evolves around generating and spending [[talent:135667@FAQAF6zA]] stacks:
  
  - [[spell:225919]] has a 35% chance to grant 1 stack of [[talent:135667@FAQAF6zA]]
  - [[talent:135664@AJADBA]] makes using [[spell:227255]] or [[spell:228477]] after reaching 3 stacks consume all of them and call down 3 meteors that deal big AOE damage.
  - With [[talent:135671@FAQAF6zA]], the meteors additionally cause their targets to take 25% additional damage for 8 seconds.
  - [[talent:135660@FAQAF6zA]] reduces [[spell:187827]] cooldown by 10 seconds after every third meteor that is called down.
- [[talent:135672]] and [[talent:135670]] increase haste and reduce damage taken by 2% for each active stack of [[talent:135667@FAQAF6zA]].
  
  - [[talent:135663@FAQAF6zA]] makes this effect last for 8 seconds after being consumed.
- This results in gameplay that revolves around constantly building [[talent:135667@FAQAF6zA]] stacks with [[spell:225919]] and consuming them with [[spell:227255]] or [[spell:228477]].
  
  - While this happens naturally by doing normal rotation, it is important to consume [[talent:135667@FAQAF6zA]] stacks as early as possible, to not overcap them.




### [[talent:134253]]

- Consuming 20 [[spell:203981]] or casting [[spell:389815]] converts your next [[spell:204157]] into [[spell:442294]].
  
  - This enhances your next [[spell:225919]] and [[spell:228477]]. The enhanced ability you cast first deals 10% increased damage, and the second deals 20% increased damage.
  
  
  
  - Quite simply casting [[spell:225919]] > [[spell:228477]] is the priority of empowerments after using [[spell:442294]].
- The second enhanced ability from using [[spell:442294]] shatters an additional [[spell:203795]] through [[talent:117511]], this allows you to get [[spell:442294]] back faster by consuming more [[spell:203795]].
- [[talent:117500]] is a debuff that causes the target to take 7% increased damage for 20 seconds from an enhanced [[spell:225919]] from [[spell:442294]]. 
  
  - If cast after [[spell:228477]], [[talent:117500]] is increased to 14%.
  - [[talent:117500]] also stacks and can be increased from 7% to 14% by doing a second set of empowerments starting with [[spell:225919]] > [[spell:228477]].
  
  
  
  - Additionally while [[talent:117500]] is up, [[talent:117494]] gives your melee attacks additional damage and has a chance to shatter a [[spell:203795]].
- [[talent:123047]] gives [[talent:112853]] a way of generating **Fury** as it resets the cooldown of [[spell:213241]].
- [[talent:123046]] is extremely strong as it allows you to have incredible amounts of absorbs because you how many [[spell:203795]] you currently consume.
- [[talent:117516]] is a passive buff you get from consuming both enhancements from [[spell:442294]] that gives 6% increased haste.





## Talents



### [[talent:134253]]

:::talents **Vengeance Demon Hunter** [[talent:134253]] Build in Raid
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **[Deep Dive](<https://maxroll.gg/wow/class-guides/vengeance-demon-hunter-raid-guide#deep-dive-header>)** sections below.

##### Spec Tree

- [[talent:112893]]
  
  - A debuff that makes you heal for 8% or 16% with [[spell:389985]] of the damage done. This works exactly like Leech.
- [[spell:336639]]
  
  - Gives [[spell:204021]] a lot higher uptime, making it very strong.
- [[spell:212084]]
  
  - Big damage frontal cone ability that also heals you.
- [[spell:202137]]
  
  - AoE silence in an 8 yard radius.
- [[spell:227255]]
  
  - Small 25 seconds AoE cooldown to generate snap threat that consumes souls.
  - Applies [[talent:112893]].
- [[spell:389732]]
  
  - Makes [[spell:204021]] a 45 second cooldown instead of 1 minute and gives it an additional charge. Damage reduction uptime from [[spell:204021]] becomes a lot higher with this, allowing you to cycle defensives more easily.

##### Class Tree

- [[spell:204909]]
  
  - A 2 point node that gives 5% Leech per point and 5% additional Leech when [[spell:187827]] is active.
- [[spell:179057]]
  
  - A very potent 45 seconds cooldown AoE stun.
- [[spell:202140]]
  
  - Your AoE disorientation that CC's mobs for 15 seconds.
  - Also acts as a stop, or interrupt by canceling a mob's cast.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Fracture damage increased by 35%.
- **4-Set:** Fracture has a 30% chance to spark a violent detonation, causing Fire damage onto nearby enemies. Damage reduced beyond 5 targets.

### Opener



#### [[talent:134253]]

##### Opener

:::rotation Vengeance Demon Hunter [[talent:134253]] Single Target in Raid
```json
{
  "source_code": "IUFbKI0tyXAAAgAUyVGIDF2c0BgQ_J3AAAAAAIUf8lACIc3-CUAEEg8GJABB1zRCIEBKEQHPJABKea8AAAAAAIUf8NA"
}
```
1. [[spell:389815]] Pre Cast
2. [[spell:225919]]
3. [[spell:228477]]
4. [[spell:195447]]
5. [[spell:203720]]
6. [[spell:204021]]
7. [[spell:225919]]
8. [[spell:212084]]
9. [[spell:247454]]
10. [[spell:228477]]
:::

##### Priority List

On Single Target, your goal is to generate as many [[spell:203981]] as possible.

1. Cast [[spell:389815]] off cooldown
2. Cast [[talent:112908@FAQA_ROB]] off cooldown.
3. Cast [[spell:204021]] off cooldown for DR and [[talent:112872]] damage.
4. Cast [[spell:227255]] off cooldown.
5. Cast [[spell:204513]] off cooldown.
6. Cast [[spell:195447]] off cooldown.
7. Cast [[spell:225919]]
8. Cast [[spell:189110]] if you are at 2 charges and do not need to save for movement.
9. Cast [[spell:228477]] as much as possible.
10. Cast [[spell:213241]] if you don't cap Fury.
11. Cast [[spell:195441]] as a filler or if you're far away from the target.





### AoE



#### [[talent:134253]]

##### Opener

:::rotation Vengeance Demon Hunter [[talent:134253]] Aoe in Raid
```json
{
  "source_code": "IUFbKI0tyXAAAgAUyVGIDF2c0BgQ_J3AAAAAAIUf8lACIc3-CUAEEg8GJABB1zRCIEBKEQHPJABKea8AAAAAAIUf8NA"
}
```
1. [[spell:389815]] Pre Cast
2. [[spell:225919]]
3. [[spell:228477]]
4. [[spell:195447]]
5. [[spell:203720]]
6. [[spell:204021]]
7. [[spell:225919]]
8. [[spell:212084]]
9. [[spell:247454]]
10. [[spell:228477]]
:::

##### Priority List

On Single Target, your goal is to generate as many [[spell:203981]] as possible.

1. Cast [[spell:389815]] off cooldown
2. Cast [[talent:112908@FAQA_ROB]] off cooldown.
3. Cast [[spell:204021]] off cooldown for DR and [[talent:112872]] damage.
4. Cast [[spell:227255]] off cooldown.
5. Cast [[spell:204513]] off cooldown.
6. Cast [[spell:195447]] off cooldown.
7. Cast [[spell:225919]]
8. Cast [[spell:189110]] if you are at 2 charges and do not need to save for movement.
9. Cast [[spell:228477]] as much as possible.
10. Cast [[spell:213241]] if you don't cap Fury.
11. Cast [[spell:195441]] as a filler or if you're far away from the target.





### Defensive Cooldowns

- [[spell:187827]]
  
  - [[spell:187827]] is your biggest defensive cooldown, and you should learn to plan around [[spell:187827]] usage to have a smoother time mitigating incoming damage.

- [[spell:204021]] 
  
  - [[spell:204021]] gives you 40% damage reduction while applying a DoT to your target. Normally, you want to use this spell on cooldown as it does decent damage, and can buff your other fire damage spells with [[spell:212818]]. However, hold this spell if there is a tank buster or mechanic that does a lot of damage, and you need to save extra defensives to survive. With talents, it can be extended through [[spell:336639]] to last even longer than usual and have an additional charge as well as a shorter cooldown with [[spell:389732]].

- [[spell:196718]]
  
  - [[spell:196718]] lasts 8 seconds and causes all damage you or an ally takes while inside the darkness to have a 15% chance of being negated completely. This is not great compared to large single hits, but it is good for numerous small hits, such as melee attacks. If you're not saving it for something in particular, you should go ahead and use it almost on cooldown because of the defensive benefits.

### Offensive Cooldowns

- [[spell:389815]]
  
  - [[spell:389815]] deals a moderate amount of damage and generates 3 [[spell:203795]], allowing you to cast [[spell:227255]] more frequently.

## Deep Dive

### Sigils

- Sigils are **Demon Hunter** specific abilities that are placed on the ground and then have a delay of 2 seconds before having an effect within an 8 yard radius. 
  
  - Talenting into [[spell:209281]] brings that delay down to 1 second.
  - They generate 1 [[spell:204255]] with [[spell:395446]].
  
  
  
  - [[spell:389715]] increases the duration of your sigils by 2 seconds and their radius by 2 yards.
  - [[spell:389718]] reduces the cooldown of all your sigils by 15%.

### Cycling defensives on Vengea nce Demon Hunter

- Vengeance Demon Hunter's active mitigation [[spell:203720]] has very high uptime, meaning that as Vengeance Demon Hunter, you can utilize macros and bind [[spell:203720]] into your [[spell:225919]] ability without any defensive loss.
- For cycling defensives, while [[spell:203720]] is our most available active defensive, players should be trying to maximize the uptime of [[spell:187827]] > [[spell:204021]] > [[spell:203720]] in that order.
  
  - This does mean that you end up overlapping and layering [[spell:203720]] with other defensives. The main goal is to make sure that you're not capping [[spell:203720]] charges either.
- This type of gameplay sets Vengeance Demon Hunter apart from other tanks since it needs to be done frequently in high-level content as taking damage with no defensive cooldown can spell disaster.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to **Heroic Bosses**. Mythic tips are going to be released after our progression concludes.

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Vengeance Demon Hunter Raid Nek'Zali**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Tank mechanics

- The main tank mechanic of this fight is Hollowing Strikes - a debuff that the boss applies with each melee strike, as well as with [[spell:1284103]].
- During [[spell:1284103]], the boss sends spectral echoes towards the active tank, applying extra stacks of Hollowing Strikes. These echoes burst on first impact with any player, dealing reduced raid 
  
  - When targeted by this mechanic, move out of the raid and make sure no one is standing between you and the boss so they don't trigger the echoes too early. Otherwise, they will deal too much damage to the raid.
  - Taunt swap after each cast of [[spell:1284103]].
- Apart from that, the boss will spawn waves of Restless Amani - make sure to move the boss next to them to allow for better cleave.
- During the intermission, the active tank will be targeted by a group soak - [[spell:1289855]]. Try to put it on top of as many Restless Amani corpses as possible to burn them with [[spell:1289875]] to prevent them from awakening again.




### Entombed Sentinels

:::talents **Vengeance Demon Hunter Raid Entombed Sentinels**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Tank mechanics

- The bosses have to always be separated by at least 40 yards due to [[spell:1290189]]. At the start of each phase, split the bosses apart by moving them to different sides of the room.
- [[spell:1284458]] and [[spell:1284487]] are the stacking tank debuffs of each of the bosses. Make sure to taunt swap on the bosses each time they meet in the middle of the room during [[spell:1284588]] to reset your stacks.
  
  - [[spell:1284487]] additionally creates a large pool of blood upon expiration. Make sure to drop it off at the edges of the room if possible.
- Don't tank Breath of Ula'tek too close to the existing blood puddles so the [[spell:1284251]] doesn't spawn in the pool and melees can safely attack it.




### Lost Explorers

:::talents **Vengeance Demon Hunter** **Raid Lost Explorers**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Tank mechanics

- All three bosses cannot be positioned within 30 yards of each other due to [[spell:1297645]] - always keep one of the bosses away from the other 2.
- Trader Gebbo just wanders around the room and doesn't follow or attack its threat target. It also doesn't have any tank mechanics.
- Scrollsage Iku casts [[spell:1295854]] at its current target - a series of ice shards, each doing magic damage and increasing damage taken from the next shard for 80 seconds.
- First Mate Nama applies [[spell:1291929]] with each attack to its target, increasing physical damage done to that target for 30 seconds.
- The job of the tanks on this fight is to swap between Scollsage Iku and First Mate Nama, never letting [[spell:1295854]] to be casted at the same target twice and resetting [[spell:1291929]] as often as possible, while always keeping one of the bosses far enough to prevent [[spell:1297645]] from being applied.




### Vashnik

:::talents **Vengeance Demon Hunter Raid Vashnik**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Tank mechanics

- There are 3 fountains placed on the sides of the room: Fountain of Blood, Fire, and Shadow. The boss will activate the two closest ones with [[spell:1283164]] throughout the fight, gaining their powers and spawning some adds.
  
  - Each fountain activation empowers the next activation for 1.5 minutes.
  
  
  
  - Your job as a tank is to never let the boss activate the same two fountains in a row by moving the boss to the next fountain before each [[spell:1283164]] cast.
  - Make sure to position the boss on top of the adds coming from the fountain for better cleave. However, be careful with quickly killing all the fire adds, as they apply stacking [[spell:1285979]] when they die.
- Vashnik's tank hit is [[spell:1280935]], taunt swap after each cast.




### Sszorak

:::talents **Vengeance Demon Hunter Raid Sszorak**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Fight mechanics

- [[spell:1277025]] is a combination of tank frontals consisting of 2 [[spell:1277002]], 2 [[spell:1277027]], and one [[spell:1287072]], cast in a random order.
  
  - [[spell:1277002]] is a frontal cone that deals heavy physical damage and follows the active tank. Make sure to aim it **away from the raid**.
  - [[spell:1277027]] is a frontal cone that applies a heavy magic DOT, which is reduced by the number of people hit by the cone. Make sure this ability is aimed into one half of the raid, so people can soak it.
  - [[spell:1287072]] spawns a bunch of tornadoes around the boss and sends them outwards at the end of the cast. Make sure you're not under the boss when this happens and dodge the tornadoes.
  - In heroic and mythic difficulties, the boss will cast these in a random order. Since each frontal cone applies a damage taken increase from that ability, make sure that one tank never takes 2 of the same abilities. Keep in mind that you can taunt during the cast so the boss aims the frontal cone at you instead.
- Each cast of [[spell:1306120]] spawns [[spell:1305998]] puddles around the boss. Make sure to move the boss to an edge of the room, ideally opposite the [[spell:1285732]] spawn, so that the puddles get blown off the edge of the room by the winds.
- Apart from that, Sszorak applies a stack of [[spell:1282869]] with each melee attack, increasing physical damage taken by the target. Taunt swapping on each [[spell:1277025]] combo is enough to reset the stacks.




### Twin Fangs

:::talents **Vengeance Demon Hunter** **Raid Twin Fangs**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### General mechanics

- The entire fight revolves around managing [[spell:1290336]] stacks
  
  - [[spell:1291404]], [[spell:1291478]], getting hit by poison waves, or soaking [[spell:1289201]] applies a stack of [[spell:1290336]].
  - Reaching 10 stacks in Heroic or 9 in Mythic difficulties immediately kills you.
  - It is crucial to dodge as many poison waves as possible while managing how many [[spell:1289201]] you soak to prevent reaching maximum stacks of this debuff.

#### Tank mechanics

- Being outside of melee range of the boss that you're actively tanking will cause it to cast [[spell:1295107]] or [[spell:1295113]], so make sure to never leave melee or use a big personal if you ever find yourself far from the boss.
- Vexhul's tank ability is [[spell:1289192]], which deals nature damage and pushes you back for 5 seconds.
  
  - It also spawns [[spell:1289201]] around you. These need to be soaked by players before they explode to prevent everyone from getting an [[spell:1290336]] stack.
  - Each hit applies [[spell:1310360]], so taunt swap between every [[spell:1289192]] cast.
  - Be aware of the pushback, especially when the poison waves are coming!
- Ithraz casts [[spell:1288538]], pushing back players close to the boss and spawning 3 soak zones.
  
  - Each zone deals heavy physical damage and increases the damage taken from the next zone by 33%. If it is left unsoaked, it deals raid-wide damage and knocks everyone away. Make sure to taunt swap between each set of [[spell:1288538]] to reset the stacks of the damage increase.
  
  
  
  - The zones spawn in a random order and need to be soaked in the same order that they spawned. Pay attention to the spawns and memorize the spawn order when this ability is happening. The boss will also shortly face towards the zone it will trigger next, so you can use that direction if you can't remember the spawn order.
  - Each second [[spell:1288538]] cast overlaps with poison waves coming - make sure you're not getting hit by waves while soaking the [[spell:1288538]].
  - Watch out for the pushback at the start of this mechanic, as it can push you into an incoming wave or a [[spell:1289201]].




### Coiled Altar

:::talents **Vengeance Demon Hunter Raid Coiled Altar**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### Phase 1

- Only Zul'jan is active during this phase.
- He casts [[spell:1299960]], which spawns multiple [[spell:1282403]] orbs during this phase. They deal pulsing raid-wide AOE while they're active, and can be picked up and moved by players running into them.
- [[spell:1299684]] is a frontal cone aimed at the active tank that deals physical damage and destroys any [[spell:1282403]] it hits.
  
  - It also increases damage taken by the next [[spell:1299684]] by 200%, so make sure to taunt swap after every cast.
- The goal of this phase is for the raid to group up the [[spell:1282403]] orbs so they can then be destroyed by [[spell:1299684]].
- Additionally, each cast of [[spell:1282487]] empowers the next 23 melees of the boss with [[spell:1300322]], dealing extra nature damage to the tank. 
  
  - Make sure to frontload defensives while the boss has stacks of [[spell:1300322]].

#### Phase 2

- Only Hex Lord Malacrass is active during this phase.
- He casts [[spell:1285640]], which mind-controls selected players, and spawns 2 [[spell:1285842]] per player when the mind control is broken.
  
  - The Manifestations fixate on random players, moving towards them, unless the fixated player looks back at the Manifestation.
- Similar to [[spell:1299684]] in Phase 1, [[spell:1286620]] is a frontal cone aimed at the active tank that deals shadow damage and destroys any [[spell:1285842]] it hits.
  
  - It also increases damage taken by the next [[spell:1286620]] by 200%, so make sure to taunt swap after every cast.
  - Additionally, it applies 3 stacks of [[spell:1286837]], which spawn a Soul Fragment per stack that needs to be picked up in order to remove the stack. If the stacks are not cleared before the debuff expires, the affected player immediately dies.
  - It is important to pay extra attention to finding and collecting all Soul Fragments quickly after each tank frontal.
- Getting hit by a [[spell:1286895]] also applies 3 stacks of [[spell:1286837]]. Don't let it catch you off guard!

#### Intermission

- Malacrass takes 100% extra damage while casting [[spell:1287685]]. Make sure to save your big defensives for the intermission!
- Don't let any Fragments of Malacrass reach the boss by soaking them to prevent them from healing the boss.
  
  - Soaking each fragment deals raid-wide AOE damage, so don't soak them too quickly to give your healers some time to react to the incoming damage.

#### Phase 3

- During this phase, both Zul'jan and Malacrass are active, combining their abilities from Phases 1 and 2.
- Both [[spell:1299960]] and [[spell:1285640]] happen in this phase, meaning both [[spell:1282403]] and the [[spell:1285842]] need to be cleared by the tank frontal.
- The tank frontal cone of this phase is [[spell:1307279]], which deals shadow damage, destroys any [[spell:1282403]] and [[spell:1285842]] hit by it, and applies 3 stacks of [[spell:1286837]].
  
  - Don't forget to collect your Soul Fragments and taunt swap after each cone!
- [[spell:1298381]] is the empowered verision of [[spell:1282487]] from phase 1.
  
  - In this phase, the empowered melee attacks additionally apply a **stacking** shadow DOT. Use big defensives when reaching high stacks.




### Ula'tek

:::talents **Vengeance Demon Hunter Raid Ula'tek**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::




### Nymrissa Wavecaller

:::talents **Vengeance Demon Hunter Raid Nymrissa Wavecaller**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

#### General mechanics

- The boss targets random players with Chilling Frost, which drops Frost Orbs under their feet.
  
  - These orbs need to get soaked before they explode and wipe the raid.
  - Soaking an orb applies a stacking debuff that increases the damage taken from soaking Frost Orbs, so don't soak too many in one go.
  - Each orb soak also deals raid-wide AOE, so don't soak them too quickly to give your healers some time to react to the incoming damage.
- Occasionally, murlocs will spawn from the water and start walking towards the bubble in the middle of the room.
  
  - Don't let them reach the bubble, and move the boss on top of them whenever possible to allow for better cleave.

#### Tank mechanics

- A tank-only mechanic of the fight is the Iceblade Flurry - a series of magic slashes, with each slash increasing the damage of the following ones.
  
  - Use a defensive for each cast and taunt swap after each one.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance raiding as a **Vengeance Demon Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

#### 

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

### Reasons for Stats

Haste is always the most sought after Stat as it gives a high amount of damage, as well as cdr on [[spell:203795]] generating abilities and [[spell:203720]], which gives a lot of survivability. In Raiding, you can't often get as much defensive value out of Critical Strike as you can with Versatility, especially because a lot of bosses have tank busters or abilities that cannot be parried. Therefore, Versatility is slightly better than Critical Strike for survivability in Raiding as well as more consistent which is something you value a lot in "Progress Raiding".

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary Stats

- **Avoidance** - Slightly reduces damage taken from area of effect attacks. This can be certain tank abilities a boss does,  as well as trash. Starts diminishing returns heavily at 20% (2000), but it has no cap.
- **Leech** - Causes a player to instantly return health from both outgoing damage and outgoing heals. Health returned is equal to your amount of Leech. For Example; 1 % of Leech gives health equal to 1% of damage and healing done.
- **Speed** - Increases movement speed.

In conclusion, **Avoidance** is what you should go for as a **Vengeance Demon Hunter** in raiding to min-max survivability as it gives you the greatest benefit in Raid over the other two tertiary stats. **Leech** is better on fights with lots of adds that are difficult to tank and live a long time.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | Ula'tek |
| Neck | [[item:271537@DCRBAUkAvj7cVrDZ1chNYFwAmQA]] | Ula'tek |
| Shoulder | [[item:271535@DAQAAUkA1k74UA]] | Tier |
| Cloak | [[item:268253@BAQAAUkAYFA]] | The Coiled Altar |
| Chest | [[item:271540@DAQAAUkAJk74UA]] | Tier |
| Wrist | [[item:244576@FAQAAUkAWA8YiqzSBA]] | Crafting |
| Gloves | [[item:271538@BAQAAUkAOFA]] | Tier |
| Belt | [[item:268256@BCQAAUkAU06gVA]] | The Coiled Altar |
| Legs | [[item:271536@DAQAAUkAhu7gVA]] | Tier |
| Boots | [[item:251153@DgQAAUkApk7IoAOF]] | Den of Nalorakk |
| Ring 1 | [[item:268252@DEQAAUkAvk7QRrDFtOOF]] | Sszorak |
| Ring 2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | Kings' Rest |
| Trinket 1 | [[item:270164@BgQAAgGACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270173@BAQAAUkAOFA]] | The Coiled Altar |
| Weapon | [[item:268209@DAQAAUkA9k7gVA]], [[item:237840@HAQAAUkA9k7UBwDpqQLF]] | The Coiled Altar, Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@BgQAAgGACKQQBA]] | Altar of Fangs |
| Neck | [[item:251173@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAAgGACKQQBA]] | Voidscar Arena |
| Cloak | [[item:193763@BgQAAgGACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@BgQAAgGACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251135@BgQAAgGACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgQAAgGACKQQBA]] | Murder Row |
| Belt | [[item:159301@BgQAAgGACKQQBA]] | Kings' Rest |
| Legs | [[item:159313@BgQAAgGACKQQBA]] | Kings' Rest |
| Boots | [[item:251153@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Ring 1 | [[item:273792@BgQAAgGACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:159459@BgQAAgGACKQQBA]] | Kings' Rest |
| Trinket 1 | [[item:250228@BgQAAgGACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250215@BgQAAgGACKQQBA]] | Murder Row |
| Weapon | 2x [[item:251143@AgQAAIoAOFA]] | Den of Nalorakk |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270175@BgQAAgGACKAWBA]]  <br>[[item:270173@BgQAAgGACKAWBA]]  <br>[[item:270165@BgQAAgGACKgTBA]] |
| **A-Tier** | [[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B-Tier** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Best overall choice of stat budget.
- 1x [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241324]]**
- **Food**
  
  - **[[item:255845]]**
- **Combat Potion**
  
  - **[[item:241308]]**
- **Health Potion**
  
  - **[[item:271884]]**
- **Weapon Stone/Oil**
  
  - **[[item:243734]]**
- **Augment Rune**
  
  - **[[item:259085@AQAAAoF]]**
- **Sockets**
  
  - **[[item:240967]] *-- Unique, use one of each gem colour to enhance your Blasphemite.***
    
    - **[[item:240910]]**
    - **[[item:240914]]**
    - **[[item:240890]]**
    - **[[item:240900]]**

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAIE]] |
| Belt | [[item:275707@BAAAAIE]] |
| Legs | [[item:244641@BAAAAIE]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244015@BAAAAIE]] |
| Ring 2 | [[item:244015@BAAAAIE]] |
| Weapon | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **Vengeance Demon Hunter** **Raid**
```json
{
  "source_code": "JwFZFJQ9NGQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AERgAK9k7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
| 副手 | [[item:244029]] |  |
:::

:::

:::

> *You buy ‍[[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

In this section of the Vengeance Demon Hunter Raid Guide, we showcase and explain how impactful certain racials can be in World of Warcraft.

- [[spell:58984]] -- Nightelf
  
  - Provides nothing in Raid, but can be useful in Mythic+ in very niche situations.
- [[spell:202719]] -- Bloodelf
  
  - Removes 1 beneficial effect from hostile targets around you.
  - Generates 15 Fury.
- [[spell:256948]] -- Voidelf
  
  - Tear a rift in space. Reactivate this ability to teleport through the rift.

### Recommendation

I personally recommend Night Elf because of its use cases in Mythic+ which get more value out of as a player even as a Raider. The difference between both races in raiding is not very big at all, so you might as well play Night Elf for its bonuses in Mythic+.

## Macros

Discover recommended macros for **Vengeance Demon Hunter** for Raids and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
**Taunt at Mouseover** --- *Mouseover macro for [[spell:185245]] (Taunt) that allows you to get aggro easily from targets that just come into view or spawn without having to change target. If you have nothing over mouseover it taunts your primary target.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]Torment
```

Boss 1 Taunt --- *Casts [[spell:185245]]* *on Boss1*

```wow-macro
/cast [@boss1] Torment
```

Boss 2 Taunt --- *Casts [[spell:185245]]* *on Boss2*

```wow-macro
/cast [@boss2] Torment
```

:::

:::details Cursor Macros
***[[spell:202137]]** at cursor ---  This makes it much faster to quickly use [[spell:202137]] in any given scenario*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Silence
```

***[[spell:202138]]** at cursor ---  This makes it much faster to quickly use [[spell:202138]] in any given scenario*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Chains
```

***[[spell:202140]]** at cursor ---  This makes it much faster to quickly use [[spell:202140]] in any given scenario.*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Misery
```

***[[spell:204513]]** at cursor ---  This makes it much faster to quickly use [[spell:204513]] in any given scenario.*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Flame
```

**[[spell:389815]]** at cursor ---  This makes it much faster to quickly use [[spell:389815]] in any given scenario.

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Spite
```

**[[spell:189110]]** at cursor ---  This makes it much faster to quickly use [[spell:189110]] so that you can move around quicker and more effectively.

```wow-macro
#showtooltip
/cast [@cursor] Infernal Strike
```

:::

:::details Utility Macros
**Cancelaura macro** --- *Here is a very important macro that you want to fill with any buff that is an immunity that you would need to cancel in a given scenario. For example;  you used a paladin's [[spell:1022]] to get rid of a debuff quickly and need to cancel so that you can continue being the primary aggro target before your allies are tanking instead.*

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::details Player Macros
**[[spell:189110]] at Self**--- *Allows to instantly Infernal strike at the feet, which can be used to min max a bit more damage since [[spell:189110]] is off the GCD. This should not be done that often but it has its use cases.*

```wow-macro
#showtooltip
/cast [@player] Infernal strike
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Vengeance Demon Hunter**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/nicememesuimidnight-3-1024x681.png>)

**Vengeance Demon Hunter** Interface in Raids

:::accordion
:::details Addons
- BigWigs -- Generic Boss Mod
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific raid encounter.
- Plater -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter for World of Warcraft.
- Echo Raid Tools -- Notes, Raid cooldowns, and more
  
  - Echo Raid Tools is a World of Warcraft addon designed by Echo Esports to enhance raiding efficiency. It offers "Echo Approved" WeakAuras for each raid boss accessible through an in-game Dungeon Journal interface, allowing easy import and customization.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**▶ DEMON HUNTER**

- Vengeance
  
  - Fracture and Soul Cleave now require equipped Warglaives, Axes, Swords, and Fist Weapons.
  - Sigil of Chains is now learned at level 35 and is no longer a talent.
  - Sigil of Chains cooldown reduced to 60 seconds (was 90 seconds).
  - Sigil of Chains no longer replaces Sigil of Misery.
  - Sigil of Silence now replaces Sigil of Misery when selected.
  - Improved Sigil of Misery no longer affects Sigil of Chains.
  - Improved Sigil of Misery now reduces the cooldown of Sigil of Silence by 15 seconds when Sigil of Silence is selected.
  - All damage increased by 5.5%.
  - Soul Cleave healing increased by 25%.
  - Fel Devastation healing increased by 25%.
  - Charred Warblades heals you for 5% of Fire damage you deal (was 4%).
  - Frailty causes you to heal for 10% of damage dealt to afflicted targets (was 8%).
  - Feast of Souls healing increased by 25%.
  - Revel in Pain causes 6% of your Fire damage to shield you (was 5%).
  - Several talents have changed locations in the talent tree.

:::

:::

## FAQ

:::accordion
:::details Q: How to get better at tanking?
The biggest tip I can give is to always figure out why you died in a given scenario and how you can improve. Tanking is tough, with constant opportunities to better use your externals, rotation, and defensives. Recording your gameplay and reviewing Warcraft Logs are great methods. Being good at tanking requires cognitive flexibility—focus on what you could have done better instead of blaming others. This mindset is more rewarding and healthier for becoming a better tank.

:::

:::

---

### Credits

Written By: Nicememes

Reviewed By: Tief

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1

**2026-06-22** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-01-19** Updated for patch 12.0.1



:::
