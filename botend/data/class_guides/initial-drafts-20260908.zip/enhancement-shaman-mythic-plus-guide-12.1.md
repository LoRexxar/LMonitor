欢迎来到魔兽世界12.1版本的**增强 萨满祭司** 大秘境攻略！本攻略涵盖了你了解自己角色所需的一切知识！如果你是从80级开始练级的新手，请查看练级攻略！

## 概述

:::columns
:::column
:::rating 大秘境
**单体** · 4/5 · 强

范围伤害 · 5/5 · 优秀

功能性 · 5/5 · 优秀

生存能力 · 3/5 · 一般

机动性 · 4/5 · 强



:::

:::

:::column
:::gear **增强 萨满祭司** 大秘境最佳配装（BiS）
```json
{
  "source_code": "IgoAQfQA3_fABsHJEIICBAwJ5OwVtOQOC4UABk-FEAQEBAA_sOA_sOQOCwYNYFQA5RCBCgQAAcRuJMCJEYCBCARAAkQuD0AIQ49FEAICFQTBDBgeJ8CBhubCPgQyXQQA-QQ84mwDIg2uDEwcEgBwBEGL3WzSBEAfkQAAIEAAFwDBZfRBRSQ94GgHFIBBildBwkgEAIYAji0XfQAAIMAA5IAWBUAAB40FCEQXBIRAChBWBEAKoOABBMNDqOAGAnAYAEbCBCwPBALQYFQAYV9ACgQAA8TuDIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271483]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271481]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240892]] |
| 腿部 | [[item:271482]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271484]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:239656]] | [[item:240167]] · [[item:245784]] |
| 主手 | [[item:268209]] | [[item:244031]] |
| 副手 | [[item:251224]] | [[item:244031]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**增强 萨满祭司**，你可以使用风暴释放，它有几率触发，使你的下一个[[talent:101840]]无视冷却时间。

**第2级**使你的终结技和武器灌注造成更多伤害。

**第3级**使你的[[talent:101840]]对一片区域施放闪电，对站在其中的任何敌人造成伤害。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-enhancement-mxr.webp>)

风暴释放

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:101826]]
    
    - 使该专精运转流畅的最重要天赋之一。
  
  
  
  - [[talent:101827]]
- **职业天赋树**
  
  - [[talent:127868@AJwB]]
    
    - 使你的 [[talent:127871@FJgAWRpEigdBHA]] 不消耗层数，并且治疗量提高。
  
  
  
  - [[talent:135591@AJwB]]
    
    - 被动获得智力，并自动施放你所有的附魔和护盾。
- **已移除**
  
  - [[spell:375982]]
  - [[spell:117014]]
  - [[spell:179400]]
  - [[spell:262624]]

## 英雄天赋



### [[talent:123381]]

- 在 至暗之夜 中，英雄树新增了3个天赋：
  
  - [[talent:135987@AJwBBA]]
    
    - 被动提升你的 [[spell:65986]] 的伤害。
  - [[talent:135986]]
    
    - 被动提升自然伤害
  - [[talent:135985@AJwBBA]]
    
    - 在使用你的 [[talent:114291]] 或从 [[talent:101816]] 获得触发效果后，给予你一个 [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]。
- [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - 你的 ‍闪电箭‍ 在消耗 [[spell:187880]] 后有几率变成 ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]‍。
  - 这个英雄天赋树的核心思路是尽可能多地循环使用 [[spell:187880]]，并尽可能多地施放 ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]‍。
- [[talent:117482]]
  
  - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 使你的下一个 [[spell:188443]] 或 [[spell:188196]] 变为瞬发，并造成更高伤害。
- [[talent:117470]] 或 [[talent:128225]]
  
  - [[talent:117470]] 
    
    - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 给予你 精通 持续几秒。
  - [[talent:128225]]
    
    - [[spell:188196]]、[[spell:188443]] 和 [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 有几率返还 [[spell:187880]] 层数。
- [[spell:454026@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 还会召唤一个自然 [[spell:51533]]。
- [[spell:455123@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - 施放 ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]‍ 会对你的目标施加 ‍[[spell:210689@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]‍。
- 这个天赋树的其余部分是不太影响你游戏方式的被动效果。
  
  - [[spell:454391@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - 消耗 [[spell:187880]] 会给予你 急速.
  - [[spell:454919@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - 提升你的 ‍[[spell:187874]]‍ 和 ‍[[spell:188443]]‍ 的伤害。
  - [[spell:454021@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - 提升你的 爆击 几率和自然法术的伤害。




### [[talent:123379]]

- 在 至暗之夜 中，英雄树新增了3个天赋：
  
  - [[talent:135984@AJwBBA]]
    
    - 被动提升[[talent:135593]]，且每当你消耗[[spell:65986]]时，你的[[talent:101809]]会获得延长。
  - [[talent:135983]]
    
    - 被动精通提升
  - [[talent:135982@AJwBBA]]
    
    - 在使用[[spell:444995]]后强化你的第一个[[talent:135593]]。
- [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - 召唤一个图腾，每6秒释放大量伤害，伤害降低于 急速.
- [[spell:445024@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - 在召唤你的[[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]之后，你的下一个：
    
    - [[spell:188196]]、[[spell:188443]]或[[spell:394150]]会释放 **汹涌之箭** 射向你的[[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]。
    - 你的下一个[[spell:60103]]或[[spell:333974]]使你获得[[spell:201900]]，持续6秒。
- [[spell:445034@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - [[spell:60103]]有几率召唤一个 **灼热图腾** 向附近的敌人发射灼热之箭
    
    - 被[[spell:334195]]、[[spell:60103]]和[[spell:333974]]强化的[[spell:196840]]使你的 **灼热图腾** 向附近的敌人发射一发灼热烈焰齐射。
- 其余部分为被动效果，对你的玩法影响不大。
  
  - [[spell:445025@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - [[spell:188196]]、[[spell:188443]]和[[spell:394150]]有几率强化你的图腾并造成额外伤害。
  - [[spell:445028@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - 提升[[spell:33757]]的触发几率及其伤害。
    - 当[[spell:318038]]由[[spell:33757]]攻击触发时，有几率在目标周围引发火焰漩涡，对其附近的所有敌人造成伤害。
  - [[spell:445029@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]或[[talent:125823]]
    
    - [[spell:445029@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
      
      - 当[[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]处于激活状态时，你造成的伤害和治疗提高3%。
    - [[talent:125823]]
      
      - [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]在[[spell:114051]]期间造成更多伤害。
  - [[spell:445036@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]或[[talent:125822@FAQARdhA]]
    
    - [[talent:117478@FAQARdhA]]
      
      - 提升你的 **灼热图腾**' 爆击 的几率，以及其 爆击 伤害。
    - [[talent:125822@FAQARdhA]]
      
      - 施放 [[spell:197214]] 会使你的 [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 产生一次震颤。
  - [[spell:445032@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 或 [[talent:125824@FAQARdhA]]
    
    - [[talent:117463@FAQARdhA]]
      
      - 提高你的 [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 的伤害。
    - [[talent:125824@FAQARdhA]]
      
      - 提升你的 爆击 你的 [[spell:318038]] 及其的几率 爆击 伤害。





## 天赋



### [[talent:123381]]

:::talents [[talent:123381]] **增强 萨满祭司**在大秘境中的天赋
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 改变游戏玩法的天赋

探索专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行简明概述，如需更详细的了解，请查看下方的**输出循环**和**深度解析**章节。

##### 专精树

- [[talent:101827]]
  
  - 使 [[talent:101804]] 和[[talent:101805]] 有100%的几率产生1层 [[spell:187880]]。
- [[talent:101825]]
  
  - [[talent:101804@FAQAlezA]] 现在拥有2层充能。
  - [[spell:201845]] 现在还会使你的下一个 [[talent:101804@FAQAlezA]] 额外造成25%的自然伤害，最多叠加2次。
- [[talent:101814]]
  
  - 20%的几率返还任何已消耗的 [[spell:187880]]。
  - 在 [[talent:114291]] 期间每秒产生2点 [[spell:187880]]。
- [[talent:101813]]
  
  - [[spell:188196]] 和 [[talent:127856]] 造成的伤害提高20%。
  - 当 [[talent:114291]] 或 [[talent:101824@FAQAQSfB]] 处于激活状态时，[[spell:115356]] 会自动消耗最多5个 [[spell:187880]] 来施放 [[spell:188196]] 或 [[talent:127856]]，以最近施放过的那个为准。
  - 自11.2版本起，会自动施放 [[talent:117489@FAgAo3tAHldB]]，消耗最多10个 [[talent:101804@FAQAHldB]]。

##### 英雄天赋

- [[talent:117489]]
  
  - 你的 ‍闪电箭 会变成 ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
- [[talent:128225]]
  
  - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]、[[spell:188443]] 和 [[spell:188196]] 有 35% 的几率返还 2 层 [[spell:187880]]。




### [[talent:123379]]

:::talents [[talent:123379]] **增强 萨满祭司** 在 大秘境   中的天赋
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMjZmZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZC2AYWmxMGLLzYhZmNWmZmZYYMDAwMAjZmYmBAGD",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMjZmZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZC2AYWmxMGLLzYhZmNWmZmZYYMDAwMAjZmYmBAGD"
}
```
:::

#### 专精树

- [[talent:101841]] 配合 [[talent:101828]] 可造成大量 范围伤害 伤害。
- [[talent:101813]]
  
  - [[spell:188196]] 和 [[talent:127856]] 造成的伤害提高 20%。
  - 当 [[talent:114291]] 或 [[talent:101824@FAQAQSfB]] 处于激活状态时，[[spell:115356]] 会自动消耗最多 5 个 [[spell:187880]] 来施放 [[spell:188196]] 或 [[talent:127856]]，以最近施放过的那个为准。
- [[talent:101809]]
  
  - 触发效果，可大幅强化你的 [[spell:60103]]。

#### 英雄天赋

- [[talent:117476@FAQARdhA]]
  
  - 在使用 [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] 后，你的下一个 [[spell:60103]] 将触发 [[spell:201900]]。
- [[talent:135984@AJwBBA]]
  
  - [[talent:101809]] 的延伸以及被动伤害提升。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2 件套：‍**[[spell:470053]] 会使你的主要目标每 2 秒爆发一次 [[talent:136176]]，持续 6 秒。[[talent:136176]] 对你的 [[spell:470053]] 的主要目标造成的伤害提高 200%。
- **4 件套：**‍[[talent:136176]] 会使 [[talent:101840@FAQAVwxE]] 的冷却时间缩短 2 秒，并使你的下一个 [[talent:101840@FAQAVwxE]] 的伤害提高 8%，最多可叠加 5 次。

### 单体目标



#### [[talent:123381]]

##### 起手爆发

- 你的目标是使用 [[spell:470057]]，然后配合 [[spell:114049]] 使用你的爆发技能，并从那里继续你的循环。

:::rotation **增强 萨满祭司** [[talent:123381]] 在 大秘境   中的单体开场手法
```json
{
  "source_code": "I0CcFIUKscAAAAAACNYvBAAAAEQAc66AAAAAAIk4dLQBIgCnCHAAAAAACxpwBA"
}
```
1. [[spell:470057]]
2. [[spell:114051]]  [[item:241308]]
3. [[spell:187874]]
4. [[spell:115356]]
5. [[spell:115356]]
:::

- 你需要在 10 层 [[talent:101804@FAQAHldB]] 时使用 [[talent:101828]] 以激活 [[talent:101815]]。如果在施放 [[talent:101828]] 之前未达到 10 层，请先施放一个 [[talent:101805@FAQARjRB]]。
- [[talent:101805@FAQARjRB]] 只是填充技能，如果有可用的 [[spell:32175]] 或 [[spell:470053]]，你会更倾向于使用它们。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在 [[talent:114291@FAgAb2dB51uB]] 期间施放 [[talent:101840]]。
2. 在 [[talent:114291@FAgAb2dB51uB]] 期间施放 [[spell:115356]]。
3. 施放 [[talent:101824@FAgAQSfB3HAB]]。
4. 施放 [[talent:114291@FAgAb2dB51uB]]。
5. 在 [[spell:187880]] 达到 9 层以上时施放 [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]。
6. 在 [[spell:187880]] 达到 9 层以上时施放 [[spell:188196]]。
7. 施放 [[talent:101840]]
8. 如果你有 2 层充能，则施放 [[spell:17364]]。
9. 施放 [[spell:60103]]
10. 施放 [[spell:17364]]。
11. 施放 [[spell:470057]]。
12. 施放 [[spell:196840]]。




#### [[talent:123379]]

##### 起手爆发

- 当你拥有10层[[talent:101804@FAQAHldB]]时使用你的[[talent:101830@AJwBBA]]。

:::rotation **增强 萨满祭司** [[talent:123379]]在大秘境中的单体开场
```json
{
  "source_code": "I0F2HIUKscAAAAAAC588GUkAKUmUBMFUBcaLBE1FCQwZCk4eCUHFDoRDHwRDH8vhScQAAEQAc66AAEQMMAW3FAQAIQgXCkAEIcs6AEQAoI0_VKBAAAAACds6"
}
```
1. [[spell:470057]]
2. [[spell:455630]]  [[item:241308]]
3. [[spell:384352]]
4. [[spell:197214]]
5. [[spell:60103]]
6. [[spell:1218047]]
7. [[spell:60103]]
:::

- 如果在 [[talent:101815]] 处于激活状态时，务必在 [[spell:201900]] 期间施放 [[spell:60103]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在冷却时施放 [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wB_boEHEA]]。
2. 如果 [[spell:384450]] 即将结束，在 10 层 [[spell:187880]] 时施放 [[spell:1218047]]。
3. 在 10 层 [[spell:187880]] 时施放 [[spell:188196]]。
4. 如果 [[spell:470411]] 尚未作用于你的目标，则施放它。
5. 施放 [[spell:60103]]。
6. 施放 [[spell:384352]]。
7. 施放 [[spell:17364]]。
8. 施放 [[spell:196840]]。
9. 施放 [[spell:470411]]。





### 范围伤害



#### [[talent:123381]]

##### 起手爆发

- 你的目标是使用 [[spell:470057]]，然后配合 [[spell:114049]] 使用你的爆发技能，并从那里继续你的循环。

:::rotation **增强 萨满祭司** [[talent:123381]] 在大秘境中的2+目标开场
```json
{
  "source_code": "I0CcFIUKscAAAAAACNYvBAAAAEQAc66AAAAAAIk4dLQBIgCnCHAAAAAACxpwBA"
}
```
1. [[spell:470057]]
2. [[spell:114051]]  [[item:241308]]
3. [[spell:187874]]
4. [[spell:115356]]
5. [[spell:115356]]
:::

- [[talent:101840]] 会消耗你的 [[spell:65986]] 并且本身伤害不俗，所以请确保在你的 [[spell:114051]] 或 [[spell:384352]] 中尽可能多地使用它。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在 [[talent:114291@FAgAb2dB51uB]] 期间施放 [[talent:101840]]。
2. 在 [[talent:114291@FAgAb2dB51uB]] 期间施放 [[spell:115356]]。
3. 施放 [[talent:101824@FAgAQSfB3HAB]]。
4. 施放 [[talent:114291@FAgAb2dB51uB]]。
5. 在 [[spell:187880]] 达到 9 层以上时施放 [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]。
6. 在 [[spell:187880]] 达到 9 层以上时施放 [[spell:188196]]。
7. 施放 [[talent:101840]]
8. 如果你有 2 层充能，则施放 [[spell:17364]]。
9. 施放 [[spell:60103]]
10. 施放 [[spell:17364]]。
11. 施放 [[spell:470057]]。
12. 施放 [[spell:196840]]。




#### [[talent:123379]]

##### 起手爆发

:::rotation **增强 萨满祭司** [[talent:123379]] 在 大秘境 中的多目标开局
```json
{
  "source_code": "I0F2HIUKscAAAAAAC588GUkAKUmUBMFUBcaLBE1FCQwZCk4eCUHFDoRDHwRDH8vhScQAAEQAc66AAEQMMAW3FAQAIQgXCkAEIcs6AEQAoI0_VKBAAAAACds6"
}
```
1. [[spell:470057]]
2. [[spell:455630]]  [[item:241308]]
3. [[spell:384352]]
4. [[spell:197214]]
5. [[spell:60103]]
6. [[spell:1218047]]
7. [[spell:60103]]
:::

- 只要有可能，你就应该施放 [[spell:60103]]。在 [[talent:101809]] 期间，这相当于每隔一个公共冷却施放一次。
- 你会提前施放一次 [[spell:187874]]，然后在整个战斗过程中保持该增益效果不断。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 如果 [[spell:470411]] 尚未作用于你的目标，则施放它。
2. 冷却好了就施放 [[spell:444995]]。
3. 在 [[talent:101809]] 期间施放 [[spell:60103]]。
4. 冷却好了就施放 [[spell:384352]]。
5. 如果 [[spell:384450]] 即将结束，在 10 层 [[spell:187880]] 时施放 [[spell:1218047]]。
6. 在 10 [[spell:187880]] 时施放 [[talent:127856@FAwAo3tAHldBi3tA]]
7. 施放 [[spell:187874]] 以保持增益效果。
8. 冷却好了就施放 [[spell:60103]]。
9. 冷却好了就施放 [[spell:17364]]。
10. 冷却好了就施放 [[spell:187874]]。
11. 施放 [[talent:127856@FAwAo3tAHldBi3tA]]。
12. 冷却好了就施放 [[spell:196840]]。
13. 冷却好了就施放 [[spell:470411]]。





## 深入解析

### 使用 闪电链 对比 闪电箭

在 2 个或更多目标时，使用你的 [[spell:188443]] 会更好。如果存在一个需要优先击杀的目标，则改为对其使用 [[spell:8246]]。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

**← 向下滚动查看更多副本 →**



### 毒牙祭坛

:::talents **增强 萨满祭司** 大秘境 在 毒牙祭坛 中的构建
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧




### 纳洛拉克的洞穴

:::talents **增强 萨满祭司** 大秘境 配装副本：纳洛拉克的洞穴
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧




### 密谋小径

:::talents **增强 萨满祭司** 大秘境 配装副本：密谋小径
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧




### 夺目谷

:::talents **增强 萨满祭司** 大秘境 配装副本：夺目谷
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧

##### 




### 虚空之痕竞技场

:::talents **增强 萨满祭司** 大秘境 在 虚空之痕竞技场 中构建
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::




### 诸王之眠

:::talents **增强 萨满祭司** 大秘境 诸王之眠配装
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧




### 红玉新生法池

:::talents **增强 萨满祭司** 大秘境 配装副本：红玉新生法池
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧




### 塞塔里斯神庙

:::talents **增强 萨满祭司** 大秘境 配装副本：塞塔里斯神庙
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

#### 首领攻略技巧





### 词缀

词缀系统在进入**地心之战第一赛季**时进行了重做，退役了大部分词缀，同时引入了新的有利有弊的词缀，并改变了它们出现的钥石等级。

- +2 词缀 
  
  - 林多尔米的指引
- +5 词缀 —— 每周轮换
  
  - 萨拉塔斯的交易：升腾
  - 萨拉塔斯的交易：虚空之缚
  
  
  
  - 萨拉塔斯的交易：吞噬
  - 萨拉塔斯的交易：脉冲星
- +6 词缀
  
  - 林多尔米的指引被移除。
- +7 词缀 —— 每周相互交替
  
  - 暴君
  - 强韧
- +10 词缀 —— 两种词缀同时存在
  
  - 暴君
  - 强韧
- +12 词缀
  
  - 萨拉塔斯的诡计*—— 取代 +5 词缀*

以下是一些实用的技巧，帮助你作为一名**应对不同大秘境词缀增强 萨满祭司**。

- 萨拉塔斯的交易：升腾
  
  - 你可以对它们使用 [[spell:51490]] 或 [[spell:192058]]。
- 萨拉塔斯的交易：虚空绑定
  
  - 应尽快集火击杀。
- 萨拉塔斯的交易：吞噬
  
  - [[spell:383013]] 非常适合应对这个词缀。

## 属性优先级

了解你的副属性优先级以及在大秘境地下城中作为一名**获得最佳表现所需的次要属性增强 萨满祭司**。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **增强 萨满祭司** 大秘境 属性优先级
```json
{
  "source_code": "HoAJFMAJxACKBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 精通 ＞ 暴击 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **Avoidance -** 降低“范围伤害”技能伤害承受的优秀属性。
- **Leech -** 通过造成伤害提供额外治疗。你的宠物所造成的伤害治疗术，因此**Leech** 对你来说是一个极佳的第三属性，因为你的大部分伤害来自于你自己的法术。
- **Speed -**  较为小众的第三属性，但在特定情况下可能非常有用，过去也已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271483@DiQAAYQAnk7cVrTOC4UA]] | 套装 / 催化器 |
| 项链 | [[item:268265@BERAAYQA8z6wPrTOCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271481@DgQAAYQAXk7kjAOF]] | 套装 / 催化器 |
| 披风 | [[item:239656@FgQAAYQAno6gBwzt1sUA]] | 制造业 |
| 胸部 | [[item:271876@DARAAYQAJk7kjAMWDWB]] | 套装 / 催化器 |
| 护腕 | [[item:244584@DiQAAYQAYA8wPrzt1sUA]] | 制造业 |
| 手套 | [[item:271484@BgQAAYQA5IgTBA]] | 套装 / 催化器 |
| 腰带 | [[item:268254@BiQAAYQA8z6kjAOF]] | 瓦什尼克 |
| 腿部 | [[item:271482@DgQAAYQAFo6kjAOF]] | 套装 / 催化器 |
| 靴子 | [[item:268233@DgQAAYQAxj7kjAOF]] | 斯索拉克 |
| 戒指 1 | [[item:268249@DiQAAYQA1j7wPrTOC4UA]] | 瓦什尼克 |
| 戒指 2 | [[item:252258@DiQAAYQA1j7wPrjgC4UA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:270175@AgwAAkjAYFQBAEgTXIA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@AgQAAIoAYFA]] | 盘绕祭坛 |
| 主手 | [[item:268209@AgQAAIoAYFA]] | 盘绕祭坛 |
| 副手 | [[item:251224@AgQAAIoAOFA]] | 夺目谷 |




### 可刷取的替代装备

下面为你提供一份不错的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁CD系统之外获取。虽然随着你的进度推进它们最终会被替换，但能立即提升角色强度。

| 部位 | 物品 | 获取途径 |
| --- | --- | --- |
| 头部 | [[item:251220@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 颈部 | [[item:251142@AgQAAIoABFA]] | 密谋小径 |
| 肩部 | [[item:239049@AgQAAIoABFA]] | 诸王之眠 |
| 披风 | [[item:251190@AgQAAIoABFA]] | 夺目谷 |
| 胸部 | [[item:251233@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 腕部 | [[item:251200@AgQAAIoABFA]] | 夺目谷 |
| 手部 | [[item:160213@AgQAAIoABFA]] | 诸王之眠 |
| 腰部 | [[item:251228@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 腿部 | [[item:159375@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 脚部 | [[item:159388@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:252258@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:273792@AgQAAIoABFA]] | 毒牙祭坛 |
| 饰品 1 | [[item:250225@AgQAAIoABFA]] | 诸王之眠 |
| 饰品 2 | [[item:273796@AgQAAIoABFA]] | 毒牙祭坛 |
| 主手 | [[item:251224@AgQAAIoAOFA]] | 纳洛拉克的洞穴 |
| 副手 | [[item:251224@AgQAAIoAOFA]] | 纳洛拉克的洞穴 |





### 饰品

你可以在下方找到现有饰品的主动和被动排名。请注意，根据大秘境地下城的不同，某些饰品的表现会优于其他饰品。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgwAAkjAYFQBAEgTXIA]]  <br>[[item:273796@AgQAAIoABFA]] |
| **A级** | [[item:270164@BgQAAYQA5IgTBA]] |
| **B级** | [[item:250225@AgQAAIoABFA]]  <br>[[item:250215@AgQAAIoABFA]] |
| **C级** | [[item:193757@AgQAAIoABFA]] |
| **垃圾级** | [[item:273797@AgQAAIoABFA]] |

### 美化饰品

- 2x [[item:240166]]

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **瓶装合剂**
  
  - [[item:241324]]
  - [[item:241322]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[spell:33757]]
  
  
  
  - [[spell:318038]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240892]]
  
  
  
  - [[item:240983]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAAYQA]]  <br>[[item:244007]] |
| --- | --- |
| 肩部 | [[item:243991]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAAYQA]] |
| 腰带 | [[item:275707@BAAAAYQA]] |
| 腿部 | [[item:244641]] |
| 靴子 | [[item:243953@BAAAAYQA]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 主手 | [[item:244031]] |
| 副手 | [[item:244031]] |

:::

:::column
:::gear **增强 萨满祭司** 在团队副本中的附魔
```json
{
  "source_code": "IwFZHEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NAREIgyP5OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAYQA]]，为你的 **头盔**、**护腕** 和 **腰带** 添加插槽。

## 种族

要想在大秘境中将**增强 萨满祭司**发挥到极致，不同的种族特长可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族也同样可行。

- [[spell:65116]] —— 矮人
  
  - 无论现在还是历史上，都是 大秘境 中最强大的种族技能之一。
  - 驱散魔法和流血减益效果。
- [[spell:33702]] *—— 兽人* 
  
  - 不错的 DPS 种族技能，但与 [[spell:114051]] 的契合度较差。
  
  
  
  - 使你受到的昏迷持续时间缩短 20%，在某些 大秘境 地城中可能有用。
- [[spell:69070]] —— 地精
  
  - 朝角色面朝的方向进行一次小跳。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:26297]] *—— 巨魔* 
  
  - 强大的 DPS 种族技能，与 [[spell:114051]] 完美契合。
  - 使移动限制效果的持续时间缩短 20%。
- [[spell:274738]] *—— 玛格汉兽人* 
  
  - 不错的 DPS 种族技能，但与 [[spell:114051]] 的契合度较差。
  - 使中毒、疾病和诅咒效果的持续时间缩短 10%。
- [[spell:287712]] —— 库尔提拉斯人
  
  - 眩晕你的目标 3 秒并将其击退，在团本中并不算出彩
  - 1% 全能，使这个种族对 DPS 来说还算不错。

### 推荐

**矮人**的种族技能对你的大秘境体验影响如此之大，以至于如果你真心想以**增强 萨满祭司**的身份冲击更高层数的大秘境钥石，你就必须选择这个种族。

## 宏

了解 **增强 萨满祭司的推荐宏**，用于 大秘境 地城，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:108287]]** -- *无需确认，直接对光标位置施放[[spell:108287]]。*

```wow-macro
#showtooltip
/cast [@cursor] 图腾投射
```

**[[spell:192077]] -- *无需确认，直接在鼠标指针位置施放 [[spell:192077]]。***

```wow-macro
#showtooltip
/cast [@cursor] 狂风图腾
```

:::

:::details 鼠标指向宏
**[[spell:188389]]** -- *对鼠标指向的目标施放[[spell:188389]]。*

```wow-macro
#showtooltip 烈焰震击
/cast [@mouseover, exists] 烈焰震击; 烈焰震击
```

:::

:::details 实用 宏
**[[spell:51514]]**  -- *对鼠标指向的目标或当前目标施放[[spell:51514]]。*

```wow-macro
#showtooltip 妖术
/cast [@mouseover, exists] 妖术; 妖术
```

**[[spell:8004]]** *-- 通过鼠标指向或选中目标，快速对队友施放[[spell:8004]]*。

```wow-macro
#showtooltip 治疗之涌
/cast [@mouseover, exists] 治疗之涌; 治疗之涌
```

:::

:::

## 插件

下方是作者为其 **增强 萨满祭司** 所使用用户界面的截图，说明了使用了哪些插件，以及如何在 大秘境 地城中运用这些插件，让你的游戏过程更加轻松。

![Enhancement Shaman Myhtic+](<https://assets-ng.maxroll.gg/wordpress/enha-m-1024x681.webp>)

**增强 萨满祭司** 大秘境 用户界面

:::accordion
:::details 插件
- **EllesmereUI** *—— 完整的用户界面替换* 
  
  - 一款以用户友好为核心设计的界面，附带标准界面所不具备的额外功能。
  - 或者，你也可以使用 Shadowed Unit Frames (SUF) 并搭配任意动作条插件，当然也可以使用原生界面。
- **LittleWigs** *—— 通用首领模块* 
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些迷你插件专为特定的 团队副本 战斗触发警报信息、计时条、音效等而设计。
- **Plater** —— 高级姓名版
  
  - Plater 是一款姓名版插件，拥有海量的设置选项，开箱即用的减益监控、仇恨着色

:::

:::

## 本次版本改动

:::accordion
:::details
*开发者备注：进入乌拉·特克之咒版本之际，我们对 增强 萨满祭司 的玩法感到满意。这些改动的目标是在保持该玩法的同时，提升冷却窗口之外的伤害表现——在冷却间隙期间伤害可能会显得疲软。风怒触发与 漩涡武器 的产生之间的强力联动，使得冷却之间的空档期难以获得喘息。*

- 近战伤害提高15%。
- 闪电箭伤害提高20%。
- 闪电链伤害提高20%。
- 熔岩猛击伤害提高15%。
- 风暴打击伤害提高15%。
- 毁灭之风现在使 风怒武器 的触发几率提高50%（原为100%）。
- 治疗之涌治疗量提高25%。
- 大地之盾治疗量提高25%。
- 治疗之泉图腾治疗量提高25%。
- 修复了 元素节奏 会错误提高 风暴打击 和 风切 伤害的问题。

**英雄天赋**

- 风暴使者
  
  - 狂风怒号 主目标伤害降低 10%。
  
  
  
  - 狂风怒号 次要目标伤害降低 30%。
  
  
  
  - 修复了一个单个 弧形放电 效果可以提高多次 闪电链 施法伤害的问题，例如来自 托里姆的祈咒 和驭雷而行的情况。
- 图腾祭司
  
  - 涌动图腾 震颤伤害降低 15%。
  - 涌动图腾 涌动闪电伤害降低 10%。
  - 修复了一个问题：由 涌动图腾 施放 闪电链 所产生的涌动闪电全部被发送给 闪电链 最后命中的目标，而非 闪电链 的主要目标。

:::

:::

:::accordion
:::details **12.0版本**
- **增强 狂风怒号已更新——每消耗1层漩涡武器有2%的几率使你的下一个闪电箭升级为狂风怒号。**
- **狂风怒号对单体目标的伤害提高15%。**
- **狂风怒号对次要目标的伤害降低25%。**
- **觉醒风暴已更新——风暴打击有较小的几率使你的下一个闪电箭升级为狂风怒号。**
- **滚雷现在会使毁灭之风召唤一个自然野性狼魂，持续12秒。**
- **弧形放电现在仅影响闪电链，且使其伤害提高20%（此前还额外影响闪电箭，伤害提高40%）。**
- **图腾祭司 新天赋：图腾势能 增强：每消耗1层漩涡武器使一个激活的灼热之手的持续时间延长0.2秒。**
- **增强 新天赋：涌动催化——施放涌动图腾后，你的下一个熔岩猛击会以150%的效果再次施放。**
- **新天赋：元素协调——精通提高2%。**
- **生机图腾已更新——熔岩猛击和流电炽焰会使你的灼热图腾射出灼热箭雨。**
- **飞旋元素已更新——大地：现在使你的下一个裂地术伤害提高100%，并召唤一个灼热图腾。**
- **火焰：熔岩猛击使你获得灼热之手，持续8秒（此前为6秒）。火焰新星不再使你获得灼热之手。**
- **涌动图腾震颤伤害提高115%。**
- **涌动图腾冷却时间延长至65秒。**
- **涌动之箭伤害提高75%。**
- **分裂急流现在会以80%的效果施放裂地术（此前为50%）。**
- **大地奔涌现在会以125%的效果引发一次震颤（此前为100%）。**

:::

:::

## 常见问题

:::accordion
:::details 问：什么时候打 [[talent:123379]] / [[talent:123381]]？
A：[[talent:123379]] 目前是更侧重顺劈斩的英雄天赋树，你不再那么专注于[[talent:114291]]，而是专注于[[talent:101809]]和你的[[spell:444995]]。

[[talent:123381]] 目前在单体目标上表现更好，范围伤害也更加稳定，例如大秘境。你需要大量消耗[[talent:101804@FAQAHldB]]来触发更多的[[talent:117489@FAgAo3tAHldB]]。

:::

:::

---

### 致谢

**作者：Stove**

审校：**Ftm**

:::changelog 更新记录
**2026-08-07** 已更新至12.1版本

**2026-04-26** 已更新至12.0.5版本

**2026-02-23** 已更新至12.0.1版本

**2026-01-17** 已更新至12.0版本

**2025-12-03** 已更新至11.2.7版本

**2025-10-08** 已更新至11.2.5版本

**2025-08-06** 已更新至11.2版本

**2025-06-18** 已更新至11.1.7版本

**2025-04-23** 已更新至11.1.5版本

**2025-02-23** 已更新至11.1版本

**2024-12-17** 已更新至11.0.7版本

**2024-10-23** 已更新至11.0.5版本

**2024-08-17** 已更新至11.0.2版本。

**2024-07-29** 本攻略写于11.0.1前置版本。



:::
