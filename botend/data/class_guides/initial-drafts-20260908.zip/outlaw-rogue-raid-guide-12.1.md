欢迎来到**狂徒 潜行者** 团队副本攻略，适用于魔兽世界12.1版本！本攻略涵盖了你了解自己角色所需的一切内容！如果你刚起步，正在从80级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 4/5 · 强

范围伤害 · 3/5 · 一般

功能性 · 3/5 · 一般

生存能力 · 4/5 · 优秀

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **狂徒 潜行者** 团队副本 最佳装备
```json
{
  "source_code": "JMpAwTFBBc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOgCtOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADLgt7AECSAAkBwDYiqBYGAAUQAsIyLLFQAXSCBAgQAAUgZsw9FEIICBAQ94Og-smQOEAYLRIBAKEAbk4UAB81HEAACDAQApxRBAEgSXIQAdFgEBIENYFQAYfBBAAQAA4UABEbCCCQIBIIHYFQANE6AGgQBCSyA5OApqQgIvsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240906]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240906]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240890]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268209]] | [[item:244001]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为一名**狂徒 潜行者**，你可以使用掘墓人，它使你的[[spell:315341]]有45%的几率施加2层其6%的增益效果。

**等级2**使你的5连击点或更多的[[spell:2098]]造成额外物理伤害

而**等级3**使你的[[spell:2098]]有12%的几率给予你1层。达到6层时，你的下一个[[spell:315341]]不消耗能量，并产生6个连击点，同时重置其冷却时间。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-outlaw-mxr.webp>)

掘墓人

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[talent:112552]]
    
    - 重置你的[[spell:13750]]、[[spell:315341]]、[[spell:13877]]、[[spell:271896]]和[[talent:117148@FAgARRgB7PvA]]的冷却时间。
  
  
  
  - [[talent:112557]]
    
    - 有趣的新天赋，通过你的自动攻击提高你[[spell:315341]]的暴击。可叠加。
  - [[talent:112541]] / [[talent:135732]]
    
    - 为你的[[spell:13750]]提供该专精所欠缺的一些爆发能力，或使其持续更久。
  - [[talent:112554]]
    
    - 旧的来自[[spell:193316]]的加成被加入到了树中。
  - [[talent:112529]]
    
    - 有趣的天赋，可以在空档期提供一点帮助，但作用不大。
- **职业树**
  
  - [[talent:112636]]
    
    - 敏捷提高3%。
  
  
  
  - [[talent:112639]]
    
    - 不再是一个主动技能，现在由你的产生连击点技能触发，并使你下一个终结技的暴击提高10%。
  - [[talent:112644]]
    
    - 你的[[spell:5171]]提供额外的攻击速度。
- **已移除**
  
  - [[spell:424044]]
  
  
  
  - 这个改动连同[[spell:423703]]是该树最大的变化。你不再需要围绕潜行窗口期来操作了。
  - [[spell:341542]]
  - [[spell:341546]]
  - [[spell:423703]]
  - [[spell:108216]]
  - [[spell:354897]]
  - [[spell:196937]]
  - [[spell:209423]]
  - [[spell:382746]]
  - [[spell:381985]]
  - [[spell:344363]]
  - [[spell:381988]]
  - [[spell:341540]]
  - [[spell:455143]]
  - [[spell:170882]]
  - [[spell:341534]]
  - [[spell:455131]]。

## 英雄天赋



### [[talent:123371]]

- 你使用的每一个消耗 5 连击点 或更多的终结技都有几率掷一次硬币。
  
  - 落在 [[spell:452923]] 上会使你的伤害提高 10%。后续落在 [[spell:452923]] 上的掷硬币额外提高 2% 伤害。可叠加
  - 落在 [[spell:452538]] 上会造成宇宙伤害。后续的掷硬币使 [[spell:452538]] 的伤害提高 10%。*可叠加*
- [[talent:117724]]
  
  - 每掷 7 次硬币，你会获得一个 4% 的敏捷增益，此外：
    
    - [[spell:452923]] 和 [[spell:452923]] 两个奖励的效果都提高 50%。
    - 掷硬币的结果有 15% 的更高几率与上一次相同。

这些掷硬币在玩法上都没有太大意义，你完全可以不追踪它们，但你可以在命缚者树中通过天赋进行一些极限优化。

- [[talent:117736]]。
  
  - 在你使用[[spell:13750]]之后掷出这两次硬币。
- [[talent:117717]]
  
  - 使你的[[spell:13877]]伤害提高 6%。
- [[talent:136025]]
  
  - 被动暴击。
- [[talent:136026]]
- [[talent:136024]]




### [[talent:123372]]

- 使你的[[spell:8676]]和[[spell:1752]]用[[talent:117737]]打击你的目标。*持续 10 秒，冷却 15 秒。*
  
  - [[talent:117737]]会施加[[spell:441224]]，使目标受到你造成的伤害提高 8%，且无法招架，这相当不错。尤其是在那些你需要长时间站在首领正面输出的 boss 战中。
  - [[talent:117737]]还会为你施加 1 层[[spell:441786]]作为增益。
    
    - 当[[spell:441786]]达到 4 层时，你的下一个[[spell:2098]]将变为[[talent:117712]]。
  - [[talent:117712]]打击目标时，视为你的[[spell:2098]]额外拥有 5 个连击点。

- [[talent:120130]]
  
  - 这是一个相当不错的防御技能，为你的技能组增添了一些坦克度。
- [[talent:117708]]
  
  - 这是天赋树中一个具有协同效果的天赋，除了为你的终结技提供固定的百分比增益外，还能与[[talent:117725]]和[[talent:117712]]配合。
- [[talent:117731]]
  
  - 这是一个非常不错的生活质量天赋。
- [[talent:117725]]
  
  - [[talent:117708]]的覆盖率相当不错，因此为你的顺劈提供一个固定的伤害加成还是挺划算的。
- [[talent:117715]]
  
  - 遗憾的是，在狂徒中触发这个效果的是[[talent:117149]]，但这对本专精来说仍是一个重要的天赋。
- [[talent:136023]]
- [[talent:136022]]
- [[talent:136021@AJABBA]]





## 天赋



### 推荐 - [[talent:123372]] 单体

:::talents [[talent:123372]] **狂徒 潜行者** 团本中的单体目标天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

**需要约 25% 急速。**

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

##### 专精树

- [[spell:381989]]
  
  - 这个天赋可以让你的 [[spell:193316]] 延长 30 秒。
- [[talent:112529]]
  
  - 如果你有停顿时间，这可以提供一些额外的冷却缩减。
- [[talent:112535]]
  
  - 具有协同效应的技能，通过套装效果提升你的伤害，同时为你提供一些额外的能量。
- [[talent:112542]]
  
  - 用于维持 [[spell:193316]] 第二阶段或更高阶段的关键天赋。

##### 英雄天赋

- [[talent:125140]]
  
  - 当你需要跨越很远的距离时，这是最好的机动性天赋之一。
- [[talent:125139]]
  
  - 我们选择这个天赋，因为狂徒不喜欢玩[[spell:170882]]。




### [[talent:123372]] 顺劈

:::talents [[talent:123372]] **狂徒 潜行者** 团本中的顺劈天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

##### 专精树

- **新增** 
  
  - [[talent:112556]]
  - [[talent:112554]]
- **移除**
  
  - [[talent:112537]]
  - [[talent:112551]]

##### 职业树

##### 英雄天赋

- [[talent:125140]]
  
  - 当你需要跨越很远的距离时，这是最好的机动性天赋之一。
- [[talent:125139]]
  
  - 我们选择这个天赋，因为狂徒不喜欢玩[[spell:170882]]。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:2098]] 伤害提高15%。
- **4件套：** [[spell:1752]] 和 [[spell:8676]] 有12%的几率使你的下一个 [[spell:2098]] 免费施放，并按照你消耗了最大连击点数的情况造成伤害。

### 单体目标



#### [[talent:123374]]

##### 起手爆发

:::rotation **狂徒 潜行者** 作为[[talent:123374]]在单体目标上的开场连招
```json
{
  "source_code": "J0FEKIkt1AQABgnAkMvAAEgQlQdBAAgQFYCBAAAABEAnuOAAAAAACJDCBcAYAIE2GAAAAYAdvBiNDBFAC08zEAAAC1-fTEQHJwBNAAgQFYCBAAAAAIQzPTA"
}
```
1. [[spell:13750]]
2. [[spell:193316]]  [[spell:381989]]
3. [[spell:271877]]  [[item:241308]]
4. [[spell:2098]]
5. [[spell:1752]] 打到6星
6. [[spell:315341]]
7. [[spell:1277933]]
8. [[spell:1752]]
9. [[spell:271877]]
10. [[spell:315341]]
:::

##### 优先级列表

1. 如果你处于第1阶段或没有增益时施放 [[spell:193316]]。
2. 在第2阶段或更高阶段时使用 [[spell:381989]]。
3. 在连击点数小于等于2时，冷却完毕就施放 [[spell:13750]]。
4. 在连击点数大于等于6时施放 [[spell:315341]]。
5. 如果 [[spell:315341]]、[[spell:13750]] 处于冷却中，则施放 [[talent:112552]]。
6. 在能量较低时施放 [[spell:271877]]。
7. 在连击点数大于等于5时施放 [[spell:2098]]。
8. 在连击点数小于等于3且带有 [[spell:195627]] 增益时，或 [[spell:195627]] 达到6层时施放 [[spell:185763]]。
   
   - 在连击点数小于等于1且带有 [[spell:195627]] 增益时，或 [[spell:195627]] 达到6层时，且 [[spell:1214934]] 或更高阶段处于激活状态时施放 [[spell:185763]]。
   - 当 [[spell:195627]] 达到3层时，在连击点数大于1时使用 [[spell:185763]]；在 [[spell:1214934]] 或更高阶段处于激活状态且连击点数为4时也使用。
9. 在连击点数小于等于5时施放 [[spell:1752]]。




#### [[talent:123372]]

##### 起手爆发

:::rotation **狂徒 潜行者** 单体起手式，作为 [[talent:123372]]
```json
{
  "source_code": "JcGSIIkt1AAAAcAcyVGc1xGbAI0MU4yDAgoAkMvAAAgQYbAAAAgB09GI2MEUBEAnuOAAAAAAC08zEAAACVAHEIBdFwBYgkkRg42bgIXZzVGdAIk6JDAAAAAAC1-fTA"
}
```
1. [[spell:13750]] 战前
2. [[spell:5171]] 战前
3. [[spell:193316]]
4. [[spell:1752]] 打到6连击点 [[item:241308]]
5. [[spell:315341]]
6. [[spell:1752]] 打到6连击点，如果没有重置
7. [[spell:51690]]
8. [[spell:1277933]]
:::

##### 优先级列表

1. 在第1阶段施放[[spell:193316]]，否则没有增益时也可施放。
2. 在第3阶段或更高阶段使用[[spell:381989]]。
3. 在连击点数大于等于6时施放 [[spell:315341]]。
4. 在[[spell:470347]]期间冷却好了就施放[[talent:117148@FAgARRgB7PvA]]。
5. 在连击点数小于等于2时，冷却完毕就施放 [[spell:13750]]。
6. 如果[[spell:315341]]、[[spell:13750]]和[[talent:117148@FAgARRgB7PvA]]都在冷却中，则施放[[talent:112552]]。
7. 在能量较低时施放 [[spell:271877]]。
8. 在6个或更多连击点数时施放[[spell:2098]]。
9. 在连击点数小于等于3且带有 [[spell:195627]] 增益时，或 [[spell:195627]] 达到6层时施放 [[spell:185763]]。
10. 在连击点数小于等于5时施放 [[spell:1752]]。





### 多目标

在多目标情况下，你的输出循环几乎不变，但有几点需要注意

- [[spell:13877]] 是以你的角色为中心溅射的，所以尽量让自己靠近怪物。
- 在有2个或更多目标时，保持[[spell:13877]]激活是最高优先级。
- 如果你要进行溅射输出，记得在开战前始终[[spell:13877]]。
- 当你点出了[[spell:381878]]天赋时，在有5个或更多目标时，将[[spell:13877]]作为最高优先级的生成技能使用

## 深度解析

#### 命运骨骰 ，它的运作机制，以及如何最优地使用它。

1. 总的来说，他们把这个技能简化了很多。现在，你每次施放 [[spell:193316]] 时，都有几率获得 4 个不同阶段的增益，其中 1 阶以上的每个阶段都会使你获得之前的增益加上当前阶段的增益。例如
   
   - 阶段 1：[[spell:1214933]]
   - 阶段 2：[[spell:1214934]]
   - 阶段 3：[[spell:1214935]]
   - 阶段 4：[[spell:1214937]]
2. 所以如果你拥有 [[spell:1214934]]，你也一定会拥有 [[spell:1214933]]。如果你拥有 [[spell:1214935]]，你就会同时拥有前两个阶段的增益，以此类推。
3. 你需要尽量保持在 2 阶或 3 阶及以上，作为 欺诈者。

#### 对于 时运继延 ，你需要尽快在 2 阶及以上或 3 阶时使用它，作为 欺诈者 。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下提示主要适用于英雄难度首领。史诗难度攻略将在我们的开荒进度结束后发布。

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **狂徒 潜行者** 奈兹卡利天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

#### 首领攻略技巧

- 注意[[spell:1284103]]的计时条，切勿站在首领与其技能目标坦克之间。
- 提前观察小怪的尸体位置，以便更轻松地应对[[spell:1294742]]净化它们的减益效果。




### 陵寝哨兵

:::talents **狂徒 潜行者** 陵寝哨兵 天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### 首领攻略技巧

- 注意观察首领的能量，当其接近 100 时务必分散站位，这样在阶段转换时会更加轻松。
- 总的来说，注意自己的站位，尽量靠近首领输出，这样就不用担心 [[spell:1284494]] 和 [[spell:1284503]] 的层数叠加。
- 留意团队框架，在阶段转换时使用你的 [[spell:195457]] 来清除叠加的增益。




### 迷失的探险者

:::talents **狂徒 潜行者** 迷失的探险者天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### 首领攻略技巧

- 注意[[spell:1296062]]，尽量把它们引到房间外围。
- 不要过度吸收[[spell:1291934]]，因为它会给你施加一个不断叠加的**流血**负面效果。
- 小心[[spell:1292105]]产生的蘑菇，因为它们在使用一次后就会被消耗掉。




### 瓦什尼克

:::talents **狂徒 潜行者** 瓦什尼克天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

#### 首领攻略技巧

- 每当 [[spell:1281907]] 减益效果即将到来时，务必提前分散，并尽可能不要将它对准首领。
- 请记住，击杀 **燃烧毒液** 会给你叠加一层减益效果，所以要避免同时击杀它们。




### 斯索拉克

:::talents **狂徒 潜行者** 斯索拉克 天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### 首领攻略技巧

- 如果你找不到队友来处理[[spell:1285419]]，请记住你也可以用[[spell:195457]]或[[spell:31224]]来化解它。
- 如果你被[[spell:1287072]]命中，请使用防御冷却技能，因为它会在你身上施加一个可叠加的**中毒**负面效果。




### 双牙

:::talents **狂徒 潜行者** 双牙天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

- 在这场战斗中，拥有一个良好的负面效果监控手段极其重要，因为[[spell:1290336]]在达到一定层数后必定会致死，具体层数取决于难度。
- 当你成为[[spell:1291478]]的目标时，尽量不要到处乱跑。如果需要躲避什么，最好沿自己的直线移动。
- 别忘了吸收[[spell:1290516]]也会将你击退，所以在那期间要小心[[spell:1290956]]产生的波纹。
- 每当[[spell:1294293]]发生时，观察场地中央的**维克苏尔** ，你会发现有一些围绕他旋转的小球，它们指示了他施放光束的方向。




### 盘绕祭坛

:::talents **狂徒 潜行者** 蟠曲祭坛天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

- 小心 [[spell:1282403]]，如果有需要，确保协助将它们移动到别处。
- 要格外注意 [[spell:1285643]] 之后刷新的幽灵，因为处理它们将是这个阶段最难的部分。
  
  - 即使你没有被幽灵点名，也请确保不要停留在它们附近，因为它们会被 [[spell:1286620]] 的正面劈砍清理掉，这是消灭它们的唯一办法。
- 每当你被 [[spell:1286895]] 点名时，使用一个防御冷却技能。




### 乌拉特克

:::talents **狂徒 潜行者** 乌拉特克 天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::




### 尼姆瑞莎·唤波者

:::talents **狂徒 潜行者** 尼姆瑞莎·唤波者 天赋
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

- 请注意，[[spell:1258673]]发生后，[[spell:1258150]]会把你从中间击退开，所以要相应地站位，或准备好用[[spell:195457]]来抵消击退效果。
- 每当[[spell:1281393]]被触发时，使用一个防御冷却技能。





## 属性优先级

了解你的次要属性优先级，以及作为**狂徒 潜行者**在团队副本首领战中取得最佳表现所需的第三属性。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **狂徒 潜行者** 团队副本中的属性优先级
```json
{
  "source_code": "JoAJFMAJggSMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 暴击 ＞ 全能 ＞ 精通**
:::

> 至少需要25%急速。达到之后，暴击的收益会更高。
> 
> 
> 
> **在大多数情况下，物品等级更高的装备更好。** 要想准确判断应该装备哪件物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的“**属性优先级**”只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可减少“**范围效果**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外的治疗。
- **加速** - 小众副属性，但可能非常有用，过去已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | 乌拉特克 |
| 颈部 | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | 乌拉特克 |
| 肩部 | [[item:271508@DwQAAQQAXk74kgC4UA]] | 迷失的探险者 / 催化 |
| 披风 | [[item:268248@BAQAAQQAOFA]] | 卷魂者奈兹卡利 |
| 胸部 | [[item:271513@DgQAAMQAJk7IoAOF]] | 万毒邪祟者瓦什尼克 / 催化 |
| 腕部 | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | 制造业 |
| 手部 | [[item:271511@BgQAAMQACKgTBA]] | 陵寝哨兵 / 催化 |
| 腰部 | [[item:268256@BiQAAQQAS06IoAYF]] | 盘卷祭坛 |
| 腿部 | 将 [[item:268225@AgQAAIoAYFA]] 转换为 [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | 盘卷祭坛 催化剂 |
| 脚部 | [[item:268261@DAQAAMQAPk74UA]] | 双子毒牙 |
| 戒指 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | 斯索拉克 |
| 戒指 2 | [[item:268252@DiQAAQQA1j7oPrjgC4UA]] | 毒牙祭坛 |
| 饰品 1 | [[item:270175@BgwAAQQACKAWBUAABo0FCA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgQAAQQACKAWBA]] | 毒牙祭坛 |
| 武器 | [[item:268209@DgQAAQQADk7IoAYF]] | 毒牙祭坛 |
| 武器 | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | 制造业 |

狂徒 潜行者 最佳配装 团本列表




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | 毒牙祭坛 |
| 颈部 | [[item:273781@BiQAAMQAH16IoABF]] | 毒牙祭坛 |
| 肩部 | [[item:251223@DgQAAMQAXk7IoABF]] | 虚空之痕竞技场 |
| 披风 | [[item:193763@BgQAAMQACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251226@DgQAAQQAJk7IoABF]] | 虚空之痕竞技场 |
| 护腕 | [[item:251135@BiQAAMQAU06IoABF]] | 密谋小径 |
| 手套 | [[item:251124@BgQAAMQACKQQBA]] | 密谋小径 |
| 腰带 | [[item:251189@BiQAAQQAK06IoABF]] | 夺目谷 |
| 腿部 | [[item:159313@DgQAAQQAhu7IoABF]] | 诸王之眠 |
| 脚部 | [[item:251153@DgQAAQQAPk7IoABF]] | 纳洛拉克的洞穴 |
| 戒指 1 | [[item:251148@DiQAAQQA1j7oPrjgCEUA]] | 纳洛拉克巢穴 |
| 戒指 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | 毒牙祭坛 |
| 饰品 1 | [[item:159617@BgQAAQQACKQQBA]] | 诸王之眠 |
| 饰品 2 | [[item:250259@BgQAAMQACKQQBA]] | 夺目谷 |
| 武器 | [[item:193767@DgQAAQQADk7IoABF]] | 红玉新生法池 |
| 武器 | [[item:275070@DgQAAMQADk7IoABF]] | 毒牙祭坛 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgwAAQQACKAWBUAABo0FCA]][[item:270173@BgQAAQQACKAWBA]] |
| **A级** | [[item:270164@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |
| **B级** | [[item:159617@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:270166@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C级** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273796@AgQAAIoAOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **垃圾级** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |

### 美化饰品

- [[item:240166]]
- [[item:273059]]

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备在最高物品等级时为334，因此除非你该部位没有其他高物品等级装备可用，否则除了你的2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药剂**
  
  - [[item:241326]] *—— 最高DPS*。
  
  
  
  - [[item:241320]] *—— DPS略低，但生存能力更强。*
- **食物**
  
  - [[item:266985]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240898]]
  
  
  
  - [[item:240914]] x1
  - [[item:240906]] x1
  - [[item:240890]] x1
  - [[item:240966]] *—— 唯一，每种颜色的宝石各用一颗来强化你的[[item:240966]]。*
- *建议运行模拟以获得最优属性。*

### 附魔

:::columns
:::column
| 头部 | [[item:275707@DAAAAMQAnk7A]] - [[item:243949]] |
| --- | --- |
| 肩部 | [[item:243991]] |
| 披风 |  |
| 胸部 | [[item:243977@BAAAAMQA]] |
| 护腕 | [[item:275707@DAAAAMQAnk7A]] |
| 腰带 | [[item:275707@DAAAAMQAnk7A]] |
| 腿部 | [[item:244641@BAAAAMQA]] |
| 靴子 | [[item:244009@BAAAAMQA]] |
| 戒指 1 | [[item:243957@BAAAAMQA]] |
| 戒指 2 | [[item:243957@BAAAAMQA]] |
| 武器 | [[item:244001@BAAAAQQA]] |
| 武器 | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **狂徒 潜行者** 团队副本中的附魔
```json
{
  "source_code": "JwFZEEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCoESuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244001]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> 你可以从宏伟宝库商贩处购买[[item:275707@DAAAAMQAnk7A]]，为你的**头盔**、**护腕** & **腰带**添加插槽。

## 种族

为了将 **狂徒 潜行者** 在团队副本中优化到极致，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你风格的种族同样可行。

- [[spell:65116]] —— 矮人
  
  - 可以驱散魔法和流血减益效果。过去在一些有流血机制的首领战中曾经很有用。
- [[spell:154743]] —— 牛头人
  
  - 在输出方面与矮人类似，但你无法拥有 [[spell:65116]]。
- [[spell:69070]] —— 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:26297]] *—— 巨魔* 
  
  - 相当弱的输出种族技能，冷却时间3分钟。
  - 使移动限制效果的持续时间缩短20%。在最近的开荒团队副本历史中只用上过一次，但仍然值得一提。
- [[spell:33702]] *—— 兽人* 
  
  - 使你受到的眩晕持续时间缩短20%，在某些情况下会很有用。
- [[spell:256948]] —— 虚空精灵
  
  - 放出一个朝你面向方向移动的暗影，再次激活即可传送到该暗影处。
  - 最大距离为100码。
- [[spell:312923]] —— 机械侏儒
  
  - 相当强力的被动技能，随等级提升而增强，这也是它现在如此强大的原因

:::columns
:::column


:::

:::

### 推荐

总的来说，可以肯定的是：如果你追求输出最大化，就应该选择输出最高的种族天赋。不过，如果是开荒团本，情况就有所不同了。有些种族天赋能极大加快特定首领的进度。值得注意的是，矮人凭借其 [[spell:65116]]，在最近的世界首杀竞速中，由于能在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键节点轻松自我驱散，提供了巨大帮助。

## 宏

了解 **狂徒 潜行者** 在 团队副本 战斗中推荐的宏，并观看一段关于为你的角色制作简单宏的快速视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
*当你的鼠标指向某个怪物时设置一个标记。这非常适合让你的队友知道你打算把* **[[spell:1766]]** *用在哪个目标上。*

```wow-macro
/focus [@mouseover][]
/run SetRaidTarget("mouseover",6)
```

*鼠标指向* **[[spell:1766]]** *，如果你更喜欢这种方式而不是焦点目标。*

```wow-macro
#showtooltip 脚踢
/cast [target=mouseover] 脚踢
```

**[[spell:195457]]** *在鼠标指针位置*

```wow-macro
#showtooltip 抓钩
/cast [@cursor] 抓钩
```

:::

:::details 焦点目标宏
**[[spell:1766]]** *你的焦点目标*

```wow-macro
#Showtooltip 脚踢
/cast [target=focus] 脚踢
```

*施放* **[[talent:112631]]** *在你的焦点目标身上*

```wow-macro
#showtooltip 凿击
/cast [target=focus] 凿击
```

*焦点* **[[spell:408]]** *以提供额外控制*

```wow-macro
#showtooltip 肾击
/cast [@focus] 肾击
```

*焦点* **偷袭**

```wow-macro
#showtooltip 偷袭
/cast [@focus] 偷袭
```

:::

:::details 实用 宏
*在这个宏里，你可以将名字替换为你队伍中的坦克，从而让使用* **[[talent:112574]] *变得更加轻松。***

```wow-macro
#showtooltip 嫁祸诀窍
/cast [@Meeresdh] 嫁祸诀窍
/cast [@Meeresmana] 嫁祸诀窍
/cast [@Méèrès] 嫁祸诀窍
```

:::

:::

## 插件

下方是作者为其 **狂徒 潜行者** 的用户界面截图，其中说明了使用了哪些插件，以及它们在团队副本中如何帮助你更轻松地游戏。

![](<https://i.gyazo.com/d97025dda622df7bbb24a134b36349b9.jpg>)

**狂徒 潜行者** 界面

:::accordion
:::details 插件
- **Ellesmere UI** *—— 完整的用户界面替换* 
  
  - 一款以用户友好为核心设计的用户界面，附带标准界面中没有的额外功能。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**潜行者**

- 职业
  
  - 蓟茶现在是一个可选天赋——玩家可以在现有版本（既可在能量低时自动施放，也可主动使用）和一个必须主动施放的新版本之间进行选择。
  - 萎缩毒药现在使造成的伤害降低 4%（原为 3%）。
  - 萎缩毒药的持续时间延长至 60 秒（原为 10 秒）。PvP 战斗中持续时间保持不变。

- 狂徒
  
  - 开发者说明：对 狂徒 在 乌拉特克 之咒中的改动旨在提高天赋构建的多样性和灵活性。我们增强了一些表现不佳的天赋，并回调了一些让人感觉“必点”的天赋。影舞步 的伤害得到了显著提升，因为此前它所造成的伤害并不比在其引导期间使用其他技能强多少。该天赋现在对你总体伤害的提升应与其他同类天赋相当。
  - 影舞步 已更新——持续时间不再因消耗超过上限的连击点数而延长。每消耗一个超出上限的连击点数，伤害提高15%。
  - 冲动 现在使 影舞步 的执行速度加快20%，与其提升你其他攻击速度的比率相同。
  - 影舞步 会优先选择不受伤害免疫或受到物理伤害低于5%的目标。
  - 影舞步 伤害提高60%。不影响PvP战斗。
  - 影舞步 射击如果有效，会有更高的几率以你选中的目标为目标。
    
    - *开发者说明：影舞步 的大部分价值在于它产生的连击点数，因此当玩家可以在 影舞步 上消耗超过上限的连击点数时（例如通过 超荷充能），这些额外点数的价值就被稀释了。影舞步 的持续时间现在上限为产生最大连击点数所需的时间，而任何额外消耗的连击点数都会按相应比例提高该技能的伤害。*
  - 强化 正中眉心 已更新——使 正中眉心 的爆击造成2.5倍正常伤害（原为3倍）。
  - 迅捷行动已更新——现在使 正中眉心 的冷却时间缩短8秒（原为5秒），并使每层 正中眉心 的伤害加成提高1%。
  - 所有伤害提高9%。不影响PvP战斗。
  - 重拳出击使产生连击点数的攻击伤害提高15%/30%（原为10%/20%）。
  - 锁定 每层的数值降低至2%（原为3%）。
    
    - *开发者说明：我们不希望玩家为了最大化该天赋的价值而觉得必须使用副手匕首。锁定 现在如果由1.8攻速的武器触发，有30%的几率不触发，使其在使用匕首与其他单手武器攻击时的触发几率相同。*
  - 肆无忌惮现在还会使 伏击 的伤害提高80%。
  - 暗藏的 可乘之机 使 伏击 赋予 可乘之机 的几率提高至 影袭 赋予 可乘之机 几率的100%（原为80%）。
  - 暗藏的 可乘之机 还会使 伏击 的能量消耗降低5点。
    
    - *开发者说明：肆无忌惮和暗藏的 可乘之机 不如其他天赋选项强大，因此我们为其增加了一些效果，使其更具竞争力。*
  - 迅捷了结使 斩击 的伤害提高15%/30%（原为10%/20%）。
  - 在天赋树中新增了连接节点，分别位于无情和寻隙之间，以及闪钢选择节点与 大乱斗 之间。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我的伤害这么低？
**答：** 作为一名 **狂徒 潜行者**，最常见的错误之一就是没有尽快地按出公共冷却技能。狂徒 是一个非常高APM（每分钟操作数）的专精，而且由于 [[spell:79096]] 和 [[spell:1214937]] 这类技能的存在，保持输出时间并持续使用技能非常重要。通过大量游玩 大秘境 或打木桩来培养该专精的肌肉记忆，可以解决这个问题。

:::

:::

---

### 致谢

作者：**Perfecto**

审校：**Verb**

---

:::changelog 更新记录
**2026-08-08** 已更新至12.1版本。

**2026-06-17** 已更新至12.0.7版本。

**2026-04-21** 已更新至12.0.5版本。

**2026-02-10** 已更新至12.0.1版本。

**2025-12-03** 已更新至12.0版本

**2025-10-07** 已更新至11.2.5版本。

**2025-07-29** 已更新至11.2版本。

**2025-06-19** 已更新至11.1.7版本。

**2025-04-21** 已更新至11.1.5版本。

**2025-02-14** 已更新至11.1版本。

**2024-12-16** 已更新至11.0.7版本。

**2024-10-24** 已更新至11.0.5版本。

**2024-08-17** 已更新至11.0.2版本。

**2024-07-24** 攻略撰写于11.0.1前夕版本。



:::
