Welcome to the  **Feral Druid** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 5/5 · Strong

Survivability · 5/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Feral Druid** Bis List Raid
```json
{
  "source_code": "JgoAwz1ZAc__AEwAmQggQEAAnk7AH16A5IwF2gVABk-FEAQEBAgEtOg-sOAj1kjAYFQAmSCBCgQAAcRuDkjAOFQArSCBCgQAAkQuDkjAOFQAgfBBAiQAAoQrDkjAYFQAnSSBeQQo7mwDAl1uDYAIBAAGAPwJqOQ84OAAFEAI3WzSBEAY7OAhVsBBC0qLbAAGpSCBAgQAAUAYgk9FEIICBAQ94GAJFIBCil9AZIBACGwkE01HFADACGQgA8VAMAwAFwAIFAQAxchAB09FF4RBMTztXQgAIEAAwqCBWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240967]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240914]] · [[item:240890]] |
| 肩部 | [[item:271526]] | [[item:243991]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240906]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245784]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:273072]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Feral Druid**, you gain access to **Unseen Predator**. This ability provides a chance to trigger an **Unseen Attack** [[spell:1263903]] or [[spell:1263840]].

**Rank 2** gives you 15% damage buff for 5sec whenever  you trigger an **Unseen Attack**.  
**Rank 3:** your [[spell:5217]] now forces your **next 2 generators** to proc an **Unseen Attack**.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-feral-mxr.webp>)

Unseen Predator

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103309@AJwCBA]].
    
    - Now it gives you something depending on the form you are on.
    - **In Human Form (Non-Shapeshifted):** Grants an **Empowered [[talent:103283]]**.
    - **In Bear Form:** Grants you 20% more health for 20 seconds.
  
  
  
  - [[talent:123794]]
    
    - Amplifies the effect of Mark of the Wild.
- **Class Tree**
  
  - [[talent:103149]]
    
    - Nice talent to do even more Prio Damage on the main target.
  - [[talent:103156]]
    
    - Has big potential.
  - [[talent:134211]] & [[talent:103174]]
    
    - Empower even more [[talent:103175]] to be stronger in ST or become a powerful AoE ability.
  - [[talent:134212]]
    
    - Designed for ST, sadly a bit undertuned right now as you will never pick it in the optimal setup.
  - [[talent:114771]]
    
    - Decent passive that increase either [[spell:1822]] or [[spell:5221]]/[[spell:106785]].
  - [[talent:103164]]
    
    - Have a chance to gain 5 combo points.
  - [[talent:103157]]
    
    - More bleeds damage 10%.
- **Removed**
  
  - [[spell:202028]].
    
    - From doing a lot of damage by itself to just being a [[spell:319439]] trigger, we will miss it for sure.
  - [[spell:319439]].
    
    - We used to have it for years, I think it's nice to finally have it gone. It was annoying in AoE, felt fine on ST. Overall a good change. Does it make the gameplay easier? I guess a tiny bit for newer player to pick up the spec.
  - [[spell:106830]].
    
    - Was mainly a [[spell:319439]] trigger spell.
  - [[spell:108238]].
    
    - Now we have a passive instead ([[talent:128581]]), less control but fewer keybinds.
  - [[spell:391891]].

## Hero Talents

- Both [[talent:123296]] and [[talent:123297]] are very close on single-target to each other but [[talent:123296]] is winning.
- On the other hand [[talent:123297]] is a bit ahead for any AoE encounter.
- [[talent:123296]] damage breakdown is more towards bleeds whereas [[talent:123297]] is more focus on [[spell:22568]] damage overall.

### [[talent:123296]]

- Your [[spell:1079]] and [[spell:1822]] have a chance to grow [[spell:439528]] on any affected target.

- Every vine does a DoT effect and debuffs the target with [[talent:117227]].

- Whenever you [[spell:22568]] a target with a vine, you trigger the effect of [[talent:117232]], which also triggers the effect when the vine expires.

- [[talent:117233]] is a good damage boost to all your abilities and is stronger the more mobs you are fighting.

- A nice little passive to [[talent:123296]] is [[talent:117230]], which give you more vine overall.

With Patch 12.0, Blizzard removed our The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:135973@AJwCBA]]
- [[talent:117232@AJwCBA]]
- [[talent:135975@AJwCBA]]

### [[talent:123297]]

- Your auto-attacks have a chance to make your next [[spell:22568]] become [[talent:117206]].
  
  - An empowered [[spell:22568]] that deals damage in an arc in front of you, so make sure to always face as many enemies as possible.

- [[talent:117220]] is applied to every target hit by [[talent:117206]]. 
  
  - [[talent:117220]] can be extended with [[talent:117216]].

- [[talent:117219]] is a nice auto-attack speed boost which procs [[talent:103187]] and [[talent:117206]] more often.

- [[talent:103298]] can be cast in Cat Form with [[talent:117210]].
  
  - You also gain 10% maximum health during the duration with [[talent:117218]].

With Patch 12.0, Blizzard removed our The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:135980@AJwCBA]]
- [[talent:135979@AJwCBA]]
- [[talent:117219@AJwCBA]]

## Talents

### [[talent:123296]] Single-Target

:::talents [[talent:123296]] **Feral Druid** raid single-target
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### When to use this Spec

Use this spec in a single-target encounter.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[spell:5217]]
  
  - Increase the damage of all your attacks for their **full** duration.
- [[talent:103175]]
  
  - You want to maximize the amount of [[talent:103175]] by casting [[talent:103175]] on as many targets as possible. This can even be on friendly targets if you already have [[talent:103175]] on every enemy.
- [[spell:319439]]
  
  - You need to use 3 different generators within 4 seconds to proc it.
  - Your next 3 finishing moves deal 25% more damage.
  - [[spell:391972]] is an alternative if you don't like playing [[spell:319439]].
- [[spell:16864]]
  
  - Your auto attacks have a chance to cause your next [[spell:5221]], [[spell:106830]] and/or [[spell:213764]] / [[spell:202028]] to cost 0 energy.
  - To maximize this effect you want to avoid using it on [[spell:202028]] as it costs way less energy than the other abilities.
  - You want [[spell:236068]] up as well to boost its efficacy further.
- [[talent:103177]]
  
  - Use this to cast a bunch of powerful spells on your target.

#### Hero Talents

- [[talent:117234]]
  
  - Your default pick since [[talent:117233]] is more focused on multi-target.
- [[talent:117229]]
  
  - [[talent:117230]] is more of a multi-target talent but does work on single-target.

### [[talent:123297]] Single-Target

:::talents [[talent:123297]] **Feral Druid** raid single target
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCGGGzMqZMLmZmZMmZGAAAAAAADAAAgmZZWmZmBEYBmZGgFGMAAAmZDDA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCGGGzMqZMLmZmZMmZGAAAAAAADAAAgmZZWmZmBEYBmZGgFGMAAAmZDDA"
}
```
:::

#### When to use this Spec

Use this spec in a single-target encounter if you want your damage breakdown more focused on [[spell:22568]].

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the [[talent:123296]] **Single-Target** build.

##### Spec Tree

- **Added**
  
  - [[talent:103173]].

- **Removed**
  
  - [[talent:103170]].

##### Hero Talents

**Changed** [[talent:123296]] to [[talent:123297]] for more info visit the **Hero Talent** section above.

- [[talent:117219]]
  
  - This is the best single-target option but requires perfect melee uptime which can be rough in real practice.
- [[talent:117214]] 
  
  - Outperforms [[talent:117213]].
- [[talent:117210]]
  
  - [[talent:117209]] is just worse in every aspect.

### [[talent:123297]] Cleave

:::talents [[talent:123297]] **Feral Druid** raid adds spawn
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAzMz2DYmZmxY2M2GbzYm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZGQgFYmZAWYwAAAYmNM",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAzMz2DYmZmxY2M2GbzYm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZGQgFYmZAWYwAAAYmNM"
}
```
:::

#### When to use this Spec

Use this spec in a single-target encounter when you have adds spawning and you want to cleave them without losing much single-target.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the [[talent:123297]] **Single-Target** build.

##### Spec Tree

- **Added**
  
  - [[talent:103184]]
  - [[talent:103181]]
  - [[talent:134211]]

- **Removed**
  
  - [[talent:103185]]
  - [[talent:103174]]
  - [[talent:114771]]

##### Hero Talents

**Changed** [[talent:123296]] to [[talent:123297]] for more info visit the **Hero Talent** section above.

- [[talent:117219]]
  
  - This is the best single-target option but requires perfect melee uptime which can be rough in real practice.
- [[talent:117214]] 
  
  - Outperforms [[talent:117213]].
- [[talent:117210]]
  
  - [[talent:117209]] is just worse in every aspect.

### [[talent:123296]] Cleave

:::talents [[talent:123296]] **Feral Druid** raid adds spawn
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### When to use this Spec

Use this spec in a single-target encounter when you have adds spawning and you want to cleave them without losing much single-target.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the [[talent:123296]] **Single-Target** build.

##### Spec Tree

- **Added**
  
  - [[talent:103184]]
  - [[talent:103181]]
  - [[talent:134211]]

- **Removed**
  
  - [[talent:103185]]
  - [[talent:103174]]
  - [[talent:114771]]

#### Hero Talents

- [[talent:117234]]
  
  - Your default pick since [[talent:117233]] is more focused on multi-target.
- [[talent:117229]]
  
  - [[talent:117230]] is more of a multi-target talent but does work on single-target.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** When [[talent:103162]] ends, you deal 10% increased damage for 1 sec for each combo point spent during it..
- **4-Set:** ‍[[talent:103162]] last 10 sec longer.

### Single-Target

#### [[talent:123296]] & [[talent:123297]]

##### Opener

- Your goal as a **Feral Druid** is to cast as many [[spell:22568]] as possible without wasting uptime on your bleeds like [[spell:1079]] and [[spell:1822]]. Below, you can see an example of how your opener looks using the recommended **Raid Single target** spec.

:::rotation **Feral Druid** Single target opener in Mythic+
```json
{
  "source_code": "I4EeKIwXUAAAAIgHHAAACIQYUAgAHHaACVZMEAAAAAgQ3UwBoAgA0CPBAAgQogFABEABCVWAyQAAAoEEAA"
}
```
1. [[spell:5215]]
2. [[spell:1822]]  [[spell:5217]] · [[spell:106951]]
3. [[spell:274837]]
4. [[spell:1079]]
5. [[spell:323764]]
6. [[spell:22568]]
7. [[spell:5221]]
8. [[spell:22568]]
9. [[spell:5221]]
10. [[spell:22568]]
:::

###### Priority List

This is a general priority you aim to maintain throughout the fight as **Feral Druid**.

1. Cast [[spell:106951]].
2. Cast [[spell:5217]].
3. Cast [[spell:323764]].
4. Cast [[talent:103175]].
5. Keep [[spell:1079]] up.
6. Cast [[spell:22568]].
7. Keep [[spell:1822]] up.
8. Keep [[spell:155625]] up.
9. Cast [[spell:5221]].

### AoE

#### [[talent:123296]] & [[talent:123297]]

##### Opener

- Below, you can see an example of how your opener looks like as **Feral Druid** using the recommended **Raid cleave** talent spec.

:::rotation **Feral Druid** Multi target opener in Mythic+
```json
{
  "source_code": "IkFOLIwXUAAAAIgHHAAACIUYBwAKCdLPFAAAC9p-SAQAagTxaRAAAIAtwTAAAIEKYBQABUBCQESoBAAAdgBKhEaAAAAAAIQxaRA"
}
```
1. [[spell:5215]]
2. [[spell:1822]]  [[spell:5217]] · [[spell:343223]]
3. [[spell:1243807]]
4. [[spell:285381]]
5. [[spell:323764]]
6. [[spell:22568]]
7. [[spell:22568]]
8. [[spell:106785]]
9. [[spell:22568]]
10. [[spell:106785]]
11. [[spell:285381]]
:::

###### Priority List

1. Cast [[spell:106951]].
2. Cast [[spell:5217]].
3. Cast [[spell:323764]].
4. Cast [[talent:134211]]
5. Keep [[spell:1079]] up with [[spell:285381]].
6. Cast [[spell:22568]].
7. Keep [[spell:1822]] up on most targets.
8. Keep [[spell:155625]] up on most targets.
9. Cast [[talent:103301@FAQAzchA]].

## Deep dive

### Snapshot

***What is snapshotting?***

The term "snapshotting" refers to a game mechanic where certain abilities capture (or "snapshot") the buffs at the moment they are cast and retain those buffs for their duration.

This is particularly relevant for Damage over Time (DoT) abilities (Bleed for **Feral Druid**), as they continue to deal damage based on the buffs present when they were applied, even if those stats or buffs change or expire.

- **[[spell:5217]]**: Applying [[spell:1079]] or [[spell:1822]] while [[spell:5217]] is active ensures that the bleed benefits from the increased damage throughout the **entire** duration.

- **[[spell:231052]]**: Applying [[spell:1822]] from stealth increases the damage for the **entire** duration.

#### Circle of Life and Death

The **[[spell:400320]]** talent modifies the duration of your DoTs, reducing their overall duration by 20% but increasing their tick rate. Here’s how it affects your DoTs:

- **[[spell:1822]]**: Reduced to **12 seconds**.
- **[[spell:1079]]**: Reduced to 1**9 seconds**.
- **[[spell:155625]]**: Reduced to **14.4 seconds**.

With these new durations, the Pandemic thresholds adjust accordingly:

- **[[spell:1822]]:** You can refresh [[spell:1822]] when there are up to **3.6 seconds** (30% of 12 seconds) remaining, adding this time to the new [[spell:1822]].
- **[[spell:1079]]**: You can refresh [[spell:1079]] when there are up to **5.7 seconds** (30% of 19 seconds) remaining, adding this time to the new [[spell:1079]].
- **[[spell:155625]]:** You can refresh [[spell:155625]] when there are up to **4.3 seconds** (30% of 14.4 seconds) remaining, adding this time to the new [[spell:155625]].

#### Practical Application with Circle of Life and Death

1. **[[spell:1822]]**: If it has 3 seconds left, refreshing it adds the remaining **3 seconds** to the new **12 seconds** duration, making the new duration **15 seconds**.
2. **[[spell:1079]]**: If it has 5 seconds left, refreshing it adds the remaining **5 seconds** to the new **19 seconds** duration, making the new duration **24 seconds**.
3. **[[spell:155625]]**: If it has 4 seconds left, refreshing it adds the remaining **4 seconds** to the new **14.4 seconds duration**, making the new duration **18.4 seconds**.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

### Nek'Zali

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAjZYmZmZMmtlx2YbmZm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAjZYmZmZMmtlx2YbmZm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### Boss Tips

- Can make use of [[talent:103156]] by killing **Restless Amani** adds.

### Entombed Sentinels

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### Boss Tips

- Keep an eye out for when the **Entombed Sentinels** reach 100 energy to not use your offensive cooldown right before.

### Lost Explorers

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### Boss Tips

- Make sure to bait the shell away from ranged, it goes only on melees.

### Vashnik

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### Boss Tips

- Don't try to dps adds too much, not your strength.

### Sszorak

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### Boss Tips

- During Winds you can [[talent:103276]] if you are out of position.

### Twin Fangs

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### Boss Tips

- Go against the balls that you see on the boss in the middle to dodge the beam coming from him.

### Coiled Altar

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### Boss Tips

- Use one [[talent:103162]] only each phase.

### Ula'tek

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### Boss Tips

- Ula'tek was not seen on the 12.1 PTR servers, and will first be seen on patch launch and season start. The talents provided above should be a good starting point.
- Ula'tek and updates to all bosses will follow soon after the conclusion of the upcoming Race to World First.

### Nymrissa Wavecaller

:::talents **Feral Druid**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### Boss Tips

- Dodge waves by finding the safe spot!
- Help with [[talent:103287]] to avoid murlocs going in the middle.
- Don't go swimming.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance when you raid as a **Feral Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Feral Druid** Raid Stat Priorities
```json
{
  "source_code": "HoAJFMAIxQCKEEQABA"
}
```
**敏捷 ≫ 暴击 ＞ 精通 ＞ 急速 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAcGAnk7cUrTOCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAcGAS06oPrDj1kjAYFA]] | Ula'tek |
| Shoulder | [[item:271526@DgQAAcGAXk7kjAOF]] | Catalyst |
| Cloak | [[item:268253@BgQAAcGA5IgTBA]] | The Coiled Altar |
| Chest | [[item:271531@DgQAAcGAJk7kjAOF]] | Catalyst |
| Wrist | [[item:244576@FCSAAcGAYA8ciqjAtOAAAAAAAA3WzSB]] | Crafting |
| Gloves | [[item:271529@BgQAAcGA5IgTBA]] | Catalyst |
| Belt | [[item:268256@BiQAAcGAK06kjAYF]] | The Coiled Altar |
| Legs | [[item:249312@DgQAAcGAhu7IoAhE]] | The Coiled Altar / Catalyst |
| Boots | [[item:244569@HASAAcGAYA8ciqT84OAAAAAAAA3WzSB]] | Crafted |
| Ring 1 | [[item:268249@DiQAAcGA1j7IQrTOC4UA]] | Vashnik |
| Ring 2 | [[item:252258@DiQAAcGA1j7IQrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270173@BgQAAcGACKAWBA]] | The Coiled Altar |
| Trinket 2 | [[item:270175@BgwAAcGACKAWBUAABEzFCA]] | Ula'tek |
| Weapon | [[item:268215@DgQAAcGAwqCZhNYF]] | Ula'tek |

Feral Druid BiS list in Raids

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271528@AgQAAkjABFA]] | Catalyst |
| Neck | [[item:251142@BiQAAcGAC06IoABF]] | Murder Row |
| Shoulder | [[item:271526@DgQAAcGAXk7kjABF]] | Catalyst |
| Cloak | [[item:251132@DgQAAcGANk7IoABF]] | Murder Row |
| Chest | [[item:271531@DgQAAcGAJk7kjABF]] | Catalyst |
| Wrist | [[item:244576@FCSAAcGAYA8ciqjAtOAAAAAAAA3WjPB]] | Crafted |
| Gloves | [[item:271529@BgQAAcGA5IQQBA]] | Catalyst |
| Belt | [[item:159317@BiQAAcGAC06IoABF]] | Temple of Sethraliss |
| Legs | [[item:271527@DgQAAcGAhu7kjABF]] | Catalyst |
| Boots | [[item:244569@HASAAcGAYA8ciqT84OAAAAAAAA3WjPB]] | Crafted |
| Ring 1 | [[item:252258@DiQAAcGA1j7IQrjgCEUA]] | Voidscar Arena |
| Ring 2 | [[item:273792@CiQAAUPujAtOCKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:273796@BgQAAcGACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAAcGACKQQBA]] | Murder Row |
| Weapon | [[item:273783@DgQAAcGAwqCJoABF]] | Altar of Fangs |

Feral Druid alternative

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAAcGACKgTBA]]  <br>[[item:270173@BgQAAcGACKgTBA]]  <br>[[item:270164@BgQAAcGACKgTBA]] |
| **A-Tier** | [[item:273796@BgQAAcGACKgTBA]]  <br>[[item:270165@BgQAAcGACKgTBA]]  <br>[[item:250228@BgQAAcGACKgTBA]] |
| **B-Tier** | [[item:250215@BgQAAcGACKgTBA]]  <br>[[item:159617@BgQAAcGACKgTBA]]  <br>[[item:250225@BgQAAcGACKgTBA]] |
| **C-Tier** | [[item:270166@BgQAAcGACKgTBA]]  <br>[[item:250214@BgQAAcGACKgTBA]] |
| **Junkyard** | [[item:250259@BgQAAcGACKgTBA]]  <br>[[item:273797@BgQAAcGACKgTBA]]  <br>[[item:193757@BgQAAcGACKgTBA]] |

### Embellishments

- [[item:240167]] x2

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255846]] *-- Feast*
  
  
  
  - [[item:242747]] -- personal food which lacks the stamina bonus that feasts provide
- Combat Potion
  
  - [[item:241308]] -- *Grants agility*
  
  
  
  - [[item:241289]] -- Grants secondary stats, currently the recommended choice
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].*
    
    - [[item:240908]] *-- Main gem.*
    - [[item:240900]]
    - [[item:240918]]
    - [[item:240892]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAcGANk7A]]  <br>[[item:243949]] |
| --- | --- |
| Shoulder | [[item:244019@BAAAAMQA]] |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@BAAAAcG]] |
| Waist | [[item:275707@BAAAAcG]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:244015@BAAAAMQA]] |
| Ring 2 | [[item:244015@BAAAAMQA]] |
| Weapon | [[item:273072@BAAAAcG]] |

Feral Druid Enchantments in Raids

:::

:::column
:::gear **Feral Druid** Enchantments in Raids
```json
{
  "source_code": "IQFZnBQ9NCQA7TDBCAAAA0QuDEwM5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAAv0AEo8SuDAAAAAQAwqCB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243981]] |
| 肩部 | [[item:244019]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:273072]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAcG]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Feral Druid** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Night Elf
  
  - One of the most broken racials in Mythic+ but has almost no use in any raid encounter.
  - Does work with [[spell:390772]]**.**
- [[spell:20549]] *-- Tauren* 
  
  - Can be used to stun 5 enemies.
  - [[spell:154743]] 2% critical strike damage.
  - Also, [[spell:20550]] gives you extra health to survive unavoidable damage.

### Recommendation

**Night Elf or Tauren is the best race for your Feral Druid in raiding environments.**

## Macros

Discover recommended macros for **Feral Druid** during Raid and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:102793]]** -- *Casts [[spell:102793]] on your cursor without confirmation.*

```wow-macro
#showtooltip Ursol's Vortex
/cast [@cursor] Ursol's Vortex
```

:::

:::details Mouseover Macros
**Set focus macro - *Put focus on mouseover*.**

```wow-macro
/focus [@mouseover,exists,nodead] []
```

**[[spell:20484]]** -- *Casts [[spell:20484]] on your mouseover or target.*

```wow-macro
#showtooltip Rebirth
/use [@mouseover,exists][] Rebirth
```

:::

:::details Focus Macros
**Focus kick macro - *Cast your [[spell:106839]]* *on your focus*.**

```wow-macro
#showtooltip Skull Bash
/cast [@focus, exists] Skull Bash
```

:::

:::details Utility Macros
**Macro to avoid canceling [[talent:103177]] - *You casts only [[spell:22568]] when [[talent:103177]] is done channeling.***

```wow-macro
#showtooltip Ferocious Bite
/startattack
/cast [nochanneling:Convoke the Spirits] Ferocious Bite
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Feral Druid**, outlining which addons are used and how they are utilized in Raid to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/INTERFACE-midnight-v2-maxroll-3-1024x683.png>)

:::accordion
:::details Addons
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI**-- *UI addon* 
  
  - EllesmereUI is a BIG addon that contain many modules, you can make your whole UI with it.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**DRUID**

- Class
  
  - Matted Fur absorb increased by 25%.
  - Heart of the Wild empowered Wild Growth healing increased by 25%.
- Feral
- Developers’ notes: Feral updates in Curse of Ula’tek are aimed at talent diversity. We’d like Chomp to be stronger for players who enjoy it, and we’re adjusting some other talents to get their power closer and open up more build options.
- Saber Jaws damage bonus increased to 60% per point (was 50%).
- Focused Frenzy damage bonus reduced to 15% (was 20%).
- Rip and Tear damage bonus increased to 20% (was 15%).
- Chomp damage increased by 30%.
- Apex Predator’s Craving base chance to trigger reduced to 4% (was 5%).
- Rejuvenation healing increased by 25%.
- Wild Growth healing increased by 25%.
- Regrowth healing increased by 25%.

:::

:::details Patch 12.0.1
**DRUID**

- Hero Talents
  
  - Wildstalker
    
    - Bloodseeker Vines grow at an increased rate when multiple targets are afflicted by your bleeds.
    - Rampancy causes Bursting Growths to have a 30% chance to trigger (was 20%).
    - Patient Custodian increases bleed damage by 8% (was 6%).
    - Fixed an issue that caused Patient Custodian to not increase Bloodseeker Vine damage.
- Class
  
  - Matted Fur absorption increased by 100%.
  - Matted Fur lasts 15 seconds (was 8 seconds).
  - Regrowth direct healing reduced by 15%.
  - Wild Growth healing increased by 25%.
- Feral
  
  - All attack damage increased by 8%.
  - Cat form Swipe damage increased by 20%.
  - Focused Frenzy increases the damage of Feral Frenzy by 20% (was 40%).
  - Wild Growth healing increased by 100%.
  - Rejuvenation healing increased by 100%.

:::

:::details Patch 12.0
- DRUID
  
  - Hero Talents
  - Druid of the Claw
    
    - New Talent: Limb from Limb – Your auto-attacks are 30% more likely to make your next Ferocious Bite/Maul to become Ravage.
    - New Talent: Twin Claw – You have a 16%/18% chance to follow up any single target melee ability or Raze with a Twin Claw, dealing High Physical damage and generating 3 Energy/5 Rage.
    - New Talent: Exacerbating Wounds – Your Dreadful Wounds increase the damage afflicted enemies take from your Bleed damage over time effects by 8%/15%.
    - Strike for the Heart has been updated –Feral: Shred, Swipe, and Rake damage increased by 10% and their critical strike chance is increased by 8%.
    - Guardian: Mangle damage increased by 20% and its critical strike chance is increased by 10%. Mangle heals you for 5% of maximum health.
    - Tear Down the Mighty has been updated –Feral: Damage dealt by Chomp and Frantic Frenzy increased by 25%.
    - Guardian: The cooldown of Sundering Roar is reduced by 15 seconds.
    - Claw Rampage has been updated – The chance for Ravage to be triggered reduced to 20% (was 25%). Attacks during Berserk only have one chance to grant Ravage (was one per target hit).
    - Ravage has been updated – Your auto-attacks are 15% more likely to make your next attack a Ravage.
    - Empowered Shapeshifting increases the damage and Shred and Swipe by 10% (was 6%).
    - The Ruthless Aggression/Killing Strikes choice talent has changed position.
  - Wildstalker
    
    - New Talent: Green Thumb – The rate at which Bloodseeker Vines/Symbiotic Blooms grow is increased by 20%.
    - New Talent: Rampancy – Bloodseeker Vines/Symbiotic Blooms have a 20% chance to trigger Bursting Growth every 2 seconds at 100% effectiveness.
    - New Talent: Patient Custodian – Your Bleeds and other damage over time/heal over time effects are 6% more effective.
    - Bloodseeker Vines damage reduced by 15%.
    - Bursting Growth damage reduced by 20%.
    - Vigorous Creepers causes Bloodseeker Vines to increase damage victims take from you by 4% (was 6%).
    - Bursting Growth has changed position.
  - Feral
    
    - Twin Claw damage increased by 20%.
    - Ravage damage to its primary target reduced by 20%.
    - Dreadful Wound damage reduced by 20%.
    - Strike for the Heart increases Shred, Swipe, and Rake critical strike chance by 5% (was 8%).
    - Ursine Potential's increase to Mangle and Swipe damage in Bear Form is now 50% (was 300%).

:::

:::details Patch 11.2
- DRUID
  
  - Lycara’s Meditation replaced with Lycara’s Inspiration – You gain a bonus while in each form inspired by the breadth of your Druidic knowledge:
    
    - No Form: 4% Magic Damage
    - Bear Form: 5% Movement Speed
    - Cat Form: 4% Stamina
    
    
    
    - Moonkin Form: 3% Avoidance
  
  
  
  - Maim now has a 30 second cooldown (was 20 seconds).
  
  
  
  - Bear Form’s threat generation multiplier has been reduced for Balance, Feral, and Restoration Druids.
  
  
  
  - Druid of the Claw
    
    - Empowered Shapeshifting causes Bear Form to reduce magic damage taken by 6% (was 4%).
  
  
  
  - Wildstalker
    
    - Symbiotic Blooms and Bursting Growth healing increased by 30%.
    - Thriving Growth's base chance for Symbiotic Blooms to grow increased by 30%. Rate at which this increases with larger target counts slightly reduced.
    - Twin Sprouts' chance to generate an additional Bloodseeker Vine or Symbiotic Bloom increased to 30% (was 20%).
    - Vigorous Creepers causes Bloodseeker Vines to increase damage targets take from you by 6% (was 5%).
  
  
  
  - Feral
    
    - All ability damage increased by 8%.
    - Brutal Slash damage in Bear Form increased by 25%.
    - Lycara’s Teachings gives 6% Mastery while in Moonkin Form (was 2%).
    - Saber Jaws bonus to extra Ferocious Bite damage increased to 60/120% (was 40/80%). This change does not affect PvP combat.
    - Sabertooth causes Ferocious Bite to increase damage taken from your bleeds and other periodic effects by 5% per combo point (was 3%).

:::

:::details Patch 11.0.2
- DRUID
  
  - Regrowth initial heal increased by 27% and its healing over time decreased by 3%.
  - Swiftmend healing increased by 38%.
  - Ironfur increases Armor by 112% of Agility (was 120%).
  
  
  
  - Feral
    
    - Melee auto-attack damage increased by 30%.
    - Rip damage increased by 15%.
    - Rake initial damage increased by 30% and periodic damage increased by 5%.
    - Shred initial damage increased by 30%.
    - Swipe initial damage increased by 30%.
    - Brutal Slash initial damage increased by 30%.
    - Thrash initial damage increased by 30% and periodic damage increased by 5%.
    - Lunar Inspiration Moonfire initial damage increased by 30%.
    - Primal Wrath direct damage increased by 20%.
    - Adaptive Swarm direct damage increased by 20%.
    - Rampant Ferocity's damage increased by up to 100% (was 50%) when players spend extra Energy on Ferocious Bite.
    - Taste For Blood increases Ferocious Bite damage by 12% (was 15%) and an additional 12% (was 15%) during Tiger's Fury.
    - Apex Predator's chance to proc against multiple targets increased slightly.
    - Berserk now increases all ability and auto-attack damage by 15% (was 10%).
    - Berserk: Frenzy now causes enemies to bleed for 150% of all direct damage dealt by combo point generating abilities (was 135%).
    - Incarnation reduces the Energy cost of all abilities by 25% (was 20%).
    - Ashamane's Guidance's effect now lasts 40 seconds after Incarnation ends (was 30 seconds).
    - Savage Fury increases your Haste by 10% (was 8%) and Energy recovery rate by 25% (was 20%).

:::

:::

## FAQ

:::accordion
:::details Q: Do I use my finishers at 4 or 5 combo points?
**A:** You want to always use your finishers at 5 combo points.

:::

:::

---

### Credits

Written by: **Maystine**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-06** updated for 12.1

**2026-06-22** updated for 12.0.7

**2026-04-24** updated 12.0.5

**2026-02-10** updated 12.0.1

**2026-01-19** updated 12.0

**2025-12-03** Updated 11.2.7

**2025-10-08** Updated 11.2.5

**2025-07-28** Updated for 11.2!

**2025-06-17** Updated for patch 11.1.7.

**2025-04-22** Updated for patch 11.1.5.



:::
