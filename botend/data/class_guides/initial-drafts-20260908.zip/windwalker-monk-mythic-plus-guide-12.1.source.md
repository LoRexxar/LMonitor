Welcome to the **Windwalker Monk** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 2/5 · Weak

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Windwalker Monk** Mythic+ Best in Slot
```json
{
  "source_code": "JUrAY3QA3_PAB8JJEIIMBAQD5OwVtOAf1IYNXYjt1ghNCKAWBEQ6XQAApEAA8z6A8z6AMWDZ1ghNeVTBaQSnkQAAgEAA-VTgFwCPOFQAiSCBCASAAkQuDoXNCGRFQA-FEAIIFEUA6Qgt1UAPA4ZCqwQo7OQfNoCNYFQAf5mACgQAAkSuDIYAOBBY7OAgIVQOwDktvMWNRDzt1YTN6FjVi4INAMySBEA9UPAAYEAA2IjX1caJOFQA5Z9ACiRAAUPuDwPrDAwI2-yt1sUABIW2DIIIB0gFEQWNB4CHWiiTBEwXfQQA-EwkUkjAYFQAdlBEFEKGdfBBAgQAAUAD8c7FEIAEBAwP5OgF2IoAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240983]] · [[item:243981]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271517]] |  |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159327]] | [[item:244009]] |
| 腕部 | [[item:244576]] | [[item:240892]] |
| 手部 | [[item:251124]] |  |
| 戒指一 | [[item:251513]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Windwalker Monk**, you have access to Tigereye Brew, which increases your critical strike chance during [[talent:124826]].

**Rank 2** does increase the total amount of your critical strike damage.

While **Rank 3** unlocks a new ability [[spell:1272696]]!

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-windwalker-mxr.webp>)

Tigereye Brew

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:128711]]
    
    - You gain [[talent:124985@FAgATZfABdhA]] damage in aoe, as it splashes now.
  - [[talent:134543@AJgCCA]]
    
    - A high chance to get free empowered [[talent:124985@FAgATZfABdhA]] after consuming [[spell:116768]].
  - [[talent:128712]]
    
    - Enhances your [[talent:125026]].
  - [[talent:124815]] or [[talent:124814]]
    
    - Empowers your [[talent:126307]].
  - [[talent:124817@FAQABdhA]]
    
    - Provides an additional hit at the end of your [[talent:125026]].
- **Class Tree**
  
  - [[talent:124956]]
    
    - Provides a decent chunk of damage after casting [[talent:124826]].
  - [[talent:124953]]
    
    - Increases your chance for your auto attacks to crit.
  - [[talent:136520]]
    
    - After a successful dispel the target is faster!
- **Removed**
  
  - [[spell:137639]]
    
    - Replaced by your new cooldown [[talent:124826]].
  - [[spell:123904]]
    
    - You change from a 2 minute class without this cooldown.
  - [[spell:393039]]
  
  
  
  - [[spell:459809]]
    
    - Removes your capabilities to cleave spread targets.
  - [[spell:122783]]
    
    - The loss of a defensive does make you more squishy.
  - [[spell:388686]]
    
    - More freedom of movement for the enemies in your cooldowns.

## Hero Talents

- In single target both hero talents [[talent:125027]] and [[talent:125047]] perform very similar, but due to higher burst from [[talent:125047]] it is most likely the better choice.
- [[talent:125027]] vastly outperforms  [[talent:125047]] in AoE scenarios.

:::tabs
:::tab [[talent:125027]]
- Your autoattacks have a chance to generate 1-2 [[spell:451021]], upon casting [[spell:113656]] you unleash all your [[spell:451021]] stacks.

- [[talent:125072@AJgCCA]]
  
  - Reduces the cooldown of [[talent:124826]] by 10 seconds.
- [[talent:125073@AJgCCA]]
  
  - Your [[talent:124985@FAgATZfABdhA]] and [[spell:101546]] unleash up to 3 [[spell:451021]] during [[talent:124826]].
- [[talent:135955]]
  
  - [[talent:125069@AJgCCA]] deals damage to all enemies within 6 yards.
- [[talent:135956@AJgCCA]]
  
  - You gain 10 stacks of [[talent:125069@AJgCCA]] after casting [[talent:124826]], that will trigger on your next ability cast.
- [[talent:135957@AJgCCA]]
  
  - Increases [[talent:124956]] by 20%.

:::

:::tab [[talent:125047]]
- Gain access to [[talent:125062@FAQAfGPB]] a powerful 120 second cooldown.
- [[talent:136744]]
  
  - Reduces the cooldown of [[talent:125062@FAQAfGPB]] by 30 seconds.
- [[talent:136745@AJgCCA]]
  
  - Gain the ability to cast [[talent:136745@AJgCCA]] after summoning  [[talent:125062@FAQAfGPB]].
- [[talent:125055]]
  
  - Your [[talent:125014]] and your [[talent:134452]] grants you 75% cooldown reduction on [[talent:124985]], [[spell:113656]], [[talent:125014]] and [[talent:125011]].
  
  
  
  - While it is up your [[spell:113656]] channel time is reduced by 50%.
- [[talent:136754@AJgCCA]]
  
  - Gain [[talent:135959@AJgCCA]] after casting [[talent:124826]] for 4 seconds.
- [[talent:135958@AJgCCA]]
  
  - Increases your haste by 10% while [[talent:135959@AJgCCA]] is up.
- [[talent:125058]]
  
  - After finishing your [[talent:136745@AJgCCA]] you spawn all Celestials.
  - It is also possible to finish the channel early to spawn them faster.

:::

:::

## Talents

:::tabs
:::tab [[talent:125027]]
:::talents [[talent:125046]] **Windwalker Monk** Mythic+ Build
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

### When to use this Spec

It is your choice whether you play [[talent:125046]] or [[talent:125062@AJgCCA]] in dungeons. Although for some dungeons some minor talents in the class tree will change for some different utility options. To make your life easier, dungeon-specific talent loadouts are available in the Dungeons section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[talent:125009]]
  
  - [[talent:134452]] and [[talent:125014]] grants you a guaranteed [[spell:116768]] proc.
- [[talent:124824]]
  
  - [[talent:124826]] cooldown is reduced by 20 seconds.
- [[talent:124810]]
  
  - You have a chance to restore 1 Chi with [[talent:124985@FAgATZfABdhA]].
- [[talent:126307]]
  
  - Generates 2 Chi with [[talent:124815]].

#### Class Tree

- [[talent:124956]]
  
  - Activating [[talent:124826]] unleashes a strong [[talent:124817@FAQABdhA]] around you.
- [[talent:124975]]
  
  - Reduces the cooldown of [[spell:322111]] by 90 seconds.

### Hero Talents

- [[talent:125068]]
  
  - Your default pick since [[talent:125067]] is weaker.
- [[talent:125076]]
  
  - Personal preference but most likely the better choice than [[talent:125075]].
- [[talent:125065]]
  
  - Your default pick, but you can take [[talent:125064]] as well.

:::

:::tab [[talent:125047]]
:::talents [[talent:125047]] **Windwalker Monk**  Mythic+ Build
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### When to use this Spec

It is your choice whether you play [[talent:125046]] or [[talent:125062@AJgCCA]] in dungeons. Although for some dungeons some minor talents in the class tree will change for some different utility options. To make your life easier, dungeon-specific talent loadouts are available in the Dungeons section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[talent:125009]]
  
  - [[talent:134452]] and [[talent:125014]] grants you a guaranteed [[spell:116768]] proc.
- [[talent:124824]]
  
  - [[talent:124826]] cooldown is reduced by 20 seconds.
- [[talent:124810]]
  
  - You have a chance to restore 1 Chi with [[talent:124985@FAgATZfABdhA]].
- [[talent:126307]]
  
  - Generates 2 Chi with [[talent:124815]].
- [[talent:124829]]
  
  - Generate 1 Chi after consuming a [[spell:116768]] proc.

#### Class Tree

- [[talent:124956]]
  
  - Activating [[talent:124826]] unleashes a strong [[talent:124817@FAQABdhA]] around you.
- [[talent:124975]]
  
  - Reduces the cooldown of [[spell:322111]] by 90 seconds.

### Hero Talents

- [[talent:125054@AJgCCA]] 
  
  - Your default choice as it is stronger than [[talent:125053]].
- [[talent:136744]]
  
  - Depending on fight duration and your trinkets [[talent:136760@FJQAfGPBKIA]] might be better.
- [[talent:125057]]
  
  - Personal preference if you prefer [[talent:125056]].

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:125026]] strikes an additional time at the start of its channel at 50% effectiveness.
- 4**-Set**: ‍[[talent:125026]] increases the damage of your next ‍[[talent:124985@FAgATZfABdhA]] by 10% or ‍[[spell:101546]] by 20% each time it strikes, stacking up to 6 times.

### Single-Target

:::tabs
:::tab [[talent:125046]]
### Opener

- Your goal is to cast as many Chi spenders as possible in your [[talent:124826]] window while also keeping relevant abilities on cooldown.

:::rotation **Windwalker Monk** Single-Target Opener in Mythic+
```json
{
  "source_code": "IEYAssgQsmYAAAAAAIEpjmACUV4kSAAALkmZgQXYsVmb0VGZCEAiuOQBjgQWRMRHpgwF_XgNpAAEAIE-7GQBpgwbSJgPbAgPnBAH4vbAAAAAAIE"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:1217413]] if talented [[item:241288]] · [[spell:1249625]]
4. [[spell:107428]]
5. [[spell:392983]] if talented
6. [[spell:113656]]
7. [[spell:152175]] if talented
8. [[spell:100780]]
9. [[spell:107428]]
10. [[spell:113656]]
11.
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. [[spell:322109]] if possible.
2. [[spell:107428]] when buffed by [[spell:337481]].
3. [[spell:100780]] if below 5 Chi and close to capping Energy.
4. [[talent:125014]]
5. [[talent:126307]].
6. [[spell:101546]] with 2 stacks of [[spell:286585]].
7. [[talent:134452]] if possible.
8. [[spell:107428]].
9. [[spell:100780]] if you are capping energy.
10. [[spell:113656]].
11. [[spell:100784]] to not overcap on stacks of [[spell:116645]].
12. [[spell:101546]] with [[spell:286585]].
13. [[spell:100780]].
14. [[spell:100784]].

:::

:::tab [[talent:125047]]
### Opener

- Your goal is to cast as many Chi spenders as possible in your [[talent:124826]] window while also keeping relevant abilities on cooldown.

:::rotation **Windwalker Monk** single-target opener in Mythic+
```json
{
  "source_code": "IkZAs4gQsmYAAAAAAIEpjmAC0BCnGAAALkmZgQXYsVmb0VGZAI0ePUAAAAgABgorDUwKIkVET0RMIcx_F4TMAQA-7mATI8mUC4zGAExZIQpwGUATRAREzwBAAAAAAAAACB"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:433184]] if talented
4. [[spell:331643]]  [[item:241288]] · [[spell:1249625]]
5. [[spell:107428]]
6. [[spell:392983]] if talented
7. [[spell:113656]]
8. [[spell:152175]] if talented
9. [[spell:107428]]
10. [[spell:443028]]
11. [[spell:107428]]
12. [[spell:113656]]
13. 
14.
:::

1. [[spell:322109]] if possible.
2. [[talent:125014]].
3. [[talent:134452]] if possible.
4. [[talent:126307]].
5. [[talent:125062@AJgCCA]].
6. [[spell:107428]] when buffed by [[spell:337481]].
7. [[spell:100780]] if below 5 Chi and close to capping Energy.
8. [[spell:113656]].
9. [[spell:107428]].
10. [[spell:101546]] with 2 stacks of [[spell:286585]].
11. [[spell:100784]] to not overcap on stacks of [[spell:116645]].
12. [[spell:101546]] with 1 stack of [[spell:286585]].
13. [[spell:100784]].

:::

:::

### AoE

:::tabs
:::tab [[talent:125046]]
### Opener

- Below you can see one variation of the multi-target opener rotation using the [[talent:125046]].

:::rotation **Windwalker Monk** AoE opener in Mythic+
```json
{
  "source_code": "IEYAssgQsmYAAAAAAIEpjmACUV4kSAAALkmZgQXYsVmb0VGZCEAiuOQBjgQWRMRHpgwF_XgNpAAEAIE-7GQBpgwbSJgPbAgPnBAH4vbAAAAAAIE"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:1217413]] if talented [[item:241288]] · [[spell:1249625]]
4. [[spell:107428]]
5. [[spell:392983]] if talented
6. [[spell:113656]]
7. [[spell:152175]] if talented
8. [[spell:100780]]
9. [[spell:107428]]
10. [[spell:113656]]
11.
:::

### Priority List

1. [[spell:100780]] if below 5 Chi and close to capping Energy.
2. [[spell:322109]] if possible.
3. [[spell:101546]] with [[spell:286585]] with 2 stacks to not overcap.
4. [[talent:134452]].
5. [[talent:125014]].
6. [[spell:113656]].
7. [[spell:107428]] to enable [[talent:134452]].
8. [[spell:101546]].
9. [[spell:100784]] to not overcap on stacks of [[spell:116645]].

:::

:::tab [[talent:125047]]
### Opener

- Below you can see one variation of the multi-target opener rotation using the [[talent:125047]].

:::rotation **Windwalker Monk** AoE opener in Mythic+
```json
{
  "source_code": "IkZAs4gQsmYAAAAAAIEpjmAC0BCnGAAALkmZgQXYsVmb0VGZAI0ePUAAAAgABgorDUwKIkVET0RMIcx_F4TMAQA-7mATI8mUC4zGAExZIQpwGUATRAREzwBAAAAAAAAACB"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:433184]] if talented
4. [[spell:331643]]  [[item:241288]] · [[spell:1249625]]
5. [[spell:107428]]
6. [[spell:392983]] if talented
7. [[spell:113656]]
8. [[spell:152175]] if talented
9. [[spell:107428]]
10. [[spell:443028]]
11. [[spell:107428]]
12. [[spell:113656]]
13. 
14.
:::

1. [[spell:322109]] if possible.
2. [[talent:125014]].
3. [[talent:126307]].
4. [[talent:136745@AJgCCA]].
5. [[spell:100780]] if below 5 Chi and close to capping Energy.
6. [[spell:101546]] with 2 stacks of [[spell:286585]].
7. [[talent:134452]] if possible.
8. [[spell:113656]].
9. [[spell:107428]] to enable [[talent:134452]].
10. [[spell:101546]] with 1 stack of [[spell:286585]].
11. [[spell:101546]].

:::

:::

## Deep dive

### Mastery

- It is very important to never break your [[spell:115636]] or [[spell:196740]].
- During downtime you can use [[spell:101546]] to keep up your [[spell:196740]].
- If the boss is immune to damage you can also use [[spell:117952]] to keep it up.

### Touch of Karma

- To maximize your damage output you want to press [[spell:122470]] on every damage event possible in the fight.
- You can increase the absorbed amount of your [[spell:122470]] damage by using [[spell:243435]] beforehand to increase your maximum health.
- When grouped with a **Warrior**, you can ask them to press [[spell:97462]] if it is not needed as a cooldown to get even more health before using [[spell:122470]].

### Two-handed weapon versus one-handed weapons

- Two-handed weapons outperform one-handed due to [[talent:124828]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Windwalker Monk** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### Rav'i

- Dodge the [[spell:1296050]].
- Use a defensive on [[spell:1296220]].
- Soak the puddles that spawn from [[spell:1306226]].

#### The Writhing Coil

- Interrupt [[spell:1310358]] from the **Writhing Coil**.
- Break [[spell:1299053]] as fast as possible.
- Bait the [[spell:1299130]] towards the closest wall.
- You can [[spell:119381]] and [[talent:124926]] the **Uncoiled Writhes**.
- Holding a charge of [[talent:124826]] is good for the Uncoiled Writhes to maximize damage output.

#### Zul'jan

- Soak one of the beams from [[spell:1300872]].
- Remove [[spell:1300894]] by soaking [[spell:1301413]].

### Trash Tips

At the start of the dungeon in the library area you can activate a **Arcane Tome**, it provides your party with [[spell:1254550]].

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  
  
  
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.
- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  
  
  
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.
- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[talent:124937]].

:::

:::tab Den of Nalorakk
:::talents **Windwalker Monk** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Soak the [[spell:1234740]] before they explode.
  
  - You can dispel [[spell:1234846]] with [[talent:124941]].
- Use a defensive on [[spell:1234681]].

#### Sentinel of Winter

- Use [[talent:124826]] to cleave the  **Fractured Shivercore**.
- You can use [[talent:124932]] on the **Fractured Shivercore**.
- Interrupt [[spell:1235829]] from **Fractured Shivercore**.

#### Nalorakk

- Make sure you are on Zul'jarra to get [[spell:1261776]] during  [[spell:1243569]].
- Intercept the **Echoes of Nalorakk** during [[spell:1243002]].

### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  
  
  
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:124937]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  
  
  
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Windwalker Monk** Mythic+ Build in Murder Row
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- In general you should hit **Nibbles** until Kystia Manaheart looses her shield.
- You can remove the **Miror Images** with [[talent:124932]], [[talent:124926]] and [[spell:119381]].
- Use [[talent:124826]] during [[spell:1265412]] to maximize damage.

#### Zaen Bladesorrow

- Destroy the **Fel-infused Freight** with [[spell:1214357]].
- Hide behind a **Forbidden Freight** during [[spell:1218347]].

#### Xathuux the Annihilator

- Stay on the boss if targeted by [[spell:1214663]].
- Use a defensive on [[spell:1295455]].
- Either use [[talent:124826]] while the Axe is on the ground, or during [[spell:474197]].

#### Lithiel Cinderfury

- Wait for the boss to finish the cast [[spell:1217384]] before using [[spell:1214675]].
- Use [[talent:124826]] after [[spell:474457]] to kill the **Wild imps**.
- Use a defensive on [[spell:474457]].
- Interrupt [[spell:474375]] from **Kystia Manaheart**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  
  
  
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.
- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  
  
  
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Windwalker Monk** Mythic+ Build in Blinding Vale
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Interrupt [[spell:1235616]] from **Kezkitt**.
- Use [[talent:124826]] when you can cleave as many targets as possible.
- Intercept the [[spell:1235564]].
- Use a defensive if targeted by [[spell:1235640]].

#### Ikuzz the Light Hunter

- You can dispel [[spell:1236658]] with [[talent:124937]].
- Get away from the boss if targeted by [[spell:1237090]].
- Use a personal on [[spell:1236746]].

#### Lightwarden Ruia

- Interupt [[spell:1239821]] from **Lightwarden Ruia**.
- Use a defensive if targeted by [[spell:1240098]].
  
  - You can stack together with other people.
- Spread out during [[spell:1240210]], make sure not a single person is behind you to not cleave each other.

#### Ziekket

- Use [[talent:124826]] to kill the **Lightspawn Lashers**.
- Intercept the [[spell:1246858]] before they reach the boss.
- Use a defensive when targeted by [[spell:1246607]].

### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  
  
  
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.
- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  
  
  
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.
      
      - You can dispel it with [[talent:124941]].
- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents **Windwalker Monk** Mythic+ Build in Voidcsar Arena
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### Taz'Rah

- Use a defensive on [[spell:1222098]].
  
  - Try to be as close to each other as it spawns the **Ethereal Shades**.
- Watch the **Ethereal Shades** during [[spell:1300259]].

#### Atroxus

- Kill the **Toxic Creeper** as fast as possible.
- Use your [[talent:124826]] while the **Toxic Creeper** is alive.
- You can dispell [[spell:1222642]] and [[spell:1226031]] with [[talent:124941]].
- Use a defensive while the **Toxic Creeper** is alive.

#### Charonus

- Put the [[spell:1223298]] into the [[spell:1264191]].
- Spread out during [[spell:1227197]] and use a personal.
- Either hide behind the tank when targeted by [[spell:1222755]] or kite the projectile.

### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  
  
  
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.
- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  
  
  
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents **Windwalker Monk** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Use a defensive on [[spell:265773]] and place the puddle behind the boss.
- Keep the **Animated Gold** away from the **Golden Serpent** with [[talent:124926]] and [[spell:119381]].
- It is adviced to use a defensive on [[spell:1311987]]**.**

#### Mchimba the Embalmer

- Use a defensive if targeted by [[spell:267618]].
- [[spell:267639]] drops a puddle, place it in a good spot.
- Interrupt [[spell:267763]] from the **finished Mummy**.

#### The Council of Tribes

- Use a defensive on [[spell:266231]].
- Soak the [[spell:266951]].
- Interrupt [[spell:267273]] from **Zanazal the Wise**.
- Kill the **Explosive Totem** before it finishes [[spell:267077]].

#### Dazar, the first King

- Dazar, the first King shares health with **T'zala** due to [[spell:1303519]].
  
  - T'zala spawns after **Dazar, the first King** reaches 80%.
- Interrupt [[spell:269369]] from **Reban**.
- Use a defensive on [[spell:1303267]].

### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  
  
  
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.
- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  
  
  
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  
  
  
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab `Ruby Life Pools`
:::talents **Windwalker Monk** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- [[spell:373680]] happens on 66% and 33% boss health.
  
  - Plan your [[talent:124826]] usage accordingly to break the [[spell:372988]] as fast as possible.
- Put the [[spell:372851]] away from the group and use a defensive on it.
- Interrupt [[spell:372808]] from **Melidrussa Chillworn**.

#### Kokia Blazehoof

- Maximize your cleave damage on this boss.
- You can use [[talent:124826]] while the **Blazebound Firestorm** is alive.
- Interrupt [[spell:373017]] from **Blazebound Firestorm.**
- Aim the [[spell:372819]] properly, do not waste too much space in the room.

#### Kyrakka and Erkhart Stormvein

- Go towards the edge of the room on expiration of [[spell:381602]] as it drops a [[spell:381868]].
- Use a defensive on  [[spell:381602]].
- [[spell:381517]] moves the [[spell:381868]].
  
  - [[spell:381517]] follows a counterclockwise pattern.
- Only use [[talent:124826]] when you can cleave both bosses.

### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.
- **Pay extra attention to these casts:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  
  
  
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  
  
  
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Windwalker Monk** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Always hit the target that does not have [[spell:1289229]].
- [[spell:1288864]] puts down a puddle at the end.
- [[spell:1289059]] pushes you back, make sure to not pull any uncessary trash during the encounter.

#### Merektha

- You can dispell [[spell:267027]] from the **Toxic Viper**.
- You can remove [[spell:263958]] with [[spell:119381]].
- Use a defensive on [[spell:1293048]].

#### Galvazzt

- Intercept each [[spell:265986]] from reaching the boss with atleast 1 player.
- Use a defensive whenever you are in danger.

#### Avatar of Sethraliss

- Use a defensive on [[spell:1302153]], it also drops a puddle on the ground.
- Soak the [[spell:1300869]].
- Interrupt [[spell:1302158]] from **Twisted Hexxers**.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1291262]] from **Storm Adept**.
  
  
  
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- **Pay extra attention to these casts:**
  
  - [[spell:272655]] from **Sand-Sworn Rider**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  
  
  
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

The Affix system got revamped going into **The War Within Season** 3 retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear. These affixes have been further iterated on through The War Within and going into Midnight.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affixes 
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified

- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Windwalker Monk.**

- Xal'atath's Bargain: Ascendant
  
  - Use [[talent:124926]] to handle as many orbs as possible.
  - You can use it to gain additional [[spell:220357]] stacks.
  - [[spell:119381]] if necessary.
- Xal'atath's Bargain: Voidbound
  
  - You can use it to gain additional [[spell:220357]] stacks.
  - Hit it as your priority target as other mobs take reduced damage while it is up.
  - [[spell:322109]] can be instantly used on it.
- Xal'atath's Bargain: Devour
  
  - Dispel yourself with [[talent:124941]] or any other party member.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Windwalker Monk**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Windwalker Monk** Stat Priority in Mythic+
```json
{
  "source_code": "HoAJFMQMkACKBEQABA"
}
```
**敏捷 ＞ 精通 ＞ 急速 ＞ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271519@DCTAA0QANk7cVrDf1IYNXYjt1ghNCKAWBA]] | Ula'tek |
| Neck | [[item:268265@BkSAA0QA8z6wPrDj1QWNYYjX1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271517@BASAA0QA-VTg1ghNCKgTBA]] | The lost explorers/Catalyst |
| Cloak | [[item:268253@BgQAA0QACKAWBA]] | The Coiled Altar |
| Chest | [[item:271522@DASAA0QAJk7oXNCWDG2IoAOF]] | Vashnik the Malignant/Catalyst |
| Wrist | [[item:244576@BiUAA0QA8z6Y7LjVT0wcbN2UjexYlIOSDAjsUA]] | Leatherworking |
| Gloves | [[item:251124@BgRAA0QA2IjX1caJOFA]] | Murder Row |
| Belt | [[item:268256@BCSAA0QA8z6ghNeVjt1IoAYF]] | The Coiled Altar |
| Legs | [[item:271518@DASAA0QAhu70XNCWDG2IoAYF]] | Sszorak/Catalyst |
| Boots | [[item:159327@DgQAA0QApk7IoAOF]] | Temple of Sethraliss |
| Ring 1 | [[item:251513@DiRAA0QA1j7wPrDAjY7L3WzSBA]] | Jewelcrafting |
| Ring 2 | [[item:252258@DCSAA0QA1j7wPrDZ1YjMeVjlo4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270175@BgRAA0QAYYjX1kjAYFA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgRAA0QAYYjX1IoAYFA]] | The Coiled Altar |
| Mainhand | [[item:268215@DARAA0QA_k7YhNCKAWB]] | Ula'tek |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@BgQAA0QACKQQBA]] | Murder Row |
| Neck | [[item:251173@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAA0QACKQQBA]] | Voidcar Arena |
| Cloak | [[item:251132@BgQAA0QACKQQBA]] | Murder Row |
| Chest | [[item:251159@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:251135@BgQAA0QACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgRAA0QA2IjX1caJBFA]] | Murder Row |
| Belt | [[item:159317@BgQAA0QACKQQBA]] | Temple of Sethraliss |
| Legs | [[item:251130@BgQAA0QACKQQBA]] | Murder Row |
| Boots | [[item:159327@DgQAA0QApk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:273792@BgQAA0QACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:252258@BASAA0QAkVjNy4VNWiSQBA]] | Voidscar Arena |
| Trinket 1 | [[item:250215@BgQAA0QACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAA0QACKQQBA]] | The Blinding Vale |
| Mainhand | [[item:273783@BgQAA0QACKQQBA]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgRAA0QAYYjX1kjAYFA]]  <br>[[item:270173@BgRAA0QAYYjX1IoAYFA]] |
| **A-Tier** | [[item:270164@BgQAA0QACKgTBA]]  <br>[[item:270168@BgQAA0QACKAWBA]] -- Useful on demand burst siuations.  <br>[[item:270165@BgQAA0QACKgTBA]] |
| **B-Tier** | [[item:270166@BgQAA0QACKgTBA]]  <br>[[item:250215@BgQAA0QACKgTBA]]  <br>[[item:250259@BgQAA0QACKgTBA]] |
| **C-Tier** | [[item:250214@BgQAA0QACKgTBA]]  <br>[[item:250228@BgQAA0QACKgTBA]] |
| **Junkyard** | [[item:250225@BgQAA0QACKgTBA]]  <br>[[item:273796@BgQAA0QACKgTBA]] |

### Embellishments

> Everything in this section is subject to change, so check back before you do any important craft using Sparks to see if this text is removed.

- 1x [[item:251513@DiRAA0QAvk7oPrDAjMWNFITHBA]]
  
  - This embellishment is a unique ring.
- 1x [[item:240167@BAAAA0QA]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 1x [[item:245875]]
  
  - This embellishment can only be applied to weapons.
- 1x [[item:240167@BAAAA0QA]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

#### Remaining Sparks

- Crafted items are 331item level and regular items are 334 on max item level therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]] *-- maximum DPS.*
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]*--  default pick.*
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  - [[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].*
    
    - [[item:240892]]
    - [[item:240908]]
    - [[item:240918]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAA0QA]]  <br>[[item:243951@BAAAA0QA]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAA0QA]] |
| Waist | [[item:275707@BAAAA0QA]] |
| Legs | [[item:244641]] |
| Boots | [[item:243953]] |
| Ring 1 | [[item:243957@BAAAA0QA]] |
| Ring 2 | [[item:243957@BAAAA0QA]] |
| Mainhand | [[item:244031]] |

:::

:::column
:::gear **Windwalker Monk** Enchantments in Mythic+
```json
{
  "source_code": "IQFZNEQ9NCQA7TDBQAAAAgF3SEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[spell:1236056]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAA0QA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Windwalker Monk** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
  - Use-cases:
    
    - [[spell:450095]], **Drahga Shadowburner** (Grim Batol)
    - [[spell:461487]], **Ki'katal the Harvester** (Ara-Kara, City of Echoes)
    - [[spell:275014]], **Viq'Goth** (Siege of Boralus)
    - [[spell:434137]], **Royal Venomshell** (City of Threads)
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:33702]] -- Orc
  
  - Strong racial for damage both because of [[spell:21563]] and [[spell:33702]] which lines up with [[talent:125013]].
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] -- Troll
  
  - Your strongest DPS racial but lines up poorly with [[talent:125013]].
  - Reduce the duration of movement impairing effects by 20%.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Windwalker Monk**.

## Macros

Discover recommended macros for Windwalker Monks during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**Cursor [[spell:116844]] -- *[[spell:116844]]* *on your cursor without confirmation.***

```wow-macro
#showtooltip
/cast [@cursor] Ring of Peace
```

:::

:::details Mouseover Macros
**[[spell:116670]] Mouseover -- *Casts [[spell:116670]] on your mouseover.***

```wow-macro
#showtooltip
/cast [@mouseover,help] Vivify
```

**Mouseover [[spell:116841]] -- *Casts[[spell:116841]] on your mouseover*.**

```wow-macro
#showtooltip
/cast [@mouseover,help] Tiger's Lust
```

**[[talent:124941]] -- *Casts [[talent:124941]] on your mouseover target if it exists.***

```wow-macro
#showtooltip Detox
/cast [@mouseover,help,nodead] Detox;Detox
```

:::

:::details Pet Macros
**Pet Dismiss Macro** - *Removes [[talent:125013]].*

```wow-macro
/petdismiss
```

:::

:::details Utility Macros
**/stopmacro [channeling:Fists of Fury] --  *makes sure your [[spell:113656]]* is not getting canceled while spamming [[spell:100780]] ( You can replace  [[spell:100780]] with any other ability you want to spam).**

```wow-macro
#showtooltip Tiger Palm
/stopmacro [channeling:Fists of Fury]
/cast Tiger Palm
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Windwalker Monk**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/swaguimidnightdungeon-1024x607.png>)

**Windwalker Monk** Mythic+ User Interface

:::accordion
:::details Addons
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **LittleWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for custom scripting.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- MONK
  
  - Chi Transfer now causes Touch of Death to heal you for 60% of damage it deals (was 50%).
  - Vigorous Expulsion increases Expel Harm's healing by 6% (was 5%).
  - Silent Sanctuary healing increased by 25%.
- Windwalker
  
  - Developers' notes: We are making a few adjustments to Windwalker's damage profile to reduce the gap between their steady-state damage and high-end burst capabilities.
  - Dance of the Wind has been updated – Your physical damage taken is reduced by 10% and an additional 10% every 4 seconds until you receive a physical attack, stacking up to 4.
  - Melee auto-attack damage increased by 30%.
  - Zenith Stomp damage reduced by 30%.
  - Blackout Kick damage increased by 50%.
  - Tiger Palm damage increased by 200%.
  - Dual Threat damage increased by 30%.
  - Spinning Crane Kick damage decreased by 12%.
  - Whirling Dragon Punch area of effect damage increased by 30%.
  - Jade Ignition damage increased by 50%.
  - Weapon of Wind now increases damage during Zenith by 5% (was 10%).
  - Apex Talent: Tigereye Brew (Rank 2) now increases Critical Strike damage by 5%/10% (was 10%/20%).
  - Vivify healing increased by 25%.
  - Expel Harm healing increased by 25%.
  - Combat Wisdom now increases Stamina by 5%.
  - Calming Presence now reduces damage taken by 10% (was 6%).
- Hero Talents
  
  - Conduit of the Celestials
    
    - Celestial Conduit damage reduced by 25%.
    - Temple Training increases the damage of Fists of Fury and Spinning Crane Kick by 30% (was 10%).

:::

:::

:::accordion
:::details Patch 12.0.5
- MONK
  
  - Windwalker 
    
    - Crashing Fists has been redesigned – Fists of Fury damage is increased by 20% (was extends duration by 1 second).
    - Tigereye Brew (Rank 1) has been redesigned – Every 3 Chi spent generates Tigereye Brew. Zenith consumes up to 20 Tigereye Brew stacks to increase your critical strike chance for its duration by 1% per stack. Generates quickly up to 10 stacks while out of combat and may generate up a maximum of 30 stacks.
    - Tigereye Brew (Rank 3) has been redesigned – Zenith now grants access to 2 additional Zenith Stomps.
    - Xuen's Battlegear may now additionally trigger from Spinning Crane Kick, reducing the cooldown of Fists of Fury by 0.5 seconds for each unique target struck, up to 2.5 seconds.
    - Zenith Stomp now generates 2 Chi.
    - Zenith no longer generates 2 Chi on cast.

:::

:::

:::columns
:::column
:::accordion
:::details Patch 12.0.1
- MONK
  
  - Windwalker 
    
    - *Developers' notes: These changes are aimed at underperforming and overperforming talents, increasing Windwalker’s AoE damage, tweaking Rising Sun Kick’s damage contribution in single target versus Fists of Fury, and adjusting its chi economy in a few ways to be a smoother experience.*
    - Rising Sun Kick damage increased by 20%.
    - Spinning Crane Kick damage increased by 50%.
    - Jadefire Stomp damage increased by 25%.
    - Flurry of Xuen damage increased by 40%.
    - Fists of Fury damage decreased by 10%.
    - Airborne Rhythm now generates 1 Chi (was 2 Chi).
    - Rushing Wind Kick no longer has a Chi cost.
    - Sunfire Spiral now increases Mastery: Combo Strikes by 40% (was 20%).
    - Universal Energy increases magical damage done by 8% (was 15%).
    - Memory of the Monastery now increases Combo Breaker's effect chance by 75% (was 25%) and increases Tiger Palm's damage by 30% (was 15%).
    - Communion with Wind increases the damage of Strike of the Windlord and Whirling Dragon Punch by 20% (was 10%).
    - Tigereye Brew now only reduces its stacks down to 10 while out of combat in a raid instance and now grants 10 stacks or reduces stacks down to 10 at encounter start and Mythic+ start.
    - Threat generated by Zenith Stomp reduced by 50%.
    - Vivify Healing increased by 100%.
    - Vivify Healing is reduced by 33% in PvP combat (was 66%).
    - Expel Harm healing increased by 30%.

:::

:::

:::

:::

:::accordion
:::details Patch 12.0
- MONK
  
  - Spear Hand Strike interrupt duration increased to 5 seconds (was 3 seconds). Does not affect PvP combat.
- **Hero Talents**
  
  - Conduit of the Celestials New Talent: Path of the Falling Star – Celestial Conduit's damage is increased by 100% when striking a single target. Each additional target reduces this bonus by 20%.
  - Yu'lon's Knowledge has been redesigned – Now increases the damage of Rising Sun Kick by 15%.
  - Heart of the Jade Serpent no longer decreases the cooldown time of Flying Serpent Kick.
  - Celestial Conduit no longer splits its damage and now deals reduced damage beyond 5 targets.
  - Flight of the Red Crane has been removed.
- **Windwalker** 
  
  - Invoke Xuen, the White Tiger and Xuen's Bond moved from the Windwalker talent tree to Conduit of the Celestials hero talent tree.
  
  
  
  - Celestial Conduit damage reduced by 75% and healing reduced by 80%.
  - Celestial Conduit now overrides Xuen, the White Tiger when Xuen is cast.
  - Celestial Conduit has moved locations in the hero talent tree.
- **Master of Harmony**
  
  - New Talent: Harmonic Surge – Casting Thunder Focus Tea, Celestial Brew, or Celestial Infusion guarantees that your next 2 casts of Tiger Palm or Vivify will cause a Harmonic Surge, dealing Nature damage split between your target and other nearby enemies, and healing up to 5 injured allies.
  
  
  
  - New Talent: Potential Energy – Casting Keg Smash, Rising Sun Kick, or Rushing Wind Kick causes your next Tiger Palm or Vivify to release a Harmonic Surge.
  - Clarity of Purpose has been updated – Casting Enveloping Mist stores additional vitality (was Vivify or Sheilun's Gift).
- **Shado-Pan**
  
  - New Talent: Shado Over the Battlefield – Flurry Strikes deal Nature damage to all enemies within 6 yards, reduced beyond 8 targets.
  
  
  
  - New Talent: Stand Ready Brewmaster: Activating Invoke Niuzao, the Black Ox instantly grants 10 stacks of Flurry Strikes that trigger on your next attack at 70% effectiveness.
  - Windwalker: Activating Zenith instantly grants 10 stacks of Flurry Strikes that trigger on your next attack at 70% effectiveness.
  - New Talent: Weapons of the Wall Brewmaster: Invoke Niuzao, the Black Ox's stomp damage increased by 20%.
  - Windwalker: Zenith Stomp damage increased by 20%.
  - New Talent: Initiator's Edge – Movement speed is increased by 50% for the first 8 seconds of combat.
  - New Talent: Combat Stance – Roll's cooldown is reduced by 10%.
  - Flurry Strikes has been redesigned – Brewmaster: Your auto attacks have a chance to generate 1-2 Flurry Charges. When you cast Keg Smash, unleash all Flurry Charges, dealing Physical damage per charge.
  - Windwalker: Your auto attacks have a chance to generate 1-2 Flurry Charges. When you cast Fists of Fury, unleash all Flurry Charges, dealing Physical damage per charge.
  - Wisdom of the Wall has been redesigned – Brewmaster: Invoke Niuzao, the Black Ox causes Breath of Fire to launch 3 Flurry Strikes.
  - Windwalker: Zenith causes Rising Sun Kick and Spinning Crane Kick to launch 3 Flurry Strikes.
  - Veteran's Eye has been redesigned – Haste increased by 5%.
  - Against All Odds has been redesigned – Your Agility is increased by 4%.
  - Vigilant Watch no longer increases the damage of your next Flurry Strikes.
  - One Versus Many has been redesigned – Now causes auto attack critical strikes to grant double Flurry Charge stacks.
  - Efficient Training has been updated – Brewmaster: Now decreases the cooldown of Invoke Niuzao, the Black Ox by 25 seconds.
  - Windwalker: Now decreases the cooldown of Zenith by 10 seconds.
- Class
  
  - New Talent: Silent Sanctuary – While no enemies are within 15 yards, you heal every 3 seconds.
  
  
  
  - New Talent: Stillstep Coil – Leg Sweep applies Disable for 5 seconds when it ends.
  - New Talent: Serene Surge – After casting Enveloping Mist, your next Sheilun's Gift or Vivify becomes instant cast.
  - New Talent: Reinvigoration – After Detox successfully removes an effect from an ally, their movement speed is increased by 30% for 5 seconds.
  - New Talent: Chi Transfer – Touch of Death now heals you for 50% of its damage done.
  - Save Them All has been redesigned – Now increases your healing by up to 10% based on your target's health. Lower health allies are healed for more.
  - Diffuse Magic has been redesigned – Now causes activating Fortifying Brew to transfer all currently active harmful magical effects on you back to their original caster if possible.
  - Soothing Mist healing increased by 50%.
  - Vivacious Vivification no longer increases the healing of Vivify.
  - Fatal Touch no longer increases damage dealt.
  - Ferocity of Xuen is now a 2-point talent.
  - The following talents have been removed: Bounce Back
  - Chi Burst *(removed for Mistweaver and Windwalker only)*
  - Clash
  - Profound Rebuttal *(removed for Mistweaver only)*
  - Rising Sun Kick *(removed for Brewmaster only)*
  - Spear Hand Strike *(removed for Mistweaver only)*
  - Strength of Spirit *(removed for Mistweaver only)*
  - Vigorous Expulsion *(removed for Mistweaver only)*
- Windwalker
  
  - New Talent: Airborne Rhythm – Slicing Winds now generates 2 Chi when cast.
  
  
  
  - New Talent: Hurricane's Vault – Slicing Winds now costs 2 Chi to cast, but its damage is increased by 40%.
  - New Talent: Sharp Reflexes – Blackout Kick reduces the cooldown of Rising Sun Kick and Fists of Fury by 1 second.
  - New Talent: Crashing Fists – The duration of Fists of Fury is increased by 1 second.
  - New Talent: Combo Breaker – You have a 8% chance when you Tiger Palm to cause your next Blackout Kick to cost no Chi within 15 seconds.
  - New Talent: Zenith – Chi costs are reduced by 1, and Blackout Kick reduces the cooldown of affected abilities by an additional 1 second. Activating Zenith resets the remaining cooldown on Rising Sun Kick and grants 2 Chi.
  - New Talent: Harmonic Combo – Fists of Fury's Chi cost is reduced by 1, but its damage is reduced by 10%.
  - New Talent: Skyfire Heel – Rising Sun Kick's critical strike chance is increased by 4% for each nearby enemy, up to 5 enemies. 10% of Rising Sun Kick's damage splashes onto nearby enemies. Damage is reduced beyond 5 targets.
  - New Talent: Cyclone's Drift – You gain 10% more Haste from all sources.
  - New Talent: Echo Technique – Casting Strike of the Windlord and Whirling Dragon Punch grants Blackout Kick!.
  - New Talent: Obsidian Spiral – During Weapons of Order, Blackout Kick generates 1 Chi.
  - New Talent: Sunfire Spiral – Rising Sun Kick gains 20% additional effectiveness from Mastery: Combo Strikes.
  - New Talent: Weapon of Wind – Your damage during Zenith is increased by 10%.
  - New Talent: Martial Agility – Your melee attack speed is increased by 30%. This bonus is increased to 60% during Zenith.
  - New Talent: Tiger Fang – Your auto attack critical strike chance is increased by 15%.
  - New Talent: Zenith Stomp – Activating Zenith causes you to release a powerful stomp, dealing significant Nature damage to nearby enemies, reduced beyond 5 targets.
  - New Talent: Universal Energy – Magical damage increased by 15%.
  - New Talent: Rushing Wind Kick – After consuming Blackout Kick!, Rising Sun Kick has a 40% chance to become Rushing Wind Kick. Rushing Wind Kick: Kick up a powerful gust of wind, dealing Nature damage in a 25 yard cone to enemies in front of you, split evenly among them. Damage is increased by 6% for each target hit, up to 30%.
  - Dual Threat has been redesigned – Now has a 30% chance to kick your target and damage increased by 300%, but no longer increases damage by 5% for 5 seconds when activated.
  - Drinking Horn Cover has been redesigned – Now increases the duration of Weapons of Order by 5 seconds.
  - Spiritual Focus has been redesigned – Now decreases the cooldown of Weapons of Order by 20 seconds.
  - Xuen's Battlegear has been redesigned – Now increases the critical strike rate of Rising Sun Kick by 20% and decreases the cooldown of Fists of Fury by 4 seconds when Rising Sun Kick critically strikes.
  - Meridian Strikes has been redesigned – Now decreases the cooldown of Touch of Death by 45 seconds and increases Touch of Death's damage by 15%.
  - Jade Ignition has been redesigned – No longer stacks an aura to increase Chi Explosion's damage.
  - Auto-attack damage increased by 200%.
  - All spell and ability damage reduced by 13%.
  - Spinning Crane Kick damage increased 80%.
  - Crane Vortex now increases the damage of Spinning Crane Kick by 15% (was 30%).
  - Dance of Chi-Ji no longer increases the damage of Spinning Crane Kick.
  - Dance of Chi-Ji activation chance reduced by 33%.
  - Fists of Fury damage increased 30%.
  - Rising Sun Kick damage increased 30%.
  - Blackout Kick damage increased by 300%.
  - Slicing Winds damage reduced by 50%.
  - Jadefire Stomp now increases movement speed for 3 seconds after casting.
  - Singularly Focused Jade now increases Jadefire Stomp's damage by 300% (was 500%).
  - Touch of the Tiger now increases the damage of Tiger Palm by 15% (was 40%).
  - Jadefire Fists now triggers after every Fists of Fury cast.
  - Thunderfist, Revolving Whirl, and Knowledge of the Broken Temple now triggers from both Whirling Dragon Punch and Strike of the Windlord.
  - Communion of Wind now reduces the cooldown of Strike of the Windlord and Whirling Dragon Punch by 5 seconds and increases their damage by 20%.
  - Whirling Dragon Punch cooldown is now 35 seconds and no longer scales with Haste.
  - Teachings of the Monastery Blackout Kicks are now cast at 25% effectiveness.
  - Memory of the Monastery no longer increases Haste and instead increases the damage of Tiger Palm.
  - Combat Wisdom no longer increases the damage of Tiger Palm.
  - Mastery: Combo Strikes now displays a tracking buff after each cast that displays your previously cast spell.
  - Ferociousness and Hardened Soles are now 2-point talents.
  - Combat Assistant's rotation has been updated.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Acclamation
    - Chi Wave
    - Courageous Impulse
    - Fury of Xuen
    - Gale Force
    - Invoke Xuen, the White Tiger *(moved to the Conduit of the Celestials hero talent tree)*
    - Invoker's Delight
    - Jadefire Harmony
    - Last Emperor's Capacitor
    - Martial Mixture
    - Ordered Elements
    - Rushing Jade Wind
    - Storm, Earth, and Fire
    - Summon White Tiger Statue
    - Transfer the Power
    - Xuen's Bond *(moved to the Conduit of the Celestials hero talent tree)*

:::

:::

## FAQ

:::accordion
:::details Q: Why does my [[spell:196740]] drop?
**A:** You are pressing the same ability twice in a row. Common scenarios where this can happen is if your [[spell:100780]] gets parried and you press two of them to gain Chi.

:::

:::

---

### Credits

Written By: **Swag**

:::changelog 更新记录
**2026-08-07** Updated for patch 12.1

**2026-05-01** Updated for patch 12.0.5

**2026-02-24** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2

**2025-06-18** Updated for patch 11.1.7

**2025-04-22** Updated for patch 11.1.5

**2025-02-24** Updated for patch 11.0

**2024-12-17** Updated for patch 11.0.7

**2024-10-24** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
