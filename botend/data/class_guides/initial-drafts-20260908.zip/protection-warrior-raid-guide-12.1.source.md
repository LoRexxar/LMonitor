Welcome to the **Protection Warrior** raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 5/5 · Excellent

AoE · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Protection Warrior** Raid Best in Slot
```json
{
  "source_code": "JkpAomEA3_fABAGJEIACBAw74OggC4UABk-FEAQEBAgCtOgCtOggCwYNYFQAeRSBjgQN5OQBjAwYBIDCFAQCB8AKYFgvXQQAjfBBAiQB1glgCgVAB8FJEIAKFAwo7OQf1IYNWYDG2EwFgagJEEABhOgA4EAAPk7A2-CD2cbNbWCAjAGMZJySBEgChOAgAFAAX16ARsBB2WTFdwhTVPAAIEAACGgogIW2DIICBAw94mgoU4UABAYLEojEAgQXfQQCwwAWBEwXdwABdfRGYQQsXUg1A0TCHzSAkeBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271456]] | [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240906]] · [[item:240906]] |
| 肩部 | [[item:271454]] | [[item:244021]] |
| 胸部 | [[item:271459]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240906]] |
| 腿部 | [[item:271455]] | [[item:244643]] |
| 脚部 | [[item:237828]] | [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240983]] |
| 手部 | [[item:251214]] |  |
| 戒指一 | [[item:252258]] | [[item:240906]] · [[item:243959]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243959]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:268196]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Protection Warrior**, you have access to Phalanx, which gives you 5% damage reduction at basically 100% uptime and a bunch of damage bonuses on [[talent:112205@FAwAYdhAjnqBEMA]] and [[spell:23922]].

**Rank 2** increases the damage of [[talent:112205@FAwAYdhAjnqBEMA]] and Phalanx by 10% per point. While **Rank 3** increases [[spell:23922]] damage by 10% and crit chance by 20%. Enemies hit by [[spell:1269311]] deal 5% reduced damage to you for 8 sec.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-protwarrior-mxr.webp>)

Phalanx

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:132879]]
    
    - Got reworked from an active ability to a passive bonus to your [[talent:112156]].
- **Class Tree**
  
  - [[talent:134031@AJQABA]]
    
    - Can provide a massive survivability boost if you are taking frequent big hits and utilizing your [[talent:114644]].
    - The offensive part of the talent provides only a very small damage increase, making this talent often a damage loss to pick compared to alternatives.
  
  
  
  - [[talent:136627]]
    
    - Now additionally increases the movement speed of allies within 12y(or 24y) by 30% for 4 seconds!
  - [[talent:134033]]
    
    - Improves all your shout abilities.
- **Removed**
  
  - [[spell:384318]]
  
  
  
  - [[spell:383762]]

## Hero Talents

- [[talent:123388]] buffs your baseline rotation and brings in more rage without adding an extra ability.
- [[talent:123391]] has higher burst damage than [[talent:123388]] but comes at the cost of less defensive value and a worse playstyle.
- [[talent:123388]] is the recommended choice currently as it outperforms [[talent:123391]] in all scenarios.

### [[talent:123388]]

- [[talent:117400]]
  
  - Your [[talent:117400]] deal damage, and have a chance to proc [[talent:117404]].
- [[talent:117404]]
  
  - A low chance on [[talent:117400]] to get a significant [[talent:112261]] buff, and temporarily remove the cooldown of the ability.
- [[talent:117413]]
  
  - [[talent:112205]] is with this trait a better way to apply [[talent:112298]] and enable cleave, compared to [[spell:190411]].
  - With [[talent:112205]] being so strong, you barely lose single-target damage while cleaving, which is something [[talent:123390]] struggles with in comparison to [[talent:123392]].
- [[talent:117382]]
  
  - Transforms your [[talent:112205]] into [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]], dealing Stormstrike damage that ignores armor.
  - Has a chance to proc from [[talent:112261]].
- [[talent:117402]]
  
  - A reliable way to get [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]].
- [[talent:136070@AJQACA]]
  
  - Replaced a Class Tree talent, raises the priority of [[talent:112205]] during [[talent:112305@AJQACA]].
- [[talent:136068]]
  
  - You can extend [[talent:112285@AJQABA]] by using [[spell:435222]]. You can have [[talent:112285@AJQABA]] active for a majority of the time by prioritizing [[spell:435222]]  usage.

### [[talent:123391]]

- [[talent:117415]]
  
  - Gets significantly buffed by [[talent:117416]] damage wise.
  - Can be used in niche scenarios to immune stuns and knockbacks or as another small defensive.
- [[talent:117396]], [[talent:117393]] and [[talent:117408]]
- With all of these **Hero** **Talents** combined your [[talent:112152]] becomes your highest damage ability by far during AoE.
- [[talent:117390]]
  
  - [[talent:117415]] gets its cooldown reduced, significantly increased when you're pressing [[talent:112152]] a lot during AoE.
- [[talent:136073]]
  
  - Applies [[talent:135940]] to all targets hit by [[talent:117415]].
- [[talent:136072@AJQA]]
  
  - Further emphasizes [[talent:123393]] bleed damage that was already increased from [[talent:119856@AJQA]].
- [[talent:136071@AJQA]]
  
  - Increases your burst damage significantly with [[talent:117415]].

## Talents

### Standard [[talent:123388]] Raid Build

:::talents **Protection Warrior** Standard [[talent:123388]] Raid Build
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZmZMzMzMmNzMLDjxIzMzMbmZmZGmxMDAAAAWGDwMGgB2glFjGzAYWiZ2gZYGGAgZGAAAGD",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZmZMzMzMmNzMLDjxIzMzMbmZmZGmxMDAAAAWGDwMGgB2glFjGzAYWiZ2gZYGGAgZGAAAGD"
}
```
:::

#### When to use this spec

This is the default loadout going into any boss unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the **Raids** section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:132885]]
  
  - This talent makes it important to stay in the vicinity of your teammates as much as possible to gain the maximum benefit.
- [[talent:112170]]
  
  - Gives your [[talent:112159]] a big offensive component, pair it up with your other offensive cooldowns.
- [[talent:132884]]
  
  - Free [[spell:5308]] which is great for damage and also to get some globals that don't cost Rage.

##### Class Tree

- [[talent:112249]]
  
  - This is an incredible boost to your mobility, it gives you 2 charges of [[spell:100]].
- [[talent:112205]]
  
  - When talented into [[talent:135597]] your [[talent:112205]] automatically applies [[talent:135597]] to 5 enemies meaning that you never need to press [[talent:135597]] manually.
- [[talent:112219]]
  
  - Gives you a huge movement speed boost after [[talent:112208]].
- [[talent:112186]]
  
  - A very powerful external defensive in niche scenarios. Most of the time you should use it for mobility or to aid your co-tank during periods of heavy damage intake.
- [[talent:134032@AJQACA]]
  
  - Makes it very important to never overcap on Rage and also to use [[talent:112305@AJQACA]] on cooldown when possible to maximize the cooldown reduction.

##### Hero Talents

- [[talent:117395]]
  
  - Default pick as [[talent:118836]] is not very useful.
- [[talent:118834]]
  
  - Very nice boost to Rage generation which is great for both defense and offense.
- [[talent:117394]]
  
  - Simply outperforms the other option as more [[talent:117400]] synergises well with [[talent:117404]].

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Free [[spell:5302]] deal 15% additional damage and cause your next [[spell:23922]] to deal 20% additional damage.
- **4-Set:** [[spell:228920]] and your free [[spell:5302]] cause all targets to bleed for X damage over 12 sec. [[spell:228920]] cooldown is reduced by 30 seconds.

#### [[talent:123388]]

##### Opener

- The goal of the opener is to get [[spell:2565]] active as soon as possible to avoid the possibility of getting one shot after [[spell:100]] in while also getting all your offensive cooldowns rolling.

- Below, you can see an example of how your opener might look, depending on when you get your first [[spell:437118@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]] proc among other factors.

:::rotation [[talent:123388]] **Protection Warrior** Opener in Raid
```json
{
  "source_code": "IkcAMcgQkBQBBAvXCYDpBAQACUgCAIAiEAAAAIkFkaQRCwwBSFQOsEAOEHwRAAAWXIQtUAgB4Jgj7JwpJOAjRYAJNcwJNcQACAAACIXXAAAAC53qGAAAEAlcvNGgDIgcdBAABIE-nLAAAIQAM4LVAI7gAA"
}
```
1. [[spell:100]]
2. [[spell:107574]]  [[spell:2565]]
3. [[spell:1160]]
4. [[spell:435222]]
5. [[spell:23922]]
6. [[spell:437118]] Proc 
   
   1. [[spell:23922]]  [[spell:190456]]
   2. [[spell:23922]]
   3. [[spell:435222]]
7. [[spell:435222]]
:::

##### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Cast [[spell:190456]] as your main Rage spender.
2. Maintain [[spell:2565]] at 100% uptime.
3. Cast [[talent:112304]] on cooldown if talented.
4. Cast [[talent:112305@AJQACA]] on cooldown.
5. Cast [[spell:1160]] on cooldown.
6. Cast [[spell:435222@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]] if you are at 2 stacks.
7. Cast [[spell:23922]] if [[spell:437118@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]] is active.
8. Cast [[spell:435222@FJADHIVA5wSA4QcAHBAAYdhA1SBAGgnAOunAnm4AMGhBk0wBn0wBBIA]].
9. Cast [[spell:23922]] on cooldown.
10. Cast[[spell:6572]] on AoE.
11. Cast [[spell:163201]] on 2 or less targets.

#### [[talent:123391]]

##### Opener

- The goal of the opener is to get [[spell:2565]] active as soon as possible to avoid the possibility of getting one shot after [[spell:100]] in while also getting all your offensive cooldowns rolling.

- Below, you can see an example of how your opener might look, depending on proc and other factors.

:::rotation [[talent:123391]] **Protection Warrior** Opener in Raid
```json
{
  "source_code": "IMEDIIEZAUQAkJgNkGAABIQBKAgAISAAAEgQ4fuAAAgAgOeBVwAWy1FAAAgQGiqBAAAAAIgcdBAAAIEoDaA"
}
```
1. [[spell:100]]
2. [[spell:107574]]  [[spell:2565]]
3. [[spell:1160]]  [[spell:190456]]
4. [[spell:385952]]  [[spell:190456]]
5. [[spell:23922]]
6. [[spell:436358]]
7. [[spell:23922]]
8. [[spell:426912]]
:::

##### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Cast [[spell:190456]] as your main Rage spender.
2. Maintain [[spell:2565]] at 100% uptime.
3. Cast [[talent:112304]] on cooldown.
4. Cast [[talent:112305@AJQACA]] on cooldown.
5. Cast [[spell:1160]] on cooldown.
6. Cast [[spell:385952]] on cooldown.
7. Cast [[spell:23922]] on cooldown.
8. Cast [[talent:117415]] on cooldown.
9. Cast [[spell:426912]] on cooldown.
10. Cast[[spell:6572]] on AoE.
11. Cast [[spell:163201]] on 2 or less targets.

### Defensive Stance vs. Battle Stance

- When swapping stances there are some factors you need to keep in mind:
  
  - [[spell:386208]] provides you with a 20% flat damage reduction and an additional 5% magic damage reduction.
  - [[spell:386164]] provides you with a 3% critical chance and a 10% reduction on slow and cc effects.
- Stay in [[spell:386208]] at all times when taking any damage since the 3% crit chance is just not worth it losing 20% or 25% damage reduction.
  
  - If you are not tanking anything and don't have any debuffs that do heavy damage to you, swapping to [[spell:386164]] is totally fine and provides a small DPS gain.

### Defensive Cooldowns

- [[spell:1160]] 
  
  - Most of the time you should use this on cooldown as it's a DPS increase when talented into [[spell:202743]]. You also have [[spell:335229]] that heavily reduces the cooldown which further incentivizes using it as much as possible.
- [[spell:871]]
  
  - This should be your first go-to when you need a big defensive as this spell also gets heavily reduced cooldown from [[spell:152278]] & [[spell:384072]] if talented.
- [[spell:202168]]
  
  - Not necessarily a defensive cooldown but a very nice self-heal tool. Just press it whenever you feel like a small heal would be useful.

### Offensive Cooldowns

- [[spell:385952]] 
  
  - Use on cooldown preferably while under the effect of [[talent:112305@AJQACA]] and [[spell:202743]].
- [[talent:112304]] 
  
  - Usually lines up with every 2nd [[talent:112305@AJQACA]].
- [[talent:112305@AJQACA]]
  
  - Use on cooldown as much as possible, extra important because of cooldown reduction from [[spell:152278]].

## Deep Dive

### Spell Reflection

- [[spell:23920]] is highly complex in the sense that it works differently for every mechanic and is often times the difference between **Protection Warrior** being very strong or mediocre.
- There is no one way to know at first glance if a spell cast on you is reflectable or not outside of just knowing beforehand through knowledge. 
  
  - To acquire this knowledge I highly recommend this [Spell Reflect Guide](<https://maxroll.gg/wow/resources/spell-reflect-guide>).

- Some important notes about [[spell:23920]]:
  
  - A spell does not always have to target you to be reflectable.
  - [[spell:23920]] provides 20% magic damage taken reduction for 5 seconds.
    
    - If a spell gets reflected and consumes the buff you still keep the 20% magic damage reduction for the full 5 seconds.

### Managing Ignore Pain

- [[spell:190456]] is your primary Rage spender together with [[spell:6572]], one is full damage where the other one is full defensive value.
- Juggling both is your main job when it comes to how you spend your rage.
  
  - [[spell:190456]] as the ability is different from all the others it does not occur a GCD when pressed but has its own small internal GCD, making it so you can press it while normally playing your rotation.
  - Where on the other hand [[spell:6572]] is a normal spender and also a GCD.
- As a rule of thumb, you want to always use [[spell:190456]] when reaching your Rage cap to not overcap and while taking any damage to just become tankier.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

### Nek'Zali

:::talents **Protection Warrior Raid Nek'Zali**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZmZMzMzMmNzMLDjxIzMzMbmZmZGmxMDAAAAWGDwMGgB2glFjGzAYWiZ2gZYGGAgZGAAAGD",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZmZMzMzMmNzMLDjxIzMzMbmZmZGmxMDAAAAWGDwMGgB2glFjGzAYWiZ2gZYGGAgZGAAAGD"
}
```
:::

#### Tank mechanics

- The main tank mechanic of this fight is Hollowing Strikes - a debuff that the boss applies with each melee strike, as well as with [[spell:1284103]].
- During [[spell:1284103]], the boss sends spectral echoes towards the active tank, applying extra stacks of Hollowing Strikes. These echoes burst on first impact with any player, dealing reduced raid 
  
  - When targeted by this mechanic, move out of the raid and make sure no one is standing between you and the boss so they don't trigger the echoes too early. Otherwise, they deal too much damage to the raid.
  - Taunt swap after each cast of [[spell:1284103]].
- Apart from that, the boss spawns waves of Restless Amani - make sure to move the boss next to them to allow for better cleave.
- During the intermission, the active tank gets targeted by a group soak - [[spell:1289855]]. Try to put it on top of as many Restless Amani corpses as possible to burn them with [[spell:1289875]] to prevent them from awakening again.

### Entombed Sentinels

:::talents **Protection Warrior Raid Entombed Sentinels**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZmZzMzMzYmxMDAAAAWGDwMGgB2glFjGzAY2iZ2gZYGmBAMzAAAwY",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZmZzMzMzYmxMDAAAAWGDwMGgB2glFjGzAY2iZ2gZYGmBAMzAAAwY"
}
```
:::

#### Tank mechanics

- The bosses always have to be separated by at least 40 yards due to [[spell:1290189]]. At the start of each phase, split the bosses apart by moving them to different sides of the room.
- [[spell:1284458]] and [[spell:1284487]] are the stacking tank debuffs of each of the bosses. Make sure to taunt swap on the bosses each time they meet in the middle of the room during [[spell:1284588]] to reset your stacks.
  
  - [[spell:1284487]] additionally creates a large pool of blood upon expiration. Make sure to drop it off at the edges of the room if possible.
- Don't tank Breath of Ula'tek too close to the existing blood puddles so the [[spell:1284251]] doesn't spawn in the pool and melees can safely attack it.

### Lost Explorers

:::talents **Protection Warrior Raid Lost Explorers**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZmZZZmZmZwYmBAAAALzAYGDwAbwyiRjZAMbxMbwMMDzAAmZAAwAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZmZZZmZmZwYmBAAAALzAYGDwAbwyiRjZAMbxMbwMMDzAAmZAAwAjBA"
}
```
:::

#### Tank mechanics

- All three bosses cannot be positioned within 30 yards of each other due to [[spell:1297645]] - always keep one of the bosses away from the other 2.
- **Trader Gebbo** just wanders around the room and doesn't follow or attack its threat target. It also doesn't have any tank mechanics.
- **Scrollsage Iku** casts [[spell:1295854]] at its current target - a series of ice shards, each doing magic damage and increasing damage taken from the next shard for 80 seconds.
- **First Mate Nama** applies [[spell:1291929]] with each attack to its target, increasing physical damage done to that target for 30 seconds.
- The job of the tanks on this fight is to swap between **Scollsage Iku** and **First Mate Nama**, never letting [[spell:1295854]] be casted at the same target twice and resetting [[spell:1291929]] as often as possible, while always keeping one of the bosses far enough to prevent [[spell:1297645]] from being applied.

### Vashnik

:::talents **Protection Warrior Raid Vashnik**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZmZZZmZmZwYmBAAAALzAYGDwAbwyiRjZAMbxMbwMMDzAAmZAAwAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZmZZZmZmZwYmBAAAALzAYGDwAbwyiRjZAMbxMbwMMDzAAmZAAwAjBA"
}
```
:::

#### Tank mechanics

- There are 3 fountains placed on the sides of the room: Fountain of Blood, Fire, and Shadow. The boss activates the two closest ones with [[spell:1283164]] throughout the fight, gaining their powers and spawning some adds.
  
  - Each fountain activation empowers the next activation for 1.5 minutes.
  
  
  
  - Your job as a tank is to never let the boss activate the same two fountains in a row by moving the boss to the next fountain before each [[spell:1283164]] cast.
  - Make sure to position the boss on top of the adds coming from the fountain for better cleave. However, be careful with quickly killing all the fire adds, as they apply stacking [[spell:1285979]] when they die.
- **Vashnik's** tank hit is [[spell:1280935]], taunt swap after each cast.

### Sszorak

:::talents **Protection Warrior Raid Sszorak**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBk1yAAAzMDzMzMzYWMmlZMGjGmZssMzMzMMjZGAAAAsMGgZMADsBLLGNmBwsFzsBzYmBDAYmBAgBMGA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBk1yAAAzMDzMzMzYWMmlZMGjGmZssMzMzMMjZGAAAAsMGgZMADsBLLGNmBwsFzsBzYmBDAYmBAgBMGA"
}
```
:::

#### Fight mechanics

- [[spell:1277025]] is a combination of tank frontals consisting of 2 [[spell:1277002]], 2 [[spell:1277027]], and one [[spell:1287072]], cast in a random order.
  
  - [[spell:1277002]] is a frontal cone that deals heavy physical damage and follows the active tank. Make sure to aim it **away from the raid**.
  - [[spell:1277027]] is a frontal cone that applies a heavy magic DoT, which is reduced by the number of people hit by the cone. Make sure this ability is aimed into one half of the raid, so people can soak it.
  - [[spell:1287072]] spawns a bunch of tornadoes around the boss and sends them outwards at the end of the cast. Make sure you're not under the boss when this happens and dodge the tornadoes.
  - In heroic and mythic difficulties, the boss casts these in a random order. Since each frontal cone applies a damage taken increase from that ability, make sure that one tank never takes 2 of the same abilities. Keep in mind that you can taunt during the cast so the boss aims the frontal cone at you instead.
- Each cast of [[spell:1306120]] spawns [[spell:1305998]] puddles around the boss. Make sure to move the boss to an edge of the room, ideally opposite the [[spell:1285732]] spawn, so that the puddles get blown off the edge of the room by the winds.
- Apart from that, **Sszorak** applies a stack of [[spell:1282869]] with each melee attack, increasing physical damage taken by the target. Taunt swapping on each [[spell:1277025]] combo is enough to reset the stacks.

### Twin Fangs

:::talents **Protection Warrior Raid Twin Fangs**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxoxMmxyMzMzwwMDAAAAWGDwMGgB2glFjGzAYWiZ2gZYGmZBAmZAAwAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxoxMmxyMzMzwwMDAAAAWGDwMGgB2glFjGzAYWiZ2gZYGmZBAmZAAwAjBA"
}
```
:::

#### General mechanics

- The entire fight revolves around managing [[spell:1290336]] stacks
  
  - [[spell:1291404]], [[spell:1291478]], getting hit by poison waves, or soaking [[spell:1289201]] applies a stack of [[spell:1290336]].
  - Reaching 10 stacks in Heroic or 9 in Mythic difficulties immediately kills you.
  - It is crucial to dodge as many poison waves as possible while managing how many [[spell:1289201]] you soak to prevent reaching maximum stacks of this debuff.

#### Tank mechanics

- Being outside of melee range of the boss that you're actively tanking causes it to cast [[spell:1295107]] or [[spell:1295113]], so make sure to never leave melee or use a big personal if you ever find yourself far from the boss.
- **Vexhul's** tank ability is [[spell:1289192]], which deals nature damage and pushes you back for 5 seconds.
  
  - It also spawns [[spell:1289201]] around you. These need to be soaked by players before they explode to prevent everyone from getting an [[spell:1290336]] stack.
  - Each hit applies [[spell:1310360]], so taunt swap between every [[spell:1289192]] cast.
  - Be aware of the pushback, especially when the poison waves are coming!
- **Ithraz** casts [[spell:1288538]], pushing back players close to the boss and spawning 3 soak zones.
  
  - Each zone deals heavy physical damage and increases the damage taken from the next zone by 33%. If it is left unsoaked, it deals raid-wide damage and knocks everyone away. Make sure to taunt swap between each set of [[spell:1288538]] to reset the stacks of the damage increase.
  
  
  
  - The zones spawn in a random order and need to be soaked in the same order that they spawned. Pay attention to the spawns and memorize the spawn order when this ability is happening. The boss also shortly faces towards the zone it's going to trigger next, so you can use that direction if you can't remember the spawn order.
  - Each second [[spell:1288538]] cast overlaps with poison waves coming - make sure you're not getting hit by waves while soaking the [[spell:1288538]].
  - Watch out for the pushback at the start of this mechanic, as it can push you into an incoming wave or a [[spell:1289201]].

### Coiled Altar

:::talents **Protection Warrior Raid Coiled Altar**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZGLLzMzMDGzMAAAAYZMAzYAGYDWWMaMDgZJmZDmxMDGAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZGLLzMzMDGzMAAAAYZMAzYAGYDWWMaMDgZJmZDmxMDGAwMDAAzAjBA"
}
```
:::

#### Phase 1

- Only **Zul'jan** is active during this phase.
- He casts [[spell:1299960]], which spawns multiple [[spell:1282403]] orbs during this phase. They deal pulsing raid-wide AOE while they're active, and can be picked up and moved by players running into them.
- [[spell:1299684]] is a frontal cone aimed at the active tank that deals physical damage and destroys any [[spell:1282403]] it hits.
  
  - It also increases damage taken by the next [[spell:1299684]] by 200%, so make sure to taunt swap after every cast.
- The goal of this phase is for the raid to group up the [[spell:1282403]] orbs so they can then be destroyed by [[spell:1299684]].
- Additionally, each cast of [[spell:1282487]] empowers the next 23 melees of the boss with [[spell:1300322]], dealing extra nature damage to the tank. 
  
  - Make sure to frontload defensives while the boss has stacks of [[spell:1300322]].

#### Phase 2

- Only **Hex Lord Malacrass** is active during this phase.
- He casts [[spell:1285640]], which mind-controls selected players, and spawns 2 [[spell:1285842]] per player when the mind control is broken.
  
  - The Manifestations fixate on random players, moving towards them, unless the fixated player looks back at the Manifestation.
- Similar to [[spell:1299684]] in Phase 1, [[spell:1286620]] is a frontal cone aimed at the active tank that deals shadow damage and destroys any [[spell:1285842]] it hits.
  
  - It also increases damage taken by the next [[spell:1286620]] by 200%, so make sure to taunt swap after every cast.
  - Additionally, it applies 3 stacks of [[spell:1286837]], which spawn a Soul Fragment per stack that needs to be picked up in order to remove the stack. If the stacks are not cleared before the debuff expires, the affected player immediately dies.
  - It is important to pay extra attention to finding and collecting all Soul Fragments quickly after each tank frontal.
- Getting hit by a [[spell:1286895]] also applies 3 stacks of [[spell:1286837]]. Don't let it catch you off guard!

#### Intermission

- **Malacrass** takes 100% extra damage while casting [[spell:1287685]]. Make sure to save your offensive cooldowns for this.
- Don't let any Fragments of Malacrass reach the boss by soaking them to prevent them from healing the boss.
  
  - Soaking each fragment deals raid-wide AOE damage, so don't soak them too quickly to give your healers some time to react to the incoming damage.

#### Phase 3

- During this phase, both **Zul'jan** and **Malacrass** are active, combining their abilities from Phases 1 and 2.
- Both [[spell:1299960]] and [[spell:1285640]] happen in this phase, meaning both [[spell:1282403]] and the [[spell:1285842]] need to be cleared by the tank frontal.
- The tank frontal cone of this phase is [[spell:1307279]], which deals shadow damage, destroys any [[spell:1282403]] and [[spell:1285842]] hit by it, and applies 3 stacks of [[spell:1286837]].
  
  - Don't forget to collect your Soul Fragments and taunt swap after each cone!
- [[spell:1298381]] is the empowered verision of [[spell:1282487]] from phase 1.
  
  - In this phase, the empowered melee attacks additionally apply a **stacking** shadow DOT. Use big defensives when reaching high stacks.

### Ula'tek

:::talents **Protection Warrior Raid Ula'tek**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZGLLzMzMDGzMAAAAYZGAzYAGYDWWMaMDgZJmZDmxMDGAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZGLLzMzMDGzMAAAAYZGAzYAGYDWWMaMDgZJmZDmxMDGAwMDAAzAjBA"
}
```
:::

### Nymrissa Wavecaller

:::talents **Protection Warrior Raid Nymrissa Wavecaller**
```json
{
  "source_code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZGLLzMzMDGzMAAAAYZMAzYAGYDWWMaMDgZJmZDmxMDGAwMDAAzAjBA",
  "code": "CmEAYyB6EulQT7kdp2SXeCVBklBAAmZGzMzMzMmNzMLDjxohZGLLzMzMDGzMAAAAYZMAzYAGYDWWMaMDgZJmZDmxMDGAwMDAAzAjBA"
}
```
:::

#### General mechanics

- The boss targets random players with Chilling Frost, which drops Frost Orbs under their feet.
  
  - These orbs need to get soaked before they explode and wipe the raid.
  - Soaking an orb applies a stacking debuff that increases the damage taken from soaking Frost Orbs, so don't soak too many in one go unless you have big defensives.
  - Each orb soak also deals raid-wide AOE, so don't soak them too quickly to give your healers some time to react to the incoming damage.
- Occasionally, murlocs spawn from the water and start walking towards the bubble in the middle of the room.
  
  - Don't let them reach the bubble, and move the boss on top of them whenever possible to allow for better cleave.

#### Tank mechanics

- A tank-only mechanic of the fight is the Iceblade Flurry - a series of magic slashes, with each slash increasing the damage of the following ones.
  
  - Use a defensive for each cast and taunt swap after each one.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Protection Warrior**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Protection Warrior** Raid Stat Priorities
```json
{
  "source_code": "IoAJFQAJxACKBEgABA"
}
```
**力量 ＞ 急速 ＞ 精通 ＝ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
Avoidance is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

### Overall BiS

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271456@DgQAAkEAvj7IoAOF]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAkEAK06oQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271454@DgQAAkEA1k7IoAOF]] | Tier / Catalyst |
| Cloak | [[item:268253@BgQAAkEACKAWBA]] | The Coiled Altar |
| Chest | Convert [[item:268222@AgQAAIoAYFA]]  <br>into [[item:271459@DgQBAkEAJk7IoAYFgvXQ]] | Catalyst of The Coiled Altar |
| Wrist | [[item:237834@BCUAAkEAX16Y7LMYzt1sZJ2WDAjAGMZJySB]] | Crafting |
| Gloves | [[item:251214@BgQAAkEACKgTBA]] | Den of Nalorakk |
| Belt | [[item:268259@BiQAAkEAK06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:271878@AARAAIoAWYDWBA]]  <br>into [[item:271455@DgSBAkEAju70XNCWjF2ghNCKAWBYgJE]] | Catalyst of Ula'tek |
| Boots | [[item:237828@DgTAAkEAPk7Y7LMYzt1sZJAMCYwklILF]] | Crafting |
| Ring 1 | [[item:252258@DiQAAkEA3j7oQrjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:273792@DiQAAkEA3j7oQrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270173@BgQAAkEACKAWBA]] | The Coiled Altar |
| Trinket 2 | [[item:270175@BgQAAkEACKAWBA]] | Ula'tek |
| Weapon | [[item:268209@DgQAAkEA9k7IoAYF]] | The Coiled Altar |
| Shield | [[item:268196@BgQAAkEACKgTBA]] | The Lost Explorers |

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@AgQAAIoABFA]] | Murder Row |
| Neck | [[item:273781@AgQAAIoABFA]] | Altar of Fangs |
| Shoulder | [[item:251138@AgQAAIoABFA]] | Murder Row |
| Cloak | [[item:193763@AgQAAIoABFA]] | Ruby Life Pools |
| Chest | [[item:193753@AgQAAIoABFA]] | Ruby Life Pools |
| Wrist | [[item:251133@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:159413@AgQAAIoABFA]] | Kings' Rest |
| Belt | [[item:159418@AgQAAIoABFA]] | Kings' Rest |
| Legs | [[item:273776@AgQAAIoABFA]] | Altar of Fangs |
| Boots | [[item:159412@AgQAAIoABFA]] | Kings' Rest |
| Ring 1 | [[item:273792@AgQAAIoABFA]] | Altar of Fangs |
| Ring 2 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Trinket 1 | [[item:273796@AgQAAIoABFA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@AgQAAIoABFA]] | Murder Row |
| Weapon | [[item:251195@AgQAAIoABFA]] | The Blinding Vale |
| Shield | [[item:159664@AgQAAIoABFA]] | The Blinding Vale |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAIEACKgTBA]]  <br>[[item:270175@BgQAAIEACKAWBA]]  <br>[[item:270173@BgQAAIEACKAWBA]] |
| **A-Tier** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:158367@BgQAAIEACKgTBA]]  <br>[[item:270174@BgQAAIEACKgTBA]]  <br>[[item:270160@BgQAAIEACKgTBA]]  <br>[[item:250228@BgQAAIEACKgTBA]] |
| **B-Tier** | [[item:250243@BgQAAIEACKgTBA]]  <br>[[item:159618@BgQAAIEACKgTBA]]  <br>[[item:250229@BgQAAIEACKgTBA]]  <br>[[item:193762@BgQAAIEACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAIEACKgTBA]]  <br>[[item:270163@BgQAAIEACKgTBA]]  <br>[[item:273795@BgQAAIEACKgTBA]]  <br>[[item:250259@BgQAAIEACKgTBA]]  <br>[[item:250244@BgQAAIEACKgTBA]]  <br>[[item:193757@BgQAAIEACKgTBA]]  <br>[[item:270168@BgQAAIEACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAIEACKgTBA]]  <br>[[item:250238@BgQAAIEACKgTBA]]  <br>[[item:273797@BgQAAIEACKgTBA]] |

### Embellishments

- 2x [[item:240166]]
  
  - Proc that gives you primary stat, also gives a small buff to an ally.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334-344 on max item level, therefore it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Flask**
  
  - [[item:241326]]
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240906]]
  
  
  
  - [[item:240983]] *-- Unique*

### Enchantments

:::columns
:::column
| Head | [[item:243951@DAAAAkEAZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulders | [[item:244021]] |
| Chest | [[item:243977@BAAAAoQA]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:244643@BAAAAkE]] |
| Boots | [[item:243983@BAAAAkE]] |
| Ring 1 | [[item:243959]] |
| Ring 2 | [[item:243959]] |
| Weapon | [[item:243973@BAAAAkE]] |

:::

:::column
:::gear **Protection Warrior** Raid Enchantments
```json
{
  "source_code": "IQFZJBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwo7mAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244643]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy ‍[[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Protection Warrior** in Raids, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  - On top of that using Stoneform gives you 10% physical DR which can be used as a small extra 8 second personal when tanking.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
  - Maximum range of 100 yards.

### Recommendation

As tank picking a racial for damage is most of the times such a small gain that its not worth. If you care about min-maxing your DPS go with the highest DPS racial.

That being said the recommended race for raid tanks is for sure Dwarf the one use physical damage reduction and ability to self dispel when needed are insanely strong and should not be undervalued.

## Macros

Discover recommended macros for **Protection Warrior** for Raids and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:355]]* at your target or your mouseover (very handy to pick up mobs)

```wow-macro
#showtooltip Taunt
/cast [@mouseover,exists,harm][@target,exists,harm] Taunt
```

Boss 1 Taunt --- *Casts* [[spell:355]] on Boss1

```wow-macro
/cast [@boss1] Taunt
```

Boss 2 Taunt --- *Casts* [[spell:355]] on Boss2

```wow-macro
/cast [@boss2] Taunt
```

:::

:::details Mouseover Macros
**[[spell:100]]** *-- Charge your target unless your mouse is over another enemy, then it targets that enemy and charges it.*

```wow-macro
/target [@mouseover, harm, nodead]
/cast Charge
```

**[[spell:3411]]** *--- This macro makes you Intervene a friendly player your mouse is over.*

```wow-macro
/cast [@mouseover,help] Intervene
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Cursor Macros
**[[spell:228920]]**

```wow-macro
/cast [@cursor] Ravager
```

**[[spell:376079]]**

```wow-macro
/cast [@cursor] Champion's Spear
```

**[[spell:6544]]**

```wow-macro
/cast [@cursor] Heroic Leap
```

:::

:::details Recommended Macros
**[[spell:386208]] and [[spell:386164]]** *--- With this you can swap stances from 1 keybind.*

```wow-macro
/cast [stance:2] Defensive Stance; stance[:3] Battle Stance
```

**[[spell:3411]]** *--- This macro makes you Intervene a friendly player in the direction you are facing. It is less precise than a mouse over macro, but easier to use.*

```wow-macro
/targetfriendplayer
/cast Intervene
/targetlasttarget
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Protection Warrior**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/ProtmidnightraidUI-ezgif.com-png-to-webp-converter-1-1024x682.webp>)

**Protection Warrior** Interface in Raids

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI** -- Additional customization for the Cooldown Manager
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI. With EllesmereUI you can easily disable modules you don't want and only use it for the CDM in this case.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripts.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Warrior
  
  - Developers' notes: Rend is an iconic and core Warrior ability with a different relationship to each spec. Our approach to Rend in Midnight hasn't worked out as we hoped, so we're making changes to how each spec applies and interacts with Rend in Curse of Ula'tek.
  - The Rend ability is now exclusive to Arms, has returned to being a single-target ability, and its Rage cost is reduced to 10. Cleave will apply Rend to all targets if the Warrior knows Rend.
  - New Talent (Fury): Storm of Blood – Whirlwind applies Rend to all targets. Crashing Thunder causes Storm of Blood to also apply to Thunder Clap for Mountain Thane.
  - New Talent (Protection): Blood and Thunder – Thunder Clap applies Rend to all targets.
  - Thunder Clap no longer innately applies Rend if known.
  - Javelineer has a new icon.
  - **Hero Talents**
    
    - **[[talent:123391]]**
      
      - *Developers' notes: Demolish's variable cooldown has proven to be more frustrating than interesting, so we're changing it to align closely with Colossus Smash, enabling Arms Colossus Warriors to coordinate their use for maximum devastation.*
      - No Stranger to Pain has been updated – Damage prevented by each use of Ignore Pain increased by 30% (was 20%).
      - Dominance of the Colossus has been updated – Enemies damaged by Demolish deal 20% reduced damage to you for 10 seconds (was 10%) and no longer reduces the cooldown of Demolish.
      - Demolish cooldown reduced to 30 seconds (was 45 seconds).
    - **[[talent:123388]]**
      
      - *Developers' notes: Thunder Clap's base damage increased significantly in Midnight, causing overall Thunder Clap damage to rise significantly for Mountain Thane, which in turn devalued Thunder Blast. We're moving the Crashing Thunder damage bonus into Thunder Blast itself to keep Thunder Blast feeling special and powerful.*
      - Thunder Blast damage increased by 20%.
      - Crashing Thunder increases Thunder Clap damage by 10% (was 30%).
  - Protection
    
    - Devastating Focus has been updated – Now increases Revenge and Execute damage dealt to the target (was Revenge only).
    - Bloodborne has been updated – Now increases all Bleed damage (was only Rend and Deep Wounds).
    - Ravager has been updated –
      
      - Ravager damage increased by 50% and its duration is no longer reduced by Haste.
      - Ravager no longer increases Revenge and Thunder Clap damage while active. Ravager now causes all enemies it damages to take 50% increased damage from your Bleeds for 12 seconds. Duration reduced to 4 seconds with Whirling Blade.
      - *Developers' notes: Ravager is a unique ability and we want the Ravager itself and its positioning to be important, but the current design puts more emphasis on its value as an AOE damage amp rather than the Ravager itself. We're redesigning Ravager slightly to address this, as well as to increase Ravager's value in all combat situations.*
    - Revenge has been updated – Your successful dodges, parries, and auto-attacks have a chance to make your next Revenge cost no Rage (was only dodges and parries). Damage increased by 20%.
      
      - *Developers' notes: Protection’s free Revenge counter-attack mechanic has existed for a long time, and we love it, but we don’t love how wildly its frequency and impact vary depending on what content you are doing. In dungeons, Revenge! triggers very frequently, contributing to many buttons being highlighted at once and overwhelming the rotation, but in raids and solo content, Revenge! frequency is so low as to feel weak and exacerbate Rage starvation issues. Our goal here is to shrink the gap between these extremes and make sure Revenge! procs feel meaningful while not crowding your rotation.*
    - All ability damage increased by 11%.
    - Fueled by Violence heals you for 125% of Bleed damage dealt (was 110%).
    - Ignore Pain absorb amount increased by 25%.
    - Brutal Vitality adds 10% of damage dealt to Ignore Pain (was 8%).
    - Unyielding increases the damage reduction bonus of Defensive Stance by 6% (was 4%).
    - **Hero Talents**
      
      - **[[talent:123391]]**
        
        - Practiced Strikes has been updated – Shield Slam generates an additional 4 Rage (was 3).
        - Tide of Battle increases the damage of Revenge and Execute (was Revenge only).

:::

:::details Patch 12.0.1
- Warrior
  
  - Hero Talents
    
    - [[talent:123391]]
      
      - *Developers' notes: We want Demolish to feel satisfying to use even at low or no Colossal Might stacks, so we’re moving some of the Colossal Might damage into the ability’s baseline damage.*
      - Demolish damage increased by 65%.
      - Colossal Might increases damage of your next Demolish by 5% per stack (was 10%).
      - Protection
        
        - Practiced Strikes damage bonus increased to 15% (was 10%).
  
  
  
  - Protection
    
    - Ground Current damage increased by 150%.
    - Lightning Strike damage increased by 50%.
    - Thunder Blast damage reduced by 30%.

:::

:::details Patch 12.0
- Warrior
  
  - New Talent: Resonant Voice – The duration of your shouts is increased by 20%.
  - New Talent: Retaliation – When you take any damage from an enemy within melee range, you have a chance to strike that enemy for Physical damage.
  - New Talent: Stance Mastery – Your stances have additional effects.
    
    - Battle Stance: Increases the critical strike damage of your abilities by 3%.
    - Berserker Stance: Increases your auto-attack speed by 3%.
    - Defensive Stance: When an attack deals 20% or more of your maximum health in damage, that damage is reduced by 15%.
  - New Talent: Battlefield Commander – Your Shout abilities have additional effects.
    
    - Battle Shout: Grants you an additional 3% attack power.
    - Rallying Cry: Grants an additional 2% health and duration increased by 3 seconds.
    - Piercing Howl: Radius increased by 100%.
    - Berserker Shout: Radius increased by 100%.
    - Intimidating Shout: Cooldown reduced by 15 seconds.
  - New Talent: Anger Management – Every 20 Rage you spend reduces the remaining cooldown on Avatar, Colossus Smash, Recklessness, and Shield Wall by 1 second.
  - New Talent: Field Dressing – Healing received increased by 3% and all self-healing increased by an additional 10%.
  - New Talent: Fearless – Cooldown of Berserker Rage is reduced by 50% and Berserker Rage removes all movement speed-impairing effects.
  - New Talent: Javelineer – Range of your thrown abilities is increased by 5 yards. Damage dealt by Champion's Spear, Shattering Throw, and Wrecking Throw increased by 20%. Shattering Throw and Wrecking Throw silence non-players for 3 seconds.
  - New Arms and Fury Talent: Interpose – Run at high speed toward a target location near your allies, taking 30% of all damage dealt to allies within 3 yards for 8 seconds or until you take at least 20% of your max health in damage from this effect.
  - New Arms and Fury Talent: Rend – Lash out with your weapon, striking all targets within 8 yards for Physical damage and wounding them for additional Bleed damage over 15 seconds.
  - Champion's Spear has been redesigned – Throw a spear at the target location, chaining all enemies in the area to the spear's location and dealing Physical damage instantly and additional Physical damage over 6 seconds. While the spear is active, activating this ability will cause you to leap to the spear, slamming down to deal Physical damage to all targets. All damage dealt reduced beyond 5 targets. Generates 10 Rage.
  - Intimidating Shout now reduces the movement speed of all targets by 70% and causes all enemies other than your primary target in range to flee. Was previously 8 targets.
  - Rallying Cry has been updated – Health granted is increased by 50% when not in a raid.
  - Honed Reflexes now reduces cooldowns by 10% (was 5%) and has an additional effect – Successfully interrupting an enemy increases the damage you deal to them by 5% for 10 seconds.
  - Piercing Howl now also spurs all allies within 12 yards, increasing their movement speed by 30% for 4 seconds.
  - Barbaric Training now increases damage dealt by 10% and critical strike damage by 5% for Slam, Whirlwind, Thunder Clap, Raging Blow, and Revenge.
  - Shattering Throw and Wrecking Throw range reduced to 25 yards (was 30 yards).
  - Thunder Clap damage increased by 150% and applies Rend to all targets if talented.
  - Shield Slam damage increased by 140%.
  - Second Wind healing while you are below 35% health increased by 100%.
  - Crushing Force is now a 1-point talent.
  - Many talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Avatar *(moved to each specialization's talent tree)*
    - Berserker's Torment
    - Blademaster's Torment
    - Cacophonous Roar
    - Challenger's Might
    - Concussive Blows
    - Immovable Object
    - Menace
    - Piercing Challenge
    - Seismic Reverberation
    - Thunderous Roar
    - Thunderous Words
    - Titan's Torment
    - Unstoppable Force
    - Uproar
    - Warlord's Torment
- Mountain Thane
  
  - New Talent: Storm Surge – Avatar increases the damage of Thunder Clap by 50% and reduces its cooldown by 50%.
  - New Talent: Conductivity – Lightning Strike damage increased by 10% and critical strike damage increased by 10%.
  - New Talent: Capacitance –During Avatar Thunder Blast extends Avatar's duration by 2 seconds.
  - Thunder Blast damage increased by 150%.
- Colossus
  
  - New Talent: Decimator – Demolish's final strike applies Deep Wounds to all targets at 100% effectiveness.
  - New Talent: Cut to the Bone
    
    - Arms: Mortal Strike critical strikes increase your Rend and Deep Wounds damage by 25% for 8 seconds.
    - Protection: Shield Slam critical strikes increase your Rend and Deep Wounds damage by 25% for 8 seconds.
  - New Talent: Celeritous Conclusion
    
    - Arms: Demolish's final strike grants 10% Haste for 10 seconds and increases the critical strike chance of your next Mortal Strike by 100%.
    - Protection: Demolish's final strike grants 10% Haste for 10 seconds and increases the critical strike chance of your next Shield Slam by 100%.
  - Demolish now makes the Warrior immune to movement forces during the channel.
  - Tide of Battle's Colossal Might increases damage of Revenge by 3% per stack (was 7%).
  - One Against Many no longer affects Whirlwind.

- Protection
  
  - New Talent: Devastating Focus – You focus on the target struck by your Devastator, dealing 30% additional Revenge damage to them. Only one target can have your focus at a time.
  - Avatar moved to the Protection specialization tree and has been updated – Transform into a colossus, increasing all damage you deal by 20% and reducing all damage you take by 3% for 20 seconds.
  - Deep Wounds is now a talent (was learned at level 10) and has been redesigned – Execute inflicts Deep Wounds on the target, causing high damage over 6 seconds.
  - Last Stand has been redesigned – Activating Shield Wall increases your maximum health by 30% for 8 seconds and instantly heals you for that amount.
  - Ravager has been updated – Additional effect: Revenge and Thunder Clap deal 50% increased damage while Ravager is active. Ravager is now thrown at your target.
  - Auto-attack damage increased by 100%.
  - Devastator damage increased by 100%.
  - Devastate damage increased by 100%.
  - Shield Charge damage increased by 100%.
  - Tough as Nails damage increased by 100%.
  - Revenge damage increased by 200%.
  - Violent Outburst now only buffs your next Shield Slam (was Shield Slam and Thunder Clap).
  - Bloodsurge has a chance to generate 5 Rage every time Rend deals damage (was Deep Wounds).
  - Fueled By Violence now heals for Bleed damage from Rend and Deep Wounds.
  - Several talents has changed positions in the talent tree.
  - The following talents have been removed:
    
    - Anger Management *(moved to the class talent tree)*
    - Bolster
    - Red Right Hand
    - Rend *(moved to the class talent tree)*
    - Sweeping Revenge
    - Unnerving Focus

:::

:::

## FAQ

:::accordion
:::details Q: How do I not get tired from spamming [[spell:190456]] all the time?
A: I recommend binding [[spell:190456]] to something like Scroll Wheel.

:::

:::

---

### Credits

Written by: **Wolfdisco**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-10** Updated for patch 12.1

**2026-06-17** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-18** Updated for patch 12.0.1

**2026-01-15** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updatedor patch 11.2.5

**2025-07-22** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-20** Updated for patch 11.1

**2024-12-17** Updated for Patch 11.0.7

**2024-10-27** Updated for Patch 11.0.5

**2024-08-17** Updated for Patch 11.0.2

**2024-07-28** Guide Written for patch 11.0.



:::
