Welcome to the **Marksmanship Hunter** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**SINGLE-TARGET** · 4/5 · Strong

AOE · 4/5 · Strong

UTILITY · 3/5 · Average

SURVIVABILITY · 3/5 · Average

MOBILITY · 3/5 · Average



:::

:::

:::column
:::gear **Marksmanship Hunter** Raid Best in Slot
```json
{
  "source_code": "JApAwDk_Ac__AEAhkQggIUAAnk7AC06ACKgTBsbpDEQ6XQAAJEAAX16AC06AMWDWBEggkQgAIUAAXk7ACKAWBc8FEEwhkUgEEkQuFECPEYCBBU2uDQIIBAgHAPwJqGgTAAQBBQzt1sUABMIJEIACBAQo7WwYIEQyXUwDE8QuJ8AAoZWOAgRhkQAAIUAABkJMVHnABk9FEIICBAQ94GAYBUBDB4paCojEAgxXfQAAIMAABgKHFAQA2chABQVASAQAFUEEB09FEAQBMAEWBEwrXQgAIEAA_k7AMWDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271492]] | [[item:240898]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240898]] |
| 肩部 | [[item:271490]] | [[item:243991]] |
| 胸部 | [[item:271495]] | [[item:243977]] |
| 腰部 | [[item:244581]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 腿部 | [[item:271491]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271493]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268207]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Marksmanship Hunter**, you have access to Take Aim, which will significantly improve your [[spell:19434]] in various ways.

**Rank** **1** improves the damage by [[spell:257044]] and makes it reduce the current cooldown of [[spell:19434]].

**Rank 2** , after committing two points to it, increases your  Crit Damage by 10% and increasing the damage of the rest of your ranged abilities by 6%.

**Rank 3** adds [[spell:1301098]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-marksmanship-mxr.webp>)

Take Aim

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

#### Class Tree

- [[talent:136686]] / [[talent:136685]]
  
  - New choice node at the bottom of the Class Tree, giving you 3% passive damage reduction with [[talent:136685]] or a 15% damage reduction on use cooldown for yourself or someone else with [[talent:136686]].
- [[talent:136670]]
  
  - Previously only available for Pack Leader hero talent tree, it adds a [[spell:102793]] effect to [[talent:135711]].
- [[talent:126481@AJwABA]] + [[talent:126490]]
  
  - Added more cooldown reduction to [[spell:186265]].
- [[talent:135710]]
  
  - Better survivability than before.
- [[talent:135704]]
  
  - Makes [[talent:128413]] become a short 1 second AoE stun.
- [[talent:135713]]
  
  - Got moved from the Class Tree to the Spec Tree

#### Removed

- [[spell:191433]] + [[spell:462031]] + [[spell:186387]] 
  
  - All your available knocks have been removed from the game which is especially bad because you can no longer proc your own [[spell:109248]].
- [[spell:212431]]
  
  - Removed along with all its interactions, except for [[talent:128381]] still being in the game tied to [[spell:260243]].
- [[spell:342076]]
  
  - With this being removed and no replacement, [[spell:19434]] has a very long cast time in Midnight.

## Hero Talents

- Your two Hero Talent trees are [[talent:123346]] and [[talent:123345]].
- They both provide different defensive benefits that are important to your survivability and should be taken into account, with [[talent:123346]] being more useful defensively in general.
- [[talent:123345]] currently performs better in all PvE content and [[talent:123346]] will not be recommended in this guide.

:::tabs
:::tab [[talent:123345]]
- Replaces [[spell:1219616]] for [[spell:1253601@FJAC4chAJunA8OvAA0wBB0wB8TpEgwpEs3yEDEA]], with multiple other talents increasing its capabilities.
- Transforms [[spell:288613]] into [[talent:136065@AJwABA]] after using it.
- Increases your maximum Focus through [[talent:117568@AJwABA]].
- Multiple talents altering almost every damage dealing part of your kit.
- [[talent:123345]] also grants you [[talent:117586]], giving you some extra survivability through absorbs.

:::

:::tab [[talent:123346]]
- This hero talent tree introduces [[talent:117584]] to replace [[spell:53351]], changing how it interacts with your gameplay. 
  
  - Usable on enemies below 20% health, above 80% health or whenever you proc [[spell:378770]].
  - AoE potential through [[talent:117571@AJwABA]] and [[talent:132888@AJwABA]], with the later replacing [[spell:2643]] when available in AoE scenarios.
  
  
  
  - Extra burst potential during [[spell:288613]] through the talent [[talent:117590@AJwABA]].
- Transforms [[spell:288613]] into [[spell:392058]] after using it.
  
  - [[spell:392058]] is a heavy hitting ability with a 1 second AoE silence.
- [[talent:117565@FJQA0_xBDEA]] will make your [[spell:257044]] have a 100% chance to proc [[spell:378770]], removing some RNG.
- [[talent:123346]] applies [[spell:264735]] to you when you use [[spell:109304]] through the talent [[talent:123779]], making it an on demand damage reduction cooldown.
- Using [[spell:264735]] with this talent chosen also heals you for 50% of  what a normal [[spell:109304]] would.

:::

:::

## Talents

:::tabs
:::tab [[talent:123345]] Single-Target
:::talents [[talent:123345]] **Marksmanship Hunter** Single-Target talents in Raids
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGaGDGbLzMzMzMzMDMLDmBAAMzMzYGgZstBDwCzsNjB",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGaGDGbLzMzMzMzMDMLDmBAAMzMzYGgZstBDwCzsNjB"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:19434]] + [[spell:185358]] + [[spell:257044]]
  
  - Your core damage dealing abilities as a Marksmanship Hunter. They are buffed by a lot of other talents you pick throughout your Talent Tree.
- [[spell:257620]] + [[spell:257621]] + [[spell:260243]] + [[spell:212431]]
  
  - Enables your entire AoE damage dealing kit. [[spell:257620]] only procs [[spell:257621]] when hitting 3 or more targets, but should be used on 2 targets over [[spell:185358]].
- [[talent:128377]]
  
  - Allows for very effective cleave on exactly 2 targets.
- [[talent:128399]]
  
  - Empowers [[spell:185358]] and [[spell:257620]].
- [[talent:128370]]
  
  - Gives you extra damage potential on targets below 20%.
- [[talent:128710]]
  
  - Replaces your ability to use a pet with a non-interactive eagle that grants you certain active and passive abilities.
- [[spell:378770]]
  
  - Allows for [[spell:53351]] / [[spell:466930]] to proc randomly during the fight.
- [[spell:288613]]
  
  - Your main offensive cooldown, enhanced by multiple talents below it to make it a very important part of your kit.
    
    - 2 minute cooldown baseline, reduced to 1:30 when specced in to [[talent:128379]].

#### Class Tree

- [[talent:126470]]
  
  - Grants [[spell:264735]] two charges.
- [[talent:126465]]
  
  - Heavily reduces the cooldown of your [[spell:109304]] ability, allowing you to heal yourself on demand quite often.
- [[talent:126452]]
  
  - Grants [[spell:5384]] and [[spell:186265]] the capability to dispel yourself from Poison and Disease debuffs.
- [[talent:136686]]
  
  - Defensive that can be used on yourself or on someone else.
  - Choice node with [[talent:136685]].

:::

:::tab [[talent:123345]] Cleave
:::talents [[talent:123345]] **Marksmanship Hunter** 2 Target Cleave talents in Raids
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGaGDmtNzMzMzMzMDMLDzMAAgZmZGDgZstBDwCzsNjB",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGaGDmtNzMzMzMzMDMLDzMAAgZmZGDgZstBDwCzsNjB"
}
```
:::

### When to use this Spec

Use this spec for encounters where majority of the fight includes 2 targets to cleave.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:212431]] lasts 1.0 sec longer and deals 5% increased damage.
- **4-Set:** [[spell:19434]] and [[spell:257044]] damage increased by 5%. Each time [[spell:212431]] causes a burst of damage, the cooldown of [[spell:19434]] and [[spell:257044]] is reduced by 0.5 sec.

### Single-Target

:::tabs
:::tab [[talent:123345]]
### Opener

- Your goal in the opener and all your [[spell:288613]] windows is to use as many [[spell:257044]], [[spell:19434]] and [[spell:185358]] buffed by [[talent:128399]] as possible.

:::rotation **Marksmanship Hunter** single-target opener in Raids
```json
{
  "source_code": "JUcAg2gQE0-AAAgCQJXZgM0btJWY0BgAqvEAVAlclNWYzRHIvVHdg8mZgM2bFsBKC9cPDAAAAAgQTifAIwDBCV2ZEAAACJTMEAAABgorBQBWAEwXfQAAAMAAYFQBAEgNXIgAUw-AAAQAVRBAAIkDULQAAVgDEAYBBsBEEAlcvNWCRUxHMIUNNNRFnonFAwgAUw-A"
}
```
1. [[spell:257284]] Pre Combat
2. [[spell:19434]] Precast out of combat
3. [[spell:212431]]
4. [[spell:260243]]  [[spell:288613]] · [[spell:274738]] · [[item:241288]] · [[item:270175]]
5. [[spell:257044]]
6. [[spell:19434]]
7. [[spell:185358]]
8. [[spell:19434]]  
   
   1. [[spell:257044]] Proc
   2. [[spell:19434]]
   3. [[spell:185358]]
   4. [[spell:1264949]]
   5. [[spell:19434]]
9. [[spell:185358]]
10. [[spell:1264949]]
11. [[spell:19434]]
12. [[spell:185358]]
13. [[spell:257044]]
:::

- Always apply [[spell:257284]] on the boss before combat.
- [[spell:1264949]] should be used when you are starting to run out of [[spell:19434]] during your cooldowns, which may wary depending on [[spell:194594]] procs. Just don't wait too long since you want it to do its damage in [[spell:288613]].
- There can be some variance in the opener since you have talents that have a chance to reset the cooldown of certain abilities.
  
  - [[spell:336867]] can reset [[spell:257044]] cooldown.
  
  
  
  - [[spell:194594]] can also grant a charge of [[spell:19434]] and make it instant.
  - If you are unlucky with procs you may run out of **Focus** even during [[spell:288613]], in that case fill with a [[spell:56641]].
- Use any on-use trinket, racials and [[item:241288]] with your [[spell:288613]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Use [[spell:212431]] on cooldown.
2. Use [[spell:260243]] on cooldown.
3. Cast [[spell:257044]] on cooldown.
4. Use [[spell:19434]] if you are at 2 charges or close to hitting 2 charges.
5. Use [[spell:185358]] if you have [[talent:128399]].
6. Use [[spell:19434]] on cooldown.
7. Cast [[spell:56641]] if you're too low on **Focus** or if everything above is on cooldown.

:::

:::

### AoE

:::tabs
:::tab [[talent:123345]]
### Opener

- Your goal in the AoE opener and all your [[spell:288613]] windows is to use as many [[spell:257044]] and [[spell:19434]] empowered by [[spell:257621]] as possible, while filling with your other abilities to empower it and regain focus.
  
  - Even when not playing [[talent:128378]], you want to fill with [[spell:257620]] on 2 targets and more instead of  [[spell:185358]].

:::rotation **Marksmanship Hunter** AoE opener in Raids
```json
{
  "source_code": "JccAg6gQE0-AAAgCQJXZgM0btJWY0BgAqvEAVAlclNWYzRHIvVHdg8mZgM2bFsBDCNlCAEQAMI0z9MQBIQwk4HACkQgQldGBAAQAI6aAOwAACJTMB4AUf9BBAAwAAgVAFAQA2chACQB7DAAAB0FBAAQEIJjDAQAgEEwIQQAUy92YRkBC100EFcGAT1wdNAhM3AAEAIAFsPA"
}
```
1. [[spell:257284]] Pre Combat
2. [[spell:19434]] Precast out of combat
3. [[spell:2643]]
4. [[spell:212431]]
5. [[spell:260243]]  [[spell:288613]] · [[item:241288]] · [[spell:274738]] · [[item:270175]]
6. [[spell:257044]]
7. [[spell:19434]]
8. [[spell:2643]]
9. [[spell:19434]]
10. [[spell:2643]]  
    
    1. [[spell:257044]] Proc
    2. [[spell:19434]]
    3. [[spell:1264949]]
    4. [[spell:2643]]
11. [[spell:1264949]]
12. [[spell:19434]]
13. [[spell:2643]]
14. [[spell:257044]]
:::

- Always apply [[spell:257284]] on the boss before combat.
- Your AoE opener can vary depending on procs from [[spell:194594]] and [[spell:336867]].
- Use any on-use trinket, racials and [[item:241288]] with your [[spell:288613]].

### Priority List

1. Use [[spell:212431]] on cooldown.
2. Use [[spell:260243]] on cooldown to activate [[spell:257621]], if talented.
3. Use [[spell:257620]] to activate [[spell:257621]] if it is **NOT** currently active.
4. Cast [[spell:257044]] if you have [[spell:257621]] active.
5. Cast [[spell:19434]] on cooldown if you have [[spell:257621]] active.
6. Use [[spell:257620]] if you have [[talent:128399]].
7. Cast [[spell:56641]] if you are low on **Focus** or everything else is on cooldown.

:::

:::

## Deep Dive

### The Importance of Trick Shots on AoE

- It is crucial for you to **ALWAYS** have the [[spell:257621]] buff active before you use [[spell:257044]] or [[spell:19434]] in AoE scenarios no matter what.
- Remember that using either of them always consumes your current [[spell:257621]] buff, except when you have [[spell:260243]] running which constantly applies [[spell:257621]] while active.
- Not doing this in all AoE cases results in a significant loss of overall damage.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'zali
:::talents **Marksmanship Hunter** Nek'zali Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYGMmmxgZZzMzMzMzMzgZWGmZAAAjxMGAzYbDGgFmZbGDA",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYGMmmxgZZzMzMzMzMzgZWGmZAAAjxMGAzYbDGgFmZbGDA"
}
```
:::

### Boss Tips

- Use [[spell:109248]], [[spell:474421]] and [[spell:187698]] to help control the **Restless Amani** adds.
- If you get [[spell:1287322]], use a defensive and place it on the side of the room.
  
  - If you notice the ghost spawn on you that applies this debuff, you can [[spell:186265]] right before its about to hit you to avoid it.
- Remember to move around your [[spell:259558]] to the big mobs in the intermission and the mob inside the other realm, and swapping it back to the boss afterwards.

:::

:::tab Entombed Sentinels
:::talents **Marksmanship Hunter** Entombed Sentinels Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz22yMzMzMzMzgZWGmBAAYMzwAYGbMLGgFmZbGDA",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz22yMzMzMzMzgZWGmBAAYMzwAYGbMLGgFmZbGDA"
}
```
:::

### Boss Tips

- With Marksmanship's extra range from Mastery, you can easily attack the Green golem to cleave it with the **Venom Coagulation** add even when playing on the Red golem side, so consider doing that if you feel comfortable with it.
- Soak [[spell:1288232]] when on the side with the Red golem, and spread near the wall and close to other people to drop pools well.
  
  - This may also be a good time to use a defensive.
- Consider swapping [[spell:259558]] to the add when it spawns and then back to the boss you had it on after it is dead.

:::

:::tab Lost Explorers
:::talents **Marksmanship Hunter** Lost Explorers Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz22yMzMzMzMzgZWGmBAAYMzwAYGbMLGgFmZbGDA",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz22yMzMzMzMzgZWGmBAAYMzwAYGbMLGgFmZbGDA"
}
```
:::

### Boss Tips

- Always DPS the two turtles that are next to each other at any time to not waste cleave damage.
- Interrupt [[spell:1286922]] from **Scrollsage Iku**.
- In the empowered phases of each turtle after feeding them **Disgusting Fish**, consider using a defensive when getting targeted by the mechanics of those phases.
- Help soaking the crates from [[spell:1291933]] by walking in to them, but don't overdo it.
- Depending on your amount of Hunters in the raid, you may want to swap your [[spell:259558]] around to the current focus targets.

:::

:::tab Vashnik
:::talents **Marksmanship Hunter** Vashnik Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz22yMzMzMzMzAzywMAAAjZmxAYGbbGGgFmZbGDA",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZWMjZmxMYMNjBz22yMzMzMzMzAzywMAAAjZmxAYGbbGGgFmZbGDA"
}
```
:::

### Boss Tips

- Always focus on killing the adds when they are up. You can also help control the purple adds with [[spell:109248]].
- Use a defensive when you have [[spell:1294994]] or [[spell:1295224]].
- Don't hit other players with the waves you spawn from [[spell:1281907]], especially avoiding aiming it at the boss/melee camp.

:::

:::tab Sszorak
:::talents **Marksmanship Hunter** Sszorak Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDGzMjZwYaGDGbLzMzMzMzMDMLDmBAAMzMDzAMjNmFDwCzsNjB",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDGzMjZwYaGDGbLzMzMzMzMDMLDmBAAMzMDzAMjNmFDwCzsNjB"
}
```
:::

### Boss Tips

- If you are ever hit by a [[spell:1287072]] you can use [[spell:5384]] to dispel the poison debuff on yourself.
- If you don't find a partner to solve the [[spell:1285419]] mechanic with, you can use [[spell:781]] to save yourself from falling off the platform.
- Use a defensive if [[spell:1286987]] is applied to you and place it wherever your raid has planned for you to place the [[spell:1287008]].

:::

:::tab Twin Fangs
:::talents **Marksmanship Hunter** Twin Fangs Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZsNjZmxMYoZMY22WmZmZmZmZGMzywMAAAzMzwAYGbMMALMz2MG",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZsNjZmxMYoZMY22WmZmZmZmZGMzywMAAAzMzwAYGbMMALMz2MG"
}
```
:::

### Boss Tips

- Make sure you help soak [[spell:1289201]] that spawn, but not too many since it will instantly kill you through [[spell:1290336]].
- Stand in the red circle from [[spell:1290516]] every time it comes to remove a [[spell:1290336]] stack.
- If [[spell:1290809]] is applied to you, do not hit other people with your circle and move near the edge of the room to place the puddle good.
  
  - Also use a defensive while this is on you.
- Kill the **Spawn of Vexhul** adds that spawn in the middle part of the room as fast as possible.

:::

:::tab Coiled Altar
:::talents **Marksmanship Hunter** Coiled Altar Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGaGDmttlZmZmZmZmBmlhZAAAmZmhBwM2YWMALMz2MG",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGaGDmttlZmZmZmZmBmlhZAAAmZmhBwM2YWMALMz2MG"
}
```
:::

- Help move any [[spell:1282403]] into a good position.
- Use [[spell:5384]] when the [[spell:1282281]] debuff is applied to you to dispel it.
- Help soak [[spell:1283485]] when you are able to.
- Move out and away from other players when targeted by [[spell:1286895]] and soak the spirits spawned around you when it hits before you die to [[spell:1286837]].
- Kill **Spiteful Soulcoilers** when they spawn and interrupt them.
- Make sure to hold your cooldowns after the first usage in Phase 2 to have them ready for the intermission damage increase.

:::

:::tab Ula'tek
:::talents **Marksmanship Hunter** Ula'tek Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDGzMjZwYaGDmlttZmZmZmZmBzsMYGAAwMzMjBwM2ADwCzsNjB",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMzMDGzMjZwYaGDmlttZmZmZmZmBzsMYGAAwMzMjBwM2ADwCzsNjB"
}
```
:::

### Boss Tips

- Since this boss is untested on PTR, the build above is just a generic AoE build and may or may not be the correct choice. It will be updated once the Race to World First finishes.

:::

:::tab Nymrissa Wavecaller
:::talents **Marksmanship Hunter** Nymrissa Wavecaller Raid Talents
```json
{
  "source_code": "C6PAe4d-yQ5lSoc6yFim_XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYGMmmxgZbbZmZmZmZmZwMLDmBAAMGzYAMjtNYAWYmtZMA",
  "code": "C6PAe4d+yQ5lSoc6yFim/XEz3yCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYGMmmxgZbbZmZmZmZmZwMLDmBAAMGzYAMjtNYAWYmtZMA"
}
```
:::

- Spawn the **Frost Orbs** from the Chilling Frost debuff close to each other and ideally near the edges of the room.
  
  - Also use a defensive when this debuff is on you.
- When the murlocs spawn, kill them as fast as possible and keep them from reaching the middle of the room by using [[spell:109248]], [[spell:187698]] and [[spell:474421]].

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Marksmanship Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Marksmanship Hunter** Stat Priorities in Raid
```json
{
  "source_code": "JoAJFMAIxQCKDEQAEA"
}
```
**敏捷 ≥ 暴击 ＞ 精通 ＞ 急速 ≫ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through dealing damage. Great stat especially in AoE scenarios.
- **Speed** -  Less useful for you since **Marksmanship Hunter** already has decent mobility, but it can help you deal with certain mechanics in raids or increase your DPS slightly over a boss fight.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@DiQAA4PAnk7IQrjgC4UA]] **(Catalyst to Tier)** | Temple of Sethraliss |
| Neck | [[item:268265@BkQAA4PAX16IQrDj1gVA]] | Ula'tek |
| Shoulder | [[item:268231@DgQAA4PAXk7IoAYF]] **(Catalyst to Tier)** | Coiled Altar |
| Cloak | [[item:268253@BgQAA4PACKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DgQAA4PAJk7wYNYF]] **(Catalyst to Tier)** | Ula'tek |
| Wrist | [[item:244584@FCSAA4PAeA8ciqjAtOAAAAAAAA3WzSB]] | Crafted |
| Gloves | [[item:160213@BgQAA4PACKgTBA]] **(Catalyst to Tier)** | Kings' Rest |
| Belt | [[item:244581@FCSAA4PAeA8ciqjAtOAAAAAAAA3WzSB]] | Crafted |
| Legs | [[item:271491@DgQAA4PAhu7IoAOF]] | Sszorak |
| Boots | [[item:268233@DgQAA4PAPk7IoAOF]] | Crafted |
| Ring 1 | [[item:268249@DiQAA4PA1j7IQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAA4PA1j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270175@BgwAA4PACKAWBUAABYzFCA]] | Ula'tek |
| Trinket 2 | [[item:270164@BgQAA4PACKgTBA]] | Lost Explorers |
| Weapon | [[item:268207@DgQAA4PA_k7wYNYF]] | Ula'tek |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAA4PACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAA4PACKQQBA]] | Kings' Rest |
| Cloak | [[item:251132@BgQAA4PACKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAA4PACKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAA4PACKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAA4PACKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAA4PACKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:273796@BgQAA4PACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAA4PACKQQBA]] | Murder Row |
| Weapon | [[item:159637@BgQAA4PACKQQBA]] | Temple of Sethraliss |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BAwAA4PAYFQBAEgNXIA]]  <br>[[item:270164@BAQAA4PAOFA]]  <br>[[item:270168@BAQAA4PAYFA]] |
| **A-Tier** | [[item:273796@BgQAA4PACKgTBA]]  <br>[[item:159617@BgQAA4PACKgTBA]]  <br>[[item:250228@BgQAA4PACKgTBA]]  <br>[[item:270165@BAQAA4PAOFA]]  <br>[[item:250214@BgQAA4PACKgTBA]] *-- Good if you can stand in it at all times, but unrealistic value a lot of the time*  <br>[[item:270173@BAQAA4PAYFA]] -- Good for Single Target |
| B-Tier | [[item:250215@BgQAA4PACKgTBA]]  <br>[[item:251787@BAQAA4PABFA]] *-- Good for its item level, but capped at 321* - *prepare your healers to dispel you at the end of the effect*  <br>[[item:273797@BgQAA4PACKgTBA]]  <br>[[item:246304@BAAAA4P]]  <br>[[item:251792@BgQAA4PACKQQBA]] *-- Good for its item level, but capped at 321*  <br>[[item:265657@BgQAA4PACKQQBA]] *-- Good for its item level, but capped at 321* |
| **C-Tier** | [[item:250225@BgQAA4PACKgTBA]]  <br>[[item:274493@BAQAA4PABFA]] *-- Decent for its item level, but capped at 321*  <br>[[item:251782@BAQAA4PABFA]] *-- Decent for its item level, but capped at 321*  <br>[[item:246307@BAQAA4PALFA]]  <br>[[item:248583@BgQAA4PACKQQBA]] *-- Decent for its item level, but capped at 321*  <br>[[item:251783@BAQAA4PABFA]] *-- Decent for its item level, but capped at 321* |
| **Junkyard** | [[item:251785@BAQAA4PABFA]]  <br>[[item:158374@BgQAA4PACKgTBA]]  <br>[[item:193757@BgQAA4PACKgTBA]]  <br>[[item:250259@BgQAA4PACKgTBA]]  <br>[[item:270166@BAQAA4PAOFA]]  <br>[[item:274496@BAQAA4PABFA]]  <br>[[item:274497@BAQAA4PABFA]]  <br>[[item:246305@BAQAA4PALFA]]  <br>[[item:246306@BAQAA4PALFA]]  <br>[[item:251784@BAQAA4PABFA]]  <br>[[item:251791@BAQAA4PABFA]]  <br>[[item:252957@BgQAA4PACKQQBA]]  <br>[[item:241340@BAQAA4PALFA]]  <br>[[item:251790@BAQAA4PABFA]] |

### Embellishments

- [[item:240167]] x 2
  
  - Best used on Bracers and Belt/Boots in a full BiS setup.
- [[item:245875]] + [[item:240167]]
  
  - Very likely the best setup you can run early on in the season, where weapon craft has high value.
  - Craft [[item:245875]] on your Weapon and [[item:240167]] on your biggest upgrade offpiece.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 or 344 on max item level therefore it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]]
- **Food**
  
  - [[item:255846]]
  - [[item:242747]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]]
  - [[item:240898]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAA4PAZbAB]] and [[item:275707@BAAAA4P]] |
| --- | --- |
| Shoulders | [[item:243991@BAAAA4P]] |
| Chest | [[item:243977@BAAAA4P]] |
| Wrist | [[item:275707@BAAAA4P]] |
| Waist | [[item:275707@BAAAA4P]] |
| Legs | [[item:244641@BAAAA4P]] |
| Boots | [[item:243983@BAAAA4P]] |
| Ring 1 | [[item:243957@BAAAA4P]] |
| Ring 2 | [[item:243957@BAAAA4P]] |
| Weapon | [[item:244031@BAAAA4P]] |
|  |  |

:::

:::column
:::gear **Marksmanship Hunter** Enchantments in Raids
```json
{
  "source_code": "IQFZ-DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Marksmanship Hunter** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:20594]] -- Dwarf
  
  - Able to dispel a lot of debuffs from you on demand, while also providing you with a 10% physical damage reduction upon use.
- [[spell:59224]] -- Dwarf
  
  - Passively increasing your Critical Damage and Healing done by 2%.

- [[spell:59752]] -- Human
  
  - Can break you out of certain CC, even in PvE scenarios.
- [[spell:20598]] -- Human
  
  - You gain 2% more secondary stats from all sources.

- [[spell:256948]] -- Void Elf
  
  - Throws out a shadowy projectile in front of you, if you press this button again after the projectile is thrown out, you teleport to its current location. Occasionally extremely helpful for movement.
- [[spell:255669]] -- Void Elf
  
  - Occasionally empowering you to deal 5% more damage with all your spells for 12 seconds.

- [[spell:20549]] -- Tauren
  
  - Stuns 5 enemies close to you for 2 seconds.
- [[spell:20550]] -- Tauren
  
  - Increases your maximum health.
- [[spell:154743]] -- Tauren
  
  - Passively increasing your Critical Damage and Healing done by 2%.

- [[spell:274738]] *--* Mag'har Orc
  
  - Increasing one of your two highest stats on a two minute cooldown.

- [[spell:26297]] -- Troll
  
  - Increases your Haste by 10% for 12 seconds. Useful if you want a damage racial that provides more burst damage.

- [[spell:69070]] -- Goblin
  
  - About the same as [[spell:781]], except it launches you forward instead of backwards. Can be very useful on certain encounters with heavy movement.
- [[spell:69042]] -- Goblin
  
  - Increases your Haste by 1%.

- [[spell:107072]] -- Pandaren
  
  - Doubles the amount of stats you get from Well Fed.
- [[spell:107076]] -- Pandaren
  
  - Reduces fall damage.

- [[spell:461039]] -- Dracthyr
  
  - Frontal knockback, useful to proc [[spell:109248]].
- [[spell:358733]] -- Dracthyr
  
  - Useful to negate knockback mechanics on you
- [[spell:365575]] -- Dracthyr
  
  - Increase Mastery by 1%

- [[spell:1238623]] -- Haranir
  
  - Passively increasing your Critical Damage and Healing done by 1%.
- [[spell:1238677]] -- Haranir
  
  - Passively increases your damage done to elementals, aberrations and beasts by 1%.

- **Gnome** and **Night Elf**, with the active abilities [[spell:20589]] for **Gnome** to break roots and [[spell:58984]] for **Night Elf**, have proven useful in the past. 
  
  - However, you already have access to the same capabilities as Marksmanship Hunter with [[spell:781]] breaking roots on use and [[spell:5384]] generally working on the same things as [[spell:58984]] does, so they are much less useful for you.

### Recommendation

For you as a Marksmanship Hunter, the overall most useful races to play would be Mag'har Orc, Orc or Tauren for Horde, Dwarf for Alliance and Pandaren which works for both factions.  
Whenever [[spell:20594]] has usefulness it is the superior choice.

## Macros

Discover recommended macros for **Marksmanship Hunter** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**@Cursor Macros** simply uses whichever ability you combined it with directly where you have your cursor without the usual second click confirmation. Can take some getting used to if you've never used it but makes all abilities like this faster to throw out.

**@Cursor [[spell:260243]]**

```wow-macro
#showtooltip
/cast [@cursor] Volley
```

**@Cursor [[spell:187650]]** -- *Freezing Trap can sometimes require very precise placement, in those cases, you might want to avoid using this macro.*

```wow-macro
#showtooltip 
/cast [@cursor] Freezing Trap
```

**@Cursor [[spell:187698]]**

```wow-macro
#showtooltip
/cast [@cursor] Tar Trap
```

**@Cursor [[spell:109248]]**

```wow-macro
#showtooltip 
/cast [@cursor] Binding Shot
```

**@Cursor** **[[spell:1543]]**

```wow-macro
#showtooltip 
/cast [@cursor] Flare
```

:::

:::details Stop Macro Rapid Fire Macros
These macros stop your chosen ability from being used while [[spell:257044]] is channeling. This enables you to spam your next button while [[spell:257044]] is still channeling without losing out on any damage by interrupting the cast too early.

**Stop Macro [[spell:19434]]**

```wow-macro
#showtooltip
/stopmacro [channeling: Rapid Fire]
/cast Aimed Shot
```

**Stop Macro [[spell:185358]]**

```wow-macro
#showtooltip
/stopmacro [channeling: Rapid Fire]
/cast Arcane Shot
```

**Stop Macro [[spell:56641]]**

```wow-macro
#showtooltip
/stopmacro [channeling: Rapid Fire]
/cast Steady Shot
```

**Stop Macro [[spell:53351]]**

```wow-macro
#showtooltip
/stopmacro [channeling: Rapid Fire]
/cast Kill Shot
```

**Stop Macro [[spell:466930]]**

```wow-macro
#showtooltip
/stopmacro [channeling: Rapid Fire]
/cast Black Arrow
```

:::

:::details Other Recommended Macros
**[[spell:34477]]** **Mouseover** -- *Casts [[spell:34477]] on your mouseover target. Secondary use where you can replace @Solwinas in the macro with the name of the target you want to Misdirect and it casts it on them without the need for any mouseover at all.*

```wow-macro
#showtooltip
/cast [@mouseover, help][@Solwinas]Misdirection; Misdirection
```

**Cancelaura [[spell:186265]] Macro** *-- Removes [[spell:186265]] from you when pressed.*

```wow-macro
/cancelaura Aspect of the Turtle
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Marksmanship Hunter**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Sol-Raid-UI-mxr-1024x616.webp>)

**Marksmanship Hunter** Interface in Raids

:::accordion
:::details Addons
- **UnhaltedUnitFrames** *-- User Interface replacement* 
  
  - Replaces player, target, focus, boss frames and more with more customizable ones.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **Dominos** -- Action Bars replacement
  
  - Cleaner looking action bars with more customization.
- **Plater**  -- Advanced Nameplates
  
  - Replaces the default blizzard nameplates with more advances ones with way more customization.
- **Details** -- In-depth Damage Meter
  
  - Enables more visual customization for the new default damage meters.
- RaidFrameSettings -- Party/Raidframe enhancement
  
  - Adds extra customization to your default party and raidframes.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
### Dark Ranger Changes

- **Bleak Arrows damage increased by 300%.**
- **Withering Fire's Black Arrow damage reduced by 40%.**
- **Fixed an issue where Through The Eyes was not properly increasing Withering Fire's damage.**
- **Through the Eyes has been redesigned – Increases the damage of Kill Shot and Black Arrow by 10%.**
- **Black Arrow damage increased by 25%.**
- **Black Arrow direct damage reduced by 40%.**
- **Black Arrow no longer highlights itself whenever it is able to be used against the target.**
- **Ebon Bowstring now causes Black Arrow to have a chance to cause your next Aimed Shot to grant the Deathblow effect.**
- **Dark Minion summons can now be tracked on the Cooldown Manager.**

### Sentinel Changes

- **Moon's Blessing now only causes 1 second of cooldown reduction to Aimed Shot (was 2 seconds).**

### Marksmanship Changes

- ***Developers' notes: Marksmanship Hunter's last round of changes reintroduced Explosive Shot as a button players can opt into, but it didn't flow well with how the spec was playing. In Midnight Season 2, we're making changes to Explosive Shot's design and some of its supporting talents. The Headshot talent has also been a source of frustration, so we're removing it and adjusting how Deathblow works to make it more predictable when you should follow up an Aimed Shot cast with a Kill Shot or Black Arrow. Finally, we're adjusting Markmanship's Apex Talent nodes to no longer make Aimed Shot a guaranteed critical strike to reduce the emphasis on Aimed Shot modifiers.***
- **New Talent: Unstable Trigger – Explosive Shot can be used a second time if used within 3 seconds. Explosive Shot incorporates any remaining damage from previous Explosive Shots on your target.**
- **Explosive Shot has been redesigned – Fire an explosive shot at your target. Every 1 second for 3 seconds, the target explodes, dealing Fire damage to all enemies within 8 yards. Damage reduced beyond 5 targets. Recasting Explosive Shot incorporates any remaining damage from previous Explosive Shots on your target.**
  
  - **Developers' notes: We are pivoting the design of Explosive Shot quite a bit to attempt to find a stronger identity. The changes to the core Explosive Shot as well as the Explosive Shot related talents should give it a distinct feel to play with compared to your other main abilities.**
- **Explosive Shot's visual has been updated.**
- **Explosive Shot's tooltip has been updated and now includes contextual notes when Unstable Trigger is talented.**
- **Precision Detonation has been redesigned – Explosive Shot lasts for 1 additional second.**
- **Shrapnel Shot renamed to Accuracy by Volume and has been redesigned – Bulletstorm now affects your next 1 Aimed Shots.**
- **Windrunner Quiver has been redesigned – Rapid Fire damage increased by 10%. Rapid Fire has a 30% chance to grant the Lock and Load effect.**
- **Apex Talent: Take Aim (Rank 2) has been redesigned – Your critical strike damage is increased by 5%/10%. Your ranged abilities deal 3%/6% increased damage.**
- **Apex Talent: Take Aim (Rank 3) has been updated – Spotter's Mark now increases the damage of your next Aimed Shot and Rapid Fire against the target (was Aimed Shot only).**
  
  - ***Developer's notes: The previous version of Marksmanship's Apex Talents put too much emphasis on Aimed Shot and its critical damage modifiers. This new version should better interact with more of your specialization's abilities.***
- **Bulletstorm has been redesigned – Rapid Fire now increases the damage of your next Aimed Shot by 20%.**
- **Deathblow has been updated – Aimed Shot now has a chance to cause your next Aimed Shot to grant the Deathblow effect.**
  
  - ***Developers' notes: Our goal with our Deathblow updates for Marksmanship Hunters is to make it clear to you when you should follow up an Aimed Shot with a Kill Shot or Black Arrow cast rather than having the uncertainty of which button to press. Rapid Fire’s 100% chance to get the Deathblow effect is unchanged, you should always be able to follow-up a Rapid Fire with a Kill Shot or Black Arrow.***
- **Aspect of the Hydra has been updated – Arcane Shot no longer cleaves.**
- **All damage dealt by your abilities increased by 5%.**
- **Auto Shot damage increased by 756%.**
- **Aimed Shot damage increased by 20%.**
- **Rapid Fire damage increased by 44%.**
- **Arcane Shot damage increased by 38%.**
- **Steady Shot damage increased by 50%.**
- **Multi-Shot damage increased by 73%.**
- **Volley damage increased by 20%.**
- **Kill Shot damage increased by 50%.**
- **Eagle's Accuracy is now a 1-point talent that increases the damage of Aimed Shot by 5% (was 10%) and Rapid Fire by 10% (was 20%).**
- **Focused Aim now reduces the cooldown of Aimed Shot by 1 second (was 2 seconds).**
- **Small Game Hunter is now a 2-point talent. Values unchanged.**
- **Aimed Shot has a new icon.**
- **Some talents have changed positions in the talent tree.**
- **The following talents have been removed:**
  
  - Double Tap
  - Headshot

:::

:::details Patch 12.0
### Hunter Changes

- **New Talent: Precision Strikes – Auto attack and auto shot damage increased by 25%.**
- **New Talent: Moment of Opportunity – When a trap triggers, gain 30% movement speed for 3 seconds.**
- **New Talent: Shell Wall – Damage taken during Aspect of the Turtle is reduced by an additional 20%.**
- **New Talent: Cold Feet – When your Freezing Trap breaks, the victim's movement speed is reduced by 70% for 4 seconds.**
- **New Talent: Combat Experience – Agility increased by 3%.**
- **New Talent: Improved Snaring – Wing Clip slows an additional 25%. Concussive Shot slows an additional 10%.**
- **New Talent: Horsehair Tether – When an enemy is stunned by Binding Shot, it is dragged to Binding Shot's center.**
- **New Talent: Roar of Sacrifice – Instructs your pet to protect a friendly target, reducing their damage taken by 15%, but 50% of all damage taken by that target is transferred to your pet. Lasts 10 seconds or until your pet's health drops below 25%.**
- **New Talent: Guardian's Hide – Your pet protects you at all times, reducing the damage you take by 3%. Your pet receives 100% of the damage it mitigates.**
- **Hunter's Mark has been updated – Now increases the target's damage taken by 3% (was 5% above 80% health).**
- **Fortitude of the Bear has been updated – Now passive. Reduces all damage taken by 3%.**
- **Lone Survivor has been updated – Now increases Survival of the Fittest's duration by 2 seconds (was 4 seconds).**

### Dark Ranger Changes

- New Talent: Corpsecaller
  
  - Marksmanship: Black Arrow's periodic damage has a small chance to rouse the dead, summoning a Dark Minion to fight alongside you for 20 seconds.
- New Talent: Wailing Dead
  
  - Marksmanship: Trueshot summons a Dark Minion. For 15 seconds after casting Trueshot, Trueshot is replaced with Wailing Arrow. 
    
    - **Wailing Arrow: Fire an enchanted arrow, dealing Shadow damage to your target and additional Shadow damage to all enemies within 8 yards of your target. Non-Player targets struck by a Wailing Arrow have their spellcasting interrupted and are silenced for 1 second. Grants Deathblow.**
- New Talent: Blighted Quiver
  
  - Marksmanship: You fire 2 additional Black Arrows during Withering Fire's barrage. Trick Shots damage bonus increased by 8%. Aspect of the Hydra's damage bonus increased by 10%.
- New Talent: Pact of the Hollow
  
  - Marksmanship: Aimed Shot causes your Dark Minion to fire a Blighted Arrow, dealing moderate Shadow damage to up to 8 nearby enemies.
- **Black Arrow has been updated – Periodic damage increased substantially and is no longer a rolling periodic.**
- **Soul Drinker has been updated – Now causes Kill Command and Barbed Shot to have a chance to grant Deathblow. Now causes Aimed Shot and Rapid Fire to have an increased chance to grant Deathblow.**
- **Bleak Arrows has been updated – No longer has a chance to grant Deathblow. Now increases auto shot damage by 100%.**
- **Banshee's Mark has been updated – Now increases the critical strike damage of Bleak Powder and Black Arrow by 10%.**
- **The Bell Tolls has been updated –**
  
  - **Marksmanship: Increases crit chance and Dark Minion damage.**
- **Phantom Pain has been removed.**
- **New Talent: Through the Eyes – Headshot can now stack 5 additional times.**
- **Black Arrow direct damage increased by 75%.**
- **Bleak Powder damage increased by 50%.**

### Sentinel Changes

- **New Talent: Moonlight Chakram – After casting Trueshot or Takedown, it is replaced with Moonlight Chakram for 15 seconds. Throw a chakram blessed with moonlight at your current target that will rapidly deal Physical damage 7 times, bouncing to other targets if they are nearby.**
- New Talent: Stalk and Strike
  
  - Marksmanship: Throwing your Moonlight Chakram grants you Lock and Load.
- **New Talent: Twilight Requiem – When your Moonlight Chakram expires, it summons an explosion of moonlight, dealing moderate Arcane damage to nearby enemies. Damage reduced beyond 8 targets.**
- **New Talent: Radiant Edge – Your Moonlight Chakram deals 25% increased damage each time it bounces.**
- New Talent: Moon's Blessing
  
  - Marksmanship: Consuming Precise Shots has a 10% increased chance to summon your Sentinel Owl. When your Sentinel Owl applies Sentinel's Mark, reduce the cooldown of Aimed Shot by 2 seconds.
- New Talent: Stargazer
  
  - Marksmanship: Consuming Precise Shots grants 2% increased critical strike damage for 10 seconds. Multiple applications may overlap.
- New Talent: Open Fire
  
  - Marksmanship: Volley damage increased by 25%.
- New Talent: Arcane Talons
  
  - Marksmanship: Sentinel's Mark further increases the damage of Aimed Shot by 15%.
- New Talent: Can't Miss, Won't Miss
  
  - Marksmanship: Precise Shots damage bonus increased by 40%. Trueshot duration increased by 4 seconds.
- New Talent: Sanctified Armaments
  
  - Marksmanship: An additional 25% of Rapid Fire damage is dealt as Arcane damage over 6 seconds.
- **New Talent: Conditioning – Your movement speed is increased by 8%. Aspect of the Cheetah's cooldown is reduced by 60 seconds.**
- **New Talent: Scout's Vigil – Enemy detection radius reduced by 10 yards. While in Camouflage, your stealth detection radius is increased by 25 yards.**
- New Talent: Lunar Calling
  
  - Marksmanship: Feathered Frenzy further increases your chance to summon your Sentinel Owl during Trueshot by 10%.
- **Sentinel has been redesigned –**
  
  - **Marksmanship: Your Eagle is replaced with a Sentinel Owl that applies an enhanced Sentinel's Mark.**
    
    - **Sentinel's Mark: Increases the damage taken from Aimed Shot by 30%.**
- **Lunar Storm has been redesigned – When Sentinel's Mark is consumed, it summons a barrage of 4 lunar missiles, each dealing heavy Arcane damage to enemies within 10 yards.**
- **Don't Look Back has been redesigned – Consuming Sentinel's Mark grants you an absorb shield equal to 10% of your maximum health.**
- **Invigorating Pulse has been redesigned –**
  
  - **Marksmanship: Steady Shot grants an additional 5 Focus and its damage is increased by 20%. Maximum Focus increased by 25.**
- **The following talents have been removed:**
  
  - Catch Out
  - Crescent Steel
  - Extrapolated Shots
  - Eyes Closed
  - Kill Shot *(moved to the Marksmanship talent tree)*
  - Overwatch
  - Release and Reload
  - Sentinel Precision
  - Sentinel Watch
  - Sideline
  - Symphonic Arsenal

### Marksmanship Changes

- **New Talent: Deathblow – Aimed Shot has a 20% chance to reset the cooldown of Kill Shot and cause your next cast to be usable on any target regardless of their current health.**
- **New Talent: Lethality – Critical damage dealt by your abilities and auto attacks is increased by 5%/10%.**
- **New Talent: Focus Fire – When Surging Shots resets the cooldown of Rapid Fire, the damage of your next Rapid Fire is increased by 20%.**
- **New Talent: Unload – When Rapid Fire begins and finishes channeling, it also fires an additional Arcane Shot at 100% effectiveness. If your target is below 20% health, Rapid Fire instead fires additional Kill Shots.**
- **New Talent: Critical Precision – Precise Shots now increases the critical strike chance of Arcane Shot and Multi-Shot by 10%.**
- **Ammo Conservation renamed to Quick Draw and has been updated – Now causes Aimed Shot to grant 50% increased movement speed for 2 seconds, decaying rapidly over its duration. No longer grants Aimed Shot cooldown reduction.**
- **Shrapnel Shot has been updated – Now grants Lock and Load when you Volley.**
- **Aspect of the Hydra has been updated – Now also includes Kill Shot/Black Arrow.**
- **Tensile Bowstring has been updated – No longer extends Trueshot. Now reduces the cast time and Focus cost of Aimed Shot during Trueshot.**
- **Bullet Hell has been updated – Now reduces the cooldown of Volley by 15 seconds.**
- **On Target has been updated – Now grants 2% increased Haste (was short duration Haste every time you consumed Spotter's Mark).**
- **Penetrating Shots has been updated – Crit damage bonus reduced to 25% of critical strike chance (was 40%).**
- **Master Marksman has been updated – Now causes targets to bleed for 10% of the damage of a critical strike (was 15%).**
- **Target Acquisition has been updated – Now reduces Aimed Shot's cooldown by 1 second (was 2 seconds).**
- **Focused Aim has been updated – Consuming Precise Shots now reduces Aimed Shot’s cooldown by 1 seconds (was 0.75 seconds).**
- **Small Game Hunter has been updated – Now increases Volley damage by 15% (was Explosive Shot) and Multi-Shot damage by 25% (was 75%).**
- **Headshot has been updated – Damage from Kill Shot increases the damage your target receives from Black Arrow by 2%, stacking up to 10 times.**
- **Aimed Shot damage increased by 50%. Does not affect PvP combat.**
- **Aimed Shot cast time reduced to 2.5 seconds (was 3 seconds) and cooldown increased to 15 seconds (was 12 seconds).**
- **Kill Shot damage increased by 75%.**
- **Rapid Fire damage increased by 200%.**
- **Rapid Fire now grants 3 Focus per shot (was 2 Focus).**
- **Arcane Shot damage increased by 50%.**
- **Multi-Shot damage increased by 50%.**
- **Volley damage increased by 50%.**
- **Trick Shots damage percentage increased to 65% (was 60%).**
- **Precise Shots now reduces the Focus cost of Arcane Shot and Multi-Shot by 60% (was 40%).**
- **Fixed an issue causing Deadly Insight to trigger from Marksmanship abilities.**
- **Surging Shots should now more reliably activate while in combat.**
- **Trueshot's tooltip has been updated to better reflect the various bonuses provided by its talents.**
- **Salvo's tooltip has been updated to communicate the effects of Explosive Shot.**
- **The following talents have been removed:**
  
  - Improved Deathblow
  - Improved Streamline
  - Moving Target
  - Oh'naran Winds
  - Razor Fragments
  - Streamline
  - Tactical Reload

:::

:::

## FAQ

:::accordion
:::details When would Marksmanship Hunter use a pet?
A: With the changes in patch 11.1, Marksmanship Hunter will never use a pet if you are trying to maximize the specs potential.

:::

:::

---

### Credits

Written By: **Solwinas**

Reviewed by: **Ftm**

---

:::changelog 更新记录
**2026-08-06** Updated for patch 12.1

**2026-06-14** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-02-21** Updated for patch 12.0.1

**2026-01-19** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2

**2025-06-18** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-25** Updated for patch 11.1

**2024-12-11** Updated for patch 11.0.7

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
