Welcome to the **Subtlety Rogue** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 2/5 · Weak

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Subtlety Rogue** Mythic+ Best in Slot
```json
{
  "source_code": "JUpAwTVBBc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOA_sOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADQgt7AECSAAkBwDYiqDIQrDAQBBwiIvsUABcJJEAACBAQBmBC3XQggIEAA1jbAKWgEAkdFSAgCBwGJOFQAf9BBAgwAAEQacUAABo0FCEQXBIRAChBWBEgNVPAAFwAEOFQA1LSBESwP5WglUEQDhOgBIUAhkMQuDQqKEIyLLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240892]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:251190]] |  |
| 主手 | [[item:271093]] | [[item:244031]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Subtlety Rogue**, you have access to Ancient Arts, that causes the Combo Points you generate from [[spell:196911]] to have a 15% chance to create a shadow clone that repeats the attack for 50% of normal damage as shadow.

**Rank 2** makes the shadow clones have a 50% / 100% per point spent to trigger the [[spell:196911]] effect.

While with **Rank 3** if you have 5 or more [[spell:196911]] when you use a builder, your next finisher will consume them to generate max Combo Points.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-subtlety-mxr.webp>)

Ancient Arts

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:112612]]
  
  
  
  - - Causes your [[spell:169629]] to scale with haste, increasing its duration the more that you have of it.
  - [[talent:112627]]
    
    - This talent was changed, now makes your [[spell:53]] or [[spell:185438]] have a 15% chance to create a shadow clone that repeats the attack for 50% of its damage as shadow.
  - [[talent:112628]]
    
    - Increases shadow clone damage by 15%. Also causes your [[spell:1833]] and [[spell:408]] create a clone that attacks the target.
  - [[talent:112605]]
    
    - Changed, now causes your [[spell:197835]] to have a 15% chance to create a clone that repeats the attack for 50% of normal damage.
  - [[talent:112604]]
    
    - Changed, buffs your shadow clones by 15%, and gives you an extra 5% chance to spawn them.
  - [[talent:112623]]
    
    - Changed, now you deal 10% damage in [[spell:169629]] or [[spell:1784]].
  - [[talent:112618]]
    
    - Changed, now simply does extra damage every time you use a different ability in your [[spell:169629]].
  - [[talent:112606]]
    
    - Causes your [[spell:319175]] to do 30% more damage damage based on mastery if you spend 5 or more Combo Points.
  - [[talent:112594]]
    
    - Changed, just buffs your finishing moves during [[spell:169629]] by 10% per rank.
- **Class Tree**
  
  - [[talent:112636]]
    
    - Increases agility by 3%.
  
  
  
  - [[talent:112639]]
    
    - No longer a button, now it procs from your generators and increases your next finisher crit by 10%.
  - [[talent:112644]]
    
    - Extra attack speed from your [[spell:5171]].
- **Removed**
  
  - [[spell:323654]]
  
  
  
  - [[spell:393972]]
  - [[spell:394023]]
  - [[spell:278683]]
  - [[spell:1943]]
  - [[spell:394309]]
  - [[spell:212283]]

## Hero Talents



### [[talent:123370]]

- Makes your [[spell:185438]] and [[spell:53]] hit your target with an [[talent:117737]]. *10sec duration, 15sec Cooldown.*
  
  - [[talent:117737]] applies [[spell:441224]], making the target take 8% more damage from you and being unable to parry, which is pretty nice. Especially on bosses where you have to sit on front of the boss for extended periods of time.
  - [[talent:117737]] also applies 1 stack of [[spell:441786]] as a buff on you.
    
    - At 4 stacks of [[spell:441786]], your next [[spell:2098]] becomes [[talent:117712]].
  - [[talent:117712]] hits your target as if your [[spell:15691]] had an extra 5 Combo Points.

- [[talent:120130]]
  
  - This is a pretty nice defensive that adds some tankyness to your kit.
- [[talent:117708]]
  
  - This is a synergistic talent in the tree that outside of being a flat % buff on your finishers, works with [[talent:117725]] and [[talent:117712]].
- [[talent:117731]]
  
  - This is a pretty nice quality of life talent.
- [[talent:117725]]
  
  - [[talent:117708]] has pretty good uptime so a flat damage buff on your cleave is decent.
- [[talent:117715]]
  
  - [[spell:280719]] makes your [[spell:441144]] ignore its cooldown.
- [[talent:136023]]
- [[talent:136022]]
- [[talent:136021@AJABBA]]




### [[talent:123373]]

- Your [[spell:185438]] marks your target with 3 stacks of [[talent:117733]]. 
  
  - You can only have 1 [[talent:117733]] active.
  - Consume a stack of [[talent:117733]] by using a 5 Combo Point or more finisher.
  - You can only apply the [[talent:117733]] with [[spell:185438]]

- After consuming the last stack of [[talent:117733]], or if a mob dies while the [[talent:117733]] is active, you gain [[talent:117739]]..
  
  - When [[talent:117739]] is up, always make sure your next finisher is an [[spell:15691]] with 7 Combo Points.
  
  
  
  - When you consume [[talent:117739]], you apply [[talent:117733]] on the mob you have targetted.
- You can also move your mark with [[spell:1293340]].

Additionally, there are a few more capstones in the tree that are important.

- [[talent:117707]]
- [[talent:117732]].
- [[talent:126029]]
  
  - A defensive node that makes [[talent:112657]] even stronger. [[talent:117703]] is also interesting but much more fight specific.
- [[talent:136020]]
  
  - Passive crit bonus.
- [[talent:136019]]
  
  - A little bit of extra flavor every time you apply mark, but realistically not a big thing.
- [[talent:136018@AJAB]]
  
  - Adds a bit of extra damage in aoe or cleave scenarios, ignoring your main target.
- [[spell:457055]]
  
  - A bit of extra funnel on your main target.





## Talents



### [[talent:123373]]

:::talents [[talent:123373]] **Subtlety Rogue** Single-Target talents in Raids
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[spell:185313]]
  
  - [[spell:185313]] puts you in a stance where you can use all your stealth abilities while buffing your damage for its duration. This is your bread and butter spell for your cooldown windows and is a major contributor to your core gameplay.
- [[spell:382528]]
  
  - This talent makes it so each unique spell cast during [[spell:185313]] deals extra damage.
- [[spell:426594]]
  
  - This talent modifies your [[spell:185313]] to generate double combo points from [[spell:196911]] and causes your finishers to generate combo points if you have enough to fill your combo point bar.
- [[spell:121471]]
  
  - [[spell:121471]] causes most of your damage to be increased by 26% and all your combo point generators to generate double the combo points.
- [[spell:280719]]
  
  - Your biggest damage finisher for both AoE & single target situations.

##### Class Tree

- [[talent:114737]]
  
  - Your strongest defensive utility that lets you play aggressively with no fear of dying.

##### Hero Talents

- [[talent:117706]]
  
  - This is your default pick for all scenarios since [[talent:126030]] is significantly weaker numerically.
- [[talent:126029]] 
  
  - This is your default pick or almost all scenarios, [[talent:117703]] may have some value but it's very niche and [[talent:126029]] is solid all around.
- [[talent:117720]]
  
  - This is your default pick since [[talent:126027]] does not do anything in raid encounters.
- [[talent:117728]]
  
  - This is your default pick for most scenarios, [[talent:126028]] is the other option. Currently [[talent:117728]] seems to be a bit stronger numerically.




### [[talent:123370]]

:::talents [[talent:123370]] **Subtlety Rogue** Single-Target and cleave talents in Raids
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA"
}
```
:::

700~ Haste minimum

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Hero Talents

Changed to [[talent:123373]] to [[talent:123370]] for more info visit the Hero Talent section above.

- [[talent:120132]] 
  
  - This is your default pick for all scenarios since [[talent:117713]] is not very good.
- [[talent:117734]]
  
  - This is your default pick for all scenarios since [[talent:120131]] seems more like a PvP Talent.
- [[talent:117738]]
  
  - This is your default pick for all scenarios since [[talent:120130]] is worse in comparison.
- [[talent:117731]]
  
  - Although not very useful for raiding, the alternative is even more useless.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: [[spell:53]] costs 10 less Energy and has 100% increased damage. [[spell:197835]] costs 5 less Energy and has 60% increased damage.
- **4-Set:** [[talent:112619]] now also benefits [[spell:15691]] and [[spell:319175]] at 100% effectiveness.

### Single-Target



#### [[talent:123370]]

##### Opener

- Your main goal with your cooldowns as a **Subtlety Rogue** is stacking as many of them as possible for maximum burst potential. There are a few priorities and rules when it comes to using your cooldowns as efficiently as possible.

:::rotation [[talent:123370]] **Subtlety Rogue** Single-Target Mythic+ opener
```json
{
  "source_code": "JEGgKIkXULAAAAwACFo2BAAACF-0CAAABwprDAAAAAgQPiEBFgAB2NTCQAgXFwCEAI0S9AQABUBC-gBAo4F1CAAAAAgQPiEB"
}
```
1. [[spell:185438]]  [[spell:121473]] · [[spell:185313]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:209782]]
4. [[spell:185438]]
5. [[spell:15691]]
6. [[spell:15691]]
7. [[spell:185438]]
8. [[spell:15691]]
9. [[spell:185438]]
10. [[spell:280719]]
:::

1. When your [[spell:121471]] has 8s remaining, use your second [[spell:169629]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

The rotational priority for **Subtlety Rogue** changes based on whether you have [[spell:185313]] active or not:

###### Shadow Dance Priority

1. Cast [[spell:280719]] as your first finisher if above 5 combo points.
2. Cast [[spell:196819]] if above 5 combo points if your target is [[spell:441224]] and [[talent:112578]] is up.
3. Cast [[spell:185438]] if under 5 combo points.
4. Cast [[spell:209782]] on cooldown.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with less than 4 [[spell:441786]] stacks with 6+ combo points.
2. Cast [[spell:53]].

###### Cooldown Usage

- Cast [[spell:121471]].
- Cast [[spell:185313]]
- Cast [[spell:280719]] on cooldown at 6 or more Combo Points.
- Cast [[spell:209782]] on cooldown.




#### [[talent:123373]]

##### Opener

:::rotation [[talent:123373]] **Subtlety Rogue** Single-Target Mythic+ opener
```json
{
  "source_code": "JYcAQ2gQeRtAAAAABIEX5bAAAI0S9AAAA8gMgMFdhN2azBybmBCRT1UEdADQHAAAAAgACtMBDAAAuEDAE4QMJEjOwAAC2NzABEDCCF-0BMGBEIUH4gQAc6aCcASgaHAAAI0jIRQBFSgY5HQhE4F1BADEBIExcNRET2BCA4VBeADACtUPAAAAAAgQeRtA"
}
```
1. [[spell:185438]]  [[spell:457052]]
2. [[spell:15691]] 2 Stacks of DSM [[spell:457052]]
3. [[spell:1856]]  [[spell:197835]] · [[spell:457052]]
4. [[spell:15691]] 1 Stack of DSM [[spell:457052]]
5. [[spell:209782]]
6. [[spell:185313]]  [[spell:197835]] · [[spell:457052]] · [[item:241308]] · [[spell:121473]]
7. [[spell:280719]]  [[spell:457058]]
8. [[spell:185438]]  [[spell:1268932]]
9. [[spell:15691]]
10. [[spell:15691]]
11. [[spell:185438]]
12. [[spell:15691]]
13. [[spell:185438]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

The rotational priority for **Subtlety Rogue** changes based on whether you have [[spell:185313]] active or not:

###### Shadow Dance Priority

1. Cast [[spell:196819]] with [[spell:457058]] and [[spell:1268932]] active at 7 Combo Points.
2. Cast [[spell:280719]] if available at 6+ combo points.
3. Cast [[spell:185438]] if under 5 combo points.
4. Cast [[spell:197835]] as your first builder if you start your dance at 2 or less Combo Points.
5. Cast [[spell:209782]] on cooldown.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with [[spell:457058]] and [[spell:1268932]] active at 7 Combo Points.
2. Cast [[spell:196819]] with 5+ combo points.
3. Cast [[spell:53]].
4. Cast [[spell:209782]] on cooldown.





### AoE



#### [[talent:123370]]

##### Opener

:::rotation **Subtlety Rogue** AoE opener in Mythic+
```json
{
  "source_code": "JkEXHI0yEMAAAAwAC1plCAAAC9n2BAAABwprBQBDAIkdzkACc8ISEAAAAAgQJwCDAIkyebDEAgwT8aA"
}
```
1. [[spell:197835]]  [[spell:169629]] · [[spell:121471]] · [[item:241308]]
2. [[spell:209782]]
3. [[spell:280719]]
4. [[spell:197835]]
5. [[spell:319178]]
6. [[spell:197835]]
7. [[spell:441423]]
:::

##### 4+ Targets Priority List

###### Shadow Dance Priority

1. Cast [[spell:280719]] as your first finisher if above 5 combo points.
2. Cast [[spell:209782]] on cooldown.
3. Cast [[spell:319175]] if above 5 combo points.
4. Cast [[spell:197835]] if under 5 combo points.

###### No Shadow Dance Priority

1. Cast [[spell:319175]] with less than 4 [[spell:441786]] stacks with 5+ Combo Points.
2. Cast [[spell:15691]] if you have 4 [[spell:441786]] stacks with 5+ Combo Points.
3. Cast [[spell:197835]].




#### [[talent:123373]]

##### Opener

:::rotation [[talent:123373]] **Subtlety Rogue** AoE opener in Mythic+
```json
{
  "source_code": "IEFXII0yEMAAAAwAC1plCAAAC9n2BAAABwprBQBMAI0jIRAAAAAAC5F1CUACEMNAJgRC0wAACps3JACKLTwAAAAAAI0T8aA"
}
```
1. [[spell:197835]]  [[spell:169629]] · [[spell:121471]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:185438]]
4. [[spell:196819]]
5. [[spell:197835]]
6. [[spell:319178]]
7. [[spell:197835]]
8. [[spell:441423]]
:::

##### 4+ Targets Priority List

###### Shadow Dance Priority

1. Cast [[spell:209782]] on cooldown.
2. Cast [[spell:280719]] as your second finisher with 5+ combo points.
3. Cast [[spell:319175]] at 5+ combo points.
4. Cast [[spell:197835]] if under 5 combo points.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with 7+ combo points with [[talent:117739]] buff active.
2. Cast [[spell:319175]] with 5+ combo points.
3. Cast [[spell:197835]].





## Deep Dive

:::columns
:::column


:::

:::

#### Deathstalker

- [[talent:123373]] while not as complicated rotational changes as [[talent:123370]] still comes with a few optimizations such as:
  
  - Always building to maximum combo points when [[talent:117739]] is up.
  - Always using [[spell:196819]] as your first finisher whenever [[talent:117739]] is active, even on AoE.

### Eviscerate vs Black Powder

- When to use [[spell:196819]] over [[spell:319175]]  might seem obvious or easy if you simply refer to your priority. However, the reality is not as black and white.

- A lot of people who play **Subtlety Rogue** see a bunch of targets and instantly start pressing [[spell:319175]] without much thought behind it, however, there are situations where you would want to press [[spell:196819]], even if at the cost of  DPS.
- Priority damage to your main targets is often more useful than so called "pad damage" to targets of lesser importance, which is your main consideration when deciding what finisher you decide to use.

### Secret Technique Intricacies

- [[spell:280719]] is your hardest hitting spell, so it's important that you understand how it works and some common mistakes.
- [[spell:280719]] has an initial instant damage part and two delayed shadow clone attacks, one of them being delayed by 1 second and the other by 1.3 seconds. To clarify, this means that the latest time you can press [[spell:280719]] to get its full damage in your [[spell:185313]] window is 1.3 seconds before it ends. This is very important since you lose a lot of damage not getting the damage inside of your [[spell:185313]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Subtlety Rogue** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

#### The Writhing Coil

- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

#### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- **Pay extra attention to these casts:**
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[spell:1856]].




### Den of Nalorakk

:::talents **Subtlety Rogue** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with [[spell:1856]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Subtlety Rogue** Mythic+ Build in Murder Row
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- **Pay extra attention to these casts:**
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Subtlety Rogue** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Subtlety Rogue** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- **Pay extra attention to these casts:**
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.




### Kings' Rest

:::talents **Subtlety Rogue** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- **Pay extra attention to these casts:**
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Subtlety Rogue** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- **Pay extra attention to these casts:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Subtlety Rogue** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- **Pay extra attention to these casts:**
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affixes *-- Rotates on a weekly basis*
  
  - [[spell:1284818]]
- +5 Affixes *-- Rotates of a weekly basis.*
  
  - [[spell:461916]]
  - [[spell:1272895]]+
  - [[spell:465051]]
  - [[spell:1272894]]
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- *Alternates on a weekly basis.*
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Subtlety Rogues**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:2094]] with [[talent:117740]] on your main target, if you use it on the orbs it will not work.
- Xal'atath's Bargain: Voidbound
  
  - Make sure to focus the **Void Emissary** as it buffs nearby mobs and makes them take less damage. Consider funneling this target over using AoE.
- Xal'atath's Bargain: Devour
  
  - You can use [[spell:31224]] if it overlaps with another bad mechanic since it's a heal absorb and can be deadly with bad overlaps. [[spell:212198]] can also help out.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Subtlety Rogues**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Subtlety Rogues** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFMQMkACKBMQAEA"
}
```
**敏捷 ＞ 精通 ≥ 急速 ＞ 暴击 ≫ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** -  Avoidance works similarly to [[spell:1966]], as it provides you with passive AoE damage reduction. However, due to the significant amount of avoidance you already receive from [[spell:1966]], it loses value compared to other classes.
- **Leech** - Provides additional healing through damage dealing. Great stat for staying alive and healthy.
- **Speed** -  Speed is the worst out of the three tertiary stats because you are already very fast, it is of course better than nothing.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271508@DwQAAUQAXk74kgC4UA]] | The Lost Explorers / Catalyst |
| Cloak | [[item:251190@BgQAAMQACKgTBA]] | The Blinding Vale |
| Chest | [[item:271513@DgQAAMQAJk7IoAOF]] | Vashnik the Malignant / Catalyst |
| Wrist | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | Crafting |
| Gloves | [[item:271511@BgQAAMQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:268256@BiQAAUQAS06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]] into [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268261@DgQAAUQAPk7IoAOF]] | The Twin Fangs |
| Ring 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:268249@DiQAAMQA1j7oQrjgC4UA]] | Vashnik the Malignant |
| Trinket 1 | [[item:270175@BgwAAMQACKAWBUAABo0FCA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAUQACKAWBA]] | The Coiled Altar |
| Weapon | [[item:271093@DgQAAMQADk7IoAYF]] | Ula'tek |
| Weapon | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | Crafting |

Subtlety Rogue BiS list in Mythic+




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | Altar of Fangs |
| Neck | [[item:273781@BiQAAMQAH16IoABF]] | Altar of Fangs |
| Shoulder | [[item:251223@DgQAAMQAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:251190@BgQAAMQACKQQBA]] | The Blinding Vale |
| Chest | [[item:251159@DgQAAMQAJk7IoABF]] | Den of Nalorakk |
| Wrist | [[item:251135@BiQAAMQAU06IoABF]] | Murder Row |
| Gloves | [[item:251124@BgQAAMQACKQQBA]] | Murder Row |
| Belt | [[item:159317@BiQAAMQAE06IoABF]] | Temple of Sethraliss |
| Legs | [[item:251130@DgQAAMQAhu7IoABF]] | Murder Row |
| Boots | [[item:159327@DgQAAMQAPk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@DiQAAMQA1j7wPrjgCEUA]] | Temple of Sethraliss |
| Ring 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:250215@BgQAAMQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAAMQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAMQACKAWBUAABo0FCA]]  <br>[[item:270173@AgQAAIoAYFA]] |
| **A-Tier** | [[item:270164@AgQAA8rBOFA]] |
| **B-Tier** | [[item:159617@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **Junkyard** | [[item:270166@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]] |

### Embellishments

- [[item:273059]]
- [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level therefore it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- Your go to flask for all scenarios.*
  - [[item:241324]] *-- If you need to meet the haste requirement.*
- **Food**
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:241304]]
- **Weapon Stone**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  - [[item:240918]]
  - [[item:240908]]
  - [[item:240892]]
  
  
  
  - [[item:240966]] *-- Unique, use one of each gem color to enhance your [[item:240966]].*

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAMQAnk7A]] - [[item:244007]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAUQA]] |
| Cloak |  |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@DAAAAMQAnk7A]] |
| Waist | [[item:275707@DAAAAMQAnk7A]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:243957@BAAAAMQA]] |
| Ring 2 | [[item:243957@BAAAAMQA]] |
| Weapon | [[item:244031]] |
| Weapon | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **Subtlety Rogue** Enchantments in Mythic+
```json
{
  "source_code": "JwFZFEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCo8TuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAMQAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Subtlety Rogues** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dwarf has proven to be valuable historically and continues to be still. The dispell [[spell:65116]] provides is extremely strong compared to other racial effects.
- [[spell:58984]] -- Night Elf
  
  - Run past basically any mob and then cast [[spell:58984]] to make them reset. This works even on mobs with stealth detection, if you get enough distance before you [[spell:58984]] they will simply drop threat and you are safe to continue.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
    
    - Typically not a very strong activate racial for **Subtlety Rogue** in Mythic+ but it does occasionally find some niche usage.

### Recommendation

**Dwarf** Is too good in Mythic+ to ever consider any other race if you're serious about pushing keys with as **Subtlety Rogue**.

## Macros

Discover recommended macros for **Subtlety Rogues** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
**Mouseover [[spell:408]] Macro** - Casts on your mouseover or target if there are is no mouseover target present.

```wow-macro
#showtooltip Kidney Shot
/use [@mouseover,exists][]Kidney Shot
```

**Mouseover Focus macro -** very handy when selecting a focus **target to make you not have to target it.**

```wow-macro
/focus [@mouseover,exists][]
```

:::

:::details Focus Macros
**Focus [[spell:1833]] Macro.**

```wow-macro
#showtooltip Cheap Shot
/cast [@focus] Cheap Shot
```

**Focus [[spell:408]] Macro.**

```wow-macro
#showtooltip Kidney Shot
/cast [@focus] Kidney Shot
```

**Focus [[spell:1766]] Macro.**

```wow-macro
#showtooltip Kick
/cast [target=focus,exists,nodead] [] Kick
```

:::

:::

:::accordion
:::details Shadow Dance Macros
Shadow Dance > Secret Technique. Make sure you are not on GCD

```wow-macro
#showtooltip
/cast Shadow Dance
/cast Secret Technique
```

Shadow Dance > Shuriken Storm

```wow-macro
#showtooltip
/cast Shadow Dance
/cast Shuriken Storm
```

:::

:::

:::accordion
:::details


:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Subtlety Rogue**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://i.gyazo.com/cd27ad7c7ee352aeff1bedbac42220e8.jpg>)

**Subtlety Rogue** Interface

:::accordion
:::details Addons
- **Ellesmere UI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**ROGUE**

- Class
  
  - Thistle Tea is now a choice talent – Players may now choose between the existing version, which casts automatically at low Energy in addition to being usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds). Duration remains unchanged in PvP combat.
- Hero Talents
  
  - Deathstalker
    
    - Fixed an issue that caused Unshakable Drive's bonus to multiply with each stack.
    - Fixed an issue that often caused Unshakable Drive to remove more than one stack per ability use.

- Subtlety
  
  - Developers' notes: We've made some updates to Subtlety's resource economy in Curses of Ula'tek, including the removal of a double-generation bug that made the desired intent and combat feel unclear. Base effect rate and Energy generation of Shadow Techniques are being increased to make moments outside of Shadow Dance feel less starved, while preserving the same proc rate and combo point generation within Shadow Dance. Energy generation should still grow during cooldowns, but not nearly as drastically as before.
  - Goremaw’s Bite has been redesigned – Lash out at your target and 2 additional nearby enemies, inflicting Shadow damage and causing them to Bleed over 14 seconds. 20% of all damage from Finishing Moves is repeated as Shadow, split evenly among affected enemies.
  - Shadowcraft has been updated - While Shadow Dance is active, your Shadow Techniques triggers 25% more frequently and generates 1 additional combo point.
  - All damage dealt increased by 2%. This does not apply to PvP combat.
  - The First Dance now increases Shadow Dance duration by 4 seconds (was 3 seconds).
  - Relentless Strikes now generates 4 Energy per combo point spent on finishing moves (was 5 Energy).
  - Shadow Techniques' base effect frequency has been increased by 40%.
  - Shadow Techniques' Energy generation has been increased to 5 (was 4).
  - Lingering Shadow now also applies to Shuriken Storm.
  - Shadow Dance's tooltip has been updated to include its threat reduction effect.
  - Apex Talent: Ancient Arts now considers the total damage of Secret Technique when creating a shadow clone, instead of only its initial hit.
  - Fixed an issue that caused Secret Technique damage from secondary hits to be attributed to summoned pets instead of the attacking Rogue.
  - Some talents have changed positions in the talent tree.

:::

:::

## FAQ

:::accordion
:::details Q: Why is my Energy so low that I can't hit my buttons sometimes?
A: Pooling Energy is a common aspect of Rogue gameplay. It's normal to sometimes feel like you're struggling with energy, even if you're playing correctly.

:::

:::

---

### Credits

Written By: **Perfecto**

Reviewed By: **Verb**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-17** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-10** Updated for patch 12.0.1.

**2026-01-13** Updated for patch 12.0.

**2025-12-03** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-07-29** Updated for patch 11.2.

**2025-06-19** Updated for patch 11.1.7.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-14** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
