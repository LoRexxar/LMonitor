Welcome to the **Devourer Demon Hunter** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Devourer Demon Hunter** Raid Best in Slot
```json
{
  "source_code": "J8pAQicB3_fABMgJEIIGBAw74OA_sOAZ1chNCKAWBEQ6XQAAZEAAX1aCWQAj1UgFI9KJEIACFAwM5OggC4UAXV9ABQbCSAQCJIBKXU9ABA-FEAIEBAQBNVQNAAbCjgQBqOQAPAPSBfBBBk1uDQAMBAwD5OAGAPAAjY7LgBzt1wgNbWySBEAY7OggIEAAYA8A8z6A3WzSBEgskQAAIUAACKgTBo8FEEQ2XQggQEAA13AsBcBEB4paCIYFUAgtJQBGnF9AAgQAAUAIIQ1HEUBDE09FNwALYFQA0LCBCgQAA8TuFsJOBM7FEIACBAwP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240892]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240892]] |
| 肩部 | [[item:271535]] | [[item:244019]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271536]] | [[item:240133]] |
| 脚部 | [[item:244569]] | [[item:243983]] · [[item:245784]] |
| 腕部 | [[item:244576]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268211]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Devourer Demon Hunter**, you have access to Midnight, which enables [[talent:132281@FAgAMyuE2VvE]] to be an actually pressable button, the first Rank makes it so [[talent:132281@FAgAMyuE2VvE]] always crits, which synergizes very well with talents like [[talent:136691]].

**Rank 2** increases all cosmic damage you deal by 6% and increases the damage of [[talent:132281@FAgAMyuE2VvE]] furthermore since it always critically strikes anyway  
  
Rank 3 enables the use of [[talent:132281@FAgAMyuE2VvE]] as soon as you enter [[talent:132282]] and grants you an additional 5 souls when you enter [[talent:132282]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-devourer-mxr.webp>)

Midnight

:::

:::

## Hero Talents

- [[talent:134251]] and [[talent:136623]] are the new Hero Talent tree options.[[talent:134251]] is currently slighty ahead of [[talent:136623]] in both AoE and Single-Target scenarios.

:::tabs
:::tab [[talent:134251]]
- The [[talent:134253]] talent tree evolves around generating and spending [[talent:135667@FAQAF6zA]] stacks.
- [[talent:135672]], [[talent:135670]] increase haste and reduce damage taken by 2% capped at 3 stacks.
- [[talent:135673@AJADCA]] grants one stack of [[talent:135667]], make sure to spend stacks before casting [[spell:1213649]] to avoid overcapping. This especially tends to happen whenever you enter [[talent:132282]], as people tend to [[spell:1213649]] to get it on cooldown as soon as possible.

:::

:::tab [[talent:136623]]
- The [[talent:136623]] talent tree is generally evolving about being in melee a lot more than the [[talent:134251]] talent tree as it turns the first [[talent:134272@FAQAiVwE]] and [[spell:1239123]] you cast into big [[talent:136613@FAgAtByAOSOB]] explosions around you.
- It is a bit counter intuitive with traits like [[talent:136615]] and [[talent:136608]] as you generally want to be in [[talent:132282]] for as long as possible but it massively increases the damage outside of it.

:::

:::

## Talents

:::tabs
:::tab [[talent:134251]]
:::talents [[talent:134251]] **Devourer Demon Hunter** Raid  Build
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[talent:132282]]
  
  - Entering [[talent:132282]] after collecting 50 souls (35 if talented into [[talent:134331]]) enhance your Consume and Reap, also Fury is slowly being drained the longer you stay in [[talent:132282]], [[spell:1242157]] now grants fury instead of spending it.
- [[talent:132281@FAQAMyuE]]
  
  - Every 30 souls that are collected during [[talent:132282]] grants access to a cast of [[talent:132281@FAQAMyuE]] doing massive damage to your main target and around it, additionally fury drain is significantly slowed during it.

- [[talent:133106]]
  
  - Resets your [[spell:1226019]] after casting [[spell:1213649]].
- [[talent:133110]]
  
  - [[spell:1213649]] deals significantly more damage if you only hit one target, avoid hitting off targets if you do not want to.
- [[talent:132287]]
  
  - [[spell:1226019]] turns into [[talent:132287]] after fully channeling a [[spell:1213649]], massively increasing the damage and adding a frontal AoE component to it.
- [[talent:133512]]
  
  - Allowing you to stay [[talent:132282]] significantly longer and increases your haste with every soul you collect.

#### Class Tree

- [[spell:196718]] 
  
  - This group-wide defensive cooldown creates a zone of [[spell:196718]] at the **Devourer Demon Hunter's** location, granting all allies within it a 15% chance to avoid all damage from incoming attacks.

#### Hero Talents

- [[talent:135667]]
  
  - Consume has a 35% chance to grant you a stack of voidfall, after 3 stacks your next reap does massive aoe damage around it.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Harvesting 4 or more ‍Soul Fragments with ‍Reap has a 20% chance to cause your next ‍Consume to be instant cast and explode in a ‍Soulburst, dealing Cosmic damage to nearby enemies.
- **4-Set:** ‍Soulburst generates 8 ‍Soul Fragments and grants ‍Moment of Craving. ‍Reap deals 20% increased damage.

### Single-Target

:::tabs
:::tab [[talent:134251]]
### Opener

- The **Devourer Demon Hunter's** opener is rather easy, you just spam consumes untill 100 fury, dump it with Void ray and finish with an eradicate, repeat this untill you can enter [[talent:132282]].

:::rotation **Devourer Demon Hunter** single-target opener in Mythic+
```json
{
  "source_code": "JoZAwLXCC5jOHAAAXUlb0lGbgQDIhZXYpxWYixWZgM3b1x2cBI0I1KBAAIEg6cAAAAAACJGtSAAAkIVZwVWY0BCdol2cgMXZxVXZuNWZgUnb0lGbsBSNwAyUvVHbzBgQFRpEAAAACEwZRPAAIEAACKgTBEAiuOAABgUBWBAAZgFBeIaAsADACJGtSAAAAAgQKRpE"
}
```
1. [[spell:473662]] Until 4 available souls [[spell:1226019]]
2. [[spell:473728]]
3. [[spell:1225826]] Repeat this sequence untill 50 Souls
4. [[spell:1217605]]  [[item:250215]] · [[item:241288]]
5. [[spell:1226019]]
6. [[spell:473728]]
7. [[spell:1221150]]
8. [[spell:1225826]]
9. [[spell:1217610]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

- Enter [[talent:132282]] after reaching 50 souls
- Cast [[spell:1213649]] in [[talent:132282]] on cooldown.
- Cast [[talent:132281@FAQAMyuE]]
- Cast [[talent:132287]]
- Cast [[spell:1213649]] outside of [[talent:132282]]
- Cast [[spell:1226019]] if you are at 4. souls to fish for Tier proccs.
- Cast [[spell:1226019]] if you are at 3 stacks of [[talent:135667]].
- Cast [[spell:1217610]]
- Cast [[spell:473662]]

:::

:::

### Multi-Target

:::tabs
:::tab [[talent:134251]]
### Opener

- The **Devourer Demon Hunter's** opener is rather easy, you just spam consumes untill 100 fury, dump it with Void ray and finish with an eradicate, repeat this untill you can enter [[talent:132282]].

:::rotation **Devourer Demon Hunter** AoE opener in Mythic+
```json
{
  "source_code": "JoZAwLXCC5jOHAAAXUlb0lGbgQDIhZXYpxWYixWZgM3b1x2cBI0I1KBAAIEg6cAAAAAACJGtSAAAkIVZwVWY0BCdol2cgMXZxVXZuNWZgUnb0lGbsBSNwAyUvVHbzBgQFRpEAAAACEwZRPAAIEAACKgTBEAiuOAABgUBWBAAZgFBeIaAsADACJGtSAAAAAgQKRpE"
}
```
1. [[spell:473662]] Until 4 available souls [[spell:1226019]]
2. [[spell:473728]]
3. [[spell:1225826]] Repeat this sequence untill 50 Souls
4. [[spell:1217605]]  [[item:250215]] · [[item:241288]]
5. [[spell:1226019]]
6. [[spell:473728]]
7. [[spell:1221150]]
8. [[spell:1225826]]
9. [[spell:1217610]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

- Enter [[talent:132282]] after reaching 50 souls
- Cast [[spell:1213649]] in [[talent:132282]] on cooldown.
- Cast [[talent:132281@FAQAMyuE]]
- Cast [[talent:132287]]
- Cast [[spell:1213649]] outside of [[talent:132282]]
- Cast [[spell:1226019]] if you are at 4. souls to fish for Tier proccs.
- Cast [[spell:1226019]] if you are at 3 stacks of [[talent:135667]].
- Cast [[spell:1217610]]
- Cast [[spell:473662]]

:::

:::

## Deep Dive

### Dead or Alive

The most important part of doing damage and being a useful part of your group is staying alive. With movement being a core part of your damage rotation you NEED to always be aware of your surroundings. Do not [[spell:1234796]], [[spell:1245412]] or [[spell:198793]] into frontal abilities or area of effect zones.

You cannot do damage while you are dead and neither can you stop abilities from going through.

Being able to execute the perfect rotation isn't going to help you if you are lying dead on the floor or if you need externals/healing that your tank would need otherwise.

### Making the most out of Soul Fragment 's

Always remember that Soul Fragment management is a crucial part of maximizing your DPS as **Devourer Demon Hunter**, staying in [[talent:132282]] for as long as possible should be your goal.  
THIS BEING SAID: There are 3 ways of collecting souls,

1. Casting [[spell:1226019]]
2. Auto collecting by too many being on the floor
3. Running over them  
   People tend to forget the second and third way which makes them waste massive amounts of fury and overcap a ton in [[talent:132282]] wasting significant amounts of uptime.  
   Even if it sounds alluring that your reap or eradicate damage is increased by the amount of souls you collect, it is sometimes smart to pick them up by hand to squeeze in another [[talent:132281@FAQAMyuE]] faster to not waste cooldown of [[talent:132278]] or squeezing in another [[talent:132281@FAQAMyuE]] at the end of meta while spamming [[spell:1217610]]'s and running over souls to gain fury and not waste globals on a non soul spawning ability like reap.  
   It also takes some time for the souls to hit you after casting reap as they are collected, walking towards them can help.

### Haste ?!

Even though **Haste** Sims pretty poorly on paper, it is a great stat for multi target scenarios as it smooths your gameplay out by a lot.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to Heroic and Mythic Bosses.

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Devourer Demon Hunter** Nek'Zali
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.

:::

:::tab Entombed Sentinels
:::talents **Devourer Demon Hunter** Entombed Sentinels
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Important to know that [[spell:1284434]] may also spawn on the opposite boss, so try not to stand between them and be careful whenever [[spell:1284434]] spawn.
- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].

:::

:::tab Lost Explorers
:::talents **Devourer Demon Hunter** Lost Explorers
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Pay attention to [[spell:1296062]] casts to have an easier time dodging them.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed after being used once.

:::

:::tab Vashnik
:::talents **Devourer Demon Hunter** Vashnik
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.

:::

:::tab Sszorak
:::talents **Devourer Demon Hunter** Sszorak
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- In case you fail to find a partner to deal with [[spell:1285419]], keep in mind that you can also negate it with a double jump.
- Very important to keep an eye on the [[spell:1305959]] timer and, whenever it's close, scan the platform ahead of time to see where you will need to place it.
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.

:::

:::tab Twin Fangs
:::talents **Devourer Demon Hunter** Twin Fangs
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.

:::

:::tab Coiled Altar
:::talents **Devourer Demon Hunter** Coiled Altar
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].

:::

:::tab Ula'tek
:::talents **Devourer Demon Hunter** Ula'tek
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

-

:::

:::tab Nymrissa Wavecaller
:::talents **Devourer Demon Hunter** Nymrissa Wavecaller
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle, so position accordingly or be ready to negate the knockback with [[talent:80163]] or [[talent:80174]].
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Devourer Demon Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Devourer Demon Hunter** Raid Stat Priorities
```json
{
  "source_code": "IoAJFUQMkACKBMQABA"
}
```
**智力 ＞ 精通 ≥ 急速 ＞ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAgcBvj7wPrDZ1chNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAgcBX16wPrDZ1wYNYFA]] | Ula'tek |
| Shoulder | [[item:271535@DAQBAgcBzk74UAXV9A]] | Tier |
| Cloak | [[item:268253@BAQAAgcBYFA]] | The Coiled Altar |
| Chest | [[item:271540@DAQBAgcBJk74UAXU9A]] | Tier |
| Wrist | [[item:244576@DiQAAgcBYA8wPrzt1sUA]] | Crafting |
| Gloves | [[item:271538@BAQBAgcBOFgyXQA]] | Tier |
| Belt | [[item:268256@BiQAAgcB8z6QWNYF]] | The Coiled Altar |
| Legs | [[item:271536@DAQBAgcBFo6gVABfBB]] | Tier |
| Boots | [[item:244569@FATAAgcBPk7gBwDAjY7LgBzt1wgNbWySBA]] | Crafting |
| Ring 1 | [[item:268249@DiQAAgcB1j7wPrDZ14UA]] | Vashnik |
| Ring 2 | [[item:158366@DCRAAgcB1j7wPrjt1IoAOFA]] | Temple of Sehtraliss |
| Trinket 1 | [[item:250215@BgQAAgcBCKgTBA]] | Murder Row |
| Trinket 2 | [[item:270164@BAQAAgcBOFA]] | The Lost Explorers |
| Weapon | [[item:271092@DAQAAgcB_k7gVA]] & [[item:268211@DAQAAgcB_k7gVA]] | Ulatek & The Coiled Altar |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@BgQAA0QACKQQBA]] | Murder Row |
| Neck | [[item:251173@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAA0QACKQQBA]] | Voidcar Arena |
| Cloak | [[item:251132@BgQAA0QACKQQBA]] | Murder Row |
| Chest | [[item:251159@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:251135@BgQAA0QACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgRAA0QA2IjX1caJBFA]] | Murder Row |
| Belt | [[item:159317@BgQAA0QACKQQBA]] | Temple of Sethraliss |
| Legs | [[item:251130@BgQAA0QACKQQBA]] | Murder Row |
| Boots | [[item:159327@DgQAA0QApk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:273792@BgQAA0QACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:252258@BASAA0QAkVjNy4VNWiSQBA]] | Voidscar Arena |
| Trinket 1 | [[item:250215@BgQAA0QACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAA0QACKQQBA]] | The Blinding Vale |
| Weapon | 2x [[item:273778@AgQAAIoAOFA]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A-Tier** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B-Tier** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C-Tier** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **Junkyard** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### Embellishments

- 1x [[item:251513@DiQAAgcBvk7wPrjIv0RA]]
  
  - Best overall choice of stat budget.
- [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241322]] *-- maximum DPS.***
  
  
  
  - **[[item:241320]] *-- less DPS but more survivability.***
- **Food**
  
  - **[[item:242272]]**
  - **[[item:255845]]**
- **Combat Potion**
  
  - **[[item:241288]]**
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - **[[item:243734]] *-- default***
  - **[[item:243738]]**
- **Augment Rune**
  
  - **[[item:259085@AQAAAoF]]**
- **Sockets**
  
  - **[[item:240967]] *-- Unique***
    
    - **[[item:240890]]**
    - **[[item:240898]]**
    - **[[item:240906]]**
    - **[[item:240914]]**

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAAsQA]]  <br>[[item:244007@BAAAAsQA]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsQA]] |
| Chest | [[item:243977@BAAAAsQA]] |
| Wrist | [[item:275707@BAAAAsQA]] |
| Waist | [[item:275707@BAAAAsQA]] |
| Legs | [[item:240133@BAAAAsQA]] |
| Boots | [[item:244009@BAAAAsQA]] |
| Ring 1 | [[item:243957@BAAAAsQA]] |
| Ring 2 | [[item:243957@BAAAAsQA]] |
| Weapon | [[item:244031@BAAAAsQA]] |

:::

:::column
:::gear **Devourer Demon Hunter** Enchantments in Raids
```json
{
  "source_code": "JwFZIXQ9NGQAnk7ACAAAAsPNEEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYEBCo8TuDAAAAAQA_k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:244007]] | [[item:275707]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAsQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Devourer Demon Hunter** in raiding, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Nightelf
  
  - Provides nothing in Raid, but can be useful in Mythic+ in very niche situations.
- [[spell:202719]] -- Bloodelf
  
  - Removes 1 beneficial effect from hostile targets around you.
  - Generates 15 Fury.
- [[spell:256948]] -- Voidelf
  
  - Tear a rift in space. Reactivate this ability to teleport through the rift.

### Recommendation

It does not really matter which Race you chose for **Devourer Demon Hunter**, as both provide about the same DPS benefits, it is however advised to go Bloodelf as [[spell:202719]] might come in handy in some situations where you need a quick AoE purge and can be used to gain 15 Fury while you are out of range of any target in combat.

## Macros

Discover recommended macros for **Devourer Demon Hunter** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**@Cursor [[spell:1234796]] Macro - *Uses your [[spell:1234796]] at your cursor's location***

```wow-macro
/cast [@Cursor] Shift
```

**@Cursor [[spell:207684]] Macro - *Uses your [[spell:207684]] at your cursor's location***

```wow-macro
/cast [@Cursor] Sigil of Misery
```

:::

:::details Mouseover Macros
**@Mouseover Interrupt Macro - *Interrupts your Mouseover target if you have one, Interrupts your current target if you don't have a Mouseover.***

```wow-macro
/cast [@mouseover,harm,nodead][] Disrupt
```

**@Mouseover [[spell:217832]] Macro** **-** *[[spell:217832]]*'s ***your Mouseover target if you have one, [[spell:217832]]***'s ***your current target if you don't have a Mouseover.***

```wow-macro
/cast [@mouseover,harm,nodead] [] Imprison
```

**@Mouseover [[spell:1234195]] Macro - *Stuns your Mouseover target if you have one, stuns your current target if you don't have a Mouseover.***

```wow-macro
/cast [@mouseover,harm,nodead] [] Void Nova
```

:::

:::details General Macros
**@Player [[spell:207684]] Macro - *Uses your [[spell:207684]] at your current location***

```wow-macro
/cast [@Player] Sigil of Misery
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Devourer Demon Hunter**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/nicememesuimidnight-1-1024x681.png>)

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
Demon Hunters can now equip daggers.

- *Developers' notes: This will allow Devourer Demon Hunters to acquire and use daggers with Intelligence on them.*

**Devourer**

- *Developers' notes: We're reducing the scaling of Devourer's Mastery: Monster Within to help other stats to compete and compensating with an overall ability damage buff. Between that and a few more targeted changes, we expect damage during Void Metamorphosis to be slightly reduced while damage outside of Metamorphosis is significantly increased.*
- Mastery: Monster Within has been updated – Bonus damage during Void Metamorphosis reduced by 66%.
- All ability damage increased by 32%.
- Collapsing Star damage increased by 12%.
- Eradicate damage reduced by 6% and secondary target damage reduced by 15%.
- Consume damage increased by 60% (does not affect Devour).
- Void Metamorphosis now increases Void Ray damage by 40% (was 67%).
- Impending Apocalypse now causes each Collapsing Star to grant 20% increased damage to the next one (was 30%).
- Hungering Slash now properly gives a temporary charge of Vengeful Retreat rather than giving a free cast and also resetting its cooldown.
- Hero Talents
  
  - Annihilator
    
    - Otherworldly Focus now increases Collapsing Star and Voidfall Meteor damage against a single target by 30% (was 35%).
    - Final Hour now causes Voidfall bonuses to persist for 6 seconds (was 8 seconds).

:::

:::

---

### Credits

Written By: **Nicememes**

Reviewed By: **Verb**

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1

**2026-06-22** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-01-20** Updated for patch 12.0



:::
