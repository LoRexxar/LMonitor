欢迎来到魔兽世界12.1版本的**敏锐 潜行者** 团队副本攻略！本攻略涵盖了你需要了解的关于你角色的一切！你是刚起步、从80级开始练级的玩家吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 4/5 · 强

弱 · 2/5 · 一般

功能性 · 1/5 · 较差

生存能力 · 5/5 · 极佳

机动性 · 5/5 · 极佳



:::

:::

:::column
:::gear **敏锐 潜行者** 团队副本 最佳配装
```json
{
  "source_code": "JUpAwTVBBc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOA_sOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADQgt7AECSAAkBwDYiqDIQrDAQBBwiIvsUABcJJEAACBAQBmBC3XQggIEAA1jbAKWgEAkdFSAgCBwGJOFQAf9BBAgwAAEQacUAABo0FCEQXBIRAChBWBEgNVPAAFwAEOFQA1LSBESwP5WglUEQDhOgBIUAhkMQuDQqKEIyLLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240892]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:251190]] |  |
| 主手 | [[item:271093]] | [[item:244031]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **敏锐 潜行者**，你可以使用 诡谋承袭，使你通过 [[spell:196911]] 产生的连击点有15%的几率制造一个暗影分身，以50%的正常伤害重复该攻击，造成暗影伤害。

**等级2** 使暗影分身每消耗一点天赋点数有50%/100%的几率触发 [[spell:196911]] 效果。

而在**等级3**下，如果你在使用生成技能时拥有5层或更多[[spell:196911]]，你的下一个终结技将消耗它们以产生最大连击点数。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-subtlety-mxr.webp>)

诡谋承袭

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:112612]]
    
    - 使你的[[spell:169629]]随急速缩放，急速越高持续时间越长。
  - [[talent:112627]]
    
    - 该天赋已改动，现在使你的[[spell:53]]或[[spell:185438]]有15%几率制造一个暗影分身，以暗影伤害重复该攻击，造成50%的伤害。
  - [[talent:112628]]
    
    - 暗影分身伤害提高15%。同时使你的[[spell:1833]]和[[spell:408]]制造一个攻击目标的分身。
  - [[talent:112605]]
    
    - 已改动，现在使你的[[spell:197835]]有15%几率制造一个分身，以50%的普通伤害重复该攻击。
  - [[talent:112604]]
    
    - 已改动，使你的暗影分身增强15%，并有额外5%的几率召唤它们。
  - [[talent:112623]]
    
    - 已改动，现在你在[[spell:169629]]或[[spell:1784]]中造成10%的伤害。
  - [[talent:112618]]
    
    - 已改动，现在只要你每次在[[spell:169629]]中使用不同的技能，就会造成额外伤害。
  - [[talent:112606]]
    
    - 如果你消耗5个或更多连击点数，使你的[[spell:319175]]基于精通额外造成30%伤害。
  - [[talent:112594]]
    
    - 已改动，只是在[[spell:169629]]期间使你的终结技每级增强10%。
- **职业天赋树**
  
  - [[talent:112636]]
    
    - 敏捷提高3%。
  
  
  
  - [[talent:112639]]
    
    - 不再是一个主动技能，现在由你的连击点数生成技能触发，使你下一个终结技爆击几率提高10%。
  - [[talent:112644]]
    
    - 来自你的[[spell:5171]]的额外攻击速度。
- **已移除**
  
  - [[spell:323654]]
  - [[spell:393972]]
  - [[spell:394023]]
  - [[spell:278683]]
  - [[spell:1943]]
  - [[spell:394309]]
  - [[spell:212283]]

## 英雄天赋

:::tabs
:::tab [[talent:123370]]
- 使你的[[spell:185438]]和[[spell:53]]以[[talent:117737]]打击你的目标。*持续10秒，冷却15秒。*
  
  - [[talent:117737]]施加[[spell:441224]]，使目标受到你的伤害提高8%，且无法招架，这非常不错。尤其是对那些你需要长时间待在 Boss 正面输出的战斗。
  - [[talent:117737]]还会为你施加1层[[spell:441786]]增益。
    
    - 当[[spell:441786]]达到4层时，你的下一个[[spell:2098]]变为[[talent:117712]]。
  - [[talent:117712]]打击你的目标时，如同你的[[spell:15691]]额外拥有5个连击点。

- [[talent:120130]]
  
  - 这是一个相当不错的防御技能，为你的技能组合增添了一些坦度。
- [[talent:117708]]
  
  - 这是天赋树中一个具有协同效应的天赋，除了为你的终结技提供固定的百分比加成外，还能与 [[talent:117725]] 和 [[talent:117712]] 配合。
- [[talent:117731]]
  
  - 这是一个非常实用的提升游戏体验的天赋。
- [[talent:117725]]
  
  - [[talent:117708]] 的覆盖率相当不错，因此为你的顺劈斩提供固定伤害加成是不错的选择。
- [[talent:117715]]
  
  - [[spell:280719]] 使你的 [[spell:441144]] 无视其冷却时间。
- [[talent:136023]]
- [[talent:136022]]
- [[talent:136021@AJABBA]]

:::

:::tab [[talent:123373]]
- 你的 [[spell:185438]] 会给目标施加 3 层 [[talent:117733]]。 
  
  - 你只能同时激活 1 个 [[talent:117733]]。
  - 消耗一层[[talent:117733]]，需使用一个5 连击点 或更高星级的终结技。
  - 你只能通过 [[spell:185438]] 施加 [[talent:117733]]

- 在消耗完[[talent:117733]]的最后一层后，或者当[[talent:117733]]处于激活状态时一个小怪死亡，你将获得[[talent:117739]]。
  
  - 当[[talent:117739]]生效时，务必确保你的下一个终结技是带7层[[spell:15691]] 连击点.
  
  
  
  - 当你消耗[[talent:117739]]时，你会对你当前目标小怪施加[[talent:117733]]。
- 你也可以用[[spell:1293340]]来移动你的标记。

此外，天赋树中还有几个重要的顶级天赋。

- [[talent:117707]]
- [[talent:117732]]。
- [[talent:126029]]
  
  - 一个防御节点，使[[talent:112657]]更加强力。[[talent:117703]]也很有意思，但更依赖具体战斗情况。
- [[talent:136020]]
  
  - 被动暴击加成。
- [[talent:136019]]
  
  - 每次施加印记时带来一点额外效果，但实际上影响不大。
- [[talent:136018@AJAB]]
  
  - 在范围伤害或多目标场景中增加一些额外伤害，忽略你的主目标。
- [[spell:457055]]
  
  - 为你的主目标提供一点额外的伤害汇聚。

:::

:::

## 天赋

:::tabs
:::tab [[talent:123373]] - 单体
:::talents [[talent:123373]] **敏锐 潜行者** 团本中的单体天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 专精树

- [[spell:185313]]
  
  - [[spell:185313]]使你进入一种姿态，在其持续时间内你可以使用所有潜行技能，同时增强你的伤害。这是你冷却窗口期的核心技能，也是你核心玩法的重要组成部分。
- [[spell:382528]]
  
  - 该天赋使你在[[spell:185313]]期间每施放一个不同的法术都会造成额外伤害。
- [[spell:426594]]
  
  - 该天赋修改你的[[spell:185313]]，使其从[[spell:196911]]中产生双倍连击点数，并且当你的连击点数足够填满连击点数条时，你的终结技也会产生连击点数。
- [[spell:121471]]
  
  - [[spell:121471]]使你的大部分伤害提高26%，并且你所有的连击点数生成技能产生双倍连击点数。

#### 职业树

- [[talent:114737]]
  
  - 你最强大的防御技能，让你可以毫无顾忌地激进输出，不必担心死亡。

#### 英雄天赋

- [[talent:117706]]
  
  - 这是你在所有情况下的默认选择，因为 [[talent:126030]] 在数值上明显更弱。
- [[talent:126029]] 
  
  - 这几乎是你所有情况下的默认选择，[[talent:117703]] 可能有一定价值但非常小众，而 [[talent:126029]] 全面扎实。
- [[talent:117720]]
  
  - 这是你的默认选择，因为 [[talent:126027]] 在团队副本战斗中没有任何作用。
- [[talent:117728]]
  
  - 这是你在大多数情况下的默认选择，[[talent:126028]] 是另一个选项。目前 [[talent:117728]] 在数值上似乎稍强一些。

:::

:::tab [[talent:123370]] 单体
:::talents [[talent:123370]] **敏锐 潜行者** 团本中的单体和顺劈天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA"
}
```
:::

**700以上 急速最低要求**

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 英雄天赋

已更改为 [[talent:123373]] 至 [[talent:123370]]，更多信息请访问上方英雄天赋章节。

- [[talent:120132]] 
  
  - 由于 [[talent:117713]] 并不出色，这是你在所有情况下的默认选择。
- [[talent:117734]]
  
  - 由于 [[talent:120131]] 看起来更像是一个 PvP 天赋，这是你在所有情况下的默认选择。
- [[talent:117738]]
  
  - 相比之下 [[talent:120130]] 更差，这是你在所有情况下的默认选择。
- [[talent:117731]]
  
  - 虽然对团队副本用处不大，但另一个选项更加无用。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套**：[[spell:53]] 消耗的能量减少10点，伤害提高100%。[[spell:197835]] 消耗的能量减少5点，伤害提高60%。
- **4件套**：[[talent:112619]] 现在也能以100%的效果作用于[[spell:15691]] 和[[spell:319175]]。

### 单体目标

:::tabs
:::tab [[talent:123370]]
### 起手爆发

- 作为 **敏锐 潜行者**，你使用冷却技能的主要目标是尽可能多地叠加它们，以获得最大的爆发潜力。在尽可能高效地使用冷却技能时，有几条优先级和规则需要遵循。

:::rotation [[talent:123370]] **敏锐 潜行者** 单目标团队副本 起手
```json
{
  "source_code": "JEGgKIkXULAAAAwACFo2BAAACF-0CAAABwprDAAAAAgQPiEBFgAB2NTCQAgXFwCEAI0S9AQABUBC-gBAo4F1CAAAAAgQPiEB"
}
```
1. [[spell:185438]]  [[spell:121473]] · [[spell:185313]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:209782]]
4. [[spell:185438]]
5. [[spell:15691]]
6. [[spell:15691]]
7. [[spell:185438]]
8. [[spell:15691]]
9. [[spell:185438]]
10. [[spell:280719]]
:::

1. 当你的 [[spell:121471]] 剩余 8 秒时，使用你的第二个 [[spell:169629]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

**敏锐 潜行者** 的循环优先级会根据你是否激活了 [[spell:185313]] 而改变：

#### 暗影之舞 优先级

1. 若连击点数高于5点，则施放 [[spell:280719]] 作为你的第一个终结技。
2. 如果你的目标是 [[spell:441224]] 且 [[talent:112578]] 已生效，在连击点数高于5点时施放 [[spell:196819]]。
3. 如果连击点数低于 5 点，则施放 [[spell:185438]]。
4. 在冷却完毕时施放 [[spell:209782]]。

#### 无 暗影之舞 优先级

1. 在连击点数达到 6 点以上且 [[spell:441786]] 层数少于 4 层时施放 [[spell:196819]]。
2. 施放 [[spell:53]]。

#### 冷却技能使用

- 施放 [[spell:121471]]。
- 施放 [[spell:185313]]
- 在连击点数达到 6 点及以上时，于冷却完毕时施放 [[spell:280719]]。
- 在冷却完毕时施放 [[spell:209782]]。

:::

:::tab [[talent:123373]]
### 起手爆发

:::rotation [[talent:123373]] **敏锐 潜行者** 单目标团队副本 起手
```json
{
  "source_code": "JYcAQ2gQeRtAAAAABIEX5bAAAI0S9AAAA8gMgMFdhN2azBybmBCRT1UEdADQHAAAAAgACtMBDAAAuEDAE4QMJEjOwAAC2NzABEDCCF-0BMGBEIUH4gQAc6aCcASgaHAAAI0jIRQBFSgY5HQhE4F1BADEBIExcNRET2BCA4VBeADACtUPAAAAAAgQeRtA"
}
```
1. [[spell:185438]]  [[spell:457052]]
2. [[spell:15691]] DSM 2 层 [[spell:457052]]
3. [[spell:1856]]  [[spell:197835]] · [[spell:457052]]
4. [[spell:15691]] DSM 1 层 [[spell:457052]]
5. [[spell:209782]]
6. [[spell:185313]]  [[spell:197835]] · [[spell:457052]] · [[item:241308]] · [[spell:121473]]
7. [[spell:280719]]  [[spell:457058]]
8. [[spell:185438]]  [[spell:1268932]]
9. [[spell:15691]]
10. [[spell:15691]]
11. [[spell:185438]]
12. [[spell:15691]]
13. [[spell:185438]]
:::

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

**敏锐 潜行者** 的循环优先级会根据你是否激活了 [[spell:185313]] 而改变：

#### 暗影之舞 优先级

1. 在连击点数达到 7 点时，在 [[spell:457058]] 和 [[spell:1268932]] 激活的状态下施放 [[spell:196819]]。
2. 如果在 6 点或以上连击点数时可用，则施放 [[spell:280719]]。
3. 如果连击点数低于 5 点，则施放 [[spell:185438]]。
4. 如果你在 2 点或更少连击点数时开始你的舞步，则将 [[spell:197835]] 作为你的第一个攒点技能施放。
5. 在冷却完毕时施放 [[spell:209782]]。

#### 无 暗影之舞 优先级

1. 在连击点数达到 7 点时，在 [[spell:457058]] 和 [[spell:1268932]] 激活的状态下施放 [[spell:196819]]。
2. 在连击点数达到5点或以上时施放 [[spell:196819]]。
3. 施放 [[spell:53]]。
4. 在冷却完毕时施放 [[spell:209782]]。

:::

:::

### 2个目标

:::tabs
:::tab [[talent:123370]]
### 起手爆发

- 作为 **敏锐 潜行者**，你使用冷却技能的主要目标是尽可能多地叠加它们，以获得最大的爆发潜力。在尽可能高效地使用冷却技能时，有几条优先级和规则需要遵循。

:::rotation [[talent:123370]] **敏锐 潜行者** 单目标团队副本 起手
```json
{
  "source_code": "JEGgKIkXULAAAAwACFo2BAAACF-0CAAABwprDAAAAAgQPiEBFgAB2NTCQAgXFwCEAI0S9AQABUBC-gBAo4F1CAAAAAgQPiEB"
}
```
1. [[spell:185438]]  [[spell:121473]] · [[spell:185313]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:209782]]
4. [[spell:185438]]
5. [[spell:15691]]
6. [[spell:15691]]
7. [[spell:185438]]
8. [[spell:15691]]
9. [[spell:185438]]
10. [[spell:280719]]
:::

1. 当你的 [[spell:121471]] 剩余 8 秒时，使用你的第二个 [[spell:169629]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

**敏锐 潜行者** 的循环优先级会根据你是否激活了 [[spell:185313]] 而改变：

#### 暗影之舞 优先级

1. 若连击点数高于5点，则施放 [[spell:280719]] 作为你的第一个终结技。
2. 如果你的目标是 [[spell:441224]] 且 [[talent:112578]] 已生效，在连击点数高于5点时施放 [[spell:196819]]。
3. 如果连击点数低于 5 点，则施放 [[spell:185438]]。
4. 在冷却完毕时施放 [[spell:209782]]。

#### 无 暗影之舞 优先级

1. 在连击点数达到 6 点以上且 [[spell:441786]] 层数少于 4 层时施放 [[spell:196819]]。
2. 施放 [[spell:53]]。
3. 在冷却完毕时施放 [[spell:209782]]。

#### 冷却技能使用

- 施放 [[spell:121471]]。
- 施放 [[spell:185313]]
- 在连击点数达到 6 点及以上时，于冷却完毕时施放 [[spell:280719]]。
- 在冷却完毕时施放 [[spell:209782]]。

:::

:::tab [[talent:123373]]
### 起手爆发

:::rotation [[talent:123373]] **敏锐 潜行者** 单目标团队副本 起手
```json
{
  "source_code": "JYcAQ2gQeRtAAAAABIEX5bAAAI0S9AAAA8gMgMFdhN2azBybmBCRT1UEdADQHAAAAAgACtMBDAAAuEDAE4QMJEjOwAAC2NzABEDCCF-0BMGBEIUH4gQAc6aCcASgaHAAAI0jIRQBFSgY5HQhE4F1BADEBIExcNRET2BCA4VBeADACtUPAAAAAAgQeRtA"
}
```
1. [[spell:185438]]  [[spell:457052]]
2. [[spell:15691]] DSM 2 层 [[spell:457052]]
3. [[spell:1856]]  [[spell:197835]] · [[spell:457052]]
4. [[spell:15691]] DSM 1 层 [[spell:457052]]
5. [[spell:209782]]
6. [[spell:185313]]  [[spell:197835]] · [[spell:457052]] · [[item:241308]] · [[spell:121473]]
7. [[spell:280719]]  [[spell:457058]]
8. [[spell:185438]]  [[spell:1268932]]
9. [[spell:15691]]
10. [[spell:15691]]
11. [[spell:185438]]
12. [[spell:15691]]
13. [[spell:185438]]
:::

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

**敏锐 潜行者** 的循环优先级会根据你是否激活了 [[spell:185313]] 而改变：

#### 暗影之舞 优先级

1. 在连击点数达到 7 点时，在 [[spell:457058]] 和 [[spell:1268932]] 激活的状态下施放 [[spell:196819]]。
2. 如果在 6 点或以上连击点数时可用，则施放 [[spell:280719]]。
3. 如果连击点数低于 5 点，则施放 [[spell:185438]]。
4. 如果你在 2 点或更少连击点数时开始你的舞步，则将 [[spell:197835]] 作为你的第一个攒点技能施放。

#### 无 暗影之舞 优先级

1. 在连击点数达到 7 点时，在 [[spell:457058]] 和 [[spell:1268932]] 激活的状态下施放 [[spell:196819]]。
2. 在连击点数达到5点或以上时施放 [[spell:196819]]。
3. 施放 [[spell:53]]。

:::

:::

### 4+个目标

:::tabs
:::tab [[talent:123370]]
### 起手爆发

:::rotation **敏锐 潜行者** 团队副本中的范围伤害起手
```json
{
  "source_code": "JkEXHI0yEMAAAAwAC1plCAAAC9n2BAAABwprBQBDAIkdzkACc8ISEAAAAAgQJwCDAIkyebDEAgwT8aA"
}
```
1. [[spell:197835]]  [[spell:169629]] · [[spell:121471]] · [[item:241308]]
2. [[spell:209782]]
3. [[spell:280719]]
4. [[spell:197835]]
5. [[spell:319178]]
6. [[spell:197835]]
7. [[spell:441423]]
:::

### 4 个以上目标优先级列表

#### 暗影之舞 优先级

1. 如果连击点数高于 5 点，将 [[spell:280719]] 作为你的第一个终结技施放。
2. 冷却完毕即施放 [[spell:209782]]。
3. 如果连击点数高于 5 点，施放 [[spell:319175]]。
4. 如果连击点数低于 5 点，施放 [[spell:197835]]。

#### 无 暗影之舞 优先级

1. 在拥有5+连击点数且[[spell:441786]]层数少于4层时施放[[spell:319175]]。
2. 在拥有5+连击点数且[[spell:441786]]层数达到4层时施放[[spell:15691]]。
3. 施放[[spell:197835]]。

:::

:::tab [[talent:123373]]
### 起手爆发

:::rotation [[talent:123373]] **敏锐 潜行者** 团队副本中的范围伤害起手
```json
{
  "source_code": "IEFXII0yEMAAAAwAC1plCAAAC9n2BAAABwprBQBMAI0jIRAAAAAAC5F1CUACEMNAJgRC0wAACps3JACKLTwAAAAAAI0T8aA"
}
```
1. [[spell:197835]]  [[spell:169629]] · [[spell:121471]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:185438]]
4. [[spell:196819]]
5. [[spell:197835]]
6. [[spell:319178]]
7. [[spell:197835]]
8. [[spell:441423]]
:::

### 4 个以上目标优先级列表

#### 暗影之舞 优先级

1. 冷却完毕即施放 [[spell:209782]]。
2. 在连击点数达到 5 点以上时，将 [[spell:280719]] 作为你的第二个终结技施放。
3. 在连击点数达到 5 点以上时，施放 [[spell:319175]]。
4. 如果连击点数低于 5 点，施放 [[spell:197835]]。

#### 无 暗影之舞 优先级

1. 在[[talent:117739]]增益激活时，以7个以上连击点数施放[[spell:196819]]。
2. 以5个以上连击点数施放[[spell:319175]]。
3. 施放[[spell:197835]]。

:::

:::

## 深度解析

:::columns
:::column


:::

:::

#### 死亡猎手

- [[talent:123373]]虽然不像[[talent:123370]]那样有复杂的循环变化，但仍有一些优化技巧，例如：
  
  - 当[[talent:117739]]激活时，始终将连击点攒到最大，并触发你的[[spell:1268932]]。

### 刺骨 vs 黑火药

- 什么时候该用[[spell:196819]]而不是[[spell:319175]]，如果只是简单参照你的优先级，答案似乎显而易见或很容易。但实际情况并非如此非黑即白。

- 许多玩 **敏锐 潜行者** 的玩家一看到一大群目标就会不加思索地立刻开始按 [[spell:319175]]，然而在某些情况下，你应该优先按下 [[spell:196819]]，即使这会牺牲一些 DPS。
- 对主要目标造成优先伤害往往比对次要目标打出所谓的"凑数伤害（pad damage）"更有价值，这也是你决定使用哪个终结技时的核心考量。

### 影分身的使用细节

- [[spell:280719]] 是你伤害最高的技能，因此理解它的机制以及一些常见错误非常重要。
- [[spell:280719]] 有一段初始即时伤害和两次延迟的暗影克隆攻击，其中一次延迟1秒，另一次延迟1.3秒。需要说明的是，这意味着你可以在 [[spell:280719]] 结束前1.3秒按下它，以确保其全部伤害都落在你的 [[spell:185313]] 窗口内。这一点非常重要，因为如果伤害没有打在你的 [[spell:185313]] 之内，你会损失大量伤害。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **敏锐 潜行者** 内克扎莉天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

### 首领攻略技巧

- 注意[[spell:1284103]]的计时条，切勿站在首领与其技能目标坦克之间。
- 提前观察小怪的尸体位置，以便更轻松地应对[[spell:1294742]]净化它们的减益效果。

:::

:::tab 陵寝哨兵
:::talents **敏锐 潜行者** 陵寝哨兵天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

### 首领攻略技巧

- 注意观察首领的能量，在其即将达到100时务必分散站位，这样能让转阶段阶段更加轻松。
- 总体而言，要留意自己的站位，尽量贴近首领输出，这样就不用担心[[spell:1284494]]和[[spell:1284503]]的层数问题。
- 查看团队框架，在转阶段阶段使用你的[[spell:36554]]来清除叠加的增益效果。

:::

:::tab 迷失的探险者
:::talents **敏锐 潜行者** 迷失的探险者天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA"
}
```
:::

### 首领攻略技巧

- 注意[[spell:1296062]]，尽量把它们引到房间外围。
- 不要过度吸收[[spell:1291934]]，因为它会给你施加一个不断叠加的**流血**负面效果。
- 小心[[spell:1292105]]产生的蘑菇，因为它们在使用一次后就会被消耗掉。

:::

:::tab 瓦什尼克
:::talents **敏锐 潜行者** 瓦什尼克天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

### 首领攻略技巧

- 每当 [[spell:1281907]] 减益效果即将到来时，务必提前分散，并尽可能不要将它对准首领。
- 请记住，击杀 **燃烧毒液** 会给你叠加一层减益效果，所以要避免同时击杀它们。

:::

:::tab 斯索拉克
:::talents **敏锐 潜行者** 斯索拉克天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

### 首领攻略技巧

- 如果你找不到队友来处理[[spell:1285419]]，请记住你也可以用[[spell:36554]]或[[spell:31224]]来化解它。
- 当你被[[spell:1287072]]命中时使用防御冷却技能，因为它会对你施加一个可叠加的**中毒**负面效果。

:::

:::tab 双牙
:::talents **敏锐 潜行者** 双牙天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

- 在这场战斗中，拥有一个良好的负面效果监控手段极其重要，因为[[spell:1290336]]在达到一定层数后必定会致死，具体层数取决于难度。
- 当你成为[[spell:1291478]]的目标时，尽量不要到处乱跑。如果需要躲避什么，最好沿自己的直线移动。
- 别忘了吸收[[spell:1290516]]也会将你击退，所以在那期间要小心[[spell:1290956]]产生的波纹。
- 每当[[spell:1294293]]发生时，观察场地中央的**维克苏尔** ，你会发现有一些围绕他旋转的小球，它们指示了他施放光束的方向。

:::

:::tab 盘绕祭坛
:::talents **敏锐 潜行者** 盘绕祭坛天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

- 小心 [[spell:1282403]]，如果有需要，确保协助将它们移动到别处。
- 要格外注意 [[spell:1285643]] 之后刷新的幽灵，因为处理它们将是这个阶段最难的部分。
  
  - 即使你没有被幽灵点名，也请确保不要停留在它们附近，因为它们会被 [[spell:1286620]] 的正面劈砍清理掉，这是消灭它们的唯一办法。
- 每当你被 [[spell:1286895]] 点名时，使用一个防御冷却技能。

:::

:::tab 乌拉特克
:::talents **敏锐 潜行者** 乌拉特克天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

:::

:::tab 尼姆瑞莎·唤波者
:::talents **敏锐 潜行者** 尼姆瑞莎·唤波者天赋
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

- 请记住，[[spell:1258673]]发生后[[spell:1258150]]会把你从中部击退，因此要相应地站位，或准备好用[[spell:36554]]来化解击退效果。
- 每当[[spell:1281393]]被触发时，使用一个防御冷却技能。

:::

:::

## 属性优先级

了解你在 团队副本 Boss 战期间获得最佳表现所需的次要属性优先级和第三属性，作为一名 **敏锐 潜行者**。欲了解更多详细信息，请访问 **[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority **敏锐 潜行者** 团队副本 中的属性优先级
```json
{
  "source_code": "JoAJFMQMkACKBMQABA"
}
```
**敏捷 ＞ 精通 ≥ 急速 ＞ 暴击 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** -  闪避的运作方式与[[spell:1966]]类似，它为你提供被动的范围伤害伤害减免。因此，由于你已经从[[spell:1966]]获得了大量闪避，与其他职业相比，它的价值有所降低。
- **吸血** - 通过造成伤害来提供额外治疗。是保持生存和健康的优秀属性。
- **速度** -  速度是三种副属性中最差的，因为你已经非常快了，不过当然，有总比没有好。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | 乌拉特克 |
| 项链 | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | 乌拉特克 |
| 肩部 | [[item:271508@DwQAAUQAXk74kgC4UA]] | 迷失的探险者 / 催化 |
| 披风 | [[item:251190@BgQAAMQACKgTBA]] | 夺目谷 |
| 胸部 | [[item:271513@DgQAAMQAJk7IoAOF]] | 万毒邪祟者瓦什尼克 / 催化 |
| 护腕 | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | 制造业 |
| 手部 | [[item:271511@BgQAAMQACKgTBA]] | 陵寝哨兵 / 催化 |
| 腰带 | [[item:268256@BiQAAUQAS06IoAYF]] | 盘卷祭坛 |
| 腿部 | 将 [[item:268225@AgQAAIoAYFA]] 转换为 [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | 盘卷祭坛的催化 |
| 脚部 | [[item:268261@DgQAAUQAPk7IoAOF]] | 双子毒牙 |
| 戒指 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | 斯索拉克 |
| 戒指 2 | [[item:268249@DiQAAMQA1j7oQrjgC4UA]] | 万毒邪祟者瓦什尼克 |
| 饰品 1 | [[item:270175@BgwAAMQACKAWBUAABo0FCA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgQAAUQACKAWBA]] | 盘卷祭坛 |
| 武器 | [[item:271093@DgQAAMQADk7IoAYF]] | 乌拉特克 |
| 武器 | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | 制造业 |

敏锐 潜行者 最佳配装 团本列表

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | 毒牙祭坛 |
| 颈部 | [[item:273781@BiQAAMQAH16IoABF]] | 毒牙祭坛 |
| 肩部 | [[item:251223@DgQAAMQAXk7IoABF]] | 虚空之痕竞技场 |
| 披风 | [[item:251190@BgQAAMQACKQQBA]] | 夺目谷 |
| 胸部 | [[item:251159@DgQAAMQAJk7IoABF]] | 纳洛拉克的洞穴 |
| 护腕 | [[item:251135@BiQAAMQAU06IoABF]] | 密谋小径 |
| 手套 | [[item:251124@BgQAAMQACKQQBA]] | 密谋小径 |
| 腰带 | [[item:159317@BiQAAMQAE06IoABF]] | 塞塔里斯神庙 |
| 腿部 | [[item:251130@DgQAAMQAhu7IoABF]] | 密谋小径 |
| 靴子 | [[item:159327@DgQAAMQAPk7IoABF]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:158366@DiQAAMQA1j7wPrjgCEUA]] | 塞塔里斯神庙 |
| 戒指 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | 毒牙祭坛 |
| 饰品 1 | [[item:250215@BgQAAMQACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250259@BgQAAMQACKQQBA]] | 夺目谷 |
| 武器 | [[item:275070@DgQAAMQADk7IoABF]] | 毒牙祭坛 |
| 武器 | [[item:275070@DgQAAMQADk7IoABF]] | 毒牙祭坛 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgwAAMQACKAWBUAABo0FCA]]  <br>[[item:270173@AgQAAIoAYFA]] |
| **A级** | [[item:270164@AgQAA8rBOFA]] |
| **B级** | [[item:159617@AgQAAIoAOFA]] |
| **C级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **垃圾级** | [[item:270166@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]] |

### 美化饰品

- [[item:273059]]
- [[item:240166]]

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药剂**
  
  - [[item:241322]] *-- 适用于所有场景的首选合剂。*
  - [[item:241324]] *-- 如果你需要满足急速需求时使用。*
- **食物**
  
  - [[item:266985]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器磨刀石**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240900]]
  
  
  
  - [[item:240918]]
  - [[item:240908]]
  - [[item:240892]]
  
  
  
  - [[item:240966]] *-- 唯一，每种颜色的宝石各使用一颗来增强你的[[item:240966]]。*

### 附魔

:::columns
:::column
| 头部 | [[item:275707@DAAAAMQAnk7A]] - [[item:244007]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAUQA]] |
| 披风 |  |
| 胸部 | [[item:243977@BAAAAMQA]] |
| 腕部 | [[item:275707@DAAAAMQAnk7A]] |
| 腰部 | [[item:275707@DAAAAMQAnk7A]] |
| 腿部 | [[item:244641@BAAAAMQA]] |
| 脚部 | [[item:244009@BAAAAMQA]] |
| 戒指 1 | [[item:243957@BAAAAMQA]] |
| 戒指 2 | [[item:243957@BAAAAMQA]] |
| 武器 | [[item:244031]] |
| 武器 | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **敏锐 潜行者** 团队副本中的附魔
```json
{
  "source_code": "JwFZFEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCo8TuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> 你可以从宏伟宝库商贩处购买[[item:275707@DAAAAMQAnk7A]]，为你的**头盔**、**护腕** & **腰带**添加插槽。

## 种族

如果想要将**敏锐 潜行者** 在团队副本中的表现发挥到极致，不同的种族天赋可以为你的角色带来巨大的收益。如果这并不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:312924]] -- 机械侏儒
  
  - 并不是一个特别有用的主动种族天赋。不过两个被动种族天赋 [[spell:312916]] 和 [[spell:312923]] 都相当强力，使机械侏儒成为一个不错的选择。
- [[spell:65116]] -- 矮人
  
  - 可以 驱散魔法 并移除流血减益效果。过去在一些有流血机制的首领战中曾有用。
- [[spell:255654]] -- 至高岭牛头人
  
  - 冲锋 向前冲锋并眩晕敌人1.5秒，对团本来说不是最实用的技能，但你可以获得 [[spell:255658]]，这是一个被动全能提升。
- [[spell:33702]] --兽人
  
  - 强力的输出种族天赋，尤其适合 [[talent:112607]] 流派，因为你的 [[spell:121471]] 是一个2分钟冷却的技能。
- [[spell:20549]] -- 牛头人
  
  - 通常对团本来说不是最实用的法术，但与矮人类似，[[spell:154743]] 被动是牛头人成为强力输出种族的主要原因。
- [[spell:256948]] -- 虚空精灵
  
  - 这个技能相当不错，它的作用类似于闪现，先以弹体形式射出，然后再次激活传送到弹体所在位置。然而，虚空精灵成为强力输出种族的原因是 [[spell:255669]]。
- [[spell:59752]] -- 人类
  
  - 这个法术很少有好的使用场景，但偶尔也会有用。人类成为强力选择的主要原因得益于 [[spell:20598]] 被动。请注意，人类的收益会随你拥有的次要属性增多而进一步提升，因此在资料片初期可能效果一般，但后期会变得更强。

### 推荐

总的来说，可以肯定的是：如果你追求输出最大化，就应该选择输出最高的种族天赋。不过，如果是开荒团本，情况就有所不同了。有些种族天赋能极大加快特定首领的进度。值得注意的是，矮人凭借其 [[spell:65116]]，在最近的世界首杀竞速中，由于能在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键节点轻松自我驱散，提供了巨大帮助。

## 宏

了解 **敏锐 潜行者** 在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**鼠标指向[[spell:408]]宏**——若无鼠标指向目标则施放到鼠标指向目标或当前目标上。

```wow-macro
#showtooltip 肾击
/use [@mouseover,exists][]肾击
```

**鼠标指向焦点宏——**在选定焦点**目标时非常实用，让你无需手动选中它。**

```wow-macro
/focus [@mouseover,exists][]
```

:::

:::details 焦点目标宏
**焦点[[spell:1833]]宏。**

```wow-macro
#showtooltip 偷袭
/cast [@focus] 偷袭
```

**焦点[[spell:408]]宏。**

```wow-macro
#showtooltip 肾击
/cast [@focus] 肾击
```

**焦点[[spell:1766]]宏。**

```wow-macro
#showtooltip 脚踢
/cast [target=focus,exists,nodead] [] 脚踢
```

:::

:::

:::accordion
:::details 暗影之舞宏
暗影之舞 > 影分身。请确保你没有处于公共冷却中

```wow-macro
#showtooltip
/cast 暗影之舞
/cast 影分身
```

暗影之舞 > 袖剑风暴

```wow-macro
#showtooltip
/cast 暗影之舞
/cast 袖剑风暴
```

:::

:::

## 插件

下方是作者的**敏锐 潜行者**用户界面截图，说明了使用了哪些插件，以及它们在团队副本中如何被用来让你的游戏体验更轻松。

![](<https://i.gyazo.com/cd27ad7c7ee352aeff1bedbac42220e8.jpg>)

**敏锐 潜行者**界面

:::accordion
:::details 插件
- **Ellesmere UI** *—— 完整的用户界面替换* 
  
  - 一款以用户友好为核心设计的用户界面，附带标准界面中没有的额外功能。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**潜行者**

- 职业
  
  - 蓟茶现在是一个可选天赋——玩家可以在现有版本（除了可以主动使用外，还会在能量较低时自动施放）和一个必须主动施放的新版本之间进行选择。
  - 萎缩毒药现在使造成的伤害降低 4%（原为 3%）。
  - 萎缩毒药的持续时间延长至 60 秒（原为 10 秒）。在 PvP 战斗中持续时间保持不变。
- 英雄天赋
  
  - 死亡猎手
    
    - 修复了“不屈驱动”的加成会随每层叠加而相乘的问题。
    - 修复了“不屈驱动”经常会在一次技能使用中移除多层的问题。

- 敏锐
  
  - 开发者说明：我们在乌拉特克之咒中对敏锐的资源经济性进行了一些更新，包括移除了一个双重生成的错误，该错误使设计意图和战斗感受变得不清晰。暗影技巧的基础效果触发频率和能量生成正在提高，以使暗影之舞之外的时刻不那么缺乏资源，同时保持暗影之舞内相同的触发频率和连击点生成。冷却期间能量生成仍会增长，但不会再像以前那样急剧。
  - Goremaw的撕咬已被重新设计——猛烈攻击你的目标以及附近2名额外敌人，造成暗影伤害，并使其在14秒内流血。终结技造成的所有伤害的20%将作为暗影重复施加，在受影响的敌人之间平均分配。
  - 迅影已更新——当暗影之舞激活时，你的暗影技巧触发频率提高25%，并额外产生1个连击点。
  - 造成的所有伤害提高2%。此效果不适用于PvP战斗。
  - 初舞现在使暗影之舞的持续时间延长4秒（原为3秒）。
  - 无情打击现在每消耗一个连击点于终结技时产生4点能量（原为5点能量）。
  - 暗影技巧的基础效果频率已提高40%。
  - 暗影技巧的能量生成已提高至5点（原为4点）。
  - 纠缠暗影现在也适用于袖剑风暴。
  - 暗影之舞的工具提示已更新，以包含其威胁值降低效果。
  - 顶尖天赋：诡谋承袭在创建暗影分身时现在会计算影分身的总伤害，而不仅仅是其初始打击。
  - 修复了一个导致影分身的后续打击伤害被归因于召唤的宠物而非攻击者潜行者的问题。
  - 一些天赋在天赋树中的位置发生了变化。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我的能量有时低到无法按下技能？
答：囤积能量是潜行者玩法中常见的一环。即使你的操作完全正确，有时感到能量不足也是正常现象。

:::

:::

---

### 致谢

作者：**Perfecto**

审核者：**Verb**

---

:::changelog 更新记录
**2026-08-08** 已更新至12.1版本。

**2026-06-17** 已更新至12.0.7版本。

**2026-04-21** 已更新至12.0.5版本。

**2026-02-10** 已更新至12.0.1版本。

**2026-01-13** 已更新至12.0版本。

**2025-12-03** 已更新至11.2.7版本。

**2025-10-07** 已更新至11.2.5版本。

**2025-07-29** 已更新至11.2版本。

**2025-06-19** 已更新至11.1.7版本。

**2025-04-21** 已更新至11.1.5版本。

**2025-02-14** 已更新至11.1版本。

**2024-12-17** 已更新至11.0.7版本。

**2024-07-24** 攻略撰写于11.0前夕版本



:::
