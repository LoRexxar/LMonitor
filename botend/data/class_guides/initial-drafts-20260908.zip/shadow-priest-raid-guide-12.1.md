欢迎来到《魔兽世界》12.1版本的 **暗影 牧师** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始练级的新玩家吗？请查阅练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体输出** · 3/5 · 强

范围伤害 · 4/5 · 强

功能性 · 2/5 · 弱

生存能力 · 2/5 · 一般

机动性 · 1/5 · 较差



:::

:::

:::column
:::gear **暗影 牧师** 团队副本 最佳配装
```json
{
  "source_code": "IsfAwjlABc__BEgAmQggQEAAnk7A8z6A5IgF2gVABk-FEAIEBAwVtOQOCwYNYFQABTCBCgQAAcRuDkjAOFQAGTCBCgQAAkQuDkjAOFQAwg6AAiQAAwPrDcbNLFQACngHIUgqDUQLE89FFwDAp0APMACqDQYALxAwDYiqBMXBzgBxkQAAIEAAFADIcfBBCiQAAUPuB4RBSAQ2CJBAccW0DAACBAggB4HBU9RG8QQ3XkBDcQvIEIAEBAQBBgHAXEg1oU6FEAACBAQOC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240892]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] |
| 肩部 | [[item:271553]] | [[item:243991]] |
| 胸部 | [[item:271558]] | [[item:243977]] |
| 腰部 | [[item:239664]] | [[item:240892]] |
| 腿部 | [[item:271554]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:245783]] · [[item:240166]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**暗影 牧师**，你可以使用**虚空幻灵**，它会在[[talent:103792]]于**神像**激活时召唤出

。

**第2级**使你的[[talent:103792]]有15/30%的几率变为[[spell:1264104]]，其造成的伤害提高50%，并释放出一个[[spell:1264177]]。

而**第3级**则使你的[[talent:115448]]有100%的几率激活你的某个**神像**的效果。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/imagzqde.png>)

虚空幻灵

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[talent:115448]]
    
    - 替代了旧的暗影冲撞，施放时需要一个目标，并会对处于你与施放目标之间的敌人施加持续伤害，同时还会影响目标周围的一片区域。
  - [[talent:103674]]
    
    - 现在在其持续期间以[[spell:1240401]]替代[[spell:1264177]]作为替代法术。
    - [[talent:103674]]的持续时间无法再被延长了。
  
  
  
  - [[talent:103799]]
    
    - 这是我们延长目标身上持续伤害效果的新方式。在目标数量较少时，它不足以延长你的持续伤害效果，你需要手动进行延长。
  - [[spell:120644]]/[[spell:263165]]
    
    - 它们已从职业树和专精树中移除，并被整合进了英雄天赋。
- **已移除**
  
  - [[spell:391109]]
    
    - 它的移除使我们只剩下[[talent:103674]]作为主要冷却技能。
  
  
  
  - [[spell:132603]]
    
    - 我们的宠物总体上已被整合为在斩杀阶段或按下冷却技能时触发的被动效果。

## 英雄天赋



### [[talent:123289]]

[[talent:123289]]赋予你[[talent:117300@FAQAJdhA]]能力，与[[talent:117284]]相结合可产生总计三个光环，并进一步与部分英雄天赋产生协同效果。

- [[talent:117302@FAQAJdhA]] 会为你提供 [[spell:391403]]，每消耗一层 [[talent:117300@FAQAJdhA]] 触发一次。
- [[talent:117279@FAQAJdhA]] 会提高被 [[talent:117300@FAQAJdhA]] 命中的目标所受到的伤害。
- [[talent:125085]] 会延长你 [[talent:103674]] 的持续时间（若处于激活状态），否则最多可储存 6 秒供下一次使用。




### [[talent:123287]]

[[talent:123287]] 赋予你 [[talent:117287@AJQBCA]] 能力，召唤一个 [[spell:447444]]，在你的目标周围造成伤害。该裂隙在持续时间结束时爆炸，对其中的敌人造成伤害，并且与部分英雄天赋有进一步的协同效果。

- [[spell:447444]] 会将你的 [[spell:8092]] 转变为 [[talent:117306]]，使其造成更高的伤害并产生更多的狂乱值。
- 你每施放一次 [[talent:103808]]，都会使裂隙的体积和伤害提高 20%。
- [[talent:123845@AJQBCA]] 允许你在移动时使用 [[talent:117287@AJQBCA]]。
- [[talent:103864@FJQAJdhAFIA]] 在配合 [[talent:117271@FJQAJdhAFIA]] 时伤害显著提高。





## 天赋



### [[talent:123289]]

:::talents [[talent:123289]] **暗影 牧师** 团队副本 配装
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 何时使用该专精

这是适用于大多数情况的通用天赋页面。

#### 改变游戏玩法的天赋

探索专精天赋树和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若想了解更多细节，请查看下方的循环和 **深入解析** 部分。

##### 专精树

- [[talent:115448]]
  
  - 对最多6个目标施加[[spell:34914]]，并拥有两层充能。
- [[talent:103809]] 或 [[talent:136811]]
  
  - 重要的抉择节点，需要在操作简易度与输出量之间做出选择。
- [[talent:103806]]
  
  - 暗影牧师造成范围伤害伤害的主要手段，与DoT本身相结合。
- [[talent:103792]]
  
  - 另一个持续伤害来源，与天赋树中的许多其他天赋有协同效果。
- [[talent:103786]] 或 [[talent:115671]]
  
  - 重要的天赋选择，因为它会改变你的[[talent:103808]]的消耗。
- [[talent:103782]]、[[talent:103817]]、[[talent:103781]] 和 [[talent:103787]]
  
  - 虽然主要是被动效果，但了解你所有的神像天赋非常重要，因为它们会与你的顶尖天赋产生协同作用。

##### 职业树

- [[talent:103833]]
  
  - 牧师斩杀阶段的重要组成部分，最大化其持续时间是充分发挥该专精潜力的重要一环。
- [[talent:103819]]
  
  - 增加你大部分法术的施法距离。
- [[talent:103834]]
  
  - 你的两分钟冷却技能，总是与[[talent:103674]]
  
  
  
  - [[talent:134284]] 一起使用。你可以[[talent:103834]] 给别人，同时自己也能获得全部收益，因此为其准备一个好用的宏非常重要。
- [[talent:103864]]
  
  - 你的斩杀按键。移动时可以随时作为填充法术使用。
- [[talent:134849]] 配合 [[talent:103835]] 和 [[talent:134846@FAQAKLbB]]
  
  - 两个强大的防御技能。




### [[talent:123287]]

:::talents [[talent:123287]] **暗影 牧师** 团队副本 配装
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMjZGAAAAAAAAAAAAMLmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMjZGAAAAAAAAAAAAMLmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

#### 何时使用该专精

如果你更喜欢使用[[talent:123287]]而不是[[talent:123289]]，请使用该配装，[[talent:123287]]在目标聚集的范围伤害中同样表现出色。

##### 英雄天赋

已更改 [[talent:123289]] 为 [[talent:123287]]，更多信息请访问上方的 **英雄天赋** 部分。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[talent:115448]] 的冷却时间缩短3秒，其伤害提高100%。
- **4件套：** ‍[[talent:115448]] 有100%的几率使你免费使用一次 [[spell:1242189]]，效果为100%。

### 单体目标



#### [[talent:123289]]

##### 起手爆发

- 你起手的目标是尽可能高效地用掉所有层数并使用所有相关技能，同时避免 **狂乱** 溢出。
- 你可以在下方找到一个起手示例：

:::rotation [[talent:123289]] **暗影 牧师** 团队副本中的单体起手
```json
{
  "source_code": "J0GEKIEnfAQABwgQQorEFgABNJQAHwAAC1D9JABCEddABEBCCls9BkBQEIETnAAAAIkpDCAAAEAiuOQAcwTAnF9AAgQAAIoAOFgQr5RBBQBDC1D9SUACow5HAAAAAAgQrjfB"
}
```
1. [[spell:8092]]
2. [[spell:1227280]]
3. [[spell:589]]
4. [[spell:1242173]]
5. [[spell:120644]]
6. [[spell:194249]]  [[spell:10060]] · [[spell:33702]] · [[item:241288]] · [[item:250215]]
7. [[spell:335467]]
8. [[spell:1242173]]
9. [[spell:8092]]
10. [[spell:391403]]
:::

- 在使用 [[talent:103674]] 之后，使用你的主动饰品、[[item:241308]]、[[talent:103834]] 以及种族技能如 [[spell:20572]] 或 [[spell:26297]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在目标身上保持 [[spell:34914]] 和 [[spell:589]]。
   
   - 你可以通过 [[talent:115448]] 来维持它，通过 [[talent:103799]] 来延长它，或者手动施放。
2. 施放 [[spell:120644]]
3. 施放 [[talent:103674]]
4. 施放 [[talent:103834]]
5. 在目标身上保持 [[talent:103808]]。
6. 施放 [[spell:1242173]]
7. 如果目标生命值低于20%，施放 [[spell:32379]]
8. 施放 [[spell:8092]]
9. 施放 [[spell:391403]]
10. 施放 [[spell:15407]]




#### [[talent:123287]]

##### 起手爆发

- 你起手的目标是尽可能高效地用掉所有层数并使用所有相关技能，同时避免 **狂乱** 溢出。
- 你可以在下方找到一个起手示例：

:::rotation [[talent:123287]] **暗影 牧师** 在大秘境中的单体起手
```json
{
  "source_code": "JUHELIEnfAQABwgQQorEFgABNJQAHABAC1_AEEQCMI0phbQBIgwaeUQBIEBEE0D9JADBJbfAxAEBCx0JAAAACZ6gAAAABgorDEALcFwZRPAAIEAACKgTBIUP0LBAAAAACtmHFA"
}
```
1. [[spell:8092]]
2. [[spell:1227280]]
3. [[spell:589]]
4. [[spell:263165]]
5. [[spell:450983]]
6. [[spell:335467]]
7. [[spell:450983]]
8. [[spell:1242173]]
9. [[spell:194249]]  [[spell:10060]] · [[spell:33702]] · [[item:241288]] · [[item:250215]]
10. [[spell:1242173]]
11. [[spell:335467]]
:::

- 在使用 [[talent:103674]] 之后，使用你的主动饰品、[[item:241308]]、[[talent:103834]] 以及种族技能如 [[spell:20572]] 或 [[spell:26297]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在目标身上保持[[spell:34914]]和[[spell:589]]。
   
   - 你可以通过[[talent:115448]]来维持它，通过[[talent:103799]]来延长它，或者手动施放。
2. 施放[[talent:103674]]
3. 施放[[talent:103834]]
4. 在目标身上保持[[talent:103808]]。
5. 施放[[spell:1242173]]
6. 施放[[spell:450983]]
7. 如果目标生命值低于20%，施放[[spell:32379]]
8. 施放[[talent:117287@AJQBCA]]
9. 施放[[spell:8092]]
10. 施放[[spell:15407]]





### 范围伤害

作为一名**暗影 牧师**，我们范围伤害的主要构成是你的持续伤害（DoT）伤害和[[talent:103806]]，因此你的单体循环就是你的范围伤害循环。

- 你的首要任务是在任何想要造成显著伤害的目标身上保持[[spell:34914]]。
  
  - 这也能让你灵活选择输出所指向的目标。
- 在使用[[talent:136811]]时，你需要决定对多少个以及哪些目标使用[[spell:589]]，因为你要在给重要目标挂DoT与通过[[talent:103806]]开始打出伤害之间取得平衡。

## 深度解析

### 精通：暗影 穿插与暗言术：癫

**暗影 牧师**的精通在玩法中至关重要。它使你施加在目标身上的每一个DoT都能按你的精通百分比提升你造成的伤害，因此精通的管理极为关键。[[spell:34914]]和[[spell:589]]几乎100%的时间都会存在于目标身上，剩下的任务就是维持目标身上的[[talent:103808]]。让[[talent:103808]]的覆盖时间尽可能高，是打出最高伤害的关键。在[[talent:103674]]期间，无论目标身上有哪些DoT，你都会获得精通的最大效果。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **暗影 牧师** 内克扎莉 团队副本天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 注意[[spell:1284103]]的计时条，切勿站在首领与其技能目标坦克之间。
- 提前观察小怪的尸体位置，以便更轻松地应对[[spell:1294742]]净化它们的减益效果。




### 陵寝哨兵

:::talents **暗影 牧师** 陵寝哨兵 团队副本天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 需要注意的是，[[spell:1284434]]也可能出现在另一个首领身上，所以尽量不要站在两个首领之间，并在[[spell:1284434]]出现时保持警惕。
- 留意首领的能量值，当其接近100时务必分散站位，以便更轻松地度过中场阶段。
- 总体而言，注意自己的站位，尽量靠近首领输出，这样就不用担心[[spell:1284494]]和[[spell:1284503]]的层数叠加。




### 迷失的探险者

:::talents **暗影 牧师** 团本中的迷失的探险者天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 注意 [[spell:1296062]] 的施法，这样更容易躲避它们。
- 不要过量吸收 [[spell:1291934]]，因为它会给你叠加一层 **流血** 减益效果。
- 小心 [[spell:1292105]] 产生的蘑菇，因为它们被使用一次后就会被消耗掉。




### 瓦什尼克

:::talents **暗影 牧师** 团本中的瓦什尼克天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 每当 [[spell:1281907]] 减益效果即将到来时，务必提前分散，并尽可能不要将它对准首领。
- 请记住，击杀 **燃烧毒液** 会给你叠加一层减益效果，所以要避免同时击杀它们。




### 斯索拉克

:::talents **暗影 牧师** 斯索拉克 团队副本天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 非常重要的一点是要时刻留意 [[spell:1305959]] 的计时器，每当它快到时，提前扫描平台，看看你需要把它放在哪里。
- 如果你被 [[spell:1287072]] 击中，请使用防御冷却技能，因为它会对你施加一个可叠加的 **Poison** debuff。




### 双牙

:::talents **暗影 牧师** 双牙 challenges in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 在这场战斗中，拥有一个良好的负面效果监控手段极其重要，因为[[spell:1290336]]在达到一定层数后必定会致死，具体层数取决于难度。
- 当你成为[[spell:1291478]]的目标时，尽量不要到处乱跑。如果需要躲避什么，最好沿自己的直线移动。
- 别忘了吸收[[spell:1290516]]也会将你击退，所以在那期间要小心[[spell:1290956]]产生的波纹。
- 每当[[spell:1294293]]发生时，观察场地中央的**维克苏尔** ，你会发现有一些围绕他旋转的小球，它们指示了他施放光束的方向。




### 盘绕祭坛

:::talents **暗影 牧师** 蛇卷祭坛 challenges in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 小心 [[spell:1282403]]，如果有需要，确保协助将它们移动到别处。
- 要格外注意 [[spell:1285643]] 之后刷新的幽灵，因为处理它们将是这个阶段最难的部分。
  
  - 即使你没有被幽灵点名，也请确保不要停留在它们附近，因为它们会被 [[spell:1286620]] 的正面劈砍清理掉，这是消灭它们的唯一办法。
- 每当你被 [[spell:1286895]] 点名时，使用一个防御冷却技能。




### 乌拉特克

:::talents **团队副本中暗影 牧师** 乌拉特克 天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::




### 尼姆瑞莎·唤波者

:::talents **团队副本中暗影 牧师** 尼姆瑞莎·唤波者 天赋
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### 首领攻略技巧

- 请记住，在 [[spell:1258673]] 结束后，[[spell:1258150]] 会把你从中间击退出去。
- 每当 [[spell:1281393]] 被引爆时，请使用防御冷却技能。





## 属性优先级

了解你的次要属性优先级，以及作为一名  **暗影 牧师** 在 团队副本 中获得最佳表现所需的第三属性。欲了解更详细的信息，请访问 **[属性与属性详解](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **暗影 牧师** 团队副本 属性优先级
```json
{
  "source_code": "IoAJFUQMkACKBIQABA"
}
```
**智力 ＞ 精通 ＝ 急速 ＞ 暴击 ＞ 全能**
:::

:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **Avoidance -** 降低“范围伤害”技能伤害承受的优秀属性。
- **Leech -** 通过造成伤害提供额外治疗。你的宠物所造成的伤害治疗术，因此**Leech** 对你来说是一个极佳的第三属性，因为你的大部分伤害来自于你自己的法术。
- **Speed -**  较为小众的第三属性，但在特定情况下可能非常有用，过去也已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取位置 |
| --- | --- | --- |
| 头部 | [[item:271874@DCRAAIQAnk7wPrTOCYhNYFA]] | 乌拉特克 |
| 颈部 | [[item:268265@BCRAAIQAX16kjAMWDWB]] | 乌拉特克 |
| 肩部 | [[item:271553@DgQAAIQAXk7kjAOF]] | 迷失的探险者 或 催化剂 |
| 披风 | [[item:268253@BgQAAIQA5IgTBA]] | 盘卷祭坛 |
| 胸部 | [[item:271558@DgQAAIQAJk7kjAOF]] | 瓦什尼克 或 催化剂 |
| 腕部 | [[item:239648@FiQAAIQAXA8YiqD_sO3WzSB]] | 制造业 |
| 手部 | [[item:271556@BgQAAIQA5IgTBA]] | 陵寝哨兵 或 催化剂 |
| 腰部 | [[item:239664@BiQAAIQA8z6cbNLF]] | 制造业 |
| 腿部 | [[item:271554@DgQAAIQAFo6kjAOF]] | 斯索拉克 或 催化剂 |
| 脚部 | [[item:268255@DgQAAIQApk7kjAOF]] | 盘卷祭坛 |
| 戒指1 | [[item:268252@DiQAAIQA1j7wPrTOC4UA]] | 斯索拉克 |
| 戒指2 | [[item:268249@DiQAAIQA1j7wPrTOC4UA]] | 瓦什尼克 |
| 饰品1 | [[item:250215@BgQAAIQACKgTBA]] | 密谋小径 |
| 饰品2 | [[item:270164@BgQAAIQA5IgTBA]] | 迷失的探险者 |
| 主手 | [[item:271092@DARAAIQAFk7kjAXYDWB]] | 乌拉特克 |
| 副手 | [[item:268197@BgQAAIQA5IgTBA]] | 陵寝哨兵 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251199@AgQAAIoABFA]] | 夺目谷 |
| 项链 | [[item:251142@AgQAAIoABFA]] | 密谋小径 |
| 肩部 | [[item:271553@AgQAAkjABFA]] | 套装/催化 |
| 披风 | [[item:251190@AgQAAIoABFA]] | 夺目谷 |
| 胸部 | [[item:271558@AgQAAkjABFA]] | 套装/催化 |
| 手腕 | [[item:239648@FiQAAIQAXA8YiqD_sO3WzSB]] | 制造业 |
| 手套 | [[item:271556@AgQAAIoABFA]] | 套装/催化 |
| 腰带 | [[item:239664@BiQAAIQA8z6cbNLF]] | 制造业 |
| 腿部 | [[item:271554@AgQAAkjABFA]] | 套装/催化 |
| 靴子 | [[item:251137@AgQAAIoABFA]] | 密谋小径 |
| 戒指 1 | [[item:251136@AgQAAIoABFA]] | 密谋小径 |
| 戒指 2 | [[item:252258@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:250215@AgQAAIoABFA]] | 密谋小径 |
| 饰品 2 | [[item:250224@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 主手 | [[item:273778@AgQAAIoABFA]] | 毒牙祭坛 |
| 副手 | [[item:251191@AgQAAIoABFA]] | 夺目谷 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:250215@BgQAAIQACKgTBA]]  <br>[[item:270164@BgQAAIQA5IgTBA]]  <br>[[item:273796@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]] |
| **A级** | [[item:270170@AgQAAkjAOFA]]  <br>[[item:250214@AgQAAIoABFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAkjAYFA]] |
| **B级** | [[item:270161@AgQAAkjAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C级** | [[item:251792@AAQAAEUA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:273794@AgQAAIoAOFA]]  <br>[[item:251785@AAQAAEUA]] |
| **垃圾级** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:158368@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |

### 美化饰品

- 1 个 [[item:245875]]
  
  - 只能制造在你的主手或副手武器上。为了前期更强大的力量，可制造在主手上；为了长期的 最佳配装，则可制造在副手上。
- 1 个 [[item:240166]]
  
  - 最佳制造部位为 **手腕**、**披风**、**靴子** 或 **腰带**，具体取决于你现有的装备。

或

- 2 个 [[item:240166]]
  
  - 最佳制造部位为 **手腕**、**披风**、**靴子** 或 **腰带**，具体取决于你现有的装备。

或

- 1x [[item:240166]]
  
  - 最适合制作的部位是**护腕**、**披风**或**靴子**，具体取决于你现有的装备。
- [[item:239664]]

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药水（合剂）**
  
  - [[item:241322]] *-- 最高DPS。*
  
  
  
  - [[item:241320]] *-- DPS略低但生存能力更强。*
- **食物**
  
  - [[item:266996]]
  - [[item:242744]]
  - [[item:266985]]
- **战斗药水**
  
  - [[item:241288]]
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]] -- 一次大量的治疗爆发
- 武器油
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240967]] *-- 唯一*
    
    - [[item:240892]]
    - [[item:240900]]
    - [[item:240906]]

### 附魔

:::columns
:::column
| 头部 | [[item:244007]]  <br>[[item:275707@BAAAAIQA]] |
| --- | --- |
| 肩部 | [[item:243991]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAAIQA]] |
| 腰部 | [[item:275707@BAAAAIQA]] |
| 腿部 | [[item:240133]] |
| 靴子 | [[item:244009]] |
| 戒指 1 | [[item:243957@BAAAAIQA]] |
| 戒指 2 | [[item:243957@BAAAAIQA]] |
| 武器 | [[item:243973]] |

:::

:::column
:::gear **暗影 牧师** 在 团队副本 中的附魔
```json
{
  "source_code": "JQFWCEQ5NDQA7TDBCAAAAcSuDEwF5OAAAAQBTUACEUgqJABApoDGAQQ94mAGRgAKJk7AAAAAAEQB5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 背部 | [[item:243977]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAIQA]]，为你的 **头盔**、**护腕** 和 **腰带** 添加插槽。

## 种族

如果你想在团队副本中极限优化你的 **暗影 牧师**，不同的种族天赋可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:65116]] —— 矮人
  
  - 可以驱散魔法和流血负面效果。过去在一些带有流血机制的首领战中很有用。
- [[spell:69070]] —— 地精
  
  - 朝角色面朝的方向进行一次小距离跳跃。
  - 在你处于 [[spell:69070]] 动画期间，你会进入公共冷却，直到角色落地为止。
- [[spell:274738]] *—— 玛格汉兽人* 
  
  - 由于 [[spell:274738]] 可以与 [[talent:103674]] 相配合，这是一个非常强力的输出种族天赋。
- [[spell:256948]] —— 虚空精灵
  
  - 向面朝的方向释放一道虚空裂隙，再次激活即可传送到其位置。
  - 最大距离为 100 码。

:::columns
:::column


:::

:::

### 推荐

总的来说，可以肯定的是：如果你追求输出最大化，就应该选择输出最高的种族天赋。不过，如果是开荒团本，情况就有所不同了。有些种族天赋能极大加快特定首领的进度。值得注意的是，矮人凭借其 [[spell:65116]]，在最近的世界首杀竞速中，由于能在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键节点轻松自我驱散，提供了巨大帮助。

## 宏

了解 **暗影 牧师** 在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:32375]] -- *在无需确认的情况下，对鼠标指针位置施放 [[spell:32375]]。***

```wow-macro
#showtooltip
/cast [@cursor] 群体驱散
```

:::

:::details 鼠标指向宏
**[[spell:34914]]** -- *对鼠标悬停目标或当前目标施放 [[spell:34914]]。*

```wow-macro
#showtooltip 
/cast [@mouseover,exists] [] 吸血鬼之触
```

**[[spell:213634]]** -- *对鼠标悬停目标或当前目标施放[[spell:213634]]。*

```wow-macro
#showtooltip 
/cast [@mouseover,exists] [] 净化疾病
```

:::

:::details 实用 宏
**对自己施放天堂之羽 - *在你的脚下使用你的[[spell:121536]]*。**

```wow-macro
#showtooltip
/cast [@player] 天堂之羽
```

**取消光环*[[spell:47585]]* - *取消你的[[spell:47585]]*，无需等待公共冷却。**

```wow-macro
#showtooltip 消散
/cast 消散
/cancelaura 消散
```

**这个宏可以防止你不小心按了两次而取消掉你的虚空洪流**

```wow-macro
#showtooltip
/stopmacro [channeling:Void Torrent]
/cast [known:虚空洪流] 虚空洪流
```

:::

:::

## 插件

下方是作者的暗影 牧师**暗影 牧师**用户界面截图，其中标明了所使用的插件，以及它们在团队副本中如何使用，从而让你的游戏体验更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/WoWSqnopnonononononcrnShot_022626_165503-1024x614.png>)

**暗影 牧师** 在团队副本中的界面

:::accordion
:::details 插件
- **HealthBarColo *—— 玩家、目标和焦点框体替换*** 
  
  - 添加自定义的玩家、目标和焦点框体，并可选择移除次要资源显示。
- **BetterCooldownManager** —— 冷却管理器增强
  
  - 为你的冷却管理器提供额外的自定义选项，同时提供资源等额外信息。
- **UnhaltedUnitFrames** —— 用户界面替换
  
  - 添加自定义的首领框体，具备更多自定义选项。
- **BigWigs** —— 通用首领模块
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件旨在为某个特定的 团队副本 战斗触发警报消息、计时条、音效等。
- **Plater** —— 高级姓名板
  
  - Plater 是一款姓名板插件，拥有极为丰富的设置选项，开箱即用的负面效果监控、仇恨着色，并支持自定义脚本。
- **Details** —— 深度伤害统计
  
  - 最强大、最可靠、最漂亮的伤害统计插件。
- **Quartz** —— 施法条替换
  
  - 添加自定义施法条，具备更多自定义选项。

:::

:::

## 本次版本改动

:::accordion
:::details **12.**1补丁说明
- *开发者注：对于 乌拉特克 诅咒中的 暗影，我们打算改进 虚空形态 的玩法，并增加一个额外的多目标伤害来源，以减少该专精在 范围伤害 情况下对 心智联结 的依赖。对于 虚空形态，我们正在将 虚空齐射 改为一个限次使用的技能，在 虚空形态 期间可使用固定次数，这为循环留出更多空间，同时让你有机会在最合适的时机使用它。我们还更新了 虚空形态 的辅助天赋，使其效果更加明显，以符合我们的目标。*
- 新天赋：暗影爆发——飘向你的主要目标的 暗影幻灵 会爆炸，对 8 码范围内的所有敌人造成 暗影 伤害。伤害超过 5 个目标后降低。
- 强化的 虚空形态 已重新设计——虚空形态 使你的法术伤害额外提高 5%，并额外给予 虚空齐射 2 次使用次数。
- 远古疯狂已重新设计——暗言术：癫 使你在 虚空形态 期间的急速提高 2%，并使其持续时间延长 1.5 秒，最多可叠加 5 次。当 虚空形态 结束时，急速效果会残留并在 10 秒内逐渐衰减。
- 所有技能造成的伤害提高 8%。
- 虚空齐射 造成的伤害降低 10%。
- 虚空形态 现在给予 虚空齐射 3 次使用次数，而非在 虚空形态 期间 虚空齐射 带有冷却时间。
- 真言术：盾 的吸收量提高 25%。
- 恩佐斯的神像 现在在 50 层时产生 2 点狂乱（原为 4 点），在 100 层时产生 6 点狂乱（原为 12 点）。
  
  - *开发者注：相对于其他被动来源，该天赋产生的狂乱一直偏高，我们总体上感觉产生的狂乱过多，以至于消耗狂乱和跟上循环触发变得困难。我们正在降低该天赋的狂乱产生量，以帮助平衡狂乱的经济系统。*
- 修复了一个问题：在点选疯狂触须和 恩佐斯的神像 天赋时，触须猛击 会施加额外层数的恐怖幻象。
- 修复了一个问题：强化的 虚空形态 会在施放 虚空形态 时产生狂乱。
- 魅影威胁已被移除。
- 英雄天赋
  
  - 执政官
    
    - 聚焦爆发已重新设计——虚空齐射 造成的伤害提高 5%，且在 虚空形态 期间施放的 暗言术：癫 会以 25% 的效果向你的目标释放一个 虚空齐射。
    - 共振能量 进行了微调重新设计——制造一个 光晕 使你的法术伤害提高 2%，持续 10 秒，最多可叠加 4 次。

:::

:::

## 常见问题

:::accordion
:::details 为什么我总是死？
确保在没有准备好 [[spell:19236]] 或 [[spell:47585]] 时，始终提前使用你的 [[spell:586]] 和 [[spell:193063]]。

:::

:::

---

### 致谢

作者：**Soda**

审校者：**Meeres**

---

:::changelog 更新记录
**2026-08-09** 已更新至12.1版本。

**2026-02-24** 已更新至12.0.1版本。

**2026-01-20** 已更新至12.0版本。



:::
