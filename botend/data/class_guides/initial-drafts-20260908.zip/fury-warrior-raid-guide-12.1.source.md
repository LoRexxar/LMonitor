Welcome to the **Fury Warrior** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Fury Warrior** Mythic+ Best in Slot
```json
{
  "source_code": "JYtAwbESAc__BEAYkQggoQAAvj7AH16A8Vjg1YbN2IjgCU8FEEQ6XQAApAAAU06AC06AMWDZ1ghNeVjgCEgXkQgAgAAA1k7A-VTg1EgLgGwYkQgAgUAAJk7A6Vjg1ghNCKAWB47FEEw4XQAggEAA8z6AYYjX1YbNBgBCBYgJFAEEju7AWYTAXAjgCEA5XQAAYAAA2IjXB4AoKE6AAiUAAwQrDY7LjVT0wwgN3Wjt1ccNAMSWisUABEGJEAAIBAwe1EYBrSkTBEgYZPgggEAA1j7A8z6AkVTCHBiTBEQ2XQgggAgOYAAHB81HEAAGCAQC7xRBAEwVXIQAdFAFAAQDUQQAdHwjAEQDOADWBEQtXQgAYAAAFk7AJUDGBgRoDIAOBEQE8Y7LMYzt1sZJLXDAjklILFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271456]] | [[item:240967]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240898]] |
| 肩部 | [[item:271454]] | [[item:244021]] |
| 胸部 | [[item:271459]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240892]] |
| 腿部 | [[item:271878]] | [[item:244643]] |
| 脚部 | [[item:268260]] |  |
| 腕部 | [[item:237834]] | [[item:240908]] |
| 手部 | [[item:271457]] |  |
| 戒指一 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:243973]] |
| 副手 | [[item:237848]] | [[item:243973]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As a **Fury Warrior** you have access to Rampaging Berserker, which increases [[talent:112277]] damage by 10% and causes your [[talent:112277]] to trigger [[spell:1269349]], increasing your strength by 3% for 8 seconds.

**Rank 2** reduces your [[talent:112277]] rage cost and increases your [[talent:112277]] damage further during [[talent:112281]].

**Rank 3** increases your [[talent:112281]] duration by 50%, and [[talent:112281]] grants 3 stacks of [[spell:1269349]]

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-fury-mxr.webp>)

Rampaging Berserker

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:136452]]
    
    - [[spell:190411]] and [[talent:112205@FAQAadhA]] deal significantly increased damage if they hit at least 3 targets with this talent.
  
  
  
  - [[talent:136449]]
    
    - Provides a massive damage boost to your auto-attacks with [[talent:112265]] resets. Synergizes well with [[talent:112255]].
  
  
  
  - [[talent:136451]]
    
    - Fury Warriors now also have access to [[talent:136451]], being triggered by [[spell:5308]].
- **Class Tree**
  
  - [[talent:134031@AJQABA]]
    
    - Can provide a massive survivability boost if you are taking frequent big hits and utilizing your [[talent:114644]].
    - The offensive part of the talent provides only a very small damage increase, making this talent often a damage loss to pick compared to alternatives.
  - [[talent:136627]]
    
    - Now additionally increases the movement speed of allies within 12y(or 24y) by 30% for 4 seconds!
  - [[talent:134033]]
    
    - Improves all your shout abilities.
- **Removed**
  
  - [[spell:384318]]
  
  
  
  - [[spell:383762]]

## Hero Talents

- [[talent:123390]] is ahead on single-target damage, and [[talent:123392]] pulls ahead in most AoE situations. [[talent:123390]] is much further ahead on single-target than [[talent:123392]] is on AoE, so [[talent:123390]] is recommended as the default setup for all encounters.



### [[talent:123390]]

- [[talent:117411]]
  
  - [[spell:445579]] deals significant damage and grants the [[spell:445584]] buff.
- [[talent:117407]]
  
  - [[talent:112314]] applies [[spell:445836]].
  - [[spell:445836]] can also be applied by [[talent:117417]] and [[talent:117406@AJQA]].
- [[talent:117385]]
  
  - Every third [[spell:445579]] procs a [[talent:112300]]. This [[talent:112300]] that comes from [[talent:117385]] does not need you to have the talent [[talent:112300]] selected.
- [[talent:117392]]
  
  - The speed boost can be useful to keep up with moving targets, and the movement impairing effect dispel is occasionally very powerful.
- [[talent:117417]]
  
  - Consuming [[talent:112126@AJQA]] reduces the cooldown of [[talent:112314@AJQA]] based on how many stacks of  [[spell:445584]] you have.

#### New in 12.0 Midnight

- [[talent:136076]]
  
  - [[talent:112314@AJQA]] gives you a haste buff.
- [[talent:136075]]
  
  - Increases the duration of [[spell:445584]].
- [[talent:136074@AJQA]]
  
  - In The War Within [[talent:136074@AJQA]] was in the Class tree, but now it is a Hero talent.




### [[talent:123392]]

- [[talent:117400]]
  
  - Your [[talent:117400]] deal a significant part of your damage, and have a chance to proc [[talent:117404]].
- [[talent:117404]]
  
  - A low chance on [[talent:117400]] to get a significant [[talent:112261]] buff, and temporarily remove the cooldown of the ability.
- [[talent:117413]]
  
  - [[talent:112205]] is with this trait a significantly stronger way to apply [[talent:112298]] and enable cleave, compared to [[spell:190411]].
- [[talent:117382]]
  
  - Transforms your [[talent:112205]] into [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]], dealing Stormstrike damage that ignores armor.
  - Has a chance to proc from [[talent:112261]].
- [[talent:117402]]
  
  - A reliable way to get [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]].

#### New in 12.0 Midnight

- [[talent:136070@AJQABA]]
  
  - [[talent:112205@FAwAadhAjnqBEMA]] and [[spell:435222]] is significantly buffed during [[talent:112285@AJQABA]].
- [[talent:136069]]
  
  - Small buff to [[talent:117400]] damage.
- [[talent:136068]]
  
  - You can extend [[talent:112285@AJQABA]] by using [[spell:435222]]. You can have [[talent:112285@AJQABA]] active for a majority of the time by prioritizing [[spell:435222]]  usage.





## Talents



### [[talent:123389]] Full ST

:::talents [[talent:123390]] **Fury Warrior** raid ST talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM"
}
```
:::

#### When to use this Spec

Use this spec if you want to play [[talent:123389]] in a single-target fight.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:112284@AJQABA]]
  
  - Deals high burst damage in both AoE and single-target situations.
- [[talent:136735]]
  
  - Enrages you and deals significant AoE damage.
  - Deals increased damage if you have [[talent:112270]].
- [[talent:119139@FAQAN3gB]]
  
  - Significant buff to your [[talent:112261]] and [[talent:112265@FAQAutdB]] that is active during [[talent:112281@FAQAN3gB]] only.

##### Class Tree

- [[talent:134032@AJQABA]]
  
  - Increases the availability of your offensive cooldowns, with the cooldown reduction being based on Rage spent.
- [[talent:112188]]
  
  - A slightly more powerful raid cooldown in Midnight because of new talent [[talent:134033]].
- [[talent:136627]]
  
  - Now in Midnight provides a short movement boost to you and your allies.
- [[talent:112253@AJQABA]]
  
  - Occasionally a very powerful offensive tool to reflect damage back to enemies. Often things are not reflectable, but you still get a good defensive buff with 20% reduced magic damage taken.
- [[talent:114644]]
  
  - A defensive with pretty much no cooldown, but comes with a penalty to your damage dealt.
- [[talent:112215]]
  
  - Can be very powerful against Absorb shields.




### [[talent:123389]] Cleave / AoE

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### When to use this Spec

This spec sacrifices only a small amount of single-target damage to deal significantly more AoE damage.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added**
  
  - [[talent:112260@FAQAN70E]]
  - [[talent:136452@FAQAjnqB]]
- **Removed**
  
  - [[talent:112271]]
  - [[talent:112279]]





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **Jade Warlord's Dominion (2pc):** [[talent:112265]] damage increased by 15%. During [[talent:112281]] [[talent:112265]] extends the duration of [[talent:112281]] by 2 sec, up to 6 sec.
- **Jade Warlord's Dominion (4pc):** [[talent:112261]] damage increased by 10%. During [[talent:112281]] [[talent:112261]] increases the critical strike bonus of [[talent:112281]] by 5%, up to 10%.

### Single-Target



#### [[talent:123389]]

##### Opener Rotation

- The opener abilities are best used in a macro like this:

```wow-macro
/cast Recklessness
/cast Avatar
/cast Charge
```

:::rotation Typical [[talent:123389]] Opener
```json
{
  "source_code": "I8EOJIAAAAAABI0tGAAAAIEZB0AEAAgQvAdBXAhQHo3AAEgHMIDpBAQEOkhHMkPHFAgLuAAC5zRB"
}
```
1. [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:227847]]  [[spell:107570]]
5. [[spell:227847]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:184367]]
9. [[spell:335097]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Use [[talent:112281@FAQAN3gB]].  -- Swap to Cooldown Priority list
2. Use [[talent:112277]] if any of:
   
   - [[spell:184361]] is not up or about to run out.
   - You have over 100 rage.
3. Use [[spell:5308]] if either of:
   
   - You have 2x [[talent:112301@AJQABA]] or [[talent:112301@AJQABA]] is about to run out.
   - You have at least 2 stacks of [[spell:445584]] and [[talent:112301@AJQABA]].
   - You are in the "Execute Phase"
4. Use [[talent:136735]] on cooldown.
5. Use [[talent:112265@FAQAutdB]] on cooldown.
6. Use [[talent:112261]] on cooldown.
7. Use [[talent:112277]].
8. Use [[spell:1680@FJwCadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTABEA]] on cooldown.

##### Cooldown Priority List

This is a general priority you aim to maintain for the duration of [[talent:112281@FAQAN3gB]].

1. Use [[talent:112277]] if:
   
   - [[spell:184361]] is running out or
   - You have over 100 rage.
2. Use [[talent:112284@AJQABA]] after triggering a new [[spell:184361]].
3. Use [[spell:5308]] if either of:
   
   - You have 2x [[talent:112301@AJQABA]] or [[talent:112301@AJQABA]] is about to run out.
   - You have at least 3 stacks of [[spell:445584]] and [[talent:112301@AJQABA]].
4. Use [[spell:335096]] if you have not yet triggered both stacks of the increased critical strike bonus from 4set.  *-- This is normally done by [[talent:112284@AJQABA]], but if your [[talent:112284@AJQABA]] is on cooldown then you have to trigger the 4pc manually.*
5. Use [[spell:335097]] if you have [[talent:112276]].
6. Use [[talent:112277]].
7. Use [[spell:335097]] on cooldown.
8. Use [[spell:5308]] if you are in the "Execute Phase"
9. Use [[spell:335096]] on cooldown.




#### [[talent:123392]]

##### Opener Rotation

- The opener 3 abilities are best used in a macro like this:

```wow-macro
/cast Recklessness
/cast Avatar
/cast Charge
```

:::rotation
```json
{
  "source_code": "IcEUIIAAAAAACIkNkGAAAI0tGAAAAIEZBMBEAAgQvAdBdggQWQaAXQBAChPHFAgLYAAK5zRBAAAAAIE-cUA"
}
```
1. [[spell:107574]] · [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:435222]]
5. [[spell:335096]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:335096]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Use [[talent:112285@AJQABA]] and [[talent:112281@FAQAN3gB]] together.  -- Swap to Cooldown Priority list down below
2. Use [[spell:435222]] if your [[talent:112285@AJQABA]] is active.
3. Use [[talent:112277]] if any of:
   
   - [[spell:184361]] is not up or about to run out.
   - You have over 100 rage.
4. Use [[talent:112265@FAQAutdB]] if you have [[talent:112276]].
5. Use [[spell:5308]] on cooldown.
6. Use [[spell:435222]].
7. Use [[talent:112261]] on cooldown.
8. Use [[talent:112265@FAQAutdB]] on cooldown.
9. Use [[talent:112277]].
10. Use [[talent:112205@FAgAadhAEMA]] on cooldown.
11. Use [[spell:1680@FJwCadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTABEA]].

##### Cooldown Priority List

This is a general priority you aim to maintain for the duration of [[talent:112281@FAQAN3gB]].

1. Use [[talent:112285@AJQABA]] and [[talent:112281@FAQAN3gB]] together.
2. Use [[talent:112277]] if any of:
   
   - [[spell:184361]] is not up or about to run out.
   - You have over 100 rage.
3. Use [[spell:435222]] if you have 2x stacks of [[spell:435222]].
4. Use [[spell:335096]] if you have not yet triggered both stacks of the increased critical strike bonus from 4set.
5. Use [[spell:335097]] if you have [[talent:112276]].
6. Use [[spell:335096]] on cooldown.
7. Use [[spell:335097]] on cooldown.
8. Use [[spell:5308]] on cooldown.
9. Use [[talent:112277]].
10. Use [[spell:435222]].





### Multi Target



#### [[talent:123389]]

##### Opener Rotation

- The opener abilities are best used in a macro like this:

```wow-macro
/cast Recklessness
/cast Avatar
/cast Charge
```

:::rotation Typical [[talent:123389]] Multi-Target Opener
```json
{
  "source_code": "I8aAQtgAAAAAAIgQ3aAAAAgQ2QaAAAgQkFwEQDAACt85CUkAMYpMAo1FCgDLB4FUBkC0Co4eCIaiDU0tAQSDHUSDHADMTsMPBEQAAAgQvAtABkDDCdgeDIDCAAwLNgREIgwIgXQBgEBEueGA"
}
```
1. [[spell:1719]] · [[spell:107574]]
2. [[spell:100]]
3. [[spell:190411]]
4. [[spell:184367]]
5. [[spell:227847]]
6. [[spell:227847]]
7. [[spell:184367]]
8. [[spell:184367]]
9. [[spell:385059]]
10. [[spell:184367]]
11. [[spell:190411]]
:::

##### Priority List

- The multi-target priority list is similar to the single-target priority list, the main difference is to always keep [[spell:12950]] active.

This is a general priority you aim to maintain throughout the fight.

1. Use [[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]] if needed to apply [[spell:85739]] enabling your single-target abilities to cleave.
2. Use [[talent:112281@FAQAN3gB]].  -- Swap to Cooldown Priority list
3. Use [[talent:112277]].
4. Use [[talent:136735]] on cooldown.
5. Use [[spell:5308]] on cooldown.
6. Use  [[talent:112265@FAQAutdB]] on cooldown.
7. Use  [[talent:112261]] on cooldown.
8. Use [[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]].

##### Cooldown Priority List

This is a general priority you aim to maintain for the duration of [[talent:112281@FAQAN3gB]].

1. Use [[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]] if needed to apply [[spell:85739]] enabling your single-target abilities to cleave.
2. Use [[talent:112277]].
3. Use [[talent:112284@AJQABA]] after triggering a new [[spell:184361]].
4. Use [[talent:136735]] on cooldown.
5. Use [[spell:5308]] if you have [[talent:112301@AJQABA]].
6. Use [[spell:335096]] if you have not yet triggered both stacks of the increased critical strike bonus from 4set. *-- This is normally done by [[talent:112284@AJQABA]] through [[talent:136074@AJQABA]], but if your [[talent:112284@AJQABA]] is on cooldown then you have to trigger the 4pc manually.*
7. Use [[spell:335097]].
8. Use [[spell:5308]] on cooldown.
9. Use [[spell:335096]] on cooldown.
10. Use [[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]].




#### [[talent:123392]]

##### Opener Rotation

- The opener 3 abilities are best used in a macro like this:

```wow-macro
/cast Recklessness
/cast Avatar
/cast Charge
```

:::rotation
```json
{
  "source_code": "IcEUIIAAAAAACIkNkGAAAI0tGAAAAIEZBMBEAAgQvAdBdggQWQaAXQBAChPHFAgLYAAK5zRBAAAAAIE-cUA"
}
```
1. [[spell:107574]] · [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:435222]]
5. [[spell:335096]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:335096]]
:::

##### Priority List

- The multi-target priority list is similar to the single-target priority list, the main difference is to always keep [[spell:12950]] active.

This is a general priority you aim to maintain throughout the fight.

1. Use [[talent:112205@FAgAadhAEMA]] if needed to apply [[spell:85739]] enabling your single-target abilities to cleave.
2. Use [[talent:112285@AJQABA]] and [[talent:112281@FAQAN3gB]] together.   -- Swap to Cooldown Priority list down below
3. Use [[talent:112277]].
4. Use [[spell:435222]] if [[talent:112285@AJQABA]] is up.
5. Use [[talent:112261]] if [[talent:112285@AJQABA]] is up.
6. Use [[talent:112205@FAQAadhA]] if [[talent:112285@AJQABA]] is up.
7. Use [[spell:5308]] on cooldown.
8. Use [[talent:112265@FAQAutdB]] if you have [[talent:112276]].
9. Use [[talent:112261]] on cooldown.
10. Use [[talent:112265@FAQAutdB]] on cooldown.
11. Use [[talent:112205@FAQAadhA]] on cooldown.

##### Cooldown Priority List

This is a general priority you aim to maintain for the duration of [[talent:112281@FAQAN3gB]].

1. Use [[talent:112285@AJQABA]] and [[talent:112281@FAQAN3gB]] together.
2. Use [[talent:112205@FAgAadhAEMA]] if needed to apply [[spell:85739]] enabling your single-target abilities to cleave.
3. Use [[talent:112277]].
4. Use [[spell:435222]] on cooldown.
5. Use [[spell:335096]] on cooldown.
6. Use [[spell:335097]] on cooldown.
7. Use [[talent:112205@FAQAadhA]] on cooldown.
8. Use [[spell:5308]] on cooldown.





## Deep Dive

### Delay Rampage

- You sometimes delay [[talent:112277]] in your rotation, it is only the highest priority when it is needed to enable [[spell:184361]].
- When you are not at risk of hitting the rage cap, it is beneficial to collect more rage in order to get a surplus that can be used later to cover for bad luck, so that you keep [[spell:184361]] up at all times.
- If you play [[talent:134032@AJQABA]], there is a great value in spending rage itself, in  order to get higher uptime of your cooldowns. You can still delay [[talent:112277]], but generally don't if you risk hitting the rage-cap.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

- More detailed boss tips will be added after the upcoming Race to World First is concluded.



### Nek'zali the Soulcoiler

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Offensive Cooldown Usage

- It can be beneficial to have cooldowns ready for **Restless Amani** add spawns, but only hold cooldowns if you can see the BigWigs timer with adds about to spawn, it is not worth holding long.

#### Defensive Cooldown Usage

- Use a defensive cooldown when **Nek'zali** casts [[spell:1288772]].

#### Boss Tips

- Beware of where the tank is when **Nek'zali** casts [[spell:1292034]]. Do not be in between her and her target.




### Entombed Sentinels

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Offensive Cooldown Usage

- Keep an eye out for when the **Entombed Sentinels** reach 100 energy and cast [[spell:1284606]] , as you don't want to just have popped cooldowns when that happens and be unable to deal any damage.

#### Defensive Cooldown Usage

- Use a defensive cooldown when soaking [[spell:1288282]].

#### Boss Tips

- During [[spell:1284606]] you get marked with either 1, 2 or 3 Venom Blobs over your head. Combine 1 with 3, and 2 with 2 with the goal of reaching 4.




### The Lost Explorers

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Defensive Cooldown Usage

- Use a defensive cooldown if soaking a [[spell:1300237]] with not many people in it to split the damage.

#### Boss Tips

- You can [[spell:6544]] over the [[spell:1297650]] if needed, but there is not really a benefit compared to playing with the group, jumping on the mushroom. Use it if you get out of position and the wave is coming.




### Vashnik the Malignant

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Defensive Cooldown Usage

- Use defensive cooldowns when affected by [[spell:1285979]] from killing the fire adds, especially if you get more than 1 stack.

#### Boss Tips

- Help allies affected by [[spell:1295224]] to clear their circle and be healable again.




### Sszorak

:::talents [[talent:123390]] **Fury Warrior** raid ST talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM"
}
```
:::

#### Offensive Cooldown Usage

- **Sszorak** takes increased damage during [[spell:1286033]].

#### Defensive Cooldown Usage

- Use a defensive cooldown if you got hit by a [[spell:1287083]] tornado.

#### Boss Tips

- When affected by [[spell:1285616]], place yourself in a way that you collide with another player. If needed use [[spell:100]] or  [[talent:112208@AJQA]] to save yourself from flying off.




### The Twin Fangs

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Defensive Cooldown Usage

- Use a defensive cooldown when affected by [[spell:1290878]].

#### Boss Tips

- Help soak [[spell:1289201]] as much as you can, but don't take too many stacks of [[spell:1292348]].
- Avoid getting hit by [[spell:1292806]] waves.




### The Coiled Altar

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Offensive Cooldown Usage

- Make sure to have all your offensive cooldowns available for the intermission after phase 2, where **Zul'jan** takes 100% increased damage through [[spell:1304033]].

#### Defensive Cooldown Usage

- Use defensive cooldowns when affected by [[spell:1286901]].

#### Boss Tips

- Absolutely prioritize and make sure to pick up all your **Soul Fragments** if you were hit by [[spell:1286901]], otherwise you will be [[spell:1286837]].




### Ula'tek

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

Ula'tek was not seen on the 12.1 PTR servers, and will first be seen on patch launch and season start. The talents provided above should be a good starting point.  
Ula'tek and updates to all bosses will follow soon after I am done competing in the upcoming Race to World First.




### Nymrissa Wavecaller

:::talents [[talent:123390]] **Fury Warrior** raid Cleave talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### Defensive Cooldown Usage

- Use a defensive cooldown when **Nymrissa** casts [[spell:1260843]].

#### Boss Tips

- Be ready to charge **Nymrissa** or use [[talent:112208@AJQA]] when the bubble [[spell:1266340]].
- Don't stand in the water too long or you get hit with a [[spell:1265425]].





## Stat Priority

Understand your stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Fury Warrior**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Fury Warrior** Stat Priority in Raids
```json
{
  "source_code": "IgAHEEDJggiADQA"
}
```
**精通 ＝ 急速 ≥ 暴击 ≫ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271456@DiCBAgEAvj7cUrDf1IYN2WjNyIoAFfBB]] | Nek'zali the Soulcoiler + Catalyst |
| Neck | [[item:268265@BkCAAgEAU06IQrDj1QWNYYjX1IoA]] | Ula'tek |
| Shoulder | [[item:271454@DACAAgEA1k74XNBWjNyIoA]] | The Lost Explorers |
| Cloak | [[item:268253@BgRAAgEAYYjX1IoAYFA]] | The Coiled Altar |
| Chest | [[item:271459@DASBAgEAJk7oXNCWDG2IoAYFgvXQ]] | The Coiled Altar + Catalyst |
| Wrist | [[item:237834@BiUAAgEAM06Y7LjVT0wwgN3Wjt1ccNAMSWisUA]] | Blacksmithing |
| Gloves | [[item:271457@BASAAgEA7VTg1YjMCKgTBA]] | Entombed Sentinels |
| Belt | [[item:268259@BCSAAgEA8z6ghNeVjt1IoAYF]] | The Coiled Altar |
| Legs | [[item:271878@DACAAgEAju7YhNYYjX1IoA]] | Ula'tek |
| Boots | [[item:268260@BgBAAgEA2IjX1IoA]] | Vashnik the Malignant |
| Ring 1 | [[item:252258@DCSAAgEA1j7wPrDZ1YjMeVjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:268249@DCCAAgEA1j7wPrDZ1YjMeVjgCA]] | Vashnik the Malignant |
| Trinket 1 | [[item:270175@BghAAgEAYYjX1IoAFAQAXdhA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgBAAgEAYYjX1IoA]] | The Coiled Altar |
| Weapon | [[item:268213@DgBAAgEAFk7ghNeVjgC]] | The Coiled Altar |
| Weapon Off-Hand | [[item:237848@DgDAAgEAFk7Y7LMYzt1sZJLXDAjklIA]] | Blacksmithing |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@DARAAcEANk74iMeVTQB]] | Murder Row |
| Neck | [[item:251142@AgQAAIoABFA]] | Murder Row |
| Shoulder | [[item:251138@DARAAcEA7j74iMeVTQB]] | Murder Row |
| Cloak | [[item:193763@BARAAcEAuIjX1EUA]] | Ruby Life Pools |
| Chest | [[item:193753@AgQAAIoABFA]] | Ruby Life Pools |
| Wrist | [[item:251133@BARAAcEAuIjX1EUA]] | Murder Row |
| Gloves | [[item:159413@BARAAcEAuIjX1EUA]] | Kings' Rest |
| Belt | [[item:159418@BARAAcEAuIjX1EUA]] | Kings' Rest |
| Legs | [[item:273776@DARAAcEAju74iMeVTQB]] | Altar of Fangs |
| Boots | [[item:159412@DARAAcEApk74iMeVTQB]] | Kings' Rest |
| Ring 1 | [[item:273792@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | Altar of Fangs |
| Ring 2 | [[item:251136@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | Murder Row |
| Trinket 1 | [[item:273796@BARAAcEAuIjX1EUA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BARAAcEAuIjX1EUA]] | Murder Row |
| Weapon | [[item:273782@DARAAcEAFk74iMeVTQB]] | Altar of Fangs |
| Weapon Off-Hand | [[item:193755@AgQAAIoABFA]] | Ruby Life-Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270165@AgQAAIoAOFA]] |
| **B-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C-Tier** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *-- OK for AoE, Junkyard for single-target.* |
| **Junkyard** |  |

:::simulation
```json
{
  "source_code": "JcsBwzkJBMYLEEAEBAASAYjMASjTBAgdXZGSB81HEEACBAASAghNYFAAsgUcIFIIO9GITVGd6oVdsdiap52JzByR1lGbs9Gdp5WZgQVZjhWXf4CNAQhdKLHSBUoOcBAEm-ZaIFgNoAAHmqBdIFQ30LgMECAFwSVaIFg46UBAUsYVphUAEqjUAQBNhrGSBQVEuCjNy4UAAoOpuhUA0F9AyIFAUo9vqhUA1pTFAQBKKnGSBMpOVAAF2vCcIFgf6UBAUcbnphUAVJzZAQh1svGSBMoOoAAF83YZIFQh6UBAYYpYrhUAfqmNjDAFu2tZIFwUyIFAU0XklhUAYFxEloHCvmiZ6YUAUEUAAsf_opTCBASQBAAPlhGSBCiqkGAFBFAAQoWby8YAUEUAA8HPwpDrAASQBAQdnTGSBMoL6FAHBFAAkXXZIFQXogRQBAQU90GS2wcAUEUAAgMJnpDzBEgUEcGa68YAUEUAAYQ1pJDABQRQBAQA1QmONGAFBFAAcAJa6oXAUEUAAoSFkpDzBQRQBAg_v3mMlFAHBFAA04MZIFgMiGAGBFAAqyIaIZzMCQRQBAQKpmmMbJAFBFAA1IKbycgAgEUAAc3Hrh0B_D"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| [[item:273795]] | 235,869.84 |
| [[item:270175]] | 247,072.69 |
| [[item:270173]] | 248,617.84 |
| [[item:273797]] | 239,230.59 |
| [[item:270173]] | 249,962.59 |
| [[item:193757]] | 238,930.75 |
| [[item:193762]] | 238,934.17 |
| [[item:273796]] | 240,516.81 |
| [[item:270164]] | 244,371.66 |
| [[item:250228]] | 240,383.41 |
| [[item:250229]] | 239,400.62 |
| [[item:250259]] | 245,935.84 |
| [[item:250238]] | 239,222.86 |
| [[item:270165]] | 241,587.34 |
| [[item:250243]] | 235,063.94 |
| [[item:250245]] | 241,034.34 |
| [[item:158367]] | 236,406.72 |
| [[item:270163]] | 235,077.95 |
| [[item:270168]] | 235,686.73 |
| [[item:273797]] | 238,583.92 |
| [[item:273796]] | 237,972.94 |
| [[item:270173]] | 243,112.25 |
| [[item:270173]] | 246,001.98 |
| [[item:158367]] | 234,397.83 |
| [[item:273795]] | 234,967.56 |
| [[item:270175]] | 242,933.27 |
| [[item:193757]] | 236,691.12 |
| [[item:193762]] | 237,981.83 |
| [[item:250229]] | 239,444.09 |
| [[item:270168]] | 233,684.02 |
| [[item:250238]] | 238,144.44 |
| [[item:250243]] | 233,556.66 |
| [[item:250259]] | 243,647.97 |
| [[item:270163]] | 234,296.81 |
| [[item:250245]] | 238,130.66 |
| [[item:250228]] | 239,268.64 |
| [[item:270164]] | 242,312.83 |
| [[item:270165]] | 240,765.86 |
:::

### Embellishments

- Going for a crafted weapon with [[item:273060]] is the best option, especially for initial gearing unless you have 2 good weapons already.
- For the second embellishment craft we go for either a [[item:240167]] or a [[item:273069]] embellishment, with the 2 options being very close when you account for the benefit that [[item:240167]] brings to an ally. Recommended slot is wrist.  *-- In the past cloak would be a likely slot, but this tier the raid drops a higher item level 344 Cloak that we prefer to use.*

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]] or  *-- BiS profile uses Haste flask*
  
  
  
  - [[item:241326]] or
  - [[item:241322]] *-- Fury Warriors want a balance of stats with Haste, Mastery and Critical Strike.*  *If you want to find out your own stat balance and what you need more of, I recommend checking out our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**.*
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]] *-- Best for the BiS profile, but it might not be best for you. Check Simulationcraft if you want to be sure of using the correct potion for your character.* *Our**[ Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** can help you if you want to learn more about Simulationcraft.*
  
  
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Temporary Enchant**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].*
    
    - [[item:240890]]
    - [[item:240906]]
    - [[item:240916]]
    - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707]] |
| --- | --- |
| Shoulders | [[item:244021]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:244643]] |
| Boots | [[item:243983]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:243973]] |
| Weapon Off-Hand | [[item:243973]] |

:::

:::column
:::gear **Fury Warrior** Enchantments for Raids
```json
{
  "source_code": "JwFZHBQ9NGQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwo7mAGA8gOYAAB1jbCYEBCoUQuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244643]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
| 副手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:263897]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Fury Warrior** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:20589]] -- Gnome
  
  - Root and Snare dispel.
- [[spell:58984]] -- Night Elf
  
  - Drop combat in order to avoid spells being targeted at you.
- [[spell:20594]] -- Dwarf
  
  - Removes all Poison, Disease, Curse, Magic, and Bleed simultaneously.
- [[spell:69179]] -- Blood Elf
  
  - Dispels 1 beneficial effect from all nearby enemies at the same time.
- [[spell:256948]] -- Void Elf
  
  - Activate to spawn a shadow traveling in the direction you are facing. Activate again to teleport to it.
  - Maximum range of 100 yards.

:::simulation
```json
{
  "source_code": "JUtAQ2xAfAAACSwRv52aKYHB251cINgFAAAAvmKdINQHAAAAVf-dINQAjAqBLlWbiVHbLYHB_L2cINAIAAAAg7jdINgIAAAAjlXdINQJAAAAA-tdIVQU0cwSyF2ZncXYMYHB_M9cJIEKFAVYnsWdJYHBvCWDmAlBBtWduRWYHYHBdiAdINgHAAAAJPeDuwXCCd3buNXYtRWaIYHB2qEdINABAAggDQUY5xKXCQXt1lAEwXZBOl2ZoRXrcJACiWHSDcAAAAwCiaHSDMAAAAweGgHSDoAAAAwToWHSDEAAAAgTfeHSDQCAAAge2THSDIAAAAQ_IXHSDsAAAAgSWWHSDgAAAAw5DYHSDUAAAAwYmSHSDgBAAAgjvbHSDkAAAAQphaHSDYAAAAwuKgHSDwBAAAApuZHSDsBAAAQuzNHSDMCAAAQB4LHSHkB"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292362]] | 249,209.84 |
| 种族 22 | 250,534.73 |
| 种族 29 | 253,855.33 |
| 种族 31 [[spell:292363]] | 249,227.98 |
| 种族 32 | 252,155.50 |
| 种族 34 | 251,365.55 |
| 种族 37 | 252,798.00 |
| 种族 31 [[spell:292364]] | 249,676.98 |
| 种族 31 [[spell:292361]] | 252,290.73 |
| 种族 31 [[spell:292359]] | 249,890.45 |
| 种族 30 | 249,743.14 |
| 种族 31 [[spell:292360]] | 250,154.84 |
| 种族 4 [[spell:154796]] | 251,605.81 |
| 种族 4 [[spell:154797]] | 251,528.12 |
| 种族 7 | 252,552.17 |
| 种族 3 | 253,977.92 |
| 种族 10 | 251,553.23 |
| 种族 1 | 253,565.22 |
| 种族 36 | 250,841.91 |
| 种族 2 | 251,683.95 |
| 种族 11 | 251,481.16 |
| 种族 8 | 251,919.61 |
| 种族 5 | 250,521.55 |
| 种族 24 | 252,862.22 |
| 种族 9 | 252,550.58 |
| 种族 6 | 253,994.92 |
| 种族 28 | 252,346.56 |
| 种族 27 | 249,294.89 |
| 种族 35 | 248,800.08 |
:::

### Recommendation

If you prioritize the highest DPS then you should go with the best simming racial, but if your priority is in progression raiding then you should consider the the utility of different racials. For example: The [[spell:65116]] racial made Dwarf the best pick for **Fyrakk the Blazing** in the Race to World First Amirdrassil, the Dream's Hope.

## Macros

Discover recommended macros for **Fury Warriors** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:376079]] Macro** *--- Champion's Spear cast on your cursor.*

```wow-macro
/cast [@cursor] Champion's Spear
```

**[[spell:6544]] Macro** *--- Leap on your cursor without the extra mouse click.*

```wow-macro
/cast [@cursor] Heroic Leap
```

:::

:::details Mouseover Macros
**[[spell:163201]] Macro** *--- If your mouse is over an enemy then Execute it, otherwise Execute your target. This macro is useful to Execute a nearby low HP mob while still targeting the boss.*

```wow-macro
/cast [@mouseover, harm, nodead][harm,nodead] Execute
```

**[[spell:100]] Macro** *--- Charge your target, unless your mouse is over another enemy, then it targets that enemy and uses Charge.*

```wow-macro
/target [@mouseover, harm, nodead]
/cast Charge
```

:::

:::details Convenience Macros
**[[spell:386208]] and [[spell:386196]] Macro *--- With this you can swap stances while using only 1 keybind.***

```wow-macro
/cast [stance:2] Defensive Stance; stance[:3] Berserker Stance
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Fury Warrior**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![Revvez Midnight Fury Warrior UI](<https://assets-ng.maxroll.gg/wordpress/UIEllesmereUI-1024x576.png>)

Revvez **Fury Warrior** UI

:::accordion
:::details Addons
- **MRT *-- Notes, Raid cooldowns, and more*** 
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **Ellesmere UI *-- User Interface replacement*** 
  
  - EllesmereUI is a fully modular UI suite designed for players who want complete control over their interface without sacrificing performance or simplicity. Every element is built from the ground up to be lightweight, responsive, and easy to configure.
- **BigWigs *-- Generic Boss Mod***  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**WARRIOR**

- *Developers' notes: Rend is an iconic and core Warrior ability with a different relationship to each spec. Our approach to Rend in Midnight hasn't worked out as we hoped, so we're making changes to how each spec applies and interacts with Rend in Curse of Ula'tek.*
- The Rend ability is now exclusive to Arms, has returned to being a single-target ability, and its Rage cost is reduced to 10. Cleave will apply Rend to all targets if the Warrior knows Rend.
- New Talent (Fury): Storm of Blood – Whirlwind applies Rend to all targets. Crashing Thunder causes Storm of Blood to also apply to Thunder Clap for Mountain Thane.
- New Talent (Protection): Blood and Thunder – Thunder Clap applies Rend to all targets.
- Thunder Clap no longer innately applies Rend if known.
- Javelineer has a new icon.
- Hero Talents
  
  - Mountain Thane
    
    - Developers' notes: Thunder Clap's base damage increased significantly in Midnight, causing overall Thunder Clap damage to rise significantly for Mountain Thane, which in turn devalued Thunder Blast. We're moving the Crashing Thunder damage bonus into Thunder Blast itself to keep Thunder Blast feeling special and powerful.
    - Thunder Blast damage increased by 20%.
    - Crashing Thunder increases Thunder Clap damage by 10% (was 30%).
- Fury
  
  - Developers' notes: Whirlwind has historically been a core part of Fury gameplay, even in single-target situations. We'd like to open the door for Whirlwind to be a useful ability in single target again.
  - New Talent: Carving Blades – Whirlwind deals 50% additional damage when it strikes only a single target.
  - Whirlwind has been updated – Whirlwind now generates 3 Rage innately.
  - Improved Whirlwind has been updated – No longer causes Whirlwind to generate 3 Rage innately, but still increases Rage generated by Whirlwind by 1 per target hit, up to 8 total Rage.
  - Rampaging Ruin has been redesigned – While Improved Whirlwind is active, Rampage's final strike slams the ground, dealing Physical damage to all enemies within 8 yards of your target. Damage reduced beyond 5 targets.
    
    - *Developers' notes: Rampaging Ruin is intended to help alleviate the AOE target cap on Fury's rotational AOE abilities. The current design ended up being very difficult to figure out when it was best to use Rampaging Ruin, the new design should make the choice much more intuitive.*
  - Hack and Slash has been updated – Rampage now has a 75% chance to refund a charge of Raging Blow and increase the damage of your next Raging Blow by 20%.
    
    - *Developer’s notes: We feel that Fury plays best when there is a degree of uncertainty about which ability you’ll use after the one you’re currently pressing. Previous iterations of Hack and Slash provided extremely regular and consistent Raging Blow resets, causing Raging Blow to almost always be available. We believe this change will help keep Fury rotations variable and allow for more difference in rotational feel between builds that emphasize Raging Blow and those that do not.*
  - Bloodbath initial damaged reduced by 12% and bleed damage increased by 300%.
    
    - *Developers' notes: The intent behind Bloodbath is that the majority of the damage bonus comes from the bleed. The existing tuning hasn’t been delivering on that, so we’re moving some of Bloodbath’s increased damage from the initial hit to the bleed. This change should be net neutral for Bloodbath’s overall damage.*
  - Hero Talents
    
    - Mountain Thane
      
      - Ground Current damage increased by 150%.

:::

:::details Patch 12.0.5
**WARRIOR**

- Rend radius increased to 10 yards (was 8 yards).
- Wrecking Throw will now be highlighted when the Warrior targets a unit with an active Absorb shield.
- Shattering Throw will now be highlighted when the Warrior targets a unit with an active Immunity effect, or a Mage’s Ice Wall.
- Fury
  
  - Hack and Slash has been redesigned – Rampage has 100% chance to refund a charge of Raging Blow.
  - Improved Whirlwind now causes Whirlwind to apply Rend to all targets if Rend is known.
  - Slayer
    
    - Reap the Storm has been updated – When Rampage hits 3 or more targets via Improved Whirlwind you have a 20% chance to unleash a flurry of steel, striking all nearby enemies for high Physical damage and applying Overwhelmed.
    - Unrelenting Onslaught now increases damage dealt by Bladestorm by 20%.

:::

:::details Patch 12.0.1
**WARRIOR**

- Hero Talents
  
  - Mountain Thane
    
    - Fury
      
      - Lightning Strike damage increased by 100%.
      - Thunder Blast damage reduced by 30%.
      - Crashing Thunder damage bonus to Thunder Clap reduced to 30% (was 40%).
  - Slayer
    
    - Imminent Demise now has an additional effect – Sudden Death has a 100% chance to trigger Reap the Storm.
    - Slayer’s Strike damage reduced by 10%.
    - Reap the Storm damage reduced by 20%.
    - Fury
      
      - Culling Cyclone bonus damage increased to 20% (was 10%).
      - Slayer's Malice bonus damage reduced to 15% (was 20%).
      - Reap the Storm’s chance to trigger increased to 35% (was 25%).
- Class
  
  - Deep Wounds damage reduced by 30%.
- Fury
  
  - Auto-attack damage reduced by 48%.
  - Bloodthirst damage increased by 10%.
  - Bladestorm damage increased by 30%.
  - Raging Blow damage reduced by 20%.
  - Rampage damage reduced by 10%.

:::

:::details Patch 12.0
**WARRIOR**

- Hero Talents
  
  - Mountain Thane
    
    - New Talent: Storm Surge – Avatar increases the damage of Thunder Clap by 50% and reduces its cooldown by 50%.
    - New Talent: Conductivity – Lightning Strike damage increased by 10% and critical strike damage increased by 10%.
    - New Talent: Capacitance –During Avatar Thunder Blast extends Avatar's duration by 2 seconds.
    - Thunder Blast damage increased by 150%.
    - Fury
      
      - Strength of the Mountain's Bloodthirst and Rampage damage increased by 15% (was 25%).
  
  
  
  - Slayer
    
    - New Talent: Violent Euphoria – Bladestorm puts you into a battle trance, granting you 15% Haste for 8 seconds after you stop Bladestorming.
    - New Talent: Deadly Focus – Executioner's duration is increased by 6 seconds.
    - New Talent: Unhinged
      
      - Fury: Every 2 strikes of Bladestorm, you automatically cast a Bloodthirst at your target or random nearby enemy, dealing 100% of normal damage.
    - Slayer's Dominance has been updated – Your attacks have a 15% chance to trigger a Slayer's Strike. Slayer's Strike now grants you a stack of Executioner, increasing your Execute damage by 3% for 12 seconds. Multiple stacks of Executioner may overlap.
    - Show No Mercy has been updated – Executioner also increases your Execute critical strike chance and critical strike damage by 3% per stack.
    - Unrelenting Onslaught has been updated – Using Sudden Death causes you to both reduce the cooldown of Bladestorm by 5 seconds and apply 1 stack of Overwhelmed to your primary target for each stack of Executioner you have.
    - Opportunist's effect now stacks up to 2 times.
    - Overwhelming Blades' Overwhelmed debuff now stacks 5 times (was 10).
    - Slayer's Malice now affects Execute in addition to Overpower and Raging Blow, but the damage increase is reduced to 20% (was 30%).
    - Slayer's Strike damage increased by 100%.
    - Reap the Storm damage increased by 100% and its chance to trigger increased to 25% (was 20%).
    - Fury
      
      - Opportunist's damage and critical strike damage of next Raging Blow reduced to 10% (was 25%).
- Class
  
  - New Talent: Resonant Voice – The duration of your shouts is increased by 20%.
  - New Talent: Retaliation – When you take any damage from an enemy within melee range, you have a chance to strike that enemy for Physical damage.
  - New Talent: Stance Mastery – Your stances have additional effects.
    
    - Battle Stance: Increases the critical strike damage of your abilities by 3%.
    - Berserker Stance: Increases your auto-attack speed by 3%.
    - Defensive Stance: When an attack deals 20% or more of your maximum health in damage, that damage is reduced by 15%.
  - New Talent: Battlefield Commander – Your Shout abilities have additional effects.
    
    - Battle Shout: Grants you an additional 3% attack power.
    - Rallying Cry: Grants an additional 2% health and duration increased by 3 seconds.
    - Piercing Howl: Radius increased by 100%.
    - Berserker Shout: Radius increased by 100%.
    - Intimidating Shout: Cooldown reduced by 15 seconds.
  - New Talent: Anger Management – Every 20 Rage you spend reduces the remaining cooldown on Avatar, Colossus Smash, Recklessness, and Shield Wall by 1 second.
  - New Talent: Field Dressing – Healing received increased by 3% and all self-healing increased by an additional 10%.
  - New Talent: Fearless – Cooldown of Berserker Rage is reduced by 50% and Berserker Rage removes all movement speed-impairing effects.
  - New Talent: Javelineer – Range of your thrown abilities is increased by 5 yards. Damage dealt by Champion's Spear, Shattering Throw, and Wrecking Throw increased by 20%. Shattering Throw and Wrecking Throw silence non-players for 3 seconds.
  - New Arms and Fury Talent: Interpose – Run at high speed toward a target location near your allies, taking 30% of all damage dealt to allies within 3 yards for 8 seconds or until you take at least 20% of your max health in damage from this effect.
  - New Arms and Fury Talent: Rend – Lash out with your weapon, striking all targets within 8 yards for Physical damage and wounding them for additional Bleed damage over 15 seconds.
  - Champion's Spear has been redesigned – Throw a spear at the target location, chaining all enemies in the area to the spear's location and dealing Physical damage instantly and additional Physical damage over 6 seconds. While the spear is active, activating this ability will cause you to leap to the spear, slamming down to deal Physical damage to all targets. All damage dealt reduced beyond 5 targets. Generates 10 Rage.
  - Intimidating Shout now reduces the movement speed of all targets by 70% and causes all enemies other than your primary target in range to flee. Was previously 8 targets.
  - Rallying Cry has been updated – Health granted is increased by 50% when not in a raid.
  - Honed Reflexes now reduces cooldowns by 10% (was 5%) and has an additional effect – Successfully interrupting an enemy increases the damage you deal to them by 5% for 10 seconds.
  - Piercing Howl now also spurs all allies within 12 yards, increasing their movement speed by 30% for 4 seconds.
  - Barbaric Training now increases damage dealt by 10% and critical strike damage by 5% for Slam, Whirlwind, Thunder Clap, Raging Blow, and Revenge.
  - Shattering Throw and Wrecking Throw range reduced to 25 yards (was 30 yards).
  - Thunder Clap damage increased by 150% and applies Rend to all targets if talented.
  - Shield Slam damage increased by 140%.
  - Second Wind healing while you are below 35% health increased by 100%.
  - Crushing Force is now a 1-point talent.
  - Many talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Avatar *(moved to each specialization's talent tree)*
    - Berserker's Torment
    - Blademaster's Torment
    - Cacophonous Roar
    - Challenger's Might
    - Concussive Blows
    - Immovable Object
    - Menace
    - Piercing Challenge
    - Seismic Reverberation
    - Thunderous Roar
    - Thunderous Words
    - Titan's Torment
    - Unstoppable Force
    - Uproar
    - Warlord's Torment
- Fury
  
  - New Talent: Deep Wounds – Execute inflicts Deep Wounds on the target, causing high damage over 6 seconds.
  - New Talent: Scent of Blood – Rampage increases the damage of your next Bloodthirst by 10%, stacking up to 2 times.
  - New Talent: Ragedrinker – Bloodthirst critical strikes restore 3% additional health and increase the damage of Raging Blow by 10% for 4 seconds.
  - New Talent: Executioner's Wrath – Execute generates 5 additional Rage and increases the damage of Rampage by 10% for 4 seconds.
  - New Talent: Surge of Adrenaline – When Raging Blow resets its own cooldown, your auto-attack damage and speed is increased by 30% for 6 seconds.
  - New Talent: Kill or Be Killed – When you would sustain fatal damage, you fly into an unstoppable rage, becoming unkillable and immune to movement-impairing effects for 8 seconds as you seek revenge on your would-be killer. If you kill your killer in this time, you emerge triumphant from your rage with at least 20% of your max health intact. If you are not victorious, you die. This effect can only occur every 5 minutes.
  - New Passive Ability: Titan's Grip: Single-Minded Fury – You can transmogrify your two-handed weapons to use one-handed weapon appearances.
  - Avatar has moved to the Fury talent tree and has been updated – Transform into a colossus, increasing all damage you deal by 20% and increasing your movement speed by 5% for 20 seconds.
  - Meat Cleaver has been redesigned – Whirlwind deals 50% additional damage when it hits 3 or more targets.
  - Bloodborne has been redesigned – Targets struck by Bloodthirst take 20% additional damage from your Bleed effects for 12 seconds.
  - Deft Experience has been redesigned – Bloodthirst's critical strike chance is increased by 5%/10% and if you are Enraged, Bloodthirst extends your Enrage by 0.5 seconds/1 second. This extension is doubled if Bloodthirst critically strikes your primary target.
  - Frenzy has been redesigned – Rampage increases your Haste by 2% for 12 seconds. Multiple instances of this effect may overlap.
  - Critical Thinking has been redesigned – Raging Blow's critical strike chance increased by 5%/10% and critical strike damage increased by 5%/10%.
  - Improved Bloodthirst renamed to Spite and has been updated – Bloodthirst and Raging Blow (was only Bloodthirst) damage and critical strike damage increased by 2.5%/5% (was 5%/10%).
  - Cruelty has been updated – While Enraged, Bloodthirst and Raging Blow (was only Raging Blow), deal 5%/10% additional damage (was 10%/20%).
  - Powerful Enrage has been updated – Enrage increases your Mastery by 15% and your Leech by 3%.
  - Bloodcraze has been updated – Raging Blow increases the damage of your next Bloodthirst by 5%, stacking up to 5 times.
  - Improved Whirlwind now causes your next 4 single-target attacks (was 2) to strike 4 additional targets.
  - Rampage now replaces Slam. Rampage damage increased by 10%.
  - Auto-attack damage increased by 200%.
  - Thunder Clap damage decreased by 60%.
  - Whirlwind damage increased by 20%.
  - Bloodthirst damage increased by 20%.
  - Bladestorm now generates 5 Rage per strike (was 10).
  - Recklessness increases all Rage generated by 50% (was 100%).
  - Odyn's Fury now Enrages you and generates 20 Rage (was 15).
  - Odyn's Fury's bleed damage increased by 140% and now deals reduced damage above 8 targets (was 5).
  - Rampaging Ruin's damage dealt increased by 50%, but it now deals reduced damage beyond 5 targets (was 8 targets).
  - Fixed an issue that was causing Odyn's Fury bleed damage to be incorrectly reduced by armor.
  - Many talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Ashen Juggernaut
    - Dancing Blade
    - Depths of Insanity
    - Onslaught
    - Ravager
    - Single-Minded Fury
    - Slaughtering Strikes
    - Storm of Steel
    - Tenderize
    - Titanic Rage
    - Unbridled Ferocity
    - Unhinged

:::

:::details Patch 11.2
### Warrior

- The global cooldown of Hamstring is now 0.75 seconds (was 1.5 seconds).
- Fixed an issue where Berserker Rage was able to remove Scatter Shot.
- Berserker Rage’s tooltip has been slightly adjusted to indicate it only works on certain Incapacitate effects.

#### Fury

- *Developers' notes: Fury has been struggling to keep up in sustained AOE combat. These changes are aimed at bolstering Fury in these situations.*
- All ability damage increased by 5%.
- Bladestorm damage increased by 15%.
- Whirlwind damage increased by 10%.
- Improved Whirlwind causes your single-target attacks to deal 65% damage to up to 4 nearby targets (was 55%).

:::

:::details Patch 11.1
### Warrior

- *Developers' notes: We feel that Warriors are in a good place overall, however, there are a few places we'd like to make improvements to each spec, and to the class as a whole. Warrior survivability in particular has been a weak point, and Endurance Training competing against powerful throughput nodes in the bottom of the Warrior tree makes it difficult to talent into. We’re combining Endurance Training and Reinforced Plates to put the choice in the second tier, which has more choice against other utility and survival nodes and thus be easier to spend points on. The Weapon Specialization nodes have been increased to 2 points to keep the tree structure and overall talent build costs similar, and the nodes have been rearranged slightly to make the choice about how to access Avatar more distinct for each spec.*
- Reinforced Plates is now a 2-point talent that grants 5% Stamina and 5% Armor per point.
- Overwhelming Rage is now a 1-point talent that increases maximum Rage by 30.
- Two-Handed Weapon Specialization (Arms) is now a 2-point talent that grants 3% damage and 2% reduction of damage from area-of-effect attacks while wielding a 2-hand weapon per point.
- Dual Wield Specialization (Fury) is now a 2-point talent that grants 3% damage and 2% movement speed while dual-wielding per point.
- One-Handed Weapon Specialization (Protection) is now a 2-point talent that grants 3% damage and 2% Leech per point.
- Thunderous Words increases your Bleed damage by 20% on affected targets (was 30%).
- Cruel Strikes, Wild Strikes, and the Weapon Specialization nodes have changed positions in the tree.
- Endurance Training has been removed.

#### Fury

- *Developers' notes: Fury is overall in a place we are happy with, and we're taking this opportunity to redesign some talents to keep their effects unique and powerful.*
- Titan’s Torment has been redesigned – While Avatar is active Rampage's Rage cost is reduced by 20 and Bloodthirst's cooldown is reduced by 1.5 seconds.
- *Developers' notes: We want to provide a new option for Avatar to impact Fury's rotation, and let you make the best use of your Avatar duration with more Rampages and Bloodthirsts. This change will also allow us to maintain Odyn’s Fury as a powerful and signature Fury ability independent of Avatar.*
- Reckless Abandon has been redesigned – Activating Recklessness generates 50 Rage and while Recklessness is active, Raging Blow and Bloodthirst are replaced by Crushing Blow and Bloodbath.Crushing Blow – A powerful dual-weapon strike that deals 20% increased Critical Strike damage.
- Bloodbath – A powerful attack that applies a Bleed to the target that is extended by its full duration when reapplied.
- *Developers' notes: Reckless Abandon has been having an outsized impact on rotations and we’d like to bring the focus of the talent back to Recklessness as well as make Crushing Blow and Bloodbath abilities with unique additional effects.*
- All ability damage reduced by 5%.
- Bloodthirst damage increased by 38%.
- Bloodbath instant damage increased by 38%.
- Raging Blow damage increased by 44%.
- Crushing Blow damage increased by 44%.
- Rampage damage increased by 44%.
- Odyn's Fury damage increased by 15%.
- Onslaught damage increased by 30%.
- Whirlwind damage increased by 30%.

#### Mountain Thane

- Thunder Blast damage increased by 25%.
- Strength of the Mountain increases Bloodthirst and Rampage damage by 25% (was 30%).

#### Slayer

- Imminent Demise and Death Drive now correctly require the Sudden Death talent to be taken to function.
- *Developers' notes: This was an oversight during implementation. Slayers are expected to talent into Sudden Death.*

:::

:::details Patch 11.0.5
### Warrior

- [[talent:112223]] now deals reduced damage beyond 5 targets (was 8).
- [[talent:112247]] icon has been updated.

#### Slayer

- [[spell:445836]] now stacks up to 10 times (was 12).

#### Fury

- [[talent:112265]] damage increased by 25%
  
  - *Developer's note: This change does not affect [[talent:112284]] Crushing Blow.*
- [[talent:112261]] damage increased by 30%.
  
  - *Developer's note: This change does not affect [[talent:112284]] Bloodbath.*
- *Developer’s note: Currently [[talent:112284]] is outperforming [[talent:112285@AJQABA]] in all situations, so we’re bringing them closer in power by bringing up Raging Blow and Bloodthirst’s base damage, which will also improve Fury’s baseline single-target damage.*
- [[talent:112212@AJQABA]] now increases [[talent:112261]] critical strike damage by 5/10% (was critical strike chance by 2/4%).
- [[talent:112289]] now deals reduced damage beyond 5 targets (was 8).

:::

:::details Patch 11.0.2
### Warrior

- [[spell:23922]] damage increased by 8%.
- [[talent:112217]] now heals for 2% of your max health (was 3.5%).

#### Fury

- [[talent:112262]] now heals for 10% of maximum health (was 15%).

:::

:::details Patch 11.0
### Warrior

- All talent trees have had many talents move locations or have had their pathing updated.
- [[talent:118850]] has been redesigned – Cooldown of [[talent:112128]], [[talent:112264]], [[spell:871]], [[spell:6552]], [[talent:112186]], [[talent:112253]], and [[talent:112198]] reduced by 5%.
- [[talent:112190]] gains an additional effect – While you are below 35% health, restores 1.0% health every 1 second. The amount restored increases the closer you are to death (max 2%).
- [[spell:18499]] is now learned at level 12.
- [[spell:1464]] damage increased by 130%. Arms [[spell:1464]] damage bonus reduced to 50% (was 75%).
- [[spell:227847]] damage increased by 70%.
- [[spell:228920]] damage decreased by 10%.
- [[spell:280721]] can now stack 2 times.
- [[spell:6343]] Rage cost reduced to 20 (was 30) and now applies [[talent:112136]] by default if it is known.
- [[spell:215571]] now refunds 10% Rage for Arms and Fury, and 25% Rage for Protection.
- [[talent:112242]] no longer generates Rage on cast.
- [[talent:112247]] generates 10 Rage on cast (was 20).
- [[talent:112223]] no longer generates Rage on cast.
- [[talent:112223]] now deals reduced damage beyond 8 targets. The tooltip will reflect this change in a future update.
- [[talent:112222]] now causes [[talent:112223]]’s Bleed effect to increase damage targets take from all the Warrior’s bleed effects, rather than passively increasing it all the time.
- [[talent:112289]] now deals reduced damage beyond 8 targets. The tooltip will reflect this change in a future update.
- [[talent:112221]] now reduces the cooldown of [[talent:112223]] by 45 seconds (was 30 seconds).
- [[talent:112180]] now causes you to deal 25% increased critical strike damage to targets chained to your Spear.
- [[talent:112246]] now increases all damage dealt by [[talent:112247]] (was only initial damage).
- The visual for [[talent:112242]] will now properly match its radius, both with and without the [[talent:112241]] talent. Impact visual has also been updated.
- The visual for [[talent:112223]] has been adjusted.
- Fixed an issue that caused [[talent:112188]] to increase maximum health by 15% instead of the intended 10%.

##### The following talents have been removed

- Titanic Throw
- Sonic Boom
- Blood and Thunder

#### Fury

- New Talent: [[talent:119112]]: [[spell:184361]] increases the damage your abilities deal by an additional 15% and [[spell:184361]]'s duration is increased by 1 second. On a choice node with [[talent:112267]].
- Hurricane replaced with [[talent:112257]] – Every other time [[talent:119139]] or [[talent:112256]] deal damage, you cast a [[talent:112261]] at your target or a nearby enemy.
- Fury Warriors now learn [[talent:114644]] by default.
- All ability damage increased by 49%.
- [[talent:112277]] damage increased by 26%.
- [[talent:112261]] damage increased by 29%.
- [[talent:112289]] damage increased by 33%.
- [[talent:112265]] damage increased by 10%.
- [[talent:112259]]’s chance for [[talent:112265]] to reset its own cooldown increased to 25% (was 20%).
- [[talent:112284]] now buffs your next [[talent:112261]] and [[talent:112265]].
- [[talent:112284]]'s [[spell:335096]] damage reduced by 26% and [[spell:335097]] damage reduced by 3%.
- [[talent:112292]] now causes [[talent:112261]] to extend your Enrage effect by 0.5/1.0 sec if you are Enraged.
- [[talent:112286]] now also increases [[talent:112261]]’s Rage generated by 1.0/2.0 Rage.
- [[talent:112212]] now increases the damage of [[talent:112261]] by 10/20% and critical strike chance of [[talent:112261]] by 2/4%.
- [[spell:1464]]'s Rage cost removed.
- [[talent:112255]] now increases the chance for [[talent:112259]] to reset [[talent:112265]]'s cooldown by 10% while Enraged.
- [[talent:112292]] no longer reduces [[talent:112261]]'s cooldown, instead it now increases [[talent:112261]]'s chance to trigger [[spell:184361]] by 2% per point.
- [[talent:112294]] no longer increases the duration of [[spell:184361]].
- [[talent:112274]] now triggers from [[talent:112265]] instead of [[talent:112261]].
- [[talent:119139]] now generates 10 Rage per damage event for Fury (20 with [[talent:112258]]).
- [[talent:119139]] is now a choice node with [[talent:112256]]. All existing [[talent:112256]] sub-talents have been updated to work with both [[talent:112256]] and [[talent:119139]].
- [[talent:112283]] no longer triggers from [[talent:112295]] and its chance to trigger is reduced to 6% (was 20%).
- [[talent:112227]] tooltip updated with detailed information. No functional changes.
- [[talent:112226]] tooltip updated with detailed information. No functional changes.
- The following talents have been removed:
  
  - Frenzied Flurry has been removed, its effects have been added to Single-Minded Fury.
  - Raging Armaments
  - Annihilator
  - Storm of Swords

:::

:::

## FAQ

:::accordion
:::details Q: Can I unbind [[talent:135597]] as a Fury Warrior?
A: Yes, in 12.0.5 [[talent:135597]] can now be applied through [[talent:112298@FAQAWKD]] for Slayer, and through [[talent:112205@FAgAadhAEMA]] for Mountain Thane.

:::

:::

---

### Credits

Written By: **Revvez**

Reviewed by: **Meeres**

---

:::changelog 更新记录
**2026-06-17** Updated for patch 12.0.7.

**2026-04-22** Updated Boss Tips and talent builds.

**2026-03-16** Updated BiS list.
Updated Embellishments.
Updated Trinket and Races DPS comparison simulations.

**2026-02-20** Updated for patch 12.0.1
Almost every part of the guide updated.

**2026-01-18** Updated for patch 12.0.

**2025-12-02** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-08-01** Updated for patch 11.2.

**2025-06-24** Updated for patch 11.1.7.
Updated BiS list.

**2025-04-21** Updated for patch 11.1.5.
Updated BiS list.
Updated Trinket simulations.
Small adjustments to rotation section.

**2025-02-23** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7.
Updated BiS list.
Updated simulations.

**2024-10-22** Updated for patch 11.0.5.

**2024-09-09** Changed Single-Target Talents.
Small adjustments to rotation.
Changed BiS list.
Updated simulations.

**2024-08-17** Updated for patch 11.0.2.

**2024-08-01** Guide Written for 11.0.



:::
