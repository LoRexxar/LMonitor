欢迎来到《魔兽世界》12.1 版本的 **野兽控制 猎人** 团队副本 攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从 80 级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 3/5 · 中等

范围伤害 · 3/5 · 中等

功能性 · 2/5 · 较弱

生存能力 · 4/5 · 强

机动性 · 5/5 · 极佳



:::

:::

:::column
:::gear **野兽控制 猎人** 团队副本 最佳配装（BiS）
```json
{
  "source_code": "JwrAo2PA3_PABQIJEIIKBAwJ5OwVtOgNycBN8Vjg1YbNOFQApfBBAESAAQQrDQQCawDZ1wYNYFQACSCBCASAAcRuF8CC-VTgBUBBEYSBVAZC5OgX1wYNYYTOCgVABU2uDQICBAAGAPwJqOgAtOwt1sUABMIJFoCBhubB_wTf1IYNYFQAJfBBCARAAEPuFUBOOFQAot7AECVAAciqDgBwBAIdZJCAjcbN2-CYwsXM2UzY1YbNRDzSBEQhkQAAgEAABgLP7VTg14UABk9FEIIGBAQ94GgNBgBAkFgFQIW2DIIIZYBPeVDZ1kjAOFQAf9BBAgQAAUgrAQVEMgoTBEQ3XQAAQEAAeVDG2gVAB86FEIAGBAQB5OgNycBNMWDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271492]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271490]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:244581]] | [[item:240898]] · [[item:245784]] · [[item:240167]] |
| 腿部 | [[item:271491]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271493]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268207]] | [[item:243973]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第 1 级。
- 第二和第三个天赋点解锁并强化第 2 级。
- 第四个天赋点解锁 **顶尖天赋**的第 3 级。

作为 **野兽控制 猎人**，你可以使用 自然之友。

- **第 1 级**：赋予你 [[spell:1273043]]。
- **第 2 级**：**第 2 级** 中的第一和第二个天赋点使你的宠物造成的伤害提高 5%，并使 [[spell:19574]] 额外打击 2 个目标。这意味着在 **第 2 级** 上花费 2 个天赋点后，你的宠物造成的伤害最终提高 10%，[[spell:19574]] 额外打击 4 个目标。
- **第 3 级**：启用 [[spell:1273126]]，如果使用得当，可大幅增强 [[talent:126408]] 的威力。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-beastmastery-mxr.webp>)

自然之友

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[spell:19574]]
    
    - **野兽控制 猎人的** 主要冷却技能。它的冷却时间不再被 [[spell:217200]] 缩短，但在点出 [[spell:231548]] 天赋后现在拥有固定的 30 秒冷却时间。
  - [[spell:217200]]
    
    - 机制变化相当大。[[spell:217200]] 不再产生 [[spell:272795]]。额外的 [[spell:217200]] 现在会重新施加并叠加到新的 [[spell:217200]] 上，与 [[spell:12654]] 的运作方式非常相似。
  
  
  
  - [[spell:1272099]]
    
    - 不再是一个可主动使用的冷却技能，而是在你按下 [[spell:19574]] 时施加一个强力 DoT。
  - [[spell:321014]]
    
    - 重新设计，被动集中值回复减少，但其产生更多地与 [[spell:217200]] 挂钩。
- **职业天赋树**
  
  - [[spell:257284]]
    
    - 现在对目标提供被动的 3% 伤害增益，但不再与敌人生命值高于 80% 挂钩。这使得 [[spell:257284]] 成为针对单体敌人的一个非常强力的团队增益。
  - [[spell:1258509]] 
    
    - [[spell:19577]] 获得了新机制，使其成为一个短暂的 范围伤害 昏迷。
  - [[spell:472729]]
    
    - [[spell:109248]] 的选择节点，使敌人在被昏迷时被拖拽到 束缚射击 的中心。由于该天赋已被移至职业天赋树，它不再被 [[talent:123347]] 锁定。
  - [[spell:272679]]
    
    - 机制已改变。它不再是一个主动使用的防御技能，而是现在提供被动的 3% 伤害减免。
  - [[spell:53480]]
    
    - 机制已改变，现在是一个可以施放在任何友方目标身上的外部辅助技能。它的运作方式与 [[spell:6940]] 非常相似，但不是在你自己生命值过低时消失，而是在宠物生命值低于 25% 时消失。与 [[spell:1272094]] 构成选择节点。

- **已移除**
  
  - [[spell:359844]] 
    
    - 这曾是 **野兽控制 猎人** 的主要冷却技能，其许多机制被并入 [[spell:19574]]。
  - [[spell:53351]]
    
    - [[talent:123348]] 仍然获得 [[spell:466932]]
  
  
  
  - [[spell:2643]] 
    
    - 基本上被 施放 [[spell:1264359]] 所取代。 一个伤害更高的 范围伤害 法术，但现在有冷却时间。
  
  
  
  - [[spell:212431]] 
    
    - 该技能很少被使用，没有重大改动。
  - [[spell:186387]]
    
    - 移除该技能使 **野兽控制 猎人** 失去了其为数不多的击退手段之一，这使得 **野兽控制 猎人** 没有任何击退手段且功能性非常有限。
  
  
  
  - [[spell:213691]]
    
    - 移除该技能使 **野兽控制 猎人** 失去了其为数不多的功能性冷却技能之一。
  
  
  
  - [[spell:236776]] 和 [[spell:462031]] 
    
    - 移除该技能使 **野兽控制 猎人** 失去了其为数不多的击退手段之一，这使得 **野兽控制 猎人** 没有任何击退手段且功能性非常有限。

## 英雄天赋

- 12.0版本为[[talent:123347]]带来了一些天赋和调整性改动，并对[[talent:123348]]英雄天赋树进行了部分重做。[[talent:123348]]和[[talent:123347]]在单体目标伤害方面非常接近。[[talent:123347]]在单体目标上略胜一筹，而[[talent:123348]]则拥有更强的防御能力。在纯范围伤害 团队副本场景下，[[talent:123348]]目前是两者中更强的一个。

:::tabs
:::tab [[talent:123348]]
- [[talent:123348]] 获得了 [[spell:466932]]，因为 [[spell:53351]] 在 12.0 版本中被移除了。
  
  - 就像 [[spell:53351]] 一样，只有当你的目标处于特定生命值阈值时，你才能使用 [[spell:466932]]。
  
  
  
  - 此外，自从 野兽控制 猎人's 获得了 [[spell:343248]] 之后，主要有两种方法可以重置 [[spell:466932]] 的冷却时间。[[talent:117565@AJwA]] 能使你的主要循环法术 [[spell:217200]] 和 [[spell:34026]] 触发 [[spell:343248]]
- [[talent:132888@AJwA]] 允许 [[talent:117584]] 的周期性持续伤害效果施加到被 [[talent:117571@AJwA]] 命中的每个目标身上，并且在点出天赋且命中 2 个或更多敌人时给予你 [[talent:126403]]。
- 你的终极天赋 [[talent:117590@AJwA]]，会给予你一次 [[spell:343248]] 的触发效果，并在施放时额外发射 2 个 [[spell:466932]]。
  
  - 施放 [[spell:19574]] 后，你会获得 [[talent:117590@AJwA]]，持续 10 秒
- 由于 [[talent:117556]] 已在 11.2 版本中被移除，天赋树中现在只剩下一个防御节点。[[talent:123779]] 依然保留。

- [[spell:1264289@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - 使用后有10%的几率召唤一只黑暗猎犬来替代[[spell:120679]]
- [[spell:1264290@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - [[spell:19574]]现在还会召唤一只黑暗猎犬  
    [[spell:19574]]被使用后会转化为[[spell:392060]]
- [[spell:1264291]]
  
  - 在[[talent:117590@AJwA]]弹幕期间火焰2个额外的[[spell:466932]]。
  - [[spell:115939]]和[[spell:378207]]的伤害提高10%。
- [[spell:1264690@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - [[spell:34026]]使你的黑暗猎犬暗影痛击，造成范围伤害伤害。

随着12.0版本更新，暴风雪移除了以下英雄天赋。

- [[spell:467941@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]

:::

:::tab [[talent:123347]]
- 每 30 秒获得 [[talent:117588]]
  
  - 这会召唤三只野兽之一 
    
    - 双足飞龙会为你和你的宠物提供最高 10% 的伤害提升，持续最多 19 秒。
    - 熊会先跃入战场，[[spell:471999]] 最多 8 个附近敌人，然后自动攻击你当前的目标。
    - 野猪会向你的目标冲锋 1 次，对你的主要目标造成大量伤害，对附近敌人造成较少伤害。
  - 消耗 [[talent:117588]] 还会提高你下一个 [[spell:34026]] 的伤害，并使 [[spell:217200]] 的持续时间缩短 6 秒。
- [[talent:126402]] 随着 [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]] 的加入被赋予了更强大的力量。
- 12.0 版本新增改动：[[talent:117559@AJwA]] 已被重做，为宠物提供 2% 的伤害增益，同时使 [[spell:217200]] 的伤害提高 10%。
- [[talent:117564]] 已在 12.0 版本中更新，[[talent:126488]] 现在会召唤一只海龟来协助你，进一步使其伤害减免效果提高 10%。

- [[spell:1264781]]
  
  - 自动射击/自动攻击为你和你的宠物恢复 2 点集中值。自动射击/自动攻击的伤害提高 25%
- [[spell:1264774]]
  
  - 精通 提高 3%。
- [[spell:1264797]]
  
  - Hogstrider 使 [[spell:193455]] 的伤害额外提高 10%，并且现在可以额外叠加 3 次。
- [[spell:1264792]]
  
  - 你的双足飞龙提供的伤害加成现在额外持续 2 秒。
- [[spell:472524]]
  
  - 你的熊的 [[spell:471999]] 伤害提高 15%
- [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - 施放 [[talent:126402]] 会授予 [[talent:117588]]，并使你的下一个 [[spell:34026]] 唤醒附近的野生动物发起兽群奔腾，冲向你的目标，在 7 秒内造成大量物理伤害。
- [[spell:1268705]]
  
  - [[spell:53271]] 的持续时间延长 2 秒，并且使其目标的移动速度提高 20%。

随着12.0版本更新，暴风雪移除了以下英雄天赋。

- [[spell:472539]]
- [[spell:472729]]
  
  - 作者注：该天赋已移至职业天赋树。
- [[spell:472743]]

:::

:::

## 天赋

:::tabs
:::tab [[[talent:123347]]  单体](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>)
:::talents [[talent:123347]] **野兽控制 猎人** 团本中的单体天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### 何时使用该专精

如果你在战斗的大部分时间里都在与单一敌人作战，请使用这套天赋。

### 改变游戏玩法的天赋

探索专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，如需更详细的了解，请查看下方的**循环**和**深度解析**章节。

#### 专精树

- [[spell:267116]]
  
  - 大幅提升单体伤害和范围伤害，因为你召唤宠物时会额外召唤一只副宠物，这只宠物也会施放[[talent:126408]]。
- [[talent:126439]]
  
  - 许多天赋与之相互配合，强化这头野兽使其变得强大。[[talent:132188@FAgA8PvA8h4A]]也因此成为必点节点。
- [[talent:126402@FAQA8h4A]]
  
  - 与[[talent:132188@FAgA8PvA8h4A]]和[[talent:117590@AJwA]]组合用于[[talent:123348]]，与[[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]组合用于[[talent:123347]]是我们唯一的主要伤害爆发技能。

#### 职业树

- [[talent:126470]]
  
  - 大幅提升生存能力，因为你获得一层额外的[[talent:126488]]充能。它与[[spell:388039]]一起将构成你防御能力的大部分。
- [[spell:53480]]
  
  - 为你提供一个外部防御冷却技能，与[[spell:1272094]]构成选择节点，因此点出该天赋的代价是失去3%的被动伤害减免。
- [[spell:459517]]
  
  - 使[[spell:5384]]和[[spell:186265]]能够为你驱散中毒和疾病负面效果。虽然属于情境性天赋，但在需要时对你和你的团队都极为有用。
- [[spell:109248]]、[[spell:19577]]和[[spell:19801]]取决于你所面对的Boss。请根据每场战斗明智地选择所需的天赋。

:::

:::tab [[talent:123348]] [单体](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>)
:::talents [[talent:123348]] **野兽控制 猎人** 团本中的单体天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azsMwAGwMsBZsAAgZMjZWMDzYmxMMzYYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbAYA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azsMwAGwMsBZsAAgZMjZWMDzYmxMMzYYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbAYA"
}
```
:::

### 何时使用该专精

如果你更喜欢玩 [[talent:123348]] 而不是 [[talent:123347]]，请使用这套天赋。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 英雄天赋

**已将** [[talent:123347]] 更改为 [[talent:123348]]，更多信息请访问上方的 **英雄天赋** 部分。

:::

:::tab [[[[talent:123347]]](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>) 视情况的顺劈](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>)
:::talents [[talent:123347]] **野兽控制 猎人** 团本中的视情况顺劈天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### 何时使用该专精

如果你在战斗中需要在短时间内应对 2 个或更多敌人，请使用这套天赋。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 专精树

- **新增**
  
  - [[spell:1264359]]
  - [[spell:115939]]
  - [[spell:378207]]
  - [[spell:459552]]
  - [[spell:378209]] x 2
  - [[talent:126413]]

- **移除**
  
  - [[spell:1265051]]
  - [[spell:385810]] x 2
  - [[spell:459730]]
  - [[spell:1232739]]
  - [[spell:120679]]
  - [[spell:378743]]

:::

:::tab [[talent:123348]] 团队副本 顺劈
:::talents [[talent:123348]] **野兽控制 猎人** 团本中的顺劈天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azsMwAGwMsBZsAAgZGzMziZYGmxMjZmZYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azsMwAGwMsBZsAAgZGzMziZYGmxMjZmZYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbA"
}
```
:::

### 何时使用该专精

如果在战斗中有较长时间需要面对2个或更多敌人，请使用这套专精。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 专精树

- **新增**
  
  - [[spell:1264359]]
  
  
  
  - [[spell:115939]]
  
  
  
  - [[spell:378207]]
  - [[spell:1217524]]

- **移除**
  
  - [[spell:1265051]] x2
  - [[talent:126418]]
  - [[talent:126400]]

#### 英雄天赋

**已将** [[talent:123347]] 更改为 [[talent:123348]]，更多信息请访问上方的 **英雄天赋** 部分。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[talent:126440]] 使你的宠物额外[[spell:201754]]一次，效果为50%。
- **4件套：**[[spell:201754]] 使你的下一个[[spell:193455]]要么以20%的效果受益于[[spell:115939]]，要么对你的主要目标造成15%的额外伤害，最多可叠加4次

### 单体目标

:::tabs
:::tab [[talent:123347]]
### 起手爆发

- 你起手的目标就是尽可能多地施放 [[talent:126408]]。由于集中值管理会成为问题，你也需要穿插一些 [[talent:126440]]。
- 注意，在每次开怪之前，你要确保对优先目标/首领使用 [[spell:257284]]，并对首选坦克 [[spell:34477]]！

:::rotation **野兽控制 猎人** 团本中的单体起手
```json
{
  "source_code": "IcFTHIEcQNAAAcwbuBCc1xGbAIk6ECQABkwFsAwACxFUAAAABwprDEgFAFwXfQQAIEAA9DQOCgVACZHTBUBCAIk6yQDAMAgQqTI"
}
```
1. [[spell:217200]] 开怪时
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:19574]]
5. [[spell:34026]]
6. [[spell:217200]]
7. [[spell:34026]]
:::

- 使用你的主动饰品、[[item:241308]] 以及诸如 [[spell:20572]] 或 [[spell:26297]] 这样的种族技能，然后再使用 [[talent:126402@FAgA8PvA8h4A]]。
- 确保永远不要让 [[talent:126408]] 和 [[talent:126440]] 达到上限，围绕这一点进行规划，并确保每次 [[talent:126408]] 时都拥有 [[spell:1273126]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:19574]]。
2. 如果 [[spell:1273126]] 处于激活状态，则施放 [[talent:126408]]。
3. 施放 [[talent:126440]]。
4. 施放 [[spell:193455]]。

:::

:::tab [[talent:123348]]
### 起手爆发

- 你开局的目标就是在保持[[spell:1273126]]的同时，尽可能多地施放[[talent:117584]]和[[talent:126408]]。
- 请注意，在每次开怪之前，你要确保在优先目标/首领身上使用[[spell:257284]]，并对首选坦克使用[[spell:34477]]！

:::rotation **野兽控制 猎人** 团本中的单体起手
```json
{
  "source_code": "IcZAMxgQy_xBAAwBv5GIwVHbsBgQqTIABEAQCBHUDAAAAMgQcBFAAAQAc6aAOwDAB81HEAACBAQOCgVACZHTBkSGyAg8BkUHQkgQ-ACAYA4ACx3-FAQAp4TMAgi6ECAAAAAACx3-FA"
}
```
1. [[spell:466930]] 开怪时使用
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:19574]]
5. [[spell:34026]]
6. [[spell:466930]]
7. [[spell:34026]]
8. [[spell:217200]]
9. [[spell:34026]]
10. [[spell:466930]]  
    
    1. [[spell:392060]]
    2. [[spell:466930]]
    3. [[spell:34026]]
11. [[spell:34026]]
12. [[spell:392060]]
:::

- 使用你的主动饰品、[[item:241308]] 以及诸如 [[spell:20572]] 或 [[spell:26297]] 这样的种族技能，然后再使用 [[talent:126402@FAgA8PvA8h4A]]。
- 确保永远不要让 [[talent:126408]] 和 [[talent:126440]] 达到上限，围绕这一点进行规划，并确保每次 [[talent:126408]] 时都拥有 [[spell:1273126]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:19574]]。（确保在此之前用掉所有 [[spell:466930]]）
2. 在 [[talent:117590@AJwA]] 窗口期内施放 [[spell:466930]]。
3. 如果 [[spell:1273126]] 处于激活状态，则施放 [[talent:126408]]。
4. 施放 [[spell:392060]]。务必在其超时之前使用。
5. 施放 [[spell:466930]]。
6. 施放 [[talent:126440]]。
7. 施放 [[spell:193455]]。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:123347]]
### 起手爆发

- 请注意，大多数 团队副本 战斗在开怪时都是单目标情况，以下仅适用于存在多个目标的场合。确保在只有一个敌人时使用单目标起手。
- 起手的目标很简单，就是尽可能多地施放 [[talent:126408]]。由于集中值的管理会是个问题，你还需要穿插一些 [[talent:126440]]。
- 注意，在每次开怪前，你要确保对优先目标/首领使用 [[spell:257284]]，并对指定的坦克使用 [[spell:34477]]！

:::rotation **野兽控制 猎人** 团本中的 范围伤害 起手
```json
{
  "source_code": "JcHiLIEcQNAAAcwbuBCc1xGbAI05KNBAAAwACxFUAAAABwprDAQAIA0XfQQAIEAA9DQOCgVACZHTAEQAIIk6EGwBAAQCDBAAmBBAE968CAAAAAgQnr0EAAAAAIk6EC"
}
```
1. [[spell:217200]] 开怪时
2. [[spell:1264359]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
3. [[spell:19574]]
4. [[spell:34026]]
5. [[spell:217200]]
6. [[spell:34026]]
7. [[spell:217200]]
8. [[spell:34026]]
9. [[spell:193455]]
10. [[spell:1264359]]
11. [[spell:34026]]
:::

- 在使用 [[talent:126402]] 之前，先使用你的主动饰品、[[item:241308]]，以及像 [[spell:20572]] 或 [[spell:26297]] 这样的种族技能。
- 确保永远不要让 [[talent:126408]] 和 [[talent:126440]] 达到上限，围绕这一点进行规划，并确保每次 [[talent:126408]] 时都拥有 [[spell:1273126]]。

### 优先级列表

1. 施放 [[spell:19574]]。
2. 施放 [[spell:1264359]].
3. 如果 [[spell:1273126]] 处于激活状态，则施放 [[talent:126408]]。
4. 施放 [[talent:126440]]。
5. 施放 [[spell:193455]]。

:::

:::tab [[talent:123348]]
### 起手爆发

- 注意，大多数 团队副本 战斗在开怪时都是单体目标，以下仅适用于存在多个目标的场景。当只有一个敌人时，请务必使用单体目标开局手法。
- 你开局的目标就是在保持[[spell:1273126]]的同时，尽可能多地施放[[talent:117584]]和[[talent:126408]]。
- 请注意，在每次开怪之前，你要确保在优先目标/首领身上使用[[spell:257284]]，并对首选坦克使用[[spell:34477]]！

:::rotation **野兽控制 猎人** 团本中的 范围伤害 起手
```json
{
  "source_code": "I8aAM5gQy_xBAAwBv5GIwVHbsBgQqTIABEAQCBHUDAAAAMgQcBFAAAQAc6aAOAEAB81HEAACBAQOCgVACduSTUgKEYHTBcQG6Ag8BEVHQkgS-ACAYAIBCx3-FAQAp4TMAERWAoeDLiy5KNBAAAAACx3-FA"
}
```
1. [[spell:466930]] 开怪时
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:1264359]]
5. [[spell:19574]]
6. [[spell:34026]]
7. [[spell:466930]]
8. [[spell:34026]]
9. [[spell:217200]]
10. [[spell:34026]]
11. [[spell:466930]]  
    
    1. [[spell:392060]]
    2. [[spell:466930]]
    3. [[spell:34026]]
    4. [[spell:1264359]]
12. [[spell:34026]]
13. [[spell:1264359]]
14. [[spell:392060]]
:::

- 使用你的主动饰品、[[item:241308]]]，以及像[[spell:20572]]或[[spell:26297]]这样的种族技能，然后再使用[[talent:126402]]。
- 确保永远不要让 [[talent:126408]] 和 [[talent:126440]] 达到上限，围绕这一点进行规划，并确保每次 [[talent:126408]] 时都拥有 [[spell:1273126]]。

### 优先级列表

1. 施放 [[talent:117584]] 如果[[spell:115939]]即将失效，请施放[[talent:132888@AJwA]]以最大化其价值。
2. 施放[[spell:19574]].
3. 施放 [[spell:1264359]].
4. 在 [[talent:117590@AJwA]] 窗口期内施放 [[spell:466930]]。
5. 如果 [[spell:1273126]] 处于激活状态，则施放 [[talent:126408]]。
6. 施放 [[talent:126440]]。
7. 施放 [[spell:466930]]。
8. 施放 [[spell:392060]]。务必在其超时之前使用。
9. 施放 [[spell:193455]]。

:::

:::

## 深度解析

### 在狂野怒火期间最大化你的伤害输出

- 确保在进入 [[spell:19574]] 时至少有 1 层 [[talent:126408]]，最好是有 2 层。
- 确保在此窗口期内穿插使用 [[talent:126440]]，不要让它的层数溢出，以免自己陷入集中值匮乏。
- 尽量将这个伤害爆发窗口与 [[talent:126411]] 提供的任意一个增益效果对齐。这些增益非常强力，[[talent:126402]] 窗口期会因此获得进一步的提升。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **野兽控制 猎人** 在团队副本中的内克扎莉天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### 首领攻略技巧

- 利用 [[talent:135711]]、[[talent:128412@FAQANQzE]] 和 [[talent:126457]]，确保**躁动的阿曼尼**不会到达中间。
- 当你被 [[spell:1287426]] 点名时，务必使用一个减伤技能，并远离团队，在房间边缘附近接受驱散。
- 确保 [[spell:257284]] 一直挂在首领身上。

:::

:::tab 陵寝哨兵
:::talents **野兽控制 猎人** 在团队副本中的陵寝哨兵天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### 首领攻略技巧

- 当你位于有以下目标的一侧时： **乌拉特克之息**，切换攻击目标至**毒液凝块**，在其出现后立即转火。
- 在有以下目标的一侧时，务必分担 [[spell:1288232]]： **乌拉特克之血**.

:::

:::tab 迷失的探险者
:::talents **野兽控制 猎人** 迷失的探险者在团本中的天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### 首领攻略技巧

- 如果你拾取了**恶心的鱼**，务必将它用在一只此前未被鱼影响过的海龟身上。
- 如果你要去承受**商人盖博**[[spell:1291933]]所产生的多个箱子，请开启一个防御技能。
- 打断**书卷贤者伊库**[[spell:1286921]]。
- 如果你是唯一的猎人，只需确保将[[spell:257284]]保持在其中一个首领身上
  
  - 如果有两名或更多猎人，商量好由谁将其保持在哪个首领身上。

:::

:::tab 瓦什尼克
:::talents **野兽控制 猎人** 瓦什尼克在团本中的天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### 首领攻略技巧

- 务必击杀首领刷新的三种小怪： **结块毒液、幽蔽毒液和燃烧剧毒**. 不要让它们到达房间中央非常重要，你可以对所有目标使用 [[talent:128412]] 和 [[talent:135711]]，除了 **结块毒液**。注意不要连续迅速击杀燃烧剧毒小怪，以免 [[spell:1285979]] 的爆炸重叠。
- 当你被 [[spell:1281907]] 施加负面状态时，注意不要打到队友。
- 如果只有你一名 猎人，优先把 [[spell:257284]] 保持在 **凝结的虚空** 这种小怪中团队正在击杀的那只身上，直到两只都被消灭；其他时候则保持在首领身上。
  
  - 如果有两名或更多 猎人，则指定一人始终将其保持在首领身上，另一人将其施加在小怪身上。

:::

:::tab 斯索拉克
:::talents **野兽控制 猎人** 在团队副本中的斯索拉克天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### 首领攻略技巧

- 当你中了[[spell:1285419]]的减益效果且远离团队、无法与其他玩家接触时，可以使用[[spell:781]]以免被吹下平台。
- 当你被[[spell:1305959]]影响时使用防御技能，并将[[spell:1287008]]放置在远离团队的位置。
- 当你点出[[talent:126452]]天赋时，可以使用[[spell:5384]]为自己驱散[[spell:1287072]]。
- 如果你是唯一的猎人，请确保将[[spell:257284]]保持在首领身上。

:::

:::tab 双牙
:::talents **野兽控制 猎人** 双尖牙在团本中的天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMegZmZZmhZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMegZmZZmhZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### 首领攻略技巧

- 去吸收[[spell:1289993]]，但注意不要吸收太多，以免死于[[spell:1290336]]。
- 尽快击杀**维克苏尔之嗣**。
- 吸收[[spell:1290516]]以消除[[spell:1290336]]的层数。
  
  - 如果你们有三名或更多猎人，那么每人各盯住一个目标即可。

:::

:::tab 盘绕祭坛
:::talents **野兽控制 猎人** 团本中的盘绕祭坛天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

吸收 [[spell:1283489]]，之后你可以使用 [[spell:781]] 快速重新站位，但要小心路径上的 [[spell:1282403]]。  
当你点出 [[talent:126452]] 天赋时，可以使用 [[spell:5384]] 解除自己身上的 [[spell:1282287]]。  
打断 [[spell:1286399]] 来自 **怨毒盘卷蛇** 并击杀他们。  
小心躲避正在锁定你的 **恐惧具象** 它们正在锁定你。   
拾取你的 **灵魂碎片** ，以在被 [[spell:1310882]] 击中后消除 [[spell:1286837]]。

:::

:::tab 乌拉特克
:::talents **野兽控制 猎人** 乌拉特克 团队副本天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### 首领攻略技巧

- 由于这个首领尚未经过测试，相关技巧将在竞速首杀（RWF）之后补充。

:::

:::tab 尼姆瑞莎·唤波者
:::talents **野兽控制 猎人** 尼姆瑞莎·唤波者 团队副本天赋
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

击杀从场地边缘刷新的鱼人小怪。你可以使用 [[talent:128412]]、[[talent:135711]] 和 [[talent:126457]] 来确保它们无法到达场地中央。

:::

:::

## 属性优先级

了解你的次要属性优先级以及 团队副本 首领战斗中获得最佳表现所需的额外属性（作为 **野兽控制 猎人**）。欲了解更多详细信息，请访问 **[属性与词条](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **野兽控制 猎人** 团队副本 中的属性优先级
```json
{
  "source_code": "IoAJFMQMgQCKEEgAEA"
}
```
**敏捷 ≫ 精通 ＞ 暴击 ＝ 急速 ≫ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 出色的属性，可以减少"**范围伤害**"技能所受到的伤害。
- **吸血** - 通过造成伤害来提供额外的治疗。你的宠物所造成的伤害不会为你回血，因此**吸血** 对你来说是一个很糟糕的第三属性，因为你的大部分伤害都来自宠物。
- **加速** - 一个小众的第三属性，可能非常有用，并且过去已被证明其实用价值。它能让处理某些机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
在 12.1 版本中，当你使用催化转化一件装备时，它会保留原有的属性和附加效果，这意味着你的套装栏位可以拥有完美的属性。在你攒够  [[item:274707]]  层数以催化转化属性更好的装备之前，你应该继续使用从套装代币获得的套装部件。

|  |  | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271492@DiSAA0PAnk7cVrjNycBN8Vjg1YbNOFA]] | 双子毒牙 / 催化 |
| 项链 | [[item:268265@BESAA0PAE06QQrjNycBNkVDj1gVA]] | 乌拉特克 |
| 肩部 | [[item:271490@DASAA0PAXk7YjMXQjf1EYNYF]] | 迷失的探险者 / 催化 |
| 披风 | [[item:268253@BARAA0PAeVDG2gVA]] | 盘卷祭坛 |
| 胸部 | [[item:271876@DASAA0PAJk74VNMWDG2kjAYF]] | 乌拉特克 |
| 腕部 | [[item:244584@FCVAA0PAno6gBwDBtOZJCAjcbN2-CYwsXM2UzY1YbNRDzSB]] | 制造装备 |
| 手套 | [[item:271493@BASAA0PA2IzF0sXNBWjTBA]] | 陵寝哨兵 / 催化 |
| 腰带 | [[item:244581@FiQAA0PAYA8ciqjAtO3WzSB]] | 制造装备 |
| 腿部 | [[item:271491@DASAA0PAhu7YjMXQTf1IYNYF]] | 斯索拉克 / 催化 |
| 脚部 | [[item:268233@DARAA0PAxj7YjMXQjTB]] | 斯索拉克 |
| 戒指 1 | [[item:249920@DkQAA0PA3j7IQrjAtOCKQIB]] | 万毒邪祟者瓦什尼克 |
| 戒指 2 | [[item:252258@DCSAA0PA1j7QQrjNy4VNkVTOC4UA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:270175@BgQAA0PA5IAWBA]] | 乌拉特克 |
| 饰品 2 | [[item:270164@BgQAA0PA5IgTBA]] | 失落的探险者 |
| 武器 | [[item:268207@DgRAA0PAFk7YjMXQDj1gVA]] | 乌拉特克 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251220@BgQAA0PACKQQBA]] | 虚空之痕竞技场 |
| 项链 | [[item:251142@AgQAAIoABFA]] | 密谋小径 |
| 肩部 | [[item:239049@AgQAAIoABFA]] | 诸王之眠 |
| 披风 | [[item:251190@AgQAAIoABFA]] | 夺目谷 |
| 胸部 | [[item:273789@BgQAA0PACKQQBA]] | 毒牙祭坛 |
| 护腕 | [[item:251200@BgQAA0PACKQQBA]] | 夺目谷 |
| 手套 | [[item:160213@BgQAA0PACKQQBA]] | 诸王之眠 |
| 腰带 | [[item:251228@BgQAA0PACKQQBA]] | 虚空之痕竞技场 |
| 腿部 | [[item:159375@BgQAA0PACKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:159388@BgQAA0PACKQQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:252258@BgQAA0PACKQQBA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:273792@BgQAA0PACKQQBA]] | 毒牙祭坛 |
| 饰品 1 | [[item:273796@BgQAA0PACKQQBA]] | 毒牙祭坛 |
| 饰品 2 | [[item:250228@BgQAA0PACKQQBA]] | 密谋小径 |
| 武器 | [[item:273784@BgQAA0PACKQQBA]] | 毒牙祭坛 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。请注意，根据不同的首领战，某些饰品会比其他饰品表现更好。

| 等级 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgQAA0PA5IAWBA]]  <br>[[item:270164@BgQAA0PA5IgTBA]]  <br>[[item:270173@BgQAA0PA5IgTBA]] |
| **A级** | [[item:270165@BgQAA8PACKgTBA]]  <br>[[item:273796@BgQAA8PACKgTBA]]  <br>[[item:250215@BgQAA8PACKgTBA]]  <br>[[item:159617@BgQAA8PACKgTBA]] |
| **B级** | [[item:246304@BgQAA8PAi8SHBA]] *-- 占用一个美化部位*   <br>[[item:273797@BgQAA8PACKgTBA]]  <br>[[item:250228@BgQAA8PACKgTBA]]  <br>[[item:193757@BgQAA8PACKgTBA]] *--* *记得在需要时将其升级*  <br>[[item:270166@BgQAA8PACKgTBA]]  <br>[[item:274493@BgQAA8PACKQQBA]] -- 最高只能升到英雄品质 |
| C级 | [[item:251787@BAQAA8PAUEA]] *-- 效果结束后会使你恐惧，记得提前告知治疗你需要驱散*  <br>[[item:250225@BgQAA8PACKgTBA]]  <br>[[item:248583@BgQAA8PACKAFBA]] *-- 最高只能升到英雄品质*  <br>[[item:251783@BAQAA8PAUEA]] *-- 最高只能升到英雄品质*  <br>[[item:251792@BAQAA8PAUEA]] *-- 最高只能升到英雄品质*  <br>[[item:265657@BgQAA8PACKAFBA]] *-- 最高只能升到英雄品质*  <br>[[item:246307@BgQAA8PAi8SHBA]] *-- 占用一个美化部位*   <br>[[item:250214@BgQAA8PACKgTBA]] *-- 需要站在光束中才能获得最大收益*  <br>[[item:270168@BgQAA8PACKAWBA]] -- 在特定情况下可用于爆发性大额伤害 |
| 废品级 | [[item:250259@BgQAA8PACKgTBA]]  <br>[[item:274496@BgQAA8PACKQQBA]]  <br>[[item:274497@BgQAA8PACKQQBA]]  <br>[[item:158374@BgQAA8PACKgTBA]]  <br>[[item:246306@BgQAA8PAi8SHBA]] *-- 占用一个美化部位*   <br>[[item:246305@BgQAA8PAi8SHBA]] *-- 占用一个美化部位*   <br>[[item:241340@BgQAA8PAi8SHBA]]  <br>[[item:251782@BAwAA8PAUEQBAEgNXIA]] *-- 最高只能升到英雄品质*  <br>[[item:251785@BAQAA8PAUEA]] *-- 最高只能升到英雄品质*  <br>[[item:251784@BAQAA8PAUEA]] *-- 最高只能升到英雄品质*  <br>[[item:251790@BAQAA8PAUEA]] *-- 最高只能升到英雄品质*  <br>[[item:252957@BgQAA8PACKAFBA]] *-- 最高只能升到英雄品质* |

### 美化饰品

- [[item:240167]]
  
  - 最理想的制造部位是**护腕**、**披风**、**靴子**或**腰带**，具体取决于你现有的装备。
  - 在开荒初期，甚至有时将它制造在头盔/胸甲这类高价值属性部位上也很有价值。
- [[spell:1230076]] 在开荒早期可能非常有价值。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **合剂**
  
  - [[item:245933]] *-- 输出最大化。*
  
  
  
  - [[item:245926]] *-- 输出略低但生存能力更强。*
- **食物**
  
  - [[item:242272]]
  
  
  
  - [[item:255845]]
- **武器油**
  
  - [[item:243734]] *-- 默认选择*
  
  
  
  - [[item:243738]]
- **战斗药水**
  
  - [[item:241308]] *-- 默认选择*
  - [[item:241288]] -- 视情况而定，如果觉得差距不大请跑模拟
- 治疗药水
  
  - [[item:271884]] -- 一波大量治疗
- 强化符文
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240983]] -- 唯一
  
  
  
  - 如果你缺少精通，就多插这种宝石。
    
    - [[item:240896]]
  
  
  
  - 否则就混搭使用这些宝石。
    
    - [[item:240892]]
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240918]]

### 附魔

:::columns
:::column
:::columns
:::column
| 头部 | [[item:275707]]  <br>[[item:244007@DAAAA0PAZbAB]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAA0P]] |
| 胸部 | [[item:243977@BAAAA0P]] |
| 护腕 | [[item:275707]] |
| 腰部 | [[item:275707]] |
| 腿部 | [[item:244641@BAAAA0P]] |
| 脚部 | [[item:243953@BAAAA0P]] |
| 戒指1 | [[item:243957@BAAAA0P]] |
| 戒指2 | [[item:243957@BAAAA0P]] |
| 武器 | [[item:243973@BAAAA0P]] |

:::

:::

:::

:::column
:::gear **野兽控制 猎人** 团本中的附魔
```json
{
  "source_code": "IQFZ9DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NABK1j7AAAAAAEQB5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买[[item:275707]]，为你的**头盔**、**护腕**和**腰带**添加插槽。

## 种族

如果你追求**野兽控制 猎人** 在团本中的极致优化，不同的种族特性可以为你的人物带来巨大的收益。如果这不是你的首要目标，选择一个符合你风格的种族同样完全可行。

- [[spell:65116]] -- 矮人
  
  - 驱散魔法和流血负面效果。过去在一些有流血机制的首领战中很有用。
- [[spell:69070]] -- 地精
  
  - 朝角色面朝的方向进行一次小跳跃。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:26297]] *-- 巨魔* 
  
  - 强力的输出种族技能
  - 使移动限制效果的持续时间缩短20%。在最近的开荒团队副本历史中只派上过一次用场，但仍有其价值。
- [[spell:33702]] *-- 兽人* 
  
  - 强力的伤害种族技能，因为 [[spell:21563]] 和 [[spell:33702]] 都能与 [[talent:126397]] 相配合。
  - 使你受到的眩晕持续时间缩短20%，在某些情况下很有用。
- [[spell:256948]] -- 虚空精灵
  
  - 朝面朝方向释放一道虚空裂隙，再次激活即可传送到该位置。
  - 最大距离为100码。
- [[spell:274738]] -- 玛格汉兽人
  
  - 强力的伤害种族技能，与 [[talent:126397]] 或每隔一次 [[spell:321530]] 配合良好。

### 推荐

总体而言，可以肯定地说，如果你在意将输出（DPS）最大化到极致，就应该选择输出最高的种族技能，对 猎人 而言就是 熊猫人、机械侏儒（效果随战斗时间提升，需要时间才能达到最大效果）以及 兽人。话虽如此，如果是团队副本开荒，情况就有些不同了。某些种族能极大地加快特定首领的开荒进度。值得注意的是，矮人 凭借他们的 [[spell:65116]]，在最近一次世界首杀竞速赛中，通过在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 这两场战斗的关键时刻轻松自我驱散，提供了巨大帮助。

## 宏

了解**野兽控制 猎人**在团队副本战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
[[talent:135711]]**[[talent:126449]]** -- *无需确认，直接对光标位置施放[[talent:135711]]。*

```wow-macro
#showtooltip
/cast [@cursor] 束缚射击
```

**[[talent:126457]]** - *无需 [[talent:126457]]确认，直接在鼠标指针位置使用 。*

```wow-macro
#showtooltip 焦油陷阱
/cast [@cursor] 焦油陷阱
```

:::

:::details 鼠标指向宏
**[[spell:217200]]** -- *对鼠标悬停目标或当前目标施放 [[talent:126440]]。*

```wow-macro
#showtooltip
/cast [@mouseover] 倒刺射击
```

**[[spell:19801]]t]** -- *对鼠标悬停目标施放[[spell:19801]]。*

```wow-macro
#showtooltip
/cast [@mouseover] 宁神射击
```

**[[talent:126471]]** -- *对鼠标悬停目标施放 [[talent:126471]]* 。

```wow-macro
#showtooltip
/cast [@mouseover] 震荡射击
```

:::

:::details 宠物宏
> 我们主要使用自定义宏来控制宠物，因为宠物自己施放技能不够可靠，由你手动控制可以提升DPS。

**[[talent:126408]]** **pet attack** -- *对你的目标施放[[talent:126408]]以及你宠物的基础攻击。*

```wow-macro
#showtooltip 杀戮命令
/petattack
/cast 杀戮命令
/cast [@pettarget]爪击
/cast [@pettarget]撕咬
/cast [@pettarget]拍击
```

**[[spell:1264359]]** **宠物攻击** -- *对目标施放[[spell:1264359]]* *以及宠物的基础攻击。*

```wow-macro
#showtooltip 狂野鞭笞
/petattack
/cast 狂野鞭笞
/cast [@pettarget]爪击
/cast [@pettarget]撕咬
/cast [@pettarget]拍击
```

**[[talent:126440]]** **pet attack** *-- 对你的目标施放[[talent:126440]]* *以及你宠物的基础攻击。*

```wow-macro
#showtooltip 倒刺射击
/petattack
/cast 倒刺射击
/cast [@pettarget]爪击
/cast [@pettarget]撕咬
/cast [@pettarget]拍击
```

**[[spell:193455]]** **pet attack** -- *施放[[spell:193455]]* *以及你宠物的基础攻击，目标是你的当前目标。*

```wow-macro
#showtooltip 眼镜蛇射击
/cast 眼镜蛇射击
/cast [@pettarget]爪击
/cast [@pettarget]撕咬
/cast [@pettarget]拍击
```

:::

:::details 实用 宏
**[[talent:126352]]焦点** -- *对你的焦点目标施放[[talent:126352]]，如果焦点目标不存在则对当前目标施放。*

```wow-macro
#showtooltip 反制射击
/cast [@focus,exists,harm,nodead][] 反制射击
```

**[[spell:186265]]** cancelaura -- *施放[[spell:186265]]，并且再次按下时可以立即取消该效果。*

```wow-macro
#showtooltip
/cast 灵龟守护
/cancelaura 灵龟守护
```

:::

:::

## 插件

下方是作者为其 **野兽控制 猎人** 所使用的用户界面截图，其中说明了使用了哪些插件，以及在团队副本中如何运用这些插件来让你的操作更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/Maxroll-2-1024x618.jpg>)

**野兽控制 猎人** 在团队副本中的界面设置

:::accordion
:::details 插件
- **RaidframeSettings** -- 小队/团队框架增强
  
  - 为默认的小队和团队框架添加额外自定义选项。
- **Unhalted Unit Frames *-- 界面替换*** 
  
  - **添加自定义的玩家、目标和首领框架，并提供更多自定义选项。**
- **BetterCooldownManager** -- 冷却管理器增强
  
  - 为你的冷却管理器添加额外自定义选项，同时还提供资源等附加信息。
- **BigWigs *-- 通用首领模块***  
  
  - **BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件专为特定 团队副本 战斗触发警报信息、计时条、音效等而设计。**
- **Plater**  -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有海量设置选项，开箱即用的负面效果监控、仇恨着色，并支持自定义脚本。
- **Details** -- 深度伤害统计
  
  - 最强大、最可靠、最漂亮的伤害统计插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 猎人
  
  - 英雄天赋
    
    - **[[talent:123348]]**
      
      - **阴郁箭矢的伤害提高300%。**
      
      
      
      - **凋零射击的 黑蚀箭 伤害降低40%。**
      - **修复了 凋零射击 未能正确提高 凋零射击 伤害的问题。**
  
  
  
  - **野兽控制** ***开发者说明：野兽控制 猎人在 狂野怒火 伤害窗口之外的输出略显疲软，因此我们通过增强 杀戮命令、眼镜蛇射击 和 倒刺射击 来提升他们的平稳期伤害。我们将 野兽顺劈 的持续时间延长至10秒，因此在群体伤害场合下，只要你可用时使用 狂野鞭笞，就应该能够保持100%的覆盖率。***
    
    - **群体之心更名为锋利异常，并已重新设计——使你的宠物的 撕咬、爪击 和 拍击 伤害提高100%。**
    - **穿刺之牙已重新设计——杀戮命令 的爆击伤害提高15%。**
    - **血腥狂乱 已更新——现在使 倒刺射击 的周期性频率提升降低33%（原为50%）。**
    - **杀戮顺劈 已更新——杀戮命令 现在在 野兽顺劈 期间只会对附近敌人造成20%的伤害（原为40%）。**
    - **自动射击伤害提高720%。**
    - **倒刺射击 伤害提高10%。**
    - **杀戮命令 伤害提高20%。**
    - **眼镜蛇射击 伤害提高25%。**
    - **野兽顺劈 现在使你的宠物对附近敌人造成所受伤害55%的打击（原为40%）。**
    - **野兽顺劈 持续时间延长至10秒（原为8秒），且不再可被取消。**
    - **蛇形打击现在使 眼镜蛇射击 的爆击伤害提高20%（原为50%）。**
    - **眼镜蛇直觉现在使 眼镜蛇射击 的伤害提高10%（原为35%）。**
    - **凶暴野兽 的召唤物现在可以在冷却管理器中被追踪。**
    - **野性本能已被移除。**
    - **英雄天赋：**
      
      - **[[talent:123348]]**
        
        - **暗影猎犬的召唤物现在可以在冷却管理器中被追踪。**
      - **[[talent:123347]]**
        
        - **猪鸦骑士现在使你的下一次 眼镜蛇射击 伤害提高100%（原为200%）。**
        - **铁蹄利刃 现在使猪鸦骑士提供的 眼镜蛇射击 额外伤害提高25%（原为50%）。**

:::

:::details 补丁12.0.1
- 猎人
  
  - 英雄天赋
    
    - **[[talent:123348]]**
      
      - 暗影 现在造成 暗影 伤害，但其伤害降低了 30%。
      - 枯萎箭袋 现在使 野兽顺劈 和 杀戮顺劈 的效果提高 5%（原为 10%）。
    - **[[talent:123347]]**
      
      - 野猪的范围伤害提高了 200%。
      - 群体意识现在使 倒刺射击 的冷却时间缩短 4 秒（原为 6 秒），并使 杀戮命令 的伤害提高 25%（原为 50%）。
    - 野兽控制
      
      - 猎人及其宠物造成的所有伤害降低了 12%。
      - 顶点天赋：自然之盟现在使 眼镜蛇射击 和 倒刺射击 的伤害提高 15%（原为 30%）。

:::

:::

:::accordion
:::details 补丁12.0
- 猎人
  
  - 英雄天赋
    
    - **[[talent:123348]]**
      
      - 新天赋：唤尸者——召唤凶暴野兽时，有10%的几率转而召唤一只暗影猎犬。
      - 新天赋：哀嚎死者——狂野怒火召唤一只暗影猎犬。在施放野兽狂怒后的15秒内，狂野怒火会被替换为哀恸箭。  
        哀恸箭：射出一支火焰的箭矢，对你的目标造成暗影伤害，并对目标8码范围内的所有敌人额外造成暗影伤害。被哀恸箭击中的非玩家目标施法会被打断，并沉默1秒。授予夺命打击。
      - 新天赋：枯萎箭袋——在凋零射击的弹幕期间额外射出2支黑箭。野兽顺劈和杀戮顺劈的伤害提高10%。
      - 新天赋：空洞契约——杀戮命令会使你的暗影猎犬对附近最多8个敌人暗影拍打，造成中等的暗影伤害。
      - 黑蚀箭已更新——周期性伤害大幅提高，且不再是滚动周期效果。
      - 饮魂者已更新——现在使杀戮命令和倒刺射击有几率授予夺命打击。现在使瞄准射击和急速火焰有更高的几率授予夺命打击。
      - 荒凉箭矢已更新——不再有几率授予夺命打击。现在使自动射击的伤害提高100%。
      - 女妖之印已更新——现在使黯然火药和黑蚀箭的爆击伤害提高10%。
      - 丧钟已更新——现在使宠物伤害提高6%，凶暴野兽伤害提高10%。
      - 洞察之眼已更新——现在使黑蚀箭对受到黑蚀箭周期性伤害影响的敌人造成20%的额外伤害。
      - 凋零射击已更新——现在由狂野怒火激活，不再周期性地授予夺命打击。持续时间缩短至10秒。
      - 黑蚀箭现在授予黑蚀箭技能，且不再替换夺命射击。
      - 以下天赋已被移除：
        
        - 幻痛
    - **[[talent:123347]]**
      
      - 新天赋：致命倒钩——你的自动射击/自动攻击为你和你的宠物恢复2点集中值。自动射击/自动攻击伤害提高25%。
      - 新天赋：尖锐獠牙——你的精通提高3%。
      - 新天赋：铁蹄利刃——野猪骑士额外使眼镜蛇射击的伤害提高10%，且现在最多可额外叠加3次。
      - 新天赋：双足飞龙之视——你的双足飞龙的伤害加成现在额外持续2秒。
      - 新天赋：锋利兽爪——你的熊的撕裂肉体伤害提高15%。
      - 新天赋：奔踏！——施放狂野怒火会授予猎群领袖之嚎，并使你的下一次杀戮命令唤醒附近的野生动物发起兽群冲锋，冲向你的目标并在7秒内造成大量物理伤害。
      - 新天赋：娴熟召唤——主人的召唤的持续时间延长2秒，并使其目标的移动速度提高20%。
      - 兽群意识已更新——倒刺射击的冷却时间缩短量降低至6秒（原为10秒）。
      - 野猪骑士已更新——现在无论你的野猪击中多少个目标，眼镜蛇射击的伤害提高200%。野猪击中的目标数量现在会增加眼镜蛇射击额外击中的目标数量。
      - 熊狂怒已更新——当你的熊被召唤时，会有2只凶暴野兽加入。
      - 绝不留情已更新——你的流血效果造成的伤害提高10%。
      - 龟壳庇护已更新——优胜劣汰现在会召唤一只海龟来协助你，并使其伤害减免效果额外提高10%。
      - 猎群领袖之嚎已更新——野猪现在每次召唤只冲锋一次（原为3次）。野猪冲锋的主目标和次要目标伤害提高300%。
      - 熊的基础伤害和属性加成降低40%。
      - 双足飞龙之吼在施放时不再获得额外初始层数（原为15层起始层数）。
      - 双足飞龙之吼现在最多叠加10层（原为25层）。
      - 双足飞龙之吼的持续时间缩短至12秒（原为15秒）。
      - 强强联手已更新——现在使宠物伤害提高2%（原为5%），倒刺射击伤害提高10%（原为20%）。
      - 双足飞龙的狂怒持续时间延长量降低至0.5秒，延长上限降低至5秒。
      - 以下天赋已被移除：
        
        - 淬毒之牙
        - 缰绳束缚（移至职业天赋树）
        - 身先士卒
    - 职业
      
      - 新天赋：精准打击——自动攻击和自动射击的伤害提高25%。
      - 新天赋：时机降临——当一个陷阱触发时，获得30%的移动速度，持续3秒。
      - 新天赋：龟壳屏障——在灵龟守护期间受到的伤害额外降低20%。
      - 新天赋：寒冷双足——当你的冰冻陷阱被打破时，受害者的移动速度降低70%，持续4秒。
      - 新天赋：战斗经验——敏捷提高3%。
      - 新天赋：强化诱捕——摔绊的减速效果额外提高25%。震荡射击的减速效果额外提高10%。
      - 新天赋：缰绳束缚——当敌人被束缚射击击晕时，会被拖拽到束缚射击的中心。
      - 新天赋：牺牲咆哮——命令你的宠物保护一名友方目标，使其受到的伤害降低15%，但该目标受到的所有伤害的50%会转移给你的宠物。持续10秒，或直到你的宠物生命值降至25%以下。
      - 新天赋：守护者之皮——你的宠物会始终保护你，使你受到的伤害降低3%。你的宠物会承受其减免伤害的100%。
      - 猎人印记已更新——现在使目标受到的伤害提高3%（原为生命值高于80%时提高5%）。
      - 巨熊之韧已更新——现在为被动效果。使你受到的所有伤害降低3%。
      - 孤独幸存者已更新——现在使优胜劣汰的持续时间延长2秒（原为4秒）。
    - 野兽控制
      
      - 新天赋：野兽之心——使狂野怒火的冷却时间缩短60秒。
      - 新天赋：狂野鞭笞——命令你的宠物对10码范围内的所有敌人进行拍打，对他们造成物理伤害。如果狂野鞭笞击中2个或更多敌人，伤害提高300%。对超过8个目标造成的伤害降低。
      - 新天赋：狂乱——宠物攻击速度提高20%/40%。
      - 新天赋：锯齿伤口——你和你的宠物造成的所有流血伤害提高10%。
      - 新天赋：兽群之心——召唤凶暴野兽会授予0.5%的急速，持续8秒。
      - 孤独伴侣回归——你的宠物伤害提高35%，宠物的体型增大10%。
      - 狩猎刺激已被重新设计——倒刺射击爆击几率提高5%/10%。眼镜蛇射击爆击几率提高15%/30%。
      - 训练专家已被重新设计——现在使宠物伤害提高3%/6%。
      - 残暴伙伴已被重新设计——倒刺射击有25%的几率使你的宠物使用其特殊攻击并造成50%的额外伤害。
      - 雷霆之蹄已被重新设计——践踏伤害提高30%。狂野怒火命令所有活跃的宠物以200%的效果践踏。
      - 蛇形打击已被重新设计——现在额外使眼镜蛇射击在爆击时返还10点集中值。
      - 血腥狂乱已被重新设计——当你使用血溅十方时，你的倒刺射击持续伤害在12秒内加快100%。
      - 野性本能已被重新设计——每当你的主宠物（仅限主宠物）使用践踏时，你会向一个未受到倒刺射击影响的目标免费射出一支倒刺射击。该倒刺射击无法触发另一次践踏。
      - 兽群战术已被重新设计——倒刺射击现在立即授予25点集中值。被动集中值恢复提高75%。
      - 倒刺射击已更新——倒刺射击的流血效果现在为滚动周期效果。伤害降低20%。
      - 凶猛狂暴已更新——现在使凶暴野兽的伤害提高10%/20%（原为30%/60%）。
      - 战争号令已更新——现在使杀戮命令的冷却时间缩短3秒。
      - 践踏已更新——不再对其主目标造成单独的伤害事件。伤害提高200%。
      - 血溅十方已更新——狂野怒火激发你的宠物撕裂你的目标，使目标在12秒内持续流血，受到大量伤害。
      - 狩猎大师的召唤已更新——芬雷尔的暴食跳跃伤害降低50%。
      - 杀戮命令伤害提高2%。
      - 杀戮顺劈的杀戮命令伤害降低至40%（原为80%）。
      - 野兽顺劈现在在你使用狂野鞭笞时激活，而不再由多重射击触发。
      - 野兽顺劈持续时间延长至8秒（原为6秒）。
      - 野兽顺劈宠物近战攻击伤害降低至40%（原为80%）。
      - 狂野怒火初始伤害大幅提高，现在使玩家和宠物的伤害提高20%（原为30%）。
      - 撕咬伤害提高50%。
      - 爪击伤害提高50%。
      - 拍击伤害提高50%。
      - 血之气息不再是2点天赋。
      - 初始构建已更新。
    - 许多天赋在天赋树中的位置发生了变化。
    - 以下天赋已被移除：
      
      - 倒刺狂怒
      - 猎人之猎物
      - 多重射击
      - 毒化倒刺
      - 蛇形节奏
      - 野性呼唤

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我的[[spell:115939]]覆盖率偏低？
答：请确保不要施放过多的[[spell:193455]]而过度消耗集中值，合理管理集中值非常重要，这样才能让[[spell:1264359]]在冷却完毕后立即使用。

:::

:::

---

### 致谢

作者：**Charmie**

审校：**Rycn**

---

:::changelog 更新记录
**2026-08-07** 已更新至12.1版本。

**2026-06-17** 已更新至12.0.7版本。

**2026-04-26** 已更新至12.0.5版本。

**2026-02-22** 已更新至12.0.1版本。

**2026-01-18** 已更新至至暗之夜 12.0

**2025-12-01** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-08-03** 已更新至11.2版本

**2025-06-16** 已更新至11.1.7版本

**2025-04-21** 已更新至11.1.5版本

**2025-02-26** 已更新至11.1版本

**2024-12-17** 已更新至11.0.7版本

**2024-11-25** 已针对某些首领更新了单体目标天赋。

**2024-10-21** 已更新至11.0.5版本

**2024-08-17** 已更新至11.0.2版本。

**2024-07-24** 本攻略撰写于11.0.1前置补丁期间。



:::
