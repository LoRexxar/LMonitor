欢迎来到《魔兽世界》12.1版本**狂怒 战士** 团队副本攻略！本攻略涵盖了解你的角色所需的一切内容！如果你是刚起步、从80级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体目标** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 4/5 · 强

机动性 · 4/5 · 强



:::

:::

:::column
:::gear **狂怒 战士** 大秘境最佳配装（BiS）
```json
{
  "source_code": "JYtAwbESAc__BEAYkQggoQAAvj7AH16A8Vjg1YbN2IjgCU8FEEQ6XQAApAAAU06AC06AMWDZ1ghNeVjgCEgXkQgAgAAA1k7A-VTg1EgLgGwYkQgAgUAAJk7A6Vjg1ghNCKAWB47FEEw4XQAggEAA8z6AYYjX1YbNBgBCBYgJFAEEju7AWYTAXAjgCEA5XQAAYAAA2IjXB4AoKE6AAiUAAwQrDY7LjVT0wwgN3Wjt1ccNAMSWisUABEGJEAAIBAwe1EYBrSkTBEgYZPgggEAA1j7A8z6AkVTCHBiTBEQ2XQgggAgOYAAHB81HEAAGCAQC7xRBAEwVXIQAdFAFAAQDUQQAdHwjAEQDOADWBEQtXQgAYAAAFk7AJUDGBgRoDIAOBEQE8Y7LMYzt1sZJLXDAjklILFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271456]] | [[item:240967]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240898]] |
| 肩部 | [[item:271454]] | [[item:244021]] |
| 胸部 | [[item:271459]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240892]] |
| 腿部 | [[item:271878]] | [[item:244643]] |
| 脚部 | [[item:268260]] |  |
| 腕部 | [[item:237834]] | [[item:240908]] |
| 手部 | [[item:271457]] |  |
| 戒指一 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:243973]] |
| 副手 | [[item:237848]] | [[item:243973]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为一名 **狂怒 战士**，你可以使用狂暴肆虐，使[[talent:112277]]伤害提高10%，并使你的[[talent:112277]]触发[[spell:1269349]]，使你的力量提高3%，持续8秒。

**等级2** 使你在[[talent:112281]]期间[[talent:112277]]的怒气消耗降低，并进一步提高[[talent:112277]]的伤害。

**第3级**使你的[[talent:112281]]持续时间延长50%，并且[[talent:112281]]会给予3层[[spell:1269349]]

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-fury-mxr.webp>)

狂暴肆虐

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:136452]]
    
    - [[spell:190411]]和[[talent:112205@FAQAadhA]]在此天赋下若命中至少3个目标，将造成显著提高的伤害。
  
  
  
  - [[talent:136449]]
    
    - 通过[[talent:112265]]的重置，为你的自动攻击提供巨额伤害加成。与[[talent:112255]]配合良好。
  
  
  
  - [[talent:136451]]
    
    - 狂怒战士现在还可以使用[[talent:136451]]，由[[spell:5308]]触发。
- **职业天赋树**
  
  - [[talent:134031@AJQABA]]
    
    - 如果你经常承受大型伤害并善加利用你的[[talent:114644]]，该天赋可提供巨额的生存能力提升。
    - 该天赋的进攻部分仅提供极小的伤害提升，因此与其他选择相比，选取该天赋往往是一种伤害损失。
  - [[talent:136627]]
    
    - 现在还会使12码（或24码）范围内盟友的移动速度提高30%，持续4秒！
  - [[talent:134033]]
    
    - 改进你所有的呐喊技能。
- **已移除**
  
  - [[spell:384318]]
  
  
  
  - [[spell:383762]]

## 英雄天赋

- [[talent:123390]]在单体目标伤害方面领先，而[[talent:123392]]在大多数范围伤害情况下更胜一筹。[[talent:123390]]在单体目标上的领先幅度远大于[[talent:123392]]在范围伤害上的领先幅度，因此推荐将[[talent:123390]]作为所有战斗的默认配置。



### [[talent:123390]]

- [[talent:117411]]
  
  - [[spell:445579]]造成大量伤害并给予[[spell:445584]]增益效果。
- [[talent:117407]]
  
  - [[talent:112314]]会施加[[spell:445836]]。
  - [[spell:445836]]也可以由[[talent:117417]]和[[talent:117406@AJQA]]施加。
- [[talent:117385]]
  
  - 每第三次[[spell:445579]]会触发一次[[talent:112300]]。这个来自[[talent:117385]]的[[talent:112300]]并不需要你已选择天赋[[talent:112300]]。
- [[talent:117392]]
  
  - 加速效果可用于追赶移动中的目标，而解除移动限制效果偶尔也非常强大。
- [[talent:117417]]
  
  - 消耗[[talent:112126@AJQA]]会减少[[talent:112314@AJQA]]的冷却时间，减少量取决于你拥有的[[spell:445584]]层数。

#### 12.0 至暗之夜 新增内容

- [[talent:136076]]
  
  - [[talent:112314@AJQA]] 会给予你一个急速增益。
- [[talent:136075]]
  
  - 延长 [[spell:445584]] 的持续时间。
- [[talent:136074@AJQA]]
  
  - 在《地心之战》中 [[talent:136074@AJQA]] 位于职业天赋树中，但现在它是英雄天赋。




### [[talent:123392]]

- [[talent:117400]]
  
  - 你的 [[talent:117400]] 造成你伤害中的很大一部分，并有几率触发 [[talent:117404]]。
- [[talent:117404]]
  
  - [[talent:117400]] 有较低几率获得一个强大的 [[talent:112261]] 增益，并暂时移除该技能的冷却时间。
- [[talent:117413]]
  
  - 有了这个特质，[[talent:112205]] 相比 [[spell:190411]] 是施加 [[talent:112298]] 并开启顺劈斩的更强大的手段。
- [[talent:117382]]
  
  - 将你的 [[talent:112205]] 转化为 [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]]，造成无视护甲的风暴打击伤害。
  - 有几率由 [[talent:112261]] 触发。
- [[talent:117402]]
  
  - 一种获得 [[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]] 的可靠方式。

#### 12.0 至暗之夜 新增内容

- [[talent:136070@AJQABA]]
  
  - [[talent:112205@FAwAadhAjnqBEMA]] 和 [[spell:435222]] 在 [[talent:112285@AJQABA]] 期间得到显著增强。
- [[talent:136069]]
  
  - 对 [[talent:117400]] 伤害的小幅增强。
- [[talent:136068]]
  
  - 你可以通过使用 [[spell:435222]] 来延长 [[talent:112285@AJQABA]]。通过优先使用 [[spell:435222]]，你可以让 [[talent:112285@AJQABA]] 在大部分时间内保持激活。





## 天赋



### [[talent:123389]] 完整单体

:::talents [[talent:123390]] **狂怒 战士** 团队单体天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM"
}
```
:::

#### 何时使用该专精

如果你想在单体战斗中玩 [[talent:123389]]，就使用这个专精。

#### 改变游戏玩法的天赋

探索专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用做简要概述，如需更详细的了解，请查看下方的**输出循环**和**深度俯冲**章节。

##### 专精树

- [[talent:112284@AJQABA]]
  
  - 在 范围伤害 和单体情况下都能造成高额爆发伤害。
- [[talent:136735]]
  
  - 使你进入激怒状态并造成可观的 范围伤害 伤害。
  - 如果你拥有 [[talent:112270]]，则造成更高伤害。
- [[talent:119139@FAQAN3gB]]
  
  - 显著增强你的 [[talent:112261]] 和 [[talent:112265@FAQAutdB]]，但仅在 [[talent:112281@FAQAN3gB]] 期间生效。

##### 职业树

- [[talent:134032@AJQABA]]
  
  - 提升你的进攻冷却技能的可用性，冷却缩减基于所消耗的怒气。
- [[talent:112188]]
  
  - 由于新天赋[[talent:134033]]，在至暗之夜中是一个略微更强的团队冷却技能。
- [[talent:136627]]
  
  - 现在在至暗之夜中会为你和你的盟友提供短暂的移动速度提升。
- [[talent:112253@AJQABA]]
  
  - 偶尔可以作为非常强力的进攻手段，将伤害反弹给敌人。很多时候目标无法被反弹，但你仍然能获得一个不错的防御增益，使受到的魔法伤害降低20%。
- [[talent:114644]]
  
  - 一个几乎完全没有冷却的防御技能，但会对你造成的伤害带来惩罚。
- [[talent:112215]]
  
  - 对付吸收护盾时可能非常强力。




### [[talent:123389]] 顺劈斩 / 范围伤害

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 何时使用该专精

此专精只牺牲少量单体伤害，即可造成显著更高的范围伤害伤害。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[talent:112260@FAQAN70E]]
  - [[talent:136452@FAQAjnqB]]
- **移除**
  
  - [[talent:112271]]
  - [[talent:112279]]





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **玉战领主的统御（2件）：**[[talent:112265]]伤害提高15%。在[[talent:112281]]期间，[[talent:112265]]会使[[talent:112281]]的持续时间延长2秒，最多6秒。
- **玉战领主的统御（4件）：** [[talent:112261]]伤害提高10%。在[[talent:112281]]期间，[[talent:112261]]会使[[talent:112281]]的爆击加成提高5%，最多10%。

### 单体目标



#### [[talent:123389]]

##### 起手循环

- 起手技能最好用这样的宏来使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation 典型的[[talent:123389]]起手
```json
{
  "source_code": "I8EOJIAAAAAABI0tGAAAAIEZB0AEAAgQvAdBXAhQHo3AAEgHMIDpBAQEOkhHMkPHFAgLuAAC5zRB"
}
```
1. [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:227847]]  [[spell:107570]]
5. [[spell:227847]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:184367]]
9. [[spell:335097]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 使用[[talent:112281@FAQAN3gB]]。  -- 切换至冷却技能优先级列表
2. 在以下任一情况时使用[[talent:112277]]：
   
   - [[spell:184361]]未激活或即将结束。
   - 你的怒气超过100点。
3. 在以下任一情况时使用[[spell:5308]]：
   
   - 你拥有2层[[talent:112301@AJQABA]]，或者[[talent:112301@AJQABA]]即将结束。
   - 你拥有至少2层[[spell:445584]]以及[[talent:112301@AJQABA]]。
   - 你正处于"斩杀阶段"
4. 冷却好了就使用[[talent:136735]]。
5. 冷却好了就使用[[talent:112265@FAQAutdB]]。
6. 冷却好了就使用[[talent:112261]]。
7. 使用[[talent:112277]]。
8. 冷却好了就使用[[spell:1680@FJwCadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTABEA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 在以下情况下使用[[talent:112277]]：
   
   - [[spell:184361]]即将结束，或者
   - 你的怒气超过100。
2. 在触发新的[[spell:184361]]后使用[[talent:112284@AJQABA]]。
3. 在以下任一情况下使用[[spell:5308]]：
   
   - 你拥有2层[[talent:112301@AJQABA]]，或者[[talent:112301@AJQABA]]即将结束。
   - 你拥有至少3层[[spell:445584]]和[[talent:112301@AJQABA]]。
4. 如果你尚未触发4件套提供的两层暴击加成提升，则使用[[spell:335096]]。  *-- 这通常由[[talent:112284@AJQABA]]完成，但如果你的[[talent:112284@AJQABA]]正在冷却中，你就必须手动触发4件套效果。*
5. 如果你拥有[[talent:112276]]，则使用[[spell:335097]]。
6. 使用[[talent:112277]]。
7. 在冷却好了就使用[[spell:335097]]。
8. 如果你处于"斩杀阶段"，则使用[[spell:5308]]。
9. 在冷却好了就使用[[spell:335096]]。




#### [[talent:123392]]

##### 起手循环

- 起手前3个技能最好用这样的宏放在一起使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation
```json
{
  "source_code": "IcEUIIAAAAAACIkNkGAAAI0tGAAAAIEZBMBEAAgQvAdBdggQWQaAXQBAChPHFAgLYAAK5zRBAAAAAIE-cUA"
}
```
1. [[spell:107574]] · [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:435222]]
5. [[spell:335096]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:335096]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 同时使用[[talent:112285@AJQABA]]和[[talent:112281@FAQAN3gB]]。  -- 切换到下方的冷却优先级列表
2. 如果你的 [[talent:112285@AJQABA]] 处于激活状态，使用 [[spell:435222]]。
3. 在以下任一情况使用 [[talent:112277]]：
   
   - [[spell:184361]] 未生效或即将结束。
   - 你的怒气超过100。
4. 如果你拥有 [[talent:112276]]，使用 [[talent:112265@FAQAutdB]]。
5. 在冷却结束后使用 [[spell:5308]]。
6. 使用 [[spell:435222]]。
7. 在冷却结束后使用 [[talent:112261]]。
8. 在冷却结束后使用 [[talent:112265@FAQAutdB]]。
9. 使用[[talent:112277]]。
10. 在冷却结束后使用 [[talent:112205@FAgAadhAEMA]]。
11. 使用 [[spell:1680@FJwCadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTABEA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 同时使用 [[talent:112285@AJQABA]] 和 [[talent:112281@FAQAN3gB]]。
2. 在以下任一情况使用 [[talent:112277]]：
   
   - [[spell:184361]] 未生效或即将结束。
   - 你的怒气超过100。
3. 如果你有2层[[spell:435222]]，使用[[spell:435222]]。
4. 如果你尚未触发4件套带来的暴击加成的两层效果，使用[[spell:335096]]。
5. 如果你有[[talent:112276]]，使用[[spell:335097]]。
6. 在冷却好了就使用[[spell:335096]]。
7. 在冷却好了就使用[[spell:335097]]。
8. 在冷却结束后使用 [[spell:5308]]。
9. 使用[[talent:112277]]。
10. 使用 [[spell:435222]]。





### 多目标



#### [[talent:123389]]

##### 起手循环

- 起手技能最好用这样的宏来使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation 典型的 [[talent:123389]] 多目标起手
```json
{
  "source_code": "I8aAQtgAAAAAAIgQ3aAAAAgQ2QaAAAgQkFwEQDAACt85CUkAMYpMAo1FCgDLB4FUBkC0Co4eCIaiDU0tAQSDHUSDHADMTsMPBEQAAAgQvAtABkDDCdgeDIDCAAwLNgREIgwIgXQBgEBEueGA"
}
```
1. [[spell:1719]] · [[spell:107574]]
2. [[spell:100]]
3. [[spell:190411]]
4. [[spell:184367]]
5. [[spell:227847]]
6. [[spell:227847]]
7. [[spell:184367]]
8. [[spell:184367]]
9. [[spell:385059]]
10. [[spell:184367]]
11. [[spell:190411]]
:::

##### 优先级列表

- 多目标优先级列表与单体优先级列表类似，主要区别在于要始终保持 [[spell:12950]] 处于激活状态。

这是你在整场战斗中力求维持的一般优先级。

1. 如有需要，使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]来施加[[spell:85739]]，使你的单体技能能够进行顺劈。
2. 使用[[talent:112281@FAQAN3gB]]。  -- 切换至冷却技能优先级列表
3. 使用[[talent:112277]]。
4. 冷却好了就使用[[talent:136735]]。
5. 冷却好了就使用[[spell:5308]]。
6. 冷却好了就使用[[talent:112265@FAQAutdB]]。
7. 冷却好了就使用[[talent:112261]]。
8. 使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 如有需要使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]来施放[[spell:85739]]，使你的单体技能获得顺劈效果。
2. 使用[[talent:112277]]。
3. 在触发新的[[spell:184361]]后使用[[talent:112284@AJQABA]]。
4. 在冷却完毕时使用[[talent:136735]]。
5. 如果你拥有[[talent:112301@AJQABA]]，则使用[[spell:5308]]。
6. 如果你尚未触发4件套带来的两层暴击加成的全部层数，则使用[[spell:335096]]。 *——这通常通过[[talent:112284@AJQABA]]配合[[talent:136074@AJQABA]]完成，但如果你的[[talent:112284@AJQABA]]正在冷却中，你就必须手动触发4件套效果。*
7. 使用[[spell:335097]]。
8. 在冷却结束后使用 [[spell:5308]]。
9. 在冷却好了就使用[[spell:335096]]。
10. 使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]。




#### [[talent:123392]]

##### 起手循环

- 起手前3个技能最好用这样的宏放在一起使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation
```json
{
  "source_code": "IcEUIIAAAAAACIkNkGAAAI0tGAAAAIEZBMBEAAgQvAdBdggQWQaAXQBAChPHFAgLYAAK5zRBAAAAAIE-cUA"
}
```
1. [[spell:107574]] · [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:435222]]
5. [[spell:335096]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:335096]]
:::

##### 优先级列表

- 多目标优先级列表与单体优先级列表类似，主要区别在于要始终保持 [[spell:12950]] 处于激活状态。

这是你在整场战斗中力求维持的一般优先级。

1. 如有需要使用 [[talent:112205@FAgAadhAEMA]] 来施加 [[spell:85739]]，使你的单体技能附带顺劈效果。
2. 同时使用 [[talent:112285@AJQABA]] 和 [[talent:112281@FAQAN3gB]]。   -- 切换到下方的冷却优先级列表
3. 使用[[talent:112277]]。
4. 如果 [[talent:112285@AJQABA]] 已就绪，使用 [[spell:435222]]。
5. 如果 [[talent:112285@AJQABA]] 已就绪，使用 [[talent:112261]]。
6. 如果 [[talent:112285@AJQABA]] 已就绪，使用 [[talent:112205@FAQAadhA]]。
7. 在冷却结束后使用 [[spell:5308]]。
8. 如果你有 [[talent:112276]]，使用 [[talent:112265@FAQAutdB]]。
9. 在冷却结束后使用 [[talent:112261]]。
10. 在冷却结束后使用 [[talent:112265@FAQAutdB]]。
11. 冷却完毕即使用 [[talent:112205@FAQAadhA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 将[[talent:112285@AJQABA]]和[[talent:112281@FAQAN3gB]]一起使用。
2. 如有需要，使用[[talent:112205@FAgAadhAEMA]]来施加[[spell:85739]]，使你的单目标技能可以进行顺劈。
3. 使用[[talent:112277]]。
4. 在冷却好了就使用[[spell:435222]]。
5. 在冷却好了就使用[[spell:335096]]。
6. 在冷却好了就使用[[spell:335097]]。
7. 在冷却好了就使用[[talent:112205@FAQAadhA]]。
8. 在冷却好了就使用[[spell:5308]]。





## 深层 俯冲

### 延迟使用暴怒

- 在循环中，你有时会延迟使用[[talent:112277]]，只有当需要它来触发[[spell:184361]]时，它才是最高优先级。
- 当你没有达到怒气上限的风险时，积攒更多怒气是有益的，以便获得一份盈余，供之后用来弥补运气不佳的情况，从而使你始终保持[[spell:184361]]处于激活状态。
- 如果你使用[[talent:134032@AJQABA]]，那么消耗怒气本身就很有价值，因为这能提高你爆发技能的覆盖率。你仍然可以延迟使用[[talent:112277]]，但一般来说，如果你有达到怒气上限的风险，就不要延迟。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

- 更详细的首领技巧将在即将到来的首杀竞速（Race to World First）结束后补充。



### 盘魂者内克扎莉

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 爆发技能使用

- 在**躁动的不安曼尼**小怪刷新时留好爆发技能会很有帮助，但只有当你能在 BigWigs 计时条上看到小怪即将刷新时才值得保留爆发技能，不要长时间握着不放。

#### 防御技能使用

- 当**内克扎莉**施放[[spell:1288772]]时使用防御技能。

#### 首领攻略技巧

- 当**内克扎莉**施放[[spell:1292034]]时，注意坦克所在的位置。不要站在她和她的目标之间。




### 陵寝哨兵

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 爆发技能使用

- 密切关注**陵寝哨兵**能量达到100并施放[[spell:1284606]]的时机，因为你肯定不希望在那时刚刚交掉技能却无法造成任何伤害。

#### 防御技能使用

- 在吸收[[spell:1288282]]时使用防御冷却技能。

#### 首领攻略技巧

- 在[[spell:1284606]]期间，你头上会被标记1、2或3个毒液球。将1与3组合，2与2组合，目标是凑满4个。




### 迷失的探险者们

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 防御技能使用

- 如果吸收[[spell:1300237]]时其中没有太多人分担伤害，请使用防御冷却技能。

#### 首领攻略技巧

- 如有需要，你可以通过[[spell:6544]]越过[[spell:1297650]]，但与团队一起踩蘑菇相比并没有太大收益。当你站位失误且冲击波即将到来时再使用它。




### 万毒邪祟者瓦什尼克

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 防御技能使用

- 在击杀火焰小怪后受到[[spell:1285979]]影响时使用防御技能，尤其是当叠加超过1层时。

#### 首领攻略技巧

- 帮助中了 [[spell:1295224]] 的队友移出他们脚下的圈，使其重新可以被治疗。




### 斯索拉克

:::talents [[talent:123390]] **狂怒 战士** 团队单体天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZGzYmlZmxMzMbmZmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM"
}
```
:::

#### 爆发技能使用

- **斯索拉克**在[[spell:1286033]]期间受到的伤害提高。

#### 防御技能使用

- 如果你被 [[spell:1287083]] 龙卷风击中，使用一个防御技能。

#### 首领攻略技巧

- 当你受到 [[spell:1285616]] 影响时，调整站位使自己与另一名玩家相撞。如有需要，使用 [[spell:100]] 或 [[talent:112208@AJQA]] 来避免自己被击飞出去。




### 双子毒牙

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 防御技能使用

- 当你受到 [[spell:1290878]] 影响时，使用一个防御技能。

#### 首领攻略技巧

- 尽可能帮助分摊 [[spell:1289201]]，但不要叠加过多层 [[spell:1292348]]。
- 避免被 [[spell:1292806]] 波动击中。




### 盘卷祭坛

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 爆发技能使用

- 确保在第二阶段后的间歇阶段保留所有进攻技能，此时**祖尔加**会因[[spell:1304033]]而受到100%的额外伤害。

#### 防御技能使用

- 当你受到[[spell:1286901]]影响时使用防御技能。

#### 首领攻略技巧

- 务必优先拾取你的所有**灵魂残片**，如果你被[[spell:1286901]]击中的话，否则你将[[spell:1286837]]。




### 乌拉特克

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

乌拉特克在 12.1 PTR 服务器上尚未见到，将在补丁上线和赛季开始时首次登场。上面提供的天赋应该是一个不错的起点。  
乌拉特克以及所有首领的更新将在结束即将到来的世界首杀竞赛后尽快推出。




### 尼姆瑞莎·唤波者

:::talents [[talent:123390]] **狂怒 战士** 团队顺劈天赋
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDzMmZsMzMzMDjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsBAAzMMmlhxgxA"
}
```
:::

#### 防御技能使用

- 当 **尼姆瑞莎** 施放 [[spell:1260843]] 时使用一个防御冷却技能。

#### 首领攻略技巧

- 准备好冲锋 **尼姆瑞莎** 或在泡泡 [[spell:1266340]] 出现时使用 [[talent:112208@AJQA]]。
- 不要在水里站太久，否则会被 [[spell:1265425]] 击中。





## 属性优先级

了解你在 **狂怒 战士** 中进行 团队副本 首领战时的属性优先级以及实现最佳表现所需的绿字属性。欲了解更多详细信息，请访问 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **狂怒 战士** 团本中的属性优先级
```json
{
  "source_code": "IgAHEEDJggiADQA"
}
```
**精通 ＝ 急速 ≥ 暴击 ≫ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可降低“**范围效果**”技能受到的伤害。
- **吸血** - 通过造成伤害提供额外治疗。
- **加速** - 比较冷门的绿字属性，但可能非常有用，过去已被证明其实用价值，能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 来源位置 |
| --- | --- | --- |
| 头部 | [[item:271456@DiCBAgEAvj7cUrDf1IYN2WjNyIoAFfBB]] | 盘魂者内克扎莉 + 催化 |
| 项链 | [[item:268265@BkCAAgEAU06IQrDj1QWNYYjX1IoA]] | 乌拉特克 |
| 肩部 | [[item:271454@DACAAgEA1k74XNBWjNyIoA]] | 迷失的探险者 |
| 披风 | [[item:268253@BgRAAgEAYYjX1IoAYFA]] | 盘卷祭坛 |
| 胸部 | [[item:271459@DASBAgEAJk7oXNCWDG2IoAYFgvXQ]] | 盘卷祭坛 + 催化 |
| 护腕 | [[item:237834@BiUAAgEAM06Y7LjVT0wwgN3Wjt1ccNAMSWisUA]] | 锻造 |
| 手套 | [[item:271457@BASAAgEA7VTg1YjMCKgTBA]] | 陵寝哨兵 |
| 腰带 | [[item:268259@BCSAAgEA8z6ghNeVjt1IoAYF]] | 盘卷祭坛 |
| 腿部 | [[item:271878@DACAAgEAju7YhNYYjX1IoA]] | 乌拉特克 |
| 靴子 | [[item:268260@BgBAAgEA2IjX1IoA]] | 万毒邪祟者瓦什尼克 |
| 戒指 1 | [[item:252258@DCSAAgEA1j7wPrDZ1YjMeVjgC4UA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:268249@DCCAAgEA1j7wPrDZ1YjMeVjgCA]] | 万毒邪祟者瓦什尼克 |
| 饰品 1 | [[item:270175@BghAAgEAYYjX1IoAFAQAXdhA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgBAAgEAYYjX1IoA]] | 盘卷祭坛 |
| 武器 | [[item:268213@DgBAAgEAFk7ghNeVjgC]] | 盘卷祭坛 |
| 副手武器 | [[item:237848@DgDAAgEAFk7Y7LMYzt1sZJLXDAjklIA]] | 锻造 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251126@DARAAcEANk74iMeVTQB]] | 密谋小径 |
| 项链 | [[item:251142@AgQAAIoABFA]] | 密谋小径 |
| 肩部 | [[item:251138@DARAAcEA7j74iMeVTQB]] | 密谋小径 |
| 披风 | [[item:193763@BARAAcEAuIjX1EUA]] | 红玉新生法池 |
| 胸部 | [[item:193753@AgQAAIoABFA]] | 红玉新生法池 |
| 护腕 | [[item:251133@BARAAcEAuIjX1EUA]] | 密谋小径 |
| 手部 | [[item:159413@BARAAcEAuIjX1EUA]] | 诸王之眠 |
| 腰带 | [[item:159418@BARAAcEAuIjX1EUA]] | 诸王之眠 |
| 腿部 | [[item:273776@DARAAcEAju74iMeVTQB]] | 毒牙祭坛 |
| 脚部 | [[item:159412@DARAAcEApk74iMeVTQB]] | 诸王之眠 |
| 戒指 1 | [[item:273792@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:251136@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | 密谋小径 |
| 饰品 1 | [[item:273796@BARAAcEAuIjX1EUA]] | 毒牙祭坛 |
| 饰品 2 | [[item:250228@BARAAcEAuIjX1EUA]] | 密谋小径 |
| 武器 | [[item:273782@DARAAcEAFk74iMeVTQB]] | 毒牙祭坛 |
| 副手武器 | [[item:193755@AgQAAIoABFA]] | 红玉新生法池 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 等级 | 饰品 |
| --- | --- |
| S 级 | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A 级** | [[item:270165@AgQAAIoAOFA]] |
| **B 级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C 级** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *—— 适合 范围伤害，单目标则选机械花园。* |
| **机械花园** |  |

:::simulation
```json
{
  "source_code": "JcsBwzkJBMYLEEAEBAASAYjMASjTBAgdXZGSB81HEEACBAASAghNYFAAsgUcIFIIO9GITVGd6oVdsdiap52JzByR1lGbs9Gdp5WZgQVZjhWXf4CNAQhdKLHSBUoOcBAEm-ZaIFgNoAAHmqBdIFQ30LgMECAFwSVaIFg46UBAUsYVphUAEqjUAQBNhrGSBQVEuCjNy4UAAoOpuhUA0F9AyIFAUo9vqhUA1pTFAQBKKnGSBMpOVAAF2vCcIFgf6UBAUcbnphUAVJzZAQh1svGSBMoOoAAF83YZIFQh6UBAYYpYrhUAfqmNjDAFu2tZIFwUyIFAU0XklhUAYFxEloHCvmiZ6YUAUEUAAsf_opTCBASQBAAPlhGSBCiqkGAFBFAAQoWby8YAUEUAA8HPwpDrAASQBAQdnTGSBMoL6FAHBFAAkXXZIFQXogRQBAQU90GS2wcAUEUAAgMJnpDzBEgUEcGa68YAUEUAAYQ1pJDABQRQBAQA1QmONGAFBFAAcAJa6oXAUEUAAoSFkpDzBQRQBAg_v3mMlFAHBFAA04MZIFgMiGAGBFAAqyIaIZzMCQRQBAQKpmmMbJAFBFAA1IKbycgAgEUAAc3Hrh0B_D"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| [[item:273795]] | 235,869.84 |
| [[item:270175]] | 247,072.69 |
| [[item:270173]] | 248,617.84 |
| [[item:273797]] | 239,230.59 |
| [[item:270173]] | 249,962.59 |
| [[item:193757]] | 238,930.75 |
| [[item:193762]] | 238,934.17 |
| [[item:273796]] | 240,516.81 |
| [[item:270164]] | 244,371.66 |
| [[item:250228]] | 240,383.41 |
| [[item:250229]] | 239,400.62 |
| [[item:250259]] | 245,935.84 |
| [[item:250238]] | 239,222.86 |
| [[item:270165]] | 241,587.34 |
| [[item:250243]] | 235,063.94 |
| [[item:250245]] | 241,034.34 |
| [[item:158367]] | 236,406.72 |
| [[item:270163]] | 235,077.95 |
| [[item:270168]] | 235,686.73 |
| [[item:273797]] | 238,583.92 |
| [[item:273796]] | 237,972.94 |
| [[item:270173]] | 243,112.25 |
| [[item:270173]] | 246,001.98 |
| [[item:158367]] | 234,397.83 |
| [[item:273795]] | 234,967.56 |
| [[item:270175]] | 242,933.27 |
| [[item:193757]] | 236,691.12 |
| [[item:193762]] | 237,981.83 |
| [[item:250229]] | 239,444.09 |
| [[item:270168]] | 233,684.02 |
| [[item:250238]] | 238,144.44 |
| [[item:250243]] | 233,556.66 |
| [[item:250259]] | 243,647.97 |
| [[item:270163]] | 234,296.81 |
| [[item:250245]] | 238,130.66 |
| [[item:250228]] | 239,268.64 |
| [[item:270164]] | 242,312.83 |
| [[item:270165]] | 240,765.86 |
:::

### 美化饰品

- 使用 [[item:273060]] 制作一件制造武器是最佳选择，尤其是在初期配装阶段，除非你已经有两把好武器。
- 第二个美化制造部位我们选择 [[item:240167]] 或 [[item:273069]] 美化，考虑到 [[item:240167]] 能为队友带来的收益，这两个选项非常接近。推荐的部位是护腕。 *—— 过去披风可能是常见部位，但本赛季团本会掉落我们更愿意使用的 344 装等更高披风。*

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **瓶装药剂**
  
  - [[item:241324]] 或  *—— 最佳配装 配装使用急速瓶*
  
  
  
  - [[item:241326]] 或
  - [[item:241322]] *—— 狂怒 战士需要急速、精通和爆击等属性的均衡搭配。*  *如果你想了解自己的属性配比以及更缺什么属性，我建议查看我们的 **[Simcraft 攻略](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**。*
- **食物**
  
  - [[item:255846]]
- **战斗药水**
  
  - [[item:241288]] *—— 最适合 最佳配装 配装，但对你来说未必最佳。如果你想确认自己的角色该用哪种药水，请查看 Simulationcraft。* *我们的**[ Simcraft 攻略](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** 可以帮助你进一步了解 Simulationcraft。*
  
  
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器临时附魔**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **插槽**
  
  - [[item:240967]] *—— 唯一，每种颜色的宝石各镶嵌一颗以强化你的 [[item:240967]]。*
    
    - [[item:240890]]
    - [[item:240906]]
    - [[item:240916]]
    - [[item:240900]]

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707]] |
| --- | --- |
| 肩部 | [[item:244021]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707]] |
| 腰部 | [[item:275707]] |
| 腿部 | [[item:244643]] |
| 脚部 | [[item:243983]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 武器 | [[item:243973]] |
| 副手武器 | [[item:243973]] |

:::

:::column
:::gear **狂怒 战士** 团队副本附魔
```json
{
  "source_code": "JwFZHBQ9NGQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwo7mAGA8gOYAAB1jbCYEBCoUQuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244643]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
| 副手 | [[item:243973]] |  |
:::

:::

:::

> 你需要从宏伟宝库商人处购买[[item:263897]]，为你的**头盔**、**护腕** & **腰带**添加插槽。

## 种族

如果要对**狂怒 战士** 在团队副本中进行极限优化，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:20589]] —— 侏儒
  
  - 解除定身和减速。
- [[spell:58984]] —— 暗夜精灵
  
  - 脱离战斗以避免法术以你为目标。
- [[spell:20594]] —— 矮人
  
  - 同时移除所有中毒、疾病、诅咒、魔法和流血效果。
- [[spell:69179]] —— 鲜血精灵
  
  - 同时驱散附近所有敌人的 1 个增益效果。
- [[spell:256948]] —— 虚空精灵
  
  - 激活后生成一个沿你面朝方向移动的暗影。再次激活可传送至其位置。
  - 最大距离 100 码。

:::simulation
```json
{
  "source_code": "JUtAQ2xAfAAACSwRv52aKYHB251cINgFAAAAvmKdINQHAAAAVf-dINQAjAqBLlWbiVHbLYHB_L2cINAIAAAAg7jdINgIAAAAjlXdINQJAAAAA-tdIVQU0cwSyF2ZncXYMYHB_M9cJIEKFAVYnsWdJYHBvCWDmAlBBtWduRWYHYHBdiAdINgHAAAAJPeDuwXCCd3buNXYtRWaIYHB2qEdINABAAggDQUY5xKXCQXt1lAEwXZBOl2ZoRXrcJACiWHSDcAAAAwCiaHSDMAAAAweGgHSDoAAAAwToWHSDEAAAAgTfeHSDQCAAAge2THSDIAAAAQ_IXHSDsAAAAgSWWHSDgAAAAw5DYHSDUAAAAwYmSHSDgBAAAgjvbHSDkAAAAQphaHSDYAAAAwuKgHSDwBAAAApuZHSDsBAAAQuzNHSDMCAAAQB4LHSHkB"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292362]] | 249,209.84 |
| 种族 22 | 250,534.73 |
| 种族 29 | 253,855.33 |
| 种族 31 [[spell:292363]] | 249,227.98 |
| 种族 32 | 252,155.50 |
| 种族 34 | 251,365.55 |
| 种族 37 | 252,798.00 |
| 种族 31 [[spell:292364]] | 249,676.98 |
| 种族 31 [[spell:292361]] | 252,290.73 |
| 种族 31 [[spell:292359]] | 249,890.45 |
| 种族 30 | 249,743.14 |
| 种族 31 [[spell:292360]] | 250,154.84 |
| 种族 4 [[spell:154796]] | 251,605.81 |
| 种族 4 [[spell:154797]] | 251,528.12 |
| 种族 7 | 252,552.17 |
| 种族 3 | 253,977.92 |
| 种族 10 | 251,553.23 |
| 种族 1 | 253,565.22 |
| 种族 36 | 250,841.91 |
| 种族 2 | 251,683.95 |
| 种族 11 | 251,481.16 |
| 种族 8 | 251,919.61 |
| 种族 5 | 250,521.55 |
| 种族 24 | 252,862.22 |
| 种族 9 | 252,550.58 |
| 种族 6 | 253,994.92 |
| 种族 28 | 252,346.56 |
| 种族 27 | 249,294.89 |
| 种族 35 | 248,800.08 |
:::

### 推荐

如果你追求最高 DPS，那么就应该选择模拟表现最好的种族天赋；但如果你的重点是开荒团本，那么就应该考虑不同种族天赋的功能性。例如：[[spell:65116]] 种族天赋使 矮人 成为 **火光之龙菲莱克** 在「阿米达希尔，梦境之希望」世界首杀竞速中的最佳选择。

## 宏

了解**狂怒战士**在团队副本战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频指南。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:376079]] 宏** *--- 在你的光标位置施放勇士之矛。*

```wow-macro
/cast [@cursor] 勇士之矛
```

**[[spell:6544]]宏** *--- 无需额外点击鼠标即可跳向你的鼠标指针位置。*

```wow-macro
/cast [@cursor] 英勇飞跃
```

:::

:::details 鼠标指向宏
**[[spell:163201]]宏** *--- 如果你的鼠标悬停在一个敌人身上，则对其施放斩杀，否则对当前目标施放斩杀。这个宏在你保持以首领（Boss）为目标的同时斩杀附近低血量的小怪时非常有用。*

```wow-macro
/cast [@mouseover, harm, nodead][harm,nodead] 斩杀
```

**[[spell:100]]宏** *--- 对当前目标施放冲锋，除非你的鼠标悬停在另一个敌人身上，此时会以该敌人为目标并施放冲锋。*

```wow-macro
/target [@mouseover, harm, nodead]
/cast 冲锋
```

:::

:::details 实用宏
**[[spell:386208]] 和 [[spell:386196]] 宏 *--- 使用这个宏，你只需一个按键绑定就能切换姿态。***

```wow-macro
/cast [stance:2] 防御姿态; [stance:3] 狂暴姿态
```

:::

:::

## 插件

下方是作者的 **狂怒 战士** 用户界面截图，其中标明了使用了哪些插件，以及它们在团队副本中如何使用，从而让你的游戏体验更加轻松。

![Revvez Midnight Fury Warrior UI](<https://assets-ng.maxroll.gg/wordpress/UIEllesmereUI-1024x576.png>)

Revvez 的 **狂怒 战士** UI

:::accordion
:::details 插件
- **MRT *-- 备注、团队副本 冷却时间等信息*** 
  
  - 对团队副本玩家非常有用的插件，尤其适合团队副本团长和官员使用。
- **Ellesmere UI *-- 用户界面替换*** 
  
  - EllesmereUI 是一套完全模块化的 UI 套件，专为那些想要完全掌控自己界面、同时又不想牺牲性能和简洁性的玩家而设计。每个元素都从底层构建，轻量、响应迅速且易于配置。
- **BigWigs *-- 通用首领模块***  
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些迷你插件旨在针对某场特定的团队副本战斗触发警报信息、计时条、音效等。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**战士**

- *开发者说明：撕裂 是 战士 的标志性核心技能，与每个专精都有不同的关联。我们在 至暗之夜 中对 撕裂 的处理方式并未达到预期效果，因此我们将在 乌拉特克 诅咒中调整每个专精如何施加和互动 撕裂。*
- 撕裂 技能现在为 武器 专精独有，重新变回单体技能，其怒气消耗降低至 10 点。如果 战士 已学会 撕裂，顺劈斩将对所有目标施加 撕裂。
- 新天赋（狂怒）：鲜血 之风暴——旋风斩 对所有目标施加 撕裂。崩解闪电 可使 鲜血 之风暴同时对 雷霆一击 施加 山丘领主。
- 新天赋（防护）：鲜血 与雷霆——雷霆一击 对所有目标施加 撕裂。
- 雷霆一击 不再天生施加 撕裂（即使已学会）。
- 标枪手有了新图标。
- 英雄天赋
  
  - 山丘领主
    
    - 开发者说明：雷霆一击 的基础伤害在 至暗之夜 中大幅提升，导致 山丘领主 的 雷霆一击 总体伤害显著上升，进而使 雷霆轰击 的价值下降。我们将把 崩解闪电 的伤害加成移入 雷霆轰击 本身，以保持 雷霆轰击 的特殊性和强大感。
    - 雷霆轰击 伤害提高 20%。
    - 崩解闪电 使 雷霆一击 伤害提高 10%（原为 30%）。
- 狂怒
  
  - 开发者说明：旋风斩 历来是 狂怒 玩法的核心部分，即使在单体输出场合也是如此。我们希望让 旋风斩 重新成为单体情况下有用的技能。
  - 新天赋：雕刻之刃——旋风斩 在只命中单个目标时造成 50% 的额外伤害。
  - 旋风斩 已更新——旋风斩 现在天生产生 3 点怒气。
  - 强化旋风斩 已更新——不再使 旋风斩 天生产生 3 点怒气，但仍使 旋风斩 每命中一个目标额外产生 1 点怒气，最多总计 8 点怒气。
  - 暴怒毁灭 已重新设计——当 强化旋风斩 激活时，暴怒 的最后一击将猛击地面，对目标 8 码范围内的所有敌人造成物理伤害。超过 5 个目标后伤害降低。
    
    - *开发者说明：暴怒毁灭 旨在帮助缓解 狂怒 循环中 范围伤害 技能的目标上限问题。当前的设计导致很难判断何时使用 暴怒毁灭 最佳，新设计应该会让这个选择更加直观。*
  - 劈斩 已更新——暴怒 现在有 75% 的几率返还一层 怒击 充能，并使你下一次 怒击 的伤害提高 20%。
    
    - *开发者说明：我们认为 狂怒 在你不确定当前按键之后该用哪个技能时体验最佳。此前版本的 劈斩 提供了极其规律且稳定的 怒击 重置，导致 怒击 几乎总是可用。我们相信这一改动将帮助保持 狂怒 循环的多变性，并让强调 怒击 的构筑与不强调它的构筑在循环手感上有更大差异。*
  - 浴血奋战 初始伤害降低 12%，流血伤害提高 300%。
    
    - *开发者说明：浴血奋战 的设计意图是大部分伤害加成来自流血效果。现有的数值调整没有实现这一点，因此我们将 浴血奋战 增加的部分伤害从初始打击移至流血效果。这一改动对 浴血奋战 的总体伤害应当是净中性的。*
  - 英雄天赋
    
    - 山丘领主
      
      - 接地电流伤害提高 150%。

:::

:::details 12.0.5 补丁
**战士**

- 撕裂 的半径扩大至 10 码（原为 8 码）。
- 当 战士 的目标拥有生效的吸收护盾时，破裂投掷 现在会被高亮显示。
- 当 战士 的目标拥有生效的免疫效果或 法师 的冰墙时，碎裂投掷现在会被高亮显示。
- 狂怒
  
  - 劈斩 已重新设计——暴怒 有 100% 的几率返还一层 怒击 充能。
  - 强化旋风斩 现在使 旋风斩 在已学会 撕裂 的情况下，对所有目标施加 撕裂。
  - 斩杀者
    
    - 掠武风暴 已更新——当 暴怒 通过 强化旋风斩 命中 3 个或更多目标时，你有 20% 的几率释放钢铁风暴，对附近所有敌人造成高额物理伤害并施加 不堪一击。
    - 无情强袭 现在使 剑刃风暴 造成的伤害提高 20%。

:::

:::details 补丁12.0.1
**战士**

- 英雄天赋
  
  - 山丘领主
    
    - 狂怒
      
      - 闪电打击伤害提高 100%。
      - 雷霆轰击 伤害降低 30%。
      - 崩解闪电 对 雷霆一击 的伤害加成降低至 30%（原为 40%）。
  - 斩杀者
    
    - 殒命在即 现在有一个额外效果——猝死 有 100% 的几率触发 掠武风暴。
    - 斩杀者 的打击伤害降低 10%。
    - 掠武风暴 伤害降低 20%。
    - 狂怒
      
      - 清剿旋风的额外伤害提高至 20%（原为 10%）。
      - 斩杀者 的恶意额外伤害降低至 15%（原为 20%）。
      - 掠武风暴 的触发几率提高至 35%（原为 25%）。
- 职业
  
  - 重伤 伤害降低 30%。
- 狂怒
  
  - 自动攻击伤害降低 48%。
  - 嗜血 伤害提高 10%。
  - 剑刃风暴 伤害提高 30%。
  - 怒击 伤害降低 20%。
  - 暴怒 伤害降低 10%。

:::

:::details 补丁12.0
**战士**

- 英雄天赋
  
  - 山丘领主
    
    - 新天赋：狂雷奔涌 – 天神下凡使雷霆一击的伤害提高50%，并使其冷却时间缩短50%。
    - 新天赋：导电 – 闪电打击的伤害提高10%，暴击伤害提高10%。
    - 新天赋：电容 –在天神下凡期间，雷霆轰击会使天神下凡的持续时间延长2秒。
    - 雷霆轰击的伤害提高150%。
    - 狂怒
      
      - 山岳之力的嗜血和暴怒伤害提高15%（原为25%）。
  
  
  
  - 斩杀者
    
    - 新天赋：狂烈快感 – 剑刃风暴会使你进入战斗恍惚状态，在你停止剑刃风暴后获得15%急速，持续8秒。
    - 新天赋：致命专注 – 处刑者的持续时间延长6秒。
    - 新天赋：迷狂乱舞
      
      - 狂怒：每攻击2次剑刃风暴，你就会自动对你的目标或附近的随机敌人施放一次嗜血，造成100%的正常伤害。
    - 屠戮之霸已更新 – 你的攻击有15%的几率触发屠戮者打击。屠戮者打击现在会为你提供一层处刑者，使你的斩杀伤害提高3%，持续12秒。处刑者的多层效果可以叠加。
    - 绝不留情已更新 – 处刑者每层还会使你的斩杀暴击几率和暴击伤害提高3%。
    - 无情强袭已更新 – 使用猝死会使你拥有的每层处刑者都使剑刃风暴的冷却时间缩短5秒，并向你的主要目标施加1层不堪一击。
    - 投机者的效果现在最多可叠加2次。
    - 压制之锋的不堪一击减益效果现在可叠加5次（原为10次）。
    - 斩杀者的恶意现在除了压制和怒击之外还会影响斩杀，但伤害加成降低至20%（原为30%）。
    - 屠戮者打击的伤害提高100%。
    - 掠武风暴的伤害提高100%，触发几率提高至25%（原为20%）。
    - 狂怒
      
      - 投机者的伤害以及下一次怒击的暴击伤害降低至10%（原为25%）。
- 职业
  
  - 新天赋：共鸣之声 – 你的怒吼的持续时间延长20%。
  - 新天赋：报复 – 当你受到近战范围内敌人造成的任何伤害时，你有几率对该敌人造成物理伤害。
  - 新天赋：姿态掌握 – 你的姿态会获得额外的效果。
    
    - 战斗姿态：使你技能的暴击伤害提高3%。
    - 狂暴姿态：使你的自动攻击速度提高3%。
    - 防御姿态：当一次攻击造成相当于你最大生命值20%或以上的伤害时，该伤害降低15%。
  - 新天赋：战地统帅 – 你的怒吼技能会获得额外的效果。
    
    - 战斗怒吼：额外为你提供3%攻击强度。
    - 集结呐喊：额外提供2%生命值，持续时间延长3秒。
    - 刺耳怒吼：半径扩大100%。
    - 狂暴怒吼：半径扩大100%。
    - 威慑怒吼：冷却时间缩短15秒。
  - 新天赋：愤怒掌控 – 你每消耗20点怒气，天神下凡、巨神兵打击、鲁莽和盾墙的剩余冷却时间就会缩短1秒。
  - 新天赋：战地包扎 – 受到的治疗提高3%，所有自我治疗额外提高10%。
  - 新天赋：无畏 – 狂暴之怒的冷却时间缩短50%，并且狂暴之怒会移除所有移动限制效果。
  - 新天赋：掷矛高手 – 你的投掷类技能距离延长5码。勇士之矛、碎裂投掷和破裂投掷造成的伤害提高20%。碎裂投掷和破裂投掷会使非玩家目标沉默3秒。
  - 新的武器和狂怒天赋：居中调停 – 高速冲向盟友附近的目标位置，在8秒内或直到你因此效果受到至少相当于你最大生命值20%的伤害为止，为3码范围内的盟友承受30%的所有伤害。
  - 新的武器和狂怒天赋：撕裂 – 挥舞武器横扫，对8码范围内的所有目标造成物理伤害，并使其流血，在15秒内受到额外的流血伤害。
  - 勇士之矛已重新设计 – 向目标位置投掷一柄长矛，将范围内的所有敌人用锁链拖至长矛所在位置，立即造成物理伤害，并在6秒内持续造成额外的物理伤害。长矛存在期间，再次激活该技能会使你跃向长矛，猛击落地，对所有目标造成物理伤害。超过5个目标后造成的伤害降低。产生10点怒气。
  - 威慑怒吼现在会使所有目标的移动速度降低70%，并使范围内除你主要目标以外的所有敌人逃跑。原为8个目标。
  - 集结呐喊已更新 – 不在团队中时，提供的生命值提高50%。
  - 干练反射现在使冷却时间缩短10%（原为5%），并获得额外效果 – 成功打断敌人后，你在10秒内对其造成的伤害提高5%。
  - 刺耳怒吼现在还会激励12码范围内的所有盟友，使其移动速度提高30%，持续4秒。
  - 野蛮训练现在使猛击、旋风斩、雷霆一击、怒击和复仇造成的伤害提高10%，暴击伤害提高5%。
  - 碎裂投掷和破裂投掷的距离缩短至25码（原为30码）。
  - 雷霆一击的伤害提高150%，如果已选择相应天赋，则会对所有目标施加撕裂。
  - 盾牌猛击的伤害提高140%。
  - 当你的生命值低于35%时，复苏之风的治疗效果提高100%。
  - 碾压之力现在是一个1点天赋。
  - 许多天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - 天神下凡 *（移至各专精的天赋树）*
    - 狂战士的折磨
    - 剑刃大师的折磨
    - 震耳咆哮
    - 挑战者之力
    - 震荡打击
    - 不可移动之物
    - 威吓
    - 穿刺挑战
    - 地震回响
    - 雷鸣之吼
    - 声如雷鸣
    - 泰坦的折磨
    - 势不可挡
    - 怒吼震天
    - 战争领主的折磨
- 狂怒
  
  - 新天赋：重伤 – 斩杀会对目标施加重伤，在6秒内造成高额伤害。
  - 新天赋：血之气息 – 暴怒使你下一次嗜血的伤害提高10%，最多可叠加2次。
  - 新天赋：怒气饮者 – 嗜血的爆击恢复额外3%的生命值，并使怒击的伤害提高10%，持续4秒。
  - 新天赋：处刑者之怒 – 斩杀额外产生5点怒气，并使暴怒的伤害提高10%，持续4秒。
  - 新天赋：蛮力爆发 – 当怒击重置自身冷却时间时，你的自动攻击伤害和速度提高30%，持续6秒。
  - 新天赋：不成功便成仁 – 当你将受到致命伤害时，你会陷入无法阻挡的狂怒，在8秒内无法被杀死并免疫移动限制效果，同时向企图杀死你的敌人复仇。如果你在这段时间内杀死了你的杀手，你会带着至少20%的最大生命值从狂怒中凯旋而归。如果你没有获胜，你将会死亡。此效果每5分钟只能触发一次。
  - 新被动技能：泰坦之握：单手狂怒 – 你可以将双手武器幻化为单手武器的外观。
  - 天神下凡已移至狂怒天赋树并已更新 – 变身为巨人，使你造成的所有伤害提高20%，移动速度提高5%，持续20秒。
  - 血肉顺劈已重新设计 – 当旋风斩击中3个或更多目标时，造成50%的额外伤害。
  - 浴血之躯已重新设计 – 被嗜血击中的目标在12秒内受到你的流血效果20%的额外伤害。
  - 熟能生巧已重新设计 – 嗜血的爆击几率提高5%/10%，如果你处于激怒状态，嗜血会使你的激怒延长0.5秒/1秒。如果嗜血爆击命中你的主要目标，此延长效果翻倍。
  - 狂乱已重新设计 – 暴怒使你的急速提高2%，持续12秒。此效果的多个实例可以叠加。
  - 批判性思维已重新设计 – 怒击的爆击几率提高5%/10%，爆击伤害提高5%/10%。
  - 强化嗜血更名为怨恨并已更新 – 嗜血和怒击（原仅为嗜血）的伤害和爆击伤害提高2.5%/5%（原为5%/10%）。
  - 残忍已更新 – 处于激怒状态时，嗜血和怒击（原仅为怒击）造成5%/10%的额外伤害（原为10%/20%）。
  - 怒意生威已更新 – 激怒使你的精通提高15%，吸血提高3%。
  - 血腥疯狂已更新 – 怒击使你下一次嗜血的伤害提高5%，最多可叠加5次。
  - 强化旋风斩现在使你的下4次单体攻击（原为2次）额外击中4个目标。
  - 暴怒现在替换猛击。暴怒的伤害提高10%。
  - 自动攻击的伤害提高200%。
  - 雷霆一击的伤害降低60%。
  - 旋风斩的伤害提高20%。
  - 嗜血的伤害提高20%。
  - 剑刃风暴现在每次攻击产生5点怒气（原为10点）。
  - 鲁莽使产生的所有怒气提高50%（原为100%）。
  - 奥丁之怒现在会使你进入激怒状态并产生20点怒气（原为15点）。
  - 奥丁之怒的流血伤害提高140%，并且现在对超过8个目标（原为5个）造成降低的伤害。
  - 暴怒毁灭造成的伤害提高50%，但现在对超过5个目标（原为8个目标）造成降低的伤害。
  - 修复了奥丁之怒流血伤害被护甲错误减免的问题。
  - 许多天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - 灰烬攻城车
    - 舞刃
    - 疯狂深渊
    - 强攻
    - 破坏者
    - 单手狂怒
    - 屠戮打击
    - 钢铁风暴
    - 暴捶
    - 泰坦之怒
    - 不羁狂野
    - 迷狂乱舞

:::

:::details 11.2版本
### 战士

- 断筋的公共冷却时间现在为0.75秒（原为1.5秒）。
- 修复了狂暴之怒能够驱散驱散射击的问题。
- 狂暴之怒的工具提示已略微调整，以说明其只对部分瘫痪效果生效。

#### 狂怒

- *开发者说明：狂怒在持续的范围伤害战斗中一直难以跟上节奏。这些改动旨在增强狂怒在这些情况下的表现。*
- 所有技能伤害提高5%。
- 剑刃风暴伤害提高15%。
- 旋风斩伤害提高10%。
- 强化旋风斩使你的单体攻击对附近最多4个目标造成65%的伤害（原为55%）。

:::

:::details 11.1版本
### 战士

- *开发者说明：我们认为战士的整体状态良好，但我们仍希望对每个专精以及整个职业进行一些改进。战士的生存能力尤其一直是一个弱点，而耐力训练在天赋树底层与强大的输出类节点竞争，导致很难投入点数。我们将耐力训练与强化护甲合并，把这个选择放到第二层，使其与其他实用性和生存类节点之间有更多选择空间，从而更容易分配点数。武器专精节点已增加到2点，以保持天赋树结构和整体天赋构筑消耗相近，同时对节点位置稍作调整，使各专精获取天神下凡的方式选择更加分明。*
- 强化护甲现在是一个2点天赋，每点提供5%耐力和5%护甲。
- 压倒性怒火现在是一个1点天赋，使怒气值上限提高30点。
- 双手武器专精（武器）现在是一个2点天赋，每点在持双手武器时提供3%伤害和2%的范围攻击伤害减免。
- 双持专精（狂怒）现在是一个2点天赋，每点在双持武器时提供3%伤害和2%的移动速度。
- 单手武器专精（防护）现在是一个2点天赋，每点提供3%伤害和2%的吸血。
- 声如雷鸣使你对受影响目标造成的流血伤害提高20%（原为30%）。
- 残忍打击、狂野打击和武器专精节点在天赋树中的位置已改变。
- 耐力训练已被移除。

#### 狂怒

- *开发者说明：狂怒 整体上处于我们满意的状态，我们借此机会重新设计了一些天赋，以保持其效果的独特性和强大。*
- 泰坦之怒已被重新设计——当 天神下凡 激活时，暴怒 的怒气消耗降低 20 点，且 嗜血 的冷却时间缩短 1.5 秒。
- *开发者说明：我们希望为 天神下凡 提供一个影响 狂怒 循环的新选项，并让你在 天神下凡 持续期间通过更多的暴怒和嗜血来获得最大收益。这一改动也让我们能够将 奥丁 的 狂怒 保持为一个独立于 天神下凡 的强大标志性 狂怒 技能。*
- 肆意放纵 已被重新设计——激活 鲁莽 会产生 50 点怒气，并且在 鲁莽 激活期间，怒击 和 嗜血 会被 碎甲猛击 和 浴血奋战 替换。碎甲猛击——一次强大的双武器打击，造成提高 20% 的爆击伤害。
- 浴血奋战——一次强大的攻击，对目标施加流血效果，再次施放时会延长其完整持续时间。
- *开发者说明：肆意放纵 对输出循环的影响过大，我们希望将该天赋的重心重新放回 鲁莽 上，并让 碎甲猛击 和 浴血奋战 成为具有独特附加效果的技能。*
- 所有技能伤害降低 5%。
- 嗜血 伤害提高 38%。
- 浴血奋战 立即伤害提高 38%。
- 怒击 伤害提高 44%。
- 碎甲猛击 伤害提高 44%。
- 暴怒 伤害提高 44%。
- 奥丁之怒 伤害提高 15%。
- 强攻 伤害提高 30%。
- 旋风斩 伤害提高 30%。

#### 山丘领主

- 雷霆轰击伤害提高25%。
- 山脉之力使嗜血和暴怒的伤害提高25%（原为30%）。

#### 斩杀者

- 殒命在即和死亡驱动现在正确要求选择猝死天赋后才能生效。
- *开发者说明：这是实现过程中的疏忽。屠戮者应当选择猝死天赋。*

:::

:::details 11.0.5版本
### 战士

- [[talent:112223]] 现在对超过5个目标（原为8个）造成降低的伤害。
- [[talent:112247]] 图标已更新。

#### 斩杀者

- [[spell:445836]] 现在最多叠加10层（原为12层）。

#### 狂怒

- [[talent:112265]]伤害提高25%
  
  - *开发者说明：此改动不影响[[talent:112284]]碎甲猛击。*
- [[talent:112261]]伤害提高30%。
  
  - *开发者说明：此改动不影响[[talent:112284]]浴血奋战。*
- *开发者说明：目前[[talent:112284]]在所有情况下都优于[[talent:112285@AJQABA]]，因此我们通过提高怒击和嗜血的基础伤害来拉近两者的差距，这同时也会改善狂怒的基础单体伤害。*
- [[talent:112212@AJQABA]] 现在使[[talent:112261]]的爆击伤害提高5/10%（原为爆击几率提高2/4%）。
- [[talent:112289]]现在对超过5个目标造成降低的伤害（原为8个）。

:::

:::details 11.0.2补丁
### 战士

- [[spell:23922]] 伤害提高8%。
- [[talent:112217]] 现在治疗你最大生命值的2%（原为3.5%）。

#### 狂怒

- [[talent:112262]]现在治疗最大生命值的10%（原为15%）。

:::

:::details 11.0版本
### 战士

- 所有天赋树中的许多天赋已经调整了位置或更新了连接路径。
- [[talent:118850]] 已经重新设计——[[talent:112128]]、[[talent:112264]]、[[spell:871]]、[[spell:6552]]、[[talent:112186]]、[[talent:112253]]和[[talent:112198]]的冷却时间缩短5%。
- [[talent:112190]] 获得了额外效果——当你的生命值低于35%时，每1秒恢复1.0%的生命值。你越接近死亡，恢复量越高（最高为2%）。
- [[spell:18499]] 现在于12级学习。
- [[spell:1464]] 伤害提高130%。武器 [[spell:1464]] 伤害加成降低至50%（原为75%）。
- [[spell:227847]] 伤害提高70%。
- [[spell:228920]] 伤害降低10%。
- [[spell:280721]] 现在可以叠加2次。
- [[spell:6343]] 怒气消耗降低至20点（原为30点），并且如果你已学会[[talent:112136]]，现在默认施加该效果。
- [[spell:215571]] 现在对武器和狂怒返还10%的怒气，对防护返还25%的怒气。
- [[talent:112242]] 施放时不再产生怒气。
- [[talent:112247]] 施放时产生10点怒气（原为20点）。
- [[talent:112223]] 施放时不再产生怒气。
- [[talent:112223]] 现在对8个以上目标造成的伤害降低。工具提示将在未来的更新中反映此改动。
- [[talent:112222]] 现在使[[talent:112223]]的流血效果提高目标受到的战士所有流血效果的伤害，而不是持续被动地提高。
- [[talent:112289]] 现在对8个以上目标造成的伤害降低。工具提示将在未来的更新中反映此改动。
- [[talent:112221]] 现在使[[talent:112223]]的冷却时间缩短45秒（原为30秒）。
- [[talent:112180]] 现在使你对被锁链连接到你的长矛的目标造成暴击伤害提高25%。
- [[talent:112246]] 现在提高[[talent:112247]]造成的所有伤害（原来仅提高初始伤害）。
- [[talent:112242]]的视觉效果现在将正确匹配其半径，无论是否选择了[[talent:112241]] 天赋。撞击视觉效果也已更新。
- [[talent:112223]]的视觉效果已调整。
- 修复了[[talent:112188]]使最大生命值提高15%而非预期的10%的问题。

##### 以下天赋已被移除

- 泰坦之掷
- 音爆
- 鲜血与雷霆

#### 狂怒

- 新天赋： [[talent:119112]]：[[spell:184361]] 使你的技能造成的伤害额外提高15%，并且 [[spell:184361]] 的持续时间延长1秒。与 [[talent:112267]] 处于同一选择节点。
- 飓风已被 [[talent:112257]] 取代 – 每当 [[talent:119139]] 或 [[talent:112256]] 造成伤害的每隔一次，你会对目标或附近的一名敌人施放 [[talent:112261]]。
- 狂怒 战士现在默认学会 [[talent:114644]]。
- 所有技能伤害提高49%。
- [[talent:112277]] 伤害提高26%。
- [[talent:112261]] 伤害提高29%。
- [[talent:112289]] 伤害提高33%。
- [[talent:112265]] 伤害提高10%。
- [[talent:112259]] 的 [[talent:112265]] 重置自身冷却几率提高至25%（原为20%）。
- [[talent:112284]] 现在会强化你的下一个 [[talent:112261]] 和 [[talent:112265]]。
- [[talent:112284]] 的 [[spell:335096]] 伤害降低26%，[[spell:335097]] 伤害降低3%。
- [[talent:112292]] 现在使 [[talent:112261]] 在你处于激怒状态时延长你的 激怒 效果0.5/1.0秒。
- [[talent:112286]] 现在还使 [[talent:112261]] 产生的怒气提高1.0/2.0点。
- [[talent:112212]] 现在使 [[talent:112261]] 的伤害提高10/20%，[[talent:112261]] 的爆击几率提高2/4%。
- [[spell:1464]] 的怒气消耗已移除。
- [[talent:112255]] 现在在激怒状态下使 [[talent:112259]] 重置 [[talent:112265]] 冷却的几率提高10%。
- [[talent:112292]] 不再降低 [[talent:112261]] 的冷却时间，改为每点使 [[talent:112261]] 的触发几率提高 [[spell:184361]]，每点提高 2%。
- [[talent:112294]] 不再延长 [[spell:184361]].
- [[talent:112274]] 现在由 [[talent:112265]] 触发 而不是 [[talent:112261]]。
- [[talent:119139]] 现在为 狂怒 的每次伤害事件产生10点怒气（配合 [[talent:112258]] 为20点）。
- [[talent:119139]] 现在是与 [[talent:112256]] 同一选择节点的天赋。所有现有的 [[talent:112256]] 子天赋均已更新，可同时适用于 [[talent:112256]] 以及 [[talent:119139]]。
- [[talent:112283]] 不再由 [[talent:112295]] 触发，且其触发几率降低至6%（原为20%）。
- [[talent:112227]] 的工具提示已更新详细信息。无功能性改动。
- [[talent:112226]] 的工具提示已更新详细信息。无功能性改动。
- 以下天赋已被移除：
  
  - 狂乱连击已被移除，其效果已并入一心狂怒。
  - 狂怒武装
  - 歼灭者
  - 剑刃风暴

:::

:::

## 常见问题

:::accordion
:::details 问：我可以解除[[talent:135597]]作为狂怒战士的绑定吗？
答：是的，在 12.0.5 版本中，[[talent:135597]] 现在可以通过 [[talent:112298@FAQAWKD]] 应用于 斩杀者，并通过 [[talent:112205@FAgAadhAEMA]] 应用于 山丘领主。

:::

:::

---

### 致谢

作者：**Revvez**

审校：**Meeres**

---

:::changelog 更新记录
**2026-06-17** 已针对 12.0.7 版本更新。

**2026-04-22** 更新了首领技巧和天赋构筑。

**2026-03-16** 更新了 最佳配装 列表。
更新了美化附加属性。
更新了饰品和种族 DPS 对比模拟。

**2026-02-20** 已针对 12.0.1 版本更新
攻略的几乎所有部分均已更新。

**2026-01-18** 已针对 12.0 版本更新。

**2025-12-02** 已针对 11.2.7 版本更新。

**2025-10-07** 已针对 11.2.5 版本更新。

**2025-08-01** 已针对 11.2 版本更新。

**2025-06-24** 已针对 11.1.7 版本更新。
更新了 最佳配装 列表。

**2025-04-21** 已针对 11.1.5 版本更新。
更新了 最佳配装 列表。
更新了饰品模拟。
对循环部分做了小幅调整。

**2025-02-23** 已针对 11.1 版本更新。

**2024-12-17** 已针对 11.0.7 版本更新。
更新了 最佳配装 列表。
更新了模拟。

**2024-10-22** 已针对 11.0.5 版本更新。

**2024-09-09** 调整了单体目标天赋。
对循环做了小幅调整。
调整了 最佳配装 列表。
更新了模拟。

**2024-08-17** 已针对 11.0.2 版本更新。

**2024-08-01** 攻略撰写于 11.0 版本。



:::
