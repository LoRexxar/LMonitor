欢迎来到魔兽世界12.1版本**奇袭 潜行者** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从80级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 3/5 · 中等

范围伤害 · 3/5 · 中等

功能性 · 3/5 · 中等

生存能力 · 4/5 · 强

机动性 · 4/5 · 强



:::

:::

:::column
:::gear **奇袭 潜行者** 团队副本 最佳配装
```json
{
  "source_code": "JUpAwT1ABc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOA_sOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADQgt7AECSAAkBwDYiqDIQrDAQBBwiIvsUABcJJEAACBAQBmBC3XQggIEAA1jbAKWgEAkdFSAgCBwGJOFQAf9BBAgwAAEQacUAABo0FCEAWBIRAChBWBEA24PAAFwAEOFQA1LSBECQBBQIHYFQANE6AGgQBESyA5OApqQgIvsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240892]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270168]] |  |
| 背部 | [[item:260312]] |  |
| 主手 | [[item:271093]] | [[item:243973]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为一名**奇袭 潜行者**，你可以使用不容动摇，它会使你的[[spell:32645]]伤害提高 10%，并且[[spell:32645]]每个连击点恢复 2 点能量。

**等级 2**使你的自然伤害和流血伤害提高 20%。

而**等级 3**则使你的[[spell:192759]]生成 6 个连击点。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-assassination-mxr.webp>)

冷酷无情

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

专精天赋树有很多改动。

- **专精天赋树**
  
  - [[talent:117139]]
    
    - 不再是持续伤害效果，而是将你的[[spell:703]]和[[spell:1943]]同时施加给附近2个敌人。
  - [[talent:112660]] / [[talent:134835]]。
    
    - 这两个都相当强力。[[talent:112660]]是一个不错的增伤，尤其在范围伤害中，而[[talent:134835]]在连击点生成方面表现出色。
  - [[talent:117130]]
    
    - 在你的[[talent:112663]]结束后提供急速加成。
  - [[talent:112672]]
    
    - 现在是一个独立天赋。
  - [[talent:112511]]
    
    - 在你的[[talent:112662]]期间提供额外增伤。
  
  
  
  - [[talent:112673]]
    
    - 使[[spell:703]]的持续时间延长6秒。

- **职业天赋树**
  
  - [[talent:112636]]
    
    - 敏捷提高3%。
  - [[talent:112639]]
    
    - 不再是一个主动技能，现在由你的技能生成触发，并使你的下一个终结技爆击几率提高10%。
  - [[talent:112644]]
    
    - 由你的[[spell:5171]]提供额外攻击速度。
- **已移除**
  
  - [[spell:324073]]
  
  
  
  - [[spell:455143]]
  - [[spell:170882]]
  - [[spell:341534]]
  - [[spell:455131]]
  - [[spell:400783]]
  - [[spell:381802]]
  - [[spell:394983]]
  - [[spell:255989]]
  - [[spell:200806]]
  - [[spell:340078]]
  - [[spell:273488]]
  - [[spell:381634]]

## 英雄天赋

:::tabs
:::tab [[talent:123375]]
- 你的 [[spell:703]] 会为目标标记 3 层 [[talent:117733]]。 
  
  - 你只能同时激活 1 个 [[talent:117733]]。
  - 消耗一层[[talent:117733]]，需使用一个5 连击点 或更高星级的终结技。
  - 你只能通过 [[spell:703]] 施加 [[talent:117733]]

- 在消耗掉最后一层[[talent:117733]]之后，或者当某个小怪在[[talent:117733]]生效期间死亡时，你会获得[[talent:117739]]。
  
  - 当 [[talent:117739]] 生效时，务必让下一个终结技为 [[spell:32645]]，并消耗 7 点 连击点.
  
  
  
  - 当你消耗[[talent:117739]]时，你会对你当前目标小怪施加[[talent:117733]]。
- 借助[[spell:1293340]]，你可以手动将你的[[talent:117733]]转移到另一个小怪身上。

此外，天赋树中还有几个重要的顶级天赋。

- [[talent:117707]]
- [[talent:117732]]。
- [[talent:126029]]
  
  - 一个防御节点，使[[talent:112657]]更加强力。[[talent:117703]]也很有意思，但更依赖具体战斗情况。
- [[talent:136020]]
  
  - 被动暴击加成。
- [[talent:136019]]
  
  - 每次施加印记时带来一点额外效果，但实际上影响不大。
- [[talent:136018@AJAB]]
  
  - 在范围伤害或多目标场景中增加一些额外伤害，忽略你的主目标。
- [[spell:457055]]
  
  - 为你的主目标提供一点额外的伤害汇聚。

:::

:::tab [[talent:123371]]
- 与 [[talent:123375]] 树中类似，你每使用一个 5 连击点或以上的终结技，都有机会进行一次掷硬币。
  
  - 落在 [[spell:452923]] 时，你的伤害提高 10%。后续落在 [[spell:452923]] 的掷硬币额外提高 2% 伤害。 —— 可叠加
  - 落在 [[spell:452538]] 时造成宇宙伤害。后续掷硬币使 [[spell:452538]] 的伤害提高 10%。--- *可叠加*
- [[talent:117724]]
  
  - 每进行 7 次掷硬币，你将获得一个 4% 的敏捷增益，此外：
    
    - [[spell:452923]] 和 [[spell:452923]] 两项加成均提高 50%。
    - 掷硬币有 15% 的更高概率与上一次掷硬币结果相同。

这些掷硬币在玩法上都没有太大意义，你完全可以不追踪它们，但你可以在命缚者树中通过天赋进行一些极限优化。

- [[talent:117736]].
  
  - 在你使用[[talent:112662]]之后，两个翻转都会重新刷新。
- [[talent:117717]]
  
  - 使你的[[talent:112672]]伤害提高5%。
- [[talent:136025]]
  
  - 被动暴击。
- [[talent:136026]]
- [[talent:136024]]

:::

:::

## 天赋

:::tabs
:::tab [[talent:123375]] 单目标
:::talents [[talent:123375]] **奇袭 潜行者** 团本中的单目标天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYxsMwAWC2GmADLGMzAMGD",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYxsMwAWC2GmADLGMzAMGD"
}
```
:::

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 专精树

- [[spell:381798]] 
  
  - 这是你的斩杀天赋。在理想情况下，战斗中你总应至少与它配合使用一轮爆发冷却技能。如果战斗剩余时间内你只能再使用一次[[spell:360194]]，建议将其留到首领血量降至 35% 或以下时使用。
- [[spell:385627]]
  
  - 你的短冷却爆发技能。与[[spell:360194]]每两分钟配合使用时尤为强力。
- [[spell:360194]]
  
  - 你的大冷却技能。使你的[[spell:703]]、[[spell:1943]]以及目标身上致命毒药的伤害提高 100%，同时使你的致命毒药可以叠加两层。
- [[talent:117131]]
  
  - 使你可以额外使用一种致命毒药。
- [[talent:112679]]
  
  - 这是一个可以为你节省大量能量的触发效果，因为它使你的下一个[[spell:8676]]免费。在斩杀范围内效果尤其出色，因为触发频率更高。
- [[talent:112649]]
  
  - 有助于为你积攒连击点来释放终结技，这也是为什么爆击对你来说是优秀属性的原因之一。
- [[talent:134835]]。
  
  - 这个天赋在连击点生成方面非常出色。

#### 职业树

- [[talent:112648]]
- [[talent:112655]] / [[talent:112656]]
  
  - 在团队副本环境下，[[talent:112655]]始终是你的首选，除非你拥有超过1名潜行者。它提供的减伤效果，再加上[[talent:112521]]，实在过于强大。另一方面，[[talent:112656]]会与其他职业的同类技能叠加，因此是较差的选择。
- [[talent:114737]] / [[talent:112632]]
  
  - 对于团队副本，除非另有说明，通常推荐使用[[spell:31230]]。

#### 英雄天赋

- [[talent:117706]]
  
  - 明显优于 [[talent:126030]]。
- [[talent:117720]]
  
  - 当你需要频繁移动时，它非常有用。而替代选项 [[talent:126027]] 的收益则不大，尤其是在团队副本环境中。
- [[talent:126029]]
  
  - 这是我们技能组中非常棒的补充，让 [[talent:112657]] 在团队副本环境中变得有用。
  - [[talent:117703]] 如果你在应对特定机制时需要更长的 [[talent:112585]]，它也可以表现不错。

### 毒药

- 此构筑使用以下毒药：
  
  - [[talent:112676]]
  - [[talent:112670]]
  - [[talent:112655]] -或- [[talent:112656]]。

:::

:::tab [[talent:123375]] 顺劈斩
:::talents [[talent:123375]] **奇袭 潜行者** 团队副本中的范围伤害天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhFDmZwMzYMA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhFDmZwMzYMA"
}
```
:::

### 何时使用该专精

如果你在战斗的大部分时间内面对3个或更多敌人，请使用此专精。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 专精树

- **新增**
  
  - [[talent:117139]]
  - [[talent:112672]]
- **移除**
  
  - [[talent:112519]]
  - [[talent:117137]]

:::

:::tab [[talent:123371]] 单目标
:::talents [[talent:123371]] **奇袭 潜行者** 团队副本中的单目标天赋。
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxYbmZmtZWmZmBjZmxYmxwAsMzyYhxMmlGzy2wkthhNDmZwMzYM",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxYbmZmtZWmZmBjZmxYmxwAsMzyYhxMmlGzy2wkthhNDmZwMzYM"
}
```
:::

#### 命缚者变体。

:::

:::tab [[talent:123371]] 顺劈斩
:::talents
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhNDmZwMzYMA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsMzyYhxMmlGz22wkthhNDmZwMzYMA"
}
```
:::

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:32645]] 伤害提高10%，并使你造成的伤害提高3%。
- **4件套：** [[spell:2818]] 使你在目标身上的流血伤害提高10%。对带有你 [[spell:381664]] 的目标进行自动攻击时，每层造成伤害提高3%。[[spell:8679]] 会进行第二次攻击。

### 单体目标

:::tabs
:::tab [[talent:123375]]
### 起手爆发

- 你的目标是维持 [[spell:32645]]。下面是一个示例，展示你在使用推荐的**单体**天赋配装

:::rotation [[talent:123375]] **奇袭 潜行者** 在团本中的单体起手手法
```json
{
  "source_code": "J0GELI0vCAQABggQxUQAHwAACd5BJgQEQkAIQIQAc66ABkBTB81HEAADCAAWCKQBAEgSXIgQF-XAYABACJwfFEQCMI09wLQBIEBGkETBAAAAAAgQF-H"
}
```
1. [[spell:703]]
2. [[spell:1329]]
3. [[spell:1943]]
4. [[spell:1329]]
5. [[spell:703]]  [[item:241308]] · [[item:270175]]
6. [[spell:32645]]
7. [[spell:360194]]
8. [[spell:192759]]
9. [[spell:32645]]
10. [[spell:1329]]
11. [[spell:32645]]
:::

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. [[spell:703]] 第一个全局冷却用于施加 [[talent:117733@AJAB]]。
2. 在整个战斗中保持 [[spell:1943]] 和 [[spell:703]]。
   
   1. 不要覆盖你的 [[talent:112673]]，而是在带有增益的那个失效后立即施加 [[spell:703]]。
3. 始终在7层时使用 [[spell:32645]] 连击点 在 [[talent:117739]] 生效期间。
4. 在你的 [[spell:360194]] 和 [[spell:385627]] 冷却完毕前准备好刷新你的流血效果，当它们的冷却时间还剩大约 8 秒时就开始为此做准备。
5. 如果不在5层，则按下 [[spell:1329]] 连击点.

:::

:::tab [[talent:123371]]
### 起手爆发

- 你的目标是在整个冷却技能持续期间保持 [[spell:32645]] 和 [[spell:5938]] 生效。下面是一个示例，展示你在使用推荐的**单体**天赋配装时的起手手法。
- *这是* [[talent:123371]] 起手手法的一种变体，更多信息请参阅**深度解析**章节。

:::rotation [[talent:123371]] **奇袭 潜行者** 在团本中的单体起手手法
```json
{
  "source_code": "J0GELI0vCAQABggQxUQAHwAACd5BJgQEQkAIQIQAc66ABkBTB81HEAADCAAWCKQBAEgSXIgQF-XAYABACJwfFEQCMI09wLQBIEBGkETBAAAAAAgQF-H"
}
```
1. [[spell:703]]
2. [[spell:1329]]
3. [[spell:1943]]
4. [[spell:1329]]
5. [[spell:703]]  [[item:241308]] · [[item:270175]]
6. [[spell:32645]]
7. [[spell:360194]]
8. [[spell:192759]]
9. [[spell:32645]]
10. [[spell:1329]]
11. [[spell:32645]]
:::

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在整个战斗中保持 [[spell:1943]] 和 [[spell:703]]。
   
   - 不要覆盖你的 [[talent:112673]]，而是在带有增益的那个失效后立即施加 [[spell:703]]。
2. 一冷却完毕就准备好使用你的 [[spell:360194]] 和 [[spell:385627]]，当它们的冷却时间剩余约 8 秒时，就开始为此做准备。
3. 使用 [[spell:32645]] 配合 5 层 连击点.
4. 如果不在5层，则按下 [[spell:1329]] 连击点 不使用 [[talent:112525]]。

:::

:::

### 多目标

:::tabs
:::tab [[talent:123375]]
*在多目标战斗中，指的是战斗中偶尔刷新小怪的战斗，你的循环和构筑基本保持不变。唯一需要注意的是 [[spell:421975]]*，*以及在某些情况下的 [[talent:112517]]*。

- 如何利用 [[spell:421975]]：
  
  - [[spell:421975]] 会从你的目标进行顺劈，与 [[spell:13877]] 不同。
  
  
  
  - 留意你的目标身上的 [[spell:421975]] 减益效果。在它消失前刷新。
  - [[spell:360194]] 和 [[spell:385627]] 会增强你的 [[spell:421975]] 伤害。始终将它们用在能够存活完整持续时间的小怪身上。

### 起手爆发

:::rotation [[talent:123375]] **奇袭 潜行者** 团本中的多目标开场
```json
{
  "source_code": "IEFEKI0vCAQABggQLocAHwAACd5BJgQEYAy-HMBAAIwMUBQDKQQNUlBLIU4fAEQAsIkA_VAAAAAACdP8CA"
}
```
1. [[spell:703]]
2. [[spell:51723]]
3. [[spell:1943]]
4. [[spell:703]]
5. [[spell:1247227]] 3T
6. [[spell:1247227]] 5T
7. [[spell:51723]]
8. [[spell:32645]]
9. [[spell:360194]]
10. [[spell:192759]]
:::

### 多目标优先级列表

1. [[spell:703]] 第一个全局冷却用于施加 [[talent:117733@AJAB]]。
2. 在整个战斗中保持 [[spell:1943]] 和 [[spell:703]]。
   
   1. 不要覆盖你的 [[talent:112673]]，而是在带有增益的那个失效后立即施加 [[spell:703]]。
3. 始终在7层时使用 [[spell:32645]] 连击点 在 [[talent:117739]] 生效期间。
4. 在你的 [[spell:360194]] 和 [[spell:385627]] 冷却完毕前准备好刷新你的流血效果，当它们的冷却时间还剩大约 8 秒时就开始为此做准备。
5. 如果不在5层，则按下 [[spell:1329]] 连击点.

:::

:::tab [[talent:123371]]
*在多目标战斗中（指战斗过程中会不时刷新小怪的战斗），你的循环和构筑基本保持不变。唯一需要注意的是 [[spell:421975]]，以及在某些情况下的 [[talent:112517]]。*

1. 如何运用 [[spell:421975]]：
   
   - [[spell:421975]] 会从你的目标进行溅射，这与 [[spell:13877]] 不同。
   
   
   
   - 留意你目标身上的 [[spell:421975]] 减益效果，在其消失之前进行刷新。
   - [[spell:360194]] 和 [[spell:385627]] 会增强你的 [[spell:421975]] 伤害。务必将它们用在能存活完整持续时间的小怪身上。

### 起手爆发

:::rotation [[talent:123371]] **奇袭 潜行者** 团本中的多目标开场
```json
{
  "source_code": "IEFEKI0vCAQABggQLocAHwAACd5BJgQEYAy-HMBAAIwMUBQDKQQNUlBLIU4fAEQAsIkA_VAAAAAACdP8CA"
}
```
1. [[spell:703]]
2. [[spell:51723]]
3. [[spell:1943]]
4. [[spell:703]]
5. [[spell:1247227]] 3T
6. [[spell:1247227]] 5T
7. [[spell:51723]]
8. [[spell:32645]]
9. [[spell:360194]]
10. [[spell:192759]]
:::

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在整个战斗中保持 [[spell:1943]] 和 [[spell:703]]。
   
   - 不要覆盖你的 [[talent:112673]]，而是在带有增益的那个失效后立即施加 [[spell:703]]。
2. 一冷却完毕就准备好使用你的 [[spell:360194]] 和 [[spell:385627]]，当它们的冷却时间剩余约 8 秒时，就开始为此做准备。
3. 使用 [[spell:32645]] 配合 5 层 连击点.
4. 如果不在5层，则按下 [[spell:1329]] 连击点 不使用 [[talent:112525]]。

:::

:::

## 深度解析

### 何时刷新你的锁喉和割裂

- 由于[[spell:169629]]已从 **奇袭潜行者中移除**，你不再能够快照你的流血效果，唯一的例外是在使用[[talent:112673]]时的[[spell:703]]。因此，在刷新[[spell:703]]时，你需要遵循以下几条规则。
  
  - 如果你当前的[[spell:703]]带有[[talent:112673]]的增益，不要覆盖它，让它自然到期后再重新施加。
  - 如果你当前的[[spell:703]]没有[[talent:112673]]的增益，且你没有冷却技能正在运行，并且它剩余时间少于5.2秒，就刷新它。
- 由于[[spell:1943]]是一个基于 连击点 基于终结技，它使用灵活的传染机制。这意味着无论有多少 连击点 施加的，疫情延长机制都会根据新一次施放[[spell:1943]]所用的 连击点 次新施放的[[spell:1943]]。以下列表是获得最佳刷新效果时应遵循的规则：
  
  - 如果你当前拥有5个 连击点，你可以在剩余7.2秒或更少时安全地刷新[[spell:1943]]。
  - 如果你当前拥有6个 连击点，你可以在剩余8.4秒或更少时安全地刷新[[spell:1943]]。
  - 1: 2.4s
  - 2: 3.6s
  - 3: 4.8s
  - 4: 6s
  - 7: 9.6s
  - 8: 10.8s
  - 9: 12s
  - 10: 13.2s

### 最大化你的死亡印记与君王之灾爆发窗口。

- [[spell:32645]]在你的冷却技能期间必须保持100%的覆盖率。

在开局起手之外，你2分钟冷却技能的使用方式非常相似，在为[[spell:360194]]做准备时，这是最重要的规则：

1. 如果你在按下[[spell:360194]]时流血效果剩余时间不超过18秒，务必先刷新你的流血效果。具体来说：
   
   - 在6秒或以上时刷新你的[[spell:1943]] 连击点.
   
   
   
   - [[spell:1329]]到6秒时 连击点 然后在按下你的[[spell:360194]]之前先使用[[spell:32645]]。

下面是一个在战斗中途正确使用[[spell:360194]]的示例（**在团本中**）。

:::rotation **奇袭 潜行者** 中作为[[talent:123375]]  的冷却技能使用
```json
{
  "source_code": "IQFEKI0lHAQABggQ_KQAHwAACFTBugAAsEQAc66AAAAAAIUh_FwBMAgQC8XBhggQ3DfBxUBGkETBAAAAAAgQxUA"
}
```
1. [[spell:1943]]
2. [[spell:703]]
3. [[spell:1329]]
4. [[spell:1329]]  [[item:241308]]
5. [[spell:32645]]
6. [[spell:360194]]
7. [[spell:192759]]
8. [[spell:32645]]
9. [[spell:1329]]
10. [[spell:1329]]
:::

- **这不是一套固定的循环**；这只是你的[[spell:360194]]窗口期内的一个打法示例。[[spell:111240]]触发和暴击可能会改变技能的使用顺序。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **奇袭 潜行者** 内克扎莉 天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

### 首领攻略技巧

- 注意[[spell:1284103]]的计时条，切勿站在首领与其技能目标坦克之间。
- 提前观察小怪的尸体位置，以便更轻松地应对[[spell:1294742]]净化它们的减益效果。

:::

:::tab 陵寝哨兵
:::talents **奇袭 潜行者** 陵寝哨兵 天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZmZwMzMjxMDjBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZmZwMzMjxMDjBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

### 首领攻略技巧

- 注意观察首领的能量，在其即将达到100时务必分散站位，这样能让转阶段阶段更加轻松。
- 总体而言，要留意自己的站位，尽量贴近首领输出，这样就不用担心[[spell:1284494]]和[[spell:1284503]]的层数问题。
- 查看团队框架，在转阶段阶段使用你的[[spell:36554]]来清除叠加的增益效果。

:::

:::tab 迷失的探险者
:::talents **奇袭 潜行者** 迷失的探险者天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB"
}
```
:::

### 首领攻略技巧

- 注意[[spell:1296062]]，尽量把它们引到房间外围。
- 不要过度吸收[[spell:1291934]]，因为它会给你施加一个不断叠加的**流血**负面效果。
- 小心[[spell:1292105]]产生的蘑菇，因为它们在使用一次后就会被消耗掉。

:::

:::tab 瓦什尼克
:::talents **奇袭 潜行者** 瓦什尼克天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB"
}
```
:::

### 首领攻略技巧

- 每当 [[spell:1281907]] 减益效果即将到来时，务必提前分散，并尽可能不要将它对准首领。
- 请记住，击杀 **燃烧毒液** 会给你叠加一层减益效果，所以要避免同时击杀它们。

:::

:::tab 斯索拉克
:::talents **奇袭 潜行者** 斯索拉克 天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDGzMjxMjhBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

### 首领攻略技巧

- 如果你找不到队友来处理[[spell:1285419]]，请记住你也可以用[[spell:36554]]或[[spell:31224]]来化解它。
- 当你被[[spell:1287072]]命中时使用防御冷却技能，因为它会对你施加一个可叠加的**中毒**负面效果。

:::

:::tab 双牙
:::talents **奇袭 潜行者** 双牙天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZm5BwMzMzMMzYMALzsMWYMjZpxstNMZbYYxgZGMzMGDA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGmZmZbmlZm5BwMzMzMMzYMALzsMWYMjZpxstNMZbYYxgZGMzMGDA"
}
```
:::

- 在这场战斗中，拥有一个良好的负面效果监控手段极其重要，因为[[spell:1290336]]在达到一定层数后必定会致死，具体层数取决于难度。
- 当你成为[[spell:1291478]]的目标时，尽量不要到处乱跑。如果需要躲避什么，最好沿自己的直线移动。
- 别忘了吸收[[spell:1290516]]也会将你击退，所以在那期间要小心[[spell:1290956]]产生的波纹。
- 每当[[spell:1294293]]发生时，观察场地中央的**维克苏尔** ，你会发现有一些围绕他旋转的小球，它们指示了他施放光束的方向。

:::

:::tab 盘绕祭坛
:::talents **奇袭 潜行者** 盘绕祭坛天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

- 小心 [[spell:1282403]]，如果有需要，确保协助将它们移动到别处。
- 要格外注意 [[spell:1285643]] 之后刷新的幽灵，因为处理它们将是这个阶段最难的部分。
  
  - 即使你没有被幽灵点名，也请确保不要停留在它们附近，因为它们会被 [[spell:1286620]] 的正面劈砍清理掉，这是消灭它们的唯一办法。
- 每当你被 [[spell:1286895]] 点名时，使用一个防御冷却技能。

:::

:::tab 乌拉特克
:::talents **奇袭 潜行者** 乌拉特克 天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmtZwAAAAAAzyglZAAAAAAttNmZmZmxwMzMbzsMzMDmZmZMmZgBYZmlxCjZMLNmtthJbDDLGMzgZmxYA"
}
```
:::

:::

:::tab 尼姆瑞莎·唤波者
:::talents **奇袭 潜行者** 尼姆瑞莎·唤波者 天赋
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HPzsMmNDGAAAAAYWGsMDAAAAAottxMzMzMGLzMzsNzyMz8AYmZmxYmZMGglZWGLMmxs0Y22GmsNMsYwMDmZGjB"
}
```
:::

- 请记住，[[spell:1258673]]发生后[[spell:1258150]]会把你从中部击退，因此要相应地站位，或准备好用[[spell:36554]]来化解击退效果。
- 每当[[spell:1281393]]被触发时，使用一个防御冷却技能。

:::

:::

## 属性优先级

作为**奇袭 潜行者**，了解你的次要属性优先级以及在团队副本首领战斗中获得最佳表现所需的第三属性。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **奇袭 潜行者** 团队副本中的属性优先级
```json
{
  "source_code": "IoAJFMAIkEDKBMwABA"
}
```
**敏捷 ＞ 暴击 ≥ 急速 ≥ 精通 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可减少“**范围效果**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外的治疗。
- **加速** - 小众副属性，但可能非常有用，过去已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取来源 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | 乌拉特克 |
| 颈部 | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | 乌拉特克 |
| 肩部 | [[item:271508@DwQAAMQAXk74kgC4UA]] | 迷失的探险者 / 催化 |
| 披风 | [[item:251190@BgQAAMQACKgTBA]] | 夺目谷 |
| 胸部 | [[item:271513@DgQAAMQAJk7IoAOF]] | 万毒邪祟者瓦什尼克 / 催化 |
| 护腕 | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | 制造业 |
| 手套 | [[item:271511@BgQAAMQACKgTBA]] | 陵寝哨兵 / 催化 |
| 腰带 | [[item:268256@BiQAAMQAS06IoAYF]] | 盘卷祭坛 |
| 腿部 | 将 [[item:268225@AgQAAIoAYFA]] 转化为 [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | 盘卷祭坛 的催化 |
| 靴子 | [[item:268261@DgQAAMQAPk7IoAOF]] | 双子毒牙 |
| 戒指 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | 斯索拉克 |
| 戒指 2 | [[item:268249@DiQAAMQA1j7oQrjgC4UA]] | 万毒邪祟者瓦什尼克 |
| 饰品 1 | [[item:270175@BwgAAMQAYJoAFAQAKdhA]] | 乌拉特克 |
| 饰品 2 | [[item:270168@BgQAAMQACKAWBA]] | 乌拉特克 |
| 武器 | [[item:271093@DgQAAMQADk7IoAYF]] | 乌拉特克 |
| 武器 | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | 制造业 |

奇袭 潜行者 团本中的 最佳配装 列表

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | 毒牙祭坛 |
| 颈部 | [[item:273781@BiQAAMQAH16IoABF]] | 毒牙祭坛 |
| 肩部 | [[item:251223@DgQAAMQAXk7IoABF]] | 虚空之痕竞技场 |
| 披风 | [[item:251190@BgQAAMQACKQQBA]] | 夺目谷 |
| 胸部 | [[item:251159@DgQAAMQAJk7IoABF]] | 纳洛拉克的洞穴 |
| 护腕 | [[item:251135@BiQAAMQAU06IoABF]] | 密谋小径 |
| 手套 | [[item:251124@BgQAAMQACKQQBA]] | 密谋小径 |
| 腰带 | [[item:159317@BiQAAMQAE06IoABF]] | 塞塔里斯神庙 |
| 腿部 | [[item:251130@DgQAAMQAhu7IoABF]] | 密谋小径 |
| 靴子 | [[item:159327@DgQAAMQAPk7IoABF]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:158366@DiQAAMQA1j7wPrjgCEUA]] | 塞塔里斯神庙 |
| 戒指 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | 毒牙祭坛 |
| 饰品 1 | [[item:250215@BgQAAMQACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250259@BgQAAMQACKQQBA]] | 夺目谷 |
| 武器 | [[item:275070@DgQAAMQADk7IoABF]] | 毒牙祭坛 |
| 武器 | [[item:275070@DgQAAMQADk7IoABF]] | 毒牙祭坛 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgwAAMQACKAWBUAABo0FCA]] |
| **A级** | [[item:270168@BgQAAMQACKAWBA]]  <br>[[item:270173@AgQAAIoAYFA]] |
| **B级** | [[item:270164@AgQAA8rBOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **C级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **垃圾级** | [[item:270166@AgQAAIoAOFA]]  <br>[[item:159617@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]] |

### 美化饰品

- [[item:273059]]
- [[item:240166]]

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **合剂**
  
  - [[item:241326]] *——最大化DPS*。
  
  
  
  - [[item:241320]] *——DPS略低但生存能力更强。*
- **食物**
  
  - [[item:266985]]
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240898]]
  - [[item:240914]] x1
  - [[item:240906]] x1
  - [[item:240890]] x1
  - [[item:240966]] *——唯一装备，每种颜色的宝石各使用一颗，以增强你的[[item:240966]]。*
- 一如既往，请对你的角色进行模拟，以检查当前装备下的最佳宝石。

### 附魔

:::columns
:::column
| 头部 | [[item:275707@DAAAAMQAnk7A]]- [[item:243949]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAMQA]] |
| 披风 |  |
| 胸部 | [[item:243977@BAAAAMQA]] |
| 护腕 | [[item:275707@DAAAAMQAnk7A]] |
| 腰带 | [[item:275707@DAAAAMQAnk7A]] |
| 腿部 | [[item:244641@BAAAAMQA]] |
| 靴子 | [[item:244009@BAAAAMQA]] |
| 戒指1 | [[item:243957@BAAAAMQA]] |
| 戒指2 | [[item:243957@BAAAAMQA]] |
| 武器 | [[item:243973@BAAAAMQA]] |
| 武器 | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **奇袭 潜行者** 团队副本中的附魔
```json
{
  "source_code": "JwFZDEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCoUQuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> 你可以从宏伟宝库商贩处购买[[item:275707@DAAAAMQAnk7A]]，为你的**头盔**、**护腕** & **腰带**添加插槽。

## 种族

对于以 **奇袭 潜行者** 进行团队副本极限优化（min-max）而言，不同的种族特性可以为你的角色带来巨大的收益。如果这并非你的首要目标，选择一个符合你风格的种族也同样可行。

- [[spell:65116]] -- 矮人
  
  - 驱散魔法和流血负面效果。在过去某些有流血机制的首领战中非常有用。
- [[spell:69070]] -- 地精
  
  - 朝角色面向的方向进行一次小跳。
  - 在你处于 [[spell:69070]] 动画期间，你会进入公共冷却，直到你的角色落地为止。
- [[spell:26297]] *-- 巨魔* 
  
  - 强大的输出型种族技能，但与 [[talent:112662]] 的契合度不佳
- [[spell:33702]] *-- 兽人* 
  
  - 非常强力的伤害型种族技能，由于会随等级缩放且与你的 [[talent:112662]] 相契合，目前极具竞争力。
  - 使你受到的昏迷时间缩短20%，在某些情况下很有用。
- [[spell:256948]] -- 虚空精灵
  
  - 朝面向方向释放一道暗影并在其中穿行，再次激活即可传送到该位置。
  - 最大距离为100码。
- [[spell:255669]] -- 虚空精灵
  
  - 不错的被动特性。
- [[spell:312923]] -- 机械侏儒
  
  - 相当强力的被动特性，且会随等级缩放，因此现在表现得非常出色。

:::columns
:::column


:::

:::

### 推荐

总体而言，可以说如果你在乎将输出极限化（min-max），就应该选择输出最高的种族技能。不过，如果是开荒团队副本，情况就有些不同了。某些种族技能能极大加快特定首领的开荒进度。例如，矮人 凭借其 [[spell:65116]]，在争夺世界第一的比赛中，能够在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键时刻轻松驱散自身的负面效果，从而提供了巨大帮助。

## 宏

了解 奇袭 潜行者在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:703]]** -- *对你的鼠标指向目标或当前目标施放 [[spell:703]]。*

```wow-macro
#showtooltip 锁喉
/cast [@mouseover,exists] 锁喉;锁喉
```

**[[spell:1943]]** -- *若你的鼠标指向目标存在、未死亡且为敌对，则对其施放 [[spell:1943]]，否则对你的当前目标施放 割裂*。

```wow-macro
#showtooltip
/cast [@mouseover,exists,nodead,harm] 割裂;割裂
```

*当你将鼠标指向某个怪物时，将其设为**焦点**并 **在其身上放置标记**。这非常适合让你的队友知道你打算对什么目标使用你的* **[[spell:1766]]*****。***

```wow-macro
/focus [@mouseover][]
/run SetRaidTarget("mouseover",6)
```

**[[spell:36554]]** *施放在你的鼠标指向目标身上*

```wow-macro
#showtooltip 暗影步
/cast [@mouseover] 暗影步
```

*鼠标指向* **[[spell:1766]]***，如果你更倾向这种方式而非焦点目标的话。*

```wow-macro
#showicon 脚踢
/cast [target=mouseover] 脚踢
```

:::

:::details 焦点目标宏
**[[spell:36554]] + [[spell:1766]]***施放在你的焦点目标怪物身上。这个宏可用作“远程”[[spell:1766]]。*

```wow-macro
/cast [@focus] 暗影步
/cast [@focus] 脚踢
```

**[[spell:1766]]** *你的焦点目标*

```wow-macro
#Show 脚踢
/cast [target=focus] 脚踢
```

*将* **[[talent:112631]]** *施放在你的焦点目标身上*

```wow-macro
#showicon 凿击
/cast [target=focus] 凿击
```

*焦点* **[[spell:408]]** *作为额外控制*

```wow-macro
#showicon 肾击
/cast [@focus] 肾击
```

*焦点* **偷袭**

```wow-macro
#showicon 偷袭
/cast [@focus] 偷袭
```

---

:::

:::details 实用 宏
**[[spell:360194]]** + **[[spell:10060]]** **宏** - *将 "Rycn-Tarrenmill" 和 "请给我能量灌注" 替换为给你能量灌注的牧师的名字，以及他们告知你的其能量灌注宏的触发词。*

```wow-macro
#show 死亡印记
/w Rycn-TarrenMill 请给我能量灌注
/cast 死亡印记
```

*在这个宏中，你可以将名字替换为你队伍中的坦克，从而让使用* **[[talent:112574]]** *变得更加轻松。*

```wow-macro
#show 嫁祸诀窍
/cast [@Meeresdh] 嫁祸诀窍
/cast [@Meeresmana] 嫁祸诀窍
/cast [@Méèrès] 嫁祸诀窍
```

:::

:::

## 插件

下方是作者的 **奇袭 潜行者** 用户界面截图，其中说明了使用了哪些插件，以及它们在团队副本中如何使用，从而让你的游戏体验更加轻松。

![](<https://i.gyazo.com/737a316d3f0b0d850b3ce2b4b3e1f6af.jpg>)

**奇袭 潜行者** 界面

:::accordion
:::details 插件
- **Ellesmere UI** *—— 完整的用户界面替换插件* 
  
  - 一款以用户友好为核心设计的界面插件，附带标准界面中不具备的额外功能。
  - 此外，你也可以使用 Shadowed Unit Frames (SUF) 搭配任意动作条插件，当然也可以使用原生界面。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 职业
  
  - 蓟叶茶 现在是一个选择型天赋——玩家现在可以在现有版本（在能量较低时自动施放，同时也可主动使用）和一个必须主动施放的新版本之间进行选择。
  - 萎缩药膏 现在使造成的伤害降低4%（原为3%）。
  - 萎缩药膏 的持续时间延长至60秒（原为10秒）。在PvP战斗中持续时间保持不变。
- 英雄天赋
  
  - 命缚者
    
    - 命运裁决在你 封印命运 时额外获得一个连击点的几率现在为60%（原为100%）。
  - 死亡猎手
    
    - 修复了一个导致不动之驱的加成会随每层叠加相乘的问题。
    - 修复了一个经常导致不动之驱在每次使用技能时移除多于一层的问题。
- 奇袭
  
  - 开发者说明：我们正在对 奇袭 在 乌拉特克 诅咒中的能量机制进行一些更新。我们对1阶“不屈”顶点天赋的表现不满意——为了最优玩法而故意让 ⟦WOWTERM_00010⟫ 掉落是不直观的。我们正在更新其设计，使较晚刷新 ⟦WOWTERM_00010⟫ 始终是最佳玩法，并赋予其稳定的能量恢复价值。我们还在进行一些旨在增加天赋build选项的改动。
  - 新天赋：不稳定毒素——毒伤 的伤害提高18%，但其持续时间缩短2秒。
  - 顶点天赋：不屈（1阶）已更新——毒伤 的伤害提高10%。毒伤 现在每消耗一个连击点恢复2点能量。
  - 顶点天赋：不屈（3阶）——不屈打击的伤害提高15%。
  - 内出血已更新——现在由施放 肾击 和 割裂 触发，而不再是在用 猩红风暴 复制割裂时施加。伤害提高10%。
  - 铁丝网已更新——从潜行状态施放或在 强化锁喉 窗口期间施放的绞喉现在会使目标沉默5秒。减伤机制不变。
  - 亡命之徒已更新——毒伤 的效果现在还会使你的武器毒药的爆击几率提高10%（原为5%）。你的武器上每有一种致命药膏，能量生成提高4%。
  - 造成的所有伤害提高20%。
  - 死亡印记 使你的 割裂、锁喉 和致命药膏的伤害提高75%（原为100%）。
  - 君王之灾 的伤害降低15%。
  - 遮蔽窒息使 锁喉 的伤害提高30%（原为20%）。
  - 撕裂神经使 割裂 的伤害提高25%（原为20%）。
  - 嗜血凶手能量提高至30%（原为20%）。
  - 速射注射的伤害加成提高至20%/40%（原为15%/30%）。
  - 当多个目标受到你的流血效果影响时，毒伤会生成更多能量。
  - 侧袭 的触发几率降低至10%（原为15%），目标生命值较低时为20%（原为30%）。
  - 毒液炸弹的视觉效果已调整，使其上方的其他重要视觉效果更容易看清。
  - 致命打击和冷血杀手现在能与不屈（3阶）造成的打击正确地协同生效。
  - 若干天赋在天赋树中的位置发生了变动。
  - 致命动能已被移除。

:::

:::

## 常见问题

:::accordion
:::details


:::

:::

---

### 致谢

作者：**Perfecto**

审核：**Stove**

---

:::changelog 更新记录
**2026-08-08** 已更新至12.1版本。

**2026-06-16** 已更新至12.0.7版本。

**2026-04-21** 已更新至12.0.5版本。

**2026-02-10** 已更新至12.0.1版本。

**2026-01-13** 已更新至12.0版本

**2025-12-03** 已更新至11.2.7版本。

**2025-10-07** 已更新至11.2.5版本。

**2025-07-29** 已更新至11.2版本。

**2025-06-19** 已更新至11.1.7版本。

**2025-04-21** 已更新至11.1.5版本。

**2025-02-14** 已更新至11.1版本。

**2024-12-16** 已更新至11.0.7版本。

**2024-10-24** 已更新至11.0.5版本。

**2024-08-17** 已更新至11.0.2版本。

**2024-07-24** 本攻略写于11.0.1前夕版本。



:::
