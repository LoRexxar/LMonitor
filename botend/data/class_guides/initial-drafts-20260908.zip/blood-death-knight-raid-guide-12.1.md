欢迎来到魔兽世界12.1版本的**鲜血 死亡骑士** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始升级的玩家吗？请查看升级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 5/5 · 优秀

范围伤害 · 4/5 · 强力

功能性 · 5/5 · 优秀

生存能力 · 5/5 · 优秀

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **鲜血 死亡骑士** 团队副本 最佳配装
```json
{
  "source_code": "JsfAAqPA3_PABIHJEIICBAw74Og_sOQOC4UABk-FEAQEBAwVtmgE0wYNYFQAwRCBCgQAAUTuJMCB-eRBPAQCB8AKYFQAjfBBAiQAA4fABBGWBEQckQgAQUAAhu7A5IgF2gVAGYCBBEXLFIDTPk7ACKgTBEgChOAhQEAAVA8AmoaAnRDAAcbNLFQAzRCBAgQAAUwhgMubCIICBAwL5GAIAIYA1ggYZPgOSAABf9RDwwAWBEQXdwAEog6AEgQEfBwtBoFN1eBBQgQAAUJ_EkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240894]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240894]] |
| 肩部 | [[item:271472]] | [[item:244021]] |
| 胸部 | [[item:268222]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271473]] | [[item:244641]] |
| 脚部 | [[item:273777]] | [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245781]] · [[item:240166]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:159459]] | [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:239656]] | [[item:245781]] · [[item:240166]] |
| 主手 | [[item:268213]] | [[spell:326805]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **鲜血 死亡骑士** 你可以使用 至暗之夜之舞。它使你在 [[spell:49028]] 期间招架一次攻击后，有几率让你的下一次 [[spell:79885]] 不消耗符文，并额外造成150%的伤害。

**等级2**会降低你受到的伤害，并且每有一个激活的[[spell:49028]]都会提高你造成的伤害。而**等级3**则使你每消耗一枚符文时有一定几率召唤一个[[spell:49028]]，持续6秒。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-blood-mxr.webp>)

至暗之夜之舞

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[spell:1264235]]
    
    - 使你的[[spell:45470]]现在可以额外命中2个目标。
  - [[spell:108199]]
    
    - 沉默效果现已整合到该技能中，不再需要额外消耗1点天赋点。
  - [[spell:1263743]]
    
    - 使你在[[spell:49028]]期间提高招架几率，并在其持续期间使你的符文能量提高10点。
  - [[spell:1263781]]
    
    - 当[[spell:1263743]]结束时，它会爆炸，对附近敌人造成伤害，并为你恢复相当于其爆炸伤害15%的生命值。
  - [[spell:1265790]]
    
    - 你的[[spell:79885]]有几率使你的[[spell:50842]]的冷却时间缩短0.25秒。
  - [[spell:1263824]]
    
    - 是一个拥有3个阶段的文化赋能技能，你蓄力时间越长，其造成的伤害就越高，获得的伤害降低效果也越强。

- **职业树**
  
  - [[spell:1266819]]
    
    - 你的[[spell:61999]]的符文能量消耗降低30点。
  - [[spell:391571]]
    
    - 现在是一个2点天赋，投入2点后可提供30%的额外吸收量。
  
  
  
  - [[spell:374265]]
    
    - 同样是一个2点天赋，最多可为你提供4%的额外急速。
- **已移除**
  
  - [[spell:219809]] 
    
    - 这导致你面对坦克大额伤害时缺少了一个重要的防御冷却技能。
  - [[spell:194844]]
  
  
  
  - [[spell:377640]]
    
    - 在失去[[spell:195181]]层数时，不再对敌人造成任何被动伤害。
  - [[spell:194679]]
    
    - 损失不大，因为这是一个非常小众的天赋，平时也很少有人选择。
  - [[spell:221699]]
  - [[spell:343294]]

## 英雄天赋

- 进入 至暗之夜 第二赛季初期，[[talent:123325]] 目前的表现比 [[talent:123326]] 稍好一些，而且操作也更简单，因此本攻略后续内容将假定你使用的是 [[talent:123325]]。



### [[talent:123326]]

- [[spell:439843]]
  
  - 按下该技能会使目标染上[[spell:439843]]，当叠加达到40层，或者该效果持续时间结束时，你会获得一层[[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]。
- [[talent:117631]]
  
  - 按下[[talent:117659]]还会额外给予你3层[[spell:195181]]。
- [[spell:440031@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]和[[spell:441894]]
  
  - 使[[spell:50842]]转化为造成冰霜暗影伤害，并使[[spell:55078]]有几率造成额外的冰霜暗影伤害，从而为[[talent:117659]]叠加更多层数。

#### 防御选择节点

- [[talent:117632]] 或 ‍[[talent:123420]]
  
  - ‍[[talent:117632]] 并不是一个值得考虑的强力天赋。[[talent:123420]] 非常强力，因为它是一个基于你使用技能的被动减伤。
- ‍[[talent:117646]] 或 ‍[[spell:439948]]
  
  - ‍死亡信使 显然是这里的首选，因为 ‍反斥之盾 在PvE内容中关键的施法场合并不生效。

在12.0前夕版本中，你将可以使用新的英雄天赋栏，但可用的点数有限。

- [[spell:1265855@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - 施放[[spell:49028]]会额外提供一层[[spell:441378@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]。




### [[talent:123325]]

- [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - [[spell:49998]] 有几率将你的下一个 [[spell:79885]] 变为 [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]。
  
  
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 会为你恢复相当于最大生命值 1% 的生命，并给予你 1 层 [[spell:433925]]。
- [[talent:117645]]
  
  - 当你站在自己的 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 中时，你受到的物理伤害降低 5%，并且 [[spell:433895]] 的触发几率提升至 5%。
- [[talent:117662]]
  
  - 使 [[spell:433925]] 最多可叠加至 2 层，并且每层使你的 [[spell:49998]] 伤害提高 5%。
- [[spell:434157@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - 消耗 [[spell:81141]] 触发效果时会给予你 12% 的力量，持续 12 秒。
- [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - [[talent:96269]] 现在会给予你 [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]，在其持续期间将 [[spell:79885]] 替换为 [[spell:433895]]。
  - [[spell:433925]] 的效果在 [[talent:96269]] 期间也会提高 200%。

#### 防御选择节点

- [[talent:117892]] 或 [[talent:117661]]
  
  - 默认选择，因为它对机动性是个不错的加成；如果你是团队中主要的战复担当，可以换成[[talent:117661]]。
- [[talent:117891]] 或 [[talent:117653]]
  
  - [[talent:117891]]提升‍[[talent:96210]]的效果实在太好，难以放弃，而2%的**吸血**即使对4名盟友来说有时也只能提高到4%，实在不够好。

在12.0前夕版本中，你将可以使用新的英雄天赋栏，但可用的点数有限。

- [[spell:1234559]]
  
  - [[spell:37788]] 现在有机会造成巨大的 范围伤害 爆发伤害，因为它在持续期间会随机引爆。
- [[spell:1265574]]
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 提升你的 [[talent:96269]] 所造成的伤害。





## 天赋



### 标准配置

:::talents **鲜血 死亡骑士** 团队副本 标准配置
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 何时使用此专精

除非另有说明，这是应对任何首领的默认配置。你需要根据战斗所需的 utility 来调整职业天赋树。为了方便起见，针对特定首领的天赋配置可在团队副本章节中找到。

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若需更详细的解析，请查看下方的循环和 **深度解析** 章节。

##### 专精树

- [[spell:458572]]
  
  - 拉到敌人时获得1层 [[spell:195181]]。
- [[spell:219786]]
  
  - 当 [[spell:195181]] 层数高于5层时，你的 [[spell:49998]] 消耗的符文能量减少。
- [[spell:273946]]
  
  - [[spell:50842]] 会给你提供层数来强化你的 [[spell:49998]]。命中的敌人越多，收益越大。
- [[spell:377637]]
  
  - 降低你的 [[spell:49028]] 的冷却时间。
- [[spell:377668]]
  
  - 复制 [[spell:49028]] 会放大这个冷却技能的效果。
- [[spell:374737]]
  
  - 有了它，你最多可以拥有12层 [[spell:195181]]。
- [[spell:205723]]
  
  - 这为你的 [[spell:55233]] 提供了巨大的冷却缩减。
- [[spell:114556]]
  
  - 每4分钟一次的免死效果。

##### 职业树

- [[spell:374277]]
  
  - 非常重要的天赋，能让你的 [[spell:49998]] 变得更强。
- [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - 使 ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 能够顺劈更多目标，并延长你的 ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 持续时间。详见深度解析。
- [[spell:205727]]
  
  - 降低你的 [[spell:48707]] 的冷却时间并使其更强。
- [[spell:194878]]
  
  - 有了它，你需要维持一个新增益。
- [[spell:391566]]
  
  - 这会降低敌人的攻击速度，大体上算是你的 团队副本 增益。
- [[spell:457574]]
  
  - 使 ‍[[spell:48707]] 的冷却时间增加20秒。
  - 同时还使你可以在激活 ‍[[spell:48707]] 时移除魔法减益效果。
- [[spell:356367]]
  
  - 这会为你额外提供一层 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]][[spell:49576]] 和 [[spell:48265]]，使它们更容易正确地使用和统筹。




### 防御型build

:::talents **鲜血 死亡骑士** 团队副本 防御型build
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAwYmZmZMjZGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAwYmZmZMjZGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 何时使用此专精

两种build中更偏防御的选择，推荐在开荒推进时使用，或者在你还觉得不太安全的时候使用！





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** 当你[[spell:49998]]时，获得一层[[spell:1310372]]。当[[spell:1310372]]达到10层时，你的下一个[[spell:195182]]将消耗该效果，使你获得10%力量，持续10秒。
- **4件套：** 消耗[[spell:1310372]]时，你的下一个[[spell:195182]]会额外产生3点[[spell:195181]]，并对你的目标及附近敌人造成暗影伤害。

### 起手爆发

- 你开局的目标是确保获得 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 的收益，同时通过 [[spell:49028]] 达到 [[spell:232049]] 的最大层数。此外，你还想尽可能多地获取符文能量，以便随时准备好 [[spell:49998]]。

:::rotation **鲜血 死亡骑士** 开场 团队副本
```json
{
  "source_code": "IgFkKIQApCACQJXZtAVdsxGACwt-CAgACgftAEAnuOAAAAAACR4vAEACIIgmGHgDI4m-CEgDMIkTDDQABwgQn7pBBgAACkgHkcunGAAAAAgQONM"
}
```
1. [[spell:43265]] 开怪前
2. [[spell:195292]]  [[spell:46584]] · [[item:241308]]
3. [[spell:49028]]
4. [[spell:50842]]
5. [[spell:195182]]
6. [[spell:49998]]
7. [[spell:433895]]
8. [[spell:50842]]
9. [[spell:433895]]
10. [[spell:49998]]
:::

- [[spell:195292]] 有飞行时间，应在跑向开怪点的途中施放。

### 优先级列表

这是标准的优先级列表，除非某个首领或场景需要你保留这里列出的某些技能，否则请遵循此列表。你可以在 **团队副本** 部分了解更多关于何时保留冷却技能的信息。

1. 千万不要让 [[spell:195181]] 掉落！使用 [[spell:195182]] 或 [[spell:195292]] 来保持其激活。
   
   - 维持 5 层以上的 [[spell:195181]] 以充分利用 [[spell:219788]]，如果 [[spell:49028]] 即将到来，低于 5 层也是可以的。
2. 在冷却时施放 [[spell:46585]] 以获得一些额外伤害。
3. 保持你的 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 增益效果，查看深度解析部分以了解更多信息。
4. 冷却时施放 [[spell:49028]]。
5. 当你即将达到符文能量上限或 [[spell:391477]] 即将消失时，将符文能量用于 [[spell:49998]]。
6. 施放 [[spell:433895]] 以获取符文能量。
7. 如果已选择该天赋，在冷却时施放 [[spell:274156]]，并且总是在你的 [[spell:49028]] 结束后施放。
8. 施放 [[spell:50842]] 以避免层数溢出。
9. 施放 [[spell:79885]] 来消耗符文，作为填充技能。

### 防御技能冷却

- [[spell:55233]] 
  
  - 大多数情况下，当你受到任何形式的伤害时，你都应尽可能多地使用吸血 鲜血。只有在需要硬吃一次大额伤害，或者即将迎来Boss的停机阶段导致它无法发挥全部价值时，才有必要扣住不放。
- [[spell:49028]]
  
  - 一般来说，直接卡CD使用即可，除非你在某些特殊情况下需要招架效果，更详细的信息请查看下方的**深度解析**。
- [[spell:48707]]
  
  - 这是对抗魔法伤害最强的防御技能之一。一般来说，它可以在承受魔法伤害时使用，但在很多情况下，扣住它并用来免疫机制才是这个技能的最佳用法。请务必留意后文中关于具体免疫什么以及如何最大化利用[[spell:48707]]的章节。
- [[spell:48792]]
  
  - 这是一个极为出色的通用减伤防御技能，在一场战斗中应尽可能多地使用，除非必要，不要与其他减伤技能重叠覆盖。它也可以被扣住用来免疫眩晕类机制，但这种情况相当少见。
- [[spell:49039]]
  
  - 这是一个极其微弱的防御技能，为你提供10%的吸血，当你只需要一点点帮助时，它是一个不错的按键选择。在范围伤害场景中它会更有价值，因为吸血在范围伤害中非常强力。另外，如果你因为某种原因被恐惧了，赶紧按它！

## 深度解析

### 灵界打击治疗与吸收

[[spell:49998]]正是让你成为**鲜血 死亡骑士**的核心。这个技能是你职业的核心！理解它的运作机制以及如何正确使用它，对于最大化你的伤害、保持生存，以及凭借你惊人的自我续航成为最优秀的坦克来说至关重要。

- [[spell:49998]] 会为你恢复一定百分比最大生命值的治疗，且该治疗量会根据你过去5秒内受到的伤害而提高。这意味着，如果你在过去5秒内没有受到可观伤害，灵界打击 就会成为一个低效的治疗来源。
  
  - 环境伤害和友方误伤不计入所受伤害的计算公式中，它们是自我治疗出问题的主要原因。环境伤害来源很多，例如首领房间的 范围伤害 伤害，以及风暴等词缀伤害。
- 你来自 [[spell:49998]] 的治疗效果会被许多不同的技能和属性所放大：
  
  - 全能 是 [[spell:49998]] 治疗的乘数。
  - [[spell:273953]] 也会提高你的 [[spell:49998]] 治疗量以及你的 [[spell:77513]] 数值。
  - [[spell:273946]] 只会放大你的 [[spell:49998]] 治疗量，但不会提高你的 [[spell:77513]] 的数值。
- [[spell:77513]] 是 [[spell:49998]] 的另一项重要机制：
  
  - [[spell:77513]] 生成的护盾基于完整的治疗数值，其中包含过量治疗。
  - 该吸收效果纯粹是物理性的，对魔法伤害完全无效。
  - 该吸收效果会受到你的 精通 属性数值的提高。
  - [[spell:273953]] 会提高你的治疗量和护盾数值，而 [[spell:273946]] 则不会。
  - [[spell:77513]] 的最大值为你的最大生命值。该上限会随着 [[spell:55233]] 和 [[spell:97462]] 等生命值增益动态更新。

### 灵界打击的管理

既然你已经了解了[[spell:49998]]的运作机制，接下来我们谈谈如何使用它来从中获得最大的伤害和生存能力。

- 就输出伤害而言，当你即将符文能量溢出，或者你可以放心地把全部符文能量用于对目标造成伤害时，就使用 [[spell:49998]]。
- 如果你想正确使用 [[spell:49998]] 来进行治疗或应对特定机制，关键在于良好的操作节奏：
  
  - 在使用 [[spell:49998]] 时要考虑你过去5秒所受的伤害。大多数情况下，你应该在坦克机制之后或承受大量伤害之后再 [[spell:49998]]。这能让你在使用 [[spell:49998]] 之后立刻获得大量治疗和大型吸收护盾。
  - 大多数时候，连续使用2次 [[spell:49998]] 并不明智，因为只使用1次就足以让你回满血并获得大型吸收护盾。某些情况下确实需要连续使用 [[spell:49998]]，但比起精准时机下只使用1次，这种情况要少见得多。
  - 针对魔法伤害精准把握 [[spell:49998]] 的时机非常重要，因为你的 [[spell:77513]] 对这类伤害完全无效。
  - 提前积攒吸收护盾以应对坦克机制可能很有用，但代价往往很高，因为如果你没有承受足够的伤害来供给 [[spell:49998]] 治疗，生成大型护盾需要很长时间。

掌握所有这些信息后，你就能够完全理解并将 [[spell:49998]] 发挥到极致了。请始终牢记，坦克并不是按照固定的循环或僵硬的技能流程来运作的，良好的游戏节奏和正确的 [[spell:49998]] 使用需要靠经验与练习来积累。

### 枯萎凋零 优化

- 自至暗之夜12.0补丁以来，对[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]保持高覆盖率对你来说已不像以前那么重要了，它仍然会提升你的伤害和治疗效果，因为 **鲜血 死亡骑士** 因为[[spell:391458]]，并通过[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]为你提供额外收益。

- 核心思路是：只要[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]未激活且不在冷却中，就始终使用它。[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]为你的[[spell:43265]]提供大量额外持续时间以及诸多便利收益。
- 以下是[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]提供的优势：
  
  - 你走出[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]后仍会保留其收益，持续4秒。
  - [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]的持续时间耗尽后，该增益会随后出现。
  - 无论[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]的持续时间如何，进出[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]都会刷新该增益。

- 由于 [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 会为 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 额外提供 4 秒的持续时间，因此即使没有 [[spell:356367]]，维持该效果的循环也极为顺畅。
  
  - 在没有 [[spell:356367]] 的情况下，平均覆盖率约为 93%，这已经非常出色了。
  - 而有了 [[spell:356367]]，只要操作得当，你永远不会失去 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] 增益。

- 这里展示了[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]与[[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]良好配合的时间线示例。只需在冷却好了就施放即可。

:::timeline **鲜血 死亡骑士** 枯萎凋零 团队副本
```json
{
  "source_code": "H4FT2Z3_8AQIEww_eAAAOAAD_7xDA0RAHggHAwSAHgSLAsDAEIQApCAAAEgBA8QBGAgHFYAKtAABCRf1EAAAZAQCIAgCNgAKoAgQ0XNBAAwNAEA"
}
```
总时长：60 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:43265]] | 上轨 |
| 10 秒 | [[spell:316916]] | 下轨 |
| 15 秒 | [[spell:43265]] | 上轨 |
| 25 秒 | [[spell:316916]] | 下轨 |
| 30 秒 | [[spell:43265]] | 上轨 |
| 40 秒 | [[spell:316916]] | 下轨 |
| 45 秒 | [[spell:43265]] | 上轨 |
| 55 秒 | [[spell:316916]] | 下轨 |
:::

### 符文刃舞

[[spell:49028]] 是 **鲜血 死亡骑士** 武器库中最重要的技能之一，有很多乍看之下并不明显的地方！

无论是在输出还是在防御价值方面，它对该职业的玩法都至关重要，以下是关于该技能你应当了解的关键特性。

- 该武器基本上算作一个不可被选为目标的“守护者”，并且始终跟随你使用该技能的目标。这意味着当该目标死亡后，它会跟随你并攻击你当前的目标。
- [[spell:49028]] 会在目标身后生成，因此在对远处的目标使用时可能会引到更多敌人。
- 你召唤的每把武器都会复制某些法术并给予你其收益，下面我们来逐一介绍：
  
  - [[spell:195182]] 使你获得 9 层 [[spell:195181]]（每把武器 3 层）。
  - [[spell:195292]] 使你获得 6 层 [[spell:195181]]（每把武器 2 层）。
  - [[spell:79885]] 使你获得 15 符文能量而非 5 点（每把武器都会施放 [[spell:79885]]，各产生 5 符文能量）。
  - [[spell:50842]] 现在会施加 3 个独立的 [[spell:55078]] 减益效果（每把额外武器各施加 1 个），生命值转移量不会增加，你仍然只能从自己的 [[spell:55078]] 中获益。
    
    - 由 [[spell:195292]] 施加的 [[spell:55078]] 同理。
  - [[spell:49998]]造成更多伤害，因为该技能被武器复制了，但治疗效果不会提高。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下技巧主要适用于**英雄难度首领**。史诗难度的技巧将在我们的开荒进度结束后发布。

**← 滚动查看更多首领 →**



### 奈克泽利

:::talents **鲜血 死亡骑士** 团队副本 内克泽利
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 坦克机制

- 这场战斗的主要坦克机制是蚀空打击——首领每次近战攻击以及施放 [[spell:1284103]] 时都会施加的一种减益效果。
- 在 [[spell:1284103]] 期间，首领会向当前坦克发射幽灵回响，额外施加蚀空打击层数。这些回响在首次接触到任意玩家时会爆炸，对团队造成降低后的 
  
  - 当你成为该机制的目标时，走出团队，并确保你和首领之间没有任何人，以免他们过早触发回响。否则，回响会对团队造成过多伤害。
  - 每次 [[spell:1284103]] 施放完毕后进行嘲讽换坦。
- 此外，首领还会召唤成群的不安阿曼尼——务必将首领拉到它们旁边，以便更好地进行顺劈。
- 在过渡阶段，当前坦克会成为一次群体分担——[[spell:1289855]] 的目标。尽量将它放在尽可能多的不安阿曼尼尸体上，利用 [[spell:1289875]] 将其烧毁，防止它们再次苏醒。




### 被埋葬的哨兵

:::talents **鲜血 死亡骑士** 团队副本 被埋葬的哨兵
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 坦克机制

- 由于 [[spell:1290189]]，首领们必须始终保持至少40码的距离。在每个阶段开始时，将首领们移到房间的不同两侧使其分开。
- [[spell:1284458]] 和 [[spell:1284487]] 是各个首领的叠加坦克减益效果。在 [[spell:1284588]] 期间，每当首领们在房间中央相遇时，务必进行嘲讽换坦以重置你的层数。
  
  - [[spell:1284487]] 额外会在到期时产生一个大型血泊。如果可能，请务必将其放置在房间的边缘。
- 不要将 乌拉特克之息 坦克在现有的血泊太近的位置，这样 [[spell:1284251]] 就不会在血泊中生成，近战职业就可以安全地攻击它。




### 迷失的探险者

:::talents **鲜血 死亡骑士** 团队副本 迷路的探险者
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 坦克机制

- 由于 [[spell:1297645]]，三个首领彼此都不能处于 30 码以内——始终让其中一个首领远离另外两个。
- 商人盖博 只会在房间里游荡，不会跟随或攻击其仇恨目标。它也没有任何坦克机制。
- 书卷贤者伊库 会对其当前目标施放 [[spell:1295854]]——一连串冰碎片，每片造成魔法伤害，并使后续碎片受到的伤害提高，持续 80 秒。
- 大副纳玛 每次攻击都会对其目标施加 [[spell:1291929]]，使该目标受到的物理伤害提高，持续 30 秒。
- 这场战斗中坦克的职责是在Scrollsage伊库和 大副纳玛 之间来回换坦，绝不让 [[spell:1295854]] 连续两次施放在同一目标身上，并尽可能频繁地重置 [[spell:1291929]]，同时始终让其中一个首领距离足够远，以防止 [[spell:1297645]] 被施加。




### 瓦什尼克

:::talents **鲜血 死亡骑士** 团队副本 瓦什尼克
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 坦克机制

- 房间两侧放置着 3 座喷泉：鲜血之泉、火焰和 暗影。整场战斗中，首领会通过 [[spell:1283164]] 激活最近的两座喷泉，获得它们的力量并召唤一些小怪。
  
  - 每座喷泉被激活后，会使下一次激活强化 1.5 分钟。
  
  
  
  - 作为坦克，你的职责是通过在每次 [[spell:1283164]] 施放前将首领拉到下一座喷泉处，绝不让首领连续激活相同的两座喷泉。
  - 务必将首领定位在从喷泉出来的小怪上方，以便更好地顺劈。但是，要小心不要过快杀死所有火焰小怪，因为它们死亡时会施加可叠加的 [[spell:1285979]]。
- 瓦什尼克的坦克打击技能是 [[spell:1280935]]，每次施放后进行嘲讽换坦。




### 斯索拉克

:::talents **鲜血 死亡骑士** 团队副本 斯索拉克
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 战斗机制

- [[spell:1277025]] 是一组坦克正面机制的组合，由 2 次 [[spell:1277002]]、2 次 [[spell:1277027]] 和 1 次 [[spell:1287072]] 组成，以随机顺序施放。
  
  - [[spell:1277002]] 是一个正面锥形范围技能，造成高额物理伤害并跟随当前坦克。务必将其指向**远离团队**的方向。
  - [[spell:1277027]] 是一个正面锥形范围技能，会施加一个强力的魔法持续伤害效果，其效果会被锥形范围内被击中的人数所分摊减弱。务必将此技能指向团队的一半人马，让他们来分担。
  - [[spell:1287072]] 会在首领周围生成一群龙卷风，并在施法结束时将其向外发射。当此技能发生时，确保你不在首领下方，并躲避龙卷风。
  - 在英雄和史诗难度下，首领会以随机顺序施放这些技能。由于每个正面锥形技能都会施加来自该技能的伤害提高效果，务必确保同一个坦克绝不承受 2 次相同技能。请记住，你可以在施法期间嘲讽，让首领将正面锥形技能对准你。
- 每次施放 [[spell:1306120]] 都会在首领周围生成 [[spell:1305998]] 个水坑。务必将首领拉到房间边缘，理想情况下是与 [[spell:1285732]] 刷新点相对的一侧，这样水坑就会被风吹出房间边缘。
- 除此之外，斯索拉克 每次近战攻击都会施加一层 [[spell:1282869]]，使目标受到的物理伤害提高。在每次 [[spell:1277025]] 连击后进行嘲讽换坦就足以重置层数。




### 双牙

:::talents **鲜血 死亡骑士** 团队副本 双尖牙
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 通用机制

- 整场战斗的核心在于管理 [[spell:1290336]] 层数
  
  - [[spell:1291404]]、[[spell:1291478]]、被毒波命中或吸收 [[spell:1289201]] 都会施加一层 [[spell:1290336]]。
  - 在英雄难度下达到 10 层或史诗难度下达到 9 层会立即死亡。
  - 尽可能躲开毒波，同时控制好吸收 [[spell:1289201]] 的数量，以避免该减益效果达到最大层数，这一点至关重要。

#### 坦克机制

- 当你主动坦住的首领脱离近战范围时，它会施放 [[spell:1295107]] 或 [[spell:1295113]]，所以千万不要离开近战范围；如果发现自己离首领太远，请使用一个大型个人减伤。
- 维克苏尔 的坦克技能是 [[spell:1289192]]，造成自然伤害并将你击退 5 秒。
  
  - 它还会在你周围生成 [[spell:1289201]]。这些需要由玩家吸收，以免爆炸后给所有人叠加一层 [[spell:1290336]]。
  - 每次被击中都会施加 [[spell:1310360]]，因此每次 [[spell:1289192]] 施放后都要进行嘲讽换坦。
  - 注意击退效果，尤其是毒波即将到来的时候！
- 伊斯拉兹 会施放 [[spell:1288538]]，击退靠近首领的玩家并生成 3 个吸收区域。
  
  - 每个区域会造成高额物理伤害，并使下一个区域造成的伤害提高 33%。如果无人吸收该区域，它会对全团造成伤害并将所有人击飞。务必在每组 [[spell:1288538]] 之间进行嘲讽换坦，以重置伤害增加的层数。
  
  
  
  - 这些区域以随机顺序生成，并且必须按照生成的先后顺序依次吸收。在这一技能进行时，请密切关注区域的生成并记住生成顺序。首领在触发下一个区域前会短暂地面朝该区域的方向，所以如果你记不住生成顺序，可以参考首领的朝向。
  - 每隔一次 [[spell:1288538]] 施放都会与毒波重合——吸收 [[spell:1288538]] 时务必确保不被毒波击中。
  - 小心该机制开始时的击退，因为它可能把你推入袭来的毒波或某个 [[spell:1289201]] 中。




### 盘绕祭坛

:::talents **鲜血 死亡骑士** 团队副本 盘绕祭坛
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 第一阶段

- 该阶段中只有 祖尔加 处于激活状态。
- 他会施放 [[spell:1299960]]，在该阶段中生成多个 [[spell:1282403]] 法球。法球存在期间会持续对全团造成 范围伤害 伤害，玩家可以撞入法球来拾取并移动它们。
- [[spell:1299684]] 是一个指向当前坦克的正面锥形技能，造成物理伤害，并摧毁任何被它命中的 [[spell:1282403]]。
  
  - 它还会使下一次 [[spell:1299684]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
- 该阶段的目标是让团队将 [[spell:1282403]] 法球聚集到一起，然后用 [[spell:1299684]] 将其摧毁。
- 此外，每次施放 [[spell:1282487]] 都会强化首领接下来的 23 次近战攻击，附带 [[spell:1300322]]，对坦克造成额外的自然伤害。
  
  - 当首领身上有 [[spell:1300322]] 层数时，务必提前开启减伤技能。

#### 第二阶段

- 该阶段中只有 妖术领主玛拉卡斯 处于激活状态。
- 他会施放 [[spell:1285640]]，对被选中的玩家进行精神控制，并且每当精神控制被打断时，每名玩家会生成 2 个 [[spell:1285842]]。
  
  - 这些具象会锁定随机玩家并向其移动，除非被锁定的玩家回头面对该具象。
- 与第一阶段的 [[spell:1299684]] 类似，[[spell:1286620]] 是一个指向当前坦克的正面锥形技能，造成暗影伤害，并摧毁任何被它命中的 [[spell:1285842]]。
  
  - 它还会使下一次 [[spell:1286620]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
  - 此外，它会施加 3 层 [[spell:1286837]]，每层会生成一个灵魂碎片，必须拾取灵魂碎片才能移除对应的层数。如果在减益效果到期前没有清空层数，受影响的玩家会立即死亡。
  - 在每次坦克正面锥形技能之后，务必格外注意迅速找到并收集所有灵魂碎片。
- 被 [[spell:1286895]] 命中同样会施加 3 层 [[spell:1286837]]。千万不要掉以轻心！

#### 阶段转换

- 马拉克拉丝在施放 [[spell:1287685]] 期间受到的伤害提高 100%。
- 不要让任何马拉克拉丝碎片到达首领处，通过吸收它们来阻止其治疗首领。
  
  - 吸收每个碎片会对全团造成 范围伤害 伤害，因此不要吸收得太快，给治疗者一些时间来应对即将到来的伤害。

#### 第三阶段

- 在该阶段中，祖尔加 和马拉克拉丝同时激活，并结合了第一阶段和第二阶段的技能。
- 该阶段中 [[spell:1299960]] 和 [[spell:1285640]] 都会出现，这意味着 [[spell:1282403]] 和 [[spell:1285842]] 都需要由坦克的正面锥形技能来清除。
- 该阶段的坦克正面锥形技能是 [[spell:1307279]]，造成暗影伤害，摧毁任何被它命中的 [[spell:1282403]] 和 [[spell:1285842]]，并施加 3 层 [[spell:1286837]]。
  
  - 别忘了收集你的灵魂碎片，并在每次锥形技能后进行嘲讽换坦！
- [[spell:1298381]] 是第一阶段 [[spell:1282487]] 的强化版本。
  
  - 在该阶段中，被强化的近战攻击还会额外施加可叠加的  暗影持续伤害。当层数较高时，请使用大型减伤技能。




### 乌拉特克

:::talents **鲜血 死亡骑士** 团队副本 乌拉特克
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::




### 尼姆瑞莎·唤波者

:::talents **鲜血 死亡骑士** 团队副本 尼姆瑞莎·唤波者
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

#### 通用机制

- 首领会用刺骨的 冰霜 随机标记玩家，在其脚下生成 冰霜 法球。
  
  - 这些法球必须在爆炸并团灭团队之前被吸收。
  - 吸收法球会施加一个可叠加的减益效果，使吸收 冰霜 法球时受到的伤害增加，所以不要一次吸收太多。
  - 每次吸收法球还会对全团造成 范围伤害，因此不要吸收得太快，给治疗者一些时间来应对即将到来的伤害。
- 鱼人会不时从水中出现，并开始走向房间中央的气泡。
  
  - 不要让它们到达气泡处，并尽可能将首领移动到它们上方，以便更好地进行顺劈。

#### 坦克机制

- 这场战斗中坦克专属的机制是冰刃连斩——一系列魔法斩击，每一斩都会增加后续斩击的伤害。
  
  - 每次施放时使用一个防御技能，并在每次结束后换坦嘲讽。





## 属性优先级

了解你的副属性优先级，以及作为**鲜血 死亡骑士**在 团队副本 首领战斗中达到最佳表现所需的第三属性。欲了解更详细的信息，请访问 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority **鲜血 死亡骑士** 团队副本 属性
```json
{
  "source_code": "IoAJFQAJoASMBIQACA"
}
```
**力量 ＞ 急速 ＝ 全能 ＞ 暴击 ＝ 精通**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 一项极佳的属性，可以降低承受"**范围伤害**"技能所造成的伤害。
- **吸血** - 通过造成伤害来提供额外的治疗。
- **速度** - 一项小众的副属性，但可能非常有用，过去已被证明其实用价值。它能让应对某些机制变得轻松许多。

总体而言，吸血 对坦克来说非常强力，尤其是在 范围伤害 环境下，它可能是你所能拥有的最佳属性。  
闪避 也很不错，但大多数时候坦克并不难在典型的范围效果技能下存活。

## 装备



### 总体最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271474@DiQAAoPAvj74PrTOC4UA]] | 双子毒牙 |
| 颈部 | [[item:268265@BERAAoPAX164PrTOCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271472@DgQAAoPA1k7kjAOF]] | 失落的探险者 |
| 披风 | [[item:239656@FgQAAoPAVA8Yiqzt1sUA]] | 制造 |
| 胸部 | [[item:268222@DgQAAoPAJk7kjAYF]] | 盘卷祭坛 |
| 护腕 | [[item:237834@FCRAAoPAVA8Yiqj_sOAAwt1sUA]] | 制造 |
| 手套 | [[item:271475@BgQAAoPA5IgTBA]] | 陵寝哨兵 |
| 腰带 | [[item:268259@BiQAAoPA-z6kjAYF]] | 盘卷祭坛 |
| 腿部 | 将[[item:271878@BARAAoPACKgF2gVA]]  <br>转化为[[item:271473@DARBAoPAhu7kjAWYDWBYgJE]] | 乌拉特克的催化剂 |
| 靴子 | [[item:273777@DgQAAoPAPk7IoAOF]] | 毒牙祭坛 |
| 戒指 1 | [[item:159459@DiQAAoPAvk74PrjgC4UA]] | 诸王之眠 |
| 戒指 2 | [[item:252258@DiQAAoPAvk74PrjgC4UA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:270175@BgQAAoPA5IAWBA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgQAAoPA5IAWBA]] | 盘卷祭坛 |
| 武器 | [[item:268213@RgQAAoPAVyPB5IAWBA]] | 盘卷祭坛 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:239050@BgQAAoPACKQQBA]] | 诸王之眠 |
| 颈部 | [[item:251173@BgQAAoPACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:239037@BgQAAoPACKQQBA]] | 塞塔里斯神庙 |
| 披风 | [[item:193763@BgQAAoPACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251193@BgQAAoPACKQQBA]] | 夺目谷 |
| 护腕 | [[item:159425@BgQAAoPACKQQBA]] | 塞塔里斯神庙 |
| 手套 | [[item:251221@BgQAAoPACKQQBA]] | 虚空之痕竞技场 |
| 腰带 | [[item:159418@BgQAAoPACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:159435@BgQAAoPACKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:273777@BgQAAoPACKQQBA]] | 毒牙祭坛 |
| 戒指 1 | [[item:159459@BgQAAoPACKQQBA]] | 诸王之眠 |
| 戒指 2 | [[item:251148@BgQAAoPACKQQBA]] | 纳洛拉克的洞穴 |
| 饰品 1 | [[item:250244@BgQAAoPACKQQBA]] | 纳洛拉克的洞穴 |
| 饰品 2 | [[item:250228@BgQAAoPACKQQBA]] | 密谋小径 |
| 武器 | [[item:251181@BgQAAoPACKQQBA]] | 夺目谷 |





### 饰品

以下是从地下城、团队副本和探洞中可获得的后市（毕业）饰品排名。请注意，上文推荐的饰品以伤害最优化为标准；如果你并不在意伤害，只求生存，我建议你使用类似 [[item:270160@BgQAAoPACKgTBA]] 这样的饰品。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgQAAoPA5IAWBA]]  <br>[[item:270173@BgQAAoPACKAWBA]] |
| **A级** | [[item:270160@BgQAAoPACKgTBA]]  <br>[[item:270164@BgQAAoPACKgTBA]]  <br>[[item:270165@BgQAAoPA5IgTBA]]  <br>[[item:270174@BgQAAoPACKgTBA]] |
| **B级** | [[item:270163@BgQAAoPACKgTBA]]  <br>[[item:273795@BgQAAoPACKgTBA]]  <br>[[item:250243@BgQAAoPACKgTBA]]  <br>[[item:250244@BgQAAoPACKgTBA]]  <br>[[item:250228@BgQAAoPACKgTBA]]  <br>[[item:193762@BgQAAoPACKgTBA]] |
| **C级** | [[item:273796@BgQAAoPACKgTBA]]  <br>[[item:159618@BgQAAoPACKgTBA]]  <br>[[item:250229@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:193757@BgQAAoPACKgTBA]]  <br>[[item:273797@BgQAAoPACKgTBA]] |
| **垃圾级** | [[item:250238@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:158367@BgQAAoPACKgTBA]]  <br>[[item:270168@BgQAAoPACKAWBA]] |

### 美化饰品

- 在披风、护腕、腰带或靴子任选其一打上2个 [[item:240166@BAAAAoP]]。
  
  - 不错的被动主属性增益。

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - [[item:241324@BAAAAoP]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884@BAAAAoP]]
- **武器磨刀石**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240983]] *-- 唯一，只能使用一次。*
  - [[item:240894@BAAAAoP]]
  
  
  
  - [[item:240916@BAAAAoP]]

### 附魔

:::columns
:::column
| 头部 | [[item:243949@DAAAAwQAZbAB]]  <br>*[[item:275707@DAAAAoPAvj7A]]* |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 护腕 | *[[item:275707@DAAAAoPAvj7A]]* |
| 腰带 | *[[item:275707@DAAAAoPAvj7A]]* |
| 腿部 | [[item:244641@BAAAAwQA]] |
| 脚部 | [[item:243983@BAAAAwQA]] |
| 戒指 1 | [[item:244017@BAAAAwQA]] |
| 戒指 2 | [[item:244017@BAAAAwQA]] |
| 武器 | [[spell:326801]] |

:::

:::column
:::gear **鲜血 死亡骑士** 团队副本
```json
{
  "source_code": "IQFZ6DQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAx0AEoETuDAAAAAgQRyPB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244017]] |  |
| 戒指二 | [[item:244017]] |  |
| 主手 | [[spell:326801]] |  |
:::

:::

:::

> *你需要从巨集宝库商人处购买 ‍[[item:275707@DAAAAoPAvj7A]] 来为你的头部、护腕和腰带添加宝石插槽。*

## 种族

要在团队副本中对你的 **鲜血 死亡骑士**进行极限优化，不同的种族特长可以为你的角色带来巨大的收益。如果极限优化不是你的首要目标，选择一个符合你个人风格的种族也同样可行。

- **[[spell:65116]]** -- 矮人
  
  - 非常有价值，因为你可以为自己驱散魔法或移除危险的流血效果。
  - 此外，使用石像形态可以为你提供10%的物理伤害减免，在坦克时可以作为一个持续8秒的小型额外减伤技能。
- [[spell:25046]] -- 鲜血精灵
  
  - 强大的种族技能，可用于驱散或驱除敌人身上的增益效果，价值非常有限，但有时能派上用场。
- [[spell:69070]] -- 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在[[spell:69070]]动画期间，你会处于公共冷却状态，直到角色落地为止。
- [[spell:256948]] -- 虚空精灵
  
  - 生成一道朝你面向方向旅行的暗影裂隙，再次激活即可传送到裂隙处。
  - 最大距离为100码。

### 推荐

作为一名坦克，为了伤害而选择种族只是很小的收益，大多数情况下并不值得。如果你在意将 DPS 优化到极致，那就选择 DPS 最高的种族特性。

话虽如此，团队副本 坦克的推荐种族是 **矮人**，因为它拥有主动使用的物理减伤以及需要时自我驱散的能力。这些用途极其强大，绝不应被低估！

## 宏

了解 **鲜血 死亡骑士** 的团队副本推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
嘲讽宏 --- *这个宏会对你的当前目标或鼠标悬停目标施放[[spell:56222]]*（在拉起小怪时非常方便）

```wow-macro
#showtooltip 黑暗命令
/cast [@mouseover,exists,harm][@target,exists,harm] 黑暗命令
```

1号首领嘲讽宏 --- *对1号首领施放* [[spell:56222]]

```wow-macro
/cast [@boss1] 黑暗命令
```

2号首领嘲讽宏 --- *对2号首领施放* [[spell:56222]]

```wow-macro
/cast [@boss2] 黑暗命令
```

:::

:::details 鼠标指向宏
寒冰锁链 --- *此宏会对你的当前目标或鼠标悬停目标施放 [[spell:45524]]*

```wow-macro
#showtooltip 寒冰锁链
/cast [@mouseover,exists,harm][@target,exists,harm] 寒冰锁链
```

鼠标悬停死亡之握 --- *对你的鼠标悬停目标施放 [[spell:49576]]*

```wow-macro
#showtooltip
/use [@mouseover] 死亡之握
```

鼠标悬停焦点 --- *此宏会将你的鼠标悬停目标设为焦点*

```wow-macro
/focus [@mouseover]
```

鼠标悬停战斗复活 --- *此宏使你可以通过鼠标悬停团队框架来使用 [[spell:61999]]*

```wow-macro
#showtooltip 复活盟友
/cast [@mouseover,help,dead][]复活盟友
```

:::

:::details 焦点目标宏
焦点死亡之握 --- *对你的焦点目标施放 [[spell:49576]]*

```wow-macro
#showtooltip
/use [@focus] 死亡之握
```

焦点打断 --- *对你的焦点目标施放 [[spell:47528]]*

```wow-macro
#showtooltip 心灵冰冻
/cast [@focus,harm,nodead][] 心灵冰冻
```

鼠标指向焦点 --- *此宏会将你的鼠标指向目标设置为焦点*。

```wow-macro
/focus [@mouseover]
```

:::

:::details 实用宏
反魔法领域宏 --- *在光标位置施放 [[spell:222791]]*

```wow-macro
/cast [@cursor] 反魔法领域
```

死亡凋零宏 --- *在你的角色脚下施放 [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]*

```wow-macro
/cast [@player] 枯萎凋零
```

群体绞杀宏 --- *此宏会将 [[spell:108199]]* 施放在你的鼠标指向目标或角色位置

```wow-macro
#showtooltip 血魔之握
/cast [@mouseover,exists,nodead][@player] 血魔之握
```

控制亡灵 *--- 这使你无需选中宠物即可再次施放控制亡灵。*

```wow-macro
/target pet
/run PetDismiss()
/use 控制亡灵
/petassist
```

取消保护之手的取消光环宏 --- *这条宏会取消你身上的[[spell:1022]]，与圣骑士组队时非常有用*

```wow-macro
/cancelaura 保护祝福
```

:::

:::

## 插件

下方是作者为其 **鲜血 死亡骑士**所用用户界面的截图，其中概述了使用了哪些插件以及它们在团队副本中如何帮助你更轻松地进行游戏。

![](<https://assets-ng.maxroll.gg/wordpress/Death-Knight-Raid-Interface-1024x606.png>)

**鲜血 死亡骑士** 团队副本中的界面

:::accordion
:::details 插件
- **ElvUI *-- 完整的用户界面替换插件*** 
  
  - 一款以用户友好为核心设计的界面插件，附带标准界面所不具备的额外功能。
  - 另外，你也可以使用 Shadowed Unit Frames (SUF) 以及你喜欢的动作条插件，当然也可以使用原生界面。
- [](<https://www.curseforge.com/wow/addons/shadowed-unit-frames>)**BigWigs** -- 通用首领模块
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件专为特定的团队副本战斗触发警报信息、计时条、音效等而设计。
- **Plater** -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的减益效果追踪、威胁着色以及大量自定义选项。
- **Details** -- 深度伤害统计
  
  - 让你的伤害统计界面看起来更漂亮。
- **MRT** -- 标记、团队副本冷却以及更多功能
  
  - 对团队副本玩家非常有用的插件，尤其适合团队团长和官员。ditions.

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
死亡骑士

- 英雄天赋
  
  - 萨莱因
    
    - 鲜血 野兽自动攻击伤害提高1400%。
    - 血染之地现在使受到的物理伤害降低8%（原为5%）。
- 鲜血
  
  - 顶尖天赋：至暗之夜之舞（等级2）已更新——每个激活的符文刃舞使受到的伤害降低6%（原为4%）。
  - 近战伤害提高20%。
  - 心脏打击伤害提高25%。
  - 精髓分裂伤害提高50%。
  - 符文刃舞现在使招架提高30%（原为25%）。
  - 永久冻结提供的护盾相当于造成伤害的50%（原为40%）。
  - 饮血提供15%的吸血（原为12%）。
  - 品味鲜血的治疗效果提高25%。
  - 迅速分解使血之疫病的治疗效果提高85%（原为50%）。
  - 血腥爆裂为你恢复相当于造成伤害18%的生命值（原为15%）。
  - 永恒脐带吸收的伤害相当于血之疫病所造成伤害的6倍（原为5倍）。
  - 黑锋军团的坚忍现在在消耗赤色天灾时使受到的伤害降低4%。持续时间延长至10秒（原为6秒）。
  - 血丝现在还使鲜血护盾激活期间受到的伤害降低4%。
  - 英雄天赋
    
    - 死亡使者
      
      - 死神印记对主要目标的伤害提高20%。
      - 破灭对主要目标的伤害提高20%。
    - 萨莱因
      
      - 萨莱因契约现在储存所有暗影伤害的15%（原为10%）。
      - 吸血鬼打击伤害提高25%。
      - 脏腑之力现在提供10%的力量（原为12%）。
      - 疯狂嗜血的灵界打击和死亡缠绕伤害加成降低至每层5%（原为6%）。
      - 鲜血即生命现在累积鲜血野兽所造成伤害的15%（原为25%）。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我总是死亡？
答：你没有正确使用 [[spell:49998]]，或者减伤技能按得不够多。请务必阅读 **深度解析** 以了解更多信息！

:::

:::

---

### 致谢

作者：**Skövte**

审核：**Tief**

---

:::changelog 更新记录
**2026-08-11** 已更新至12.1版本

**2026-06-16** 已更新至12.0.7版本

**2026-04-21** 已更新至12.0.5版本

**2026-02-26** 已更新至12.0.1版本

**2026-01-20** 已更新至至暗之夜 12.0

**2025-12-02** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-08-05** 已更新至11.2版本



:::
