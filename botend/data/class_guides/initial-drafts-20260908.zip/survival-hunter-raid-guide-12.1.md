欢迎来到《魔兽世界》12.1版本的**生存 猎人** 团队副本攻略！本攻略涵盖了你在了解自己角色时所需的一切知识！如果你是刚起步、从80级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体输出** · 3/5 · 中等

范围伤害 · 3/5 · 中等

功能性 · 2/5 · 较弱

生存能力 · 5/5 · 优秀

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear 生存 猎人 团队副本 最佳配装
```json
{
  "source_code": "JYpAI-PA3_PABQIJEIICBAQD5OwVtOggC4UABk-FEAQEBAABtOABBIBeMWDWBEggkQgAIUAAXk7ACKAWBc8FEEwhkQgAQUAAJEgEBMCPEYCBBU2uDQIIBAwJqOAGAHQPAAQBBQxt1sUABMYCBRQo7WQQw08FEEQyXQgAIEAAPkbC2BAamxDAYUIJEAACFAQAdiR1xJQAil9ABILD1j7AEEAoQ4UABAYLFQcHSgxXfQAAIMAAB0KHFAQA2chAB0VASAQAFIBEB09FEAQEMwztXQgAQEAAFk7ACKgF2gVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271492]] | [[item:240983]] · [[item:243981]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271490]] | [[item:243991]] |
| 胸部 | [[item:271495]] | [[item:243977]] |
| 腰部 | [[item:244581]] | [[item:240900]] · [[item:240167]] · [[item:245784]] |
| 腿部 | [[item:271491]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271493]] |  |
| 戒指一 | [[item:252258]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:243973]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**生存 猎人**，你可以使用猛禽横扫，使[[spell:186270]]有25%的几率变为[[spell:1259003]]。

**等级2** 提高[[spell:186270]]、[[spell:259495]]和[[spell:1259003]]的伤害，同时使其对你的主目标造成更多伤害。 **等级3** 使每第二个[[spell:186270]]变为[[spell:1259003]]。在受到[[spell:260285]]影响期间施放的每个[[spell:1259003]]还会以300%的效果触发一次额外的[[spell:1251717]]。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-survival-mxr.webp>)

猛禽横扫

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[talent:135514@AJwACA]]
    
    - 新的伤害爆发技能，使你和你的宠物在8秒内造成20%的额外伤害。替代[[spell:360952]]。
  - [[talent:135515]]
    
    - 新的短冷却技能，使你在前方锥形范围内造成范围伤害伤害。替代[[spell:203415]]。
  - [[talent:126311]]
    
    - 使你的[[talent:126324]]更强大。选择[[talent:135508]]天赋后，施放[[talent:126324]]有几率提高其冷却回复速度。
- **职业树**
  
  - [[talent:136686]]选择节点，包含[[talent:136685]]
    
    - 新的顶层天赋，让你可以为自己获得更多被动减伤，或获得一个同样可以施放在盟友身上的外部减伤技能。
  - [[talent:136670]]
    
    - 此前仅为[[talent:123350]]的天赋，现在两种英雄天赋均可使用。使你的[[talent:135711]]将其命中的敌人拉回
- **已移除**
  
  - [[spell:459868]]，[[spell:268501]]和[[spell:1217429]]
    
    - 失去持续伤害（DoT）大幅降低了[[talent:135497]]的价值。
  - [[spell:462031]]，[[spell:191433]]，[[spell:186387]]
    
    - 所有击退效果的移除使生存 猎人的功能性变差，尤其是在大秘境地下城中。
  - [[spell:212431]]，[[spell:320976]]，[[spell:212436]]，[[spell:269751]]
    
    - 由于技能被精简，输出循环简单了许多，且单体与范围伤害之间的差异也变小了

## 英雄天赋

- 你的英雄天赋是[[talent:123349]]和[[talent:123350]]。两种英雄天赋都不会大幅改变你的输出循环。
- 目前推荐的英雄天赋是[[talent:123349]]。

:::tabs
:::tab [[talent:123349]]
[[talent:123349]]英雄天赋树会极大地强化[[spell:259495]]。

- 它最重要的天赋是[[talent:117573@AJwACA]]，有几率对敌人施加一个减益效果，使你的[[spell:259495]]造成额外伤害。在[[spell:1250646]]期间，该几率会提高[[talent:117562@AJwACA]]。使用[[spell:260285]]强化技能会自然地包含在你的正常的输出循环中，因此这个天赋不会影响你的操作。
- [[talent:136065@AJwACA]]赋予你另一个技能——[[spell:1264949]]，你可以在按下[[spell:1250646]]后的15秒窗口内施放它。
- [[talent:117575]]是你的英雄天赋顶点天赋，在消耗[[spell:1253601]]后会对你的主目标和附近敌人造成伤害。
- 在防御方面，[[talent:123349]]提供[[talent:117586]]，给予你一个最高相当于最大生命值10%的吸收护盾。
- [[talent:117577]]进一步提升你的机动性。

:::

:::tab [[talent:123350]]
[[talent:123350]]英雄天赋树主要强化[[talent:126314@FAQA9i_A]]、[[talent:126322]]以及你的宠物的普通攻击。

- 它的标志性技能是[[talent:117588]]，使你的[[talent:126314@FAQA9i_A]]每30秒召唤三种野兽之一，这个时间还会被[[talent:117589@FJQA5chADIA]]进一步缩短。每种野兽都会提供一种被动的伤害收益。
- 召唤野兽会使[[talent:126324]]的冷却时间缩短6秒。
- [[talent:117585@AJwACA]]使你的[[talent:135515]]造成更多伤害。
- [[talent:135514@FJgALl2Eq3yEDIA]]提供一次额外的野兽召唤，召唤出[[talent:117563@AJwACA]]，在你前方直线范围内持续造成伤害7秒。
- 在防御方面，[[talent:123350]]提供[[talent:117564]]，使你的[[talent:126488]]更加强大。
- 当你使用狡诈系的宠物时，[[talent:123781]]会强化你的[[spell:53271]]。

:::

:::

## 天赋

:::tabs
:::tab [[talent:123350]] 单目标
:::talents [[talent:123350]] 生存 猎人 团队副本中的单目标
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OgxMG2ILwMM0gFjZmxMWGAAAAAAmZmxMMjxMmBjpZAAAAGAMjllZmZhZmZGzMGwMbAWMGzYxA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OgxMG2ILwMM0gFjZmxMWGAAAAAAmZmxMMjxMmBjpZAAAAGAMjllZmZhZmZGzMGwMbAWMGzYxA"
}
```
:::

#### 英雄天赋树

- [[talent:128358]]
  
  - 生存与凶暴野兽没有任何联动，因此[[talent:117569]]是一个较弱的选择。

:::

:::tab [[talent:123350]] 多目标和范围伤害
:::talents [[talent:123350]] 生存 猎人 团队副本中的多目标和范围伤害天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwYGjZbkFDzwMawiZmZGzYZAAAAAAYmZGzwMGzYGMmmBAAAYAwMWWmZegFmZGjZGDYmNDYxYMzsYA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwYGjZbkFDzwMawiZmZGzYZAAAAAAYmZGzwMGzYGMmmBAAAYAwMWWmZegFmZGjZGDYmNDYxYMzsYA"
}
```
:::

:::

:::tab [[talent:123349]] 单目标
:::talents [[talent:123349]] 生存 猎人 团队副本中的单目标天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbGzMMzsNAAAAAAMjZmZYGjZMDGTzAAAAMAwYZbmZWYmZmxYGgZ2mxGjZMmxiBA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbGzMMzsNAAAAAAMjZmZYGjZMDGTzAAAAMAwYZbmZWYmZmxYGgZ2mxGjZMmxiBA"
}
```
:::

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 专精树

- [[talent:126323]]
  
  - 你需要围绕并强化正确法术的核心天赋之一。施放被 [[talent:126323]] 强化的技能时，你还会获得 [[talent:135512]] 的效果，它会通过 [[talent:136684]] 最多命中 3 个敌人。
- [[talent:135515]] 
  
  - 一个 1 分钟冷却的技能，其冷却时间可通过 [[talent:136683]] 和 [[talent:126316]] 进一步缩短。它还会通过 [[talent:136066]] 缩短 [[spell:259495]] 的冷却时间。由于 [[talent:135510]] 的存在，它在单体目标和 范围伤害 场景中都很强力。
- [[talent:135514@FJgALl2Eq3yEDIA]]
  
  - 你的主要爆发冷却技能，可通过 [[talent:136682]] 变得更强。借助 [[talent:135511]]，你可以每分钟使用一次，同时由于 [[talent:135689]]，它还会给予 3 层 [[talent:126323]]。

#### 职业树

- [[talent:126470]]
  
  - 与[[talent:126454]]结合使用，可为[[talent:126488]]提供额外一层充能并缩短其冷却时间，显著提升你的生存能力。
- [[talent:126465]]
  
  - 为[[spell:109304]]提供冷却时间缩减，改善你的自我治疗能力。
- [[talent:126475]]
  
  - 有了这个天赋，[[spell:781]]现在可以移除所有移动限制效果，并在4秒内提供一次移动速度爆发。
- [[talent:136670]]
  
  - 使你的[[talent:135711]]将被击晕的敌人拉到中心，为你的坦克提供更多风筝机会。
- [[talent:136673]]
  
  - 与[[talent:126490]]和[[talent:126481@AJwACA]]结合使用，可使你的[[spell:186265]]成为一个强大的2分钟防御技能。
- [[talent:136686]]
  
  - 2分钟的外部防御技能，你可以将其用于自己或队友，只要你的宠物生命值保持在25%以上，就能使其受到的伤害降低15%，持续最多10秒。

#### 英雄天赋树

- [[talent:117555@AJwACA]]
  
  - 在消耗[[talent:126323]]时提供额外的爆击伤害。
- [[talent:136521@AJwACA]]
  
  - 为[[spell:259495]]提供额外的冷却缩减。

:::

:::tab [[talent:123349]] 多目标和范围伤害
:::talents [[talent:123349]] 生存 猎人 团队副本中的多目标和范围伤害天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZmZYGjZMDGTzAAAAMAwYZbm5BWwMzMGzMgZ2mxGMjxMziB",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZmZYGjZMDGTzAAAAMAwYZbm5BWwMzMGzMgZ2mxGMjxMziB"
}
```
:::

### 何时使用该专精

在大多数情况下目标数量超过1个的战斗中使用这套天赋构筑。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[talent:135501]] 还会使 [[talent:126324]] 的伤害提高10%。
- **4件套：** [[talent:135515]] 的每一次爆炸都会使 [[talent:135501]] 的持续时间延长1秒。[[talent:135501]] 的效果提高10%。

### 单体目标

:::tabs
:::tab [[talent:123349]]
### 起手爆发

- 总体目标 **生存 猎人** 循环是避免溢出你的 **集中值**，不要在[[spell:259495]]和[[spell:259489]]等技能上浪费宝贵的冷却时间，并最大化[[talent:126323]]的价值来增益你最强的技能，详见 **优先级列表**.
- 在不使用[[talent:135689]]时，你应在[[talent:135514@FJgALl2Eq3yEDIA]]之前施放[[talent:126314@FAQA9i_A]]。

:::rotation [[talent:123349]] 生存 猎人 团本中的单体开局爆发
```json
{
  "source_code": "I8GaLIknXLAAAAwABgorDAAAAAgQyEDBAAQAf9BBF4ACWVxEFgANhDyEAAABQJ3bjBgQnWfCqQQi-kAHAEaDQEBGEUtQWhBAIUTTTA"
}
```
1. [[spell:186270]]  [[item:241288]] · [[spell:274738]] · [[item:270175]]
2. [[spell:1250646]]
3. [[spell:1253601]] 触发
4. [[spell:259495]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:1262293]]
9. [[spell:259489]]
10. [[spell:259495]]
11. [[spell:1264949]]
:::

- 在战斗前使用 [[spell:257284]]。
- 在使用 [[spell:1250646]] 之前，使用你的主动饰品 [[item:241308]] 或 [[item:241289]]，以及 [[spell:274738]] 等种族技能。
- [[talent:123349]]的起手式可能会根据你获得的[[spell:1253601]]触发次数而变化。你应该首先通过施放一个被[[talent:126323]]强化的[[spell:259495]]来消耗[[spell:1253601]]，然后继续执行起手式的其余部分。如果你没有[[spell:259495]]的层数，可以使用[[spell:1264949]]来减少它们的冷却时间。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 当你没有 [[talent:126323]] 层数时施放 [[talent:126314]]。
2. 通过施放 [[spell:259495]] 来消耗 [[spell:1253601]] 的触发效果。
3. 确保不要错过施放 [[spell:1264949]]。
4. 避免让 [[spell:259495]] 的充能达到上限。
5. 施放 [[spell:1261193]] 若已选择该天赋 且不会使你的 [[spell:259495]] 充能达到上限。
6. 在 [[spell:259495]] 充能少于 2 层且目标身上没有 [[spell:1253601]] 时施放 [[spell:1250646]]。 
   
   - 使用 [[talent:135689]] 时，尽量在进入 [[spell:1250646]] 之前没有 [[talent:126323]] 层数。
7. 按以下优先级消耗 [[talent:126323]] 层数：
   
   - 当你即将达到 2 层时施放 [[talent:126324]]
   
   
   
   - [[spell:1261193]] 若已选择该天赋
   - [[spell:1264949]]
   
   
   
   - [[spell:186270]]
8. 在集中值低于 70 时施放 [[talent:126314]]。
9. 施放 [[spell:186270]]。

:::

:::tab [[talent:123350]]
### 起手爆发

- **生存 猎人** 输出循环的总体目标是避免让 **集中值** 溢出，不要在 [[talent:135515]] 和 [[spell:259489]] 等技能上浪费宝贵的冷却时间，并最大化 [[talent:126323]] 的价值，用以强化 **优先级列表** 中详述的你最强大的技能。
- 在游玩 [[talent:135689]] 时，你应该跳过 [[talent:126314@FAQA9i_A]] 之前的 [[talent:135514@FJgALl2Eq3yEDIA]]。

:::rotation [[talent:123350]] 生存 猎人 团本中的单体开局爆发
```json
{
  "source_code": "IsGMLI0p1PAAAAAAC551CUACAEaBQwwABgorJgBIyEDBAAQAf9BBF4BCWVxEFgABJ6TCIAQoF4CDAI0p1ngLIsfNTUAIRgBKeetAAAAAAI0p1PA"
}
```
1. [[spell:259495]]
2. [[spell:186270]]
3. [[spell:259489]]  [[item:241288]] · [[spell:274738]] · [[item:270175]]
4. [[spell:1250646]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:1259003]]
9. [[spell:259489]]
10. [[spell:186270]]
11. [[spell:259495]]
:::

- 在战斗前使用 [[spell:257284]]。
- 在使用 [[spell:1250646]] 之前，使用你的主动饰品 [[item:241308]] 或 [[item:241288]] 以及种族技能如 [[spell:274738]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 当你没有 [[talent:126323]] 层数时施放 [[talent:126314]]，或用它召唤一只 [[talent:117588]] 动物。
2. 施放 [[spell:1261193]] 若已选择该天赋.
3. 施放 [[spell:1250646]]。 
   
   - 使用 [[talent:135689]] 时，尽量在进入 [[spell:1250646]] 之前没有 [[talent:126323]] 层数。
4. 注意不要让 [[talent:126324]] 的充能层数溢出。
5. 按以下优先级消耗 [[talent:126323]] 层数：
   
   - [[spell:1261193]] 若已选择该天赋
   
   
   
   - [[spell:1250646]]
   - [[talent:126324]]
   
   
   
   - [[spell:186270]]
6. 在集中值低于 70 时施放 [[talent:126314]]。
7. 施放 [[spell:186270]]。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:123349]]
### 起手爆发

- 与单体情况类似，你的目标保持不变，但你可以施放更多的[[spell:1261193]]和[[spell:259495]]。下面你可以看到在范围伤害情况下你的起手循环示例。

:::rotation [[talent:123349]] 生存 猎人 范围伤害 团本中的开局爆发
```json
{
  "source_code": "I8GaLIknXLAAAAwABgorDAAAAAgQyEDBAAQAf9BBF4ACWVxEFgANhDyEAAABQJ3bjBgQnWfCqQQi-kAHAEaDQEBGRgQEYgS1CNBAAAAACVTTTA"
}
```
1. [[spell:186270]]  [[item:241288]] · [[spell:274738]] · [[item:270175]]
2. [[spell:1250646]]
3. [[spell:1253601]] 触发
4. [[spell:259495]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:259495]]
9. [[spell:259489]]
10. [[spell:1262293]]
11. [[spell:1264949]]
:::

- 在战斗前对最高优先级目标使用 [[spell:257284]]。
- 在使用 [[spell:1250646]] 之前，使用你的主动饰品 [[item:241308]] 或 [[item:241289]]，以及 [[spell:274738]] 等种族技能。
- [[talent:123349]] 的起手手法可能会根据你获得 [[spell:1253601]] 触发的次数而改变。你应该首先通过施放被 [[talent:126323]] 强化的 [[spell:259495]] 来消耗 [[spell:1253601]]，然后继续执行起手手法的其余部分。如果你没有 [[spell:259495]] 的充能，可以使用 [[spell:1264949]] 来缩短它们的冷却时间。

### 优先级列表

1. 当你没有 [[talent:126323]] 层数时施放 [[talent:126314]]。
2. 通过施放 [[spell:259495]] 来消耗 [[spell:1253601]] 的触发效果。
3. 确保不要错过施放 [[spell:1264949]]。
4. 避免让 [[spell:259495]] 的充能达到上限。
5. 施放 [[spell:1261193]] 若已选择该天赋 且不会使你的 [[spell:259495]] 充能达到上限。
6. 在 [[spell:259495]] 充能少于 2 层且目标身上没有 [[spell:1253601]] 时施放 [[spell:1250646]]。 
   
   - 使用 [[talent:135689]] 时，尽量在进入 [[spell:1250646]] 之前没有 [[talent:126323]] 层数。
7. 按以下优先级消耗 [[talent:126323]] 层数：
   
   - 当你即将达到 2 层时施放 [[talent:126324]]
   
   
   
   - [[spell:1261193]] 若已选择该天赋
   - [[spell:1264949]]
   
   
   
   - [[spell:186270]]
8. 在集中值低于 70 时施放 [[talent:126314]]。
9. 施放 [[spell:186270]]。

:::

:::tab [[talent:123350]]
### 起手爆发

- 与单体情况类似，你的目标保持不变，但你可以施放更多的[[spell:1261193]]和[[spell:259495]]。下面你可以看到在范围伤害情况下你的起手循环示例。

:::rotation [[talent:123350]] 生存 猎人 范围伤害 团本中的开局爆发
```json
{
  "source_code": "IMGZLIknXLAAAAgABgorDAAAAAgQyEDBAAgQnWfCOAQoNgACWVxEF4BBJ6TCIEBGRgCC7XzEFAiPYAACeetA"
}
```
1. [[spell:186270]]  [[item:241288]] · [[spell:274738]]
2. [[spell:259495]]
3. [[spell:259489]]
4. [[spell:1250646]]
5. [[spell:1261193]]
6. [[spell:259489]]
7. [[spell:259495]]
8. [[spell:1259003]]
9. [[spell:259489]]
10. [[spell:259495]]
11. [[spell:186270]]
:::

- 在战斗前使用 [[spell:257284]]。
- 在使用 [[spell:1250646]] 之前，使用你的主动饰品 [[item:241308]] 或 [[item:241288]] 以及种族技能如 [[spell:274738]]。

### 优先级列表

这是你在整场战斗中都要努力保持的一般优先级。

1. 当你没有 [[talent:126323]] 层数时施放 [[talent:126314]]，或用它召唤一只 [[talent:117588]] 动物。
2. 避免让 [[spell:259495]] 的充能达到上限。
3. 施放 [[spell:1261193]] 若已选择该天赋 且不会使你的 [[spell:259495]] 充能达到上限。
4. 施放 [[spell:1250646]]。 
   
   - 使用 [[talent:135689]] 时，尽量在进入 [[spell:1250646]] 之前没有 [[talent:126323]] 层数。
5. 按以下优先级消耗 [[talent:126323]] 层数：
   
   - 当你即将达到 2 层时施放 [[talent:126324]]
   
   
   
   - [[spell:1261193]] 若已选择该天赋
   
   
   
   - [[spell:1250646]]
   
   
   
   - [[spell:186270]]
6. 在集中值低于 70 时施放 [[talent:126314]]。
7. 施放 [[spell:186270]]。

:::

:::

## 深度解析

### 利矛之刃

- 你在单体和范围伤害中的主要目标是让尽可能多的 [[talent:126324]]、[[spell:1261193]] 和 [[spell:1264949]] 获得 [[talent:126323]] 增益。
- 虽然有时你可能会发现自己积累了过多的 [[talent:126323]] 层数，尤其是在 [[spell:1250646]] 之外，但更重要的是让 [[spell:259489]] 保持冷却中，以尽量减少集中值短缺。

### 奔踏！

- 如果你选择了 [[talent:123350]] 英雄天赋，当你施放 [[talent:135514@AJwACA]] 时会获得 [[talent:117563@AJwACA]]。它会在你与 [[spell:259489]] 目标之间召唤一列野兽，在 7 秒内对敌人造成伤害。注意调整自己的站位，让 [[talent:117563@AJwACA]] 命中尽可能多的目标。留意坦克是否即将移动敌人，以便朝着坦克移动的方向施放 [[talent:117563@AJwACA]]。

### 当你发现自己处于近战范围之外时

- 尽管生存 猎人 有许多技能不需要你处于近战范围内，但有时机制可能会迫使你在一段时间内离开近战范围。在这种情况下，你可以使用[[spell:186289]]，它使你可以在40码距离外施放[[spell:186270]]，并确保[[spell:263135]]获得最大收益。
- [[spell:193265]]是一个非常弱的技能，除非实在没有其他技能可按，否则应避免施放它。

### 猎人印记

- 在 至暗之夜 中，[[spell:257284]] 被改为提供固定 3% 的伤害提升，无论目标的生命值如何。如果你所在的对战中有多个敌人但没有足够的猎人覆盖所有重要目标，你应该确保将你的 [[spell:257284]] 切换到当时的优先目标上。例如，在 **光盲先锋军** 遭遇战中，位于 **虚空尖塔** 中，你应该确保 [[spell:257284]] 永远不要放在被拉离团队的首领身上，除非你有足够的猎人来覆盖全部 3 个首领。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents 生存 猎人 内克扎莉 团队副本天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNDAAAAAgZMjZW2mxYGzgx0MAAAADAwy2MjFMzMjxMAzsNjtNYMmZWMA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNDAAAAAgZMjZW2mxYGzgx0MAAAADAwy2MjFMzMjxMAzsNjtNYMmZWMA"
}
```
:::

### 首领攻略技巧

- 利用[[talent:135711]]、[[talent:128412@FAQANQzE]]和[[talent:126457]]，确保**躁动的阿曼尼**不会到达中间区域。
- 当你被[[spell:1287426]]选中为目标时，务必使用一个防御技能，并远离团队，移动到房间边缘附近等待驱散。
- 为了尽可能少地损失精通收益，你应确保你的宠物一直跟随你。你可以通过使用宠物指令“跟随”来实现，也可以使用一个简短的 /petfollow 宏。

:::

:::tab 陵寝哨兵
:::talents 生存 猎人 陵寝哨兵 团队副本天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbGzMMzsNAAAAAAMjZMziZMmxMYMNDAAAwAAssNzMLMzMzYmZAmZbGbMMGzMLGA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbGzMMzsNAAAAAAMjZMziZMmxMYMNDAAAwAAssNzMLMzMzYmZAmZbGbMMGzMLGA"
}
```
:::

### 首领攻略技巧

- 当你位于有以下目标的一侧时： **乌拉特克之息**，切换攻击目标至**毒液凝块**，在其出现后立即转火。
- 在有以下目标的一侧时，务必分担 [[spell:1288232]]： **乌拉特克之血**.

:::

:::tab 迷失的探险者
:::talents 生存 猎人 迷失的探险者 在团队副本中的天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMziZMmxMYMNDAAAwAAjltZmHYBzMzYmZAmZbGbMMGzMLG",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMziZMmxMYMNDAAAwAAjltZmHYBzMzYmZAmZbGbMMGzMLG"
}
```
:::

### 首领攻略技巧

- 如果你选取了**恶心的鱼** ，务必将其用在一只之前未被鱼影响过的乌龟身上。
- 为了尽可能少地损失精通收益，你应确保你的宠物一直跟随你。你可以通过使用宠物指令“跟随”来实现，也可以使用一个简短的 /petfollow 宏。
- 如果你要吸收由**商人盖博的**[[spell:1291933]]产生的大量箱子，请使用一个防御技能。
- 打断**书卷贤者伊库的**[[spell:1286921]]。

:::

:::tab 瓦什尼克
:::talents 生存 猎人 万毒邪祟者瓦什尼克 在团队副本中的天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMziZMmxMYMNDAAAwAAjltZmHYBzMzYmZAmZbGbbwYMzsYA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMziZMmxMYMNDAAAwAAjltZmHYBzMzYmZAmZbGbbwYMzsYA"
}
```
:::

### 首领攻略技巧

- 务必击杀首领刷新的三种小怪： **结块毒液、幽蔽毒液和燃烧剧毒**. 不要让它们到达房间中央非常重要，你可以对所有目标使用 [[talent:128412]] 和 [[talent:135711]]，除了 **结块毒液**。注意不要连续迅速击杀燃烧剧毒小怪，以免 [[spell:1285979]] 的爆炸重叠。
- 当你被 [[spell:1281907]] 施加负面状态时，注意不要打到队友。

:::

:::tab 斯索拉克
:::talents 生存 猎人 斯索拉克 团队副本天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbGzMMzsNAAAAAAMjZmZYGjZMDGTzAAAAAAGLbzMzCzMzMzMDgZ2mxGDjxMWM",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbGzMMzsNAAAAAAMjZmZYGjZMDGTzAAAAAAGLbzMzCzMzMzMDgZ2mxGDjxMWM"
}
```
:::

### 首领攻略技巧

- 如果你在受到[[spell:1285419]]的负面效果影响时远离了团队，且无法与另一名玩家接触，你可以使用[[spell:781]]和[[spell:190925]]，以免被吹下平台。
- 当你被[[spell:1305959]]影响时，使用一个防御技能，并将[[spell:1287008]]放置在远离团队的位置。
- 当你点出[[talent:126452]]天赋时，可以使用[[spell:5384]]来驱散自己身上的[[spell:1287072]]。

:::

:::tab 双生利牙
:::talents 生存 猎人 双子毒牙 在团队副本中的天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMDzYMjZwYaGAAAgBAGLbzMPwCmZm5BmZGgZ2mxGDjxMziB",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMDzYMjZwYaGAAAgBAGLbzMPwCmZm5BmZGgZ2mxGDjxMziB"
}
```
:::

### 首领攻略技巧

- 分摊 [[spell:1289993]]，但注意不要分摊太多次数，以免死于 [[spell:1290336]]。
- 尽快击杀 **维克苏尔之嗣** 。
- 分摊 [[spell:1290516]] 以消除 [[spell:1290336]] 的层数。

:::

:::tab 盘绕祭坛
:::talents 生存 猎人 盘卷祭坛 团本天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZmZYGjZMDGTzAAAAAAGLbzMPwCmZmZmZAMz2M2YYMmZWMA",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZmZYGjZMDGTzAAAAAAGLbzMPwCmZmZmZAMz2M2YYMmZWMA"
}
```
:::

### 首领攻略技巧

- 吸收 [[spell:1283489]]，你可以使用 [[spell:190925]] 快速回到首领身边，但要小心路上的 [[spell:1282403]]。
- 当你点出 [[talent:126452]] 天赋时，可以使用 [[spell:5384]] 解除自己身上的 [[spell:1282287]]。
- 打断 [[spell:1286399]] 来自 **怨毒盘卷蛇** 并击杀他们。
- 小心躲避正在锁定你的 **恐惧具象** 它们正在锁定你。
- 拾取你的 **灵魂碎片** ，以在被 [[spell:1310882]] 击中后消除 [[spell:1286837]]。

:::

:::tab 乌拉特克
:::talents 生存 猎人 乌拉特克 团队副本天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZmZWMjxMmBjpZAAAAGAYssNz8ALYmZGjZAmZbGbMMGzMLG",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZmZWMjxMmBjpZAAAAGAYssNz8ALYmZGjZAmZbGbMMGzMLG"
}
```
:::

乌拉特克 暂时无法进行测试，首领攻略提示将在开荒后更新。

:::

:::tab 尼姆瑞莎·唤波者
:::talents 生存 猎人 尼姆瑞莎·唤波者 团本天赋
```json
{
  "source_code": "C-PAe4d-yQ5lSoc6yFim_XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMzy2MGzYGMmmBAAAYAgxy2MzDsgZmZMmBYmtZstBjxMziB",
  "code": "C+PAe4d+yQ5lSoc6yFim/XEz3OWwMzYmZb0ssMMDzMNYbmZmZMzsNAAAAAAMjZMzy2MGzYGMmmBAAAYAgxy2MzDsgZmZMmBYmtZstBjxMziB"
}
```
:::

## 首领攻略技巧

- 击杀从竞技场边缘刷新的鱼人小怪。你可以使用 [[talent:128412]]、[[talent:135711]] 和 [[talent:126457]] 来阻止它们到达中央。

:::

:::

## 属性优先级

了解你在 团队副本 Boss 战期间获得最佳表现所需的次要属性优先级和第三属性，作为一名 **生存 猎人**。欲了解更多详细信息，请访问 **[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority 生存 猎人 ⟦WOWTERM_00003⟧ 团本属性
```json
{
  "source_code": "IgAHEEDJggSADQA"
}
```
**精通 ＞ 急速 ≥ 暴击 ≫ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可以减少"**范围伤害**"技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外治疗。你的宠物造成的伤害无法为你回血，因此**吸血**对你来说是一个极佳的副属性，因为你的大部分伤害都来自你自己的法术。
- **加速** - 小众副属性，但在某些情况下非常有用，并且过去已被证明其实用性。能让处理某些副本机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
在具有顺劈斩的团队副本战斗中，[[item:268213@DgQAA8PAFk7IoAYF]]搭配[[item:270173@BgQAA8PACKAWBA]]时可能是比[[item:268215@DgQAA8PAFk7IoAYF]]更好的武器。

在12.1版本中，使用催化转换器转化物品时会保留其属性和附加效果，这意味着你的套装槽位可以拥有完美的属性。在积攒足够的Venomblight Manaflux充能以催化转化属性更好的物品之前，你应当继续使用从套装代币获得的套装部件。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271492@DiQAA8PANk7cVrjgC4UA]] | 双子毒牙 |
| 项链 | [[item:268265@BERAA8PAE06QQrjgCwYNYFA]] | 乌拉特克 |
| 肩部 | 将[[item:268231@DgQAA8PA7j7IoAYF]]  <br>转化为[[item:271490@DgQBA8PAXk7IoAYFwxXQ]] | 盘卷祭坛之触媒 |
| 披风 | [[item:268253@BgQAA8PACKAWBA]] | 盘卷祭坛 |
| 胸部 | 将 [[item:271876@BARAA8PACKAj1gVA]]  <br>转化为[[item:271495@DARBA8PAJk7IoAMWDWBQgJE]] | 乌拉特克之触媒 |
| 护腕 | [[item:244584@FCSAA8PAno6gBwD_sOAAAAAAAA3WzSB]] | 制造装备 |
| 手套 | 将 [[item:160213@BgQAA8PACKgTBA]]  <br>转化为[[item:271493@BgQBA8PACKgTBUdcCA]] | 诸王之眠之触媒 |
| 腰带 | [[item:244581@FCSAA8PAno6gBwD_sOAAAAAAAA3WzSB]] | 制造装备 |
| 腿部 | 将 [[item:268237@DgQAA8PAhu7IoAYF]]  <br>转化为[[item:271491@DgQBA8PAhu7IoAYFQzXQ]] | 盘卷祭坛之触媒 |
| 靴子 | [[item:268233@DgQAA8PAPk7IoAOF]] | 斯索拉克 |
| 戒指 1 | [[item:252258@DiQAA8PA1j7wPrjgC4UA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:273792@DiQAA8PA1j7wPrjgC4UA]] | 毒牙祭坛 |
| 饰品 1 | [[item:270175@BgwAA8PACKAWBUAABYzFCA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgQAA8PACKAWBA]] | 盘卷祭坛 |
| 武器 | [[item:268215@DARAA8PAFk7IoAWYDWB]] | 乌拉特克 |

:::

:::tab 可刷取的替代装备
以下为你呈现一份优质的、可在魔兽世界每周副本锁定系统之外获取的可刷取替代装备清单。虽然随着你的进度推进它们最终会被替换，但这些装备能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251220@BgQAA8PACKQQBA]] | 虚空之痕竞技场 |
| 颈部 | [[item:251234@BgQAA8PACKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:239049@BgQAA8PACKQQBA]] | 诸王之眠 |
| 披风 | [[item:251190@BgQAA8PACKQQBA]] | 夺目谷 |
| 胸部 | [[item:251233@BgQAA8PACKQQBA]] | 虚空之痕竞技场 |
| 护腕 | [[item:251200@BgQAA8PACKQQBA]] | 夺目谷 |
| 手套 | [[item:160213@BgQAA8PACKQQBA]] | 诸王之眠 |
| 腰带 | [[item:251228@BgQAA8PACKQQBA]] | 虚空之痕竞技场 |
| 腿部 | [[item:159375@BgQAA8PACKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:159388@BgQAA8PACKQQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:252258@BgQAA8PACKQQBA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:273792@BgQAA8PACKQQBA]] | 毒牙祭坛 |
| 饰品 1 | [[item:273796@BgQAA8PACKQQBA]] | 毒牙祭坛 |
| 饰品 2 | [[item:250228@BgQAA8PACKQQBA]] | 密谋小径 |
| 武器 | [[item:251149@BgQAA8PACKQQBA]] | 纳洛拉克的洞穴 |
| 双持备选 | [[item:275070@BgQAA8PACKQQBA]] | 毒牙祭坛 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 等级 | 饰品 |
| --- | --- |
| S 级 | [[item:270164@BgQAA8PACKgTBA]]  <br>[[item:270175@BgwAA8PACKAWBUAABYzFCA]]  <br>[[item:270173@BgQAA8PACKAWBA]] |
| **A 级** | [[item:270165@BgQAA8PACKgTBA]]  <br>[[item:273796@BgQAA8PACKgTBA]]  <br>[[item:250228@BgQAA8PACKgTBA]] |
| **B 级** | [[item:250214@BgQAA8PACKgTBA]] *-- 需要站在光柱中以获得最大收益*  <br>[[item:250259@BgQAA8PACKgTBA]]  <br>[[item:270168@BgQAA8PACKAWBA]] *-- 在特定情况下可用于爆发性的按需伤害*  <br>[[item:273797@BgQAA8PACKgTBA]]  <br>[[item:159617@BgQAA8PACKgTBA]]  <br>[[item:250215@BgQAA8PACKgTBA]] |
| **C 级** | [[item:248583@BgQAAcEACKQQBA]] *-- 无法超过英雄装备档位*  <br>[[item:251783@BgQAAcEACKQQBA]] *-- 无法超过英雄装备档位*  <br>[[item:274493@BgQAA8PACKQQBA]] *-- 无法超过英雄装备档位*  <br>[[item:251792@BgQAAcEACKQQBA]] *-- 无法超过英雄装备档位*  <br>[[item:265657@BgQAAcEACKQQBA]] -- 无法超过英雄装备档位 |
| 废品场 | [[item:270166@BgQAA8PACKgTBA]]  <br>[[item:274496@BgQAA8PACKQQBA]]  <br>[[item:274497@BgQAA8PACKQQBA]]  <br>[[item:193757@BgQAA8PACKgTBA]]  <br>[[item:158374@BgQAA8PACKgTBA]]  <br>[[item:250225@BgQAA8PACKgTBA]]  <br>[[item:251782@BgwAAcEACKQQBUAABYzFCA]] *-- 无法超过英雄装备档位*  <br>[[item:251785@BgQAAcEACKQQBA]] *-- 无法超过英雄装备档位*  <br>[[item:251784@BgQAAcEACKQQBA]] *-- 无法超过英雄装备档位* |

### 美化饰品

- 在护腕和腰带上制作 [[item:240167]]。
- 在开荒初期，将 [[item:245876]] 制作在武器上，或将 [[item:240167]] 制作在头部等高属性部件上，也是不错的选择。

#### 剩余的火花

- 制作装备的最高装备等级为 331，而普通装备的最高装备等级为 334（部分装备可达 344），因此除非你在该部位没有其他高装备等级的装备可用，否则除了 2 件美化装饰之外，佩戴制作装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **瓶装药剂**
  
  - [[item:241322]] *-- 最大化 DPS。*
  
  
  
  - [[item:241320]] *-- DPS 略低，但生存能力更强。*
- **食物**
  
  - [[item:255846]] *-- 盛宴*
  
  
  
  - [[item:242747]] -- 个人食物，缺少盛宴提供的耐力加成
- 战斗药水
  
  - [[item:241308]] -- *提供敏捷*
  
  
  
  - [[item:241289]] -- 提供次要属性，目前为推荐选择
- 生命药水
  
  - [[item:271884]]
- **武器磨刀石/油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240900]]
  
  
  
  - [[item:240983]] *-- 唯一*

### 附魔

:::columns
:::column
| 头部 | [[item:244007@BAAAA8P]]  <br>[[item:275707@BAAAA8P]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAA8P]] |
| 胸部 | [[item:243977@BAAAA8P]] |
| 护腕 | [[item:275707@BAAAA8P]] |
| 腰带 | [[item:275707@BAAAA8P]] |
| 腿部 | [[item:244641@BAAAA8P]] |
| 靴子 | [[item:243983@BAAAA8P]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 主手 | [[item:244031@BAAAA8P]] |
| 副手 | [[item:243973@BAAAA8P]] |

:::

:::column
:::gear 生存 猎人 团队副本中的附魔
```json
{
  "source_code": "IQFZ_DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAABUQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAA8P]]，为你的 **头部**、**护腕** 和 **腰带** 添加宝石插槽。

## 种族

对于在团队副本中极限优化 **生存 猎人** 来说，不同的种族特性可以为你的角色带来巨大的收益。如果这并非你的首要目标，选择一个符合你风格的种族也同样可行。

- [[spell:20594]] -- 矮人
  
  - 可以按需驱散你身上的大量负面效果，同时在使用时为你提供 10% 的物理伤害减免。
- [[spell:59224]] -- 矮人
  
  - 被动提高你的爆击伤害和治疗 2%。

- [[spell:59752]] -- 人类
  
  - 可以解除某些控制效果，即使在 PvE 场景中也有效。
- [[spell:20598]] -- 人类
  
  - 你从所有来源获得的次级属性提高 2%。

- [[spell:256948]] -- 虚空精灵
  
  - 向你的前方掷出一个暗影投射物，如果在投射物掷出后再次按下此技能，你会传送到它当前所在的位置。在需要移动时偶尔极其有用。
- [[spell:255669]] -- 虚空精灵
  
  - 偶尔赋予你在 12 秒内所有法术伤害提高 5% 的效果。

- [[spell:20549]] -- 牛头人
  
  - 将附近最多5个敌人眩晕2秒。
- [[spell:20550]] -- 牛头人
  
  - 提高你的最大生命值。
- [[spell:154743]] -- 牛头人
  
  - 被动提高你的 暴击伤害和治疗 效果2%。

- [[spell:274738]] *--* 玛格汉兽人
  
  - 在两分钟冷却时间内提高你两项最高属性之一。

- [[spell:69070]] -- 地精
  
  - 与 [[spell:781]] 大致相同，只不过是向前弹射而不是向后。在需要大量移动的某些首领战中可能非常有用。
- [[spell:69042]] -- 地精
  
  - 提高你的 急速 1%。

- [[spell:107072]] -- 熊猫人
  
  - 使你从 进食充分 效果中获得的属性翻倍。

- [[spell:1238623]] -- 哈拉尼尔
  
  - 被动使你的爆击伤害和治疗效果提高 1%。
- [[spell:1238677]] -- 哈拉尼尔
  
  - 被动使你对畸变体、野兽和元素生物造成的伤害提高 1%。

### 推荐

总体来说，可以肯定地说，如果你在意将 DPS 最大化（min-max），就应该选择目前 DPS 最高的种族，即熊猫人。话虽如此，如果涉及开荒团本，情况就有所不同了。一些功能性种族技能可以帮助应对特定首领的机制。值得注意的是，矮人的[[spell:65116]]可用于驱散负面效果，而[[spell:256948]]来自虚空精灵的技能可用于闪现穿越某些机制。

## 宏

探索推荐的**生存猎人**在团队副本战斗中的实用宏，并观看一段快速视频教程，学习如何为你的角色制作简单宏。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:187650]]** -- *在无需确认的情况下，将[[spell:187650]]施放在你的鼠标指针位置。*

```wow-macro
#showtooltip 冰冻陷阱    
/cast [@cursor] 冰冻陷阱
```

**[[talent:126457]] --** *在无需确认的情况下，将[[talent:126457]]施放在你的鼠标指针位置。*

```wow-macro
#showtooltip 焦油陷阱    
/cast [@cursor] 焦油陷阱
```

**[[talent:135711]]] --** *在鼠标光标位置施放[[talent:135711]]，无需确认。*

```wow-macro
#showtooltip 束缚射击
/cast [@cursor] 束缚射击
```

:::

:::details 鼠标指向宏
**[[talent:126324]]** -- *这个宏在某些特殊情况下有其用途：你不想切换当前目标，但若从当前目标投掷炸弹，其命中目标数量会少于从另一个目标投掷。这类情况的典型例子是新的虚空尖塔团队副本中的**弗拉希乌斯**。*

```wow-macro
#showtooltip 野火炸弹
/use [@mouseover,exists,harm,nodead][]野火炸弹
```

**[[talent:135712]]** -- *对鼠标指向目标或当前目标施放 [[talent:135712]]。*

```wow-macro
#showtooltip 宁神射击
/use [@mouseover,exists,harm,nodead][]宁神射击
```

**[[spell:53271]]** *-- 施放 [[spell:53271]]，优先级依次为：鼠标指向目标、指定玩家名，最后是你自己。请将第三行中的玩家名和服务器名替换为你想要对其施放 [[spell:53271]] 的人。*

```wow-macro
#showtooltip 主人的召唤
/cast [@mouseover,exists,help] 主人的召唤
/cast [@PlayerName-PlayerRealm] 主人的召唤
/cast [] 主人的召唤
```

:::

:::details 宠物宏
[[talent:126322]] pet attack -- *对当前目标施放[[talent:126322]]以及你宠物的基础攻击*。

```wow-macro
#showtooltip 猛禽一击
/petattack
/cast 猛禽一击
/cast [@pettarget]爪击
/cast [@pettarget]撕咬
/cast [@pettarget]拍击
```

**[[talent:126314]]** pet attack/pet call -- *对当前目标施放[[talent:126314]]以及你宠物的基础攻击**。如果你没有宠物，该宏会[[spell:23498]]你列表中的第一只宠物。如果想召唤其他宠物，只需更改编号或调整宠物顺序即可。*

```wow-macro
#showtooltip 杀戮命令
/petattack
/cast [pet] 杀戮命令; 召唤宠物 1
/cast 爪击
/cast 撕咬
/cast 拍击
```

**[[spell:136]]** *-- 宠物存活时施放 [[spell:136]]，宠物死亡时施放 [[spell:982]]。*

```wow-macro
#showtooltip
/cast [exists, nodead, @pet] 治疗宠物; [exists, @pet] 复活宠物
```

:::

:::details 实用 宏
**[[spell:186265]]** 宏 -- *再次按下该宏时可以立即取消[[spell:186265]]* *，适用于你只需免疫一次伤害，或需要用[[talent:126452]]驱散某个减益效果的情况。*

```wow-macro
#showtooltip 灵龟守护
/cancelaura 灵龟守护
/stopcasting
/stopcasting
/cast 灵龟守护
```

:::

:::

## 插件

下方是作者为其 **生存 猎人**所用用户界面的截图，其中概述了使用了哪些插件以及它们在团队副本中如何帮助你更轻松地进行游戏。

![Survival Hunter User Interface in Raids](<https://assets-ng.maxroll.gg/wordpress/raiduiedited-2-1024x650.png>)

生存 猎人团队副本用户界面

:::accordion
:::details 插件
- **MRT** -- 记事、团队副本冷却监控及更多功能
  
  - 对团队副本玩家非常有用的插件，尤其适合团队副本指挥和官员。
- **BetterBlizzFrames** -- 单位框体美化插件
  
  - 为默认单位框体提供更多自定义选项。内置大量预设配置文件，如果你不想自己配置，可以直接试用。
  - 当然，你也可以使用 ElvUI 或原生界面。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一个首领战斗插件，由许多独立的战斗脚本（即首领模块）组成。这些迷你插件旨在为团队副本战斗提供警报信息、计时条、音效等提示。
- **BetterBlizzPlates**  -- 姓名板美化插件
  
  - BetterBlizzPlates 是一款姓名板插件，拥有极其丰富的设置选项，并开箱即用地提供减益效果监控和仇恨着色功能。
- **Details** -- 深度伤害统计插件
  
  - 最强大、最可靠、最漂亮的伤害统计插件。

:::

:::

## 本次版本改动

:::accordion
:::details 12.0版本补丁.1
**猎人**

- 英雄天赋
  
  - 猎群领袖
    
    - 猪突猛进现在持续1分钟（原为20秒）。
    - 猪突猛进现在会在开始团队副本战斗或大秘境地下城时被取消。
    - 致命倒钩已更新——自动攻击现在有极高几率产生3点集中值，而不是每次自动攻击获得1点集中值。
    - 修复了精通：灵魂联结错误地对来自猎群领袖英雄天赋的某些召唤物生效两次的问题。
  
  
  
  - 哨兵
    
    - 开放火焰已重新设计——火焰造成的伤害提高5%。
    - 侦察者的警醒在使用伪装时不再增加潜行侦测半径。
    - 月亮的祝福现在在施放哨兵印记时提供6秒的野火炸弹冷却缩减（原为4秒）。
    - 哨兵印记的持续时间延长至16秒（原为12秒）。
    - 修复了猛禽横扫可能导致哨兵印记被施加到非当前选中目标上的问题。如果你在使用猛禽横扫时没有选中目标，则会选择一个被猛禽横扫命中的目标。

**生存**

- 新天赋：锋锐之刃 – 猛禽一击、猛禽横扫和杀戮命令的爆击几率提高10%，造成的爆击伤害提高10%。
- 新天赋：投弹手 – 野火炸弹的伤害、爆击几率和造成的爆击伤害提高15%。
- 野火灌注已被重新设计 – 投掷野火炸弹有几率用烈焰灌注你的武器，使你和你的宠物的自动攻击在10秒内造成额外的火焰伤害。
- 榴弹杂耍已被重新设计 – 爆裂火铳使野火炸弹的冷却恢复速度提高60%，持续8秒。
- 榴弹杂耍现在会在冷却管理器中被追踪。
- 突进现在使你的敏捷提高3%（原为2%），双持时额外提高1%（原为2%）。
- 野火弹药现在为野火炸弹提供3秒冷却缩减（原为2秒）。
- 原始涌动已移至天赋树中更容易获取的位置。
- 修复了外域之毒未能被来自猎人、其当前宠物或猎群领袖英雄天赋的其他召唤物的各种周期性效果正确施加的问题。
- 以下天赋已被移除：
  
  - 焰牙沥青
  - 鲜血之雨

:::

:::

## 常见问题

:::accordion
:::details 问：生存的最佳宠物是什么？
**答：** 所有宠物造成的伤害都相同，唯一的重大区别在于它们的科别，每个科别提供不同的法术：

- 狡诈系宠物提供 [[spell:53271]] 和 [[spell:264656]]。
- 狂野系宠物提供 [[spell:264667]] 和 [[spell:264663]]。
- 坚韧系宠物提供 [[spell:388035]] 和 [[spell:264662]]。

每个系的宠物都有其用途，因此建议至少每个系都准备一只宠物，并根据需要随时更换。

:::

:::

---

### 致谢

作者：**Heleni**

审校：**Ftm**

---

:::changelog 更新记录
**2026-08-08** 更新至12.1版本。

**2026-06-16** 更新至12.0.7版本。

**2026-04-22** 更新至12.0.5版本。

**2026-02-20** 更新至12.0.1版本。

**2026-01-11** 更新至12.0版本。

**2025-10-06** 更新至11.2.5版本。

**2025-08-02** 更新至11.2版本。

**2025-02-22** 更新至11.1版本。

**2024-12-17** 更新至11.0.7版本。

**2024-10-20** 更新至11.0.5版本。

**2024-08-17** 更新至11.0.2版本。

**2024-07-24** 攻略写于11.0.1前夕版本。



:::
