欢迎来到魔兽世界12.1版本的**踏风 武僧** 团队副本攻略！本攻略涵盖了你需要了解的关于你角色的所有内容！你是刚刚起步、从80级开始练级的吗？快去看看练级攻略吧！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 3/5 · 一般

范围伤害 · 4/5 · 强力

功能性 · 5/5 · 极佳

生存能力 · 2/5 · 较弱

机动性 · 5/5 · 极佳



:::

:::

:::column
:::gear **踏风 武僧** 团队副本 最佳装备（BiS）
```json
{
  "source_code": "JUrAY3QA3_PAB8JJEIIMBAQD5OwVtOAf1IYNXYjt1ghNCKAWBEQ6XQAApEAA8z6A8z6AMWDZ1ghNeVTBaQSnkQAAgEAA-VTgFwCPOFQAiSCBCASAAkQuDoXNCGRFQA-FEAIIFEUA6Qgt1UAPA4ZCqwQo7OQfNoCNYFQAf5mACgQAAkSuDIYAOBBY7OAgIVQOwDktvMWNRDzt1YTN6FjVi4INAMySBEA9UPAAYEAA2IjX1caJOFQA5Z9ACiRAAUPuDwPrDAwI2-yt1sUABIW2DIIIB0gFEQWNB4CHWiiTBEwXfQQA-EwkUkjAYFQAdlBEFEKGdfBBAgQAAUAD8c7FEIAEBAwP5OgF2IoAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240983]] · [[item:243981]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271517]] |  |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159327]] | [[item:244009]] |
| 腕部 | [[item:244576]] | [[item:240892]] |
| 手部 | [[item:251124]] |  |
| 戒指一 | [[item:251513]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244031]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**踏风 武僧**，你可以使用虎眼酒，它会在[[talent:124826]]期间提高你的爆击几率。

**等级2**会提高你的爆击伤害总量。

而**等级3**则会解锁一个新技能[[spell:1272696]]！

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-windwalker-mxr.webp>)

虎眼酒

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:128711]]
    
    - 你在范围伤害中获得[[talent:124985@FAgATZfABdhA]]伤害，因为它现在具有溅射效果。
  - [[talent:134543@AJgCCA]]
    
    - 在消耗[[spell:116768]]后有较高几率获得免费的强化[[talent:124985@FAgATZfABdhA]]。
  - [[talent:128712]]
    
    - 增强你的[[talent:125026]]。
  - [[talent:124815]]或[[talent:124814]]
    
    - 强化你的[[talent:126307]]。
  - [[talent:124817@FAQABdhA]]
    
    - 在你的[[talent:125026]]结束时提供一次额外打击。
- **职业天赋树**
  
  - [[talent:124956]]
    
    - 施放[[talent:124826]]后提供可观的伤害。
  - [[talent:124953]]
    
    - 提高你的自动攻击造成暴击的几率。
  - [[talent:136520]]
    
    - 成功驱散后目标会更快！
- **已移除**
  
  - [[spell:137639]]
    
    - 被你的新冷却技能[[talent:124826]]取代。
  - [[spell:123904]]
    
    - 没有这个冷却技能，你从一个2分钟的职业技能变为另一个状态。
  - [[spell:393039]]
  - [[spell:459809]]
    
    - 移除了你攻击分散目标的能力。
  - [[spell:122783]]
    
    - 失去一个防御技能确实会让你更脆弱。
  - [[spell:388686]]
    
    - 敌人在你的冷却技能期间拥有更多的行动自由。

## 英雄天赋

- 在单体目标战斗中，两个英雄天赋 [[talent:125027]] 和 [[talent:125047]] 表现非常接近，但由于 [[talent:125047]] 的爆发伤害更高，它很可能是更好的选择。
- [[talent:125027]] 在 范围伤害 场景中远胜于 [[talent:125047]]。

:::tabs
:::tab [[talent:125027]]
- 你的自动攻击有几率产生 1-2 层 [[spell:451021]]，施放 [[spell:113656]] 时你会释放所有的 [[spell:451021]] 层数。

- [[talent:125072@AJgCCA]]
  
  - 使[[talent:124826]]的冷却时间缩短10秒。
- [[talent:125073@AJgCCA]]
  
  - 在[[talent:124826]]期间，你的[[talent:124985@FAgATZfABdhA]]和[[spell:101546]]最多释放3道[[spell:451021]]。
- [[talent:135955]]
  
  - [[talent:125069@AJgCCA]]对6码范围内的所有敌人造成伤害。
- [[talent:135956@AJgCCA]]
  
  - 施放[[talent:124826]]后，你将获得10层[[talent:125069@AJgCCA]]，并将在你下一次施放技能时触发。
- [[talent:135957@AJgCCA]]
  
  - 使[[talent:124956]]提高20%。

:::

:::tab [[talent:125047]]
- 获得 [[talent:125062@FAQAfGPB]] 的使用权，这是一个强大的 120 秒冷却技能。
- [[talent:136744]]
  
  - 使 [[talent:125062@FAQAfGPB]] 的冷却时间缩短 30 秒。
- [[talent:136745@AJgCCA]]
  
  - 获得在召唤 [[talent:125062@FAQAfGPB]] 后施放 [[talent:136745@AJgCCA]] 的能力。
- [[talent:125055]]
  
  - 你的 [[talent:125014]] 和你的 [[talent:134452]] 使你的 [[talent:124985]]、[[spell:113656]]、[[talent:125014]] 和 [[talent:125011]] 获得 75% 冷却缩减。
  
  
  
  - 当它生效时，你的 [[spell:113656]] 引导时间缩短 50%。
- [[talent:136754@AJgCCA]]
  
  - 施放 [[talent:124826]] 后获得 [[talent:135959@AJgCCA]]，持续 4 秒。
- [[talent:135958@AJgCCA]]
  
  - 当 [[talent:135959@AJgCCA]] 生效时，你的急速提高 10%。
- [[talent:125058]]
  
  - 完成你的 [[talent:136745@AJgCCA]] 后，你会召唤出所有天神。
  - 也可以提前结束引导以更快地召唤出它们。

:::

:::

## 天赋

:::tabs
:::tab [[talent:125027]] 单体目标
:::talents [[talent:125046]] **踏风 武僧** 团本中的单体目标天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 专精树

- [[talent:125009]]
  
  - [[talent:134452]] 和 [[talent:125014]] 使你必定触发一次 [[spell:116768]]。
- [[talent:124825]]
  
  - [[talent:124826]] 的持续时间延长 5 秒。
- [[talent:124810]]
  
  - 你有几率恢复 1 真气 （使用 [[talent:124985@FAgATZfABdhA]] 时）。
- [[talent:126307]]
  
  - 产生2点 真气 通过 [[talent:124815]]。[[talent:124829]]
- [[talent:124829]]
  
  - 产生1点 真气 在消耗一次 [[spell:116768]] 触发之后。
- [[talent:124823]]
  
  - 在 [[talent:124826]] 期间，你的 [[spell:100784]] 会产生 1 真气.

### 职业树

- [[talent:124956]]
  
  - 激活 [[talent:124826]] 会在你周围释放一次强力的 [[talent:124817@FAQABdhA]]。
- [[talent:124975]]
  
  - 使 [[spell:322111]] 的冷却时间缩短 90 秒。

#### 英雄天赋

- [[talent:125068]]
  
  - 你的默认选择，因为[[talent:125067]]较弱。
- [[talent:125076]]
  
  - 个人喜好问题，但很可能比[[talent:125075]]更好。
- [[talent:125065]]
  
  - 你的默认选择，但你也可以选[[talent:125064]]。

:::

:::tab [[talent:125027]] 范围伤害
:::talents [[talent:125046]] **踏风 武僧** 团本中的范围伤害天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

### 何时使用该专精

如果你在战斗中长时间面对4个或更多敌人，请使用这套专精。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 专精树

- **新增**
  
  - [[talent:134452]]
  - [[talent:124836]]
  - [[talent:128711]]
  - [[talent:124824]]
- **移除**
  
  - [[talent:124825]]
  - [[talent:125019]]
  - [[talent:125014]]
  - [[talent:124823]]

#### 英雄天赋

- [[talent:125068]]
  
  - 你的默认选择，因为[[talent:125067]]较弱。
- [[talent:125076]]
  
  - 个人喜好问题，但很可能比[[talent:125075]]更好。
- [[talent:125065]]
  
  - 你的默认选择，但你也可以选[[talent:125064]]。

:::

:::tab [[talent:125047]] 单目标
:::talents [[talent:125047]]  团本中的踏风 武僧单目标天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYM2GGsMzMbzAAAAAAAAAAAAsMMTYGwAMzwMzMDzywMMLzEAwiZ2GzYmZmBAwiZZZ2GTQAAYAMDwYbAjZmZzH",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYM2GGsMzMbzAAAAAAAAAAAAsMMTYGwAMzwMzMDzywMMLzEAwiZ2GzYmZmBAwiZZZ2GTQAAYAMDwYbAjZmZzH"
}
```
:::

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 专精树

- [[talent:125009]]
  
  - [[talent:134452]] 和 [[talent:125014]] 使你必定触发一次 [[spell:116768]]。
- [[talent:124825]]
  
  - [[talent:124826]] 的持续时间延长 5 秒。
- [[talent:124810]]
  
  - 你有几率恢复 1 真气 （使用 [[talent:124985@FAgATZfABdhA]] 时）。
- [[talent:126307]]
  
  - 产生2点 真气 与 [[talent:124815]]。
- [[talent:124829]]
  
  - 产生1点 真气 在消耗一次 [[spell:116768]] 触发之后。

#### 职业树

- [[talent:124956]]
  
  - 激活 [[talent:124826]] 会在你周围释放一次强力的 [[talent:124817@FAQABdhA]]。
- [[talent:124975]]
  
  - 使 [[spell:322111]] 的冷却时间缩短 90 秒。

#### 英雄天赋

- [[talent:125054@AJgCCA]] 
  
  - 由于比[[talent:125053]]更强，这是你的默认选择。
- [[talent:136744]]
  
  - 根据战斗时长和你的饰品，[[talent:136760@FJQAfGPBKIA]]可能更好。
- [[talent:125057]]
  
  - 如果你更喜欢[[talent:125056]]，则凭个人偏好选择。

:::

:::tab [[talent:125047]] 范围伤害
:::talents [[talent:125047]] **踏风 武僧** 范围伤害 团本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

### 何时使用该专精

如果你在战斗中长时间面对4个或更多敌人，请使用这套专精。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 专精树

- **新增**
  
  - [[talent:134452]]
  - [[talent:128711]]
  - [[talent:124836]]
  - [[talent:124824]]
- **移除**
  
  - [[talent:125014]]
  - [[talent:125021]]
  - [[talent:125019]]
  - [[talent:124825]]

### 英雄天赋

- [[talent:125054@AJgCCA]] 
  
  - 由于比[[talent:125053]]更强，这是你的默认选择。
- [[talent:136744]]
  
  - 根据战斗时长和你的饰品，[[talent:136760@FJQAfGPBKIA]]可能更好。
- [[talent:125057]]
  
  - 如果你更喜欢[[talent:125056]]，则凭个人偏好选择。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[talent:125026]]在引导开始时会额外打击一次，效果为50%。
- **4件套： ‍** [[talent:125026]]每次打击时，使你的下一个 ‍[[talent:124985@FAgATZfABdhA]]伤害提高10%，或使 ‍[[spell:101546]]伤害提高20%，最多可叠加6次。

### 单体目标

:::tabs
:::tab [[talent:125046]]
### 起手爆发

- 你的目标是在  窗口期内尽可能多地释放 真气消耗技能[[talent:124826]]，同时保持相关技能的冷却转好就用。

:::rotation **踏风 武僧**在团队副本中的单体起手循环
```json
{
  "source_code": "IEYAssgQsmYAAAAAAIEpjmACUV4kSAAALkmZgQXYsVmb0VGZCEAiuOQBjgQWRMRHpgwF_XgNpAAEAIE-7GQBpgwbSJgPbAgPnBAH4vbAAAAAAIE"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:1217413]] 若已点出该天赋 [[item:241288]] · [[spell:1249625]]
4. [[spell:107428]]
5. [[spell:392983]] 若已点出该天赋
6. [[spell:113656]]
7. [[spell:152175]] 若已点出该天赋
8. [[spell:100780]]
9. [[spell:107428]]
10. [[spell:113656]]
11.
:::

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. [[spell:322109]] 尽可能使用。
2. [[spell:107428]] 当获得[[spell:337481]]增益时使用。
3. [[spell:100780]] 若真气低于5点真气且能量即将能量溢出时使用。
4. [[talent:125014]]
5. [[talent:126307]]。
6. [[spell:101546]] 在拥有2层[[spell:286585]]时使用。
7. [[talent:134452]] 尽可能使用。
8. [[spell:107428]]。
9. [[spell:100780]] 在能量即将溢出时使用。
10. [[spell:113656]]。
11. [[spell:100784]] 以避免[[spell:116645]]层数溢出。
12. [[spell:101546]] 搭配[[spell:286585]]使用。
13. [[spell:100780]]。
14. [[spell:100784]]。

:::

:::tab [[talent:125047]]
### 起手爆发

- 你的目标是在  窗口期内尽可能多地释放 真气消耗技能[[talent:124826]]，同时保持相关技能的冷却转好就用。

:::rotation **踏风 武僧**在团队副本中的单体起手循环
```json
{
  "source_code": "IkZAs4gQsmYAAAAAAIEpjmAC0BCnGAAALkmZgQXYsVmb0VGZAI0ePUAAAAgABgorDUwKIkVET0RMIcx_F4TMAQA-7mATI8mUC4zGAExZIQpwGUATRAREzwBAAAAAAAAACB"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:433184]] 若已选择天赋
4. [[spell:331643]]  [[item:241288]] · [[spell:1249625]]
5. [[spell:107428]]
6. [[spell:392983]] 若已选择天赋
7. [[spell:113656]]
8. [[spell:152175]] 若已选择天赋
9. [[spell:107428]]
10. [[spell:443028]]
11. [[spell:107428]]
12. [[spell:113656]]
13. 
14.
:::

1. [[spell:322109]] 尽可能使用。
2. [[talent:125014]]。
3. [[talent:134452]] 尽可能使用。
4. [[talent:126307]]。
5. [[talent:125062@AJgCCA]]。
6. [[spell:107428]] 当获得[[spell:337481]]增益时使用。
7. [[spell:100780]] 若真气低于5点真气且能量即将能量溢出时使用。
8. [[spell:113656]]。
9. [[spell:107428]]。
10. [[spell:101546]] 在拥有2层[[spell:286585]]时使用。
11. [[spell:100784]] 以避免[[spell:116645]]层数溢出。
12. [[spell:101546]] 在拥有1层[[spell:286585]]时使用。
13. [[spell:100784]]。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:125046]]
### 起手爆发

- 下方展示的是使用[[talent:125046]]的多目标起手循环的一种变体。

:::rotation **踏风 武僧** 范围伤害 团本起手循环
```json
{
  "source_code": "IEYAssgQsmYAAAAAAIEpjmACUV4kSAAALkmZgQXYsVmb0VGZCEAiuOQBjgQWRMRHpgwF_XgNpAAEAIE-7GQBpgwbSJgPbAgPnBAH4vbAAAAAAIE"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:1217413]] 若已点出该天赋 [[item:241288]] · [[spell:1249625]]
4. [[spell:107428]]
5. [[spell:392983]] 若已点出该天赋
6. [[spell:113656]]
7. [[spell:152175]] 若已点出该天赋
8. [[spell:100780]]
9. [[spell:107428]]
10. [[spell:113656]]
11.
:::

### 优先级列表

1. [[spell:100780]] 若真气低于 5 点且能量即将溢出。
2. [[spell:322109]] 若有可能。
3. [[spell:101546]] 于 [[spell:286585]] 拥有 2 层时使用以避免溢出。
4. [[talent:134452]]。
5. [[talent:125014]]。
6. [[spell:113656]]。
7. [[spell:107428]] 以触发 [[talent:134452]]。
8. [[spell:101546]]。
9. [[spell:100784]] 以避免 [[spell:116645]] 的层数溢出。

:::

:::tab [[talent:125047]]
### 起手爆发

- 你可以在下方看到使用 [[talent:125047]] 的多目标起手循环的一种变体。

:::rotation **踏风 武僧** 范围伤害 团本起手循环
```json
{
  "source_code": "IkZAs4gQsmYAAAAAAIEpjmAC0BCnGAAALkmZgQXYsVmb0VGZAI0ePUAAAAgABgorDUwKIkVET0RMIcx_F4TMAQA-7mATI8mUC4zGAExZIQpwGUATRAREzwBAAAAAAAAACB"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:433184]] 若已选择天赋
4. [[spell:331643]]  [[item:241288]] · [[spell:1249625]]
5. [[spell:107428]]
6. [[spell:392983]] 若已选择天赋
7. [[spell:113656]]
8. [[spell:152175]] 若已选择天赋
9. [[spell:107428]]
10. [[spell:443028]]
11. [[spell:107428]]
12. [[spell:113656]]
13. 
14.
:::

1. [[spell:322109]] 若有可能。
2. [[talent:125014]]。
3. [[talent:126307]]。
4. [[talent:136745@AJgCCA]]。
5. [[spell:100780]] 若 真气 低于 5 点且 能量 即将溢出。
6. [[spell:101546]] 于 [[spell:286585]] 拥有 2 层时使用。
7. [[talent:134452]] 若有可能。
8. [[spell:113656]]。
9. [[spell:107428]] 以触发 [[talent:134452]]。
10. [[spell:101546]] 于 [[spell:286585]] 拥有 1 层时使用。
11. [[spell:101546]]。

:::

:::

## 深度解析

### 精通

- 千万不要打断你的 [[spell:115636]] 或 [[spell:196740]]，这一点非常重要。
- 在空闲时间你可以使用 [[spell:101546]] 来维持你的 [[spell:196740]]。
- 如果首领对伤害免疫，你也可以使用 [[spell:117952]] 来保持它不断。

### 业报之触

- 为了最大化你的伤害输出，你希望在战斗中尽可能在每次伤害事件时按下 [[spell:122470]]。
- 你可以事先使用 [[spell:243435]] 来提高你的最大生命值，从而增加 [[spell:122470]] 的吸收伤害量。
- 当与 **战士**组队时，如果 [[spell:97462]] 不需要留作冷却技能，你可以请求他们按下它，以便在使用 [[spell:122470]] 之前获得更多生命值。

### 双手武器与单手武器的对比

- 由于 [[talent:124828]]，双手武器的表现优于单手武器。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **踏风 武僧** 内克扎莉 天赋在 团队副本
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

### 爆发技能使用

- 如果你的团队很难击杀**不安的阿曼尼**，请把你的 [[talent:124826]] 留给它。

### 首领攻略技巧

- 在被[[spell:1287322]]点名后使用一个防御技能，并走到房间边缘放下水潭。
- 让 **躁动的阿曼尼** 使用[[spell:119381]]和[[talent:124926]]远离中间。
- 在[[spell:1284103]]期间，确保你处于Boss身后，以免意外吸收灵魂。

:::

:::tab 陵寝哨兵
:::talents 踏风 武僧 陵寝哨兵 团队副本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

### 爆发技能使用

- 如果你的团队在应对某次特定的小怪刷新时遇到困难，可以为他们保留一层你的 [[talent:124826]] 充能。

### 首领攻略技巧

- 站在乌拉提克一侧时吃下 [[spell:1288232]] **位于 鲜血** 一侧时。
- 如果你在 **乌拉提克之息** 一侧，在 **毒液凝块** 出现时立刻换位。
- 吃下地面上的 [[spell:1284434]]。

:::

:::tab 迷失的探险者
:::talents **踏风 武僧** 团本中的迷失探险者天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

### 爆发技能使用

- 始终使用你的[[talent:124826]]，以最大化你的溅射（aoe）价值。

### 首领攻略技巧

- [[spell:1291759]] 以近战玩家为目标时，尽量站在房间边缘。
- 如果你获得了 [[spell:1292490]]，将其施放在尚未吃鱼的Boss身上。
- 吸收地面上的 [[spell:1291933]]。
- 打断 [[spell:1286921]]，来自 **书卷贤者伊库**。

:::

:::tab 瓦什尼克
:::talents **踏风 武僧** 团本中的瓦什尼克天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

### 

- 你可以把你的 [[talent:124826]] 留给你团队难以应对的某次特定小怪刷新。

### 首领攻略技巧

- 不要用 [[spell:1281907]] 打中任何人。
- 有 3 个小怪需要你在它们到达中间之前击杀，即 **结块毒液**, **幽蔽毒液** 和 **燃烧剧毒** 在它们到达中间之前。
  
  - 的 **燃烧剧毒** 死后会施加一个可叠加的持续伤害效果。
    
    - 一次击杀一个。
  - **结块毒液** 免疫控制效果。
  - 你可以控制 **幽蔽毒液** 和 **燃烧剧毒** ，使用 [[talent:124926]] 和 [[spell:119381]]。

:::

:::tab 斯索拉克
:::talents **踏风 武僧** 斯索拉克 团队副本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLPwEAwiZ2mZYmZmBAwGAaWmlmZmZBADMzAwYZAMgP",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLPwEAwiZ2mZYmZmBAwGAaWmlmZmZBADMzAwYZAMgP"
}
```
:::

### 爆发技能使用

- 为[[spell:1286033]]保留一层[[talent:124826]]充能

### 首领攻略技巧

- 你可以用 [[talent:124941]] 驱散任何被 [[spell:1287072]] 击中的队友。
- 在房间中央放一个 [[talent:124962]]，以防你在 [[spell:1285419]] 时需要用到它。
- 在 [[spell:1285419]] 期间使用一个防御技能。

:::

:::tab 双牙
:::talents **踏风 武僧** 双子毒牙 团本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

### 爆发技能使用

- 你可以按住你的[[talent:124826]]来 **维克苏尔之嗣**.

### 首领攻略技巧

- 尽快击杀 **维克苏尔之嗣**。
- 注意追踪你的 [[spell:1290336]] 层数，不要试图叠太多层。
- 踩地板上的 [[spell:452818]]。
- 踩 [[spell:1290505]] 以移除一层 [[spell:1290336]]。

:::

:::tab 盘绕祭坛
:::talents **踏风 武僧** 盘绕祭坛团队副本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

### 爆发技能使用

- 为 [[spell:1304033]] 保留一层 [[talent:124826]] 的充能。

### 首领攻略技巧

- 将 [[spell:1282403]] 拉到一起移动，以便你的坦克能够轻松地对它们进行顺劈。
- 吸收 [[spell:1283485]]。
- 时刻注意 **恐惧具象** 是极其重要的。
  
  - 如果你被 **恐惧具象** 选为目标，请将它们风筝到彼此靠近的位置，以便你的坦克能够用 [[spell:1308809]] 轻松地对它们进行顺劈。
- 当被 [[spell:1286895]] 选为目标时使用防御技能。
  
  - 你还需要在 [[spell:1286837]] 到期之前吸收你的灵魂。
- 在 [[spell:1287685]] 期间使用防御技能。
- 打断 **怨毒盘魂者** 施放的 [[spell:1286399]]。

:::

:::tab 乌拉特克
:::talents **踏风 武僧** 乌拉特克 团队副本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

:::

:::tab 尼姆瑞莎·唤波者
:::talents **踏风 武僧** 尼姆瑞莎·唤波者 团本天赋
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

### 爆发技能使用

- 你随时可以在难对付的小怪刷新时使用[[talent:124826]]。

### 首领攻略技巧

- 在**泡鳍疾行者**和**泡鳍狂战士**到达中间之前击杀它们。
- [[spell:1266340]]会将你从房间中央击退。

:::

:::

## 属性优先级

了解你作为**踏风 武僧**在团队副本首领战中的次要属性优先级以及实现最佳表现所需的第三属性。欲了解更多详细信息，请访问**[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **踏风 武僧** 团队副本中的属性优先级
```json
{
  "source_code": "IoAJFMAJxACKBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 精通 ＞ 暴击 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可以减少"**范围伤害**"技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外治疗。你的宠物造成的伤害无法为你回血，因此**吸血**对你来说是一个极佳的副属性，因为你的大部分伤害都来自你自己的法术。
- **加速** - 小众副属性，但在某些情况下非常有用，并且过去已被证明其实用性。能让处理某些副本机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271519@DCTAA0QANk7cVrDf1IYNXYjt1ghNCKAWBA]] | 乌拉特克 |
| 颈部 | [[item:268265@BkSAA0QA8z6wPrDj1QWNYYjX1IoAYFA]] | 乌拉特克 |
| 肩部 | [[item:271517@BASAA0QA-VTg1ghNCKgTBA]] | 迷失的探险者/催化剂 |
| 披风 | [[item:268253@BgQAA0QACKAWBA]] | 盘卷祭坛 |
| 胸部 | [[item:271522@DASAA0QAJk7oXNCWDG2IoAOF]] | 万毒邪祟者瓦什尼克/催化剂 |
| 手腕 | [[item:244576@BiUAA0QA8z6Y7LjVT0wcbN2UjexYlIOSDAjsUA]] | 制皮 |
| 手套 | [[item:251124@BgRAA0QA2IjX1caJOFA]] | 密谋小径 |
| 腰部 | [[item:268256@BCSAA0QA8z6ghNeVjt1IoAYF]] | 盘卷祭坛 |
| 腿部 | [[item:271518@DASAA0QAhu70XNCWDG2IoAYF]] | 斯索拉克/催化剂 |
| 脚部 | [[item:159327@DgQAA0QApk7IoAOF]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251513@DiRAA0QA1j7wPrDAjY7L3WzSBA]] | 珠宝加工 |
| 戒指 2 | [[item:252258@DCSAA0QA1j7wPrDZ1YjMeVjlo4UA]] | 虚空之痕竞技场 |
| 饰品 1 | [[item:270175@BgRAA0QAYYjX1kjAYFA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgRAA0QAYYjX1IoAYFA]] | 盘卷祭坛 |
| 主手 | [[item:268215@DARAA0QA_k7YhNCKAWB]] | 乌拉特克 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251140@BgQAA0QACKQQBA]] | 密谋小径 |
| 项链 | [[item:251173@BgQAA0QACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:251223@BgQAA0QACKQQBA]] | 虚空车竞技场 |
| 披风 | [[item:251132@BgQAA0QACKQQBA]] | 密谋小径 |
| 胸部 | [[item:251159@BgQAA0QACKQQBA]] | 纳洛拉克的洞穴 |
| 护腕 | [[item:251135@BgQAA0QACKQQBA]] | 密谋小径 |
| 手套 | [[item:251124@BgRAA0QA2IjX1caJBFA]] | 密谋小径 |
| 腰带 | [[item:159317@BgQAA0QACKQQBA]] | 塞塔里斯神庙 |
| 腿部 | [[item:251130@BgQAA0QACKQQBA]] | 密谋小径 |
| 靴子 | [[item:159327@DgQAA0QApk7IoABF]] | 塞塔里斯神庙 |
| 戒指1 | [[item:273792@BgQAA0QACKQQBA]] | 毒牙祭坛 |
| 戒指2 | [[item:252258@BASAA0QAkVjNy4VNWiSQBA]] | 虚空之痕竞技场 |
| 饰品1 | [[item:250215@BgQAA0QACKQQBA]] | 密谋小径 |
| 饰品2 | [[item:250259@BgQAA0QACKQQBA]] | 夺目谷 |
| 主手 | [[item:273783@BgQAA0QACKQQBA]] | 毒牙祭坛 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 等级 | 饰品 |
| --- | --- |
| S 级 | [[item:270175@BgRAA0QAYYjX1kjAYFA]]  <br>[[item:270173@BgRAA0QAYYjX1IoAYFA]] |
| **A 级** | [[item:270164@BgQAA0QACKgTBA]]  <br>[[item:270168@BgQAA0QACKAWBA]] -- 适用于需要按需爆发的场合。  <br>[[item:270165@BgQAA0QACKgTBA]] |
| **B 级** | [[item:270166@BgQAA0QACKgTBA]]  <br>[[item:250215@BgQAA0QACKgTBA]]  <br>[[item:250259@BgQAA0QACKgTBA]] |
| **C 级** | [[item:250214@BgQAA0QACKgTBA]]  <br>[[item:250228@BgQAA0QACKgTBA]] |
| **垃圾** | [[item:250225@BgQAA0QACKgTBA]]  <br>[[item:273796@BgQAA0QACKgTBA]] |

### 美化饰品

> 本部分内容随时可能变动，因此在你使用火花进行任何重要制造之前请回来查看，看这段文字是否已被移除。

- 1个 [[item:251513@DiRAA0QAvk7oPrDAjMWNFITHBA]]
  
  - 这件美化附魔是一枚独特的戒指。
- 1个 [[item:240167@BAAAA0QA]]
  
  - 最佳的制作部位是**护腕**、**披风**、**靴子**或**腰部**，取决于你现有的装备。

或

- 1个 [[item:245875]]
  
  - 这件美化附魔只能应用于武器。
- 1个 [[item:240167@BAAAA0QA]]
  
  - 最佳的制作部位是**护腕**、**披风**、**靴子**或**腰部**，取决于你现有的装备。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备的最高物品等级为334，因此，除非你在该部位没有其他高物品等级装备可选，否则在你2件美化附魔之外装备制造装备并不划算。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - [[item:241324]] *——最高伤害输出。*
  - [[item:241322]] *——最高伤害输出。*
  
  
  
  - [[item:241320]] *——伤害略低但生存能力更强。*
- **食物**
  
  - [[item:255846]]
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]] —— 一次大量的治疗爆发
- 武器磨刃油
  
  - [[item:243734]]*——  默认选择。*
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240900]]
  - [[item:240967]] *——唯一装备，每种颜色的宝石各镶嵌一颗，以增强你的 [[item:240967]]。*
    
    - [[item:240892]]
    - [[item:240908]]
    - [[item:240918]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAA0QA]]  <br>[[item:243951@BAAAA0QA]] |
| --- | --- |
| 肩部 | [[item:243991]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAA0QA]] |
| 腰带 | [[item:275707@BAAAA0QA]] |
| 腿部 | [[item:244641]] |
| 靴子 | [[item:243953]] |
| 戒指 1 | [[item:243957@BAAAA0QA]] |
| 戒指 2 | [[item:243957@BAAAA0QA]] |
| 主手 | [[item:244031]] |

:::

:::column
:::gear **踏风 武僧** 团队副本中的附魔
```json
{
  "source_code": "IQFZNEQ9NCQA7TDBQAAAAgF3SEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[spell:1236056]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从巨型仓库商人处购买 [[item:275707@BAAAA0QA]]，为你的**头盔**、**护腕** & **腰带** 添加插槽。

## 种族

对于想要在团队副本中将 **踏风 武僧** 发挥到极致的玩家来说，不同的种族特性可以为你的角色带来巨大的收益。如果这并不是你的首要目标，选择一个符合你风格的种族同样可行。

- [[spell:65116]] -- 矮人
  
  - 驱散魔法和流血减益效果。过去在某些有流血机制的Boss战中曾有用。
- [[spell:69070]] —— 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到你的角色落地。
- [[spell:26297]] *-- 巨魔* 
  
  - 你最强的DPS种族技能，但与 [[talent:125013]] 的配合不佳。
  - 使移动限制效果的持续时间缩短20%。这在近期开荒团本历史上只有一次派上用场，但仍然值得一提。
- [[spell:33702]] *-- 兽人* 
  
  - 强大的伤害向种族技能，得益于 [[spell:21563]] 以及与 [[talent:125013]] 契合的 [[spell:33702]]。
  - 你受到的昏迷持续时间缩短20%，在某些情况下可能有用。
- [[spell:256948]] —— 虚空精灵
  
  - 向你的面向方向发射一道暗影，再次激活该技能即可传送到暗影所在位置。
  - 最大距离为100码。

### 推荐

总的来说，可以肯定的是：如果你追求输出最大化，就应该选择输出最高的种族天赋。不过，如果是开荒团本，情况就有所不同了。有些种族天赋能极大加快特定首领的进度。值得注意的是，矮人凭借其 [[spell:65116]]，在最近的世界首杀竞速中，由于能在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键节点轻松自我驱散，提供了巨大帮助。

## 宏

了解 **踏风 武僧** 在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**光标 [[spell:116844]] -- *[[spell:116844]]* *在无需确认的情况下施放于你的光标处。***

```wow-macro
#showtooltip
/cast [@cursor] 平心之环
```

:::

:::details 鼠标指向宏
**[[spell:116670]] 鼠标指向Mouseover -- *施放 [[spell:116670]] 于你的鼠标指向目标。***

```wow-macro
#showtooltip
/cast [@mouseover,help] 活血术
```

**鼠标指向[[spell:116841]] -- *施放[[spell:116841]]于你的鼠标指向目标*。**

```wow-macro
#showtooltip
/cast [@mouseover,help] 迅如猛虎
```

**[[talent:124941]] -- *若鼠标指向目标存在，则对其施放 [[talent:124941]]。***

```wow-macro
#showtooltip 清创生血
/cast [@mouseover,help,nodead] 清创生血;清创生血
```

:::

:::details 宠物宏
**宠物解散宏 - *移除[[talent:125013]]。***

```wow-macro
/petdismiss
```

:::

:::details 实用 宏
**/stopmacro [channeling:怒雷破] --  *确保你的 [[spell:113656]]* 在连续按 [[spell:100780]] 时不会被取消 （你可以用任何其他想要连续施放的技能替换  [[spell:100780]] 配合任何你想连续施放的其他技能使用)。**

```wow-macro
#showtooltip 猛虎掌
/stopmacro [channeling:Fists of Fury]
/cast 猛虎掌
```

:::

:::

## 插件

下方是作者的 **踏风 武僧** 用户界面截图，其中标明了所使用的插件，以及它们在团队副本中如何运用，从而让你的游戏生活更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/swaguimidnight-1-1024x608.png>)

**踏风 武僧** 在团队副本中的界面

:::accordion
:::details 插件
- **MRT** -- 备注、团队副本 冷却时间等
  
  - 对团队副本玩家非常有用的插件，尤其适合 团队副本 团长和官员。
- **ElvUI** *-- 整套用户界面替换* 
  
  - 一款以易用性为核心设计的用户界面，并带有标准界面所不具备的额外功能。
  - 另外，你也可以使用 Shadowed Unit Frames (SUF) 配合任意一款动作条插件，当然也可以继续使用原生界面。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些微型插件专为特定的 团队副本 战斗触发警报信息、计时条、音效等而设计。
- **Plater**  -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的负面效果监控、仇恨着色，并支持自定义脚本。
- **Details** -- 深度伤害统计
  
  - 最强大、最可靠、最好用的伤害统计插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 武僧
  
  - 气 transfer 现在使 轮回之触 为你恢复其造成伤害 60% 的生命值（原为 50%）。
  - 旺盛驱逐使驱逐 Harm 的治疗量提高 6%（原为 5%）。
  - 宁静圣疗所的治疗效果提高 25%。
- 踏风
  
  - 开发者备注：我们正在对 踏风 的伤害结构做一些调整，以缩小其平稳期伤害与高端爆发能力之间的差距。
  - 风之舞已更新——你受到的物理伤害降低 10%，且每 4 秒额外降低 10%，直到你受到一次物理攻击，最多叠加 4 层。
  - 近战 自动攻击伤害提高 30%。
  - 乾元镇踏 伤害降低 30%。
  - 幻灭踢 伤害提高 50%。
  - 猛虎掌 伤害提高 200%。
  - 拳脚齐施 伤害提高 30%。
  - 神鹤引项踢 伤害降低 12%。
  - 升龙霸 范围伤害提高 30%。
  - 翡翠引燃伤害提高 50%。
  - 风之武器现在使 乾元之巅 期间的伤害提高 5%（原为 10%）。
  - 巅峰天赋：虎眼酿（等级 2）现在使爆击伤害提高 5%/10%（原为 10%/20%）。
  - 活血术 的治疗效果提高 25%。
  - 驱逐 Harm 的治疗效果提高 25%。
  - 战斗智慧现在使耐力提高 5%。
  - 沉静气场现在使受到的伤害降低 10%（原为 6%）。
- 英雄天赋
  
  - 天神御师
    
    - 天神御身 伤害降低 25%。
    - 闭关修行 使 怒雷破 和 神鹤引项踢 的伤害提高 30%（原为 10%）。

:::

:::

:::accordion
:::details 12.0.5 补丁
- 武僧
  
  - 踏风 
    
    - 怒拳破击已重新设计——怒雷破 伤害提高 20%（原为持续时间延长 1 秒）。
    - 虎眼酿（等级 1）已重新设计——每消耗 3 点真气产生一层虎眼酿。乾元之巅 最多消耗 20 层虎眼酿，在持续期间内每层使你的爆击几率提高 1%。脱战时最多快速叠加至 10 层，且最多可叠加 30 层。
    - 虎眼酿（等级 3）已重新设计——乾元之巅 现在额外提供 2 次 乾元之巅 践踏。
    - 雪怒的战甲 现在还可以由 神鹤引项踢 触发，命中的每个不同目标使 怒雷破 的冷却时间缩短 0.5 秒，最多缩短 2.5 秒。
    - 乾元镇踏 现在产生 2 点真气。
    - 乾元之巅 施放时不再产生 2 点真气。

:::

:::

:::accordion
:::details 补丁12.0.1
- 武僧
  
  - 踏风 
    
    - *开发者备注：这些改动针对表现不佳和表现过强的天赋，提高踏风的范围伤害伤害，调整旭日东升踢在单体目标中对伤害的贡献（相对于怒雷破），并通过多种方式调整其真气运转，使体验更加流畅。*
    - 旭日东升踢伤害提高20%。
    - 神鹤引项踢伤害提高50%。
    - 碧火踏伤害提高25%。
    - 雪怒连击伤害提高40%。
    - 怒雷破伤害降低10%。
    - 凌空韵动现在产生1点真气（原为2点真气）。
    - 疾风呼啸踢不再消耗真气。
    - 旭日螺旋现在使精通：组合拳提高40%（原为20%）。
    - 寰宇能量现在使造成的魔法伤害提高8%（原为15%）。
    - 圣寺之忆现在使连击破的触发几率提高75%（原为25%），并使猛虎掌的伤害提高30%（原为15%）。
    - 御风交流现在使风领主之击和升龙霸的伤害提高20%（原为10%）。
    - 虎眼酒现在在团队副本中脱离战斗时只将层数降至10层，并且在首领战开始和大秘境开始时给予10层或将层数降至10层。
    - 乾元镇踏产生的威胁值降低50%。
    - 活血术治疗效果提高100%。
    - 活血术在PvP战斗中的治疗效果降低33%（原为66%）。
    - 移花接木治疗量提高30%。

:::

:::

:::accordion
:::details 补丁12.0
- 武僧
  
  - 制猿蹄的打断持续时间增加到5秒（原为3秒）。不影响PvP战斗。
- **英雄天赋**
  
  - 天神御师 新天赋：陨星之道 – 天神御身在攻击单个目标时伤害提高100%。每增加一个目标，此加成减少20%。
  - 玉珑的知识已被重新设计 – 现在使旭日东升踢的伤害提高15%。
  - 青龙之心不再降低怒雷破的冷却时间。
  - 天神御身不再分割其伤害，且对5个以上目标造成的伤害降低。
  - 赤鹤之翔已被移除。
- **踏风** 
  
  - 白虎下凡和雪怒羁绊从踏风天赋树移至天神御师英雄天赋树。
  - 天神御身伤害降低75%，治疗量降低80%。
  - 当施放雪怒时，天神御身现在会取代白虎雪怒。
  - 天神御身在英雄天赋树中的位置已变更。
- **祥和宗师**
  
  - 新天赋：和谐涌动 – 施放雷电之专注茶、星辰之酿或天界灌顶后，保证你的下2次猛虎掌或活血术施放将引发一次和谐涌动，对目标及其附近其他敌人造成自然伤害（分割计算），并治疗最多5名受伤的盟友。
  - 新天赋：潜能 – 施放醉酿投、旭日东升踢或疾风呼啸踢后，你的下一次猛虎掌或活血术将释放一次和谐涌动。
  - 目标明确已更新 – 施放氤氲之雾会储存额外的活力（原为活血术或神龙之赐）。
- **影踪派**
  
  - 新天赋：战场隐踪 – 疾风乱打对6码范围内的所有敌人造成自然伤害，超过8个目标后伤害降低。
  - 新天赋：准备就绪 酒仙：激活召唤砮皂黑牛时，立即获得10层疾风乱打，在你下次攻击时以70%效果触发。
  - 踏风：激活乾元之巅时立即获得10层疾风乱打，在你下次攻击时以70%效果触发。
  - 新天赋：城壁兵械 酒仙：召唤砮皂黑牛的践踏伤害提高20%。
  - 踏风：乾元镇踏伤害提高20%。
  - 新天赋：意到锋至 – 战斗开始后的前8秒内移动速度提高50%。
  - 新天赋：作战姿态 – 翻地滚的冷却时间缩短10%。
  - 疾风乱打已被重新设计 – 酒仙：你的自动攻击有几率产生1-2层疾风连击充能。当你施放醉酿投时，释放所有疾风连击充能，每层造成物理伤害。
  - 踏风：你的自动攻击有几率产生1-2层疾风连击充能。当你施放怒雷破时，释放所有疾风连击充能，每层造成物理伤害。
  - 城壁之智已被重新设计 – 酒仙：召唤砮皂黑牛会使火焰之息发射3个疾风乱打。
  - 踏风：乾元之巅使旭日东升踢和神鹤引项踢发射3个疾风乱打。
  - 老兵之眼已被重新设计——急速提高5%。
  - 绝境求生已被重新设计——你的敏捷提高4%。
  - 警惕守望不再提高你下一个 疾风乱打 的伤害。
  - 以一敌众已被重新设计——现在使自动攻击爆击时提供双倍 疾风拳势 层数。
  - 高效演武 已被更新——酒仙：现在使召唤黑牛 砮皂 的冷却时间缩短25秒。
  - 踏风：现在使 乾元之巅 的冷却时间缩短10秒。
- 职业
  
  - 新天赋：静谧圣所——当15码范围内没有敌人时，你每3秒恢复一次生命值。
  - 新天赋：静步螺旋——扫堂腿 结束时使目标窒息（禁用）5秒。
  - 新天赋：宁静涌动——施放 氤氲之雾 后，你的下一个 神龙之赐 或 活血术 变为瞬发。
  - 新天赋：重焕活力——在 清创生血 成功移除盟友身上的一个效果后，其移动速度提高30%，持续5秒。
  - 新天赋：气转移——轮回之触 现在会为你恢复其所造成伤害50%的生命值。
  - 拯救众生已被重新设计——现在根据你目标的生命值使你的治疗提高最多10%。生命值较低的盟友受到的治疗更多。
  - 散魔功 已被重新设计——现在激活 壮胆酒 时，如果可能，会将你身上当前所有有害魔法效果转移回其原始施法者。
  - 抚慰之雾 的治疗效果提高50%。
  - 活泼活化不再提高 活血术 的治疗效果。
  - 致命之触 不再提高造成的伤害。
  - 雪怒 之狂烈现在是一个2点天赋。
  - 以下天赋已被移除：弹地回旋
  - 气爆 *（仅对 织雾 和 踏风 移除）*
  - 冲撞
  - 深刻反驳 *（仅对 织雾 移除）*
  - 旭日东升踢 *（仅对 酒仙 移除）*
  - 贯手击 *（仅对 织雾 移除）*
  - 灵魂之力 *（仅对 织雾 移除）*
  - 正气迸发 *（仅对 织雾 移除）*
- 踏风
  
  - 新天赋：凌空韵动 – 切削之风 现在施放时产生2点真气。
  - 新天赋：飓风腾跃 – 切削之风 现在施放需要消耗2点真气，但其伤害提高40%。
  - 新天赋：敏锐反射 – 幻灭踢 使 旭日东升踢 和 怒雷破 的冷却时间缩短1秒。
  - 新天赋：碎拳 – 怒雷破 的持续时间延长1秒。
  - 新天赋：连击破绽 – 当你 猛虎掌 时，有8%的几率使你在15秒内施放的下一个 幻灭踢 不消耗真气。
  - 新天赋：乾元之巅 – 真气消耗降低1点，且 幻灭踢 使受影响技能的冷却时间额外缩短1秒。激活 乾元之巅 会重置 旭日东升踢 的剩余冷却时间并获得2点真气。
  - 新天赋：谐律连击 – 怒雷破 的真气消耗降低1点，但其伤害降低10%。
  - 新天赋：天火踢 – 旭日东升踢 的爆击几率提高，每个附近的敌人提高4%，最多计算5个敌人。旭日东升踢 伤害的10%会溅射到附近的敌人身上。超过5个目标后伤害降低。
  - 新天赋：旋风之息 – 你从所有来源获得的急速提高10%。
  - 新天赋：回响技法 – 施放 风领主之击 和 升龙霸 会获得 幻灭踢！。
  - 新天赋：黑曜石螺旋 – 在武器大师序期间，幻灭踢 产生1点真气。
  - 新天赋：阳光螺旋 – 旭日东升踢 从 精通：组合拳 获得的加成效果提高20%。
  - 新天赋：风之武器 – 你在 乾元之巅 期间的伤害提高10%。
  - 新天赋：身手矫健 – 你的近战攻击速度提高30%。在 乾元之巅 期间，此加成提高到60%。
  - 新天赋：猛虎之牙 – 你的自动攻击爆击几率提高15%。
  - 新天赋：乾元镇踏 – 激活 乾元之巅 会释放一次强力的跺击，对附近的敌人造成大量自然伤害，超过5个目标后伤害降低。
  - 新天赋：万有能量 – 法术伤害提高15%。
  - 新天赋：疾风呼啸踢 – 消耗 幻灭踢！ 后，旭日东升踢 有40%的几率变成 疾风呼啸踢。疾风呼啸踢：掀起一阵狂风，对面前25码锥形范围内的敌人造成自然伤害，由所有敌人平均分摊。每击中一个目标伤害提高6%，最多30%。
  - 拳脚齐施已被重新设计——现在有30%的几率击退你的目标，伤害提高300%，但激活时不再在5秒内使伤害提高5%。
  - 角杯盖子已被重新设计——现在使武器之序的持续时间延长5秒。
  - 灵魂专注已被重新设计——现在使武器之序的冷却时间缩短20秒。
  - 雪怒的战甲已被重新设计——现在使旭日东升踢的爆击几率提高20%，并且当旭日东升踢爆击时，怒雷破的冷却时间缩短4秒。
  - 子午打击已被重新设计——现在使轮回之触的冷却时间缩短45秒，并使轮回之触的伤害提高15%。
  - 翡翠点燃已被重新设计——不再叠加光环以提高氤氲之爆的伤害。
  - 自动攻击伤害提高200%。
  - 所有法术和技能伤害降低13%。
  - 神鹤引项踢伤害提高80%。
  - 鹤之漩涡现在使神鹤引项踢的伤害提高15%（原为30%）。
  - 赤精之舞不再提高神鹤引项踢的伤害。
  - 赤精之舞的触发几率降低33%。
  - 怒雷破伤害提高30%。
  - 旭日东升踢伤害提高30%。
  - 幻灭踢伤害提高300%。
  - 切削之风伤害降低50%。
  - 碧火踏现在在施放后使移动速度提高，持续3秒。
  - 凝神翡翠现在使碧火踏的伤害提高300%（原为500%）。
  - 虎之触现在使猛虎掌的伤害提高15%（原为40%）。
  - 碧火拳现在在每次施放怒雷破后触发。
  - 雷霆之拳、旋转旋风和残寺秘学现在可由升龙霸和风领主之击共同触发。
  - 风之交融现在使风领主之击和升龙霸的冷却时间缩短5秒，并使其伤害提高20%。
  - 升龙霸的冷却时间现在为35秒，不再受急速影响。
  - 禅院教诲的幻灭踢现在以25%的效果施放。
  - 修道院回忆不再提高急速，改为提高猛虎掌的伤害。
  - 战斗智慧不再提高猛虎掌的伤害。
  - 精通：组合拳现在每次施放后会显示一个追踪增益，显示你之前施放的法术。
  - 凶猛和硬化脚掌现在是2点天赋。
  - 战斗助手的循环已更新。
  - 若干天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - 赞誉
    - 真气波
    - 勇气冲动
    - 雪怒之狂怒
    - 狂风之力
    - 白虎下凡 *（移至天神御师英雄天赋树）*
    - 祈唤者之悦
    - 碧火调和
    - 末代皇帝的电容
    - 武术混合
    - 有序元素
    - 迅如疾风
    - 风火雷电
    - 召唤白虎雕像
    - 力量转移
    - 雪怒羁绊 *（移至天神御师英雄天赋树）*

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我的[[spell:196740]] 会掉？
**答：** 你连续按了同一个技能两次。常见的情况是你的[[spell:100780]]被招架了，然后你按了两次来获取真气。

:::

:::

---

### 致谢

作者：**Swag**

审核：**Xerwo**

---

:::changelog 更新记录
**2026-08-07** 已更新至12.1版本

**2026-05-01** 已更新至12.0.5版本

**2026-02-24** 已更新至12.0.1版本

**2026-01-18** 已更新至12.0版本

**2025-12-03** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-08-03** 已更新至11.2版本

**2025-06-18** 已更新至11.1.7版本

**2025-04-22** 已更新至11.1.5版本

**2025-02-24** 已更新至11.1版本

**2024-12-17** 已更新至11.0.7版本

**2024-10-24** 已更新至11.0.5版本

**2024-08-17** 已更新至11.0.2版本。

**2024-07-24** 本指南撰写于前置补丁11.0.1版本。



:::
