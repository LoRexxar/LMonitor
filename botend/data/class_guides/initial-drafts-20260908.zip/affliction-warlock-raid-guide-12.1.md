欢迎来到魔兽世界12.1版本的**痛苦 术士** 团队副本攻略！本攻略涵盖了你需要了解的关于你的角色的一切！你是刚起步、从80级开始练级吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 3/5 · 一般

范围伤害 · 3/5 · 一般

功能性 · 4/5 · 强

生存能力 · 5/5 · 优秀

机动性 · 2/5 · 弱



:::

:::

:::column
:::gear **痛苦 术士** 团队副本 最佳配装
```json
{
  "source_code": "J4fAImQA3_fABIgJEIIEBAwJ5OgCtOgF2IoAYFQApfBBAERAAcVrBQBBMWTBUwDukQgAIEAAXk7ACKgTBEQvJ8AAJ0wDsECqDQIABAwJqOgGAHQNQsUABkLJFEDBFoaCxQw3XUwDAkSAxwAWBEAIVEDBZAcDxwxukQAAIEAACGwHgw9FEIICBAQ94GAHAIYAxRAgt4jEAQAht0AMQ4UABQ1HZwABdfRDMQBWBEA9iQQA2CQPNYHKz1CBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240906]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240906]] |
| 肩部 | [[item:271544]] | [[item:243991]] |
| 胸部 | [[item:271549]] | [[item:243977]] |
| 腰部 | [[item:239649]] | [[item:240906]] · [[item:240167]] · [[item:245786]] |
| 腿部 | [[item:271545]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240906]] · [[item:240167]] · [[item:245785]] |
| 手部 | [[item:271547]] |  |
| 戒指一 | [[item:268252]] | [[item:240906]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:273796]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:273779]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为一名**痛苦术士**，你可以使用纳斯雷扎尔的暗影，它会使你的[[spell:48181]]造成少量顺劈伤害。

**等级2**会提高初始伤害，并提高鬼影缠身为你的其他技能提供的加成伤害。而**等级3**有几率召唤[[spell:48181]]内的恶魔之魂，使其召唤一颗陨石落在你的目标上，造成大量范围伤害伤害。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-affliction-mxr.webp>)

纳斯雷扎尔的暗影

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[spell:30108]]
    
    - 你的新单体消耗技能，取代了[[spell:324536]]。
  
  
  
  - [[spell:27243]]
    
    - 你的新范围伤害消耗技能，取代了[[spell:324536]]。
  - [[spell:1257052]]
    
    - 取代[[spell:386997]]成为你的次要冷却技能。[[spell:1259886]]每当你消耗灵魂碎片时，都会缩短[[spell:1257052]]的冷却时间。
  - [[spell:1260229]]
    
    - 当持续伤害效果即将到期时，有几率重新施加[[spell:30108]]。
  - [[spell:1261124]]
    
    - 当你对已有一个生效痛苦无常的目标施加[[spell:30108]]时，提高急速。
  - [[spell:1259825]]
    
    - 使你的[[spell:980]]在作用于主要目标之外，还会施加到附近的一个目标身上。
- **职业树**
  
  - [[spell:1265813]]
    
    - 绝佳天赋，可一次性对一群敌人施加[[spell:702]]、[[spell:334275]]或[[spell:1714]]。
  - [[spell:1265799]]
    
    - 对目标附近的所有敌人施加强化过的[[spell:702]]。
  - [[spell:1271802]]
    
    - 对目标附近的所有敌人施加强化过的[[spell:1714]]。
  - 更多[[talent:91466]]机动性
    
    - [[spell:1265801]]让你可以在进入冷却前使用第二次恶魔传送门。
- **已移除**
  
  - [[spell:324536]]
  - [[spell:205179]]
  - [[spell:278350]]
  - [[spell:386997]]
  - [[spell:417537]]
  - [[spell:215941]]

## 英雄天赋

- [[talent:123384]]目前在所有场合下都优于[[talent:123382]]，无论是单体、顺劈还是纯范围伤害。



### [[talent:123384]]

- 生成 [[spell:246985]] 现在有几率使你获得 [[spell:449793@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]]。
  
  - [[spell:449793@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 会强化你的下一次 [[spell:30108]] 施法。
- [[spell:449637@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 使 [[talent:91552]] 会给予你 [[spell:108558]] 触发。
  
  - 注意不要让 [[spell:108558]] 层数溢出，因为 [[spell:449637@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 还会使你的 [[spell:146739]] 跳动更快，从而导致更频繁的触发。
- [[spell:449620@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 提高 [[spell:686]] 和 [[spell:388667]] 的伤害，并放大 [[spell:108558]]。
- [[spell:449638@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 使你的 [[spell:1257052]] 生成 3 个 [[spell:246985]]，每个都包含一个 [[spell:449793@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]]。
- [[spell:1268884]] 使你偶尔释放出一个对敌人进行顺劈的恶魔之魂。




### [[talent:123382]]

- 你的 [[spell:146739]] 会转化为 [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]]。
- 你可以使用一个冷却时间为1分钟、名为 [[spell:430014@FAQA6hcA]] 的技能。
- [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 可以叠加层数，并与不同的天赋有多种巧妙的互动，这些天赋可以增加其层数或带来其他收益。
  
  - 将 [[spell:246985]] 用于伤害法术时，会使 [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 的层数增加1层，并且由于 [[talent:117434]]，有机会额外获得一层。
  - 施放 [[spell:430014@FAQA6hcA]] 会使所有激活的 [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 层数增加6层，而每个 [[spell:324536]] 在其持续期间会额外增加1层。
  
  
  
  - [[talent:117441]] 使 [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 在造成暴击时有几率增加一层。
- [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 内置一个机制，会将其累积的层数逐一消耗以造成更多伤害。这个机制被称为 **锐利**.
  
  - 的 **锐利** [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 的状态由以下条件触发： 
    
    - [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 每获得一层时都有几率触发。
    - 当 [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 达到8层时。
    - 当 [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] 所在的目标生命值降至20%或已经低于20%时。
    - 当 [[talent:117439]] 生效时。
- [[spell:1266805]] 枯萎 的周期性效果现在有几率触发 [[spell:430014@FAQA6hcA]]。





## 天赋

**← 滚动查看更多天赋构筑 →**



### [[talent:123384]] 单目标

:::talents [[talent:123384]] **痛苦 术士** 团本中的单体天赋
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 改变游戏玩法的天赋

在这里你可以找到专精和职业天赋树中所有会显著改变你玩法的天赋。本节将对这些天赋及其应用进行简要概述，如果想了解更多细节，请查看下方的**[输出循环](<https://maxroll.gg/wow/class-guides/affliction-warlock-raid-guide#rotation-header>)**和**[深度解析](<https://maxroll.gg/wow/class-guides/affliction-warlock-raid-guide#deep-dive-header>)**章节。

##### 专精树

- [[spell:27243]]
  
  - 使你能快速将[[spell:146739]]施加到大量目标上。消耗1个[[spell:246985]]。
- [[spell:1257052]]
  
  - 强大的范围伤害冷却技能，对所有当前带有DoT的目标造成大量伤害并生成灵魂碎片。
  - [[spell:1259886]]会缩短[[spell:1257052]]的冷却时间
- [[spell:108558]]
  
  - 使你的下一个[[talent:124692]]施法时间减半并提高其伤害的增益效果。最多可叠加2层。
- [[talent:91552]]
  
  - 对目标施加减益效果，使其受到你技能的伤害提高。
- [[spell:205180]]
  
  - 爆发窗口期的主要冷却技能。
  - [[spell:1280733]]还赋予你最多对5个目标进行劈砍的能力。
- [[spell:1259825]]
  
  - 使你能够在多个目标身上维持痛苦。

##### 职业树

- [[talent:91439]]
  
  - 帮助你阵亡后快速恢复，让你能够免费且迅速地重新召唤宠物。
- [[talent:91460]]
  
  - 除了[[talent:124694]]和[[talent:91466]]之外的主要机动技能，不过这两个技能都需要提前规划。
- [[talent:91469]]
  
  - 以消耗1块[[spell:246985]]为代价，强化多种实用技能。
  - 主要用于[[spell:48020]]、[[talent:91466]]和[[spell:6262]]。
- [[spell:6789]]
  
  - 一个单体控制技能，当你需要即时治疗时也可作为防御技能使用。
  - [[spell:1265816]]会提高死亡缠绕的治疗量和施法距离。

- [[talent:91444]]
  
  - 一个防御技能，根据你 **当前** 生命值为你提供一个大型吸收护盾，并在此基础上额外附加一定数值。
- [[talent:91434]]
  
  - 在长时间的首领战中，将 [[spell:6262]] 与 [[talent:91469]] 结合使用可成为一个强力的 1 分钟防御冷却。

#### 英雄天赋

- [[talent:123840]] 
  
  - 你的默认选择，因为与其他天赋选项不同，它能提高你的整体生存能力。
- [[talent:117420]]
  
  - 表现优于[[talent:123839]]。
- [[talent:117421]]
  
  - 你的默认选择，但如果你是团队中唯一的战复职业，可以换成[[talent:123838]]。




### [[talent:123384]] 多目标

:::talents [[talent:123384]] **痛苦 术士** 团本中的多目标天赋
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

#### 何时使用该专精

如果你在战斗的大部分时间内面对2到3个敌人，请使用此专精。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[spell:1280733]].
- **移除**
  
  - [[spell:1260264]].




### [[talent:123384]] 范围伤害

:::talents [[talent:123384]] **痛苦 术士** 团队副本中的范围伤害构筑
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

#### 何时使用该专精

如果你在战斗的大部分时间内面对4个或更多聚集的敌人，请使用此专精。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[spell:196226]].
  
  
  
  - [[spell:1311969]].
  
  
  
  - [[spell:1259838]].
- **移除**
  
  - [[spell:416615]].
  
  
  
  - [[spell:1261124]].
  
  
  
  - [[spell:1260264]].




### [[talent:123382]] 单体

:::talents [[talent:123382]] **痛苦 术士** 团队副本中的单体构筑
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZZmZWGDAMLbbjhxsYmGzMDbZWYYZAAAYGAAYmZmZMjZmNmhZGzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZZmZWGDAMLbbjhxsYmGzMDbZWYYZAAAYGAAYmZmZMjZmNmhZGzMjBzMzAAMDM"
}
```
:::

#### 何时使用该专精

如果你在与单个敌人战斗，请使用这套专精。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[spell:686]]
- **移除**
  
  - [[talent:124692]]

##### 英雄天赋

**已将** 英雄天赋更换为 [[talent:123382]]，更多信息请访问上方的**英雄天赋**章节。

- [[talent:117419]]
  
  - 你的默认选择，因为两个天赋选项都非常小众，而这个比另一个有更多的使用场景。
- [[talent:117451]]
  
  - 目前表现优于[[talent:123310]]。
- [[talent:117432]]
  
  - 帮助你恢复因使用[[talent:91444]]而损失的生命值。




### [[talent:123382]] 多目标

:::talents [[talent:123382]] **痛苦 术士** 在 团队副本 中的多目标配装
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDLDAAAzAAAzMzMjZMzsNGzYMzMzYYmZGAgBM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDLDAAAzAAAzMzMjZMzsNGzYMzMzYYmZGAgBM"
}
```
:::

#### 何时使用该专精

如果你在战斗的大部分时间内面对2到3个敌人，请使用此专精。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[spell:1280733]]
- **移除**
  
  - [[spell:1260209]]

##### 英雄天赋

**已将** [[talent:123384]] 更换为 [[talent:123382]]，更多信息请访问上方的**英雄天赋**章节。

- [[talent:117419]]
  
  - 你的默认选择，因为两个天赋选项都非常小众，而这个比另一个有更多的使用场景。
- [[talent:117451]]
  
  - 目前表现优于[[talent:123310]]。
- [[talent:117432]]
  
  - 帮助你恢复因使用[[talent:91444]]而损失的生命值。




### [[talent:123382]] 范围伤害

:::talents [[talent:123382]] **痛苦 术士** 在 团队副本 中的 范围伤害 配装
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDLDAAAzAAAzMzMjZMzsNGzYMzMzYYmZGAgBM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDLDAAAzAAAzMzMjZMzsNGzYMzMzYYmZGAgBM"
}
```
:::

#### 何时使用该专精

如果你在战斗的大部分时间内面对4个或更多聚集的敌人，请使用此专精。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[spell:196226]]
  
  
  
  - [[spell:1311969]]
  
  
  
  - [[talent:91567]]
  
  
  
  - [[spell:1259838]]
- **移除**
  
  - [[spell:416615]]
  
  
  
  - [[talent:126064]]
  
  
  
  - [[spell:1261124]]
  
  
  
  - [[spell:1260229]]

##### 英雄天赋

**已将** [[talent:123384]] 更换为 [[talent:123382]]，更多信息请访问上方的**英雄天赋**章节。

- [[talent:117419]]
  
  - 你的默认选择，因为两个天赋选项都非常小众，而这个比另一个有更多的使用场景。
- [[talent:117451]]
  
  - 目前表现优于[[talent:123310]]。
- [[talent:117432]]
  
  - 帮助你恢复因使用[[talent:91444]]而损失的生命值。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：**[[spell:172]] 伤害提高25%。[[spell:980]] 伤害提高15%。
- **4件套：**每个激活的 [[spell:30108]] 使你的法术和技能造成的伤害提高2%，最多叠加至6%。[[spell:27243]] 会以20%的效果对目标施加 痛苦无常。

### 单体目标



#### [[talent:123384]]

##### 起手爆发

- 你在起手阶段的目标是施加并维持所有的持续伤害效果和减益效果，同时避免浪费（溢出）[[spell:246985]]和[[talent:91568]]的触发层数。下面你可以看到一个示例，展示在使用推荐的[[talent:123384]]单体专精时，你的起手爆发应该是什么样子。

:::rotation **痛苦 术士** 在 团队副本 中的单体起手循环
```json
{
  "source_code": "IwGTLIUN8CAAAcAUyVGc1xGbAIE1DAQABwgQz0jAFgAB8FSARwgABwprBgAEAEAhtQQBYQwwSbDCAgAXuMhUYAAKDLNBAAAAAI0OuXA"
}
```
1. [[spell:48181]] 战前准备
2. [[spell:980]]
3. [[spell:146739]]
4. [[spell:205180]]  [[item:241308]] · [[item:273796]]
5. [[spell:316099]]
6. [[spell:316099]]
7. [[spell:1257052]]
8. [[spell:316099]]
9. [[spell:316099]]
10. [[spell:316099]]
11. [[spell:388667]]
:::

- 始终保持目标身上的 [[spell:980]]、[[spell:146739]] 和 [[talent:91552]]。
- 务必通过每 15 秒对目标施放两次 [[spell:316099]] 来维持 [[spell:1261124]]。
- 在开怪前约 2 秒预读 [[talent:91552]]，这样当开怪倒计时归零时它正好命中首领。
- 与 [[talent:123382]] 相比，[[talent:123384]] 在整场战斗中拥有更多总 [[talent:91568]] 触发次数。请时刻牢记这一点，且切勿让任一触发效果溢出浪费。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 跟上，[[spell:980]] 和 [[spell:146739]]。
2. 冷却好了就施放 [[spell:48181]]，但如果目标身上的减益效果不会马上到期，且你已拥有最大层数的 [[spell:108558]]，可以将它延迟几秒施放。
3. 维持 [[spell:1261124]] 增益。
4. 只要你的 [[spell:246985]] 为 2 层或更少，就在冷却好了时施放 [[spell:1257052]]。
5. 只要你的 [[spell:246985]] 为 3 层或更多，就在冷却好了时施放 [[spell:205180]]。
6. 如果你拥有 [[spell:108558]]，就施放 [[talent:124692]]。
7. 如果你的 [[spell:246985]] 即将溢出，就施放 [[spell:316099]]。
8. 将 [[talent:124692]] 作为你的填充法术施放。




#### [[talent:123382]]

##### 起手爆发

- 你在起手阶段的目标是施加并维持所有的持续伤害和减益效果，同时避免[[spell:246985]]和[[talent:91568]]触发效果溢出。下面你可以看到使用推荐的[[talent:123382]]单体专精时起手的一个示例。

:::rotation **痛苦 术士** 在 团队副本 中的单体起手循环
```json
{
  "source_code": "IMHTMIUN8CAAAcAUyVGc1xGbAIE1DAQABwgQcwsBFgABmFcCIQAfhEQGMIQAc6aAIABABQYLEUAIEMs02gAAIwlLTIFGAQywSTAAAAAAC5qA"
}
```
1. [[spell:48181]] 战前准备
2. [[spell:980]]
3. [[spell:445468]]
4. [[spell:442726]]
5. [[spell:205180]]  [[item:241308]] · [[item:273796]]
6. [[spell:316099]]
7. [[spell:316099]]
8. [[spell:1257052]]
9. [[spell:316099]]
10. [[spell:316099]]
11. [[spell:316099]]
12. [[spell:686]]
:::

- 始终保持目标身上的 [[spell:980]]、[[spell:146739]] 和 [[talent:91552]]。
- 务必通过每 15 秒对目标施放两次 [[spell:316099]] 来维持 [[spell:1261124]]。
- 在开怪前约 2 秒预读 [[talent:91552]]，这样当开怪倒计时归零时它正好命中首领。
- 与 [[talent:123382]] 相比，[[talent:123384]] 在整场战斗中拥有更多总 [[talent:91568]] 触发次数。请时刻牢记这一点，且切勿让任一触发效果溢出浪费。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 跟上，[[spell:980]] 和 [[spell:146739]]。
2. 冷却好了就施放 [[spell:48181]]，但如果目标身上的减益效果不会马上到期，且你已拥有最大层数的 [[spell:108558]]，可以将它延迟几秒施放。
3. 维持 [[spell:1261124]] 增益。
4. 只要你的 [[spell:246985]] 为 2 层或更少，就在冷却好了时施放 [[spell:1257052]]。
5. 冷却好了就施放 [[spell:442726]]。
6. 只要你的 [[spell:246985]] 为 3 层或更多，就在冷却好了时施放 [[spell:205180]]。
7. 如果你有 [[spell:108558]]，就施放 [[spell:686]]。
8. 如果你的 [[spell:246985]] 即将溢出，就施放 [[spell:316099]]。
9. 将 [[spell:686]] 作为你的填充技能施放。





### 多目标



#### [[talent:123384]]

##### 起手爆发

多目标循环与单体完全相同，唯一的区别在于你的开局方式以及获得的触发效果数量。

- 你在开局阶段的目标是施加并维持所有的持续伤害效果和减益效果，同时不要让[[spell:246985]]和[[talent:91568]]的触发效果溢出。下面你可以看到一个示例，展示在使用推荐的[[talent:123384]]多目标专精时，你的开局是如何进行的。

:::rotation **痛苦 术士** 在团队副本中的多目标开场
```json
{
  "source_code": "IwZA81gQ1wLAAAwBQJXZwVHbsBgQUPAAAAACUFmcnVGdgEDA2ABAUIDACNTPCIDIAIDEAAhMAIEfhEQQMIQAc6aAIwCABQYLEAAAAAgQcWXAHkBCIwlLTEQEChBAowZdAAAAAAgQ-ewA"
}
```
1. [[spell:48181]] 开战前
2. [[spell:980]] 目标1
3. [[spell:980]] 目标2
4. [[spell:146739]] 目标1
5. [[spell:146739]] 目标2
6. [[spell:205180]]  [[item:241308]] · [[item:273796]]
7. [[spell:30108]]
8. [[spell:30108]]
9. [[spell:1257052]]
10. [[spell:30108]]
11. [[spell:30108]]
12. [[spell:30108]]
13. [[spell:198590]]
:::

- 始终保持目标身上的 [[spell:980]]、[[spell:146739]] 和 [[talent:91552]]。
- 务必通过每 15 秒对目标施放两次 [[spell:316099]] 来维持 [[spell:1261124]]。
- 在开怪前约 2 秒预读 [[talent:91552]]，这样当开怪倒计时归零时它正好命中首领。
- 与 [[talent:123382]] 相比，[[talent:123384]] 在整场战斗中拥有更多总 [[talent:91568]] 触发次数。请时刻牢记这一点，且切勿让任一触发效果溢出浪费。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 跟上，[[spell:980]] 和 [[spell:146739]]。
2. 冷却好了就施放 [[spell:48181]]，但如果目标身上的减益效果不会马上到期，且你已拥有最大层数的 [[spell:108558]]，可以将它延迟几秒施放。
3. 维持 [[spell:1261124]] 增益。
4. 只要你的 [[spell:246985]] 为 2 层或更少，就在冷却好了时施放 [[spell:1257052]]。
5. 只要你的 [[spell:246985]] 为 3 层或更多，就在冷却好了时施放 [[spell:205180]]。
6. 如果你拥有 [[spell:108558]]，就施放 [[talent:124692]]。
7. 如果你的 [[spell:246985]] 即将溢出，就施放 [[spell:316099]]。
8. 将 [[talent:124692]] 作为你的填充法术施放。




#### [[talent:123382]]

##### 起手爆发

多目标循环与单体完全相同，唯一的区别在于你的开局方式以及获得的触发效果数量。

- 你在开场阶段的目标是施放并维持所有的持续伤害效果和负面效果，同时不让[[spell:246985]]和[[talent:91568]]的触发效果溢出浪费。下面你可以看到一个示例，展示在使用推荐的[[talent:123382]]多目标专精时，你的开场手法是什么样的。

:::rotation **痛苦 术士** 在团队副本中的多目标开场
```json
{
  "source_code": "IMaA85gQ1wLAAAwBQJXZwVHbsBgQUPAAAAACUFmcnVGdgEDA2ABAUIDACxBzGIDIAIDEAAjMAIkZBbAAAAAACxXIBkEDCEAnuGACQAQAE2CBFgBBDLtNIAACc5yEShBAkMs0EAAAAAgQuKA"
}
```
1. [[spell:48181]] 开战前
2. [[spell:980]] 目标1
3. [[spell:980]] 目标2
4. [[spell:445468]] 目标1
5. [[spell:445468]] 目标2
6. [[spell:442726]]
7. [[spell:205180]]  [[item:241308]] · [[item:273796]]
8. [[spell:316099]]
9. [[spell:316099]]
10. [[spell:1257052]]
11. [[spell:316099]]
12. [[spell:316099]]
13. [[spell:316099]]
14. [[spell:686]]
:::

- 始终保持目标身上的 [[spell:980]]、[[spell:146739]] 和 [[talent:91552]]。
- 务必通过每 15 秒对目标施放两次 [[spell:316099]] 来维持 [[spell:1261124]]。
- 在开怪前约 2 秒预读 [[talent:91552]]，这样当开怪倒计时归零时它正好命中首领。
- 与 [[talent:123382]] 相比，[[talent:123384]] 在整场战斗中拥有更多总 [[talent:91568]] 触发次数。请时刻牢记这一点，且切勿让任一触发效果溢出浪费。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 跟上，[[spell:980]] 和 [[spell:146739]]。
2. 冷却好了就施放 [[spell:48181]]，但如果目标身上的减益效果不会马上到期，且你已拥有最大层数的 [[spell:108558]]，可以将它延迟几秒施放。
3. 维持 [[spell:1261124]] 增益。
4. 只要你的 [[spell:246985]] 为 2 层或更少，就在冷却好了时施放 [[spell:1257052]]。
5. 冷却好了就施放 [[spell:442726]]。
6. 只要你的 [[spell:246985]] 为 3 层或更多，就在冷却好了时施放 [[spell:205180]]。
7. 如果你有 [[spell:108558]]，就施放 [[spell:686]]。
8. 如果你的 [[spell:246985]] 即将溢出，就施放 [[spell:316099]]。
9. 将 [[spell:686]] 作为你的填充技能施放。





### 范围伤害



#### [[talent:123384]]

##### 起手爆发

- 你在范围伤害开场中的目标与单体目标基本相同，唯一的区别在于需要通过[[spell:27243]]将持续伤害效果施加到更多目标上。下面你可以看到使用推荐的[[talent:123384]] 范围伤害专精时开场的一个示例。

:::rotation **痛苦 术士** 范围伤害 开场爆发（opener）在 团队副本   中
```json
{
  "source_code": "I0HTMI0aqBAAAcAUyVGc1xGbAIUN8CQABggQUPQAHkBCEwXIBEBDCEAnuGACQAQAE2CBBECCCtmaBcAEAIEXuMRAJUBERgRCIABgBIkvHEQOwAkQrpGAAAAAAIkvHMA"
}
```
1. [[spell:27243]] 战前准备
2. [[spell:48181]]
3. [[spell:980]]
4. [[spell:980]]
5. [[spell:205180]]  [[item:241308]] · [[item:273796]]
6. [[spell:27243]]
7. [[spell:1257052]]
8. [[spell:27243]]
9. [[spell:27243]]
10. [[spell:27243]]  
    
    1. [[spell:198590]]  
       
       随后回到主循环
11. [[spell:27243]]
12. [[spell:198590]]
:::

- 将所有 [[spell:246985]] 用于 [[talent:91571]]。
- 在优先目标上手动施加并维持 [[spell:980]]，尽量时刻保持 4 到 5 个痛苦效果存在，以帮助生成 [[spell:246985]]。

##### 优先级列表

1. 在最多 5 个目标上保持 [[spell:980]]。
2. 对主目标冷却即施放 [[spell:48181]]。
3. 冷却即施放 [[spell:205180]]。
4. 冷却即施放 [[spell:1257052]]。
5. 当 [[spell:246985]] 触发即将到达上限时，施放 [[talent:91571]]。
6. 当你有 [[spell:108558]] 触发时，施放 [[talent:91571]]。
7. 只要你有 [[spell:246985]]，就施放 [[talent:91571]]。
8. 施放 [[spell:388667]] 作为填充法术。

虽然[[spell:48181]]、[[spell:388667]]和[[spell:316099]]可能会降低你的总体DPS，但对优先目标而言仍然是伤害提升，而在许多首领战中，这往往比总体伤害更为重要。




#### [[talent:123382]]

##### 起手爆发

- 你在 范围伤害 开场爆发中的目标与单体情况类似，唯一的区别是需要通过 [[spell:27243]] 将持续伤害效果（DoT）施加到更多目标上。下面你可以看到一个示例，展示在使用推荐的 [[talent:123382]] 范围伤害 天赋专精时，你的开场爆发流程是什么样子。

:::rotation **痛苦 术士** 范围伤害 开场爆发（opener）在 团队副本   中
```json
{
  "source_code": "I0HTMI0aqBAAAcAUyVGc1xGbAIUN8CQABggQUPQAHkBCI47jGEQEIIEfhEQGMIQAc6aAIABABQYLEUAGEsmaBcAEAIEXuMRAJUBEJgBEAGgQ-eQAxADQCtmaAAAAAAgQ-ewA"
}
```
1. [[spell:27243]] 战前准备
2. [[spell:48181]]
3. [[spell:980]]
4. [[spell:980]]
5. [[spell:430014]]
6. [[spell:205180]]  [[item:241308]] · [[item:273796]]
7. [[spell:27243]]
8. [[spell:1257052]]
9. [[spell:27243]]
10. [[spell:27243]]  
    
    1. [[spell:198590]]  
       
       随后回到主循环
11. [[spell:27243]]
12. [[spell:198590]]
:::

- 将所有 [[spell:246985]] 用于 [[talent:91571]]。
- 在优先目标上手动施加并维持 [[spell:980]]，尽量时刻保持 4 到 5 个痛苦效果存在，以帮助生成 [[spell:246985]]。

##### 优先级列表

1. 在最多 5 个目标身上保持 [[spell:980]]。
2. 对主目标在冷却时施放 [[spell:48181]]。
3. 在冷却时施放 [[spell:430014]]。
4. 在冷却时施放 [[spell:205180]]。
5. 在冷却时施放 [[spell:1257052]]。
6. 当 [[spell:246985]] 触发即将达到上限时施放 [[talent:91571]]。
7. 当你拥有 [[spell:108558]] 时施放 [[talent:91571]]。
8. 当你拥有 [[spell:246985]] 时施放 [[talent:91571]]。
9. 以 [[spell:686]] 作为填充法术。

虽然[[spell:48181]]、[[spell:686]]和[[spell:316099]]可能会降低你的总体DPS，但对优先目标而言仍然是伤害提升，而在许多首领战中，这往往比总体伤害更为重要。





## 深度解析

### 爆发窗口

作为一名**痛苦 术士**，你要在**爆发窗口期**内施放尽可能多的[[spell:316099]]。

- **爆发期** 是指[[spell:205180]]就绪可用的时机。你的主要目标是为这个冷却技能储备尽可能多的[[spell:246985]]，并在这段窗口期内尽可能多地施放[[spell:316099]]。

随着经验的积累，你会更清楚在爆发期之外需要消耗多少[[spell:246985]]，这取决于你战斗的目标数量。

### 管理 灵魂碎片

[[talent:123384]]和[[talent:123387]]的主要目标都是在[[spell:205180]]激活期间尽可能多地消耗灵魂碎片。

这意味着在使用 [[spell:205180]] 之前，你应当拥有 4 到 5 枚灵魂碎片，并确保 [[spell:1257052]] 已就绪。这使你能够在使用 [[spell:205180]] 之后立刻消耗大量 [[spell:246985]]，从而打出最高的输出。

### 夜幕

随着**英雄天赋**的加入，你在整场战斗中获得的触发次数显著增加。以至于管理这些触发并避免溢出，与维持你的DoT以及不搞砸**爆发窗口期**同样重要。

[[talent:123384]] 提高 [[talent:91568]] 通过 [[talent:117435]] 获得的量。

[[talent:123387]] 和 [[talent:123384]] 之间的差别非常大，以至于你需要根据专精的不同以不同方式来管理你的 [[spell:246985]]。

### 吸取灵魂 打断

打断（Clip）指的是手动中断你的施法。没有必要完整引导 [[spell:388667]]，**除非**它被 [[talent:91568]] 强化了。因此，任何时候你在没有该效果的情况下施放 [[spell:388667]]，只要优先级更高的技能到来，你就应该打断当前施法。

例如，如果你正在引导普通的、未被强化的 [[spell:388667]]，此时触发了 [[talent:91568]]，你应该立即打断当前施法并消耗掉这个触发效果。

### 幽冥收割

虽然这个技能的使用方法相当直接，但有几点需要牢记：

- [[spell:1257052]] 是一个 1 分钟冷却的技能，每当我们施放 [[talent:91571]] 或 [[spell:316099]] 时其冷却时间都会缩短。因此，高效地消耗灵魂碎片来尽可能缩短这个强力技能的冷却时间是至关重要的。

### 优化 召唤黑眼

[[spell:205180]] 的主要特点是其对当前目标上每个持续伤害效果（DoT）都会增加伤害。为了最优地使用 [[spell:205180]]，你应该在短时间内尽可能连续地消耗灵魂碎片，以快速提升它的伤害。

另一个需要了解的要点是 [[spell:205180]] 是一个 **守卫者**，以及它如何更新自身属性。在 [[spell:205180]] 被召唤出来的那一刻和它已经在场上的情况下，更新方式是不同的。

一旦你施放 [[spell:205180]]，它会立即快照你的角色属性；但当它已经激活时，可能需要几秒钟才能更新属性。这就是为什么你应该在施放 [[spell:205180]] 之前（而不是之后）使用药水、种族技能以及任何使用后提升属性的饰品。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **痛苦 术士** 内克扎莉 天赋在团队副本中的表现
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

#### 首领攻略技巧

- 进入该阶段时，确保 [[spell:1271802]] 或 [[spell:1714]] 已在打断小怪身上生效




### 陵寝哨兵

:::talents **痛苦 术士** 陵寝哨兵 天赋在团队副本中的表现
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 首领攻略技巧

- 尽可能长时间地在两个首领身上保持[[spell:980]]。
- 一个放置得当的[[spell:48018]]可以让你在两个首领之间快速移动。




### 迷失的探险者们

:::talents **痛苦 术士** 团本中迷失的探险者天赋
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

#### 首领攻略技巧

- 将你的 [[spell:48018]] 放置在靠近中心的位置，这样你就可以选择传送到火焰圈上，而不必使用蘑菇。




### 瓦什尼克

:::talents **痛苦 术士** 团本中瓦什尼克的天赋选择
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 首领攻略技巧

- 为小怪出现时合理积攒[[spell:246985]]，以便快速爆发击杀它们。
- 提前放置好你的[[spell:111771]]和[[spell:48018]]，以便在各处小怪刷新点之间快速转移。




### 斯索拉克

:::talents **痛苦 术士** 斯索拉克 天赋在团队副本中的表现
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 首领攻略技巧

- 将 [[spell:48018]] 放在房间中部附近，以便在转阶段时保护自己免受击退和风的影响。




### 双牙

:::talents **痛苦 术士** 团本中双尖牙的天赋选择
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

#### 首领攻略技巧

- 始终保持 [[spell:980]] 在两个首领身上。
- 在小怪刷新前保留几个 [[spell:246985]]，以快速击杀它们并减少你的团队获得的层数。




### 盘绕祭坛

:::talents **痛苦 术士** 团本中盘绕祭坛的天赋选择
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 首领攻略技巧

- 确保为转阶段的伤害增益准备好 [[spell:205180]]。




### 乌拉特克

:::talents **痛苦 术士** 乌拉特克 天赋在团队副本中的表现
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 首领攻略技巧

- 预先将你的[[spell:48018]]放置在近战范围附近，以便能够传送过去躲避波次。




### 尼姆瑞莎·唤波者

:::talents **痛苦 术士** 尼姆瑞莎·唤波者 天赋在团队副本中的表现
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAMzsMLzMzyYAgZZbbMMmFz0YmZYLzCDbDAAAzAAAzMzMjZMzsxMMzMzMjBzMzAAMDM"
}
```
:::

#### 首领攻略技巧

- 在阶段转换的安全区域放置一个[[spell:111771]]，这样你的团队就可以抵消首领的击退效果。





## 属性优先级

了解你作为**痛苦 术士**在团队副本首领战中发挥最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **痛苦 术士** 团队副本属性优先级
```json
{
  "source_code": "IoAJFUAIkEDKBMwAEA"
}
```
**智力 ＞ 暴击 ≥ 急速 ≥ 精通 ≫ 全能**
:::

在装备初期，你的主要目标是避免全能属性，其他所有属性对**痛苦术士**都有收益。

:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可以减少"**范围伤害**"技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外治疗。你的宠物造成的伤害无法为你回血，因此**吸血**对你来说是一个极佳的副属性，因为你的大部分伤害都来自你自己的法术。
- **加速** - 小众副属性，但在某些情况下非常有用，并且过去已被证明其实用性。能让处理某些副本机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271874@BCRAAkQAK06YhNCKAWB]] | 乌拉特克 |
| 项链 | [[item:268265@BERAAkQAX16oQrDj1IoAYFA]] | 乌拉特克 |
| 肩部 | 将 [[item:239031@BgQAAkQACKgTBA]]  <br>转化为 [[item:271544@DgQAAkQAXk7IoAOF]] | 塞斯拉里斯神庙 / 催化装置 |
| 披风 | [[item:268253@BgQAAkQACKAWBA]] | 盘卷祭坛 |
| 胸部 | [[item:271549@DgQAAkQAJk7IoAOF]] | 套装 / 催化装置 |
| 腕部 | [[item:239648@FCQAAkQAno6kBwjCtOLF]] | 制造业 |
| 手套 | 将 [[item:268243@BgQAAkQACKAWBA]]  <br>转化为 [[item:271547@BgQAAkQACKAWBA]] | 盘卷祭坛 / 催化装置 |
| 腰带 | [[item:239649@FCQAAkQAno6oBwjCtOLF]] | 制造业 |
| 腿部 | [[item:271545@DgQAAkQAFo6IoAOF]] | 套装 / 催化装置 |
| 脚部 | [[item:268255@DgQAAkQApk7IoAYF]] | 盘卷祭坛 |
| 戒指 1 | [[item:268252@DiQAAkQA1j7oQrjgC4UA]] | 斯索拉克 |
| 戒指 2 | [[item:273792@DiQAAkQA1j7oQrjgC4UA]] | 毒牙祭坛 |
| 饰品 1 | [[item:273796@BgQAAkQACKgTBA]] | 毒牙祭坛 |
| 饰品 2 | [[item:270164@BgQAAkQACKgTBA]] | 迷失的探险者 |
| 武器 | [[item:271092@DgQAAkQA9k7IoAYF]] | 乌拉特克 |
| 副手 | [[item:273779@BgQAAkQACKgTBA]] | 毒牙祭坛 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251199@BgQAAkQACKQQBA]] | 夺目谷 |
| 项链 | [[item:273781@BgQAAkQACKQQBA]] | 毒牙祭坛 |
| 肩部 | [[item:271544@BgQAAkQACKQQBA]] | 套装 / 催化装置 |
| 披风 | [[item:239656@FAQAAkQAno6oBwzSBA]] | 制造业 |
| 胸部 | [[item:271549@BgQAAkQACKQQBA]] | 套装 / 催化装置 |
| 护腕 | [[item:239648@FCQAAkQAno6kBwjCtOLF]] | 制造业 |
| 手套 | [[item:271547@BgQAAkQACKQQBA]] | 套装 / 催化装置 |
| 腰带 | [[item:251222@BgQAAkQACKQQBA]] | 虚空之痕竞技场 |
| 腿部 | [[item:271545@BgQAAkQACKQQBA]] | 套装 / 催化装置 |
| 靴子 | [[item:159259@BgQAAkQACKQQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251136@BgQAAkQACKQQBA]] | 密谋小径 |
| 戒指 2 | [[item:273792@BgQAAkQACKQQBA]] | 毒牙祭坛 |
| 饰品 1 | [[item:273649@BgQAAkQACKQQBA]] | 诸王之眠 |
| 饰品 2 | [[item:273794@BgQAAkQACKQQBA]] | 毒牙祭坛 |
| 武器 | [[item:251123@BgQAAkQACKQQBA]] | 密谋小径 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:273649@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A级** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B级** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C级** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **垃圾级** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### 美化饰品

- 1个[[item:245876@BAAAAkQA]]
  
  - 只可制作在你的**主手**或**副手武器**上。制作在主手上可在前期获得更多强度，制作在副手上则可获得长期的最佳配装收益。
- 1个[[item:245876@BAAAAkQA]]
  
  - 前期可将其中2个用于**主手**和**副手武器**的组合。当你拾取到一件史诗武器并升级后，可以移除主手上的[[item:245876@BAAAAkQA]]，换成拾取到的更高装等的物品。

或

- 1件 [[item:245876@BAAAAkQA]]
  
  - 制作在**副手武器**上。
- 1件 [[item:251488]]
  
  - 制作在**戒指**上是长期使用的最佳选择。

或

- 2件 [[item:240167]]
  
  - 制造装备选择护腕和披风部位。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **合剂**
  
  - [[item:241326]]
  
  
  
  - [[item:241324]]
- **食物**
  
  - [[item:255846]] —— 默认选择
- 战斗药水
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]] —— 提供一次大量的治疗爆发
- 武器油
  
  - [[item:243734]] —— 默认选择
- 强化符文
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240967]] *—— 唯一，使用每种颜色的宝石各一颗来强化你的 [[item:240967]]。*
    
    - [[item:240900]]
    
    
    
    - [[item:240892]]
    - [[item:240916]]
    - [[item:240906]]

### 附魔

:::columns
:::column
| 头部 | [[item:243981@DAAAAkQAZbAB]]  <br>[[item:275707@BAAAAkQA]] |
| --- | --- |
| 披风 | [[item:223731@BAAAAkQA]] |
| 胸部 | [[item:243977@BAAAAkQA]] |
| 护腕 | [[item:275707@BAAAAkQA]] |
| 腰部 | [[item:275707@BAAAAkQA]] |
| 腿部 | [[item:240133@BAAAAkQA]] |
| 脚部 | [[item:244009@BAAAAkQA]] |
| 戒指1 | [[item:243957@BAAAAkQA]] |
| 戒指2 | [[item:243957@BAAAAkQA]] |
| 武器 | [[item:244029@BAAAAkQA]] |

:::

:::column
:::gear **痛苦 术士**在团队副本中的附魔
```json
{
  "source_code": "JQFaJEQ9NCQA7TDBQAAAAcG3SEw-4OAAAAAABkQuJgAC7TDBFABBFoaCQAQK6gBAAUfDwgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[spell:1236071]] |
| 肩部 | [[item:243963]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAkQA]]，为你的**头盔**、**护腕**和**腰带**添加宝石插槽。

## 种族

对于追求团队副本极限优化的**痛苦 术士**来说，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:65116]] —— 矮人
  
  - 驱散魔法和流血减益效果。过去在部分有流血机制的首领战中曾经很有用。
- [[spell:69070]] —— 地精
  
  - 朝角色面朝的方向进行一次小距离跳跃。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:26297]] *—— 巨魔* 
  
  - 强力的输出种族技能，但与 [[spell:205180]] 的配合不佳。
  - 使移动限制效果的持续时间缩短 20%。在近期的开荒历史中只发挥过一次作用，但仍值得一提。
- [[spell:33702]] *—— 兽人* 
  
  - 强力的伤害向种族技能，因为 [[spell:21563]] 和 [[spell:33702]] 都能与 [[spell:205180]] 相配合。
  - 使你受到的眩晕持续时间缩短 20%，在某些情况下可能很有用。
- [[spell:274738]] *-- 玛格汉* 兽人
  
  - 强力的输出种族技能，可与 [[spell:205180]] 相配合。
- [[spell:256948]] —— 虚空精灵
  
  - 放出一个沿你面朝方向移动的虚空残影，再次激活技能即可传送到残影处。
  - 最大距离为 100 码。

### 推荐

总体而言，可以说如果你在乎将输出极限化（min-max），就应该选择输出最高的种族技能。不过，如果是开荒团队副本，情况就有些不同了。某些种族技能能极大加快特定首领的开荒进度。例如，矮人 凭借其 [[spell:65116]]，在争夺世界第一的比赛中，能够在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键时刻轻松驱散自身的负面效果，从而提供了巨大帮助。

## 宏

了解**痛苦术士**在团队副本战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:30283]]** -- *在鼠标光标位置施放[[spell:30283]]，无需确认。*

```wow-macro
#showtooltip
/cast [@cursor] 暗影之怒
```

:::

:::details 鼠标指向宏
**[[spell:316099]]** -- *对鼠标指向目标或当前目标施放[[spell:316099]]。*

```wow-macro
#showtooltip 痛苦无常
/cast [@mouseover,exists] 痛苦无常;痛苦无常
```

**[[spell:980]]** -- *对鼠标指向目标或当前目标施放[[spell:980]]。*

```wow-macro
#showtooltip 痛楚
/cast [@mouseover,exists] 痛楚;痛楚
```

**[[spell:146739]]** -- *对鼠标指向目标或当前目标施放[[spell:146739]]。* *如果选择了[[talent:123387]]，会自动切换为[[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]]。*

```wow-macro
#showtooltip 腐蚀术
/cast [@mouseover,exists] 腐蚀术;腐蚀术
```

**[[spell:702]]** -- *对鼠标悬停目标或当前目标使用[[spell:702]]。*

```wow-macro
#showtooltip 虚弱诅咒
/cast [@mouseover, exists, harm, nodead] 虚弱诅咒; 虚弱诅咒
```

**[[spell:1714]]** -- *对鼠标悬停目标或当前目标使用[[spell:1714]]。*

```wow-macro
#showtooltip 语言诅咒
/cast [@mouseover, exists, harm, nodead] 语言诅咒; 语言诅咒
```

**[[spell:334275]]** -- 对鼠标悬停目标或当前目标使用*[[spell:29539]]。*

```wow-macro
#showtooltip 疲劳诅咒
/cast [@mouseover, exists, harm, nodead] 疲劳诅咒;[@target] 疲劳诅咒
```

```wow-macro
#showtooltip
/cast [@mouseover,exists] 吸取生命;吸取生命
```

**[[spell:710]]** -- *若鼠标指向目标存在，则对其施放 [[spell:710]]。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] 放逐术; [harm,nodead] 放逐术
```

:::

:::details 宠物宏
> 我们主要为宠物使用自定义宏，因为过去 [[spell:119898]] 的常规功能被证明并不可靠。

**宠物技能1宏** -- *施放你的主宠物技能，对每个宠物均作用于*你鼠标指向的目标。

```wow-macro
/cast [@mouseover]烧灼驱魔
/cast [@mouseover,exists]法术封锁;法术封锁
/cast [@mouseover]受难
/cast [@mouseover,exists]魅惑;魅惑
/cast [@mouseover,exists]利斧投掷;利斧投掷
/cast [nopet,@mouseover,exists]恶魔掌控;[nopet]恶魔掌控
```

**焦点目标宠物技能** **1 宏** -- *为你的每只宠物对其焦点目标施放主要宠物技能。*

```wow-macro
/cast [@focus] 烧灼驱魔
/cast [@focus] 法术封锁
/cast [@focus] 受难
/cast [@focus] 魅惑
/cast [@focus] 利斧投掷
/cast [nopet,@focus] 恶魔掌控
```

**宠物技能** **2 宏** *-- 在需要时对你的鼠标指向目标施放第二个相关宠物技能。*

```wow-macro
/cast [@mouseover] 烧灼驱魔
/cast [@mouseover,exists] 吞噬魔法;吞噬魔法
/cast 暗影壁垒
/cast 魔刃风暴 
/cast [nopet,@mouseover] 恶魔掌控
```

**焦点目标宠物技能** **2 宏** -- *对你的焦点目标施放第二个相关宠物技能，同时命令你的宠物攻击焦点目标。*

```wow-macro
/cast [@focus]烧灼驱魔;
/cast [@focus] 吞噬魔法;
/cast [@focus] 次级隐形术;
/cast 暗影壁垒;
/cast [nopet,@focus] 恶魔掌控
/petattack [@focus]
```

**[[spell:108503]] 与解散宠物** -- *如果你点出了该天赋，则施放 [[spell:108503]]。如果你没有天赋《牺牲魔典》，则会改为解散你的宠物。*

```wow-macro
#showtooltip
/run if not IsSpellKnown(108503) then PetDismiss(); end
/cast 牺牲魔典
```

:::

:::details 实用 宏
**[[spell:20707]]** 鼠标指向 -- *对你的鼠标指向目标施放 [[spell:20707]]，传统的 [@mouseover,exists] 宏一段时间前已失效，这是一个替代方案。*

```wow-macro
#showtooltip 灵魂石 
/target [@mouseover,help] 
/cast 灵魂石 
/targetlasttarget
```

**[[spell:5697]]** 自我施法 *-- 在不选中任何目标的情况下对自己施放 [[spell:5697]]。在你无法对任何目标进行输出时仍然可以用来刷饰品触发/层数，非常有用。*

```wow-macro
#showtooltip
/cast [@player] 无尽呼吸
```

**[[spell:30283]] / [[spell:5484]]**选择*-- 根据所选天赋在[[spell:30283]]**和[[spell:5484]]之间切换。*

```wow-macro
/cast [known:暗影之怒] 暗影之怒
/cast [known:恐惧嚎叫] 恐惧嚎叫
```

:::

:::

## 插件

下方是作者的**痛苦 术士**用户界面截图，展示了使用了哪些插件，以及它们在团本中如何使用以让你更轻松。此外还附上了一些你可能会觉得有用的其他插件。

![](<https://assets-ng.maxroll.gg/wordpress/UI-ss-maxroll-1024x610.jpg>)

**痛苦 术士**的团本界面

:::accordion
:::details 插件
- **MRT** —— 记事、团队副本冷却监控等功能
  
  - 对团队副本玩家非常有用的插件，尤其是对团队副本团长和官员而言。
- **ElvUI** *—— 完整的界面替换插件* 
  
  - 一款以用户友好为设计理念的界面插件，带有标准界面所不具备的额外功能。
  - 或者，你也可以使用 Shadowed Unit Frames (SUF) 加上任意一款动作条插件，当然也可以使用原生界面。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一款首领战插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件专为某一场特定的团队副本战斗提供警报信息、计时条、音效等功能。
- **Plater**  —— 高级姓名版插件
  
  - Plater 是一款姓名版插件，拥有极为丰富的设置项，开箱即用的减益监控、仇恨着色，并支持自定义脚本。
- **BetterCooldownManager**  *--* 高级暴风雪冷却管理器
  
  - BetterCooldownManager 是一款插件，可以对默认的暴风雪冷却管理器进行更多自定义，并使其外观更加整洁。
- **Details**  *--* 伤害统计
  
  - Details 可以对暴雪默认的伤害统计进行更多的自定义。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- **地狱召唤者** 
  
  - *开发者说明：我们正在调整黑化灵魂，为地狱召唤者提供一个更好的工具，将伤害集中于优先目标，从而提升英雄天赋树的整体灵活性，而不是让它只在多目标场合中大放异彩。不过，我们将保持怨毒的功能不变，因此它仍是地狱召唤者技能库中一个炫酷且极具影响力的工具。*
  - 黑化灵魂已重新设计——如果目标身上带有你的枯萎，你的混乱之箭和暗影灼烧会使其层数增加1。枯萎每次获得层数时都有几率塌缩，每1秒消耗1层，对其宿主造成暗影烈焰伤害，直到只剩1层。
  - 佩洛萨恩印记已重新设计——枯萎造成的伤害性爆击 now 造成215%伤害（通常为200%）。黑化灵魂造成的伤害性爆击造成225%伤害（通常为200%）。
- **痛苦** 
  
  - 鬼影缠身现在使你对目标造成的伤害提高16%，持续18秒（原为12%）。
  - 新天赋：享乐吞噬——使吸取生命的伤害提高10%，且生命虹吸现在额外使腐蚀术的伤害提高10%。幽冥收割引导速度加快10%，并造成15%的额外伤害。
  
  
  
  - 零号病人已被移除。
  - 新天赋：轻率之怒——若目标受到鬼影缠身影响，暗影箭、吸取灵魂和恶魔之握的伤害提高10%或20%。若目标受到鬼影缠身影响，幽冥收割的伤害提高10%或20%。
  - 碎片动荡已重新设计——暗影箭或吸取灵魂造成的伤害有20%的几率使你的下一个痛苦无常或腐蚀之种不消耗灵魂碎片并瞬发。
  - 夜之馈赠已被移除。

:::

:::

:::accordion
:::details 补丁12.0.1
- **地狱召唤者** 
  
  - 怨毒伤害提高230%。

- 灵魂收割者
  
  - 邪恶收割现在会提高 具现贪欲 的灵魂挥击的伤害。
  - 共享之器现在使精通提高 2%（原为 4%）。
  - 显化的恶魔之魂的灵魂挥击伤害降低 30%。此改动不影响 PvP 战斗。
  - 灵魂诅咒伤害降低 40%。
- 痛苦
  
  - 萨泰尔的意志不再影响获得 夜幕 的几率。
  - 幽冥收割 伤害降低 30%。
  - 同一时间只能存在一层 鬼影缠身。
  - 死亡逼近不再影响获得 夜幕 的几率。

:::

:::

:::accordion
:::details 补丁12.0
- **地狱召唤者** 
  
  - 新天赋：穿越邪藤 痛苦：使 痛苦无常 的伤害提高8%，腐蚀之种 的伤害提高4%。在 怨毒 激活期间，此效果翻倍。
  - 新天赋：恶魔果实 – 枯萎 造成的周期性伤害有几率使你获得 怨毒，持续8秒。
  - 新天赋：阿尔扎因的邪恶 – 怨毒 额外赋予4%急速，并且施放时会使当前激活的枯萎层数额外增加2层。
  - 黑化灵魂 伤害提高30%。
- **痛苦** 
  
  - 灭世之种现在有几率赋予 碎片动荡（原为苦痛渐强）。
  - 萨维斯 之印现在使 痛楚 伤害提高30%（原为20%）。
  - 枯萎 伤害降低35%。
- **灵魂收割者** 
  
  - 新天赋：具现贪欲 – 每消耗一个 诱人灵魂，都有不断递增的几率释放你体内的恶魔之魂，使其攻击你的敌人，持续9秒。
  - 新天赋：灵魂横扫 – 用一只邪恶的利爪打击附近的敌人，对其目标造成 暗影 伤害，并对10码内的其他敌人造成 暗影 伤害。
  - 新天赋：共享容器 – 使你的精通提高4%。当恶魔实体在战斗中协助你时，此效果翻倍。
  - 新天赋：永恒饥渴 – 使 具现贪欲 的持续时间延长5秒，并使灵魂横扫的伤害提高10%。
  - 恶魔之魂已更新 – 现在一个恶魔实体栖息于你的灵魂之中，使你能够察觉获得的灵魂碎片是否带有 诱人灵魂。消耗一个 诱人灵魂 会释放你的恶魔之魂，对目标10码范围内的所有敌人造成 暗影 伤害。超过8个目标后伤害降低。恶魔之魂伤害提高100%。
  - 邪恶魔收割伤害提高150%。
  - 灵魂诅咒伤害提高50%。
- **痛苦** 
  
  - 死亡之影 已重新设计 – 你的 幽冥收割 法术被你体内的恶魔实体强化，在引导期间每1秒赋予1个灵魂碎片，且每个碎片都包含一个 诱人灵魂。
- **职业** 
  
  - 新天赋：疲劳诅咒 – 使目标的移动速度降低50%，持续12秒。
  - 新天赋：语言诅咒 – 强迫目标使用恶魔语交谈，使其所有法术的施法时间延长30%，持续1分钟。
  - 新天赋：虚弱灾厄 – 召唤一团黏滞的暗影迷雾，笼罩目标及其10码范围内的所有敌人，使他们的攻击间隔延长100%，爆击几率降低10%，持续12秒。
  - 新天赋：语言灾厄 – 召唤一团黏滞的暗影迷雾，笼罩目标及其10码范围内的所有敌人，使其所有法术的施法时间延长100%，持续12秒。
  - 新天赋：强化死亡缠绕 – 使 死亡缠绕 的范围扩大10码，治疗量提高5%。
  - 新天赋：地狱火 受益者 – 吸取生命 造成的治疗现在还会以400%的效果治疗你的主要恶魔。
  - 新天赋：邪污巨口 – 施放 疲劳诅咒、语言诅咒或虚弱诅咒现在会诅咒目标10码范围内的所有敌人。
  - 新天赋：共享生命力 – 吸取生命 造成的治疗现在还会以100%的效果治疗你的主要恶魔。
  - 新天赋：血魔 的贪婪 – 吸取生命 现在引导速度提高50%/100%，恢复生命值的速度提高50%/100%。
  - 新天赋：旅行常客 – 使 恶魔传送门 的施法时间缩短0.5秒，并且你现在可以在触发冷却之前使用两次恶魔传送门。
  - 新天赋：萨特契约 – 使你的急速提高3%。
  - 新天赋：安尼赫兰契约 – 使你的爆击几率提高2%。
  - 新天赋：纳斯雷兹姆契约 – 使你的吸血提高2%。
  - 新天赋：艾瑞达契约 – 使你的智力提高3%。
  - 新天赋：强化 治疗石 – 治疗石额外恢复5%生命值。
  - 新天赋：强化 吸取生命 – 吸取生命 现在按所造成伤害的700%进行治疗，并赋予相当于所造成伤害10%的灵魂吸取。
  - 新天赋：强化灵魂 – 灵魂吸取现在提供的护盾最高可达你最大生命值的15%。
  - 新天赋：压迫黑暗 – 使 暗影之怒 的冷却时间缩短15秒，范围扩大2码。使 恐惧嚎叫 的冷却时间缩短10秒，并且现在可额外恐惧5个敌人。
  - 许多天赋在天赋树中的位置发生了变化。
  - 已为全部3个专精实装了新的初始构筑。
  - 以下天赋已被移除：
  - 累积活力
  - 诅咒增幅
  - 衰弱诅咒
  - 黑暗之怒
  - 恶魔鼓舞
  - 恶魔战术
  - 生命之血
  - 疲劳契约
  - 语言契约
  - 索克雷萨的诡诈
  - 灵魂导管
  - 萨格雷技艺
  - 萨特教诲
  - 愤怒仆从
- 痛苦 
  
  - 新天赋：熟练瘟疫 – 使你的精通提高2%。
  - 新天赋：苦痛共享 – 使 痛楚 伤害提高10%，并且 痛楚 现在会击中目标15码范围内的另一名附近敌人。
  - 新天赋：毁灭之种 – 使 腐蚀之种 的施法时间缩短0.2秒/0.4秒，伤害提高5%/10%。
  - 新天赋：幽冥收割 – 汲取每个受到你的伤害性持续效果影响的敌人的生命力，在3秒内造成暗影烈焰伤害。幽冥收割 造成的伤害会为你恢复相当于所造成伤害50%的生命值。1分钟冷却。
  - 新天赋：钻心剧痛 – 痛楚 伤害提高10%，并且初始带有3层。
  - 新天赋：致命回响 – 当 痛苦无常 到期时，有10%的几率重新施加自身。
  - 新天赋：碎片动荡 – 暗影箭/吸取灵魂 造成的伤害有20%/10%的几率使你的下一个 痛苦无常 不消耗 灵魂碎片 并立即施放。
  - 新天赋：夜幕收成 – 使 腐蚀术 伤害提高10%，并且 夜幕 额外使你的下一个 腐蚀之种 不消耗 灵魂碎片 并立即施放。
  - 新天赋：零号病人 – 使 腐蚀之种 对其宿主造成的伤害提高50%。
  - 新天赋：腐蚀播种 – 腐蚀之种 现在会以50%的效果将恶魔种子额外植入2名附近敌人体内。
  - 新天赋：邪恶束缚 – 在黑暗之眼激活期间，你的 暗影箭/吸取灵魂 变为邪恶束缚。邪恶束缚：用暮光束缚目标，在4秒内造成 暗影 伤害。当邪恶束缚造成伤害时，会使你所有其他周期性 痛苦 伤害效果立即造成其正常周期伤害30%的伤害。
  - 新天赋：强力 灵魂碎片 – 使 痛苦无常 和 腐蚀之种 造成的伤害提高5%。
  - 新天赋：尼斯卡拉之法 – 使 痛楚 和 腐蚀术 的伤害提高10%。
  - 新天赋：眼球契约 – 使 召唤黑眼 的持续时间延长5秒。
  - 新天赋：虚空铠甲 – 为你的黑暗之眼装备由安托鲁斯内部锻造的护甲，使其护甲值提高10%。眼棱 现在最多可额外跳向4个目标，并造成10%的额外伤害。
  - 痛苦无常 已重新设计 – 在8秒内对目标造成 暗影 伤害。此技能可多次使用并叠加。若被驱散，则对驱散者造成 暗影 伤害并使其沉默4秒。若目标在受影响期间死亡，则产生1个灵魂碎片。痛苦无常 伤害提高20%。
  - 萨维斯的诡计 已重新设计 – 使 痛苦无常 的施法时间缩短0.15秒/0.3秒，伤害提高5%/10%。
  - 强化鬼影缠身 已重新设计 – 使 鬼影缠身 的伤害提高35%，施法时间缩短0.3秒。
  - 恃强凌弱 已重新设计 – 施放 痛苦无常 或 腐蚀之种 会使 幽冥收割 的冷却时间缩短1.5秒。
  - 死亡之拥已重新设计 – 痛楚、腐蚀术、痛苦无常、腐蚀之种 和 暗影箭/吸取灵魂 对生命值低于35%的目标最多造成40%的额外伤害。目标生命值越低，伤害提升越高。
  - 死亡蔓延已更新 – 你的 痛楚、腐蚀术 和 痛苦无常 造成伤害的速度加快10%/20%。
  - 枯萎箭已更新 – 暗影箭/吸取灵魂 伤害提高5%/10%，你对目标激活的每个持续伤害效果额外提升，最高可达15%/30%。
  - 腐蚀之种 伤害提高330%，超过8个目标后伤害降低。
  - 召唤黑眼 已更新 – 从扭曲虚空中召唤一只黑暗之眼，在激活期间使 痛楚、腐蚀术/枯萎 和 痛苦无常 的伤害提高20%。黑暗之眼将为你效力20秒，用 暗影 伤害轰击其目标，你对目标激活的每个持续伤害效果使其伤害提高10%（原为45%）。冷却时间现在为2分钟（原为1分钟）。
  - 召唤黑眼 伤害提高260%。此改动不影响PvP战斗。
  - 痛楚 已移至天赋树中（原为10级习得）。
  - 痛楚 伤害提高82%。此改动不影响PvP战斗。
  - 腐蚀术 伤害提高50%。
  - 暗影箭 伤害提高60%。此改动不影响PvP战斗。
  - 吸取灵魂 伤害提高60%。此改动不影响PvP战斗。
  - 传染的图标已更新。
  - 若干天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
  - 黑暗造诣
  - 专注恶毒
  - 强化 灾难狂欢
  - 燃起恶意
  - 灾难狂欢
  - 邪恶之触
  - 恶毒幻想家
  - 恶毒预兆
  - 湮灭
  - 永动不稳
  - 诡异魅影
  - 舍弃
  - 暗影 之拥
  - 灵魂腐化
  - 苦痛渐强
  - 邪恶污染
  - 不稳定 痛楚

:::

:::

## 常见问题

:::accordion
:::details Q: 我应该使用哪只宠物？
**答：** 如果魅魔的近战覆盖率不足，你应该使用 [[spell:712]] 或 [[spell:688]]。

:::

:::

---

### 致谢

作者：**Spen**

审核：**Ftm**

---

:::changelog 更新记录
**2026-08-03** 已更新至12.1版本

**2026-06-17** 已更新至12.0.7版本

**2026-04-22** 已更新至12.0.5版本

**2026-02-22** 已更新至12.0.1版本

**2026-02-10** 已更新至12.0.1版本



:::
