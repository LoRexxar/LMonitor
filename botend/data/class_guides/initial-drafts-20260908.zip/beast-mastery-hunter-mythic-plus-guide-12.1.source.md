Welcome to the **Beast Mastery Hunter** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 1/5 · Subpar

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Beast Mastery Hunter** Mythic+ Best in Slot
```json
{
  "source_code": "JooAwLX_Ac__AEAhkQggIUAAnk7AX16ACKgTBsbpDEQ6XQAAREAAC06AC06AMWTOCgVABIIJEIACFAwF5OggCgVAHfBBBcIJEIAEFAQC5OAj1kjAYFABmQQAlt7AEiQAA4BwDciqDIQrDcbNLFQADSCBCgQAAE6uFEGDBk8FEEwDA8QAKBhTBEAa7q0MAgRhkQAAIUAABEJMVHnABk9FEIICBAQ94GAVBUBDB4paCojEAgxXfQAAIMAAB4JHFAQA2chABQVASAQAFUEEB09FEAQBMgEWBEwrXQgAQEAA_k7AMWTOCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271492]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271490]] | [[item:243991]] |
| 胸部 | [[item:271495]] | [[item:243977]] |
| 腰部 | [[item:244581]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 腿部 | [[item:271491]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271493]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268207]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Beast Mastery Hunter**, you have access to Nature's Ally.

- **Rank 1**: Gives you [[spell:1273043]].
- **Rank 2**: The first and the second talent point in **Rank 2** increases damage done by your pets by 5% and makes [[spell:19574]] strike 2 additional targets. This means that after spending 2 talent points in **Rank 2** you end up getting 10% increased damage done by your pets and [[spell:19574]] striking 4 additional targets.
- **Rank 3**: Enables [[spell:1273126]], greatly increases the power of [[talent:126408]] if used correctly.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-beastmastery-mxr.webp>)

Nature's Ally

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:19574]]
    
    - **Beast Mastery Hunter's** main cooldown. No longer gets its cooldown reduced by [[spell:217200]], it however now has a flat 30 seconds cooldown when talented into [[spell:231548]].
  
  
  
  - [[spell:217200]]
    
    - Functionality has changed quite a bit. [[spell:217200]] no longer generates [[spell:272795]]. Additional [[spell:217200]] will now reapply and add to the new  [[spell:217200]], very similar to how [[spell:12654]] works.
  
  
  
  - [[spell:1272099]]
    
    - Is no a longer useable cooldown but instead applies a powerful DoT when you pressing [[spell:19574]].
  - [[spell:321014]]
    
    - Redesigned, less passive focus regen but more of its generation tied into [[spell:217200]].
- **Class Tree**
  
  - [[spell:257284]]
    
    - Now gives a passive 3% damage increase to its target but is no longer tied to enemy health being > 80%. This makes [[spell:257284]] a really strong raidbuff on single enemies.
  
  
  
  - [[spell:1258509]] 
    
    - New functionallity for [[spell:19577]] wich makes it a short AoE stun.
  - [[spell:472729]]
    
    - Choice node for [[spell:109248]], makes enemies get dragged to binding shot's center on stun. This talent is no longer locked behind [[talent:123347]] since it has been moved to the class talent tree.
  - [[spell:272679]]
    
    - Functionality has changed. Instead of being an on use defensive it's now a passive 3% damage reduction.
  - [[spell:53480]]
    
    - Functionality has changed, it's now an external that can be used on any friendly target. It works very similar to how [[spell:6940]] works, but instead of it fading on your own health going low it fades on pet health going below 25%. Choicenode with [[spell:1272094]].
- **Removed**
  
  - [[spell:359844]] 
    
    - This was **Beast Mastery Hunter** major cooldown, a lot of its functionality was moved into [[spell:19574]].
  
  
  
  - [[spell:53351]]
    
    - [[talent:123348]] still gains [[spell:466932]]
  
  
  
  - [[spell:2643]] 
    
    - Basically just replaced with [[spell:1264359]]. A stronger hitting AoE spell but now has a cooldown.
  
  
  
  - [[spell:212431]] 
    
    - This was very rarely used, no major change.
  - [[spell:186387]]
    
    - Removing this lost **Beast Mastery Hunter** one of its few ways to access knockback, this leaves **Beast Mastery Hunter** with no knocks and very limited utility.
  
  
  
  - [[spell:213691]]
    
    - Removing this lost **Beast Mastery Hunter** one of its few utility cooldowns.
  
  
  
  - [[spell:236776]] and [[spell:462031]] 
    
    - Removing this lost **Beast Mastery Hunter** one of its few ways to access knockback, this leaves **Beast Mastery Hunter** with no knocks and very limited utility.

## Hero Talents

- Patch 12.0 brought about some talent and tuning changes for [[talent:123347]] and a partial revamp for the [[talent:123348]] hero tree. Right now [[talent:123347]] is ahead in every scenario, the only thing [[talent:123348]] does better is defensive power. So at the start of 12.1 we will be playing [[talent:123347]] in m+.

:::tabs
:::tab [[talent:123348]]
- [[talent:123348]] gains [[spell:466932]] since [[spell:53351]] was removed in 12.0.
  
  - Just like [[spell:53351]] you can only use [[spell:466932]] whenever your target is at a certain HP threshold.
  
  
  
  - Also since Beast Mastery Hunter's gained access to [[spell:343248]] there are mainly two ways to reset [[spell:466932]] cooldown. [[talent:117565@AJwA]] enables your primary rotation spells [[spell:217200]] and [[spell:34026]] to proc [[spell:343248]]
- [[talent:132888@AJwA]] is allowing for [[talent:117584]] periodic dot to be applied to every target hit by [[talent:117571@AJwA]] as well as granting you [[talent:126403]] while talented and hitting 2 or more enemies.
- Your capstone [[talent:117590@AJwA]], gives you a proc of [[spell:343248]]  and fires 2 extra [[spell:466932]] when casted.
  
  - You get [[talent:117590@AJwA]] for 10 seconds after casting [[spell:19574]]
- There is now only a single defensive node in the tree since [[talent:117556]] has been removed in 11.2. [[talent:123779]] still remains.

- [[spell:1264289@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - 10% Chance to summon a Dark Hound instead of a [[spell:120679]]
- [[spell:1264290@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - [[spell:19574]] now also summons a Dark Hound  
    After [[spell:19574]] is used its transformed into [[spell:392060]]
- [[spell:1264291]]
  
  - Fire 2 additional [[spell:466932]] during [[talent:117590@AJwA]] barrage.
  - [[spell:115939]] and [[spell:378207]] damage increased by 10%.
- [[spell:1264690@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - [[spell:34026]] Causes your Dark Hound to Shadow Thrash, dealing AoE damage.

With Patch 12.0, Blizzard removed following Hero talent.

- [[spell:467941@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]

:::

:::tab [[talent:123347]]
- Every 30 seconds gain [[talent:117588]]
  
  - This will summon one of three Beasts 
    
    - The Wyvern will give you up-to 10% increased damage for you and your pet for up to 19 seconds.
    - The Bear will initially leap in and [[spell:471999]] up-to 8 nearby enemies and then auto attack your current target.
    - The Boar will charge your target 1 time dealing a large amount of damage to your primary target and a lesser amount to nearby enemies.
  - Consuming [[talent:117588]] will also increase the damage of your next [[spell:34026]] and reduce the duration of [[spell:217200]] by 6 seconds.
- [[talent:126402]] has had even more power baked into it with [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]] being added.
- New to patch 12.0 [[talent:117559@AJwA]] has been reworked to be a 2% damage buff to pets as well as a 10% increased damage to [[spell:217200]].
- [[talent:117564]] has been updated in 12.0, [[talent:126488]] now summons a Turtle to aid you, further increasing its damage reduction effect by 10%.

- [[spell:1264781]]
  
  - Auto shot/auto attacks grant 2 Focus to you and your pet. Auto shot/auto attack damage increased by 25%
- [[spell:1264774]]
  
  - Mastery is increased by 3%.
- [[spell:1264797]]
  
  - Hogstrider further increases the damage of [[spell:193455]] by 10% and it now stacks up to 3 additional times.
- [[spell:1264792]]
  
  - The damage bonus from your Wyvern now lasts an additional 2 seconds.
- [[spell:472524]]
  
  - The damage of your Bear's [[spell:471999]] is increased by 15%
- [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - Casting [[talent:126402]] grants [[talent:117588]] and causes your next [[spell:34026]] to rouse the nearby wildlife into a Stampede, charging your target and dealing heavy Physical damage over 7 seconds.
- [[spell:1268705]]
  
  - The duration of [[spell:53271]] is increased by 2 seconds and it increases the movement speed of its target by 20%.

With Patch 12.0, Blizzard removed the following Hero talents.

- [[spell:472539]]
- [[spell:472729]]
  
  - Author's Note: Talent moved to class talent tree.
- [[spell:472743]]

:::

:::

## Talents

:::tabs
:::tab [[talent:123347]] Mythic+
:::talents [[talent:123347]] **Beast Mastery Hunter** AoE Mythic+ Build
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### When to use this Spec

You can use this Spec at all levels of Mythic+ keys. [[talent:123347]] provides a very consistent damage output at all times due to the low cooldown of [[spell:19574]] and high uptime of [[spell:115939]] from using [[spell:1264359]].

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[spell:1264359]]
  
  - Your main cooldown for AoE damage.
- [[spell:267116]]
  
  - Large single-target and AoE increase since your pet-summon will summon an additional secondary pet, this pet will also cast [[talent:126408]].
- [[talent:126439]]
  
  - Alot of talents weave in to this, buffing the beast to be powerful. [[talent:132188@FAgA8PvA8h4A]] is a must take node because of this.
- [[talent:126402@FAQA8h4A]]
  
  - Combined with [[talent:132188@FAgA8PvA8h4A]] and [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]] is our only major damage cooldown.

#### Class Tree

- [[talent:126470]]
  
  - A large survivability increase since you gain an extra charge of [[talent:126488]]. This together with [[spell:388039]] will make up for a big majority of your Defensive capabilities.
- [[spell:53480]]
  
  - Give you and external defensive cooldown, choice node with [[spell:1272094]] so it comes with the cost of losing 3% passive damage reduction to take this talent.
- [[spell:459517]]
  
  - Grants [[spell:5384]] and [[spell:186265]] the ability to dispel Poision and Disease effects from yourself. Situational but can be extremely useful to yourself and your group.
- [[spell:109248]], [[spell:19577]] and [[spell:19801]] depending on the boss you're fighting. Pick wisely depending on what you need in each encounter.

- The following Talents can all have a huge impact if used correctly, but they might not always be useful in all dungeons. Since you can't talent them all at the same time make sure you talent the one *needed*  for specific dungeons. 
  
  - [[spell:19801]]
    
    - [[spell:459983]]
    - [[spell:459991]]
  - [[spell:19577]]
  - [[spell:109248]]
    
    - [[spell:459460]]
    - [[spell:472729]]
  - [[spell:199483]]
  - [[spell:459517]]

### Hero Talents

- [[spell:472476]]
  
  - Outperforms [[spell:472524]] since we are investing in alot of Talents that empower [[spell:120679]].
- [[spell:1264797]]
  
  - Straight up outperforms [[spell:1264792]].
- These both have their value, use what you prefer or might find need for.
  
  - [[spell:472719]]
  - [[spell:1268705]]

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set: [[talent:126440]] causes your pets to [[spell:201754]] one additional time at 50% effectiveness.**
- **4-Set: [[spell:201754]] causes your next  [[spell:193455]] to either benefit from [[spell:115939]] at 20% effectiveness, or strike your primary target for 15% additional damage, stacking up to 4 times**

### Single-Target

:::tabs
:::tab [[[talent:123347]]](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)
### Opener

- The goal of your opener is to simply cast as many [[talent:126408]] as possible. Since Focus management will be an issue you will also weave in some [[talent:126440]].
- Note that before every pull you want to mare sure to use [[spell:257284]] on the priority target/boss and to [[spell:34477]] prefered tank!

:::rotation **Beast Mastery Hunter** Single-Target opener in Mythic+
```json
{
  "source_code": "IcFTHIEcQNAAAcwbuBCc1xGbAIk6ECQABkwFsAwACxFUAAAABwprDEgFAFwXfQQAIEAA9DQOCgVACZHTBUBCAIk6yQDAMAgQqTI"
}
```
1. [[spell:217200]] on pull
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:19574]]
5. [[spell:34026]]
6. [[spell:217200]]
7. [[spell:34026]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] before using [[talent:126402@FAgA8PvA8h4A]].
- Make sure to NEVER cap on [[talent:126408]] and [[talent:126440]], plan around this and make sure to have [[spell:1273126]] for every [[talent:126408]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:19574]].
2. Cast [[talent:126408]] if [[spell:1273126]] is active.
3. Cast [[talent:126440]].
4. Cast [[spell:193455]].

:::

:::

### AoE

:::tabs
:::tab [[[talent:123347]]](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)
### Opener

- Note that most bosses are Single-Target on pull, this is only for scenarios with multiple targets. Make sure to use the Single-Target openers when there is only one enemy.
- The goal of your opener is to simply cast as many [[talent:126408]] as possible. Since Focus management will be an issue you will also weave in some [[talent:126440]].
- Note that before every pull you want to mare sure to use [[spell:257284]] on the priority target/boss and to [[spell:34477]] prefered tank!

:::rotation **Beast Mastery Hunter** AoE opener in Mythic+
```json
{
  "source_code": "JcHiLIEcQNAAAcwbuBCc1xGbAI05KNBAAAwACxFUAAAABwprDAQAIA0XfQQAIEAA9DQOCgVACZHTAEQAIIk6EGwBAAQCDBAAmBBAE968CAAAAAgQnr0EAAAAAIk6EC"
}
```
1. [[spell:217200]] on pull
2. [[spell:1264359]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
3. [[spell:19574]]
4. [[spell:34026]]
5. [[spell:217200]]
6. [[spell:34026]]
7. [[spell:217200]]
8. [[spell:34026]]
9. [[spell:193455]]
10. [[spell:1264359]]
11. [[spell:34026]]
:::

- Use your active trinkets, [[item:241308]], and racials like [[spell:20572]] or [[spell:26297]] before using [[talent:126402]].
- Make sure to NEVER cap on [[talent:126408]] and [[talent:126440]], plan around this and make sure to have [[spell:1273126]] for every [[talent:126408]].

### Priority List

1. Cast [[spell:19574]].
2. Cast [[spell:1264359]].
3. Cast [[talent:126408]] if [[spell:1273126]] is active.
4. Cast [[talent:126440]].
5. Cast [[spell:193455]].

:::

:::

## Deep dive

### Maximizing your damage output during Bestial Wrath .

- Ensure you are going into [[spell:19574]] with at least 1 charge of [[talent:126408]], but having 2 is best.
- Try to use all [[talent:126440]] before casting [[spell:19574]].
- Make sure you don't focus starve yourself by weaving in [[talent:126440]] during this window and not letting it over-cap on charges.
- Make sure to have enough focus to always be able to cast [[spell:1264359]] on cooldown and to not cap out on [[talent:126408]] charges, don't cast too many [[spell:193455]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Beast Mastery Hunter** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

#### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

#### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

#### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, susch as [[spell:781]].

:::

:::tab Den of Nalorakk
:::talents **Beast Mastery Hunter** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

#### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

#### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[spell:781]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Beast Mastery Hunter** Mythic+ Build in Murder Row
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmxMMzMmxMYMNDAAAAAAAAmHYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmxMMzMmxMYMNDAAAAAAAAmHYMzwMzMbEGmFw2AwA"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

#### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

#### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

#### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Beast Mastery Hunter** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

#### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots with [[spell:781]].
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

#### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

#### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.
      
      - Can be removed with [[talent:126452]]

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents **Beast Mastery Hunter** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

#### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

#### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

#### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents **Beast Mastery Hunter** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

#### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

#### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

#### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents **Beast Mastery Hunter** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmxMMzMmxMsMmmBAAAAAAAAjxMDzMzsRYYWAbDADA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmxMMzMmxMsMmmBAAAAAAAAjxMDzMzsRYYWAbDADA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

#### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

#### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Beast Mastery Hunter** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

#### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

#### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

#### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

The Affix system stays the same going into Midnight with the only exception of adding [[spell:1284818]] to the lower keys.

- +2  Affix
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affix -- Alternates between each other on a weekly basis
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Beast Mastery Hunter**.

- Xal'atath's Bargain: Ascendant
  
  - You can use [[spell:147362]] to interrupt one.
- Xal'atath's Bargain: Voidbound
  
  - This affix gives stacking damage reduction to mobs in combat while it lives, so it should be your #1 priority to make sure this dies relatively quickly.
- Xal'atath's Bargain: Devour
  
  - This is a healing absorb that gets applied to the player. This can be countered by [[spell:109304]].

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Beast Mastery Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Beast Mastery Hunter** Stat Priorities in Mythic+
```json
{
  "source_code": "JoAJFMQMgQCKEIABCA"
}
```
**敏捷 ≫ 精通 ＝ 暴击 ≫ 急速 ＝ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is an awful tertiary for you since most of your damage is coming from your pets.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
In patch 12.1 when you catalyst an item it will keep its stats and cantrip effects which means you can have the perfect stats on your tier set slots. You should keep using the tier pieces you get from tier tokens until you have enough ‍[[item:274707]] charges to catalyst the items with better stats.

| Slot | Item | Location |
| --- | --- | --- |
| Head | Catalyst [[item:239035@AgQAAIoAOFA]] into [[item:271492@DiQBA0PAnk7cVrjgC4UA7W6A]] | Temple of Sethraliss |
| Neck | [[item:268265@BERAA0PAC06IQrDj1kjAYFA]] | Ula'tek |
| Shoulder | Catalyst [[item:268231@AgQAAIoAYFA]] into [[item:271490@DgQBA0PAXk7IoAYFwxXQ]] | Coiled Altar |
| Cloak | [[item:268253@BgQAA0PACKAWBA]] | Coiled Altar |
| Chest | Catalyst [[item:271876@AgQAAIoAYFA]] into [[item:271495@DARBA0PAJk7wYN5IAWBQgJE]] | Ula'tek |
| Wrist | [[item:244584@FCSAA0PAeA8ciqjAtOAAAAAAAA3WzSB]] | Crafted |
| Gloves | Catalyst [[item:160213@AgQAAIoAOFA]] into [[item:271493@BgQBA0PACKgTBUdcCA]] | Kings' Rest |
| Belt | [[item:244581@FCSAA0PAeA8ciqjAtOAAAAAAAA3WzSB]] | Crafted |
| Legs | [[item:271491@DgQAA0PAhu7IoAOF]] | Sszorak |
| Boots | [[item:268233@DgQAA0PAPk7IoAOF]] | Crafted |
| Ring 1 | [[item:268249@DiQAA0PA1j7IQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAA0PA1j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270175@BgwAA0PACKAWBUAABYzFCA]] | Ula'tek |
| Trinket 2 | [[item:270164@BgQAA0PACKgTBA]] | Lost Explorers |
| Weapon | [[item:268207@DARAA0PA_k7wYN5IAWB]] | Ula'tek |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAA4PACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAA4PACKQQBA]] | Kings' Rest |
| Cloak | [[item:251132@BgQAA4PACKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAA4PACKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAA4PACKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAA4PACKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAA4PACKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAA4PACKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:273796@BgQAA4PACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAA4PACKQQBA]] | Murder Row |
| Weapon | [[item:159637@BgQAA4PACKQQBA]] | Temple of Sethraliss |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAA0PA5IAWBA]]  <br>[[item:270164@BgQAA0PA5IgTBA]] |
| **A-Tier** | [[item:270165@BgQAA8PACKgTBA]]  <br>[[item:273796@BgQAA8PACKgTBA]]  <br>[[item:250228@BgQAA8PACKgTBA]]  <br>[[item:250215@BgQAA8PACKgTBA]]  <br>[[item:159617@BgQAA8PACKgTBA]] |
| **B-Tier** | [[item:246304@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:270173@BgQAA0PA5IgTBA]]  <br>[[item:273797@BgQAA8PACKgTBA]]  <br>[[item:193757@BgQAA8PACKgTBA]] *--* *Make sure to upgrade it after needs*  <br>[[item:270166@BgQAA8PACKgTBA]]  <br>[[item:274493@BgQAA8PACKQQBA]] -- Can't get higher than Hero track |
| C-Tier | [[item:251787@BAQAA8PAUEA]] *-- Fears you after the effect ends, make sure to let your healers know you will need a dispel*  <br>[[item:250225@BgQAA8PACKgTBA]]  <br>[[item:248583@BgQAA8PACKAFBA]] *-- Can't get higher than Hero track*  <br>[[item:251783@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:251792@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:265657@BgQAA8PACKAFBA]] *-- Can't get higher than Hero track*  <br>[[item:246307@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:250214@BgQAA8PACKgTBA]] *-- Need to stand in the light beam to gain maximum value*  <br>[[item:270168@BgQAA8PACKAWBA]] -- Situationally can be good for big on demand damage |
| Junkyard | [[item:250259@BgQAA8PACKgTBA]]  <br>[[item:274496@BgQAA8PACKQQBA]]  <br>[[item:274497@BgQAA8PACKQQBA]]  <br>[[item:158374@BgQAA8PACKgTBA]]  <br>[[item:246306@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:246305@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:241340@BgQAA8PAi8SHBA]]  <br>[[item:251782@BAwAA8PAUEQBAEgNXIA]] *-- Can't get higher than Hero track*  <br>[[item:251785@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:251784@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:251790@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:252957@BgQAA8PACKAFBA]] *-- Can't get higher than Hero track* |

### Embellishments

- [[item:240167]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.
  - Early on in progression it can even in some cases be valuable to craft this on a high value stat piece like head/chest.
- [[spell:1230076]] Can be very valuable for early progression.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:245933]] *-- maximum DPS.*
  
  
  
  - [[item:245926]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:242272]]
  
  
  
  - [[item:255845]]
- **Weapon Oil**
  
  - [[item:243734]] *-- default*
  
  
  
  - [[item:243738]]
- **Combat Potion**
  
  - [[item:241308]] *-- default*
  
  
  
  - [[item:241288]] -- situational, sim it if you think it's close
- Health Potion
  
  - [[item:271884]] -- a big burst of healing
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- Unique
  
  
  
  - If you are short of Mastery, stack these.
    
    - [[item:240896]]
  
  
  
  - Else use a combination of these gems.
    
    - [[item:240892]]
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240918]]

### Enchantments

:::columns
:::column
| Head | [[item:275707]]  <br>[[item:244007@DAAAA0PAZbAB]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAA0P]] |
| Chest | [[item:243977@BAAAA0P]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:244641@BAAAA0P]] |
| Boots | [[item:243953@BAAAA0P]] |
| Ring 1 | [[item:243957@BAAAA0P]] |
| Ring 2 | [[item:243957@BAAAA0P]] |
| Weapon | [[item:243973@BAAAA0P]] |

:::

:::column
:::gear **Beast Mastery Hunter** Enchantments in Raids
```json
{
  "source_code": "IQFZ9DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NABK1j7AAAAAAEQB5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy  [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Beast Mastery Hunter** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:33702]] -- Orc
  
  - Strong racial for damage both because of [[spell:21563]] and [[spell:33702]].
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:274738]] -- Mag'Har Orc
  
  - Strong damage racial.
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] -- Troll
  
  - Strong DPS racial.
  - Reduce the duration of movement imparing effects by 20%.

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial, which in Hunter's case would be Pandaren and Orc for m+. However **racial** abilities might have such a big impact on your Mythic+ experience that you need to some of them if you're serious about pushing keys with your **Beast Mastery Hunter**. Example **Dwarf** and **Night Elf**.

## Macros

Discover recommended macros for **Beast Mastery Hunters** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[talent:126449]]** -- *Casts [[talent:126449]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Binding Shot
```

**[[talent:126457]]** - *Uses [[talent:126457]] on your cursor position without confirmation.*

```wow-macro
#showtooltip Tar Trap
/cast [@cursor] Tar Trap
```

:::

:::details Mouseover Macros
**[[spell:217200]]** -- *Casts [[talent:126440]] on your mouseover or target.*

```wow-macro
#showtooltip
/cast [@mouseover] Barbed Shot
```

**[[spell:19801]]t] -- *Casts [[spell:19801]] on your mouseover target.***

```wow-macro
#showtooltip
/cast [@mouseover] Tranquilizing Shot
```

**[[talent:126471]]** -- *Casts [[talent:126471]]* *on your mouseover target*.

```wow-macro
#showtooltip
/cast [@mouseover] Concussive Shot
```

:::

:::details Pet Macros
> We're mainly using custom macros for Pets because pets don't cast their own abilities reliably enough and doing it yourself is a DPS gain.

**[[talent:126408]]** **pet attack** -- *Casts [[talent:126408]] and your pets basic attack at your target.*

```wow-macro
#showtooltip Kill Command
/petattack
/cast Kill Command
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[talent:126425]]** **pet attack** -- *Casts [[talent:126425]]* *and your pets basic attack at your target.*

```wow-macro
#showtooltip Wild Thrash
/petattack
/cast Wild Thrash
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[talent:126440]]** **pet attack** *-- Casts [[talent:126440]]* *and your pets basic attack at your target.*

```wow-macro
#showtooltip Barbed Shot
/petattack
/cast Barbed Shot
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[spell:193455]]** **pet attack** -- *Casts [[spell:193455]]* *and your pets basic attack at your target.*

```wow-macro
#showtooltip Cobra Shot
/cast Cobra Shot
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

:::

:::details Utility Macros
**[[talent:126352]] focus** -- *Casts [[talent:126352]] at your focus target or your current target if your focus target doesn't exist.*

```wow-macro
#showtooltip Counter Shot
/cast [@focus,exists,harm,nodead][] Counter Shot
```

**[[spell:186265]]** cancelaura -- *Casts [[spell:186265]] and allows you to immediately cancel it upon pressing it again.*

```wow-macro
#showtooltip
/cast Aspect of the Turtle
/cancelaura Aspect of the Turtle
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Beast Mastery Hunter**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/maxroll-m-1024x617.png>)

**Beast Mastery Hunter** Interface for Mythic+

:::accordion
:::details Addons
- **Unhalted Unit Frames** -- User Interface replacement
  
  - Adds custom Player,Target and Bossframes with more customization.
- **BetterCooldownManager** -- CooldownManager enhancement
  
  - Adds extra customization to your cooldownmanager while also providing additional information like resources etc.
- **LittleWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **RaidframeSettings** -- Party/Raidframe enhancement
  
  - Adds extra customization to your default party and raidframes.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Hunter
  
  - Hero Talents
    
    - **[[talent:123348]]**
      
      - **Bleak Arrows damage increased by 300%.**
      
      
      
      - **Withering Fire's Black Arrow damage reduced by 40%.**
      - **Fixed an issue where Through The Eyes was not properly increasing Withering Fire's damage.**
  - **Beast Mastery** ***Developers' notes: Beast Mastery Hunters felt a bit weak outside of Bestial Wrath damage windows, so we're increasing their steady-state damage by boosting Kill Command, Cobra Shot, and Barbed Shot. We're increasing the duration of Beast Cleave to 10 seconds, so you should be able to maintain 100% uptime in area damage situations as long as you are using Wild Thrash when it is available.***
    
    - **Heart of the Pack renamed to Razor Sharp and has been redesigned – Increases the damage of your pet's Bite, Claw, and Smack by 100%.**
    - **Piercing Fangs has been redesigned – Kill Command critical damage increased by 15%.**
    - **Bloody Frenzy has been updated – Now reduces Barbed Shot's periodic rate increase by 33% (was 50%).**
    - **Kill Cleave has been updated – Kill Command now only cleaves 20% of its damage during Beast Cleave (was 40%).**
    - **Auto Shot damage increased by 720%.**
    - **Barbed Shot damage increased by 10%.**
    - **Kill Command damage increased by 20%.**
    - **Cobra Shot damage increased by 25%.**
    - **Beast Cleave now causes your pets to strike nearby enemies for 55% of the damage dealt (was 40%).**
    - **Beast Cleave duration increased to 10 seconds (was 8 seconds) and can no longer be cancelled.**
    - **Serpentine Strikes now increases Cobra Shot’s critical strike damage by 20% (was 50%).**
    - **Cobra Senses now increases Cobra Shot’s damage by 10% (was 35%).**
    - **Dire Beast summons can now be tracked on the Cooldown Manager.**
    - **Wild Instincts has been removed.**
    - **Hero Talents:**
      
      - **[[talent:123348]]**
        
        - **Dark Hound summons can now be tracked on the Cooldown Manager.**
      - **[[talent:123347]]**
        
        - **Hogstrider now increases the damage of your next Cobra Shot by 100% (was 200%).**
        - **Hoof and Blade now increases the bonus Cobra Shot damage from Hogstrider by 25% (was 50%).**

:::

:::details Patch 12.0.1
- Hunter
  
  - Hero Talents
    
    - **[[talent:123348]]**
      
      - Shadow Thrash now deals Shadow damage, but its damage has been reduced by 30%.
      - Blighted Quiver now increases Beast Cleave and Kill Cleave effectiveness by 5% (was 10%).
    - **[[talent:123347]]**
      
      - Boar area damage increased by 200%.
      - Pack Mentality now grants 4 seconds of cooldown reduction to Barbed Shot (was 6 seconds) and increases Kill Command’s damage by 25% (was 50%).
    - Beast Mastery
      
      - All damage dealt by the hunter and their pets reduced by 12%.
      - Apex Talent: Nature’s Ally now increases the damage of Cobra Shot and Barbed Shot by 15% (was 30%).

:::

:::

:::accordion
:::details Patch 12.0
- Hunter
  
  - Hero Talents
    
    - **[[talent:123348]]**
      
      - New Talent: Corpsecaller - When summoning a Dire Beast, you have a 10% chance to instead summon a Dark Hound.
      - New Talent: Wailing Dead - Bestial Wrath summons a Dark Hound. For 15 seconds after casting Beastial Wrath, Bestial Wrath is replaced with Wailing Arrow.  
        Wailing Arrow: Fire an enchanted arrow, dealing Shadow damage to your target and additional Shadow damage to all enemies within 8 yards of your target. Non-Player targets struck by a Wailing Arrow have their spellcasting interrupted and are silenced for 1 second. Grants Deathblow.
      - New Talent: Blighted Quiver - You fire 2 additional Black Arrows during Withering Fire's barrage. Beast Cleave and Kill Cleave damage increased by 10%.
      - New Talent: Pact of the Hollow - Kill Command causes your Dark Hound to Shadow Thrash, dealing moderate Shadow damage to up to 8 nearby enemies.
      - Black Arrow has been updated – Periodic damage increased substantially and is no longer a rolling periodic.
      - Soul Drinker has been updated – Now causes Kill Command and Barbed Shot to have a chance to grant Deathblow. Now causes Aimed Shot and Rapid Fire to have an increased chance to grant Deathblow.
      - Bleak Arrows has been updated – No longer has a chance to grant Deathblow. Now increases auto shot damage by 100%.
      - Banshee's Mark has been updated – Now increases the critical strike damage of Bleak Powder and Black Arrow by 10%.
      - The Bell Tolls has been updated – Now increases pet damage by 6% and Dire Beast damage by 10%.
      - Through the Eyes has been updated – Now causes Black Arrow to deal 20% increased damage to enemies affected by Black Arrow's periodic damage.
      - Withering Fire has been updated – Now activates from Bestial Wrath and no longer periodically grants Deathblow. Duration reduced to 10 seconds.
      - Black Arrow now grants the Black Arrow ability and no longer replaces Kill Shot.
      - The following talents have been removed:
        
        - Phantom Pain
    - **[[talent:123347]]**
      
      - New Talent: Lethal Barbs – Your auto shot/auto attacks grant 2 Focus to you and your pet. Auto shot/auto attack damage increased by 25%.
      - New Talent: Sharpened Fangs – Your Mastery is increased by 3%.
      - New Talent: Hoof and Blade – Hogstrider further increases the damage of Cobra Shot by 10% and it now stacks up to 3 additional times.
      - New Talent: Wyvern's Gaze – The damage bonus from your Wyvern now lasts an additional 2 seconds.
      - New Talent: Sharpened Claws – The damage of your Bear's Rend Flesh is increased by 15%.
      - New Talent: Stampede! – Casting Bestial Wrath grants Howl of the Pack Leader and causes your next Kill Command to rouse the nearby wildlife into a Stampede, charging your target and dealing heavy Physical damage over 7 seconds.
      - New Talent: Masterful Call – The duration of Master's Call is increased by 2 seconds and it increases the movement speed of its target by 20%.
      - Pack Mentality has been updated –  Barbed Shot cooldown reduction reduced to 6 seconds (was 10 seconds).
      - Hogstrider has been updated – Now grants Cobra Shot a 200% damage increase regardless of the number of targets struck by your Boar. Number of targets struck by the Boar now increases the number additional targets struck by Cobra Shot.
      - Ursine Fury has been updated – When your Bear is summoned, it is joined by 2 Dire Beasts.
      - No Mercy has been updated – Your Bleed effects deal 10% increased damage.
      - Shell Cover has been updated – Survival of the Fittest now summons a Turtle to aid you, further increasing its damage reduction effect by 10%.
      - Howl of the Pack Leader has been updated –Boar now charges once per summon (was 3 times). Boar charge primary and secondary target damage increased by 300%.
      - Bear base damage and stat scalings reduced by 40%.
      - Wyvern's Cry no longer gets bonus initial stacks when applied (was granting a starting point of 15 stacks).
      - Wyvern's Cry now stacks to a maximum of 10 (was 25).
      - Wyvern's Cry duration reduced to 12 seconds (was 15 seconds).
      - Better Together has been updated – Now increases pet damage by 2% (was 5%) and increases Barbed Shot damage by 10% (was 20%).
      - Fury of the Wyvern duration extension reduced to 0.5 seconds and extension cap reduced to 5 seconds.
      - The following talents have been removed:
        
        - Envenomed Fangs
        - Horsehair Tether (moved to Class talent tree)
        - Lead from the Front
    - Class
      
      - New Talent: Precision Strikes – Auto attack and auto shot damage increased by 25%.
      - New Talent: Moment of Opportunity – When a trap triggers, gain 30% movement speed for 3 seconds.
      - New Talent: Shell Wall – Damage taken during Aspect of the Turtle is reduced by an additional 20%.
      - New Talent: Cold Feet – When your Freezing Trap breaks, the victim's movement speed is reduced by 70% for 4 seconds.
      - New Talent: Combat Experience – Agility increased by 3%.
      - New Talent: Improved Snaring – Wing Clip slows an additional 25%. Concussive Shot slows an additional 10%.
      - New Talent: Horsehair Tether – When an enemy is stunned by Binding Shot, it is dragged to Binding Shot's center.
      - New Talent: Roar of Sacrifice – Instructs your pet to protect a friendly target, reducing their damage taken by 15%, but 50% of all damage taken by that target is transferred to your pet. Lasts 10 seconds or until your pet's health drops below 25%.
      - New Talent: Guardian's Hide – Your pet protects you at all times, reducing the damage you take by 3%. Your pet receives 100% of the damage it mitigates.
      - Hunter's Mark has been updated – Now increases the target's damage taken by 3% (was 5% above 80% health).
      - Fortitude of the Bear has been updated – Now passive. Reduces all damage taken by 3%.
      - Lone Survivor has been updated – Now increases Survival of the Fittest's duration by 2 seconds (was 4 seconds).
    - Beast Mastery
      
      - New Talent: The Beast Within – Reduces the cooldown of Bestial Wrath by 60 seconds.
      - New Talent: Wild Thrash – Command your pet(s) to thrash all enemies within 10 yards, dealing Physical damage to them. Damage is increased by 300% if Wild Thrash hits 2 or more enemies. Deals reduced damage beyond 8 targets.
      - New Talent: Frenzy – Increases pet attack speed by 20%/40%.
      - New Talent: Jagged Wounds – All bleed damage dealt by you and your pets increased by 10%.
      - New Talent: Heart of the Pack – Summoning a Dire Beast grants 0.5% Haste for 8 seconds.
      - Solitary Companion has returned – Your pet damage is increased by 35% and your pet's size is increased by 10%.
      - Thrill of the Hunt has been redesigned – Barbed Shot critical strike chance increased by 5%/10%. Cobra Shot critical strike chance increased by 15%/30%.
      - Training Expert has been redesigned – Now increases pet damage by 3%/6%.
      - Brutal Companion has been redesigned – Barbed Shot has a 25% chance to cause your pet to use its special attack and deal 50% bonus damage.
      - Thundering Hooves has been redesigned – Stomp damage increased by 30%. Bestial Wrath commands all active pets to Stomp at 200% effectiveness.
      - Serpentine Strikes has been redesigned – Now additionally causes Cobra Shot to refund 10 Focus when it critically strikes.
      - Bloody Frenzy has been redesigned – When you use Bloodshed, your Barbed Shot damage over time happens 100% faster for 12 seconds.
      - Wild Instincts has been redesigned – Whenever your primary pet (and only your primary pet) uses Stomp, you will fire a free Barbed Shot at a target not already affected by Barbed Shot. This Barbed Shot cannot cause another Stomp.
      - Pack Tactics has been redesigned – Barbed Shot now instantly grants 25 Focus. Passive Focus generation increased by 75%.
      - Barbed Shot has been updated – Barbed Shot's bleed is now a rolling periodic. Damage reduced by 20%.
      - Dire Frenzy has been updated – Now increases Dire Beast damage by 10%/20% (was 30%/60%).
      - War Orders has been updated – Now reduces Kill Commands cooldown by 3 seconds.
      - Stomp has been updated – No longer deals a separate damage event to its primary target. Damage increased by 200%.
      - Bloodshed has been updated – Bestial Wrath provokes your pets to tear into your target, causing your target to bleed for heavy damage over 12 seconds.
      - Huntmaster's Call has been updated – Fenryr's Ravenous Leap damage reduced by 50%.
      - Kill Command damage increased by 2%.
      - Kill Cleave's Kill Command damage reduced to 40% (was 80%).
      - Beast Cleave now activates when you use Wild Thrash, rather than from Multi-Shot.
      - Beast Cleave duration increased to 8 seconds (was 6 seconds).
      - Beast Cleave pet melee attack damage reduced to 40% (was 80%).
      - Bestial Wrath initial damage increased substantially and now increases player and pet damage by 20% (was 30%).
      - Bite damage increased by 50%.
      - Claw damage increased by 50%.
      - Smack damage increased by 50%.
      - Scent of Blood is no longer a 2-point talent.
      - Starter Build has been updated.
    - Many talents have changed positions in the talent tree.
    - The following talents have been removed:
      
      - Barbed Wrath
      - Hunter's Prey
      - Multi-Shot
      - Poisoned Barbs
      - Serpentine Rhythm
      - Wild Call

:::

:::

## FAQ

:::accordion
:::details Q: Why is my [[spell:115939]] uptime low?
**A:** Make sure to not overspend your Focus by casting to many [[spell:193455]], it's important to manage your focus so you can use your [[spell:1264359]] on cooldown.

:::

:::

---

### Credits

Written By: **Charmie**

Reviewd by: **Rycn**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-17** Updated for patch 12.0.7.

**2026-04-26** Updated for patch 12.0.5.

**2026-02-22** Updated for patch 12.0.1.

**2026-01-19** Updated for Midnight 12.0

**2025-12-01** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2

**2025-06-16** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-26** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-21** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
