Welcome to the **Guardian Druid** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 5/5 · Excellent

Survivability · 4/5 · Strong

Mobility · 2/5 · Weak



:::

:::

:::column
:::gear **Guardian Druid Mythic+ Best in Slot**
```json
{
  "source_code": "JUoAwDEaAc__AEwAmQggQEAAvj7AX16ACKwF2gVABk-FEAQEBAg_sOg_sOAj1kjAYFQAmSCBCgQBAUTuDIoAOFwVVPQArGgE4EAAJk7ACKgTBEA4XQAgIUQNUIoAYFQAnGgHMUAAhubBPAXwXQQAZt7AGgQAAYBwDciqDEPuDIoALFQAgt7AEWRF44PrDcbNLFQApSCBAgQBAEwV8QP1DEg6XQgAJEAAvk7A-zaADEAGMEw4uJgRVAAFU9BBAgQAFkDBB8VEMABWBEQ3X0AGAhVABc7FEIACBAQP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240894]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245782]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Guardian Druid**, you have access to Wild Guardian, which gives you a chance to summon a guardian spirit that attacks your target whenever you use [[spell:77758]] and [[spell:33917]].

**Rank 2** increases your mastery and [[talent:103191]] damage. **Rank 3** resets the cooldown of your [[spell:77758]] and [[spell:33917]] whenever you get a proc of Wild Guardian. Additionally, you get one use of Wild Guardian after each [[talent:103201]] to activate it on demand.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-guardian-mxr.webp>)

Wild Guardian

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look at **all** changes, check out our **Changes This Patch** section.

- Spec Tree
  
  - New ability [[talent:135336]]
    
    - Applies an 8-second DOT to your target, which gets extended by 1 second every time you cast [[spell:33917]].
    - Replaces [[spell:8921]], which makes pulling multiple packs a lot harder. Therefore, it is not recommended to pick this talent in Mythic+.
  
  
  
  - New passive [[talent:135490]]
    
    - Grants [[spell:33917]] a second charge.
    - Doubles [[talent:103202]] chance to proc [[talent:103190]] when cast at 80 rage or above.
    - This massively boosts rage generation and reduces the amount of filler [[talent:103301]] casts due to having more impactful buttons to press.
  - New passive [[talent:103222]]
    
    - Allows [[talent:103202]] to consume up to 50% more rage and deal up to 100% more damage.
    - Increases the effectiveness of [[talent:103202]] when cast at high rage levels.
    - Together with [[talent:135490]] strongly incentivizes you to only cast [[talent:103202]] when above 80 rage.
  - New ability [[talent:114701]]
    
    - Resets [[spell:77758]] cooldown and allows it to stack 5 additional times for 12 seconds.
    - When it ends, excess [[spell:77758]] stacks immediately deal their damage.
  
  
  
  - [[talent:114700]] 
    
    - Location in the talent tree was adjusted, making it easier to pick it even when playing [[talent:123301]]
  - [[talent:114698]]
    
    - Now stacks up to 4 times, which is a good quality-of-life improvement.
- **Class Tree**
  
  - [[talent:103309@AJwCCA]] is reworked. It is now a 2-minute cooldown, whose effect depends on your current form:
    
    - In human form, it casts an empowered [[talent:103283]] to the target and up to 5 allies around it.
    - In [[spell:768]], it applies an empowered [[spell:274837]] to your target - a heavy-hitting single-target bleed.
    - In [[talent:103286@AJwCCA]], it deals AOE damage to enemies within 40 yards around you over 8 seconds, similar to [[spell:191034]].
- **Removed**
  
  - [[spell:400222]] 
    
    - Without this talent, [[talent:103305]] becomes a purely defensive rage spender that does no damage.
  - [[spell:135288]]
    
    - No free procs of [[talent:103202]] combined with removal of [[spell:400222]] means you now have to spend rage on [[talent:103202]] in order to actively do damage.

## Hero Talents

- The changes to the apex talents together with the new tier set bonus of Season 2 reinforce the gameplay loop of [[talent:123295]], giving even more value to pressing [[spell:77758]] on cooldown. [[talent:123301]] is not far behind, however it requires a more complicated rotation with little to no throughput gain. Therefore, we recommend playing [[talent:123295]] in M+.



### [[talent:123301]]

- [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - When it procs [[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] replaces your [[spell:6807]] for 20 seconds or until used.
- [[talent:117218]]
  
  - The health increase is only active during the [[spell:22842]] buff.
- [[talent:117220]] + [[talent:117216]]
  
  - [[talent:117220]] is applied to all targets hit by [[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] and provides you with 10% damage reduction.
  - With this talent combination, [[talent:117216]] extends this bleed and damage reduction passively by just pressing your normal rotation.
- [[talent:117207]]
  
  - [[spell:441685]] provides health and armor when shifting out of [[spell:5487]], for example to use [[talent:103309@AJwCCA]].
    
    - This buff gets canceled when shifting back into [[spell:5487]].
  
  
  
  - Both [[talent:103298]] and [[talent:103305]] do not vanish when swapping out of [[spell:5487]].
- [[spell:441835@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - The tooltip is misleading, every target hit with the initial damage has a 25% chance to proc [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]. Meaning on bigger pulls, you most likely receive a proc after each ability.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:135980@FJQA-thBLIA]] makes your auto-attacks 30% more likely to proc [[talent:117206@FAQAychA]].
- [[talent:117219@AJwCCA]] makes targets afflicted by [[talent:117220]] take 15% more damage from your other bleed effects, such as [[talent:103277@FAQAKFjB]], [[talent:103300]], and [[spell:77758]].
- [[talent:135979@AJwCCA]] can randomly proc from your single target melee abilities, dealing physical damage and generating 5 rage.




### [[talent:123295]]

- [[spell:424058@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - Makes it important to tank all enemies inside the [[talent:114700]] zone.
- [[talent:117204]]
  
  - This effect is permanently refreshed while enemies are in your [[talent:114700]] zone, which means it lingers after it ends or they walk out for another 6 seconds.
- [[talent:117192]] 
  
  - Since [[spell:8921@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] is more or less up all the time on enemies, this is a nice, convenient passive slow.
- [[talent:117183]] + [[talent:117177]]
  
  - This talent combination enables [[spell:77758]] to contribute cooldown reduction on [[talent:114700]], increasing the usage rate a lot.
- [[talent:117176]]
  
  - The procced [[spell:211545@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] has no internal cooldown and also applies [[talent:117204]] to targets hit.
- [[spell:424113@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - The [[talent:114700]] buff on yourself does not depend on the zone and provides you with both healing and mastery increase, even if you leave the zone on the ground.
  - Other benefits, like the talents mentioned above, only apply when enemies are within the zone.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:135978@AJwCCA]] gives [[spell:77758]] a chance to cast a [[talent:103278]] at your target.
- [[talent:135977@AJwCCA]] makes [[talent:114700]] increase Arcane damage you deal by 10%.
- [[talent:135976@FJQA-thBLIA]]
  
  - Increases damage of [[talent:103191]] by 10%
  - Increases damage of [[talent:114700]] to your primary target by 30%





## Talents



### [[talent:123295]]

:::talents **Guardian Druid** [[talent:123295]] Mythic+
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### When to use this spec

This is the default loadout for any Mythic+ dungeon unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the dungeon. To make your life easier, dungeon-specific talent loadouts are available in the **Dungeons** section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section provides a concise overview of these talents and their applications; for a more detailed look, check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:377811]]
  
  - Grants you another charge of [[spell:22842]] and increases the healing based on your missing health. This is amazing for both cooldown management and bonus healing.
- [[spell:204053]]
  
  - Makes maintaining your [[spell:77758]] stacks also increase your damage done, and grant defensive value.
- [[spell:393414]]
  
  - Grants cooldown reduction for [[spell:102558]] when you spend Rage

##### Class Tree

- [[talent:103309@AJwCCA]]:
  
  - Make sure to swap to [[spell:768]] before using it on single-target fights in order to apply [[spell:274837]].
- [[spell:377847]]
  
  - With a 120-second cooldown, you proc a [[spell:22842]] when falling below 45% HP. What's important to note is that this overwrites any current active [[spell:22842]] can also be overwritten by any newly applied [[spell:22842]]. 
    
    - Keeping track of the cooldown and not overlapping it is very important.
    - [[talent:128586]] reduces the cooldown to 90 seconds




### [[talent:123301]]

:::talents **Guardian Druid** [[talent:123301]] Mythic+
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgFMzAsYGMgNLGgZmZ2gB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgFMzAsYGMgNLGgZmZ2gB"
}
```
:::

#### When to use this spec

This is the [[talent:123301]] version of the Mythic+ Build.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Hero Talents

**Changed** to [[talent:123301]]. For more info, visit the **Hero Talent** section above.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:77758]] has a 20% chance to make your next [[spell:33917]] deal 100% increased damage.
- **4-Set:** [[spell:77758]] calls up 3 thorns, each impaling a target for Nature damage and dealing additional Nature damage to up to 5 nearby enemies, and extends the duration of [[spell:102558]] by 0.5 seconds, up to 5 seconds.



#### [[talent:123301]]

##### Opener

- The Goal of the opener is to cast an [[spell:192081]] as fast as possible to get the active defensive rolling early. Afterwards, consume procs of [[talent:117206]] and keep rage-generating abilities on cooldown.

:::rotation **Guardian Druid** [[talent:123301]] Opener in Mythic+
```json
{
  "source_code": "IgYAIlgQZLCAAAAABIUWKAAAAIkvvEQAPwgQi0xAFgABeCZAQwQABwprJAREggQfECQB2wQUuLAAZYTCWwMACVQvGUkAOAFUBcIYCsdbCIzFCcwZCw4eCkphDQxHEI3ADoTlEoUMGUPDHcPDHEiLTsgA"
}
```
1. [[spell:8921]]  [[spell:2649]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:33917]]  [[spell:192081]]
7. [[spell:77758]]
8. [[spell:33917]]
9. [[spell:441605]]
:::

##### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Use [[talent:114700]] and [[spell:102558]] on cooldown.
2. Make sure to have at least 1 stack of [[spell:192081]] rolling all the time. You might need to go to higher stacks depending on the expected damage intake.
3. Use [[talent:117206]].
4. Use [[talent:103202]] when above 80 Rage to benefit from [[talent:135490]].
5. Keep [[spell:77758]] on cooldown.
6. Keep [[spell:33917]] on cooldown.
7. Use [[spell:8921]] as filler.




#### [[talent:123295]]

##### Opener

- The Goal of the opener is to cast an [[spell:192081]] as fast as possible to get the active defensive rolling early.

:::rotation **Guardian Druid** [[talent:123301]] Opener in Mythic+
```json
{
  "source_code": "IkFSJIU2iAAAAAQACllCAAAAC57LBEwDMIkIdMQBIQgnQGAEMEQAc6aCQEBII0HhAUgNMEl7CAQG2gSfECAAAAAAC53GGA"
}
```
1. [[spell:8921]]  [[spell:2649]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:33917]]  [[spell:192081]]
7. [[spell:77758]]
8. [[spell:33917]]
9. [[spell:400254]]
:::

##### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Use [[talent:114700]] and [[spell:102558]] on cooldown.
2. Make sure to have at least 1 stack of [[spell:192081]] rolling all the time. You might need to go to higher stacks depending on the expected damage intake.
3. Keep [[spell:77758]] on cooldown.
4. Keep [[spell:33917]] on cooldown.
5. Use [[talent:103202]] when above 80 Rage to benefit from [[talent:135490]].
6. Use [[spell:8921]] as filler.





### Defensive Cooldowns

- [[spell:22812]]
  
  - This is your go-to defensive with a short cooldown. Activating it when walking into the boss, trash, or anything that does damage is never a bad idea, and due to the short cooldown, it is the first defensive you press if you need a cooldown.
- [[spell:61336]]
  
  - Your strongest (granting 50% damage reduction) and also the shortest defensive, with a duration of 6 seconds. Choose wisely when to use this defensive, but also don't sit on 2 charges. Having 1 charge ready for an emergency is always nice, but sitting on 2 is a big waste.
- [[spell:22842]] 
  
  - Your big self-healing button. You can either use it proactively or reactively, the only important part is that you want to use its full potential to the best of your ability. Don't use it just because it's ready if you're only taking some damage. The spell has a short cooldown, yes, but if you tend to use it all the time when taking any damage, you might run into the situation of not having any charges after taking a big tank hit. Overall, using this after any tank mechanic or when gathering mobs is the way to go, just because it helps you get your HP up before your other defensives and [[spell:192081]] gets rolling.
- [[spell:192081]] 
  
  - Your active mitigation and your Rage spender. For more details, check out the **Deep Dive**.

### Incarnation: Guardian of Ursoc

- [[spell:102558]] or [[spell:50334]] can have a lot of applications, either as a DPS cooldown or a defensive cooldown. Therefore, you normally use it on cooldown. Holding it is only needed in special cases since it loses you a lot of value. 
  
  1. It is a strong defensive ability and can carry you through a burst of damage.
  2. Holding it causes the CDR from [[spell:393414]] to be wasted even more, so make sure to press the button.
  3. The offensive portion of it should not be underestimated.

## Deep Dive

This Deep Dive explains special mechanics that are important for **Guardian Druid's** survivability**.**

### Optimizing Ironfur

[[spell:192081]] is your Rage spender and active mitigation. It increases your armor based on your Agility for 7 (9 with [[talent:135568]]) seconds when pressed. Important to note is that multiple applications of [[spell:192081]] overlap and stack together while the duration does not increase, get refreshed, or extended.

- 1. [[spell:192081]] is pressed at 0 seconds
- 2. [[spell:192081]] at 3 seconds
- 3. [[spell:192081]] at 5 seconds 
  
  - Now you have 3 Stacks of [[spell:192081]], all 3 with different durations, and they expire at different times as shown on the timeline with the icons below.
- After 12 seconds, you are left without any stacks of [[spell:192081]], even though you pressed it 3x in the first 5 seconds of the fight.
- It is crucial to understand how Guardian Druid's active mitigation works since your armor value and your associated damage reduction changes all the time with the amount of [[spell:192081]] stacks you have active.

Here is a picture showing how [[spell:192081]] works.

:::timeline **Guardian Druid** Raid Ironfur optimization
```json
{
  "source_code": "HYFu2Z3_UAQAEww_eAAAHAQndi4AAoAA_DHAFAADA8Pg_3AAUAABCEl7CAAACEl7CMQBGAQBFYABNAQBZAwBF0AOKAgAR5uAMAgAR5uAUAQA"
}
```
总时长：20 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:192081]] | 上轨 |
| 3 秒 | [[spell:192081]] | 上轨 |
| 5 秒 | [[spell:192081]] | 上轨 |
| 7 秒 | [[spell:192081]] | 下轨 |
| 10 秒 | [[spell:192081]] | 下轨 |
| 12 秒 | [[spell:192081]] | 下轨 |
| 13 秒 | [[spell:192081]] | 上轨 |
| 20 秒 | [[spell:192081]] | 下轨 |
:::

### Ironfur Armor

- [[spell:192081]] armor is reducing your physical damage intake, which in most cases is only melee swings. Bleeds and magical DoTs are not affected by armor.
- There is a hard cap of 85% on physical damage reduction. This would equal to around 7-8 stacks of [[spell:192081]] at a time (around 4 with [[spell:360827]]) which makes it useless to spam [[spell:192081]] after reaching this amount.
- However, due to how armor scaling works, it is more overall defensive value to keep 1 stack of [[spell:192081]] rolling all the time than using 3 stacks instantly and then not having any at all after. The more armor you stack, the less effective each new layer becomes.
- Because you have high physical damage reduction, you struggle a lot more with magical damage, bleeds, and other DoTs. For those, it's important to use [[spell:22842]] correctly.

### Frenzied Regeneration

- [[spell:22842]] is your only self-heal as a Guardian Druid and is very important to stay alive.
- Generally, the cooldown of [[spell:22842]] is relatively low with 36 seconds (reduced by haste), which makes it very tempting to press any time you take damage. This often leads to problems when you take damage later on that is too big for your healer to cover, or you need a fast way to heal up. Keeping an eye on future scenarios is important when using it.
- On top of that, you also need to decide how you use [[spell:22842]] either proactively to stay topped for any mechanic or reactively after the mechanic to top yourself back up to stay stable. Often, this comes down entirely to the amount of damage you take from whatever you're dealing with. Knowing what to do comes with playing the game and knowledge of the situation.
- When playing [[spell:377811]], you have 2 charges of [[spell:22842]], and it's generally really nice to always keep one ready for the emergency and use the other charge more freely so you don't waste the cooldown recovery.
- Noteworthy things with [[spell:22842]]: 
  
  - [[spell:377847]] does not consume a charge of your [[spell:22842]], but it overwrites your current one if you press it right before it procced + If you use [[spell:22842]] and it procs after your proc overwrites the one you pressed before, basically wasting a lot of value.
  - [[spell:102558]] refunds you both charges of [[spell:22842]] and makes it have no cooldown at all for its duration. Keep this in mind since it can be a lifesaver.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons→**



### Altar of Fangs

:::talents **Guardian Druid** Mythic+ Altar of Fangs
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### Rav'i

- There are 3 Carrion Piles spread in the room, make sure to move the boss before he reaches 0% energy towards one of the three Carrion Piles that is not glowing red so he can [[spell:1296216]] in them.
- While [[spell:1296216]] look out for [[spell:1307703]] on the ground and soak them if needed.

##### The Writhing Coil

- The boss will cast [[spell:1298949]] at you, which deals physical damage and knocks you slightly back.
- Interrupt [[spell:1310358]].
- During [[spell:1299053]] run away from the boss as fast and far as possible.

##### Zul'jan

- Whenever the boss casts [[spell:1300872]] make sure to stand in between him and [[spell:1300894]] to soak it.
- Dodge any axes spawned by [[spell:1283832]].
- [[spell:1301350]] is a quick 0.5 second cast which deals physical damage and is the tank buster of the fight.
- When a teammate is targeted by [[spell:1301413]], move into the line between the boss and the targeted player. This reduces the damage your teammate takes.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] - Primal Serpent
  - [[spell:1307567]] - Ula'tek's Chosen

- Pay extra attention to these casts:
  
  - [[spell:1306911]] - Ritual Chieftain
  - [[spell:1294845]] - Rattling Writhe
  - [[spell:1294934]] - Ascendant Serpent




### Den of Nalorakk

:::talents **Guardian Druid** Mythic+ Den of Nalorakk
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Whenever the boss casts [[spell:1234233]] he will summon [[spell:1234740]] on the ground, make sure to help your group soak them.

##### Sentinal of Winter

- After the boss has casted [[spell:1235783]], drag him on top of a summoned add and kick [[spell:1235829]].

##### Nalorakk

- When the boss begins casting [[spell:1243569]], make sure you are standing in the [[spell:1243856]] provided by Zul'jarra. Once the cast finishes, the boss will immediately follow up with [[spell:1297797]], creating a large circle in front of him. As the tank, move into the circle to soak the hit.
- During [[spell:1243002]], run towards any Echo of Nalorakk that tries to reach Zul'jarra to stop it from reaching her by touching it with your character.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1297696]] - Earthwhisper Tender
  - [[spell:1309919]] - Frigid Mauler
  - [[spell:263607]] - Stormbound Mystic
  - [[spell:9532]] - Loa Speaker Nanea

- Pay extra attention to these casts:
  
  - [[spell:1238687]] - Spirit of Hunger




### Murder Row

:::talents **Guardian Druid** Mythic+ Murder Row
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Nibbles will cast a frontal cone [[spell:1253811]] on you, make sure to not aim this on top of your group, by the end of the cast you can also dodge it by running to the side.
- Kystia will occasionally cast multiple [[spell:1264095]] which cast [[spell:1264106]] that you can interrupt or stun to cancel their casts.

##### Zaen Bladesorrow

- The boss will cast [[spell:1222795]] at you, which deals physical damage and leaves a dot at you [[spell:474515]].
- When targeted by [[spell:474545]] try to hide behind barrels in the room.

##### Xathuux the Annihilator

- [[spell:1214781]] is the main tank buster mechanic of this fight, it is a frontal cone which you do not want to aim towards you group, it leaves debuff on you which reduces your healing taken by 80% for 8 sec.
- After [[spell:1214637]] try to tank the boss near his axe.
- During [[spell:1223533]] try to kite him alongside the edge of the room to minimize the spread of [[spell:474231]].

##### Lithiel Cinderfury

- The boss will use [[spell:1220899]] and you will need to kite this infernal for the entire duration of the fight.
- Interrupt [[spell:474375]] whenever possible.
- Grab threat on [[spell:474408]] whenever it is up.
- When the boss summons [[spell:1214675]] wait until it has also finished the cast [[spell:1217345]] before taking the gateway.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216570]] - Felonious Mage
  - [[spell:1201554]] - Seductive Sayaad
  - [[spell:1214922]] - Wrathguard Flayer
  - [[spell:1214980]] - Fel Invoker

- Pay extra attention to these casts:
  
  - [[spell:1216529]] - Bribed Captain




### The Blinding Vale

:::talents **Guardian Druid** Mythic+ The Blinding Vale
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Make sure to keep threat on all three bosses and position them together whenever possible to allow cleave and efficient damage since they all share the same healthpool.
- Meittik will cast [[spell:1234753]] at you, which is the main source of tank damage during the fight.
- Try to interrupt [[spell:1235616]] whenever possible, which is cast by Kezkitt.
- Kezkitt will also cast [[spell:1235564]], which requires you to stand inside one of the three Lightblossoms to soak the damage.

##### Ikuzz the Light Hunter

- Every time the boss casts [[spell:1236746]] make sure you don't get knocked into one of the roots on the ground. If you get knocked away from the group, make your way back quickly, as everyone will be rooted 4 seconds after the mechanic happens. You want to be stacked with the group so you can cleave down the roots as quickly as possible.

##### Lightwarden Ruia

- This boss has 3 different phases, he will always start in the Moonkin phase.
- In this phase you simply just kick [[spell:1239821]] and dodge [[spell:1239830]]'s created by [[spell:1239824]].
- In his next phase, the Bear form, his melee attacks become more dangerous due to [[spell:1272265]]. Also if targeted by [[spell:1240210]] make sure to not move too much so you and your teammates have an easier time dodging.
- The final phase starts at 40%, when the boss enters Haranir Form and channels [[spell:1241067]], casting all his abilities in a rapid flurry.

##### Ziekket

- Each time the boss casts [[spell:1246372]] he will summon adds beneath him, make sure to grab threat on those as quickly as possible.
- After [[spell:1246858]] the boss will have orbs coming towards him, soak these orbs and do not let any of them touch the boss.
- Additionally the boss will also use [[spell:1247685]] as tank buster mechanic this fight inflicting magic damage, knocking you back and leaving a bleed on you that deals physical damage every second for 10 seconds.
- When the adds die, you have to position the boss in a way that he will hit all of them with the [[spell:1246607]] ability that is targeted on you, completely removing that set of adds from the fight when they are getting it, if not getting hit, they will be revived the next time the boss casts [[spell:1246372]], alongside the newly summoned adds.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1301834]] - Radiant Spellsower
  - [[spell:1238294]] - Lightfeather Petalwing

- Pay extra attention to these casts:
  
  - [[spell:1237855]] - Virid Grovekeeper




### Voidscar Arena

:::talents **Guardian Druid** Mythic+ Voidscar Arena
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Whenever the boss casts [[spell:1296889]], make sure that you don't overlap your [[spell:1222098]] with others.
- He will also cast [[spell:1297017]] at you which deals huge magic damage and will knock you back.
- After every [[spell:1300259]] make sure to dodge orbs.

##### Atroxus

- [[spell:1222642]] is the tank buster mechanic of this fight, it deals magic damage and leaves a dot for 10 seconds which makes you suffer more magic damage.
- Each time the boss casts [[spell:1262497]] he will summon a Toxic Creeper which will fixate you, try to kite this Toxic Creeper alongside the boss for maximum amount of cleave.

##### Charonus

- The boss will cast [[spell:1311923]] at you, which is a 5 second long cast, try to not move too much with this so your teammates can dodge it.
- Ocassionally the boss will target one of your group members with [[spell:1222755]]. As the tank, your job is to position yourself between the boss and the targeted player, intercepting the projectiles before they can reach your teammate.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1299938]] - Voidtouched Magi
  - [[spell:1298899]] - Dominated Brawler
  - [[spell:1249621]] - Angry Krolusk
  - [[spell:1233398]] - Kilivore Screamer

- Pay extra attention to these casts:
  
  - [[spell:1300243]] - Devouring Brutalizer




### Kings' Rest

:::talents **Guardian Druid** Mythic+ Kings' Rest
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- The boss will hit you with [[spell:265910]] which deals physical damage.
- After the boss has casted [[spell:265923]] make sure to kite him if needed so adds do not reach him.

##### Mchimba the Embalmer

- Whenever the boss casts his main ability [[spell:267702]], watch out on the tombs as the sides of the room and click the one that is shaking since one of your party members will be inside of it.

##### The Council of Tribes

- Aka'ali the Conqueror will use [[spell:266237]] against use which knocks you back and makes you take 200% increased physical damage taken afterwards for 10 seconds.
- Help soaking [[spell:266939]] on your teammates.
- Interrupt [[spell:267273]] during the fight with Zanazal the Wise.
- After he has [[spell:267060]] try to move him on top of an explosive totem.

##### Dazar, The First King

- This boss can deal a lot of tank damage due to [[spell:268586]] and [[spell:1303267]] so make sure to use your defensive abilities.
- Dodge [[spell:1302945]] whenever possible throughout the encounter.
- While Reban is active, make sure to interrupt [[spell:269369]] whenever you can.
- T'zala will also start casting [[spell:1303488]] at you whenever he is active, adding another layer of tank damage in this fight.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] - Risen Hexer
  - [[spell:270920]] - Queen Wasi
  - [[spell:270901]] - Seneschal M'bara
  - [[spell:270492]] - Phantom Hex Priest

- Pay extra attention to these casts:
  
  - [[spell:1297918]] - King A'akul
  - [[spell:1302028]] - Ghostly Brute
  - [[spell:270514]] - Ghostly Brute
  - [[spell:1309385]] - Shadow of Zul




### Ruby Life Pools

:::talents **Guardian Druid** Mythic+ Ruby Life Pools
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- The boss will cast [[spell:372808]] at you, which is an interruptable cast, so make sure to interrupt it on cooldown and press defensives if you or your teammates cannot interrupt.
- Occasionally the boss will also cast [[spell:396044]], after the cast has finished, move him away from the circles on the ground.
- At 66% and 33% health the boss will cast [[spell:373037]], make sure to grab threat of the spawned adds.

##### Kokia Blazehoof

- This bosses main tank mechanic is [[spell:372858]], which is a 3 second long cast.
- Make sure to tank the boss always next to a Blazebound Firestorm spawned by [[spell:372863]].

##### Kyrakka and Erkhart Stormvein

- With [[spell:381512]] the boss will apply a debuff to you which makes you take increased damage by the next [[spell:381512]] so make sure to communicate with your healer beforehand that he has to dispell you every time you get hit by this mechanic.
- Whenever the dragon Kyrakka has landed move out of [[spell:381525]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:372743]] - Flashfrost Chillweaver
  - [[spell:384197]] - Primalist Cinderweaver
  - [[spell:392576]] - Tempest Channeler

- Pay extra attention to these casts:
  
  - [[spell:372730]] - Primal Juggernaut
  - [[spell:372047]] - Defier Draghar
  - [[spell:392394]] - Flamegullet
  - [[spell:392395]] - Thunderhead




### Temple of Sethraliss

:::talents **Guardian Druid** Mythic+ Temple of Sethraliss
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Whenever Aspix casts [[spell:1310712]] make sure to not stack with your teammates.
- Adderis will focus on of your teammates with [[spell:1288049]], try help soaking this ability to split the damage and reduce the overall impact on the targeted teammate.
- He will also cast [[spell:1288428]] which makes him deal more melee damage for 8 seconds, use your defensive cooldowns if necessary.

##### Merektha

- The boss periodically casts [[spell:1290797]], a tank buster ability, it deals physical damage on hit and leaves a dot that ticks nature damage every second for 7 seconds.
- During [[spell:264206]], make sure to quickly establish threat on all summoned adds.

##### Galvazzt

- The only thing you have to do on this fight is to move the boss after every [[spell:1309525]] cast since it summons a [[spell:1291815]] beneath him.

##### Avatar of Sethraliss

- Make sure to grab threat of the Corrupted Guardians which ocassionally will cast [[spell:1300803]] at you. Additionally, you can also move him on top of the Essence Defiler.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1293307]] - Faithless Subjugator
  - [[spell:9532]] - Imbued Stormcaller
  - [[spell:13729]] - Twisted Hexxer

- Pay extra attention to these casts:
  
  - [[spell:1291468]] - Sandfury Stonefist
  - [[spell:1308546]] - Orb Watcher





### Affixes

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Guardian Druid**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:103316]] as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - The **Void Emissary** follows you; keep it close to cleave and target it whenever it's up.
- Xal'atath's Bargain: Devour
  
  - [[talent:103293]] yourself whenever its applied to yourself.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Dungeons as a **Guardian Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Guardian Druid** Mythic+ Stats
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** - Niche tertiary that can be very useful and has proven so in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
**Avoidance** is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAgGA-z64PrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:251223@DgQAAgGAJk7IoAOF]]   <br>into [[item:271526@DgQBAgGA1k7IoAOFwVVP]] | Catalyst of Voidscar Arena |
| Cloak | [[item:268253@BgQAAgGACKAWBA]] | The Coiled Altar |
| Chest | [[item:271531@DgQAAgGAJk7IoAOF]] | Vashnik Tier Token |
| Wrist | [[item:244576@FiQAAgGAWA8ciqj_sO3WzSB]] | Crafting |
| Gloves | Convert [[item:251124@BgQAAgGACKgTBA]]   <br>into [[item:271529@BgQBAgGACKgTBQP1DA]] | Catalyst of Murder Row |
| Belt | [[item:268256@BiQAAgGA-z6IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@DgQAAgGAhu7IoAYF]]   <br>into [[item:271527@DgQAAgGAhu7IoAOF]] | Catalyst of The Coiled Altar |
| Boots | [[item:244569@HgQAAgGAWA8ciqT84OCKwSB]] | Crafting |
| Ring 1 | [[item:268266@DkQAAgGAvk74Prj_sOCKgTB]] | Nymrissa Wavecaller |
| Ring 2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | Kings' Rest |
| Trinket 1 | [[item:270164@BgQAAgGACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270175@BgQAAgGACKAWBA]] | Ula'tek |
| Weapon | [[item:268215@DgQAAgGA9k7IoAYF]] | Ula'tek |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@BgQAAgGACKQQBA]] | Altar of Fangs |
| Neck | [[item:251173@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Shoulder | Convert [[item:251223@BgQAAgGACKQQBA]] | Voidscar Arena |
| Cloak | [[item:193763@BgQAAgGACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@BgQAAgGACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251135@BgQAAgGACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgQAAgGACKQQBA]] | Murder Row |
| Belt | [[item:159301@BgQAAgGACKQQBA]] | Kings' Rest |
| Legs | [[item:159313@BgQAAgGACKQQBA]] | Kings' Rest |
| Boots | [[item:251153@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Ring 1 | [[item:273792@BgQAAgGACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:159459@BgQAAgGACKQQBA]] | Kings' Rest |
| Trinket 1 | [[item:250228@BgQAAgGACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250215@BgQAAgGACKQQBA]] | Murder Row |
| Weapon | [[item:158370@BgQAAgGACKQQBA]] | Temple of Sethraliss |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons & Raids. Do note that the trinkets recommended above are for optimal damage; if you do not care about your damage and only want to survive, it is recommended to use a trinket like [[item:270160@BgQAAIEACKgTBA]].

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270175@BgQAAgGACKAWBA]] |
| **A-Tier** | [[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270165@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B-Tier** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:270173@BgQAAgGACKAWBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### Embellishments

- 2x [[item:240167]] is your best in slots option.
  
  - Random main stat proc for you and your teammates.
  - Preferably on Wrists and Boots; however, it can be crafted on any armor piece.

A good option for early season or if you don't have access to a 334 or 344 weapon is crafting a 331 weapon[[item:245876]] instead of an offpiece with [[item:240167]]. As soon as you get access to a 334 or 344 weapon, this option loses value compared to 2x [[item:240167]].

- [[item:245876]]
  
  - Passively gives secondary stats depending on the mob type you're fighting.
  - Has to be crafted on a weapon.

#### Remaining Sparks

- Crafted items are 331 item level, and regular items are 334 on max item level; therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear in that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stone/Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAgGAaB]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, use one of each gem colour to enhance your Blasphemite.*
    
    - [[item:240910]]
    - [[item:240914]]
    - [[item:240890]]
    - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAIE]] |
| Belt | [[item:275707@BAAAAIE]] |
| Legs | [[item:244641@BAAAAIE]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244015@BAAAAIE]] |
| Ring 2 | [[item:244015@BAAAAIE]] |
| Weapon | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **Guardian Druid** **Mythic+**
```json
{
  "source_code": "IQFZoBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy [[item:275707@BAAAAIE]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Guardian Druid** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:255654]] *-- Highmountain Tauren*
  
  - [[spell:255654]] can be used to stun a pack, even when on stun DR, since it counts as a knockdown, making it very useful for those cases.
  
  
  
  - Strong passives for survival with [[spell:255659]] and [[spell:255658]]
- [[spell:287712]] -- Kul Tirans
  
  - [[spell:287712]] can be moved to knock enemies out of bad positions.
  
  
  
  - Very good defensive passives with [[spell:291628]] and [[spell:291417]].
- [[spell:20549]] -- Tauren
  
  - [[spell:20549]] can be strong since you don't have any other source to stun enemies. Sadly, it only hits up to 5 targets tho so keep that in mind.
  
  
  
  - On top of that, you also get decent passive effects [[spell:20550]], [[spell:154743]], and [[spell:20551]].
- [[spell:26297]] *-- Troll* 
  
  - Troll is by far the best for burst damage since you can just use [[spell:26297]] during incarnation for the extra haste, if you want to survive this is the worst option compared to the others.

#### Recommendation

- **Highmountain Tauren** and **Kul Tiran** aren't the overall best racials in terms of **DPS,** but their abilities have a decent impact on your Mythic+ experience and survivability as a **Guardian Druid**.
- **Night Elf** is very good for DPS and can be useful in certain skips during any Mythic+ as a **Guardian Druid**, but doesn't offer too much in the way of survivability benefits.

## Macros

Discover recommended macros for **Guardian Druid** for Mythic+ and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:2649]] at your target or your mouseover (very handy to pick up mobs)*

```wow-macro
#showtooltip Growl
/cast [@mouseover,exists,harm][@target,exists,harm] Growl
```

Boss 1 Taunt --- *Casts [[spell:2649]] on Boss1*

```wow-macro
/cast [@boss1] Growl
```

Boss 2 Taunt --- *Casts [[spell:2649]] on Boss2*

```wow-macro
/cast [@boss2] Growl
```

:::

:::details Mouseover Macros
Mouseover Ursol's Vortex/Mass Entanglement *--- Casts [[spell:102793]]* *at your cursor if talented and [[spell:102359]] at your mouseover, if no mouseover is available it instead casts it on your target.*

```wow-macro
/cast [@cursor] Ursol's Vortex
/cast [@mouseover,exists] [] Mass Entanglement
```

Mouseover [[spell:2782]] *--- Cast it on target if no mouseover is available, casts it on yourself if no target is available.*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Remove Corruption
```

Mouseover Regrowth --- *Casts [[spell:16561]] on mouseover or yourself.*

```wow-macro
#showtooltip Regrowth
/cast [@mouseover,exists][] Regrowth
```

Mouseover [[spell:29166]]

```wow-macro
/cast  [@mouseover] Innervate
```

Mouseover Wild Charge *--- Casts [[spell:16979]] on mouseover or target.*

```wow-macro
#showtooltip Wild Charge
/cast [@Mouseover][] Wild Charge
```

Mouseover Soothe *--- Casts [[spell:2908]] on mouseover or target.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Soothe
```

Mouseover Battle Res --- *This makes it so you can use [[spell:20484]]* as mouseover on your frames

```wow-macro
#showtooltip
/cast [@mouseover,help,dead][] Rebirth
```

:::

:::details Focus Macros
Focus Kick --- *Casts [[spell:106839]]* at your focus target

```wow-macro
/cast [@focus] Skull Bash
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Utility Macros
Cancelaura BoP --- *This cancelaura's [[spell:1022]] on you very useful to have when playing with a paladin ever*

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Guardian Druid**, outlining which addons are used and how they are utilized in Mythic+ to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/pala-1-1024x623.png>)

**Guardian Druid** Interface

:::accordion
:::details Addons
- EllesmereUI
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
#### Druid

- Matted Fur absorb increased by 25%.
- Heart of the Wild empowered Wild Growth healing increased by 25%.
- Shred and Cat Form Swipe damage increased by 10%.

- Elune's Chosen
  
  - Boundless Moonlight – Lunar Beam now causes you to Leech 12% of damage dealt to affected enemies (was 10%).

#### Guardian

- Gory Fur has been redesigned – Ironfur has a chance to make your next Maul, Raze, or Ravage free. Maul, Raze, or Ravage have a chance to make your next Ironfur free.
- Apex Talent: Wild Guardian has been redesigned –
  
  - Rank 1: Spending Rage has a 10% chance to awaken a guardian spirit for 8 seconds, which attacks a nearby enemy when you cast Thrash or Mangle.
  - Rank 2: Mangle, Ravage, Raze, and Maul deal 20%/40% additional Nature damage over 12 seconds. Your Mastery is increased by 3%/6%.
  - Rank 3: When a spirit is awakened, the cooldowns of Thrash and Mangle are reset, and they deal 30% increased damage while the spirit is with you. Each time a spirit attacks, you generate 8 additional Rage. After casting Berserk or Incarnation: Guardian of Ursoc, gain 1 charge of Wild Guardian:
    
    - Wild Guardian: Your next cast of Ravage, Raze or Maul is guaranteed to awaken a spirit.
- All damage increased by 8%.
- Brambles absorb increased by 25%.
- After the Wildfire healing increased by 25%.
- Lunar Beam healing increased by 25%.
- Lunation reduces Lunar Beam's cooldown by 20 seconds (was 3 seconds per Arcane ability).
- Ursoc's Fury grants an absorb for 35% of Thrash and Maul damage (was 30%).
- Elune's Favored heals you for 18% of Arcane damage dealt (was 15%).
- Fixed an issue where Dream Guide was incorrectly being consumed by Regrowths cast via Reinvigoration.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I randomly get one-shot?
A: You most likely left [[spell:5487]] by pressing a button that brings you out of form. The most common mistakes are pressing [[spell:339]] and [[spell:8936]] without a [[spell:158497]] proc.

:::

:::

---

### Credits

Written By: Tief

Reviewed by: **Meeres**

---

:::changelog 更新记录
**2026-08-08** Updated for Patch 12.1

**2026-06-21** Updated for Patch 12.0.7

**2026-04-26** Updated for Patch 12.0.5

**2026-02-22** Updated for Patch 12.0.1

**2026-01-18** Updated for Patch 12.0

**2025-12-01** Updated for Patch 11.2.7

**2025-10-06** Updated for Patch 11.2.5

**2025-07-28** Updated for Patch 11.2

**2025-06-18** Updated for Patch 11.1.7

**2025-04-20** Updated for Patch 11.1.5

**2025-02-25** Updated for Patch 11.1

**2024-12-17** Updated for Patch 11.0.7

**2024-10-27** Updated for Patch 11.0.5

**2024-08-17** Updated for Patch 11.0.2

**2024-07-28** Guide Written for patch 11.0.



:::
