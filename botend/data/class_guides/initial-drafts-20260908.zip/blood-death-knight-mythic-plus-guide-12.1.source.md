Welcome to the **Blood Death Knight** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 5/5 · Excellent

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 5/5 · Excellent

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Blood Death Knight** Mythic+ BIS
```json
{
  "source_code": "JsfAAqPA3_PABIHJEIICBAw74Og_sOQOC4UABk-FEAQEBAwVtmgE0wYNYFQAwRCBCgQAAUTuJMCB-eRBPAQCB8AKYFQAjfBBAiQAA4fABBGWBEQckQgAQUAAhu7A5IgF2gVAGYCBBEXLFIDTPk7ACKgTBEgChOAhQEAAVA8AmoaAnRDAAcbNLFQAzRCBAgQAAUwhgMubCIICBAwL5GAIAIYA1ggYZPgOSAABf9RDwwAWBEQVRwAHOFQAog6AEgQEfBwtBoFN1eBBQgQAAUJ_EkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240894]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240894]] |
| 肩部 | [[item:271472]] | [[item:244021]] |
| 胸部 | [[item:268222]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271473]] | [[item:244641]] |
| 脚部 | [[item:273777]] | [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245781]] · [[item:240166]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:159459]] | [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270165]] |  |
| 背部 | [[item:239656]] | [[item:245781]] · [[item:240166]] |
| 主手 | [[item:268213]] | [[spell:326805]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Blood Death Knight** you have access to Dance of Midnight. It gives parrying an attack during [[spell:49028]] a chance to make your next [[spell:79885]] cost no runes and deal additional 150% damage.

**Rank 2** reduces your damage taken and increases damage done for every [[spell:49028]] active. While **Rank 3** gives you a chance to summon a [[spell:49028]] every time you spend a rune for 6 seconds.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-blood-mxr.webp>)

Dance of Midnight

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:1264235]]
    
    - Makes your [[spell:45470]] now hit 2 additional targets.
  - [[spell:108199]]
    
    - The silence is now build into this ability and doesn't cost 1 additional talent point anymore.
  - [[spell:1263743]]
    
    - Gives you increased parry chance during [[spell:49028]] and increases your Runic Power by 10 during its uptime.
  - [[spell:1263781]]
    
    - When [[spell:1263743]] ends, it explodes and does damage to nearby enemies plus it heals you for 15% of its explosion damage done.
  - [[spell:1265790]]
    
    - Your [[spell:79885]] has a chance to reduce the cooldown of your [[spell:50842]] by 0.25 seconds.
  - [[spell:1263824]]
    
    - Is an empowered ability with 3 stages, the longer you empower it the more damage it deals and the more damage taken reduce you gain from it.
- **Class Tree**
  
  - [[spell:1266819]]
    
    - Your [[spell:61999]] costs 30 less Runic Power.
  
  
  
  - [[spell:391571]]
    
    - Is now a 2-point talent which makes it a 30% bonus absorb value if 2 points are put in.
  - [[spell:374265]]
    
    - Also a 2-point talent which can give you up to 4% extra haste.

- **Removed**
  
  - [[spell:219809]] 
    
    - This results in having less major defensive cooldowns against large tank hits.
  
  
  
  - [[spell:194844]]
  
  
  
  - [[spell:377640]]
    
    - Not dealing any passive damage to enemies anymore when losing [[spell:195181]] stacks.
  - [[spell:194679]]
    
    - Not a huge loss since this was a very niche talent and not being played so often.
  - [[spell:221699]]
  - [[spell:343294]]

## Hero Talents

- Going into the start of Midnight Season 2, [[talent:123325]] currently outperformes [[talent:123326]] by a little bit, it is also easier to play so the rest of the guide will assume you're going to be running [[talent:123325]].

:::tabs
:::tab [[talent:123326]]
- [[spell:439843]]
  
  - Pressing this ability inflicts the target with a [[spell:439843]], after either reaching 40 stacks, or the ability simply running out, you gain a stack of [[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].
- [[talent:117631]]
  
  - This allows you to apply an additional [[talent:96192]] to targets below 35% HP.
- [[spell:440031@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] and [[talent:117655]] 
  
  - Transforms [[spell:50842]] to deal Shadowfrost damage and gives [[spell:55078]] a chance to deal extra Shadowfrost damage therefore contributing more stacks to [[talent:117659]].
- [[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] + [[spell:443564@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - With this talent combination, [[talent:117659]] empowers your next 2 [[talent:96303]] casts.
    
    - [[talent:96303]] now costs 1 Rune and summons two scythes dealing damage to all enemies around your target, applying [[spell:55078]] and dealing considerable damage to them.
    - Additionally, they have a 30% chance to apply a new [[talent:117659]] to the target.
  
  
  
  - [[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] does not stack above 2 which means you need to use up all procs before a new [[talent:117659]] explodes.

#### Defensive Choice Nodes

- [[talent:117632]] or ‍[[talent:123420]]
  
  - ‍[[talent:117632]] is not a good enough talent to consider. [[talent:123420]] is incredibly strong as it is a passive damage reduction based on what abilities you use.
- ‍[[talent:117646]] or ‍[[talent:119140]]
  
  - ‍Death's Messenger is the clear choice here as ‍Expelling Shield does not work in PvE content on casts where it matters.

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1265855@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - Casting [[spell:49028]] grants another stack of [[spell:441378@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]].

:::

:::tab [[talent:123325]]
- [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - [[spell:49998]] has a chance to transform your next [[spell:79885]] into [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].
  
  
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] heals you for 1% of your max HP and also grants you 1 stack of [[spell:433925]].
- [[talent:117645]]
  
  - While standing in your [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]], you take 5% less physical damage and the proc chance of [[spell:433895]] is increased to 5%.
- [[talent:117662]]
  
  - Allows [[spell:433925]] to stack up to 2 and increases your ‍ [[spell:49998]] damage by 5% per stack.
- [[spell:434157@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - Consuming [[spell:81141]] procs grants you 12% strength for 12 seconds.
- [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - [[talent:96269]] now grants you [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]] which replaces [[spell:79885]] with [[spell:433895]] for its' duration.
  - [[spell:433925]] effectiveness is also increased by 200% during [[talent:96269]].

#### Defensive Choice Nodes

- [[talent:117892]] or [[talent:117661]]
  
  - Default pick since it's a nice bonus to mobility, [[talent:117661]] can be swapped to if you are the main combat resser.
- [[talent:117891]] or [[talent:117653]]
  
  - [[talent:117891]] increasing the potency of ‍[[talent:96210]] is simply too good to give up as 2% **Leech** sometimes increasing to 4% even for 4 allies is just not good enough.

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1234559]]
  
  - [[spell:37788]] now has a chance to deal huge AoE burst damage, as it can explode randomly during its duration.
- [[spell:1265574]]
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] increases your damage done by your [[talent:96269]].

:::

:::

## Talents

:::tabs
:::tab Mythic+ Build
:::talents **Blood Death Knight** Mythic+ Build
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### When to use this spec

This is the default loadout going into any Mythic+ unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the dungeon. To make your life easier, dungeon-specific talent loadouts are available in the Dungeon section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[spell:458572]]
  
  - Gain 1 charge of  [[spell:195181]] when pulling an enemy.
- [[spell:219786]]
  
  - While above 5 charges of [[spell:195181]] your [[spell:49998]] costs less Runic Power.
- [[spell:317133]]
  
  - Improves all aspects of your [[spell:55233]].
- [[spell:221536]]
  
  - This provides a nice bonus to your Runic Power generation.
- [[spell:273946]]
  
  - [[spell:50842]] gives you stacks to improve your [[spell:49998]]. The more enemies you hit the more beneficial this is.
- [[spell:377637]]
  
  - Reduces the cooldown of your [[spell:49028]].
- [[spell:374737]]
  
  - With this, you now can have a maximum of 12 charges of  [[spell:195181]].
- [[spell:205723]]
  
  - This provides a huge cooldown reduction for your [[spell:55233]].
- [[spell:114556]]
  
  - A Cheat Death every 4 minutes.

#### Class Tree

- [[spell:374277]]
  
  - Very important talent to make your [[spell:49998]] much stronger.
- [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - Enables ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] to cleave more targets and extend your ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] duration. Details in the Deep Dive.
- [[spell:205727]]
  
  - Lowers the cooldown of your [[spell:48707]] and makes it stronger.
- [[spell:194878]]
  
  - With this, you obtain a new buff to upkeep.
- [[spell:273952]]
  
  - [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] now has a huge slow.
- [[spell:391566]]
  
  - This reduces the enemy's attack speed and is more or less your party buff.
- [[spell:356367]]
  
  - This grants you an additional charge of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]][[spell:49576]] and [[spell:48265]] making them easier to use and juggle correctly.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** When you [[spell:49998]], gain a stack of [[spell:1310372]]. When [[spell:1310372]] reaches 10 stacks, your next [[spell:195182]] consumes it granting 10% Strength for 10 sec.
- **4-Set:** When consuming [[spell:1310372]], your next [[spell:195182]] generates 3 additional [[spell:195181]] and deals Shadow damage to your target and nearby enemies.

### Opener

- The Goal of your opener is to make sure you gain the benefit of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] while also reaching max stacks of [[spell:232049]] with [[spell:49028]]. Additionally you want to gain as much runic power as possible to always be ready to [[spell:49998]].

:::rotation **Blood Death Knight** Opener Mythic+
```json
{
  "source_code": "IgFkKIQApCACQJXZtAVdsxGACwt-CAgACgftAEAnuOAAAAAACR4vAEACIIgmGHgDI4m-CEgDMIkTDDQABwgQn7pBBgAACkgHkcunGAAAAAgQONM"
}
```
1. [[spell:43265]] Pre-Pull
2. [[spell:195292]]  [[spell:46584]] · [[item:241308]]
3. [[spell:49028]]
4. [[spell:50842]]
5. [[spell:195182]]
6. [[spell:49998]]
7. [[spell:433895]]
8. [[spell:50842]]
9. [[spell:433895]]
10. [[spell:49998]]
:::

- [[spell:195292]] has a travel time and should be cast while running in for the pull.

### Priority List

This is the standard priority list, follow this unless a Boss or scenario requires you to hold some abilities listed here.

1. Never drop your [[spell:195181]]! Use [[spell:195182]] or [[spell:195292]] to keep it active.
   
   - Maintain 5+ Stacks of [[spell:195181]] to make use of [[spell:219788]], dropping below 5 is ok if [[spell:49028]] is coming up soon.
2. Cast [[spell:46585]] on cooldown for some extra damage.
3. Keep up your [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] buff, check out the Deep Dive section for more info.
4. Cast [[spell:49028]] on cooldown.
5. Spend Runic Power on [[spell:49998]] when you are about to overcap or [[spell:391477]] is about to fade.
6. Cast [[spell:433895]] to gain Runic Power.
7. Cast [[spell:274156]] if talented, on cooldown and always after your [[spell:49028]] has run out.
8. Cast [[spell:50842]] to avoid overcapping on stacks.
9. Cast [[spell:79885]] to consume runes as a filler.

### Defensive Cooldowns

- [[spell:55233]] 
  
  - Most of the time you want to use Vamp Blood as much as possible when you take any form of damage. Holding it is only really required if you need to survive a big hit or are about to have downtime on the Boss, and it can't get full value.
- [[spell:49028]]
  
  - Generally use this on cooldown unless you need the parry for some special situation, more detailed info is in the **Deep Dive** below.
- [[spell:48707]]
  
  - One of the strongest defensives when it comes to magic damage. In general, it can be used when taking magic damage, in a lot of scenarios delaying it and using it to immune mechanics is the best usage this ability can have. Make sure to keep an eye out during the specific sections on what to immune and how to make the most out of [[spell:48707]].
- [[spell:48792]]
  
  - An amazing defensive for general damage reduction, use this as much as possible in a fight without overlapping it with other cooldowns unless it's needed. It can also be held to immune a stun mechanic, but this is rather rare.
- [[spell:49039]]
  
  - Extremely minor defensive that provides you 10% Leech which makes it a good button to press when you just need a little bit of help, in an AoE scenario it becomes more worthwhile since leech is really strong in AoE. Also, if you get feared for some reason, press it!

## Deep Dive

### Death Strike Healing and Absorb

[[spell:49998]] is what makes you a **Blood Death Knight**. This ability is the core of your class! Understanding how it works and how to properly use it is very important for maximizing your damage, staying alive, and being the best tank out there through your incredible self-sustain.

- [[spell:49998]] heals you for a % of your maximum HP and the healing is increased this healing based on your damage taken in the last 5 seconds. This makes Death Strike an ineffective source of healing when you haven’t taken a meaningful amount of damage in the last 5 seconds.
  
  - Environmental and friendly fire damage are not counted in the damage taken formula and are the main cause of self-healing issues. Environmental damage can come from a lot of sources such as Boss room AoE damage, and affix damage like Storming.
- Your healing from [[spell:49998]] is now multiplied by a lot of different abilities and stats:
  
  - Versatility is a multiplier for [[spell:49998]] healing.
  - [[spell:273953]] also increases your [[spell:49998]] healing as well as your [[spell:77513]] value.
  - [[spell:273946]] only multiplies your [[spell:49998]] healing, but does not increase the size of your [[spell:77513]].
- [[spell:77513]] is the other important mechanic of [[spell:49998]]:
  
  - The generated Shield from [[spell:77513]] is based on the full healing value which includes overhealing.
  - The absorb is purely physical and does not work on magic damage at all.
  - The absorb is increased by your Mastery stat value.
  - [[spell:273953]] increases the Healing and value of your Shield, whereas [[spell:273946]] does not.
  - The maximum value that [[spell:77513]] can have is your max HP. This dynamically updates with HP buffs such as [[spell:55233]] and [[spell:97462]] for example.

### Managing Death Strike

Now that you learned how [[spell:49998]] works, let's talk about how to use it to gain the most damage and survivability out of it.

- For damage, you want to use [[spell:49998]] when you are getting close to overcapping your Runic Power or when you can afford to spend all your Runic Power to just do damage to a target.
- If you want to use [[spell:49998]] properly to heal up or counter certain mechanics, it all comes down to a good gameplay flow:
  
  - Take your damage taken in the last 5 seconds into account when [[spell:49998]] is being used. Most of the time you want to [[spell:49998]] after tank mechanics or taking a lot of damage. This benefits you with both a big heal and big absorb shield right after using [[spell:49998]].
  - Most of the time, using 2 [[spell:49998]] back to back is not a good idea since using 1 already tops you and gives you a big absorb. There are scenarios where you would want to use [[spell:49998]] back to back, but they are rarer than just using 1 with precise timing.
  - Timing [[spell:49998]] correctly against magic damage is very important, since your [[spell:77513]] does not help you at all against this type of damage.
  - Stacking up the absorb to be ready for tank mechanics can be quite handy but often comes at a great cost since generating big shields takes a long time if you don't take enough damage to feed into your [[spell:49998]] healing.

With all this info you are ready to fully understand and utilize [[spell:49998]] to the max. Always keep in mind tanking is not set on a rotation or rigid flow of abilities, getting a good gameplay flow going and having proper [[spell:49998]] usage comes with experience and practice.

### Death and Decay Optimization

- Since Midnight Patch 12.0, maintaining high uptime on [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] is not as important for you as it was before, it still buffs both your damage and healing done as a **Blood Death Knight** because of [[spell:391458]] and gives you extra benefits via [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].

- The main idea is to always use [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] whenever it's not active, and you have it off cooldown. [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] grants you a lot of extra duration and quality of life benefits for your [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].
- Here are the advantages provided by [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]:
  
  - You walk out of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] and retain the benefits for 4 seconds.
  - [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] duration runs out and this buff appears afterwards.
  - Walking in and out of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] always refreshes the buff regardless of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] duration.

- Due to [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] giving you another 4 extra seconds of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] the rotation to upkeep this effect is very nice and smooth even without [[spell:356367]].
  
  - The average uptime without [[spell:356367]] is around 93% which is already very good.
  - With [[spell:356367]] you never drop the [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] buff when playing correctly.

- Here is a timeline of how a good [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] usage with [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] looks. Just pressing it off cooldown.

:::timeline **Blood Death Knight** Death and Decay Mythic+
```json
{
  "source_code": "H4FT2Z3_8AQIEww_eAAAOAAD_7xDA0RAHggHAwSAHgSLAsDAEIQApCAAAEgBA8QBGAgHFYAKtAABCRf1EAAAZAQCIAgCNgAKoAgQ0XNBAAwNAEA"
}
```
总时长：60 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:43265]] | 上轨 |
| 10 秒 | [[spell:316916]] | 下轨 |
| 15 秒 | [[spell:43265]] | 上轨 |
| 25 秒 | [[spell:316916]] | 下轨 |
| 30 秒 | [[spell:43265]] | 上轨 |
| 40 秒 | [[spell:316916]] | 下轨 |
| 45 秒 | [[spell:43265]] | 上轨 |
| 55 秒 | [[spell:316916]] | 下轨 |
:::

### Dancing Rune Weapon

[[spell:49028]] is one of the most important spells in the **Blood Death Knight's** arsenal and has a lot of things that are not that obvious at first!

It is essential for both damage and defensive value when playing the class, and these are the key features you should know about the ability.

- The Weapon more or less counts as an untargetable "guardian" and always follows the target you used the ability on. This means when that target dies it follows you and attacks your current target.
- [[spell:49028]] spawns behind the target so it can pull more enemies when used on far away targets.
- Each weapon you summon duplicates certain spells and gives you the benefits, so let's talk about them:
  
  - [[spell:195182]] grants you 9 Stacks of [[spell:195181]] (3 Stacks per weapon).
  - [[spell:195292]] grants you 6 Stacks of [[spell:195181]] (2 Stacks per weapon).
  - [[spell:79885]] grants you 15 Runic Power instead of 5 (each weapon casts [[spell:79885]] generating 5 Runic Power).
  - [[spell:50842]] now applies 3 individual debuffs of [[spell:55078]] (1 Debuff per weapon extra) the health transfer does not increase you still only benefit from your own [[spell:55078]].
    
    - The same goes for [[spell:55078]] applied from [[spell:195292]].
  - [[spell:49998]] does more damage as the ability is copied by the weapon but the heal is not increased.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Bosses →**

:::tabs
:::tab Altar of Fangs
:::talents **Blood Death Knight** Mythic+ Altar of Fangs
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### Boss Tips

#### Rav'i

- There are 3 Carrion Piles spread in the room, make sure to move the boss before he reaches 0% energy towards one of the three Carrion Piles that is not glowing red so he can [[spell:1296216]] in them.
- While [[spell:1296216]] look out for [[spell:1307703]] on the ground and soak them if needed.

#### The Writhing Coil

- The boss will cast [[spell:1298949]] at you, which deals physical damage and knocks you slightly back.
- Interrupt [[spell:1310358]].
- During [[spell:1299053]] run away from the boss as fast and far as possible.

#### Zul'jan

- Whenever the boss casts [[spell:1300872]] make sure to stand in between him and [[spell:1300894]] to soak it.
- Dodge any axes spawned by [[spell:1283832]].
- [[spell:1301350]] is a quick 0.5 second cast which deals physical damage and is the tank buster of the fight.
- When a teammate is targeted by [[spell:1301413]], move into the line between the boss and the targeted player. This reduces the damage your teammate takes.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] - Primal Serpent
  - [[spell:1307567]] - Ula'tek's Chosen

- Pay extra attention to these casts:
  
  - [[spell:1306911]] - Ritual Chieftain
  - [[spell:1294845]] - Rattling Writhe
  - [[spell:1294934]] - Ascendant Serpent

:::

:::tab Den of Nalorakk
:::talents **Blood Death Knight** Mythic+ Den of Nalorakk
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Whenever the boss casts [[spell:1234233]] he will summon [[spell:1234740]] on the ground, make sure to help your group soak them.

#### Sentinal of Winter

- After the boss has casted [[spell:1235783]], drag him on top of a summoned add and kick [[spell:1235829]].

#### Nalorakk

- When the boss begins casting [[spell:1243569]], make sure you are standing in the [[spell:1243856]] provided by Zul'jarra. Once the cast finishes, the boss will immediately follow up with [[spell:1297797]], creating a large circle in front of him. As the tank, move into the circle to soak the hit.
- During [[spell:1243002]], run towards any Echo of Nalorakk that tries to reach Zul'jarra to stop it from reaching her by touching it with your character.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1297696]] - Earthwhisper Tender
  - [[spell:1309919]] - Frigid Mauler
  - [[spell:263607]] - Stormbound Mystic
  - [[spell:9532]] - Loa Speaker Nanea

- Pay extra attention to these casts:
  
  - [[spell:1238687]] - Spirit of Hunger

:::

:::tab Murder Row
:::talents **Blood Death Knight** Mythic+ Murder Row
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- Nibbles will cast a frontal cone [[spell:1253811]] on you, make sure to not aim this on top of your group, by the end of the cast you can also dodge it by running to the side.
- Kystia will occasionally cast multiple [[spell:1264095]] which cast [[spell:1264106]] that you can interrupt or stun to cancel their casts.

#### Zaen Bladesorrow

- The boss will cast [[spell:1222795]] at you, which deals physical damage and leaves a dot at you [[spell:474515]].
- When targeted by [[spell:474545]] try to hide behind barrels in the room.

#### Xathuux the Annihilator

- [[spell:1214781]] is the main tank buster mechanic of this fight, it is a frontal cone which you do not want to aim towards you group, it leaves debuff on you which reduces your healing taken by 80% for 8 sec.
- After [[spell:1214637]] try to tank the boss near his axe.
- During [[spell:1223533]] try to kite him alongside the edge of the room to minimize the spread of [[spell:474231]].

#### Lithiel Cinderfury

- The boss will use [[spell:1220899]] and you will need to kite this infernal for the entire duration of the fight.
- Interrupt [[spell:474375]] whenever possible.
- Grab threat on [[spell:474408]] whenever it is up.
- When the boss summons [[spell:1214675]] wait until it has also finished the cast [[spell:1217345]] before taking the gateway.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216570]] - Felonious Mage
  - [[spell:1201554]] - Seductive Sayaad
  - [[spell:1214922]] - Wrathguard Flayer
  - [[spell:1214980]] - Fel Invoker

- Pay extra attention to these casts:
  
  - [[spell:1216529]] - Bribed Captain

:::

:::tab The Blinding Vale
:::talents **Blood Death Knight** Mythic+ The Blinding Vale
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

#### Lightblossom Trinity

- Make sure to keep threat on all three bosses and position them together whenever possible to allow cleave and efficient damage since they all share the same healthpool.
- Meittik will cast [[spell:1234753]] at you, which is the main source of tank damage during the fight.
- Try to interrupt [[spell:1235616]] whenever possible, which is casted by Kezkitt.
- Kezkitt will also cast [[spell:1235564]], which requires you to stand inside one of the three Lightblossoms to soak the damage.

#### Ikuzz the Light Hunter

- Every time the boss casts [[spell:1236746]] make sure you don't get knocked into one of the roots on the ground. If you get knocked away from the group, make your way back quickly, as everyone will be rooted 4 seconds after the mechanic happens. You want to be stacked with the group so you can cleave down the roots as quickly as possible.

#### Lightwarden Ruia

- This boss has 3 different phases, he will always start in the Moonkin phase.
- In this phase you simply just kick [[spell:1239821]] and dodge [[spell:1239830]]'s created by [[spell:1239824]].
- In his next phase, the Bear form, his melee attacks become more dangerous due to [[spell:1272265]]. Also if targeted by [[spell:1240210]] make sure to not move too much so you and your teammates have an easier time dodging.
- The final phase starts at 40%, when the boss enters Haranir Form and channels [[spell:1241067]], casting all his abilities in a rapid flurry.

#### Ziekket

- Each time the boss casts [[spell:1246372]] he will summon adds beneath him, make sure to grab threat on those as quickly as possible.
- After [[spell:1246858]] the boss will have orbs coming towards him, soak these orbs and do not let any of them touch the boss.
- Additionally the boss will also use [[spell:1247685]] as tank buster mechanic this fight inflicting magic damage, knocking you back and leaving a bleed on you that deals physical damage every second for 10 seconds.
- When the adds die, you have to position the boss in a way that he will hit all of them with the [[spell:1246607]] ability that is targeted on you, completely removing that set of adds from the fight when they are getting it, if not getting hit, they will be revived the next time the boss casts [[spell:1246372]], alongside the newly summoned adds.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1301834]] - Radiant Spellsower
  - [[spell:1238294]] - Lightfeather Petalwing

- Pay extra attention to these casts:
  
  - [[spell:1237855]] - Virid Grovekeeper

:::

:::tab Voidscar Arena
:::talents **Blood Death Knight** Mythic+ Voidscar Arena
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### Boss Tips

#### Taz'Rah

- Whenever the boss casts [[spell:1296889]], make sure that you don't overlap your [[spell:1222098]] with others.
- He will also cast [[spell:1297017]] at you which deals huge magic damage and will knock you back.
- After every [[spell:1300259]] make sure to dodge orbs.

#### Atroxus

- [[spell:1222642]] is the tank buster mechanic of this fight, it deals magic damage and leaves a dot for 10 seconds which makes you suffer more magic damage.
- Each time the boss casts [[spell:1262497]] he will summon a Toxic Creeper which will fixate you, try to kite this Toxic Creeper alongside the boss for maximum amount of cleave.

#### Charonus

- The boss will cast [[spell:1311923]] at you, which is a 5 second long cast, try to not move too much with this so your teammates can dodge it.
- Ocassionally the boss will target one of your group members with [[spell:1222755]]. As the tank, your job is to position yourself between the boss and the targeted player, intercepting the projectiles before they can reach your teammate.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1299938]] - Voidtouched Magi
  - [[spell:1298899]] - Dominated Brawler
  - [[spell:1249621]] - Angry Krolusk
  - [[spell:1233398]] - Kilivore Screamer

- Pay extra attention to these casts:
  
  - [[spell:1300243]] - Devouring Brutalizer

:::

:::tab Kings' Rest
:::talents **Blood Death Knight** Mythic+ Kings' Rest
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### Boss Tips

#### Taz'Rah

- Whenever the boss casts [[spell:1296889]], make sure that you don't overlap your [[spell:1222098]] with others.
- He will also cast [[spell:1297017]] at you which deals huge magic damage and will knock you back.
- After every [[spell:1300259]] make sure to dodge orbs.

#### Atroxus

- [[spell:1222642]] is the tank buster mechanic of this fight, it deals magic damage and leaves a dot for 10 seconds which makes you suffer more magic damage.
- Each time the boss casts [[spell:1262497]] he will summon a Toxic Creeper which will fixate you, try to kite this Toxic Creeper alongside the boss for maximum amount of cleave.

#### Charonus

- The boss will cast [[spell:1311923]] at you, which is a 5 second long cast, try to not move too much with this so your teammates can dodge it.
- Ocassionally the boss will target one of your group members with [[spell:1222755]]. As the tank, your job is to position yourself between the boss and the targeted player, intercepting the projectiles before they can reach your teammate.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1299938]] - Voidtouched Magi
  - [[spell:1298899]] - Dominated Brawler
  - [[spell:1249621]] - Angry Krolusk
  - [[spell:1233398]] - Kilivore Screamer

- Pay extra attention to these casts:
  
  - [[spell:1300243]] - Devouring Brutalizer

:::

:::tab Ruby Life Pools
:::talents **Blood Death Knight** Mythic+ Ruby Life Pools
```json
{
  "source_code": "CqPAc9ixpxn-sbPhxb6yjRDs6wMzyMzwMmxgZbmZmmZzMzMzMmBAAAAGMzMzMjZmZMAYmZmZGAAAzMbjhxMWWasstMMZbYYBwMGAAMzAAGA",
  "code": "CqPAc9ixpxn+sbPhxb6yjRDs6wMzyMzwMmxgZbmZmmZzMzMzMmBAAAAGMzMzMjZmZMAYmZmZGAAAzMbjhxMWWasstMMZbYYBwMGAAMzAAGA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- The boss will cast [[spell:372808]] at you, which is an interruptable cast, so make sure to interrupt it on cooldown and press defensives if you or your teammates cannot interrupt.
- Occasionally the boss will also cast [[spell:396044]], after the cast has finished, move him away from the circles on the ground.
- At 66% and 33% health the boss will cast [[spell:373037]], make sure to grab threat of the spawned adds.

#### Kokia Blazehoof

- This bosses main tank mechanic is [[spell:372858]], which is a 3 second long cast.
- Make sure to tank the boss always next to a Blazebound Firestorm spawned by [[spell:372863]].

#### Kyrakka and Erkhart Stormvein

- With [[spell:381512]] the boss will apply a debuff to you which makes you take increased damage by the next [[spell:381512]] so make sure to communicate with your healer beforehand that he has to dispell you every time you get hit by this mechanic.
- Whenever the dragon Kyrakka has landed move out of [[spell:381525]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:372743]] - Flashfrost Chillweaver
  - [[spell:384197]] - Primalist Cinderweaver
  - [[spell:392576]] - Tempest Channeler

- Pay extra attention to these casts:
  
  - [[spell:372730]] - Primal Juggernaut
  - [[spell:372047]] - Defier Draghar
  - [[spell:392394]] - Flamegullet
  - [[spell:392395]] - Thunderhead

:::

:::tab Temple of Sethraliss
:::talents **Blood Death Knight** Mythic+ Temple of Sethraliss
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyMzwMmxMMbzMz0MLmZmZmxAAAAAGMzMzMjZmZMAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDgB"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Whenever Aspix casts [[spell:1310712]] make sure to not stack with your teammates.
- Adderis will focus on of your teammates with [[spell:1288049]], try help soaking this ability to split the damage and reduce the overall impact on the targeted teammate.
- He will also cast [[spell:1288428]] which makes him deal more melee damage for 8 seconds, use your defensive cooldowns if necessary.

#### Merektha

- The boss periodically casts [[spell:1290797]], a tank buster ability, it deals physical damage on hit and leaves a dot that ticks nature damage every second for 7 seconds.
- During [[spell:264206]], make sure to quickly establish threat on all summoned adds.

#### Galvazzt

- The only thing you have to do on this fight is to move the boss after every [[spell:1309525]] cast since it summons a [[spell:1291815]] beneath him.

#### Avatar of Sethraliss

- Make sure to grab threat of the Corrupted Guardians which ocassionally will cast [[spell:1300803]] at you. Additionally, you can also move him on top of the Essence Defiler.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1293307]] - Faithless Subjugator
  - [[spell:9532]] - Imbued Stormcaller
  - [[spell:13729]] - Twisted Hexxer

- Pay extra attention to these casts:
  
  - [[spell:1291468]] - Sandfury Stonefist
  - [[spell:1308546]] - Orb Watcher

:::

:::

### Affixes

The Affix system got revamped going into The War Within Season 1 retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Blood Death Knight**.

- Xal'atath's Bargain: Ascendant
  
  - [[spell:207167]] as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - The **Void Emissary** follows you, keep it close to the pack and target it whenever it's up.
- Xal'atath's Bargain: Devour
  
  - This is a healing absorb that can be dispelled, you passively deal with it.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Dungeons as a **Blood Death Knight**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Blood Death Knight** Mythic+ Stats
```json
{
  "source_code": "IoAJFQAJoASMBIQACA"
}
```
**力量 ＞ 急速 ＝ 全能 ＞ 暴击 ＝ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
**Avoidance** is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

:::tabs
:::tab Overall BiS
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271474@DiQAAoPAvj74PrTOC4UA]] | The Twin Fangs |
| Neck | [[item:268265@BERAAoPAX164PrTOCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271472@DgQAAoPA1k7kjAOF]] | The Lost Explorer |
| Cloak | [[item:239656@FgQAAoPAVA8Yiqzt1sUA]] | Crafting |
| Chest | [[item:268222@DgQAAoPAJk7kjAYF]] | The Coiled Altar |
| Wrist | [[item:237834@FCRAAoPAVA8Yiqj_sOAAwt1sUA]] | Crafting |
| Gloves | [[item:271475@BgQAAoPA5IgTBA]] | Entombed Sentinels |
| Belt | [[item:268259@BiQAAoPA-z6kjAYF]] | The Coiled Altar |
| Legs | Convert [[item:271878@BARAAoPACKgF2gVA]]  <br>into [[item:271473@DARBAoPAhu7kjAWYDWBYgJE]] | Catalyst of Ula'tek |
| Boots | [[item:273777@DgQAAoPAPk7IoAOF]] | Altar of Fangs |
| Ring 1 | [[item:159459@DiQAAoPAvk74PrjgC4UA]] | Kings' Rest |
| Ring 2 | [[item:252258@DiQAAoPAvk74PrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270175@BgQAAoPA5IAWBA]] | Ula'tek |
| Trinket 2 | [[item:270165@BgQAAoPA5IgTBA]] | Entombed Sentinals |
| Weapon | [[item:268213@RgQAAoPAVyPB5IAWBA]] | The Coiled Altar |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239050@BgQAAoPACKQQBA]] | Kings' Rest |
| Neck | [[item:251173@BgQAAoPACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:239037@BgQAAoPACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAoPACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251193@BgQAAoPACKQQBA]] | The Blinding Vale |
| Wrist | [[item:159425@BgQAAoPACKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:251221@BgQAAoPACKQQBA]] | Voidscar Arena |
| Belt | [[item:159418@BgQAAoPACKQQBA]] | Kings' Rest |
| Legs | [[item:159435@BgQAAoPACKQQBA]] | Temple of Sethraliss |
| Boots | [[item:273777@BgQAAoPACKQQBA]] | Altar of Fangs |
| Ring 1 | [[item:159459@BgQAAoPACKQQBA]] | Kings' Rest |
| Ring 2 | [[item:251148@BgQAAoPACKQQBA]] | Den of Nalorakk |
| Trinket 1 | [[item:250244@BgQAAoPACKQQBA]] | Den of Nalorakk |
| Trinket 2 | [[item:250228@BgQAAoPACKQQBA]] | Murder Row |
| Weapon | [[item:251181@BgQAAoPACKQQBA]] | The Blinding Vale |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids and Delves. Do note that some trinkets are better than others depending on the mythic+ dungeon. In addition trinkets that are meant for DPS specialisations are nerfed by 33% but still provide better damage than tank specific trinkets.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAAoPA5IAWBA]]  <br>[[item:270165@BgQAAoPA5IgTBA]] |
| **A-Tier** | [[item:270160@BgQAAoPACKgTBA]]  <br>[[item:270164@BgQAAoPACKgTBA]]  <br>[[item:270173@BgQAAoPACKAWBA]]  <br>[[item:270174@BgQAAoPACKgTBA]] |
| **B-Tier** | [[item:270163@BgQAAoPACKgTBA]]  <br>[[item:273795@BgQAAoPACKgTBA]]  <br>[[item:250243@BgQAAoPACKgTBA]]  <br>[[item:250244@BgQAAoPACKgTBA]]  <br>[[item:250228@BgQAAoPACKgTBA]]  <br>[[item:193762@BgQAAoPACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAoPACKgTBA]]  <br>[[item:159618@BgQAAoPACKgTBA]]  <br>[[item:250229@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:193757@BgQAAoPACKgTBA]]  <br>[[item:273797@BgQAAoPACKgTBA]] |
| **Junkyard** | [[item:250238@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:158367@BgQAAoPACKgTBA]]  <br>[[item:270168@BgQAAoPACKAWBA]] |

### Embellishments

- 2x [[item:240166@BAAAAoP]] on either cloak, wrists, belt or boots.
  
  - Nice passive primary stat buff.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324@BAAAAoP]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884@BAAAAoP]]
- **Weapon Stones**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *-- Unique, can only be used once.*
  - [[item:240894@BAAAAoP]]
  - [[item:240916@BAAAAoP]]

### Enchantments

:::columns
:::column
| Head | [[item:243949@DAAAAwQAZbAB]]  <br>[[item:275707@BAAAAoP]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAoP]] |
| Belt | [[item:275707@BAAAAoP]] |
| Legs | [[item:244641@BAAAAwQA]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244017@BAAAAwQA]] |
| Ring 2 | [[item:244017@BAAAAwQA]] |
| Weapon | [[spell:326801]] |

:::

:::column
:::gear **Blood Death Knight** Mythic+
```json
{
  "source_code": "IQFZ6DQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAx0AEoETuDAAAAAgQRyPB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244017]] |  |
| 戒指二 | [[item:244017]] |  |
| 主手 | [[spell:326801]] |  |
:::

:::

:::

> *You buy ‍[[item:275707@DAAAAoPAvj7A]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Blood Death Knight** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  - On top of that using Stoneform gives you 10% physical DR which can be used as a small extra 8 second personal when tanking.
  - Use-case examples:
    
    - **Kyrakka and Erkhart Stormvein (Ruby Life Pools) - [[spell:381512]]**
    - **Zaen Bladesorrow (Murder Row) - [[spell:1222795]]**
    - **Ziekket (The Blinding Vale) - [[spell:1247685]]**
- [[spell:58984]] -- Night Elf
  
  - Can be very useful when doing any kind of skip in Mythic+
  - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]]
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
  - Maximum range of 100 yards.

### Recommendation

As a tank picking a racial for damage is a small gain that it's not worth it most of the time. If you care about min-maxing your DPS go with the highest DPS racial.

That being said the recommended race for Mythic+ is either **Night Elf** or **Dwarf** both offer unique features one being more tactical with Night Elf skips and the other being more reliable when it comes to your survivability.

## Macros

Discover recommended macros for **Blood Death Knight** for Mythic+ and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:56222]]* at your target or your mouseover (very handy to pick up mobs)

```wow-macro
#showtooltip Dark Command
/cast [@mouseover,exists,harm][@target,exists,harm] Dark Command
```

Boss 1 Taunt --- *Casts* [[spell:56222]] on Boss1

```wow-macro
/cast [@boss1] Dark Command
```

Boss 2 Taunt --- *Casts* [[spell:56222]] on Boss2

```wow-macro
/cast [@boss2] Dark Command
```

:::

:::details Mouseover Macros
Chains of Ice --- *This macro either casts [[spell:45524]] at your target or your mouseover*

```wow-macro
#showtooltip Chains of Ice
/cast [@mouseover,exists,harm][@target,exists,harm] Chains of Ice
```

Mouseover Grip --- *Casts [[spell:49576]]* at your mouseover target

```wow-macro
/show tooltip
/use [@mouseover] Death Grip
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

Mouseover Battle Res --- *This makes it so you can use [[spell:61999]]* as mouseover on your frames

```wow-macro
#showtooltip Raise Ally
/cast [@mouseover,help,dead][]Raise Ally
```

:::

:::details Focus Macros
Focus Grip --- *Casts [[spell:49576]]* at your focus target

```wow-macro
/show tooltip
/use [@focus] Death Grip
```

Focus Kick --- *Casts [[spell:47528]]* at your focus target

```wow-macro
#showtooltip Mind Freeze
/cast [@focus,harm,nodead][] Mind Freeze
```

Mouseover Focus --- *This macro sets your mouseover as your focus*.

```wow-macro
/focus [@mouseover]
```

:::

:::details Utility Macros
AMZ Macro --- *Casts [[spell:222791]]* at your Cursor position

```wow-macro
/cast [@cursor] Anti-Magic Zone
```

DND Macro --- *Casts [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]* under your character

```wow-macro
/cast [@player] Death and Decay
```

Mass Grip Macro --- *This casts [[spell:108199]]* either at your mouseover or character

```wow-macro
#showtooltip Gorefiend's Grasp
/cast [@mouseover,exists,nodead][@player] Gorefiend's Grasp
```

Control Undead *--- This allows you to recast control undead without targeting your pet.*

```wow-macro
/target pet
/run PetDismiss()
/use Control Undead
/petassist
```

Cancelaura BoP --- *This cancelaura's [[spell:1022]] on you very useful to have when playing with a paladin ever*

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Blood Death Knight**, outlining which addons are used and how they are utilized in Mythic+ to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Death-Knight-M-Interface-1024x606.png>)

**Blood Death Knight** Interface in Mythic+

:::accordion
:::details Addons
- **ElvUI *-- Full User Interface replacement*** 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **LittleWigs *-- Generic Boss Mod*** 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring and a lot of customization options.
- **Details** -- In-depth Damage Meter
  
  - Makes your damage meter look more handsome.
- **MPlusTimer** -- Used to be a Weakaura, now it is an addon to skin your Mythic+ timer
  
  - Makes your Mythic+ timer look more compact and visualises information cleaner.
  - Alternatively, you can also use the addon with almost the exact same name "MythicPlusTimer", it really is just personal preference.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
Death Knight

- Hero Talents
  
  - San'layn
    
    - Blood Beast auto-attack damage increased by 1400%.
    - Blood-Soaked Ground now reduces physical damage taken by 8% (was 5%).
- Blood
  
  - Apex Talent: Dance of Midnight (Rank 2) has been updated – Damage taken for each active Dancing Rune Weapon is reduced by 6% (was 4%).
  - Melee damage increased by 20%.
  - Heart Strike damage increased by 25%.
  - Marrowrend damage increased by 50%.
  - Dancing Rune Weapon now increases Parry by 30% (was 25%).
  - Permafrost grants a shield equal to 50% of damage dealt (was 40%).
  - Voracious grants 15% Leech (was 12%).
  - Relish in Blood healing increased by 25%.
  - Rapid Decomposition increases Blood Plague healing by 85% (was 50%).
  - Sanguinary Burst heals you for 18% of damage dealt (was 15%).
  - Umbilicus Eternus absorbs damage equal to 6 times damage dealt by Blood Plague (was 5).
  - Perseverance of the Ebon Blade now reduces damage taken by 4% when consuming Crimson Scourge. Duration increased to 10 seconds (was 6 seconds).
  - Bloodshot now also reduces damage taken while Blood Shield is active by 4%.
  - Hero Talents
    
    - Deathbringer
      
      - Reaper's Mark damage to the primary target increased by 20%.
      - Exterminate damage to the primary target increased by 20%.
    - San'layn
      
      - Pact of the San'layn now stores 15% of all Shadow damage dealt (was 10%).
      - Vampiric Strike damage increased by 25%.
      - Visceral Strength now grants 10% Strength (was 12%).
      - Frenzied Bloodthirst’s Death Strike and Death Coil damage bonus reduced to 5% per stack (was 6%).
      - Blood is Life now accumulates 15% of the damage dealt from the Blood Beast (was 25%).

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: You didn't use [[spell:49998]] correctly or didn't press enough defensives. Make sure to read the **Deep Dive** for more info!

:::

:::

---

### Credits

Written By: **Skövte**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-11** Updated for Patch 12.1

**2026-06-16** Updated for Patch 12.0.7

**2026-04-21** Updated for Patch 12.0.5

**2026-02-26** Updated for Patch 12.0.1

**2026-01-20** Updated for Midnight 12.0

**2025-12-02** Updated for Patch 11.2.7

**2025-10-07** Updated for Patch 11.2.5

**2025-08-05** Updated for Patch 11.2



:::
