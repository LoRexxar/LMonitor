Welcome to the **Restoration Druid** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 4/5 · Strong

Cooldown Strength · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 3/5 · Average

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Restoration Druid** Raid Best in Slot Gear
```json
{
  "source_code": "JwpAwzUaAc__BEwAmQggQEAAvj7AJ16ACKwF2gVABYQ1DAICBAA_sOggC4UABYKJEIACBAQN5OggC4UABsKJEIACFAwI5OggC4UALfBBBA-FEUBMMgVABcaChA5GqOggCgVABfBBBk1uDQAEBAAGAPwD5OAAAcbNLFQAgt7AECSABQBGno6AE06AAUQAFsBGpSCBAgQBAEgb4QP1DEgYZPggIEAAvk7AUEwoY4UABUTrDQYCQxwL5OgCBwDA3GwUUQ1HEAACBUAOEEwVdwABdfRDYABWBEA9iUQzMUQuDkTAPgVCAPABgEAAzB8AYA8AAAAAAAAA3WzSBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240969]] · [[item:243951]] |
| 项链 | [[item:251142]] | [[item:240892]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:244003]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271527]] | [[item:240155]] |
| 脚部 | [[item:244569]] | [[item:245784]] · [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:252258]] | [[item:240916]] · [[item:244015]] |
| 戒指二 | [[item:240949]] | [[item:240906]] · [[item:245784]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245875]] · [[item:245784]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Restoration Druid**, you have access to Everbloom, which lets your [[spell:33763]] stack up to 3 times and makes its bloom cleave aoe.

**Rank 4** causes your [[spell:33763]] to bloom 3 times when you cast [[spell:18562]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-restodruid-mxr.webp>)

Everbloom

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103106]]
    
    - Changed from an active ability, into a passive that extends all your hots by up to 14 seconds while channeling [[spell:740]].
  - [[talent:103121]]
    
    - Now causes your [[talent:103109]] to apply [[spell:774]] or [[spell:8936]] to 2 additional targets.
  - [[talent:117104]]
    
    - Instead of an active Ability, causes [[spell:18562]] and [[spell:48438]] to spawn a [[talent:117104]].
  - [[talent:103105]]
    
    - Regrowth crits for 260% instead of 200%.
- **Class Tree**
  
  - [[talent:103309@AJwCDA]]
    
    - Now an active ability, that u prefer to press in [[spell:768]] for damage.
- **Removed**
  
  - [[spell:392301]] 
    
    - [[spell:33763]] is back to only one target at all times.

## Hero Talents

- [[talent:123299]] focuses on AoE healing and Cooldown strength, while [[talent:123298]] focuses on Single Target healing and damage done in [[spell:768]].
- In a Raid environment [[talent:123299]] outperforms [[talent:123298]] in any scenario. Therefore this guide focuses solely on the better option.



### [[talent:123299]]

- Every time you summon a [[spell:102693]] you gain all of the following benefits:
  
  - [[talent:117203]]
    
    - 5% healing done increase per active [[spell:102693]].
  
  
  
  - [[spell:428859]]
    
    - [[spell:774]], [[spell:145205]], and [[spell:33763]] healing is increased by 10% per active Grove Guardian.
  
  
  
  - [[talent:117194]]
    
    - Your [[spell:102693]] do damage passively.
  
  
  
  - [[talent:117195]]
    
    - Your next direct heal creates 3 Dream Petals that each heal up to 3 Allies. These direct heals scale with your Mastery.
    - Further enhanced by [[talent:117185]].




### [[talent:123298]]

- [[spell:48438]], [[spell:8936]], and [[spell:81262]] healing has a chance to spawn a [[spell:439530]] on the target, greatly increasing your healing done to that target.
- [[spell:439530]] is enhanced by the following nodes:
  
  - [[talent:117227]]
    
    - 20% increased healing done to targets with [[spell:439530]].
  
  
  
  - [[talent:117234]]
    
    - Increases the duration of [[spell:439530]] by a third of its total duration.
  
  
  
  - [[talent:117232]]
    
    - Small AoE healing is triggered if you cast [[spell:774]] on a targets with [[spell:439530]] or [[spell:439530]] expires.





## Talents



### General Raid Talents

:::talents **Restoration Druid** General Raid Talents
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### When to use this Spec

- This is the default loadout going into any boss unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter.

#### Gameplay Altering Talents

- Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications, but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:114108]]
  
  - Empowers your next [[spell:8936]] or [[spell:774]] after every [[spell:18562]] cast, to be stronger and apply to two extra targets.
- [[talent:128708]]
  
  - Merges your [[talent:103111]] into your [[talent:103100]].
- [[talent:103128]]
  
  - This talent makes your [[spell:8936]] cleave onto all other targets affected by [[spell:8936]].
- [[spell:200383]]
  
  - Your [[spell:18562]] has 2 charges.
- [[spell:207383]]
  
  - This talent greatly improves your mana efficiency by reducing the cost of your [[spell:8936]] by 50% and increasing its critical chance by 50% while you have 5 or more active [[spell:774]].
- [[spell:155675]]
  
  - Grants you the ability to place a second [[spell:774]] on a target.
- [[spell:278515]]
  
  - Applies [[spell:8936]] to all active [[spell:33763]] targets, allowing you to apply multiple [[spell:8936]] HoTs with a single cast. Also the increased hot duration increases the value you get out of your mastery a lot.

##### Class Tree

- [[spell:197524]] 
  
  - Increases the range of all your abilities by 5 yards, providing a powerful tool for remaining in range of your group.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍[[spell:774]] has a 15% chance and ‍[[spell:132158]] has a 100% chance to grant ‍[[spell:1302255]], causing all your heal over time effects to heal for 25% more for 8 seconds. Multiple applications may overlap.
- **4-Set:** ‍[[spell:132158]], ‍[[talent:103108]] and ‍[[talent:103120]] or ‍[[talent:103119]] have a 100% chance to grant ‍[[spell:1302255]], and ‍[[spell:1302255]] duration is increased by 4 seconds.

### Priority List

1. Keep [[spell:33763]] active, refreshing them no earlier than 4.5 seconds left.
2. Keep 2 [[spell:774]] active on your [[spell:33763]] target.
3. Cast [[spell:18562]] on Cooldown, while consuming either [[spell:48438]] or [[spell:8936]].
4. Cast [[spell:48438]] on Cooldown.
5. Cast [[spell:774]] until [[talent:128277]] is active.
6. Cast [[spell:8936]] with any [[spell:16870]] procs you get.
7. Cast [[spell:8936]] on anyone taking damage, prefer targets with hots already present but no [[spell:8936]] hot.
8. Send some [[spell:5176]] if there is any free time to regain Mana.

### Cooldowns

#### Flourish

:::rotation **Restoration Druid** Flourish Ramp
```json
{
  "source_code": "IsGiMI04DCAAAcgUlZmclNHaAIggIBAAAIgBDAwB15GdpxGI1AQDTwC6iAgA0gHAClhJFAQAjwhN9CAAAIE5CEQDAAQAewRB40SMwgHACVgQIBQAC5DBCAAAChuIAAAAAAgAoLC"
}
```
1. [[spell:33763]] Refresh
2. [[spell:18562]]
3. [[spell:774]] until 5
4. [[spell:18562]]
5. [[spell:8936]] 4x
6. [[spell:337433]]
7. [[spell:48438]]
8. [[spell:740]]
9. [[spell:8936]] 8-10x
10. [[spell:18562]]  [[spell:132158]]
11. [[spell:8936]]
12. [[spell:8936]]
:::

- [[spell:197721]] has been baked into [[talent:103108]] there is still a ramp sequence, you just wont be able to use it as often anymore.

## Deep Dive

#### 

#### Soul of the Forest

- The change to [[talent:103121]] makes this the primairy spec defining talent as this is the most impactful tool to either set up for a big ramp by using it on [[spell:774]] and also to do the actual healing by using it on [[spell:8936]]. Knowing how to use every single one of these for an encounter will make the difference between a good and a great Druid.

#### Heart of the Wild

- This is either your tool to do damage or a strong defensive. Use this in [[spell:768]] to do damage, or use it in [[spell:5487]] to gain 30% max hp that stays even when you shapeshift out of form!

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss



### Nek'Zali

:::talents **Restoration Druid** Nek'Zali talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1287322]] at the edge of the room!
- Do not be inbetween the boss and the tank when the boss casts [[spell:1284103]].




### Entombed Sentinels

:::talents **Restoration Druid** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- Dispel players affected with [[spell:1284471]].
- [[spell:1284590]] is neutralized harmlessly upon reaching exactly 4 stacks.




### Lost Explorers

:::talents **Restoration Druid** Lost Explorers talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1286921]].




### Vashnik

:::talents **Restoration Druid** Vashnik talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- External players affected with [[spell:1295224]]. While affected, they are immune to your regular healing.
- Use a personal defensive when affected by [[spell:1294994]].




### Sszorak

:::talents **Restoration Druid** Sszorak talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- External people with [[spell:1286987]].
- Use [[talent:103276]] to counter [[spell:1285419]].




### Twin Fangs

:::talents **Restoration Druid** Twin Fangs talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- Use a personal defensive when affected by [[spell:1290809]].




### Coiled Altar

:::talents **Restoration Druid** Coiled Altar talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.




### Ula'tek

:::talents **Restoration Druid** Ula'tek talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.




### Nymrissa Wavecaller

:::talents **Restoration Druid** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CmGA4vV1lPvoFlyB-BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA",
  "code": "CmGA4vV1lPvoFlyB+BZ6YBsKYbMmZbmZmZmxsNMMzshNmBAAAAAAAAAALDa2YMNzYYMbzMzMDDzAAAAAAAAAbbjNMNzsMAAmtZWa2mZzGzMzgZGgmBAzMzMAMA"
}
```
:::

#### Boss Tips

- Use a personal defensive when many [[spell:1257717]] get popped.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Restoration Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Restoration Druid** Stat Priority in Raid
```json
{
  "source_code": "DoAJFUAJxgCIBEQABA"
}
```
**智力 ＞ 急速 ＞ 精通 ＞ 全能 ＞ 暴击**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- All secondary stats are affected by **diminishing returns**. [Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to learn more!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful Leech is for a Healer: Breakdown of Mythic Vorasius

![](<https://assets-ng.maxroll.gg/wordpress/PmriF2i-1024x509.png>)

**Restoration Druid** healing breakdown from Warcraftlogs

## Gear



### Best in Slot

Due to the way stat weights work for **Restoration Druids**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAkGAvj7kUrjgCchNYFA]] | Ula'tek |
| Neck | [[item:251142@BiQAAkGA8z6IoAOF]] | Murder Row |
| Shoulder | [[item:271526@DgQAAkGA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAkGACKAWBA]] | Coiled Altar |
| Chest | [[item:268235@AgQAAIoAOFA]] (Catalyst to Tier) | Nek'Zali |
| Wrist | [[item:244576@FCSAAkGAYA8ciqDBtOAAAAAAAA3WzSB]] | Crafting |
| Gloves | [[item:251124@AgQAAIoAOFA]] | Murder Row |
| Belt | [[item:268256@BiQAAkGA8z6IoAYF]] | Coiled Altar |
| Legs | [[item:271527@DgQAAkGAbo6IoAYF]] | Coiled Altar |
| Boots | [[item:244569@FARAAkGAYA88QuDAAcbNLFA]] | Crafting |
| Ring 1 | [[item:252258@DiQAAkGAvk7wPrjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:240949@FCRAAkGAYA88SuD_sOAAwt1sUA]] | Crafting |
| Trinket 1 | [[item:270164@BgQAAkGACKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAkGACKgTBA]] | Nymrissa |
| Weapon | [[item:271092@DgQAAkGAFk7kjAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FASAAkGAzB8gBwDAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Raids from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@AgQAAIoABFA]] | Murder Row |
| Neck | [[item:251142@BiQAAkGA8z6IoABF]] | Murder Row |
| Shoulder | [[item:251223@AgQAAIoABFA]] | Voidscar Arena |
| Cloak | [[item:251190@AgQAAIoABFA]] | Blinding Vale |
| Chest | [[item:251159@AgQAAIoABFA]] | Den of Nalorakk |
| Wrist | [[item:251135@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:251124@AgQAAIoABFA]] | Murder Row |
| Belt | [[item:251166@AgQAAIoAUEA]] | Maisara Caverns |
| Legs | [[item:159313@AgQAAIoABFA]] | Pit of Saron |
| Boots | [[item:251153@AgQAAIoABFA]] | Den of Nalorakk |
| Ring 1 | [[item:252258@DiQAAkGAvk7wPrjgCEUA]] | Voidscar Arena |
| Ring 2 | [[item:159459@AgQAAIoABFA]] | King's Rest |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | Blinding Vale |
| Trinket 2 | [[item:273649@AgQAAIoABFA]] | King's Rest |
| Two-Hand Weapon | [[item:159636@AgQAAIoABFA]] | Tempel |
| One-Hand Weapon | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:251191@AgQAAIoABFA]] | Blinding Vale |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A-Tier** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]] |
| **B-Tier** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:240167]]
  
  - Very strong stat stick, that also empowers your allies.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAkGAaB]]
- **Sockets**
  
  - [[item:240892]]
  - [[item:240969]]
    
    - [[item:240900]]
    - [[item:240906]]
    - [[item:240916]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@DAAAAkGAvj7A]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:244003@BAAAAkG]] |
| Wrist | [[item:275707@DAAAAkGAvj7A]] |
| Belt | [[item:275707@DAAAAkGAvj7A]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:244015@BAAAAkG]] |
| Ring 2 | [[item:244015@BAAAAkG]] |
| Weapon | [[item:243973@BAAAAkG]] |

:::

:::column
:::gear **Restoration Druid** Enchantments
```json
{
  "source_code": "IQFZpBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABMSDIgw-0QQBQQwGqmAGA8gOYAAAv0AEo8SuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:244003]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAkG]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Restoration Druid** in Mythic Raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:26297]] -- Troll
  
  - Increases your haste by 10% for 12 sec.

### Recommendation:

While Trolls' [[spell:26297]] theoretically offers the highest output bonus in Raids, it is recommended to pick Tauren for a small survivability bonus. These bonuses are very minor, so you shouldn't worry about them at all.

## Macros

Discover recommended macros for **Restoration Druid** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Restoration Druid** Raid Guide are available as mouseover macros for your convenience!

[[spell:774]]

```wow-macro
/cast [@mouseover, help] Rejuvenation; Rejuvenation
```

[[spell:8936]]

```wow-macro
/cast [@mouseover, help] Regrowth; Regrowth
```

[[spell:18562]]

```wow-macro
/cast [@mouseover, help] Swiftmend; Swiftmend
```

[[spell:33763]]

```wow-macro
/cast [@mouseover, help] Lifebloom; Lifebloom
```

[[spell:48438]]

```wow-macro
/cast [@mouseover, help] Wild Growth; Wild Growth
```

[[spell:102401]]

```wow-macro
/cast [@mouseover, help] Wild Charge; Wild Charge
```

[[spell:102342]]

```wow-macro
/cast [@mouseover, help] Ironbark; Ironbark
```

[[spell:20484]]

```wow-macro
/cast [@mouseover, help] Rebirth; Rebirth
```

:::

:::details Recommended Macros
Guarantees that your [[spell:29166]] is always on yourself, without needing to deal with targeting or mouse-over adjustments.

```wow-macro
/cast [@player] Innervate
```

Cancel your current form to ensure you use the human form one, allowing you to jump to one of your [[spell:102693]].

```wow-macro
#showtooltip Wild Charge
/tar Treant
/cancelaura [mod:ctrl] Travel Form
/cancelaura [mod:ctrl] Cat Form
/cancelaura [mod:ctrl] Bear Form
/cancelaura [mod:ctrl] Moonkin Form
/cast Wild Charge
```

Quicker Way for Emergency healing

```wow-macro
/Cast Nature's swiftness
/cast [@mouseover, help] Regrowth; Regrowth
```

Quicker Way for Combat Ress

```wow-macro
/Cast Nature's swiftness
/cast [@mouseover, help] Rebirth; Rebirth
```

Directly place your [[spell:145205]] without needing to confirm with a click. Good to have incase you dont talent into [[talent:128708]].

```wow-macro
/cast [@cursor] Efflorescence
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Restoration Druid**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/f9BRME4-1024x576.webp>)

**Restoration Druid** Raid

:::accordion
:::details Addons
- EllesmereUI -- Everything
  
  - Addon to upgrade Blizzards very own UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Restoration
  
  - Developers' notes: We're making several quality-of-life adjustments to Restoration Druid in this update with a goal of addressing usability issues with Tranquility, Nature's Swiftness, and Incarnation: Tree of Life. We're also making a few adjustments to Swiftmend to bring back some of its power as a punchy single-target heal. Finally, we'd like to address issues with Abundance by redesigning it with a clear threshold of when you should be using Regrowth.
- New Talent: Overgrowth – Nature's Swiftness causes your next Regrowth to apply Lifebloom, Rejuvenation, and Wild Growth's heal over time effect to an ally.
- New Talent: Flash of Clarity – Omen of Clarity increases Regrowth's healing by 40%. Now available where Cultivation previously was in the talent tree.
- Cultivation is now available below Flash of Clarity in the talent tree.
- Innervate has been redesigned – Now regenerates 25% of the target's maximum mana over 8 seconds, rather than causing spells to be free for 8 seconds.
- Abundance has been redesigned – While you have at least 5 Rejuvenations active, Regrowth's critical strike chance is increased by 50% and its mana cost is reduced by 50%.
- Tranquility has been updated – Now grows protective roots at your feet, absorbing damage equal to 60% of your health and preventing knockbacks.
- Incarnation: Tree of Life has been updated – Now casts Regrowth on up to 3 nearby injured allies when you initially shapeshift.
- Swiftmend has been updated – Healing increased by 40% of the consumed heal over time effect.
- Everbloom (Rank 3) has been updated – Its heal effect now triggers when you press Swiftmend (was Soul of the Forest).
- Verdant Infusion has been updated – No longer extends heal over time effects.
- Germination has been updated – No longer increases Rejuvenation's duration by 2 seconds.
- Ysera's Gift has been updated – If its healing would overheal the Druid, the overhealing amount is instead transferred to a nearby ally.
- Mastery: Harmony healing bonus increased by 15%.
- All spell and ability healing increased by 6%.
- Wild Growth healing increased by 20% and mana cost increased by 15%.
- Verdancy healing increased by 40%.
- Rejuvenation mana cost reduced by 10%.
- Regrowth healing reduced by 20% and mana cost reduced by 10%.
- Lifebloom mana cost reduced by 20%.
- Passing Seasons reduces Nature's Swiftness cooldown by 15 seconds (was 12 seconds).
- Symbiotic Relationship now highlights itself on the action bar while it is not active.
- Germination and Verdancy have swapped positions in the talent tree.
- Nature's Splendor has been removed.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:102342]] as a personal defensive cooldown.

:::

:::details Q: Why do I keep running out of mana?
A: Keep [[spell:33763]] uptime at 100%, and don't waste a single [[spell:113043]] proc.

:::

:::

---

### Credits

Written By: **Rycn**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-07** Guide updated for patch 12.1

**2026-06-19** Guide updated for patch 12.0.7

**2026-04-22** Guide updated for patch 12.0.5

**2026-02-11** Guide updated for patch 12.0.1

**2026-01-09** Guide updated for patch 12.0

**2025-10-07** Guide updated for patch 11.2.5

**2025-07-14** Guide updated for patch 11.2

**2025-06-18** Guide updated for patch 11.1.7

**2025-04-19** Guide updated for patch 11.1.5

**2024-12-17** Guide updated for patch 11.0.7

**2024-10-20** Guide updated for patch 11.0.5

**2024-08-17** Guide Written for patch 11.0.2



:::
