Welcome to the **Balance Druid** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 3/5 · Average

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Balance Druid** Mythic+ Best in Slot
```json
{
  "source_code": "J4rA4aGA3_fABMgJEIIKAAwJ5OwRtOwF2ghNeVjt1IoABk-FEAQKAAAFtOABtOAj1QWNBoBWCKQAmSCBCACAAcRuD4XNBWjNyIoABsaCTQRC5Oge1IYCTwC4XQAgYEAAE06AYYTAPxAWBEwpBYCaEAQBqOQf1IYNYYjgCE8FEEgqkQgAQAAAxj7AFsEIgt7ACiTAAgBwBYHY2-CD2cbNbWit1AwIgBzSBEQqkQAAgAAA7FRekpT1DIIGBAQ94OA_sOAZ1YjMASjTBEQ2XQggJYBBM0aBWwigC4UABQYLEAACBAQBMgBVfQAAQEAABIHEOFQAdfRDaADWBEA9iQgAQEAA9k7ABEKbYFQAJA8AAAUAAY7LjVT0wcbNZJCD2scNAMySBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240967]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240900]] |
| 肩部 | [[item:271526]] | [[item:243991]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240900]] |
| 腿部 | [[item:271527]] | [[item:240133]] |
| 脚部 | [[item:271530]] | [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240900]] · [[item:245784]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:251194]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:273796]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:245769]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Balance**, you have access to Ascendant Eclipses.

Rank 1 makes it so your [[spell:1239669]] grants your next 3 [[spell:78674]] or Starfall 20% increased damage and also makes your next [[spell:5176]] or [[spell:35243]] instant.

Rank 2 grants you some crit scaling on your kit as your spell crits deal an additional 24% of it's damage over 6 seconds.

Rank 3 makes it so when you enter an [[spell:1239669]] you either shoot a single bolt at your target for [[spell:48517]] or several bolts at random targets for [[spell:48518]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-balance-mxr.webp>)

Ascendant Eclipses

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:109858]]
    
    - [[spell:1239669]] has been reworked so instead of entering it via casting [[spell:5176]] or [[spell:35243]], it is instead it's own spell and has 2 charges with a 32 second cooldown. This means that eventually you will run out of [[spell:1239669]] and have to spend some time outside of [[spell:1239669]]. This is the core mechanic of Midnights Balance Druid as we strive to maximize [[spell:1239669]] uptime.
- **Class Tree**
  
  - [[talent:103309@FJQA19PBLA]]
    
    - [[talent:103309@FJQA19PBLA]] has been completely reworked into a 2 minute cooldown with different versions depending on which form you're in.
      
      - [[spell:5487]] grants you 30% increased maximum health for 20 seconds which persists in any form.
      - Human Form casts an empowered [[spell:48438]] that heals your target and 4 most wounded nearby players for around 15% of their maximum health over 8 seconds.
- **Removed**
  
  - [[spell:108238]]
  - [[spell:202347]]

## Hero Talents

- [[talent:123302]] is the main hero talent used in both single and AoE scenarios.



### [[talent:123302]]

[[talent:123302]] focuses gameplay around casting [[spell:194153]] as much as possible and reducing the cooldown of [[talent:109859]] to get as many casts as possible.

#### Core Talents

- [[talent:117205]]
  
  - Works with all versions of your [[spell:202770]] including [[talent:109831]] and [[talent:117176]].
  - Works with all versions of your [[spell:274283]] including [[talent:123860]] and the second [[spell:274283]] from [[talent:109847]].
- [[spell:429523@FJwCYBVA1chALunAXUwA28fByNwACa4A2vPBKFjB0zwB1zwBLA]]
  
  - Makes your [[spell:194153]] hit like a truck single-target and prevents you from entering [[spell:48517]].
  
  
  
  - Great for fights with low movement, but can be rough to get used to on high movement fights. Sadly most hard fights in raids are high movement.
- [[talent:117177]]
  
  - Makes all your spells that deal Astral or Arcane damage reduce the cooldown of your [[talent:109859]] or [[talent:109860]].

#### Passive Talents

- [[talent:117769]]
  
  - [[spell:24858]] and [[spell:5487]] reduces all Arcane damage taken by 6% and all other magic damage taken by 3%.
- [[talent:117204]]
  
  - Enemies damaged by your [[spell:274283]] or [[spell:202770]] take 6% more damage from you for 6 seconds.




### [[talent:123300]]

[[talent:123300]] is heavily reliant on playing around [[talent:109844]] as a minor cooldown.

#### Core Talents

- [[spell:433831@FJwCYBVA1chALunAXUwA28fByNwACa4A2vPBKFjB0zwB1zwBLA]]
  
  - [[spell:205636]] empowers your next 3-4 [[spell:190984]] or [[spell:194153]] to explode around your target for additional nature damage to nearby enemies and your target.
- [[talent:117194]]
  
  - Casting [[talent:109844]] is now a great way for you to apply [[spell:8921]] to enemies quickly.
  - Great for add-waves.
- [[talent:117203]]
  
  - Grants you an 8% damage increase per active Treant.
- [[spell:428937@FJwCYBVA1chALunAXUwA28fByNwACa4A2vPBKFjB0zwB1zwBLA]]
  
  - Reduces the cooldown of [[talent:109844]] by 15 seconds.
- [[talent:117894]]
  
  - Makes holding your cooldowns more forgiving, retaining up to 15 seconds per use.
- [[talent:135972@AJwC]]
  
  - Summons a Dryad that casts [[spell:65797]] and [[spell:78674]] whenever you enter an Eclipse.

#### Passive Talents

- [[spell:429399@FJwCYBVA1chALunAXUwA28fByNwACa4A2vPBKFjB0zwB1zwBLA]]
  
  - Increases your maximum Astral Power by 20.
- [[talent:117186]]
  
  - While affected by your own [[spell:8936]] you take 8% less damage.





## Talents



### [[talent:123302]]

:::talents [[talent:123302]] **Balance Druid** Mythic+ Talents
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:115458]]
  
  - Grants you an additional charge of [[spell:1239669]].
- [[talent:109856@FAQAgCZA]]
  
  - Reduces the cooldown of your [[talent:109849]] and grants it an additional charge.
- [[talent:109857]]
  
  - Gives your [[spell:190984]] and [[spell:194153]] a chance to make your next cast of [[spell:78674]] or [[spell:191034]] free.
- [[talent:109840]]
  
  - Grants you a stacking haste buff whenever you spend Astral Power.
- [[talent:109848]]
  
  - Increases your critical chance with Arcane or Nature spells whenever you enter [[talent:109858]] or [[talent:109849]].

##### Class Tree

- [[talent:103296]]
  
  - Increases healing taken while [[spell:22812]] or [[talent:103298@FAQAIrJB]] is active.
- [[talent:103276]]
  
  - Grants you a leap, charge, or disengage depending on your form.
- [[talent:103312]]
  
  - Applies a big movement speed buff to you and all allies around you for a short duration.
- [[talent:103309@FJQA19PBLA]]
  
  - Grants you an ability depending on your current form. Mostly used in [[spell:5487]] for [[spell:1261872]] that gives you extra maximum health that stays even after changing away from [[spell:5487]].

#### Hero Talents

- [[talent:123304]]
  
  - More useful utility talent than the other one.
- [[talent:117772@FAgA1chAg3oB]]
  
  - Outperforms [[talent:117176]].
- [[talent:117178]]
  
  - Outperforms [[talent:117177@FAQA1chA]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:78674]] damage increased by 20%. [[spell:191034]] also deals a bit of Astral damage instantly to all valid enemies in range when cast.
- **4-Set:** Your damage is increased by 10% while in any [[spell:1239669]]. This bonus wanes to 2% at the midpoint of the [[spell:1239669]], then waxes back to 10% at the

### Single-Target



#### [[talent:123302]]

##### Opener

- Your goal is to put [[spell:1239669]] on cooldown as fast as possible and enter [[talent:109839@FAQAg3oB]] right after it with full amount of Astral Power. Below, you can see an example of how your opener may look using our recommended ‍‍[[talent:123302]] talent build:

:::rotation **Balance Druid** Single-Target opener in Mythic+
```json
{
  "source_code": "JEcA0EhA4QBAHAlclNWYzRHAy0AAQIUa2LAAZwBLCZ_-EAAAAAgQazWAFgAC4FtEFgACSNTAygAAFcDAA0wPEAAAVASBYAHHTBXYtBSduRXasBiZ1xGbgE0c0JXYsBCUvdXZyZEZAQiEYMAAAAQABwprBgATAIEoQGAAAAAACJ1MBAAAEMFch1G"
}
```
1. [[spell:5176]] Precast
2. [[spell:5176]] Precast
3. [[spell:194153]] Precast
4. [[spell:326646]]
5. [[spell:93402]]
6. [[spell:1233272]]
7. [[spell:78674]]
8. [[spell:78674]]
9. [[spell:194153]]
10. [[spell:194153]]
11. [[spell:78674]]
12. [[spell:194153]] Spam until full Astral Power
13. [[spell:326646]]
14. [[spell:93402]]
15. [[spell:202770]]  [[item:241308]]
16. [[spell:102560]]
17. [[spell:78674]] Spam
:::

- You want to spend 3 stacks of [[spell:1263382]] once in your first [[spell:1239669]] and after that build Astral Power for [[talent:109839@FAQAg3oB]].
- This is just an example of an opener, and it can be cut short if needed, meaning that you can enter [[talent:109839@FAQAg3oB]] earlier if needed for specific timings of the fight.
- Keep in mind that due to [[talent:109848]], you want to spend your Astral Power as soon as possible whenever you enter [[talent:109839@FAQAg3oB]] or [[talent:109858]] to benefit from it the most.

##### Priority List

1. Keep up [[spell:326646]] and [[spell:164815]] on your target.
2. Cast [[talent:109859]] on cooldown.
   
   - Your goal is to line it up with [[talent:109858]] or [[talent:109839@FAQAg3oB]] as best as you can.
3. Cast [[talent:109839@FAQAg3oB]] on cooldown.
   
   - Make sure to always enter it with close to the full amount of Astral Energy.
4. Cast [[talent:109858]] on cooldown.
   
   - Make sure to always enter it with close to the full amount of Astral Energy.
5. Cast [[spell:191034]] if you either
   
   - have a [[spell:393942]] proc.
   - outside of [[talent:109839@FAQAg3oB]] and [[talent:109858]], don't have a [[spell:393944]] proc but do have [[spell:450356]] procced.
6. Cast [[spell:78674]] if you either
   
   - have [[talent:109858]] or [[talent:109839@FAQAg3oB]] active.
   - have more than 82 Astral Power and not going to enter [[talent:109858]] or [[talent:109839@FAQAg3oB]] right after.
7. Cast [[spell:194153]].





### Cleave



#### [[talent:123302]]

##### Opener

- Your goal is to put [[spell:1239669]] on cooldown as fast as possible and enter [[talent:109839@FAQAg3oB]] right after it with full amount of Astral Power. Below, you can see an example of how your opener may look using our recommended ‍‍[[talent:123302]] talent build:

:::rotation **Balance Druid** Cleave opener in Mythic+
```json
{
  "source_code": "JEbA08gA4QBAHAlclNWYzRHAy0AAQIUa2LAAZwBLCZ_-EAAAAAgQazWAFgAC4FtEFgAC6ouAFgQBvQAAAYDEAAHHTBXYtBSduRXasBiZ1xGbgE0c0JXYsBCUvdXZyZEVAQiEYMAAAAQABwprBgATAIEoQGAAAAAACpj6CAAAEMFch1G"
}
```
1. [[spell:5176]] Precast
2. [[spell:5176]] Precast
3. [[spell:194153]] Precast
4. [[spell:326646]]
5. [[spell:93402]]
6. [[spell:1233272]]
7. [[spell:191034]]
8. [[spell:194153]]
9. [[spell:191034]]
10. [[spell:194153]] Spam until full Astral Power
11. [[spell:326646]]
12. [[spell:93402]]
13. [[spell:202770]]  [[item:241308]]
14. [[spell:102560]]
15. [[spell:191034]] Spam
:::

- The only difference in Cleave is that now you are spending Astral Power on [[spell:191034]] instead of [[spell:78674]] and have a slightly different opener.

##### Priority List

1. Keep up [[spell:326646]] and [[spell:164815]] on your target.
2. Cast [[talent:109859]] on cooldown.
   
   - Your goal is to line it up with [[talent:109858]] or [[talent:109839@FAQAg3oB]] as best as you can.
3. Cast [[talent:109839@FAQAg3oB]] on cooldown.
   
   - Make sure to always enter it with close to the full amount of Astral Energy.
4. Cast [[talent:109858]] on cooldown.
   
   - Make sure to always enter it with close to the full amount of Astral Energy.
5. Cast [[spell:78674]] if you have [[spell:393944]].
6. Cast [[spell:191034]] if you either
   
   - have [[talent:109858]] or [[talent:109839@FAQAg3oB]] active.
   - have more than 82 Astral Power and not going to enter [[talent:109858]] or [[talent:109839@FAQAg3oB]] right after.
7. Cast [[spell:194153]].





## Deep Dive

### Eclipse Gaps

We play heavily around [[talent:109858]] to maximize it's uptime, but since we have to have gaps between each [[talent:109858]] to not run out of charges we can also maximize those windows.

[[spell:202345]] and [[spell:343647]] reset everytime we press [[talent:109858]], so if those are running and we won't overcap charges on Eclipse it's a gain to delay going into your next Eclipse until both buffs have expired.

Generally you will enter a new [[talent:109858]] every 20 seconds as [[spell:202345]] drops but in rare cases [[spell:343647]] will remain for even longer, but you should always enter an [[talent:109858]] if the spell is not recharging.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Balance Druid** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as shifting into another form.




### Den of Nalorakk

:::talents **Balance Druid** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root by shifting into another form.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Balance Druid** Mythic+ Build in Murder Row
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Balance Druid** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots with a [[talent:115877]].
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Balance Druid** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Balance Druid** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Balance Druid** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Balance Druid** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CaGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD",
  "code": "CaGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDjZWmZxMzYhlZWGjZGLYYAGbbzMYMbjATAAAAWMzMzMYzYGjZAAMzAD"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system stays the same going into **Midnight** with the only exception of adding [[spell:1284818]] to the lower keys.

- +2 Affix 
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Alternates between each other on a weekly basis, is always the opposite of the +7 Affix
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Balance Druid**.

- Xal'atath's Bargain: Ascendant *-- Destroy the orbs with Crowd Control*
  
  - [[spell:132469]]
  
  
  
  - [[spell:99]]
- Xal'atath's Bargain: Voidbound -- Kill the Voidbound add
  
  - Main target this add with [[spell:194153]] and use [[spell:191034]] to cleave.
- Xal'atath's Bargain: Devour *-- Dispel or heal the Healing Absorbs*
  
  - [[spell:2782]]
- Xal'atath's Bargain: Pulsar
  
  - Nothing special you can do with this affix. Just make sure to not run after your own orb but look for orbs from your teammates instead.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Balance Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Balance Druid** Mythic+ Stat Priorities
```json
{
  "source_code": "JoAJFUQMgQCKBEwABA"
}
```
**智力 ＞ 精通 ＞ 暴击 ≥ 急速 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech** - Provides additional healing through damage dealing. The damage of your pets does not heal you thus Leech is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed** - Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DiCAAYGAnk7cUrzF2ghNeVjt1IoA]] | Ula'tek |
| Neck | [[item:268265@BkCAAYGAU06QQrDj1QWNYYjX1IoA]] | Ula'tek |
| Shoulder | [[item:271526@DACAAYGAXk74XNBWjNyIoA]] | Tier / Catalyst |
| Cloak | [[item:268253@BgQAAYGACKAWBA]] | The Coiled Altar |
| Chest | [[item:271531@DACAAYGAJk7oXNCWjNyIoA]] | Tier / Catalyst |
| Wrist | [[item:244576@DiTAAYGAYA8QQrjtvwgN3WzmlYbNAMCYwsUA]] | Crafting |
| Gloves | [[item:271529@BACAAYGA7VTg1YjMCKA]] | Tier / Catalyst |
| Belt | [[item:268256@BiRAAYGAE06ghN2WjgCgVA]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]]  <br>into [[item:271527@DACBAYGAFo60XNCWDG2IoABfBB]] | Catalyst of The Coiled Altar |
| Boots | [[item:271530@DABAAYGAxj7YjMCK]] | Catalyst |
| Ring 1 | [[item:251194@DiRAAYGA1j7wPrDZ1YjMASjTBA]] | The Blinding Vale |
| Ring 2 | [[item:268249@DiRAAYGA1j7wQrDZ1YjMCKgTBA]] | Vashnik the Malignant |
| Trinket 1 | [[item:273796@BgQAAYGACKgTBA]] | Altar of Fangs |
| Trinket 2 | [[item:270164@BARAAYGA2IjgC4UA]] | The Lost Explorers |
| Main-hand | [[item:271092@DARAAYGA9k7ghNCKAWB]] | Ula'tek |
| Off-hand | [[item:245769@BAUAAYGA2-yY1ENM3WTWiwgNLXDAjsUA]] | Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@BARAAYGAyIDg0EUA]] | Murder Row |
| Neck | [[item:251234@BgRAAYGAkVjMyAINBFA]] | Voidscar Arena |
| Shoulder | [[item:251223@BARAAYGAyIDg0EUA]] | Voidscar Arena |
| Cloak | [[item:251132@BARAAYGAyIDg0EUA]] | Murder Row |
| Chest | [[item:251159@BARAAYGAyIDg0EUA]] | Den of Nalorakk |
| Wrist | [[item:251135@BARAAYGAyIDg0EUA]] | Murder Row |
| Gloves | [[item:159337@BARAAYGAyIDg0EUA]] | Temple of Sethraliss |
| Belt | [[item:159317@BARAAYGAyIDg0EUA]] | Temple of Sethraliss |
| Legs | [[item:159329@BARAAYGAyIDg0EUA]] | Temple of Sethraliss |
| Boots | [[item:159327@BARAAYGAyIDg0EUA]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@BgRAAYGAyIDg0YbNBFA]] | Temple of Sethraliss |
| Ring 2 | [[item:251194@BgRAAYGAkVjMyAINBFA]] | The Blinding Vale |
| Trinket 1 | [[item:250214@BARAAYGAyIDg0EUA]] | The Blinding Vale |
| Trinket 2 | [[item:273796@BARAAYGAyIDg0EUA]] | Altar of Fangs |
| Main-hand | [[item:273778@BARAAYGAyIDg0EUA]] | Altar of Fangs |
| Off-hand | [[item:251191@BARAAYGAyIDg0EUA]] | The Blinding Vale |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]]  <br>[[item:273796@AgQAAIoAOFA]] |
| **A-Tier** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **B-Tier** | [[item:270170@AgQAAIoAOFA]]  <br>[[item:270161@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:273794@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Only crafted on your **weapon** or **off-hand**.
- 1x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists** or **Cloak** depending on your available gear.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]] -- default
- Combat Potion
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] -- default
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  
  
  
  - [[item:240967]] *-- Unique, can only use one; make sure to use at least one of each colour of the normal gems*
    
    - [[item:240916]]
    - [[item:240892]]
    - [[item:240908]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAAEAZbAB]]  <br>[[item:275707@BAAAAAE]] |
| --- | --- |
| Shoulders | [[item:243991@BAAAAoQA]] |
| Chest | [[item:243977@BAAAAoQA]] |
| Wrist | [[item:275707@BAAAAAE]] |
| Waist | [[item:275707@BAAAAAE]] |
| Legs | [[item:240133@BAAAAoQA]] |
| Boots | [[item:243953@BAAAAoQA]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:244029@BAAAAoQA]] |

:::

:::column
:::gear **Balance Druid** Enchantments in Mythic+
```json
{
  "source_code": "JQFZmBQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAAEAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Balance Druid** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Night Elf
  
  - One of the most potent racials in Mythic+ historically for avoiding mechanics.
  
  
  
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:26297]] -- Troll
  
  - Strong burst racial but lines up poorly with [[spell:194223]]
- [[spell:20549]] *-- Tauren* 
  
  - [[spell:20549]] in combination with [[spell:99]] and [[spell:61391]] can make you a one-man army of rotating AoE interrupts.
- [[spell:291628]] -- Kul Tiran
  
  - The numerically best defensive racial.
  - Looks badass.

### Recommendation

**Night Elf** has a big impact on your Mythic+ experience due to [[spell:58984]], making it the only logical choice if you're serious about pushing keys with your **Balance Druid**.

## Macros

Discover recommended macros for **Balance Druid** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
[[spell:394013]] **/ [[spell:395022]] / [[spell:390378]] Macro -** *casts [[spell:390378]] at your cursor, uses potion and on-use trinket. (*You can also add [[spell:124974]] and [[spell:29166]] in here but it's not always the best).

```wow-macro
#showtooltip Celestial Alignment
/cast Berserking
/use 14
/use [combat] 16
/use Potion of Recklessness
/cast [@cursor] Celestial Alignment
```

**Cursor/Mouseover [[spell:102793]]/[[spell:102359]] -** *Casts Ursol's Vortex at your cursor if talented and Mass Entanglement at your mouseover*, *if no mouseover is available it is instead cast it on your target.*

```wow-macro
/cast [@cursor] Ursol's Vortex
/cast [@mouseover,exists] [] Mass Entanglement
```

**[[spell:205636]]** -- *Casts [[spell:205636]] without confirmation click which can save you valuable time.*

```wow-macro
#showtooltip
/cast [@cursor] Force of Nature
```

:::

:::details Mouseover Macros
**Mouseover Focus Macro**

```wow-macro
/focus [@mouseover]
```

**Mouseover [[spell:2782]] -** *Casts [[spell:2782]]* *on mouseover > or target > or self.*

```wow-macro
#showtooltip
/cast [@mouseover,exists][] Remove Corruption
```

**Mouseover [[spell:20484]] -** *Casts [[spell:20484]] on mouseover > or target.*

```wow-macro
/cast [@mouseover][] Rebirth
```

**Mouseover [[spell:8936]]** *- Casts **[[spell:8936]]** on mouseover > or target > or self.*

```wow-macro
#showtooltip Regrowth
/cast [@mouseover,exists][] Regrowth
```

**Mouseover [[spell:18562]]** - *Casts **[[spell:18562]]** on mouseover > or target > or self.*

```wow-macro
#showtooltip Swiftmend
/cast [@mouseover, exists] [] Swiftmend
```

**[Mouseover [[spell:48438]]** - *Casts **[[spell:48438]]** on mouseover > or target > or self.*

```wow-macro
#showtooltip Wild Growth
/cast [@mouseover, exists] [] Wild Growth
```

**[Mouseover [[spell:774]]** - *Casts **[[spell:774]]** on mouseover > or target > or self.*

```wow-macro
#showtooltip Rejuvenation
/cast [@mouseover, exists] [] Rejuvenation
```

:::

:::details Utility Macros
**Focus [[spell:78675]]**

```wow-macro
#showtooltip Solar Beam
/cast [@focus] Solar Beam
```

Stopcasting Health Potion Macro

```wow-macro
/stopcasting
/use Silvermoon Health Potion
```

Augment Rune Macro -- *Refreshes your augment rune whenever you enter [[spell:24858]]*.

```wow-macro
/cast Moonkin Form
/use Void-Touched Augment Rune
```

**[[spell:29166]] M+ Healer Macro -** *Innervate the healer in your party*

```wow-macro
/cast [@party1] Innervate
/cast [@party2] Innervate
/cast [@party3] Innervate
/cast [@party4] Innervate
/cast [@party5] Innervate
```

**Dynamic Mount Macro** - *Mounts dragonflying mount if flying mounts are allowed, else Swift Zulian Tiger. (feel free to change mounts)*

```wow-macro
/cast Highland Drake
/cast [flyable] Highland Drake; Swift Zulian Tiger
```

**[[spell:78674]] after [[spell:391528]] Macro** *- Replaces your [[spell:78674]] key and prevents [[spell:78674]] from being cast while [[spell:391528]] is being channeled.*

```wow-macro
#showtooltip Starsurge
/startattack
/cast [nochanneling:Convoke the Spirits] Starsurge
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Balance Druid**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Balance-Mythic-UI-1024x616.png>)

**Balance Druid** User Interface in Mythic+

:::accordion
:::details Addons
- **EllesmereUI** -- Unit frames, nameplates, cooldown manager replacement, and many more
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **LittleWigs** *-- Generic Boss Mod*  
  
  - This is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger +alert messages, timer bars, sounds, and so forth, for one specific boss encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Matted Fur absorb increased by 25%.
- Heart of the Wild empowered Wild Growth healing increased by 25%.
- Shred and Cat Form Swipe damage increased by 10%.
- Balance
  
  - Developers' notes: Our goal for Balance in Curse of Ula'tek is to emphasize its core gameplay of building, spending, and pooling Astral Power. In Midnight, Balance had high Astral Power generation and a lot of free spender procs, which meant there weren't many GCDs left after casting spenders. In Curse of Ula'tek we've reduced Astral Power generation and the number of free spenders but increased the damage each spender does. The intent is to provide more time to react to Astral Power gain and make pooling Astral Power outside Eclipse to spend inside Eclipse more impactful. We've also adjusted some talent power to increase build diversity.
  - New passive ability learned at level 42: Stellar Protection – If Moonfire and Sunfire are dispelled, Stellar Flare is applied to the target. Generates 12 Astral Power.
  - Umbral Intensity has been updated – Now increases Wrath and Starfire damage by 12% at all times.
  - Apex Talent: Ascendant Eclipses (Rank 2) – Astral Smolder damage reduced to 10%/20% of critical strike damage (was 12%/24%) and its duration is increased to 8 seconds (was 6 seconds).
  - Apex Talent: Ascendant Eclipses – Solar Bolt increased by 27% and Lunar Bolt damage increased by 10%.
  - All damage dealt increased by 8%
  - Moonfire damage increased by 5%.
  - Sunfire damage increased by 5%.
  - Wrath damage increased by 10%.
  - Starfire damage increased by 20%.
  - Starsurge damage increased by 71%.
  - Starfall damage increased by 4%.
  - Shooting Stars damage increased by 10%.
  - Meteorites damage increased by 15%.
  - Rejuvenation healing increased by 25%.
  - Wild Growth healing increased by 25%.
  - Regrowth healing increased by 25%.
  - Celestial Fire increases the damage of Moonfire, Sunfire, and Shooting Stars by 10% (was 8%).
  - Orbit Breaker effectiveness reduced to 50% (was 60%).
  - Touch the Cosmos chance to trigger from Wrath reduced to 12% (was 15%), and chance to trigger from Starfire reduced to 15% (was 20%).
  - Total Eclipse chance to trigger increased to 15%/30% (was 10%/20%).
  - Sculpt the Stars and Astral Communion have swapped positions in the talent tree.
  - Sculpt the Stars reduces Eclipse cooldown by 3 seconds (was 2 seconds).
  - Stellar Amplification is now only applied to 1 target.
  - Orbit Breaker Aura can be tracked in the Cooldown Manager.
  - Fixed an issue causing some Cooldown Manager elements such as damage-over-time timers and buff trackers to sometimes not show accurate information.
  - Hero Talents
    
    - Elune's Chosen
      
      - Developers' notes: Elune's Chosen should always use Starfire as its builder over Wrath, so we are restoring their Starfire single target bonus and reducing their single target damage through a small reduction to Starsurge.
      - Star Cascade no longer triggers off of gaining Astral Power with Wrath.
      - Star Cascade has a 30% chance to launch a Starsurge at 50% effectiveness (was 40% at 70% effectiveness).
        
        - *Developers’ notes: With the increased number of builders that Balance is casting in Season 2, this talent is overperforming its intended value.*
      - Bask in Moonlight increases the damage of Starsurge by 5% (was 10%).
    - Keeper of the Grove
      
      - Bounteous Bloom now extends the duration of Force of Nature Treants by 4 seconds instead of adding a fourth Treant.
      - Cenarius' Might haste increase reduced to 6% (was 8%).
      - Potent Enchantments haste increase reduced to 6% (was 10%).
      - Sylvan Beckoning Dryad's Starfall damage increased to 250% effectiveness (was 200%).
      - Spirit of the Thicket increases Starfall damage by 18% (was 12%).
      - Dream Burst damage increased by 30%.
      - Power of Nature increases your treant melee damage by 300% (was 200%).

:::

:::

:::accordion
:::details Patch 12.0
- Skull Bash interrupt duration increased to 5 seconds (was 3 seconds). Does not affect PvP combat.
- Potent Enchantments has been updated – Orbital Strike damage increased by 30%, and damage of Stellar Flares it applies increased by 30%. Whirling Stars increases the Haste you gain during Celestial Alignment by an additional 10%.
- Bounteous Bloom has been updated – Force of Nature summons 4 treants.
- Moonfire cast by your Treants no longer generates Astral Power.
- Harmony of the Grove causes your Force of Nature Treants to increase your spell damage by 4% (was 8%).
- Cenarius' Might increases Haste by 8% (was 12%).
- Elune's Chosen
- New Talent: Star CascadeBalance: Gaining Astral Power with Wrath or Starfire has a 40% chance to launch a Starsurge at a victim at 70% effectiveness.
- Guardian: Thrash has a 50% chance to launch a Starsurge at a victim at 120% effectiveness.
- New Talent: Penumbral SwellBalance: Lunar Eclipse increases Arcane damage by an additional 3%.
- Guardian: Lunar Beam increases Arcane damage you deal by 10% while it is active.
- New Talent: Bask in MoonlightBalance: Starsurge damage increased by 10%. Starfall damage increased by 10%.
- Guardian: Maul/Raze damage increased by 10%. Lunar Beam's damage dealt to its primary target increased by 30%.
- The Light of Elune triggers Fury of Elune 20% less frequently.
- Lunar Amplification has been removed.
- Stellar Command moved to Lunar Amplification's previous position.
- BalanceLunar Calling has been updated – Now increases damage dealt to Starfire's primary target by 100% (was 160%) and no longer includes a reference to triggering Solar Eclipse.
- Lunation causes your Arcane abilities to reduce the cooldown of Fury of Elune by 1.5 seconds (was 2 seconds).
- All Druid specializations learn Bear Form Thrash at level 11 (was a talent).
- Keeper of the Grove
- New Talent: Sylvan Beckoning –Balance: Entering an Eclipse summons a Dryad to assist you for 8 seconds, casting Starsurge dealing astral damage and Starfall at 200% effectiveness.
- Restoration: Your periodic heals have a chance to empower your next Swiftmend to summon a Dryad to assist you, casting Tranquility at 10% effectiveness and Regrowth to heal your lowest health ally.
- New Talent: Dryad's Dance –Balance: Dryads cause most of your Astral power generation to be increased by 10%.
- Restoration: Dryads cause Swiftmend to cool down 25% faster.
- New Talent: Spirit of the Thicket –Balance: Your Starfall damage is increased by 8% and your Starsurge damage is increased by 8%.
- Restoration: Ironbark summons a Dryad to channel a beam of pure nature onto your target, healing them for over 6 seconds.
- BalancePotent Enchantments has been updated – Orbital Strike damage increased by 30%, and damage of Stellar Flares it applies increased by 30%. Whirling Stars increases the Haste you gain during Celestial Alignment by an additional 10%.
- Bounteous Bloom has been updated – Force of Nature summons 4 treants.
- Moonfire cast by your Treants no longer generates Astral Power.
- Harmony of the Grove causes your Force of Nature Treants to increase your spell damage by 4% (was 8%).
- Cenarius' Might increases Haste by 8% (was 12%).

:::

:::

:::accordion
:::details Patch 11.2.0
- Lycara’s Meditation replaced with Lycara’s Inspiration – You gain a bonus while in each form inspired by the breadth of your Druidic knowledge: No Form: 4% Magic Damage
- Bear Form: 5% Movement Speed
- Cat Form: 4% Stamina
- Moonkin Form: 3% Avoidance
- Bear Form’s threat generation multiplier has been reduced for Balance, Feral, and Restoration Druids.
- **Balance** All damage increased by 8%.

:::

:::details Patch 11.1.0
- New Talent: Grievous Wounds – Rake, Rip, and Thrash damage increased by 10%.
- New Talent: Gale Winds – Increases Typhoon's radius by 20% and its range by 5 yards.
- New Talent: Incessant Tempest – Reduces the cooldown of Typhoon by 5 seconds.
- New Talent: Circle of the Wild – Physical damage dealt by your abilities increased by 5% (25% for Restoration Druids).
- New Talent: Circle of the Heavens – Magical damage dealt by your spells increased by 5% (25% for Restoration Druids).
- New Talent: Lycara's Meditation – You retain Lycara's Teachings' bonus from your most recent shapeshift form for 5 seconds after shifting out of it.
  
  - *Developers’ notes: Lycara’s Meditation is meant to retain some power when you shapeshift. It is not intended as a buff you would want to always maintain, and since Druids can swap into humanoid form instantly at no cost, the humanoid form bonus is not retained. Druids must also stay in Cat Form for 2 seconds to retain the Cat Form bonus if they entered Cat Form by casting Skull Bash with Fluid Form.*
- New Talent: Symbiotic Relationship – Form a bond with an ally. Your self-healing also heals your bonded ally for 10% of the amount healed. Your healing to your bonded ally also heals you for 8% of the amount healed.
- New Talent: Aessina's Renewal – When a hit deals more than 12% of your maximum health, instantly heal for 10% of your health. This effect cannot occur more than once every 30 seconds.
- New Talent: Perfectly-Honed Instincts – Well-Honed Instincts can trigger up to once every 90 seconds.
- Ursoc's Spirit has been updated – Stamina increased by 4%. Stamina in Bear Form increased by an additional 5%.
  
  - *Developers' notes: These bonuses multiply together, so Druids' health in Bear Form remains unchanged.*
- Light of the Sun replaces Skull Bash for Balance Druids only – The remaining cooldown of Solar Beam is reduced by 15 seconds when it interrupts its primary target.
- Improved Rejuvenation has been changed to Lingering Healing – Rejuvenation's duration is increased by 3 seconds. Regrowth's duration is increased by 3 seconds when cast on yourself.
- Instincts of the Claw is now a 1-point talent (was 2) and has been updated – Ferocious Bite and Maul damage increased by 8%.
- Lore of the Grove is now a 1-point talent (was 2) and has been updated – Moonfire and Sunfire damage increased by 10%.
- Fluid Form has been updated – Skull Bash can now be used in any form and shifts you into Cat Form if necessary.
- Fluid Form causes Wrath and Starfire to transform you into Moonkin Form at the end of their casts, instead of at their starts.
  
  - *Developers' notes: It should always take a global cooldown to transform to a shapeshift form, either from a direct transformation or a Fluid Form ability. Starting a Wrath or Starfire cast and cancelling it allowed Druids to transform into Moonkin without a global cooldown.*
- Moonkin Form has been added to the Class talent tree in Sunfire’s previous position.
  
  - *Developers' notes: Restoring Moonkin Form to the class talent tree empowers Restoration Druids to use Convoke the Spirits for magic damage, like they can currently use Cat Form for physical damage.*
- Rejuvenation healing increased by 5%.
- Wild Growth healing increased by 5%.
- Rip damage reduced by 9%.
- Shred damage increased by 10%.
- Swipe damage increased by 10%.
- Ferocious Bite damage reduced by 8%.
- Cyclone duration is now 5 seconds (was 6 seconds).
- Improved Sunfire’s effect is now included in Sunfire.
- Disorienting Roar now breaks based on a small damage threshold instead of any damage.
- Many talents have changed positions in the class tree.
- Rising Light, Falling Night has been removed.
- Balance
  
  - Balance Druids now learn Moonkin Form in the Class talent tree upon reaching level 10.
  - Light of the Sun has been moved to the Class Talent Tree for Balance Druids.
  - Power of Goldrinn damage increased by 100%.
  - Starsurge damage increased by 5%.
  - Touch the Cosmos chances increased to 18% from Wrath (was 15%) and 25% for Starfire (was 22%).

:::

:::

:::accordion
:::details Patch 11.0.5
- Mark of the Wild now costs 1% base mana (was 4%).
- Adaptive Swarm's icon has been updated.
- Convoke the Spirits' icon has been updated.
- Hero Talents
  
  - Elune's Chosen
    
    - Arcane spells cast by Convoke the Spirits now trigger Lunation.
- Balance
  
  - New Talent: Sunseeker Mushrooms – Sunfire damage has a chance to grow a magical mushroom at the target's location. After 1 second, the mushroom detonates, dealing Nature damage and then an additional Nature damage over 10 seconds. Affected targets are slowed by 50%. Generates up to 20 Astral Power based on targets hit.
  - New Talent: Whirling Stars – Celestial Alignment's cooldown is reduced to 100 seconds and it now has two charges, but its duration is reduced by 20%.
  - New Talent: Astronomical Impact – The critical strike damage of your Astral spells is increased by 20%.
  - New Talent: Crashing Star – Shooting Stars has a 15% chance to instead call down a Crashing Star, dealing Astral damage to the target and generating 4 Astral Power.
  - New Talent: Hail of Stars – Casting a free Starsurge or Starfall grants Solstice for 3 seconds. Free spells cast by Convoke the Spirits grant a 1 second version of this effect.
  - Touch the Cosmos has been updated – Casting Wrath in an Eclipse has a 12% chance to make your next Starsurge or Starfall free. Casting Starfire in an Eclipse has an 18% chance to make your next Starsurge or Starfall free.
  - Starfall is learned by all Balance Druids at level 15 (was a talent).
  - Starfall damage increased by 10%.
  - New Moon damage increased by 20%.
  - Half Moon damage increased by 10%.
  - Rattle the Stars increases Starsurge and Starfall damage by 10% (was 12%).
  - Umbral Inspiration increases damage by 30% (was 35%).
  - Wild Mushroom now generates 10 Astral Power upon hitting a single target (was 5).
  - Warrior of Elune increases Astral Power generation of affected Starfires by 30% (was 40%).
  - Nature's Grace no longer increases the damage of affected Wraths and Starfires.
  - Umbral Intensity is now a 1-point talent that increases the damage of Solar Eclipse Wrath by 20% (was 15%), Lunar Eclipse Starfire by 15%, and the damage Starfire does to nearby enemies by 30%.
  - Astral Smolder's chance to trigger is reduced to 35% (was 40%), and it deals 60% of damage dealt (was 50%).
  - Orbit Breaker calls down a Full Moon every 30th Shooting Stars (was 25).
  - Power of Goldrinn is now a 1-point talent (was 2) and its damage has been reduced by 35%.
  - Astral Communion no longer grants Astral Power on entering an Eclipse. Instead, entering an Eclipse causes your next Starsurge or Starfall to cost 15 less Astral Power.
  - Spells cast by Convoke the Spirits now trigger Starlord.
  - Many talents have changed positions in the talent tree.
  - Added a connection between Force of Nature/Warrior of Elune and Celestial Alignment.
  - Added a connection between Umbral Intensity and Starlord.
  - Cosmic Rapidity tooltip description updated for clarity and now says your periodic effects deal damage more frequently.
  - The following talents have been removed:
    
    - Greater Alignment
    - Lunar Shrapnel
    - Starfall (now learned at level 15)
  - Elune's Chosen
    
    - Lunar Calling increases Starfire damage by 100% (was 80%).
  - Keeper of the Grove
    
    - Potent Enchantments causes Whirling Stars to reduce the cooldown of Celestial Alignment by an additional 10 seconds.
    - Control of the Dream now reads "are available to be used or at maximum charges." If the player has Whirling Stars, it reduces the cooldown of Celestial Alignment based on time spent at maximum charges.

:::

:::

:::accordion
:::details Patch 11.0.2
- All spell damage increased by 6%.
- Force of Nature melee damage increased by 60%.
- Wild Mushroom damage increased by 20% and it generates up to 20 Astral Power (was 16).
- Umbral Inspiration damage bonus increased to 35% (was 30%).
- Denizen of the Dream damage reduced by 6.5%.
- Denizen of the Dream's attacks are now affected by all abilities that increase all your spell damage or critical strike chance.
- Astral Communion grants 25 Astral Power (was 20).
- Wrath or Starfire cast with Umbral Embrace are now affected by both passive bonuses from Mastery: Astral Invocation.
- Wraths cast by Convoke the Spirits can now trigger Umbral Embrace and Astral Smolder.
- If a player has a free cast available from Touch the Cosmos and Starweaver, only the bonus from Starweaver is consumed on the next cast.
- Touch the Cosmos now highlights Starfall or Starsurge when your next cast will be free.

:::

:::details Patch 11.0
- All talent trees have had many talents move locations or have had their pathing updated.
- New Talent: Oakskin – Survival Instincts and Barkskin reduce damage taken by an additional 10%.
- New Talent: Fluid Form – Shred and Rake can be used in any form and shifts you into Cat Form. Mangle can be used in any form and shifts you into Bear Form. Wrath and Starfire shifts you into Moonkin Form, if known.
- New Talent: Ursoc's Spirit – Stamina in Bear Form is increased by 10%.
- New Talent: Instincts of the Claw – Shred, Swipe, Rake, Mangle, and Thrash damage increased by 5/10%.
- New Talent: Lore of the Grove – Moonfire and Sunfire damage increased by 5/10%. Rejuvenation and Wild Growth healing increased by 3/5%.
- New Talent: Starlight Conduit – Wrath, Starsurge, and Starfire damage increased by 5%. For non-Balance, Starsurge's cooldown is reduced by 4 seconds and its mana cost is reduced by 50%.
- Improved Swipe has been removed from the talent tree and its benefit added to Swipe by default.
- Moonkin Form has been removed from the talent tree and is now learned at level 10 for Balance Druids.
- Swiftmend has been removed from the talent tree and is now learned at level 11 for Restoration Druids.
- Heart of the Wild now reduces the global cooldown of affected Balance cast-time spells.
- Cat Form now increases the range of auto-attacks and melee abilities by 3 yards.
- Feline Swiftness now increases movement speed by 15%. Now a 1-point talent.
- Thick Hide now reduces damage taken by 4%. Now a 1-point talent.
- Natural Recovery now increases healing received by 4% and no longer increases healing done. Now a 1-point talent.
- Astral Influence now increases the range of all your spells by 5 yards and no longer increases auto attack or melee ability range. Now a 1-point talent.
- Primal Fury now also increases critical strike damage of Mangle by 20%.
- Ursine Vigor now increases Stamina and armor in Bear Form by 15% for 4 seconds. Now a 1-point talent.
- Guardian Druid improved Bear Form Stamina bonus decreased to 10% (was 20%).
- Lycara's Teachings is now a 2-point talent that grants 3/6% of various secondary stats.
- Forestwalk now increases your movement speed and healing received by 8% for 6 seconds. Now a 1-point talent.
- Well-Honed Instincts' effect now occurs once every 120 seconds. Now a 1-point talent.
- Mass Entanglement now roots targets for 10 seconds (was 30 seconds).
- Tireless Pursuit has been removed.

- New Talent: Greater Alignment – Incarnation: Chosen of Elune/Celestial Alignment lasts 40% longer. During Incarnation: Chosen of Elune/Celestial Alignment, Solar Eclipse increases Nature damage done by an additional 8% and Lunar Eclipse increases Arcane damage done by an additional 8%.
- New Talent: Stellar Amplification – Starsurge increases the damage the target takes from your periodic effects and Shooting Stars by 20% for 5 seconds. Reapplying this effect extends its duration, up to 20 seconds.
- New Talent: Harmony of the Heavens – Starsurge or Starfall increase your current Eclipse's Arcane or Nature damage bonus by an additional 1%, up to 5%.
- New Talent: Touch the Cosmos – Casting Wrath in an Eclipse has an 12% chance to make your next Starsurge free. Casting Starfire in an Eclipse has a 15% chance to make your next Starfall free.
- New Talent: Umbral Inspiration – Consuming Umbral Embrace increases the damage of your Moonfire, Sunfire, Stellar Flare, Shooting Stars, and Starfall by 30% for 6 seconds.
- Umbral Embrace has been redesigned – Wrath and Starfire have a 20% chance to cause the next Wrath or Starfire you cast in Eclipse to become Astral and deal 75% additional damage. Now a 1-point talent.
- Astral Smolder has been redesigned – Wrath and Starfire have a 40% chance to cause their targets to languish for an additional 50% of their damage dealt over 6 seconds. Now a 1- point talent.
- Astral Communion has been redesigned – Increases maximum Astral Power by 20. Entering Eclipse grants 20 Astral Power.
- Nature's Grace has been redesigned – When Eclipse ends or when you enter combat, enter a Dreamstate, reducing the cast time of your next 2 Starfires or Wraths by 20% and increasing their damage by 50%.
- All ability damage increased by 6%.
- Wrath damage increased by 15%.
- Starfire damage increased by 15%.
- Starsurge damage increased by 15%.
- Starfall damage increased by 15%.
- Denizen of the Dream damage increased by 64%.
- Shooting Stars damage increased by 46%.
- Fury of Elune damage increased by 15%.
- Full Moon damage increased by 15%.
- Stellar Flare damage increased by 20%.
- Wild Mushrooms damage increased by 25%.
- Mastery: Astral Invocation value reduced by 17%.
- Astral Power generation reduced for the following abilities:
  
  - Wrath: 6 (was 8)
  - Starfire: 8 (was 10)
  - New Moon: 10 (was 12)
  - Half Moon: 20 (was 24)
  - Full Moon: 40 (was 50)
  - Fury of Elune: 40 / 2.5 per tick (was 48 / 3 per tick)
- Incarnation: Chosen of Elune duration reduced to 20 seconds (was 30 seconds).
- Celestial Alignment duration reduced to 15 seconds (was 20 seconds).
- Aetherial Kindling now extends during of active Sunfires and Moonfires by 3 seconds (was 4 seconds).
- Umbral Intensity now increases Starfire's damage as well as its area-of-effect damage scaling. Solar Eclipse increases the damage of Wrath by an additional 25/50%. Lunar Eclipse increases the damage of Starfire by 25/50% and the damage it deals to nearby enemies by an additional 15/30%.
- Waning Twilight now increases damage you deal to targets with 3 or more of your periodic effects by 6%. Now a 1-point talent.
- Balance of all Things now increases Critical Strike chance by 10/20%, decreasing by 1/2% every second.
- Wild Surges increases Wrath and Starfire critical strike by 10% (was 12%).
- Elune's Guidance reduces the Astral Power cost of Starsurge by 10 (was 8) and Starfall by 12 (was 10).
- Orbit Breaker calls downs a Full Moon every 25 Shooting Stars (was 30).
- Sundered Firmament calls down a Fury of Elune at 25% power (was 20%).
- Convoke the Spirits now prefer to cast Starsurge or Full Moon on your current target, if valid.
- The following talents have been removed:
  
  - Friend of the Fae
  - Primodial Arcanic Pulsar

:::

:::

## FAQ

:::accordion
:::details Q: Why is my DPS so low?
**A:** Balance Druids do proportionally more damage the higher the Mythic+ keys go since you have a long ramp up time on packs.

:::

:::

---

### Credits

Written By: **Wexi**

Reviewed By: **Maystine**

:::changelog 更新记录
**2026-08-03** Updated for patch 12.1.

**2026-06-18** Updated for patch 12.0.7.

**2026-06-18** Updated for patch 12.0.5.

**2026-02-20** Updated for patch 12.0.1.

**2026-01-16** Updated for patch 12.0.

**2025-08-03** Updated for patch 11.2.

**2025-06-16** Updated for Patch 11.1.7.

**2025-02-14** Updated for Patch 11.1.0.

**2024-12-15** Updated for patch 11.0.7.

**2024-10-23** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide written for the pre-patch 11.0.1.



:::
