欢迎来到 **防护 圣骑士** 魔兽世界12.1版本团队副本攻略！本攻略涵盖了你了解自己角色所需的一切！你是刚起步、从80级开始练级的玩家吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体目标** · 3/5 · 一般

范围伤害 · 4/5 · 强势

功能性 · 5/5 · 极佳

生存能力 · 2/5 · 较弱

机动性 · 2/5 · 较弱



:::

:::

:::column
:::gear **防护 圣骑士 团队副本 最佳配装**
```json
{
  "source_code": "JQpAgLEA3_fABkGJEIICFAw74OwVtOggC4UAKX6ABk-FEAQEBAg_sOg_sOAj1kjAYFQAnRCBCgQBAUTuDEgJU0bpDEAbkUgEAkQASgCWB47FEEw4XQAgIUAOAIYAzAjBmQgAQEAAhu7AWYTOBEBdEE6AGgQAAUXZDciqD8QuDcbNLFQAKE6AEiQAAYBwBUBB-zaCVQmakQAAIUAACKgTB4U1DEg6XQgAJEAAvk7A-XAlBgBDBMubCYUFAQBVfQAAIEQB5QQAdFBDQgVAB09FNgBLYFQAxeBBCgQAA0TuJcKKkeBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271878]] | [[item:244641]] |
| 脚部 | [[item:237828]] | [[item:222581]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:268196]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为 **防护 圣骑士**，你可以使用先锋之辉，它使[[spell:275779]]有几率赋予你[[spell:1268810]]，强化你的下一个[[talent:102471]]，使其在你与目标之间的直线上造成额外的范围伤害伤害。

**等级2** 使 [[spell:275779]] 造成的伤害提高，并使消耗 [[spell:1268810]] 时生成 神圣 能量。当 **等级3** 使 [[spell:53600]] 在消耗 [[spell:1268810]] 后造成更多伤害，并使 [[talent:102471]] 在 [[talent:102448@FJQA41dBCEA]] 期间始终受益于 [[spell:1268810]]。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-protpala-mxr.webp>)

先锋之辉

:::

:::

### 核心改动

以下为你整理从《地心之战》到 至暗之夜 的重要职业改动，帮你保持信息更新。如果想更详细地了解 **全部** 改动，请查看我们的 **本补丁改动** 部分。

- **专精天赋树**
  
  - [[spell:76671@FJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEA]] 
    
    - 站在 [[spell:26573]] 中不再提供伤害减免，这让你可以更自由地移动。现在留在 [[spell:26573]] 中的唯一动机是将小怪留在其中以造成 范围伤害 伤害，以及来自 [[talent:102436]] 的 5% 伤害减免，这些都不如以前 [[spell:76671@FJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEA]] 提供的伤害减免那么关键。
    - 现在允许你在基础状态下格挡法术。基本上包含了已被移除的 [[spell:152261]] 的效果。
  
  
  
  - [[spell:1246481]]
    
    - 使 [[talent:102456]] 获得第二次充能。由于其他职业改动使防御冷却技能更加稀缺，该天赋在任何有挑战性的内容中都是必选的。
  - [[spell:1246488]]
    
    - 新天赋，使你的 [[spell:275779]] 链式传导至 2 个额外目标，造成 50% 的伤害。
- **职业天赋树**
  
  - [[spell:1241288]]
    
    - 现在不再是一个单独的法术，而是在 [[talent:102448]] 期间被动强化 [[spell:275779]] 以造成更多伤害。此外，[[spell:1241958]] 会根据目标已损失的生命值提高造成的伤害。
  - [[spell:1241945]]
    
    - 现在最多减少 10% 所受伤害，随你已损失的生命值而增加。
  - [[spell:183416]]
    
    - 当你生命值高于 85% 时，将队友所受伤害的 5% 转移到你身上，而不是增强你的圣能量消耗技能。
- 已移除
  
  - 坚定守护者
    
    - 以前是在消耗 神圣 能量时减少 [[talent:102445]] 和 [[spell:642]] 的冷却时间。
    
    
    
    - 结合 [[spell:204074]] 的重做，这导致 防护 圣骑士 玩法中冷却缩减方面的完全移除。所有防御和进攻冷却技能现在都是固定的，使它们的使用更加可预测且更容易规划。
  - [[spell:387174]]
    
    - 从我们的技能库中移除了一个短冷却的防御技能。
  - [[spell:378974]] 和 [[spell:327193]]
    
    - 这些技能几乎总是在冷却好了就使用，并不会显著改变输出循环，导致出现了两个‘按完就忘’的按钮，但并没有让循环变得更有趣。
  - [[spell:385724]] 和 [[spell:379043]] 
    
    - 这些改动移除了围绕维持 100% 法术格挡几率来应对大型魔法攻击的玩法。

## 英雄天赋

- [[talent:123361]]和[[talent:123358]]都是非常有竞争力的选择。目前[[talent:123361]]在单体和顺劈战斗中表现都更好。因此，作为防护 圣骑士打团队副本时，我们推荐[[talent:123361]]。



### [[talent:123361]]

- 作为 [[talent:123361]]，你会获得 [[talent:117882]]，它会在以下效果之间交替：
  
  - [[spell:432459]]：一个吸收你最大生命值15%的护盾，并在20秒内每2秒额外获得2%的吸收量。
  - [[spell:432472]]：一个伤害增益效果，有几率对附近敌人造成 神圣 伤害，持续20秒。该效果在单体目标时会增强，在命中超过5个目标时减弱。
- [[talent:117882]] 拥有2层充能，并在 [[spell:432459]] 与 [[spell:432472]] 之间轮换。
  
  - 两种武装都可以施放在你自己或队友身上。搭配 [[talent:117873]] 时，将其施放在队友身上也会使你获得该效果，反之亦然。
- [[talent:117875]]：
  
  - 激活 [[spell:31884]] 会额外召唤一个 [[spell:432472]]。
  - 这个额外的 [[spell:432472]] 会通过回响你的 神圣 之能技能来造成额外伤害。
  - 这使得 [[spell:31884]] 成为一个更加强大的爆发技能。
- [[talent:117877]] 有几率随机在附近一名队友身上触发 [[talent:117882]] 效果。
- [[talent:117883]] 在施放一个 神圣 之能技能后，使 [[talent:102430]] / [[talent:102431]] 的伤害提高100%。
- [[talent:117881]] 是一个护甲和主属性增益，可替代武器油。

12.0版本新增了3个英雄天赋。

- [[talent:136000]] 使你在施放 [[talent:117882]] 之后的下3个技能会召唤一个它的削弱版。
- [[talent:136002@AJgABA]] 使 [[talent:136496@FJQAEdhACEA]] 也会触发 [[talent:136001@AJgABA]]。
- [[talent:117887@AJgABA]] 使你的 [[talent:102453]] 在吸收伤害或造成伤害时有几率获得 [[talent:117882]]。




### [[talent:123358]]

- 施放 [[talent:136496@FJQAEdhACEA]] 后，它会被替换为 [[spell:427453]]，持续 12 秒。 
  
  - [[spell:427453]] 消耗 3 点 神圣 能量，并造成高额 范围伤害 伤害。
  
  
  
  - 你应该施放 [[talent:136496@FJQAEdhACEA]]，然后在冷却时使用 [[spell:427453]]。
- 使用 [[spell:427453]] 后的 8 秒内，[[talent:117823]] 每 2 秒会在附近的一个目标上触发一次 [[spell:431398]]。
- [[talent:117811@FAQAEdhA]] 每当你施放以下技能时，使 [[talent:117823]] 延长 1 秒：
  
  - [[talent:102430]] / [[talent:102431]]
  - [[spell:275779]] 或 [[talent:133481@AJgABA]]
- [[talent:117818@FAQAEdhA]] 使你的 [[spell:53600]] 和 [[spell:85673]] 会在附近的一个目标上降下 [[spell:431398]]。当 [[talent:117823]] 处于激活状态时，此效果会额外降下 **一个额外的** [[spell:431398]].
- [[talent:117815]] 允许你在触发 [[spell:431398]] 60 次后免费施放 [[spell:427453]]。
- [[talent:117822@FAQAEdhA]] 使 [[spell:427453]] 能够：
  
  - 给予你 12% 急速 持续 6 秒。
  - 赋予 [[spell:53600]]。
  - 在你的目标脚下放置一个 [[spell:26573]]。
- [[talent:117810]] 使 [[spell:431398]] 的爆击会顺劈到另一个目标，并使你在 8 秒内受到受影响怪物造成的伤害降低 5%。此效果显著提升了 爆击用于顺劈和范围伤害场景。
- [[talent:117858]] 为 防护 圣骑士 解决了许多机动性问题，它提供延长 2 秒的 [[talent:102625]]，并在最初 3 秒内使你的移动速度额外提高 30%。

12.0版本新增了3个英雄天赋。

- [[talent:136005]] 使 [[talent:136496@FJQAEdhACEA]] 召唤神圣之锤，在8秒内围绕你造成 范围伤害 伤害。
- [[talent:136004@FAQAEdhA]] 使你的 [[spell:431398]] 造成更高的爆击伤害，并在爆击时额外获得一层 [[talent:117815@FAQAEdhA]]。
- 一个新的选择节点：
  
  - [[talent:136003]] 使 [[talent:136003]] 额外对你的目标施放2次。
  - [[talent:136184@FAQAEdhA]] 使 [[spell:275779]] 的伤害提高30%。





## 天赋



### [[talent:123361]] 单体

:::talents **防护 圣骑士** 团队副本 [[talent:123361]] 单体配装
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxMGAgBAAAAAANNzsMzYGMmt2AwAAGsBAAmZabmZbmZmltlWmZsYbjZAMGzwYAwMz2MAzMgxC",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxMGAgBAAAAAANNzsMzYGMmt2AwAAGsBAAmZabmZbmZmltlWmZsYbjZAMGzwYAwMz2MAzMgxC"
}
```
:::

#### 何时使用此专精

这是进入纯单体首领战时的默认配装。你需要根据战斗所需的团队功能性来调整职业天赋树。为了让你更省事，团本部分提供了针对各个首领的专属天赋配装。

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若需更详细的解析，请查看下方的循环和 **深度解析** 章节。

##### 专精树

- [[spell:204074]]
  
  - 使[[talent:102448@FJgA41dBACNACEA]]的冷却时间缩短50%，持续时间缩短40%，使其成为一个更短的1分钟冷却。
- [[spell:204018]]
  
  - 用于完全免疫魔法伤害，并防止你或你的队友受到减益效果的影响。
- [[talent:102466]]
  
  - 使 [[talent:102456]] 额外获得一层充能。
- [[spell:182104]]
  
  - 在施放3次 [[spell:53600]] 后，使你的 [[spell:85673]] 免费施放，最多可叠加2次免费使用次数。

##### 职业树

- [[talent:102596]]
  
  - 即使你身上有 [[spell:25771]] 减益效果，也允许使用 [[spell:642]]。

- [[talent:102603@FAQAqxH]]
  
  - 显著延长你最强大的防御冷却技能——[[spell:31850]]和[[spell:642]]的持续时间。
- [[talent:136503]]
  
  - 生命值降至25%以下时，以60%效果施放一次免费的[[spell:85673]]。此效果有1分钟冷却时间。
- [[spell:223817]]
  
  - 神圣能量消耗技能有几率使你的下一个[[spell:85673]]或[[spell:53600]]变为免费，并造成15%的额外伤害和治疗效果。
- [[talent:102465@FJQAEdhACEA]]
  
  - 对最多5个目标施放[[talent:102471]]，每命中一个目标产生1点神圣能量。
  - 如果点了天赋，通过[[spell:384027]]在15秒内每5秒立即施放一次[[talent:102471]]。
  - 为范围伤害威胁值、神圣能量生成和功能性提供强大的爆发。




### [[talent:123361]] 多目标（顺劈）

:::talents **防护 圣骑士** 团队副本 [[talent:123361]] 顺劈构筑
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### 何时使用此专精

在任何顺劈战斗中使用这套构筑，即战斗的大部分时间无法从[[talent:102435]]中获益，或者需要范围伤害伤害来应对大量的小怪。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[talent:102434]]
  - [[talent:102461]]
  - [[talent:102474@FAgAbHNBvj4A]]
- **移除**
  
  - [[talent:102435]]
  - [[talent:102446]]




### [[talent:123358]]

:::talents **防护 圣骑士** 团队副本 [[talent:123358]] **构筑**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGb22YGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGb22YGAjxMMGAMzsNDwMDYsA"
}
```
:::

#### 何时使用此专精

这是团队副本构建的[[talent:123358]]版本。如果你更喜欢[[talent:123358]]的玩法，或者想通过[[talent:117858]]获得更多机动性，可以使用它。

#### 天赋调整

##### 英雄天赋

**已将**改为[[talent:123358]]。更多信息请访问上方的**英雄天赋**部分。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:26573]] 的范围扩大30%，且 [[spell:26573]] 范围内的敌人将被照亮，使你的技能对其造成暴击的几率提高5%。
- **4件套：** 被 [[spell:20271]] 或 [[spell:204019]] 击中的敌人将额外受到20%的 神圣 伤害。若其被暴击击中，则额外伤害提高100%。

### 起手爆发

- 作为一名**防护 圣骑士**，你的输出循环目标是在不损失[[talent:102471@FAgAtWcBtHzA]]施放次数的前提下，尽可能多地产生并消耗神圣能量。



#### [[talent:123361]]

:::rotation **防护 圣骑士**[[talent:123361]] 团队副本   中的起手爆发
```json
{
  "source_code": "JQaAQxgQLlpBAAACQJXZtAVdsxGAC18ZA0BE8NQAd66AAAAAAI0oxXAAAI0N2MAAAIEG7WAAAAQACBW0BoBC_yHAd4ABT7VAOwAAC1gHJgTCQEBLJYBBBIUCkkAHRwSEkYDUAQQznB"
}
```
1. [[spell:432459]] 战前准备
2. [[spell:26573]] 开战前 [[item:241309]] · [[spell:389539]] · [[spell:210487]]
3. [[spell:375576]]  [[spell:53600]]
4. [[spell:31935]]  [[spell:53600]]
5. [[spell:24275]]
6. [[spell:204301]]
7. [[spell:24275]]  [[spell:53600]]
8. [[spell:204301]]
9. [[spell:24275]]
10. [[spell:204301]]  [[spell:53600]]
11. [[spell:31935]]  [[spell:53600]]
12. [[spell:26573]]
:::

- 使用 [[spell:432472]] 时需要注意的重要事项是它不能叠加。这意味着由 [[spell:31884]] 产生的 [[spell:432472]] 应该先使用，而正常施放的那个则在前一个耗尽后再使用。 
  
  - [[talent:117877]] 也可能出现这种情况，所以要小心，务必好好追踪这个增益。
  - 除上述情况外，冷却好了就使用[[talent:117882]]。




#### [[talent:123358]]

:::rotation **防护 圣骑士** [[talent:123358]] 团队副本   中的起手爆发
```json
{
  "source_code": "JgFwHIUznBAAAgAUyVWLQVHbsJQAd66AAAAAAI0oxXAAAIEG7WAAAAQACBW0AAAAC9LfAUAHI0bhGUACEMtXBcADAI08ckANkMtXAAAAAEgQgFN"
}
```
1. [[spell:26573]] 战前准备 [[item:241309]] · [[spell:389539]]
2. [[spell:375576]]  [[spell:53600]]
3. [[spell:31935]]
4. [[spell:427453]]
5. [[spell:24275]]
6. [[spell:204019]]
7. [[spell:24275]]  [[spell:53600]]
:::

- 在冷却时施放 [[talent:136496@FJQAEdhACEA]]，以便尽可能多地施放 [[spell:427453]]，并保持 [[talent:117823]] 的高覆盖率。





### 优先级列表



#### [[talent:123361]]

1. 在冷却时对 [[spell:31884]] 配合 [[spell:375576]] 使用。
2. 在 3-5 点 神圣 能量时使用 [[spell:53600]]。
3. 在 [[spell:31884]] 期间或在 3 点 神圣 能量以下触发 [[spell:1268810]] 时使用 [[spell:31935]]。
4. 如果你有 2 层充能，就使用 [[spell:20271]]。
5. 用 [[spell:26573]] 消耗 5 层 [[talent:117884]]。
6. 如果 [[spell:31884]] 的剩余冷却时间超过 20 秒且你尚未激活 [[spell:432472]]，就使用 [[spell:432472]]。
7. 使用 [[spell:31935]]。
8. 使用 [[spell:26573]]。
9. 使用 [[spell:20271]]。
10. 使用 [[spell:204019]]。




#### [[talent:123358]]

1. 在冷却时使用 [[spell:31884]] 配合 [[spell:375576]]。
2. 如果你还没有 [[talent:117822@FAQAEdhA]] 增益效果，就使用 [[spell:427453]]。
3. 在 3-5 点 神圣 能量时使用 [[spell:53600]]。
4. 在 神圣 能量低于 3 点时，于 [[spell:31884]] 期间或触发 [[spell:1268810]] 时使用 [[spell:31935]]。
5. 如果你有 2 层充能，使用 [[spell:20271]]。
6. 如果你有 3 层充能，就使用 [[talent:102431]]。
7. 使用 [[spell:31935]]。
8. 使用 [[spell:26573]]。
9. 使用 [[spell:20271]]。
10. 使用 [[spell:204019]]。





### 防御技能冷却

- [[spell:31850]]
  
  - 你的主要防御冷却技能。
  
  
  
  - 包含免死组件，允许在承受极端打击时存活。
- [[spell:86659]]
  
  - 你工具箱中最强的伤害减免技能。
  - 搭配[[talent:102466]]时有2层充能。
- [[spell:204018]]
  
  - 提供魔法伤害免疫，并防止魔法负面效果的施加。
  
  
  
  - 可以对你自己或其他玩家使用。
  - 激活期间不会导致你失去仇恨，与[[spell:1022]]不同。
- [[spell:642]]
  
  - 如果使用得当，这是最强大的防御技能，可以让你对某些机制完全免疫。更多详情，请查看**深度解析**。
  - [[spell:204077]] 使你在[[spell:642]]激活期间保持对附近敌人的仇恨。

## 深度解析

### 合理运用 保护祝福 与 破咒祝福

- 正确使用 [[spell:1022]] 和 [[spell:204018]] 可以让你完全**免疫**危险的机制，即使这些机制并非以你为目标。
- [[spell:1022]] 和 [[spell:204018]] 共享冷却时间。
- [[spell:1022]] 可用于使被敌人锁定的玩家免疫物理伤害，让他们能够持续贴住首领，专注于输出或治疗，而不必风筝。
- 它会移除已存在的**物理减益效果**（如流血），以及**眩晕**，并阻止新的减益效果被施加。
- [[spell:204018]] 则**不会**移除已存在的 **魔法减益效果**——它只在生效期间阻止**新的**减益效果被施加。
- 巧妙地使用 [[spell:204018]] 或 [[spell:1022]] 可以拯救你的队友，常常能防止团灭并加快首领攻略进度。
- 注意 [[spell:1022]] 在其持续期间会导致仇恨丢失。[[spell:204018]] 则没有同样的效果，因此你可以在主动坦怪时安全地对自己使用。

### 将 清算之手 与 圣盾术 和 保护祝福 配合使用

- 在[[spell:642]]或[[spell:1022]]生效之前或生效期间使用[[spell:62124]]，可以让你在[[spell:62124]]的持续时间内保持对目标的仇恨。
- 这样你就能在继续扛住首领的同时获得免疫：[[spell:642]] 提供完全免疫，[[spell:1022]] 提供物理免疫。这使你能够在以下情况下获得 [[talent:102473]] 的效果：**单个目标**无需点出该天赋，但效果仅持续 3 秒。
- 在大多数典型的首领战斗中，这3秒足以规避坦克机制——例如，免疫爆发性的坦克打击，或避免坦克受到减益效果的施加。
- 要安全地实现这一效果：
  
  1. 在坦克机制即将到来之前（不到3秒），对首领使用[[spell:62124]]。
  2. 对自己使用[[spell:642]]或[[spell:1022]]。
  3. 等待首领施放你想要免疫的机制。
  4. 在[[spell:62124]]的效果结束之前，使用以下宏取消[[spell:642]]或[[spell:1022]]：

```wow-macro
/cancelaura 保护祝福  
/cancelaura 圣盾术
```

- 请记住，[[spell:1022]] 只能免疫**纯粹的物理攻击**。对于混合类型的机制，它只能抵消伤害中的**物理部分**，而对魔法伤害则**完全**无效。
- 注意，你只会对受到 [[spell:62124]] 影响的目标保持仇恨，因此该技巧只适用于单体目标的战斗。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下提示适用于 **英雄难度首领**，以及如何尽可能有效地在其中生存下来。本节推荐的配置会帮助你在每个遭遇战中存活，但不一定能给你最高的伤害输出。

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **防护 圣骑士 团队副本 内克扎莉**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA"
}
```
:::

#### 坦克机制

- 这场战斗的主要坦克机制是蚀空打击——首领每次近战攻击以及施放 [[spell:1284103]] 时都会施加的一种减益效果。
- 在 [[spell:1284103]] 期间，首领会向当前坦克发射幽灵回响，额外施加蚀空打击层数。这些回响在首次接触到任意玩家时会爆炸，对团队造成降低后的 
  
  - 当你成为该机制的目标时，走出团队，并确保你和首领之间没有任何人，以免他们过早触发回响。否则，回响会对团队造成过多伤害。
  - 每次 [[spell:1284103]] 施放完毕后进行嘲讽换坦。
- 此外，首领还会召唤成群的不安阿曼尼——务必将首领拉到它们旁边，以便更好地进行顺劈。
- 在过渡阶段，当前坦克会成为一次群体分担——[[spell:1289855]] 的目标。尽量将它放在尽可能多的不安阿曼尼尸体上，利用 [[spell:1289875]] 将其烧毁，防止它们再次苏醒。




### 陵寝哨兵

:::talents **防护 圣骑士 团队副本 陵寝哨兵**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMjZmZmxyYMmlxwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA"
}
```
:::

#### 坦克机制

- 由于 [[spell:1290189]]，首领们必须始终保持至少40码的距离。在每个阶段开始时，将首领们移到房间的不同两侧使其分开。
- [[spell:1284458]] 和 [[spell:1284487]] 是各个首领的叠加坦克减益效果。在 [[spell:1284588]] 期间，每当首领们在房间中央相遇时，务必进行嘲讽换坦以重置你的层数。
  
  - [[spell:1284487]] 额外会在到期时产生一个大型血泊。如果可能，请务必将其放置在房间的边缘。
- 不要将 乌拉特克之息 坦克在现有的血泊太近的位置，这样 [[spell:1284251]] 就不会在血泊中生成，近战职业就可以安全地攻击它。




### 迷失的探险者

:::talents **防护 圣骑士 团队副本 迷途的探险者**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA"
}
```
:::

#### 坦克机制

- 由于 [[spell:1297645]]，三个首领彼此都不能处于 30 码以内——始终让其中一个首领远离另外两个。
- 商人盖博 只会在房间里游荡，不会跟随或攻击其仇恨目标。它也没有任何坦克机制。
- 书卷贤者伊库 会对其当前目标施放 [[spell:1295854]]——一连串冰碎片，每片造成魔法伤害，并使后续碎片受到的伤害提高，持续 80 秒。
- 大副纳玛 每次攻击都会对其目标施加 [[spell:1291929]]，使该目标受到的物理伤害提高，持续 30 秒。
- 这场战斗中坦克的职责是在Scrollsage伊库和 大副纳玛 之间来回换坦，绝不让 [[spell:1295854]] 连续两次施放在同一目标身上，并尽可能频繁地重置 [[spell:1291929]]，同时始终让其中一个首领距离足够远，以防止 [[spell:1297645]] 被施加。




### 瓦什尼克

:::talents **防护 圣骑士 团队副本 瓦什尼克**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### 坦克机制

- 房间两侧放置着 3 座喷泉：鲜血之泉、火焰和 暗影。整场战斗中，首领会通过 [[spell:1283164]] 激活最近的两座喷泉，获得它们的力量并召唤一些小怪。
  
  - 每座喷泉被激活后，会使下一次激活强化 1.5 分钟。
  
  
  
  - 作为坦克，你的职责是通过在每次 [[spell:1283164]] 施放前将首领拉到下一座喷泉处，绝不让首领连续激活相同的两座喷泉。
  - 务必将首领定位在从喷泉出来的小怪上方，以便更好地顺劈。但是，要小心不要过快杀死所有火焰小怪，因为它们死亡时会施加可叠加的 [[spell:1285979]]。
- 瓦什尼克的坦克打击技能是 [[spell:1280935]]，每次施放后进行嘲讽换坦。

#### 通用技巧

- [[talent:102583@FAQAPreB]]配合天赋[[talent:128255]]可以直接穿透[[spell:1295224]]的治疗吸收护盾进行治疗，这对于帮助你的队友非常有用。




### 斯索拉克

:::talents **防护 圣骑士 团队副本 斯索拉克**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftNjtZZmZMzMzMWGjxswwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftNjtZZmZMzMzMWGjxswwAAMAAAAAAopZmlZGzMMGtBgBGgBbAAgZm2mZ2mZmZZbplZGL22YGAjxMMGAMzsNDwMDYsA"
}
```
:::

#### 战斗机制

- [[spell:1277025]] 是一组坦克正面机制的组合，由 2 次 [[spell:1277002]]、2 次 [[spell:1277027]] 和 1 次 [[spell:1287072]] 组成，以随机顺序施放。
  
  - [[spell:1277002]] 是一个正面锥形范围技能，造成高额物理伤害并跟随当前坦克。务必将其指向**远离团队**的方向。
  - [[spell:1277027]] 是一个正面锥形范围技能，会施加一个强力的魔法持续伤害效果，其效果会被锥形范围内被击中的人数所分摊减弱。务必将此技能指向团队的一半人马，让他们来分担。
  - [[spell:1287072]] 会在首领周围生成一群龙卷风，并在施法结束时将其向外发射。当此技能发生时，确保你不在首领下方，并躲避龙卷风。
  - 在英雄和史诗难度下，首领会以随机顺序施放这些技能。由于每个正面锥形技能都会施加来自该技能的伤害提高效果，务必确保同一个坦克绝不承受 2 次相同技能。请记住，你可以在施法期间嘲讽，让首领将正面锥形技能对准你。
- 每次施放 [[spell:1306120]] 都会在首领周围生成 [[spell:1305998]] 个水坑。务必将首领拉到房间边缘，理想情况下是与 [[spell:1285732]] 刷新点相对的一侧，这样水坑就会被风吹出房间边缘。
- 除此之外，斯索拉克 每次近战攻击都会施加一层 [[spell:1282869]]，使目标受到的物理伤害提高。在每次 [[spell:1277025]] 连击后进行嘲讽换坦就足以重置层数。




### 双牙

:::talents **防护 圣骑士 团队副本 双牙**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA"
}
```
:::

#### 通用机制

- 整场战斗的核心在于管理 [[spell:1290336]] 层数
  
  - [[spell:1291404]]、[[spell:1291478]]、被毒波命中或吸收 [[spell:1289201]] 都会施加一层 [[spell:1290336]]。
  - 在英雄难度下达到 10 层或史诗难度下达到 9 层会立即死亡。
  - 尽可能躲开毒波，同时控制好吸收 [[spell:1289201]] 的数量，以避免该减益效果达到最大层数，这一点至关重要。

#### 坦克机制

- 当你主动坦住的首领脱离近战范围时，它会施放 [[spell:1295107]] 或 [[spell:1295113]]，所以千万不要离开近战范围；如果发现自己离首领太远，请使用一个大型个人减伤。
- 维克苏尔 的坦克技能是 [[spell:1289192]]，造成自然伤害并将你击退 5 秒。
  
  - 它还会在你周围生成 [[spell:1289201]]。这些需要由玩家吸收，以免爆炸后给所有人叠加一层 [[spell:1290336]]。
  - 每次被击中都会施加 [[spell:1310360]]，因此每次 [[spell:1289192]] 施放后都要进行嘲讽换坦。
  - 注意击退效果，尤其是毒波即将到来的时候！
- 伊斯拉兹 会施放 [[spell:1288538]]，击退靠近首领的玩家并生成 3 个吸收区域。
  
  - 每个区域会造成高额物理伤害，并使下一个区域造成的伤害提高 33%。如果无人吸收该区域，它会对全团造成伤害并将所有人击飞。务必在每组 [[spell:1288538]] 之间进行嘲讽换坦，以重置伤害增加的层数。
  
  
  
  - 这些区域以随机顺序生成，并且必须按照生成的先后顺序依次吸收。在这一技能进行时，请密切关注区域的生成并记住生成顺序。首领在触发下一个区域前会短暂地面朝该区域的方向，所以如果你记不住生成顺序，可以参考首领的朝向。
  - 每隔一次 [[spell:1288538]] 施放都会与毒波重合——吸收 [[spell:1288538]] 时务必确保不被毒波击中。
  - 小心该机制开始时的击退，因为它可能把你推入袭来的毒波或某个 [[spell:1289201]] 中。




### 盘绕祭坛

:::talents **防护 圣骑士 团队副本 蟠蛇祭坛**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzMzDMzMzMWGjxsYZYAAGAAAAAA00MzyMjZGGj2AwADwgNAAwMTbzMbzMzsst0yMjFbYGAjxMMGAMzsNDwMDYsA"
}
```
:::

#### 第一阶段

- 在此阶段只有祖尔加处于激活状态。
- 他会施放[[spell:1299960]]，并在此阶段生成多个[[spell:1282403]]法球。它们存在期间会造成持续的团队范围范围伤害伤害，玩家可以跑入其中将它们拾起并移动。
- [[spell:1299684]]是一个瞄准当前坦克的正面锥形范围攻击，造成物理伤害并摧毁其命中的任何[[spell:1282403]]。
  
  - 它还会使下一次[[spell:1299684]]所受伤害提高200%，所以务必在每次施放后进行嘲讽换坦。
- 此阶段的目标是让团队将[[spell:1282403]]法球集中到一起，以便随后被[[spell:1299684]]摧毁。
  
  - **防护 圣骑士** 在非坦克期间特别适合收集法球，因为借助[[talent:102625]]拥有很高的机动性。
- 此外，每次施放[[spell:1282487]]都会使Boss接下来的23次近战攻击被[[spell:1300322]]强化，对坦克造成额外的自然伤害。 
  
  - 务必在Boss身上还带有[[spell:1300322]]层数时提前使用减伤技能。

#### 第二阶段

- 该阶段中只有 妖术领主玛拉卡斯 处于激活状态。
- 他会施放 [[spell:1285640]]，对被选中的玩家进行精神控制，并且每当精神控制被打断时，每名玩家会生成 2 个 [[spell:1285842]]。
  
  - 这些具象会锁定随机玩家并向其移动，除非被锁定的玩家回头面对该具象。
- 与第一阶段的 [[spell:1299684]] 类似，[[spell:1286620]] 是一个指向当前坦克的正面锥形技能，造成暗影伤害，并摧毁任何被它命中的 [[spell:1285842]]。
  
  - 它还会使下一次 [[spell:1286620]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
  - 此外，它会施加 3 层 [[spell:1286837]]，每层会生成一个灵魂碎片，必须拾取灵魂碎片才能移除对应的层数。如果在减益效果到期前没有清空层数，受影响的玩家会立即死亡。
  - 在每次坦克正面锥形技能之后，务必格外注意迅速找到并收集所有灵魂碎片。
- 被 [[spell:1286895]] 命中同样会施加 3 层 [[spell:1286837]]。千万不要掉以轻心！

#### 阶段转换

- 玛拉克里斯在施放 [[spell:1287685]] 期间受到的伤害提高100%。请务必将你的 [[talent:102466@AJgABA]] 和 [[talent:136496@FJQAEdhACEA]] 留到中场阶段使用！
- 不要让任何玛拉克里斯的碎片到达首领处，需要吸收它们以防止其治疗首领。
  
  - 吸收每块碎片会对全团造成 范围伤害 伤害，因此不要吸收得太快，给你的治疗者一些时间来应对即将到来的伤害。

#### 第三阶段

- 在该阶段中，祖尔加 和马拉克拉丝同时激活，并结合了第一阶段和第二阶段的技能。
- 该阶段中 [[spell:1299960]] 和 [[spell:1285640]] 都会出现，这意味着 [[spell:1282403]] 和 [[spell:1285842]] 都需要由坦克的正面锥形技能来清除。
- 该阶段的坦克正面锥形技能是 [[spell:1307279]]，造成暗影伤害，摧毁任何被它命中的 [[spell:1282403]] 和 [[spell:1285842]]，并施加 3 层 [[spell:1286837]]。
  
  - 别忘了收集你的灵魂碎片，并在每次锥形技能后进行嘲讽换坦！
- [[spell:1298381]] 是第一阶段 [[spell:1282487]] 的强化版本。
  
  - 在该阶段中，被强化的近战攻击还会额外施加可叠加的  暗影持续伤害。当层数较高时，请使用大型减伤技能。




### 乌拉特克

:::talents **防护 圣骑士 团队副本 乌拉特克**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLLjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYB"
}
```
:::




### 尼姆瑞莎·唤波者

:::talents **防护 圣骑士 团队副本 尼姆瑞莎·唤波者**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLzDMjZmZmZZZMGzilhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWstwMAGjZYMAYmZbGgZGwYBA"
}
```
:::

#### 通用机制

- 首领会用冰寒 冰霜 随机点名玩家，在其脚下生成 冰霜 法球。
  
  - 这些法球需要在爆炸导致团灭之前被吸收。
  - 吸收法球会施加一个可叠加的减益效果，增加吸收 冰霜 法球时所受的伤害，因此除非 [[spell:642]] 或 [[talent:111886]] 已就绪，否则不要一次性吸收太多。
  - 每次吸收法球还会对全团造成 范围伤害，因此不要吸收得太快，给你的治疗者一些时间来应对即将到来的伤害。
- 鱼人会不定期从水中出现，并开始走向房间中央的气泡。
  
  - 不要让它们到达气泡处，并尽可能将首领拉到它们上方，以便更好地进行顺劈输出。

#### 坦克机制

- 这场战斗中坦克专属的机制是冰刃连斩——一系列魔法斩击，每一斩都会增加后续斩击的伤害。
  
  - 每次施放时使用一个防御技能，并在每次结束后换坦嘲讽。





## 属性优先级

了解你作为**在团队副本中的次要属性优先级以及实现最佳表现所需的第三属性防护 圣骑士**。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **防护 圣骑士** 团队副本中的属性
```json
{
  "source_code": "JoAJFQAJoASMBEwAEA"
}
```
**力量 ＞ 急速 ＞ 全能 ≥ 暴击 ≫ 精通**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 极佳的属性，可减少\"**范围伤害**\"技能的伤害承受量。
- **吸血** - 通过造成伤害提供额外治疗。
- 加速 - 小众的第三属性，但可能非常有用，过去已被证明如此。能让应对某些机制变得轻松许多。

总体而言，**吸血**对坦克来说非常强力。**闪避**很棒，但大多数时候，坦克并不难以在典型的范围伤害技能下生存。

## 装备



### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | 将 [[item:239050@CiQAA8OuzVtOCKgTBA]]   <br> 转化为 [[item:271465@DiQBAIEAvj7cVrjgC4UAKX6A]] | 诸王之眠的催化器 |
| 项链 | [[item:268265@BERAAIEA-z64PrDj1kjAYFA]] | 乌拉特克 |
| 肩部 | 将 [[item:239037@DgQAAIEA1k7IoAOF]]   <br> 转化为 [[item:271463@DgQBAIEA1k7IoAOFQvlO]] | 塞塔里斯神庙 的催化器 |
| 披风 | [[item:268253@BgQAAIEACKAWBA]] | 盘卷祭坛 |
| 胸部 | 将 [[item:268222@DgQAAIEAJk7IoAYF]]   <br> 转化为 [[item:271468@DgQBAIEAJk7IoAYFgvXQ]] | 盘卷祭坛 的催化器 |
| 护腕 | [[item:237834@FiQAAIEAWA8ciqj_sO3WzSB]] | 专业制造 |
| 手套 | 将 [[item:251214@BgQAAIEACKgTBA]]   <br> 转化为 [[item:271466@BgQBAIEACKgTB4U1DA]] | 纳洛拉克的洞穴 的催化器 |
| 腰带 | [[item:268259@BiQAAIEA-z6IoAYF]] | 盘卷祭坛 |
| 腿部 | [[item:271878@DARAAIEAhu7YhN5IAWB]] | 乌拉特克 |
| 靴子 | [[item:237828@HgQAAIEA1V2ciqzD5O3WzSB]] | 专业制造 |
| 戒指1 | [[item:268266@DkQAAIEAvk74Prj_sOCKgTB]] | 尼姆瑞莎·唤波者 |
| 戒指2 | [[item:159459@DkQAAIEAvk74Prj_sOCKgTB]] | 诸王之眠 |
| 饰品1 | [[item:270164@BgQAAIEACKgTBA]] | 迷失的探险者 |
| 饰品2 | [[item:270173@BgQAAIEACKAWBA]] | 盘卷祭坛 |
| 武器 | [[item:268209@DgQAAIEA9k7IoAYF]] | 盘卷祭坛 |
| 盾牌 | [[item:268196@BgQAAIEACKgTBA]] | 迷失的探险者 |




### 可刷取的替代装备

以下是一份不错的可在魔兽世界每周锁定系统之外获取的可刷装备替代品列表。虽然随着你的进度推进它们终将被替换，但这些装备能立即提升你的角色实力。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:239050@BgQAAIEACKQQBA]] | 诸王之眠 |
| 颈部 | [[item:251173@BgQAAIEACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:239037@BgQAAIEACKQQBA]] | 塞塔里斯神庙 |
| 披风 | [[item:193763@BgQAAIEACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251193@BgQAAIEACKQQBA]] | 夺目谷 |
| 护腕 | [[item:159425@BgQAAIEACKQQBA]] | 塞塔里斯神庙 |
| 手套 | [[item:251214@BgQAAIEACKQQBA]] | 纳洛拉克的洞穴 |
| 腰带 | [[item:159418@BgQAAIEACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:273776@BgQAAIEACKQQBA]] | 毒牙祭坛 |
| 脚部 | [[item:273777@BgQAAIEACKQQBA]] | 毒牙祭坛 |
| 戒指 1 | [[item:159459@BgQAAIEACKQQBA]] | 诸王之眠 |
| 戒指 2 | [[item:273792@BgQAAIEACKQQBA]] | 毒牙祭坛 |
| 饰品 1 | [[item:158367@BgQAAIEACKQQBA]] | 塞塔里斯神庙 |
| 饰品 2 | [[item:250228@BgQAAIEACKQQBA]] | 密谋小径 |
| 武器 | [[item:251195@BgQAAIEACKQQBA]] | 夺目谷 |
| 盾牌 | [[item:159664@BgQAAIEACKQQBA]] | 塞塔里斯神庙 |





### 饰品

以下是从地下城和团队副本中可获得的后毕业阶段饰品的排名。请注意，上文推荐的饰品是以伤害最优为目标的；如果你不在乎伤害、只想活下去，建议使用类似 [[item:270160@BgQAAIEACKgTBA]] 这样的饰品。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAIEACKgTBA]]  <br>[[item:270173@BgQAAIEACKAWBA]] |
| **A级** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:158367@BgQAAIEACKgTBA]]  <br>[[item:270174@BgQAAIEACKgTBA]]  <br>[[item:270160@BgQAAIEACKgTBA]]  <br>[[item:250228@BgQAAIEACKgTBA]] |
| **B级** | [[item:270175@BgQAAIEACKAWBA]]  <br>[[item:250243@BgQAAIEACKgTBA]]  <br>[[item:159618@BgQAAIEACKgTBA]]  <br>[[item:270168@BgQAAIEACKgTBA]]  <br>[[item:250229@BgQAAIEACKgTBA]]  <br>[[item:193762@BgQAAIEACKgTBA]] |
| **C级** | [[item:273796@BgQAAIEACKgTBA]]  <br>[[item:270163@BgQAAIEACKgTBA]]  <br>[[item:273795@BgQAAIEACKgTBA]]  <br>[[item:250259@BgQAAIEACKgTBA]]  <br>[[item:250244@BgQAAIEACKgTBA]]  <br>[[item:193757@BgQAAIEACKgTBA]] |
| **垃圾级** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:250245@BgQAAIEACKgTBA]]  <br>[[item:250238@BgQAAIEACKgTBA]]  <br>[[item:273797@BgQAAIEACKgTBA]] |

### 美化饰品

- 2 个 [[item:240167]] 是你的最佳毕业选择。
  
  - 为你和你的队友提供随机主属性触发效果。
  - 最好制作在护腕和靴子上；不过，它也可以制作在任何一件护甲部位上。

在赛季初期，或者当你无法获得 334 或 344 装等的武器时，一个不错的选择是制作一把 331 装等的武器[[item:245876]]，而不是用 [[item:240167]] 制作散件。一旦你能获得 334 或 344 的武器，这个选择相比 2 个 [[item:240167]] 就会失去价值。

- [[item:245876]]
  
  - 被动提供次要属性 ，具体取决于你正在与之作战的怪物类型。
  - 必须制作在武器上。

#### 剩余的火花

- 制造业装备为 331 装等，而普通装备的最高装等为 334；因此，除了 2 件装饰品之外，装备制造业装备会有少量损失，除非你在该部位没有其他高装等的装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药水（合剂）**
  
  - [[item:241324]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器磨刀石/油**
  
  - [[talent:117881]] *-- 作为 [[talent:123361]]*
  - [[item:243734]]-- 作为 [[talent:123358]]
- **强化符文**
  
  - [[item:259085@BQAAAIEAaB]]
- **宝石插槽**
  
  - [[item:240983]] *-- 唯一，只能使用一次*
  
  
  
  - [[item:240894]]
  - [[item:240916]]

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 护腕 | [[item:275707@BAAAAIE]] |
| 腰带 | [[item:275707@BAAAAIE]] |
| 腿部 | [[item:244641@BAAAAIE]] |
| 靴子 | [[item:243983@BAAAAwQA]] |
| 戒指1 | [[item:244015@BAAAAIE]] |
| 戒指2 | [[item:244015@BAAAAIE]] |
| 武器 | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **防护 圣骑士** **大秘境**
```json
{
  "source_code": "IQFZCBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *你购买[[item:275707@BAAAAIE]] 从宏伟宝库商人处购买，以为你的头盔、护腕和腰带添加插槽*.

## 种族

在本节 **防护 圣骑士** 团队副本 指南中，我们将展示并解释某些种族天赋在《魔兽世界》中能产生多大影响：

- [[spell:65116]] —— ***矮人***
  
  - [[spell:59224]] 提供2%爆击伤害和治疗效果，对 **防护 圣骑士** 来说非常强力。
  
  
  
  - 其价值在于你可以驱散自己或移除危险的流血效果。
  - 提供10%物理减伤，作为坦克相当于一个持续8秒的小型额外个人减伤技能。
- [[spell:25046]] —— 鲜血 精灵
  
  - 强力的种族技能，可用于驱散或净化敌人，其价值较为有限，但有时能派上用场。
- [[spell:20549]] —— 牛头人
  
  - 强力的 范围伤害 昏迷，可用作打断，持续2秒。
  - [[spell:154743]] 提供2%爆击伤害和治疗效果

### 推荐

我几乎总是选择矮人，因为他们是综合进攻能力最强的种族（与牛头人并列），同时由于**[[spell:65116]]**能够移除棘手的减益效果，他们在防御方面也是最强的。

## 宏

探索**防护 圣骑士**的推荐宏，并观看一段关于为你的角色创建简单宏的快速视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
**鼠标指向嘲讽** --- *[[spell:62124]]（嘲讽）的鼠标指向宏，让你无需切换目标即可轻松对刚刚进入视野或刷新的敌人建立仇恨。如果没有鼠标指向目标，则嘲讽你的当前目标。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]清算之手
```

1号首领嘲讽 --- *对1号首领施放 [[spell:62124]]*

```wow-macro
/cast [@boss1] 清算之手
```

2号首领嘲讽 --- *对2号首领施放 [[spell:62124]]*

```wow-macro
/cast [@boss2] 清算之手
```

:::

:::details 鼠标指向宏
**自由祝福鼠标指向宏** --- *用于对队友施放自由祝福的鼠标指向宏（请不要对自己使用，因为它的效率不如下一个宏）*

```wow-macro
#showtooltip
/cast [@mouseover] 自由祝福
```

**牺牲祝福鼠标指向宏**--- *可以让你快速为他人提供减伤（外部减伤）的牺牲祝福鼠标指向宏。*

```wow-macro
#showtooltip
/cast [@mouseover] 牺牲祝福
```

**[[spell:85673]] 鼠标指向宏** --- *对队友使用 荣耀圣令 的鼠标指向宏，与自由祝福一样，请不要对自己使用，因为它的效率较低。*

```wow-macro
#showtooltip 荣耀圣令
/cast [@mouseover] 荣耀圣令
```

**圣疗术 鼠标指向** --- *鼠标指向宏，对友方目标使用圣疗术。*

```wow-macro
#showtooltip 圣疗术
/cast [@mouseover] 圣疗术
```

**清毒术 鼠标指向宏** --- *对队友施放驱散的鼠标指向宏。*

```wow-macro
#showtooltip 清毒术
/cast [@mouseover] 清毒术
```

:::

:::details 焦点目标宏
**焦点目标宏** --- *将鼠标指向的目标设为你的焦点目标*

```wow-macro
/focus [@mouseover,exists]
```

**焦点打断** --- *此宏会对*  你的焦点目标施放 "责难" 或进行打断。如果你的焦点目标超出范围或你没有焦点目标，它也会打断你的当前目标。非常适用于日常玩法的可靠宏。

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] 责难
```

**专注[[spell:31935]]** --- *如果你需要对焦点目标进行打断或沉默，此宏会将你的[[spell:31935]]施加到焦点目标上*

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] 复仇者之盾
```

:::

:::details 实用宏
**取消增益宏** --- *这是一个非常重要的宏，你需要根据具体场景填入任何需要取消的免疫类增益效果。例如：[[spell:642]] 嘲讽失败、未能嘲讽住敌人时，你需要取消 [[spell:642]]；或者你使用了 [[spell:1022]] 来快速移除某个减益效果，之后需要取消它，以便在队友承接坦克职责之前继续担任主要仇恨目标。* 至于 [[spell:204018]]，有时当你受到 [[spell:204018]] 保护时，某些怪物会无法对坦克执行其主要威胁技能，不过这种情况比较罕见。

```wow-macro
/cancelaura 保护祝福
/cancelaura 破咒祝福
/cancelaura 圣盾术
```

:::

:::details 玩家宏
[[spell:85673]] 对自己施放--- *此宏会对你自己施放 [[spell:85673]]，当你想将 [[spell:85673]] 作为自我治疗时非常高效。我建议为 [[spell:85673]] 设置两个按键绑定，就像 自由祝福 一样。*

```wow-macro
#showtooltip 荣耀圣令
/cast [@player] 荣耀圣令
```

**对自己施放自由祝福** --- *这个宏会立即对自己施放自由祝福，在按键速度上比对自己使用鼠标指向宏更高效。一般来说，为自由祝福设置两个按键绑定是好的做法，一个用于鼠标指向，一个用于玩家（自己），这样效率会高得多。*

```wow-macro
#showtooltip 自由祝福
/cast [@player] 自由祝福
```

**圣疗术 自己** --- *你应该使用这个宏来将 圣疗术 作为"自我治疗"使用。*

```wow-macro
#showtooltip
/cast [@player] 圣疗术
```

**清毒术 自我** --- *这个宏应用于驱散你自己，因为它的效率更高。*

```wow-macro
#showtooltip 清毒术
/cast [@player] 清毒术
```

:::

:::

## 插件

下 面是 作者针对 **防护 圣骑士**的界面截图，其中概述了所使用的插件，以及它们在团队副本中如何使用，从而让你的游戏体验更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/pala-1024x623.png>)

**防护 圣骑士** 界面

:::accordion
:::details 插件
- EllesmereUI
  
  - 一款以易用性为核心设计的用户界面，附带标准界面中不包含的额外功能。
- **BigWigs** 
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些迷你插件旨在为某一个特定的 团队副本 战斗触发警报消息、计时条、音效等内容。

:::

:::

:::accordion


:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 职业
  
  - 黄金之路的治疗效果提高25%。
  - 光铸祝福的治疗效果提高25%。
  - 启蒙之光的治疗效果提高25%。
- **[[talent:123361]]**
  
  - 祝福仪式的治疗效果提高25%。
  - 神恩指引 重新设计——每施放一次 神圣 之力的技能，你的下一个 奉献 会立即造成 神圣 伤害，由所有敌人分摊。最多3名附近盟友各自获得相当于总伤害一定百分比的治疗。
  - 圣眷在握 现在使你的下一个 祝福之锤 或 正义之锤 的伤害和治疗量提高100%（原为200%）。
- 防护
  
  - 新天赋：祝福圣言——荣耀圣令 无法再造成爆击，但其治疗量会随着你的爆击几率而提高，并且其对自身造成的过量治疗的80%会转而使你沐浴圣光之中，获得一个吸收护盾。
  - 强化的 炽热防御者 已重新设计——现在激活时使最大生命值提高20%，且在承受致命伤害时不再取消剩余持续时间。
  - 报复之印已重新设计——祝福之锤 使敌人对你造成的伤害降低10%，持续8秒。
  - 大师杰作 已更新——在施放 神圣 武装后，你的下3次 正义之锤/祝福之锤/十字军打击施放会为一名附近盟友赋予同类的次级武装。
  - 审判 伤害提高51%。
  - 奉献 伤害提高100%。
  - 正义盾击 伤害提高150%。
  - 正义之锤 初始伤害提高50%。
  - 复仇之怒 使造成的伤害和治疗量提高10%，爆击几率提高10%。
  - 复仇者之盾 伤害提高30%。
  - 次级武器伤害提高50%。
  - 圣光之锤 伤害降低33%。
  - 苍穹之锤 伤害降低33%。
  - 槌砧战术 伤害降低20%。
  - 神圣之征 的 圣洁鸣钟 效果降低至80%（原为150%）。
  - 戒卫 持续时间延长至20秒。
  - 强力 审判 的负面效果现在持续18秒（原为15秒）。
  - 远古列王守卫 现在有8秒的初始冷却时间。
  - 不灭余烬为你恢复的生命值相当于精炼 火焰 所造成伤害的125%（原为100%）。
  - 秩序壁垒的吸收量提高至 复仇者之盾 伤害的75%（原为60%）。
  - 抚慰使 奉献 为你恢复的生命值相当于其所造成伤害的375%（原为300%）。
  - 正义 狂怒 壁垒现在每层使你的下一个 正义盾击 伤害提高10%（原为20%）。
  - 圣洁武器 和 神圣壁垒 在被同一施法者重新施加时会延长持续时间。
  - 先锋 的荣耀现在造成的伤害为 复仇者之盾 初始伤害的一定百分比。
  - 戒卫 现在继承 复仇之怒 的爆击加成。
  - 英勇十字军不再在死亡时取消。
  - 光辉映象 的触发几率已大幅降低。
  - 强化的 炽热防御者 现在会施加一个负面效果，用于标示何时承受了致命伤害。
  - 圣光之锤、圣洁共鸣、神圣十字军、秩序壁垒、以太结界、逆境搏力 以及报复之印现在可以通过冷却时间管理器进行追踪。
  - 修复了权威 责难 错误地通过复仇者之盾的施放降低 责难 冷却时间的问题。
  - 修复了神圣器物导致 正义盾击 以错误数量延长 戒卫 层数的问题。
  - 修复了加速祈使错误地降低 神圣军备 冷却时间的问题。
  - 修复了将敌人击至空中的技能可能导致 先锋 的荣耀额外多次造成伤害的问题。
  - 修复了在两次直接施放 奉献 之间施放 圣光之锤 可能使 奉献 超出上限的问题。
  - 许多天赋在天赋树中的位置发生了变化。
  - 圣洁怒火已被移除。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我总是死亡？
我能给出的最大建议是：在任何情况下都要弄清楚你为什么会死亡，以及你可以如何改进。坦克这份职责很艰难，你始终有机会更好地运用外部辅助、循环和减伤技能。录制你的游戏过程并查看 Warcraft Logs 是很好的方法。成为一名优秀的坦克需要认知上的灵活性——专注于思考自己本可以做得更好，而不是责怪他人。这种心态对于成为更好的坦克来说更有回报，也更有益于身心健康！

:::

:::

---

### 致谢

作者：**Tief**

审校：**Meeres**

---

:::changelog 更新记录
**2026-08-06** 已更新至12.1版本

**2026-06-21** 已更新至12.0.7版本

**2026-04-26** 已更新至12.0.5版本

**2026-02-21** 已更新至12.0.1版本

**2026-01-16** 已更新至12.0版本

**2025-12-01** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-07-30** 已更新至11.2版本

**2025-06-18** 已更新至11.1.7版本

**2025-04-20** 已更新至11.1.5版本

**2025-02-25** 已更新至11.1版本

**2024-12-17** 已更新至11.0.7版本。

**2024-10-26** 已更新至11.0.5版本。

**2024-08-17** 已更新至11.0.2版本

**2024-07-28** 攻略编写于11.0版本。



:::
