欢迎来到魔兽世界12.1版本的**神圣 牧师** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是从80级开始升级的新手吗？快去看看升级攻略吧！

## 概述

:::columns
:::column
:::rating 团队副本
**整体治疗** · 4/5 · 强

冷却技能强度 · 3/5 · 一般

功能性 · 4/5 · 强

生存能力 · 4/5 · 强

机动性 · 1/5 · 较弱



:::

:::

:::column
:::gear **神圣 牧师** 团队副本 最佳装备（BiS）
```json
{
  "source_code": "JEpAwbVABc__BEgAmQgAREAAvj7AJ16AC06ACKgF2gVABk-FEAQEBAgEtOg-sOggCwYNYFQABTCBCgQAAUTuDIoAOFQAGTCBCgQAAMSuDIoAOFQAATCBAiQAAwQADxgTBEgwJ4BBboaCeQw3XUAPA8QA8wHWBEAIoOAhIEAAeA8Ano6AM06A3WzSBEAxkQAAIEAACGQIg4paCIICBAQ94GgHF8GCAU9A6IBAEI1HNADDOFQAU1BDE09FNgBKYFQA0LCBCgQAAMQD4RTCAPAB4EAA0B8AeA8AA0RAMcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240969]] · [[item:240898]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240914]] · [[item:240890]] |
| 肩部 | [[item:271553]] | [[item:244021]] |
| 胸部 | [[item:271558]] | [[item:244003]] |
| 腰部 | [[item:271552]] | [[item:240908]] |
| 腿部 | [[item:271554]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240908]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:251136]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270162]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243971]] |
| 副手 | [[item:245769]] | [[item:245876]] · [[item:245790]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**神圣 牧师**，你可以使用祝福，它有几率将你的[[spell:2061]]变为更强大的版本。

**等级2**和**等级3**使你的所有治疗效果提高12%，[[spell:243241]]治疗效果提高30%。

**等级 4** 确保 [[spell:64843]] 触发 [[spell:243241]] 的祈福效果，并通过其触发效果增强你的技能。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-holypriest-mxr.webp>)

祝福

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:103762]]
    
    - 你的爆击效果造成220%的伤害。
  
  
  
  - [[talent:103733]]
    
    - 极大地强化你的[[talent:103775@FAQA1UwE]]，但会移除[[talent:103766]]。
- **已移除**
  
  - [[spell:391387]] 
    
    - 这会导致[[talent:103748@FAQADh5A]]的覆盖率大幅降低。

## 英雄天赋

- [[talent:123291]]专注于爆发式的治疗输出，而[[talent:123290]]则专注于增强你的持续治疗输出并为团队提供功能性。
- 本攻略推荐游玩[[talent:123291]]，因此只涵盖该英雄天赋选项。

:::tabs
:::tab [[talent:123291]]
- 施放[[spell:120517]]时，你还会周期性地产生更多回旋飞回你身边的 halo。它们会被以下节点增强，并为你提供特定收益：
  
  - [[talent:117284]]
    
    - 产生多个[[spell:120517]]。
  - [[talent:117279]]
    
    - 为被[[spell:120517]]光环环击中的任何队友施加一个受到的治疗量提高的增益。
  - [[talent:117281]]
    
    - 大幅提升每个[[spell:120517]]的效果。
  - [[talent:117305]]
    
    - [[spell:120517]]在到达最大距离后回旋飞向你。

:::

:::tab [[talent:123290]]
- [[talent:123290]] 主要强化你的 [[spell:33076]]。
  
  - [[talent:117286]]
    
    - 给予你 2 层 [[spell:33076]]。
  - [[talent:117282]]
    
    - 降低 [[spell:33076]] 的基础冷却时间。
  - [[talent:117276]]
    
    - 立即为你的 [[spell:33076]] 目标恢复大量生命值。

:::

:::

## 天赋

:::tabs
:::tab 通用 团队副本 天赋
:::talents **神圣 牧师** 团队副本 天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 何时使用该专精

这是进入任何首领战时的默认配置，除非另有说明。你需要根据战斗所需的团队功能来调整职业天赋树。为了让你的操作更轻松，团队副本章节中提供了针对各首领的专用天赋配置。

### 改变游戏玩法的天赋

探索专精和职业天赋树中显著改变你游戏方式的所有天赋。本节将简明概述这些天赋及其应用，如需更详细的了解，请查看下方的循环和深度解析部分。

#### 专精树

- [[spell:235587]]
  
  - 此天赋为你的治疗神圣言额外提供一层充能。这提升了**神圣 牧师** 核心冷却缩减机制的价值，因为你可以保留一层充能以备紧急情况而不损失价值。
- [[spell:391124]]
  
  - 免死效果。
- [[spell:392988]]
  
  - 在每次施放神圣言后召唤一个纳鲁。该纳鲁会因你施放的每个神圣言而获得强化，但强化效果只会持续很短的时间。
- [[talent:103733]]
  
  - 大幅增强你的[[talent:103775@FAQA1UwE]]，并使所有影响[[talent:103766]]的天赋同时也作用于[[talent:103775@FAQA1UwE]]。

#### 职业树

- [[spell:459559]]
  
  - 将你的法术距离提升至46码，如果使用得当，这是一个非常强大的工具。这使你即使在团队副本分散时也能触及队友。
- [[spell:109186]]
  
  - 此天赋对法力管理和移动能力帮助很大，为你在移动中提供了一个额外的恢复手段。
- [[spell:336897]]
  
  - 当你对队友施放此技能时，你也会获得[[spell:10060]]的效果。
- [[spell:193063]]
  
  - 与[[spell:368276]]和[[spell:109186]]搭配时，此天赋为你提供一个易于获得的10%减伤。
- [[talent:103835]]
  
  - 为**牧师**职业工具库添加了一个新的但较弱的防御技能。不过，当与[[spell:193063]]搭配时，它可能救你一命！

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** 每个受到你的‍恢复术‍影响的目标使你的爆击几率提高2%，最多可达6%。
- **4件套：** ‍恢复术‍的治疗效果提高10%。‍圣光回响‍现在有100%的几率在‍愈合祷言‍治疗的第一个目标身上留下一个‍恢复术‍。

### 优先级列表

1. 如果有2层充能，则施放[[spell:2050]]。
2. 施放 祝福 在[[talent:103868@FAgAHdhAKfwE]]未激活时。
3. 如果有范围伤害治疗需要完成，则施放[[spell:596]]。
4. 施放[[spell:2050]]。
5. 在移动公共冷却时施放[[talent:103870]]。
6. 在移动公共冷却时施放[[spell:33076]]。

### 冷却技能

#### 神圣赞美诗

- 虽然与其他冷却技能相比，这个法术的数值表现并非最佳，但其真正的强大之处在于引导期间逐渐叠加的全团队受治疗量增加增益。当与强大的团队治疗冷却技能配合时，[[talent:103755]]可以成为最强大的治疗冷却技能之一。

#### 神圣化身

- 这是你最强大的冷却技能，务必查阅攻略了解在每个首领战中的使用时机。

## 深度解析

#### 极限优化 能量灌注

- 虽然 [[spell:10060]] 是你自己的技能，但最佳的使用方式是优先考虑队友的收益而非你自己的。为此，请与队友沟通，让他们在确切需要的时刻向你提出请求。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 毒噬深渊

以下提示主要适用于英雄难度首领。史诗难度提示将在我们的开荒进度结束后发布。

:::tabs
:::tab 内克扎莉
:::talents **神圣 牧师** 内克扎莉 团队副本天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 在房间边缘驱散中了 [[spell:1287322]] 的队友！
- 当首领施放 [[spell:1284103]] 时，不要站在首领和坦克之间。

:::

:::tab 陵寝哨兵
:::talents **神圣 牧师** 陵寝哨兵 团队副本天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 驱散受到 [[spell:1284471]] 影响的玩家。
- [[spell:1284590]] 在恰好达到 4 层时会被无害地中和。

:::

:::tab 迷失的探险者
:::talents **神圣 牧师** 团本中迷途探险者的天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 驱散受到 [[spell:1286921]] 影响的玩家。

:::

:::tab 瓦什尼克
:::talents **神圣 牧师** 团本中瓦什尼克的天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 对受到 [[spell:1295224]] 影响的玩家使用单体技能（外部增益）。在受影响期间，他们免疫你的常规治疗。
- 受到 [[spell:1294994]] 影响时请使用个人减伤。

:::

:::tab 斯索拉克
:::talents **神圣 牧师** 斯索拉克 团队副本天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 对受到 [[spell:1286987]] 影响的玩家使用单体技能（外部增益）。

:::

:::tab 双牙
:::talents **神圣 牧师** 双牙团本天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 当你受到 [[spell:1290809]] 影响时，使用个人防御技能。

:::

:::tab 盘绕祭坛
:::talents **神圣 牧师** 盘绕祭坛团本天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。

:::

:::tab 乌拉特克
:::talents **神圣 牧师** 乌拉特克 团队副本天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。

:::

:::tab 尼姆瑞莎·唤波者
:::talents **神圣 牧师** 团本中的 尼姆瑞莎·唤波者 天赋
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### 首领攻略技巧

- 当大量 [[spell:1257717]] 被触发时，使用个人防御技能。

:::

:::

## 属性优先级

了解你作为**神圣 牧师**在团队副本首领战中发挥最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问**[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **神圣 牧师** 团队副本中的属性优先级
```json
{
  "source_code": "IoAJFUAIoEDJBMwABA"
}
```
**智力 ＞ 暴击 ≥ 全能 ≥ 精通 ＞ 急速**
:::

> 此处的结论是，你通常应当装备装等最高的装备。

- 所有次要属性都会受到**收益递减**的影响。[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)了解更多！

### 第三属性

- **闪避** - 减少受到的范围伤害效果伤害。
- **吸血** - 将你造成伤害和治疗的一部分转化为对你的治疗。（不包括自我治疗）
- **加速** - 提高移动速度。（可与其他移动速度技能叠加）

唯一需要考虑选择较低装等装备的情况，是它带有吸血或闪避属性时。加速也不错，但在两件装备之间抉择时不应考虑该属性。

- 这里展示吸血对治疗者来说有多强大：史诗弗拉希乌斯数据分解。

![](<https://assets-ng.maxroll.gg/wordpress/MyUb2Ci-1024x491.png>)

魔兽世界战斗日志

## 装备

:::tabs
:::tab 最佳配装
由于 **神圣 牧师** 的属性权重运作方式，并不存在严格意义上的最佳配装（BiS）列表。尽管理论上有可能获得所有第三属性都正确的装备，但由于《魔兽世界》的每周重置机制，这需要极佳的运气或好几辈子的时间。

| 部位 | 物品 | 来源 |
| --- | --- | --- |
| 头部 | [[item:271874@DERAAEQAvj7kUrjAtOCKgF2gVA]] | 乌拉特克 |
| 颈部 | [[item:268265@BERAAEQAS06oPrjgCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:271553@DgQAAEQA1k7IoAOF]] | 套装/催化剂 |
| 披风 | [[item:268253@BgQAAEQACKAWBA]] | 盘蛇祭坛 |
| 胸部 | [[item:271558@DgQAAEQAjk7IoAOF]] | 套装/催化剂 |
| 腕部 | [[item:239648@FiQAAEQAeA8ciqDDtO3WzSB]] | 制造业 |
| 手套 | [[item:271556@BgQAAEQACKAWBA]] | 套装/催化剂 |
| 腰带 | [[item:271552@BiQAAEQAM06IoAOF]] | 套装/催化剂 |
| 腿部 | [[item:271554@DgQAAEQAbo6IoAOF]] | 套装/催化剂 |
| 脚部 | [[item:268255@DgQAAEQAPk7IoAYF]] | 盘蛇祭坛 |
| 戒指 1 | [[item:158366@DiQAAEQA1j7wQrjgC4UA]] | 神庙 |
| 戒指 2 | [[item:251136@DiQAAEQA1j7wQrjgC4UA]] | 密谋小径 |
| 饰品 1 | [[item:270162@BgQAAEQACKgTBA]] | 内克扎莉 |
| 饰品 2 | [[item:270164@BgQAAEQACKgTBA]] | 迷失的探险者 |
| 武器 | [[item:271092@DgQAAEQADk7IoAYF]] | 乌拉特克 |
| 副手 | [[item:245769@FgTAAEQA0B84BwDAAAAAAAAAAAAAAAwt1sUA]] | 制造业 |

#### 作者的话：

此列表展示了来自所有来源、在团队副本中治疗表现最佳的物品。请注意，获得带有吸血 / 闪避的不同套装部件会改变哪件散件对你来说最好。同样地，任何其他带有吸血 / 闪避的非饰品物品都可以替换此处建议的装备。

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251199@AgQAAIoABFA]] | 夺目谷 |
| 项链 | [[item:251234@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 肩部 | [[item:251227@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 披风 | [[item:251132@AgQAAIoABFA]] | 密谋小径 |
| 胸部 | [[item:239032@AgQAAIoABFA]] | 神殿 |
| 护腕 | [[item:251154@AgQAAIoABFA]] | 巢穴 |
| 手套 | [[item:273773@AgQAAIoABFA]] | 毒牙祭坛 |
| 腰带 | [[item:159255@AgQAAIoABFA]] | 神殿 |
| 腿部 | [[item:159234@AgQAAIoABFA]] | 诸王之眠 |
| 靴子 | [[item:159259@AgQAAIoABFA]] | 神殿 |
| 戒指 1 | [[item:158366@DiQAAEQA1j7wQrjgCEUA]] | 神殿 |
| 戒指 2 | [[item:251136@DiQAAEQA1j7wQrjgCEUA]] | 学院 |
| 饰品 1 | [[item:250214@AgQAAIoABFA]] | 学院 |
| 饰品 2 | [[item:250215@AgQAAIoABFA]] | 密谋小径 |
| 双手武器 | [[item:193761@AgQAAIoABFA]] | 红玉新生法池 |
| 单手武器 | [[item:251225@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 副手 | [[item:271681@AgQAAIoABFA]] | 纳洛拉克的洞穴 |

:::

:::

### 饰品

下面你可以找到可用饰品的主动与被动排名。请注意，根据每个首领战的不同，某些饰品会比其他饰品表现更好。

| 排名 |  |
| --- | --- |
| S级 | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A级** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **B级** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **垃圾级** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### 美化饰品

- [[item:245876]] 
  
  - 属性武器附魔效果非常强力，根据你攻击的目标提供大量的某一二级属性。
- [[item:239664@BiQAAEQA6z6IyLdE]]
  
  - 属性数值严重超模的属性武器附魔。

#### 剩余的火花

- 制造装备的物品等级为331，普通装备的最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则在2件美化装备之外再装备制造装备并无收益。

## 消耗品

- **药水（合剂）**
  
  - [[item:241326]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241300]] *-- 推荐*
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@BQAAAEEAaB]]
- **宝石插槽**
  
  - [[item:240908]]
  - [[item:240969]] *--* *独特，使用各色宝石各一枚来强化你的 ⟪0⟫。*
    
    - [[item:240898]]
    - [[item:240914]]
    - [[item:240890]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAAEQA]]  <br>[[item:243951]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAkG]] |
| 胸部 | [[item:243977]] |
| 手腕 | [[item:275707@BAAAAEQA]] |
| 腰带 | [[item:275707@BAAAAEQA]] |
| 腿部 | [[item:240155@BAAAAkG]] |
| 脚部 | [[item:243983@BAAAAkG]] |
| 戒指1 | [[item:243987@BAAAAEQA]] |
| 戒指2 | [[item:243987@BAAAAEQA]] |
| 武器 | [[item:244029@BAAAAEQA]] |

:::

:::column
:::gear **神圣 牧师** 附魔
```json
{
  "source_code": "IQFZBEQ9NCQAvj7ACAAAAktBEEQN5OAAAAAABkQDIgQ2GQQBQQwGqmAGA8gOYAAAT0AEoMRuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:243951]] | [[item:263897]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:263897]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:263897]] |  |
| 戒指一 | [[item:243987]] |  |
| 戒指二 | [[item:243987]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> 你可以在宏伟宝库商人处购买 [[item:275707@BAAAAEQA]] 来为你的头部、护腕和腰带添加插槽。

## 种族

若要在史诗团队副本中对 **神圣 牧师** 进行极限优化（min-max），不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族同样可行。

- [[spell:69070]] *-- 地精* 
  
  - 向前跳跃，可在下落或被击退时施放。
- [[spell:256948]] *--* *虚空精灵* 
  
  - 生成一个朝你面朝方向前进的暗影，再次激活可传送至其位置。
  - 最大距离为100码。

### 推荐

强烈建议玩龙希尔！**牧师** 的移动速度可能相当缓慢，而二段跳带来的额外机动性在那些棘手的处境中真的非常有用。

## 宏

探索为 **神圣 牧师** 推荐的宏，并观看一段关于为你的角色创建简单宏的快速视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
为方便使用，本 **神圣 牧师** 团队副本 攻略中的所有法术均提供鼠标指向宏！

[[spell:33076]]

```wow-macro
/cast [@mouseover, help] 愈合祷言; 愈合祷言
```

[[spell:2050]]

```wow-macro
/cast [@mouseover, help] 圣言术：静; 圣言术：静
```

[[spell:596]]

```wow-macro
/cast [@mouseover, help] 治疗祷言; 治疗祷言
```

[[spell:2061]]

```wow-macro
/cast [@mouseover, help] 快速治疗; 快速治疗
```

[[spell:10060]]

```wow-macro
/cast [@mouseover,exists] 能量灌注; 能量灌注
```

[[spell:73325]]

```wow-macro
/cast [@mouseover, help] 信仰飞跃; 信仰飞跃
```

[[spell:47788]]

```wow-macro
/cast [@mouseover, help] 守护之魂; 守护之魂
```

:::

:::details 推荐宏
如果你在使用这个宏时按下 Shift，[[spell:121536]] 会自动放置在你脚下，省去 Ctrl 点击的步骤。

```wow-macro
/cast [mod:shift, @player] 天堂之羽; 天堂之羽
```

如果你愿意，可以替换你的[[spell:527]]宏。这个宏的作用是：如果你以敌人为目标就驱散敌方魔法，如果以队友为目标就驱散友方负面效果，为你节省一个按键绑定。

```wow-macro
#showtooltip 纯净术
/use [@mouseover, help] 纯净术; [harm] 驱散魔法; [noharm] 纯净术
```

你的[[spell:32375]]在按下按钮时无需确认点击就会立即施放，请谨慎使用。

```wow-macro
#showtooltip
/cast [@cursor] 群体驱散
```

一个不错的 **牧师** 专用宏，懂的都懂。

```wow-macro
/cast [nomod] 漂浮术
/cancelaura [mod:shift] 漂浮术
```

:::

:::

## 插件

下面是作者的 **神圣 牧师** 用户界面截图，其中说明了使用了哪些插件，以及它们在团队副本中如何运用，从而让你的游戏过程更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/xMsr1We-1-1024x576.webp>)

**神圣 牧师** 团队副本 用户界面

:::accordion
:::details 插件
- EllesmereUI —— 全能
  
  - 用于升级暴雪自带 UI 的插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 神圣
  
  - 神圣赞美诗 已更新——现在在引导期间额外提供 守护之魂。
    
    - *开发者注：我们正在为引导 神圣赞美诗 增加一项收益，使其更易于使用。如果你身上已有 守护之魂 生效，神圣赞美诗 将为其持续时间增加5秒。如果 神圣赞美诗 的引导提前结束，则会从其增加的时间中扣除剩余的部分。*
  - 顶尖天赋：祝福（第3级）已更新——神圣化身 不再将 快速治疗 升级为祝福。圣言术：静 现在有100%的几率将你的下一个 快速治疗 升级为祝福。
  - 顶尖天赋：祝福的法力消耗降低30%，治疗量提高15%。
    
    - *开发者注：我们希望通过让祝福的获取途径超越 神圣化身 和 愈合祷言 来调整其表现。此外，我们正在提高祝福的输出量，使其效果更加显著，并为 神圣 的整体输出做出更多贡献。最后，我们希望通过专门针对 快速治疗 和 治疗祷言 来进一步降低 神圣 循环的高昂消耗。*
  - 所有治疗量提高16%。
  - 快速治疗 的法力消耗降低10%。
  - 治疗祷言 的法力消耗降低10%。
  - 神圣化身 现在使 神圣 言的法力消耗降低70%（原为50%）。
- 英雄天赋
  
  - 执政官
    
    - 共振能量 进行了轻微重做——制造一个 光晕 使造成的治疗提高2%，持续10秒，最多可叠加4次。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我总是死亡？
答：开始将[[spell:47788]]作为个人防御冷却技能使用。

:::

:::

---

### 致谢

作者：**Rycn**

审校：**Ftm**

---

:::changelog 更新记录
**2026-08-07** 攻略已更新至12.1版本

**2026-04-22** 攻略已更新至12.0.5版本

**2026-01-15** 攻略已更新至12.0版本

**2025-10-07** 攻略已更新至11.2.5版本

**2025-07-28** 攻略已更新至11.2版本

**2025-06-18** 攻略已更新至11.1.7版本

**2025-04-21** 攻略已更新至11.1.5版本

**2025-02-25** 攻略已更新至11.1版本

**2024-12-17** 攻略已更新至11.0.7版本

**2024-10-20** 攻略已更新至11.0.5版本

**2024-10-11** 攻略已更新。

**2024-08-17** 攻略撰写于11.0.2版本



:::
