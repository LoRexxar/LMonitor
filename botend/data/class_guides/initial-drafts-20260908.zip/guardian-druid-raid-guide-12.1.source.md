Welcome to the **Guardian Druid** raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 2/5 · Weak



:::

:::

:::column
:::gear **Guardian Druid Raid Best in Slot**
```json
{
  "source_code": "JUoAwDEaAc__AEwAmQggQEAAvj7AX16ACKwF2gVABk-FEAQEBAg_sOg_sOAj1kjAYFQAmSCBCgQBAUTuDIoAOFwVVPQArGgE4EAAJk7ACKgTBEA4XQAgIUQNUIoAYFQAnGgHMUAAhubBPAXwXQQAZt7AGgQAAYBwDciqDEPuDIoALFQAgt7AEWRF44PrDcbNLFQApSCBAgQBAEwV8QP1DEg6XQgAJEAAvk7A-zaADEAGMEw4uJgRVAAFU9BBAgQAFkDBB0VEMABWBEQ3X0AGAhVABc7FEIACBAQP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240894]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245782]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Guardian Druid**, you have access to Wild Guardian, which gives you a chance to summon a guardian spirit that attacks your target whenever you use [[spell:77758]] and [[spell:33917]].

**Rank 2** increases your mastery and [[talent:103191]] damage. **Rank 3** resets the cooldown of your [[spell:77758]] and [[spell:33917]] whenever you get a proc of Wild Guardian. Additionally, you get one use of Wild Guardian after each [[talent:103201]] to activate it on demand.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-guardian-mxr.webp>)

Wild Guardian

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look at **all** changes, check out our **Changes This Patch** section.

- Spec Tree
  
  - New ability [[talent:135336]]
    
    - Applies an 8-second DOT to your target, which gets extended by 1 second every time you cast [[spell:33917]].
    - Replaces [[spell:8921]], which makes picking up multiple adds a lot harder. Works best on single-target fights where this is not an issue.
  
  
  
  - New passive [[talent:135490]]
    
    - Grants [[spell:33917]] a second charge.
    - Doubles [[talent:103191]] chance to proc [[talent:103190]] when cast at 80 rage or above.
    - This massively boosts rage generation and reduces the amount of filler [[talent:103301]] casts due to having more impactful buttons to press.
  - New passive [[talent:103222]]
    
    - Allows [[talent:103191]] to consume up to 50% more rage and deal up to 100% more damage.
    - Increases the effectiveness of [[talent:103191]] when cast at high rage levels.
    - Together with [[talent:135490]] strongly incentivizes you to only cast [[talent:103191]] when above 80 rage.
  - New ability [[talent:114701]]
    
    - Resets [[spell:77758]] cooldown and allows it to stack 5 additional times for 12 seconds.
    - When it ends, excess [[spell:77758]] stacks immediately deal their damage.
    - Due to the low priority of [[spell:77758]] on single target, it's hard to get good value from this talent in raid encounters.
  
  
  
  - [[talent:114700]] 
    
    - Location in the talent tree was adjusted, making it easier to pick it even when playing [[talent:123301]]
  - [[talent:114698]]
    
    - Now stacks up to 4 times, which is a good quality-of-life improvement.
- **Class Tree**
  
  - [[talent:103309@AJwCCA]] is reworked. It is now a 2-minute cooldown, whose effect depends on your current form:
    
    - In human form, it casts an empowered [[talent:103283]] to the target and up to 5 allies around it.
    - In [[spell:768]], it applies an empowered [[spell:274837]] to your target - a heavy-hitting single-target bleed.
    - In [[talent:103286@AJwCCA]], it deals AOE damage to enemies within 40 yards around you over 8 seconds, similar to [[spell:191034]].
- [[talent:123301]]
  
  - [[talent:117209]] was nerfed, and now increases damage of [[talent:103300]] or [[spell:22568]] only by 50% instead of 200%.
  - This makes catweaving gameplay much less effective. It is now more optimal for damage output to pick [[talent:117210]] and just stay in [[spell:5487]] throughout the fight.
- **Removed**
  
  - [[spell:400222]] 
    
    - Without this talent, [[talent:103305]] becomes a purely defensive rage spender that does no damage.
  - [[spell:135288]]
    
    - No free procs of [[talent:103191]] combined with removal of [[spell:400222]] means you now have to spend rage on [[talent:103191]] in order to actively do damage.

## Hero Talents

- Even though the apex talent changes together with the new tier set bonus of Season 2 synergize better with [[talent:123295]], [[talent:123301]] still offers better ST burst output. [[talent:123295]] is not far behind and offers a less complicated rotation. We recommend playing [[talent:123295]] in raid, but view [[talent:123295]] as a competitive alternative.

:::tabs
:::tab [[talent:123301]]
- [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - When it procs [[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] replaces your [[spell:6807]] for 20 seconds or until used.
- [[talent:117218]]
  
  - The health increase is only active during the [[spell:22842]] buff.
- [[talent:117220]] + [[talent:117216]]
  
  - [[talent:117220]] is applied to all targets hit by [[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] and provides you with 10% damage reduction.
  - With this talent combination, [[talent:117216]] extends this bleed and damage reduction passively by just pressing your normal rotation.
- [[talent:117207]]
  
  - [[spell:441685]] provides health and armor when shifting out of [[spell:5487]], for example to use [[talent:103309@AJwCCA]].
    
    - This buff gets canceled when shifting back into [[spell:5487]].
  
  
  
  - Both [[talent:103298]] and [[talent:103305]] do not vanish when swapping out of [[spell:5487]].
- [[spell:441835@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - The tooltip is misleading, every target hit with the initial damage has a 25% chance to proc [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]. Meaning on bigger pulls, you most likely receive a proc after each ability.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:135980@FJQA-thBLIA]] makes your auto-attacks 30% more likely to proc [[talent:117206@FAQAychA]].
- [[talent:117219@AJwCCA]] makes targets afflicted by [[talent:117220]] take 15% more damage from your other bleed effects, such as [[talent:103277@FAQAKFjB]], [[talent:103300]], and [[spell:77758]].
- [[talent:135979@AJwCCA]] can randomly proc from your single target melee abilities, dealing physical damage and generating 5 rage.

:::

:::tab [[talent:123295]]
- [[spell:424058@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - Makes it important to tank all enemies inside the [[talent:114700]] zone.
- [[talent:117204]]
  
  - This effect is permanently refreshed while enemies are in your [[talent:114700]] zone, which means it lingers after it ends or they walk out for another 6 seconds.
- [[talent:117192]] 
  
  - Since [[spell:8921@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] is more or less up all the time on enemies, this is a nice, convenient passive slow.
- [[talent:117183]] + [[talent:117177]]
  
  - This talent combination enables [[spell:77758]] to contribute cooldown reduction on [[talent:114700]], increasing the usage rate a lot.
- [[talent:117176]]
  
  - The proced [[spell:211545@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] has no internal cooldown and also applies [[talent:117204]] to targets hit.
- [[spell:424113@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - The [[talent:114700]] buff on yourself does not depend on the zone and provides you with both healing and mastery increase, even if you leave the zone on the ground.
  - Other benefits, like the talents mentioned above, only apply when enemies are within the zone.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:135978@AJwCCA]] gives [[spell:77758]] a chance to cast a [[talent:103278]] at your target.
- [[talent:135977@AJwCCA]] makes [[talent:114700]] increase Arcane damage you deal by 10%.
- [[talent:135976@FJQA-thBLIA]]
  
  - Increases damage of [[talent:103191]] by 10%
  - Increases damage of [[talent:114700]] to your primary target by 30%

:::

:::

## Talents

:::tabs
:::tab [[talent:123301]]
:::talents **Guardian Druid** Raid [[talent:123301]] Build
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### When to use this spec

This is the default loadout for any boss, unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the **Raids** section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section provides a concise overview of these talents and their applications. For a more detailed look, check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[spell:377811]]
  
  - Grants you another charge of [[spell:22842]] and increases the healing based on your missing health. This is amazing for both cooldown management and bonus healing.
- [[spell:204053]]
  
  - Makes maintaining your [[spell:77758]] stacks also increase your damage done, and grant defensive value.
- [[spell:393414]]
  
  - Grants cooldown reduction for [[spell:102558]] when you spend Rage

#### Class Tree

- [[talent:103309@AJwCCA]]:
  
  - Make sure to swap to [[spell:768]] before using it on single-target fights in order to apply [[spell:274837]].
- [[talent:103326]] allows to switch to [[spell:768]] and back to [[spell:5487]] without loosing a GCD:
  
  - Using [[talent:103277@FAQAKFjB]] in [[spell:5487]] will shift you to [[spell:768]].
  - Using [[spell:33917]] in [[spell:768]] will shift you back to [[spell:5487]]
  - Use this every time when you're planning to use [[talent:103309@AJwCCA]].
- [[spell:377847]]
  
  - With a 120-second cooldown, you proc a [[spell:22842]] when falling below 45% HP. What's important to note is that this overwrites any current active [[spell:22842]] can also be overwritten by any newly applied [[spell:22842]]. 
    
    - Keeping track of the cooldown and not overlapping it is very important.
    - [[talent:128586]] reduces the cooldown to 90 seconds

:::

:::tab [[talent:123295]]
:::talents **Guardian Druid** Raid [[talent:123295]] Build
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

### When to use this spec

This is the [[talent:123295]] version of the Raid Build.

To make your life easier, boss-specific talent loadouts are available in the **Raids** section.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Class Tree

- **Added**
  
  - [[talent:103203]]
  - [[talent:103198]]
- **Removed**
  
  - [[talent:103223]]
  - 1 point from [[talent:103226]]

#### Hero Talents

**Changed** to [[talent:123295]]. For more info, visit the **Hero Talent** section above.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:77758]] has a 20% chance to make your next [[spell:33917]] deal 100% increased damage.
- **4-Set:** [[spell:77758]] calls up 3 thorns, each impaling a target for Nature damage and dealing additional Nature damage to up to 5 nearby enemies, and extends the duration of [[spell:102558]] by 0.5 seconds, up to 5 seconds.

:::tabs
:::tab [[talent:123295]]
### Opener

- The Goal of the opener is to cast an [[spell:192081]] as fast as possible to get the active defensive rolling early.

:::rotation **Guardian Druid** [[talent:123295]] Opener in Raid
```json
{
  "source_code": "IoFEKI0iaAQABwgQ--SAFgACi0xAFgABeCZAQwQABwprJAREgQyBeMBAAAAAC1HhBcAFBIUUuLAAZ4DJ9RIAAAAAAI0laA"
}
```
1. [[spell:6795]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:1252871]]
7. [[spell:33917]]  [[spell:192081]]
8. [[spell:77758]]
9. [[spell:33917]]
10. [[spell:6807]]
:::

### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Use [[talent:114700]] and [[spell:102558]] on cooldown, unless it's needed for defensive purposes later on in the fight.
2. Activate Wild Guardian when both [[spell:77758]] and [[spell:33917]] are on cooldown.
3. Use [[talent:135336]] on cooldown.
4. Use [[spell:33917]] on 2 charges while [[talent:135336]] is active.
5. Make sure to have at least 1 stack of [[spell:192081]] rolling while actively tanking. You might need to go to higher stacks depending on the expected damage intake.
6. Use [[spell:33917]] on 2 charges.
7. Keep [[spell:77758]] on cooldown.
8. Spend rage on [[talent:103191]] when above 80 Rage to benefit from [[talent:135490]].Use [[spell:33917]].
9. Use [[talent:103191]].
10. Use [[spell:27554]] as filler.

:::

:::tab [[talent:123301]]
### Opener

- The Goal of the opener is to cast an [[spell:192081]] as fast as possible to get the active defensive rolling early. Afterwards, consume procs of [[talent:117206]] and keep rage-generating abilities on cooldown.

:::rotation **Guardian Druid** [[talent:123301]] Opener in Raid
```json
{
  "source_code": "IoYAQogQLqBABEADC57LBUACIISHDUACE4JkBABDBEAnumAERACJH4xEAAAAAIUfEGwBUEgQR5uAAkhPJYBzAIUB9aQRC4AUQFwhgJw2tJgMXIwBnJAj7JQmGOAFfQgcDMgOVSgSxYQ9Mcw9McQIuMxCCA"
}
```
1. [[spell:6795]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:1252871]]
7. [[spell:33917]]  [[spell:192081]]
8. [[spell:77758]]
9. [[spell:33917]]
10. [[spell:441605]]
:::

### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Use [[talent:114700]] and [[spell:102558]] on cooldown, unless it's needed for defensive purposes later on in the fight.
2. Activate Wild Guardian when both [[spell:77758]] and [[spell:33917]] are on cooldown.
3. Use [[talent:135336]] on cooldown.
4. Use [[spell:33917]] on 2 charges while [[talent:135336]] is active.
5. Make sure to have at least 1 stack of [[spell:192081]] rolling while actively tanking. You might need to go to higher stacks depending on the expected damage intake.
6. Use [[talent:117206]].
7. Use [[spell:33917]] on 2 charges.
8. Keep [[spell:77758]] on cooldown.
9. Spend rage on [[talent:103191]] when above 80 Rage to benefit from [[talent:135490]].
10. Use [[spell:33917]].
11. Use [[talent:103191]].
12. Use [[spell:27554]] as filler.

:::

:::

### Defensive Cooldowns

- [[spell:22812]]
  
  - This is your go-to defensive with a short cooldown. Activating it when walking into the boss, trash, or anything that does damage is never a bad idea, and due to the short cooldown, it is the first defensive you press if you need a cooldown.
- [[spell:61336]]
  
  - Your strongest (granting 50% damage reduction) and also the shortest defensive with a duration of 6 seconds. Choose wisely when to use this defensive, but also don't sit on 2 charges. Having 1 charge ready for an emergency is always nice, but sitting on 2 is a big waste.
- [[spell:22842]] 
  
  - Your big self-healing button. You can either use it proactively or reactively, the only important part is that you want to use its full potential to the best of your ability. Don't use it just because it's ready if you're only taking some damage. The spell has a short cooldown, yes, but if you tend to use it all the time when taking any damage, you might run into the situation of not having any charges after taking a big tank hit. Overall, using this after any tank mechanic or when gathering mobs is the way to go, just because it helps you get your HP up before your other defensives and [[spell:192081]] gets rolling.
- [[spell:192081]] 
  
  - Your active mitigation and your Rage spender. For more details, check out the **Deep Dive**.

### Incarnation: Guardian of Ursoc

- [[spell:102558]] or [[spell:50334]] can have a lot of applications, either as a DPS cooldown or a defensive cooldown. Therefore, you normally use it on cooldown. Holding it is only needed in special cases since it loses you a lot of value. 
  
  1. It is a strong defensive ability and can carry you through a burst of damage.
  2. Holding it causes the CDR from [[spell:393414]] to be wasted even more, so make sure to press the button.
  3. The offensive portion of it should not be underestimated.

## Deep Dive

This Deep Dive explains special mechanics that are important for **Guardian Druid's** survivability**.**

### Optimizing Ironfur

[[spell:192081]] is your Rage spender and active mitigation. It increases your armor based on your Agility for 7 (9 with [[talent:135568]]) seconds when pressed. Important to note is that multiple applications of [[spell:192081]] overlap and stack together while the duration does not increase, get refreshed, or extended.

- 1. [[spell:192081]] is pressed at 0 seconds
- 2. [[spell:192081]] at 3 seconds
- 3. [[spell:192081]] at 5 seconds 
  
  - Now you have 3 Stacks of [[spell:192081]], all 3 with different durations, and they expire at different times as shown on the timeline with the icons below.
- After 12 seconds, you are left without any stacks of [[spell:192081]], even though you pressed it 3x in the first 5 seconds of the fight.
- It is crucial to understand how Guardian Druid's active mitigation works since your armor value and your associated damage reduction changes all the time with the amount of [[spell:192081]] stacks you have active.

Here is a picture showing how [[spell:192081]] works.

:::timeline **Guardian Druid** Raid Ironfur optimization
```json
{
  "source_code": "HYFu2Z3_UAQAEww_eAAAHAQndi4AAoAA_DHAFAADA8Pg_3AAUAABCEl7CAAACEl7CMQBGAQBFYABNAQBZAwBF0AOKAgAR5uAMAgAR5uAUAQA"
}
```
总时长：20 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:192081]] | 上轨 |
| 3 秒 | [[spell:192081]] | 上轨 |
| 5 秒 | [[spell:192081]] | 上轨 |
| 7 秒 | [[spell:192081]] | 下轨 |
| 10 秒 | [[spell:192081]] | 下轨 |
| 12 秒 | [[spell:192081]] | 下轨 |
| 13 秒 | [[spell:192081]] | 上轨 |
| 20 秒 | [[spell:192081]] | 下轨 |
:::

### Ironfur Armor

- [[spell:192081]] armor is reducing your physical damage intake, which in most cases is only melee swings. Bleeds and magical DoTs are not affected by armor.
- There is a hard cap of 85% on physical damage reduction. This would equal to around 7-8 stacks of [[spell:192081]] at a time (around 4 with [[spell:360827]]) which makes it useless to spam [[spell:192081]] after reaching this amount.
- However, due to how armor scaling works, it is more overall defensive value to keep 1 stack of [[spell:192081]] rolling all the time than using 3 stacks instantly and then not having any at all after. The more armor you stack, the less effective each new layer becomes.
- Because you have high physical damage reduction, you struggle a lot more with magical damage, bleeds, and other DoTs. For those, it's important to use [[spell:22842]] correctly.

### Frenzied Regeneration

- [[spell:22842]] is your only self-heal as a Guardian Druid and is very important to stay alive.
- Generally, the cooldown of [[spell:22842]] is relatively low with 36 seconds (reduced by haste), which makes it very tempting to press any time you take damage. This often leads to problems when you take damage later on that is too big for your healer to cover, or you need a fast way to heal up. Keeping an eye on future scenarios is important when using it.
- On top of that, you also need to decide how you use [[spell:22842]] either proactively to stay topped for any mechanic or reactively after the mechanic to top yourself back up to stay stable. Often, this comes down entirely to the amount of damage you take from whatever you're dealing with. Knowing what to do comes with playing the game and knowledge of the situation.
- When playing [[spell:377811]], you have 2 charges of [[spell:22842]], and it's generally really nice to always keep one ready for the emergency and use the other charge more freely so you don't waste the cooldown recovery.
- Noteworthy things with [[spell:22842]]: 
  
  - [[spell:377847]] does not consume a charge of your [[spell:22842]], but it overwrites your current one if you press it right before it procced + If you use [[spell:22842]] and it procs after your proc overwrites the one you pressed before, basically wasting a lot of value.
  - [[spell:102558]] refunds you both charges of [[spell:22842]] and makes it have no cooldown at all for its duration. Keep this in mind since it can be a lifesaver.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dreamrift, Voidspire and MoQ

The following tips apply to **Heroic Bosses** and to surviving them as effectively as possible. The recommended builds in this section are going to help you survive each encounter, but do not necessarily give you the highest damage output.

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Guardian Druid Raid Nek'Zali**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### Tank mechanics

- The main tank mechanic of this fight is Hollowing Strikes - a debuff that the boss applies with each melee strike, as well as with [[spell:1284103]].
- During [[spell:1284103]], the boss sends spectral echoes towards the active tank, applying extra stacks of Hollowing Strikes. These echoes burst on first impact with any player, dealing reduced raid 
  
  - When targeted by this mechanic, move out of the raid and make sure no one is standing between you and the boss so they don't trigger the echoes too early. Otherwise, they will deal too much damage to the raid.
  - Taunt swap after each cast of [[spell:1284103]].
- Apart from that, the boss will spawn waves of Restless Amani - make sure to move the boss next to them to allow for better cleave.
- During the intermission, the active tank will be targeted by a group soak - [[spell:1289855]]. Try to put it on top of as many Restless Amani corpses as possible to burn them with [[spell:1289875]] to prevent them from awakening again.

:::

:::tab Entombed Sentinels
:::talents **Guardian Druid Raid Entombed Sentinels**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### Tank mechanics

- The bosses have to always be separated by at least 40 yards due to [[spell:1290189]]. At the start of each phase, split the bosses apart by moving them to different sides of the room.
- [[spell:1284458]] and [[spell:1284487]] are the stacking tank debuffs of each of the bosses. Make sure to taunt swap on the bosses each time they meet in the middle of the room during [[spell:1284588]] to reset your stacks.
  
  - [[spell:1284487]] additionally creates a large pool of blood upon expiration. Make sure to drop it off at the edges of the room if possible.
- Don't tank Breath of Ula'tek too close to the existing blood puddles so the [[spell:1284251]] doesn't spawn in the pool and melees can safely attack it.

:::

:::tab Lost Explorers
:::talents **Guardian Druid** **Raid Lost Explorers**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### Tank mechanics

- All three bosses cannot be positioned within 30 yards of each other due to [[spell:1297645]] - always keep one of the bosses away from the other 2.
- Trader Gebbo just wanders around the room and doesn't follow or attack its threat target. It also doesn't have any tank mechanics.
- Scrollsage Iku casts [[spell:1295854]] at its current target - a series of ice shards, each doing magic damage and increasing damage taken from the next shard for 80 seconds.
- First Mate Nama applies [[spell:1291929]] with each attack to its target, increasing physical damage done to that target for 30 seconds.
- The job of the tanks on this fight is to swap between Scollsage Iku and First Mate Nama, never letting [[spell:1295854]] to be casted at the same target twice and resetting [[spell:1291929]] as often as possible, while always keeping one of the bosses far enough to prevent [[spell:1297645]] from being applied.

:::

:::tab Vashnik
:::talents **Guardian Druid Raid Vashnik**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### Tank mechanics

- There are 3 fountains placed on the sides of the room: Fountain of Blood, Fire, and Shadow. The boss will activate the two closest ones with [[spell:1283164]] throughout the fight, gaining their powers and spawning some adds.
  
  - Each fountain activation empowers the next activation for 1.5 minutes.
  
  
  
  - Your job as a tank is to never let the boss activate the same two fountains in a row by moving the boss to the next fountain before each [[spell:1283164]] cast.
  - Make sure to position the boss on top of the adds coming from the fountain for better cleave. However, be careful with quickly killing all the fire adds, as they apply stacking [[spell:1285979]] when they die.
- Vashnik's tank hit is [[spell:1280935]], taunt swap after each cast.

:::

:::tab Sszorak
:::talents **Guardian Druid Raid Sszorak**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### Fight mechanics

- [[spell:1277025]] is a combination of tank frontals consisting of 2 [[spell:1277002]], 2 [[spell:1277027]], and one [[spell:1287072]], cast in a random order.
  
  - [[spell:1277002]] is a frontal cone that deals heavy physical damage and follows the active tank. Make sure to aim it **away from the raid**.
  - [[spell:1277027]] is a frontal cone that applies a heavy magic DOT, which is reduced by the number of people hit by the cone. Make sure this ability is aimed into one half of the raid, so people can soak it.
  - [[spell:1287072]] spawns a bunch of tornadoes around the boss and sends them outwards at the end of the cast. Make sure you're not under the boss when this happens and dodge the tornadoes.
  - In heroic and mythic difficulties, the boss will cast these in a random order. Since each frontal cone applies a damage taken increase from that ability, make sure that one tank never takes 2 of the same abilities. Keep in mind that you can taunt during the cast so the boss aims the frontal cone at you instead.
- Each cast of [[spell:1306120]] spawns [[spell:1305998]] puddles around the boss. Make sure to move the boss to an edge of the room, ideally opposite the [[spell:1285732]] spawn, so that the puddles get blown off the edge of the room by the winds.
- Apart from that, Sszorak applies a stack of [[spell:1282869]] with each melee attack, increasing physical damage taken by the target. Taunt swapping on each [[spell:1277025]] combo is enough to reset the stacks.

:::

:::tab Twin Fangs
:::talents **Guardian Druid** **Raid Twin Fangs**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

### General mechanics

- The entire fight revolves around managing [[spell:1290336]] stacks
  
  - [[spell:1291404]], [[spell:1291478]], getting hit by poison waves, or soaking [[spell:1289201]] applies a stack of [[spell:1290336]].
  - Reaching 10 stacks in Heroic or 9 in Mythic difficulties immediately kills you.
  - It is crucial to dodge as many poison waves as possible while managing how many [[spell:1289201]] you soak to prevent reaching maximum stacks of this debuff.

### Tank mechanics

- Being outside of melee range of the boss that you're actively tanking will cause it to cast [[spell:1295107]] or [[spell:1295113]], so make sure to never leave melee or use a big personal if you ever find yourself far from the boss.
- Vexhul's tank ability is [[spell:1289192]], which deals nature damage and pushes you back for 5 seconds.
  
  - It also spawns [[spell:1289201]] around you. These need to be soaked by players before they explode to prevent everyone from getting an [[spell:1290336]] stack.
  - Each hit applies [[spell:1310360]], so taunt swap between every [[spell:1289192]] cast.
  - Be aware of the pushback, especially when the poison waves are coming!
- Ithraz casts [[spell:1288538]], pushing back players close to the boss and spawning 3 soak zones.
  
  - Each zone deals heavy physical damage and increases the damage taken from the next zone by 33%. If it is left unsoaked, it deals raid-wide damage and knocks everyone away. Make sure to taunt swap between each set of [[spell:1288538]] to reset the stacks of the damage increase.
  
  
  
  - The zones spawn in a random order and need to be soaked in the same order that they spawned. Pay attention to the spawns and memorize the spawn order when this ability is happening. The boss will also shortly face towards the zone it will trigger next, so you can use that direction if you can't remember the spawn order.
  - Each second [[spell:1288538]] cast overlaps with poison waves coming - make sure you're not getting hit by waves while soaking the [[spell:1288538]].
  - Watch out for the pushback at the start of this mechanic, as it can push you into an incoming wave or a [[spell:1289201]].

:::

:::tab Coiled Altar
:::talents **Guardian Druid Raid Coiled Altar**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMzmZZGMLLDMMMaimZmlZmZmxMzwAAAAAAmZWmBssNzgxsMAmamlZZmZGAALYmHAYxMYAbWMAzMzsAD"
}
```
:::

### Phase 1

- Only Zul'jan is active during this phase.
- He casts [[spell:1299960]], which spawns multiple [[spell:1282403]] orbs during this phase. They deal pulsing raid-wide AOE while they're active, and can be picked up and moved by players running into them.
- [[spell:1299684]] is a frontal cone aimed at the active tank that deals physical damage and destroys any [[spell:1282403]] it hits.
  
  - It also increases damage taken by the next [[spell:1299684]] by 200%, so make sure to taunt swap after every cast.
- The goal of this phase is for the raid to group up the [[spell:1282403]] orbs so they can then be destroyed by [[spell:1299684]].
- Additionally, each cast of [[spell:1282487]] empowers the next 23 melees of the boss with [[spell:1300322]], dealing extra nature damage to the tank. 
  
  - Make sure to frontload defensives while the boss has stacks of [[spell:1300322]].

### Phase 2

- Only Hex Lord Malacrass is active during this phase.
- He casts [[spell:1285640]], which mind-controls selected players, and spawns 2 [[spell:1285842]] per player when the mind control is broken.
  
  - The Manifestations fixate on random players, moving towards them, unless the fixated player looks back at the Manifestation.
- Similar to [[spell:1299684]] in Phase 1, [[spell:1286620]] is a frontal cone aimed at the active tank that deals shadow damage and destroys any [[spell:1285842]] it hits.
  
  - It also increases damage taken by the next [[spell:1286620]] by 200%, so make sure to taunt swap after every cast.
  - Additionally, it applies 3 stacks of [[spell:1286837]], which spawn a Soul Fragment per stack that needs to be picked up in order to remove the stack. If the stacks are not cleared before the debuff expires, the affected player immediately dies.
  - It is important to pay extra attention to finding and collecting all Soul Fragments quickly after each tank frontal.
- Getting hit by a [[spell:1286895]] also applies 3 stacks of [[spell:1286837]]. Don't let it catch you off guard!

### Intermission

- Malacrass takes 100% extra damage while casting [[spell:1287685]]. Make sure to save your [[talent:103201]] for the intermission!
- Don't let any Fragments of Malacrass reach the boss by soaking them to prevent them from healing the boss.
  
  - Soaking each fragment deals raid-wide AOE damage, so don't soak them too quickly to give your healers some time to react to the incoming damage.

### Phase 3

- During this phase, both Zul'jan and Malacrass are active, combining their abilities from Phases 1 and 2.
- Both [[spell:1299960]] and [[spell:1285640]] happen in this phase, meaning both [[spell:1282403]] and the [[spell:1285842]] need to be cleared by the tank frontal.
- The tank frontal cone of this phase is [[spell:1307279]], which deals shadow damage, destroys any [[spell:1282403]] and [[spell:1285842]] hit by it, and applies 3 stacks of [[spell:1286837]].
  
  - Don't forget to collect your Soul Fragments and taunt swap after each cone!
- [[spell:1298381]] is the empowered verision of [[spell:1282487]] from phase 1.
  
  - In this phase, the empowered melee attacks additionally apply a **stacking** shadow DOT. Use big defensives when reaching high stacks.

:::

:::tab Ula'tek
:::talents **Guardian Druid Raid Ula'tek**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents **Guardian Druid Raid Nymrissa Wavecaller**
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxswMjZWmZZGMLbDMMMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmlBwUzsMLzMzAAYDzMALmBDYziBYmZmFYA"
}
```
:::

### General mechanics

- The boss targets random players with Chilling Frost, which drops Frost Orbs under their feet.
  
  - These orbs need to get soaked before they explode and wipe the raid.
  - Soaking an orb applies a stacking debuff that increases the damage taken from soaking Frost Orbs, so don't soak too many in one go.
  - Each orb soak also deals raid-wide AOE, so don't soak them too quickly to give your healers some time to react to the incoming damage.
- Occasionally, murlocs will spawn from the water and start walking towards the bubble in the middle of the room.
  
  - Don't let them reach the bubble, and move the boss on top of them whenever possible to allow for better cleave.

### Tank mechanics

- A tank-only mechanic of the fight is the Iceblade Flurry - a series of magic slashes, with each slash increasing the damage of the following ones.
  
  - Use a defensive for each cast and taunt swap after each one.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Guardian Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Guardian Druid** Raid Stats
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** - Niche tertiary that can be very useful and has proven so in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks, especially in AoE scenarios, it can be by far the best stat you can have.  
Avoidance is great, but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAgGA-z64PrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:251223@DgQAAgGAJk7IoAOF]] into [[item:271526@DgQBAgGA1k7IoAOFwVVP]] | Catalyst of Voidscar Arena |
| Cloak | [[item:268253@BgQAAgGACKAWBA]] | The Coiled Altar |
| Chest | [[item:271531@DgQAAgGAJk7IoAOF]] | Tier / Catalyst |
| Wrist | [[item:244576@FiQAAgGAWA8ciqj_sO3WzSB]] | Crafting |
| Gloves | Convert [[item:251124@BgQAAgGACKgTBA]] into [[item:271529@BgQBAgGACKgTBQP1DA]] | Catalyst of Murder Row |
| Belt | [[item:268256@BiQAAgGA-z6IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@DgQAAgGAhu7IoAYF]] into [[item:271527@DgQAAgGAhu7IoAOF]] | Catalyst of The Coiled Altar |
| Boots | [[item:244569@HgQAAgGAWA8ciqT84OCKwSB]] | Crafting |
| Ring 1 | [[item:268266@DkQAAgGAvk74Prj_sOCKgTB]] | Nymrissa Wavecaller |
| Ring 2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | Kings' Rest |
| Trinket 1 | [[item:270164@BgQAAgGACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270173@BgQAAgGACKAWBA]] | The Coiled Altar |
| Weapon | [[item:268215@DgQAAgGA9k7IoAYF]] | Ula'tek |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@BgQAAgGACKQQBA]] | Altar of Fangs |
| Neck | [[item:251173@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAAgGACKQQBA]] | Voidscar Arena |
| Cloak | [[item:193763@BgQAAgGACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@BgQAAgGACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251135@BgQAAgGACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgQAAgGACKQQBA]] | Murder Row |
| Belt | [[item:159301@BgQAAgGACKQQBA]] | Kings' Rest |
| Legs | [[item:159313@BgQAAgGACKQQBA]] | Kings' Rest |
| Boots | [[item:251153@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Ring 1 | [[item:273792@BgQAAgGACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:159459@BgQAAgGACKQQBA]] | Kings' Rest |
| Trinket 1 | [[item:250228@BgQAAgGACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250215@BgQAAgGACKQQBA]] | Murder Row |
| Weapon | [[item:158370@BgQAAgGACKQQBA]] | Temple of Sethraliss |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons & Raids. Do note that the trinkets recommended above are for optimal damage; if you do not care about your damage and only want to survive, it is recommended to use a trinket like [[item:270160@BgQAAIEACKgTBA]].

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270173@BgQAAgGACKAWBA]] |
| **A-Tier** | [[item:270175@BgQAAgGACKAWBA]]  <br>[[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270165@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B-Tier** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:270173@BgQAAgGACKgTBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### Embellishments

- 2x [[item:240167]] is your best in slots option.
  
  - Random main stat proc for you and your teammates.
  - Preferably on Wrists and Boots; however, it can be crafted on any armor piece.

A good option for early season or if you don't have access to a 334 or 344 weapon is crafting a 331 weapon[[item:245876]] instead of an offpiece with [[item:240167]]. As soon as you get access to a 334 or 344 weapon, this option loses value compared to 2x [[item:240167]].

- [[item:245876]]
  
  - Passively gives secondary stats depending on the mob type you're fighting.
  - Has to be crafted on a weapon.

#### Remaining Sparks

- Crafted items are 331 item level, and regular items are 334 on max item level; therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear in that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stone/Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAgGAaB]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, use one of each gem colour to enhance your Blasphemite.*
    
    - [[item:240910]]
    - [[item:240914]]
    - [[item:240890]]
    - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAIE]] |
| Belt | [[item:275707@BAAAAIE]] |
| Legs | [[item:244641@BAAAAIE]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244015@BAAAAIE]] |
| Ring 2 | [[item:244015@BAAAAIE]] |
| Weapon | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **Guardian Druid** **Raid**
```json
{
  "source_code": "IQFZoBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy [[item:275707@BAAAAIE]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Guardian Druid** in Raids, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:255654]] *-- Highmountain Tauren*
  
  - [[spell:255654]] can be used to stun a pack, even when on stun DR since it counts as a knockdown making it very useful for those cases.
  
  
  
  - Strong passives for survival with [[spell:255659]] and [[spell:255658]].
- [[spell:287712]] *-- Kul Tirans*
  
  - [[spell:287712]] can be moved to knock enemies out of bad positions but has limited uses.
  
  
  
  - Very good defensive passives with [[spell:291628]] and [[spell:291417]].
- **[[spell:20549]]** *-- Tauren*
  
  - **[[spell:20549]]** can be strong since you don't have any other source to stun enemies. Sadly it only hits up to 5 targets though so keep that in mind.
  
  
  
  - On top of that you also get decent passive effects [[spell:20550]], [[spell:154743]] and [[spell:20551]].
- [[spell:26297]] *-- Troll* 
  
  - Troll is by far the best for burst damage since you can just use [[spell:26297]] during incarnation for the extra haste, if you want to survive this is the worst option compared to the others.

### Recommendation

- Highmountain Tauren and Kul Tiran aren't the overall best racials in terms of DPS, but their survivability abilities are decent in Raiding as a **Guardian Druid.**
- Night Elf is very good for DPS, but doesn't have any other useful benefits in Raid as **Guardian Druid.**

## Macros

Discover recommended macros for **Guardian Druid** for Raids and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:2649]] at your target or your mouseover (very handy to pick up mobs)*

```wow-macro
#showtooltip Growl
/cast [@mouseover,exists,harm][@target,exists,harm] Growl
```

Boss 1 Taunt --- *Casts [[spell:2649]] on Boss1*

```wow-macro
/cast [@boss1] Growl
```

Boss 2 Taunt --- *Casts [[spell:2649]] on Boss2*

```wow-macro
/cast [@boss2] Growl
```

:::

:::details Mouseover Macros
Mouseover Ursol's Vortex/Mass Entanglement *--- Casts [[spell:102793]]* *at your cursor if talented and [[spell:102359]] at your mouseover, if no mouseover is available, it instead casts it on your target.*

```wow-macro
/cast [@cursor] Ursol's Vortex
/cast [@mouseover,exists] [] Mass Entanglement
```

Mouseover [[spell:2782]] *--- Cast it on target if no mouseover is available, casts it on yourself if no target is available.*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Remove Corruption
```

Mouseover Regrowth --- *Casts [[spell:16561]] on mouseover or yourself.*

```wow-macro
#showtooltip Regrowth
/cast [@mouseover,exists][] Regrowth
```

Mouseover [[spell:29166]]

```wow-macro
/cast  [@mouseover] Innervate
```

Mouseover Wild Charge *--- Casts [[spell:16979]] on mouseover or target.*

```wow-macro
#showtooltip Wild Charge
/cast [@mouseover][] Wild Charge
```

Mouseover Soothe *--- Casts [[spell:2908]] on mouseover or target.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Soothe
```

Mouseover Battle Res --- *This makes it so you can use [[spell:20484]]* as mouseover on your frames

```wow-macro
#showtooltip
/cast [@mouseover,help,dead][] Rebirth
```

:::

:::details Focus Macros
Focus Kick --- *Casts [[spell:106839]]* at your focus target

```wow-macro
/cast [@focus] Skull Bash
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Utility Macros
Cancelaura BoP --- *This cancelaura's [[spell:1022]] on you, very useful to have whenever playing with a paladin*

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Guardian Druid**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/pala-1-1024x623.png>)

**Guardian Druid** Interface

:::accordion
:::details Addons
- EllesmereUI
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
#### Druid

- Matted Fur absorb increased by 25%.
- Heart of the Wild empowered Wild Growth healing increased by 25%.
- Shred and Cat Form Swipe damage increased by 10%.

- Elune's Chosen
  
  - Boundless Moonlight – Lunar Beam now causes you to Leech 12% of damage dealt to affected enemies (was 10%).

#### Guardian

- Gory Fur has been redesigned – Ironfur has a chance to make your next Maul, Raze, or Ravage free. Maul, Raze, or Ravage have a chance to make your next Ironfur free.
- Apex Talent: Wild Guardian has been redesigned –
  
  - Rank 1: Spending Rage has a 10% chance to awaken a guardian spirit for 8 seconds, which attacks a nearby enemy when you cast Thrash or Mangle.
  - Rank 2: Mangle, Ravage, Raze, and Maul deal 20%/40% additional Nature damage over 12 seconds. Your Mastery is increased by 3%/6%.
  - Rank 3: When a spirit is awakened, the cooldowns of Thrash and Mangle are reset, and they deal 30% increased damage while the spirit is with you. Each time a spirit attacks, you generate 8 additional Rage. After casting Berserk or Incarnation: Guardian of Ursoc, gain 1 charge of Wild Guardian:
    
    - Wild Guardian: Your next cast of Ravage, Raze or Maul is guaranteed to awaken a spirit.
- All damage increased by 8%.
- Brambles absorb increased by 25%.
- After the Wildfire healing increased by 25%.
- Lunar Beam healing increased by 25%.
- Lunation reduces Lunar Beam's cooldown by 20 seconds (was 3 seconds per Arcane ability).
- Ursoc's Fury grants an absorb for 35% of Thrash and Maul damage (was 30%).
- Elune's Favored heals you for 18% of Arcane damage dealt (was 15%).
- Fixed an issue where Dream Guide was incorrectly being consumed by Regrowths cast via Reinvigoration.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I randomly get one-shot?
A: You most likely left [[spell:5487]] by pressing a button that brings you out of form, most common mistakes are pressing [[spell:339]] and [[spell:8936]] without a [[spell:158497]] proc.

:::

:::

---

### Credits

Written By: Tief

Reviewed by: **Meeres**

---

:::changelog 更新记录
**2026-08-08** Updated for Patch 12.1

**2026-06-21** Updated for Patch 12.0.7

**2026-04-26** Updated for Patch 12.0.5

**2026-02-21** Updated for Patch 12.0.1

**2026-01-18** Updated for Patch 12.0

**2025-12-01** Updated for Patch 11.2.7

**2025-10-07** Updated for Patch 11.2.5

**2025-07-28** Updated for Patch 11.2

**2025-06-18** Updated for Patch 11.1.7

**2025-04-20** Updated for Patch 11.1.5

**2025-02-25** Updated for Patch 11.1

**2024-12-17** Updated for Patch 11.0.7

**2024-10-27** Updated for Patch 11.0.5

**2024-08-17** Updated for Patch 11.0.2

**2024-07-28** Guide Written for patch 11.0.



:::
