Welcome to the **Shadow Priest** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 2/5 · Average

Mobility · 1/5 · Subpar



:::

:::

:::column
:::gear **Shadow Priest** Mythic+ Best in Slot
```json
{
  "source_code": "IsfAwjlABc__BEgAmQggQEAAnk7A8z6A5IgF2gVABk-FEAIEBAwVtOQOCwYNYFQABTCBCgQAAcRuDkjAOFQAGTCBCgQAAkQuDkjAOFQAwg6AAiQAAwPrDcbNLFQACngHIUgqDUQLE89FFwDAp0APMACqDQYALxAwDYiqBMXBzgBxkQAAIEAAFADIcfBBCiQAAUPuB4RBSAQ2CJBAccW0DAACBAggB4HBU9RG8QQ3XkBDcQvIEIAEBAQBBgHAXEg1oU6FEAACBAQOC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240892]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] |
| 肩部 | [[item:271553]] | [[item:243991]] |
| 胸部 | [[item:271558]] | [[item:243977]] |
| 腰部 | [[item:239664]] | [[item:240892]] |
| 腿部 | [[item:271554]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:245783]] · [[item:240166]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Shadow Priest**, you have access to **Void Apparitions**, which conjures [[talent:103792]] on an **Idol** activation.

**Rank 2** gives a 15/30% chance for your [[talent:103792]] to become [[spell:1264104]], increasing its damage done by 50% and releasing a [[spell:1264177]].

While **Rank 3** gives your [[talent:115448]] 100% chance to activate an effect of one of your **Idols**.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/imagzqde.png>)

Void Apparitions

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115448]]
    
    - Replaces the old Shadow Crash, requires a target to be casted and dots targets between you and the target casted on, on top of an area around it.
  
  
  
  - [[talent:103674]]
    
    - Now has [[spell:1240401]] instead of [[spell:1264177]] as a replacement spell throughout its duration.
    - The duration of [[talent:103674]] can't be extended anymore.
  
  
  
  - [[talent:103799]]
    
    - Our new way to extend our DoTs on targets. On few target count, it won't be enough to extend your DoTs and you'll be required to do it manually.
  - [[spell:120644]]/[[spell:263165]]
    
    - They have been removed from the class and spec tree and baked into hero talents.
- **Removed**
  
  - [[spell:391109]]
    
    - The removal of it leaves us only with [[talent:103674]] as our main cooldown.
  
  
  
  - [[spell:132603]]
    
    - Our pets in general have been baked into passives that trigger on execute or on cooldown presses.

## Hero Talents



### [[talent:123289]]

[[talent:123289]] grants you the [[talent:117300@FAQAJdhA]] ability that combined with [[talent:117284]] creates a total of three halos that further synergise with some of the hero talents.

- [[talent:117302@FAQAJdhA]] grants you [[spell:391403]] for every [[talent:117300@FAQAJdhA]].
- [[talent:117279@FAQAJdhA]] increases the damage taken by targets hit by [[talent:117300@FAQAJdhA]].
- [[talent:125085]] extends the duration of your [[talent:103674]] if active or stores up to 6 extra seconds for the next one.




### [[talent:123287]]

[[talent:123287]] grants you the [[talent:117287@AJQBCA]] ability that summons an [[spell:447444]] that does damage around your target, this rift explodes at the end of its duration doing damage to enemies in it and it has further synergies with some of the hero talents.

- [[spell:447444]] transforms your [[spell:8092]] into [[talent:117306]], making it do more damage and generate more insanity.
- Each [[talent:103808]] you cast empowers your rift's size and damage by 20%.
- [[talent:123845@AJQBCA]] allows you to use [[talent:117287@AJQBCA]] while moving.
- [[talent:103864@FJQAJdhAFIA]] does significantly more damage with [[talent:117271@FJQAJdhAFIA]].





## Talents



### [[talent:123289]]

:::talents [[talent:123289]] **Shadow Priest** Mythic+ Build
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### When to use this Spec

You can use this Spec at all levels of Mythic+ keys but in lower keys where mobs tend to die faster, there will be situations where you won't have your [[talent:103674]] or [[talent:117300@FAQAJdhA]] resulting in mediocre damage. You can opt in to pick [[talent:136811]] instead of [[talent:103809]] resulting in more throughput but a harder playstyle.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:115448]]
  
  - Applies [[spell:34914]] to up to 6 targets and has two charges.
- [[talent:103809]] or [[talent:136811]]
  
  - Important choice node deciding between ease of play or throughput.
- [[talent:103806]]
  
  - The main way to do AoE damage as a shadow priest combined with the DoTs themselves.
- [[talent:103792]]
  
  - Another source of sustained damage synergizing with many other talents in the tree.
- [[talent:103786]] or [[talent:115671]]
  
  - Important talent choice as it changes the cost of your [[talent:103808]].
- [[talent:103782]], [[talent:103817]], [[talent:103781]] and [[talent:103787]]
  
  - Although mainly passive, it is important to acknowledge all your idol talents as they will synergize with your Apex Talents.

##### Class Tree

- [[talent:103833]]
  
  - Important part of priest's execute phase, maximizing it's uptime is a significant part of getting the most out of the spec.
- [[talent:103819]]
  
  - Increases the range of most of your spells.
- [[talent:103834]]
  
  - Your two minute cooldown that you always combine with [[talent:103674]]
  
  
  
  - [[talent:134284]] allows you to [[talent:103834]] someone else and still get the full value of it yourself so having a good macro for it is important.
- [[talent:103864]]
  
  - Your execute button. It can be used any time as a filler spell when moving.
- [[talent:134849]] with [[talent:103835]] and [[talent:134846@FAQAKLbB]]
  
  - Two strong defensive abilities.




### [[talent:123287]]

:::talents [[talent:123287]] **Shadow Priest** Mythic+ Build
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMjZGAAAAAAAAAAAAMLmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMjZGAAAAAAAAAAAAMLmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

#### When to use this Spec

You can use this spec in lower keys as [[talent:117287@AJQBCA]] windows provide impactful burst windows more often than [[talent:123289]]. You can opt in to pick [[talent:136811]] instead of [[talent:103809]] resulting in more throughput but a harder playstyle.

##### Hero Talents

Changed [[talent:123289]] to [[talent:123287]] for more info visit the **Hero Talent** section above.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:115448]]'s cooldown is reduced by 3 seconds and its damage is increased by 100%.
- **4-Set:** ‍[[talent:115448]] has a 100% chance to grant a free use of  [[spell:1242189]] at 100% effectiveness.

### Single-Target



#### [[talent:123289]]

##### Opener

- Your goal of your opener is to spend all charges and use all of your relevant abilities as efficiently as possible without overcaping your **Insanity**.
- Below you can find an example of how your opener should look like:

:::rotation [[talent:123289]] **Shadow Priest** Single-Target opener in Mythic+
```json
{
  "source_code": "J0GEKIEnfAQABwgQQorEFgABNJQAHwAAC1D9JABCEddABEBCCls9BkBQEIETnAAAAIkpDCAAAEAiuOQAcwTAnF9AAgQAAIoAOFgQr5RBBQBDC1D9SUACow5HAAAAAAgQrjfB"
}
```
1. [[spell:8092]]
2. [[spell:1227280]]
3. [[spell:589]]
4. [[spell:1242173]]
5. [[spell:120644]]
6. [[spell:194249]]  [[spell:10060]] · [[spell:33702]] · [[item:241288]] · [[item:250215]]
7. [[spell:335467]]
8. [[spell:1242173]]
9. [[spell:8092]]
10. [[spell:391403]]
:::

- Use your active trinkets, [[item:241308]], [[talent:103834]] and racials like [[spell:20572]] or [[spell:26297]] after using [[talent:103674]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:34914]] and [[spell:589]] on your target.
   
   - You can keep it through [[talent:115448]], extend it through [[talent:103799]] or apply it manually.
2. Cast [[spell:120644]]
3. Cast [[talent:103674]]
4. Cast [[talent:103834]]
5. Keep up [[talent:103808]] on the target.
6. Cast [[spell:1242173]]
7. Cast [[spell:32379]] if the target is below 20%
8. Cast [[spell:8092]]
9. Cast [[spell:391403]]
10. Cast [[spell:15407]]




#### [[talent:123287]]

##### Opener

- Your goal of your opener is to spend all charges and use all of your relevant abilities as efficiently as possible without overcaping your **Insanity**.
- Below you can find an example of how your opener should look like:

:::rotation [[talent:123287]] **Shadow Priest** Single-Target opener in Mythic+
```json
{
  "source_code": "JUHELIEnfAQABwgQQorEFgABNJQAHABAC1_AEEQCMI0phbQBIgwaeUQBIEBEE0D9JADBJbfAxAEBCx0JAAAACZ6gAAAABgorDEALcFwZRPAAIEAACKgTBIUP0LBAAAAACtmHFA"
}
```
1. [[spell:8092]]
2. [[spell:1227280]]
3. [[spell:589]]
4. [[spell:263165]]
5. [[spell:450983]]
6. [[spell:335467]]
7. [[spell:450983]]
8. [[spell:1242173]]
9. [[spell:194249]]  [[spell:10060]] · [[spell:33702]] · [[item:241288]] · [[item:250215]]
10. [[spell:1242173]]
11. [[spell:335467]]
:::

- Use your active trinkets, [[item:241308]], [[talent:103834]] and racials like [[spell:20572]] or [[spell:26297]] after using [[talent:103674]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:34914]] and [[spell:589]] on your target.
   
   - You can keep it through [[talent:115448]], extend it through [[talent:103799]] or apply it manually.
2. Cast [[talent:103674]]
3. Cast [[talent:103834]]
4. Keep up [[talent:103808]] on the target.
5. Cast [[spell:1242173]]
6. Cast [[spell:450983]]
7. Cast [[spell:32379]] if the target is below 20%
8. Cast [[talent:117287@AJQBCA]]
9. Cast [[spell:8092]]
10. Cast [[spell:15407]]





### AoE

As a **Shadow Priest**, the majority of our AoE consists of your DoTs damage and [[talent:103806]], therefore your Single-Target rotation is your AoE rotation.

- Your number one priority is to keep your [[spell:34914]] on any target that you want to significantly damage.
  
  - This also gives you flexibility on which target you want your throughput directed.
- When playing [[talent:136811]], you have to made decisions on how many and which targets you want to use [[spell:589]] as you want a balance between DoTing the important targets but also starting to do your damage through [[talent:103806]].

## Deep dive

### Mastery: Shadow Weaving and Shadow Word: Madness

The **Shadow Priest's** mastery is very important to play around. It makes it so that every DoT you have on the target increases your damage done by your mastery %, which makes your mastery management vital. [[spell:34914]] and [[spell:589]] are up on the target nearly 100% of the time, this leaves you with the task of maintaining [[talent:103808]] on the target. Having as high uptime as possible on [[talent:103808]] is crucial to dealing the highest possible damage. During your [[talent:103674]] you gain the maximum effect of your mastery no matter the DoTs on the target.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Shadow Priest** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[talent:80176]] with [[talent:80157]].




### Den of Nalorakk

:::talents **Shadow Priest** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:115877]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Shadow Priest** Mythic+ Build in Murder Row
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Shadow Priest** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots with a [[talent:115877]].
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Shadow Priest** Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Shadow Priest** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Shadow Priest** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Shadow Priest** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Shadow Priest**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:103849]] works but it is capped to 5.
  - [[spell:8122]]
- Xal'atath's Bargain: Voidbound
  
  - Switch to the affix and kill it as soon as it spawns as it gives damage reduction to the rest of the mobs.
  - [[talent:103864]]  is very powerful against this mob because it spawns at 1 hp with a big shield, especially when playing [[talent:117271]].
- Xal'atath's Bargain: Oblivion
  
  - Collect the orbs moving towards the enemy mobs.
- Xal'atath's Bargain: Devour
  
  - [[talent:103849]] is very powerful as it can cleanse your entire team.
  - [[talent:103854]].

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a  **Shadow Priest**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Shadow Priest** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUQMkACKBIQABA"
}
```
**智力 ＞ 精通 ＝ 急速 ＞ 暴击 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DCRAAIQAnk7wPrTOCYhNYFA]] | Ula'tek |
| Neck | [[item:268265@BCRAAIQAX16kjAMWDWB]] | Ula'tek |
| Shoulder | [[item:271553@DgQAAIQAXk7kjAOF]] | The Lost Explorers or Catalyst |
| Cloak | [[item:268253@BgQAAIQA5IgTBA]] | The Coiled Altar |
| Chest | [[item:271558@DgQAAIQAJk7kjAOF]] | Vashnik or Catalyst |
| Wrist | [[item:239648@FiQAAIQAXA8YiqD_sO3WzSB]] | Crafting |
| Gloves | [[item:271556@BgQAAIQA5IgTBA]] | Entombed Sentinels or Catalyst |
| Belt | [[item:239664@BiQAAIQA8z6cbNLF]] | Crafting |
| Legs | [[item:271554@DgQAAIQAFo6kjAOF]] | Sszorak or Catalyst |
| Boots | [[item:268255@DgQAAIQApk7kjAOF]] | The Coiled Altar |
| Ring 1 | [[item:268252@DiQAAIQA1j7wPrTOC4UA]] | Sszorak |
| Ring 2 | [[item:268249@DiQAAIQA1j7wPrTOC4UA]] | Vashnik |
| Trinket 1 | [[item:250215@BgQAAIQACKgTBA]] | Murder Row |
| Trinket 2 | [[item:270164@BgQAAIQA5IgTBA]] | The Lost Explorers |
| Main Hand | [[item:271092@DARAAIQAFk7kjAXYDWB]] | Ula'tek |
| Off Hand | [[item:268197@BgQAAIQA5IgTBA]] | Entombed Sentinels |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@AgQAAIoABFA]] | The Blinding Vale |
| Neck | [[item:251142@AgQAAIoABFA]] | Murder Row |
| Shoulder | [[item:271553@AgQAAkjABFA]] | Tier / Catalyst |
| Cloak | [[item:251190@AgQAAIoABFA]] | The Blinding Vale |
| Chest | [[item:271558@AgQAAkjABFA]] | Tier / Catalyst |
| Wrist | [[item:239648@FiQAAIQAXA8YiqD_sO3WzSB]] | Crafting |
| Gloves | [[item:271556@AgQAAIoABFA]] | Tier / Catalyst |
| Belt | [[item:239664@BiQAAIQA8z6cbNLF]] | Crafting |
| Legs | [[item:271554@AgQAAkjABFA]] | Tier / Catalyst |
| Boots | [[item:251137@AgQAAIoABFA]] | Murder Row |
| Ring 1 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Ring 2 | [[item:252258@AgQAAIoABFA]] | Voidscar Arena |
| Trinket 1 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Trinket 2 | [[item:250224@AgQAAIoABFA]] | Voidscar Arena |
| Main Hand | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off Hand | [[item:251191@AgQAAIoABFA]] | The Blinding Vale |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:250215@BgQAAIQACKgTBA]]  <br>[[item:270164@BgQAAIQA5IgTBA]]  <br>[[item:273796@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270170@AgQAAkjAOFA]]  <br>[[item:250214@AgQAAIoABFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAkjAYFA]] |
| **B-Tier** | [[item:270161@AgQAAkjAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C-Tier** | [[item:251792@AAQAAEUA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:273794@AgQAAIoAOFA]]  <br>[[item:251785@AAQAAEUA]] |
| **Junkyard** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:158368@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |

### Embellishments

- 1x [[item:245875]]
  
  - Only crafted on your main hand or off-hand weapon. Craft it on your main hand for more power early on or on your off-hand for long-term BiS.
- 1x [[item:240166]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 2x [[item:240166]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 1x [[item:240166]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak** or **Boots** depending on your available gear.
- [[item:239664]]

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266996]]
  - [[item:242744]]
  
  
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241288]]
  
  
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique*
    
    - [[item:240892]]
    - [[item:240900]]
    - [[item:240906]]

### Enchantments

:::columns
:::column
| Head | [[item:244007]]  <br>[[item:275707@BAAAAIQA]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAIQA]] |
| Waist | [[item:275707@BAAAAIQA]] |
| Legs | [[item:240133]] |
| Boots | [[item:244009]] |
| Ring 1 | [[item:243957@BAAAAIQA]] |
| Ring 2 | [[item:243957@BAAAAIQA]] |
| Weapon | [[item:243973]] |

:::

:::column
:::gear **Shadow Priest** Enchantments in Raid
```json
{
  "source_code": "JQFWCEQ5NDQA7TDBCAAAAcSuDEwF5OAAAAQBTUACEUgqJABApoDGAQQ94mAGRgAKJk7AAAAAAEQB5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 背部 | [[item:243977]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAIQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a  **Shadow Priest** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:274738]]-- Mag'har Orc
  
  - Strong racial for damage both because of [[spell:274738]] which lines up with [[talent:103674]].
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your  **Shadow Priest**.

## Macros

Discover recommended macros for **Shadow Priests** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:32375]] -- *Casts [[spell:32375]] on your cursor without confirmation.***

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

:::

:::details Mouseover Macros
**[[spell:34914]]** -- *Casts [[spell:34914]] on your mouseover or target.*

```wow-macro
#showtooltip 
/cast [@mouseover,exists] [] Vampiric Touch
```

**[[spell:213634]]** -- *Casts[[spell:213634]] on your mouseover or target.*

```wow-macro
#showtooltip 
/cast [@mouseover,exists] [] Purify Disease
```

:::

:::details Utility Macros
**Angelic Feather on player - *Uses your [[spell:121536]]* on your feet.**

```wow-macro
#showtooltip
/cast [@player] Angelic Feather
```

**Cancelaura *[[spell:47585]]* - *Cancels your [[spell:47585]]* without having to wait a gcd.**

```wow-macro
#showtooltip Dispersion
/cast Dispersion
/cancelaura Dispersion
```

**This macro prevents you from cancelling your Void Torrent if accidentally press it twice**

```wow-macro
#showtooltip
/stopmacro [channeling:Void Torrent]
/cast [known:Void Torrent] Void Torrent
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their  **Shadow Priest**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/WoWSqdzqzdqdzqdzcrnShozdqzqdt_022626_17qzqzqdzqdzqdzqdzqdzzdqzdqzddqzdq0008-1024x631.png>)

**Shadow Priest** Interface in Mythic+

:::accordion
:::details Addons
- **HealthBarColo** *-- Player, Target and Focus Frame replacement* 
  
  - Adds custom Player, Target and Focus frames with options to remove secondary recourses.
- **BetterCooldownManager** -- CooldownManager enhancement
  
  - Adds extra customization to your cooldown manager while also providing additional information like resources etc.
- **UnhaltedUnitFrames** -- User Interface Replacement
  
  - Adds custom Boss frames with more customization.
- **BigWigs** -- Generic Boss Mod
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat colouring, and support for custom scripting.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **Quartz** -- Cast Bars replacement
  
  - Adds custom Cast Bars with more customization.

:::

:::

## Changes this Patch

:::accordion
:::details **Patch 12.**1
- *Developers' notes: For Shadow in Curses of Ula'tek, we're intending to improve Voidform gameplay and are adding an additional source of multi-target damage to reduce the spec's reliance on Psychic Link in AoE situations. For Voidform, we're updating Void Volley to be a limited use ability that can be used a set number of times during Voidform which leaves more room in the rotation while giving you the chance to use it at its most opportune moment. We've also updated Voidform support talents to have more noticeable effects to align with our goals.*
- New Talent: Shadeburst – Shadowy Apparitions that float towards your primary target explode, dealing Shadow damage to all enemies within 8 yards. Damage reduced beyond 5 targets.
- Improved Voidform has been redesigned – Voidform increases your spell damage by an additional 5% and grants 2 additional uses of Void Volley.
- Ancient Madness has been redesigned – Shadow Word: Madness increases your Haste during Voidform by 2% and increases its duration by 1.5 seconds, stacking up to 5 times. When Voidform ends, the Haste lingers and decays over 10 seconds.
- All ability damage done increased by 8%.
- Void Volley damage reduced by 10%.
- Voidform now grants 3 uses of Void Volley instead of Void Volley having a cooldown during Voidform.
- Power Word: Shield absorb increased by 25%.
- Idol of N'Zoth now generates 2 Insanity (was 4) at 50 stacks and 6 Insanity (was 12) at 100 stacks.
  
  - *Developers' notes: Insanity generation from this talent has been high relative to other passive sources, and we've been feeling there's too much Insanity being generated overall to where it can become difficult to spend Insanity and keep up with rotational procs. We're bringing the Insanity generation of this talent down to help balance the Insanity economy.*
- Fixed an issue causing Tentacle Slam to apply extra stacks of Horrific Visions when talented for Maddening Tentacles and Idol of N'Zoth.
- Fixed an issue causing Improved Voidform to generate Insanity when casting Voidform.
- Phantom Menace has been removed.
- Hero Talents
  
  - Archon
    
    - Focused Outburst has been redesigned – Void Volley deals 5% increased damage and Shadow Word: Madness casts during Voidform unleash a Void Volley at your target at 25% effectiveness.
    - Resonant Energy has been slightly redesigned – Creating a Halo increases your spell damage by 2% for 10 seconds, stacking up to 4 times.

:::

:::

## FAQ

:::accordion
:::details Why do I keep dying?
Make sure to always pre-use your [[spell:586]] and [[spell:193063]] when you don’t have your [[spell:19236]] or [[spell:47585]] ready.

:::

:::

---

### Credits

Written By: **Soda**

Reviewed By: **Meeres**

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1.

**2026-02-24** Updated for patch 12.0.1.

**2026-01-20** Updated for patch 12.0.



:::
