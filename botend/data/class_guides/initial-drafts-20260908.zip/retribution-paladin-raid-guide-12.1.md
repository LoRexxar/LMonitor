欢迎来到魔兽世界12.1版本的**惩戒 圣骑士** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始升级吗？快去看看升级攻略吧！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 3/5 · 强

范围伤害 · 4/5 · 一般

功能性 · 2/5 · 一般

生存能力 · 5/5 · 优秀

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **惩戒 圣骑士** 团队副本 最佳配装
```json
{
  "source_code": "JUfAwHrRAc__AEQakQggAEAAvj7AH16AOFQApfBBAkCAAQQrDQRrDkjAkVDG24VNWYTAnRCBCgQAAUTuDIcAOFQAsRCBCgQAAkQuDkjAOFQAmRCBAiQAAoQrDkjAOFQAGYCBQARAAg0-SkjAWYjTBEABhOABIAAA5V2AkqCB3WTAKE6AEiQAAkXZDQqKEQQrDcbNLFQAqRCBAgQAAkjAOFQAcfBBCiQAAUPuDQQrDkjAOFQAZfBB6IBA481HEAAGAAAG24VN5IQAdJjDAwV3XQAAAEAAYFQA1eBBCgQAA0TuDkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240967]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240916]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:271462]] | [[item:240906]] |
| 腿部 | [[item:271878]] | [[spell:1243976]] |
| 脚部 | [[item:237828]] | [[item:222585]] · [[item:273060]] |
| 腕部 | [[item:237834]] | [[item:240900]] · [[item:222585]] · [[item:273060]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268252]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:244029]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**惩戒 圣骑士**，你可以使用内在之光，它会强化你的大多数强力法术，例如[[spell:184575]]、[[spell:383328]]和[[spell:53385]]。

**等级2** 在 [[talent:102519@FJQA41dBCIA]] 期间，使 [[spell:383328]] 和 [[spell:53385]] 的伤害总共提高 20%。 **等级3** 进一步增强你的 [[spell:184575]]，使其在你触发 [[spell:231843]] 时，现在能以正面锥形范围造成 神圣 伤害。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-retribution.webp>)

内在之光

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:115435]]
    
    - 现在已将 [[spell:343721]] 内置其中。此外，它还经过了些许重做，现在会作用于所有被命中的目标，而不仅仅是1个。
  - [[talent:102511]]
    
    - 在你按下 [[talent:102519@FJQA41dBCIA]] 后，第一次使用神圣能量消耗技能时，会返还所消耗的 神圣 能量。
- **职业天赋树**
  
  - [[talent:136127]]
    
    - 现在你的 [[spell:498]] 还会赋予 [[spell:1261562]]。
  - [[talent:128259]]
    
    - 受到的伤害降低10%。
- **已移除**
  
  - [[spell:343721]]
  - [[talent:136005]]
    
    - 现在被移入圣殿骑士英雄天赋中。

## 英雄天赋

[[talent:123357]]专注于单体目标，并通过[[talent:117823]]进行叠加的顺劈输出，而[[talent:123360]]则专注于增益你的[[talent:102499]]，并通过[[talent:117696]]的持续伤害（DoT）来造成伤害。

:::tabs
:::tab [[talent:123357]]
- 施放 [[talent:102497]] 会给予你 [[spell:427453]]——一个消耗 5 点神圣 能量 的技能，在使用前会替代 [[talent:102497]]。
- 随着时间推移，你会获得 [[talent:117815]] 的层数。达到 60 层时，你会获得一次免费的[[spell:427453]]，由于它和 [[talent:102497]] 共用同一个按键绑定，所以你必须在此之前施放它。

#### 倾天圣威 互动

- 施放 [[spell:427453]] 后，你会获得 [[talent:117823]]，它每 2 秒对你的目标施放一次 [[spell:431625]]，持续 8 秒，并可以通过 [[talent:117811]] 延长持续时间
- [[talent:117823]] 还会给予你 12% 急速，持续 6 秒。

#### 苍穹之锤 互动

- 施放任何消耗神圣 能量 的技能都会触发一次 [[spell:431625]]，如果它暴击则会激活 [[talent:117810]]。[[talent:117823]] 会额外触发一次 [[spell:431625]]。
  
  - 施放 [[spell:427453]] 后，你会立即在主要目标身上触发 2 次 [[spell:431625]]。
- [[talent:117819]]
  
  - 尽量维持高层数非常重要，施放 [[talent:102465]] 每命中一个敌人就会给予你 1 层。

#### 防御特质

- [[talent:117812]]
  
  - [[talent:102497]] 会给予你一个吸收护盾，而 [[spell:427453]] 在使用时会治疗你。

:::

:::tab [[talent:123360]]
#### 晨光 互动

- [[talent:102497]]会使你的下2次神圣能消耗型技能对目标施加[[talent:117696@AJgACA]]。该减益效果会在8秒内对目标周围造成辐射伤害。此外，当你激活[[talent:102593]]或[[talent:125129]]时，你还会对附近4个目标施加[[talent:117696@AJgACA]]，并开始[[talent:117702]]。
- 只要存在任意[[talent:117696@AJgACA]]持续伤害效果生效，你的神圣能消耗型技能便获得5%的额外伤害。在此基础上，每当你施加任意[[talent:117696@AJgACA]]时，你将获得2%急速，持续12秒，且可以叠加。
- [[talent:102497]]会赋予你[[spell:408458]]。

#### 神圣风暴 和愤怒之锤获得了一些新的被动效果

- [[talent:117677@AJgACA]]
  
  - 它们两者的伤害都提高 10%。
- [[talent:117669@AJgACA]]
  
  - 当它们对任意目标造成暴击时，会灼烧目标，在 4 秒内造成一定的辉光伤害。
- [[talent:117668@AJgACA]]

#### 防御特质

- [[talent:117692]]
  
  - 替代 [[spell:85673]]，并会在 16 秒内治疗少量生命值，且对自己使用时治疗量提高 25%。
- [[talent:117695@AJgACA]]
  
  - 当目标身上有 [[talent:117696]] 时，其移动速度降低 50%。

:::

:::

## 天赋

:::tabs
:::tab 单体目标   [[talent:123357]]
:::talents **惩戒 圣骑士** 团队副本中的单体目标配装，搭配[[talent:123357]]
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 何时使用该专精

在单体团队副本战斗中使用此专精，这是你的标准单体输出构筑。它利用 [[talent:115435]] 的组合来打出单体爆发伤害。想要详细了解玩法和优先级列表，请查看下方的深度解析部分，学习如何充分发挥这套构筑的全部潜力！

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你游戏方式的天赋。本节将简要介绍这些天赋及其应用。如需更详细的内容，请查看下方的循环和深度俯冲部分。

#### 专精树

- [[talent:115435]]
  
  - 一个强力的单体爆发冷却技能。
  
  
  
  - 每当 [[talent:102497]] 就绪时，务必将它与该技能组合使用。
- [[talent:102504@FAQAQjiB]]
  
  - 你的主要单体 神圣 能量 消耗技能。
- [[talent:115021]]
  
  - 更频繁地触发你的精通。
- [[talent:102493]]
  
  - 你的自动攻击有15%的几率重置 [[talent:102498]]。
- [[talent:115438]]
  
  - 如果目标身上有 [[talent:114830]]，你对其造成的神圣伤害提高5%。

#### 职业树

- [[talent:135564@FJQADdhACIA]]
  
  - 对目标施放[[spell:20271]]。
  - 主要用于获取神圣能量。
- [[talent:102625]]
  
  - 以100%移动速度移动，持续3秒。
  
  
  
  - [[talent:102592]] 使你获得2层充能而不是1层。
- [[talent:102583]]
  
  - 一个强大的单体治疗技能，可用于救助友方目标。
- [[talent:102604@AJgACA]]
  
  - 避免仇恨或减免物理伤害的好方法。
- [[talent:102602]]
  
  - 非常适合用于坦克或在首领战中被特定法术影响的玩家。
- [[talent:136594]]
  
  - 用于打断任意法术的打断技能。
- [[talent:128251]]
  
  - 你在8秒内免疫减速效果。
  - [[talent:115454]]
  
  
  
  - 当你对另一名玩家施放[[talent:128251]]时，你自己也会获得该效果，且你们双方都会获得30%的移动速度提升
- [[talent:128257]]
  
  - 你受到的任何治疗中会有10%同样作用于你的近战营地。
- [[talent:128259]]
  
  - 受到的伤害降低10%

#### 英雄天赋

更多信息请访问上方的**英雄天赋**部分。

- [[talent:136005]]
- [[talent:136004]]
- [[talent:136184@FAQAgldB]]

:::

:::tab 范围伤害   [[talent:123357]]
:::talents **惩戒 圣骑士** 在团队副本中搭配的范围伤害配置[[talent:123357]]
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxYMGmxGbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxMzGWmZmZMjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxYMGmxGbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxMzGWmZmZMjhBDA"
}
```
:::

### 何时使用该专精

当战斗需要更多范围伤害或 AoE（多目标）输出时使用此配置。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 专精树

新增：

- [[talent:102521@FAQAyliB]]
- [[talent:102515]]
- [[talent:115452]]

移除：

- [[talent:115440@FAwAbHNBvj4AQjiB]]
- [[talent:115483]] 2x

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:223817]] 额外有10%的几率触发，且消耗它时会获得[[spell:1305230]]，使你造成的神圣伤害提高10%，持续12秒。
- **4件套：** 消耗[[spell:223817]]会获得[[spell:1306161]]，强化你的其他神圣能量消耗技能，在其主要目标处召唤一名圣光仲裁者，造成神圣伤害，并对8码范围内的敌人造成神圣伤害。[[spell:1306161]]处于激活状态时无法触发。

### 单体目标

:::tabs
:::tab [[talent:102525]]
想要了解更多关于[[talent:102525]]的信息，请前往深层俯冲部分阅读！

### 起手爆发

你的开场连招的主要目标应该是通过使用[[spell:184575]]紧接[[spell:315867]]来积攒到3层神圣 Power。

[[talent:136809@FAQAQjiB]] 特质带有一个随机因素，会影响你何时获得 神圣 能量。具体来说， 神圣 能量 在第2次自动攻击时获得，但由于随机因素可能会有所变化。在开怪阶段，要注意这种可变性。假设你没有如期获得 神圣 能量。在这种情况下，你可能需要使用一个生成技能来填补空缺，或者跳过1个生成技能，因为 [[talent:136809@FAQAQjiB]] 已经为你获得了施放 神圣 能量 所需的 ，以便在你的 [[talent:115435]] 窗口期内施放 [[spell:85256]]。

#### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士** 标准起手
```json
{
  "source_code": "IUEMJI0_QLAAAAAACdePFUACIE85DUACI0bhGUACIgQTBUACIs0pEUACE8yTBcAMAIECNFAAAAAAC9P0CA"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
5. [[spell:85256]]
6. [[spell:304971]]
7. [[spell:20271]]
8. [[spell:85256]]
9. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::rotation **惩戒 圣骑士** 快速起手
```json
{
  "source_code": "I0DMII0_QLAAAAAACt0pEUACIcePFUACIE85DUACI0bhGUACIgQTBUACo8P0CAAAAAgQI0UA"
}
```
1. [[spell:184575]]
2. [[spell:304971]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:85256]]
7. [[spell:184575]]
8. [[spell:85256]]
:::

#### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:85256]]（当接近 5 点 神圣 能量 时施放，避免能量超出上限（神圣 能量 溢出）而搞乱你的爆发窗口。
2. 冷却好了就施放 [[talent:115435]]。
3. 冷却好了就施放 [[talent:102497]]，以触发 [[talent:102525]]（需要 2 点 神圣 能量）。前提是选择了该天赋！！
4. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
5. 施放 [[talent:102498]]（以维持 [[talent:114830]] 和 [[talent:115438]]）。
6. 冷却好了就施放 [[talent:102465]]。
7. 施放 [[spell:315867]]（若 神圣 能量 为 3 点或以下）。
8. 施放 [[talent:102498]]（若 神圣 能量 为 3 点或以下）。

:::

:::tab [[spell:339044]]
想要了解更多关于 [[spell:339044]] 的内容，请前往深入 俯冲 章节！

你的开场连招的主要目标应该是通过使用[[spell:184575]]紧接[[spell:315867]]来积攒到3层神圣 Power。

[[talent:136809@FAQAQjiB]] 特质带有随机因素，会影响你获得 神圣 能量的时机。具体来说， 神圣 能量 在第2次自动攻击时获得，但由于随机性可能会有所变化。在开局阶段，请注意这种可变性。假设你没有按预期获得 神圣 能量。在这种情况下，你可能需要使用一个生成技能来填补空缺，或者跳过1个生成技能，因为 [[talent:136809@FAQAQjiB]] 已经为你获得了 神圣 能量 施放 [[spell:85256]] 所需的，在你的 [[talent:115435]] 窗口内。

### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士** 标准起手
```json
{
  "source_code": "I0ELKI0_QLAAAAAACxIfBcAEAI059UQAJwgQBf-AFgAC9WoBFgACI0UAFgACLdKBFgABv8UAHADAChQTBAAAAAgQ_DtA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:85256]]
7. [[spell:304971]]
8. [[spell:20271]]
9. [[spell:85256]]
10. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::group
:::rotation **惩戒 圣骑士** 快速起手
```json
{
  "source_code": "IUELJI0_QLAAAAAACxIfBcAEAI0SnSQAJwgQn3TBFgACBf-AFgAC9WoBFgACI0UAFgAK_DtAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:343527]]
5. [[spell:255937]]
6. [[spell:427453]]
7. [[spell:85256]]
8. [[spell:184575]]
9. [[spell:85256]]
:::

:::

#### 延迟 圣洁鸣钟 起手

#### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:85256]]（当接近 5 点 神圣 能量 时施放，避免能量超出上限（神圣 能量 溢出）而搞乱你的爆发窗口。
2. 冷却好了就施放 [[talent:115435]]。
3. 冷却好了就施放 [[talent:102497]]，以触发 [[talent:102525]]（需要 2 点 神圣 能量）。前提是选择了该天赋！！
4. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
5. 施放 [[talent:102498]]（以维持 [[talent:114830]] 和 [[talent:115438]]）。
6. 冷却好了就施放 [[talent:102465]]。
7. 施放 [[spell:315867]]（若 神圣 能量 为 3 点或以下）。
8. 施放 [[talent:102498]]（若 神圣 能量 为 3 点或以下）。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:102525]]
想要了解更多关于[[talent:102525]]的信息，请前往深层俯冲部分阅读！

### 起手爆发

如果你在连招前期过早使用[[spell:304971]]会导致神圣 Power溢出，在某些情况下你可以将它延后到[[spell:427453]]之后再使用。

#### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士 标准开局**
```json
{
  "source_code": "IUEMJI0_QLAAAAAACdePFUACIE85DUACI0bhGUACEkI0BcAEAI0SnSQAJggQv8UAHADAClI0AAAAAAgQ_DtA"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
5. [[spell:53385]]
6. [[spell:304971]]
7. [[spell:20271]]
8. [[spell:53385]]
9. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::rotation
```json
{
  "source_code": "IwDMII0_QLAAAAAACt0pEUACIcePFUACIE85DUACI0bhGUACEkI0BcALAI0_QLAAAAAAClI0"
}
```
1. [[spell:184575]]
2. [[spell:304971]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:53385]]
7. [[spell:184575]]
8. [[spell:53385]]
:::

#### 多目标 / 范围伤害 优先级列表

1. 当你接近 5 点[[talent:102499]]时施放 神圣 能量.
2. 当你的 [[talent:102497]] ≤2 时，冷却转好就施放 [[talent:102525]] 以触发 神圣 能量.
3. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
4. 施放 [[talent:102498]] 以维持 [[talent:114830]] 和 [[talent:115438]]。
5. 冷却转好就施放 [[talent:102465]]。
6. 如果你的 [[spell:315867]] 较少，则施放 神圣 能量 或用来维持 [[talent:117819]]。
7. 如果你有 3 层[[talent:102499]]，则施放 神圣 能量.

:::

:::tab [[spell:339044]]
想要了解更多关于 [[spell:339044]] 的内容，请前往深入 俯冲 章节！

### 起手爆发

如果你在连招前期过早使用[[spell:304971]]会导致神圣 Power溢出，在某些情况下你可以将它延后到[[spell:427453]]之后再使用。

#### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士 标准开局**
```json
{
  "source_code": "I0ELKI0_QLAAAAAACxIfBcAEAI059UQAJwgQBf-AFgAC9WoBFgABJCdAHABACt0pEEQCII0LPFwBwAgQJCNAAAAAAI0_QLA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:53385]]
7. [[spell:304971]]
8. [[spell:20271]]
9. [[spell:53385]]
10. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::rotation
```json
{
  "source_code": "IQELJI0_QLAAAAAACxIfBcAEAI0SnSQAJwgQn3TBFgACBf-AFgAC9WoBFgABJCdAHwCAC9P0CAAAAAgQJCN"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:343527]]
5. [[spell:255937]]
6. [[spell:427453]]
7. [[spell:53385]]
8. [[spell:184575]]
9. [[spell:53385]]
:::

#### 多目标 / 范围伤害 优先级列表

1. 当你接近 5 点[[talent:102499]]时施放 神圣 能量.
2. 当你的 [[talent:102497]] ≤2 时，冷却转好就施放 [[talent:102525]] 以触发 神圣 能量.
3. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
4. 施放 [[talent:102498]] 以维持 [[talent:114830]] 和 [[talent:115438]]。
5. 冷却转好就施放 [[talent:102465]]。
6. 如果你的 [[spell:315867]] 较少，则施放 神圣 能量 或用来维持 [[talent:117819]]。
7. 如果你有 3 层[[talent:102499]]，则施放 神圣 能量.

:::

:::

## 深层 俯冲

:::tabs
:::tab [[talent:102525]]
- 当你选择了 [[talent:102525]] 天赋时，你无法直接使用 [[talent:102593]] 或 [[talent:125129]]。相反，使用 [[talent:102497]] 会触发你在天赋中所选择的冷却时间，持续数秒。此外，任何 神圣 能量 消耗技能都有较小的几率触发你所选的天赋，额外延长 5 秒；如果该法术正处于激活状态时触发，则会延长你的 [[talent:125129]] 或 [[talent:102593]]。
- 不要闲置不用 [[talent:102497]]，因为 [[talent:102513]] 有 1 分钟冷却时间，而 [[talent:115435]] 有 30 秒冷却时间。推迟 灰烬觉醒 也会推迟你所有其他的冷却技能。

#### 处决宣判

- 当你选择[[talent:115435]]作为你的次要冷却技能时，最优做法是在[[talent:115435]]之后使用[[talent:102497]]。这是因为获得[[talent:102593]]带来的收益不会影响[[talent:115435]]，而且你希望在[[talent:115435]]的持续期间内翅膀有完整的覆盖时间。尽量在[[talent:115435]]冷却结束前就备好3层神圣 Power，以便冷却一好就能立即使用。

#### 使用英雄天赋 圣殿骑士 时

:::rotation **惩戒 圣骑士** [[talent:115435]] 在 团队副本 中的技能顺序
```json
{
  "source_code": "H0BMEI0_QLAAAAAACdePFUACoE85DAAAAAgQ9WoB"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
:::

#### 使用英雄天赋 烈日先驱 时

:::rotation **惩戒 圣骑士** [[talent:115435]] 在 团队副本 中的技能顺序
```json
{
  "source_code": "HUDLHI0_QLAAAAAAC9yTBcAEAI059UQAJwgQI0UAFgACBf-AFgAKI0UAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:20271]]
3. [[spell:343527]]
4. [[spell:85256]]
5. [[spell:255937]]
6. [[spell:85256]]
7. [[spell:85256]]
:::

:::

:::tab [[talent:102519@FJQA41dBCIA]]
- 当首领战或地下城允许你不错过任何冷却窗口时选择此天赋。
- 不要让 [[talent:102519@FJQA41dBCIA]] 闲置超过几秒，因为你的大部分伤害来自于将它与其他1分钟冷却技能结合使用。如前所述，除非你正在使用 [[spell:343527]]，否则总是先使用 [[talent:102519@FJQA41dBCIA]]，若是后者，则按照下文解释的特定策略执行。
- 延迟 [[talent:102519@FJQA41dBCIA]] 也会延迟你的其他次要冷却技能。
- 使用饰品时，不要扣住你的 [[talent:102519@FJQA41dBCIA]]，因为它不会显著提升饰品的总体伤害，但它确实会提高它们的暴击几率。
- 对于有90秒冷却的饰品，除非你有一件能提供大量精通或力量加成的饰品，否则就冷却好了就用。在那种情况下，尽量将其与 [[talent:102519@FJQA41dBCIA]] 对齐使用。

:::rotation **惩戒 圣骑士** [[talent:115435]] 优先级列表
```json
{
  "source_code": "HkBYEIkpHRAAAAAACwIfAAAACs0pEAAACE85DA"
}
```
1. [[spell:280486]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:255937]]
:::

:::

:::

### 小型冷却技能

要发挥你的全部潜力，你还必须知道如何将小技能冷却时间的收益最大化。

:::tabs
:::tab [[talent:115435]]
- 你在[[spell:343527]]期间的计划是尽可能在其持续时间内打入更多的终结技能。由于其爆发窗口短暂且缺乏初始伤害，它在[[talent:102593]]或[[spell:384392]]之外表现不强。
- 始终在[[talent:102593]]之前施放[[spell:343527]]。
- 在冷却完毕时使用[[spell:343527]]，以确保它与其他冷却技能对齐。
- 如果你选择了[[talent:102525]]，务必在[[spell:255937]]之前使用[[spell:343527]]。

#### 使用英雄天赋 圣殿骑士 时

:::rotation **惩戒 圣骑士** [[spell:343527]] 的快速优先级列表
```json
{
  "source_code": "H0BMEIEeGTAAAAAACdePFUACoE85DAAAAAgQ9WoB"
}
```
1. [[spell:312952]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
:::

#### 使用英雄天赋 烈日先驱 时

:::rotation **惩戒 圣骑士** [[spell:343527]] 而不使用 [[talent:102593]] 和 [[talent:102465]]
```json
{
  "source_code": "HUDLHI0_QLAAAAAAC9yTBcAEAI059UQAJwgQI0UAFgACBf-AFgAKI0UAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:20271]]
3. [[spell:343527]]
4. [[spell:85256]]
5. [[spell:255937]]
6. [[spell:85256]]
7. [[spell:85256]]
:::

:::

:::

### 惩戒 通用机制

如果你不重视基础，就无法精通 **惩戒 圣骑士**。

#### 远征打击

- 这会取代你的自动攻击和你正常的 [[spell:35395]] 法术，成为一种独立的自动攻击，每次攻击产生 1 个 神圣 能量 每第2次攻击。
- 在你的开场或战斗中的任何冷却期间，你的 神圣 能量 可能有所不同。你可以从4-5个 神圣 能量 就在[[talent:115435]]之前，这意味着你需要在任何其他法术之前立即按下[[spell:85256]]。这可能会改变你的开怪方式，因此理解优先级列表以知道何时按下哪些按键非常重要。

#### 精通

- **惩戒 圣骑士** [[spell:267316]] 已经被重做了。现在 [[spell:315867]] 不仅会强化你的消耗型技能，还有几率对你的主要目标触发额外的神圣伤害。由于精通长期以来都是一个短板，这一改动带来了显著的收益。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 爆发技能使用

- 在**躁动的不安曼尼**小怪刷新时留好爆发技能会很有帮助，但只有当你能在 BigWigs 计时条上看到小怪即将刷新时才值得保留爆发技能，不要长时间握着不放。

### 防御技能使用

- 当**内克扎莉**施放[[spell:1288772]]时使用防御技能。

### 首领攻略技巧

- 当**内克扎莉**施放[[spell:1292034]]时，注意坦克所在的位置。不要站在她和她的目标之间。

:::

:::tab 陵寝哨兵
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 爆发技能使用

- 密切关注**陵寝哨兵**能量达到100并施放[[spell:1284606]]的时机，因为你肯定不希望在那时刚刚交掉技能却无法造成任何伤害。

### 防御技能使用

- 在吸收[[spell:1288282]]时使用防御冷却技能。

### 首领攻略技巧

- 在[[spell:1284606]]期间，你头上会被标记1、2或3个毒液球。将1与3组合，2与2组合，目标是凑满4个。

:::

:::tab 迷失的探险者
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 防御技能使用

- 如果吸收[[spell:1300237]]时其中没有太多人分担伤害，请使用防御冷却技能。

### 首领攻略技巧

- 如有需要，你可以[[spell:642]]来越过[[spell:1297650]]，但与团队一起行动、跳上蘑菇相比并没有什么实际好处。如果你脱离了站位而冲击波即将到来，再使用它。

:::

:::tab 瓦什尼克
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 防御技能使用

- 在击杀火焰小怪后受到[[spell:1285979]]影响时使用防御技能，尤其是当叠加超过1层时。

### 首领攻略技巧

- 帮助中了 [[spell:1295224]] 的队友移出他们脚下的圈，使其重新可以被治疗。

:::

:::tab 斯索拉克
:::talents [[talent:123357]] **惩戒 圣骑士** 团队副本单体输出天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 爆发技能使用

- **斯索拉克**在[[spell:1286033]]期间受到的伤害提高。

### 防御技能使用

- 如果你被 [[spell:1287083]] 龙卷风击中，使用一个防御技能。

### 首领攻略技巧

- 当你受到 [[spell:1285616]] 的影响时，将自己站在会与另一名玩家相撞的位置。如有需要，使用 [[spell:642]] 来避免自己被击飞出去。

:::

:::tab 双子毒牙
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 防御技能使用

- 当你受到 [[spell:1290878]] 影响时，使用一个防御技能。

### 首领攻略技巧

- 尽可能帮助分摊 [[spell:1289201]]，但不要叠加过多层 [[spell:1292348]]。
- 避免被 [[spell:1292806]] 波动击中。

:::

:::tab 盘卷祭坛
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 爆发技能使用

- 确保在第二阶段后的间歇阶段保留所有进攻技能，此时**祖尔加**会因[[spell:1304033]]而受到100%的额外伤害。

### 防御技能使用

- 当你受到[[spell:1286901]]影响时使用防御技能。

### 首领攻略技巧

- 务必优先拾取你的所有**灵魂残片**，如果你被[[spell:1286901]]击中的话，否则你将[[spell:1286837]]。

:::

:::tab 乌拉特克
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

乌拉特克 尚未在 12.1 的 PTR 服务器上出现，将会在补丁上线和赛季开始时首次亮相。上面提供的天赋应该是一个不错的起点。  
乌拉特克 以及所有首领的更新将在即将到来的世界首杀竞速赛结束后很快跟进。

:::

:::tab 尼姆瑞莎·唤波者
:::talents [[talent:123357]] **惩戒 圣骑士** 团本单体/顺劈天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYAAAAAAYUGzwMjtxsNMz2MGjxwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 爆发技能使用

- 在**躁动的不安曼尼**小怪刷新时留好爆发技能会很有帮助，但只有当你能在 BigWigs 计时条上看到小怪即将刷新时才值得保留爆发技能，不要长时间握着不放。

### 防御技能使用

- 当**内克扎莉**施放[[spell:1288772]]时使用防御技能。

### 首领攻略技巧

- 当**内克扎莉**施放[[spell:1292034]]时，注意坦克所在的位置。不要站在她和她的目标之间。

:::

:::

## 属性优先级

了解你作为 **惩戒 圣骑士** 在 团队副本 首领战中获得最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问 **[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **惩戒 圣骑士** 团队副本中的属性优先级
```json
{
  "source_code": "HoAJFQQMgQCKBEQABA"
}
```
**力量 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可减少“**范围效果**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外的治疗。
- **加速** - 小众副属性，但可能非常有用，过去已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271465@BgQAAYEA5IgTBA]] | 套装 |
| 项链 | [[item:268265@BkCAAYEAE06QRrTOCQWNYYjX1YhN]] | 乌拉特克 |
| 肩部 | [[item:271463@BgQAAYEACHgTBA]] | 套装 |
| 披风 | [[item:268253@BAQAAYEAYFA]] | 盘卷祭坛 |
| 胸部 | [[item:271468@BgQAAYEA5IgTBA]] | 套装 |
| 护腕 | [[item:268239@BgQAAYEA5IgTBA]] | 迷失的探险者 |
| 手套 | [[item:271466@BgQAAYEA5IgTBA]] | 套装 |
| 腰带 | [[item:271462@BgQAAYEA5IgTBA]] | 催化 |
| 腿部 | [[item:271878@RARAAYEAItvE5IgF24UA]] | 乌拉特克 |
| 靴子 | [[item:268260@BgQAAYEA5IgTBA]] | 瓦什尼克 |
| 戒指 1 | [[item:268252@BgQAAYEA5IgTBA]] | 斯索拉克 |
| 戒指 2 | [[item:268249@BgQAAYEA5IgTBA]] | 节点-泽纳斯 |
| 饰品 1 | [[item:270175@BgBAAYEAYYjX1kjA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgBAAYEAYYjX1kjA]] | 盘卷祭坛 |
| 武器 | [[item:268213@DgQAAYEA9k7kjAYF]] | 盘卷祭坛 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251126@DARAAcEANk74iMeVTQB]] | 密谋小径 |
| 颈部 | [[item:273781@BgQAAYEACKQQBA]] | 毒牙祭坛 |
| 肩部 | [[item:251138@DARAAcEA7j74iMeVTQB]] | 密谋小径 |
| 披风 | [[item:193763@BgQAAYEACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:193753@AgQAAIoABFA]] | 红玉新生法池 |
| 腕部 | [[item:251133@BgQAAYEACKQQBA]] | 密谋小径 |
| 手部 | [[item:159413@BARAAcEAuIjX1EUA]] | 诸王之眠 |
| 腰带 | [[item:159418@BgQAAYEACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:273776@DARAAcEAju74iMeVTQB]] | 毒牙祭坛 |
| 脚部 | [[item:159412@BgQAAYEACKQQBA]] | 诸王之眠 |
| 戒指 1 | [[item:273792@BgQAAYEACKQQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:251136@BgQAAYEACKQQBA]] | 密谋小径 |
| 饰品 1 | [[item:273796@BgQAAYEACKQQBA]] | 毒牙祭坛 |
| 饰品 2 | [[item:250228@BgQAAYEACKQQBA]] | 密谋小径 |
| 武器 | [[item:273782@BgQAAYEACKQQBA]] | 毒牙祭坛 |

:::

:::

### 饰品

下面你可以找到可用饰品的主动与被动排名。请注意，根据每个首领战的不同，某些饰品会比其他饰品表现更好。

| 等级 | 饰品 |
| --- | --- |
| S 级 | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A 级** | [[item:270165@AgQAAIoAOFA]] |
| **B 级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C 级** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *——非常适合范围伤害，单体目标则是废料场。* |
| **废料场** |  |

### 美化饰品

- 本节内容很有可能发生变动，因此在进行任何重要的制造业制作之前请回头确认，看看这段文字是否已被删除。如果已删除，则说明我对这些推荐更有信心。
- [[item:245876]] 是最佳的修饰。由于制造业制造的物品装等为331而非334，这意味着你需要使用更低装等的武器来获得 [[item:245876]]。
  
  - 对于初期配装，制作一把带有 [[item:245876]] 的武器无疑是最佳选择，除非你不知怎么已经拥有两把高装等的史诗武器。
- 对于第二个修饰，有许多可行的选择，目前推荐的是 [[item:240167]]。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - **[[item:241324]] 或**
  
  
  
  - **[[item:241326]] 或**
  - **[[item:241322]] *-- 惩戒骑需要在精通和爆击之间取得属性平衡，同时急速也要保持在一个手感流畅的合适百分比。你可以通过配装来实现这种平衡，也可以借助消耗品。* *如果你想了解自己的属性平衡情况以及更需要哪种属性，我建议查看我们的 [Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)。***
- **食物**
  
  - **[[item:255846]]**
- **战斗药水**
  
  - **[[item:241288]]**
- **生命药水**
  
  - **[[item:241304]]**
- **武器临时附魔**
  
  - **[[item:243734]]**
- **强化符文**
  
  - **[[item:259085@AQAAAoF]]**
- **宝石插槽**
  
  - **[[item:240967]] *-- 唯一，每种颜色的宝石各用一颗来强化你的 [[item:240967]]。***
    
    - **[[item:240890]]**
    - **[[item:240906]]**
    - **[[item:240916]]**
    - **[[item:240900]]**

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707@DAAAAYEAvj7A]] |
| --- | --- |
| 肩部 | [[item:244021]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAAYE]] |
| 腰部 | [[item:275707@BAAAAYE]] |
| 腿部 | [[item:244641@BAAAAYE]] |
| 靴子 | [[item:243983]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 武器 | [[item:244029@BAAAAYE]] |

:::

:::column
:::gear **惩戒 圣骑士** 团本中的附魔
```json
{
  "source_code": "JQFZGBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

- 你可以从宏伟宝库商人处购买 [[item:275707]]，为你的 **头盔**、**护腕** & **腰带** 添加插槽。

## 种族

对于追求**惩戒 圣骑士**的极限优化而言，在团队副本中，不同的种族特长可以为你的角色带来巨大的收益。如果这不是你的首要目标，那么选择一个符合你个人风格或幻化喜好的种族同样可行，因为其带来的DPS提升并没有人们渲染的那么夸张。

- [[spell:65116]] -- 矮人
  
  - 可以移除 驱散魔法 和流血减益效果。过去在部分有流血机制的首领战中很有用。
- [[spell:20549]] -- 牛头人
  
  - 一个 范围伤害 昏迷技能非常有价值，因为圣骑士目前缺少这类技能。此外，[[spell:20550]] 在进行高难度内容时也非常实用。
- [[spell:265221]] *-- 黑铁矮人* 
  
  - 它可以移除几乎任何减益效果，并提供一个小幅伤害增益。
- [[spell:25046]] *-- 鲜血精灵* 
  
  - 移除你周围目标身上的 1 个增益效果。
- [[spell:292361]] -- 赞达拉巨魔
  
  - 提供一个基于随机触发率的小幅爆击增益。作为赞达拉巨魔的一大优势是，你可以将 [[spell:291944]] 和 [[spell:642]] 组合使用来把自己完全治满。
- [[spell:59752]] *-- 人类* 
  
  - 移除你身上的任何昏迷效果，类似于一件 PvP 饰品。[[spell:20598]] 是选择人类种族的主要原因。
- [[spell:28880]] *-- 德莱尼* 
  
  - 除了 [[spell:6562]] 之外没有特别有用的种族技能。
- [[spell:255647]] *-- 光铸德莱尼* 
  
  - 更像是一个娱乐性的种族技能，但别忘了 [[spell:255652]]——当你死亡时它会爆炸，造成少量伤害！

### 推荐

总体而言，可以肯定地说，如果你在意将自己的 DPS 最大化，就应该选择 DPS 最高的种族特性。话虽如此，如果涉及推进终局 团队副本 进度，情况就有些不同了。某些种族特性能极大帮助加快地下城或团队副本中某些首领的攻略进度。尤其是 **矮人** 凭借其 [[spell:65116]] 在最新的  **丁达尔·迅贤** & **火光之龙菲莱克** 的 **世界首杀竞速** 中提供了帮助，因为在上述战斗的关键时刻能够轻松自我驱散。

## 宏

探索 **惩戒 圣骑士** 在团队副本战斗期间，并观看一段关于为你的角色创建简单宏的快速视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏 / 焦点宏
**在不切换目标的情况下对焦点目标施放[[spell:96231]]。**

```wow-macro
#showtooltip 责难
/cast [@focus] 责难
```

**在完全不切换目标的情况下对焦点目标施放[[spell:853]]。**

```wow-macro
#showtooltip 制裁之锤
/cast [@focus] 制裁之锤
```

:::

:::details 鼠标指向宏
**对于以下所有宏，如果你按住鼠标右键，则会将技能施放在你自己身上，而不是鼠标指向的目标。**

**鼠标指向宏，用于** [[spell:19750]]

```wow-macro
#showtooltip 圣光闪现
/cast [@mouseover,exists,help] 圣光闪现 [@player] 圣光闪现
```

**鼠标指向宏，用于 [[spell:85673]]**

```wow-macro
#showtooltip 荣耀圣令
/cast [@mouseover,exists,help] 荣耀圣令 [@player] 荣耀圣令
```

**鼠标指向宏，用于 [[spell:633]]**

```wow-macro
#showtooltip 圣疗术
/cast [@mouseover,exists,help] 圣疗术 [@player] 圣疗术
```

**鼠标指向宏，用于[[spell:305394]]**

```wow-macro
#showtooltip 自由祝福
/cast [@mouseover,exists,help] 自由祝福 [@player] 自由祝福
```

**鼠标指向宏，用于 [[spell:6940]]**

```wow-macro
#showtooltip 牺牲祝福
/cast [@mouseover,exists,help] 牺牲祝福; 牺牲祝福
```

**鼠标指向宏，用于 [[spell:1022]]**

```wow-macro
#showtooltip 保护祝福
/cast [@mouseover,exists,help] 保护祝福 [@player] 保护祝福
```

**鼠标指向宏，用于 [[spell:213644]]**

```wow-macro
#showtooltip 清毒术
/cast [@mouseover,exists,help] 清毒术 [@player] 清毒术
```

:::

:::details 冷却宏
**使用宏把饰品用在 [[talent:102593]]**

```wow-macro
#showtooltip 复仇之怒
#show 复仇之怒
/cast 复仇之怒
/use 烬魄之灰
/use 14
```

:::

:::

## 插件

下方是作者为其 **惩戒 圣骑士**所用用户界面的截图，其中概述了使用了哪些插件以及它们在团队副本中如何帮助你更轻松地进行游戏。

一旦我们确定哪些插件会完整可用以及我个人将使用哪些插件，就会发布新的 UI。请在团队副本层级开放之前或之后的更新时回来看完整解析

![](<https://assets-ng.maxroll.gg/wordpress/dddd-1-1024x651.jpg>)

**惩戒 圣骑士** 团队副本 中的界面。

:::accordion
:::details 插件
- **MRT** -- 备注、团队副本冷却等信息
  
  - 对团队副本玩家非常有用的插件，尤其适合团队副本团长和官员。
- **ElvUI** *-- 完整的用户界面替换* 
  
  - 一款以用户友好为核心设计的界面插件，附带许多标准界面所没有的额外功能。
  - 当然，你也可以选择使用 Shadowed Unit Frames (SUF) 加上任意动作条插件，或者直接使用原生界面。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些迷你插件旨在为特定的一场团队副本战斗触发警报信息、计时条、音效等。
- **Plater**  -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的减益效果监控、仇恨染色，并且支持类似 WeakAuras 的脚本功能，还可配合 wago.io 和 WeakAuras-Companion 来更新 Mod/脚本/配置文件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- **惩戒**:

- Apex 天赋：Light Within（内里之光，第 1 级）现在有额外效果——战争艺术和 Righteous Cause（正义之因）现在各可额外累积一次。
- 战争艺术已更新——现在使公正之剑伤害提高 80%（原为 150%）。
- 公正之剑伤害提高 40%。
- 最终审判伤害提高 15%。
- 神圣风暴伤害提高 15%。
- 复仇之怒现在使造成的伤害和爆击几率提高 15%（原为 20%）。
- 圣殿骑士打击伤害提高 50%。
- 圣殿骑士斩击伤害提高 50%。
- 审判伤害提高 50%。
- 愤怒之锤伤害提高 50%。
- 圣洁鸣钟的审判现在造成 50% 的额外伤害（原为 100%）。
- Apex 天赋：Light Within（内里之光，第 3 级）伤害降低 25%。
- 圣光闪现治疗效果提高 25%。
- 荣耀圣令治疗效果提高 25%。
- 永恒之火治疗效果提高 25%。
- 战争艺术不再由额外的 Skyfury（天怒）攻击触发。
- 额外的 Skyfury（天怒）攻击在点出远征打击天赋时不再产生神圣能量。
- 远征打击现在使自动攻击速度提高 15%（原为降低 20%）。
- 处决宣判的作用范围半径提高至 10 码，且现在包含目标的碰撞半径（原为 8 码）。
- 英雄天赋
  
  - 圣殿骑士
    
    - 圣光之锤伤害降低 30%。不影响 PvP 战斗。
    - 圣光之锤现在消耗 3 点神圣能量（原为 5 点）。

:::

:::details 11.0.2补丁
- 开发者说明： 新天赋：神圣烈焰 – 神圣风暴造成的伤害提高10%，并且当其命中受到你异端逐除影响的敌人时，会将该效果扩散至最多4个被命中的目标。你对因异端逐除而燃烧的目标造成的神圣伤害提高3%。
- 惩戒的职业天赋树中不再默认提供十字军圣印天赋。
- 审判的职业天赋树中现在默认提供强效审判天赋。
- 神圣之刃不再是天赋，改为11级时学习。
- 荣耀圣令的治疗量提高44%。
- 最终审判的伤害降低10%。
- 圣殿骑士的裁决的伤害降低10%。
- 公正者复仇的伤害降低10%，治疗量现在为最大生命值的3%（原为5%）。
- 愤怒之锤的伤害降低15%。
- 公正之剑的伤害降低20%。不影响复仇之剑。
- 复仇之剑的伤害提高25%。
- 异端逐除的伤害降低10%。
- 神圣风暴的伤害提高25%。
- 圣殿骑士打击的伤害降低10%。
- 圣殿骑士斩击的伤害降低10%。
- 远征打击的伤害降低10%。
- 十字军打击的伤害降低10%。
- 受祝福的勇士对次要目标造成的伤害降低25%（原为降低50%），且现在为1点天赋（原为2点）。
- 已修复光辉荣耀在快速连续触发时无法生效的问题。
- 以下天赋现在为2点（原为1点）：十字军之心
- 狂热者
- 正义先锋已被移除。
- 苍穹遗产移动到了天赋树上正义先锋原来的位置。
- 神圣烈焰现在与复仇之剑处于一个选择节点。

:::

:::details 版本 11.1
- 开发者说明
- 神圣之锤已被重新设计 -- 神圣之锤将环绕你旋转，在8秒内每2秒对附近的敌人造成神圣伤害。生效期间，每消耗1点神圣能量会使神圣之锤的持续时间延长0.5秒。对8个以上目标造成的伤害降低。消耗3点神圣能量，冷却时间1分钟。
- 所有技能伤害提高5%。
  
  - *开发者说明：苍穹之锤的伤害输出在总体伤害构成中高于预期。我们正在将这部分强度重新分配到其他技能上。*
- 最终清算的伤害提高75%。
- 圣光闪现的治疗量提高35%。
- 荣耀圣令的法力消耗已提高至15%（原为10%）。
- 治疗之手现在只会提升圣骑士自身受到的荣耀圣令治疗量（原为提升对盟友的治疗量）。
- 圣洁鸣钟现在即使你未与主目标附近的单位交战，也会对其施放审判。
- 在使用带翼复仇雕文时，征伐现在将持续显示正确的法术视觉效果。
- 烈日先驱
  
  - 第二次日出已更新 – 神圣风暴和愤怒之锤有20%的几率以50%的效果再次施放（原为15%几率、30%效果）。
  - 曜日化身的伤害提高50%。
- 圣殿骑士
  
  - 苍穹之锤的伤害降低30%。
  - 圣光之锤现在可以受益于无可争议的裁决审判。
  - 圣光之锤现在可以受益于它为征伐添加的层数。
    
    - *开发者说明：圣光之锤的重新实现无意间改变了它与征伐和审判的交互方式。我们现已调整这些交互，使其与当前正式服版本保持一致。*
  - 圣光之锤的初次命中现在可以受益于最终清算。

:::

:::

## 常见问题

:::accordion
:::details 问：在拥有4点圣能时[[spell:315867]]并超过5点，值得吗？
**答：如果你是在为[[talent:115435]]做准备，那么值得；如果不是，尽量先打出一次[[talent:102504]]再使用它！**

:::

:::details 问：怪物在[[spell:1022]]之后会盯上我——[[spell:642]]这是为什么？
答：你在这两个技能生效期间仍会产生仇恨，所以要注意它们失效的时候，如果你继续输出，怪物可能会立刻转而攻击你。

:::

:::

---

### 致谢

作者：**Narcolies**

审校者：**Tief**

---

:::changelog 更新记录
**2026-08-04** 更新至12.1版本

**2026-02-21** 更新至12.0.1版本

**2026-01-15** 更新至12.0版本

**2025-10-07** 更新至11.2.5版本

**2025-02-20** 更新至11.1.7版本

**2024-12-17** 更新至11.0.7版本。

**2024-10-23** 更新至11.0.5版本。

**2024-08-17** 更新至11.0.2版本。

**2024-07-24** 攻略撰写于前夕版本



:::
