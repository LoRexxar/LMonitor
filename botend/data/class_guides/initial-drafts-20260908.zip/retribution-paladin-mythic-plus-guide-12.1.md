欢迎来到魔兽世界12.1版本的**惩戒 圣骑士** 大秘境攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你是刚起步、从80级开始练级的玩家？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 大秘境
**单体** · 2/5 · 一般

范围伤害 · 3/5 · 强

功能性 · 3/5 · 一般

生存能力 · 5/5 · 优秀

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **惩戒 圣骑士** 整体最佳装备（BiS）
```json
{
  "source_code": "JUfAwHrRAc__AEQakQggAEAAvj7AH16AOFQApfBBAkCAAQQrDQRrDkjAkVDG24VNWYTAnRCBCgQAAUTuDIcAOFQAsRCBCgQAAkQuDkjAOFQAmRCBAiQAAoQrDkjAOFQAGYCBQARAAg0-SkjAWYjTBEABhOABIAAA5V2AkqCB3WTAKE6AEiQAAkXZDQqKEQQrDcbNLFQAqRCBAgQAAkjAOFQAcfBBCiQAAUPuDQQrDkjAOFQAZfBB6IBA481HEAAGAAAG24VN5IQAdJjDAwV3XQAAAEAAYFQA1eBBCgQAA0TuDkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240967]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240916]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:271462]] | [[item:240906]] |
| 腿部 | [[item:271878]] | [[spell:1243976]] |
| 脚部 | [[item:237828]] | [[item:222585]] · [[item:273060]] |
| 腕部 | [[item:237834]] | [[item:240900]] · [[item:222585]] · [[item:273060]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268252]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:244029]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**惩戒 圣骑士**，你可以使用内在之光，它会强化你大多数强力法术，例如[[spell:184575]]、[[spell:383328]]和[[spell:53385]]。

**等级2** 在 [[talent:102519@FJQA41dBCIA]] 期间，使 [[spell:383328]] 和 [[spell:53385]] 的伤害总共提高 20%。 **等级3** 进一步增强你的 [[spell:184575]]，使其在你触发 [[spell:231843]] 时，现在能以正面锥形范围造成 神圣 伤害。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-retribution.webp>)

内在之光

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:115435]]
    
    - 现在内建了[[spell:343721]]，除此之外它还被小幅重做，现在作用于所有被击中的目标，而不仅仅是1个目标。
  - [[talent:102511]]
    
    - 在你按下[[talent:102519@FJQA41dBCIA]]后，会返还你第一次使用神圣能量消耗技能所消耗的神圣能量。
- **职业天赋树**
  
  - [[talent:136127]]
    
    - 现在你的[[spell:498]]还会赋予[[spell:1261562]]。
  - [[talent:128259]]
    
    - 受到的伤害降低10%。
- **已移除**
  
  - [[spell:343721]]
  - [[talent:136005]]
    
    - 现在已移入圣殿骑士英雄天赋。

## 英雄天赋

[[talent:123357]]专注于单体目标，并通过[[talent:117823]]进行叠加的顺劈输出，而[[talent:123360]]则专注于增益你的[[talent:102499]]，并通过[[talent:117696]]的持续伤害（DoT）来造成伤害。

:::tabs
:::tab [[talent:123357]]
- 施放 [[talent:102497]] 会给予你 [[spell:427453]]，这是一个 5 神圣 能量 消耗技能，在使用之前会替代 [[talent:102497]]。
- 随着时间推移，你会获得 [[talent:117815]] 的层数。达到 60 层时，你会获得一次免费的[[spell:427453]]，你必须在使用 [[talent:102497]] 之前施放它，因为它们绑定同一个按键。

#### 倾天圣威 互动

- 施放 [[spell:427453]] 后，你会获得 [[talent:117823]]，它每 2 秒对你的目标施放一次 [[spell:431625]]，持续 8 秒，并可以通过 [[talent:117811]] 延长持续时间
- [[talent:117823]] 还会给予你 12% 急速，持续 6 秒。

#### 苍穹之锤 互动

- 施放任意 神圣 能量 消耗技能都会触发一次 [[spell:431625]]，如果暴击则会激活 [[talent:117810]]。[[talent:117823]] 会额外触发一次 [[spell:431625]]。
  
  - 施放 [[spell:427453]] 后，你会立即在主要目标上触发 2 次 [[spell:431625]]。
- [[talent:117819]]
  
  - 尽量维持高层数非常重要，施放 [[talent:102465]] 每命中一名敌人会给予你 1 层。

#### 防御特质

- [[talent:117812]]
  
  - [[talent:102497]] 会给予你一个吸收护盾，而 [[spell:427453]] 在使用时会治疗你。

:::

:::tab [[talent:123360]]
#### 晨光 互动

- [[talent:102497]] 使你接下来的 2 个 神圣 能量 消耗技能对目标施加 [[talent:117696@AJgACA]]。该减益效果会在 8 秒内对目标周围造成辐射伤害。此外，当你激活 [[talent:102593]] 或 [[talent:125129]] 时，你还会对附近 4 个目标施加 [[talent:117696@AJgACA]] 并开始 [[talent:117702]]。
- 只要任意 [[talent:117696@AJgACA]] 持续伤害效果存在，你的 神圣 能量 消耗技能就会获得 5% 的额外伤害。在此基础上，每当你施加任意 [[talent:117696@AJgACA]]，你会获得 2% 急速，持续 12 秒，且可以叠加。
- [[talent:102497]] 会赋予你 [[spell:408458]]。

#### 神圣风暴 和愤怒之锤获得了一些新的被动效果

- [[talent:117677@AJgACA]]
  
  - 它们两者的伤害都提高 10%。
- [[talent:117669@AJgACA]]
  
  - 当它们对任意目标造成暴击时，会灼烧目标，在 4 秒内造成一定的辉光伤害。
- [[talent:117668@AJgACA]]

#### 防御特质

- [[talent:117692]]
  
  - 替代 [[spell:85673]]，并会在 16 秒内治疗少量生命值，且对自己使用时治疗量提高 25%。
- [[talent:117695@AJgACA]]
  
  - 当目标身上有 [[talent:117696]] 时，其移动速度降低 50%。

:::

:::

## 天赋

:::tabs
:::tab 范围伤害    [[talent:123357]]
:::talents **惩戒 圣骑士** 在 范围伤害 中的 大秘境 构筑（搭配 [[talent:123357]]  ）
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 何时使用该专精

在你的 大秘境 限时挑战钥石中使用此专精，这应该作为你在 范围伤害 中的标准通用构筑。该构筑让你可以不断施放 [[talent:102499]]，同时你的资源生成技能会顺劈你周围的所有敌人。查看下方的深入解析部分，了解如何 fully 优化这个构筑！

### 改变游戏玩法的天赋

探索专精和职业天赋树中所有显著改变你玩法的天赋。本节提供了这些天赋及其应用的简明概述。如需更详细的了解，请查看下方的工作循环和**深度解析**部分。

#### 专精树

- [[talent:115435]]
  
  - 一个强大的单体爆发冷却技能。
  
  
  
  - 每当 [[talent:102497]] 就绪时，务必将其连接使用。
- [[talent:102504@FAQAQjiB]]
  
  - 你的主要单体 神圣 能量 消耗技能。
- [[talent:115021]]
  
  - 更频繁地触发你的精通。
- [[talent:102493]]
  
  - 你的自动攻击有15%的几率重置 [[talent:102498]]。
- [[talent:115438]]
  
  - 如果目标带有[[talent:114830]]，你对其造成的神圣伤害提高5%。
- [[talent:102511]]
  
  - 神圣伤害提高5%。
  - 你会获得 1 次免费的 神圣 能量 消耗技能，在你施放 [[talent:115435]] 之后

#### 职业树

- [[talent:135564@FJQADdhACIA]]
  
  - 对目标施放[[spell:20271]]。
  - 主要用于获取神圣能量。
- [[talent:102625]]
  
  - 以100%移动速度移动，持续3秒。
  
  
  
  - [[talent:102592]] 使你获得2层充能而不是1层。
- [[talent:102583]]
  
  - 一个强大的单体治疗技能，可用于救助友方目标。
- [[talent:102604@AJgACA]]
  
  - 避免仇恨或减免物理伤害的好方法。
- [[talent:102602]]
  
  - 非常适合用于坦克或在首领战中被特定法术影响的玩家。
- [[talent:136594]]
  
  - 用于打断任意法术的打断技能。
- [[talent:128251]]
  
  - 你在8秒内免疫减速效果。
  - [[talent:115454]]
  
  
  
  - 当你对另一名玩家施放[[talent:128251]]时，你自己也会获得该效果，且你们双方都会获得30%的移动速度提升
- [[talent:128257]]
  
  - 你受到的任何治疗中会有10%同样作用于你的近战营地。
- [[talent:128259]]
  
  - 受到的伤害降低10%

#### 英雄天赋

更多信息请访问上方的**英雄天赋**部分。

- [[talent:136005]]
- [[talent:136004]]
- [[talent:136184@FAQAgldB]]

:::

:::tab 单体   [[talent:123357]]
:::talents **惩戒 圣骑士** 在大秘境中搭配[[talent:123357]]的单体输出Build
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGGDAAAAAAjyYGmZsNmthZ2mxYMzwM2YbAYWmtZmZrZmptZmtZAAbAGAjxMMDmxY2wyMzMjZMMY"
}
```
:::

### 何时使用该专精

某些地下城可能需要更加偏向单体的打法，这套Build能让你打出最高的单体伤害，同时在处理小怪时也不会落后。

### 天赋调整

新增：

- [[talent:115483]] 2x
- [[talent:115440@FAwAbHNBvj4AQjiB]]

移除：

- [[talent:102521@FAQAyliB]]
- [[talent:102515]]
- [[talent:115452]]

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:223817]] 的触发几率额外提高10%，且2件套：[[spell:223817]] 的触发几率额外提高10%，消耗它将获得[[spell:1305230]]，使神圣造成的伤害提高10%，持续12秒。
- **4件套：** 消耗[[spell:223817]]将获得[[spell:1306161]]，强化你的其他神圣之能量消耗技能，在其主要目标处召唤一名光明仲裁者，对其造成神圣伤害，并对8码范围内的敌人造成神圣伤害。在[[spell:1306161]]激活期间无法触发。

### 单体目标

:::tabs
:::tab [[talent:102525]]
想要了解更多关于 [[talent:102525]] 的内容，请前往“深入解析”部分！

### 起手爆发

你开局的首要目标是使用[[spell:184575]]，紧接着使用[[spell:315867]]，将神圣能量堆到3层。

[[talent:136809@FAQAQjiB]] 特质带有随机因素，会影响你获得 神圣 能量的时机。具体来说， 神圣 能量 在第2次自动攻击时获得，但由于随机性可能会有所变化。在开局阶段，请注意这种可变性。假设你没有按预期获得 神圣 能量。在这种情况下，你可能需要使用一个生成技能来填补空缺，或者跳过1个生成技能，因为 [[talent:136809@FAQAQjiB]] 已经为你获得了 神圣 能量 施放 [[spell:85256]] 所需的，在你的 [[talent:115435]] 窗口内。

#### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士** 标准起手
```json
{
  "source_code": "IUEMJI0_QLAAAAAACdePFUACIE85DUACI0bhGUACIgQTBUACIs0pEUACE8yTBcAMAIECNFAAAAAAC9P0CA"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
5. [[spell:85256]]
6. [[spell:304971]]
7. [[spell:20271]]
8. [[spell:85256]]
9. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::rotation **惩戒 圣骑士** 快速起手
```json
{
  "source_code": "I0DMII0_QLAAAAAACt0pEUACIcePFUACIE85DUACI0bhGUACIgQTBUACo8P0CAAAAAgQI0UA"
}
```
1. [[spell:184575]]
2. [[spell:304971]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:85256]]
7. [[spell:184575]]
8. [[spell:85256]]
:::

#### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:85256]]（当接近 5 点 神圣 能量 时施放，避免能量超出上限（神圣 能量 溢出）而搞乱你的爆发窗口。
2. 冷却好了就施放 [[talent:115435]]。
3. 冷却好了就施放 [[talent:102497]]，以触发 [[talent:102525]]（需要 2 点 神圣 能量）。前提是选择了该天赋！！
4. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
5. 施放 [[talent:102498]]（以维持 [[talent:114830]] 和 [[talent:115438]]）。
6. 冷却好了就施放 [[talent:102465]]。
7. 施放 [[spell:315867]]（若 神圣 能量 为 3 点或以下）。
8. 施放 [[talent:102498]]（若 神圣 能量 为 3 点或以下）。

:::

:::tab [[spell:339044]]
想了解更多关于 [[spell:339044]] 的内容，请前往深度解析部分！

你开局的首要目标是使用[[spell:184575]]，紧接着使用[[spell:315867]]，将神圣能量堆到3层。

[[talent:136809@FAQAQjiB]] 特质带有一个随机因素，会影响你何时获得 神圣 能量。具体来说， 神圣 能量 在第2次自动攻击时获得，但由于随机因素可能会有所变化。在开怪阶段，要注意这种可变性。假设你没有如期获得 神圣 能量。在这种情况下，你可能需要使用一个生成技能来填补空缺，或者跳过1个生成技能，因为 [[talent:136809@FAQAQjiB]] 已经为你获得了施放 神圣 能量 所需的 ，以便在你的 [[talent:115435]] 窗口期内施放 [[spell:85256]]。

### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士** 标准起手
```json
{
  "source_code": "I0ELKI0_QLAAAAAACxIfBcAEAI059UQAJwgQBf-AFgAC9WoBFgACI0UAFgACLdKBFgABv8UAHADAChQTBAAAAAgQ_DtA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:85256]]
7. [[spell:304971]]
8. [[spell:20271]]
9. [[spell:85256]]
10. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::group
:::rotation **惩戒 圣骑士** 快速起手
```json
{
  "source_code": "IUELJI0_QLAAAAAACxIfBcAEAI0SnSQAJwgQn3TBFgACBf-AFgAC9WoBFgACI0UAFgAK_DtAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:343527]]
5. [[spell:255937]]
6. [[spell:427453]]
7. [[spell:85256]]
8. [[spell:184575]]
9. [[spell:85256]]
:::

:::

#### 延迟 圣洁鸣钟 起手

#### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[spell:85256]]（当接近 5 点 神圣 能量 时施放，避免能量超出上限（神圣 能量 溢出）而搞乱你的爆发窗口。
2. 冷却好了就施放 [[talent:115435]]。
3. 冷却好了就施放 [[talent:102497]]，以触发 [[talent:102525]]（需要 2 点 神圣 能量）。前提是选择了该天赋！！
4. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
5. 施放 [[talent:102498]]（以维持 [[talent:114830]] 和 [[talent:115438]]）。
6. 冷却好了就施放 [[talent:102465]]。
7. 施放 [[spell:315867]]（若 神圣 能量 为 3 点或以下）。
8. 施放 [[talent:102498]]（若 神圣 能量 为 3 点或以下）。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:102525]]
想了解更多关于 [[talent:102525]] 的内容，请前往深入解析部分！

### 起手爆发

如果你在连招早期使用[[spell:304971]]会导致神圣能量溢出，在某些情况下可以将它推迟到[[spell:427453]]之后使用。

#### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士 标准开局**
```json
{
  "source_code": "IUEMJI0_QLAAAAAACdePFUACIE85DUACI0bhGUACEkI0BcAEAI0SnSQAJggQv8UAHADAClI0AAAAAAgQ_DtA"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
5. [[spell:53385]]
6. [[spell:304971]]
7. [[spell:20271]]
8. [[spell:53385]]
9. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::rotation
```json
{
  "source_code": "IwDMII0_QLAAAAAACt0pEUACIcePFUACIE85DUACI0bhGUACEkI0BcALAI0_QLAAAAAAClI0"
}
```
1. [[spell:184575]]
2. [[spell:304971]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:53385]]
7. [[spell:184575]]
8. [[spell:53385]]
:::

#### 多目标 / 范围伤害 优先级列表

1. 当你接近 5 点[[talent:102499]]时施放 神圣 能量.
2. 当你的 [[talent:102497]] ≤2 时，冷却转好就施放 [[talent:102525]] 以触发 神圣 能量.
3. 施放 [[spell:427453]] 以触发 [[talent:117823]]。
4. 施放 [[talent:102498]] 以维持 [[talent:114830]] 和 [[talent:115438]]。
5. 冷却转好就施放 [[talent:102465]]。
6. 如果你的 [[spell:315867]] 较少，则施放 神圣 能量 或用来维持 [[talent:117819]]。
7. 如果你有 3 层[[talent:102499]]，则施放 神圣 能量.

:::

:::tab [[spell:339044]]
想了解更多关于[[spell:339044]]的内容，请前往深入解析部分！

### 起手爆发

如果你在连招早期使用[[spell:304971]]会导致神圣能量溢出，在某些情况下可以将它推迟到[[spell:427453]]之后使用。

#### 惩戒 圣骑士 标准起手

:::rotation **惩戒 圣骑士 标准开局**
```json
{
  "source_code": "I0ELKI0_QLAAAAAACxIfBcAEAI059UQAJwgQBf-AFgAC9WoBFgABJCdAHABACt0pEEQCII0LPFwBwAgQJCNAAAAAAI0_QLA"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:343527]]
4. [[spell:255937]]
5. [[spell:427453]]
6. [[spell:53385]]
7. [[spell:304971]]
8. [[spell:20271]]
9. [[spell:53385]]
10. [[spell:184575]]
:::

#### 快速 圣洁鸣钟 起手。

:::rotation
```json
{
  "source_code": "IQELJI0_QLAAAAAACxIfBcAEAI0SnSQAJwgQn3TBFgACBf-AFgAC9WoBFgABJCdAHwCAC9P0CAAAAAgQJCN"
}
```
1. [[spell:184575]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:343527]]
5. [[spell:255937]]
6. [[spell:427453]]
7. [[spell:53385]]
8. [[spell:184575]]
9. [[spell:53385]]
:::

#### 多目标 / 范围伤害 优先级列表

1. 施放[如果你接近5点[[talent:102499]]神圣能量，则施放。
2. 当你的[[talent:102497]]神圣能量[[talent:102525]]≤2时，冷却好了就施放以触发。
3. 施放[[spell:427453]]以触发[[talent:117823]]。
4. 施放[[talent:102498]]以维持[[talent:114830]]和[[talent:115438]]。
5. 冷却好了就施放[[talent:102465]]。
6. 当你的[[spell:315867]]神圣能量不足或需要维持时，施放[[talent:117819]]。
7. 当你有3点[[talent:102499]]神圣能量时，施放。

:::

:::

## 深入解析

:::tabs
:::tab [[talent:102525]]
- 当你选择了[[talent:102525]]天赋时，你无法直接使用[[talent:102593]]或[[talent:125129]]。相反，使用[[talent:102497]]会在几秒内触发你在天赋中选择的冷却时间。此外，任何神圣能量消耗技能都有小概率触发你所选择的天赋，额外延长5秒。如果在该法术生效期间触发，还会延长你的[[talent:125129]]或[[talent:102593]]。
- 永远不要闲置[[talent:102497]]，因为[[talent:102513]]有1分钟冷却时间，而[[talent:115435]]有30秒冷却时间。延后灰烬觉醒也会延后你所有其他冷却技能。

#### 处决宣判

- 当你选择[[talent:115435]]作为你的小爆发冷却时，最优做法是在[[talent:115435]]之后使用[[talent:102497]]。这是因为获得[[talent:102593]]的收益不会影响[[talent:115435]]，而且你希望在[[talent:115435]]的持续期间让翅膀保持完整的覆盖时间。尽量在[[talent:115435]]转好冷却之前就准备好3层神圣能量，以便冷却一好就能立刻使用。

#### 使用英雄天赋 圣殿骑士 时

:::rotation **惩戒 圣骑士** [[talent:115435]] 在 团队副本 中的技能顺序
```json
{
  "source_code": "H0BMEI0_QLAAAAAACdePFUACoE85DAAAAAgQ9WoB"
}
```
1. [[spell:184575]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
:::

#### 使用英雄天赋 烈日先驱 时

:::rotation **惩戒 圣骑士** [[talent:115435]] 在 团队副本 中的技能顺序
```json
{
  "source_code": "HUDLHI0_QLAAAAAAC9yTBcAEAI059UQAJwgQI0UAFgACBf-AFgAKI0UAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:20271]]
3. [[spell:343527]]
4. [[spell:85256]]
5. [[spell:255937]]
6. [[spell:85256]]
7. [[spell:85256]]
:::

:::

:::tab [[talent:102519@FJQA41dBCIA]]
- 当首领战或地下城允许你不错过任何冷却窗口期时，选择此天赋。
- 不要让 [[talent:102519@FJQA41dBCIA]] 闲置超过几秒，因为你的大部分伤害来自于它与其他 1 分钟冷却技能的联合使用。如前所述，始终优先使用 [[talent:102519@FJQA41dBCIA]]，除非你正在使用 [[spell:343527]]，在这种情况下请遵循下文说明的具体策略。
- 延迟 [[talent:102519@FJQA41dBCIA]] 也会推迟你的其他小型冷却技能。
- 使用饰品时，不要保留你的 [[talent:102519@FJQA41dBCIA]]，因为它不会显著增强饰品的总体伤害，但会提高它们的暴击几率。
- 对于冷却时间为 90 秒的饰品，直接按冷却使用即可，除非你拥有一个提供巨额精通或力量加成的饰品。在这种情况下，尽量将其与 [[talent:102519@FJQA41dBCIA]] 对齐使用。

:::rotation **惩戒 圣骑士** [[talent:115435]] 优先级列表
```json
{
  "source_code": "HkBYEIkpHRAAAAAACwIfAAAACs0pEAAACE85DA"
}
```
1. [[spell:280486]]
2. [[spell:31884]]
3. [[spell:304971]]
4. [[spell:255937]]
:::

:::

:::

### 小型冷却技能

要发挥你的全部潜力，你还必须知道如何将小技能冷却时间的收益最大化。

:::tabs
:::tab [[talent:115435]]
- 你在[[spell:343527]]期间的计划是尽可能在其持续时间内打入更多的终结技能。由于其爆发窗口短暂且缺乏初始伤害，它在[[talent:102593]]或[[spell:384392]]之外表现不强。
- 始终在[[talent:102593]]之前施放[[spell:343527]]。
- 在冷却完毕时使用[[spell:343527]]，以确保它与其他冷却技能对齐。
- 如果你选择了[[talent:102525]]，务必在[[spell:255937]]之前使用[[spell:343527]]。

#### 使用英雄天赋 圣殿骑士 时

:::rotation **惩戒 圣骑士** [[spell:343527]] 的快速优先级列表
```json
{
  "source_code": "H0BMEIEeGTAAAAAACdePFUACoE85DAAAAAgQ9WoB"
}
```
1. [[spell:312952]]
2. [[spell:343527]]
3. [[spell:255937]]
4. [[spell:427453]]
:::

#### 使用英雄天赋 烈日先驱 时

:::rotation **惩戒 圣骑士** [[spell:343527]] 而不使用 [[talent:102593]] 和 [[talent:102465]]
```json
{
  "source_code": "HUDLHI0_QLAAAAAAC9yTBcAEAI059UQAJwgQI0UAFgACBf-AFgAKI0UAAAAAAIECNFA"
}
```
1. [[spell:184575]]
2. [[spell:20271]]
3. [[spell:343527]]
4. [[spell:85256]]
5. [[spell:255937]]
6. [[spell:85256]]
7. [[spell:85256]]
:::

:::

:::

### 惩戒 通用机制

如果你不重视基础，就无法精通 **惩戒 圣骑士**。

#### 远征打击

- 这会取代你的自动攻击和你正常的 [[spell:35395]] 法术，成为一种独立的自动攻击，每次攻击产生 1 个 神圣 能量 每第2次攻击。
- 在你的开场或战斗中的任何冷却期间，你的 神圣 能量 可能有所不同。你可以从4-5个 神圣 能量 就在[[talent:115435]]之前，这意味着你需要在任何其他法术之前立即按下[[spell:85256]]。这可能会改变你的开怪方式，因此理解优先级列表以知道何时按下哪些按键非常重要。

#### 精通

- **惩戒 圣骑士** [[spell:267316]] 已经被重做了。现在 [[spell:315867]] 不仅会强化你的消耗型技能，还有几率对你的主要目标触发额外的神圣伤害。由于精通长期以来都是一个短板，这一改动带来了显著的收益。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

**← 向下滚动查看更多副本 →**

:::tabs
:::tab 毒牙祭坛
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 拉维

- 注意[[spell:1297876]]。

#### 扭缠盘蛇

- 小蛇和大蛇共享一个生命值池，所以你对小蛇造成的任何伤害都会使大蛇以更低的血量回来。当大蛇离开、小蛇出现时，是使用爆发冷却技能的好时机。第一批小蛇在战斗开始53秒后出现，下一批在90秒后出现。
- 你可以反射[[spell:1299189]]，如果不躲开它，它可能占你在这场战斗中所受伤害的大部分。
- [[spell:1310358]]在只剩1条蛇时必须连续被打断3次，最好与你的队伍协调好，确保3次打断全部有人负责，不要不小心浪费打断技能去抢同一次施法。
- [[spell:1310358]]在有多条蛇时也会施放，不过多条蛇并不是每条都施放3次。

#### 祖尔加

- 在[[spell:1300886]]期间使用防御技能以减少所受伤害。
- 在分担[[spell:1301508]]时使用防御技能。

### 小怪攻略

- 对 [[spell:1294568]] 使用 [[talent:102476]]，来自 **双牙蹂躏者**.

:::

:::tab 纳洛拉克的洞穴
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 囤宝狂人

- 当**囤宝狂人**施放[[spell:1234681]]或[[spell:1235125]]时使用防御技能。

#### 寒冬哨兵

- 打断 [[spell:1235829]] 的施法，该技能由 **碎裂的震颤核心.**
- soak [[spell:1263590]] 当你击败 **碎裂的震颤核心**.
- 被击败的 **碎裂的震颤核心** 会留下一个 [[spell:1234314]]，你可以站在其中以免被 [[spell:1235656]] 推退。

#### 纳洛拉克

- 尽量把 [[spell:1242887]] 放在你队友放置的位置旁边，最好都集中在房间的一侧或一个角落。这样当它们活过来追逐 **祖尔加拉** 时，当 **纳洛拉克** 施放 [[spell:1243002]] 时，更容易承受它们的伤害。
- 在 [[spell:1243569]] 期间躲到护盾后面。如果你获得了减益效果 [[spell:1261781]]，就说明你是安全的。

:::

:::tab 密谋小径
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 凯斯媞亚·魔力之心

- 在**凯斯媞亚**施放[[spell:1214959]]时，确保你的DPS冷却已经准备好。这也是使用防御冷却的好时机。

#### 赞恩·刃悲

- 如果你被点 名，使用你的 [[spell:1214352]] 来清除绿色发光的 [[spell:1201553]]。
- 当 **扎恩** 施放 [[spell:474483]] 时，是使用防御冷却技能的好时机。

#### 歼灭者萨祖克斯

- 专注于击杀 **军团大斧** 来自 [[spell:1214663]]，因为只要它存活，[[spell:1214650]]就会对你造成持续增加的大量伤害。它们彼此的刷新间隔略少于1分钟。
- 小心不要踩到 [[spell:474234]]。

#### 利希尔·烬怒

- 通常情况下，这场战斗中你受到的几乎所有伤害都来自被动的 [[spell:1216945]]。因此，只要你受到任何额外伤害，比如小鬼的施法被打进来，或者带着 [[spell:474457]] 与其他人重叠站位，那就是交出防御冷却技能的时机。
- 尽量在使用传送门前解决掉小鬼。

:::

:::tab 夺目谷
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 光明众花

- 拦截[[spell:1235574]]，阻止其击中**光明之花 种子。**
- 当**梅提克** 施放[[spell:1276586]]时注意你的生命值。这是使用防御技能的好时机。

#### 伊库兹，光明猎人

- 当**伊库兹**施放[[spell:1236715]]时使用防御技能。
- 你可以用[[talent:128251]]来解除定身效果。

#### 护光者鲁伊亚

- [[spell:1240098]]下落速度很快，要迅速躲避。
- 你可以和[[spell:1239824]]像素级重叠站位，就不会被[[spell:1239830]]击中。

#### 兹欧凯特

- 不要让球体进入首领体内，否则会引发[[spell:1247039]]爆炸，极有可能导致团灭。
- 吸收球体会获得[[spell:1247052]]，提高造成的伤害，但同时会给你施加一个造成大量伤害的持续伤害效果。

### 小怪攻略

- 务必打断 [[spell:1238294]] 的施法，施法者是 **光羽瓣翼鸟.** 如果不这样做，很可能会导致团灭，因为队伍会陷入混乱。

:::

:::tab 虚空惊惧竞技场
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 塔兹拉尔

- [[spell:1222103]]会造成大量初始伤害，并给你施加一个持续伤害效果。
- 当[[spell:1300259]]被施放时，如果生命值不满，请准备好使用防御技能或治疗药水，它会造成大量范围伤害。它还会产生许多小球，你必须躲避，否则会受到更多伤害。

#### 阿特洛苏斯

- **剧毒蠕行者** 的 [[spell:1222692]] 会造成高额伤害。立刻切换目标攻击它，甚至可以为它保留输出爆发技能。
- 如果 **剧毒蠕行者** 在 **阿特洛苏斯** 施放 [[spell:1300351]] 时还活着，请使用防御技能。

#### 煞戎努斯

- 这场战斗中你受到的主要伤害来自[[spell:1264188]]。
- 战斗中最危险的时刻，是你被与[[spell:1264188]]的持续背景伤害重叠的技能点名时，这时你应该使用防御冷却技能。
  
  - [[spell:1300372]]会造成大量伤害并对你施加一个持续伤害效果（DoT）。
  
  
  
  - 如果你不及时清除你的法力球，你将受到来自[[spell:1287450]]越来越高的伤害。

:::

:::tab 诸王之眠
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 黄金风蛇

- 当**黄金风蛇**施放[[spell:1311988]]时使用防御冷却技能。
- 不要让**活体黄金**到达首领处，否则他会获得[[spell:265991]]。

#### 殓尸者姆沁巴

- 打断**未完工的木乃伊**施放的[[spell:267763]]。
- 当队友被[[spell:267702]]击中时要迅速把他们救出来。如果陵墓在震动，你就能知道他们在哪里；如果你是被点名的那个人，就使用[[spell:267764]]来提醒队友你的位置。

#### 部族议会

- 一定要帮忙分担[[spell:1310761]]。这是使用防御冷却技能的好时机。
- 打断[[spell:267273]]。
- 击杀**洪流图腾、雷电图腾**以及**爆裂图腾。**

#### 始皇达萨

- 打断[[spell:269369]]，由**莱班**施放。
- **莱班**在战斗开始几秒后出现，而**提扎拉**在**达萨尔**剩余80%生命值时出现。提扎拉和**达萨尔**共享一个生命值池。
- 你在这场遭遇战中所受的大部分伤害来自[[spell:1303267]]，因此那是使用防御冷却技能的好时机。

### 小怪攻略

- 打断 [[spell:270920]] 的技能，由 **瓦西女王施放。**
- 打断 [[spell:270901]] 的技能，由 **塞内沙·姆巴拉施放**.

:::

:::tab 红玉新生法池
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 梅莉杜莎·寒妆

- 打断 [[spell:372808]]。
- 当 **梅丽莎** 施放 [[spell:396044]] 时，与队友集合会比较好，这样 [[spell:384022]] 会生成在彼此重叠的位置，更容易躲避。
- 最好将 [[spell:372851]] 放在远离首领和队友的地方。
- 在 [[spell:373680]] 护盾存续期间，你受到的伤害会不断增加。

#### 柯姬雅·焰蹄

- [[spell:372863]]会召唤一个**炎缚火焰风暴**。
- 打断[[spell:373017]]，由**炎缚火焰风暴**施放。
- 尽量把[[spell:372107]]引向不会在你的队伍附近爆炸的方向，最好也不会让火焰之后妨碍到你。

#### 基拉卡与厄克哈特·风脉

- 在最后阶段受到 [[spell:381862]] 影响时使用防御技能，因为它会额外选中一名玩家，给治疗带来更大压力，同时注意水潭的放置位置。

### 小怪攻略

- 当 **阿什希尔·焰鞭** 施放 [[spell:1305865]] 时使用打断。
- 当 **原始主宰** 施放 [[spell:1305201]] 时使用防御技能。

:::

:::tab 塞塔里斯神庙
:::talents **惩戒 圣骑士** [[talent:123357]] 大秘境天赋
```json
{
  "source_code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA",
  "code": "CaEAo7SHLZA3aYychDLmrvpSfBAAAAwoZbbmZWGzYGAAAAAAzUGzwMjtxsNMz2MGjxwM2YDAzysNzMbNzMtNzsNDAYDwAYMmhZwMmZ2wyMzMDjhBDA"
}
```
:::

### 首领攻略技巧

#### 阿德里斯和阿斯匹克斯

- 确保你的目标是那个没有[[spell:1289229]]护盾的首领。有护盾的那个免疫伤害，而且护盾在谁身上会随战斗交替变化。
- [[spell:1289062]]会迅速把你击退很远，在它即将生效时狂按冲锋。不要被击退进[[spell:1288864]]里，因为它们会使你沉默。

#### 米利克萨

- 如果你被 [[spell:1290031]] 选为目标，靠近另一名被选中的玩家，最好你们都在首领处汇合。
- 使用 [[spell:853]] 移除队友身上由 [[spell:1290031]] 施加的负面效果。
- 当 **梅蕾克塔** [[spell:264206]] 横扫战场时要小心，被击中会造成大量伤害并使你昏迷。

#### 加瓦兹特

- 在承担 [[spell:266923]] 时使用防御技能。不要让光束击中并为首领充能，如果他的能量达到100，他就可以施放 [[spell:266512]]，很可能导致团灭。

#### 塞塔里斯的化身

- 吸收来自 [[spell:1300869]] 的腐蚀，使 **塞塔里斯的化身** 能够 [[spell:1302895]]。这个机制更适合由伤害输出者来吸收，而不是坦克或治疗者，因为吸收后会受到治疗效果惩罚，并且所受物理伤害增加。
- 打断 [[spell:1302158]]，该技能由 **扭曲的妖术师.**
- 带着 [[spell:1302153]] 分散。
- **无信折磨者** 锁定你的治疗者，必要时眩晕并减速他们。

:::

:::

### 词缀

词缀系统在进入**地心之战**时进行了重做，移除了大部分词缀，同时引入了新的有利有弊的词缀，并改变了这些词缀出现的钥石等级。这些词缀在地心之战期间以及进入至暗之夜时又经过了进一步调整。

- +2 词缀
  
  - [[spell:1284818]]
- +5 词缀 *-- 按周轮换*。
  
  - 萨拉塔斯的契约：升腾者
  - 萨拉塔斯的契约：虚空缚束
  - 萨拉塔斯的契约：吞噬
  - 萨拉塔斯的契约：脉冲星
- +6 词缀
  
  - [[spell:1284818]] 已移除。
- +7 词缀 *-- 每周交替出现*。
  
  - [[spell:1284818]] 已移除。
- +10 词缀 *-- 两种词缀同时存在。*
  
  - 暴怒
  - 强韧
- +12 词缀
  
  - 萨拉塔斯的诡诈 *-- 替代 +5 词缀*

## 属性优先级

了解你作为 **惩戒 圣骑士** 在 大秘境 地下城中获得最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **惩戒 圣骑士** 大秘境 属性优先级
```json
{
  "source_code": "HoAJFQQMgQCKBEQABA"
}
```
**力量 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避 -** 极好的属性，可减少“范围效果（AoE）”技能受到的伤害。
- **吸血 -** 通过造成伤害提供额外治疗。
- **加速 -**  较为冷门的第三属性，但可能非常有用，过去已被证明其实用性。能大幅降低应对特定机制的难度。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271465@BgQAAYEA5IgTBA]] | 套装 |
| 项链 | [[item:268265@BkCAAYEAE06QRrTOCQWNYYjX1YhN]] | 乌拉特克 |
| 肩部 | [[item:271463@BgQAAYEACHgTBA]] | 套装 |
| 披风 | [[item:268253@BAQAAYEAYFA]] | 盘卷祭坛 |
| 胸部 | [[item:271468@BgQAAYEA5IgTBA]] | 套装 |
| 护腕 | [[item:268239@BgQAAYEA5IgTBA]] | 迷失的探险者 |
| 手套 | [[item:271466@BgQAAYEA5IgTBA]] | 套装 |
| 腰带 | [[item:271462@BgQAAYEA5IgTBA]] | 催化 |
| 腿部 | [[item:271878@RARAAYEAItvE5IgF24UA]] | 乌拉特克 |
| 靴子 | [[item:268260@BgQAAYEA5IgTBA]] | 瓦什尼克 |
| 戒指 1 | [[item:268252@BgQAAYEA5IgTBA]] | 斯索拉克 |
| 戒指 2 | [[item:268249@BgQAAYEA5IgTBA]] | 节点-泽纳斯 |
| 饰品 1 | [[item:270175@BgBAAYEAYYjX1kjA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgBAAYEAYYjX1kjA]] | 盘卷祭坛 |
| 武器 | [[item:268213@DgQAAYEA9k7kjAYF]] | 盘卷祭坛 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251126@DARAAcEANk74iMeVTQB]] | 密谋小径 |
| 颈部 | [[item:273781@BgQAAYEACKQQBA]] | 毒牙祭坛 |
| 肩部 | [[item:251138@DARAAcEA7j74iMeVTQB]] | 密谋小径 |
| 披风 | [[item:193763@BgQAAYEACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:193753@AgQAAIoABFA]] | 红玉新生法池 |
| 腕部 | [[item:251133@BgQAAYEACKQQBA]] | 密谋小径 |
| 手部 | [[item:159413@BARAAcEAuIjX1EUA]] | 诸王之眠 |
| 腰带 | [[item:159418@BgQAAYEACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:273776@DARAAcEAju74iMeVTQB]] | 毒牙祭坛 |
| 脚部 | [[item:159412@BgQAAYEACKQQBA]] | 诸王之眠 |
| 戒指 1 | [[item:273792@BgQAAYEACKQQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:251136@BgQAAYEACKQQBA]] | 密谋小径 |
| 饰品 1 | [[item:273796@BgQAAYEACKQQBA]] | 毒牙祭坛 |
| 饰品 2 | [[item:250228@BgQAAYEACKQQBA]] | 密谋小径 |
| 武器 | [[item:273782@BgQAAYEACKQQBA]] | 毒牙祭坛 |

:::

:::

### 饰品

你可以在下方找到现有饰品的主动和被动排名。请注意，根据大秘境地下城的不同，某些饰品的表现会优于其他饰品。

| 等级 | 饰品 |
| --- | --- |
| S 级 | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A 级** | [[item:270165@AgQAAIoAOFA]] |
| **B 级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C 级** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *——非常适合范围伤害，单体目标则是废料场。* |
| **废料场** |  |

### 美化饰品

- 本节内容很有可能发生变动，因此在进行任何重要的制造业制作之前请回头确认，看看这段文字是否已被删除。如果已删除，则说明我对这些推荐更有信心。
- [[item:245876]] 是最佳的修饰。由于制造业制造的物品装等为331而非334，这意味着你需要使用更低装等的武器来获得 [[item:245876]]。
  
  - 对于初期配装，制作一把带有 [[item:245876]] 的武器无疑是最佳选择，除非你不知怎么已经拥有两把高装等的史诗武器。
- 对于第二个修饰，有许多可行的选择，目前推荐的是 [[item:240167]]。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **瓶装合剂**
  
  - **[[item:241324]] 或**
  
  
  
  - **[[item:241326]] 或**
  - **[[item:241322]] *-- 惩戒骑需要平衡精通和爆击属性，同时急速也要保持在一个手感流畅的合适百分比。你可以通过配装来实现这种平衡，也可以借助消耗品。* *如果你想了解自己具体的属性平衡情况以及还需要补什么属性，我建议查阅我们的 [Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)。***
- **食物**
  
  - **[[item:255846]]**
- **战斗药水**
  
  - **[[item:241288]]**
- **治疗药水**
  
  - **[[item:241304]]**
- **武器临时附魔**
  
  - **[[item:243734]]**
- **强化符文**
  
  - **[[item:259085@AQAAAoF]]**
- **宝石插槽**
  
  - **[[item:240967]] *-- 唯一，每种颜色的宝石各用一颗来增强你的 [[item:240967]]。***
    
    - **[[item:240890]]**
    - **[[item:240906]]**
    - **[[item:240916]]**
    - **[[item:240900]]**

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707@DAAAAYEAvj7A]] |
| --- | --- |
| 肩部 | [[item:244021]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707@BAAAAYE]] |
| 腰部 | [[item:275707@BAAAAYE]] |
| 腿部 | [[item:244641@BAAAAYE]] |
| 靴子 | [[item:243983]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 武器 | [[item:244029@BAAAAYE]] |

:::

:::column
:::gear **惩戒 圣骑士** 大秘境中的附魔
```json
{
  "source_code": "JQFZGBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

- 你可以从宏伟宝库商人处购买 [[item:275707]]，为你的 **头盔**、**护腕** & **腰带** 添加插槽。

## 种族

对于在团队副本中极限优化 **惩戒 圣骑士** 在大秘境中，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你的风格或幻化审美的种族同样可行，因为DPS的提升并没有人们说的那么显著。

- [[spell:65116]] -- 矮人
  
  - 可以移除 驱散魔法 和流血减益效果。过去在部分有流血机制的首领战中很有用。
- [[spell:20549]] -- 牛头人
  
  - 一个 范围伤害 昏迷技能非常有价值，因为圣骑士目前缺少这类技能。此外，[[spell:20550]] 在进行高难度内容时也非常实用。
- [[spell:265221]] *-- 黑铁矮人* 
  
  - 它可以移除几乎任何减益效果，并提供一个小幅伤害增益。
- [[spell:25046]] *-- 鲜血精灵* 
  
  - 移除你周围目标身上的 1 个增益效果。
- [[spell:292361]] -- 赞达拉巨魔
  
  - 提供一个基于随机触发率的小幅爆击增益。作为赞达拉巨魔的一大优势是，你可以将 [[spell:291944]] 和 [[spell:642]] 组合使用来把自己完全治满。
- [[spell:59752]] *-- 人类* 
  
  - 移除你身上的任何昏迷效果，类似于一件 PvP 饰品。[[spell:20598]] 是选择人类种族的主要原因。
- [[spell:28880]] *-- 德莱尼* 
  
  - 除了 [[spell:6562]] 之外没有特别有用的种族技能。
- [[spell:255647]] *-- 光铸德莱尼* 
  
  - 更像是一个娱乐性的种族技能，但别忘了 [[spell:255652]]——当你死亡时它会爆炸，造成少量伤害！

### 推荐

**总的来说，可以肯定地说，如果你在意将DPS最大化到极致，你应该选择DPS最高的种族天赋。话虽如此，如果涉及冲击终极副本 团队副本 或 大秘境 进度，情况就有些不同了。一些种族天赋能极大帮助加速地下城或团队副本中某些首领的推进进度。值得注意的是 矮人 凭借其 [[spell:65116]] 在最新的  丁达尔·迅贤 & 火光之龙菲莱克 的 世界首杀竞速 中提供了帮助，因为在上述战斗的关键时刻能够轻松自我驱散。**

## 宏

探索 **惩戒 圣骑士** 在 大秘境 地城中的推荐宏，并观看一段关于为你的角色创建简单宏的快速视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 光标宏 / 焦点宏
**在不选定目标的情况下，将 [[spell:96231]] 施放给你的焦点目标。**

```wow-macro
#showtooltip 责难
/cast [@focus] 责难
```

**在完全不选定目标的情况下，将 [[spell:853]] 施放给你的焦点目标。**

```wow-macro
#showtooltip 制裁之锤
/cast [@focus] 制裁之锤
```

:::

:::details 鼠标指向宏
**对于这些宏，如果你按住鼠标右键，则会将技能施放在你自己身上，而不是鼠标指向的目标。**

**鼠标指向宏，用于** [[spell:19750]]

```wow-macro
#showtooltip 圣光闪现
/cast [@mouseover,exists,help] 圣光闪现 [@player] 圣光闪现
```

**鼠标指向宏，用于 [[spell:85673]]**

```wow-macro
#showtooltip 荣耀圣令
/cast [@mouseover,exists,help] 荣耀圣令 [@player] 荣耀圣令
```

**鼠标指向宏，用于 [[spell:633]]**

```wow-macro
#showtooltip 圣疗术
/cast [@mouseover,exists,help] 圣疗术 [@player] 圣疗术
```

**鼠标悬停以[[spell:305394]]**

```wow-macro
#showtooltip 自由祝福
/cast [@mouseover,exists,help] 自由祝福 [@player] 自由祝福
```

**鼠标悬停以 [[spell:6940]]**

```wow-macro
#showtooltip 牺牲祝福
/cast [@mouseover,exists,help] 牺牲祝福; 牺牲祝福
```

**鼠标悬停以 [[spell:1022]]**

```wow-macro
#showtooltip 保护祝福
/cast [@mouseover,exists,help] 保护祝福 [@player] 保护祝福
```

**鼠标悬停以 [[spell:213644]]**

```wow-macro
#showtooltip 清毒术
/cast [@mouseover,exists,help] 清毒术 [@player] 清毒术
```

:::

:::details 冷却宏
**将饰品与 [[talent:102593]]**

 一起使用的宏

```wow-macro
#showtooltip 复仇之怒
#show 复仇之怒
/cast 复仇之怒
/use 烬魄之灰
/use 14
```

:::

:::

## 插件

下方是作者为其 **惩戒 圣骑士** 所使用的用户界面截图，其中说明了使用了哪些插件，以及如何在 大秘境 地下城中利用它们让你的游戏生活更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/dddd-1-1024x651.jpg>)

**惩戒 圣骑士** UI

:::accordion
:::details 插件
- **ElvUI** *-- 完整的用户界面替换* 
  
  - 一款以用户友好为核心设计的界面，附带标准界面所不具备的额外功能。
  - 此外，你也可以使用 Shadowed Unit Frames (SUF) 加上任意一款动作条插件，当然也可以使用原生界面。
- **LittleWigs** *-- 通用首领模块* 
  
  - BigWigs 是一款首领战插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件旨在为某个特定的 大秘境 战斗触发警报信息、计时条、声音提示等。
- **Plater** -- 进阶姓名板
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的减益效果监控、仇恨染色，并且支持类似 WeakAuras 的脚本功能，配合 wago.io 和 WeakAuras-Companion 可更新 Mod/脚本/配置文件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- **惩戒**:

- Apex 天赋：Light Within（内里之光，第 1 级）现在有额外效果——战争艺术和 Righteous Cause（正义之因）现在各可额外累积一次。
- 战争艺术已更新——现在使公正之剑伤害提高 80%（原为 150%）。
- 公正之剑伤害提高 40%。
- 最终审判伤害提高 15%。
- 神圣风暴伤害提高 15%。
- 复仇之怒现在使造成的伤害和爆击几率提高 15%（原为 20%）。
- 圣殿骑士打击伤害提高 50%。
- 圣殿骑士斩击伤害提高 50%。
- 审判伤害提高 50%。
- 愤怒之锤伤害提高 50%。
- 圣洁鸣钟的审判现在造成 50% 的额外伤害（原为 100%）。
- Apex 天赋：Light Within（内里之光，第 3 级）伤害降低 25%。
- 圣光闪现治疗效果提高 25%。
- 荣耀圣令治疗效果提高 25%。
- 永恒之火治疗效果提高 25%。
- 战争艺术不再由额外的 Skyfury（天怒）攻击触发。
- 额外的 Skyfury（天怒）攻击在点出远征打击天赋时不再产生神圣能量。
- 远征打击现在使自动攻击速度提高 15%（原为降低 20%）。
- 处决宣判的作用范围半径提高至 10 码，且现在包含目标的碰撞半径（原为 8 码）。
- 英雄天赋
  
  - 圣殿骑士
    
    - 圣光之锤伤害降低 30%。不影响 PvP 战斗。
    - 圣光之锤现在消耗 3 点神圣能量（原为 5 点）。

:::

:::details 11.0.2补丁
- 开发者说明： 新天赋：神圣烈焰 – 神圣风暴造成的伤害提高10%，并且当其命中受到你异端逐除影响的敌人时，会将该效果扩散至最多4个被命中的目标。你对因异端逐除而燃烧的目标造成的神圣伤害提高3%。
- 惩戒的职业天赋树中不再默认提供十字军圣印天赋。
- 审判的职业天赋树中现在默认提供强效审判天赋。
- 神圣之刃不再是天赋，改为11级时学习。
- 荣耀圣令的治疗量提高44%。
- 最终审判的伤害降低10%。
- 圣殿骑士的裁决的伤害降低10%。
- 公正者复仇的伤害降低10%，治疗量现在为最大生命值的3%（原为5%）。
- 愤怒之锤的伤害降低15%。
- 公正之剑的伤害降低20%。不影响复仇之剑。
- 复仇之剑的伤害提高25%。
- 异端逐除的伤害降低10%。
- 神圣风暴的伤害提高25%。
- 圣殿骑士打击的伤害降低10%。
- 圣殿骑士斩击的伤害降低10%。
- 远征打击的伤害降低10%。
- 十字军打击的伤害降低10%。
- 受祝福的勇士对次要目标造成的伤害降低25%（原为降低50%），且现在为1点天赋（原为2点）。
- 已修复光辉荣耀在快速连续触发时无法生效的问题。
- 以下天赋现在为2点（原为1点）：十字军之心
- 狂热者
- 正义先锋已被移除。
- 苍穹遗产移动到了天赋树上正义先锋原来的位置。
- 神圣烈焰现在与复仇之剑处于一个选择节点。

:::

:::details 版本 11.1
- 开发者说明
- 神圣之锤已被重新设计 -- 神圣之锤将环绕你旋转，在8秒内每2秒对附近的敌人造成神圣伤害。生效期间，每消耗1点神圣能量会使神圣之锤的持续时间延长0.5秒。对8个以上目标造成的伤害降低。消耗3点神圣能量，冷却时间1分钟。
- 所有技能伤害提高5%。
  
  - *开发者说明：苍穹之锤的伤害输出在总体伤害构成中高于预期。我们正在将这部分强度重新分配到其他技能上。*
- 最终清算的伤害提高75%。
- 圣光闪现的治疗量提高35%。
- 荣耀圣令的法力消耗已提高至15%（原为10%）。
- 治疗之手现在只会提升圣骑士自身受到的荣耀圣令治疗量（原为提升对盟友的治疗量）。
- 圣洁鸣钟现在即使你未与主目标附近的单位交战，也会对其施放审判。
- 在使用带翼复仇雕文时，征伐现在将持续显示正确的法术视觉效果。
- 烈日先驱
  
  - 第二次日出已更新 – 神圣风暴和愤怒之锤有20%的几率以50%的效果再次施放（原为15%几率、30%效果）。
  - 曜日化身的伤害提高50%。
- 圣殿骑士
  
  - 苍穹之锤的伤害降低30%。
  - 圣光之锤现在可以受益于无可争议的裁决审判。
  - 圣光之锤现在可以受益于它为征伐添加的层数。
    
    - *开发者说明：圣光之锤的重新实现无意间改变了它与征伐和审判的交互方式。我们现已调整这些交互，使其与当前正式服版本保持一致。*
  - 圣光之锤的初次命中现在可以受益于最终清算。

:::

:::

## 常见问题

:::accordion
:::details 问：在拥有4点圣能时[[spell:315867]]并超过5点，值得吗？
**答：如果你是在为[[talent:115435]]做准备，那么值得；如果不是，尽量先打出一次[[talent:102504]]再使用它！**

:::

:::details 问：怪物在[[spell:1022]]之后会盯上我——[[spell:642]]这是为什么？
答：你在这两个技能生效期间仍会产生仇恨，所以要注意它们失效的时候，如果你继续输出，怪物可能会立刻转而攻击你。

:::

:::

---

### 致谢

作者：**Narcolies**

审校： **Tief**

:::changelog 更新记录
**2026-08-04** 已更新至12.1版本

**2026-02-21** 已更新至12.0.1版本

**2026-01-15** 已更新至12.0版本

**2025-10-07** 已更新至11.2.5版本

**2025-08-04** 已更新至11.2版本

**2024-12-17** 已更新至11.1.7版本

**2024-10-23** 已更新至11.0.5版本。

**2024-08-17** 已更新至11.0.2版本。

**2024-07-29** 攻略撰写于11.0.1前夕版本。



:::
