Welcome to the **Restoration Druid** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 5/5 · Excellent

Damage · 3/5 · Average

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Restoration Druid** Mythic+ Best in Slot Gear
```json
{
  "source_code": "JwpAwzUaAc__BEwAmQggQEAAvj7AJ16ACKwF2gVABYQ1DAICBAA_sOggC4UABYKJEIACBAQN5OggC4UABsKJEIACFAwI5OggC4UALfBBBA-FEUBMMgVABcaChA5GqOggCgVABfBBBk1uDQAEBAAGAPwD5OAAAcbNLFQAgt7AECSABQBGno6AE06AAUQAFsBGpSCBAgQBAEgb4QP1DEgYZPggIEAAvk7AUEwoY4UABUTrDQYCQxwL5OgCBwDA3GwUUQ1HEAACBUAOEEgUdwABdfRDYABWBEA9iUQzMUQuDkTAPgVCAPABgEAAzB8AYA8AAAAAAAAA3WzSBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240969]] · [[item:243951]] |
| 项链 | [[item:251142]] | [[item:240892]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:244003]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271527]] | [[item:240155]] |
| 脚部 | [[item:244569]] | [[item:245784]] · [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:252258]] | [[item:240916]] · [[item:244015]] |
| 戒指二 | [[item:240949]] | [[item:240906]] · [[item:245784]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270162]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245875]] · [[item:245784]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Restoration Druid**, you have access to Everbloom, which lets your [[spell:33763]] stack up to 3 times and makes its bloom cleave aoe.

**Rank 4 causes your [[spell:33763]] to bloom 3 times when you cast [[spell:18562]].**

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-restodruid-mxr.webp>)

Everbloom

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103106]]
    
    - Changed from an active ability, into a passive that extends all your hots by up to 14 seconds while channeling [[spell:740]].
  - [[talent:103121]]
    
    - Now causes your [[talent:103109]] to apply [[spell:774]] or [[spell:8936]] to 2 additional targets.
  - [[talent:117104]]
    
    - Instead of an active Ability, causes [[spell:18562]] and [[spell:48438]] to spawn a [[talent:117104]].
  - [[talent:103105]]
    
    - Regrowth crits for 260% instead of 200%.
- **Class Tree**
  
  - [[talent:103309@AJwCDA]]
    
    - Now an active ability, that u prefer to press in [[spell:768]] for damage.
- **Removed**
  
  - [[spell:392301]] 
    
    - [[spell:33763]] is back to only one target at all times.

## Hero Talents

- [[talent:123299]] focuses on AoE healing and Cooldown strength, while [[talent:123298]] focuses on Single Target healing and damage done in [[spell:768]].
- In a Mythic+ environment [[talent:123298]] outperforms [[talent:123299]] in the majority of scenarios. Therefore this Guide focuses solely on the better option.



### [[talent:123299]]

- Everytime you summon a [[spell:102693]] you gain all of the following benefits:
  
  - [[talent:117203]]
    
    - 5% healing done increase per active [[spell:102693]].
  
  
  
  - [[spell:428859]]
    
    - [[spell:774]], [[spell:145205]] and [[spell:33763]] healing is increased by 10% per active Grove Guardian.
  
  
  
  - [[talent:117194]]
    
    - Your [[spell:102693]] do damage passively.
  
  
  
  - [[talent:117195]]
    
    - Your next direct heal creates 3 Dream Petals that each heal up to 3 Allies. These direct heals scale with your Mastery.
    - Further enhanced by [[talent:117185]].




### [[talent:123298]]

- [[spell:48438]], [[spell:8936]] and [[spell:81262]] healing has a chance to spawn a [[spell:439530]] on the target, greatly increasing healing done to that target.
- [[spell:439530]] is enhanced by the following nodes:
  
  - [[talent:117227]]
    
    - 20% increased healing done to targets with [[spell:439530]].
  
  
  
  - [[spell:439882]]
    
    - Increases your damage depending on how many [[spell:439531]] are active.
  
  
  
  - [[talent:117232]]
    
    - Small AoE healing is triggered if you cast [[spell:774]] on a target with [[spell:439530]] or [[spell:439530]] expires.





## Talents



### General

:::talents **Restoration Druid** Mythic+ Talents
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### When to use this Spec

This is the default loadout going into any dungeon as it specializes in survivability. You have to adjust the class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, Dungeon specific talent loadouts are available in the Dungeons section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:114108]]
  
  - Empowers your next [[spell:8936]] or [[spell:774]] after every [[spell:18562]] cast, to be stronger and apply to two extra targets.
- [[talent:128708]]
  
  - Merges your [[talent:103111]] into your [[talent:103100]].
- [[talent:103128]]
  
  - This talent makes your [[spell:8936]] cleave onto all other targets affected by [[spell:8936]].
- [[spell:207383]]
  
  - This talent greatly improves your mana efficiency by reducing the cost of your [[spell:8936]] by 50% and increasing its critical chance by 50% while having atleast 5 [[spell:774]] active.
- [[spell:155675]]
  
  - Grants you the ability to place a second [[spell:774]] on a target.
- [[spell:278515]]
  
  - Applies [[spell:8936]] to all active [[spell:33763]] targets, allowing you to apply multiple [[spell:8936]] HoTs with a single cast. Also the increased hot duration increases the value you get out of your mastery a lot.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍[[spell:774]] has a 15% chance and ‍[[spell:132158]] has a 100% chance to grant ‍[[spell:1302255]], causing all your heal over time effects to heal for 25% more for 8 seconds. Multiple applications may overlap.
- **4-Set:** ‍[[spell:132158]], ‍[[talent:103108]] and ‍[[talent:103120]] or ‍[[talent:103119]] have a 100% chance to grant ‍[[spell:1302255]], and ‍[[spell:1302255]] duration is increased by 4 seconds.

### Priority List

1. Keep [[spell:33763]] active, refreshing them no earlier than 4.5 seconds left.
2. Keep 2 [[spell:774]] active on your [[spell:33763]] target.
3. Cast [[spell:18562]] on Cooldown, while consuming either [[spell:48438]] or [[spell:8936]].
4. Cast [[spell:48438]] on Cooldown.
5. Cast [[spell:774]] until [[talent:128277]] is active.
6. Cast [[spell:8936]] with any [[spell:16870]] procs you get.
7. Cast [[spell:8936]] on anyone taking damage, prefer targets with hots already present but no [[spell:8936]] hot.
8. Send some [[spell:5176]] if there is any free time to regain Mana.

#### For Damage



##### Single Target

1. Keep [[spell:1079]] on your target.
2. Cast [[spell:22568]] at 4 or more combo points.
3. Keep  [[spell:1822]] on your target.
4. Cast [[spell:5221]] to avoid capping energy.
5. Attack your target in [[spell:768]].
6. Keep [[spell:8921]] on your target if you can not be in melee.
7. Cast [[spell:5176]] if you can not be in melee.




##### AoE <5 targets

1. Keep [[spell:1079]] on as many targets as possible.
2. Keep  [[spell:1822]] on as many targets as possible.
3. Keep [[spell:106830]] active on all stacked mobs.
4. Cast [[spell:27554]] to avoid capping energy.
5. Attack your target in [[spell:768]].
6. Keep [[spell:8921]] on all targets if you can not be in melee.
7. Cast [[spell:197628]] if you can not be in meele.




##### AoE 5+ targets

1. Keep [[spell:106830]] active on all stacked mobs.
2. Keep [[spell:1079]] on as many targets as possible.
3. Keep  [[spell:1822]] on as many targets as possible.





### Cooldowns

#### Tranquility

- [[talent:103108]] is your strongest cooldown, it is strong enough that you can use it as recover button if you dont have any HoTs out.

#### Convoke the Spirits

- Healers do very little damage in Midnight. Therefore it is recommended to use this for healing instead of in [[spell:768]] for damage.

## Deep Dive

### Min maxing Lifebloom

- Picking the correct target for your [[spell:33763]] is very crucial as its your strongest single target heal in midnight and also has [[talent:103111]] and all talents affecting [[talent:103111]] tied to it. Make sure to tell your group that stacking greatly increases your healing.

#### Optimizing Heart of the Wild

- Using [[talent:103309@AJwCDA]] in [[spell:768]] does the most damage and should nearly always be done. If you push very high keys you might need to use it in [[spell:5487]] instead to counter certain damage events.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Restoration Druid** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as Shapeshift.




### Den of Nalorakk

:::talents **Restoration Druid** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]].
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a Shapeshift.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Restoration Druid** Mythic+ Build in Murder Row
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Restoration Druid** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYmZmZMbDPAzMLML2mBAAAAAAAAAALDa2MjpZGzYMLmZmxyM8AGAAAAAAADAAEAAwsMzWzyMb2YmZgZmFQzAAMzAwA",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYmZmZMbDPAzMLML2mBAAAAAAAAAALDa2MjpZGzYMLmZmxyM8AGAAAAAAADAAEAAwsMzWzyMb2YmZgZmFQzAAMzAwA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots by shapeshifting.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Restoration Druid** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Restoration Druid** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Restoration Druid** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Restoration Druid** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CmGA29xkejBw_aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG",
  "code": "CmGA29xkejBw/aamuA5thbTECPMmxYGzMjZbYYmZhZx2MAAAAAAAAAAYZQzmZMNzYGjZxMzMWmhHwAAAAAAAYMAAEAAwsMzWz2Mb2YmZgZsAaGAgZGAG"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got adjusted going into **Midnight Season 1** making it more beginner friendly:

- +2 Affixes
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  
  
  
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
- +6 Affix
  
  - [[spell:1284818]] removed
- +7 Affix -- Alternates between each other on a weekly basis
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  
  
  
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Restoration Druid**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:99]] to interrupt as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - There is nothing special you can do to help with this affix.
- Xal'atath's Bargain: Devour
  
  - Make sure to instantly dispel a healing absorb debuff!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Restoration Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Restoration Druid** Stat Priority in Mythic+
```json
{
  "source_code": "HoAJFUAJoEDIBEwAEA"
}
```
**智力 ＞ 急速 ＞ 全能 ≥ 精通 ≫ 暴击**
:::

> The conclusion here is that you want to equip the highest item level generally.

All secondary stats are affected by **diminishing returns**. [Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to learn more!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful Leech is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/PmriF2i-1024x509.png>)

Warcraftlogs

## Gear



### Best in Slot

Due to the way stat weights work for **Restoration Druids**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAkGAvj7kUrjgCchNYFA]] | Ula'tek |
| Neck | [[item:251142@BiQAAkGA8z6IoAOF]] | Murder Row |
| Shoulder | [[item:271526@DgQAAkGA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAkGACKAWBA]] | Coiled Altar |
| Chest | [[item:268235@AgQAAIoAOFA]] (Catalyst to Tier) | Nek'Zali |
| Wrist | [[item:244576@FCSAAkGAYA8ciqDBtOAAAAAAAA3WzSB]] | Crafting |
| Gloves | [[item:251124@AgQAAIoAOFA]] | Murder Row |
| Belt | [[item:268256@BiQAAkGA8z6IoAYF]] | Coiled Altar |
| Legs | [[item:271527@DgQAAkGAbo6IoAYF]] | Coiled Altar |
| Boots | [[item:244569@FARAAkGAYA88QuDAAcbNLFA]] | Crafting |
| Ring 1 | [[item:252258@DiQAAkGAvk7wPrjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:240949@FCRAAkGAYA88SuD_sOAAwt1sUA]] | Crafting |
| Trinket 1 | [[item:270164@BgQAAkGACKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270162@BgQAAkGACKgTBA]] | Soulcoiler |
| Weapon | [[item:271092@DgQAAkGAFk7kjAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FASAAkGAzB8gBwDAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Mythic+ from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@AgQAAIoABFA]] | Murder Row |
| Neck | [[item:251142@BiQAAkGA8z6IoABF]] | Murder Row |
| Shoulder | [[item:251223@AgQAAIoABFA]] | Voidscar Arena |
| Cloak | [[item:251190@AgQAAIoABFA]] | Blinding Vale |
| Chest | [[item:251159@AgQAAIoABFA]] | Den of Nalorakk |
| Wrist | [[item:251135@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:251124@AgQAAIoABFA]] | Murder Row |
| Belt | [[item:251166@AgQAAIoAUEA]] | Maisara Caverns |
| Legs | [[item:159313@AgQAAIoABFA]] | Pit of Saron |
| Boots | [[item:251153@AgQAAIoABFA]] | Den of Nalorakk |
| Ring 1 | [[item:252258@DiQAAkGAvk7wPrjgCEUA]] | Voidscar Arena |
| Ring 2 | [[item:159459@AgQAAIoABFA]] | King's Rest |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | Blinding Vale |
| Trinket 2 | [[item:273649@AgQAAIoABFA]] | King's Rest |
| Two-Hand Weapon | [[item:159636@AgQAAIoABFA]] | Tempel |
| One-Hand Weapon | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:251191@AgQAAIoABFA]] | Blinding Vale |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]][[item:274493@AgQAAkjABFA]] |
| **B-Tier** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:240167]]
  
  - Very strong stat stick, that also empowers your allies.

### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241288]]
  - [[item:241300]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAkGAaB]]
- **Sockets**
  
  - [[item:240892]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@DAAAAkGAvj7A]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@DAAAAkGAvj7A]] |
| Belt | [[item:275707@DAAAAkGAvj7A]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:244015@BAAAAkG]] |
| Ring 2 | [[item:244015@BAAAAkG]] |
| Weapon | [[item:243973@BAAAAkG]] |

:::

:::column
:::gear **Restoration Druid** Enchantments
```json
{
  "source_code": "IQFZpBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAAv0AEo8SuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAkGAvj7A]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Restoration Druid** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Night Elf
  
  - Turns you invisible, any action, movement, or suffering any damage breaks this effect.
  - Use-cases:
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].

### Recommendation:

It is highly recommended to play a Night Elf this season! The higher the keys you run, the more essential [[spell:58984]] becomes in certain dungeons, such as Mechagon and others.

## Macros

Discover recommended macros for **Restoration Druid** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Restoration Druid** Mythic+ Guide are available as mouseover macros for your convenience!

[[spell:774]]

```wow-macro
/cast [@mouseover, help] Rejuvenation; Rejuvenation
```

[[spell:8936]]

```wow-macro
/cast [@mouseover, help] Regrowth; Regrowth
```

[[spell:18562]]

```wow-macro
/cast [@mouseover, help] Swiftmend; Swiftmend
```

[[spell:33763]]

```wow-macro
/cast [@mouseover, help] Lifebloom; Lifebloom
```

[[spell:102693]]

```wow-macro
/cast [@mouseover, help] Grove Guardians; Grove Guardians
```

[[spell:48438]]

```wow-macro
/cast [@mouseover, help] Wild Growth; Wild Growth
```

[[spell:102401]]

```wow-macro
/cast [@mouseover, help] Wild Charge; Wild Charge
```

[[spell:102342]]

```wow-macro
/cast [@mouseover, help] Ironbark; Ironbark
```

[[spell:20484]]

```wow-macro
/cast [@mouseover, help] Rebirth; Rebirth
```

:::

:::details Recommended Macros
Guarantees that your [[spell:29166]] is always on yourself, without needing to deal with targeting or mouse-over adjustments.

```wow-macro
/cast [@player] Innervate
```

Cancel your current form to ensure you use the human form variant, allowing you to jump to one of your [[spell:102693]].

```wow-macro
#showtooltip Wild Charge
/tar Treant
/cancelaura [mod:ctrl] Travel Form
/cancelaura [mod:ctrl] Cat Form
/cancelaura [mod:ctrl] Bear Form
/cancelaura [mod:ctrl] Moonkin Form
/cast Wild Charge
```

Quicker Way for Emergency healing

```wow-macro
/Cast Nature's swiftness
/cast [@mouseover, help] Regrowth; Regrowth
```

Quicker Way for Combat Ress

```wow-macro
/Cast Nature's swiftness
/cast [@mouseover, help] Rebirth; Rebirth
```

Directly place your [[spell:145205]] without needing to confirm with a click.

```wow-macro
/cast [@cursor] Efflorescence
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Restoration Druid**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/f9BRME4-1024x576.webp>)

**Restoration Druid** Mythic+

:::accordion
:::details Addons
- EllesmereUI -- Everything
  
  - Addon to upgrade Blizzards very own UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Restoration
  
  - Developers' notes: We're making several quality-of-life adjustments to Restoration Druid in this update with a goal of addressing usability issues with Tranquility, Nature's Swiftness, and Incarnation: Tree of Life. We're also making a few adjustments to Swiftmend to bring back some of its power as a punchy single-target heal. Finally, we'd like to address issues with Abundance by redesigning it with a clear threshold of when you should be using Regrowth.
- New Talent: Overgrowth – Nature's Swiftness causes your next Regrowth to apply Lifebloom, Rejuvenation, and Wild Growth's heal over time effect to an ally.
- New Talent: Flash of Clarity – Omen of Clarity increases Regrowth's healing by 40%. Now available where Cultivation previously was in the talent tree.
- Cultivation is now available below Flash of Clarity in the talent tree.
- Innervate has been redesigned – Now regenerates 25% of the target's maximum mana over 8 seconds, rather than causing spells to be free for 8 seconds.
- Abundance has been redesigned – While you have at least 5 Rejuvenations active, Regrowth's critical strike chance is increased by 50% and its mana cost is reduced by 50%.
- Tranquility has been updated – Now grows protective roots at your feet, absorbing damage equal to 60% of your health and preventing knockbacks.
- Incarnation: Tree of Life has been updated – Now casts Regrowth on up to 3 nearby injured allies when you initially shapeshift.
- Swiftmend has been updated – Healing increased by 40% of the consumed heal over time effect.
- Everbloom (Rank 3) has been updated – Its heal effect now triggers when you press Swiftmend (was Soul of the Forest).
- Verdant Infusion has been updated – No longer extends heal over time effects.
- Germination has been updated – No longer increases Rejuvenation's duration by 2 seconds.
- Ysera's Gift has been updated – If its healing would overheal the Druid, the overhealing amount is instead transferred to a nearby ally.
- Mastery: Harmony healing bonus increased by 15%.
- All spell and ability healing increased by 6%.
- Wild Growth healing increased by 20% and mana cost increased by 15%.
- Verdancy healing increased by 40%.
- Rejuvenation mana cost reduced by 10%.
- Regrowth healing reduced by 20% and mana cost reduced by 10%.
- Lifebloom mana cost reduced by 20%.
- Passing Seasons reduces Nature's Swiftness cooldown by 15 seconds (was 12 seconds).
- Symbiotic Relationship now highlights itself on the action bar while it is not active.
- Germination and Verdancy have swapped positions in the talent tree.
- Nature's Splendor has been removed.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:102342]] as a personal defensive cooldown.

:::

:::details Q: Why do I keep running out of mana?
A: Keep [[spell:33763]] uptime at 100%, and don't waste a single [[spell:113043]] proc.

:::

:::

---

### Credits

Written By: **Rycn**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-07** Guide updated for patch 12.1

**2026-06-19** Guide updated for patch 12.0.7

**2026-04-22** Guide updated for patch 12.0.5

**2026-01-15** Guide updated for patch 12.0

**2025-10-07** Guide updated for patch 11.2.5

**2025-07-29** Guide updated for patch 11.2

**2025-06-18** Guide updated for patch 11.1.7

**2025-04-19** Guide updated for patch 11.1.5

**2025-02-22** Guide updated for patch 11.1

**2024-12-17** Guide updated for patch 11.0.7

**2024-10-20** Guide updated for patch 11.0.5

**2024-08-17** Guide Written for patch 11.0.2



:::
