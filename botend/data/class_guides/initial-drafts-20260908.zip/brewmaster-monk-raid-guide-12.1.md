欢迎来到《魔兽世界》12.1版本的 **酒仙 武僧** 团队副本攻略！本攻略涵盖了你需要了解的关于你的角色的全部内容！如果你是刚起步、从80级开始升级？请查看升级指南！

## 概述

:::columns
:::column
:::rating 团队副本
**单体目标** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 5/5 · 优秀

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **酒仙 武僧** 团队副本 最佳配装
```json
{
  "source_code": "JgfAYyQA3_PAB8JJEIIEFAw74OgDtOQOCchNYFwAmQQApfBBAERAA4QrDUwFYxYNYFQAKU9ACgQAAUTuDIoAOFQAiSCBB8ADJk7A5EwDUUT1DAICBEgMF4BAeGgH8UAAhu7A5IAWBE8FEEASuJQAwAwDN8DCE5mAuADAYAKJEAACBAQBLBYeWPggIEAA1j7AO06A3WzSBEQNtOghIEAAfA8A1j7AhZdFYQwXf0gNMgVAB4VEMAhTBEA2XUAGFoIP3eBBCARAA0TuDIoAWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240910]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240910]] · [[item:240910]] |
| 肩部 | [[item:251146]] | [[item:244021]] |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:251189]] | [[item:240910]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159304]] | [[item:243983]] |
| 腕部 | [[item:159300]] | [[item:240910]] |
| 手部 | [[item:271520]] |  |
| 戒指一 | [[item:251513]] | [[item:240910]] · [[item:243957]] |
| 戒指二 | [[item:240949]] | [[item:240910]] · [[item:245791]] · [[item:243957]] · [[item:251489]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270174]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**酒仙 武僧**，你可以使用再来一杯，它使你饮用的下一个酒类有20%的几率给你一个空酒桶，该空酒桶会在你下次使用[[spell:121253]]时被自动消耗，并造成额外的物理伤害。

**等级2** 会使你的 [[spell:121253]] 冷却时间重置，并且你的下一次 [[spell:121253]] 消耗的能量减少50%。而在 **等级3** 时，饮用 [[spell:115203]] 或 [[spell:322507]] 会给予你一个新鲜的酒桶，随后在消耗时为你提供增益 [[spell:1265140]]。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-brewmaster-mxr.webp>)

再来一杯

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[spell:400629]]
    
    - 以前，每当你受到伤害时，都有几率生成一个疗伤珠；现在每当你使用[[spell:109080]]时，都有几率生成一个疗伤珠。
  
  
  
  - [[spell:196736]]
    
    - 这一改动使得你的下一个[[spell:109080]]只会强化你的下一个[[spell:121253]]或[[spell:100780]]。
  
  
  
  - [[spell:1262659]]
    
    - 使你的火焰和自然伤害为你恢复其伤害量50%的生命值。
  - [[spell:1263245]]
    
    - 在[[spell:132578]]期间为我们提供额外的5%精通。
  - [[spell:1262017]]
    
    - 在施放[[spell:325153]]后，你的下2次[[spell:121253]]会被强化，并在敌人周围召唤一个火焰漩涡。
  - [[spell:1262329]]
    
    - 使我们可以在使用[[spell:325153]]后再次激活它，向附近的敌人额外投掷5个酒桶，并使我们的所有酒的冷却时间缩短3秒。
  - [[spell:383707]]
    
    - 除了为你的[[spell:121253]]额外增加一次充能外，它还为[[spell:121253]]额外增加10码距离，这使其非常适合从更远的地方进行开怪拉怪。
  - [[spell:1263345]]
    
    - 饮用你的任意一种酒会为你提供更多的移动速度和自动攻击速度。
- **职业天赋树**
  
  - [[spell:1266733]]
    
    - [[spell:119381]]现在会对所有被命中的敌人施加[[spell:116095]]，持续5秒。
  
  
  
  - [[spell:1243287]]
    
    - 现在不再是一个主动按钮，而是被整合进你的[[spell:115203]]中，功能是每当你按下[[spell:115203]]时，可以将魔法负面效果转移回你的目标身上。
  - [[spell:1272452]]
    
    - 使你的下一个[[spell:115080]]为其所造成伤害的50%为你恢复生命值。
- **已移除**
  
  - [[spell:122278]] 
    
    - 这导致在面对坦克的大型重击时，我们拥有的大型防御冷却技能变少了。
  
  
  
  - [[spell:310454]]
    
    - [[spell:310454]]的移除使我们不再拥有进攻性冷却技能。
  - [[spell:389577]]

## 英雄天赋

- [[talent:125028]] 和 ‍[[talent:125027]] 在伤害输出方面彼此之间竞争非常激烈。
- [[talent:125028]] 会通过 [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 和 [[spell:451036@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 影响你的操作玩法，而 [[talent:125027]] 则几乎完全是被动生效的。
- 推荐使用 [[talent:125028]]，因为它的单体目标伤害略高于 [[talent:125027]]，而且在团队副本首领战中更加耐抗，这主要归功于 [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]。

### [[talent:125027]]

- [[talent:125069]]
  
  - 你的自动攻击有几率生成 [[spell:451021]]。
  
  
  
  - 施放 [[spell:121253]] 将释放所有的 [[talent:125069]]。
- [[spell:450989@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 使 [[spell:132578]] 的冷却时间缩短25秒。
- [[spell:1272821@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]]
  
  - 在 [[spell:132578]] 期间，你的下一次 [[spell:115181]] 将释放3倍的 [[talent:125069]]。

- [[talent:125027]] 选择节点的选取为：
  
  - [[talent:125068]]
  - [[spell:1272844]]
  
  
  
  - [[talent:125064]]
    
    - 这个被动效果没有冷却时间，随时都有可能触发。

在12.0前置补丁中，你可以解锁新的英雄天赋栏，但可用的点数有限。

- [[spell:1262603@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]] 
  
  - 每当你使用 [[spell:132578]] 时，你都会立即获得10层 [[spell:450615]]。

### [[talent:125028]]

- [[spell:450508@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 伤害和有效治疗会被储存为活力。
  - 在 [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 期间你不会产生任何活力。
  - 重要：过量治疗不计入有效治疗。
- [[talent:125035]] 
  
  - 关键节点，确保永远不浪费任何活力。
- [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 拥有2层充能的 [[spell:1241059]] 让你可以轻松地保留/延迟使用，以优化伤害和生存能力。
- [[spell:451036@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 额外的护盾和 [[spell:115069]] 的缩减在防御方面非常强力。
- [[spell:450529@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 当你处于 [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 的效果影响下时，敌人受到的伤害提高20%。

在12.0前置补丁中，你可以解锁新的英雄天赋栏，但可用的点数有限。

- [[spell:1239442]] 
  
  - 每当你施放 [[spell:1241059]] 时，你接下来的2次 [[spell:100780]] 会被强化，并会触发一次 [[spell:1239442]]。
- [[spell:1271048]]
  
  - 每次 [[spell:121253]] 之后，你的下一个 [[spell:100780]] 将触发一次 [[spell:1239442]]。

## 天赋

### 防御型build

:::talents **酒仙 武僧** 团队副本 防御型配装
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 何时使用此专精

除非另有说明，这是应对任何首领的默认配置。你需要根据战斗所需的 utility 来调整职业天赋树。为了方便起见，针对特定首领的天赋配置可在团队副本章节中找到。

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若需更详细的解析，请查看下方的循环和 **深度解析** 章节。

##### 专精树

- [[talent:124864]]
  
  - 酒醒入定使[[spell:115069]]的效果翻倍。
- [[spell:400629]]
  
  - 使你的[[spell:109080]]有几率生成[[spell:115464]]。
- [[spell:212935]]
  
  - 在施放[[spell:121253]]之前，务必确保[[spell:115181]]处于冷却中，以便获得该天赋提供的冷却重置效果。
- [[spell:383707]]
  
  - [[spell:121253]]现在拥有2次充能，且距离增加10码。
- [[spell:389942]]
  
  - [[spell:100780]]变得强大得多，并会产生额外的酒类冷却缩减。

##### 职业树

- [[talent:124950]]
  
  - [[spell:115546]] 现在会使目标的移动速度提高50%。
- [[talent:124963]]
  
  - 现在翻滚之后你可以按下二段跳，向前进行一小段冲刺。

### 伤害向配置

:::talents **酒仙 武僧** 团队副本 伤害向配置
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDzw2M2wMjBAAAAAAYZBjGzMwMM2YwMzMDz2YmxMLPAbLPwy2sNLmFAAYb2mWmtZWGAgZbWamZmFGWAYmhpxAAAGA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDzw2M2wMjBAAAAAAYZBjGzMwMM2YwMzMDz2YmxMLPAbLPwy2sNLmFAAYb2mWmtZWGAgZbWamZmFGWAYmhpxAAAGA"
}
```
:::

#### 何时使用此专精

这套天赋配置更适合进阶的**酒仙武僧**，适合那些懂得如何熟练管理自身资源的玩家。这套配置更侧重于伤害输出，但如果操作得当，也能轻松应对各种生存压力。

#### 天赋调整

列出与默认构筑相比，职业树和专精树中的所有改动。

##### 职业树

- **新增**
  
  - [[talent:124837]]
    
    - 提高你的自动攻击速度，有助于获取 [[spell:451021]]。
  - [[spell:196730]]
    
    - 每当你使用 [[spell:1241059]] 或 [[spell:119582]] 时，你都会向敌人丢下一个酒桶，造成额外伤害。
- **移除**
  
  - [[spell:455139]]
    
    - 只提供一个非常小的护盾，且没有任何伤害收益。

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:115181]] 会点燃你的下一个 [[spell:121253]]，使其在命中时爆炸，对其主要目标造成额外的烈焰风暴伤害，并对额外目标造成较低的伤害。
- **4件套：** 被点燃的 [[spell:121253]] 会使被击中的敌人受到你物理技能的伤害提高8%，并在地面上留下一片火焰，每秒造成 火焰 点伤害，持续5秒。

### 起手爆发

- 我们希望借助[[spell:121253]]和[[spell:205523]]获得可观的[[spell:322120]]，同时不断铺开我们的减益效果。

:::rotation **酒仙武僧** 团队副本 起手爆发
```json
{
  "source_code": "IUETIIUpZHAAAAQABwprDAAAAAgQwmYAQgAACxaDIQQ7BnAEJgCEAIUI2TgPoAA"
}
```
1. [[spell:121253]]  [[item:241308]]
2. [[spell:100784]]
3. [[spell:100780]]
4. [[spell:115181]]
5. [[spell:121253]]
6. [[spell:325153]]
7. [[spell:100784]]
8. [[spell:100780]]
:::

### 优先级列表

请务必牢记这份清单，除非某些首领或场景需要你保留这里列出的一些技能

1. 冷却好了就施放[[spell:121253]]。
2. 冷却好了就施放[[spell:100784]]。
3. 当目标达到8个或以上时，施放[[spell:100780]]或[[spell:101546]]。
4. 如果点出了相应天赋，施放[[spell:115181]]。
5. 施放[[spell:325153]]。
6. 如果点出了相应天赋，施放[[spell:123986]]。
7. 当一波小怪即将被清完时，务必尽可能使用[[spell:322109]]。

### 防御技能冷却

- [[spell:1241059]]
  
  - 在持续期间为你提供一个较小的吸收护盾和30%的伤害减免。
  
  
  
  - 通过[[spell:121253]]和[[spell:100780]]获得冷却缩减。
  - 搭配[[talent:125028]]天赋[[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]后现在拥有2层充能。
- [[spell:322507]]与[[spell:1241059]]的对比
  
  - 对于团队副本，我推荐使用[[spell:1241059]]，因为在数值上它是优于[[spell:322507]]的更好选择。

- [[spell:243435]]
  
  - 冷却时间长达4分钟，但可以通过[[spell:121253]]和[[spell:100780]]来缩减。
  - 提供20%最大生命值和20%伤害减免，这使它成为你最全面的**防御技能**。
  - 主要用于对抗巨大的伤害，并且尽量早用，好让冷却缩减机制尽早开始运作以使其恢复。
- [[spell:132578]]
  
  - 当你的[[spell:115069]]特别高时使用，因为它会替你承受40%的[[spell:115069]]伤害。

### 进攻冷却技能

- [[talent:125001]]
  
  - 使被击中目标的近战攻击在3秒内100%未命中你。
  - 投掷一个酒桶，使你的所有伤害附加额外火焰伤害。与[[spell:101546]]配合在范围伤害上使用。
- [[spell:322109]]
  
  - 施放时移除最多200%的[[spell:115069]]。[[spell:325095]]非常适合在冷却时施放，兼具伤害和防御价值。

## 深度解析

### 醉拳

**酒仙武僧** 依靠其[[spell:115069]]机制被动地降低所受伤害，这是其伤害减免的核心组成部分。

#### 醉拳阶段

你的[[spell:115069]]分为3个不同的阶段。

- [[spell:124275]]
  
  - [[spell:115069]] 总伤害量等于你最大生命值的 1-29%。
- [[spell:124274]]
  
  - [[spell:115069]] 总伤害量等于你最大生命值的 30-59%。
- [[spell:124273]]
  
  - [[spell:115069]] 总伤害量等于你最大生命值的 60% 或以上。

使用 [[spell:119582]] 可以净化 **50%** 的 [[spell:115069]] 伤害，从而缩短你的 [[spell:115069]] 阶段，这也是你的主要减伤手段。[[spell:119582]] 最好在刚受到大量伤害后立即使用，将 [[spell:115069]] 伤害减半。

### 管理天神灌注与活血酒

在 **酒仙 武僧** 中，灵活运用 [[spell:322507]] 和 [[spell:119582]] 是你生存能力的核心任务与玩法。

- 如上所述，[[spell:119582]] 是你净化 [[spell:115069]] 的主要手段。
  
  - 需要注意的是：[[spell:119582]] **不受公共冷却时间影响**，因此可以在使用其他任何技能的同时按下它。
- [[spell:1241059]] 则是你的防御技能。

以下是一些关于使用它们时需要牢记的技巧和要点：

- 在分配 [[spell:119582]] 使用层数时，有几条规则需要牢记：
  
  - 避免让两层充能同时就绪，否则你会浪费技能带来的防御价值和冷却缩减价值。
  
  
  
  - 确保始终通过 [[spell:121253]] 获得完整的冷却缩减。
- 关于如何最高效地使用 [[spell:119582]] 的通用原则：
  
  - 在承受一次重击之后使用，这样可以在 [[spell:115069]] 刚产生且处于最高点时净化掉最多的伤害。
  - 另一种选择是在承受重击后几乎完全净化掉所有危险的 [[spell:115069]]，做法是先积累大量酒醉状态，然后连续使用两层充能。
- 总体而言，只要遵循自然的游戏节奏，你就应该频繁使用它，以避免 [[spell:124273]] 并防止充能溢出浪费。
- 你可能犯的最大错误就是一冷却就用掉所有充能，结果在 [[spell:115069]] 变得危险时却毫无充能可用。
- [[spell:1241059]] 的使用则更简单直接：
  
  - 它是你最常用的主动防御技能，应尽可能用在大多数机制上。
  - 尽量不要把它扣太久，因为这样会浪费冷却缩减，从长远来看会导致承受更多伤害。
  - 不过在某些情况下，你必须把它留给危险的坦克机制，请牢记这一点。

### 酒醒入定

**酒仙 武僧**需要 [[spell:115069]] 才能在各种机制下存活，而让这一切在很大程度上成为可能的正是 [[talent:124864]]。

- [[talent:124864]] 通过按下 [[spell:121253]]、[[spell:101546]] 和 [[spell:205523]] 被动产生。
- 只要你不停止按键，[[talent:124864]] 就永远不会掉，你无需对此付出任何注意力。但在某些情况下该增益可能会耗尽：
  
  - 当机制迫使你离开攻击范围而你无法接近首领时，你可能会导致它掉落，从而承受更多伤害，所以要小心！
  - 用 [[spell:121253]] 开怪并快速冲进去可能会导致死亡。由于 [[talent:124864]] 是由 [[spell:121253]] 的伤害而非施法触发的，如果你的速度比酒桶飞行还快，你可能会在 [[talent:124864]] 尚未生效时被打中而死。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下技巧适用于**史诗首领**以及如何最好地在这些战斗中存活。本节推荐的构建会帮助你度angular过每场遭遇战，但并不能为你提供最高的伤害输出。

**← 滚动查看更多首领 →**

### 内克扎莉

:::talents **酒仙 武僧** 团队副本 内克扎莉
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 坦克机制

- 这场战斗的主要坦克机制是蚀空打击——首领每次近战攻击以及施放 [[spell:1284103]] 时都会施加的一种减益效果。
- 在 [[spell:1284103]] 期间，首领会向当前坦克发射幽灵回响，额外施加蚀空打击层数。这些回响在首次接触到任意玩家时会爆炸，对团队造成降低后的 
  
  - 当你成为该机制的目标时，走出团队，并确保你和首领之间没有任何人，以免他们过早触发回响。否则，回响会对团队造成过多伤害。
  - 每次 [[spell:1284103]] 施放完毕后进行嘲讽换坦。
- 此外，首领还会召唤成群的不安阿曼尼——务必将首领拉到它们旁边，以便更好地进行顺劈。
- 在过渡阶段，当前坦克会成为一次群体分担——[[spell:1289855]] 的目标。尽量将它放在尽可能多的不安阿曼尼尸体上，利用 [[spell:1289875]] 将其烧毁，防止它们再次苏醒。

### 被埋葬的哨兵

:::talents **酒仙 武僧** 团队副本 被困守卫
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 坦克机制

- 由于 [[spell:1290189]]，首领们必须始终保持至少40码的距离。在每个阶段开始时，将首领们移到房间的不同两侧使其分开。
- [[spell:1284458]] 和 [[spell:1284487]] 是各个首领的叠加坦克减益效果。在 [[spell:1284588]] 期间，每当首领们在房间中央相遇时，务必进行嘲讽换坦以重置你的层数。
  
  - [[spell:1284487]] 额外会在到期时产生一个大型血泊。如果可能，请务必将其放置在房间的边缘。
- 不要将 乌拉特克之息 坦克在现有的血泊太近的位置，这样 [[spell:1284251]] 就不会在血泊中生成，近战职业就可以安全地攻击它。

### 迷失的探险者

:::talents **酒仙 武僧** 团队副本 迷失的探险者
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 坦克机制

- 由于 [[spell:1297645]]，三个首领彼此都不能处于 30 码以内——始终让其中一个首领远离另外两个。
- 商人盖博 只会在房间里游荡，不会跟随或攻击其仇恨目标。它也没有任何坦克机制。
- 书卷贤者伊库 会对其当前目标施放 [[spell:1295854]]——一连串冰碎片，每片造成魔法伤害，并使后续碎片受到的伤害提高，持续 80 秒。
- 大副纳玛 每次攻击都会对其目标施加 [[spell:1291929]]，使该目标受到的物理伤害提高，持续 30 秒。
- 这场战斗中坦克的职责是在Scrollsage伊库和 大副纳玛 之间来回换坦，绝不让 [[spell:1295854]] 连续两次施放在同一目标身上，并尽可能频繁地重置 [[spell:1291929]]，同时始终让其中一个首领距离足够远，以防止 [[spell:1297645]] 被施加。

### 瓦什尼克

:::talents **酒仙 武僧** 团队副本 瓦什尼克
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 坦克机制

- 房间两侧放置着 3 座喷泉：鲜血之泉、火焰和 暗影。整场战斗中，首领会通过 [[spell:1283164]] 激活最近的两座喷泉，获得它们的力量并召唤一些小怪。
  
  - 每座喷泉被激活后，会使下一次激活强化 1.5 分钟。
  
  
  
  - 作为坦克，你的职责是通过在每次 [[spell:1283164]] 施放前将首领拉到下一座喷泉处，绝不让首领连续激活相同的两座喷泉。
  - 务必将首领定位在从喷泉出来的小怪上方，以便更好地顺劈。但是，要小心不要过快杀死所有火焰小怪，因为它们死亡时会施加可叠加的 [[spell:1285979]]。
- 瓦什尼克的坦克打击技能是 [[spell:1280935]]，每次施放后进行嘲讽换坦。

### 斯索拉克

:::talents **酒仙 武僧** 团队副本 斯索拉克
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 战斗机制

- [[spell:1277025]] 是一组坦克正面机制的组合，由 2 次 [[spell:1277002]]、2 次 [[spell:1277027]] 和 1 次 [[spell:1287072]] 组成，以随机顺序施放。
  
  - [[spell:1277002]] 是一个正面锥形范围技能，造成高额物理伤害并跟随当前坦克。务必将其指向**远离团队**的方向。
  - [[spell:1277027]] 是一个正面锥形范围技能，会施加一个强力的魔法持续伤害效果，其效果会被锥形范围内被击中的人数所分摊减弱。务必将此技能指向团队的一半人马，让他们来分担。
  - [[spell:1287072]] 会在首领周围生成一群龙卷风，并在施法结束时将其向外发射。当此技能发生时，确保你不在首领下方，并躲避龙卷风。
  - 在英雄和史诗难度下，首领会以随机顺序施放这些技能。由于每个正面锥形技能都会施加来自该技能的伤害提高效果，务必确保同一个坦克绝不承受 2 次相同技能。请记住，你可以在施法期间嘲讽，让首领将正面锥形技能对准你。
- 每次施放 [[spell:1306120]] 都会在首领周围生成 [[spell:1305998]] 个水坑。务必将首领拉到房间边缘，理想情况下是与 [[spell:1285732]] 刷新点相对的一侧，这样水坑就会被风吹出房间边缘。
- 除此之外，斯索拉克 每次近战攻击都会施加一层 [[spell:1282869]]，使目标受到的物理伤害提高。在每次 [[spell:1277025]] 连击后进行嘲讽换坦就足以重置层数。

### 双生利牙

:::talents **酒仙 武僧** 团队副本 双生利牙
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 通用机制

- 整场战斗的核心在于管理 [[spell:1290336]] 层数
  
  - [[spell:1291404]]、[[spell:1291478]]、被毒波命中或吸收 [[spell:1289201]] 都会施加一层 [[spell:1290336]]。
  - 在英雄难度下达到 10 层或史诗难度下达到 9 层会立即死亡。
  - 尽可能躲开毒波，同时控制好吸收 [[spell:1289201]] 的数量，以避免该减益效果达到最大层数，这一点至关重要。

#### 坦克机制

- 当你主动坦住的首领脱离近战范围时，它会施放 [[spell:1295107]] 或 [[spell:1295113]]，所以千万不要离开近战范围；如果发现自己离首领太远，请使用一个大型个人减伤。
- 维克苏尔 的坦克技能是 [[spell:1289192]]，造成自然伤害并将你击退 5 秒。
  
  - 它还会在你周围生成 [[spell:1289201]]。这些需要由玩家吸收，以免爆炸后给所有人叠加一层 [[spell:1290336]]。
  - 每次被击中都会施加 [[spell:1310360]]，因此每次 [[spell:1289192]] 施放后都要进行嘲讽换坦。
  - 注意击退效果，尤其是毒波即将到来的时候！
- 伊斯拉兹 会施放 [[spell:1288538]]，击退靠近首领的玩家并生成 3 个吸收区域。
  
  - 每个区域会造成高额物理伤害，并使下一个区域造成的伤害提高 33%。如果无人吸收该区域，它会对全团造成伤害并将所有人击飞。务必在每组 [[spell:1288538]] 之间进行嘲讽换坦，以重置伤害增加的层数。
  
  
  
  - 这些区域以随机顺序生成，并且必须按照生成的先后顺序依次吸收。在这一技能进行时，请密切关注区域的生成并记住生成顺序。首领在触发下一个区域前会短暂地面朝该区域的方向，所以如果你记不住生成顺序，可以参考首领的朝向。
  - 每隔一次 [[spell:1288538]] 施放都会与毒波重合——吸收 [[spell:1288538]] 时务必确保不被毒波击中。
  - 小心该机制开始时的击退，因为它可能把你推入袭来的毒波或某个 [[spell:1289201]] 中。

### 盘绕祭坛

:::talents **酒仙 武僧** 团队副本 蜷曲祭坛
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 第一阶段

- 该阶段中只有 祖尔加 处于激活状态。
- 他会施放 [[spell:1299960]]，在该阶段中生成多个 [[spell:1282403]] 法球。法球存在期间会持续对全团造成 范围伤害 伤害，玩家可以撞入法球来拾取并移动它们。
- [[spell:1299684]] 是一个指向当前坦克的正面锥形技能，造成物理伤害，并摧毁任何被它命中的 [[spell:1282403]]。
  
  - 它还会使下一次 [[spell:1299684]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
- 该阶段的目标是让团队将 [[spell:1282403]] 法球聚集到一起，然后用 [[spell:1299684]] 将其摧毁。
- 此外，每次施放 [[spell:1282487]] 都会强化首领接下来的 23 次近战攻击，附带 [[spell:1300322]]，对坦克造成额外的自然伤害。
  
  - 当首领身上有 [[spell:1300322]] 层数时，务必提前开启减伤技能。

#### 第二阶段

- 该阶段中只有 妖术领主玛拉卡斯 处于激活状态。
- 他会施放 [[spell:1285640]]，对被选中的玩家进行精神控制，并且每当精神控制被打断时，每名玩家会生成 2 个 [[spell:1285842]]。
  
  - 这些具象会锁定随机玩家并向其移动，除非被锁定的玩家回头面对该具象。
- 与第一阶段的 [[spell:1299684]] 类似，[[spell:1286620]] 是一个指向当前坦克的正面锥形技能，造成暗影伤害，并摧毁任何被它命中的 [[spell:1285842]]。
  
  - 它还会使下一次 [[spell:1286620]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
  - 此外，它会施加 3 层 [[spell:1286837]]，每层会生成一个灵魂碎片，必须拾取灵魂碎片才能移除对应的层数。如果在减益效果到期前没有清空层数，受影响的玩家会立即死亡。
  - 在每次坦克正面锥形技能之后，务必格外注意迅速找到并收集所有灵魂碎片。
- 被 [[spell:1286895]] 命中同样会施加 3 层 [[spell:1286837]]。千万不要掉以轻心！

#### 阶段转换

- 马拉克拉丝在施放 [[spell:1287685]] 期间受到的伤害提高 100%。
- 不要让任何马拉克拉丝碎片到达首领处，通过吸收它们来阻止其治疗首领。
  
  - 吸收每个碎片会对全团造成 范围伤害 伤害，因此不要吸收得太快，给治疗者一些时间来应对即将到来的伤害。

#### 第三阶段

- 在该阶段中，祖尔加 和马拉克拉丝同时激活，并结合了第一阶段和第二阶段的技能。
- 该阶段中 [[spell:1299960]] 和 [[spell:1285640]] 都会出现，这意味着 [[spell:1282403]] 和 [[spell:1285842]] 都需要由坦克的正面锥形技能来清除。
- 该阶段的坦克正面锥形技能是 [[spell:1307279]]，造成暗影伤害，摧毁任何被它命中的 [[spell:1282403]] 和 [[spell:1285842]]，并施加 3 层 [[spell:1286837]]。
  
  - 别忘了收集你的灵魂碎片，并在每次锥形技能后进行嘲讽换坦！
- [[spell:1298381]] 是第一阶段 [[spell:1282487]] 的强化版本。
  
  - 在该阶段中，被强化的近战攻击还会额外施加可叠加的  暗影持续伤害。当层数较高时，请使用大型减伤技能。

### 乌拉特克

:::talents **酒仙 武僧** 团队副本 乌拉特克
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

### 尼姆瑞莎·唤波者

:::talents **酒仙 武僧** 团队副本 尼姆瑞莎·唤波者
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMWYmZMAAAAAAALLY0YmBmhxGDmZmZY2GzMmZ5BYbbW2mtxMLAAwysNtMbzsMAAQAMsAmZATDAAgB"
}
```
:::

#### 通用机制

- 首领会用刺骨的 冰霜 随机标记玩家，在其脚下生成 冰霜 法球。
  
  - 这些法球必须在爆炸并团灭团队之前被吸收。
  - 吸收法球会施加一个可叠加的减益效果，使吸收 冰霜 法球时受到的伤害增加，所以不要一次吸收太多。
  - 每次吸收法球还会对全团造成 范围伤害，因此不要吸收得太快，给治疗者一些时间来应对即将到来的伤害。
- 鱼人会不时从水中出现，并开始走向房间中央的气泡。
  
  - 不要让它们到达气泡处，并尽可能将首领移动到它们上方，以便更好地进行顺劈。

#### 坦克机制

- 这场战斗中坦克专属的机制是冰刃连斩——一系列魔法斩击，每一斩都会增加后续斩击的伤害。
  
  - 每次施放时使用一个防御技能，并在每次结束后换坦嘲讽。

## 属性优先级

了解你在 团队副本 Boss 战期间获得最佳表现所需的次要属性优先级和第三属性，作为一名 **酒仙 武僧**。欲了解更多详细信息，请访问 **[属性与特性](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority **酒仙 武僧** 团队副本 中的属性优先级
```json
{
  "source_code": "HoAJFMAKgEDJBIQABA"
}
```
**敏捷 ＞ 全能 ＝ 暴击 ＞ 精通 ＞ 急速**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 能够有效降低"**范围伤害**"技能所造成的伤害的优秀属性。
- **吸血** - 通过造成伤害来提供额外治疗。
- **加速** - 一种小众的第三属性，但在某些情况下非常有用，过去也曾被证明其实用价值。它能让应对某些机制变得轻松许多。

总体而言，吸血 对坦克来说非常强力，尤其是在 范围伤害 环境下，它可能是你所能拥有的最佳属性。  
闪避 也很不错，但大多数时候坦克并不难在典型的范围效果技能下存活。

## 装备

### 总体最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | 将 [[item:271875@BARAAwQACKwF2gVA]]  <br> 转换为 [[item:271519@DCRBAwQAvj74QrTOCchNYFwAmQA]] | 乌拉特克的催化者 |
| 颈部 | [[item:268265@BERAAwQAO064QrTOCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:251146@DgQAAwQA1k7IoAOF]] | 纳洛拉克的洞穴 |
| 披风 | [[item:268248@BgQAAwQACKgTBA]] | 盘魂者内克扎莉 |
| 胸部 | [[item:271522@DgQAAwQAJk7kjAOF]] | 恶性瓦辛克 |
| 手腕 | [[item:159300@BiQAAwQAO06IoAOF]] | 诸王之眠 |
| 手套 | [[item:271520@BgQAAwQA5IgTBA]] | 被埋葬的哨兵 |
| 腰带 | [[item:251189@BiQAAwQAO06IoAOF]] | 夺目谷 |
| 腿部 | 将 [[item:268225@BgQAAwQA5IAWBA]]  <br> 转换为 [[item:271518@DgQBAwQAhu7kjAYFQwXQ]] | 盘卷祭坛的催化者 |
| 靴子 | [[item:159304@DgQAAwQAPk7IoAOF]] | 诸王之眠 |
| 戒指 1 | [[item:251513@DiQAAwQA1j74Qrzt1sUA]] | 制造业 |
| 戒指 2 | [[item:240949@HiQAAwQAfA8UPuTYWPO06cbNLFA]] | 制造业 |
| 饰品 1 | [[item:270175@BgQAAwQA5IAWBA]] | 乌拉特克 |
| 饰品 2 | [[item:270174@BgQAAwQA5IgTBA]] | 斯索拉克 |
| 武器 | [[item:268215@DARAAwQA9k7IoAWYDWB]] | 乌拉特克 |

### 可刷取的替代选择

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 位置 |
| --- | --- | --- |
| 头部 | [[item:193751@BgQAAwQACKQQBA]] | 红玉新生法池 |
| 颈部 | [[item:251234@BgQAAwQACKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:251146@BgQAAwQACKQQBA]] | 纳洛拉克的洞穴 |
| 披风 | [[item:159288@BgQAAwQACKQQBA]] | 诸王之眠 |
| 胸部 | [[item:251226@BgQAAwQACKQQBA]] | 虚空之痕竞技场 |
| 手腕 | [[item:159300@BgQAAwQACKQQBA]] | 诸王之眠 |
| 手套 | [[item:193758@BgQAAwQACKQQBA]] | 红玉新生法池 |
| 腰带 | [[item:251189@BgQAAwQACKQQBA]] | 夺目谷 |
| 腿部 | [[item:251198@BgQAAwQACKQQBA]] | 夺目谷 |
| 脚部 | [[item:159304@BgQAAwQACKQQBA]] | 诸王之眠 |
| 戒指1 | [[item:251148@BgQAAwQACKQQBA]] | 纳洛拉克的洞穴 |
| 戒指2 | [[item:251136@BgQAAwQACKQQBA]] | 密谋小径 |
| 饰品 1 | [[item:250244@BgQAAwQACKQQBA]] | 纳洛拉克的洞穴 |
| 饰品 2 | [[item:250228@BgQAAwQACKQQBA]] | 密谋小径 |
| 武器 | [[item:251192@BgQAAwQACKQQBA]] | 夺目谷 |

### 饰品

以下是从地下城和团队副本中可获得的游戏后期饰品排名。请注意，上文推荐的饰品是以伤害最优为目标的；如果你不在意伤害而只想活下去，我建议你使用类似 [[item:270160@BgQAAwQA5IgTBA]] 这样的饰品。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgQAAwQA5IAWBA]]  <br>[[item:270174@BgQAAwQA5IgTBA]] |
| **A级** | [[item:270160@BgQAAwQA5IgTBA]]  <br>[[item:270173@BgQAAwQACKAWBA]]  <br>[[item:250244@BgQAAwQACKgTBA]]  <br>[[item:250215@BgQAAwQACKgTBA]]  <br>[[item:250228@BgQAAwQACKgTBA]] |
| **B级** | [[item:270164@BgQAAwQA5IgTBA]]  <br>[[item:250243@BgQAAwQACKgTBA]]  <br>[[item:159617@BgQAAwQACKgTBA]]  <br>[[item:159618@BgQAAwQACKgTBA]] |
| **C级** | [[item:273796@BgQAAwQACKgTBA]]  <br>[[item:250259@BgQAAwQACKgTBA]]  <br>[[item:250214@BgQAAwQACKgTBA]]  <br>[[item:193757@BgQAAwQACKgTBA]] |
| **垃圾级** | [[item:270165@BgQAAwQA5IgTBA]]  <br>[[item:250245@BgQAAwQACKgTBA]]  <br>[[item:250225@BgQAAwQACKgTBA]] |

### 美化饰品

- [[item:251513@DiQAAwQA1j74Qrzt1sUA]]
  
  - 不错的被动次级属性加成。
- [[item:251489@BAAAAwQA]]
  
  - 使你所有宝石提供的属性翻倍，并且可以镶嵌在任意装备上。

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药剂**
  
  - [[item:241326]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器磨刀石**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **插槽**
  
  - [[item:240983]] *—— 唯一，只能使用一次。*
  - [[item:240914]]
  - [[item:240910]]

### 附魔

:::columns
:::column
| 头部 | [[item:243949@DAAAAwQAZbAB]]  <br>[[item:275707@BAAAAwQA]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 手腕 | [[item:275707@BAAAAwQA]] |
| 腰带 | [[item:275707@BAAAAwQA]] |
| 腿部 | [[item:244641@BAAAAwQA]] |
| 靴子 | [[item:243983@BAAAAwQA]] |
| 戒指 1 | [[item:244017@BAAAAwQA]] |
| 戒指 2 | [[item:244017@BAAAAwQA]] |
| 武器 | [[item:244029@BAAAAwQA]] |

:::

:::column
:::gear **酒仙 武僧** 团队副本
```json
{
  "source_code": "IQFZMEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *你从宏伟宝库商人处购买 ‍[[item:275707@BAAAAwQA]] 来为你的头盔、手腕和腰带添加插槽。*

## 种族

为了将 **酒仙 武僧** 最大化，不同的种族特长可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你风格的种族同样可行。

- **[[spell:65116]]** -- 矮人
  
  - 非常有价值，因为你可以为自己驱散魔法或移除危险的流血效果。
  - 此外，使用石像形态可以为你提供10%的物理伤害减免，在坦克时可以作为一个持续8秒的小型额外减伤技能。
- [[spell:25046]] -- 鲜血精灵
  
  - 强大的种族技能，可用于驱散或驱除敌人身上的增益效果，价值非常有限，但有时能派上用场。
- [[spell:69070]] -- 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在[[spell:69070]]动画期间，你会处于公共冷却状态，直到角色落地为止。
- [[spell:256948]] -- 虚空精灵
  
  - 生成一道朝你面向方向旅行的暗影裂隙，再次激活即可传送到裂隙处。
  - 最大距离为100码。

### 推荐

对于坦克来说，选择一个以输出为目的的种族大多数时候收益微乎其微，并不划算。如果你在意极限优化你的 DPS，那就选择 DPS 最高的种族。

话虽如此，推荐给团队副本坦克的种族无疑是 **矮人**，因为它拥有主动使用的物理伤害减免技能，以及按需自我驱散的能力。这些特性极其强大，绝不应被低估！

## 宏

探索 **酒仙 武僧** 的推荐宏，并观看一段关于为你的角色创建简单宏的快速视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
嘲讽宏 --- *此宏会对你的当前目标或鼠标悬停目标施放 [[spell:115546]]*（在拉起小怪时非常实用）

```wow-macro
#showtooltip 嚎镇八方
/cast [@mouseover,exists,harm][@target,exists,harm] 嚎镇八方
```

首领 1 嘲讽 --- *对首领 1 施放* [[spell:115546]]

```wow-macro
/cast [@boss1] 嚎镇八方
```

首领 2 嘲讽 --- *对首领 2 施放* [[spell:115546]]

```wow-macro
/cast [@boss2] 嚎镇八方
```

:::

:::details 鼠标指向宏
[[spell:116841]] --- *此宏会对你的当前目标或鼠标悬停目标施放 [[spell:116841]]*

```wow-macro
#showtooltip 迅如猛虎
/cast [@mouseover,exists,noharm][@target,exists,noharm] 迅如猛虎
```

[[spell:115078]] --- *对鼠标悬停目标施放 [[spell:115078]]*

```wow-macro
#showtooltip
/use [@mouseover] 分筋错骨
```

鼠标指向焦点 --- *此宏将鼠标指向的目标设为焦点*

```wow-macro
/focus [@mouseover]
```

:::

:::details 焦点目标宏
[[spell:115078]] --- *对焦点目标施放[[spell:115078]]*

```wow-macro
#showtooltip
/use [@focus] 分筋错骨
```

焦点 [[spell:116705]] --- *对焦点目标施放[[spell:116705]]*

```wow-macro
#showtooltip 切喉手
/cast [@focus,harm,nodead][] 切喉手
```

:::

:::details 实用宏
[[spell:116844]] 光标 --- *在光标位置直接施放[[spell:116844]]**，无需确认。*

```wow-macro
/cast [@cursor] 平心之环
```

取消保护之手 --- *取消你身上的[[spell:1022]]，与圣骑士组队时非常实用*。

```wow-macro
/cancelaura 保护祝福
```

:::

:::

## 插件

下方是作者为其 **酒仙 武僧**所用用户界面的截图，其中概述了使用了哪些插件以及它们在团队副本中如何帮助你更轻松地进行游戏。

![](<https://assets-ng.maxroll.gg/wordpress/Monk-Raid-Interface-1024x607.png>)

**酒仙 武僧** 突袭界面

:::accordion
:::details 插件
- **ElvUI *-- 整体用户界面替换*** 
  
  - 一款以用户友好为核心设计的界面插件，附带标准界面所没有的额外功能。
  - 你也可以选择 Shadowed Unit Frames (SUF) 加上任意动作条插件，或者直接使用原生界面。
- [](<https://www.curseforge.com/wow/addons/shadowed-unit-frames>)**BigWigs** -- 通用首领模块
  
  - BigWigs 是一款首领战插件。它由许多独立的战斗脚本（即首领模块）组成——这些小型插件旨在为某个特定团队战斗触发警报信息、计时条、音效等。
- **Plater** -- 高级姓名版
  
  - Plater 是一款姓名版插件，拥有极其丰富的设置选项，开箱即用的减益监控、仇恨染色以及大量自定义功能。
- **Details** -- 深度伤害统计
  
  - 让你的伤害统计界面更好看。
- **MRT** -- 标记、团队副本 冷却监控及更多功能
  
  - 对团队成员非常有用的插件，尤其是对团长和官员而言。

:::

:::

## 本次版本改动

:::accordion
:::details 12.1 版本
#### 武僧

- 真气转移现在使轮回之触为你恢复其造成伤害60%的生命值（原为50%）。
- 蓬勃施疗使移花接木的治疗量提高6%（原为5%）。
- 静寂圣所的治疗量提高25%。

#### 酒仙

- 震荡打击提供的⟦WOWTERM_00001⟫缩短效果提高25%。
- 玄牛之魂生成疗伤珠的几率提高20%。
- 天神酒和天神灌注的吸收量提高150%，冷却时间延长100%。
- 觉醒之魂的最大吸收值提高25%。
- 生命之焰现在为你恢复所造成的火焰或自然伤害50%的生命值（原为40%）。
- 以下增益效果现已加入冷却管理器追踪：火上浇油、热力四射、灼烧、碎玉闪电和奥古斯特祝福。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我会被一击秒杀？
A：很有可能是[[spell:322120]]已经用完了，导致你无法正常使用[[spell:115069]]。

:::

:::

---

### 致谢

作者：**Skövte**

审阅者： **深**

---

:::changelog 更新记录
**2026-08-11** 更新至12.1版本

**2026-06-16** 更新至12.0.7版本

**2026-04-21** 更新至12.0.5版本

**2026-02-26** 更新至12.0.1版本

**2026-01-20** 更新至至暗之夜 12.0版本

**2025-12-02** 更新至11.2.7版本

**2025-10-07** 更新至11.2.5版本

**2025-08-05** 更新至11.2版本



:::
