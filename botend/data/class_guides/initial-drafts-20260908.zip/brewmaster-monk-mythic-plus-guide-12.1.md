欢迎阅读**酒仙 武僧** 大秘境 指南，适用于《魔兽世界》12.1版本！本指南涵盖了你需要了解的关于你角色的一切！你是刚起步、从80级开始练级的吗？请查看练级指南！

## 概述

:::columns
:::column
:::rating 大秘境
**单体** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 5/5 · 优秀

生存能力 · 4/5 · 强

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **酒仙 武僧** 大秘境 最佳装备
```json
{
  "source_code": "JgfAYyQA3_PAB8JJEIIEFAw74OgDtOQOCchNYFwAmQQApfBBAERAA4QrDUwFYxYNYFQAKU9ACgQAAUTuDIoAOFQAiSCBB8ADJk7A5EwDUUT1DAICBEgMF4BAeGgH8UAAhu7A5IAWBE8FEEASuJQAwAwDN8DCE5mAuADAYAKJEAACBAQBLBYeWPggIEAA1j7AO06A3WzSBEQNtOghIEAAfA8A1j7AhZdFYQwXf0gNMgVAB4VEMAhTBEA2XUAGFoIP3eBBCARAA0TuDIoAWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240910]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240910]] · [[item:240910]] |
| 肩部 | [[item:251146]] | [[item:244021]] |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:251189]] | [[item:240910]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159304]] | [[item:243983]] |
| 腕部 | [[item:159300]] | [[item:240910]] |
| 手部 | [[item:271520]] |  |
| 戒指一 | [[item:251513]] | [[item:240910]] · [[item:243957]] |
| 戒指二 | [[item:240949]] | [[item:240910]] · [[item:245791]] · [[item:243957]] · [[item:251489]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270174]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**酒仙 武僧**，你可以使用再来一杯，它使你饮用的下一个酒类有20%的几率给你一个空酒桶，该空酒桶会在你下次使用[[spell:121253]]时被自动消耗，并造成额外的物理伤害。

**等级2** 使你的[[spell:121253]]冷却时间重置，并且你的下一个[[spell:121253]]消耗的能量减少50%。而在**等级3**下，饮用[[spell:115203]]或[[spell:322507]]会给你一个新鲜的酒桶，消耗后为你提供[[spell:1265140]]增益。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-brewmaster-mxr.webp>)

再来一杯

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[spell:400629]]
    
    - 以前，每次你受到伤害时都有几率生成一个疗伤珠，现在则是每次你使用[[spell:109080]]时都有几率生成一个疗伤珠。
  
  
  
  - [[spell:196736]]
    
    - 这个天赋被改动了，现在你的下一个[[spell:109080]]只会强化你的下一个[[spell:121253]]或[[spell:100780]]。
  - [[spell:1262659]]
    
    - 使你的火焰和自然伤害为你恢复其伤害量50%的生命值。
  - [[spell:1263245]]
    
    - 在[[spell:132578]]期间为我们提供额外的5%精通。
  - [[spell:1262017]]
    
    - 在施放[[spell:325153]]后，你的下2次[[spell:121253]]会被强化，并在敌人周围召唤一股火焰旋风。
  - [[spell:1262329]]
    
    - 使我们可以在使用[[spell:325153]]后重新激活它，向附近的敌人额外投掷5个酒桶，并将我们所有酒的冷却时间缩短3秒。
  - [[spell:383707]]
    
    - 除了为你的[[spell:121253]]额外增加一次充能外，它现在还使[[spell:121253]]的射程额外增加10码，这使得它非常适合从更远的地方开怪。
  - [[spell:1263345]]
    
    - 饮用任意一种你的酒会为你提供额外的移动速度和自动攻击速度。

- **职业天赋树**
  
  - [[spell:1266733]]
    
    - [[spell:119381]]现在会对每个被击中的敌人施加[[spell:116095]]，持续5秒。
  - [[spell:1243287]]
    
    - 现在不再是一个主动按钮，而是内置到你的[[spell:115203]]中，当你按下[[spell:115203]]时，可以将魔法负面效果转移回你的目标身上。
  - [[spell:1272452]]
    
    - 使你的下一个[[spell:115080]]按其所造成伤害的50%为你进行治疗。

- **已移除**
  
  - [[spell:122278]] 
    
    - 这导致我们面对坦克型巨型重击时缺少了主要的防御冷却技能。
  - [[spell:310454]]
    
    - [[spell:310454]]的移除使我们不再拥有进攻性冷却技能。
  - [[spell:389577]]

## 英雄天赋

- 在伤害输出方面，[[talent:125028]] 和 [[talent:125027]] 两者彼此之间非常有竞争力。
- [[talent:125028]] 会通过 [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 影响你的操作方式，而 [[talent:125027]] 则几乎完全是被动生效的。
- 在伤害和生存能力方面，[[talent:125027]] 总体上更适合推进大秘境，但 [[talent:125028]] 的伤害曲线更加平滑，而 [[talent:125028]] 由于 [[spell:450529@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 的存在，在集火优先目标伤害方面更胜一筹。
- 你可以在下方的天赋部分找到两套针对大秘境的推荐天赋配装，一套对应 [[talent:125027]]，另一套对应 [[talent:125028]]，两套在低层大米和高层M+推进中都是可行的。

### [[talent:125027]]

- [[talent:125069]]
  
  - 你的自动攻击有几率生成 [[spell:451021]]。
  
  
  
  - 施放 [[spell:121253]] 将释放所有的 [[talent:125069]]。
- [[spell:450989@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 使 [[spell:132578]] 的冷却时间缩短25秒。
- [[spell:1272821@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]]
  
  - 在 [[spell:132578]] 期间，你的下一次 [[spell:115181]] 将释放3倍的 [[talent:125069]]。

- [[talent:125027]] 选择节点的选取为：
  
  - [[talent:125068]]
  - [[spell:1272844]]
  
  
  
  - [[talent:125064]]
    
    - 这个被动效果没有冷却时间，随时都有可能触发。

在12.0前置补丁中，你可以解锁新的英雄天赋栏，但可用的点数有限。

- [[spell:1262603@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]] 
  
  - 每当你使用 [[spell:132578]] 时，你都会立即获得10层 [[spell:450615]]。

### [[talent:125028]]

- [[spell:450508@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 伤害和有效治疗会被储存为活力。
  - 在 [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 期间你不会产生任何活力。
  - 重要：过量治疗不计入有效治疗。
- [[talent:125035]] 
  
  - 关键节点，确保永远不浪费任何活力。
- [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 拥有2层充能的 [[spell:1241059]] 让你可以轻松地保留/延迟使用，以优化伤害和生存能力。
- [[spell:451036@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 额外的护盾和 [[spell:115069]] 的缩减在防御方面非常强力。
- [[spell:450529@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - 当你处于 [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] 的效果影响下时，敌人受到的伤害提高20%。

在12.0前置补丁中，你可以解锁新的英雄天赋栏，但可用的点数有限。

- [[spell:1239442]] 
  
  - 每当你施放 [[spell:1241059]] 时，你接下来的2次 [[spell:100780]] 会被强化，并会触发一次 [[spell:1239442]]。
- [[spell:1271048]]
  
  - 每次 [[spell:121253]] 之后，你的下一个 [[spell:100780]] 将触发一次 [[spell:1239442]]。

## 天赋

### [[talent:125028]] 构建

:::talents **酒仙 武僧** 大秘境
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若需更详细的解析，请查看下方的循环和 **深度解析** 章节。

##### 专精树

- [[talent:124864]]
  
  - 酒醒入定使[[spell:115069]]的效果翻倍。
- [[spell:400629]]
  
  - 使你的[[spell:109080]]有几率生成[[spell:115464]]。
- [[talent:124857]]
  
  - 根据你的醉拳被动提供精通，这也是精通在属性优先级中排名不高的原因之一。
- [[talent:124853]]
  
  - 使[[spell:205523]]可以顺劈，大幅提升其价值。

##### 职业树

- [[talent:124950]]
  
  - [[spell:115546]]现在会使目标的移动速度提高50%。

### [[talent:125027]] 构建

:::talents **酒仙 武僧** 大秘境
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDGz2MPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAA2mlplZbmlBAY2mlmZmZjhFAmZYaMAAgBA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDGz2MPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAA2mlplZbmlBAY2mlmZmZjhFAmZYaMAAgBA"
}
```
:::

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若需更详细的解析，请查看下方的循环和 **深度解析** 章节。

##### 专精树

- [[talent:124864]]
  
  - 酒醒入定 使 [[spell:115069]] 的效果翻倍。
- [[spell:400629]]
  
  - 使你的 [[spell:109080]] 有几率生成 [[spell:115464]]。
- [[spell:212935]]
  
  - 务必在施放 [[spell:121253]] 之前让 [[spell:115181]] 处于冷却中，以获得该天赋带来的冷却重置效果。
- [[talent:124857]]
  
  - 这会为你提供 精通 基于你的醉酿，这也是 精通 在属性优先级中排名不那么靠前的原因之一。
- [[spell:387230]]
  
  - 让你更频繁地拥有 [[spell:205523]]，从而使 [[spell:196736]] 的覆盖率更高，进而可用于打出更多单体伤害，或在 范围伤害 情况下进一步缩短你酿类技能的冷却时间。

##### 职业树

- [[talent:124950]]
  
  - [[spell:115546]]现在会使目标的移动速度提高50%。

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:115181]]会点燃你的下一个[[spell:121253]]，使其在命中时爆炸，对主要目标造成额外的烈焰风暴伤害，对额外目标造成的伤害降低。
- **4件套：** 被点燃的[[spell:121253]]会使被击中的敌人受到你物理技能的伤害提高8%，并在地面留下一片火焰，每秒造成火焰伤害，持续5秒。

### 起手爆发

- 我们希望借助[[spell:121253]]和[[spell:205523]]获得可观的[[spell:322120]]，同时不断铺开我们的减益效果。

:::rotation **酒仙武僧** 大秘境  范围伤害起手
```json
{
  "source_code": "IUETIIUpZHAAAAQABwprDAAAAAgQtHcAQwAACBbiJgABqyYCIkAKQAgQhYPBFgCKwmYAAAAAAIUpZHA"
}
```
1. [[spell:121253]]  [[item:241308]]
2. [[spell:115181]]
3. [[spell:100784]]
4. [[spell:101546]]
5. [[spell:121253]]
6. [[spell:325153]]
7. [[spell:100784]]
8. [[spell:121253]]
:::

:::rotation **酒仙武僧** 大秘境单体起手
```json
{
  "source_code": "IUETIIUpZHAAAAQABwprDAAAAAgQwmYAQgAACxaDIQQ7BnAEJgCEAIUI2TgPoAA"
}
```
1. [[spell:121253]]  [[item:241308]]
2. [[spell:100784]]
3. [[spell:100780]]
4. [[spell:115181]]
5. [[spell:121253]]
6. [[spell:325153]]
7. [[spell:100784]]
8. [[spell:100780]]
:::

### 优先级列表

请务必牢记这份清单，除非某些首领或场景需要你保留这里列出的一些技能

1. 冷却好了就施放[[spell:121253]]。
2. 施放[[spell:115181]]。
3. 冷却好了就施放[[spell:100784]]。
4. 在8个及以上目标时施放[[spell:100780]]或[[spell:101546]]。
5. 施放[[spell:325153]]。
6. 如果点了天赋，就施放[[spell:123986]]。
7. 当这波小怪即将拉完时，务必尽可能使用[[spell:322109]]。

### 防御技能冷却

- [[spell:1241059]]
  
  - 在其持续期间为你提供一个较小的吸收护盾和30%的伤害减免。
  
  
  
  - 在拥有[[talent:125028]]天赋[[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]时拥有2层充能。
- [[spell:243435]]
  
  - 冷却时间长达4分钟，但可以通过[[spell:121253]]来缩短。
  - 提供20%最大生命值和20%伤害减免，这使它成为你最全面的**防御**技能。
  - 主要用于应对重型伤害，并尽早使用，好让冷却缩减开始生效，尽快转好。

### 进攻冷却技能

- [[talent:125001]]
  
  - 使被击中的目标在3秒内的近战攻击100%未命中你。
  - 投掷一桶酒，以额外的火焰伤害放大你的所有伤害。配合范围伤害的[[spell:101546]]使用。
- [[spell:322109]]
  
  - 施放时最多可消除200%的[[spell:115069]]。[[spell:325095]]无论是伤害还是防御价值都非常出色，冷却好了就施放。
  - 它还能帮助你在拉怪快结束时收掉危险的小怪。

## 深度解析

### 醉拳

**酒仙武僧** 依靠其[[spell:115069]]机制被动地降低所受伤害，这是其伤害减免的核心组成部分。

#### 醉拳阶段

你的[[spell:115069]]分为3个不同的阶段。

- [[spell:124275]]
  
  - [[spell:115069]] 总伤害量等于你最大生命值的 1-29%。
- [[spell:124274]]
  
  - [[spell:115069]] 总伤害量等于你最大生命值的 30-59%。
- [[spell:124273]]
  
  - [[spell:115069]] 总伤害量等于你最大生命值的 60% 或以上。

使用 [[spell:119582]] 可以净化 **50%** 的 [[spell:115069]] 伤害，从而缩短你的 [[spell:115069]] 阶段，这也是你的主要减伤手段。[[spell:119582]] 最好在刚受到大量伤害后立即使用，将 [[spell:115069]] 伤害减半。

### 管理天神灌注与活血酒

在 **酒仙 武僧** 中，灵活运用 [[spell:1241059]] 与 [[spell:119582]] 是你生存能力的核心任务和玩法。

- 如上所述，[[spell:119582]] 是你净化 [[spell:115069]] 的主要手段。
  
  - 需要注意的是：[[spell:119582]] **不受公共冷却时间影响**，因此可以在使用其他任何技能的同时按下它。
- [[spell:1241059]] 则是你的防御技能。

以下是一些关于使用它们时需要牢记的技巧和要点：

- 在分配 [[spell:119582]] 使用层数时，有几条规则需要牢记：
  
  - 避免让两层充能同时就绪，否则你会浪费技能带来的防御价值和冷却缩减价值。
  
  
  
  - 确保始终通过 [[spell:121253]] 获得完整的冷却缩减。
- 关于如何最高效地使用 [[spell:119582]] 的通用原则：
  
  - 在承受一次重击之后使用，这样可以在 [[spell:115069]] 刚产生且处于最高点时净化掉最多的伤害。
  - 另一种选择是在承受重击后几乎完全净化掉所有危险的 [[spell:115069]]，做法是先积累大量酒醉状态，然后连续使用两层充能。
- 总体而言，只要遵循自然的游戏节奏，你就应该频繁使用它，以避免 [[spell:124273]] 并防止充能溢出浪费。
- 你可能犯的最大错误就是一冷却就用掉所有充能，结果在 [[spell:115069]] 变得危险时却毫无充能可用。
- [[spell:1241059]] 的使用则更简单直接：
  
  - 它是你最常用的主动防御技能，应尽可能用在大多数机制上。
  - 尽量不要把它扣太久，因为这样会浪费冷却缩减，从长远来看会导致承受更多伤害。
  - 不过在某些情况下，你必须把它留给危险的坦克机制，请牢记这一点。

### 酒醒入定

**酒仙 武僧**需要 [[spell:115069]] 才能在各种机制下存活，而让这一切在很大程度上成为可能的正是 [[talent:124864]]。

- [[talent:124864]] 通过按下 [[spell:121253]]、[[spell:101546]] 和 [[spell:205523]] 被动产生。
- 只要你不停止按键，[[talent:124864]] 就永远不会掉，你无需对此付出任何注意力。但在某些情况下该增益可能会耗尽：
  
  - 当机制迫使你离开攻击范围而你无法接近首领时，你可能会导致它掉落，从而承受更多伤害，所以要小心！
  - 用 [[spell:121253]] 开怪并快速冲进去可能会导致死亡。由于 [[talent:124864]] 是由 [[spell:121253]] 的伤害而非施法触发的，如果你的速度比酒桶飞行还快，你可能会在 [[talent:124864]] 尚未生效时被打中而死。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

在下面的地下城部分中，我们只展示使用[[talent:125028]]的构筑，但你也可以放心使用在[天赋](<https://maxroll.gg/wow/class-guides/brewmaster-monk-mythic-plus-guide#talents-header>)部分中找到的推荐[[talent:125027]]构筑。两种构筑在所有地下城中都完全可行。

### 毒牙祭坛

:::talents **酒仙 武僧** 大秘境 毒牙祭坛
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 拉维

- 房间中散布着3个腐肉堆，确保在boss能量降到0%之前将他拉到其中一个没有发红光的腐肉堆旁，以便他[[spell:1296216]]在其中。
- 在[[spell:1296216]]期间，注意地面上的[[spell:1307703]]，如有需要请进行吸收。

##### 扭缠盘蛇

- boss会对你施放[[spell:1298949]]，造成物理伤害并将你轻微击退。
- 打断[[spell:1310358]]。
- 在[[spell:1299053]]期间，尽可能快且远地远离boss。

##### 祖尔加

- 每当boss施放[[spell:1300872]]时，务必站在他与[[spell:1300894]]之间进行吸收。
- 躲避[[spell:1283832]]所产生的任何斧头。
- [[spell:1301350]]是一个0.5秒的快速施法，造成物理伤害，是本场战斗的坦克重击技能。
- 当队友被[[spell:1301413]]锁定时，移动到boss与被锁定玩家之间的直线上，这会减少你的队友所受到的伤害。

#### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1294557]] - 原始毒蛇
  - [[spell:1307567]] - 乌拉特克神选者

- 额外注意这些施法：
  
  - [[spell:1306911]] - 仪式首领
  - [[spell:1294845]] - 振响的扭缠蛇
  - [[spell:1294934]] - 晋升之蛇

### 纳洛拉克的洞穴

:::talents **酒仙 武僧** 大秘境 纳洛拉克的洞穴
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 囤宝狂人

- 每当boss施放[[spell:1234233]]时，他会在地面上召唤[[spell:1234740]]，务必帮助你的队伍进行吸收。

##### 寒冬哨卫

- 在boss施放[[spell:1235783]]之后，将他拉到一个被召唤的小怪身上，并打断[[spell:1235829]]。

##### 纳洛拉克

- 当首领开始施放 [[spell:1243569]] 时，确保你站在 祖尔加拉 提供的 [[spell:1243856]] 中。施法结束后，首领会立即接一个 [[spell:1297797]]，在他面前生成一个大圈。作为坦克，走进圈中吸收这一击。
- 在 [[spell:1243002]] 期间，跑向任何试图接近 祖尔加拉 的 纳洛拉克的回响，用你的角色触碰它以阻止其靠近她。

#### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1297696]] - 地语看护者
  - [[spell:1309919]] - 酷寒重殴者
  - [[spell:263607]] - 雷缚秘法师
  - [[spell:9532]] - 神灵代言人纳尼亚

- 请格外注意以下施法：
  
  - [[spell:1238687]] - 饥渴之灵

### 密谋小径

:::talents **酒仙 武僧** 大秘境 密谋小径
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 凯斯媞亚·魔力之心

- 咬咬 会对施放一个正面锥形 [[spell:1253811]]，请务必不要把它的方向对准你的队友；在引导/施法结束前，你也可以向侧面跑开躲避。
- 凯斯媞亚 会不时施放多个 [[spell:1264095]]，它们会施放 [[spell:1264106]]，你可以通过打断或眩晕来取消它们的施法。

##### 赞恩·刃悲

- 首领会对你施放 [[spell:1222795]]，造成物理伤害并在你身上留下一个持续伤害 [[spell:474515]]。
- 当你被 [[spell:474545]] 点名时，尝试躲在房间里的木桶后面。

##### 歼灭者萨祖克斯

- [[spell:1214781]] 是这场战斗中主要的坦克重击机制，它是一个正面锥形技能，不要把它对准你的小队，它会给你留下一层使你受到的治疗效果降低80%、持续8秒的减益。
- 在 [[spell:1214637]] 之后，尽量在首领的斧头附近拉住他。
- 在 [[spell:1223533]] 期间，尽量沿着房间边缘风筝他，以减少 [[spell:474231]] 的扩散。

##### 利希尔·烬怒

- 首领将使用[[spell:1220899]]，你需要在这场战斗的全程中风筝这只地狱火。
- 尽可能打断[[spell:474375]]。
- 每当[[spell:474408]]出现时，就要抓住它的仇恨。
- 当首领召唤[[spell:1214675]]时，等待它完成[[spell:1217345]]的施法后再进入传送门。

#### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1216570]] - 凶邪的法师
  - [[spell:1201554]] - 诱惑的萨亚德
  - [[spell:1214922]] - 愤怒卫士掠夺者
  - [[spell:1214980]] - 邪能祈求者

- 请格外注意以下施法：
  
  - [[spell:1216529]] - 受贿的队长

### 夺目谷

:::talents **酒仙 武僧** 大秘境 夺目谷
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 光明众花

- 务必对所有三个首领保持仇恨，并尽可能将它们拉在一起，以便进行顺劈输出并提高伤害效率，因为它们共享同一个生命值池。
- 梅提克 会对你施放 [[spell:1234753]]，这是战斗中坦克伤害的主要来源。
- 科兹齐特 会施放 [[spell:1235616]]，尽可能打断它。
- 科兹齐特 还会施放 [[spell:1235564]]，你需要站在三朵光蕾之一中来分摊伤害。

##### 圣光猎手伊库兹

- 每次首领施放 [[spell:1236746]] 时，务必确保自己不被击退到地上的任何树根中。如果你被击退远离团队，请尽快归位，因为该技能发生 4 秒后所有人都会被定身。你需要与团队集合在一起，以便尽快顺劈清理树根。

##### 护光者鲁伊亚

- 这个首领有3个不同的阶段，它总是以枭兽阶段开始。
- 在这个阶段你只需要打断[[spell:1239821]]并躲避由[[spell:1239824]]创造的[[spell:1239830]]。
- 在下一阶段，熊形态 由于 [[spell:1272265]]，他的近战攻击变得更加危险。此外，如果你被 [[spell:1240210]] 选为目标，请确保不要过多移动，这样你和你的队友会更容易躲避。
- 最后一个阶段在40%时开始，此时首领进入哈拉尼尔形态并引导[[spell:1241067]]，快速连发施放它的所有技能。

##### 兹欧凯特

- 每次首领施放 [[spell:1246372]] 时，它会在自己脚下召唤小怪，务必尽快拉住这些小怪的仇恨。
- [[spell:1246858]] 之后会有法球飞向首领，去吸收这些法球，不要让任何一颗碰到首领。
- 此外，首领在战斗中还会使用 [[spell:1247685]] 作为坦克重击技能，造成魔法伤害，将你击退，并给你留下一个流血效果，每秒造成物理伤害，持续 10 秒。
- 当小怪死亡后，你需要调整首领的站位，使其用以你为目标的 [[spell:1246607]] 技能命中所有小怪。当小怪被命中时，它们会被彻底移出战斗；如果没有被命中，下次首领施放 [[spell:1246372]] 时，它们会与新召唤的小怪一起复活。

#### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:1301834]] - 光耀播法者
  - [[spell:1238294]] - 光羽瓣翼鸟

- 请格外注意以下施法：
  
  - [[spell:1237855]] - 翠绿林地守护者

### 虚空之痕竞技场

:::talents **酒仙 武僧** 大秘境 虚空之痕竞技场
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 塔兹拉尔

- 每当首领施放 [[spell:1296889]] 时，务必确保你的 [[spell:1222098]] 不要与其他人的重叠。
- 它还会对你施放 [[spell:1297017]]，造成大量魔法伤害并将你击退。
- 每次 [[spell:1300259]] 之后，务必躲避法球。

##### 阿特洛苏斯

- [[spell:1222642]]是这场战斗中的坦克重击机制，它造成魔法伤害，并留下一个持续10秒的减益效果，使你受到更多魔法伤害。
- 每当首领施放[[spell:1262497]]时，它会召唤一个剧毒蠕行者，它会锁定你，尽量将这个剧毒蠕行者与首领一起风筝，以最大化顺劈输出。

##### 煞戎努斯

- 首领会对着你施放 [[spell:1311923]]，这是一个持续5秒的施法，此时尽量不要过多移动，以便队友能够躲避。
- 偶尔首领会用 [[spell:1222755]] 点名你的一名队友。作为坦克，你的职责是站在首领与被点名玩家之间，在弹射物到达队友之前将其拦截。

#### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1299938]] - 虚触法师
  - [[spell:1298899]] - 被统御的斗士
  - [[spell:1249621]] - 暴怒的三叶虫
  - [[spell:1233398]] - 千噬兽尖啸者

- 请格外注意这些施法：
  
  - [[spell:1300243]] - 贪噬残虐者

### 诸王之眠

:::talents **酒仙 武僧** 大秘境诸王之眠
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 黄金风蛇

- 首领会用 [[spell:265910]] 打你，造成物理伤害。
- 在首领施放 [[spell:265923]] 之后，如有需要务必风筝它，以免小怪接近它。

##### 殓尸者姆沁巴

- 每当首领施放其主要技能 [[spell:267702]] 时，注意房间两侧的墓穴，点击正在摇晃的那个，因为你的队友之一会被关在里面。

##### 部族议会

- 征服者阿卡阿里 会对我们使用 [[spell:266237]]，将你击退，并使你随后10秒内受到的物理伤害提高200%。
- 帮助队友分担 [[spell:266939]]。
- 在与 智者扎纳扎尔 的战斗中打断 [[spell:267273]]。
- 在他施放 [[spell:267060]] 之后，试着把他拉到爆炸图腾上面。

##### 始皇达萨

- 由于 [[spell:268586]] 和 [[spell:1303267]]，这个首领会对坦克造成大量伤害，所以务必使用你的防御技能。
- 在整个战斗中尽可能躲开 [[spell:1302945]]。
- 当 莱班 激活时，务必尽可能打断 [[spell:269369]]。
- 提扎拉 在激活时也会开始对你施放 [[spell:1303488]]，为这场战斗又增加了一层坦克伤害。

#### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1294815]] - 复活的妖术师
  - [[spell:270920]] - 瓦西女王
  - [[spell:270901]] - 姆巴拉侍臣
  - [[spell:270492]] - 幽灵妖术 牧师

- 请格外注意以下施法：
  
  - [[spell:1297918]] - 阿阿库尔王
  - [[spell:1302028]] - 幽灵蛮兵
  - [[spell:270514]] - 幽灵蛮兵
  - [[spell:1309385]] - 祖尔的暗影

### 红玉新生法池

:::talents **酒仙 武僧** 大秘境 红玉新生法池
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 梅莉杜莎·寒妆

- 首领会对着你施放[[spell:372808]]，这是一个可打断的施法，因此务必在冷却时就打断它；如果你或队友无法打断，请开启减伤技能。
- 首领偶尔还会施放[[spell:396044]]，施法结束后，将首领带离地面上的圆圈。
- 当首领生命值降至66%和33%时会施放[[spell:373037]]，务必拉住刷新的小怪的仇恨。

##### 柯姬雅·焰蹄

- 该首领的主要坦克机制是[[spell:372858]]，这是一个持续3秒的施法。
- 务必始终将首领拉在[[spell:372863]]所产生的炎缚火焰风暴旁边进行坦克。

##### 基拉卡与厄克哈特·风脉

- 首领会通过[[spell:381512]]对你施加一个负面效果，使你受到的下一次[[spell:381512]]伤害提高，因此请提前与你的治疗沟通好，每次你被此机制命中时他都必须为你驱散。
- 每当巨龙基拉卡落地后，请离开[[spell:381525]]。

#### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:372743]] - 闪霜织寒者
  - [[spell:384197]] - 拜荒织烬者
  - [[spell:392576]] - 暴风引导者

- 需要格外注意以下施法：
  
  - [[spell:372730]] - 原始主宰
  - [[spell:372047]] - 亵渎者德拉加尔
  - [[spell:392394]] - 烈焰之咽
  - [[spell:392395]] - 雷霆之颅

### 塞塔里斯神庙

:::talents **酒仙 武僧** 大秘境 塞塔里斯神庙
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### 首领攻略技巧

##### 阿德里斯和阿斯匹克斯

- 每当阿斯匹克斯施放[[spell:1310712]]时，确保不要与队友站在一起。
- 阿德里斯会用[[spell:1288049]]聚焦你的一名队友，尽量帮忙分担这个技能，以分摊伤害并减轻对被点名队友的整体影响。
- 它还会施放[[spell:1288428]]，使其在8秒内造成更多近战伤害，如有必要请使用你的防御技能。

##### 米利克萨

- 首领会周期性地施放[[spell:1290797]]，这是一个坦克重击技能，命中时造成物理伤害，并留下一个持续7秒、每秒跳一次自然伤害的持续伤害效果。
- 在[[spell:264206]]期间，务必迅速对所有被召唤的小怪建立仇恨。

##### 加瓦兹特

- 在这场战斗中，你唯一要做的就是每次[[spell:1309525]]施放后移动首领的位置，因为它会在首领脚下召唤一个[[spell:1291815]]。

##### 塞塔里斯的化身

- 务必抢到堕落守护者的仇恨，它们偶尔会对你施放[[spell:1300803]]。此外，你也可以把它拉到精华污染者上面。

#### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:1293307]] - 无信征服者
  - [[spell:9532]] - 灌注能量的唤雷者
  - [[spell:13729]] - 扭曲的妖术师

- 请格外注意以下施法：
  
  - [[spell:1291468]] - 沙怒石拳战士
  - [[spell:1308546]] - 宝珠守望者

### 词缀

词缀系统在进入地心之战第一赛季时进行了重做，退役了大部分词缀，同时引入了新的有利有弊型词缀，并更改了这些词缀出现的钥石等级。

- +2词缀
  
  - 林多尔米的指引
- +5 词缀——每周轮换
  
  - 萨拉塔斯的交易：升腾
  - 萨拉塔斯的交易：虚空之缚
  
  
  
  - 萨拉塔斯的交易：吞噬
  - 萨拉塔斯的交易：脉冲星
- +6词缀
  
  - 移除林多尔米的指引。
- +7 词缀——每周交替出现
  
  - 残暴
  - 强韧
- +10 词缀 *——两个词缀同时存在。*
  
  - 残暴
  - 强韧
- +12词缀
  
  - 萨拉塔斯的诡计 *——替换+5词缀*

以下是作为**酒仙 武僧**应对不同大秘境 词缀的一些实用技巧。

- 萨拉塔斯的交易：升腾者
  
  - 当法球出现时，使用 [[spell:116844]] 尽可能多地打断它们。
  - 需要时随时使用 [[spell:119381]]。
- 萨拉塔斯的交易：虚空缚誓
  
  - 的 **虚空大使** 会跟随你，让它保持在近身范围内以进行顺劈，并在它存在时以它为目标。
  - 使用 [[spell:115080]] 对 造成大量伤害 **虚空大使**.
- 萨拉塔斯的交易：吞噬
  
  - 每当 [[talent:124867]] 施加在你自己身上时，对你自己使用它。

## 属性优先级

了解你作为**酒仙 武僧**在地下城中获得最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问**[属性与数值](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **酒仙 武僧** 大秘境 中的属性优先级
```json
{
  "source_code": "HoAJFMAKgEDJBIQABA"
}
```
**敏捷 ＞ 全能 ＝ 暴击 ＞ 精通 ＞ 急速**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 能够有效降低"**范围伤害**"技能所造成的伤害的优秀属性。
- **吸血** - 通过造成伤害来提供额外治疗。
- **加速** - 一种小众的第三属性，但在某些情况下非常有用，过去也曾被证明其实用价值。它能让应对某些机制变得轻松许多。

总体而言，**吸血**对坦克来说非常强力，尤其是在范围伤害环境中，它可能是你所能拥有的最好属性。  
**闪避**很好用，但大多数时候坦克并不难在典型的范围伤害技能下存活。

## 装备

### 总体最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | 将 [[item:271875@BARAAwQACKwF2gVA]]  <br> 转换为 [[item:271519@DCRBAwQAvj74QrTOCchNYFwAmQA]] | 乌拉特克的催化者 |
| 颈部 | [[item:268265@BERAAwQAO064QrTOCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:251146@DgQAAwQA1k7IoAOF]] | 纳洛拉克的洞穴 |
| 披风 | [[item:268248@BgQAAwQACKgTBA]] | 盘魂者内克扎莉 |
| 胸部 | [[item:271522@DgQAAwQAJk7kjAOF]] | 恶性瓦辛克 |
| 手腕 | [[item:159300@BiQAAwQAO06IoAOF]] | 诸王之眠 |
| 手套 | [[item:271520@BgQAAwQA5IgTBA]] | 被埋葬的哨兵 |
| 腰带 | [[item:251189@BiQAAwQAO06IoAOF]] | 夺目谷 |
| 腿部 | 将 [[item:268225@BgQAAwQA5IAWBA]]  <br> 转换为 [[item:271518@DgQBAwQAhu7kjAYFQwXQ]] | 盘卷祭坛的催化者 |
| 靴子 | [[item:159304@DgQAAwQAPk7IoAOF]] | 诸王之眠 |
| 戒指 1 | [[item:251513@DiQAAwQA1j74Qrzt1sUA]] | 制造业 |
| 戒指 2 | [[item:240949@HiQAAwQAfA8UPuTYWPO06cbNLFA]] | 制造业 |
| 饰品 1 | [[item:270175@BgQAAwQA5IAWBA]] | 乌拉特克 |
| 饰品 2 | [[item:270174@BgQAAwQA5IgTBA]] | 斯索拉克 |
| 武器 | [[item:268215@DARAAwQA9k7IoAWYDWB]] | 乌拉特克 |

### 可刷取的替代选择

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 位置 |
| --- | --- | --- |
| 头部 | [[item:193751@BgQAAwQACKQQBA]] | 红玉新生法池 |
| 颈部 | [[item:251234@BgQAAwQACKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:251146@BgQAAwQACKQQBA]] | 纳洛拉克的洞穴 |
| 披风 | [[item:159288@BgQAAwQACKQQBA]] | 诸王之眠 |
| 胸部 | [[item:251226@BgQAAwQACKQQBA]] | 虚空之痕竞技场 |
| 手腕 | [[item:159300@BgQAAwQACKQQBA]] | 诸王之眠 |
| 手套 | [[item:193758@BgQAAwQACKQQBA]] | 红玉新生法池 |
| 腰带 | [[item:251189@BgQAAwQACKQQBA]] | 夺目谷 |
| 腿部 | [[item:251198@BgQAAwQACKQQBA]] | 夺目谷 |
| 脚部 | [[item:159304@BgQAAwQACKQQBA]] | 诸王之眠 |
| 戒指1 | [[item:251148@BgQAAwQACKQQBA]] | 纳洛拉克的洞穴 |
| 戒指2 | [[item:251136@BgQAAwQACKQQBA]] | 密谋小径 |
| 饰品 1 | [[item:250244@BgQAAwQACKQQBA]] | 纳洛拉克的洞穴 |
| 饰品 2 | [[item:250228@BgQAAwQACKQQBA]] | 密谋小径 |
| 武器 | [[item:251192@BgQAAwQACKQQBA]] | 夺目谷 |

### 饰品

以下是从地下城、团队副本和地下堡可获得的毕业饰品排名。请注意，根据大秘境地下城的不同，某些饰品会优于其他饰品。此外，为输出专精设计的饰品会被削弱33%，但依然能提供比坦克专属饰品更高的伤害。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgQAAwQA5IAWBA]]  <br>[[item:270174@BgQAAwQA5IgTBA]] |
| **A级** | [[item:270160@BgQAAwQA5IgTBA]]  <br>[[item:270173@BgQAAwQACKAWBA]]  <br>[[item:250244@BgQAAwQACKgTBA]]  <br>[[item:250215@BgQAAwQACKgTBA]]  <br>[[item:250228@BgQAAwQACKgTBA]] |
| **B级** | [[item:270164@BgQAAwQA5IgTBA]]  <br>[[item:250243@BgQAAwQACKgTBA]]  <br>[[item:159617@BgQAAwQACKgTBA]]  <br>[[item:159618@BgQAAwQACKgTBA]] |
| **C级** | [[item:273796@BgQAAwQACKgTBA]]  <br>[[item:250259@BgQAAwQACKgTBA]]  <br>[[item:250214@BgQAAwQACKgTBA]]  <br>[[item:193757@BgQAAwQACKgTBA]] |
| **垃圾级** | [[item:270165@BgQAAwQA5IgTBA]]  <br>[[item:250245@BgQAAwQACKgTBA]]  <br>[[item:250225@BgQAAwQACKgTBA]] |

### 美化饰品

- [[item:251513@DiQAAwQA1j74Qrzt1sUA]]
  
  - 不错的被动次级属性加成。
- [[item:251489@BAAAAwQA]]
  
  - 使你所有宝石提供的属性翻倍，并且可以镶嵌在任意装备上。

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药水（瓶）**
  
  - [[item:241326]]
- **食物**
  
  - [[item:266996]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器磨刀石**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **插槽**
  
  - [[item:240983]] *-- 唯一，只能使用一次。*
  - [[item:240914]]
  - [[item:240910]]

### 附魔

:::columns
:::column
| 头部 | [[item:243949@DAAAAwQAZbAB]]  <br>[[item:275707@BAAAAwQA]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 手腕 | [[item:275707@BAAAAwQA]] |
| 腰带 | [[item:275707@BAAAAwQA]] |
| 腿部 | [[item:244641@BAAAAwQA]] |
| 脚部 | [[item:243983@BAAAAwQA]] |
| 戒指1 | [[item:244017@BAAAAwQA]] |
| 戒指2 | [[item:244017@BAAAAwQA]] |
| 武器 | [[item:244029@BAAAAwQA]] |

:::

:::column
:::gear **酒仙 武僧** 大秘境
```json
{
  "source_code": "IQFZMEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *你从宏伟宝库商人处购买 ‍[[item:275707@BAAAAwQA]] 来为你的头盔、手腕和腰带添加插槽。*

## 种族

为了将一个 **酒仙 武僧** 发挥到极致，在 大秘境 地下城中，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你风格的种族也同样可行。

- [[spell:65116]] -- 矮人
  
  - 非常有价值，因为你可以驱散自己或移除危险的流血效果。
  - 除此之外，使用石像形态还会给你提供10%的物理减伤，在坦克时可以用作一个小型额外的8秒个人减伤。
  - 使用场景示例：
    
    - **基拉卡与厄克哈特·风脉 (红玉新生法池) - [[spell:381512]]**
    - **赞恩·刃悲 (密谋小径) - [[spell:1222795]]**
    - **兹欧凯特 (夺目谷) - [[spell:1247685]]**
- [[spell:58984]] -- 暗夜精灵
  
  - 在大秘境中做任何类型的跳怪时都非常有用
  - 直接跑过几乎任何怪物，然后施放[[spell:58984]]让它们重置。如果你在[[spell:58984]]之前拉开足够的距离，即使对拥有潜行侦测能力的怪物也有效
- [[spell:69070]] —— 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到你的角色落地。
- [[spell:25046]] -- 鲜血精灵
  
  - 强力的种族技能，可以驱散或净化敌人，价值非常有限但有时能派上用场。
- [[spell:256948]] —— 虚空精灵
  
  - 生成一道朝你面朝方向移动的暗影，再次激活即可传送至裂隙处。
  - 最大距离为100码。

### 推荐

对于坦克来说，选择一个输出向的种族通常收益微乎其微，不值得为此纠结。如果你追求极限优化DPS，就选择DPS最高的种族。

话虽如此，大秘境 推荐的种族是 **暗夜精灵** 或 **矮人**，两者各有特色：前者更偏战术性，暗夜精灵可以跳过一些怪物组；后者在生存能力方面更加可靠。

## 宏

查看 **酒仙 武僧** 为 大秘境 推荐的宏，并观看一段关于为你的角色创建简单宏的快速视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
嘲讽宏 --- *此宏会对你的当前目标或鼠标悬停目标施放 [[spell:115546]]*（在拉起小怪时非常实用）

```wow-macro
#showtooltip 嚎镇八方
/cast [@mouseover,exists,harm][@target,exists,harm] 嚎镇八方
```

首领 1 嘲讽 --- *对首领 1 施放* [[spell:115546]]

```wow-macro
/cast [@boss1] 嚎镇八方
```

首领 2 嘲讽 --- *对首领 2 施放* [[spell:115546]]

```wow-macro
/cast [@boss2] 嚎镇八方
```

:::

:::details 鼠标指向宏
[[spell:116841]] --- *此宏会对你的当前目标或鼠标悬停目标施放 [[spell:116841]]*

```wow-macro
#showtooltip 迅如猛虎
/cast [@mouseover,exists,noharm][@target,exists,noharm] 迅如猛虎
```

[[spell:115078]] --- *对鼠标悬停目标施放 [[spell:115078]]*

```wow-macro
#showtooltip
/use [@mouseover] 分筋错骨
```

鼠标指向焦点 --- *此宏将鼠标指向的目标设为焦点*

```wow-macro
/focus [@mouseover]
```

:::

:::details 焦点目标宏
[[spell:115078]] --- *对焦点目标施放[[spell:115078]]*

```wow-macro
#showtooltip
/use [@focus] 分筋错骨
```

焦点 [[spell:116705]] --- *对焦点目标施放[[spell:116705]]*

```wow-macro
#showtooltip 切喉手
/cast [@focus,harm,nodead][] 切喉手
```

:::

:::details 实用宏
[[spell:116844]] 光标 --- *在光标位置直接施放[[spell:116844]]**，无需确认。*

```wow-macro
/cast [@cursor] 平心之环
```

**全能 药水 --** *所有不同种类的伤害 [[item:191383]]*，*如果你死亡了则使用 [[item:191374]]* *。*

```wow-macro
/use item:191383
/use [@player,nodead] item:191914
/use item:191382
/use item:191914
/use [@player,nodead] item:191389
/use [@player,nodead] item:191388
/use [@player,nodead] item:191387
/use [@player,dead]神经传导残剂
```

取消保护之手 --- *取消你身上的[[spell:1022]]，与圣骑士组队时非常实用*。

```wow-macro
/cancelaura 保护祝福
```

:::

:::

## 插件

下方是作者为其 **酒仙 武僧**，概述了使用哪些插件以及如何在大秘境中利用它们让你的游戏生活更轻松。

![](<https://assets-ng.maxroll.gg/wordpress/Monk-M-Interface-1024x606.jpeg>)

**酒仙 武僧** 界面推荐

:::accordion
:::details 插件
- **ElvUI *-- 全面的用户界面替换插件*** 
  
  - 一款以用户友好为核心设计的界面插件，附带许多标准界面所不具备的额外功能。
  - 你也可以选择 Shadowed Unit Frames (SUF) 搭配任意动作条插件，或者直接使用原生界面。
- **LittleWigs *-- 通用首领模块*** 
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成——这些小型插件专门为某一个特定的 团队副本 战斗触发警报信息、计时条、音效等。
- **Plater** -- 高级姓名板插件
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的减益监控、仇恨染色以及大量的自定义选项。
- **Details** -- 深度伤害统计插件
  
  - 让你的伤害统计界面更加美观。
- **MPlusTimer** -- 曾经是一个 Weakaura，现在是一个用于美化 大秘境 计时器的插件
  
  - 让你的 大秘境 计时器更加紧凑，并以更清晰的方式呈现信息。
  - 你也可以使用名字几乎完全相同的插件 "MythicPlusTimer"，纯粹看个人喜好。

:::

:::

## 本次版本改动

:::accordion
:::details 12.1 版本
#### 武僧

- 真气转移现在使轮回之触为你恢复其造成伤害60%的生命值（原为50%）。
- 蓬勃施疗使移花接木的治疗量提高6%（原为5%）。
- 静寂圣所的治疗量提高25%。

#### 酒仙

- 震荡打击提供的⟦WOWTERM_00001⟫缩短效果提高25%。
- 玄牛之魂生成疗伤珠的几率提高20%。
- 天神酒和天神灌注的吸收量提高150%，冷却时间延长100%。
- 觉醒之魂的最大吸收值提高25%。
- 生命之焰现在为你恢复所造成的火焰或自然伤害50%的生命值（原为40%）。
- 以下增益效果现已加入冷却管理器追踪：火上浇油、热力四射、灼烧、碎玉闪电和奥古斯特祝福。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我总是死亡？
答：错误地使用防御技能，以及没有正确管理[[spell:115069]]。请务必阅读**深入剖析**以了解更多信息！

:::

:::

---

### 致谢

作者：**Skövte**

审核：**Tief**

---

:::changelog 更新记录
**2026-08-11** 已更新至12.1版本

**2026-06-16** 已更新至12.0.7版本

**2026-04-21** 已更新至12.0.5版本

**2026-02-26** 已更新至12.0.1版本

**2026-01-20** 已更新至至暗之夜 12.0

**2025-12-02** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-08-05** 已更新至11.2版本



:::
