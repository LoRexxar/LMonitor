欢迎来到魔兽世界12.1版本的**复仇 恶魔猎手**团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始练级的吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 4/5 · 强

生存能力 · 5/5 · 优秀

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **复仇 恶魔猎手** 团队副本 最佳配装
```json
{
  "source_code": "J8fAwTVRCc__BEQskQggYUAAvj7AX16AkVzF2IoAYFwAmQQApfBBAkQAAQRrDQRrDIoAYFQAvSCBCgQAAUTuDIoAOFQA0SCBCgQAAkQuDIoAOFQAgfBBAiQABATACRQAwmgHEE6uJ8ACRU9AB0CAp0APYB2uDQAABAgFAPgJqOwSBEgskQAAIEAAFgFMcfBBCiQAA8SuDQRrDUgEIMubCojEAQAVfkBMA0VEMABWBEQ3X0AGEiVABE7FEIAABAQP5OAWBEAEhOgBAEAA9k7AVA8AkqCBLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271537]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240916]] |
| 肩部 | [[item:271535]] | [[item:244021]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240916]] |
| 腿部 | [[item:271536]] | [[item:244641]] |
| 脚部 | [[item:251153]] | [[item:244009]] |
| 腕部 | [[item:244576]] | [[item:245782]] · [[item:240166]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268252]] | [[item:240916]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240916]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:237840]] | [[item:244029]] · [[item:245781]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **复仇 恶魔猎手**，你可以使用无拘之怒，该效果使[[spell:228477]]和[[spell:247454]]每消耗一个灵魂残片都有一定几率使你免费使用一次[[spell:187827]]。

**等级2**提高了[[spell:228477]]和[[spell:247454]]的伤害，并使它们有几率额外消耗一个灵魂。而**等级3**则使每个未触发免费[[spell:187827]]的已消耗灵魂为你提供一层可叠加的敏捷增益，并提高触发免费[[spell:187827]]的几率。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-vengeance-mxr.webp>)

无拘之怒

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:112894]]
    
    - 大型范围伤害伤害冷却技能，可提供灵魂，并已从职业天赋树移至专精天赋树。
  - [[talent:112907]]
    
    - [[talent:112907]]从一个范围伤害灵魂消耗技能变成了一个小型范围伤害冷却技能，与[[talent:112870]]协同作用，并为你提供一个强大的护盾。
  - [[talent:112899]]
    
    - 现在将你的[[spell:187827]]变成了一个真正的伤害冷却技能，因为它会在[[spell:187827]]内使你所有主要循环技能的伤害提高20%。
  - [[talent:112870]]
    
    - 每当你按下[[talent:112907]]时都会为你提供一个华丽的护盾。

- **职业天赋树**
  
  - [[talent:112838]]
    
    - 每当你打断一个法术时，减少所受的魔法伤害。
  - [[talent:136501@FAQAF6zA]]
    
    - 显著提升你的[[talent:112908@FAQA_ROB]]的伤害。
  - [[talent:117758@FAQAF6zA]]
    
    - [[spell:189110]]现在会赋予你一个随时间衰减的小型临时护盾。
  - [[talent:112837@AJADBA]] & [[talent:136502@AJADBA]]
    
    - 允许你选择一个选择节点，使[[spell:195447]]可以清除你身上的一个诅咒或疾病效果。
  - [[talent:136500]]
    
    - 疯狂的天赋，让你在滑翔时移动得非常快。
- **已移除**
  
  - [[spell:321453]]
    
    - 你在施放[[talent:112908@FAQA_ROB]]时不再能够进入[[spell:187827]]，这使其现在成为一个纯粹的伤害冷却技能。

## 英雄天赋

- 对于团本，我推荐[[talent:134253]]，因为它比[[talent:123328]]提供更高的单体伤害，以及更强的整体生存能力。

:::tabs
:::tab [[talent:134253]]
- [[talent:134253]] 天赋树围绕生成和消耗 [[talent:135667@FAQAF6zA]] 层数展开：
  
  - [[spell:225919]] 有 35% 的几率获得 1 层 [[talent:135667@FAQAF6zA]]
  - [[talent:135664@AJADBA]] 使你在达到 3 层后使用 [[spell:227255]] 或 [[spell:228477]] 时消耗全部层数，并降下 3 颗陨石，造成大量 范围伤害 伤害。
  - 有了 [[talent:135671@FAQAF6zA]]，陨石还会使其目标在 8 秒内额外受到 25% 的伤害。
  - [[talent:135660@FAQAF6zA]] 在每降下第三颗陨石后，使 [[spell:187827]] 的冷却时间缩短 10 秒。
- [[talent:135672]] 和 [[talent:135670]] 在每存在一层活跃的 [[talent:135667@FAQAF6zA]] 时，提高急速并使受到的伤害降低 2%。
  
  - [[talent:135663@FAQAF6zA]] 使该效果在被消耗后持续 8 秒。
- 这使得玩法围绕不断用 [[spell:225919]] 积攒 [[talent:135667@FAQAF6zA]] 层数，并用 [[spell:227255]] 或 [[spell:228477]] 消耗它们而展开。
  
  - 虽然通过正常循环自然会发生这种情况，但尽早消耗 [[talent:135667@FAQAF6zA]] 层数以避免溢出是很重要的。

:::

:::tab [[talent:134253]]
- 消耗20个[[spell:203981]]或施放[[spell:389815]]会将你的下一个[[spell:204157]]转化为[[spell:442294]]。
  
  - 这会强化你的下一个[[spell:225919]]和[[spell:228477]]。你先施放的强化技能造成10%的额外伤害，第二个则造成20%的额外伤害。
  
  
  
  - 很简单，在使用[[spell:442294]]之后，施放[[spell:225919]] > [[spell:228477]]就是强化效果的优先级顺序。
- 使用[[spell:442294]]后第二个被强化的技能会通过[[talent:117511]]额外击碎一个[[spell:203795]]，这使你能通过消耗更多[[spell:203795]]来更快地找回[[spell:442294]]。
- [[talent:117500]]是一个减益效果，使目标在20秒内受到来自[[spell:442294]]强化后的[[spell:225919]]的伤害提高7%。 
  
  - 如果在[[spell:228477]]之后施放，[[talent:117500]]会提高到14%。
  - [[talent:117500]]也可以叠加，通过以[[spell:225919]] > [[spell:228477]]开始的第二轮强化，可以将其从7%提高到14%。
  
  
  
  - 此外，当 [[talent:117500]] 生效期间，[[talent:117494]] 会为你的近战攻击提供额外伤害，并有几率击碎一个 [[spell:203795]]。
- [[talent:123047]]为[[talent:112853]]提供了一种产生 **狂怒** 因为它会重置[[spell:213241]]的冷却时间。
- [[talent:123046]]极其强大，因为它能让你获得巨额的吸收量，取决于你当前消耗了多少个[[spell:203795]]。
- [[talent:117516]]是一个被动增益，通过消耗来自[[spell:442294]]的两种强化效果获得，可提供6%的急速加成。

:::

:::

## 天赋

:::tabs
:::tab [[talent:134253]]
:::talents **复仇 恶魔猎手** [[talent:134253]] 团队副本配装
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 改变游戏玩法的天赋

了解专精天赋树和职业天赋树中所有能显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，如需更详细的分析，请查看下方的**输出循环**和**[深度解析](<https://maxroll.gg/wow/class-guides/vengeance-demon-hunter-raid-guide#deep-dive-header>)**章节。

#### 专精树

- [[talent:112893]]
  
  - 一个减益效果，使你通过 [[spell:389985]] 按所造成伤害的 8% 或 16% 进行治疗。其机制与吸血完全相同。
- [[spell:336639]]
  
  - 大幅提高 [[spell:204021]] 的覆盖率，使其非常强大。
- [[spell:212084]]
  
  - 高伤害的正面锥形范围技能，同时会治疗你。
- [[spell:202137]]
  
  - 范围伤害 在 8 码半径内沉默。
- [[spell:227255]]
  
  - 一个 25 秒冷却的小型 范围伤害 技能，用于消耗灵魂制造瞬间仇恨。
  - 施加 [[talent:112893]]。
- [[spell:389732]]
  
  - 使 [[spell:204021]] 的冷却时间从 1 分钟缩短为 45 秒，并使其额外获得一层充能。有了它，[[spell:204021]] 的减伤覆盖率会大幅提高，让你可以更轻松地循环使用防御技能。

#### 职业树

- [[spell:204909]]
  
  - 一个2点天赋节点，每点提供5%吸血，且在[[spell:187827]]激活时额外提供5%吸血。
- [[spell:179057]]
  
  - 一个非常强力的45秒冷却范围伤害眩晕。
- [[spell:202140]]
  
  - 你的范围伤害迷惑技能，可将怪物控制15秒。
  - 也可通过打断怪物施法起到打断或停手的作用。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** 破裂伤害提高35%。
- **4件套：** 破裂有30%的几率引发剧烈爆炸，对附近敌人造成火焰伤害。超过5个目标后伤害降低。

### 起手爆发

:::tabs
:::tab [[talent:134253]]
### 起手爆发

:::rotation 复仇 恶魔猎手 [[talent:134253]] 团队副本中的单体输出
```json
{
  "source_code": "IUFbKI0tyXAAAgAUyVGIDF2c0BgQ_J3AAAAAAIUf8lACIc3-CUAEEg8GJABB1zRCIEBKEQHPJABKea8AAAAAAIUf8NA"
}
```
1. [[spell:389815]] 开战前预施法
2. [[spell:225919]]
3. [[spell:228477]]
4. [[spell:195447]]
5. [[spell:203720]]
6. [[spell:204021]]
7. [[spell:225919]]
8. [[spell:212084]]
9. [[spell:247454]]
10. [[spell:228477]]
:::

### 优先级列表

在单体目标战斗中，你的目标是尽可能多地产生[[spell:203981]]。

1. 冷却好了就施放[[spell:389815]]
2. 冷却好了就施放[[talent:112908@FAQA_ROB]]。
3. 冷却好了就施放[[spell:204021]]，以获得DR和[[talent:112872]]伤害。
4. 冷却好了就施放[[spell:227255]]。
5. 冷却好了就施放[[spell:204513]]。
6. 冷却好了就施放[[spell:195447]]。
7. 施放[[spell:225919]]
8. 当你有2层充能且无需为移动保留时，施放[[spell:189110]]。
9. 尽可能多地施放[[spell:228477]]。
10. 在不会使狂怒溢出的情况下施放[[spell:213241]]。
11. 将[[spell:195441]]作为填充技能施放，或当你距离目标较远时使用。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:134253]]
### 起手爆发

:::rotation 复仇 恶魔猎手 [[talent:134253]] 在团队副本中的范围伤害
```json
{
  "source_code": "IUFbKI0tyXAAAgAUyVGIDF2c0BgQ_J3AAAAAAIUf8lACIc3-CUAEEg8GJABB1zRCIEBKEQHPJABKea8AAAAAAIUf8NA"
}
```
1. [[spell:389815]] 开战前预施法
2. [[spell:225919]]
3. [[spell:228477]]
4. [[spell:195447]]
5. [[spell:203720]]
6. [[spell:204021]]
7. [[spell:225919]]
8. [[spell:212084]]
9. [[spell:247454]]
10. [[spell:228477]]
:::

### 优先级列表

在单体目标战斗中，你的目标是尽可能多地产生[[spell:203981]]。

1. 冷却好了就施放[[spell:389815]]
2. 冷却好了就施放[[talent:112908@FAQA_ROB]]。
3. 冷却好了就施放[[spell:204021]]，以获得DR和[[talent:112872]]伤害。
4. 冷却好了就施放[[spell:227255]]。
5. 冷却好了就施放[[spell:204513]]。
6. 冷却好了就施放[[spell:195447]]。
7. 施放[[spell:225919]]
8. 当你有2层充能且无需为移动保留时，施放[[spell:189110]]。
9. 尽可能多地施放[[spell:228477]]。
10. 在不会使狂怒溢出的情况下施放[[spell:213241]]。
11. 将[[spell:195441]]作为填充技能施放，或当你距离目标较远时使用。

:::

:::

### 防御技能冷却

- [[spell:187827]]
  
  - [[spell:187827]] 是你最大的防御冷却技能，你应该学会围绕 [[spell:187827]] 的使用进行规划，以便更从容地减轻来袭伤害。

- [[spell:204021]] 
  
  - [[spell:204021]] 提供 40% 的伤害减免，同时对目标施加一个持续伤害效果。通常情况下，你应该在冷却好了就使用这个法术，因为它伤害不俗，还可以通过 [[spell:212818]] 增强你的其他火焰伤害法术。但是，如果即将出现坦克毁灭技或高伤害机制，而你需要保留额外的防御技能来保命时，请留住这个法术。配合天赋，可以通过 [[spell:336639]] 延长其持续时间，还可以通过 [[spell:389732]] 获得额外充能并缩短冷却时间。

- [[spell:196718]]
  
  - [[spell:196718]] 持续 8 秒，使你或盟友在黑暗中所受的所有伤害有 15% 的几率被完全规避。与应对大型单体伤害相比，这并不算出色，但对于多次小额伤害（例如近战攻击）非常有效。如果你没有为某个特定情况保留它，由于其防御收益，你几乎应该在冷却好了就使用它。

### 进攻冷却技能

- [[spell:389815]]
  
  - [[spell:389815]] 会造成中等的伤害并产生 3 层 [[spell:203795]]，使你能够更频繁地施放 [[spell:227255]]。

## 深度解析

### 符印

- 符文是 **恶魔猎手** 一种放置在地面上的特殊技能，在 2 秒延迟后于 8 码范围内生效。 
  
  - 点出 [[spell:209281]] 后，该延迟缩短至 1 秒。
  - 它们可通过 [[spell:395446]] 产生 1 层 [[spell:204255]]。
  
  
  
  - [[spell:389715]] 使你的符文持续时间延长 2 秒，半径扩大 2 码。
  - [[spell:389718]] 使你所有符文的冷却时间缩短 15%。

### 复仇 恶魔猎手 的防御技能循环

- 复仇 恶魔猎手的主动减伤[[spell:203720]]具有极高的覆盖率，这意味着作为复仇 恶魔猎手，你可以利用宏将[[spell:203720]]绑定到你的[[spell:225919]]技能中，而不会损失任何防御效果。
- 在循环使用防御技能方面，虽然[[spell:203720]]是我们最常备的主动防御技能，但玩家应尽量按[[spell:187827]] > [[spell:204021]] > [[spell:203720]]的顺序最大化它们的覆盖率。
  
  - 这确实意味着你最终会将[[spell:203720]]与其他防御技能重叠和叠加使用。主要目标是确保[[spell:203720]]的充能也不会溢出。
- 这种玩法让复仇 恶魔猎手与其他坦克职业区别开来，因为在高级别内容中需要频繁这样做，因为在没有防御冷却的情况下承受伤害可能意味着灾难。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下技巧主要适用于**英雄难度首领**。史诗难度的技巧将在我们的开荒进度结束后发布。

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **复仇 恶魔猎手 团队副本 内克扎莉**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 坦克机制

- 这场战斗的主要坦克机制是蚀空打击——首领每次近战攻击以及施放 [[spell:1284103]] 时都会施加的一种减益效果。
- 在 [[spell:1284103]] 期间，首领会向当前坦克发射幽灵回响，额外施加蚀空打击层数。这些回响在首次接触到任意玩家时会爆炸，对团队造成降低后的 
  
  - 当你成为该机制的目标时，走出团队，并确保你和首领之间没有任何人，以免他们过早触发回响。否则，回响会对团队造成过多伤害。
  - 每次 [[spell:1284103]] 施放完毕后进行嘲讽换坦。
- 此外，首领还会召唤成群的不安阿曼尼——务必将首领拉到它们旁边，以便更好地进行顺劈。
- 在过渡阶段，当前坦克会成为一次群体分担——[[spell:1289855]] 的目标。尽量将它放在尽可能多的不安阿曼尼尸体上，利用 [[spell:1289875]] 将其烧毁，防止它们再次苏醒。

:::

:::tab 陵寝哨兵
:::talents **复仇 恶魔猎手 团队副本 陵寝哨兵**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 坦克机制

- 由于 [[spell:1290189]]，首领们必须始终保持至少40码的距离。在每个阶段开始时，将首领们移到房间的不同两侧使其分开。
- [[spell:1284458]] 和 [[spell:1284487]] 是各个首领的叠加坦克减益效果。在 [[spell:1284588]] 期间，每当首领们在房间中央相遇时，务必进行嘲讽换坦以重置你的层数。
  
  - [[spell:1284487]] 额外会在到期时产生一个大型血泊。如果可能，请务必将其放置在房间的边缘。
- 不要将 乌拉特克之息 坦克在现有的血泊太近的位置，这样 [[spell:1284251]] 就不会在血泊中生成，近战职业就可以安全地攻击它。

:::

:::tab 迷失的探险者
:::talents **复仇 恶魔猎手** **团队副本 迷失的探险者**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 坦克机制

- 由于 [[spell:1297645]]，三个首领彼此都不能处于 30 码以内——始终让其中一个首领远离另外两个。
- 商人盖博 只会在房间里游荡，不会跟随或攻击其仇恨目标。它也没有任何坦克机制。
- 书卷贤者伊库 会对其当前目标施放 [[spell:1295854]]——一连串冰碎片，每片造成魔法伤害，并使后续碎片受到的伤害提高，持续 80 秒。
- 大副纳玛 每次攻击都会对其目标施加 [[spell:1291929]]，使该目标受到的物理伤害提高，持续 30 秒。
- 这场战斗中坦克的职责是在Scrollsage伊库和 大副纳玛 之间来回换坦，绝不让 [[spell:1295854]] 连续两次施放在同一目标身上，并尽可能频繁地重置 [[spell:1291929]]，同时始终让其中一个首领距离足够远，以防止 [[spell:1297645]] 被施加。

:::

:::tab 瓦什尼克
:::talents **复仇 恶魔猎手 团队副本 瓦什尼克**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 坦克机制

- 房间两侧放置着 3 座喷泉：鲜血之泉、火焰和 暗影。整场战斗中，首领会通过 [[spell:1283164]] 激活最近的两座喷泉，获得它们的力量并召唤一些小怪。
  
  - 每座喷泉被激活后，会使下一次激活强化 1.5 分钟。
  
  
  
  - 作为坦克，你的职责是通过在每次 [[spell:1283164]] 施放前将首领拉到下一座喷泉处，绝不让首领连续激活相同的两座喷泉。
  - 务必将首领定位在从喷泉出来的小怪上方，以便更好地顺劈。但是，要小心不要过快杀死所有火焰小怪，因为它们死亡时会施加可叠加的 [[spell:1285979]]。
- 瓦什尼克的坦克打击技能是 [[spell:1280935]]，每次施放后进行嘲讽换坦。

:::

:::tab 斯索拉克
:::talents **复仇 恶魔猎手 团队副本 斯索拉克**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 战斗机制

- [[spell:1277025]] 是一组坦克正面机制的组合，由 2 次 [[spell:1277002]]、2 次 [[spell:1277027]] 和 1 次 [[spell:1287072]] 组成，以随机顺序施放。
  
  - [[spell:1277002]] 是一个正面锥形范围技能，造成高额物理伤害并跟随当前坦克。务必将其指向**远离团队**的方向。
  - [[spell:1277027]] 是一个正面锥形范围技能，会施加一个强力的魔法持续伤害效果，其效果会被锥形范围内被击中的人数所分摊减弱。务必将此技能指向团队的一半人马，让他们来分担。
  - [[spell:1287072]] 会在首领周围生成一群龙卷风，并在施法结束时将其向外发射。当此技能发生时，确保你不在首领下方，并躲避龙卷风。
  - 在英雄和史诗难度下，首领会以随机顺序施放这些技能。由于每个正面锥形技能都会施加来自该技能的伤害提高效果，务必确保同一个坦克绝不承受 2 次相同技能。请记住，你可以在施法期间嘲讽，让首领将正面锥形技能对准你。
- 每次施放 [[spell:1306120]] 都会在首领周围生成 [[spell:1305998]] 个水坑。务必将首领拉到房间边缘，理想情况下是与 [[spell:1285732]] 刷新点相对的一侧，这样水坑就会被风吹出房间边缘。
- 除此之外，斯索拉克 每次近战攻击都会施加一层 [[spell:1282869]]，使目标受到的物理伤害提高。在每次 [[spell:1277025]] 连击后进行嘲讽换坦就足以重置层数。

:::

:::tab 双牙
:::talents **复仇 恶魔猎手** **团队副本 孪生毒牙**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 通用机制

- 整场战斗的核心在于管理 [[spell:1290336]] 层数
  
  - [[spell:1291404]]、[[spell:1291478]]、被毒波命中或吸收 [[spell:1289201]] 都会施加一层 [[spell:1290336]]。
  - 在英雄难度下达到 10 层或史诗难度下达到 9 层会立即死亡。
  - 尽可能躲开毒波，同时控制好吸收 [[spell:1289201]] 的数量，以避免该减益效果达到最大层数，这一点至关重要。

### 坦克机制

- 当你主动坦住的首领脱离近战范围时，它会施放 [[spell:1295107]] 或 [[spell:1295113]]，所以千万不要离开近战范围；如果发现自己离首领太远，请使用一个大型个人减伤。
- 维克苏尔 的坦克技能是 [[spell:1289192]]，造成自然伤害并将你击退 5 秒。
  
  - 它还会在你周围生成 [[spell:1289201]]。这些需要由玩家吸收，以免爆炸后给所有人叠加一层 [[spell:1290336]]。
  - 每次被击中都会施加 [[spell:1310360]]，因此每次 [[spell:1289192]] 施放后都要进行嘲讽换坦。
  - 注意击退效果，尤其是毒波即将到来的时候！
- 伊斯拉兹 会施放 [[spell:1288538]]，击退靠近首领的玩家并生成 3 个吸收区域。
  
  - 每个区域会造成高额物理伤害，并使下一个区域造成的伤害提高 33%。如果无人吸收该区域，它会对全团造成伤害并将所有人击飞。务必在每组 [[spell:1288538]] 之间进行嘲讽换坦，以重置伤害增加的层数。
  
  
  
  - 这些区域以随机顺序生成，并且必须按照生成的先后顺序依次吸收。在这一技能进行时，请密切关注区域的生成并记住生成顺序。首领在触发下一个区域前会短暂地面朝该区域的方向，所以如果你记不住生成顺序，可以参考首领的朝向。
  - 每隔一次 [[spell:1288538]] 施放都会与毒波重合——吸收 [[spell:1288538]] 时务必确保不被毒波击中。
  - 小心该机制开始时的击退，因为它可能把你推入袭来的毒波或某个 [[spell:1289201]] 中。

:::

:::tab 盘绕祭坛
:::talents **复仇 恶魔猎手 团队副本 盘卷祭坛**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 第一阶段

- 该阶段中只有 祖尔加 处于激活状态。
- 他会施放 [[spell:1299960]]，在该阶段中生成多个 [[spell:1282403]] 法球。法球存在期间会持续对全团造成 范围伤害 伤害，玩家可以撞入法球来拾取并移动它们。
- [[spell:1299684]] 是一个指向当前坦克的正面锥形技能，造成物理伤害，并摧毁任何被它命中的 [[spell:1282403]]。
  
  - 它还会使下一次 [[spell:1299684]] 造成的伤害提高 200%，因此每次施放后务必进行嘲讽换坦。
- 该阶段的目标是让团队将 [[spell:1282403]] 法球聚集到一起，然后用 [[spell:1299684]] 将其摧毁。
- 此外，每次施放 [[spell:1282487]] 都会强化首领接下来的 23 次近战攻击，附带 [[spell:1300322]]，对坦克造成额外的自然伤害。
  
  - 当首领身上有 [[spell:1300322]] 层数时，务必提前开启减伤技能。

### 第二阶段

- 在此阶段中，只有 妖术领主玛拉卡斯 处于激活状态。
- 他会施放 [[spell:1285640]]，对被选中的玩家进行精神控制，并在精神控制被打破时，每名玩家召唤出 2 个 [[spell:1285842]]。
  
  - 这些具象会锁定随机玩家并向其移动，除非被锁定的玩家回头注视具象。
- 与第一阶段的 [[spell:1299684]] 类似，[[spell:1286620]] 是一个指向当前坦克的正面锥形技能，造成暗影伤害，并摧毁其击中的任何 [[spell:1285842]]。
  
  - 它还会使下一次 [[spell:1286620]] 受到的伤害提高 200%，因此务必在每次施放后进行嘲讽换坦。
  - 此外，它会施加 3 层 [[spell:1286837]]，每层会生成一个 灵魂残片，必须拾取才能移除该层效果。如果该减益效果到期前层数未被清除，受影响的玩家将立即死亡。
  - 每次坦克正面技能之后，务必格外注意迅速找到并收集所有的 灵魂残片。
- 被 [[spell:1286895]] 击中也会施加 3 层 [[spell:1286837]]。千万不要让它打你个措手不及！

### 阶段转换

- 玛拉克拉丝在施放 [[spell:1287685]] 期间受到的伤害提高 100%。请务必为间歇阶段保留你的重要防御技能！
- 不要让任何玛拉克拉丝残片到达首领处，通过吸收它们来防止其治疗首领。
  
  - 吸收每个残片都会造成全团 范围伤害 伤害，因此不要吸收得太快，给你的治疗者们一些反应即将到来伤害的时间。

### 第三阶段

- 在此阶段中，祖尔加 和玛拉克拉丝同时激活，并将第一和第二阶段的技能组合在一起。
- [[spell:1299960]] 和 [[spell:1285640]] 都会在此阶段发生，这意味着 [[spell:1282403]] 和 [[spell:1285842]] 都需要通过坦克的正面技能来清除。
- 此阶段的坦克正面锥形技能是 [[spell:1307279]]，它造成暗影伤害，摧毁被其击中的任何 [[spell:1282403]] 和 [[spell:1285842]]，并施加 3 层 [[spell:1286837]]。
  
  - 别忘了在每次锥形技能后收集你的 灵魂残片 并进行嘲讽换坦！
- [[spell:1298381]] 是第一阶段 [[spell:1282487]] 的强化版本。
  
  - 在此阶段中，强化后的近战攻击还会额外施加一个 **可叠加的**暗影持续伤害效果。当叠加层数较高时，请使用重要防御技能。

:::

:::tab 乌拉特克
:::talents **复仇 恶魔猎手 团队副本 乌拉特克**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

:::

:::tab 尼姆瑞莎·唤波者
:::talents **复仇 恶魔猎手 团队副本 尼姆瑞莎·唤波者**
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAYMzMjZmZkZmZY2MzMjBjZGzYmZGDzYmx2MzsNGAAAAAAAIgZmxGAAAAGMmZmZWabmZGAAAAAgBA"
}
```
:::

### 通用机制

- 首领会用刺骨的 冰霜 随机标记玩家，在其脚下生成 冰霜 法球。
  
  - 这些法球必须在爆炸并团灭团队之前被吸收。
  - 吸收法球会施加一个可叠加的减益效果，使吸收 冰霜 法球时受到的伤害增加，所以不要一次吸收太多。
  - 每次吸收法球还会对全团造成 范围伤害，因此不要吸收得太快，给治疗者一些时间来应对即将到来的伤害。
- 鱼人会不时从水中出现，并开始走向房间中央的气泡。
  
  - 不要让它们到达气泡处，并尽可能将首领移动到它们上方，以便更好地进行顺劈。

### 坦克机制

- 这场战斗中坦克专属的机制是冰刃连斩——一系列魔法斩击，每一斩都会增加后续斩击的伤害。
  
  - 每次施放时使用一个防御技能，并在每次结束后换坦嘲讽。

:::

:::

## 属性优先级

了解你的次要属性优先级，以及作为一名 **复仇 恶魔猎手** 进行团队副本所需的最优表现所需的第三属性。欲了解更多详细信息，请访问 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

#### 

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

### 属性选择原因

急速始终是最受追捧的属性，因为它能提供大量伤害，同时还能缩短[[spell:203795]]生成技能和[[spell:203720]]的冷却时间，从而提供极强的生存能力。在团队副本中，爆击带来的防御价值往往不如全能，尤其是因为许多首领都有坦克终结技或无法被招架的技能。因此，在团队副本中全能在生存方面略优于爆击，而且更加稳定，这在“开荒”中是非常被看重的。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 略微减少受到的范围性攻击伤害。这可以是首领施放的某些坦克技能，也包括小怪。从20%（2000）开始收益严重递减，但没有上限。
- **吸血** - 使玩家根据造成的伤害和治疗量立即回复生命值。回复的生命值等于你的吸血量。例如：1%的吸血可回复相当于所造成伤害和治疗量1%的生命值。
- **速度** - 提高移动速度。

总而言之， **闪避** 是你在团队副本中作为一名 **复仇 恶魔猎手** 为了在生存能力方面追求极致优化所应选择的，因为它在团队副本方面比其他两种副属性为你带来更大的收益。 **吸血** 在需要坦克大量难以处理且存活时间较长的add的战斗中表现更好。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | 乌拉特克 |
| 颈部 | [[item:271537@DCRBAUkAvj7cVrDZ1chNYFwAmQA]] | 乌拉特克 |
| 肩部 | [[item:271535@DAQAAUkA1k74UA]] | 套装 |
| 披风 | [[item:268253@BAQAAUkAYFA]] | 盘卷祭坛 |
| 胸部 | [[item:271540@DAQAAUkAJk74UA]] | 套装 |
| 手腕 | [[item:244576@FAQAAUkAWA8YiqzSBA]] | 制造业 |
| 手部 | [[item:271538@BAQAAUkAOFA]] | 套装 |
| 腰部 | [[item:268256@BCQAAUkAU06gVA]] | 盘卷祭坛 |
| 腿部 | [[item:271536@DAQAAUkAhu7gVA]] | 套装 |
| 脚部 | [[item:251153@DgQAAUkApk7IoAOF]] | 纳洛拉克的洞穴 |
| 戒指 1 | [[item:268252@DEQAAUkAvk7QRrDFtOOF]] | 斯索拉克 |
| 戒指 2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | 诸王之眠 |
| 饰品 1 | [[item:270164@BgQAAgGACKgTBA]] | 迷失的探险者 |
| 饰品 2 | [[item:270173@BAQAAUkAOFA]] | 盘卷祭坛 |
| 武器 | [[item:268209@DAQAAUkA9k7gVA]]、[[item:237840@HAQAAUkA9k7UBwDpqQLF]] | 盘卷祭坛、制造业 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 位置 |
| --- | --- | --- |
| 头部 | [[item:273791@BgQAAgGACKQQBA]] | 毒牙祭坛 |
| 颈部 | [[item:251173@BgQAAgGACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:251223@BgQAAgGACKQQBA]] | 虚空之痕竞技场 |
| 披风 | [[item:193763@BgQAAgGACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251226@BgQAAgGACKQQBA]] | 虚空之痕竞技场 |
| 手腕 | [[item:251135@BgQAAgGACKQQBA]] | 密谋小径 |
| 手套 | [[item:251124@BgQAAgGACKQQBA]] | 密谋小径 |
| 腰带 | [[item:159301@BgQAAgGACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:159313@BgQAAgGACKQQBA]] | 诸王之眠 |
| 脚部 | [[item:251153@BgQAAgGACKQQBA]] | 纳洛拉克的洞穴 |
| 戒指1 | [[item:273792@BgQAAgGACKQQBA]] | 毒牙祭坛 |
| 戒指2 | [[item:159459@BgQAAgGACKQQBA]] | 诸王之眠 |
| 饰品 1 | [[item:250228@BgQAAgGACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250215@BgQAAgGACKQQBA]] | 密谋小径 |
| 武器 | 2x [[item:251143@AgQAAIoAOFA]] | 纳洛拉克的洞穴 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270175@BgQAAgGACKAWBA]]  <br>[[item:270173@BgQAAgGACKAWBA]]  <br>[[item:270165@BgQAAgGACKgTBA]] |
| **A级** | [[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B级** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C级** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **垃圾级** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### 美化饰品

- 1x [[item:273060]]
  
  - 总体来说最佳的属性分配选择。
- 1x [[item:240166]]

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - **[[item:241324]]**
- **食物**
  
  - **[[item:255845]]**
- **战斗药水**
  
  - **[[item:241308]]**
- **治疗药水**
  
  - **[[item:271884]]**
- **武器磨刀石/精油**
  
  - **[[item:243734]]**
- **强化符文**
  
  - **[[item:259085@AQAAAoF]]**
- **插槽**
  
  - **[[item:240967]] *-- 唯一，每种颜色的宝石各用一颗来强化你的亵渎石。***
    
    - **[[item:240910]]**
    - **[[item:240914]]**
    - **[[item:240890]]**
    - **[[item:240900]]**

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 护腕 | [[item:275707@BAAAAIE]] |
| 腰带 | [[item:275707@BAAAAIE]] |
| 腿部 | [[item:244641@BAAAAIE]] |
| 靴子 | [[item:243983@BAAAAwQA]] |
| 戒指1 | [[item:244015@BAAAAIE]] |
| 戒指2 | [[item:244015@BAAAAIE]] |
| 武器 | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **复仇 恶魔猎手** **团队副本**
```json
{
  "source_code": "JwFZFJQ9NGQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AERgAK9k7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
| 副手 | [[item:244029]] |  |
:::

:::

:::

> *你需要从宏伟宝库商人处购买 ‍[[item:275707]]，来为你的头盔、护腕和腰带添加插槽。*

## 种族

在复仇 恶魔猎手 团队副本攻略的这一部分中，我们将展示并解释某些种族天赋在魔兽世界中的重要作用。

- [[spell:58984]] —— 暗夜精灵
  
  - 在 团队副本 中没有任何作用，但在 大秘境 的极少数特殊情况下可能有用。
- [[spell:202719]] —— 血精灵
  
  - 移除你周围敌对目标身上的 1 个有益效果。
  - 产生 15 点 狂怒。
- [[spell:256948]] —— 虚空精灵
  
  - 在空间中撕开一道裂隙。再次激活该技能可穿越裂隙进行传送。

### 推荐

我个人推荐 暗夜精灵，因为它在 大秘境 中的用途广泛，即使是作为团队副本玩家也能获得更多收益。两个种族在团队副本中的差距其实并不大，所以你不妨选择 暗夜精灵，以获得它在 大秘境 中的加成。

## 宏

了解 **复仇 恶魔猎手** 的推荐宏命令，并观看一段关于为你的角色创建简单宏的快速视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
**鼠标指向嘲讽** --- *[[spell:185245]]（嘲讽）的鼠标指向宏，让你无需切换目标就能轻松对刚进入视野或刚刷新的目标建立仇恨。如果你的鼠标没有指向任何目标，它会嘲讽你的当前主要目标。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]折磨
```

首领1嘲讽 --- *对首领1施放 [[spell:185245]]*

```wow-macro
/cast [@boss1] 折磨
```

2号首领嘲讽 --- *施放 [[spell:185245]]* *于2号首领*

```wow-macro
/cast [@boss2] 折磨
```

:::

:::details 鼠标指向宏
***[[spell:202137]]**于鼠标位置 --- 这使你在任何情况下都能更快地使用 [[spell:202137]]*

```wow-macro
#showtooltip
/cast [@cursor] 沉默咒符
```

***[[spell:202138]]**于鼠标位置 --- 这使你在任何情况下都能更快地使用 [[spell:202138]]*

```wow-macro
#showtooltip
/cast [@cursor] 锁链咒符
```

***[[spell:202140]]**于鼠标位置 --- 这使你在任何情况下都能更快地使用 [[spell:202140]]。*

```wow-macro
#showtooltip
/cast [@cursor] 悲苦咒符
```

***[[spell:204513]]**于鼠标位置 --- 这使你在任何情况下都能更快地使用 [[spell:204513]]。*

```wow-macro
#showtooltip
/cast [@cursor] 烈焰咒符
```

**[[spell:389815]]**于鼠标位置 --- 这使你在任何情况下都能更快地使用 [[spell:389815]]。

```wow-macro
#showtooltip
/cast [@cursor] 怨念咒符
```

**[[spell:189110]]**于鼠标位置 --- 这使你能更快地使用 [[spell:189110]]，从而更快速、更高效地移动。

```wow-macro
#showtooltip
/cast [@cursor] 地狱火撞击
```

:::

:::details 实用宏
**取消光环宏** --- *这是一个非常重要的宏，你需要将任何在特定情况下需要取消的免疫类增益填入其中。例如：你使用了圣骑士的[[spell:1022]]来快速消除某个减益效果，随后需要取消它，以便在队友被迫承接仇恨之前继续充当主要的仇恨目标。*

```wow-macro
/cancelaura 保护祝福
```

:::

:::details 玩家宏
**[[spell:189110]] 对自己施放**--- *允许立即在脚下 地狱火撞击，由于 [[spell:189110]] 不占用公共冷却，因此可以用来进一步优化伤害输出。不应频繁使用，但在特定情况下有其用途。*

```wow-macro
#showtooltip
/cast [@player] 地狱火撞击
```

:::

:::

## 插件

下方是作者为其 **复仇 恶魔猎手**所用用户界面的截图，其中概述了使用了哪些插件以及它们在团队副本中如何帮助你更轻松地进行游戏。

![](<https://assets-ng.maxroll.gg/wordpress/nicememesuimidnight-3-1024x681.png>)

**复仇 恶魔猎手** 突袭界面

:::accordion
:::details 插件
- BigWigs -- 通用首领模块
  
  - BigWigs是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件专为某个特定的团队副本战斗触发警报消息、计时条、音效等内容而设计。
- Plater -- 高级姓名板
  
  - Plater是一个姓名板插件，拥有海量的设置选项、开箱即用的减益监控、仇恨着色功能，并支持类似WeakAuras和wago.io + WeakAuras-Companion的脚本编写，用于Mod/脚本/配置文件的更新。
- **Details** -- 深度伤害统计器
  
  - 魔兽世界最强大、最可靠、最精美的伤害统计器。
- 回响 团队副本 Tools -- 记事、团队副本冷却监控等
  
  - 回响 团队副本 Tools是一款由回响电竞设计的魔兽世界插件，旨在提升团队副本效率。它为每个副本首领提供“回响认证”的WeakAuras，可通过游戏内的地下城手册界面访问，便于轻松导入和自定义。

:::

:::

## 本次版本改动

:::accordion
:::details 12.1 版本
**▶ 恶魔猎手**

- 复仇
  
  - 破裂 和 灵魂裂劈 现在需要装备战刃、斧、剑和拳套。
  - 锁链咒符 现在在35级习得，不再是一个天赋。
  - 锁链咒符 冷却时间缩短至60秒（原为90秒）。
  - 锁链咒符 不再替换 悲苦咒符。
  - 选中时，沉默咒符 现在会替换 悲苦咒符。
  - 改良的 悲苦咒符 不再影响 锁链咒符。
  - 当选择 沉默咒符 时，改良的 悲苦咒符 现在会使 沉默咒符 的冷却时间缩短15秒。
  - 所有伤害提高5.5%。
  - 灵魂裂劈 治疗量提高25%。
  - 邪能毁灭 治疗量提高25%。
  - 燃魂战刃现在使你恢复相当于 火焰 伤害5%的生命值（原为4%）。
  - 脆弱 现在使你对受影响目标造成伤害的10%转化为治疗（原为8%）。
  - 灵魂盛宴治疗量提高25%。
  - 苦痛狂欢现在使你的 火焰 伤害的6%为你提供护盾（原为5%）。
  - 部分天赋在天赋树中的位置发生了变动。

:::

:::

## 常见问题

:::accordion
:::details 问： 如何提升坦克水平？
我能给出的最重要建议是：每次死亡后都要弄清楚你为什么会在那种情况下死亡，以及如何改进。坦克并不轻松，你需要不断寻找机会更好地运用队友给予的外部减益、循环和防御技能。录制你的游戏过程并回顾魔兽争霸日志（Warcraft Logs）是很好的方法。要成为一名优秀的坦克，需要认知上的灵活性——专注于思考自己本可以做得更好，而不是责怪他人。这种心态更有益，也更健康，能帮助你成为更好的坦克。

:::

:::

---

### 致谢

作者：Nicememes

审校：Tief

---

:::changelog 更新记录
**2026-08-09** 更新至12.1版本

**2026-06-22** 更新至12.0.7版本

**2026-04-23** 更新至12.0.5版本

**2026-01-19** 更新至12.0.1版本



:::
