Welcome to the **Blood Death Knight** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 5/5 · Excellent

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 5/5 · Excellent

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Blood Death Knight** Raid BIS
```json
{
  "source_code": "JsfAAqPA3_PABIHJEIICBAw74Og_sOQOC4UABk-FEAQEBAwVtmgE0wYNYFQAwRCBCgQAAUTuJMCB-eRBPAQCB8AKYFQAjfBBAiQAA4fABBGWBEQckQgAQUAAhu7A5IgF2gVAGYCBBEXLFIDTPk7ACKgTBEgChOAhQEAAVA8AmoaAnRDAAcbNLFQAzRCBAgQAAUwhgMubCIICBAwL5GAIAIYA1ggYZPgOSAABf9RDwwAWBEQXdwAEog6AEgQEfBwtBoFN1eBBQgQAAUJ_EkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240894]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240894]] |
| 肩部 | [[item:271472]] | [[item:244021]] |
| 胸部 | [[item:268222]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271473]] | [[item:244641]] |
| 脚部 | [[item:273777]] | [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245781]] · [[item:240166]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:159459]] | [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:239656]] | [[item:245781]] · [[item:240166]] |
| 主手 | [[item:268213]] | [[spell:326805]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Blood Death Knight** you have access to Dance of Midnight. It gives parrying an attack during [[spell:49028]] a chance to make your next [[spell:79885]] cost no runes and deal additional 150% damage.

**Rank 2** reduces your damage taken and increases damage done for every [[spell:49028]] active. While **Rank 3** gives you a chance to summon a [[spell:49028]] every time you spend a rune for 6 seconds.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-blood-mxr.webp>)

Dance of Midnight

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:1264235]]
    
    - Makes your [[spell:45470]] now hit 2 additional targets.
  - [[spell:108199]]
    
    - The silence is now build into this ability and doesn't cost 1 additional talent point anymore.
  - [[spell:1263743]]
    
    - Gives you increased parry chance during [[spell:49028]] and increases your Runic Power by 10 during its uptime.
  - [[spell:1263781]]
    
    - When [[spell:1263743]] ends, it explodes and does damage to nearby enemies plus it heals you for 15% of its explosion damage done.
  - [[spell:1265790]]
    
    - Your [[spell:79885]] has a chance to reduce the cooldown of your [[spell:50842]] by 0.25 seconds.
  - [[spell:1263824]]
    
    - Is an empowered ability with 3 stages, the longer you empower it the more damage it deals and the more damage taken reduce you gain from it.

- **Class Tree**
  
  - [[spell:1266819]]
    
    - Your [[spell:61999]] costs 30 less Runic Power.
  - [[spell:391571]]
    
    - Is now a 2-point talent which makes it a 30% bonus absorb value if 2 points are put in.
  
  
  
  - [[spell:374265]]
    
    - Also a 2-point talent which can give you up to 4% extra haste.
- **Removed**
  
  - [[spell:219809]] 
    
    - This results in having less major defensive cooldowns against large tank hits.
  - [[spell:194844]]
  
  
  
  - [[spell:377640]]
    
    - Not dealing any passive damage to enemies anymore when losing [[spell:195181]] stacks.
  - [[spell:194679]]
    
    - Not a huge loss since this was a very niche talent and not being played so often.
  - [[spell:221699]]
  - [[spell:343294]]

## Hero Talents

- Going into the start of Midnight Season 2, [[talent:123325]] currently outperformes [[talent:123326]] by a little bit, it is also easier to play so the rest of the guide will assume you're going to be running [[talent:123325]].

:::tabs
:::tab [[talent:123326]]
- [[spell:439843]]
  
  - Pressing this ability inflicts the target with a [[spell:439843]], after either reaching 40 stacks, or the ability simply running out, you gain a stack of [[spell:441378@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].
- [[talent:117631]]
  
  - Pressing [[talent:117659]] additionally give you 3 stacks of [[spell:195181]].
- [[spell:440031@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] and [[spell:441894]]
  
  - Transforms [[spell:50842]] to deal Shadowfrost damage and gives [[spell:55078]] a chance to deal extra Shadowfrost damage therefore contributing more stacks to [[talent:117659]].

#### Defensive Choice Nodes

- [[talent:117632]] or ‍[[talent:123420]]
  
  - ‍[[talent:117632]] is not a good enough talent to consider. [[talent:123420]] is incredibly strong as it is a passive damage reduction based on what abilities you use.
- ‍[[talent:117646]] or ‍[[spell:439948]]
  
  - ‍Death's Messenger is the clear choice here as ‍Expelling Shield does not work in PvE content on casts where it matters.

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1265855@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - Casting [[spell:49028]] grants another stack of [[spell:441378@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]].

:::

:::tab [[talent:123325]]
- [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - [[spell:49998]] has a chance to transform your next [[spell:79885]] into [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].
  
  
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] heals you for 1% of your max HP and also grants you 1 stack of [[spell:433925]].
- [[talent:117645]]
  
  - While standing in your [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]], you take 5% less physical damage and the proc chance of [[spell:433895]] is increased to 5%.
- [[talent:117662]]
  
  - Allows [[spell:433925]] to stack up to 2 and increases your ‍ [[spell:49998]] damage by 5% per stack.
- [[spell:434157@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - Consuming [[spell:81141]] procs grants you 12% strength for 12 seconds.
- [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]]
  
  - [[talent:96269]] now grants you [[spell:434152@FJwCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBU3yEGA]] which replaces [[spell:79885]] with [[spell:433895]] for its' duration.
  - [[spell:433925]] effectiveness is also increased by 200% during [[talent:96269]].

#### Defensive Choice Nodes

- [[talent:117892]] or [[talent:117661]]
  
  - Default pick since it's a nice bonus to mobility, [[talent:117661]] can be swapped to if you are the main combat resser.
- [[talent:117891]] or [[talent:117653]]
  
  - [[talent:117891]] increasing the potency of ‍[[talent:96210]] is simply too good to give up as 2% **Leech** sometimes increasing to 4% even for 4 allies is just not good enough.

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1234559]]
  
  - [[spell:37788]] now has a chance to deal huge AoE burst damage, as it can explode randomly during its duration.
- [[spell:1265574]]
  
  - [[spell:433895@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] increases your damage done by your [[talent:96269]].

:::

:::

## Talents

:::tabs
:::tab Standard Build
:::talents **Blood Death Knight** Raid Standard Build
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### When to use this spec

This is the default loadout going into any boss unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Raids section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[spell:458572]]
  
  - Gain 1 charge of  [[spell:195181]] when pulling an enemy.
- [[spell:219786]]
  
  - While above 5 charges of [[spell:195181]] your [[spell:49998]] costs less Runic Power.
- [[spell:273946]]
  
  - [[spell:50842]] gives you stacks to improve your [[spell:49998]]. The more enemies you hit the more beneficial this is.
- [[spell:377637]]
  
  - Reduces the cooldown of your [[spell:49028]].
- [[spell:377668]]
  
  - Duplicating [[spell:49028]] magnifies this cooldown's potency.
- [[spell:374737]]
  
  - With this, you now can have a maximum of 12 charges of  [[spell:195181]].
- [[spell:205723]]
  
  - This provides a huge cooldown reduction for your [[spell:55233]].
- [[spell:114556]]
  
  - A Cheat Death every 4 minutes.

#### Class Tree

- [[spell:374277]]
  
  - Very important talent to make your [[spell:49998]] much stronger.
- [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]
  
  - Enables ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] to cleave more targets and extend your ‍[[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] duration. Details in the Deep Dive.
- [[spell:205727]]
  
  - Lowers the cooldown of your [[spell:48707]] and makes it stronger.
- [[spell:194878]]
  
  - With this, you obtain a new buff to upkeep.
- [[spell:391566]]
  
  - This reduces the enemy's attack speed and is more or less your Raid buff.
- [[spell:457574]]
  
  - Increases the cooldown of ‍[[spell:48707]] by 20 seconds.
  - Also makes it so that you can use ‍[[spell:48707]] to remove magical debuffs when activated.
- [[spell:356367]]
  
  - This grants you an additional charge of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]][[spell:49576]] and [[spell:48265]] making them easier to use and juggle correctly.

:::

:::tab Defensive Build
:::talents **Blood Death Knight** Raid Defensive Build
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAwYmZmZMjZGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAwYmZmZMjZGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### When to use this spec

The more defensive option of the 2 builds, recommended for progress or if you do not feel too safe yet!

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** When you [[spell:49998]], gain a stack of [[spell:1310372]]. When [[spell:1310372]] reaches 10 stacks, your next [[spell:195182]] consumes it granting 10% Strength for 10 sec.
- **4-Set:** When consuming [[spell:1310372]], your next [[spell:195182]] generates 3 additional [[spell:195181]] and deals Shadow damage to your target and nearby enemies.

### Opener

- The Goal of your opener is to make sure you gain the benefit of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] while also reaching max stacks of [[spell:232049]] with [[spell:49028]]. Additionally you want to gain as much runic power as possible to always be ready to [[spell:49998]].

:::rotation **Blood Death Knight** Opener Raid
```json
{
  "source_code": "IgFkKIQApCACQJXZtAVdsxGACwt-CAgACgftAEAnuOAAAAAACR4vAEACIIgmGHgDI4m-CEgDMIkTDDQABwgQn7pBBgAACkgHkcunGAAAAAgQONM"
}
```
1. [[spell:43265]] Pre-Pull
2. [[spell:195292]]  [[spell:46584]] · [[item:241308]]
3. [[spell:49028]]
4. [[spell:50842]]
5. [[spell:195182]]
6. [[spell:49998]]
7. [[spell:433895]]
8. [[spell:50842]]
9. [[spell:433895]]
10. [[spell:49998]]
:::

- [[spell:195292]] has a travel time and should be cast while running in for the pull.

### Priority List

This is the standard priority list, follow this unless a Boss or scenario requires you to hold some abilities listed here. You can learn more about when to hold cooldowns in the **Raids** section.

1. Never drop your [[spell:195181]]! Use [[spell:195182]] or [[spell:195292]] to keep it active.
   
   - Maintain 5+ Stacks of [[spell:195181]] to make use of [[spell:219788]], dropping below 5 is ok if [[spell:49028]] is coming up soon.
2. Cast [[spell:46585]] on cooldown for some extra damage.
3. Keep up your [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] buff, check out the Deep Dive section for more info.
4. Cast [[spell:49028]] on cooldown.
5. Spend Runic Power on [[spell:49998]] when you are about to overcap or [[spell:391477]] is about to fade.
6. Cast [[spell:433895]] to gain Runic Power.
7. Cast [[spell:274156]] if talented, on cooldown and always after your [[spell:49028]] has run out.
8. Cast [[spell:50842]] to avoid overcapping on stacks.
9. Cast [[spell:79885]] to consume runes as a filler.

### Defensive Cooldowns

- [[spell:55233]] 
  
  - Most of the time you want to use Vamp Blood as much as possible when you take any form of damage. Holding it is only really required if you need to survive a big hit or are about to have downtime on the Boss, and it can't get full value.
- [[spell:49028]]
  
  - Generally use this on cooldown unless you need the parry for some special situation, more detailed info is in the **Deep Dive** below.
- [[spell:48707]]
  
  - One of the strongest defensives when it comes to magic damage. In general, it can be used when taking magic damage, in a lot of scenarios delaying it and using it to immune mechanics is the best usage this ability can have. Make sure to keep an eye out during the specific sections on what to immune and how to make the most out of [[spell:48707]].
- [[spell:48792]]
  
  - An amazing defensive for general damage reduction, use this as much as possible in a fight without overlapping it with other cooldowns unless it's needed. It can also be held to immune a stun mechanic, but this is rather rare.
- [[spell:49039]]
  
  - Extremely minor defensive that provides you 10% Leech which makes it a good button to press when you just need a little bit of help, in an AoE scenario it becomes more worthwhile since leech is really strong in AoE. Also, if you get feared for some reason, press it!

## Deep Dive

### Death Strike Healing and Absorb

[[spell:49998]] is what makes you a **Blood Death Knight**. This ability is the core of your class! Understanding how it works and how to properly use it is very important for maximizing your damage, staying alive, and being the best tank out there through your incredible self-sustain.

- [[spell:49998]] heals you for a % of your maximum HP and the healing is increased this healing based on your damage taken in the last 5 seconds. This makes Death Strike an ineffective source of healing when you haven’t taken a meaningful amount of damage in the last 5 seconds.
  
  - Environmental and friendly fire damage are not counted in the damage taken formula and are the main cause of self-healing issues. Environmental damage can come from a lot of sources such as Boss room AoE damage, and affix damage like Storming.
- Your healing from [[spell:49998]] is now multiplied by a lot of different abilities and stats:
  
  - Versatility is a multiplier for [[spell:49998]] healing.
  - [[spell:273953]] also increases your [[spell:49998]] healing as well as your [[spell:77513]] value.
  - [[spell:273946]] only multiplies your [[spell:49998]] healing, but does not increase the size of your [[spell:77513]].
- [[spell:77513]] is the other important mechanic of [[spell:49998]]:
  
  - The generated Shield from [[spell:77513]] is based on the full healing value which includes overhealing.
  - The absorb is purely physical and does not work on magic damage at all.
  - The absorb is increased by your Mastery stat value.
  - [[spell:273953]] increases the Healing and value of your Shield, whereas [[spell:273946]] does not.
  - The maximum value that [[spell:77513]] can have is your max HP. This dynamically updates with HP buffs such as [[spell:55233]] and [[spell:97462]] for example.

### Managing Death Strike

Now that you learned how [[spell:49998]] works, let's talk about how to use it to gain the most damage and survivability out of it.

- For damage, you want to use [[spell:49998]] when you are getting close to overcapping your Runic Power or when you can afford to spend all your Runic Power to just do damage to a target.
- If you want to use [[spell:49998]] properly to heal up or counter certain mechanics, it all comes down to a good gameplay flow:
  
  - Take your damage taken in the last 5 seconds into account when [[spell:49998]] is being used. Most of the time you want to [[spell:49998]] after tank mechanics or taking a lot of damage. This benefits you with both a big heal and big absorb shield right after using [[spell:49998]].
  - Most of the time, using 2 [[spell:49998]] back to back is not a good idea since using 1 already tops you and gives you a big absorb. There are scenarios where you would want to use [[spell:49998]] back to back, but they are rarer than just using 1 with precise timing.
  - Timing [[spell:49998]] correctly against magic damage is very important, since your [[spell:77513]] does not help you at all against this type of damage.
  - Stacking up the absorb to be ready for tank mechanics can be quite handy but often comes at a great cost since generating big shields takes a long time if you don't take enough damage to feed into your [[spell:49998]] healing.

With all this info you are ready to fully understand and utilize [[spell:49998]] to the max. Always keep in mind tanking is not set on a rotation or rigid flow of abilities, getting a good gameplay flow going and having proper [[spell:49998]] usage comes with experience and practice.

### Death and Decay Optimization

- Since Midnight Patch 12.0, maintaining high uptime on [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] is not as important for you as it was before, it still buffs both your damage and healing done as a **Blood Death Knight** because of [[spell:391458]] and gives you extra benefits via [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]].

- The main idea is to always use [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] whenever it's not active, and you have it off cooldown. [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] grants you a lot of extra duration and quality of life benefits for your [[spell:43265]].
- Here are the advantages provided by [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]:
  
  - You walk out of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] and retain the benefits for 4 seconds.
  - [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] duration runs out and this buff appears afterwards.
  - Walking in and out of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] always refreshes the buff regardless of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] duration.

- Due to [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] giving you another 4 extra seconds of [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] the rotation to upkeep this effect is very nice and smooth even without [[spell:356367]].
  
  - The average uptime without [[spell:356367]] is around 93% which is already very good.
  - With [[spell:356367]] you never drop the [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] buff when playing correctly.

- Here is a timeline of how a good [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] usage with [[spell:316916@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]] looks. Just pressing it off cooldown.

:::timeline **Blood Death Knight** Death and Decay Raid
```json
{
  "source_code": "H4FT2Z3_8AQIEww_eAAAOAAD_7xDA0RAHggHAwSAHgSLAsDAEIQApCAAAEgBA8QBGAgHFYAKtAABCRf1EAAAZAQCIAgCNgAKoAgQ0XNBAAwNAEA"
}
```
总时长：60 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:43265]] | 上轨 |
| 10 秒 | [[spell:316916]] | 下轨 |
| 15 秒 | [[spell:43265]] | 上轨 |
| 25 秒 | [[spell:316916]] | 下轨 |
| 30 秒 | [[spell:43265]] | 上轨 |
| 40 秒 | [[spell:316916]] | 下轨 |
| 45 秒 | [[spell:43265]] | 上轨 |
| 55 秒 | [[spell:316916]] | 下轨 |
:::

### Dancing Rune Weapon

[[spell:49028]] is one of the most important spells in the **Blood Death Knight's** arsenal and has a lot of things that are not that obvious at first!

It is essential for both damage and defensive value when playing the class, and these are the key features you should know about the ability.

- The Weapon more or less counts as an untargetable "guardian" and always follows the target you used the ability on. This means when that target dies it follows you and attacks your current target.
- [[spell:49028]] spawns behind the target so it can pull more enemies when used on far away targets.
- Each weapon you summon duplicates certain spells and gives you the benefits, so let's talk about them:
  
  - [[spell:195182]] grants you 9 Stacks of [[spell:195181]] (3 Stacks per weapon).
  - [[spell:195292]] grants you 6 Stacks of [[spell:195181]] (2 Stacks per weapon).
  - [[spell:79885]] grants you 15 Runic Power instead of 5 (each weapon casts [[spell:79885]] generating 5 Runic Power).
  - [[spell:50842]] now applies 3 individual debuffs of [[spell:55078]] (1 Debuff per weapon extra) the health transfer does not increase you still only benefit from your own [[spell:55078]].
    
    - The same goes for [[spell:55078]] applied from [[spell:195292]].
  - [[spell:49998]] does more damage as the ability is copied by the weapon but the heal is not increased.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to **Heroic Bosses**. Mythic tips are going to be released after our progression concludes.

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zeli
:::talents **Blood Death Knight** Raid Nek'Zeli
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### Tank mechanics

- The main tank mechanic of this fight is Hollowing Strikes - a debuff that the boss applies with each melee strike, as well as with [[spell:1284103]].
- During [[spell:1284103]], the boss sends spectral echoes towards the active tank, applying extra stacks of Hollowing Strikes. These echoes burst on first impact with any player, dealing reduced raid 
  
  - When targeted by this mechanic, move out of the raid and make sure no one is standing between you and the boss so they don't trigger the echoes too early. Otherwise, they will deal too much damage to the raid.
  - Taunt swap after each cast of [[spell:1284103]].
- Apart from that, the boss will spawn waves of Restless Amani - make sure to move the boss next to them to allow for better cleave.
- During the intermission, the active tank will be targeted by a group soak - [[spell:1289855]]. Try to put it on top of as many Restless Amani corpses as possible to burn them with [[spell:1289875]] to prevent them from awakening again.

:::

:::tab Entombed Sentinals
:::talents **Blood Death Knight** Raid Entombed Sentinals
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### Tank mechanics

- The bosses have to always be separated by at least 40 yards due to [[spell:1290189]]. At the start of each phase, split the bosses apart by moving them to different sides of the room.
- [[spell:1284458]] and [[spell:1284487]] are the stacking tank debuffs of each of the bosses. Make sure to taunt swap on the bosses each time they meet in the middle of the room during [[spell:1284588]] to reset your stacks.
  
  - [[spell:1284487]] additionally creates a large pool of blood upon expiration. Make sure to drop it off at the edges of the room if possible.
- Don't tank Breath of Ula'tek too close to the existing blood puddles so the [[spell:1284251]] doesn't spawn in the pool and melees can safely attack it.

:::

:::tab Lost Explorers
:::talents **Blood Death Knight** Raid Lost Explorers
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### Tank mechanics

- All three bosses cannot be positioned within 30 yards of each other due to [[spell:1297645]] - always keep one of the bosses away from the other 2.
- Trader Gebbo just wanders around the room and doesn't follow or attack its threat target. It also doesn't have any tank mechanics.
- Scrollsage Iku casts [[spell:1295854]] at its current target - a series of ice shards, each doing magic damage and increasing damage taken from the next shard for 80 seconds.
- First Mate Nama applies [[spell:1291929]] with each attack to its target, increasing physical damage done to that target for 30 seconds.
- The job of the tanks on this fight is to swap between Scollsage Iku and First Mate Nama, never letting [[spell:1295854]] to be casted at the same target twice and resetting [[spell:1291929]] as often as possible, while always keeping one of the bosses far enough to prevent [[spell:1297645]] from being applied.

:::

:::tab Vashnik
:::talents **Blood Death Knight** Raid Vashnik
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### Tank mechanics

- There are 3 fountains placed on the sides of the room: Fountain of Blood, Fire, and Shadow. The boss will activate the two closest ones with [[spell:1283164]] throughout the fight, gaining their powers and spawning some adds.
  
  - Each fountain activation empowers the next activation for 1.5 minutes.
  
  
  
  - Your job as a tank is to never let the boss activate the same two fountains in a row by moving the boss to the next fountain before each [[spell:1283164]] cast.
  - Make sure to position the boss on top of the adds coming from the fountain for better cleave. However, be careful with quickly killing all the fire adds, as they apply stacking [[spell:1285979]] when they die.
- Vashnik's tank hit is [[spell:1280935]], taunt swap after each cast.

:::

:::tab Sszorak
:::talents **Blood Death Knight** Raid Sszorak
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### Fight mechanics

- [[spell:1277025]] is a combination of tank frontals consisting of 2 [[spell:1277002]], 2 [[spell:1277027]], and one [[spell:1287072]], cast in a random order.
  
  - [[spell:1277002]] is a frontal cone that deals heavy physical damage and follows the active tank. Make sure to aim it **away from the raid**.
  - [[spell:1277027]] is a frontal cone that applies a heavy magic DOT, which is reduced by the number of people hit by the cone. Make sure this ability is aimed into one half of the raid, so people can soak it.
  - [[spell:1287072]] spawns a bunch of tornadoes around the boss and sends them outwards at the end of the cast. Make sure you're not under the boss when this happens and dodge the tornadoes.
  - In heroic and mythic difficulties, the boss will cast these in a random order. Since each frontal cone applies a damage taken increase from that ability, make sure that one tank never takes 2 of the same abilities. Keep in mind that you can taunt during the cast so the boss aims the frontal cone at you instead.
- Each cast of [[spell:1306120]] spawns [[spell:1305998]] puddles around the boss. Make sure to move the boss to an edge of the room, ideally opposite the [[spell:1285732]] spawn, so that the puddles get blown off the edge of the room by the winds.
- Apart from that, Sszorak applies a stack of [[spell:1282869]] with each melee attack, increasing physical damage taken by the target. Taunt swapping on each [[spell:1277025]] combo is enough to reset the stacks.

:::

:::tab Twin Fangs
:::talents **Blood Death Knight** Raid Twin Fangs
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### General mechanics

- The entire fight revolves around managing [[spell:1290336]] stacks
  
  - [[spell:1291404]], [[spell:1291478]], getting hit by poison waves, or soaking [[spell:1289201]] applies a stack of [[spell:1290336]].
  - Reaching 10 stacks in Heroic or 9 in Mythic difficulties immediately kills you.
  - It is crucial to dodge as many poison waves as possible while managing how many [[spell:1289201]] you soak to prevent reaching maximum stacks of this debuff.

### Tank mechanics

- Being outside of melee range of the boss that you're actively tanking will cause it to cast [[spell:1295107]] or [[spell:1295113]], so make sure to never leave melee or use a big personal if you ever find yourself far from the boss.
- Vexhul's tank ability is [[spell:1289192]], which deals nature damage and pushes you back for 5 seconds.
  
  - It also spawns [[spell:1289201]] around you. These need to be soaked by players before they explode to prevent everyone from getting an [[spell:1290336]] stack.
  - Each hit applies [[spell:1310360]], so taunt swap between every [[spell:1289192]] cast.
  - Be aware of the pushback, especially when the poison waves are coming!
- Ithraz casts [[spell:1288538]], pushing back players close to the boss and spawning 3 soak zones.
  
  - Each zone deals heavy physical damage and increases the damage taken from the next zone by 33%. If it is left unsoaked, it deals raid-wide damage and knocks everyone away. Make sure to taunt swap between each set of [[spell:1288538]] to reset the stacks of the damage increase.
  
  
  
  - The zones spawn in a random order and need to be soaked in the same order that they spawned. Pay attention to the spawns and memorize the spawn order when this ability is happening. The boss will also shortly face towards the zone it will trigger next, so you can use that direction if you can't remember the spawn order.
  - Each second [[spell:1288538]] cast overlaps with poison waves coming - make sure you're not getting hit by waves while soaking the [[spell:1288538]].
  - Watch out for the pushback at the start of this mechanic, as it can push you into an incoming wave or a [[spell:1289201]].

:::

:::tab Coiled Altar
:::talents **Blood Death Knight** Raid Coiled Altar
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### Phase 1

- Only Zul'jan is active during this phase.
- He casts [[spell:1299960]], which spawns multiple [[spell:1282403]] orbs during this phase. They deal pulsing raid-wide AOE while they're active, and can be picked up and moved by players running into them.
- [[spell:1299684]] is a frontal cone aimed at the active tank that deals physical damage and destroys any [[spell:1282403]] it hits.
  
  - It also increases damage taken by the next [[spell:1299684]] by 200%, so make sure to taunt swap after every cast.
- The goal of this phase is for the raid to group up the [[spell:1282403]] orbs so they can then be destroyed by [[spell:1299684]].
- Additionally, each cast of [[spell:1282487]] empowers the next 23 melees of the boss with [[spell:1300322]], dealing extra nature damage to the tank. 
  
  - Make sure to frontload defensives while the boss has stacks of [[spell:1300322]].

### Phase 2

- Only Hex Lord Malacrass is active during this phase.
- He casts [[spell:1285640]], which mind-controls selected players, and spawns 2 [[spell:1285842]] per player when the mind control is broken.
  
  - The Manifestations fixate on random players, moving towards them, unless the fixated player looks back at the Manifestation.
- Similar to [[spell:1299684]] in Phase 1, [[spell:1286620]] is a frontal cone aimed at the active tank that deals shadow damage and destroys any [[spell:1285842]] it hits.
  
  - It also increases damage taken by the next [[spell:1286620]] by 200%, so make sure to taunt swap after every cast.
  - Additionally, it applies 3 stacks of [[spell:1286837]], which spawn a Soul Fragment per stack that needs to be picked up in order to remove the stack. If the stacks are not cleared before the debuff expires, the affected player immediately dies.
  - It is important to pay extra attention to finding and collecting all Soul Fragments quickly after each tank frontal.
- Getting hit by a [[spell:1286895]] also applies 3 stacks of [[spell:1286837]]. Don't let it catch you off guard!

### Intermission

- Malacrass takes 100% extra damage while casting [[spell:1287685]].
- Don't let any Fragments of Malacrass reach the boss by soaking them to prevent them from healing the boss.
  
  - Soaking each fragment deals raid-wide AOE damage, so don't soak them too quickly to give your healers some time to react to the incoming damage.

### Phase 3

- During this phase, both Zul'jan and Malacrass are active, combining their abilities from Phases 1 and 2.
- Both [[spell:1299960]] and [[spell:1285640]] happen in this phase, meaning both [[spell:1282403]] and the [[spell:1285842]] need to be cleared by the tank frontal.
- The tank frontal cone of this phase is [[spell:1307279]], which deals shadow damage, destroys any [[spell:1282403]] and [[spell:1285842]] hit by it, and applies 3 stacks of [[spell:1286837]].
  
  - Don't forget to collect your Soul Fragments and taunt swap after each cone!
- [[spell:1298381]] is the empowered verision of [[spell:1282487]] from phase 1.
  
  - In this phase, the empowered melee attacks additionally apply a **stacking** shadow DOT. Use big defensives when reaching high stacks.

:::

:::tab Ula'tek
:::talents **Blood Death Knight** Raid Ula'tek
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents **Blood Death Knight** Raid Nymrissa Wavecaller
```json
{
  "source_code": "CqPAPMFb_SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM",
  "code": "CqPAPMFb/SlrF4ON4GtDAdVVKyMzyYmxMmxMMbzMz0MbmZmxMGAAAAYmxMzMjZYGjZAwMzMzAAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGM"
}
```
:::

### General mechanics

- The boss targets random players with Chilling Frost, which drops Frost Orbs under their feet.
  
  - These orbs need to get soaked before they explode and wipe the raid.
  - Soaking an orb applies a stacking debuff that increases the damage taken from soaking Frost Orbs, so don't soak too many in one go.
  - Each orb soak also deals raid-wide AOE, so don't soak them too quickly to give your healers some time to react to the incoming damage.
- Occasionally, murlocs will spawn from the water and start walking towards the bubble in the middle of the room.
  
  - Don't let them reach the bubble, and move the boss on top of them whenever possible to allow for better cleave.

### Tank mechanics

- A tank-only mechanic of the fight is the Iceblade Flurry - a series of magic slashes, with each slash increasing the damage of the following ones.
  
  - Use a defensive for each cast and taunt swap after each one.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Blood Death Knight**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Blood Death Knight** Raid Stats
```json
{
  "source_code": "IoAJFQAJoASMBIQACA"
}
```
**力量 ＞ 急速 ＝ 全能 ＞ 暴击 ＝ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, Leech is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
Avoidance is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

:::tabs
:::tab Overall BiS
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271474@DiQAAoPAvj74PrTOC4UA]] | The Twin Fangs |
| Neck | [[item:268265@BERAAoPAX164PrTOCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271472@DgQAAoPA1k7kjAOF]] | The Lost Explorer |
| Cloak | [[item:239656@FgQAAoPAVA8Yiqzt1sUA]] | Crafting |
| Chest | [[item:268222@DgQAAoPAJk7kjAYF]] | The Coiled Altar |
| Wrist | [[item:237834@FCRAAoPAVA8Yiqj_sOAAwt1sUA]] | Crafting |
| Gloves | [[item:271475@BgQAAoPA5IgTBA]] | Entombed Sentinels |
| Belt | [[item:268259@BiQAAoPA-z6kjAYF]] | The Coiled Altar |
| Legs | Convert [[item:271878@BARAAoPACKgF2gVA]]  <br>into [[item:271473@DARBAoPAhu7kjAWYDWBYgJE]] | Catalyst of Ula'tek |
| Boots | [[item:273777@DgQAAoPAPk7IoAOF]] | Altar of Fangs |
| Ring 1 | [[item:159459@DiQAAoPAvk74PrjgC4UA]] | Kings' Rest |
| Ring 2 | [[item:252258@DiQAAoPAvk74PrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270175@BgQAAoPA5IAWBA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAoPA5IAWBA]] | The Coiled Altar |
| Weapon | [[item:268213@RgQAAoPAVyPB5IAWBA]] | The Coiled Altar |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239050@BgQAAoPACKQQBA]] | Kings' Rest |
| Neck | [[item:251173@BgQAAoPACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:239037@BgQAAoPACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAoPACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251193@BgQAAoPACKQQBA]] | The Blinding Vale |
| Wrist | [[item:159425@BgQAAoPACKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:251221@BgQAAoPACKQQBA]] | Voidscar Arena |
| Belt | [[item:159418@BgQAAoPACKQQBA]] | Kings' Rest |
| Legs | [[item:159435@BgQAAoPACKQQBA]] | Temple of Sethraliss |
| Boots | [[item:273777@BgQAAoPACKQQBA]] | Altar of Fangs |
| Ring 1 | [[item:159459@BgQAAoPACKQQBA]] | Kings' Rest |
| Ring 2 | [[item:251148@BgQAAoPACKQQBA]] | Den of Nalorakk |
| Trinket 1 | [[item:250244@BgQAAoPACKQQBA]] | Den of Nalorakk |
| Trinket 2 | [[item:250228@BgQAAoPACKQQBA]] | Murder Row |
| Weapon | [[item:251181@BgQAAoPACKQQBA]] | The Blinding Vale |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids and Delves. Do note that the trinkets recommend above are for optimal damage, if you do not care about your damage and only want to survive I would recommend you to use a trinket like [[item:270160@BgQAAoPACKgTBA]].

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAAoPA5IAWBA]]  <br>[[item:270173@BgQAAoPACKAWBA]] |
| **A-Tier** | [[item:270160@BgQAAoPACKgTBA]]  <br>[[item:270164@BgQAAoPACKgTBA]]  <br>[[item:270165@BgQAAoPA5IgTBA]]  <br>[[item:270174@BgQAAoPACKgTBA]] |
| **B-Tier** | [[item:270163@BgQAAoPACKgTBA]]  <br>[[item:273795@BgQAAoPACKgTBA]]  <br>[[item:250243@BgQAAoPACKgTBA]]  <br>[[item:250244@BgQAAoPACKgTBA]]  <br>[[item:250228@BgQAAoPACKgTBA]]  <br>[[item:193762@BgQAAoPACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAoPACKgTBA]]  <br>[[item:159618@BgQAAoPACKgTBA]]  <br>[[item:250229@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:193757@BgQAAoPACKgTBA]]  <br>[[item:273797@BgQAAoPACKgTBA]] |
| **Junkyard** | [[item:250238@BgQAAoPACKgTBA]]  <br>[[item:250259@BgQAAoPACKgTBA]]  <br>[[item:158367@BgQAAoPACKgTBA]]  <br>[[item:270168@BgQAAoPACKAWBA]] |

### Embellishments

- 2x [[item:240166@BAAAAoP]] on either cloak, wrists, belt or boots.
  
  - Nice passive primary stat buff.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324@BAAAAoP]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884@BAAAAoP]]
- **Weapon Stones**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *-- Unique, can only be used once.*
  - [[item:240894@BAAAAoP]]
  
  
  
  - [[item:240916@BAAAAoP]]

### Enchantments

:::columns
:::column
| Head | [[item:243949@DAAAAwQAZbAB]]  <br>*[[item:275707@DAAAAoPAvj7A]]* |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | *[[item:275707@DAAAAoPAvj7A]]* |
| Belt | *[[item:275707@DAAAAoPAvj7A]]* |
| Legs | [[item:244641@BAAAAwQA]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244017@BAAAAwQA]] |
| Ring 2 | [[item:244017@BAAAAwQA]] |
| Weapon | [[spell:326801]] |

:::

:::column
:::gear **Blood Death Knight** Raid
```json
{
  "source_code": "IQFZ6DQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAx0AEoETuDAAAAAgQRyPB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244017]] |  |
| 戒指二 | [[item:244017]] |  |
| 主手 | [[spell:326801]] |  |
:::

:::

:::

> *You buy ‍[[item:275707@DAAAAoPAvj7A]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Blood Death Knight** in Raids, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- **[[spell:65116]]** -- Dwarf
  
  - Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  - On top of that using Stoneform gives you 10% physical DR which can be used as a small extra 8 second personal when tanking.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
  - Maximum range of 100 yards.

### Recommendation

As a tank picking a racial for damage is a small gain that it's not worth it most of the time. If you care about min-maxing your DPS go with the highest DPS racial.

That being said the recommended race for Raid tanks is **Dwarf** for the on-use physical damage reduction and the ability to self-dispel when needed. These uses are insanely strong and should not be undervalued!

## Macros

Discover recommended macros for **Blood Death Knight** for Raids and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:56222]]* at your target or your mouseover (very handy to pick up mobs)

```wow-macro
#showtooltip Dark Command
/cast [@mouseover,exists,harm][@target,exists,harm] Dark Command
```

Boss 1 Taunt --- *Casts* [[spell:56222]] on Boss1

```wow-macro
/cast [@boss1] Dark Command
```

Boss 2 Taunt --- *Casts* [[spell:56222]] on Boss2

```wow-macro
/cast [@boss2] Dark Command
```

:::

:::details Mouseover Macros
Chains of Ice --- *This macro either casts [[spell:45524]] at your target or your mouseover*

```wow-macro
#showtooltip Chains of Ice
/cast [@mouseover,exists,harm][@target,exists,harm] Chains of Ice
```

Mouseover Grip --- *Casts [[spell:49576]]* at your mouseover target

```wow-macro
/show tooltip
/use [@mouseover] Death Grip
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

Mouseover Battle Res --- *This makes it so you can use [[spell:61999]]* as mouseover on your frames

```wow-macro
#showtooltip Raise Ally
/cast [@mouseover,help,dead][]Raise Ally
```

:::

:::details Focus Macros
Focus Grip --- *Casts [[spell:49576]]* at your focus target

```wow-macro
/show tooltip
/use [@focus] Death Grip
```

Focus Kick --- *Casts [[spell:47528]]* at your focus target

```wow-macro
#showtooltip Mind Freeze
/cast [@focus,harm,nodead][] Mind Freeze
```

Mouseover Focus --- *This macro sets your mouseover as your focus*.

```wow-macro
/focus [@mouseover]
```

:::

:::details Utility Macros
AMZ Macro --- *Casts [[spell:222791]]* at your Cursor position

```wow-macro
/cast [@cursor] Anti-Magic Zone
```

DND Macro --- *Casts [[spell:43265@FJgCJIVAJ7SAwchAFgnAOunAlwvABfbBwzTAtzwBuzwBGA]]* under your character

```wow-macro
/cast [@player] Death and Decay
```

Mass Grip Macro --- *This casts [[spell:108199]]* either at your mouseover or character

```wow-macro
#showtooltip Gorefiend's Grasp
/cast [@mouseover,exists,nodead][@player] Gorefiend's Grasp
```

Control Undead *--- This allows you to recast control undead without targeting your pet.*

```wow-macro
/target pet
/run PetDismiss()
/use Control Undead
/petassist
```

Cancelaura BoP --- *This cancelaura's [[spell:1022]] on you very useful to have when playing with a paladin ever*

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Blood Death Knight**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Death-Knight-Raid-Interface-1024x606.png>)

**Blood Death Knight** Interface in Raids

:::accordion
:::details Addons
- **ElvUI *-- Full User Interface replacement*** 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- [](<https://www.curseforge.com/wow/addons/shadowed-unit-frames>)**BigWigs** -- Generic Boss Mod
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring and a lot of customization options.
- **Details** -- In-depth Damage Meter
  
  - Makes your damage meter look more handsome.
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for raiders, especially for raid leaders and officers.ditions.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
Death Knight

- Hero Talents
  
  - San'layn
    
    - Blood Beast auto-attack damage increased by 1400%.
    - Blood-Soaked Ground now reduces physical damage taken by 8% (was 5%).
- Blood
  
  - Apex Talent: Dance of Midnight (Rank 2) has been updated – Damage taken for each active Dancing Rune Weapon is reduced by 6% (was 4%).
  - Melee damage increased by 20%.
  - Heart Strike damage increased by 25%.
  - Marrowrend damage increased by 50%.
  - Dancing Rune Weapon now increases Parry by 30% (was 25%).
  - Permafrost grants a shield equal to 50% of damage dealt (was 40%).
  - Voracious grants 15% Leech (was 12%).
  - Relish in Blood healing increased by 25%.
  - Rapid Decomposition increases Blood Plague healing by 85% (was 50%).
  - Sanguinary Burst heals you for 18% of damage dealt (was 15%).
  - Umbilicus Eternus absorbs damage equal to 6 times damage dealt by Blood Plague (was 5).
  - Perseverance of the Ebon Blade now reduces damage taken by 4% when consuming Crimson Scourge. Duration increased to 10 seconds (was 6 seconds).
  - Bloodshot now also reduces damage taken while Blood Shield is active by 4%.
  - Hero Talents
    
    - Deathbringer
      
      - Reaper's Mark damage to the primary target increased by 20%.
      - Exterminate damage to the primary target increased by 20%.
    - San'layn
      
      - Pact of the San'layn now stores 15% of all Shadow damage dealt (was 10%).
      - Vampiric Strike damage increased by 25%.
      - Visceral Strength now grants 10% Strength (was 12%).
      - Frenzied Bloodthirst’s Death Strike and Death Coil damage bonus reduced to 5% per stack (was 6%).
      - Blood is Life now accumulates 15% of the damage dealt from the Blood Beast (was 25%).

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: You didn't use [[spell:49998]] correctly or didn't press enough defensives. Make sure to read the **Deep Dive** for more info!

:::

:::

---

### Credits

Written By: **Skövte**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-11** Updated for Patch 12.1

**2026-06-16** Updated for Patch 12.0.7

**2026-04-21** Updated for Patch 12.0.5

**2026-02-26** Updated for Patch 12.0.1

**2026-01-20** Updated for Midnight 12.0

**2025-12-02** Updated for Patch 11.2.7

**2025-10-07** Updated for Patch 11.2.5

**2025-08-05** Updated for Patch 11.2



:::
