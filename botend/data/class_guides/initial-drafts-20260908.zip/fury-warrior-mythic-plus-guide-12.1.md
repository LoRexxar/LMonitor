欢迎来到魔兽世界12.1版本的狂怒战士大秘境攻略！本攻略涵盖了你需要了解的关于角色的所有内容！如果你刚起步，正在从80级练级，请查阅练级攻略！**狂怒 战士**

## 概述

:::columns
:::column
:::rating 大秘境
**单体目标** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 4/5 · 强

机动性 · 4/5 · 强



:::

:::

:::column
:::gear **狂怒 战士** 大秘境最佳配装（BiS）
```json
{
  "source_code": "JYtAwbESAc__BEAYkQggoQAAvj7AH16A8Vjg1YbN2IjgCU8FEEQ6XQAApAAAU06AC06AMWDZ1ghNeVjgCEgXkQgAgAAA1k7A-VTg1EgLgGwYkQgAgUAAJk7A6Vjg1ghNCKAWB47FEEw4XQAggEAA8z6AYYjX1YbNBgBCBYgJFAEEju7AWYTAXAjgCEA5XQAAYAAA2IjXB4AoKE6AAiUAAwQrDY7LjVT0wwgN3Wjt1ccNAMSWisUABEGJEAAIBAwe1EYBrSkTBEgYZPgggEAA1j7A8z6AkVTCHBiTBEQ2XQgggAgOYAAHB81HEAAGCAQC7xRBAEwVXIQAdFAFAAQDUQQAdHwjAEQDOADWBEQtXQgAYAAAFk7AJUDGBgRoDIAOBEQE8Y7LMYzt1sZJLXDAjklILFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271456]] | [[item:240967]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240898]] |
| 肩部 | [[item:271454]] | [[item:244021]] |
| 胸部 | [[item:271459]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240892]] |
| 腿部 | [[item:271878]] | [[item:244643]] |
| 脚部 | [[item:268260]] |  |
| 腕部 | [[item:237834]] | [[item:240908]] |
| 手部 | [[item:271457]] |  |
| 戒指一 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:243973]] |
| 副手 | [[item:237848]] | [[item:243973]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为一名 **狂怒 战士**，你可以使用狂暴肆虐，使[[talent:112277]]伤害提高10%，并使你的[[talent:112277]]触发[[spell:1269349]]，使你的力量提高3%，持续8秒。

**等级2** 使你在[[talent:112281]]期间[[talent:112277]]的怒气消耗降低，并进一步提高[[talent:112277]]的伤害。

**第3级**使你的[[talent:112281]]持续时间延长50%，并且[[talent:112281]]会给予3层[[spell:1269349]]

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-fury-mxr.webp>)

狂暴肆虐

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:136452]]
    
    - [[spell:190411]]和[[talent:112205@FAQAadhA]]在此天赋下若命中至少3个目标，将造成显著提高的伤害。
  
  
  
  - [[talent:136449]]
    
    - 通过[[talent:112265]]的重置，为你的自动攻击提供巨额伤害加成。与[[talent:112255]]配合良好。
  
  
  
  - [[talent:136451]]
    
    - 狂怒战士现在还可以使用[[talent:136451]]，由[[spell:5308]]触发。
- **职业天赋树**
  
  - [[talent:134031@AJQABA]]
    
    - 如果你经常承受大型伤害并善加利用你的[[talent:114644]]，该天赋可提供巨额的生存能力提升。
    - 该天赋的进攻部分仅提供极小的伤害提升，因此与其他选择相比，选取该天赋往往是一种伤害损失。
  - [[talent:136627]]
    
    - 现在还会使12码（或24码）范围内盟友的移动速度提高30%，持续4秒！
  - [[talent:134033]]
    
    - 改进你所有的呐喊技能。
- **已移除**
  
  - [[spell:384318]]
  
  
  
  - [[spell:383762]]

## 英雄天赋

- [[talent:123390]]在单体伤害上领先，而[[talent:123392]]在大多数范围伤害情况下更胜一筹。[[talent:123390]]在单体上的领先幅度远大于[[talent:123392]]在范围伤害上的优势，因此目前推荐将[[talent:123390]]作为默认配置。

### [[talent:123392]]

- [[talent:117400]]
  
  - 你的[[talent:117400]]会造成伤害，并有几率触发[[talent:117404]]。
- [[talent:117404]]
  
  - [[talent:117400]]有较低几率获得一个强大的[[talent:112261]]增益，并暂时移除该技能的冷却时间。
- [[talent:117413]]
  
  - 有了这个特质，[[talent:112205]]相比[[spell:190411]]成为施加[[talent:112298]]并开启顺劈斩的更好方式。
  - 由于[[talent:112205]]非常强力，你在顺劈时几乎不会损失单体伤害，相比之下[[talent:123390]]在这点上不如[[talent:123392]]。
- [[talent:117382]]
  
  - 将你的[[talent:112205]]转化为[[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]]，造成无视护甲的风暴打击伤害。
  - 有几率由[[talent:112261]]触发。
- [[talent:117402]]
  
  - 获取[[spell:435222@FJgCjnqBadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBBEA]]的可靠途径。

#### 12.0 至暗之夜 新增内容

- [[talent:136070@AJQABA]]
  
  - [[talent:112205@FAwAadhAjnqBEMA]] 和 [[spell:435222]] 在 [[talent:112285@AJQABA]] 期间得到显著增强。
- [[talent:136069]]
  
  - 对 [[talent:117400]] 伤害的小幅增强。
- [[talent:136068]]
  
  - 你可以通过使用 [[spell:435222]] 来延长 [[talent:112285@AJQABA]]。通过优先使用 [[spell:435222]]，你可以让 [[talent:112285@AJQABA]] 在大部分时间内保持激活。

### [[talent:123390]]

- [[talent:117411]]
  
  - [[spell:445579]]造成大量伤害并给予[[spell:445584]]增益效果。
- [[talent:117407]]
  
  - 触发[[spell:444775@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]]或使用[[talent:112314]]会施加[[spell:445836]]。
- [[talent:117385]]
  
  - 每第三次[[spell:445579]]会触发一次[[talent:112300]]。这个来自[[talent:117385]]的[[talent:112300]]并不需要你已选择天赋[[talent:112300]]。
- [[spell:444774@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]]和[[spell:444779@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]]
  
  - 在游玩斩杀者时，[[talent:112123]]会造成大量伤害。
- [[talent:117417]]
  
  - 消耗[[talent:112126@AJQA]]会减少[[talent:112314@AJQA]]的冷却时间，减少量取决于你拥有的[[spell:445584]]层数。

#### 12.0 至暗之夜 新增内容

- [[talent:136076]]
  
  - [[talent:112314@AJQA]] 会给予你一个急速增益。
- [[talent:136075]]
  
  - 延长 [[spell:445584]] 的持续时间。
- [[talent:136074@AJQA]]
  
  - 在《地心之战》中 [[talent:136074@AJQA]] 位于职业天赋树中，但现在它是英雄天赋。

## 天赋

### [[talent:123389]] 顺劈斩 / 范围伤害

:::talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 何时使用该专精

将此天赋配置作为你的默认选择，它比[[talent:123392]]配置更侧重单体，但在大多数情况下都值得使用。

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

##### 专精树

- [[talent:112284@AJQABA]]
  
  - 在 范围伤害 和单体情况下都能造成高额爆发伤害。
- [[talent:136735]]
  
  - 使你进入激怒状态并造成可观的 范围伤害 伤害。
  - 如果你拥有 [[talent:112270]]，则造成更高伤害。
- [[talent:119139@FAQAN3gB]]
  
  - 显著增强你的 [[talent:112261]] 和 [[talent:112265@FAQAutdB]]，但仅在 [[talent:112281@FAQAN3gB]] 期间生效。

##### 职业树

- [[talent:134032@AJQABA]]
  
  - 提升你的进攻冷却技能的可用性，冷却缩减基于所消耗的怒气。
- [[talent:112188]]
  
  - 由于新天赋[[talent:134033]]，在至暗之夜中是一个略微更强的团队冷却技能。
- [[talent:136627]]
  
  - 现在在至暗之夜中会为你和你的盟友提供短暂的移动速度提升。
- [[talent:112253@AJQABA]]
  
  - 偶尔可以作为非常强力的进攻手段，将伤害反弹给敌人。很多时候目标无法被反弹，但你仍然能获得一个不错的防御增益，使受到的魔法伤害降低20%。
- [[talent:114644]]
  
  - 一个几乎完全没有冷却的防御技能，但会对你造成的伤害带来惩罚。
- [[talent:112215]]
  
  - 对付吸收护盾时可能非常强力。

### [[talent:123392]] 范围伤害

:::talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDDjZsMzMzMjZMzMzMzYmlZmxMjZZMzMAAQYgNYZzoxMgMbYGLAmhZWAgZGADzixAGD",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDDjZsMzMzMjZMzMzMzYmlZmxMjZZMzMAAQYgNYZzoxMgMbYGLAmhZWAgZGADzixAGD"
}
```
:::

#### 何时使用该专精

如果你主要关注高顺劈和范围伤害伤害，并愿意为此牺牲单体伤害，请使用此天赋配置。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 英雄天赋树

- 从[[talent:123389]]换成了[[talent:123392]]。

##### 专精树

- **新增**
  
  - [[talent:112271]]
  - 2x [[talent:112292]]
  - [[talent:136448]]
  - [[talent:136454]]
- **移除**
  
  - 2x [[talent:112296]]
  - [[talent:136449]]
  - [[talent:136735]]
  - [[talent:136453]]

##### 职业树

- **新增**
  
  - [[talent:112205@FAgAadhAjnqB]]
  - [[talent:118853]]
- **移除**
  
  - [[talent:112198]]
  - [[talent:112190]]

### [[talent:123392]] RB 范围伤害

:::talents
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDDzMjlZmZmZYMzMzMzYmlZmxMjZxMzMAAQYgNYZzoxMgMbYGLAmhZWAgZGAGzixAGD",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDDzMjlZmZmZYMzMzMzYmlZmxMjZxMzMAAQYgNYZzoxMgMbYGLAmhZWAgZGAGzixAGD"
}
```
:::

#### 何时使用该专精

如果你想要玩[[talent:123392]]同时仍然重视单体伤害，就使用这个专精。范围伤害伤害比另一种[[talent:123392]]构建低，但单体伤害更高。与[[talent:123389]]构建相比单体伤害明显更低，但范围伤害略高。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 英雄天赋树

- 从[[talent:123389]]换成了[[talent:123392]]。

##### 专精树

- **新增**
  
  - [[talent:136454]]
  - [[talent:112271]]
- **移除**
  
  - [[talent:136735]]
  - [[talent:136453]]

##### 职业树

- **新增**
  
  - [[talent:112205@FAgAadhAjnqB]]
  
  
  
  - [[talent:118853]]
- **移除**
  
  - [[talent:112198]]
  - [[talent:112190]]

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **玉军阀主的统御（2件）：** [[talent:112265]]的伤害提高15%。在[[talent:112281]]期间，[[talent:112265]]会使[[talent:112281]]的持续时间延长2秒，最多延长6秒。
- **玉军阀主的统御（4件）：** [[talent:112261]]的伤害提高10%。在[[talent:112281]]期间，[[talent:112261]]会使[[talent:112281]]的爆击加成提高5%，最多提高10%。

### 单体目标

#### [[talent:123389]]

##### 起手循环

- 起手技能最好用这样的宏来使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation 典型的[[talent:123389]]起手
```json
{
  "source_code": "I8EOJIAAAAAABI0tGAAAAIEZB0AEAAgQvAdBXAhQHo3AAEgHMIDpBAQEOkhHMkPHFAgLuAAC5zRB"
}
```
1. [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:227847]]  [[spell:107570]]
5. [[spell:227847]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:184367]]
9. [[spell:335097]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 使用[[talent:112281@FAQAN3gB]]。  -- 切换至冷却技能优先级列表
2. 在以下任一情况时使用[[talent:112277]]：
   
   - [[spell:184361]]未激活或即将结束。
   - 你的怒气超过100点。
3. 在以下任一情况时使用[[spell:5308]]：
   
   - 你拥有2层[[talent:112301@AJQABA]]，或者[[talent:112301@AJQABA]]即将结束。
   - 你拥有至少2层[[spell:445584]]以及[[talent:112301@AJQABA]]。
   - 你正处于"斩杀阶段"
4. 冷却好了就使用[[talent:136735]]。
5. 冷却好了就使用[[talent:112265@FAQAutdB]]。
6. 冷却好了就使用[[talent:112261]]。
7. 使用[[talent:112277]]。
8. 冷却好了就使用[[spell:1680@FJwCadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTABEA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 在以下情况下使用[[talent:112277]]：
   
   - [[spell:184361]]即将结束，或者
   - 你的怒气超过100。
2. 在触发新的[[spell:184361]]后使用[[talent:112284@AJQABA]]。
3. 在以下任一情况下使用[[spell:5308]]：
   
   - 你拥有2层[[talent:112301@AJQABA]]，或者[[talent:112301@AJQABA]]即将结束。
   - 你拥有至少3层[[spell:445584]]和[[talent:112301@AJQABA]]。
4. 如果你尚未触发4件套提供的两层暴击加成提升，则使用[[spell:335096]]。  *-- 这通常由[[talent:112284@AJQABA]]完成，但如果你的[[talent:112284@AJQABA]]正在冷却中，你就必须手动触发4件套效果。*
5. 如果你拥有[[talent:112276]]，则使用[[spell:335097]]。
6. 使用[[talent:112277]]。
7. 在冷却好了就使用[[spell:335097]]。
8. 如果你处于"斩杀阶段"，则使用[[spell:5308]]。
9. 在冷却好了就使用[[spell:335096]]。

#### [[talent:123392]]

##### 起手循环

- 起手前3个技能最好用这样的宏放在一起使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation
```json
{
  "source_code": "IcEUIIAAAAAACIkNkGAAAI0tGAAAAIEZBMBEAAgQvAdBdggQWQaAXQBAChPHFAgLYAAK5zRBAAAAAIE-cUA"
}
```
1. [[spell:107574]] · [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:435222]]
5. [[spell:335096]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:335096]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 同时使用[[talent:112285@AJQABA]]和[[talent:112281@FAQAN3gB]]。  -- 切换到下方的冷却优先级列表
2. 如果你的 [[talent:112285@AJQABA]] 处于激活状态，使用 [[spell:435222]]。
3. 在以下任一情况使用 [[talent:112277]]：
   
   - [[spell:184361]] 未生效或即将结束。
   - 你的怒气超过100。
4. 如果你拥有 [[talent:112276]]，使用 [[talent:112265@FAQAutdB]]。
5. 在冷却结束后使用 [[spell:5308]]。
6. 使用 [[spell:435222]]。
7. 在冷却结束后使用 [[talent:112261]]。
8. 在冷却结束后使用 [[talent:112265@FAQAutdB]]。
9. 使用[[talent:112277]]。
10. 在冷却结束后使用 [[talent:112205@FAgAadhAEMA]]。
11. 使用 [[spell:1680@FJwCadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTABEA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 同时使用 [[talent:112285@AJQABA]] 和 [[talent:112281@FAQAN3gB]]。
2. 在以下任一情况使用 [[talent:112277]]：
   
   - [[spell:184361]] 未生效或即将结束。
   - 你的怒气超过100。
3. 如果你有2层[[spell:435222]]，使用[[spell:435222]]。
4. 如果你尚未触发4件套带来的暴击加成的两层效果，使用[[spell:335096]]。
5. 如果你有[[talent:112276]]，使用[[spell:335097]]。
6. 在冷却好了就使用[[spell:335096]]。
7. 在冷却好了就使用[[spell:335097]]。
8. 在冷却结束后使用 [[spell:5308]]。
9. 使用[[talent:112277]]。
10. 使用 [[spell:435222]]。

### 多目标

#### [[talent:123389]]

##### 起手循环

- 起手技能最好用这样的宏来使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation 典型的 [[talent:123389]] 多目标起手
```json
{
  "source_code": "I8aAQtgAAAAAAIgQ3aAAAAgQ2QaAAAgQkFwEQDAACt85CUkAMYpMAo1FCgDLB4FUBkC0Co4eCIaiDU0tAQSDHUSDHADMTsMPBEQAAAgQvAtABkDDCdgeDIDCAAwLNgREIgwIgXQBgEBEueGA"
}
```
1. [[spell:1719]] · [[spell:107574]]
2. [[spell:100]]
3. [[spell:190411]]
4. [[spell:184367]]
5. [[spell:227847]]
6. [[spell:227847]]
7. [[spell:184367]]
8. [[spell:184367]]
9. [[spell:385059]]
10. [[spell:184367]]
11. [[spell:190411]]
:::

##### 优先级列表

- 多目标优先级列表与单体优先级列表类似，主要区别在于要始终保持 [[spell:12950]] 处于激活状态。

这是你在整场战斗中力求维持的一般优先级。

1. 如有需要，使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]来施加[[spell:85739]]，使你的单体技能能够进行顺劈。
2. 使用[[talent:112281@FAQAN3gB]]。  -- 切换至冷却技能优先级列表
3. 使用[[talent:112277]]。
4. 冷却好了就使用[[talent:136735]]。
5. 冷却好了就使用[[spell:5308]]。
6. 冷却好了就使用[[talent:112265@FAQAutdB]]。
7. 冷却好了就使用[[talent:112261]]。
8. 使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 如有需要使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]来施放[[spell:85739]]，使你的单体技能获得顺劈效果。
2. 使用[[talent:112277]]。
3. 在触发新的[[spell:184361]]后使用[[talent:112284@AJQABA]]。
4. 在冷却完毕时使用[[talent:136735]]。
5. 如果你拥有[[talent:112301@AJQABA]]，则使用[[spell:5308]]。
6. 如果你尚未触发4件套带来的两层暴击加成的全部层数，则使用[[spell:335096]]。 *——这通常通过[[talent:112284@AJQABA]]配合[[talent:136074@AJQABA]]完成，但如果你的[[talent:112284@AJQABA]]正在冷却中，你就必须手动触发4件套效果。*
7. 使用[[spell:335097]]。
8. 在冷却结束后使用 [[spell:5308]]。
9. 在冷却好了就使用[[spell:335096]]。
10. 使用[[spell:190411@FJADadhA4wSAeBVApAtAKunAim4AFdLAk0wBl0wBwAzELzTAWKDABEA]]。

#### [[talent:123392]]

##### 起手循环

- 起手前3个技能最好用这样的宏放在一起使用：

```wow-macro
/cast 鲁莽
/cast 天神下凡
/cast 冲锋
```

:::rotation
```json
{
  "source_code": "IcEUIIAAAAAACIkNkGAAAI0tGAAAAIEZBMBEAAgQvAdBdggQWQaAXQBAChPHFAgLYAAK5zRBAAAAAIE-cUA"
}
```
1. [[spell:107574]] · [[spell:1719]]
2. [[spell:100]]
3. [[spell:184367]]
4. [[spell:435222]]
5. [[spell:335096]]
6. [[spell:184367]]
7. [[spell:335097]]
8. [[spell:335096]]
:::

##### 优先级列表

- 多目标优先级列表与单体优先级列表类似，主要区别在于要始终保持 [[spell:12950]] 处于激活状态。

这是你在整场战斗中力求维持的一般优先级。

1. 如有需要使用 [[talent:112205@FAgAadhAEMA]] 来施加 [[spell:85739]]，使你的单体技能附带顺劈效果。
2. 同时使用 [[talent:112285@AJQABA]] 和 [[talent:112281@FAQAN3gB]]。   -- 切换到下方的冷却优先级列表
3. 使用[[talent:112277]]。
4. 如果 [[talent:112285@AJQABA]] 已就绪，使用 [[spell:435222]]。
5. 如果 [[talent:112285@AJQABA]] 已就绪，使用 [[talent:112261]]。
6. 如果 [[talent:112285@AJQABA]] 已就绪，使用 [[talent:112205@FAQAadhA]]。
7. 在冷却结束后使用 [[spell:5308]]。
8. 如果你有 [[talent:112276]]，使用 [[talent:112265@FAQAutdB]]。
9. 在冷却结束后使用 [[talent:112261]]。
10. 在冷却结束后使用 [[talent:112265@FAQAutdB]]。
11. 冷却完毕即使用 [[talent:112205@FAQAadhA]]。

##### 冷却技能优先级列表

这是你在[[talent:112281@FAQAN3gB]]期间需要尽量维持的一般优先级。

1. 将[[talent:112285@AJQABA]]和[[talent:112281@FAQAN3gB]]一起使用。
2. 如有需要，使用[[talent:112205@FAgAadhAEMA]]来施加[[spell:85739]]，使你的单目标技能可以进行顺劈。
3. 使用[[talent:112277]]。
4. 在冷却好了就使用[[spell:435222]]。
5. 在冷却好了就使用[[spell:335096]]。
6. 在冷却好了就使用[[spell:335097]]。
7. 在冷却好了就使用[[talent:112205@FAQAadhA]]。
8. 在冷却好了就使用[[spell:5308]]。

## 深入解析

### 延迟使用暴怒

- 在循环中，你有时会延迟使用[[talent:112277]]，只有当需要它来触发[[spell:184361]]时，它才是最高优先级。
- 当你没有达到怒气上限的风险时，积攒更多怒气是有益的，以便获得一份盈余，供之后用来弥补运气不佳的情况，从而使你始终保持[[spell:184361]]处于激活状态。
- 如果你使用[[talent:134032@AJQABA]]，那么消耗怒气本身就很有价值，因为这能提高你爆发技能的覆盖率。你仍然可以延迟使用[[talent:112277]]，但一般来说，如果你有达到怒气上限的风险，就不要延迟。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

**← 向下滚动查看更多副本 →**

### 毒牙祭坛

:::talents [[talent:123389]] 多目标 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 拉维

- 你可以反弹[[spell:1297876]]，如果不去规避它，它可能成为本场战斗中你所受伤害的主要来源。
- 如果你使用了[[talent:112215]]，请务必在**拉维**施放[[spell:1296216]]时使用它。

##### 扭缠盘蛇

- 小蛇和大蛇共享一个生命值池，所以你对小蛇造成的任何伤害都会使大蛇以更低的血量回来。当大蛇离开、小蛇出现时，是使用爆发冷却技能的好时机。第一批小蛇在战斗开始53秒后出现，下一批在90秒后出现。
- 你可以反射[[spell:1299189]]，如果不躲开它，它可能占你在这场战斗中所受伤害的大部分。
- [[spell:1310358]]在只剩1条蛇时必须连续被打断3次，最好与你的队伍协调好，确保3次打断全部有人负责，不要不小心浪费打断技能去抢同一次施法。
- [[spell:1310358]]在有多条蛇时也会施放，不过多条蛇并不是每条都施放3次。

##### 祖尔加

- 在[[spell:1300886]]期间使用[[talent:112253@AJQA]]来降低受到的伤害。
- 在分摊[[spell:1301508]]时使用[[talent:114643]]或[[talent:112264]]。

#### 小怪攻略

- 你可以反弹来自 [[spell:1294568]] 的 **双牙蹂躏者**.
- 你可以反弹来自 [[spell:1289416]] 的 **高阶进化者.**

### 纳洛拉克的洞穴

:::talents [[talent:123389]] 横扫 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 囤宝狂人

- 你可以偏转毒蘑菇施放的[[spell:1234846]]。
- 当**囤宝狂人**施放[[spell:1234681]]或[[spell:1235125]]时，使用[[talent:112264]]或[[talent:114644]]。

##### 寒冬哨兵

- 打断 [[spell:1235829]] 的施法，该技能由 **碎裂的震颤核心.**
- soak [[spell:1263590]] 当你击败 **碎裂的震颤核心**.
- 被击败的 **碎裂的震颤核心** 会留下一个 [[spell:1234314]]，你可以站在其中以免被 [[spell:1235656]] 推退。

##### 纳洛拉克

- 尽量把 [[spell:1242887]] 放在你队友放置的位置旁边，最好都集中在房间的一侧或一个角落。这样当它们活过来追逐 **祖尔加拉** 时，当 **纳洛拉克** 施放 [[spell:1243002]] 时，更容易承受它们的伤害。
- 在 [[spell:1243569]] 期间躲到护盾后面。如果你获得了减益效果 [[spell:1261781]]，就说明你是安全的。

#### 小怪攻略

- 你可以反弹来自 [[spell:1241214]] 的 **地语看护者**.
- 你可以反弹来自 [[spell:1246687]] 的 **雷缚秘法师** 和 **神灵代言人纳尼亚.**

### 密谋小径

:::talents [[talent:123389]] 横扫 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 凯斯媞亚·魔力之心

- 你可以偏转[[spell:1230298]]。
- 当**凯斯媞亚**施放[[spell:1214959]]时，准备好DPS冷却技能。这也是使用防御冷却技能的好时机。

##### 赞恩·刃悲

- 如果你被点 名，使用你的 [[spell:1214352]] 来清除绿色发光的 [[spell:1201553]]。
- 当 **扎恩** 施放 [[spell:474483]] 时，是使用防御冷却技能的好时机。

##### 歼灭者萨祖克斯

- 专注于击杀 **军团大斧** 来自 [[spell:1214663]]，因为只要它存活，[[spell:1214650]]就会对你造成持续增加的大量伤害。它们彼此的刷新间隔略少于1分钟。
- 小心不要踩到 [[spell:474234]]。

##### 利希尔·烬怒

- 通常情况下，这场战斗中你受到的几乎所有伤害都来自被动的 [[spell:1216945]]。因此，只要你受到任何额外伤害，比如小鬼的施法被打进来，或者带着 [[spell:474457]] 与其他人重叠站位，那就是交出防御冷却技能的时机。
- 尽量在使用传送门前解决掉小鬼。

#### 小怪攻略

- 你可以反射 [[spell:1217633]] 由 **巨大的邪能浮龙** 施放的技能。

### 夺目谷

:::talents [[talent:123389]] 横扫 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 光明众花

- 你可以反弹 [[spell:1235616]]，它来自 **科兹齐特。**
- 拦截 [[spell:1235574]]，防止它击中 **光明之花 种子。**
- 当 **梅提克**  施放 [[spell:1276586]] 时注意你的生命值。这是使用防御冷却技能的好时机。

##### 伊库兹，光明猎人

- 当 **伊库兹** 施放[[spell:1236715]]时使用防御技能。
- 如果你使用[[talent:123389]]，你可以用 [[talent:117392]] 和 [[talent:112284@AJQABA]] 打断定身效果。

##### 护光者鲁伊亚

- [[spell:1240098]]下落速度很快，要迅速躲避。
- 你可以和[[spell:1239824]]像素级重叠站位，就不会被[[spell:1239830]]击中。

##### 兹欧凯特

- 不要让球体进入首领体内，否则会引发[[spell:1247039]]爆炸，极有可能导致团灭。
- 吸收球体会获得[[spell:1247052]]，提高造成的伤害，但同时会给你施加一个造成大量伤害的持续伤害效果。

#### 小怪攻略

- 你可以反弹 [[spell:1238063]]，来自 **光耀播法者.**
- 务必打断 [[spell:1238294]] 的施法，施法者是 **光羽瓣翼鸟.** 如果不这样做，很可能会导致团灭，因为队伍会陷入混乱。

### 虚空之痕竞技场

:::talents [[talent:123389]] 横扫 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 塔兹拉尔

- [[spell:1222103]]会造成大量初始伤害，并给你施加一个持续伤害效果。
- 当[[spell:1300259]]被施放时，如果生命值不满，请准备好使用防御技能或治疗药水，它会造成大量范围伤害。它还会产生许多小球，你必须躲避，否则会受到更多伤害。

##### 阿特洛苏斯

- **剧毒蠕行者** 的 [[spell:1222692]] 会造成高额伤害。立刻切换目标攻击它，甚至可以为它保留输出爆发技能。
- 如果 **剧毒蠕行者** 在 **阿特洛苏斯** 施放 [[spell:1300351]] 时还活着，请使用防御技能。

##### 煞戎努斯

- 这场战斗中你受到的主要伤害来自[[spell:1264188]]。
- 战斗中最危险的时刻，是你被与[[spell:1264188]]的持续背景伤害重叠的技能点名时，这时你应该使用防御冷却技能。
  
  - [[spell:1300372]]会造成大量伤害并对你施加一个持续伤害效果（DoT）。
  
  
  
  - 如果你不及时清除你的法力球，你将受到来自[[spell:1287450]]越来越高的伤害。

#### 小怪攻略

- 你可以反制[[spell:1311754]]来自**的法术风暴拉杰克斯。**

### 诸王之眠

:::talents [[talent:123389]] 横扫 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 黄金风蛇

- 当**黄金风蛇**施放[[spell:1311988]]时使用防御冷却技能。
- 不要让**活体黄金**到达首领处，否则他会获得[[spell:265991]]。

##### 殓尸者姆沁巴

- 打断**未完工的木乃伊**施放的[[spell:267763]]。
- 当队友被[[spell:267702]]击中时要迅速把他们救出来。如果陵墓在震动，你就能知道他们在哪里；如果你是被点名的那个人，就使用[[spell:267764]]来提醒队友你的位置。

##### 部族议会

- 一定要帮忙分担[[spell:1310761]]。这是使用防御冷却技能的好时机。
- 打断[[spell:267273]]。
- 击杀**洪流图腾、雷电图腾**以及**爆裂图腾。**

##### 始皇达萨

- 打断[[spell:269369]]，由**莱班**施放。
- **莱班**在战斗开始几秒后出现，而**提扎拉**在**达萨尔**剩余80%生命值时出现。提扎拉和**达萨尔**共享一个生命值池。
- 你在这场遭遇战中所受的大部分伤害来自[[spell:1303267]]，因此那是使用防御冷却技能的好时机。

#### 小怪攻略

- 打断 [[spell:270920]] 的技能，由 **瓦西女王施放。**
- 打断 [[spell:270901]] 的技能，由 **塞内沙·姆巴拉施放**.

### 红玉新生法池

:::talents [[talent:123389]] 横扫 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 梅莉杜莎·寒妆

- 打断 [[spell:372808]]。
- 当 **梅丽莎** 施放 [[spell:396044]] 时，与队友集合会比较好，这样 [[spell:384022]] 会生成在彼此重叠的位置，更容易躲避。
- 最好将 [[spell:372851]] 放在远离首领和队友的地方。
- 在 [[spell:373680]] 护盾存续期间，你受到的伤害会不断增加。

##### 柯姬雅·焰蹄

- [[spell:372863]]会召唤一个**炎缚火焰风暴**。
- 打断[[spell:373017]]，由**炎缚火焰风暴**施放。
- 尽量把[[spell:372107]]引向不会在你的队伍附近爆炸的方向，最好也不会让火焰之后妨碍到你。

##### 基拉卡与厄克哈特·风脉

- 在最后阶段受到 [[spell:381862]] 影响时使用防御技能，因为它会额外选中一名玩家，给治疗带来更大压力，同时注意水潭的放置位置。

#### 小怪攻略

- 你可以反弹 [[spell:384194]]，它来自 **拜荒织烬者。**
- 你可以反弹 [[spell:371984]]，它来自 **闪霜织寒者**。
- 当 **阿什希尔·烈焰鞭笞者**  施放 [[spell:1305865]] 时使用控制技能。
- 当 **原始主宰** 施放 [[spell:1305201]] 时使用防御技能。

### 塞塔里斯神庙

:::talents [[talent:123389]] 顺劈斩 / 范围伤害
```json
{
  "source_code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA",
  "code": "CiEAYyB6EulQT7kdp2SXeCVBkBAAAAAAgGDjxMjlZmZmZMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYsAAAzMMmlhxgxA"
}
```
:::

#### 首领攻略技巧

##### 阿德里斯和阿斯匹克斯

- 确保你的目标是那个没有[[spell:1289229]]护盾的首领。有护盾的那个免疫伤害，而且护盾在谁身上会随战斗交替变化。
- [[spell:1289062]]会迅速把你击退很远，在它即将生效时狂按冲锋。不要被击退进[[spell:1288864]]里，因为它们会使你沉默。

##### 米利克萨

- 如果你被 [[spell:1290031]] 选中，靠近另一名被选中的玩家，最好你们都在首领处汇合。
- 使用 [[talent:112242]] 或 [[talent:134254]] 来清除队友身上由 [[spell:1290031]] 施加的负面效果。
- 当 **梅雷克塔** [[spell:264206]] 横穿战场时要小心，被击中会造成大量伤害并使你眩晕。

##### 加瓦兹特

- 在承担 [[spell:266923]] 时使用防御技能。不要让光束击中并为首领充能，如果他的能量达到100，他就可以施放 [[spell:266512]]，很可能导致团灭。

##### 塞塔里斯的化身

- 吸收来自 [[spell:1300869]] 的腐蚀，使 **塞塔里斯的化身** 能够 [[spell:1302895]]。这个机制更适合由伤害输出者来吸收，而不是坦克或治疗者，因为吸收后会受到治疗效果惩罚，并且所受物理伤害增加。
- 打断 [[spell:1302158]]，该技能由 **扭曲的妖术师.**
- 带着 [[spell:1302153]] 分散。
- **无信折磨者** 锁定你的治疗者，必要时眩晕并减速他们。

#### 小怪攻略

- 你可以反弹 [[spell:1291262]]，它来自 **风暴能手** 和 **灌注能量的唤雷者**。
- 你可以反弹 [[spell:1310683]]，它来自 **育巢者**。

### 词缀

词缀系统在进入**地心之战**时进行了重做，移除了大部分词缀，同时引入了新的有利有弊的词缀，并改变了这些词缀出现的钥石等级。这些词缀在地心之战期间以及进入至暗之夜时又经过了进一步调整。

- +2 词缀
  
  - [[spell:1284818]]
- +5 词缀*——每周轮换*。
  
  - 萨拉塔斯的契约：升腾
  - 萨拉塔斯的契约：虚空束缚
  - 萨拉塔斯的契约：吞噬
  - 萨拉塔斯的契约：脉冲星
- +6 词缀
  
  - [[spell:1284818]]已移除。
- +7 词缀*——两者每周交替出现*。
  
  - [[spell:1284818]]已移除。
- +10 词缀*——两个词缀同时存在。*
  
  - 暴君
  - 强韧
- +12 词缀
  
  - 萨拉塔斯的诡诈*——替代 +5 词缀*

## 属性优先级

了解你在大秘境地下城中作为**狂怒 战士**发挥最佳表现所需的次要属性优先级和第三属性。更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**攻略。

:::priority **狂怒 战士**在大秘境中的属性优先级
```json
{
  "source_code": "IgAHEEDJggiADQA"
}
```
**精通 ＝ 急速 ≥ 暴击 ≫ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **Avoidance -** 降低“范围伤害”技能伤害承受的优秀属性。
- **Leech -** 通过造成伤害提供额外治疗。你的宠物所造成的伤害治疗术，因此**Leech** 对你来说是一个极佳的第三属性，因为你的大部分伤害来自于你自己的法术。
- **Speed -**  较为小众的第三属性，但在特定情况下可能非常有用，过去也已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备

### 最佳配装

| 部位 | 物品 | 来源位置 |
| --- | --- | --- |
| 头部 | [[item:271456@DiCBAgEAvj7cUrDf1IYN2WjNyIoAFfBB]] | 盘魂者内克扎莉 + 催化 |
| 项链 | [[item:268265@BkCAAgEAU06IQrDj1QWNYYjX1IoA]] | 乌拉特克 |
| 肩部 | [[item:271454@DACAAgEA1k74XNBWjNyIoA]] | 迷失的探险者 |
| 披风 | [[item:268253@BgRAAgEAYYjX1IoAYFA]] | 盘卷祭坛 |
| 胸部 | [[item:271459@DASBAgEAJk7oXNCWDG2IoAYFgvXQ]] | 盘卷祭坛 + 催化 |
| 护腕 | [[item:237834@BiUAAgEAM06Y7LjVT0wwgN3Wjt1ccNAMSWisUA]] | 锻造 |
| 手套 | [[item:271457@BASAAgEA7VTg1YjMCKgTBA]] | 陵寝哨兵 |
| 腰带 | [[item:268259@BCSAAgEA8z6ghNeVjt1IoAYF]] | 盘卷祭坛 |
| 腿部 | [[item:271878@DACAAgEAju7YhNYYjX1IoA]] | 乌拉特克 |
| 靴子 | [[item:268260@BgBAAgEA2IjX1IoA]] | 万毒邪祟者瓦什尼克 |
| 戒指 1 | [[item:252258@DCSAAgEA1j7wPrDZ1YjMeVjgC4UA]] | 虚空之痕竞技场 |
| 戒指 2 | [[item:268249@DCCAAgEA1j7wPrDZ1YjMeVjgCA]] | 万毒邪祟者瓦什尼克 |
| 饰品 1 | [[item:270175@BghAAgEAYYjX1IoAFAQAXdhA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgBAAgEAYYjX1IoA]] | 盘卷祭坛 |
| 武器 | [[item:268213@DgBAAgEAFk7ghNeVjgC]] | 盘卷祭坛 |
| 副手武器 | [[item:237848@DgDAAgEAFk7Y7LMYzt1sZJLXDAjklIA]] | 锻造 |

### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251126@DARAAcEANk74iMeVTQB]] | 密谋小径 |
| 项链 | [[item:251142@AgQAAIoABFA]] | 密谋小径 |
| 肩部 | [[item:251138@DARAAcEA7j74iMeVTQB]] | 密谋小径 |
| 披风 | [[item:193763@BARAAcEAuIjX1EUA]] | 红玉新生法池 |
| 胸部 | [[item:193753@AgQAAIoABFA]] | 红玉新生法池 |
| 护腕 | [[item:251133@BARAAcEAuIjX1EUA]] | 密谋小径 |
| 手部 | [[item:159413@BARAAcEAuIjX1EUA]] | 诸王之眠 |
| 腰带 | [[item:159418@BARAAcEAuIjX1EUA]] | 诸王之眠 |
| 腿部 | [[item:273776@DARAAcEAju74iMeVTQB]] | 毒牙祭坛 |
| 脚部 | [[item:159412@DARAAcEApk74iMeVTQB]] | 诸王之眠 |
| 戒指 1 | [[item:273792@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:251136@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | 密谋小径 |
| 饰品 1 | [[item:273796@BARAAcEAuIjX1EUA]] | 毒牙祭坛 |
| 饰品 2 | [[item:250228@BARAAcEAuIjX1EUA]] | 密谋小径 |
| 武器 | [[item:273782@DARAAcEAFk74iMeVTQB]] | 毒牙祭坛 |
| 副手武器 | [[item:193755@AgQAAIoABFA]] | 红玉新生法池 |

### 饰品

以下是从地下城和团本可获得的上位饰品排名。

| 等级 | 饰品 |
| --- | --- |
| S 级 | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A 级** | [[item:270165@AgQAAIoAOFA]] |
| **B 级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C 级** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *—— 适合 范围伤害，单目标则选机械花园。* |
| **机械花园** |  |

:::simulation
```json
{
  "source_code": "JksBwzkJBMYLEEAEBAASAYjMASjTBAg7RITSB81HEEACBAASAghNYFAApJJOJFYIO9GITVGd6AiW1x2JqlmbnMHIHVXasx2b0lmblBCVlNGadJTNAQBCkUTSBUoOdBAFi23MJFQXygCAgooj5kUAdTvAB4ShAQRllMTSBIuOVAAF8cDNJFAh6IFAUE9q1kUAUFhUwYjMOFAAtK6NJFAdRPgMSBAFml8MJFQd6UBAUc8I0kUATqTFAQRSiRTSB4nOVAAFckANJFQVycGAU4yt2kUADqDKAQhpwLTSBUoOVAAGExFNJFwnqZz4AQReYRTSBMlMSBAFVtiMJFAWRMRJ7hQ5G6iOGFAFBFAAsRwM6kQAgEUAAIMYzkUgh4apBARQBAA0PYDkBQRQBAQJgZjOtCAGBFAAllTMJZjKCwRQBAwR1BTSB0lKUEUAAcZu1oTzBgRQBAQvtMTS20cAQEUAAAmE-AZAYEUAA8ZkzkkLBEAFBFAAtqML64YAMEUAAgbIBIzeBwQQBAQtBQqMNHAFBFAAp53MyYWAUEUAAU4qxozoBQRQBAgO5IjO0IAFBFAAyb6MywlAUEUAAoJZ2IDCCASQBAQunWTSH8P"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| [[item:273795]] | 729,374.88 |
| [[item:270175]] | 756,006.56 |
| [[item:270173]] | 741,952.50 |
| [[item:273797]] | 735,194.12 |
| [[item:270173]] | 760,040.62 |
| [[item:193757]] | 733,785.31 |
| [[item:193762]] | 738,163.75 |
| [[item:273796]] | 744,125.06 |
| [[item:270164]] | 752,170.81 |
| [[item:250228]] | 736,406.38 |
| [[item:250229]] | 737,852.44 |
| [[item:250259]] | 738,852.56 |
| [[item:250238]] | 737,425.75 |
| [[item:270165]] | 748,402.88 |
| [[item:250243]] | 732,938.38 |
| [[item:250245]] | 738,756.25 |
| [[item:158367]] | 738,695.56 |
| [[item:270163]] | 729,781.31 |
| [[item:270168]] | 714,862.31 |
| [[item:273797]] | 733,254.75 |
| [[item:273796]] | 734,732.12 |
| [[item:270173]] | 733,437.00 |
| [[item:270173]] | 747,010.31 |
| [[item:158367]] | 725,910.31 |
| [[item:273795]] | 722,772.44 |
| [[item:270175]] | 744,345.44 |
| [[item:193757]] | 733,915.81 |
| [[item:193762]] | 733,478.00 |
| [[item:250229]] | 735,513.94 |
| [[item:270168]] | 707,754.81 |
| [[item:250238]] | 733,259.50 |
| [[item:250243]] | 725,915.31 |
| [[item:250259]] | 735,206.56 |
| [[item:270163]] | 727,736.31 |
| [[item:250245]] | 730,003.62 |
| [[item:250228]] | 735,855.12 |
| [[item:270164]] | 747,081.62 |
| [[item:270165]] | 744,059.56 |
:::

### 美化饰品

- 使用 [[item:273060]] 制作一件制造武器是最佳选择，尤其是在初期配装阶段，除非你已经有两把好武器。
- 第二个美化制造部位我们选择 [[item:240167]] 或 [[item:273069]] 美化，考虑到 [[item:240167]] 能为队友带来的收益，这两个选项非常接近。推荐的部位是护腕。 *—— 过去披风可能是常见部位，但本赛季团本会掉落我们更愿意使用的 344 装等更高披风。*

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药剂**
  
  - [[item:241324]] 或  *—— 最佳配装配置使用急速合剂*
  
  
  
  - [[item:241326]] 或
  - [[item:241322]] *—— 狂怒战士需要急速、精通和爆击的属性平衡。* *如果你想找出适合自己的属性平衡以及缺少什么，我建议查阅我们的**[Simcraft指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**。*
- **食物**
  
  - [[item:255846]]
- **战斗药水**
  
  - [[item:241288]] *—— 最适合最佳配装配置。这可能不是你角色的最佳选择，如果你追求100%最优，请用Simulationcraft验证。*
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器临时附魔**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240983]] *—— 唯一，只能使用1个。*
    
    - [[item:240890]]
    - [[item:240906]]
    - [[item:240916]]
    - [[item:240900]]

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707]] |
| --- | --- |
| 肩部 | [[item:244021]] |
| 胸部 | [[item:243977]] |
| 护腕 | [[item:275707]] |
| 腰部 | [[item:275707]] |
| 腿部 | [[item:244643]] |
| 脚部 | [[item:243983]] |
| 戒指 1 | [[item:243957]] |
| 戒指 2 | [[item:243957]] |
| 武器 | [[item:243973]] |
| 副手武器 | [[item:243973]] |

:::

:::column
:::gear **狂怒 战士**在大秘境中的附魔
```json
{
  "source_code": "JwFZHBQ9NGQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwo7mAGA8gOYAAB1jbCYEBCoUQuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244643]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
| 副手 | [[item:243973]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买[[item:275707]]，为你的**头盔**、**护腕**和**腰带**添加插槽。

## 种族

为了在大秘境中对**狂怒 战士** 进行极限优化，不同的种族特性可以为你的角色带来巨大收益。如果这不是你的首要目标，选择一个符合你风格的种族也同样可行。

- [[spell:20589]] —— 侏儒
  
  - 解除定身和减速。
- [[spell:58984]] —— 暗夜精灵
  
  - 脱离战斗以避免法术以你为目标。
- [[spell:20594]] —— 矮人
  
  - 同时移除所有中毒、疾病、诅咒、魔法和流血效果。
- [[spell:69179]] —— 鲜血精灵
  
  - 同时驱散附近所有敌人的 1 个增益效果。
- [[spell:256948]] —— 虚空精灵
  
  - 激活后生成一个沿你面朝方向移动的暗影。再次激活可传送至其位置。
  - 最大距离 100 码。

:::simulation
```json
{
  "source_code": "JUtAA1xAEAAACOARhlHrcJwDtmTSFAB8kXgTpdGa01KXCQV65k0AHAAAAcJb6k0ADAAAAgEQ7k0AKAAAA0no5k0ABAAAA4P-6k0AkAAAA0WM5k0ACAAAAYlg5k0ALAAAAgno4k0AIAAAAQaE6k0AFAAAAo0J3k0AYAAAAIPZ6k0AJAAAAwtW6k0AGAAAAUFU7k0AcAAAAw4E6k0AbAAAAkvJ4k0AjAAAAoR22k0AfAAACSwRv52aKYHBJz8NJNgFAAAAQchOJNQHAAAARZ0OJNwHAAggGsUatJWdstgdEw_v4k0AgAAAA4qG6k0AiAAAA0NK5k0AlAAAAc3c6kUBRhzBLJXYndydhxgdEoct4kUBUwSBQF2JrVXC2RgjjoTCSQlBBtWduRWYHYHBNI3NJNgHAAAAA54NJwBSJI0dv52ch1GZphgdEAFa4k0BNA"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 4 [[spell:154796]] | 760,528.94 |
| 种族 4 [[spell:154797]] | 761,493.25 |
| 种族 7 | 763,593.44 |
| 种族 3 | 766,980.50 |
| 种族 10 | 760,359.81 |
| 种族 1 | 765,839.88 |
| 种族 36 | 758,550.81 |
| 种族 2 | 759,845.38 |
| 种族 11 | 756,263.50 |
| 种族 8 | 762,138.25 |
| 种族 5 | 750,196.62 |
| 种族 24 | 763,471.12 |
| 种族 9 | 763,309.75 |
| 种族 6 | 767,237.31 |
| 种族 28 | 762,168.75 |
| 种族 27 | 754,287.56 |
| 种族 35 | 748,945.62 |
| 种族 31 [[spell:292362]] | 752,844.56 |
| 种族 22 | 762,225.00 |
| 种族 29 | 767,077.06 |
| 种族 31 [[spell:292363]] | 756,735.75 |
| 种族 32 | 762,282.88 |
| 种族 34 | 758,413.81 |
| 种族 37 | 763,703.44 |
| 种族 31 [[spell:292364]] | 756,572.62 |
| 种族 31 [[spell:292361]] | 762,424.88 |
| 种族 31 [[spell:292359]] | 751,392.81 |
| 种族 30 | 751,844.00 |
| 种族 31 [[spell:292360]] | 755,333.00 |
:::

### 推荐

**矮人** 和**暗夜精灵**的技能对你的大秘境体验影响如此之大，如果你认真对待用**狂怒 战士**冲层，就必须选择其中之一。

## 宏

探索 **狂怒 战士**在大秘境中的用法，并观看简短的视频教程，学习为角色创建简单的宏。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:376079]]宏** *--- 将勇士之矛释放在你的鼠标指针位置。*

```wow-macro
/cast [@cursor] 勇士之矛
```

**[[spell:6544]]宏** *--- 无需额外点击鼠标即可跳向你的鼠标指针位置。*

```wow-macro
/cast [@cursor] 英勇飞跃
```

:::

:::details 鼠标指向宏
**[[spell:163201]]宏** *--- 如果你的鼠标悬停在一个敌人身上，则对其施放斩杀，否则对当前目标施放斩杀。这个宏在你保持以首领（Boss）为目标的同时斩杀附近低血量的小怪时非常有用。*

```wow-macro
/cast [@mouseover, harm, nodead][harm,nodead] 斩杀
```

**[[spell:100]]宏** *--- 对当前目标施放冲锋，除非你的鼠标悬停在另一个敌人身上，此时会以该敌人为目标并施放冲锋。*

```wow-macro
/target [@mouseover, harm, nodead]
/cast 冲锋
```

:::

:::details 实用宏
**[[spell:386208]] 和 [[spell:386196]]宏** *—— 有了它，你只需1个按键就能切换姿态。*

```wow-macro
/cast [stance:2] 防御姿态; [stance:3] 狂暴姿态
```

:::

:::

## 插件

下方是作者为其 **狂怒 战士**，说明使用哪些插件以及如何在大秘境地下城中利用它们，让你的游戏体验更轻松。

![Revvez Midnight Fury Warrior UI](<https://assets-ng.maxroll.gg/wordpress/UIEllesmereUI-1024x576.png>)

Revvez **狂怒 战士** UI

:::accordion
:::details 插件
- **MRT** *-- 备注、团队副本冷却等更多功能* 
  
  - 对团队副本玩家非常有用的插件，尤其适合团队副本团长和官员。
- **Ellesmere UI** *-- 用户界面替代方案* 
  
  - EllesmereUI 是一套完全模块化的界面套件，专为希望完全掌控自己界面、同时不牺牲性能或易用性的玩家设计。每个元素都从零开始构建，轻量、响应迅速且易于配置。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一款首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件专为某个特定的团队副本战斗触发警报信息、计时条、音效等而设计。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**战士**

- *开发者备注：撕裂是一个标志性且核心的战士技能，与每个专精的关系各不相同。我们在至暗之夜中对撕裂的处理方式并未达到预期效果，因此我们将在乌拉特克之诅咒中改变各专精运用撕裂以及与其互动的方式。*
- 撕裂技能现在为武器专精独有，重新回归为单体技能，其怒气消耗降低至10点。如果战士已学会撕裂，顺劈斩将对所有目标施加撕裂。
- 新天赋（狂怒）：血怒风暴——旋风斩对所有人目标施加撕裂。崩解闪电使血怒风暴还会对雷霆一击施加山丘领主。
- 新天赋（防护）：鲜血与雷霆——雷霆一击对所有目标施加撕裂。
- 雷霆一击不再在已学会时自动施加撕裂。
- 掷矛手获得了新的图标。
- 英雄天赋
  
  - 山丘领主
    
    - 开发者备注：雷霆一击的基础伤害在至暗之夜中大幅提升，导致山丘领主的雷霆一击总体伤害显著上升，进而贬低了雷霆轰击的价值。我们将把崩解闪电的伤害加成移入雷霆轰击本身，以保持雷霆轰击的特殊感和强大感。
    - 雷霆轰击伤害提高20%。
    - 崩解闪电使雷霆一击的伤害提高10%（原为30%）。
- 狂怒
  
  - 开发者备注：旋风斩历来是狂怒玩法中的核心部分，即使在单体目标情况下也是如此。我们希望再次为旋风斩成为单体情况下有用的技能打开大门。
  - 新天赋：雕刻之刃——旋风斩在只命中单个目标时造成50%的额外伤害。
  - 旋风斩已更新——旋风斩现在自身产生3点怒气。
  - 强化旋风斩已更新——不再使旋风斩自身产生3点怒气，但仍使旋风斩每命中一个目标额外产生1点怒气，最多产生8点怒气。
  - 暴怒毁灭已重新设计——当强化旋风斩激活时，暴怒的最后一击将猛击地面，对目标8码范围内的所有敌人造成物理伤害。超过5个目标后伤害降低。
    
    - *开发者备注：暴怒毁灭旨在帮助缓解狂怒循环范围伤害技能上的范围伤害目标上限问题。当前的设计导致很难判断何时使用暴怒毁灭最佳，新设计应使这一选择更加直观。*
  - 劈斩已更新——暴怒现在有75%的几率返还一层怒击，并使你的下一个怒击伤害提高20%。
    
    - *开发者备注：我们认为狂怒在按完当前技能后不确定下一个该用什么技能时体验最佳。此前版本的劈斩提供了极其规律和稳定的怒击重置，导致怒击几乎总是可用。我们相信这一改动将有助于保持狂怒循环的多样性，并让强调怒击的构筑与不强调它的构筑在循环手感上有更大差异。*
  - 浴血奋战初始伤害降低12%，流血伤害提高300%。
    
    - *开发者备注：浴血奋战的设计意图是大部分伤害加成来自流血效果。目前的数值调整没有实现这一点，因此我们将浴血奋战增加的部分伤害从初始打击转移到流血效果上。这一改动对浴血奋战的总体伤害应当是净中性的。*
  - 英雄天赋
    
    - 山丘领主
      
      - 地面电流伤害提高150%。

:::

:::details 12.0.5 补丁
**战士**

- 撕裂 的半径扩大至 10 码（原为 8 码）。
- 当 战士 的目标拥有生效的吸收护盾时，破裂投掷 现在会被高亮显示。
- 当 战士 的目标拥有生效的免疫效果或 法师 的冰墙时，碎裂投掷现在会被高亮显示。
- 狂怒
  
  - 劈斩 已重新设计——暴怒 有 100% 的几率返还一层 怒击 充能。
  - 强化旋风斩 现在使 旋风斩 在已学会 撕裂 的情况下，对所有目标施加 撕裂。
  - 斩杀者
    
    - 掠武风暴 已更新——当 暴怒 通过 强化旋风斩 命中 3 个或更多目标时，你有 20% 的几率释放钢铁风暴，对附近所有敌人造成高额物理伤害并施加 不堪一击。
    - 无情强袭 现在使 剑刃风暴 造成的伤害提高 20%。

:::

:::details 补丁12.0.1
**战士**

- 英雄天赋
  
  - 山丘领主
    
    - 狂怒
      
      - 闪电打击伤害提高100%。
      - 雷霆轰击伤害降低30%。
      - 崩解闪电对雷霆一击的伤害加成降低至30%（原为40%）。
  - 斩杀者
    
    - 殒命在即现在有一个额外效果——猝死有100%的几率触发掠武风暴。
    - 斩杀者之击伤害降低10%。
    - 掠武风暴伤害降低20%。
    - 狂怒
      
      - 清剿旋风的额外伤害提高至20%（原为10%）。
      - 屠戮者之怨额外伤害降低至15%（原为20%）。
      - 掠武风暴的触发几率提高至35%（原为25%）。
- 职业
  
  - 重伤伤害降低30%。
- 狂怒
  
  - 自动攻击伤害降低48%。
  - 嗜血伤害提高10%。
  - 剑刃风暴伤害提高30%。
  - 怒击伤害降低20%。
  - 暴怒伤害降低10%。

:::

:::details 补丁12.0
**战士**

- 英雄天赋
  
  - 山丘领主
    
    - 新天赋：狂雷奔涌 – 天神下凡使雷霆一击的伤害提高50%，并使其冷却时间缩短50%。
    - 新天赋：导电 – 闪电打击的伤害提高10%，暴击伤害提高10%。
    - 新天赋：电容 –在天神下凡期间，雷霆轰击会使天神下凡的持续时间延长2秒。
    - 雷霆轰击的伤害提高150%。
    - 狂怒
      
      - 山峦之力的嗜血和暴怒伤害提高15%（原为25%）。
  
  
  
  - 斩杀者
    
    - 新天赋：狂烈快感 – 剑刃风暴使你进入战斗恍惚状态，在你结束剑刃风暴后获得15%急速，持续8秒。
    - 新天赋：致命专注 – 处刑者的持续时间延长6秒。
    - 新天赋：迷狂乱舞
      
      - 狂怒：剑刃风暴每攻击2次，你就会自动向你的目标或附近随机敌人施放一次嗜血，造成100%的正常伤害。
    - 屠戮之霸已更新 – 你的攻击有15%的几率触发屠戮者打击。屠戮者打击现在会使你获得一层处刑者，使你的斩杀伤害提高3%，持续12秒。多层处刑者可以叠加。
    - 绝不留情已更新 – 处刑者现在还会使你的斩杀暴击几率和暴击伤害每层提高3%。
    - 无情强袭已更新 – 使用猝死会使剑刃风暴的冷却时间缩短5秒，并且你每拥有一层处刑者，就会向你的主要目标施加1层不堪一击。
    - 趁虚而入的效果现在最多可叠加2次。
    - 压制之锋的不堪一击负面效果现在可叠加5次（原为10次）。
    - 屠戮者之怨现在除了压制和怒击之外还会影响斩杀，但伤害加成降低至20%（原为30%）。
    - 屠戮者打击的伤害提高100%。
    - 掠武风暴的伤害提高100%，触发几率提高至25%（原为20%）。
    - 狂怒
      
      - 趁虚而入对下一个怒击的伤害和暴击伤害加成降低至10%（原为25%）。
- 职业
  
  - 新天赋：共鸣之声 – 你的战吼持续时间延长20%。
  - 新天赋：报复 – 当你受到近战范围内敌人造成的任何伤害时，你有几率对该敌人造成一次物理伤害打击。
  - 新天赋：姿态掌握 – 你的姿态将获得额外效果。
    
    - 战斗姿态：使你技能的暴击伤害提高3%。
    - 狂暴姿态：使你的自动攻击速度提高3%。
    - 防御姿态：当一次攻击造成等于或超过你最大生命值20%的伤害时，该伤害降低15%。
  - 新天赋：战地统帅 – 你的战吼类技能将获得额外效果。
    
    - 战斗怒吼：额外使你获得3%攻击强度。
    - 集结呐喊：额外提供2%生命值，持续时间延长3秒。
    - 刺耳怒吼：作用半径扩大100%。
    - 狂暴怒吼：作用半径扩大100%。
    - 破胆怒吼：冷却时间缩短15秒。
  - 新天赋：愤怒掌控 – 你每消耗20点怒气，天神下凡、巨人打击、鲁莽和盾墙的剩余冷却时间就缩短1秒。
  - 新天赋：战地包扎 – 受到的治疗效果提高3%，所有自我治疗效果额外提高10%。
  - 新天赋：无畏 – 狂暴之怒的冷却时间缩短50%，并且狂暴之怒会移除所有移动限制效果。
  - 新天赋：掷矛高手 – 你的投掷类技能射程增加5码。勇士之矛、碎裂投掷和破裂投掷造成的伤害提高20%。碎裂投掷和破裂投掷会使非玩家目标沉默3秒。
  - 新的武器和狂怒天赋：挺身而出 – 高速冲向你盟友附近的目标位置，在8秒内或直到你因此效果受到至少相当于你最大生命值20%的伤害之前，代替3码内盟友承受所有伤害的30%。
  - 新的武器和狂怒天赋：撕裂 – 挥舞你的武器横扫，对8码内所有目标造成物理伤害，并使其受伤，在15秒内持续受到额外流血伤害。
  - 勇士之矛已重新设计 – 向目标位置投掷一支长矛，将区域内所有敌人锁链拉至长矛所在位置，立即造成物理伤害，并在6秒内持续造成额外物理伤害。长矛存在期间，激活此技能会使你跃向长矛，猛击落地，对所有目标造成物理伤害。对超过5个目标造成的伤害降低。产生10点怒气。
  - 破胆怒吼现在会使范围内所有目标的移动速度降低70%，并使范围内除你主要目标外的所有敌人逃跑。原为8个目标。
  - 集结呐喊已更新 – 非团队副本中提供的生命值提高50%。
  - 干练反射现在使冷却时间缩短10%（原为5%），并获得额外效果 – 成功打断敌人后，你在10秒内对其造成的伤害提高5%。
  - 刺耳怒吼现在还会激励12码内的所有盟友，使其移动速度提高30%，持续4秒。
  - 野蛮训练现在使猛击、旋风斩、雷霆一击、怒击和复仇造成的伤害提高10%，暴击伤害提高5%。
  - 碎裂投掷和破裂投掷的射程缩短至25码（原为30码）。
  - 雷霆一击的伤害提高150%，若已学得相应天赋，则会对所有目标施加撕裂。
  - 盾牌猛击的伤害提高140%。
  - 当你生命值低于35%时，复苏之风的治疗效果提高100%。
  - 碾压之力现在是一个1点天赋。
  - 许多天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - 天神下凡 *（移至各专精的天赋树中）*
    - 狂战士的折磨
    - 剑圣的折磨
    - 震耳咆哮
    - 挑战者之力
    - 震荡打击
    - 不动如山
    - 威慑
    - 穿刺挑战
    - 裂地回响
    - 雷鸣之吼
    - 声如雷鸣
    - 泰坦的折磨
    - 势不可挡
    - 怒吼震天
    - 督军的折磨
- 狂怒
  
  - 新天赋：重伤 – 斩杀会对目标施加重伤，在6秒内造成高额伤害。
  - 新天赋：血之气息 – 暴怒使你下一个嗜血的伤害提高10%，最多可叠加2次。
  - 新天赋：怒饮者 – 嗜血的爆击会额外恢复3%生命值，并使怒击的伤害提高10%，持续4秒。
  - 新天赋：处决者的愤怒 – 斩杀额外产生5点怒气，并使暴怒的伤害提高10%，持续4秒。
  - 新天赋：蛮力爆发 – 当怒击重置自身冷却时间时，你的自动攻击伤害和速度提高30%，持续6秒。
  - 新天赋：不成功便成仁 – 当你即将受到致命伤害时，你会陷入不可阻挡的狂怒，在8秒内无法被杀死并免疫移动限制效果，向企图杀死你的敌人寻求复仇。如果你在这段时间内杀死了你的杀手，你将带着至少20%的最大生命值从狂怒中凯旋而出。如果你未能获胜，你将死亡。此效果每5分钟只能触发一次。
  - 新被动技能：泰坦之握：单手狂怒 – 你可以将你的双手武器幻化为使用单手武器的外观。
  - 天神下凡已移至狂怒天赋树并已更新 – 变身为巨人，使你造成的所有伤害提高20%，移动速度提高5%，持续20秒。
  - 血肉顺劈已重新设计 – 旋风斩在命中3个或更多目标时造成50%的额外伤害。
  - 浴血之躯已重新设计 – 被嗜血击中的目标在12秒内受到你的流血效果额外20%的伤害。
  - 熟能生巧已重新设计 – 嗜血的爆击几率提高5%/10%，如果你处于激怒状态，嗜血会使你的激怒延长0.5秒/1秒。如果嗜血对你的主要目标造成爆击，此延长效果翻倍。
  - 狂乱已重新设计 – 暴怒使你的急速提高2%，持续12秒。此效果的多个实例可以叠加。
  - 暴虐成性已重新设计 – 怒击的爆击几率提高5%/10%，爆击伤害提高5%/10%。
  - 强化嗜血已更名为怨恨并已更新 – 嗜血和怒击（原仅为嗜血）的伤害和爆击伤害提高2.5%/5%（原为5%/10%）。
  - 残忍已更新 – 激怒状态下，嗜血和怒击（原仅为怒击）造成5%/10%的额外伤害（原为10%/20%）。
  - 怒意生威已更新 – 激怒使你的精通提高15%，吸血提高3%。
  - 血腥疯狂已更新 – 怒击使你下一个嗜血的伤害提高5%，最多可叠加5次。
  - 强化旋风斩现在使你的下4次单目标攻击（原为2次）额外击中4个目标。
  - 暴怒现在替换猛击。暴怒的伤害提高10%。
  - 自动攻击的伤害提高200%。
  - 雷霆一击的伤害降低60%。
  - 旋风斩的伤害提高20%。
  - 嗜血的伤害提高20%。
  - 剑刃风暴现在每次攻击产生5点怒气（原为10点）。
  - 鲁莽现在使产生的所有怒气提高50%（原为100%）。
  - 奥丁之怒现在会使你进入激怒状态并产生20点怒气（原为15点）。
  - 奥丁之怒的流血伤害提高140%，并且现在对超过8个目标造成降低的伤害（原为5个目标）。
  - 暴怒毁灭造成的伤害提高50%，但现在对超过5个目标造成降低的伤害（原为8个目标）。
  - 修复了一个导致奥丁之怒流血伤害错误地被护甲降低的问题。
  - 许多天赋在天赋树中的位置发生了变化。
  - 以下天赋已被移除：
    
    - 灰烬战车
    - 飞舞之刃
    - 疯狂深渊
    - 强攻
    - 破坏者
    - 单手狂怒
    - 屠杀打击
    - 钢铁风暴
    - 暴捶
    - 泰坦之怒
    - 不羁狂野
    - 迷狂乱舞

:::

:::details 11.2版本
### 战士

- 断筋的公共冷却时间现在为0.75秒（原为1.5秒）。
- 修复了狂暴之怒能够驱散驱散射击的问题。
- 狂暴之怒的工具提示已略微调整，以说明其只对部分瘫痪效果生效。

#### 狂怒

- *开发者说明：狂怒在持续的范围伤害战斗中一直难以跟上节奏。这些改动旨在增强狂怒在这些情况下的表现。*
- 所有技能伤害提高5%。
- 剑刃风暴伤害提高15%。
- 旋风斩伤害提高10%。
- 强化旋风斩使你的单体攻击对附近最多4个目标造成65%的伤害（原为55%）。

:::

:::details 11.1版本
### 战士

- *开发者说明：我们认为战士的整体状态良好，但我们仍希望对每个专精以及整个职业进行一些改进。战士的生存能力尤其一直是一个弱点，而耐力训练在天赋树底层与强大的输出类节点竞争，导致很难投入点数。我们将耐力训练与强化护甲合并，把这个选择放到第二层，使其与其他实用性和生存类节点之间有更多选择空间，从而更容易分配点数。武器专精节点已增加到2点，以保持天赋树结构和整体天赋构筑消耗相近，同时对节点位置稍作调整，使各专精获取天神下凡的方式选择更加分明。*
- 强化护甲现在是一个2点天赋，每点提供5%耐力和5%护甲。
- 压倒性怒火现在是一个1点天赋，使怒气值上限提高30点。
- 双手武器专精（武器）现在是一个2点天赋，每点在持双手武器时提供3%伤害和2%的范围攻击伤害减免。
- 双持专精（狂怒）现在是一个2点天赋，每点在双持武器时提供3%伤害和2%的移动速度。
- 单手武器专精（防护）现在是一个2点天赋，每点提供3%伤害和2%的吸血。
- 声如雷鸣使你对受影响目标造成的流血伤害提高20%（原为30%）。
- 残忍打击、狂野打击和武器专精节点在天赋树中的位置已改变。
- 耐力训练已被移除。

#### 狂怒

- *开发者说明：狂怒 整体上处于我们满意的状态，我们借此机会重新设计了一些天赋，以保持其效果的独特性和强大。*
- 泰坦之怒已被重新设计——当 天神下凡 激活时，暴怒 的怒气消耗降低 20 点，且 嗜血 的冷却时间缩短 1.5 秒。
- *开发者说明：我们希望为 天神下凡 提供一个影响 狂怒 循环的新选项，并让你在 天神下凡 持续期间通过更多的暴怒和嗜血来获得最大收益。这一改动也让我们能够将 奥丁 的 狂怒 保持为一个独立于 天神下凡 的强大标志性 狂怒 技能。*
- 肆意放纵 已被重新设计——激活 鲁莽 会产生 50 点怒气，并且在 鲁莽 激活期间，怒击 和 嗜血 会被 碎甲猛击 和 浴血奋战 替换。碎甲猛击——一次强大的双武器打击，造成提高 20% 的爆击伤害。
- 浴血奋战——一次强大的攻击，对目标施加流血效果，再次施放时会延长其完整持续时间。
- *开发者说明：肆意放纵 对输出循环的影响过大，我们希望将该天赋的重心重新放回 鲁莽 上，并让 碎甲猛击 和 浴血奋战 成为具有独特附加效果的技能。*
- 所有技能伤害降低 5%。
- 嗜血 伤害提高 38%。
- 浴血奋战 立即伤害提高 38%。
- 怒击 伤害提高 44%。
- 碎甲猛击 伤害提高 44%。
- 暴怒 伤害提高 44%。
- 奥丁之怒 伤害提高 15%。
- 强攻 伤害提高 30%。
- 旋风斩 伤害提高 30%。

#### 山丘领主

- 雷霆轰击伤害提高25%。
- 山脉之力使嗜血和暴怒的伤害提高25%（原为30%）。

#### 斩杀者

- 殒命在即和死亡驱动现在正确要求选择猝死天赋后才能生效。
- *开发者说明：这是实现过程中的疏忽。屠戮者应当选择猝死天赋。*

:::

:::details 11.0.5版本
### 战士

- [[talent:112223]] 现在对超过5个目标（原为8个）造成降低的伤害。
- [[talent:112247]] 图标已更新。

#### 斩杀者

- [[spell:445836]] 现在最多叠加10层（原为12层）。

#### 狂怒

- [[talent:112265]]伤害提高25%
  
  - *开发者说明：此改动不影响[[talent:112284]]碎甲猛击。*
- [[talent:112261]]伤害提高30%。
  
  - *开发者说明：此改动不影响[[talent:112284]]浴血奋战。*
- *开发者说明：目前[[talent:112284]]在所有情况下都优于[[talent:112285@AJQABA]]，因此我们通过提高怒击和嗜血的基础伤害来拉近两者的差距，这同时也会改善狂怒的基础单体伤害。*
- [[talent:112212@AJQABA]] 现在使[[talent:112261]]的爆击伤害提高5/10%（原为爆击几率提高2/4%）。
- [[talent:112289]]现在对超过5个目标造成降低的伤害（原为8个）。

:::

:::details 11.0.2补丁
### 战士

- [[spell:23922]] 伤害提高8%。
- [[talent:112217]] 现在治疗你最大生命值的2%（原为3.5%）。

#### 狂怒

- [[talent:112262]]现在治疗最大生命值的10%（原为15%）。

:::

:::details 11.0版本
### 战士

- 所有天赋树中的许多天赋已经调整了位置或更新了连接路径。
- [[talent:118850]] 已经重新设计——[[talent:112128]]、[[talent:112264]]、[[spell:871]]、[[spell:6552]]、[[talent:112186]]、[[talent:112253]]和[[talent:112198]]的冷却时间缩短5%。
- [[talent:112190]] 获得了额外效果——当你的生命值低于35%时，每1秒恢复1.0%的生命值。你越接近死亡，恢复量越高（最高为2%）。
- [[spell:18499]] 现在于12级学习。
- [[spell:1464]] 伤害提高130%。武器 [[spell:1464]] 伤害加成降低至50%（原为75%）。
- [[spell:227847]] 伤害提高70%。
- [[spell:228920]] 伤害降低10%。
- [[spell:280721]] 现在可以叠加2次。
- [[spell:6343]] 怒气消耗降低至20点（原为30点），并且如果你已学会[[talent:112136]]，现在默认施加该效果。
- [[spell:215571]] 现在对武器和狂怒返还10%的怒气，对防护返还25%的怒气。
- [[talent:112242]] 施放时不再产生怒气。
- [[talent:112247]] 施放时产生10点怒气（原为20点）。
- [[talent:112223]] 施放时不再产生怒气。
- [[talent:112223]] 现在对8个以上目标造成的伤害降低。工具提示将在未来的更新中反映此改动。
- [[talent:112222]] 现在使[[talent:112223]]的流血效果提高目标受到的战士所有流血效果的伤害，而不是持续被动地提高。
- [[talent:112289]] 现在对8个以上目标造成的伤害降低。工具提示将在未来的更新中反映此改动。
- [[talent:112221]] 现在使[[talent:112223]]的冷却时间缩短45秒（原为30秒）。
- [[talent:112180]] 现在使你对被锁链连接到你的长矛的目标造成暴击伤害提高25%。
- [[talent:112246]] 现在提高[[talent:112247]]造成的所有伤害（原来仅提高初始伤害）。
- [[talent:112242]]的视觉效果现在将正确匹配其半径，无论是否选择了[[talent:112241]] 天赋。撞击视觉效果也已更新。
- [[talent:112223]]的视觉效果已调整。
- 修复了[[talent:112188]]使最大生命值提高15%而非预期的10%的问题。

##### 以下天赋已被移除

- 泰坦之掷
- 音爆
- 鲜血与雷霆

#### 狂怒

- 新天赋： [[talent:119112]]：[[spell:184361]] 使你的技能造成的伤害额外提高15%，并且 [[spell:184361]] 的持续时间延长1秒。与 [[talent:112267]] 处于同一选择节点。
- 飓风已被 [[talent:112257]] 取代 – 每当 [[talent:119139]] 或 [[talent:112256]] 造成伤害的每隔一次，你会对目标或附近的一名敌人施放 [[talent:112261]]。
- 狂怒 战士现在默认学会 [[talent:114644]]。
- 所有技能伤害提高49%。
- [[talent:112277]] 伤害提高26%。
- [[talent:112261]] 伤害提高29%。
- [[talent:112289]] 伤害提高33%。
- [[talent:112265]] 伤害提高10%。
- [[talent:112259]] 的 [[talent:112265]] 重置自身冷却几率提高至25%（原为20%）。
- [[talent:112284]] 现在会强化你的下一个 [[talent:112261]] 和 [[talent:112265]]。
- [[talent:112284]] 的 [[spell:335096]] 伤害降低26%，[[spell:335097]] 伤害降低3%。
- [[talent:112292]] 现在使 [[talent:112261]] 在你处于激怒状态时延长你的 激怒 效果0.5/1.0秒。
- [[talent:112286]] 现在还使 [[talent:112261]] 产生的怒气提高1.0/2.0点。
- [[talent:112212]] 现在使 [[talent:112261]] 的伤害提高10/20%，[[talent:112261]] 的爆击几率提高2/4%。
- [[spell:1464]] 的怒气消耗已移除。
- [[talent:112255]] 现在在激怒状态下使 [[talent:112259]] 重置 [[talent:112265]] 冷却的几率提高10%。
- [[talent:112292]] 不再降低 [[talent:112261]] 的冷却时间，改为每点使 [[talent:112261]] 的触发几率提高 [[spell:184361]]，每点提高 2%。
- [[talent:112294]] 不再延长 [[spell:184361]].
- [[talent:112274]] 现在由 [[talent:112265]] 触发 而不是 [[talent:112261]]。
- [[talent:119139]] 现在为 狂怒 的每次伤害事件产生10点怒气（配合 [[talent:112258]] 为20点）。
- [[talent:119139]] 现在是与 [[talent:112256]] 同一选择节点的天赋。所有现有的 [[talent:112256]] 子天赋均已更新，可同时适用于 [[talent:112256]] 以及 [[talent:119139]]。
- [[talent:112283]] 不再由 [[talent:112295]] 触发，且其触发几率降低至6%（原为20%）。
- [[talent:112227]] 的工具提示已更新详细信息。无功能性改动。
- [[talent:112226]] 的工具提示已更新详细信息。无功能性改动。
- 以下天赋已被移除：
  
  - 狂乱连击已被移除，其效果已并入一心狂怒。
  - 狂怒武装
  - 歼灭者
  - 刀剑风暴

:::

:::

## 常见问题

:::accordion
:::details Q: 战士们怎么了 [[talent:135597]] 关于 狂怒 战士？
答：在 12.1 版本中，[[talent:137472]]现在会为狂怒战士被动地施加该效果。

:::

:::

---

### 致谢

作者：**Revvez**

审校：**Meeres**

:::changelog 更新记录
**2026-08-08** 更新至 12.1 版本。

**2026-06-17** 更新至 12.0.7 版本。

**2026-03-16** 更新了最佳配装列表。
更新了装饰品部分。
更新了饰品和种族 DPS 对比模拟。

**2026-01-19** 更新至 12.0 版本。

**2025-12-02** 更新至 11.2.7 版本。

**2025-10-07** 更新至 11.2.5 版本。

**2025-09-09** 在斩杀者套装获得加强后，新增了斩杀者构筑。
更新了最佳配装列表。
更新了饰品模拟。
更新了种族模拟。

**2025-07-31** 更新至 11.2 版本。
更新了最佳配装列表。
更新了饰品模拟。
更新了种族模拟。

**2025-06-24** 更新至 11.1.7 版本。
更新了最佳配装列表。

**2025-04-21** 更新至 11.1.5 版本。
更新了最佳配装列表。
更新了饰品模拟。

**2025-02-23** 更新至 11.1 版本。

**2024-12-17** 更新至 11.0.7 版本。
更新了最佳配装列表。
更新了模拟。

**2024-10-19** 更新至 11.0.5 版本。

**2024-09-08** 由于[[talent:112257@AJQABA]]被削弱，移除了[[talent:112285@AJQABA]]天赋构筑。
对优先级列表进行了少量修正。
更新了种族和饰品模拟。

**2024-08-17** 更新至 11.0.2 版本。

**2024-08-01** 攻略撰写于 11.0.1 前夕版本。



:::
