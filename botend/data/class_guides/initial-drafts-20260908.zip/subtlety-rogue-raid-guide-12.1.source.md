Welcome to the **Subtlety Rogue** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

Weak · 2/5 · Average

Utility · 1/5 · Subpar

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Subtlety Rogue** Raid Best in Slot
```json
{
  "source_code": "JUpAwTVBBc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOA_sOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADQgt7AECSAAkBwDYiqDIQrDAQBBwiIvsUABcJJEAACBAQBmBC3XQggIEAA1jbAKWgEAkdFSAgCBwGJOFQAf9BBAgwAAEQacUAABo0FCEQXBIRAChBWBEgNVPAAFwAEOFQA1LSBESwP5WglUEQDhOgBIUAhkMQuDQqKEIyLLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240892]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:251190]] |  |
| 主手 | [[item:271093]] | [[item:244031]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Subtlety Rogue**, you have access to Ancient Arts, that causes the Combo Points you generate from [[spell:196911]] to have a 15% chance to create a shadow clone that repeats the attack for 50% of normal damage as shadow.

**Rank 2** makes the shadow clones have a 50% / 100% per point spent to trigger the [[spell:196911]] effect.

While with **Rank 3** if you have 5 or more [[spell:196911]] when you use a builder, your next finisher will consume them to generate max Combo Points.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-subtlety-mxr.webp>)

Ancient Arts

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:112612]]
    
    - Causes your [[spell:169629]] to scale with haste, increasing its duration the more that you have of it.
  - [[talent:112627]]
    
    - This talent was changed, now makes your [[spell:53]] or [[spell:185438]] have a 15% chance to create a shadow clone that repeats the attack for 50% of its damage as shadow.
  - [[talent:112628]]
    
    - Increases shadow clone damage by 15%. Also causes your [[spell:1833]] and [[spell:408]] create a clone that attacks the target.
  - [[talent:112605]]
    
    - Changed, now causes your [[spell:197835]] to have a 15% chance to create a clone that repeats the attack for 50% of normal damage.
  - [[talent:112604]]
    
    - Changed, buffs your shadow clones by 15%, and gives you an extra 5% chance to spawn them.
  - [[talent:112623]]
    
    - Changed, now you deal 10% damage in [[spell:169629]] or [[spell:1784]].
  - [[talent:112618]]
    
    - Changed, now simply does extra damage every time you use a different ability in your [[spell:169629]].
  - [[talent:112606]]
    
    - Causes your [[spell:319175]] to do 30% more damage damage based on mastery if you spend 5 or more Combo Points.
  - [[talent:112594]]
    
    - Changed, just buffs your finishing moves during [[spell:169629]] by 10% per rank.
- **Class Tree**
  
  - [[talent:112636]]
    
    - Increases agility by 3%.
  
  
  
  - [[talent:112639]]
    
    - No longer a button, now it procs from your generators and increases your next finisher crit by 10%.
  - [[talent:112644]]
    
    - Extra attack speed from your [[spell:5171]].
- **Removed**
  
  - [[spell:323654]]
  - [[spell:393972]]
  - [[spell:394023]]
  - [[spell:278683]]
  - [[spell:1943]]
  - [[spell:394309]]
  - [[spell:212283]]

## Hero Talents



### [[talent:123370]]

- Makes your [[spell:185438]] and [[spell:53]] hit your target with an [[talent:117737]]. *10sec duration, 15sec Cooldown.*
  
  - [[talent:117737]] applies [[spell:441224]], making the target take 8% more damage from you and being unable to parry, which is pretty nice. Especially on bosses where you have to sit on front of the boss for extended periods of time.
  - [[talent:117737]] also applies 1 stack of [[spell:441786]] as a buff on you.
    
    - At 4 stacks of [[spell:441786]], your next [[spell:2098]] becomes [[talent:117712]].
  - [[talent:117712]] hits your target as if your [[spell:15691]] had an extra 5 Combo Points.

- [[talent:120130]]
  
  - This is a pretty nice defensive that adds some tankyness to your kit.
- [[talent:117708]]
  
  - This is a synergistic talent in the tree that outside of being a flat % buff on your finishers, works with [[talent:117725]] and [[talent:117712]].
- [[talent:117731]]
  
  - This is a pretty nice quality of life talent.
- [[talent:117725]]
  
  - [[talent:117708]] has pretty good uptime so a flat damage buff on your cleave is decent.
- [[talent:117715]]
  
  - [[spell:280719]] makes your [[spell:441144]] ignore its cooldown.
- [[talent:136023]]
- [[talent:136022]]
- [[talent:136021@AJABBA]]




### [[talent:123373]]

- Your [[spell:185438]] marks your target with 3 stacks of [[talent:117733]]. 
  
  - You can only have 1 [[talent:117733]] active.
  - Consume a stack of [[talent:117733]] by using a 5 Combo Point or more finisher.
  - You can only apply the [[talent:117733]] with [[spell:185438]]

- After consuming the last stack of [[talent:117733]], or if a mob dies while the [[talent:117733]] is active, you gain [[talent:117739]]..
  
  - When [[talent:117739]] is up, always make sure your next finisher is an [[spell:15691]] with 7 Combo Points.
  
  
  
  - When you consume [[talent:117739]], you apply [[talent:117733]] on the mob you have targetted.
- You can also move your mark with [[spell:1293340]].

Additionally, there are a few more capstones in the tree that are important.

- [[talent:117707]]
- [[talent:117732]].
- [[talent:126029]]
  
  - A defensive node that makes [[talent:112657]] even stronger. [[talent:117703]] is also interesting but much more fight specific.
- [[talent:136020]]
  
  - Passive crit bonus.
- [[talent:136019]]
  
  - A little bit of extra flavor every time you apply mark, but realistically not a big thing.
- [[talent:136018@AJAB]]
  
  - Adds a bit of extra damage in aoe or cleave scenarios, ignoring your main target.
- [[spell:457055]]
  
  - A bit of extra funnel on your main target.





## Talents



### [[talent:123373]] - Single target

:::talents [[talent:123373]] **Subtlety Rogue** Single-Target talents in Raids
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[spell:185313]]
  
  - [[spell:185313]] puts you in a stance where you can use all your stealth abilities while buffing your damage for its duration. This is your bread and butter spell for your cooldown windows and is a major contributor to your core gameplay.
- [[spell:382528]]
  
  - This talent makes it so each unique spell cast during [[spell:185313]] deals extra damage.
- [[spell:426594]]
  
  - This talent modifies your [[spell:185313]] to generate double combo points from [[spell:196911]] and causes your finishers to generate combo points if you have enough to fill your combo point bar.
- [[spell:121471]]
  
  - [[spell:121471]] causes most of your damage to be increased by 26% and all your combo point generators to generate double the combo points.

##### Class Tree

- [[talent:114737]]
  
  - Your strongest defensive utility that lets you play aggressively with no fear of dying.

##### Hero Talents

- [[talent:117706]]
  
  - This is your default pick for all scenarios since [[talent:126030]] is significantly weaker numerically.
- [[talent:126029]] 
  
  - This is your default pick or almost all scenarios, [[talent:117703]] may have some value but it's very niche and [[talent:126029]] is solid all around.
- [[talent:117720]]
  
  - This is your default pick since [[talent:126027]] does not do anything in raid encounters.
- [[talent:117728]]
  
  - This is your default pick for most scenarios, [[talent:126028]] is the other option. Currently [[talent:117728]] seems to be a bit stronger numerically.




### [[talent:123370]] Single Target

:::talents [[talent:123370]] **Subtlety Rogue** Single-Target and cleave talents in Raids
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA"
}
```
:::

**700~ Haste minimum**

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Hero Talents

Changed to [[talent:123373]] to [[talent:123370]] for more info visit the Hero Talent section above.

- [[talent:120132]] 
  
  - This is your default pick for all scenarios since [[talent:117713]] is not very good.
- [[talent:117734]]
  
  - This is your default pick for all scenarios since [[talent:120131]] seems more like a PvP Talent.
- [[talent:117738]]
  
  - This is your default pick for all scenarios since [[talent:120130]] is worse in comparison.
- [[talent:117731]]
  
  - Although not very useful for raiding, the alternative is even more useless.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: [[spell:53]] costs 10 less Energy and has 100% increased damage. [[spell:197835]] costs 5 less Energy and has 60% increased damage.
- **4-Set**: [[talent:112619]] now also benefits [[spell:15691]] and [[spell:319175]] at 100% effectiveness.

### Single-Target



#### [[talent:123370]]

##### Opener

- Your main goal with your cooldowns as a **Subtlety Rogue** is stacking as many of them as possible for maximum burst potential. There are a few priorities and rules when it comes to using your cooldowns as efficiently as possible.

:::rotation [[talent:123370]] **Subtlety Rogue** Single-Target Raid opener
```json
{
  "source_code": "JEGgKIkXULAAAAwACFo2BAAACF-0CAAABwprDAAAAAgQPiEBFgAB2NTCQAgXFwCEAI0S9AQABUBC-gBAo4F1CAAAAAgQPiEB"
}
```
1. [[spell:185438]]  [[spell:121473]] · [[spell:185313]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:209782]]
4. [[spell:185438]]
5. [[spell:15691]]
6. [[spell:15691]]
7. [[spell:185438]]
8. [[spell:15691]]
9. [[spell:185438]]
10. [[spell:280719]]
:::

1. When your [[spell:121471]] has 8s remaining, use your second [[spell:169629]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

The rotational priority for **Subtlety Rogue** changes based on whether you have [[spell:185313]] active or not:

###### Shadow Dance Priority

1. Cast [[spell:280719]] as your first finisher if above 5 combo points.
2. Cast [[spell:196819]] if above 5 combo points if your target is [[spell:441224]] and [[talent:112578]] is up.
3. Cast [[spell:185438]] if under 5 combo points.
4. Cast [[spell:209782]] on cooldown.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with less than 4 [[spell:441786]] stacks with 6+ combo points.
2. Cast [[spell:53]].

###### Cooldown Usage

- Cast [[spell:121471]].
- Cast [[spell:185313]]
- Cast [[spell:280719]] on cooldown at 6 or more Combo Points.
- Cast [[spell:209782]] on cooldown.




#### [[talent:123373]]

##### Opener

:::rotation [[talent:123373]] **Subtlety Rogue** Single-Target Raid opener
```json
{
  "source_code": "JYcAQ2gQeRtAAAAABIEX5bAAAI0S9AAAA8gMgMFdhN2azBybmBCRT1UEdADQHAAAAAgACtMBDAAAuEDAE4QMJEjOwAAC2NzABEDCCF-0BMGBEIUH4gQAc6aCcASgaHAAAI0jIRQBFSgY5HQhE4F1BADEBIExcNRET2BCA4VBeADACtUPAAAAAAgQeRtA"
}
```
1. [[spell:185438]]  [[spell:457052]]
2. [[spell:15691]] 2 Stacks of DSM [[spell:457052]]
3. [[spell:1856]]  [[spell:197835]] · [[spell:457052]]
4. [[spell:15691]] 1 Stack of DSM [[spell:457052]]
5. [[spell:209782]]
6. [[spell:185313]]  [[spell:197835]] · [[spell:457052]] · [[item:241308]] · [[spell:121473]]
7. [[spell:280719]]  [[spell:457058]]
8. [[spell:185438]]  [[spell:1268932]]
9. [[spell:15691]]
10. [[spell:15691]]
11. [[spell:185438]]
12. [[spell:15691]]
13. [[spell:185438]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

The rotational priority for **Subtlety Rogue** changes based on whether you have [[spell:185313]] active or not:

###### Shadow Dance Priority

1. Cast [[spell:196819]] with [[spell:457058]] and [[spell:1268932]] active at 7 Combo Points.
2. Cast [[spell:280719]] if available at 6+ combo points.
3. Cast [[spell:185438]] if under 5 combo points.
4. Cast [[spell:197835]] as your first builder if you start your dance at 2 or less Combo Points.
5. Cast [[spell:209782]] on cooldown.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with [[spell:457058]] and [[spell:1268932]] active at 7 Combo Points.
2. Cast [[spell:196819]] with 5+ combo points.
3. Cast [[spell:53]].
4. Cast [[spell:209782]] on cooldown.





### 2 Targets



#### [[talent:123370]]

##### Opener

- Your main goal with your cooldowns as a **Subtlety Rogue** is stacking as many of them as possible for maximum burst potential. There are a few priorities and rules when it comes to using your cooldowns as efficiently as possible.

:::rotation [[talent:123370]] **Subtlety Rogue** Single-Target Raid opener
```json
{
  "source_code": "JEGgKIkXULAAAAwACFo2BAAACF-0CAAABwprDAAAAAgQPiEBFgAB2NTCQAgXFwCEAI0S9AQABUBC-gBAo4F1CAAAAAgQPiEB"
}
```
1. [[spell:185438]]  [[spell:121473]] · [[spell:185313]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:209782]]
4. [[spell:185438]]
5. [[spell:15691]]
6. [[spell:15691]]
7. [[spell:185438]]
8. [[spell:15691]]
9. [[spell:185438]]
10. [[spell:280719]]
:::

1. When your [[spell:121471]] has 8s remaining, use your second [[spell:169629]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

The rotational priority for **Subtlety Rogue** changes based on whether you have [[spell:185313]] active or not:

###### Shadow Dance Priority

1. Cast [[spell:280719]] as your first finisher if above 5 combo points.
2. Cast [[spell:196819]] if above 5 combo points if your target is [[spell:441224]] and [[talent:112578]] is up.
3. Cast [[spell:185438]] if under 5 combo points.
4. Cast [[spell:209782]] on cooldown.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with less than 4 [[spell:441786]] stacks with 6+ combo points.
2. Cast [[spell:53]].
3. Cast [[spell:209782]] on cooldown.

###### Cooldown Usage

- Cast [[spell:121471]].
- Cast [[spell:185313]]
- Cast [[spell:280719]] on cooldown at 6 or more Combo Points.
- Cast [[spell:209782]] on cooldown.




#### [[talent:123373]]

##### Opener

:::rotation [[talent:123373]] **Subtlety Rogue** Single-Target Raid opener
```json
{
  "source_code": "JYcAQ2gQeRtAAAAABIEX5bAAAI0S9AAAA8gMgMFdhN2azBybmBCRT1UEdADQHAAAAAgACtMBDAAAuEDAE4QMJEjOwAAC2NzABEDCCF-0BMGBEIUH4gQAc6aCcASgaHAAAI0jIRQBFSgY5HQhE4F1BADEBIExcNRET2BCA4VBeADACtUPAAAAAAgQeRtA"
}
```
1. [[spell:185438]]  [[spell:457052]]
2. [[spell:15691]] 2 Stacks of DSM [[spell:457052]]
3. [[spell:1856]]  [[spell:197835]] · [[spell:457052]]
4. [[spell:15691]] 1 Stack of DSM [[spell:457052]]
5. [[spell:209782]]
6. [[spell:185313]]  [[spell:197835]] · [[spell:457052]] · [[item:241308]] · [[spell:121473]]
7. [[spell:280719]]  [[spell:457058]]
8. [[spell:185438]]  [[spell:1268932]]
9. [[spell:15691]]
10. [[spell:15691]]
11. [[spell:185438]]
12. [[spell:15691]]
13. [[spell:185438]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

The rotational priority for **Subtlety Rogue** changes based on whether you have [[spell:185313]] active or not:

###### Shadow Dance Priority

1. Cast [[spell:196819]] with [[spell:457058]] and [[spell:1268932]] active at 7 Combo Points.
2. Cast [[spell:280719]] if available at 6+ combo points.
3. Cast [[spell:185438]] if under 5 combo points.
4. Cast [[spell:197835]] as your first builder if you start your dance at 2 or less Combo Points.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with [[spell:457058]] and [[spell:1268932]] active at 7 Combo Points.
2. Cast [[spell:196819]] with 5+ combo points.
3. Cast [[spell:53]].





### 4+ Targets



#### [[talent:123370]]

##### Opener

:::rotation **Subtlety Rogue** AoE opener in Raids
```json
{
  "source_code": "JkEXHI0yEMAAAAwAC1plCAAAC9n2BAAABwprBQBDAIkdzkACc8ISEAAAAAgQJwCDAIkyebDEAgwT8aA"
}
```
1. [[spell:197835]]  [[spell:169629]] · [[spell:121471]] · [[item:241308]]
2. [[spell:209782]]
3. [[spell:280719]]
4. [[spell:197835]]
5. [[spell:319178]]
6. [[spell:197835]]
7. [[spell:441423]]
:::

##### 4+ Targets Priority List

###### Shadow Dance Priority

1. Cast [[spell:280719]] as your first finisher if above 5 combo points.
2. Cast [[spell:209782]] on cooldown.
3. Cast [[spell:319175]] if above 5 combo points.
4. Cast [[spell:197835]] if under 5 combo points.

###### No Shadow Dance Priority

1. Cast [[spell:319175]] with less than 4 [[spell:441786]] stacks with 5+ Combo Points.
2. Cast [[spell:15691]] if you have 4 [[spell:441786]] stacks with 5+ Combo Points.
3. Cast [[spell:197835]].




#### [[talent:123373]]

##### Opener

:::rotation [[talent:123373]] **Subtlety Rogue** AoE opener in Raids
```json
{
  "source_code": "IEFXII0yEMAAAAwAC1plCAAAC9n2BAAABwprBQBMAI0jIRAAAAAAC5F1CUACEMNAJgRC0wAACps3JACKLTwAAAAAAI0T8aA"
}
```
1. [[spell:197835]]  [[spell:169629]] · [[spell:121471]] · [[item:241308]]
2. [[spell:280719]]
3. [[spell:185438]]
4. [[spell:196819]]
5. [[spell:197835]]
6. [[spell:319178]]
7. [[spell:197835]]
8. [[spell:441423]]
:::

##### 4+ Targets Priority List

###### Shadow Dance Priority

1. Cast [[spell:209782]] on cooldown.
2. Cast [[spell:280719]] as your second finisher with 5+ combo points.
3. Cast [[spell:319175]] at 5+ combo points.
4. Cast [[spell:197835]] if under 5 combo points.

###### No Shadow Dance Priority

1. Cast [[spell:196819]] with 7+ combo points with [[talent:117739]] buff active.
2. Cast [[spell:319175]] with 5+ combo points.
3. Cast [[spell:197835]].





## Deep Dive

:::columns
:::column


:::

:::

#### Deathstalker

- [[talent:123373]] while not as complicated rotational changes as [[talent:123370]] still comes with a few optimizations such as:
  
  - Always building to maximum combo points when [[talent:117739]] is up, and proccing your [[spell:1268932]].

### Eviscerate vs Black Powder

- When to use [[spell:196819]] over [[spell:319175]]  might seem obvious or easy if you simply refer to your priority. However, the reality is not as black and white.

- A lot of people who play **Subtlety Rogue** see a bunch of targets and instantly start pressing [[spell:319175]] without much thought behind it, however, there are situations where you would want to press [[spell:196819]], even if at the cost of  DPS.
- Priority damage to your main targets is often more useful than so called "pad damage" to targets of lesser importance, which is your main consideration when deciding what finisher you decide to use.

### Secret Technique Intricacies

- [[spell:280719]] is your hardest hitting spell, so it's important that you understand how it works and some common mistakes.
- [[spell:280719]] has an initial instant damage part and two delayed shadow clone attacks, one of them being delayed by 1 second and the other by 1.3 seconds. To clarify, this means that the latest time you can press [[spell:280719]] to get its full damage in your [[spell:185313]] window is 1.3 seconds before it ends. This is very important since you lose a lot of damage not getting the damage inside of your [[spell:185313]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Subtlety Rogue** Nek'Zali Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.




### Entombed Sentinels

:::talents **Subtlety Rogue** Entombed Sentinels Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].
- Look at your raid frames and use your [[spell:36554]] in the intermission to clear the stacking buff.




### Lost Explorers

:::talents **Subtlety Rogue** Lost Explorers Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02shZYmZmBzYA"
}
```
:::

#### Boss Tips

- Pay attention to [[spell:1296062]], try to bait them on the outside of the room.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed after being used once.




### Vashnik

:::talents **Subtlety Rogue** Vashnik Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.




### Sszorak

:::talents **Subtlety Rogue** Sszorak Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

#### Boss Tips

- In case you fail to find a partner to deal with [[spell:1285419]], keep in mind that you can also negate it with [[spell:36554]] or [[spell:31224]].
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.




### Twin Fangs

:::talents **Subtlety Rogue** Twin Fangs Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.




### Coiled Altar

:::talents **Subtlety Rogue** Coiled Altar Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTmZbbMmZYYmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].




### Ula'tek

:::talents **Subtlety Rogue** Ula'tek Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::




### Nymrissa Wavecaller

:::talents **Subtlety Rogue** Nymrissa Wavecaller Talents
```json
{
  "source_code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA",
  "code": "CWQAxSGv8NzbxeTO653C6Eg9HDgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL02sgZYmZmBzYA"
}
```
:::

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle, so position accordingly or be ready to negate the knockback with [[spell:36554]].
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Subtlety Rogue**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Subtlety Rogue** Stat Priorities in Raid
```json
{
  "source_code": "JoAJFMQMkACKBMQABA"
}
```
**敏捷 ＞ 精通 ≥ 急速 ＞ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** -  Avoidance works similarly to [[spell:1966]], as it provides you with passive AoE damage reduction. Therefore, due to the significant amount of avoidance you already receive from [[spell:1966]], it loses value compared to other classes.
- **Leech** - Provides additional healing through damage dealing. Great stat for staying alive and healthy.
- **Speed** -  Speed is the worst out of the three tertiary stats because you are already very fast, it is of course better than nothing.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271508@DwQAAUQAXk74kgC4UA]] | The Lost Explorers / Catalyst |
| Cloak | [[item:251190@BgQAAMQACKgTBA]] | The Blinding Vale |
| Chest | [[item:271513@DgQAAMQAJk7IoAOF]] | Vashnik the Malignant / Catalyst |
| Wrist | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | Crafting |
| Gloves | [[item:271511@BgQAAMQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:268256@BiQAAUQAS06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]] into [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268261@DgQAAUQAPk7IoAOF]] | The Twin Fangs |
| Ring 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:268249@DiQAAMQA1j7oQrjgC4UA]] | Vashnik the Malignant |
| Trinket 1 | [[item:270175@BgwAAMQACKAWBUAABo0FCA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAUQACKAWBA]] | The Coiled Altar |
| Weapon | [[item:271093@DgQAAMQADk7IoAYF]] | Ula'tek |
| Weapon | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | Crafting |

Subtlety Rogue BiS list in Raids




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | Altar of Fangs |
| Neck | [[item:273781@BiQAAMQAH16IoABF]] | Altar of Fangs |
| Shoulder | [[item:251223@DgQAAMQAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:251190@BgQAAMQACKQQBA]] | The Blinding Vale |
| Chest | [[item:251159@DgQAAMQAJk7IoABF]] | Den of Nalorakk |
| Wrist | [[item:251135@BiQAAMQAU06IoABF]] | Murder Row |
| Gloves | [[item:251124@BgQAAMQACKQQBA]] | Murder Row |
| Belt | [[item:159317@BiQAAMQAE06IoABF]] | Temple of Sethraliss |
| Legs | [[item:251130@DgQAAMQAhu7IoABF]] | Murder Row |
| Boots | [[item:159327@DgQAAMQAPk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@DiQAAMQA1j7wPrjgCEUA]] | Temple of Sethraliss |
| Ring 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:250215@BgQAAMQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAAMQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAMQACKAWBUAABo0FCA]]  <br>[[item:270173@AgQAAIoAYFA]] |
| **A-Tier** | [[item:270164@AgQAA8rBOFA]] |
| **B-Tier** | [[item:159617@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **Junkyard** | [[item:270166@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]] |

### Embellishments

- [[item:273059]]
- [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- Your go to flask for all scenarios.*
  - [[item:241324]] *-- If you need to meet the haste requirement.*
- **Food**
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stone**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  
  
  
  - [[item:240918]]
  - [[item:240908]]
  - [[item:240892]]
  
  
  
  - [[item:240966]] *-- Unique, use one of each gem color to enhance your [[item:240966]].*

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAMQAnk7A]] - [[item:244007]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAUQA]] |
| Cloak |  |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@DAAAAMQAnk7A]] |
| Waist | [[item:275707@DAAAAMQAnk7A]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:243957@BAAAAMQA]] |
| Ring 2 | [[item:243957@BAAAAMQA]] |
| Weapon | [[item:244031]] |
| Weapon | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **Subtlety Rogue** Enchantments in Raids
```json
{
  "source_code": "JwFZFEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCo8TuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAMQAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Subtlety Rogue** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:312924]] -- Mechagnome
  
  - Not a very useful active racial. The two passive racials, however [[spell:312916]] and [[spell:312923]] are both quite strong, making Mechagnome a solid pick.
- [[spell:65116]] -- Dwarf
  
  - Can dispel Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:255654]] -- Highmountain Tauren
  
  - Charge forward and stun enemies for 1.5 seconds, not the most useful ability for raiding but you do get access to [[spell:255658]] which is a passive versatility increase.
- [[spell:33702]] --Orc
  
  - Strong racial for damage, especially for [[talent:112607]] builds, due to your [[spell:121471]] being a 2 minute cooldown.
- [[spell:20549]] -- Tauren
  
  - Typically not the most useful spell for raiding but similar to dwarf, the [[spell:154743]] Passive is the main reason why Tauren is a strong dps race.
- [[spell:256948]] -- Void Elf
  
  - This ability can be quite nice as it acts similar to blink that you first shoot out as a projectile, then re-activate to teleport to the projectile's location. However, the reason why it's a strong dps race is [[spell:255669]].
- [[spell:59752]] -- Human
  
  - There are rarely any good use cases for this spell but it can happen. The main reason why human is a strong choice is thanks to the [[spell:20598]] passive. Keep in mind that Human scales further the more secondary stats you have so it may not be very good at the start of an expansion but rather later on.

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the latest Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Subtlety Rogue** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
**Mouseover [[spell:408]] Macro** - Casts on your mouseover or target if there are is no mouseover target present.

```wow-macro
#showtooltip Kidney Shot
/use [@mouseover,exists][]Kidney Shot
```

**Mouseover Focus macro -** very handy when selecting a focus **target to make you not have to target it.**

```wow-macro
/focus [@mouseover,exists][]
```

:::

:::details Focus Macros
**Focus [[spell:1833]] Macro.**

```wow-macro
#showtooltip Cheap Shot
/cast [@focus] Cheap Shot
```

**Focus [[spell:408]] Macro.**

```wow-macro
#showtooltip Kidney Shot
/cast [@focus] Kidney Shot
```

**Focus [[spell:1766]] Macro.**

```wow-macro
#showtooltip Kick
/cast [target=focus,exists,nodead] [] Kick
```

:::

:::

:::accordion
:::details Shadow Dance Macros
Shadow Dance > Secret Technique. Make sure you are not on GCD

```wow-macro
#showtooltip
/cast Shadow Dance
/cast Secret Technique
```

Shadow Dance > Shuriken Storm

```wow-macro
#showtooltip
/cast Shadow Dance
/cast Shuriken Storm
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Subtlety Rogue**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://i.gyazo.com/cd27ad7c7ee352aeff1bedbac42220e8.jpg>)

**Subtlety Rogue** Interface

:::accordion
:::details Addons
- **Ellesmere UI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**ROGUE**

- Class
  
  - Thistle Tea is now a choice talent – Players may now choose between the existing version, which casts automatically at low Energy in addition to being usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds). Duration remains unchanged in PvP combat.
- Hero Talents
  
  - Deathstalker
    
    - Fixed an issue that caused Unshakable Drive's bonus to multiply with each stack.
    - Fixed an issue that often caused Unshakable Drive to remove more than one stack per ability use.

- Subtlety
  
  - Developers' notes: We've made some updates to Subtlety's resource economy in Curses of Ula'tek, including the removal of a double-generation bug that made the desired intent and combat feel unclear. Base effect rate and Energy generation of Shadow Techniques are being increased to make moments outside of Shadow Dance feel less starved, while preserving the same proc rate and combo point generation within Shadow Dance. Energy generation should still grow during cooldowns, but not nearly as drastically as before.
  - Goremaw’s Bite has been redesigned – Lash out at your target and 2 additional nearby enemies, inflicting Shadow damage and causing them to Bleed over 14 seconds. 20% of all damage from Finishing Moves is repeated as Shadow, split evenly among affected enemies.
  - Shadowcraft has been updated - While Shadow Dance is active, your Shadow Techniques triggers 25% more frequently and generates 1 additional combo point.
  - All damage dealt increased by 2%. This does not apply to PvP combat.
  - The First Dance now increases Shadow Dance duration by 4 seconds (was 3 seconds).
  - Relentless Strikes now generates 4 Energy per combo point spent on finishing moves (was 5 Energy).
  - Shadow Techniques' base effect frequency has been increased by 40%.
  - Shadow Techniques' Energy generation has been increased to 5 (was 4).
  - Lingering Shadow now also applies to Shuriken Storm.
  - Shadow Dance's tooltip has been updated to include its threat reduction effect.
  - Apex Talent: Ancient Arts now considers the total damage of Secret Technique when creating a shadow clone, instead of only its initial hit.
  - Fixed an issue that caused Secret Technique damage from secondary hits to be attributed to summoned pets instead of the attacking Rogue.
  - Some talents have changed positions in the talent tree.

:::

:::

## FAQ

:::accordion
:::details Q: Why is my Energy so low that I can't hit my buttons sometimes?
A: Pooling Energy is a common aspect of Rogue gameplay. It's normal to sometimes feel like you're struggling with energy, even if you're playing correctly.

:::

:::

---

### Credits

Written By: **Perfecto**

Reviewed By: **Verb**

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-17** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-10** Updated for patch 12.0.1.

**2026-01-13** Updated for patch 12.0.

**2025-12-03** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-07-29** Updated for patch 11.2.

**2025-06-19** Updated for patch 11.1.7.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-14** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7.

**2024-07-24** Guide Written for the pre-patch 11.0



:::
