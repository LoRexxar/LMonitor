Welcome to the **Unholy Death Knight** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single Target** · 3/5 · Average

AoE · 4/5 · Good

Utility · 3/5 · Average

Survivability · 5/5 · Excellent

Mobility · 4/5 · Good



:::

:::

:::column
:::gear **Unholy Death Knight** Best in Slot
```json
{
  "source_code": "JUoAwTF_Ac__AEgckQggIUAAnk7AX16A5IgTBYP1DEQ6XQAAREAAC06AC06AMWTOCgVABAHJEAACFAQOC4UACU9ABUHJEIACFAQC5OQOCgVA-eBBBM-FEAICFUDs5IAWBEgBmQAAQEAACKgF2gVABQQoDYACBAgHAPwJqOQK5Owt1sUABoQoDQIIRUBDC06AAUQAFsBFzRCBAgQAF4GJBAYLEIICBAQ94GAJcIoAOFQAil9A6IBAE01HNADDYFQAfFADEMAABYIIFAQAtchAB09FZ4BN1eBBQgQAAoa_EkjAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271472]] |  |
| 胸部 | [[item:271477]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240898]] |
| 腿部 | [[item:271878]] |  |
| 脚部 | [[item:237828]] | [[item:245790]] · [[item:240167]] · [[item:244009]] |
| 腕部 | [[item:237834]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:273792]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[spell:327082]] |
:::

:::

:::

## Midnight Changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Unholy Death Knight**, you have access to Forbidden Knowledge which causes [[spell:42650]] to empower your Runic Power spenders for 30 seconds, turning [[spell:47541]] into [[spell:1242174]], increasing its damage and allows it to do full damage to up to 3 targets and turns [[spell:207317]] into [[spell:383269]], buffing its damage.

**Rank 2** gives you a passive effect that causes [[spell:1247378]] to give you 1 stack of [[spell:1254252]], and give you a Mastery buff, [[spell:1256576]], for 12 seconds. Each application of [[spell:1256576]] has its own duration.

**Rank 3** causes [[spell:1240996]] to have a 20% chance to trigger [[spell:1247378]], interacting heavily with **Rank 2**, giving you consistent Mastery buffs throughout the fight.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-unholy-mxr.webp>)

Forbidden Knowledge

:::

:::

### Core Changes

Going into Midnight, **Unholy Death Knight** has received a substantial rework that changes core abilities and resources. In this section, we go over the changes you need to know about for **Unholy**. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:85948]] 
    
    - No longer applies [[spell:197147]] and has been replaced with [[spell:1254252]] as your maintenance buff that [[spell:85948]] manages.
  - [[spell:55090]] 
    
    - Has a 30 yard range baseline and summons 1 [[spell:1277098]] per cast, assuming you have a stack of [[spell:1254252]].
    - [[spell:1241567]] is now a talent you automatically take, allowing it to always cleave up to 4 additional targets based on your stacks, albeit with reduced damage.
  - [[spell:77575]] 
    
    - Applies a new plague, [[spell:1240996]], to the target it is initially cast on.
      
      - [[spell:1240996]] can only be applied to one target at a time while [[spell:191587]] can still be applied to all targets.
  - [[spell:47541]] and [[spell:207317]] 
    
    - Both extend the duration of your plagues by 1 second per cast.
  - [[spell:1247378]] 
    
    - A **very** important new addition to your kit in Midnight. With talents further down in the talent tree, this becomes an extremely powerful ability with multiple hooks to other abilities.
  - [[spell:42650]] 
    
    - Cooldown reduced to 90 seconds baseline, down from 3 minutes.
      
      - [[spell:288853]] and [[spell:1242147]] haven’t been removed; they now sit on a choice node directly beneath [[spell:42650]] and are automatically summoned when [[spell:42650]] is cast and you are talented into one of them.
  - [[spell:343294]] 
    
    - Changed from the class tree to be **Unholy** only and has a longer cooldown, 15 seconds up from 8 seconds, buffs your minion, disease, and [[spell:1247378]] damage against that target by 20% for 8 seconds.
  - [[spell:49530]] 
    
    - Triggers from [[spell:1240996]] ticks instead of auto attacks.
  - [[talent:125816]] 
    
    - No longer summons a [[spell:390196]] and instead spawns a [[spell:1277098]].
  - [[spell:458128]] 
    
    - Reworked and now transforms into a free cast of [[spell:85948]] after each initial cast of [[spell:85948]] that increases the speed that your plagues tick.
  
  
  
  - [[spell:327087]]
    
    - Additionally triggers from [[spell:1277098]].
- **Class Tree**
  
  - [[talent:136524]]
    
    - Removes the Runic Power cost from [[spell:61999]]!
  - [[talent:136525]]
    
    - A new talent to reduce the cooldown of [[talent:96204]] and increases the speed that the healing absorb gets removed.
  - [[talent:96187]]
    
    - [[spell:49039]] is no longer a defensive cooldown and only provides charm, fear, and sleep immunity as well as a small amount of Leech while it is active.
  - Various talents have been moved around, generally being easier to get.
- **Removed**
  
  - [[spell:197147]]
    
    - [[spell:85948]] no longer applies [[spell:197147]]. Good riddance.
  - [[spell:275699]] 
    
    - This has been removed from the game leaving [[spell:1233448]] as your only 45 second cooldown.
  
  
  
  - [[spell:207289]] 
    
    - Removed, leaving [[spell:42650]] as your only 90 second cooldown.
  
  
  
  - [[talent:96202@FAQAvchA]] has been reworked and the mechanic has been removed.
    
    - Your aoe rotation now has significantly less setup and no longer requires you to stand in [[spell:43265]].

#### What does this mean for you?

All in all, there are a lot of changes but if you played **Unholy** before, this is a simplified version of it.

- There are significantly less cooldown abilities to press, dropping to only 2 down from 4 or 5 depending on what you were talented into.
- [[spell:197147]] are gone in exchange for [[spell:1254252]] but are essentially the same thing, instead stacking on you rather than your target(s).
- [[spell:1247378]] is a new and very powerful ability that has interactions with the majority of your kit and talent tree.
- Your aoe rotation has significantly less setup and no longer requires you to stand in [[spell:43265]].
  
  - Keep it keybound as there are still a few scenarios where you want to press it!

### Ability and Talent Changes

The **Unholy** specialization has undergone an extensive redesign and reorganization going into Midnight. This section goes over all abilities and their hooks with talents and what they do together, Hero Talent interactions are in the section below.

**← Scroll for all Abilities →**

:::tabs
:::tab [[spell:85948]]+[[spell:1277098]]
#### Festering Strike

##### Baseline

- Gives you a buff that causes [[spell:55090]] to summon 1 [[spell:1277098]] per cast that stacks up to 8 times.
- Melee range, the only baseline ability in your kit that requires you to be in melee.

##### Important Interactions

- [[talent:96330]]
  
  - One of the most important talents on your tree as this gives you a free cast of [[spell:85948]] after each cast of it. Essentially this allows you to spend half of the Runes you would otherwise spend pressing [[spell:85948]] to ensure you are always summoning a [[spell:1277098]] on your [[spell:55090]].
  - In addition to the free [[spell:85948]] effect, it also increases the speed that your plagues tick for 25 seconds.

##### Passive Interactions

- [[spell:377514]]
  
  - Increases its damage by 30% when the target is below 35% health.

#### Lesser Ghoul

##### Baseline

- Has a duration of 6 seconds.

##### Important Interactions

- [[talent:96283]]
  
  - Increases the duration of your [[spell:1277098]] by 25/50% of your Mastery.
- [[spell:1241705]]
  
  - Casting [[spell:1233448]] allows your [[spell:1277098]] to cast [[spell:1278150]], during its duration, significantly increasing your ability to aoe with this set of talents.
  
  
  
  - Increases the damage of your [[spell:1277098]] by 10%.

##### Passive Interactions

- [[talent:125816]]
  
  - Consuming [[spell:49530]] summons a lesser ghoul for 6 seconds.
- [[spell:288848]]
  
  - Causes your ghouls to explode when they expire.

:::

:::tab [[spell:55090]]
#### Scourge Strike

##### Baseline

- Has a 30 yard range, allowing you to interact with the majority of your kit from range.
- Summons a [[spell:1277098]] if you have a stack of it from casting [[spell:85948]].
- Causes your plagues to erupt for 35% of a normal tick.
- Applies and spreads [[spell:191587]] to unaffected nearby targets.

##### Important Interactions

- [[spell:1241567]]
  
  - Allows [[spell:55090]] to cleave up to 4 additional targets, at a reduced amount of damage per cleave.
- [[spell:276023]]
  
  - Summoning a [[spell:1277098]] with [[spell:55090]] reduces the cooldown of [[spell:1247378]] by 2.5 seconds.
- [[spell:1242604]]
  
  - If you are talented into this, it allows [[spell:1241567]] to stack 2 additional times, allowing [[spell:55090]] to hit up to 7 targets.
  - Causes your diseases to erupt for 50/70% of a normal tick, up from the baseline 35%.

##### Passive Interactions

- [[spell:377514]]
  
  - Increases its damage by 30% when the target is below 35% health.

:::

:::tab [[spell:1247378]]
#### Putrefy

##### Baseline

- Summons a [[spell:1277098]] that explodes and deals aoe damage.
- Has a 40 yard range.

##### Important Interactions

- [[spell:377580]]
  
  - Gives you three charges and increases its damage.
  - Casting [[spell:1247378]] consumes up to 2 stacks.
- Forbidden Knowledge
  
  - [[spell:1247378]] give you a stack of [[spell:1254252]] and gives you a stack of [[spell:1242158]], increasing your Mastery by 6% for 12 seconds.
    
    - Each stack has its own duration.
- [[spell:1254552]]
  
  - [[spell:1247378]] now applies both diseases to your main target and [[spell:191587]] to all other targets hit.
  - Extends the duration of your plagues by 3 seconds and deals a small amount of additional damage to all targets hit.
- [[spell:276023]]
  
  - Summoning a [[spell:1277098]] with [[spell:55090]] reduces the cooldown of [[spell:1247378]] by 2.5 seconds.
- [[spell:343294]]
  
  - Automatically casts all charges of [[spell:1247378]].
- [[talent:133513]]
  
  - After consuming your your diseases you recieve a free charge of [[spell:1247378]] allowing you to immediately reapply your diseases via [[spell:1254552]].
- [[spell:1290864]]
  
  - [[spell:1247378]] reduces the cooldown of [[spell:43265]] by 1 second.
  - [[spell:43265]] reduces the cooldown of [[spell:1247378]] by .3 per target hit up to 3 seconds.
    
    - This means that hitting 10 targets with [[spell:43265]] reduces the cooldown of [[spell:1247378]] by 3 seconds each tick. You can get up to 30 seconds of cooldown reduction per [[spell:43265]].

##### Passive Interactions

- [[talent:135676]]
  
  - Causes the initial ghoul that explodes to reanimate as a [[spell:288417]].
- [[spell:1241858]]
  
  - Passively buffs your ghoul's attack speed when you cast [[spell:1247378]].

:::

:::tab [[spell:191587]]+[[spell:1240996]]
#### Virulent Plague and Dread Plague

##### Baseline

- [[spell:1240996]]
  
  - Can only be applied to 1 target.
- [[spell:191587]]
  
  - Can be applied to all targets hit by your plague applying abilities.

##### Important Interactions

- [[spell:55090]]
  
  - Spreads [[spell:191587]] to unaffected nearby targets.
- [[spell:47541]] and [[spell:207317]]
  
  - Both of these extend the duration of [[spell:191587]] and [[spell:1240996]] by 1 second per cast.
- [[spell:207269]]
  
  - Reduces the overall duration of your plagues, but increases the damage they deal.
- [[spell:458128]]
  
  - Increases the speed that your diseases tick on all targets for 25 seconds.
- [[spell:1254552]]
  
  - [[spell:1247378]] now applies both diseases to your main target and [[spell:191587]] to all other targets hit as well as increasing the duration of your plagues by 3 seconds to all targets hit.
- [[spell:1271967]]
  
  - Casting [[spell:63560]] converts your next [[spell:77575]] into [[spell:1271967]], consuming your plagues and increasing the damage they deal, while giving you a stack of [[spell:1247378]] that can reapply your plagues.
- [[spell:49530]]
  
  - Triggers off of [[spell:1240996]] ticks.

##### Passive Interactions

- Forbidden Knowledge
  
  - Each tick of [[spell:1240996]] has a 20% chance to cast a [[spell:1247378]] at 60% effectiveness.
- [[spell:377592]]
  
  - Increases the enemies' damage taken by 1% per disease.
- [[spell:1242604]]
  
  - Causes your diseases to erupt for 50/70% of a normal tick, up from the baseline 35%.
- [[spell:390283]]
  
  - Passive Runic Power generation talent and causes your [[spell:1240996]] to deal 75% of its damage to another target.
- [[spell:390166]]
  
  - Increases the critical damage of your diseases.

:::

:::tab [[spell:47541]]
#### Death Coil

##### Baseline

- Single-target 30 Runic Power spender.
- Each cast extends the duration of [[spell:191587]] and [[spell:1240996]] on your target by 1.5 seconds.

##### Important Interactions

- [[spell:49530]]
  
  - Reduces the Runic Power cost by 15 and causes it to deal 35% increased damage
- [[spell:1233448]]
  
  - Each cast of [[spell:47541]] extends the duration of [[spell:1233448]] by 1 second.
- Forbidden Knowledge
  
  - Transforms [[spell:47541]] into [[spell:1242174]], allowing it to deal full damage to 3 targets and a small amount of damage to all targets hit.
    
    - This becomes a projectile meaning you have to aim where you are casting, but the projectile has a substantially bigger hitbox than the animation makes it seem.

##### Passive Interactions

- [[spell:390270]]
  
  - Increases the damage of [[spell:47541]] and leaves a dot effect.
- [[spell:194916]]
  
  - Consuming [[spell:49530]] fires a [[spell:1239356]].
- [[spell:377514]]
  
  - Increases its damage by 30% when the target is below 35% health.

:::

:::tab [[spell:207317]]
#### Epidemic

##### Baseline

- Aoe 30 Runic Power spender, hits every target that is affected by [[spell:191587]].
- Each cast extends the duration of [[spell:191587]] and [[spell:1240996]] by 1.5 seconds.

##### Important Interactions

- [[spell:49530]]
  
  - Reduces the Runic Power cost by 15 and causes it to deal 35% increased damage
- [[spell:1233448]]
  
  - Each cast of [[spell:207317]] extends the duration of [[spell:1233448]] by 1 second.
- Forbidden Knowledge
  
  - Transforms [[spell:207317]] into [[spell:383269]], buffing its damage.

##### Passive Interactions

- [[spell:194916]]
  
  - Consuming [[spell:49530]] fires a [[spell:1239356]] that hits 5 targets.

:::

:::tab [[spell:343294]]
#### Soul Reaper

##### Baseline

- Deals damage instantly and increases the damage of your diseases and minions by 20% for 8 seconds.
- Only usable on enemies below 35% health.
- 15 second cooldown
- Consumes 3 stacks of [[spell:1254252]] to summon them instantly.

##### Important Interactions

- [[spell:377514]]
  
  - Casting [[spell:1233448]] resets the cooldown of [[spell:343294]] and allows it to be used on a target with any amount of health.

:::

:::tab [[spell:1233448]]
#### Dark Transformation

##### Baseline

- Your 45 second cooldown.
- Off the global cooldown.
- Empowers your ghoul for 15 seconds, increasing its damage and unlocks abilities like [[spell:91778]].
- Each cast of [[spell:47541]] and [[spell:207317]] extends the duration of [[spell:1233448]] by 1 second.

##### Important Interactions

- [[spell:377514]]
  
  - Casting [[spell:1233448]] resets the cooldown of [[spell:343294]] and allows it to be used on a target with any amount of health.
- [[spell:1271967]]
  
  - Casting [[spell:63560]] converts your next [[spell:77575]] into [[spell:1271967]], consuming your plagues and increasing the damage the deal, while giving you a stack of [[spell:1247378]] that can reapply your plagues.
- [[spell:390259]]
  
  - [[spell:1233448]] empowers all minions for 30 seconds increasing their damage for 30 seconds.
  - The duration of your [[spell:1277098]] is increased by 25/50% of your Mastery.
- [[spell:1241705]]
  
  - Casting [[spell:1233448]] allows your [[spell:1277098]] to cast [[spell:1278150]] during its duration, significantly increasing your ability to aoe with this set of talents.
  
  
  
  - Increases the damage of your [[spell:1277098]] by 10%.

##### Passive Interactions

- [[spell:390196]]
  
  - Summons a [[spell:390196]] for 15 seconds.

:::

:::tab [[spell:42650]]
#### Army of the Dead

##### Baseline

- Your 90 second cooldown.
- Summons 8 [[spell:1277098]] for 30 seconds.
  
  - These ghouls are 75% stronger than regular [[spell:1277098]].
- Casting [[spell:47541]] or [[spell:207317]] during its uptime causes your Army to deal single-target or aoe damage depending on the cast.

##### Important Interactions

- [[spell:1242608]] and [[spell:1242147]] Choice Node
  
  - [[spell:1242608]] 
    
    - Summons an abomination that emits a disease cloud for 30 seconds that deals damage to nearby enemies.
  - [[spell:1242147]] 
    
    - Summons a gargoyle that lasts 25 seconds and and has its damage increased by 1% for every Runic Power spent during its duration.
- [[spell:390259]]
  
  - [[spell:1233448]] empowers all minions for 30 seconds increasing their damage by 15/30% for 30 seconds.
  - The duration of your [[spell:1277098]] is increased by 25/50% of your Mastery.

##### Passive Interactions

- [[spell:390196]]
  
  - Summons a [[spell:390196]] for 15 seconds.

:::

:::tab


:::

:::

## Hero Talents

- In patch 12.1, [[talent:123322]] Rider of the Apocalypse is the go-to hero talent for all content. [[talent:123321]] San'layn is still playable if you prefer but [[talent:123322]] Rider of the Apocalypse is overall better and easier to play.

:::tabs
:::tab [[talent:123322]] Rider of the Apocalypse
##### Offensive Nodes

- [[talent:117663]] - Each Rune spent gives you a 10% chance to summon one of the following Four Horsemen:
  
  - [[spell:444248]]
    
    - Puts up a [[spell:43265]] that follows him.
      
      - You gain the benefit of [[talent:117664]] if you are standing in it.
  - [[spell:444251]]
    
    - [[spell:444633]] is a disease with a 24 second duration that spreads and gains 1 stack every time you use [[spell:55090]] on the infected target.
  
  
  
  - [[spell:444254]]
    
    - Repeatedly casts [[spell:45524]] over his duration that gets shattered by [[spell:55090]] with [[talent:117660]].
  - [[spell:444252]]
    
    - Grants you 5% Strength, increasing by 1% for every Rune spent while Nazgrim is active.
- [[talent:117638]] 
  
  - Summons all 4 Horsemen for 20 seconds after casting [[spell:455395]]. This lines up with every other use of [[spell:63560]] and [[spell:275699]] making for extremely large burst windows especially when combined with on-use trinkets.
    
    - If a Horsemen is already out, it extends the current duration by 20 seconds instead.
      
      - [[spell:444248]] does not recast his [[spell:43265]] but all other Horsemen recast their abilities.
- [[talent:117639]] or [[talent:123411]] 
  
  - [[talent:117639]] increases the duration of your Horsemen when spending Runic Power which has incredible value for Unholy due to Mastery interactions with the Horsemen's abilities. [[talent:123411]] enables larger [[spell:47541]] and [[spell:207317]] and is interchangeable with [[talent:117639]] depending on if you want more burst quicker, or a little longer on your burst.
- [[talent:117641]]
  
  - Passively increases the damage of your plagues, [[spell:191587]] and [[spell:1240996]], and [[spell:47541]] damage.
- [[talent:117651]]
  
  - Increases [[spell:55090]] damage by 15% and reduces the cooldown of [[spell:43265]] by 5 seconds.
- [[spell:1265959]]
  
  - [[spell:1233448]] summons [[spell:444251]] for 6 seconds.
- [[spell:1265949]]
  
  - Casting [[spell:47541]] or [[spell:207317]] orders [[spell:444251]] to cast her [[spell:445513]] or [[spell:207317]] alongside you at 125% effectiveness while she is active.
  - If you played **Unholy** in The War Within Season 3, this will be familiar as it was part of your set bonus.
- [[spell:1265971]]
  
  - Increases the damage of abilities cast by the Horsemen by 5%, increases the damage of your Ghoul and [[talent:96317]] by 10%, and the damage of [[spell:1277098]] by 20%.

##### Defensive Choice Nodes

- [[talent:123412]] or [[talent:117657]]
  
  - [[talent:117657]] does not work at all in raids so you always choose [[talent:123412]] which is a great thing as it turns you into an extremely mobile class as long as you don't need to be there instantly with a blink and allows you to break roots and slows.
- [[talent:117634]] or [[talent:123410]]
  
  - [[talent:117634]] depends on the value of [[spell:48707]] during the fight as this can be incredibly potent allowing you to pre-immune debuffs or randomly absorb high amounts of magic damage. On the other hand, [[talent:123410]] grants you a 5% damage reduction per Horsemen out or a 20% damage reduction during your cooldowns with [[talent:117638]]. Due to the situational value of both of these, there is no auto pick for this as it just depends on the fight.

:::

:::tab [[talent:123321]] San'layn
##### Offensive Nodes

- [[talent:117648]]
  
  - [[spell:47541]], [[spell:207317]], and [[spell:49998]] have a 25% chance to transform your next [[spell:55090]] in to [[spell:433895]].
  - [[spell:433895]] heals you for 1% of your max HP, triggers [[spell:434143]], and grants you 1 stack of [[spell:433925]].
- [[talent:117650]]
  
  - [[spell:63560]] now grants you [[talent:117650]] which replaces [[spell:55090]] with [[spell:433895]] for its' duration.
  - [[spell:433925]] effectiveness is also increased by 80% during [[spell:63560]].
- [[spell:434143]]
  
  - Causes your plagues to erupt for with increased effectiveness and extends their duration by 3 seconds.
- [[spell:1280658]]
  
  - Your plagues now have a linearly scaling execute effect, up to 30% increased damage.
  - [[spell:433895]] grants you max stacks of [[spell:1241567]], allowing you to fully aoe immediately.
- [[talent:117645]] or [[spell:1234559]]
  
  - Both talents interact with [[spell:43265]] heavily. One causes you to have an increased chance to proc [[spell:433895]] by 5%, and the other causes [[spell:43265]] to deal its damage in 5 seconds instead of 10. Which is better depends on what content you are doing.
- [[talent:117662]] 
  
  - Allows [[spell:433925]] to stack up to 7 and increases your ‍[[spell:47541]] damage by 3% and [[spell:207317]] by 5% per stack.
- [[spell:434157]]
  
  - Consuming [[spell:49530]] procs grants you 4% strength for 5 seconds.
- [[talent:117643@FAQAvchA]] and [[talent:117652]]
  
  - After using [[spell:63560]] you summon a Blood Beast which stores both shadow damage you deal with [[talent:117652]] and damage it deals over the duration and explodes hitting all nearby enemies.
- [[spell:1265547]]
  
  - [[spell:433925]] now increases your Mastery by up to 1.4% as well as buffing the damage of [[spell:191587]] and [[spell:1240996]] by 5%.
- [[spell:1265574@FJADIIVAL7SAvchAKunADqrAlwvAyePBGkMAuzwBwzwBWmyEW3yEGIA]]
  
  - This increases the damage of the [[spell:1277098]] you summon when consuming a stack of [[spell:1254252]] for its entire duration, making it extremely important to always have stacks of [[spell:1254252]] during your [[talent:117650]] window.

##### Defensive Choice Nodes

- [[talent:117892]] or [[talent:117661]]
  
  - [[talent:117661]] has the potential to be nice, especially combined with [[talent:136524]], but overall you are not normally the person combat rezzing because you are melee while [[talent:117892]] increases your movement speed and that of nearby allies slightly which is always good.
- [[talent:117891]] or [[talent:117653]]
  
  - In Raids, [[talent:117891]] increasing the potency of [[spell:48792]] is simply too good to give up as 2% Leech sometimes increasing to 4% even for 4 allies is just not good enough.

:::

:::

## Talents

:::tabs
:::tab [[talent:123322]] Rider
:::talents
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### When to Use This Spec

This is the default loadout going into any dungeon.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[talent:96330]]
  
  - Causes your initial [[spell:85948]] to transform into a free cast of [[spell:85948]] after each initial cast of [[spell:85948]] that also increases the speed that your plagues tick on all targets for 25 seconds.
- [[spell:1233448]] and [[talent:96283]]
  
  - Empowers your ghoul and combined with [[talent:96283]] empowers all of your minions by 30% for 30 seconds.
- [[talent:96333@FAQAwXvE]]
  
  - Summons 6 empowered [[spell:1254252]] for 15 seconds and gives you Forbidden Knowledge for 30 seconds.
- [[talent:96313]]
  
  - Summoning a [[spell:1277098]] with [[spell:55090]] reduces the cooldown of [[spell:1247378]] by 2.5 seconds.
- [[spell:377580]]
  
  - [[spell:1247378]] gets 2 additional charges and consumes up to 2 charges per cast.
- [[spell:1241705]]
  
  - Allows your [[spell:1277098]] the ability to aoe with [[spell:1278150]] during [[spell:1233448]].

#### Class Tree

- [[talent:96174]]
  
  - Reduces the cooldown of [[spell:48707]] by 20 seconds and increases its duration and amount absorbed by 40%.
- [[talent:96194]]
  
  - Your raid cooldown that lasts for 6 seconds, reducing magic damage taken by anyone standing in it by 15%.
- [[talent:126016]]
  
  - Reduces your magic damage taken by 5% and reduces the duration of harmful magic effects by 35%. While the reduced magic damage portion of [[talent:126016]] works against all magic damage, the reduced duration of harmful magic effects does not work on the vast majority of debuffs in the raid as that could simply break too many things.
- [[talent:126015]]
  
  - Gives you 1 extra charge of [[spell:48265]], [[spell:43265]], and [[spell:49576]].
- [[talent:96182]]
  
  - Reduces all damage taken by 35% when below 30% health, including the portion of the hit that takes you below 30%. For example, if you take a hit that takes you from 60% to 10%, the portion of the hit below 30% of your health is reduced by 35%
- [[talent:96180]]
  
  - Increases all absorbs on you by 30%, this is incredibly powerful as it increases the absorb of spells like [[spell:48707]] and [[spell:17]] and other similar abilities.

#### Runeforge

- [[spell:327087]]

:::

:::tab [[talent:123321]] San'layn
:::talents
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### When to Use This Spec

If you prefer to play [[talent:123321]] San'layn, this is a competitive alternative.

#### Spec Tree

- **Added**
  
  - [[talent:123321]] San'layn
- Removed
  
  - [[talent:123322]] Rider of the Apocalypse

#### Runeforge

- [[spell:327087]]

:::

:::

## Rotation

### Tier Set

Check out all the [Midnight Season 2 Tier Sets](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: Your [[spell:390196]] and [[spell:1256813]] cast a more powerful [[spell:1297055]] instead of a Frostbolt, and [[spell:1297091]] instead of [[spell:317791]].
- **4-Set**: [[spell:1297055]] damage is increased by 130%, and [[spell:1297091]] damage is increased by 130% against enemies below 35% health.

### Single-Target

:::tabs
:::tab [[talent:123322]] Rider of the Apocalypse
#### Opener

- Your goal in the opener is to put up your plagues so you can start getting [[spell:49530]] procs and get your cooldowns started right away. Below is an example of how your opener looks like using the recommended [[talent:123322]] **Single-Target** build.

:::rotation Example [[talent:123322]] Rider Single-Target Opener
```json
{
  "source_code": "IIGLJI0BvEAAAAAACx7TJgACQ2vBFABBaaaAHAhABgorDEQCAGAAOPQAIEAA8DQOCESAChi0SAAAH8kZmByRDREAC5PPFEQJMIkP0LhMIAACSiwE"
}
```
1. [[spell:77575]]
2. [[spell:85948]]
3. [[spell:458128]]
4. [[spell:42650]]  [[item:241288]] · [[item:249344]]
5. [[spell:1233448]] Off GCD
6. [[spell:343294]]
7. [[spell:1242174]]
8. [[spell:1242174]]
9. [[spell:1247378]]
:::

- After this opener, there is ***a lot*** of [[spell:55090]] and [[spell:47541]] spamming with some [[spell:85948]] sprinkled in to maintain [[spell:1254252]] stacks.

#### Priority During Forbidden Knowledge

This is the priority list to follow for 30 seconds after casting [[spell:42650]].

- Cast [[spell:343294]] if it is able to be used.
- Cast [[spell:1247378]].
- Cast [[spell:458128]] if its buff is missing or about to expire.
- Cast [[spell:1242174]].
- Cast Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].

#### Priority Outside of Forbidden Knowledge

This is the priority list to follow for the other 60 seconds after your [[spell:42650]].

- Cast [[spell:77575]] if either [[spell:1240996]] or [[spell:191587]] is missing or about to expire.
- Cast [[spell:42650]].
- Cast [[spell:1233448]].
- Cast [[spell:343294]] if it is able to be used.
- Cast [[spell:1247378]] if [[spell:1233448]] is active.
- Cast [[spell:458128]] if its buff is missing or about to expire.
- Cast [[spell:55090]] if you have 8 stacks of [[spell:1254252]].
- Cast [[spell:47541]] if [[spell:49530]] is active.
- Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].
- Cast [[spell:47541]].

#### Notes

- Before execute, all of your [[spell:1247378]] charges should be used via [[spell:343294]] and manual casts during [[spell:1233448]]. It is still worth it to cast manually [[spell:1247378]] due to the amount of buffs [[spell:1233448]] provides to your [[spell:1277098]] during its duration.
- During execute, you should never need to cast [[spell:1247378]] due to [[spell:343294]] automatically firing them when cast. 
  
  - If a stack becomes available during [[spell:1233448]] it is still worth it to cast.

:::

:::tab [[talent:123321]] San'layn
#### Opener

- Your goal in the opener is get [[spell:1254252]] stacks and then into [[spell:63560]] and stack up [[talent:117650@FAgAvchAb-pB]] quickly to buff your [[spell:47541]].

:::rotation Example [[talent:123321]] San'layn Single-Target Opener
```json
{
  "source_code": "IgHLMI0BvEAAAAAACx7TJgACQ2vBFABBaaaAHAhABgorDEQC0FAAOPAAIEAA5IQIBIEKSLBAAcwTmZGIHNERAI05emwMRgAC-zTBBMDDC5D9SIDCAgy5eaAAAAAACJJCTA"
}
```
1. [[spell:77575]]
2. [[spell:85948]]
3. [[spell:458128]]
4. [[spell:42650]]  [[item:241288]] · [[item:249344]]
5. [[spell:1233448]] Off GCD
6. [[spell:433895]]
7. [[spell:433895]]
8. [[spell:343294]]
9. [[spell:1242174]]
10. [[spell:1242174]]
11. [[spell:433895]]
12. [[spell:1247378]]
:::

- After this opener, there is ***a lot*** of [[spell:55090]] and [[spell:207317]] spamming with some [[spell:85948]] sprinkled in to maintain [[spell:1254252]] stacks.

#### Priority List

- Cast [[spell:85948]] if you have less than 3 [[spell:1254252]] stacks and you are about to go into [[spell:1233448]].
- Cast [[spell:1271975]] immediately after [[spell:1233448]] ends.
- Cast [[spell:42650]].
- Cast [[spell:1233448]].
- Cast [[spell:343294]] when [[spell:1233448]] has 5 seconds or less remaining.
  
  - This includes adding up the extensions from [[spell:47541]]! You want to cast it as late as possible to get the most extension on your diseases as possible for [[spell:1271975]].
- Cast [[spell:1247378]] if your target is above 35% health and any of the following conditions are true:
  
  - You have 2 charges of [[spell:1247378]].
  - If [[spell:1240996]] or [[spell:191587]] are missing.
  - If [[spell:1233448]] has more than 15 seconds remaining on its cooldown.
- Cast [[spell:458128]] if its buff is missing or about to expire.
- Cast [[spell:47541]] if either of the following are true:
  
  - [[spell:49530]] is active.
  - You have more than 80 Runic Power.
- Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].
- Cast [[spell:47541]].

#### Notes

- Before execute, try to have 2 charges of  [[spell:1247378]] for [[spell:1233448]]. If you have 3 charges, you oversaved and are losing potential casts of your hardest hitting ability!
- During execute, you should never need to cast [[spell:1247378]] due to [[spell:343294]] automatically firing them when cast.

:::

:::

### AoE

:::tabs
:::tab [[talent:123322]] Rider of the Apocalypse
#### Opener

- Your goal in the opener is to pop your cooldowns to put up your plagues and you can start getting [[spell:49530]] procs. Below is an example of how your opener looks like using the recommended [[talent:123322]] **AoE** build.

:::rotation Example [[talent:123322]] Rider Aoe Opener
```json
{
  "source_code": "IoHLMI0BvEAAAAAACx7TJgACQ2vBFABBaaaAHAhABgorDEQCAGAAOPQAIEAA8DQOCESAChi0SAAAH8kZmByRDREAC5PPFEQJMIkkIMRBIQQApGwBMAgQlkdCY4DCAggkIMB"
}
```
1. [[spell:77575]]
2. [[spell:85948]]
3. [[spell:458128]]
4. [[spell:42650]]  [[item:241288]] · [[item:249344]]
5. [[spell:1233448]] Off GCD
6. [[spell:343294]]
7. [[spell:1247378]]
8. [[spell:43265]]
9. [[spell:383269]]
10. [[spell:383269]]
11. [[spell:383269]]
12. [[spell:1247378]]
:::

- After this opener, there is ***a lot*** of [[spell:55090]] and [[spell:47541]] or [[spell:207317]] spamming with some [[spell:85948]] sprinkled in to maintain [[spell:1254252]] stacks.
- When you are in an AoE situation, you should switch to using [[spell:207317]] over [[spell:47541]] at **4 stacked targets**. 
  
  - During [[spell:1242158]], this becomes **more than 6 targets**.

#### Priority During Forbidden Knowledge

This is the priority list to follow for 30 seconds after casting [[spell:42650]].

- Cast [[spell:458128]] if its buff is missing.
- Cast [[spell:343294]] if it is able to be used.
- Cast [[spell:1247378]].
- Cast [[spell:43265]] if your targets will get hit by the entire cast.
- Cast [[spell:383269]].
- Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].

#### Priority Outside of Forbidden Knowledge

- Cast [[spell:77575]] if either [[spell:1240996]] or [[spell:191587]] is missing or about to expire.
- Cast [[spell:42650]].
- Cast [[spell:1233448]].
- Cast [[spell:343294]] if it is able to be used.
- Cast [[spell:458128]] if its buff is missing or about to expire.
- Cast [[spell:1247378]] if [[spell:1233448]] is active.
- Cast [[spell:43265]] if your targets will get hit by the entire cast.
- Cast [[spell:55090]] if you have 8 stacks of [[spell:1254252]].
- Cast [[spell:207317]].
- Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].

#### Notes

- [[spell:43265]] is worth casting at 3+ targets.
- Before execute, try to have 2 charges of  [[spell:1247378]] for [[spell:1233448]]. If you have 3 charges, you oversaved and are losing potential casts of your hardest hitting ability!
- During execute, you should never need to cast [[spell:1247378]] due to [[spell:343294]] automatically firing them when cast.

:::

:::tab [[talent:123321]] San'layn
#### Opener

- Your goal in the opener is get [[spell:1254252]] stacks and then into [[spell:63560]] and stack up [[talent:117650@FAgAvchAb-pB]] quickly to buff your [[spell:207317]].

:::rotation Example [[talent:123321]] San'layn Single-Target Opener
```json
{
  "source_code": "IoHLMI0BvEAAAAAACx7TJgACQ2vBFABBaaaAHAhABgorDEQCAGAAOPQAIEAA8DQOCESAChi0SAAAH8kZmByRDREAC5PPFEQJMIkkIMRBIQQApGwBMAgQlkdCY4DCAggkIMB"
}
```
1. [[spell:77575]]
2. [[spell:85948]]
3. [[spell:458128]]
4. [[spell:42650]]  [[item:241288]] · [[item:249344]]
5. [[spell:1233448]] Off GCD
6. [[spell:343294]]
7. [[spell:1247378]]
8. [[spell:43265]]
9. [[spell:383269]]
10. [[spell:383269]]
11. [[spell:383269]]
12. [[spell:1247378]]
:::

- After this opener, there is ***a lot*** of [[spell:55090]] and [[spell:207317]] spamming with some [[spell:85948]] sprinkled in to maintain [[spell:1254252]] stacks.
- When you are in an AoE situation, you should switch to using [[spell:207317]] over [[spell:47541]] at **4 stacked targets**. 
  
  - During [[spell:1242158]], this becomes **more than 6 targets**.

#### Priority During Forbidden Knowledge

This is the priority list to follow for 30 seconds after casting [[spell:42650]].

- Cast [[spell:458128]] if its buff is missing or about to expire.
- Cast [[spell:343294]] if it is able to be used.
- Cast [[spell:1247378]].
- Cast [[spell:43265]] if your targets will get hit by the entire cast.
- Cast [[spell:383269]].
- Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].

#### Priority Outside of Forbidden Knowledge

- Cast [[spell:77575]] if either [[spell:1240996]] or [[spell:191587]] is missing or about to expire.
- Cast [[spell:85948]] before going into [[spell:1233448]] if you have 5 or less stacks of [[spell:1254252]].
- Cast [[spell:343294]] if it is able to be used.
- Cast [[spell:42650]].
- Cast [[spell:1233448]].
- Cast [[spell:458128]] if its buff is missing or about to expire.
- Cast [[spell:1247378]] if [[spell:1233448]] is active.
- Cast [[spell:43265]] if your targets will get hit by the entire cast.
- Cast [[spell:207317]] if [[spell:49530]] is active.
- Cast [[spell:85948]] if you have no stacks of [[spell:1254252]].
- Cast [[spell:55090]] if you have at least 1 stack of [[spell:1254252]].
- Cast [[spell:207317]].

#### Notes

- [[spell:43265]] is worth casting at 3+ targets.
- Before execute, all of your [[spell:1247378]] charges should be used via [[spell:343294]] and manual casts during [[spell:1233448]]. It is still worth it to cast manually [[spell:1247378]] due to the amount of buffs [[spell:1233448]] provides to your [[spell:1277098]] during its duration.
- During execute, you should never need to cast [[spell:1247378]] due to [[spell:343294]] automatically firing them when cast. 
  
  - If a stack becomes available during [[spell:1233448]] it is still worth it to cast.

:::

:::

## Deep Dive

### Casting Death Coil vs Epidemic

- When you are in an AoE situation, you should switch to using [[spell:207317]] over [[spell:47541]] at **4 stacked targets**.
- During [[spell:1242158]], this becomes **more than 6 targets**.

- If you are playing [[talent:123322]] Rider of the Apocalypse and you can see that you have [[spell:444251]] up, these numbers get reduced by one target meaning you would use [[spell:207317]] at 3 stacked targets instead of 4.
  
  - This can be applied after using [[spell:42650]] for 20 seconds or [[spell:1233448]] for 6 seconds guaranteed due to them automatically summoning [[spell:444251]].

### Anti-Magic Shell Runic Power

- [[spell:48707]] grants you up to 40 Runic Power based on the amount it absorbs. This is incredibly powerful as this build can get starved of Runic Power on single target so you want to use this to your advantage as often as possible on bosses where [[spell:48707]] isn't needed for purely defensive purposes.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Unholy Death Knight** Mythic+ Talents for Altar of Fangs
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### Rav'i

- Precast [[spell:48707]] on [[spell:1296220]].
- Dodge the [[spell:1296050]].
- Soak the puddles that spawn from [[spell:1306226]].

#### The Writhing Coil

- Precast [[spell:48707]] on [[spell:1299154]]
- Interrupt [[spell:1310358]] from the **Writhing Coil**.
- Break [[spell:1299053]] as fast as possible.
- Bait the [[spell:1299130]] towards the closest wall.

#### Zul'jan

- Soak one of the beams from [[spell:1300872]].
- Remove [[spell:1300894]] by soaking [[spell:1301413]].

### Trash Tips

At the start of the dungeon in the library area you can activate a **Arcane Tome**, it provides your party with [[spell:1254550]].

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1294567]] from **Twinfang Harrower**
  - [[spell:1306668]] from **Twinfang Harrower**
    
    - [[spell:48707]] can be used to immune the breath and walk through it.
  - [[spell:1307567]] from **High Evolutionist**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294557]] from **Primal Serpent**.
  
  
  
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.
- **Pay extra attention to these casts:**
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  
  
  
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1294567]] from **Twinfang Harrower**.

:::

:::tab Den of Nalorakk
:::talents **Unholy Death Knight** Mythic+ Talents for Den of Nalorakk
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Precast [[spell:48707]] on [[spell:1234846]].
- Soak the [[spell:1234740]] before they explode.
- Use a defensive on [[spell:1234681]].

#### Sentinel of Winter

- Precast [[spell:48707]] for either [[spell:1235548]] or [[spell:1235829]] to immune their debuffs.
- Interrupt [[spell:1235829]] from **Fractured Shivercore**.

#### Nalorakk

- Make sure you are on Zul'jarra to get [[spell:1261776]] during [[spell:1243569]].
- Intercept the **Echoes of Nalorakk** during [[spell:1243002]].

### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1238687]] from **Spirit of Misery**.
  - [[spell:1238760]] from **Starvation Effigy**.
  - [[spell:1241463]] from **Avatar of Determination**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  
  
  
  - [[spell:1241463]] from **Avatar of Determination**.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  
  
  
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Unholy Death Knight** Mythic+ Talents for Murder Row
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- In general you should hit **Nibbles** until Kystia Manaheart loses her shield.
- You can remove the **Mirror Images** with [[spell:49576]] and [[spell:207167]].
- Use your cooldowns during [[spell:1265412]] for maximum damage.

#### Zaen Bladesorrow

- Destroy the **Fel-infused Freight** with [[spell:1214357]].
- Hide behind a **Forbidden Freight** during [[spell:1218347]].

#### Xathuux the Annihilator

- Use [[spell:48707]] on [[spell:1214650]] to prevent the stacks for its duration.
- Precast [[spell:48707]] to prevent the dot from [[spell:1295452]].
- Stay on the boss if targeted by [[spell:1214663]].
- Use a defensive on [[spell:1295455]].

#### Lithiel Cinderfury

- Use [[spell:48707]] to walk through and immune [[spell:1217345]].
- If you do not have [[spell:48707]] available, wait for the boss to finish the cast [[spell:1217384]] before using [[spell:1214675]].
- Use your cooldowns after [[spell:474457]] to kill the **Wild imps** and get extra stacks of [[spell:377226]].
- Use a defensive on [[spell:474457]].
- Interrupt [[spell:474375]] from **Kystia Manaheart**.

### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1297682]] or [[spell:1217973]] from **Corrupted Warlock**.
  - [[spell:1215872]] from **Defiled Golem**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1216571]] from **Felonious Mage**.
  
  
  
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.
- **Pay extra attention to these casts:**
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1216300]] from **Row Hooligan**.
  
  
  
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Unholy Death Knight** Mythic+ Talents for The Blinding Vale
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTz2MzYmZMAAAAAAAAMzYYAwyMmZ2MzYmZALmFDDZgZjhGLYAzAwYmZMDwMDzYA",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTz2MzYmZMAAAAAAAAMzYYAwyMmZ2MzYmZALmFDDZgZjhGLYAzAwYmZMDwMDzYA"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Precast [[spell:48707]] to immune the DoT from [[spell:1234753]].
- Interrupt [[spell:1235616]] from **Kezkitt**.
- Intercept the [[spell:1235564]].
- Use a defensive if targeted by [[spell:1235640]].

#### Ikuzz the Light Hunter

- You can always break [[spell:1236658]] by alternating the precasting of [[spell:48707]] and using [[spell:212552]] after it is applied to you.
- Get away from the boss if targeted by [[spell:1237090]].
- Use a personal on [[spell:1236746]].

#### Lightwarden Ruia

- Interupt [[spell:1239821]] from **Lightwarden Ruia**.
- Use a defensive if targeted by [[spell:1240098]].
  
  - You can stack together with other people.
- Spread out during [[spell:1240210]], make sure not a single person is behind you to not cleave each other.

#### Ziekket

- Intercept the [[spell:1246858]] before they reach the boss.
- Use a defensive when targeted by [[spell:1246607]].

### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  
  
  
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.
- **Pay extra attention to these casts:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  
  
  
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.
      
      - You can dispel it with [[talent:124941]].
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents **Unholy Death Knight** Mythic+ Talents for Voidscar Arena
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### Taz'Rah

- Precast [[spell:48707]] when you are targeted with [[spell:1222098]].
  
  - Try to be as close to each other as it spawns the **Ethereal Shades**.
- Watch the **Ethereal Shades** during [[spell:1300259]].

#### Atroxus

- Precast [[spell:48707]] before the **Toxic Creeper** spawns to avoid [[spell:1222692]] for the duration of [[spell:48707]].
- Kill the **Toxic Creeper** as fast as possible.
- Use your cooldowns while the **Toxic Creeper** is alive.
- You can dispell [[spell:1222642]] and [[spell:1226031]] with [[talent:124941]].
- Use a defensive while the **Toxic Creeper** is alive.

#### Charonus

- Spread out and use both [[spell:48707]] and [[spell:48265]] for [[spell:1227197]] to avoid the DoT from it.
- Put the [[spell:1223298]] into the [[spell:1264191]].
- Spread out during [[spell:1227197]] and use a personal.
- Either hide behind the tank when targeted by [[spell:1222755]] or kite the projectile.

### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1299905]] from **Voidtouched Magi**.
  - [[spell:1289260]] from **Agitated Voidscythe**.
  - [[spell:1252406]] from **Devouring Brutalizer**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  
  
  
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.
- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  
  
  
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab King's Rest
:::talents **Unholy Death Knight** Mythic+ Talents for King's Rest
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Precast [[spell:48707]] when [[spell:265773]] is cast. 
  
  - This goes on 2 random players.
- Keep the **Animated Gold** away from the **Golden Serpent** with [[talent:124926]] and [[spell:119381]].
- It is adviced to use a defensive on [[spell:1311987]]**.**

#### Mchimba the Embalmer

- Precast [[spell:48707]] for [[spell:267618]]. This targets a random player but you have a chance to immune it.
- If you can not immune [[spell:267618]], use a defensive or spam [[spell:49998]] throughout its duration at higher key levels.
- [[spell:267639]] drops a puddle, place it in a good spot.
- Interrupt [[spell:267763]] from the **finished Mummy**.
- If necessary, use [[spell:48707]] to run over the fire pools.

#### The Council of Tribes

- Use a defensive on [[spell:266231]].
- Soak the [[spell:266951]].
- Interrupt [[spell:267273]] from **Zanazal the Wise**.
- Kill the **Explosive Totem** before it finishes [[spell:267077]].

#### Dazar, the first King

- Precast [[spell:48707]] to immune [[spell:1303267]].
- Dazar, the first King shares health with **T'zala** due to [[spell:1303519]].
  
  - T'zala spawns after **Dazar, the first King** reaches 80%.
- Interrupt [[spell:269369]] from **Reban**.

### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:271640]] from **Shadow of Zul**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  
  
  
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.
- **Pay extra attention to these casts:**
  
  - [[spell:270003]] from **Animated Guardian**.
  
  
  
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1297918]] from **King A'akul**.
  
  
  
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents **Unholy Death Knight** Mythic+ Talents for Ruby Life Pools
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- [[spell:373680]] happens on 66% and 33% boss health.
  
  - Plan your [[talent:124826]] usage accordingly to break the [[spell:372988]] as fast as possible.
- Put the [[spell:372851]] away from the group and use a defensive on it.
- Interrupt [[spell:372808]] from **Melidrussa Chillworn**.

#### Kokia Blazehoof

- Precast [[spell:48707]] on [[spell:373692]] from **Blazebound Firestorm**.
- Maximize your cleave damage on this boss.
- Use your cooldowns while the **Blazebound Firestorm** is alive and you are able to hit both it and the boss.
- Interrupt [[spell:373017]] from **Blazebound Firestorm.**
- Aim the [[spell:372819]] properly, do not waste too much space in the room.

#### Kyrakka and Erkhart Stormvein

- Go towards the edge of the room on expiration of [[spell:381602]] as it drops a [[spell:381868]].
- Use a defensive on  [[spell:381602]].
- [[spell:381517]] moves the [[spell:381868]].
  
  - [[spell:381517]] follows a counterclockwise pattern.
- Make sure to use your cooldowns when you can cleave both bosses.

### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:392640]] from **Thunderhead**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.
- **Pay extra attention to these casts:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  
  
  
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  
  
  
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Unholy Death Knight** Mythic+ Talents for Temple of Sethraliss
```json
{
  "source_code": "CyPAPMFb_SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG",
  "code": "CyPAPMFb/SlrF4ON4GtDAdVVKCYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzAWMLGGyAzGDNWwAmBgxMzYGgZmxMG"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Precasting [[spell:48707]] works both when targeted by [[spell:1288457]] and [[spell:1288864]].
- Always hit the target that does not have [[spell:1289229]].
- [[spell:1288864]] puts down a puddle at the end.
- [[spell:1289059]] pushes you back, make sure to not pull any uncessary trash during the encounter.

#### Merektha

- Precasting works on [[spell:1293048]] and allows you to stand in [[spell:1291622]].
- You can dispell [[spell:267027]] from the **Toxic Viper**.
- You can remove [[spell:263958]] with [[spell:119381]].
- Use a defensive on [[spell:1293048]].

#### Galvazzt

- If you need to walk through [[spell:1289589]], use [[spell:48707]] before walking through it.
- Intercept each [[spell:265986]] from reaching the boss with atleast 1 player.
- Use a defensive whenever you are in danger.

#### Avatar of Sethraliss

- [[spell:48707]] works on many things on this boss. [[spell:1302153]], [[spell:1300877]], and [[spell:1302826]].
- Use a defensive on [[spell:1302153]], it also drops a puddle on the ground.
- Soak the [[spell:1300869]].
- Interrupt [[spell:1302158]] from **Twisted Hexxers**.

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1303486]] from **Orb Watcher**.
  - [[spell:1302153]] from **Twisted Watcher**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1291262]] from **Storm Adept**.
  
  
  
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- **Pay extra attention to these casts:**
  
  - [[spell:272655]] from **Sand-Sworn Rider**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  
  
  
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

The Affix system got revamped going into **The War Within Season 3** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +4 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as an **Unholy Death Knight**

- Xal'atath's Bargain: Ascendant
  
  - Hit as many orbs as possible with [[spell:207167]].
  - [[spell:49576]] the far orbs if they are by themselves.
- Xal'atath's Bargain: Voidbound
  
  - Focus and cleave off of this target as mobs take reduced damage while it is alive.
- Xal'atath's Bargain: Oblivion
  
  - Soak any orbs that are close in melee.
- Xal'atath's Bargain: Devour
  
  - Dispel this with [[talent:96178]] if you are playing it.
  - If you have taken a considerable amount of damage in the last few seconds, you can use 1 [[spell:49998]] to help out your healer.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as an **Unholy Death Knight**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "IoAJFQAIxQCKEMQAEA"
}
```
**力量 ≫ 暴击 ≥ 精通 ＞ 急速 ≫ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is an okay tertiary for you since you have a mix of damage from yourself and pets but in AoE is mostly your damage.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
:::callout This is an Absolute BiS List
While these are the items that you should be aiming to acquire for your absolute Best in Slot, these items will not always be the best until you achieve this exact combination of items.

For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>) whenever you get what can be an upgrade!

:::

| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:251126@BgQAAcEACKgTBA]] into [[item:271474@DiQBAwPAnk7cVrTOC4UA2T9A]] | Catalyst of Murder Row |
| Neck | [[item:268265@BERAAwPAC06IQrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:251138@BgQAAcEACKgTBA]] into [[item:271472@BgQBAwPA5IgTBIQ1DA]] | Catalyst of Murder Row |
| Cloak | [[item:268253@BgQAAsPA5IAWBA]] | Coiled Altar / Catalyst |
| Chest | Convert [[item:268222@BgQAAsPA5IAWBA]] into [[item:271477@DgQBAsPAJk7kjAYFgvXQ]] | Catalyst of Coiled Altar |
| Wrist | [[item:237834@FCSAAwPAeA8ciqjAtOAAAAAAAA3WzSB]] | Crafted |
| Gloves | [[item:271475@BgQAAsPA5IgTBA]] | Tier / Catalyst |
| Belt | [[item:268259@BiQAAwPAC06kjAYF]] | Coiled Altar |
| Legs | [[item:271878@BARAAwPACKgF2gVA]] | Ula'tek |
| Boots | [[item:237828@HgQAAsPAaA8kSuTrqQ3WzSB]] | Crafted |
| Ring 1 | [[item:273792@DiQAAsPA1j7wQrjgC4UA]] | Altar of Fangs / The Great Vault |
| Ring 2 | [[item:252258@BiQAAwPAC06IoAOF]] | Voidscar Arena / The Great Vault |
| Trinket 1 | [[item:270173@BgQAAsPA5IAWBA]] | Coiled Altar |
| Trinket 2 | [[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] | Ula'tek |
| Main-Hand | [[item:268213@RgQAAwPAq2PB5IAWBA]] | Coiled Altar |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@BgQAAsPACKQQBA]] | Murder Row |
| Neck | [[item:251234@BgQAAwPACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239037@BgQAAsPACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:251132@BgQAAwPACKQQBA]] | Murder Row |
| Chest | [[item:251151@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:159409@BgQAAsPACKQQBA]] | King's Rest |
| Gloves | [[item:159413@BgQAAwPACKQQBA]] | King's Rest |
| Belt | [[item:159418@BgQAAsPACKQQBA]] | King's Rest |
| Legs | [[item:273776@BgQAAsPACKQQBA]] | Altar of Fangs |
| Boots | [[item:159412@BgQAAsPACKQQBA]] | King's Rest |
| Ring | [[item:273792@BgQAAsPACKQQBA]] | Altar of Fangs |
| Ring | [[item:158366@BgQAAsPACKQQBA]] | Temple of Sethraliss |
| Passive Trinket | [[item:250228@BgQAAsPACKQQBA]] | Murder Row |
| On-Use Trinket | [[item:273797@BgQAAsPACKQQBA]] | Altar of Fangs |
| Weapon | [[item:251134@BgQAAwPACKQQBA]] | Murder Row |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAsPA5IgTBA]] - 2 or more targets without the other set bonus  <br>[[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] |
| **A-Tier** | [[item:270165@BgQAAsPA5IgTBA]]  <br>[[item:250228@BgQAAsPACKgTBA]] |
| B-Tier | wow-item item=270173:BgQAAsPA5IAWBA]Zul'jin's Guillotine Technique[/wow-item] - Good on Single + 2 Target with [[item:268209@RgQAAsPAgBNA5IAWBA]] |
| **C-Tier** | [[item:250238@AgQAAIoAOFA]]  <br>[[item:273797@BgQAAsPACKgTBA]] |
| **Junkyard** | [[item:193757@BgQAAsPACKgTBA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:270168@BgQAAsPA5IAWBA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]]  <br>[[item:270163@AgQAAkjAOFA]] |

### Embellishments

- [[item:240167]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 at max item level therefore it is not normally beneficial to equip crafted items outside of your 2x Embellishments. 
  
  - While you are gearing up and do not yet have 334 pieces of gear or Myth track items on some slots, you can use your Myth Dawncrest to craft 331 pieces with Crit and Mastery.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- Flask
  
  - This depends on your current stats, make sure Mastery is your highest stat for [[item:241288]].
    
    - [[item:241326]]
    - [[item:241322]]
- **Food**
  
  - [[item:255846]] or [[item:255845]]
    
    - [[item:242275]] or [[item:255847]] have no stamina but are the personal items of this.
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- Unique
  
  
  
  - Any of the following depending on your stats:
    
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240890]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@BAAAAwP]]  <br>[[item:275707@BAAAAsP]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243947]] |
| Wrist | [[item:275707@BAAAAsP]] |
| Waist | [[item:275707@BAAAAsP]] |
| Legs | [[item:244641@BAAAAwP]] |
| Boots | [[item:243953@BAAAAwP]] |
| Ring 1 | [[item:243957@BAAAAwP]] |
| Ring 2 | [[item:243957@BAAAAwP]] |
| Weapon | [[spell:327087]] |

Speed Enchants are also viable in place of the Avoidance enchants, especially at higher item levels.

:::

:::column
:::gear **Unholy Death Knight** Enchantments in Raids
```json
{
  "source_code": "JQFa8DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABsOuJgAC7TDBFABBhubCQAQ86gBAAUfDQgS94OAAAAAACpa_EA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243947]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[spell:327082]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAsP]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing an **Unholy Death Knight** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:59224]] and [[spell:65116]] *--Dwarf*
  
  - [[spell:59224]]
    
    - Increases your Critical Strike damage by 2%
  
  
  
  - [[spell:65116]]
    
    - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases:
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].

:::simulation
```json
{
  "source_code": "IUtAQ1xAfAAACewSyF2ZncXYMYHBd3-0HVAFIbwSp1mY1x2C2Rwh9L9RDoAAAAgKPS9RDIAAAAATjY9RDQCAAAg7ER9RDgAAAAgLib9RDEwSwbUCCd3buNXYtRWaIYHB9jY0HNQBAAAAGL_0HNAGAAAAtwp1HNQCAAAARMJ1HNgBAAAAY8k1HNAHAAAAkFH1HNwGAAAAudE1HlwgsE0a15GZhdgdEQ9qRnwXwDEBH9mbrpgdEYwRUf0AlAAAAE8AWf0ALAAAAo5UVf0AjAAAAMq_Sf0ABAAAA48vUf0AiAAAAk13Uf0ADAAAA4qVWnwRwVAUhdya1lgdEo81Uf0AEAAACWgTpdGa01KXCgqoNIBeDQUY5xKXC87oUf0AeAAAAQaVRf0AHAAAAY_nUf0AWECEYhI1HNQHAAAAie40HNAIAAAALv-0HNQB"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292364]] | 108,507.73 |
| 种族 31 [[spell:292363]] | 108,027.05 |
| 种族 10 | 108,830.33 |
| 种族 2 | 109,638.59 |
| 种族 36 | 108,681.86 |
| 种族 8 | 110,020.36 |
| 种族 31 [[spell:292360]] | 107,281.98 |
| 种族 5 | 108,517.55 |
| 种族 24 | 109,880.35 |
| 种族 9 | 108,838.13 |
| 种族 6 | 109,726.19 |
| 种族 28 | 108,770.78 |
| 种族 27 | 108,686.86 |
| 种族 31 [[spell:292359]] | 107,351.66 |
| 种族 31 [[spell:292362]] | 108,686.05 |
| 种族 37 | 109,575.51 |
| 种族 11 | 109,223.20 |
| 种族 35 | 108,029.27 |
| 种族 1 | 108,927.61 |
| 种族 34 | 108,990.70 |
| 种族 3 | 109,741.36 |
| 种族 31 [[spell:292361]] | 108,975.58 |
| 种族 4 [[spell:154797]] | 108,869.31 |
| 种族 4 [[spell:154796]] | 108,871.49 |
| 种族 30 | 107,179.28 |
| 种族 7 | 108,863.92 |
| 种族 22 | 108,816.33 |
| 种族 29 | 108,303.27 |
| 种族 32 | 108,503.59 |
:::

### Recommendation

If you are serious about pushing Mythic+ as an **Unholy Death Knight**, you need to play either Dwarf to remove debuffs with [[spell:65116]] or Night Elf because you are able to remove important mechanics. I currently recommend Dwarf as it is virtually the highest damage racial as well as having the best utility.

## Macros

Discover recommended macros for **Unholy Death Knight** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
[[spell:51052]] - *Casts [[spell:51052]]* *at your Cursor position*.

```wow-macro
/cast [@cursor] Anti-Magic Zone
```

[[spell:43265]] - *Casts [[spell:43265]] at your cursor position.*

```wow-macro
/cast [@cursor] Death and Decay
```

*If you do not like [[spell:43265]]* *on your cursor you can replace [@cursor] with [@player] and it will instead put it at your feet. Having either of these is important as it removes the targeting reticle and allows you to get it out faster.*

```wow-macro
/cast [@player] Death and Decay
```

:::

:::details Mouseover Macros
[[spell:77575]] - *Casts [[spell:77575]] at your mouseover if it exists or your target.*

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Outbreak
```

[[spell:45524]] - *Casts ‍[[spell:45524]] at your mouseover if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Chains of Ice
```

[[spell:47528]] - *Casts [[spell:47528]]* *at your mouseover if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Mind Freeze
```

[[spell:49576]] - *Casts ‍[[spell:49576]] at your mouseover target if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Death Grip
```

[[spell:61999]] - *Casts [[spell:61999]] on your mouseover so you can use this on your frames.*

```wow-macro
/cast [@mouseover,help,dead][]Raise Ally
```

:::

:::details Focus Macros
Set Focus Mouseover - *This will set your focus to your mouseover.*

```wow-macro
/focus [@mouseover]
```

Focus [[spell:49576]] - *Casts [[spell:49576]] at your focus.*

```wow-macro
/cast [@focus] Death Grip
```

Focus [[spell:47528]] - *Casts [[spell:47528]] at your focus.*

```wow-macro
/cast [@focus] Mind Freeze
```

:::

:::details Pet Macros
While rare, you need some pet spells bound as pets can be very stupid even on assist. This can happen especially on bosses with large hitboxes as they like to follow the bosses back and they can end up being over 100 yards away.

Pet Attack - *Sometimes you will want your pet to target specific things and not follow you around*.

```wow-macro
/petattack
```

Pet Follow - *Rarely needed, but sometimes you want your ghoul to stop hitting its target*.

```wow-macro
/petfollow
```

Pet Move - *For the fights you just can not get your ghoul in the right position*.

```wow-macro
/petmoveto
```

[[spell:47481]] - *As you do not want this on auto-cast, this enables you to have a stun which is incredibly powerful on some fights. This also works while your pet is in [[spell:63560]].*

```wow-macro
/cast Gnaw
```

[[spell:47482]] / [[spell:91802]] - *While this is almost always on auto-cast, you will want this bound for the extremely rare situations that pet kick can be useful.*

```wow-macro
/cast Leap
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Unholy Death Knight**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Unholy Death Knight Interface in Mythic+](<https://assets-ng.maxroll.gg/wordpress/Unholy_dungeon-mxr-1024x626.webp>)

**Unholy Death Knight** Interface in Mythic+

:::accordion
:::details Addons
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Unholy**

- **Reanimation** renamed to [[talent:135676]] and its secondary effect has been redesigned – When you control 3 [[spell:390196]], sacrifice them to summon their [[spell:1256813]] for 15 seconds, casting Frostbolts that chain between 2 enemies. [[spell:390196]] with higher remaining duration grant increased power.
- Apex Talent: [[spell:1242158]] (Rank 3) has been updated – [[spell:390196]] no longer grants stacking damage to [[spell:1242174]] and [[spell:383269]]. The effectiveness of [[spell:1247378]] activated by [[spell:1240996]] has been increased to 100% (was 60%).
- Apex Talent: [[spell:1242158]] – [[spell:1242174]] damage reduced by 6% and [[spell:383269]] damage increased by 17.3%.
- [[spell:343294]] has been updated – No longer consumes charges of [[spell:1247378]] to cast. Now consumes up to 3 [[spell:1254252]] stacks to summon them instantly.
- [[talent:96284]] has been updated – [[spell:390196]] now grant the Haste buff on spawn for 15 seconds.
- [[spell:42650]] has been updated – Summon or empower [[spell:1277098]] to form an unholy army of 8 for 30 seconds. While active, you command your army through [[spell:55090]], executing Orders based on nearby enemies instead of summoning [[spell:1277098]].
  
  - [[spell:1294264]] – [[spell:1277098]] strike with you, dealing Shadow damage to your target.
  
  
  
  - [[spell:1300330]] – [[spell:1277098]] erupt in viscera, dealing Shadow damage to nearby enemies. Deals reduced damage beyond 5 targets.
- [[spell:42650]] [[spell:1277098]] damage reduced by 25%.
- [[talent:125815]] now has an additional effect – Your [[talent:135676]] Frostbolts now chain to 3 additional enemies.
- All damage reduced by 3%.
- Auto-attack damage increased by 100%.
- [[spell:1277098]] damage reduced by 6.5%.
- [[spell:207317]] damage increased by 54%. Does not affect [[spell:383269]].
- [[spell:390196]] damage reduced by 15%.
- [[spell:1247378]] damage reduced by 15%.
- [[spell:1247378]] area-of-effect damage increased by 35%.
- [[spell:327093]] damage reduced by 25%.
- [[talent:96324]] damage reduced by 25%.
- [[spell:191587]] damage increased by 2%.
- [[talent:96283]] now causes [[spell:1233448]] to increase the damage of your summoned creatures by 10%/20% for 30 seconds (was 15%/30%).
- [[spell:1280645]] now deals reduced damage beyond 5 targets.
- [[talent:96195]] grants a shield equal to 35% of damage dealt (was 30%).
- [[talent:133515]] now causes [[spell:1247378]] to extend the duration of plagues by 3 seconds (was 4.5 seconds).
- Runic Power spenders now extend the duration of plagues by 1 second (was 1.5 seconds).
- [[spell:1240996]] now retains its extended duration when applied to a new target while within 40 yards of the Death Knight.
- Fixed an issue causing [[spell:444052]] to grant additional Strength when [[spell:390196]] is sacrificed for [[spell:1256813]].
- [[spell:444052]] will no longer grant Strength from critters and low level targets.
- Players other than the Death Knight can now only see up to 3 Lesser Ghouls at a time.

:::accordion
:::details Hero Talents
- [[talent:123322]] Rider of the Apocalypse
  
  - Whitemane Death Coil damage reduced by 25%.
  - Whitemane Undeath damage reduced by 25%.
- [[talent:123321]] San'layn
  
  - Blood Beast auto-attack damage increased by 1400%.
  - [[talent:117645]] now reduces physical damage taken by 8% (was 5%)

:::

:::

:::

:::

:::accordion
:::details Patch 12.0.5
**Death Knight**

:::accordion
:::details Hero Talents
- **[[talent:123322]] Rider of the Apocalypse**
  
  - [[talent:135997@AJgBCA]] has an additional effect 
    
    - Your Ghoul and [[talent:96317]] deal 10% increased damage and [[spell:1277098]] deal 20% increased damage.
  
  
  
  - [[talent:123411@AJgBCA]] has been updated 
    
    - While you have 2 or more Horsemen aiding you, your [[spell:47541]] deals 20% and [[spell:207317]] deals 20% increased damage.
- **[[talent:123321]] San'layn**
  
  - [[talent:117662]] has been updated – Essence of the Blood Queen increases the damage of your [[spell:47541]] and [[spell:49998]] by 3%, and [[spell:207317]] by 3% per stack.
  
  
  
  - [[talent:135995@AJgBCA]] has an additional effect 
    
    - [[spell:1240996]] deals 5% and [[spell:191587]] deals 5% increased damage.
  
  
  
  - [[talent:136836]] has been updated 
    
    - [[spell:43265]] deals its damage 100% faster.

:::

:::

**Unholy**

- New Talent: [[talent:96289]]
  
  - [[spell:1247378]]reduces the cooldown of [[spell:43265]] by 1 second. [[spell:43265]] reduces the cooldown of [[spell:1247378]] by 0.3 seconds for each enemy it damages, up to 3 seconds.
- [[talent:96311]] has been updated
  
  - Disease Cloud no longer causes enemies to take increased damage from minions. Now deals Plague damage periodically to nearby enemies.
- [[talent:133546]] has an additional effect
  
  - [[spell:1247378]]now consumes up to 2 available charges on cast.
- [[spell:1277098]] damage reduced by 17%.
- [[spell:55090]] now applies [[spell:191587]] in addition to spreading it.
- Pestilence renamed to [[talent:133513]] and now overrides [[spell:1233448]] instead of [[spell:77575]].
- [[spell:1242174]] Shadowstrike damage now prefers the primary target.
- Some talents have changed locations in the talent tree.
- The following talents have been removed
  
  - [[spell:1242616]]
  - [[spell:1241707]]
  - [[spell:1242561]]

:::

:::

:::accordion
:::details Patch 12.0.1
**Death Knight**

:::accordion
:::details Hero Talents
- [[talent:123322]] Rider of the Apocalypse
  
  - All Horsemen damage reduced by 65%.
  
  
  
  - [[talent:117641]] now increases the damage of diseases and [[spell:47541]] by 5%, and now also affects [[spell:1242174]].
  - [[spell:444633]] damage increased by 50%.
  - Whitemane's [[spell:212739]] damage increased 150%.
  - [[spell:444834]] damage increased by 100%.
- **[[talent:123321]] San'layn**
  
  - [[talent:117648]] damage reduced by 20%.
  - [[talent:117662]] now increases the damage of [[spell:47541]] and [[spell:207317]] by 3% per stack of [[spell:433925]].
  - [[talent:117650@FAgAvchAb-pB]] now increases the effectiveness of [[spell:433925]] by 80%.
  - [[talent:135994@AJgBCA]] now increases the damage of a summoned [[spell:1277098]] by 10% (was 20%).
  - [[talent:117642@FAQAvchA]] now increases the damage of diseases by up to 30% (was 20%).
  - [[talent:117630@AJgBCA]] now causes [[talent:117648]] to extend the duration of plagues by 3 seconds (was 2 seconds).

:::

:::

**Unholy**

- New Talent:[[talent:96289]]
  
  - [[spell:458128]] casts a [[spell:43265]] at the target location. Can only occur every 30 seconds. Reduced to 15 seconds with [[talent:126015]]. Replaces [[spell:43265]].
- [[talent:96329]] has been redesigned 
  
  - [[spell:1240996]] deals damage to an additional nearby enemy at 75% effectiveness and has a chance to grant you 4 Runic Power.
- [[talent:135676]] has been updated
  
  - [[spell:1247378]] now summons a [[talent:96282]] for 15 seconds (was 8 seconds).
- [[talent:133513]] has been updated 
  
  - [[spell:1233448]] upgrades your next [[spell:77575]] to [[talent:133513]]. The rest of the effect remains the same.
- [[talent:133513]] now deals 150% of the remaining damage of Plagues instantly (was 100%).
- [[talent:96282]] has been updated 
  
  - [[talent:96333@FAQAwXvE]] now again also summons a [[talent:96282]] for 15 seconds.
- [[talent:96333@FAQAwXvE]] has been updated 
  
  - Summons a legion of 8 empowered [[spell:1277098]] that last for 15 seconds that are now 75% more effective than normal [[spell:1277098]] (was 100%). Generates 40 additional Runic Power. Reduced to 4  [[spell:1277098]] in PvP combat.
- [[talent:96311]] and [[talent:133514]] no longer putrefies 2 [[spell:1277098]].
- [[spell:288853]] Disease Cloud now increases the damage targets take from your minions by 10% (was 20%).
- [[spell:288853]] Disease Cloud now correctly increases the damage of [[spell:1247378]].
- [[spell:343294]] now increases [[spell:1247378]]damage.
- [[spell:343294]] debuff tooltip updated to show disease damage increase.
- [[spell:343294]] now consumes all available [[spell:1247378]]charges to cast Putrefy at its target.
- [[talent:96321]] now lasts for 12 seconds (was 5 seconds).
- All auto-attack and ability damage dealt reduced by 32%.
- [[spell:55090]] damage reduced by 28%.
- [[spell:191587]] damage increased by 13%.
- [[spell:207317]] damage increased by 15%.
- [[spell:1240996]] damage reduced by 15%.
- Rapid Variant is now an inherent effect for [[spell:1240996]] and now takes enemy bounding box into account for distance calculations.
- [[spell:1247378]] now summons a [[spell:1277098]] inherently. The rest of [[talent:136797]] effects remain the same.
- [[spell:1247378]] damage reduced by 10%.
- [[talent:136797]] explosion damage increased by 100%.
- [[talent:133523]] now reduces the damage of each subsequent chain of [[spell:55090]] by 20% (was 25%).
- [[talent:96322]] lasts 15 seconds (was 12 seconds) and is extended by [[spell:47541]] and [[spell:207317]] by 1 second (was 0.5 seconds).
- [[talent:96332]] now increases all disease damage by 5% (was 10%).
- [[talent:96328]] now reduces the cost of [[spell:47541]] and [[spell:207317]] by 15 Runic Power (was 10).
- Each Unholy specific summon attack and ability power reduced by 25% except for [[talent:133514]].
- All [[spell:1277098]] damage reduced by 20%.[[spell:1277098]]Sweeping Claws main target damage reduced by 20%.
- [[spell:1277098]] Sweeping Claws secondary target damage reduced by 15%.
- [[spell:1277098]] Sweeping Claw now has a global cooldown of 1 second (was 0 seconds).
- [[talent:96318]] [[spell:1277098]] [[spell:91778]] damage reduced by 30%.
- Pet Ghoul [[spell:91778]] damage reduced by 30%. Pet Ghoul's [[spell:91778]] main target damage reduced by 20%.
- Pet Ghoul's [[spell:91778]] secondary target damage reduced by 15%.
- [[talent:96318]] now causes [[spell:1233448]] to increase the damage of listed summons by 15%/30% (was 25%/50%).
- [[talent:96324]] damage reduced by 40%.
- [[talent:96334]] now increases the damage the target takes per disease by 1% (was 2%).
- Fixed an issue that caused [[spell:458128]] debuff effect to stop functioning when diseases get extended from any source.

:::

:::

:::accordion
:::details Patch 12.0
**Death Knight**

- New Talent: [[talent:136524]]
  
  - [[spell:61999]] costs 30 less Runic Power.
- New Talent: [[talent:136525]]
  
  - The cooldown of [[talent:96204]] is reduced by 30 seconds, and you receive 50% increased healing while its healing absorb is active.
- New Talent: [[talent:96189]]
  
  - While you are below 50% health, your Ghoul sacrifices 4% of its maximum health to heal you for 1% of your maximum health every second.
- [[talent:96200]] heal reduced to 20% of all damage taken in the last 5 seconds (was 25%).
- [[spell:43265]] damage increased by 130%.
- [[talent:96187]] now reduces the cooldown of Lichborne by 30 seconds (was reduces damage taken).
- [[talent:96198]] is now a 2-point talent.
- [[talent:96180]] is now a 2-point talent and has been moved to the first gate.
- [[talent:136526]] is now a choice talent against [[talent:96193]].
- [[spell:327574]] has been removed.

**Unholy**

:::accordion
:::details Hero Talents
- [[talent:123322]] Rider of the Apocalypse
  
  - New Talent: [[talent:135999@AJgBCA]]
    
    - [[spell:1233448]] summons forth Whitemane for 6 seconds.
  - New Talent: [[talent:135998@AJgBCA]]:
    
    - Casting[[spell:47541]] or [[spell:207317]]orders Whitemane to cast her [[spell:47541]] or [[spell:207317]] alongside you at 125% effectiveness.
  - New Talent: [[talent:135997]]
    
    - The abilities that Horsemen cast deal 5% increased damage.
  - Mograine's [[spell:43265]] damage increased by 50%.
  - Mograine's [[spell:43265]] now extends the duration of diseases on the targets by 1 second whenever it deals damage.
  - Trollbane's [[spell:45524]] no longer deals damage.
- [[talent:123321]] San'layn
  
  - New Talent: [[talent:135995@AJgBCA]]
    
    - [[spell:433925]] additionally increases your Mastery by 0.2% per stack.
  - New Talent: [[talent:135994@AJgBCA]]
    
    - [[talent:117648]] increases the damage of the [[spell:1277098]] it summons by 20%.
  - New Talent: [[talent:117642@FAQAvchA]]
    
    - Your plagues deal up to 30% increased damage based on the target's missing health. [[talent:117648]] grants maximum stacks of [[talent:133523]].
  
  
  
  - [[talent:117630@AJgBCA]] now consumes 50% of the Plagues to deal 100% of that amount of damage.
  - [[talent:117630@AJgBCA]] no longer causes [[spell:55090]] to consume the diseases after [[talent:117650@FAgAvchAb-pB]] ends.
  - [[talent:136836@AJgBCA]] has been moved to a choice talent with [[talent:117645]].
  
  
  
  - [[talent:117630@AJgBCA]] now has an additional effect – [[talent:117648]] erupts your plagues with 30% increased effectiveness.
  - [[talent:117630@AJgBCA]] now extends the duration of the plagues by 2 seconds (was 1.5 seconds).
  - [[talent:117630@AJgBCA]] now functions with [[spell:1240996]].
  - [[talent:117662]] now also increases the damage of [[spell:207317]] per stack of [[spell:433925]].
  - [[talent:117648]] damage increased by 10%.

:::

:::

:::accordion
:::details Spec Changes
- New Talent: [[talent:133522@FAQAQhGB]]
  
  - Command your oldest[[spell:1277098]] to leap and strike the enemy for Shadow damage and have them explode for Shadow damage to nearby enemies.
- New Talent: [[talent:96286]] 
  
  - Spending Runic Power increases your Strength by 1%/2% for 20 seconds. Multiple applications may overlap.
- New Talent:[[talent:96318]]
  
  - Each [[spell:1277098]] increases the damage of your permanent Ghoul by 10%, and [[talent:96322]] additionally empowers the Claw attacks of your [[spell:1277098]] to Sweeping Claws.
- New Talent: [[talent:133521]] 
  
  - Your [[spell:1277098]] deal 15% increased damage.
- New Talent: [[talent:135676]] 
  
  - When you Putrefy a [[spell:1277098]], it has a 100% chance to reanimate as a [[talent:96282]] who hurls Frostbolts and Shadow Bolts at foes for 8 seconds. [[talent:96282]] Frostbolts and Shadow Bolts deal 25% increased damage.
- New Talent: [[talent:96321]]
  
  - [[spell:1247378]]causes your permanent Ghoul to go on an unholy frenzy, increasing its attack speed by 25% for 5 seconds. Multiple applications may overlap.
- New Talent: [[talent:96329]]
  
  - When an enemy afflicted by your [[spell:1240996]] dies, it erupts, dealing Shadow damage to nearby enemies and infects the enemy with the lowest health remaining with your plagues. Deals reduced damage beyond 5 targets.
- New Talent: [[talent:133516]]
  
  - [[spell:55090]] now causes your Plagues to erupt at 50%/70% effectiveness. [[talent:133523]] can now stack up to 1/2 additional times.
- New Talent: [[talent:96332]]
  
  - All diseases deal 10% increased damage.
- New Talent: [[talent:133546]]
  
  - [[spell:1247378]] deals 20% increased damage and has 1 additional charge.
- New Talent: [[talent:133515]]
  
  - The explosion effect of [[spell:1247378]] extends the duration of your plagues by 4 seconds and deals 35% of the damage they would deal over that time instantly. [[spell:1247378]] now applies your plagues to unaffected targets.
- New Talent: [[talent:96314]] 
  
  - Rupture the soul of your enemy, dealing Shadowfrost damage and causing the foe to take 20% increased damage from your plagues and minions for 8 seconds. Only usable on enemies below 35% maximum health. 1 Rune. 15 second cooldown.
- New Talent: [[talent:133513]] – [[spell:77575]] is replaced with [[talent:133513]].
  
  - [[talent:133513]]: Consume 100% of your Plagues around you and deal 150% of their remaining damage instantly, and gain a charge of [[spell:1247378]]. 15 second cooldown, 1 Rune cost.
- New Talent: [[talent:136797]] 
  
  - Putrefy now summons a [[spell:1277098]] to attack instead and when your [[spell:1277098]] expire, they explode in viscera, dealing Shadow damage to enemies nearby.
- [[spell:85948]] has been redesigned 
  
  - Slash the enemy for Physical damage and corrupt your weapon with blight, causing your next 2-3 Scourge Strikes to summon a [[spell:1277098]].
- [[spell:55090]] has been redesigned 
  
  - An unholy strike that deals Shadow damage and causing your plagues on the target to erupt, dealing their damage an additional time at 35% effectiveness. Spreads [[spell:191587]] on the target to a nearby enemy. 30 yard range.
- [[spell:77575]] has been updated – Inflicts the target with [[spell:1240996]] and [[spell:191587]].
  
  - [[spell:1240996]]: A malicious plague that seeps into the soul of its host, dealing Shadow damage over 24 seconds. Can only be applied to 1 host at a time.
  - [[spell:191587]]: An infectious plague that spreads to all nearby enemies, dealing Shadow damage over 24 seconds.
- [[spell:77575]] is no longer learned automatically and is now the initial talent on the Unholy talent tree.
- [[talent:133523]] has been redesigned 
  
  - Now a passive effect. Shadows guide your strikes, increasing the damage of your [[spell:55090]] by 25%, and causing it to grant you [[talent:133523]] up to 4 times. For each stack of [[talent:133523]], your Scourge Strike chains to an additional enemy. Each subsequent chain deals 25% reduced damage.
- [[talent:96202@FAQAvchA]] has been redesigned 
  
  - [[spell:55090]] and [[spell:85948]] deal 10% increased damage.
- [[talent:96328]] has been redesigned
  
  - [[spell:1240996]] has a 35% chance to exhilarate, making your next [[spell:47541]] or [[spell:207317]] cost 10 less Runic Power and deal 35% increased damage.
- [[talent:125816]] has been updated
  
  - Consuming [[talent:96328]] summons forth a [[spell:1277098]] to assist you for 8 seconds. Moved to the first gate in the talent tree.
- [[talent:96313]] has been updated 
  
  - [[talent:96328]] triggers 30% more often and can accumulate up to 2 charges. Summoning a [[spell:1277098]] with [[spell:55090]] reduces the cooldown of [[spell:1247378]] by 2.5 seconds.
- [[talent:96289]] has been updated
  
  - [[spell:1240996]] has a chance to grant 4 Runic Power. No longer a capstone talent.
- [[talent:96284]] has been updated 
  
  - Each [[talent:96282]] under your command grants you 1%/2% Haste.
- [[talent:133517]] has been updated 
  
  - [[spell:55090]], [[spell:85948]], and [[spell:47541]] deal 30% additional damage to enemies below 35% health. [[spell:1233448]] resets [[spell:343294]] cooldown and allows it to be used on any target.
- [[talent:96324]] has been updated
  
  - Ghouls have a chance to sicken foes, dealing Shadow damage over 12 seconds. When reapplied, any remaining damage is added to the new effect.
  - [[talent:96324]] damage scales with [[spell:77515]] and can critically strike.
- [[talent:96322]] has been updated 
  
  - Corrupt and evolve your Ghoul into a Monstrosity, greatly empowering its abilities for 12 seconds. [[spell:47541]] and [[spell:207317]] extends the duration of this effect by 1 second.
- [[talent:133514]] has been redesigned 
  
  - Army of the Dead now summons a Gargoyle into the battlefield to bombard your enemies for 25 seconds and instantly Putrefies 2 [[spell:1277098]] summoned at 100% effectiveness. The Gargoyle gains 1% increased damage for every 1 Runic Power you spend and always critically strikes.
- [[talent:96311]] has been redesigned 
  
  - [[spell:42650]] now raises an Abomination that attacks enemies while emitting a disease cloud that lasts for 30 seconds, and instantly Putrefies 2 [[spell:1277098]] at 100% effectiveness. Enemies within the disease cloud take 20% increased damage from your minions.
- [[talent:96283]] now has a secondary effect
  
  - The duration of [[spell:1277098]] are increased by 25%/50% of your Mastery.
- [[talent:96330]] has been updated
  
  - [[spell:85948]] now follows up with a [[spell:458128]] that costs no Runes. Grants [[spell:1277098]] charges for [[spell:55090]]. No longer casts automatically and is now a combo spell.
    
    - [[spell:458128]]: Slashes through all enemies within 14 yards in front of you, dealing Shadow damage and hastening all of your Plagues on targets hit to deal damage 35% faster for 25 seconds.
- [[spell:46584]] and [[spell:85948]] are now learned automatically when specializing as Unholy.
- Auto-attack damage increased by 300%.
- [[spell:91778]] damage increased by 150% and now deals 35% reduced damage to secondary targets.
- Pet Ghoul and [[spell:1277098]] [[spell:91778]] damage increased by 50%.
- Pet Ghoul and [[spell:1277098]] Claw damage increased by 50%.
- [[spell:1277098]] now last for 6 seconds (was 8 seconds).
- [[spell:42650]] now has a 1.5 minute cooldown (was 3 minutes) and summons 6 [[spell:1277098]].
- [[spell:390196]] no longer causes [[spell:42650]] to summon a [[spell:390196]].
- [[talent:96294]] now causes diseases to deal 15% more damage over time in 75% of the duration (was 12% more damage over time in half the duration).
- Runic Power spenders now increase the duration of your Plagues by 1.5 seconds.
- [[spell:207317]] damage increased by 56%.
- [[spell:47541]] and [[spell:207317]] now extend plague duration by 4 seconds.
- [[spell:47541]] damage increased by 210%.
- [[talent:96290]] now additionally increases [[spell:47541]] damage by 10%.
- [[spell:1277098]] and [[spell:91778]] now trigger the effects of [[spell:327087]].
- [[talent:96205]] now correctly increases the damage of [[spell:327093]] from [[spell:327087]].
- Slow effect of [[spell:327093]] from [[spell:327087]] has been reduced to 5% (was 15%).
- [[talent:96323]] now increases the critical strike damage of [[talent:96290]], [[talent:96324]], and [[spell:327087]] [[spell:327093]].
- [[spell:77515]] now increases the critical strike damage of [[spell:191587]] eruption, [[talent:96324]], and [[talent:96290]].
- [[talent:96317]] is now affected by [[talent:96283]].
- Fixed an issue causing [[talent:96331]] to not be applied.
- Many talents have changed positions in the talent tree.
- The following talents have been removed:
  
  - Apocalypse
  - Bursting Sores
  - Death Rot
  - Decomposition
  - Defile
  - Desecrate
  - Eternal Agony
  - Festermight
  - Improved Festering Strike
  - Legion of Souls
  - Plaguebringer
  - Rotten Touch
  - Unholy Blight

:::

:::

:::

:::

## FAQ

:::accordion
:::details What abilities require you to be in melee range?
While most melee specs require you to be in melee for the majority of your abilities, Unholy is not like them. Here is the list of melee and ranged abilities:

##### Melee Range

- [[spell:85948]] and [[spell:458128]]
- [[spell:343294]]

##### 30+ Yard Range

- [[spell:55090]]
- [[spell:1247378]]
- [[spell:47541]]
- [[spell:207317]]
- [[spell:77575]]
- [[spell:1233448]]
- [[spell:42650]]

:::

:::

---

### Credits

Written By: **Miniaug**

Reviewed By: **Verb**

:::changelog 更新记录
**2026-06-17** Updated for patch 12.0.7

**2026-04-25** Updated for the hotfixes in 12.0.5

**2026-04-21** Updated for patch 12.0.5

**2026-02-25** Updated for Midnight Launch!

**2026-02-10** Updated for patch 12.0.1

**2026-01-21** Updated for Midnight Pre-patch 12.0.0
Added Rework section

**2025-10-08** Update for patch 11.2.5

**2025-08-06** Updated for patch 11.2

**2025-06-19** Updated for patch 11.1.5

**2025-02-25** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7.
BiS Updated

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
