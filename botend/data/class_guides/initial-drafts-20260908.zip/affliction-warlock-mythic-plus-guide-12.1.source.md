Welcome to the **Affliction Warlock** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 5/5 · Excellent

Mobility · 2/5 · Weak



:::

:::

:::column
:::gear **Affliction Warlock** Mythic+ Best in Slot
```json
{
  "source_code": "J4fAImQA3_fABIgJEIIEBAwJ5OgCtOgF2IoAYFQApfBBAERAAcVrBQBBMWTBUwDukQgAIEAAXk7ACKgTBEQvJ8AAJ0wDsECqDQIABAwJqOgGAHQNQsUABkLJFEDBFoaCxQw3XUwDAkSAxwAWBEAIVEDBZAcDxwxukQAAIEAACGwHgw9FEIICBAQ94GAHAIYAxRAgt4jEAQAht0AMQ4UABQ1HZwABdfRDMQBWBEA9iQQA2CQPNYHKz1CBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240906]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240906]] |
| 肩部 | [[item:271544]] | [[item:243991]] |
| 胸部 | [[item:271549]] | [[item:243977]] |
| 腰部 | [[item:239649]] | [[item:240906]] · [[item:240167]] · [[item:245786]] |
| 腿部 | [[item:271545]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240906]] · [[item:240167]] · [[item:245785]] |
| 手部 | [[item:271547]] |  |
| 戒指一 | [[item:268252]] | [[item:240906]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:273796]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:273779]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Afffliction Warlock**, you have access to Shadow of Nathreza, which empowers your [[spell:48181]] to deal a small amount of cleave damage.

**Rank 2** increases the initial damage and increases the bonus damage haunt provides to your other abilities. While **Rank 3** has a chance to call the demonic soul within the [[spell:48181]] causing a meteor to fall on your target which deals large AoE damage.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-affliction-mxr.webp>)

Shadow of Nathreza

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:30108]]
    
    - Your new spender ability in single target replacing [[spell:324536]].
  
  
  
  - [[spell:27243]]
    
    - Your new spender ability in AoE replacing [[spell:324536]].
  - [[spell:1257052]]
    
    - Replaces [[spell:386997]] as your smaller cooldown. [[spell:1259886]] reduces the cooldown of [[spell:1257052]] each time you spend shards.
  - [[spell:1260229]]
    
    - Has a chance to reapply [[spell:30108]] when the dot would expire.
  - [[spell:1261124]]
    
    - Increases haste when you apply [[spell:30108]] to a target that already has an Unstable Affliction active.
  - [[spell:1259825]]
    
    - Causes your [[spell:980]] to apply to a nearby target in additional to your primary target.
- **Class Tree**
  
  - [[spell:1265813]]
    
    - Great talent to apply [[spell:702]], [[spell:334275]] or [[spell:1714]] to a group of enemies at once.
  
  
  
  - [[spell:1265799]]
    
    - Applies an empowered [[spell:702]] to all enemies near your target.
  - [[spell:1271802]]
    
    - Applies an empowered [[spell:1714]] to all enemies near your target.
  - More [[talent:91466]] mobility
    
    - [[spell:1265801]] allows you to use gateway a second time before incurring the cooldown.
- **Removed**
  
  - [[spell:324536]]
  
  
  
  - [[spell:205179]]
  - [[spell:278350]]
  - [[spell:386997]]
  - [[spell:417537]]
  - [[spell:215941]]

## Hero Talents

- [[talent:123384]] currently outperforms [[talent:123382]] in every scenario be it single target, cleave or pure AoE.

:::tabs
:::tab [[talent:123384]]
- Generating a [[spell:246985]] now has a chance to grant a [[spell:449793@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]].
  
  - [[spell:449793@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] empowers your next [[spell:30108]] cast.
- [[spell:449637@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] makes [[talent:91552]] grant you a [[spell:108558]] proc.
  
  - Be careful to not overcap on [[spell:108558]] stacks as [[spell:449637@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] also makes your [[spell:146739]] tick faster which leads to more frequent procs.
- [[spell:449620@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] increases [[spell:686]] and [[spell:388667]] damage and amplifies [[spell:108558]].
- [[spell:449638@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] makes your [[spell:1257052]] grant 3 [[spell:246985]] that each contain a [[spell:449793@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]].
- [[spell:1268884]] causes you to occasionally unleash a demonic soul that cleaves enemies.

:::

:::tab [[talent:123382]]
- Your [[spell:146739]] is turned into [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]].
- You have access to a 1-minute cooldown called [[spell:430014@FAQA6hcA]].
- [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] can stack up and has multiple neat interactions with different talents which can increase its stack count or have other benefits.
  
  - Spending [[spell:246985]] on damaging spells increases the stacks of [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] by 1 and has a chance to gain an additional stack due to [[talent:117434]].
  - Casting [[spell:430014@FAQA6hcA]] increases all active [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] stacks by 6 while each [[spell:324536]] adds 1 additional stack during its duration.
  
  
  
  - [[talent:117441]] gives [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] the chance to add a stack whenever it crits.
- [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] has a built-in mechanic which consumes its' accumulated stacks one after another for more damage. This mechanic is called **Acute**.
  
  - The **Acute** state of [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] is triggered by the following: 
    
    - Chance whenever [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] gains a stack.
    - If [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] reaches 8 stacks.
    - If the target [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] is on reaches 20% hp or is below 20% already.
    - When [[talent:117439]] is up.
- [[spell:1266805]] Wither's periodic effect now has a chance to proc [[spell:430014@FAQA6hcA]]

:::

:::

## Talents

:::tabs
:::tab [[talent:123384]]
:::talents [[talent:123384]] **Affliction Warlock** Mythic+ Build
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### When to use this Spec

Recommended build when gearing and doing weekly keys.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **[Rotation](<https://maxroll.gg/wow/class-guides/affliction-warlock-mythic-plus-guide#rotation-header>)** and **[Deep Dive](<https://maxroll.gg/wow/class-guides/affliction-warlock-mythic-plus-guide#deep-dive-header>)** sections below.

#### Spec Tree

- [[spell:27243]]
  
  - Allows you to spread your [[spell:146739]] on a large number of targets quickly. Costs 1 [[spell:246985]].
- [[spell:1257052]]
  
  - Strong AoE cooldown that does heavy damage to all targets currently DoTed and generates shards.
  - [[spell:1259886]] reduces the cooldown of [[spell:1257052]]
- [[spell:108558]]
  
  - Buff that reduces the channel time of your next [[spell:198590]] and increases its damage. Stacks up to 2.
- [[talent:91552]]
  
  - Debuffs your target to take increased damage from your abilities.
- [[spell:205180]]
  
  - Main cooldown for burst windows.
  - [[spell:1280733]] also grants the ability to cleave up to 5 total targets.
- [[talent:91576]] 
  
  - Boost your filler windows with passive AoE during your [[talent:124692@FAQA74eB]]
- [[spell:1259825]]
  
  - Allows you to maintain agony on multiple targets.

#### Class Tree

- [[talent:91439]]
  
  - Helps you recover quickly in the event of death by allowing you to resummon a pet rapidly without cost.
- [[talent:91460]]
  
  - Your main mobility spell aside from [[talent:124694]] and [[talent:91466]], however, both of which require preplanning.
- [[spell:1271802]]
  
  - Allows you to cast an empowered AoE [[spell:1714]] effect.
- [[spell:1265799]]
  
  - Allows you to cast an empowered AoE [[spell:702]] effect.
- [[talent:91469]]
  
  - Empowers a multitude of utility spells for the cost of 1 [[spell:246985]].
  - Mainly used for [[spell:48020]], [[talent:91466]] and [[spell:6262]].
- [[spell:30283]]
  
  - Your only AoE CC that can affect an unlimited amount of targets.
- [[spell:6789]]
  
  - A single-target CC that can also be used as a defensive spell if you need to heal on demand.
  - Keep in mind that coiled and feared targets generally run **away** from you, so position yourself properly before casting it if needed.
  - [[spell:1265816]] increases the healing and range of Mortal Coil.
- [[talent:91444]]
  
  - A defensive spell that grants you a big absorb shield depending on your **current** health plus a certain amount on top of it.
- [[talent:91434]]
  
  - Combining [[spell:6262]] with [[talent:91469]] becomes a strong 1 minute defensive CD on long boss fights.

### Hero Talents

- [[talent:123840]] 
  
  - Your default pick because it increases your overall survivability unlike the other talent choice.
- [[talent:117420]]
  
  - Outperforms [[talent:123839]].
- [[talent:117421]]
  
  - Your default pick but can be swapped for [[talent:123838]] if you are the only CR in the team.

:::

:::tab [[talent:123382]]
:::talents [[talent:123382]] **Affliction Warlock** Mythic+ Build
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDLDAAAzAAAzMzMjZMzsNGzYMzMzYYmZGAgBM",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDLDAAAzAAAzMzMjZMzsNGzYMzMzYYmZGAgBM"
}
```
:::

### When to use this Spec

This hero talent is currently under preforming compared to [[talent:123384]].

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[talent:91566]]

- **Removed**
  
  - [[talent:124692@FAQA74eB]]

#### Hero Talents

- [[talent:117419]]
  
  - Your default pick since both talent choices are very niche and this one has more use cases than the other one.
- [[talent:117451]]
  
  - Outperforms [[talent:123310]] currently.
- [[talent:117432]]
  
  - Helps you recover your lost health from using [[talent:91444]].

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:172]] damage increased by 25%. [[spell:980]] damage increased by 15%.
- **4-Set:** Each active [[spell:30108]] increased your damage dealt by your spells and abilities by 2% up to 6%. [[spell:27243]] applies Unstable Affliction at 20% effectiveness to your target.

### Single-Target

:::tabs
:::tab [[talent:123384]]
### Opener

- Your goal in the opener is to apply and maintain all the DoTs and debuffs while also not overcapping on [[spell:246985]] and [[talent:91568]] procs. Below, you can see an example of how your opener looks when using the recommended [[talent:123384]] single-target spec.

:::rotation **Affliction Warlock** Single-Target opener in Mythic+
```json
{
  "source_code": "IwGTLIUN8CAAAcAUyVGc1xGbAIE1DAQABwgQz0jAFgAB8FSARwgABwprBgAEAEAhtQQBYQwwSbDCAgAXuMhUYAAKDLNBAAAAAI0OuXA"
}
```
1. [[spell:48181]] Prepull
2. [[spell:980]]
3. [[spell:146739]]
4. [[spell:205180]]  [[item:241308]] · [[item:273796]]
5. [[spell:316099]]
6. [[spell:316099]]
7. [[spell:1257052]]
8. [[spell:316099]]
9. [[spell:316099]]
10. [[spell:316099]]
11. [[spell:388667]]
:::

- Always keep up, [[spell:980]], [[spell:146739]], and [[talent:91552]] on the target.
- Precast [[talent:91552]] ~2 seconds before the pull. That way it hits the boss as the pull timer reaches 0.
- [[talent:123384]] has a higher number of total [[talent:91568]] procs over the fight compared to [[talent:123382]]. Always keep that in mind and never overcap on either of the procs.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up, [[spell:980]] and [[spell:146739]].
2. Cast [[spell:48181]] on cooldown, but you can delay it for a few seconds if the debuff is not about to expire on the target and you have the maximum amount of [[spell:108558]] stacks.
3. Cast [[spell:1257052]] on cooldown as long as you have 2 or less [[spell:246985]].
4. Cast [[spell:205180]] on cooldown as long as you have 3 or more [[spell:246985]].
5. Cast [[talent:124692]] if you have [[spell:108558]].
6. Cast [[spell:316099]] if you are otherwise capping on [[spell:246985]].
7. Cast [[talent:124692]] as your filler spell.

:::

:::tab [[talent:123382]]
### Opener

- Your goal in the opener is to apply and maintain all the DoTs and debuffs while also not overcapping on [[spell:246985]] and [[talent:91568]] procs. Below, you can see an example of how your opener looks when using the recommended [[talent:123382]] single-target spec.

:::rotation **Affliction Warlock** Single-Target opener in Mythic+
```json
{
  "source_code": "IMHTMIUN8CAAAcAUyVGc1xGbAIE1DAQABwgQcwsBFgABmFcCIQAfhEQGMIQAc6aAIABABQYLEUAIEMs02gAAIwlLTIFGAQywSTAAAAAAC5qA"
}
```
1. [[spell:48181]] Prepull
2. [[spell:980]]
3. [[spell:445468]]
4. [[spell:442726]]
5. [[spell:205180]]  [[item:241308]] · [[item:273796]]
6. [[spell:316099]]
7. [[spell:316099]]
8. [[spell:1257052]]
9. [[spell:316099]]
10. [[spell:316099]]
11. [[spell:316099]]
12. [[spell:686]]
:::

- Always keep up, [[spell:980]], [[spell:146739]], and [[talent:91552]] on the target.
- Precast [[talent:91552]] ~2 seconds before the pull. That way it hits the boss as the pull timer reaches 0.
- [[talent:123384]] has a higher number of total [[talent:91568]] procs over the fight compared to [[talent:123382]]. Always keep that in mind and never overcap on either of the procs.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up, [[spell:980]] and [[spell:146739]].
2. Cast [[spell:48181]] on cooldown, but you can delay it for a few seconds if the debuff is not about to expire on the target and you have the maximum amount of [[spell:108558]] stacks.
3. Cast [[spell:1257052]] on cooldown as long as you have 2 or less [[spell:246985]].
4. Cast [[spell:442726]] on cooldown.
5. Cast [[spell:205180]] on cooldown as long as you have 3 or more [[spell:246985]].
6. Cast [[spell:686]] if you have [[spell:108558]].
7. Cast [[spell:316099]] if you are otherwise capping on [[spell:246985]].
8. Cast [[spell:686]] as your filler spell.

:::

:::

### AoE

:::tabs
:::tab [[talent:123384]]
### Opener

- Your goal in the AoE opener is similar to single-target with the only difference of applying DoTs to more targets, mostly through [[spell:27243]]. Below, you can see an example of how your opener looks when using the recommended [[talent:123384]] AoE spec.

:::rotation **Affliction Warlock** AoE opener in Mythic+
```json
{
  "source_code": "I0HTMI0aqBAAAcAUyVGc1xGbAIUN8CQABggQUPQAHkBCEwXIBEBDCEAnuGACQAQAE2CBBECCCtmaBcAEAIEXuMRAJUBERgRCIABgBIkvHEQOwAkQrpGAAAAAAIkvHMA"
}
```
1. [[spell:27243]] Prepull
2. [[spell:48181]]
3. [[spell:980]]
4. [[spell:980]]
5. [[spell:205180]]  [[item:241308]] · [[item:273796]]
6. [[spell:27243]]
7. [[spell:1257052]]
8. [[spell:27243]]
9. [[spell:27243]]
10. [[spell:27243]]  
    
    1. [[spell:198590]]  
       
       随后回到主循环
11. [[spell:27243]]
12. [[spell:198590]]
:::

- Spend all [[spell:246985]] on [[talent:91571]].
- Apply and maintain [[spell:980]] manually on priority targets, try and maintain 4 to 5 agony's up at all times to help generate [[spell:246985]].

### Priority List

1. Keep up [[spell:980]] on up to 5 targets.
2. Cast [[spell:48181]] on cooldown on the main target.
3. Cast [[spell:205180]] on cooldown.
4. Cast [[spell:1257052]] on cooldown.
5. Cast [[talent:91571]] if you are about to cap on [[spell:246985]] proc.
6. Cast [[talent:91571]] if you have [[spell:108558]] procs.
7. Cast [[talent:91571]] whenever you have [[spell:246985]].
8. Cast [[spell:388667]] as your filler spell.

While [[spell:48181]], [[spell:388667]] and [[spell:316099]] could lower your overall dps in big pulls, it's still a damage gain on a priority target. And the way modern WoW works is that every single pull has at least one or two important trash mobs that are beneficial to kill fast to make the pull easier.

:::

:::tab [[talent:123382]]
### Opener

- Your goal in the AoE opener is similar to single-target with the only difference of applying DoTs to more targets, mostly through [[spell:27243]]. Below, you can see an example of how your opener looks when using the recommended [[talent:123382]] AoE spec.

:::rotation **Affliction Warlock** AoE opener in Mythic+
```json
{
  "source_code": "I0HTMI0aqBAAAcAUyVGc1xGbAIUN8CQABggQUPQAHkBCI47jGEQEIIEfhEQGMIQAc6aAIABABQYLEUAGEsmaBcAEAIEXuMRAJUBEJgBEAGgQ-eQAxADQCtmaAAAAAAgQ-ewA"
}
```
1. [[spell:27243]] Prepull
2. [[spell:48181]]
3. [[spell:980]]
4. [[spell:980]]
5. [[spell:430014]]
6. [[spell:205180]]  [[item:241308]] · [[item:273796]]
7. [[spell:27243]]
8. [[spell:1257052]]
9. [[spell:27243]]
10. [[spell:27243]]  
    
    1. [[spell:198590]]  
       
       随后回到主循环
11. [[spell:27243]]
12. [[spell:198590]]
:::

- Spend all [[spell:246985]] on [[talent:91571]].
- Apply and maintain [[spell:980]] manually on priority targets, try and maintain 4 to 5 agony's up at all times to help generate [[spell:246985]].

### Priority List

1. Keep up [[spell:980]] on up to 5 targets.
2. Cast [[spell:48181]] on cooldown on the main target.
3. Cast [[spell:430014]] on cooldown.
4. Cast [[spell:205180]] on cooldown.
5. Cast [[spell:1257052]] on cooldown.
6. Cast [[talent:91571]] if you are about to cap on [[spell:246985]] proc.
7. Cast [[talent:91571]] whenever you have [[spell:108558]].
8. Cast [[talent:91571]] whenever you have [[spell:246985]].
9. Cast [[spell:686]] as your filler spell.

While [[spell:48181]], [[spell:686]] and [[spell:316099]] could lower your overall dps in big pulls, it's still a damage gain on a priority target. And the way modern WoW works is that every single pull has at least one or two important trash mobs that are beneficial to kill fast to make the pull easier.

:::

:::

## Deep Dive

### Burn Windows

As an **Affliction Warlock**, you want to cast as many [[spell:316099]] as possible during your **Burn Windows**.

- **Burn Window is whenever you have [[spell:205180]] ready. Your main goal is to save as many [[spell:246985]] as you can for this cooldown and cast as many [[spell:316099]] as possible in that window.**

With experience, you get a better understanding of how many [[spell:246985]] you want to spend outside of your burns, which varies on the number of targets you fight.

### Managing Soul Shards

The main goal of both [[talent:123384]] and [[talent:123387]] is to spend as many shards while you have [[spell:205180]] active as possible. This means prior to using [[spell:205180]], you want to have 4 to 5 shards and [[spell:1257052]] ready. This allows you to spend a large amount of [[spell:246985]] right after you use [[spell:205180]], allowing for the highest output.

### Nightfall

With the addition of **hero talents**, the amount of procs you get over the fight is significantly increased. To the point that managing them and not overcapping is as important as keeping up your DoTs and not failing your **Burn Windows**.

Soul Harvester increases the amount of [[talent:91568]] you get with [[talent:117435]].

The difference between [[talent:123387]] and [[talent:123384]] is quite big to the point that you need to manage your [[spell:246985]] differently depending on the spec.

### Drain Soul clipping

Clipping means manually interrupting your cast. It is not necessary to finish your [[spell:388667]] channel cast **unless** it is buffed by [[talent:91568]]. So any time you cast [[spell:388667]] without it, you clip it whenever any other spell higher in priority comes in.

For example, if you are casting normal unbuffed [[spell:388667]] and you get a [[talent:91568]] proc then you instantly clip your cast and spend the proc.

### Dark Harvest

Although the usage of this spell is pretty straightforward, there are a couple of things you need to keep in mind:

- [[spell:1257052]] is a 1 minute cooldown that gets reduced every time we cast  [[talent:91571]] or [[spell:316099]], therefore; it is crucial we are spending shards efficiently to reduce this powerful spell's cooldown as much as possible.

### Optimizing Summon Darkglare

The main feature of [[spell:205180]] is its increased damage per DoT on the current target. For optimal use of [[spell:205180]], you want to spend as many shards as possible in quick succession to ramp up his damage.

Another important thing to know is that [[spell:205180]] is a **guardian** and how it updates its stats. It happens differently the moment [[spell:205180]] is summoned and when it is already up.

Once you cast [[spell:205180]], it snapshots your character's stats instantly but when it is already active, it may take a few seconds to update. That is why you press potion, racial and any on use stat trinket right before [[spell:205180]] and not after.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Affliction Warlock** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

#### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

#### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  
  
  
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.
- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.

:::

:::tab Den of Nalorakk
:::talents **Affliction Warlock** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

#### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

#### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  
  
  
  - [[spell:1241463]] from **Avatar of Determination**.
  
  
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  
  
  
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Affliction Warlock** Mythic+ Build in Murder Row
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

#### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

#### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

#### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  
  
  
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  
  
  
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Affliction Warlock** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

#### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

#### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

#### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  
  
  
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  
  
  
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents **Affliction Warlock** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

#### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

#### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  
  
  
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  
  
  
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents **Affliction Warlock** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

#### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

#### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

#### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  
  
  
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  
  
  
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  
  
  
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents **Affliction Warlock** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

#### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

#### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  
  
  
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  
  
  
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Affliction Warlock** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CmQAUgGY_myp-zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB",
  "code": "CmQAUgGY/myp+zpUCockSq2z5zMmZGNbM2mZGzyAAAmZmlZxMzyYAgx22ADYCmhtADbDAAAzAAAYmZMjZmtxYGjZmZGDzMzAAMgB"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

#### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

#### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

#### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  
  
  
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  
  
  
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring some Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix 
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  - Xal'atath's Bargain: Devour
  
  
  
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as an **Affliction Warlock**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:30283]] to hit as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - Make sure to DoT **Void Emissary** as soon as it appears.
- Xal'atath's Bargain: Devour
  
  - Dispel yourself with **Imp's** [[spell:89808]]. Otherwise consider using a  [[spell:452930]] or [[spell:6789]] if needed.
- Xal'atath's Bargain: Pulsar
  
  - Nothing special you can do as an **Affliction Warlock** with this affix. Just make sure to not run after your own orb but look for orbs from your teammates instead.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Affliction Warlock**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Affliction Warlock** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUAIkEDKBMwAEA"
}
```
**智力 ＞ 暴击 ≥ 急速 ≥ 精通 ≫ 全能**
:::

Main thing that you need to understand as an **Affliction Warlock**, when it comes to stats, is that **Mastery** is very valuable on AoE and any type of cleave and that **Versatility** is your worst stat and should be avoided.

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed** **-**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@BCRAAkQAK06YhNCKAWB]] | Ula'tek |
| Neck | [[item:268265@BERAAkQAX16oQrDj1IoAYFA]] | Ula'tek |
| Shoulder | Convert [[item:239031@BgQAAkQACKgTBA]]  <br>into [[item:271544@DgQAAkQAXk7IoAOF]] | Temple of Sethrallis / Catalyst |
| Cloak | [[item:268253@BgQAAkQACKAWBA]] | The Coiled Altar |
| Chest | [[item:271549@DgQAAkQAJk7IoAOF]] | Tier / Catalyst |
| Wrist | [[item:239648@FCQAAkQAno6kBwjCtOLF]] | Crafting |
| Gloves | Convert [[item:268243@BgQAAkQACKAWBA]]  <br>into [[item:271547@BgQAAkQACKAWBA]] | The Coiled Altar / Catalyst |
| Belt | [[item:239649@FCQAAkQAno6oBwjCtOLF]] | Crafting |
| Legs | [[item:271545@DgQAAkQAFo6IoAOF]] | Tier / Catalyst |
| Boots | [[item:268255@DgQAAkQApk7IoAYF]] | The Coiled Altar |
| Ring 1 | [[item:268252@DiQAAkQA1j7oQrjgC4UA]] | Sszorak |
| Ring 2 | [[item:273792@DiQAAkQA1j7oQrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:273796@BgQAAkQACKgTBA]] | Altar of Fangs |
| Trinket 2 | [[item:270164@BgQAAkQACKgTBA]] | The Lost Explorers |
| Weapon | [[item:271092@DgQAAkQA9k7IoAYF]] | Ula'tek |
| Off-hand | [[item:273779@BgQAAkQACKgTBA]] | Altar of Fangs |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@BgQAAkQACKQQBA]] | The Blinding Vale |
| Neck | [[item:273781@BgQAAkQACKQQBA]] | Altar of Fangs |
| Shoulder | [[item:271544@BgQAAkQACKQQBA]] | Tier / Catalyst |
| Cloak | [[item:239656@FAQAAkQAno6oBwzSBA]] | Crafting |
| Chest | [[item:271549@BgQAAkQACKQQBA]] | Tier / Catalyst |
| Wrist | [[item:239648@FCQAAkQAno6kBwjCtOLF]] | Crafting |
| Gloves | [[item:271547@BgQAAkQACKQQBA]] | Tier / Catalyst |
| Belt | [[item:251222@BgQAAkQACKQQBA]] | Voidscar Arena |
| Legs | [[item:271545@BgQAAkQACKQQBA]] | Tier / Catalyst |
| Boots | [[item:159259@BgQAAkQACKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAkQACKQQBA]] | Murder Row |
| Ring 2 | [[item:273792@BgQAAkQACKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:273649@BgQAAkQACKQQBA]] | Kings' Rest |
| Trinket 2 | [[item:273794@BgQAAkQACKQQBA]] | Altar of Fangs |
| Weapon | [[item:251123@BgQAAkQACKQQBA]] | Murder Row |

:::

:::

### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on the dungeon.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:273649@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A-Tier** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B-Tier** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C-Tier** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **Junkyard** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### Embellishments

- 1x [[item:245876@BAAAAkQA]]
  
  - Only crafted on your **main hand** or **off-hand weapon**. Craft it on your main hand for more power early on or on your off-hand for long-term BiS.
- 1x [[item:245876@BAAAAkQA]]
  
  - Early on use 2 of these on a combination of **main hand** and **off-hand weapon**. When you loot a mythic weapon and upgrade it you can drop [[item:245876@BAAAAkQA]] on your main hand in favour of the higher ilvl item you looted.

or

- 1x [[item:251488]]
  
  - Deals a decent amount of damage in Single-Target.
  
  
  
  - The optimal slot to craft on is **ring**.
- 1x [[item:251490]]
  
  - Doubles the effect of [[item:251488]]
  - The optimal slot to craft on is **wrist** or **Belt**.

or

- 1x [[item:245876@BAAAAkQA]]
  
  - Crafted on your **off-hand weapon**.
- 1x [[item:251488]]
  
  - Crafting on **ring** is optimal for long term use.

or

- 2x [[item:240167]]
  
  - Crafted on Wrist and Belt.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Flask**
  
  - [[item:241326]]
  
  
  
  - [[item:241324]]
- **Food**
  
  - [[item:255846]] -- default
- Combat Potion
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] -- default
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].*
    
    - [[item:240900]]
    
    
    
    - [[item:240892]]
    - [[item:240916]]
    - [[item:240906]]

### Enchantments

:::columns
:::column
| Head | [[item:243981@DAAAAkQAZbAB]]  <br>[[item:275707@BAAAAkQA]] |
| --- | --- |
| Cloak | [[item:223731@BAAAAkQA]] |
| Chest | [[item:243977@BAAAAkQA]] |
| Wrist | [[item:275707@BAAAAkQA]] |
| Waist | [[item:275707@BAAAAkQA]] |
| Legs | [[item:240133@BAAAAkQA]] |
| Boots | [[item:244009@BAAAAkQA]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:244029@BAAAAkQA]] |

:::

:::column
:::gear **Affliction Warlock** Enchantments in Mythic+
```json
{
  "source_code": "JQFaJEQ9NCQA7TDBQAAAAcG3SEw-4OAAAAAABkQuJgAC7TDBFABBFoaCQAQK6gBAAUfDwgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[spell:1236071]] |
| 肩部 | [[item:243963]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAkQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Affliction Warlock** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:33702]] -- Orc
  
  - Strong racial for damage both because of [[spell:21563]] and [[spell:33702]] which lines up with [[spell:205180]].
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:274738]] *-- Mag'har* Orc
  
  - Strong DPS racial which lines up with [[spell:205180]].
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] -- Troll
  
  - Strong DPS racial but lines up poorly with [[spell:205180]].
  - Reduce the duration of movement impairing effects by 20%.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Affliction Warlock**.

## Macros

Discover recommended macros for **Affliction Warlocks** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:30283]]** -- *Casts [[spell:30283]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Shadowfury
```

:::

:::details Mouseover Macros
**[[spell:316099]]** -- *Casts [[spell:316099]] on your mouseover or target.*

```wow-macro
#showtooltip Unstable Affliction
/cast [@mouseover,exists] Unstable Affliction;Unstable Affliction
```

**[[spell:980]]** -- *Casts [[spell:980]] on your mouseover or target.*

```wow-macro
#showtooltip Agony
/cast [@mouseover,exists] Agony;Agony
```

**[[spell:146739]]** -- *Casts [[spell:146739]] on your mouseover or target.* *Swaps automatically to [[spell:445465@FJgCf2SATdhALunADm4ArnRBvl4Awl4AnZNBf0wBg0wBJA]] if [[talent:123387]] is picked.*

```wow-macro
#showtooltip Corruption
/cast [@mouseover,exists] Corruption;Corruption
```

**[[spell:702]]** -- *[[spell:328774]] before applying [[spell:702]] to your mouseover target or target.*

```wow-macro
#showtooltip Curse of Weakness
/cast [known:328774] Amplify Curse
/cast [@mouseover, exists, harm, nodead] Curse of Weakness; Curse of Weakness
```

**[[spell:1714]]** -- *Uses [[spell:328774]] before applying [[spell:1714]] to your mouseover target or target..*

```wow-macro
#showtooltip Curse of Tongues
/cast [known:328774] Amplify Curse
/cast [@mouseover, exists, harm, nodead] Curse of Tongues; Curse of Tongues
```

**[[spell:334275]]** -- *Uses [[spell:328774]] before applying [[spell:29539]] to your mouseover target or target.*

```wow-macro
#showtooltip Curse of Exhaustion
/cast [known:328774] Amplify Curse
/cast [@mouseover, exists, harm, nodead] Curse of Exhaustion;[@target] Curse of Exhaustion
```

**[[spell:234153]]** -- *Uses [[spell:234153]] on your mouseover target or target.*

```wow-macro
#showtooltip
/cast [@mouseover,exists] Drain Life;Drain Life
```

**[[spell:710]]** -- *Casts [[spell:710]] on your mouseover target if it exists.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] Banish; [harm,nodead] Banish
```

:::

:::details Pet Macros
> We're mainly using custom macros for Pets because the normal functionality of [[spell:119898]] proved unreliable in the past.

**Pet Ability 1 Macro** -- *Casts your main pet abilities for each pet on* your mouseover target.

```wow-macro
/cast [@mouseover]Singe Magic
/cast [@mouseover,exists]Spell Lock;Spell Lock
/cast [@mouseover]Suffering
/cast [@mouseover,exists]Seduce;Seduce
/cast [@mouseover,exists]Axe Toss;Axe Toss
/cast [nopet,@mouseover,exists]Command Demon;[nopet]Command Demon
```

**Focus Pet Ability** **1 Macro** -- *Casts your main pet abilities for each pet on your focus target.*

```wow-macro
/cast [@focus] Singe Magic
/cast [@focus] Spell Lock
/cast [@focus] Suffering
/cast [@focus] Seduce
/cast [@focus] Axe Toss
/cast [nopet,@focus] Command Demon
```

**Pet Ability** **2 Macro** *-- Casts your second relevant pet ability on your mouseover target if needed.*

```wow-macro
/cast [@mouseover] Singe Magic
/cast [@mouseover,exists] Devour Magic;Devour Magic
/cast Shadow Bulwark
/cast Felstorm 
/cast [nopet,@mouseover] Command Demon
```

**Focus Pet Ability** **2 Macro** -- *Casts the second relevant Pet ability on your focus target, also sends your pet to attack your focus.*

```wow-macro
/cast [@focus]Singe Magic;
/cast [@focus] Devour Magic;
/cast [@focus] Lesser Invisibility;
/cast Shadow Bulwark;
/cast [nopet,@focus] Command Demon
/petattack [@focus]
```

**[[spell:108503]] & dismiss pet** -- *Casts [[spell:108503]] if you specced into it. If you don't have Grimoire of Sacrifice talented it dismisses your pet instead.*

```wow-macro
#showtooltip
/run if not IsSpellKnown(108503) then PetDismiss(); end
/cast Grimoire of Sacrifice
```

:::

:::details Utility Macros
**[[spell:20707]]** Mouseover -- *Casts [[spell:20707]] on your mouseover, conventional [@mouseover,exists] macros got broken a while ago, this is a work around for it.*

```wow-macro
#showtooltip Soulstone 
/target [@mouseover,help] 
/cast Soulstone 
/targetlasttarget
```

**[[spell:5697]]** Selftcast *-- Casts [[spell:5697]] on yourself without targeting anything. Useful for situations where you're not able to DPS anything to still fish for trinket proccs / stacks.*

```wow-macro
#showtooltip
/cast [@player] Unending Breath
```

**[[spell:30283]] / [[spell:5484]] choice *-- Swaps between [[spell:30283]]* *and [[spell:5484]] depending on which talent got picked.***

```wow-macro
/cast [known:Shadowfury] Shadowfury
/cast [known:Howl of Terror] Howl of Terror
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Affliction Warlock**, outlining which addons are used. As well as additional addons you may find useful in Mythic+.

![](<https://assets-ng.maxroll.gg/wordpress/UI-ss-maxroll-1-1024x610.jpg>)

**Affliction Warlock** User Interface in Mythic+

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for custom scripts.
- **BetterCooldownManager**  *--* Advanced Blizzard Cooldown Manager
  
  - BetterCooldownManager is an addon that allows more customization and cleaner look to the default Blizzard Cooldown Manager.
- **Details**  *--* Damage Tracking
  
  - Details allows for more customization of the default blizzard damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- **Hellcaller** 
  
  - *Developers’ notes: We’re updating Blackened Soul to give Hellcaller a better tool for focusing damage into a priority target, increasing the overall flexibility of the hero talent tree rather than have it only excel in situations where multiple targets are present. However, we are keeping the functionality of Malevolence the same, so it remains a cool and impactful tool in Hellcaller’s toolkit.*
  - Blackened Soul has been redesigned – If the target is afflicted with your Wither, your Chaos Bolt and Shadowburn increase its stack count by 1. Each time Wither gains a stack it has a chance to collapse, consuming a stack every 1 second to deal Shadowflame damage to its host until 1 stack remains.  
    Mark of Peroth’arn has been redesigned – Damaging critical strikes dealt by Wither deal 215% damage instead of the usual 200%. Damaging critical strikes dealt by Blackened Soul deal 225% damage instead of the usual 200%.
- **Affliction** 
  
  - Haunt now increases your damage dealt to the target by 16% for 18 seconds (was 12%).
  - New Talent: Hedonic Gorging – Increases Drain Life damage by 10% and Siphon Life now increases the damage of Corruption by an additional 10%. Dark Harvest channels 10% faster and deals 15% increased damage.
  - Patient Zero has been removed.
  - New Talent: Impetuous Wrath – Shadow Bolt, Drain Soul, and Malefic Grasp damage increased by 10% or 20% if the target is affected by Haunt. Dark Harvest damage increased by 10% or 20% if the target is affected by Haunt.
  - Shard Instability has been redesigned – Damage dealt by Shadow Bolt or Drain Soul has a 20% chance to make your next Unstable Affliction or Seed of Corruption cost no Soul Shards and cast instantly.
  - Nocturnal Yield has been removed.

:::

:::

:::accordion
:::details Patch 12.0.1
- **Hellcaller** 
  
  - Malevolence damage increased by 230%.

- Soul Harvester
  
  - Wicked Reaping now increases the damage of Manifested Avarice’s Soul Swipe.
  - Shared Vessel now increases Mastery by 2% (was 4%).
  - Manifested Demonic Soul's Soul Swipe damage reduced by 30%. This change does not affect PvP combat.
  - Soul Anathema damage reduced by 40%.
- Affliction
  
  - Sataiel’s Volition no longer affects the chance of gaining Nightfall.
  - Dark Harvest damage reduced by 30%.
  - Only 1 application of Haunt can be active at a time.
  - Creeping Death no longer affects the chance of gaining Nightfall.

:::

:::

:::accordion
:::details Patch 12.0
- **Hellcaller** 
  
  - New Talent: Through the Felvine Affliction: Increases the damage of Unstable Affliction by 8% and Seed of Corruption by 4%. This effect is doubled while Malevolence is active.
  - New Talent: Devil Fruit – Periodic damage dealt by Wither has a chance to grant Malevolence for 8 seconds.
  - New Talent: Alzzin's Iniquity – Malevolence grants an additional 4% Haste and when cast increases the stack count of active Withers by an additional 2 stacks.
  - Blackened Soul damage increased by 30%.
- **Affliction** 
  
  - Seeds of Their Demise now has a chance to grant Shard Instability (was Tormented Crescendo).
  - Mark of Xavius now increases Agony damage by 30% (was 20%).
  - Wither damage reduced by 35%.
- **Soul Harvester** 
  
  - New Talent: Manifested Avarice – Each Succulent Soul consumed has an increasing chance to unleash the Demonic Soul within you, enabling it to assault your enemies for 9 seconds.
  - New Talent: Soul Swipe – Strikes nearby enemies with a malevolent claw, dealing Shadow damage to its target and Shadow damage to other enemies in 10 yards.
  - New Talent: Shared Vessel – Increases your Mastery by 4%. This effect is doubled while the demonic entity is aiding you in combat.
  - New Talent: Eternal Hunger – Increases the duration of Manifested Avarice by 5 seconds and increases the damage of Soul Swipe by 10%.
  - Demonic Soul has been updated – A demonic entity now inhabits your soul, allowing you to detect if a Soul Shard has a Succulent Soul when granted. Consuming a Succulent Soul unleashes your demonic soul, dealing Shadow damage to all enemies within 10 yards of the target. Damage reduced beyond 8 targets. Demonic Soul damage increased by 100%.
  - Wicked Reaping damage increased by 150%.
  - Soul Anathema damage increased by 50%.
- **Affliction** 
  
  - Shadow of Death has been redesigned – Your Dark Harvest spell is empowered by the demonic entity within you, causing it to grant 1 Soul Shard that each contain a Succulent Soul every 1 second while channeled.
- **Class** 
  
  - New Talent: Curse of Exhaustion – Reduces the target's movement speed by 50% for 12 seconds.
  - New Talent: Curse of Tongues – Forces the target to speak in Demonic, increasing the casting time of all spells by 30% for 1 minute.
  - New Talent: Blight of Weakness – Call forth a cloud of cloying shadow mist that envelopes the target and all enemies within 10 yards, increasing the time between their attacks by 100% and reducing their critical strike chance by 10% for 12 seconds.
  - New Talent: Blight of Tongues – Call forth a cloud of cloying shadow mist that envelopes the target and all enemies within 10 yards, increasing their casting time of all spells by 100% for 12 seconds.
  - New Talent: Improved Mortal Coil – Increases the range of Mortal Coil by 10 yards and the amount it heals by 5%.
  - New Talent: Infernal Beneficiary – Healing done by Drain Life also heals your primary demon at 400% effectiveness.
  - New Talent: Foul Mouth – Casting Curse of Exhaustion, Tongues, or Weakness now curses all enemies within 10 yards of the target.
  - New Talent: Shared Vitality – Healing done by Drain Life also heals your primary demon at 100% effectiveness.
  - New Talent: Gorefiend's Avarice – Drain Life now channels 50%/100% faster and restores health 50%/100% faster.
  - New Talent: Frequent Traveler – Reduces the cast time of Demonic Gateway by 0.5 seconds and you can now use Demonic Gateways twice before triggering a cooldown.
  - New Talent: Pact of the Satyr – Increases your Haste by 3%.
  - New Talent: Pact of the Annihilan – Increases your Critical Strike chance by 2%.
  - New Talent: Pact of the Nathrezim – Increases your Leech by 2%.
  - New Talent: Pact of the Eredar – Increases Intellect by 3%.
  - New Talent: Empowered Healthstone – Healthstones restore 5% additional health.
  - New Talent: Empowered Drain Life – Drain Life now heals for 700% of damage dealt and now grants Soul Leech equal to 10% of damage dealt.
  - New Talent: Fortified Soul – Soul Leech now grants shields up to 15% of your maximum health.
  - New Talent: Oppressive Darkness – Reduces the cooldown of Shadowfury by 15 seconds and increases its radius by 2 yards. Reduces the cooldown of Howl of Terror by 10 seconds and it now fears 5 additional enemies.
  - Many talents have changed positions in the talent tree.
  - New starter builds have been implemented for all 3 specializations.
  - The following talents have been removed:
  - Accrued Vitality
  - Amplify Curse
  - Curses of Enfeeblement
  - Darkfury
  - Demonic Inspiration
  - Demonic Tactics
  - Lifeblood
  - Pact of Exhaustion
  - Pact of Tongues
  - Socrethar's Guile
  - Soul Conduit
  - Sargerei Technique
  - Teachings of the Satyr
  - Wrathful Minion
- Affliction 
  
  - New Talent: Practiced Pestilence – Increases your Mastery by 2%.
  - New Talent: Shared Agony – Increases Agony damage by 10% and Agony now hits another nearby enemy within 15 yards of the target.
  - New Talent: Seeds of Destruction – Reduces the cast time of Seed of Corruption by 0.2 seconds/0.4 seconds and increases its damage by 5%/10%.
  - New Talent: Dark Harvest – Consume the life force of each target afflicted by your damaging periodic effects, dealing Shadowflame damage over 3 seconds. Damage dealt by Dark Harvest heals you for 50% of damage done. 1 minute cooldown.
  - New Talent: Sudden Onset – Agony damage is increased by 10% and starts at 3 stacks.
  - New Talent: Fatal Echoes – When Unstable Affliction expires, it has a 10% chance to reapply itself.
  - New Talent: Shard Instability – Damage dealt by Shadow Bolt/Drain Soul has a 20%/10% chance to make your next Unstable Affliction cost no Soul Shards and cast instantly.
  - New Talent: Nocturnal Yield – Increases Corruption damage by 10% and Nightfall additionally makes your next Seed of Corruption cost no Soul Shards and cast instantly.
  - New Talent: Patient Zero – Increases damage dealt by Seed of Corruption to its host by 50%.
  - New Talent: Sow the Seeds – Seed of Corruption now embeds demon seeds into 2 additional nearby enemies at 50% effectiveness.
  - New Talent: Malefic Grasp – While Darkglare is active, your Shadow Bolt/Drain Soul becomes Malefic Grasp. Malefic Grasp: Binds the target in twilight, dealing Shadow damage over 4 seconds. When Malefic Grasp deals damage, it causes all of your other periodic Affliction damage effects to instantly deal 30% of their normal periodic damage.
  - New Talent: Potent Soul Shards – Increases damage dealt by Unstable Affliction and Seed of Corruption by 5%.
  - New Talent: Niskaran Methods – Increases the damage of Agony and Corruption by 10%.
  - New Talent: Eye Contract – Increases the duration of Summon Darkglare by 5 seconds.
  - New Talent: Nether Plating – Adorns your Darkglare with armor forged from within Antorus, increasing their armor by 10%. Eye Beam now jumps to up to 4 additional targets and deals 10% increased damage.
  - Unstable Affliction has been redesigned – Afflicts the target within Shadow damage over 8 seconds. Multiple uses of this ability may overlap. If dispelled, dealing Shadow damage to the dispeller and silences them for 4 seconds. Generates 1 Soul Shard if the target dies while afflicted. Unstable Affliction damage increased by 20%.
  - Xavius' Gambit has been redesigned – Reduces the cast time of Unstable Affliction by 0.15 seconds/0.3 seconds and increases its damage by 5%/10%.
  - Improved Haunt has been redesigned – Increases the damage of Haunt by 35% and reduces its cast time by 0.3 seconds.
  - Cull the Weak has been redesigned – Casting Unstable Affliction or Seed of Corruption reduces the cooldown of Dark Harvest by 1.5 seconds.
  - Death's Embrace has been redesigned – Agony, Corruption, Unstable Affliction, Seed of Corruption, and Shadow Bolt/Drain Soul deal up to 40% increased damage on targets below 35% health. Damage increase is higher against lower health targets.
  - Creeping Death has been updated – Your Agony, Corruption, and Unstable Affliction deal damage 10%/20% faster.
  - Withering Bolt has been updated – Shadow Bolt/Drain Soul deal 5%/10% increased damage, up to 15%/30%, per damage over time effect you have active on the target.
  - Seed of Corruption damage increased by 330% and is reduced beyond 8 targets.
  - Summon Darkglare has been updated – Summons a Darkglare from the Twisting Nether that increases the damage of Agony, Corruption/Wither, and Unstable Affliction by 20% while active. The Darkglare will serve you for 20 seconds, blasting its target Shadow damage, increased by 10% (was 45%) for every damage over time effect you have active on their current target. Cooldown now 2 minutes (was 1 minute).
  - Summon Darkglare damage increased by 260%. This change does not affect PvP combat.
  - Agony moved to the talent tree (was learned at level 10).
  - Agony damage increased by 82%. This change does not affect PvP combat.
  - Corruption damage increased by 50%.
  - Shadow Bolt damage increased by 60%. This change does not affect PvP combat.
  - Drain Soul damage increased by 60%. This change does not affect PvP combat.
  - Contagion's icon has been updated.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
  - Dark Virtuosity
  - Focused Malignancy
  - Improved Malefic Rapture
  - Kindled Malice
  - Malefic Rapture
  - Malefic Touch
  - Malevolent Visionary
  - Malign Omen
  - Oblivion
  - Perpetual Unstability
  - Phantom Singularity
  - Relinquished
  - Shadow Embrace
  - Soul Rot
  - Tormented Crescendo
  - Vile Taint
  - Volatile Agony

:::

:::

## FAQ

:::accordion
:::details Q: What pet should I use?
**A:** All pets do similar damage so you should be using the one you need the most which is usually [[spell:691]].

:::

:::

---

### Credits

Written By: **Spen**

Reviewed by: **Ftm**

:::changelog 更新记录
**2026-06-17** Updated for patch 12.0.7

**2026-04-22** Updated for patch 12.0.5

**2026-02-22** Updated for patch 12.0.1

**2026-02-12** Updated for patch 12.0.1



:::
