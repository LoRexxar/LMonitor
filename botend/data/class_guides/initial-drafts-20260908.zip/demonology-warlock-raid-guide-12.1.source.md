Welcome to the **Demonology Warlock** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 5/5 · Excellent

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Demonology Warlock** Raid Best in Slot
```json
{
  "source_code": "IotAYrQA3_fABIgJEIIOBAw74OwVtOgF2gCAAWzX1cBNYYzf1gVABk-FEAQKBAABtOABtOAj1QWNoAQAcAPTYFQA4SCBCgRAAcRuD4XNBWjgC4UAB0LJEIAKBAQC5Oge1IYN2IzF0gCAOFQAhg6ACiTAAoBwDQQrDY7LMYzt1sZJAMCYwYbNLFQA5SSB1wQBqOQfuUDAE89FF8FRPk7AYYjX1IoAYFQAgg6ACCTAVgEIgBDAjYbNWJytBYEH7SCBAgRAAsXBLyCWBEA3XQgggEAA1jbA4SAZ1EgtcYjMOFQAeqmAZgBF2IjX1YbNFsLBU9RBAVBKEQYLFARAiUAIY09FEAACBAQBISA9iUwmI0TuDEwLAgRINgTpXQAAYEAA2IjX1IoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271544]] | [[item:243991]] |
| 胸部 | [[item:271549]] | [[item:243977]] |
| 腰部 | [[item:239649]] | [[item:240900]] · [[item:245786]] |
| 腿部 | [[item:271545]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240900]] · [[item:245786]] |
| 手部 | [[item:271547]] |  |
| 戒指一 | [[item:268252]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:273796]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## Midnight Changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Demonology Warlock**, you have access to [[spell:1276163]], which is essentially a new version of [[spell:267217]]. For 15 seconds after casting [[talent:125850]] you want to cast as many [[talent:125834]] as possible.

**Rank 2** increases the duration of the demons you spawn from [[spell:1276163]]. While **Rank 3** makes each [[talent:125834]] refund 1 [[spell:104756]] which allows you to cast way more of them during the 15 sec window.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-demoonology-mxr.webp>)

Dominion of Argus

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:125836]]
    
    - Changed to have a 15 second cooldown and also capped to 6 [[spell:104317]].
  
  
  
  - [[talent:125863]]
    
    - The random Doomguards from [[spell:453568]] got replaced with a 2 min cooldown.
  - [[talent:136725]] / [[talent:136726]] 
    
    - Replacement  cooldown for [[spell:111898]], this gives you an additional use of [[spell:19647]] / [[spell:89808]].
- **Class Tree**
  
  - [[talent:136100]]
    
    - Great talent to apply [[spell:702]], [[spell:334275]] or [[spell:1714]] to a group of enemies at once.
  
  
  
  - [[talent:136101]]
    
    - More [[talent:91466]] mobility!
  - [[talent:136108]] / [[talent:136738]]
    
    - Powerful new AoE curses to slow down multiple enemies' attack or castspeed.
  - [[talent:136104]]
    
    - Direct [[spell:40671]] replacement.
- **Removed**
  
  - [[spell:215941]]
    
    - This results in fewer available [[spell:246985]] and less randomness in your [[spell:246985]] economy.
  - [[spell:264057]]
    
    - Reduces your [[spell:246985]] generation slightly.
  - [[spell:267211]] / [[spell:267171]]
    
    - Decent nerf to the on-demand AoE burst.

## Hero Talents

- [[talent:123385]] and [[talent:123383]] have pretty similar damage profiles. With [[talent:123385]] your burst damage through [[spell:265187]] becomes a lot stronger and [[talent:123383]] emphasizes [[talent:125836]] and AoE damage.
- Currently [[talent:123385]] performs slightly better in almost all scenarios.



### [[talent:123385]]

- Spending a [[spell:246985]] starts a cycle of one of 3 different [[spell:428514@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]. 
  
  1. [[spell:431944@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]
  2. [[spell:432815@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]
  3. [[spell:432816@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]
  4. Starts on 1. again.

- Only 1 [[spell:428514@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] can be up at a time and each turns into their respective **Demonic Art** after it expires which is triggered after you spend your next [[spell:246985]]:
  
  - [[spell:428524]]
    
    - A Fel Lord jumps at your target and applies [[spell:434424]] for 15 seconds.
  - [[spell:432794]]
    
    - Deals damage to your target and turns your next [[spell:686]] into [[spell:434506]] which generates 3 [[spell:246985]].
  - [[spell:432795]]
    
    - Summons a Pit Lord that attacks your target with [[spell:434404]] and turns your next [[spell:105174]] into [[spell:434635]] which summons 3 [[spell:104317]] at a 0 [[spell:104756]] cost.
- Your [[spell:265187]] windows become a lot more important with [[spell:429581@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]].
- [[talent:136092]]
  
  - Passive AoE damage when consuming [[spell:428524]], [[spell:432794]] or [[spell:432795]].
- [[talent:136091]]
  
  - Additional single-target damage when consuming [[spell:428524]], [[spell:432794]] or [[spell:432795]].
- [[talent:136090]]
  
  - Every time you consume [[spell:428524]], [[spell:432794]] or [[spell:432795]]. You gain 2% intellect per consumed [[talent:136092]] up to 6% for 10 seconds.




### [[talent:123383]]

- [[spell:449793]] empower your [[spell:105174]] and makes it apply [[talent:117444]].
  
  - [[spell:449793]]
    
    - Every time you generate a [[spell:104756]] it has a chance to give you a [[spell:449793]].
    - [[spell:265187]] grants you 3 [[spell:104756]] and 3 [[spell:449793]].
  - [[talent:117444]]
    
    - [[spell:105174]] applies [[talent:117444]] to all targets hit.
    - Consuming a [[spell:267102]] applies [[talent:117444]] to your current target.
  - [[talent:117420]]
    
    - When you consume a [[spell:267102]] your target gets afflicted by [[talent:117420]].
    - During AoE scenarios it's important to never cast [[spell:264178]] on targets that are too far away to benefit from [[talent:117420]] AoE damage.
  - [[talent:117435]]
    
    - Combined with [[talent:125834]] you now have a 15% chance per [[spell:104317]] to receive [[spell:267102]] after casting [[talent:125836]].
    - Make sure to be on a low amount of [[spell:267102]] stacks before casting [[talent:125836]].
  - [[talent:136098]]
    
    - Each [[spell:449793]] consumed has an increasing chance to unleash the [[spell:449614]] within you, enabling it to assault enemies with [[spell:1269049]].
  - [[talent:136097]]
    
    - Increases your Mastery by 4%.
    - This effect is doubled while the demonic entity is aiding you in combat.
  - [[talent:136096]]
    
    - Increases the duration of [[talent:136098]] by 5 sec and increases the damage of [[spell:1269049]] by 10%.





## Talents



### [[talent:123386]] Raid Build

:::talents [[talent:123386]] **Demonology Warlock** Raid Build talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### When to use this Spec

Use this spec if it's a pure single-target scenario.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[spell:104316]]
  
  - One of your key abilities which is enhanced by a multitude of talents.
  
  
  
  - [[spell:205145]] allows you to cast [[spell:104316]] for free and without cast time.
  - [[talent:135314]] spawns with your [[spell:104316]] which makes it even more important to use [[spell:104316]] on cooldown.
- [[spell:264130]]
  
  - Significantly boosts your influx of [[spell:267102]].
  - Make sure to always have 2+ [[spell:279910]] before you use it.
- [[spell:265187]]
  
  - The main cooldown for **Demonology**, synergizes with the majority of spells within the spec.
- [[talent:136725]] / [[talent:136726]]
  
  - Strong 2 min cooldown that is a big portion of your damage, always use this in combination with [[spell:265187]].
- [[talent:125863]]
  
  - Another 2 min cooldown, this one doesn't benefit from the buffs of [[spell:265187]] so you can use it more freely.
-

##### Class Tree

- [[talent:91439]]
  
  - Used as a quick pet recovery either if your current pet dies or you got resurrected. Skips the [[spell:246985]] cost and significantly reduces the cast time for the summoned pet.
- [[talent:91460]]
  
  - Toggleable movementspeed increase that costs health per second to use.
- [[talent:91452]]
  
  - Quick selfheal on a short cooldown. Further enhanced by [[talent:136105]].
- [[talent:91444]]
  
  - Provides you with a big absorbshield at the cost of your heatlh. Health cost is reduced by [[talent:91446]]. You can also change [[talent:91446]] to [[talent:91445]] to have access to more potential [[talent:91444]] uses.
- [[talent:91466]]
  
  - Enables you to travel a larger distance once every 90 seconds. You are able to use it twice if [[talent:136101]] is talented.
- [[talent:91469]]
  
  - Enhances multiple utility spells, mainly used together with [[spell:48020]], [[spell:6262]], [[spell:111771]] and [[spell:234153]].
- [[talent:91434]]
  
  - Massive for survivability since it alters your [[spell:452930]] to be usable multiple times per combat.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:104317]] damage increased by 10%. [[spell:196277]] damage increased by 20%.
- **4-Set:** When their energy depletes, [[spell:104317]] have a 20% chance to fling themselves at their target and [[spell:196277]] at 250% effectiveness to their main target and 225% effectiveness to other targets.

### Single-Target



#### [[talent:123385]]

##### Opener

> [[spell:89751]] is assumed to be on autocast and therefore not included in any Openers & Priority Lists.

- The goal of your opener is to empower and extend [[spell:104316]] & [[talent:136726]] with [[spell:265187]].
- When you are running [[talent:125836]] and have no [[spell:267102]] you can pre-cast [[spell:264178]] instead.

:::rotation [[talent:123385]] **Demonology Warlock** single-target opener in Raid
```json
{
  "source_code": "I0CsGIgrCAACQJXZtMWYzRHAC4qAAAAACRieTAAAAAgA8dZAAAgAjvABAAgQWrZA"
}
```
1. [[spell:686]] Pre-cast
2. [[spell:686]]
3. [[spell:1276452]]
4. [[spell:104316]]
5. [[spell:265187]]
6. [[spell:105174]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] in combination with [[spell:265187]].
- If talented into [[talent:136731]]
  
  - Pre-cast [[talent:136731]] 8-10 seconds before combat preferably but make sure you have 2 [[spell:104317]] beforehand.

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:104316]] and [[talent:136726]] before [[spell:265187]].
2. Cast [[spell:104316]] on cooldown.
3. Cast [[talent:125863]] on cooldown.
4. If talented cast [[talent:136731]] when you have 2+ [[spell:104317]] and 2 or less [[spell:267102]].
5. Cast [[talent:125836]] on cooldown with you have 6 [[spell:104317]] if talented.
6. Cast [[spell:105174]] / [[spell:434635]] if you are about to overcap on [[spell:104756]].
7. Cast [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] if you are below 3 [[spell:104756]] and [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] is up.
8. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
9. Cast [[spell:105174]] with 3 [[spell:104756]].
10. Cast [[spell:686]] to generate [[spell:104756]].




#### [[talent:123383]]

##### Opener

> [[spell:89751]] is assumed to be on autocast and therefore not included in any Openers & Priority Lists.

- The goal of your opener is to empower and extend [[spell:104316]] & [[talent:136726]] with [[spell:265187]].
- When you are running [[talent:125836]] and have no [[spell:267102]] you can pre-cast [[spell:264178]] instead.

:::rotation [[talent:123383]] **Demonology Warlock** single-target opener in Raid
```json
{
  "source_code": "I8CuGIgrCAACQJXZtMWYzRHACRieTAAAAAgA8dZAAAgAjvABAAgQWrZAAAAAAIk1aGA"
}
```
1. [[spell:686]] Pre-cast
2. [[spell:1276452]]
3. [[spell:104316]]
4. [[spell:265187]]
5. [[spell:105174]]
6. [[spell:105174]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] in combination with [[spell:265187]].
- If talented into [[talent:136731]]
  
  - Pre-cast [[talent:136731]] 8-10 seconds before combat preferably but make sure you have 2 [[spell:104317]] beforehand.

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:104316]] and [[talent:136726]] before [[spell:265187]].
2. Cast [[spell:104316]] on cooldown.
3. Cast [[talent:125863]] on cooldown.
4. If talented cast [[talent:136731]] when you have 2+ [[spell:104317]] and 2 or less [[spell:267102]].
5. Cast [[talent:125836]] on cooldown with you have 6 [[spell:104317]] if talented.
6. Cast [[spell:105174]] if you are about to overcap on [[spell:104756]].
7. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
8. Cast [[spell:105174]] with 3 [[spell:104756]].
9. Cast [[spell:686]] to generate [[spell:104756]].





### AoE



#### [[talent:123385]]

##### Opener

- The goal of your opener is to empower and extend [[spell:104316]] & [[talent:136726]] with [[spell:265187]].
- When you are running [[talent:125836]] and have no [[spell:267102]] you can pre-cast [[spell:264178]] instead.

:::rotation [[talent:123385]] **Demonology Warlock** AoE opener in Raid
```json
{
  "source_code": "I0CsGIgrCAACQJXZtMWYzRHAC4qAAAAACRieTAAAAAgA8dZAAAgAjvABAAgQWrZA"
}
```
1. [[spell:686]] Pre-cast
2. [[spell:686]]
3. [[spell:1276452]]
4. [[spell:104316]]
5. [[spell:265187]]
6. [[spell:105174]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] in combination with [[spell:265187]].

##### Priority List

1. Cast [[spell:104316]] and [[talent:136726]] before [[spell:265187]].
2. Cast [[spell:104316]] on cooldown.
3. Cast [[talent:125836]] on cooldown with you have 6 [[spell:104317]] if talented.
4. Cast [[spell:105174]] / [[spell:434635]] if you are about to overcap on [[spell:104756]].
5. Cast [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] if you are below 3 [[spell:104756]] and [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] is up.
6. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
7. Cast [[spell:196277]] on 4+ targets with 6+ [[spell:104317]].
8. Cast [[spell:264130]] when you have 2 or less [[spell:267102]] stacks.
9. Cast [[spell:105174]] with 3 [[spell:104756]].
10. Cast [[spell:686]] to generate [[spell:104756]].




#### [[talent:123383]]

##### Opener

- The goal of your opener is to empower and extend [[spell:104316]] & [[talent:136726]] with [[spell:265187]].
- When you are running [[talent:125836]] and have no [[spell:267102]] you can pre-cast [[spell:264178]] instead.

:::rotation [[talent:123383]] **Demonology Warlock** AoE opener in Raid
```json
{
  "source_code": "I8CuGIgrCAACQJXZtMWYzRHACRieTAAAAAgA8dZAAAgAjvABAAgQWrZAAAAAAIk1aGA"
}
```
1. [[spell:686]] Pre-cast
2. [[spell:1276452]]
3. [[spell:104316]]
4. [[spell:265187]]
5. [[spell:105174]]
6. [[spell:105174]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] in combination with [[spell:265187]].

##### Priority List

1. Cast [[spell:104316]] and [[talent:136726]] before [[spell:265187]].
2. Cast [[spell:104316]] on cooldown.
3. Cast [[talent:125836]] on cooldown with you have 6 [[spell:104317]] if talented.
4. Cast [[spell:105174]] if you are about to overcap on [[spell:104756]].
5. Cast [[spell:264178]] if you have 2+ stacks of [[spell:267102]].
6. Cast [[spell:196277]] on 4+ targets with 6+ [[spell:104317]].
7. Cast [[spell:264130]] when you have 2 or less [[spell:267102]] stacks.
8. Cast [[spell:105174]] with 3 [[spell:104756]].
9. Cast [[spell:686]] to generate [[spell:104756]].





## Deep Dive

### Implosion Cycles

[[talent:125836]] is a unique spell, making it potentially confusing. Here are some tips and tricks:

- For maximum damage always use [[talent:125836]] with 6 ‍[[spell:104317]].

#### Execution

For an ideal [[spell:196277]] cycle, ensure you have at least 2 [[spell:267102]]. After casting the last [[spell:105174]], wait for the [[spell:104317]] to spawn or use a filler global before casting [[spell:196277]].

:::rotation **Demonology Warlock** Raid Implosion Cycle
```json
{
  "source_code": "IQEmGIANZGAFTRXYyRHI3lGdoBCNrAyUoFmckNHACYtmBAAACI_BEAAAdwARAKgAuKAAAAgA16vAAAgA16vA"
}
```
1. [[spell:104756]] Start with 4+ Shards
2. [[spell:105174]]
3. [[spell:264178]]
4. [[spell:105174]]
5. [[spell:264178]]  
   
   1. [[spell:686]]
   2. [[spell:196277]]
6. [[spell:196277]]
:::

### Minmaxing Doom

When [[talent:136729]] expires it deals a high amount of damage to the target and all enemies within 10 yards.

- Single-target
  
  - To ensure maximum uptime of [[talent:136729]] it is beneficial to keep at least 1 [[spell:264173]] in the back pocket to avoid periods of downtime on [[talent:136729]].
  - While doing this it's important to not overcap on [[spell:264173]] as the maximum amount of charges is 4.
- Multi-target
  
  - When facing multiple targets, prioritize applying [[talent:136729]] to different targets for more explosions. During large pulls, tab between each [[spell:264178]] to cycle through targets.

### Demonic Tyrant Mechanics

Your [[talent:125850]] is a so called **Guardian** pet that works a bit differently compared to your primary pet called [[spell:30146]] that is a combat pet. [[talent:125850]] targets whatever your [[spell:30146]] targets.

#### Guardian Pet Stat Update

[[talent:125850]] like many other **Guardians** does update dynamically with stat increases such as haste but sometimes does so very slowly.

:::timeline
```json
{
  "source_code": "HcCmuj4hIAgAB8PzAQAAIAgACN-CEAAABAgQhnTAAAgAAEgQt2aAAAAB"
}
```
总时长：8 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 1 秒 | [[spell:265187]] | 上轨 |
| 2 秒 | [[spell:80353]] | 上轨 |
| 4 秒 | [[spell:109997]] | 下轨 |
:::

[[spell:80353]] is cast at 0:02 but your [[talent:125850]] doesn't update his haste until 0:04. The same applies to all stats and damage increases.

**This is just an example of an inconsistent mechanic and might not be accurate in every scenario!**

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'zali

:::talents **Demonology Warlock** Nek'zali talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Ensure [[spell:1271802]] or [[spell:1714]] is active on the interrupt add when you go into the phase.




### Entombed Sentinels

:::talents **Demonology Warlock** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- A well placed [[spell:48018]] can allow you to move quickly between bosses.




### The Lost Explorers

:::talents **Demonology Warlock** The Lost Explorers talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Place your [[spell:48018]] near the centre giving you an option to port over the fire ring instead of using the mushroom.




### Vashnik

:::talents **Demonology Warlock** Vashnik talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- You can hold [[talent:125836]] for add spawns to quickly burst them.
- Preplace your [[spell:111771]] and [[spell:48018]] to quickly travel between add spawns.




### Sszorak

:::talents **Demonology Warlock** Sszorak talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Place [[spell:48018]] near the middle of the room to save yourself from knock ups and winds in the intermission.




### Twin Fangs

:::talents **Demonology Warlock** Twin Fangs talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Make sure to target swap and pet attack add spawns to quickly kill them and reduce the amount of stacks your raid gets.




### Coiled Altar

:::talents **Demonology Warlock** Coiled Altar talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Make sure to have [[talent:136726]] and [[talent:125850]] ready for the intermission damage amp.




### Ula'tek

:::talents **Demonology Warlock** Ula'tek talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Preplace your [[spell:48018]] near melee to be able to port over the waves.




### Nymrissa Wavecaller

:::talents **Demonology Warlock** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### Boss Tips

- Place a [[spell:111771]] in the safe spot of the intermission so your raid can cancel the knockback from the boss.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Demonology Warlock**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Demonology Warlock** Stat Priorities in Raid
```json
{
  "source_code": "HoAJFUAJgEDKBEgABA"
}
```
**智力 ＞ 急速 ＞ 暴击 ＝ 精通 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a bad tertiary for you since most of your damage is from your pets.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DiTAAoQAvj7cVrjF2gCAAWzX1cBNYYzf1gVA]] | Ula'tek |
| Neck | [[item:268265@BkSAAoQAE06QQrDj1QWNoAwF0ghNYFA]] | Ula'tek |
| Shoulder | [[item:271544@DgRAAoQAXk74XNBWjgC4UA]] | Tier |
| Cloak | [[item:268253@BgQAAoQACKAWBA]] | The Coiled Altar |
| Chest | [[item:271549@DgSAAoQAJk7oXNCWjNycBNoAgTB]] | Tier |
| Wrist | [[item:239648@BCTAAoQAE06Y7LgBDAjYbNWJyt1sUA]] | Crafting |
| Gloves | Convert [[item:268243@AgQAAIoAYFA]]  <br>into [[item:271547@BgRAAoQA7VTg1IoAYFA]] | Catalyst of The Coiled Altar |
| Belt | [[item:239649@DiTAAoQAaA8QQrjtvwgN3WzmlAwIgBjt1sUA]] | Crafting |
| Legs | [[item:271545@DgSAAoQAFo60XNCWjNycBNoAgTB]] | Tier |
| Boots | [[item:268255@DgRAAoQAPk7ghNeVjgCgVA]] | The Coiled Altar |
| Ring 1 | [[item:268252@DCSAAoQA1j7QQrDZ1gCAXQjNy4UA]] | Sszorak |
| Ring 2 | [[item:158366@DCSAAoQA1j7QQrjNy4VN2WjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgRAAoQAoAwF0YjMOFA]] | The Lost Explorers |
| Trinket 2 | [[item:273796@BgRAAoQA2IjX1IoAOFA]] | Altar of Fangs |
| Weapon | [[item:271092@DgRAAoQA9k7gCAXQDG2gVA]] | Ula'tek |
| Offhand | [[item:268197@BgRAAoQA2IjX1IoAOFA]] | Entombed Sentinels |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@AgQAAIoABFA]] | The Blinding Vale |
| Neck | [[item:273781@AgQAAIoABFA]] | Altar of Fangs |
| Shoulder | [[item:239031@AgQAAIoABFA]] | Temple of Sethraliss |
| Cloak | [[item:251132@AgQAAIoABFA]] | Murder Row |
| Chest | [[item:251139@AgQAAIoABFA]] | Murder Row |
| Wrist | [[item:251127@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:159247@AgQAAIoABFA]] | Temple of Sethraliss |
| Belt | [[item:251222@AgQAAIoABFA]] | Voidscar Arena |
| Legs | [[item:251160@AgQAAIoABFA]] | Den of Nalorakk |
| Boots | [[item:159259@AgQAAIoABFA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Ring 2 | [[item:273792@AgQAAIoABFA]] | Altar of Fangs |
| Trinket 1 | [[item:273649@AgQAAIoABFA]] | Kings' Rest |
| Trinket 2 | [[item:273794@AgQAAIoABFA]] | Altar of Fangs |
| Weapon | [[item:251123@AgQAAIoABFA]] | Murder Row |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:273649@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A-Tier** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B-Tier** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C-Tier** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **Junkyard** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### Embellishments

- 2x [[item:240166]]
  
  - Proc that increases your primary stat, also gives a small buff to an ally.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334-344 on max item level, therefore it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Flask**
  
  - [[item:241326]]
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  
  
  
  - [[item:240983]] *-- Unique*

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAoQAZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulders | [[item:243991@BAAAAoQA]] |
| Chest | [[item:243977@BAAAAoQA]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:240133@BAAAAoQA]] |
| Boots | [[item:243953@BAAAAoQA]] |
| Ring 1 | [[item:243957@BAAAAoQA]] |
| Ring 2 | [[item:243957@BAAAAoQA]] |
| Weapon | [[item:244029@BAAAAoQA]] |

:::

:::column
:::gear **Demonology Warlock** Enchantments in Raid
```json
{
  "source_code": "IQFZKEQ9NCQA7TDBCAAAA8OuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.*

## Races

For min-maxing a **Demonology Warlock** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial but lines up poorly with [[spell:265187]].
  - Reduce the duration of movement-impairing effects by 20%. This was only useful once in the recent history of progression raiding but is still worth noting.
- [[spell:33702]] *-- Orc* 
  
  - Strong racial for damage because of both [[spell:21563]] and [[spell:33702]] which lines up with [[spell:265187]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the latest Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Demonology Warlocks** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:30283]]** -- *Casts [[spell:30283]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Shadowfury
```

:::

:::details Mouseover Macros
**[[spell:702]]** -- *[[spell:328774]] before applying [[spell:702]] to your mouseover target or target.*

```wow-macro
#showtooltip Curse of Weakness
/cast [@mouseover, exists, harm, nodead] Curse of Weakness; Curse of Weakness
```

**[[spell:1714]]** -- *Uses [[spell:328774]] before applying [[spell:1714]] to your mouseover target or target..*

```wow-macro
#showtooltip Curse of Tongues
/cast [@mouseover, exists, harm, nodead] Curse of Tongues; Curse of Tongues
```

**[[spell:334275]]** -- *Uses [[spell:328774]] before applying [[spell:29539]] to your mouseover target or target.*

```wow-macro
#showtooltip Curse of Exhaustion
/cast [@mouseover, exists, harm, nodead] Curse of Exhaustion;[@target] Curse of Exhaustion
```

**[[spell:710]]** -- *Casts [[spell:710]] on your mouseover target if it exists.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] Banish; [harm,nodead] Banish
```

**[[spell:5782]]** -- *Casts [[spell:5782]] on your mouseover target if it exists.*

```wow-macro
#showtooltip
/cast [@mouseover,exists]Fear;Fear
```

**[[spell:20707]]** Mouseover -- *Casts [[spell:20707]] on your mouseover, conventional [@mouseover,exists] macros got broken a while ago, this is a workaround for it.*

```wow-macro
#showtooltip Soulstone 
/target [@mouseover,help] 
/cast Soulstone 
/targetlasttarget
```

:::

:::details Pet Macros
> We're mainly using custom macros for Pets because the normal functionality of [[spell:119898]] proved unreliable in the past.

**Pet Ability 1 Macro** -- *Casts your main pet abilities for each pet on* your mouseover target.

```wow-macro
/cast [@mouseover]Singe Magic
/cast [@mouseover,exists]Spell Lock;Spell Lock
/cast [@mouseover]Suffering
/cast [@mouseover,exists]Seduce;Seduce
/cast [@mouseover,exists]Axe Toss;Axe Toss
/cast [nopet,@mouseover,exists]Command Demon;[nopet]Command Demon
```

**Focus Pet Ability** **1 Macro** -- *Casts your main pet abilities for each pet on your focus target.*

```wow-macro
/cast [@focus] Singe Magic
/cast [@focus] Spell Lock
/cast [@focus] Suffering
/cast [@focus] Seduce
/cast [@focus] Axe Toss
/cast [nopet,@focus] Command Demon
```

**Pet Ability** **2 Macro** *-- Casts your second relevant pet ability on your mouseover target if needed.*

```wow-macro
/cast [@mouseover] Singe Magic
/cast [@mouseover,exists] Devour Magic;Devour Magic
/cast Shadow Bulwark
/cast Felstorm 
/cast [nopet,@mouseover] Command Demon
```

**Focus Pet Ability** **2 Macro** -- *Casts the second relevant Pet ability on your focus target, and also sends your pet to attack your focus.*

```wow-macro
/cast [@focus]Singe Magic;
/cast [@focus] Devour Magic;
/cast [@focus] Lesser Invisibility;
/cast Shadow Bulwark;
/cast [nopet,@focus] Command Demon
/petattack [@focus]
```

:::

:::details Utility Macros
**[[spell:5697]]** Selftcast *-- Casts [[spell:5697]] on yourself without targeting anything. Useful for situations where you're not able to DPS anything to still fish for trinket procs/stacks.*

```wow-macro
#showtooltip
/cast [@player] Unending Breath
```

**[[talent:91457]] / [[spell:5484]]** choice *-- Swaps between [[talent:91457]]* *and [[spell:5484]] depending on which talent got picked. Useful to add your own macro conditions like @focus or @mouseover etc.*

```wow-macro
/cast [known:Shadowfury] Shadowfury
/cast [known:Howl of Terror] Howl of Terror
```

**All-In-One Potion --** *all the different damage [[item:212265]]*, *uses [[item:212256]]* *if you're dead.*

```wow-macro
/use [@player,nodead] item:212971
/use [@player,nodead] item:212265
/use [@player,nodead] item:212970
/use [@player,nodead] item:212264
/use [@player,nodead] item:212969
/use [@player,nodead] item:212263
/use [@player,dead]Grotesque Vial
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Demonology Warlock**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/DemomidnightraidUI-ezgif.com-png-to-webp-converter-2-1024x682.webp>)

**Demonology Warlock** Interface in Raids

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI** -- Additional customization for the Cooldown Manager
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI. With EllesmereUI you can easily disable modules you don't want and only use it for the CDM in this case.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripts.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.0.1
- Warlock
  
  - Hero Talents
    
    - [[talent:123386]]
      
      - Infernal Bolt damage increased by 150%.
      - Ruination damage increased by 50%. This change does not affect PvP combat.
    - [[talent:123383]]
      
      - Wicked Reaping now increases the damage of Manifested Avarice’s Soul Swipe.
      - Shared Vessel now increases Mastery by 2% (was 4%).
      - Manifested Demonic Soul's Soul Swipe damage reduced by 30%. This change does not affect PvP combat.
      - Soul Anathema damage reduced by 40%.
      - Demonology
        
        - Sataiel’s Volition now increases Wild Imp damage by 35% (was 5%).
        - Wicked Reaping now increases all demonic soul damage by 30% (was 10%).
        - Demonic Soul damage reduced by 3%.
        - Soul Swipe damage increased by 20%.
        - Wicked Reaping damage increased by 100%.
        - Soul Anathema damage increased by 50%.

:::

:::details Patch 12.0
- Warlock
  
  - New Talent: Curse of Exhaustion – Reduces the target's movement speed by 50% for 12 seconds.
  - New Talent: Curse of Tongues – Forces the target to speak in Demonic, increasing the casting time of all spells by 30% for 1 minute.
  - New Talent: Blight of Weakness – Call forth a cloud of cloying shadow mist that envelopes the target and all enemies within 10 yards, increasing the time between their attacks by 100% and reducing their critical strike chance by 10% for 12 seconds.
  - New Talent: Blight of Tongues – Call forth a cloud of cloying shadow mist that envelopes the target and all enemies within 10 yards, increasing their casting time of all spells by 100% for 12 seconds.
  - New Talent: Improved Mortal Coil – Increases the range of Mortal Coil by 10 yards and the amount it heals by 5%.
  - New Talent: Infernal Beneficiary – Healing done by Drain Life also heals your primary demon at 400% effectiveness.
  - New Talent: Foul Mouth – Casting Curse of Exhaustion, Tongues, or Weakness now curses all enemies within 10 yards of the target.
  - New Talent: Shared Vitality – Healing done by Drain Life also heals your primary demon at 100% effectiveness.
  - New Talent: Gorefiend's Avarice – Drain Life now channels 50%/100% faster and restores health 50%/100% faster.
  - New Talent: Frequent Traveler – Reduces the cast time of Demonic Gateway by 0.5 seconds and you can now use Demonic Gateways twice before triggering a cooldown.
  - New Talent: Pact of the Satyr – Increases your Haste by 3%.
  - New Talent: Pact of the Annihilan – Increases your Critical Strike chance by 2%.
  - New Talent: Pact of the Nathrezim – Increases your Leech by 2%.
  - New Talent: Pact of the Eredar – Increases Intellect by 3%.
  - New Talent: Empowered Healthstone – Healthstones restore 5% additional health.
  - New Talent: Empowered Drain Life – Drain Life now heals for 700% of damage dealt and now grants Soul Leech equal to 10% of damage dealt.
  - New Talent: Fortified Soul – Soul Leech now grants shields up to 15% of your maximum health.
  - New Talent: Oppressive Darkness – Reduces the cooldown of Shadowfury by 15 seconds and increases its radius by 2 yards. Reduces the cooldown of Howl of Terror by 10 seconds and it now fears 5 additional enemies.
  - Many talents have changed positions in the talent tree.
  - New starter builds have been implemented for all 3 specializations.
  - The following talents have been removed:Accrued Vitality
    
    - Amplify Curse
    - Curses of Enfeeblement
    - Darkfury
    - Demonic Inspiration
    - Demonic Tactics
    - Lifeblood
    - Pact of Exhaustion
    - Pact of Tongues
    - Socrethar's Guile
    - Soul Conduit
    - Sargerei Technique
    - Teachings of the Satyr
    - Wrathful Minion
  
  
  
  - Hero Talents
    
    - [[talent:123386]]
      
      - New Talent: Diabolic Oculi – You summon a Diabolic Oculus, up to 3, each time the duration of Diabolic Ritual is reduced by one of your spells. Diabolic Oculi explode when consuming Demonic Art, dealing Fire damage to all enemies within 8 yards of the target. Damage reduced beyond 8 targets.
      - New Talent: Looks That Kill – Your Diabolic Oculi now cast Diabolic Gaze at your primary's target every 1 second while active.
      - New Talent: Mind's Eyes – Your Diabolic Oculi observe the battlefield and collect information that is imparted to you upon being exploded, each Diabolic Oculi increasing your Intellect by 2% for 10 seconds.
      - Touch of Rancora now increases the damage of Hand of Gul'dan, Chaos Bolt, Rain of Fire, or Shadowburn by 20% (was 100%).
      - Eye Explosion damage reduced by 30%. This change does not affect PvP combat.
    - [[talent:123383]]
      
      - New Talent: Manifested Avarice – Each Succulent Soul consumed has an increasing chance to unleash the Demonic Soul within you, enabling it to assault your enemies for 9 seconds.
      - New Talent: Soul Swipe – Strikes nearby enemies with a malevolent claw, dealing Shadow damage to its target and Shadow damage to other enemies in 10 yards.
      - New Talent: Shared Vessel – Increases your Mastery by 4%. This effect is doubled while the demonic entity is aiding you in combat.
      - New Talent: Eternal Hunger – Increases the duration of Manifested Avarice by 5 seconds and increases the damage of Soul Swipe by 10%.
      - Demonic Soul has been updated – A demonic entity now inhabits your soul, allowing you to detect if a Soul Shard has a Succulent Soul when granted. Consuming a Succulent Soul unleashes your demonic soul, dealing Shadow damage to all enemies within 10 yards of the target. Damage reduced beyond 8 targets. Demonic Soul damage increased by 100%.
      - Wicked Reaping damage increased by 150%.
      - Soul Anathema damage increased by 50%.
  - Demonology
    
    - New Talent: Fel Intellect – Increases your Intellect by 2%.
    - New Talent: Practiced Rituals – Increases your Mastery by 2%.
    - New Talent: Unholy Power – Increases the damage of your primary demon by 5%/10%.
    - New Talent: Demonic Knowledge – Hand of Gul'dan has a 8%/15% chance to generate a charge of Demonic Core.
    - New Talent: Hellbent Commander – Your demons deal 1% increased damage for each demon you control.
    - New Talent: Antoran Armaments – Your Demonic Tyrant is equipped with armor forged within Antorus, increasing their armor by 10%. While summoned, your Demonic Tyrant now assaults enemies with powerful melee attacks.
    - New Talent: Summon Doomguard – Summons a Doomguard to assist you in combat for 12 seconds. Consuming a Demonic Core reduces the cooldown of Summon Doomguard by 3 seconds.
    - New Talent: Fel Armaments – The cooldown of your Felguard's Felstorm is reduced by 10 seconds and damage dealt to your primary demon is reduced by 10%.
    - New Talent: Infernal Rapidity – When your Wild Imps cast Fel Firebolt, they have a 10% chance to instantly cast another Fel Firebolt at 200% effectiveness.
    - New Talent: Dominant Hand – Increases damage dealt by Hand of Gul'dan to its main target by 20%.
    - New Talent: Blighted Maw – The fangs of your Dreadstalkers are coated in corrosive bile, causing Dreadbite to deal additional damage equal to 50% of damage dealt as Plague damage.
    - New Talent: Spiteful Reconstitution – Increases Demonbolt damage by 10% and consuming a Demonic Core has a chance to summon a Wild Imp.
    - New Talent: Tyrant's Oblation – Your Demonic Tyrant also empowers you while active, increasing your Haste by 8%.
    - New Talent: Reign of Tyranny – Your Demonic Tyrant lasts an additional 5 seconds and extends the duration of your Dreadstalkers by 15 seconds when summoned.
    - New Talent: Grimoire: Imp Lord – Summons an Imp Lord to assist you in combat for 20 seconds and will remove 1 harmful effect from you when summoned. Transforms into Singe Magic while on cooldown.
    - New Talent: Grimoire: Fel Ravager – Summons a Fel Ravager to assist you in combat for 20 seconds and will interrupt their target when summoned. Turns into Spell Lock while on cooldown.
    - New Talent: Stabilized Portals – Increases the duration of your Summon Vilefiend, Grimoire: Imp Lord, and Grimoire: Fel Ravager by 3 seconds.
    - New Talent: Empowered Felstorm – Increases the damage of your Felguard's Felstorm by 20% and its duration by 4 seconds.
    - New Talent: To Hell and Back – Power Siphon and Implosion summon 1 Imp Gang Boss for every 2 Wild Imps sacrificed. Wild Imps summoned this way gain Unstable Soul.Unstable Soul: Increases damage done by 100% and Fel Firebolt now jumps to 3 additional targets.
    - Summon Felguard has moved to the talent tree (was learned automatically when specializing in Demonology).
    - Felguard damage increased by 60%.
    - Hand of Gul'dan now replaces Corruption and has moved to the talent tree (was learned automatically when specializing in Demonology).
    - Hand of Gul'dan has been redesigned – Calls down a demonic meteor full of Wild Imps which burst forth to attack the target. Deals Shadowflame damage on impact to all enemies within 8 yards of the target and summons 3 Wild Imps.
    - Hand of Gul'dan damage reduced by 10%.
    - Wild Imp Fel Firebolt damage increased by 35%.
    - Imp Gang Boss has been redesigned – Hand of Gul'dan now empowers 1 of the Wild Imps it summons, increasing its damage dealt by 100%.
    - Rune of Shadows has been redesigned – Reduces the cast time of Shadow Bolt by 10%/20% and increases its damage by 15%/30%.
    - Summon Vilefiend has been redesigned – Call Dreadstalkers also summons a Vilefiend that assists you in combat for 15 seconds.
    - Improved Demonic Tactics has been updated – Increases the critical strike chance of your primary demon by 50% of your critical strike chance.
    - Doom has been updated – Hand of Gul'dan reduces the duration of Doom by 3 seconds.
    - Power Siphon has been updated – Instantly sacrifice up to 2 Wild Imps, generating 2 charges of Demonic Core that cause Demonbolt to deal 30% additional damage.
    - Implosion has been updated – Demonic forces suck 6 of your Wild Imps toward the target, and then cause them to violently explode, dealing Shadowflame damage to all enemies within 8 yards. 30 second cooldown. Implosion damage increased by 500%.
    - Demonic Calling has been updated – Call Dreadstalkers costs 1 less/2 less Soul Shards and its cast time is reduced by 50%/100%.
    - Demonic Brutality has been updated – Damaging critical strikes dealt by you and your demons deal 230% damage instead of the usual 200%.
    - Summon Demonic Tyrant has been updated – Summon a Demonic Tyrant that damages your target for 15 seconds. Damage dealt by Demonic Tyrant is increased by 10% for each Wild Imp and Dreadstalker.
    - Master Summoner has been updated – Increases Mastery by 3% and reduces the cast time of Summon Demonic Tyrant and Summon Felguard by 0.5 seconds.
    - Doom Bolt Volley has been updated – Sends a volley of malefic bolts at 5 enemies within 40 yards, inflicting Shadow damage to each target.
    - Infernal Grudge has been updated – Sears the soul of its target with fel fire, dealing Fire damage every 1 second.
    - Master of Summoner is now a 2-point talent. Increases Mastery by 3%/6% and reduces the cast time of your Call Dreadstalkers and Summon Demonic Tyrant by 15%/30%.
    - Sacrificed Souls is now a 2-point talent. Shadow Bolt and Demonbolt deals 2%/4% additional damage by demon you have summoned.
    - Several talents have changed positions in the talent tree.
    - The following talents have been removed:Bilescourge Bombers
      
      - Blood Invocation
      - Demonic Strength
      - Doom Eternal
      - Dread Calling
      - Fel Invocation
      - Fel Sunder
      - Fiendish Oblation
      - Foul Mouth
      - Grimoire: Felguard
      - Immutable Hatred
      - Impending Doom
      - Shadow Invocation
      - Shadowtouched
      - Soul Strike
      - The Expendables
      - The Houndmaster's Gambit
      - Umbral Blaze
      - Wicked Maw

:::

:::

## FAQ

:::accordion
:::details Q: Why is my [[talent:125836]] damage so low?
A: Check out the[ **Deep Dive**](<https://maxroll.gg/wow/class-guides/demonology-warlock-raid-guide#deep-dive-header>) section for more info on this topic.

:::

:::

---

### Credits

Written By: **Wolfdisco**

---

:::changelog 更新记录
**2026-08-04** Updated for patch 12.1

**2026-06-17** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-17** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0.

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-07-21** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-20** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-18** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
