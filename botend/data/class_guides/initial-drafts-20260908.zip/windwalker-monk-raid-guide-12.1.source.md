Welcome to the **Windwalker Monk** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 5/5 · Execellent

Survivability · 2/5 · Weak

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Windwalker Monk** Raid Best in Slot
```json
{
  "source_code": "JUrAY3QA3_PAB8JJEIIMBAQD5OwVtOAf1IYNXYjt1ghNCKAWBEQ6XQAApEAA8z6A8z6AMWDZ1ghNeVTBaQSnkQAAgEAA-VTgFwCPOFQAiSCBCASAAkQuDoXNCGRFQA-FEAIIFEUA6Qgt1UAPA4ZCqwQo7OQfNoCNYFQAf5mACgQAAkSuDIYAOBBY7OAgIVQOwDktvMWNRDzt1YTN6FjVi4INAMySBEA9UPAAYEAA2IjX1caJOFQA5Z9ACiRAAUPuDwPrDAwI2-yt1sUABIW2DIIIB0gFEQWNB4CHWiiTBEwXfQQA-EwkUkjAYFQAdlBEFEKGdfBBAgQAAUAD8c7FEIAEBAwP5OgF2IoAYFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240983]] · [[item:243981]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271517]] |  |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159327]] | [[item:244009]] |
| 腕部 | [[item:244576]] | [[item:240892]] |
| 手部 | [[item:251124]] |  |
| 戒指一 | [[item:251513]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Windwalker Monk**, you have access to Tigereye Brew, which increases your critical strike chance during [[talent:124826]].

**Rank 2** increases the total amount of your critical strike damage.

While **Rank 3** unlocks a new ability [[spell:1272696]]!

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-windwalker-mxr.webp>)

Tigereye Brew

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:128711]]
    
    - You gain [[talent:124985@FAgATZfABdhA]] damage in aoe, as it splashes now.
  - [[talent:134543@AJgCCA]]
    
    - A high chance to get free empowered [[talent:124985@FAgATZfABdhA]] after consuming [[spell:116768]].
  - [[talent:128712]]
    
    - Enhances your [[talent:125026]].
  - [[talent:124815]] or [[talent:124814]]
    
    - Empowers your [[talent:126307]].
  - [[talent:124817@FAQABdhA]]
    
    - Provides an additional hit at the end of your [[talent:125026]].
- **Class Tree**
  
  - [[talent:124956]]
    
    - Provides a decent chunk of damage after casting [[talent:124826]].
  - [[talent:124953]]
    
    - Increases your chance for your auto attacks to crit.
  - [[talent:136520]]
    
    - After a successful dispel the target is faster!
- **Removed**
  
  - [[spell:137639]]
    
    - Replaced by your new cooldown [[talent:124826]].
  - [[spell:123904]]
    
    - You change from a 2 minute class without this cooldown.
  - [[spell:393039]]
  - [[spell:459809]]
    
    - Removes your capabilities to cleave spread targets.
  - [[spell:122783]]
    
    - The loss of a defensive does make you more squishy.
  - [[spell:388686]]
    
    - More freedom of movement for the enemies in your cooldowns.

## Hero Talents

- In single target both hero talents [[talent:125027]] and [[talent:125047]] perform very similar, but due to higher burst from [[talent:125047]] it is most likely the better choice.
- [[talent:125027]] vastly outperforms  [[talent:125047]] in AoE scenarios.



### [[talent:125027]]

- Your autoattacks have a chance to generate 1-2 [[spell:451021]], upon casting [[spell:113656]] you unleash all your [[spell:451021]] stacks.

- [[talent:125072@AJgCCA]]
  
  - Reduces the cooldown of [[talent:124826]] by 10 seconds.
- [[talent:125073@AJgCCA]]
  
  - Your [[talent:124985@FAgATZfABdhA]] and [[spell:101546]] unleash up to 3 [[spell:451021]] during [[talent:124826]].
- [[talent:135955]]
  
  - [[talent:125069@AJgCCA]] deals damage to all enemies within 6 yards.
- [[talent:135956@AJgCCA]]
  
  - You gain 10 stacks of [[talent:125069@AJgCCA]] after casting [[talent:124826]], that will trigger on your next ability cast.
- [[talent:135957@AJgCCA]]
  
  - Increases [[talent:124956]] by 20%.




### [[talent:125047]]

- Gain access to [[talent:125062@FAQAfGPB]] a powerful 120 second cooldown.
- [[talent:136744]]
  
  - Reduces the cooldown of [[talent:125062@FAQAfGPB]] by 30 seconds.
- [[talent:136745@AJgCCA]]
  
  - Gain the ability to cast [[talent:136745@AJgCCA]] after summoning  [[talent:125062@FAQAfGPB]].
- [[talent:125055]]
  
  - Your [[talent:125014]] and your [[talent:134452]] grants you 75% cooldown reduction on [[talent:124985]], [[spell:113656]], [[talent:125014]] and [[talent:125011]].
  
  
  
  - While it is up your [[spell:113656]] channel time is reduced by 50%.
- [[talent:136754@AJgCCA]]
  
  - Gain [[talent:135959@AJgCCA]] after casting [[talent:124826]] for 4 seconds.
- [[talent:135958@AJgCCA]]
  
  - Increases your haste by 10% while [[talent:135959@AJgCCA]] is up.
- [[talent:125058]]
  
  - After finishing your [[talent:136745@AJgCCA]] you spawn all Celestials.
  - It is also possible to finish the channel early to spawn them faster.





## Talents



### [[talent:125027]] Single-Target

:::talents [[talent:125046]] **Windwalker Monk** single target talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:125009]]
  
  - [[talent:134452]] and [[talent:125014]] grants you a guaranteed [[spell:116768]] proc.
- [[talent:124825]]
  
  - The duration of [[talent:124826]] is increased by 5 seconds.
- [[talent:124810]]
  
  - You have a chance to restore 1 Chi with [[talent:124985@FAgATZfABdhA]].
- [[talent:126307]]
  
  - Generates 2 Chi with [[talent:124815]].[[talent:124829]]
- [[talent:124829]]
  
  - Generate 1 Chi after consuming a [[spell:116768]] proc.
- [[talent:124823]]
  
  - During [[talent:124826]] your [[spell:100784]] generates 1 Chi.

#### Class Tree

- [[talent:124956]]
  
  - Activating [[talent:124826]] unleashes a strong [[talent:124817@FAQABdhA]] around you.
- [[talent:124975]]
  
  - Reduces the cooldown of [[spell:322111]] by 90 seconds.

##### Hero Talents

- [[talent:125068]]
  
  - Your default pick since [[talent:125067]] is weaker.
- [[talent:125076]]
  
  - Personal preference but most likely the better choice than [[talent:125075]].
- [[talent:125065]]
  
  - Your default pick, but you can take [[talent:125064]] as well.




### [[talent:125027]] AoE

:::talents [[talent:125046]] **Windwalker Monk** AoE talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

#### When to use this Spec

Use this spec if you're fighting 4 or more enemies for an extended period of the fight.

##### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added**
  
  - [[talent:134452]]
  - [[talent:124836]]
  - [[talent:128711]]
  - [[talent:124824]]
- **Removed**
  
  - [[talent:124825]]
  - [[talent:125019]]
  - [[talent:125014]]
  - [[talent:124823]]

##### Hero Talents

- [[talent:125068]]
  
  - Your default pick since [[talent:125067]] is weaker.
- [[talent:125076]]
  
  - Personal preference but most likely the better choice than [[talent:125075]].
- [[talent:125065]]
  
  - Your default pick, but you can take [[talent:125064]] as well.




### [[talent:125047]] Single-Target

:::talents [[talent:125047]] **Windwalker Monk** single target talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYM2GGsMzMbzAAAAAAAAAAAAsMMTYGwAMzwMzMDzywMMLzEAwiZ2GzYmZmBAwiZZZ2GTQAAYAMDwYbAjZmZzH",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYM2GGsMzMbzAAAAAAAAAAAAsMMTYGwAMzwMzMDzywMMLzEAwiZ2GzYmZmBAwiZZZ2GTQAAYAMDwYbAjZmZzH"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:125009]]
  
  - [[talent:134452]] and [[talent:125014]] grants you a guaranteed [[spell:116768]] proc.
- [[talent:124825]]
  
  - The duration of [[talent:124826]] is increased by 5 seconds.
- [[talent:124810]]
  
  - You have a chance to restore 1 Chi with [[talent:124985@FAgATZfABdhA]].
- [[talent:126307]]
  
  - Generates 2 Chi with [[talent:124815]].
- [[talent:124829]]
  
  - Generate 1 Chi after consuming a [[spell:116768]] proc.

##### Class Tree

- [[talent:124956]]
  
  - Activating [[talent:124826]] unleashes a strong [[talent:124817@FAQABdhA]] around you.
- [[talent:124975]]
  
  - Reduces the cooldown of [[spell:322111]] by 90 seconds.

##### Hero Talents

- [[talent:125054@AJgCCA]] 
  
  - Your default choice as it is stronger than [[talent:125053]].
- [[talent:136744]]
  
  - Depending on fight duration and your trinkets [[talent:136760@FJQAfGPBKIA]] might be better.
- [[talent:125057]]
  
  - Personal preference if you prefer [[talent:125056]].




### [[talent:125047]] AoE

:::talents [[talent:125047]] **Windwalker Monk** AoE talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmthZYWegJAgFmtxMGzMDAgFzyysNmmtZpZmZWAmxAzMzAMWGAzMzmB"
}
```
:::

#### When to use this Spec

Use this spec if you're fighting 4 or more enemies for an extended period of the fight.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added**
  
  - [[talent:134452]]
  - [[talent:128711]]
  - [[talent:124836]]
  - [[talent:124824]]
- **Removed**
  
  - [[talent:125014]]
  - [[talent:125021]]
  - [[talent:125019]]
  - [[talent:124825]]

#### Hero Talents

- [[talent:125054@AJgCCA]] 
  
  - Your default choice as it is stronger than [[talent:125053]].
- [[talent:136744]]
  
  - Depending on fight duration and your trinkets [[talent:136760@FJQAfGPBKIA]] might be better.
- [[talent:125057]]
  
  - Personal preference if you prefer [[talent:125056]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:125026]] strikes an additional time at the start of its channel at 50% effectiveness.
- **4-Set: ‍** [[talent:125026]] increases the damage of your next ‍[[talent:124985@FAgATZfABdhA]] by 10% or ‍[[spell:101546]] by 20% each time it strikes, stacking up to 6 times.

### Single-Target



#### [[talent:125046]]

##### Opener

- Your goal is to cast as many Chi spenders as possible in your [[talent:124826]] window while also keeping relevant abilities on cooldown.

:::rotation **Windwalker Monk** single-target opener in Raids
```json
{
  "source_code": "IEYAssgQsmYAAAAAAIEpjmACUV4kSAAALkmZgQXYsVmb0VGZCEAiuOQBjgQWRMRHpgwF_XgNpAAEAIE-7GQBpgwbSJgPbAgPnBAH4vbAAAAAAIE"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:1217413]] if talented [[item:241288]] · [[spell:1249625]]
4. [[spell:107428]]
5. [[spell:392983]] if talented
6. [[spell:113656]]
7. [[spell:152175]] if talented
8. [[spell:100780]]
9. [[spell:107428]]
10. [[spell:113656]]
11.
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. [[spell:322109]] if possible.
2. [[spell:107428]] when buffed by [[spell:337481]].
3. [[spell:100780]] if below 5 Chi and close to capping Energy.
4. [[talent:125014]]
5. [[talent:126307]].
6. [[spell:101546]] with 2 stacks of [[spell:286585]].
7. [[talent:134452]] if possible.
8. [[spell:107428]].
9. [[spell:100780]] if you are capping energy.
10. [[spell:113656]].
11. [[spell:100784]] to not overcap on stacks of [[spell:116645]].
12. [[spell:101546]] with [[spell:286585]].
13. [[spell:100780]].
14. [[spell:100784]].




#### [[talent:125047]]

##### Opener

- Your goal is to cast as many Chi spenders as possible in your [[talent:124826]] window while also keeping relevant abilities on cooldown.

:::rotation **Windwalker Monk** single-target opener in Raids
```json
{
  "source_code": "IkZAs4gQsmYAAAAAAIEpjmAC0BCnGAAALkmZgQXYsVmb0VGZAI0ePUAAAAgABgorDUwKIkVET0RMIcx_F4TMAQA-7mATI8mUC4zGAExZIQpwGUATRAREzwBAAAAAAAAACB"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:433184]] if talented
4. [[spell:331643]]  [[item:241288]] · [[spell:1249625]]
5. [[spell:107428]]
6. [[spell:392983]] if talented
7. [[spell:113656]]
8. [[spell:152175]] if talented
9. [[spell:107428]]
10. [[spell:443028]]
11. [[spell:107428]]
12. [[spell:113656]]
13. 
14.
:::

1. [[spell:322109]] if possible.
2. [[talent:125014]].
3. [[talent:134452]] if possible.
4. [[talent:126307]].
5. [[talent:125062@AJgCCA]].
6. [[spell:107428]] when buffed by [[spell:337481]].
7. [[spell:100780]] if below 5 Chi and close to capping Energy.
8. [[spell:113656]].
9. [[spell:107428]].
10. [[spell:101546]] with 2 stacks of [[spell:286585]].
11. [[spell:100784]] to not overcap on stacks of [[spell:116645]].
12. [[spell:101546]] with 1 stack of [[spell:286585]].
13. [[spell:100784]].





### AoE



#### [[talent:125046]]

##### Opener

- Below you can see one variation of the multi-target opener rotation using the [[talent:125046]].

:::rotation **Windwalker Monk** AoE opener in Raids
```json
{
  "source_code": "IEYAssgQsmYAAAAAAIEpjmACUV4kSAAALkmZgQXYsVmb0VGZCEAiuOQBjgQWRMRHpgwF_XgNpAAEAIE-7GQBpgwbSJgPbAgPnBAH4vbAAAAAAIE"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:1217413]] if talented [[item:241288]] · [[spell:1249625]]
4. [[spell:107428]]
5. [[spell:392983]] if talented
6. [[spell:113656]]
7. [[spell:152175]] if talented
8. [[spell:100780]]
9. [[spell:107428]]
10. [[spell:113656]]
11.
:::

##### Priority List

1. [[spell:100780]] if below 5 Chi and close to capping Energy.
2. [[spell:322109]] if possible.
3. [[spell:101546]] with [[spell:286585]] with 2 stacks to not overcap.
4. [[talent:134452]].
5. [[talent:125014]].
6. [[spell:113656]].
7. [[spell:107428]] to enable [[talent:134452]].
8. [[spell:101546]].
9. [[spell:100784]] to not overcap on stacks of [[spell:116645]].




#### [[talent:125047]]

##### Opener

- Below you can see one variation of the multi-target opener rotation using the [[talent:125047]].

:::rotation **Windwalker Monk** AoE opener in Raids
```json
{
  "source_code": "IkZAs4gQsmYAAAAAAIEpjmAC0BCnGAAALkmZgQXYsVmb0VGZAI0ePUAAAAgABgorDUwKIkVET0RMIcx_F4TMAQA-7mATI8mUC4zGAExZIQpwGUATRAREzwBAAAAAAAAACB"
}
```
1. [[spell:100780]]
2. [[spell:107428]]
3. [[spell:433184]] if talented
4. [[spell:331643]]  [[item:241288]] · [[spell:1249625]]
5. [[spell:107428]]
6. [[spell:392983]] if talented
7. [[spell:113656]]
8. [[spell:152175]] if talented
9. [[spell:107428]]
10. [[spell:443028]]
11. [[spell:107428]]
12. [[spell:113656]]
13. 
14.
:::

1. [[spell:322109]] if possible.
2. [[talent:125014]].
3. [[talent:126307]].
4. [[talent:136745@AJgCCA]].
5. [[spell:100780]] if below 5 Chi and close to capping Energy.
6. [[spell:101546]] with 2 stacks of [[spell:286585]].
7. [[talent:134452]] if possible.
8. [[spell:113656]].
9. [[spell:107428]] to enable [[talent:134452]].
10. [[spell:101546]] with 1 stack of [[spell:286585]].
11. [[spell:101546]].





## Deep Dive

### Mastery

- It is very important to never break your [[spell:115636]] or [[spell:196740]].
- During downtime you can use [[spell:101546]] to keep up your [[spell:196740]].
- If the boss is immune to damage you can also use [[spell:117952]] to keep it up.

### Touch of Karma

- To maximize your damage output you want to press [[spell:122470]] on every damage event possible in the fight.
- You can increase the absorbed amount of your [[spell:122470]] damage by using [[spell:243435]] beforehand to increase your maximum health.
- When grouped with a **Warrior**, you can ask them to press [[spell:97462]] if it is not needed as a cooldown to get even more health before using [[spell:122470]].

### Two-handed weapon versus one-handed weapons

- Two-handed weapons outperform one-handed due to [[talent:124828]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Windwalker Monk** Nek'Zali talents in Raid
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

#### Offensive Cooldown Usage

- If your raid is struggling to kill the **Restless Amani**, hold your [[talent:124826]] for it.

#### Boss Tips

- Use a defensive after getting targeted by [[spell:1287322]], and go to the edge of the room to drop a puddle.
- Keep the **Restless Amani** away from the middle with [[spell:119381]] and [[talent:124926]].
- During [[spell:1284103]], make sure you are behind the boss, so you do not soak the spirits on accident.




### Entombed Sentinels

:::talents Windwalker Monk Entombed Sentinels talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

#### Offensive Cooldown Usage

- If your raid is struggling with a particular add spawn hold one of your [[talent:124826]] charges for them.

#### Boss Tips

- Soak the [[spell:1288232]] when you are on **Blood of Ula'teks** side.
- If you are on **Breath of Ula'teks** side, instantly swap to **Venom Coagulation** as it spawns.
- Soak the [[spell:1284434]] on the floor.




### Lost Explorers

:::talents **Windwalker Monk** Lost Explorers talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

#### Offensive Cooldown Usage

- Always use your [[talent:124826]], so you maximize your cleave value.

#### Boss Tips

- [[spell:1291759]] targets melee players, try to be towards the edge of the room.
- If you find the [[spell:1292490]] cast it on a boss that did not eat a fish yet.
- Soak the [[spell:1291933]] on the ground.
- Interrupt [[spell:1286921]] from **Scrollsage Iku**.




### Vashnik

:::talents **Windwalker Monk** Vashnik talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

#### 

- You can hold your [[talent:124826]] for a specific addspawn your raid is struggling with.

#### Boss Tips

- Do not hit anyone with [[spell:1281907]].
- There are 3 adds that you have to kill, the **Clotting Venom**, **Shrouded Venom** and **Burning Venom** before they reach the middle.
  
  - The **Burning Venom** applies a dot after dying that stacks.
    
    - Kill them one at a time.
  - **Clotting Venom** is immune to crowd control.
  - You can crowd control the **Shrouded Venom** and the **Burning Venom** with [[talent:124926]] and [[spell:119381]].




### Sszorak

:::talents **Windwalker Monk** Sszorak talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLPwEAwiZ2mZYmZmBAwGAaWmlmZmZBADMzAwYZAMgP",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLPwEAwiZ2mZYmZmBAwGAaWmlmZmZBADMzAwYZAMgP"
}
```
:::

#### Offensive Cooldown Usage

- Hold a charge of [[talent:124826]] for [[spell:1286033]]

#### Boss Tips

- You can dispel anyone that got hit by [[spell:1287072]] with [[talent:124941]].
- Put down a [[talent:124962]] in the middle of the room, incase you need it for the [[spell:1285419]].
- Use a defensive during [[spell:1285419]].




### Twin Fangs

:::talents **Windwalker Monk** The Twin Fangs talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::

#### Offensive Cooldown Usage

- You can hold your [[talent:124826]] for the **Spawn of Vexhul**.

#### Boss Tips

- Kill the **Spawn of Vexhul** as fast as possible.
- Track your stacks of [[spell:1290336]] do not try to get too many stacks.
- Soak the [[spell:452818]] on the ground.
- Soak the [[spell:1290505]] to remove a stack of [[spell:1290336]].




### Coiled Altar

:::talents **Windwalker Monk** Coiled Altar talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

#### Offensive Cooldown Usage

- Keep a charge of [[talent:124826]] for [[spell:1304033]].

#### Boss Tips

- Move the [[spell:1282403]], so your tank can easily cleave them.
- Soak the [[spell:1283485]].
- It is extremely important to watch out for the **Manifestation of Dreads**.
  
  - If you get targeted by a  **Manifestation of Dread** kite them close to each other so your tank can easily cleave them with [[spell:1308809]].
- Use a defensive when targeted by [[spell:1286895]].
  
  - You also need to soak your souls before [[spell:1286837]] expires.
- Use a defensive during [[spell:1287685]].
- Interrupt the [[spell:1286399]] from the **Spiteful Soulcoilers.**




### Ula'tek

:::talents **Windwalker Monk** Ula'tek talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYAMYbmx2MGAAAAAAAAAAAYZY0MmBMgZMMzMzwsNMDzyMBAsYmtZmxMzMDAgNA0sMLNzMzCwwAzMAMWGADYA"
}
```
:::




### Nymrissa Wavecaller

:::talents **Windwalker Monk** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B",
  "code": "C2QAI2iUD8dsJPIMmzPPH0Bl8NzYw2wMsMzYbGDAAAAAAAAAAAsMMaGzAGwMGmZmZY2GmhZZmAAWMz2MDzMzMAA2AQzys0MzMLAYgZGAGLDgB8B"
}
```
:::

#### Offensive Cooldown Usage

- You can always use [[talent:124826]] on a difficult addspawn.

#### Boss Tips

- Kill the **Bubblefin Shoerunners** and the **Bubblefin Berserkers** before they reach the middle.
- [[spell:1266340]] knocks you from the middle of the room.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Windwalker Monk**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Windwalker Monk** Stat Priorities in Raid
```json
{
  "source_code": "IoAJFMAJxACKBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 精通 ＞ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271519@DCTAA0QANk7cVrDf1IYNXYjt1ghNCKAWBA]] | Ula'tek |
| Neck | [[item:268265@BkSAA0QA8z6wPrDj1QWNYYjX1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271517@BASAA0QA-VTg1ghNCKgTBA]] | The lost explorers/Catalyst |
| Cloak | [[item:268253@BgQAA0QACKAWBA]] | The Coiled Altar |
| Chest | [[item:271522@DASAA0QAJk7oXNCWDG2IoAOF]] | Vashnik the Malignant/Catalyst |
| Wrist | [[item:244576@BiUAA0QA8z6Y7LjVT0wcbN2UjexYlIOSDAjsUA]] | Leatherworking |
| Gloves | [[item:251124@BgRAA0QA2IjX1caJOFA]] | Murder Row |
| Belt | [[item:268256@BCSAA0QA8z6ghNeVjt1IoAYF]] | The Coiled Altar |
| Legs | [[item:271518@DASAA0QAhu70XNCWDG2IoAYF]] | Sszorak/Catalyst |
| Boots | [[item:159327@DgQAA0QApk7IoAOF]] | Temple of Sethraliss |
| Ring 1 | [[item:251513@DiRAA0QA1j7wPrDAjY7L3WzSBA]] | Jewelcrafting |
| Ring 2 | [[item:252258@DCSAA0QA1j7wPrDZ1YjMeVjlo4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270175@BgRAA0QAYYjX1kjAYFA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgRAA0QAYYjX1IoAYFA]] | The Coiled Altar |
| Mainhand | [[item:268215@DARAA0QA_k7YhNCKAWB]] | Ula'tek |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@BgQAA0QACKQQBA]] | Murder Row |
| Neck | [[item:251173@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAA0QACKQQBA]] | Voidcar Arena |
| Cloak | [[item:251132@BgQAA0QACKQQBA]] | Murder Row |
| Chest | [[item:251159@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:251135@BgQAA0QACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgRAA0QA2IjX1caJBFA]] | Murder Row |
| Belt | [[item:159317@BgQAA0QACKQQBA]] | Temple of Sethraliss |
| Legs | [[item:251130@BgQAA0QACKQQBA]] | Murder Row |
| Boots | [[item:159327@DgQAA0QApk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:273792@BgQAA0QACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:252258@BASAA0QAkVjNy4VNWiSQBA]] | Voidscar Arena |
| Trinket 1 | [[item:250215@BgQAA0QACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAA0QACKQQBA]] | The Blinding Vale |
| Mainhand | [[item:273783@BgQAA0QACKQQBA]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgRAA0QAYYjX1kjAYFA]]  <br>[[item:270173@BgRAA0QAYYjX1IoAYFA]] |
| **A-Tier** | [[item:270164@BgQAA0QACKgTBA]]  <br>[[item:270168@BgQAA0QACKAWBA]] -- Useful on demand burst siuations.  <br>[[item:270165@BgQAA0QACKgTBA]] |
| **B-Tier** | [[item:270166@BgQAA0QACKgTBA]]  <br>[[item:250215@BgQAA0QACKgTBA]]  <br>[[item:250259@BgQAA0QACKgTBA]] |
| **C-Tier** | [[item:250214@BgQAA0QACKgTBA]]  <br>[[item:250228@BgQAA0QACKgTBA]] |
| **Junkyard** | [[item:250225@BgQAA0QACKgTBA]]  <br>[[item:273796@BgQAA0QACKgTBA]] |

### Embellishments

> Everything in this section is subject to change, so check back before you do any important craft using Sparks to see if this text is removed.

- 1x [[item:251513@DiRAA0QAvk7oPrDAjMWNFITHBA]]
  
  - This embellishment is a unique ring.
- 1x [[item:240167@BAAAA0QA]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 1x [[item:245875]]
  
  - This embellishment can only be applied to weapons.
- 1x [[item:240167@BAAAA0QA]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]] *-- maximum DPS.*
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]*--  default pick.*
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  - [[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].*
    
    - [[item:240892]]
    - [[item:240908]]
    - [[item:240918]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAA0QA]]  <br>[[item:243951@BAAAA0QA]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAA0QA]] |
| Waist | [[item:275707@BAAAA0QA]] |
| Legs | [[item:244641]] |
| Boots | [[item:243953]] |
| Ring 1 | [[item:243957@BAAAA0QA]] |
| Ring 2 | [[item:243957@BAAAA0QA]] |
| Mainhand | [[item:244031]] |

:::

:::column
:::gear **Windwalker Monk** Enchantments in Raids
```json
{
  "source_code": "IQFZNEQ9NCQA7TDBQAAAAgF3SEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[spell:1236056]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAA0QA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Windwalker Monk** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Your strongest DPS racial but lines up poorly with [[talent:125013]].
  - Reduce the duration of movement-impairing effects by 20%. This was only useful once in the recent history of progression raiding but is still worth noting.
- [[spell:33702]] *-- Orc* 
  
  - Strong racial for damage both because of [[spell:21563]] and [[spell:33702]] which lines up with [[talent:125013]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the latest Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Windwalker Monks** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**Cursor [[spell:116844]] -- *[[spell:116844]]* *on your cursor without confirmation.***

```wow-macro
#showtooltip
/cast [@cursor] Ring of Peace
```

:::

:::details Mouseover Macros
**[[spell:116670]] Mouseover -- *Casts [[spell:116670]] on your mouseover.***

```wow-macro
#showtooltip
/cast [@mouseover,help] Vivify
```

**Mouseover [[spell:116841]] -- *Casts[[spell:116841]] on your mouseover*.**

```wow-macro
#showtooltip
/cast [@mouseover,help] Tiger's Lust
```

**[[talent:124941]] -- *Casts [[talent:124941]] on your mouseover target if it exists.***

```wow-macro
#showtooltip Detox
/cast [@mouseover,help,nodead] Detox;Detox
```

:::

:::details Pet Macros
**Pet Dismiss Macro - *Removes [[talent:125013]].***

```wow-macro
/petdismiss
```

:::

:::details Utility Macros
**/stopmacro [channeling:Fists of Fury] --  *makes sure your [[spell:113656]]* is not getting canceled while spamming [[spell:100780]] ( You can replace  [[spell:100780]] with any other ability you want to spam).**

```wow-macro
#showtooltip Tiger Palm
/stopmacro [channeling:Fists of Fury]
/cast Tiger Palm
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Windwalker Monk**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/swaguimidnight-1-1024x608.png>)

**Windwalker Monk** Interface in Raids

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for custom scripting.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- MONK
  
  - Chi Transfer now causes Touch of Death to heal you for 60% of damage it deals (was 50%).
  - Vigorous Expulsion increases Expel Harm's healing by 6% (was 5%).
  - Silent Sanctuary healing increased by 25%.
- Windwalker
  
  - Developers' notes: We are making a few adjustments to Windwalker's damage profile to reduce the gap between their steady-state damage and high-end burst capabilities.
  - Dance of the Wind has been updated – Your physical damage taken is reduced by 10% and an additional 10% every 4 seconds until you receive a physical attack, stacking up to 4.
  - Melee auto-attack damage increased by 30%.
  - Zenith Stomp damage reduced by 30%.
  - Blackout Kick damage increased by 50%.
  - Tiger Palm damage increased by 200%.
  - Dual Threat damage increased by 30%.
  - Spinning Crane Kick damage decreased by 12%.
  - Whirling Dragon Punch area of effect damage increased by 30%.
  - Jade Ignition damage increased by 50%.
  - Weapon of Wind now increases damage during Zenith by 5% (was 10%).
  - Apex Talent: Tigereye Brew (Rank 2) now increases Critical Strike damage by 5%/10% (was 10%/20%).
  - Vivify healing increased by 25%.
  - Expel Harm healing increased by 25%.
  - Combat Wisdom now increases Stamina by 5%.
  - Calming Presence now reduces damage taken by 10% (was 6%).
- Hero Talents
  
  - Conduit of the Celestials
    
    - Celestial Conduit damage reduced by 25%.
    - Temple Training increases the damage of Fists of Fury and Spinning Crane Kick by 30% (was 10%).

:::

:::

:::accordion
:::details Patch 12.0.5
- MONK
  
  - Windwalker 
    
    - Crashing Fists has been redesigned – Fists of Fury damage is increased by 20% (was extends duration by 1 second).
    - Tigereye Brew (Rank 1) has been redesigned – Every 3 Chi spent generates Tigereye Brew. Zenith consumes up to 20 Tigereye Brew stacks to increase your critical strike chance for its duration by 1% per stack. Generates quickly up to 10 stacks while out of combat and may generate up a maximum of 30 stacks.
    - Tigereye Brew (Rank 3) has been redesigned – Zenith now grants access to 2 additional Zenith Stomps.
    - Xuen's Battlegear may now additionally trigger from Spinning Crane Kick, reducing the cooldown of Fists of Fury by 0.5 seconds for each unique target struck, up to 2.5 seconds.
    - Zenith Stomp now generates 2 Chi.
    - Zenith no longer generates 2 Chi on cast.

:::

:::

:::accordion
:::details Patch 12.0.1
- MONK
  
  - Windwalker 
    
    - *Developers' notes: These changes are aimed at underperforming and overperforming talents, increasing Windwalker’s AoE damage, tweaking Rising Sun Kick’s damage contribution in single target versus Fists of Fury, and adjusting its chi economy in a few ways to be a smoother experience.*
    - Rising Sun Kick damage increased by 20%.
    - Spinning Crane Kick damage increased by 50%.
    - Jadefire Stomp damage increased by 25%.
    - Flurry of Xuen damage increased by 40%.
    - Fists of Fury damage decreased by 10%.
    - Airborne Rhythm now generates 1 Chi (was 2 Chi).
    - Rushing Wind Kick no longer has a Chi cost.
    - Sunfire Spiral now increases Mastery: Combo Strikes by 40% (was 20%).
    - Universal Energy increases magical damage done by 8% (was 15%).
    - Memory of the Monastery now increases Combo Breaker's effect chance by 75% (was 25%) and increases Tiger Palm's damage by 30% (was 15%).
    - Communion with Wind increases the damage of Strike of the Windlord and Whirling Dragon Punch by 20% (was 10%).
    - Tigereye Brew now only reduces its stacks down to 10 while out of combat in a raid instance and now grants 10 stacks or reduces stacks down to 10 at encounter start and Mythic+ start.
    - Threat generated by Zenith Stomp reduced by 50%.
    - Vivify Healing increased by 100%.
    - Vivify Healing is reduced by 33% in PvP combat (was 66%).
    - Expel Harm healing increased by 30%.

:::

:::

:::accordion
:::details Patch 12.0
- MONK
  
  - Spear Hand Strike interrupt duration increased to 5 seconds (was 3 seconds). Does not affect PvP combat.
- **Hero Talents**
  
  - Conduit of the Celestials New Talent: Path of the Falling Star – Celestial Conduit's damage is increased by 100% when striking a single target. Each additional target reduces this bonus by 20%.
  - Yu'lon's Knowledge has been redesigned – Now increases the damage of Rising Sun Kick by 15%.
  - Heart of the Jade Serpent no longer decreases the cooldown time of Flying Serpent Kick.
  - Celestial Conduit no longer splits its damage and now deals reduced damage beyond 5 targets.
  - Flight of the Red Crane has been removed.
- **Windwalker** 
  
  - Invoke Xuen, the White Tiger and Xuen's Bond moved from the Windwalker talent tree to Conduit of the Celestials hero talent tree.
  - Celestial Conduit damage reduced by 75% and healing reduced by 80%.
  - Celestial Conduit now overrides Xuen, the White Tiger when Xuen is cast.
  - Celestial Conduit has moved locations in the hero talent tree.
- **Master of Harmony**
  
  - New Talent: Harmonic Surge – Casting Thunder Focus Tea, Celestial Brew, or Celestial Infusion guarantees that your next 2 casts of Tiger Palm or Vivify will cause a Harmonic Surge, dealing Nature damage split between your target and other nearby enemies, and healing up to 5 injured allies.
  - New Talent: Potential Energy – Casting Keg Smash, Rising Sun Kick, or Rushing Wind Kick causes your next Tiger Palm or Vivify to release a Harmonic Surge.
  - Clarity of Purpose has been updated – Casting Enveloping Mist stores additional vitality (was Vivify or Sheilun's Gift).
- **Shado-Pan**
  
  - New Talent: Shado Over the Battlefield – Flurry Strikes deal Nature damage to all enemies within 6 yards, reduced beyond 8 targets.
  - New Talent: Stand Ready Brewmaster: Activating Invoke Niuzao, the Black Ox instantly grants 10 stacks of Flurry Strikes that trigger on your next attack at 70% effectiveness.
  - Windwalker: Activating Zenith instantly grants 10 stacks of Flurry Strikes that trigger on your next attack at 70% effectiveness.
  - New Talent: Weapons of the Wall Brewmaster: Invoke Niuzao, the Black Ox's stomp damage increased by 20%.
  - Windwalker: Zenith Stomp damage increased by 20%.
  - New Talent: Initiator's Edge – Movement speed is increased by 50% for the first 8 seconds of combat.
  - New Talent: Combat Stance – Roll's cooldown is reduced by 10%.
  - Flurry Strikes has been redesigned – Brewmaster: Your auto attacks have a chance to generate 1-2 Flurry Charges. When you cast Keg Smash, unleash all Flurry Charges, dealing Physical damage per charge.
  - Windwalker: Your auto attacks have a chance to generate 1-2 Flurry Charges. When you cast Fists of Fury, unleash all Flurry Charges, dealing Physical damage per charge.
  - Wisdom of the Wall has been redesigned – Brewmaster: Invoke Niuzao, the Black Ox causes Breath of Fire to launch 3 Flurry Strikes.
  - Windwalker: Zenith causes Rising Sun Kick and Spinning Crane Kick to launch 3 Flurry Strikes.
  - Veteran's Eye has been redesigned – Haste increased by 5%.
  - Against All Odds has been redesigned – Your Agility is increased by 4%.
  - Vigilant Watch no longer increases the damage of your next Flurry Strikes.
  - One Versus Many has been redesigned – Now causes auto attack critical strikes to grant double Flurry Charge stacks.
  - Efficient Training has been updated – Brewmaster: Now decreases the cooldown of Invoke Niuzao, the Black Ox by 25 seconds.
  - Windwalker: Now decreases the cooldown of Zenith by 10 seconds.
- Class
  
  - New Talent: Silent Sanctuary – While no enemies are within 15 yards, you heal every 3 seconds.
  - New Talent: Stillstep Coil – Leg Sweep applies Disable for 5 seconds when it ends.
  - New Talent: Serene Surge – After casting Enveloping Mist, your next Sheilun's Gift or Vivify becomes instant cast.
  - New Talent: Reinvigoration – After Detox successfully removes an effect from an ally, their movement speed is increased by 30% for 5 seconds.
  - New Talent: Chi Transfer – Touch of Death now heals you for 50% of its damage done.
  - Save Them All has been redesigned – Now increases your healing by up to 10% based on your target's health. Lower health allies are healed for more.
  - Diffuse Magic has been redesigned – Now causes activating Fortifying Brew to transfer all currently active harmful magical effects on you back to their original caster if possible.
  - Soothing Mist healing increased by 50%.
  - Vivacious Vivification no longer increases the healing of Vivify.
  - Fatal Touch no longer increases damage dealt.
  - Ferocity of Xuen is now a 2-point talent.
  - The following talents have been removed: Bounce Back
  - Chi Burst *(removed for Mistweaver and Windwalker only)*
  - Clash
  - Profound Rebuttal *(removed for Mistweaver only)*
  - Rising Sun Kick *(removed for Brewmaster only)*
  - Spear Hand Strike *(removed for Mistweaver only)*
  - Strength of Spirit *(removed for Mistweaver only)*
  - Vigorous Expulsion *(removed for Mistweaver only)*
- Windwalker
  
  - New Talent: Airborne Rhythm – Slicing Winds now generates 2 Chi when cast.
  - New Talent: Hurricane's Vault – Slicing Winds now costs 2 Chi to cast, but its damage is increased by 40%.
  - New Talent: Sharp Reflexes – Blackout Kick reduces the cooldown of Rising Sun Kick and Fists of Fury by 1 second.
  - New Talent: Crashing Fists – The duration of Fists of Fury is increased by 1 second.
  - New Talent: Combo Breaker – You have a 8% chance when you Tiger Palm to cause your next Blackout Kick to cost no Chi within 15 seconds.
  - New Talent: Zenith – Chi costs are reduced by 1, and Blackout Kick reduces the cooldown of affected abilities by an additional 1 second. Activating Zenith resets the remaining cooldown on Rising Sun Kick and grants 2 Chi.
  - New Talent: Harmonic Combo – Fists of Fury's Chi cost is reduced by 1, but its damage is reduced by 10%.
  - New Talent: Skyfire Heel – Rising Sun Kick's critical strike chance is increased by 4% for each nearby enemy, up to 5 enemies. 10% of Rising Sun Kick's damage splashes onto nearby enemies. Damage is reduced beyond 5 targets.
  - New Talent: Cyclone's Drift – You gain 10% more Haste from all sources.
  - New Talent: Echo Technique – Casting Strike of the Windlord and Whirling Dragon Punch grants Blackout Kick!.
  - New Talent: Obsidian Spiral – During Weapons of Order, Blackout Kick generates 1 Chi.
  - New Talent: Sunfire Spiral – Rising Sun Kick gains 20% additional effectiveness from Mastery: Combo Strikes.
  - New Talent: Weapon of Wind – Your damage during Zenith is increased by 10%.
  - New Talent: Martial Agility – Your melee attack speed is increased by 30%. This bonus is increased to 60% during Zenith.
  - New Talent: Tiger Fang – Your auto attack critical strike chance is increased by 15%.
  - New Talent: Zenith Stomp – Activating Zenith causes you to release a powerful stomp, dealing significant Nature damage to nearby enemies, reduced beyond 5 targets.
  - New Talent: Universal Energy – Magical damage increased by 15%.
  - New Talent: Rushing Wind Kick – After consuming Blackout Kick!, Rising Sun Kick has a 40% chance to become Rushing Wind Kick. Rushing Wind Kick: Kick up a powerful gust of wind, dealing Nature damage in a 25 yard cone to enemies in front of you, split evenly among them. Damage is increased by 6% for each target hit, up to 30%.
  - Dual Threat has been redesigned – Now has a 30% chance to kick your target and damage increased by 300%, but no longer increases damage by 5% for 5 seconds when activated.
  - Drinking Horn Cover has been redesigned – Now increases the duration of Weapons of Order by 5 seconds.
  - Spiritual Focus has been redesigned – Now decreases the cooldown of Weapons of Order by 20 seconds.
  - Xuen's Battlegear has been redesigned – Now increases the critical strike rate of Rising Sun Kick by 20% and decreases the cooldown of Fists of Fury by 4 seconds when Rising Sun Kick critically strikes.
  - Meridian Strikes has been redesigned – Now decreases the cooldown of Touch of Death by 45 seconds and increases Touch of Death's damage by 15%.
  - Jade Ignition has been redesigned – No longer stacks an aura to increase Chi Explosion's damage.
  - Auto-attack damage increased by 200%.
  - All spell and ability damage reduced by 13%.
  - Spinning Crane Kick damage increased 80%.
  - Crane Vortex now increases the damage of Spinning Crane Kick by 15% (was 30%).
  - Dance of Chi-Ji no longer increases the damage of Spinning Crane Kick.
  - Dance of Chi-Ji activation chance reduced by 33%.
  - Fists of Fury damage increased 30%.
  - Rising Sun Kick damage increased 30%.
  - Blackout Kick damage increased by 300%.
  - Slicing Winds damage reduced by 50%.
  - Jadefire Stomp now increases movement speed for 3 seconds after casting.
  - Singularly Focused Jade now increases Jadefire Stomp's damage by 300% (was 500%).
  - Touch of the Tiger now increases the damage of Tiger Palm by 15% (was 40%).
  - Jadefire Fists now triggers after every Fists of Fury cast.
  - Thunderfist, Revolving Whirl, and Knowledge of the Broken Temple now triggers from both Whirling Dragon Punch and Strike of the Windlord.
  - Communion of Wind now reduces the cooldown of Strike of the Windlord and Whirling Dragon Punch by 5 seconds and increases their damage by 20%.
  - Whirling Dragon Punch cooldown is now 35 seconds and no longer scales with Haste.
  - Teachings of the Monastery Blackout Kicks are now cast at 25% effectiveness.
  - Memory of the Monastery no longer increases Haste and instead increases the damage of Tiger Palm.
  - Combat Wisdom no longer increases the damage of Tiger Palm.
  - Mastery: Combo Strikes now displays a tracking buff after each cast that displays your previously cast spell.
  - Ferociousness and Hardened Soles are now 2-point talents.
  - Combat Assistant's rotation has been updated.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Acclamation
    - Chi Wave
    - Courageous Impulse
    - Fury of Xuen
    - Gale Force
    - Invoke Xuen, the White Tiger *(moved to the Conduit of the Celestials hero talent tree)*
    - Invoker's Delight
    - Jadefire Harmony
    - Last Emperor's Capacitor
    - Martial Mixture
    - Ordered Elements
    - Rushing Jade Wind
    - Storm, Earth, and Fire
    - Summon White Tiger Statue
    - Transfer the Power
    - Xuen's Bond *(moved to the Conduit of the Celestials hero talent tree)*

:::

:::

## FAQ

:::accordion
:::details Q: Why does my [[spell:196740]] drop?
**A:** You are pressing the same ability twice in a row. Common scenarios where this can happen is if your [[spell:100780]] gets parried and you press two of them to gain Chi.

:::

:::

---

### Credits

Written By: **Swag**

Reviewed By: **Xerwo**

---

:::changelog 更新记录
**2026-08-07** Updated for patch 12.1

**2026-05-01** Updated for patch 12.0.5

**2026-02-24** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0.

**2025-12-03** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2

**2025-06-18** Updated for patch 11.1.7

**2025-04-22** Updated for patch 11.1.5

**2025-02-24** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-24** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
