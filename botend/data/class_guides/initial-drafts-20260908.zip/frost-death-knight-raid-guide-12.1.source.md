Welcome to the **Frost Death Knight** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single Target** · 3/5 · Average

AoE · 4/5 · Good

Utility · 3/5 · Fight Dependent

Survivability · 5/5 · Excellent

Mobility · 4/5 · Good



:::

:::

:::column
:::gear **Frost** **Death Knight** Best in Slot
```json
{
  "source_code": "J4oAgvPA3_fABIHJEIICFAwJ5OwVtOQOC4UAdV9ABk-FEAQEBAg-sOg-sOAj1kjAYFQAwRCBCgQBAcRuDEgJUI8FEEQdkUgEAkQASgCWB47FEEw4XQAgIUAOAljAYFQAGYCBCARAAE6uDYhNFEBGkfBBAgQAAEQQsFgChOAhIEAAaA8AiZ9A6z6A3WzSBEwckQAAIUQBhADvXQQAZfBBCCQAAUPuBECHOFQA5Z9ACiQEQUQME01HNIFDYFQAfFAD4MAA5IAWBUAAB0yFCEQ3XkhHgE7FEABCBAAYQXQIAFgqXQAEQEAAOLPAXYTOCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240890]] |
| 肩部 | [[item:271472]] | [[item:243991]] |
| 胸部 | [[item:271477]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240890]] |
| 腿部 | [[item:271878]] | [[item:244641]] |
| 脚部 | [[item:268260]] |  |
| 腕部 | [[item:237834]] | [[item:240890]] · [[item:245786]] · [[item:251490]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:268249]] | [[item:240890]] · [[item:243957]] |
| 戒指二 | [[item:251513]] | [[item:240890]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[spell:53344]] |
| 副手 | [[item:268202]] | [[spell:62158]] |
:::

:::

:::

## Midnight Changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As a **Frost Death Knight**, you have access to Chosen of Frostbrood which causes [[spell:279302]] to deal 100% increased damage and give you 15% Haste for 12 seconds.

**Rank 2** causes [[spell:279302]] to extend the duration of [[spell:51271]] by 2/4 seconds as well as increasing the amount of Strength [[talent:125875]] gives by 8%, up to a total of 18%.

**Rank 3** gives you a passive 10% Frost damage and buffs the damage of [[spell:279302]] by 100%. Additionally it gives you the ability to recall [[spell:279302]] at 50% of its effectiveness.

- For [[talent:123324]] Deathbringer this gives you a stack of [[spell:441416]].
- For [[talent:123322]]Rider of the Apocalypse it summons your Horsemen for 10 seconds.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-frostdk-mxr.webp>)

Chosen of Frostbrood

:::

:::

### Core Changes

Going into Midnight, **Frost Death Knight** received very few non-balance related changes due to a rework in patch 11.2 in The War Within. In this section, we go over the few changes you need to know about for **Frost**. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:96224]] has an additional effect which causes [[spell:1228433]] to consume [[spell:50401]] and deal an additional 300% damage to your target.
  - [[talent:125877]] now increases the duration of [[spell:51271]] by 1 second per auto attack crit, up to a max of 4 seconds.
- **Class Tree**
  
  - [[talent:136524]]
    
    - Removes the Runic Power cost from [[spell:61999]]!
  
  
  
  - [[talent:136525]]
    
    - A new talent to reduce the cooldown of [[talent:96204]] and increases the speed that the healing absorb gets removed.
  - [[talent:96187]]
    
    - [[spell:49039]] is no longer a defensive cooldown and only provides charm, fear, and sleep immunity as well as a small amount of Leech while it is active.
  - Various talents have been moved around, generally being easier to get.

## Hero Talents

- As a **Frost Death Knight** both hero talents are currently viable, allowing you to pick and choose based on the fight. [[talent:123322]]Rider of the Apocalypse is stronger on single-target focused fights while [[talent:123324]]Deathbringer is better on aoe centric fights.



### [[talent:123324]] Deathbringer

##### Offensive Nodes

- [[talent:117659]]
  
  - The explosion grants you 2 stacks of [[talent:117665]].
- [[talent:117633]]
  
  - Makes you deal up to 12% increased Shadowfrost damage to your main target, and up to 6% to additional enemies that it hits.
- [[spell:441894]]
  
  - [[talent:117665]] refreshes or applies [[spell:55095]] and makes it do its' damage faster. This is incredibly powerful in Single-Target and even stronger in AoE.
- [[talent:117640]]
  
  - [[spell:59052]] empowered [[spell:49184]] now deal 30% more damage to its main target.
- [[talent:117631]] vs [[talent:128235]]
  
  - [[talent:117631]] gives you a stack of [[spell:51128]] when you press [[talent:117659]] and increases the damage of [[talent:117659]] depending on your target's missing health
- [[talent:117658]]
  
  - When [[talent:117659]] explodes it deals damage to nearby enemies.
- [[talent:117629]]
  
  - A nice single target increase that grants you Strength if [[talent:117659]] explodes and does not hit any other targets with [[talent:117658]].
  
  
  
  - Increases [[talent:117633]] effectiveness by 100% on your main target, making it a 20% damage increase if both hits of [[talent:117633]] crit your target.
- [[talent:135992@AJgBBA]]
  
  - Increases the damage of [[spell:49143]] by 35% and [[spell:194913]] by 15%.
  - Grants you 3 stacks of [[spell:377098]] when you cast [[talent:117659]].
- [[spell:1265855@FJgDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBT3yEGEA]]
  
  - Increases the damage of [[talent:117659]] by 5%
  
  
  
  - Casting [[spell:279302]] gives you 2 stacks of [[talent:117665@FJQAm4rBGEA]].

##### Defensive Node

- [[talent:135993@AJgBBA]]
  
  - Increases the effectiveness of [[talent:96195]] by 50%.

##### Offensive Choice Node

- [[talent:117654]] vs [[talent:128266]]
  
  - [[talent:117654]] is always the winner here as extra stacks of [[spell:194878]] are quite good to allow for more [[spell:51124]] and [[spell:435010]] procs.
  - [[talent:128266]] has no synergy with the current talent builds that we play as it desyncs [[talent:117659]] from [[spell:51271]].

##### Defensive Choice Nodes

- [[talent:117632]] or [[talent:123420]]
  
  - [[talent:117632]] is not a good enough talent to consider as it puts up a random healing absorb which in some cases can be extremely detrimental. On the other side you have [[talent:123420]] which is incredibly strong as it is a passive damage reduction based on what abilities you use. During your cooldowns this is essentially a 10% magic and physical damage taken reduction as you are constantly refreshing them.
- [[talent:117646]] or [[talent:128234]]
  
  - [[talent:117646]] is the clear choice here as [[talent:128234]] does not work in PvE content on casts where it matters.




### [[talent:123322]]Rider of the Apocalypse

##### Offensive Nodes

- [[talent:117663]] - Each Rune spent gives you a 10% chance to summon one of the following Four Horsemen:
  
  - [[spell:444248]]
    
    - Puts up a [[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] that follows him for 10 seconds.
      
      - Standing in his ‍[[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] increases your damage and critical strike by 5%.
  - [[spell:444251]]
    
    - [[spell:444633]] is a disease with a 24 second duration that spreads and gains 1 stack every time you use [[spell:49020]] or [[spell:207230]] on the infected target.
  
  
  
  - [[spell:444254]]
    
    - Repeatedly casts [[spell:45524]] over his duration that gets shattered by [[spell:49020]] or [[spell:207230]] with [[talent:117660]].
  - [[spell:444252]]
    
    - Grants you 5% Strength, increasing by 1% for every Rune spent while Nazgrim is active.
- [[talent:117638]] 
  
  - Summons all 4 Horsemen for 20 seconds after casting [[talent:125876]].
    
    - If a Horsemen is already out, it extends the current duration by 20 seconds instead.
      
      - [[spell:444248]] does not recast his [[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] but all other Horsemen recast their abilities.
- [[talent:117641@FAQAuchA]]
  
  - Passively increases [[spell:55095]], [[spell:49143]], and [[spell:1228433]] damage.
- [[talent:117651]]
  
  - Increases [[spell:49020]] damage by 10% and increases the duration of [[spell:196770]] by 2 seconds.
- [[talent:135999@AJgBBA]]
  
  - [[spell:51271]] summons [[spell:444254]] for 6 seconds.
- [[talent:135998@AJgBBA]]
  
  - Casting [[spell:49143]] or [[spell:207230]] orders [[spell:444254]] to cast his [[spell:49143]] or [[spell:207230]] alongside you at 100% effectiveness while she is active.
  
  
  
  - If you played [[talent:123322]]Rider **Frost** in The War Within Season 3, this will be familiar as it was part of your set bonus.
- [[spell:1265971]]
  
  - Increases the damage of abilities cast by the Horsemen by 5%.

##### Offensive Choice Nodes

- [[talent:117639]] or [[talent:123411]]
  
  - [[talent:117639]] increases the duration of your Horsemen when spending Runic Power which has synergy with [[talent:135999@AJgBBA]] and [[talent:135998@AJgBBA]] but the build currently played has incredible synergy with [[talent:123411]] allowing for huge [[spell:49143]] and [[spell:1228433]] during your burst.

##### Defensive Choice Nodes

- [[talent:123412]] or [[talent:117657]]
  
  - [[talent:117657]] does not work at all in raids so you always choose [[talent:123412]] which is not a bad thing as this greatly increases your mobility and allows you to break roots and slows.
- [[talent:117634]] or [[talent:123410]]
  
  - [[talent:117634]] depends on the value of [[spell:48707]] during the fight as this can be incredibly potent allowing you to pre-immune debuffs or randomly absorb high amounts of magic damage. On the other hand, [[talent:123410]] grants you 5% damage reduction per Horsemen out or a 20% damage reduction during your cooldowns with [[talent:117638]]. Due to the situational value of both of these, there is no auto pick for this as it just depends on the fight.





## Talents



### [[talent:123322]]Rider   Pure Single-Target

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation and Deep Dive** sections below.

##### Spec Tree

- [[talent:125874]] and [[talent:126017]]
  
  - [[talent:125874]] is **Frost Death Knight's** major cooldown and when talented into [[talent:126017]] it activates (a free) [[spell:196770]].
    
    - Talenting into [[talent:126017]] removes your ability to cast [[spell:196770]] separately.
- [[talent:96220@FAQAhlvA]]
  
  - Allows you to gain a massive amount of [[spell:51128]] buffs during your [[talent:125874]], subsequently making it an incredibly high burst window as you can slam massive [[spell:51124]] empowered [[spell:49020]] constantly during [[talent:125874]].
- [[talent:96225]] and [[talent:133364]]
  
  - A [[spell:51128]] and Runic Power generator, with [[talent:133364]] reducing its cooldown by 6 seconds for every [[spell:59052]] consumed.
  - Makes your [[spell:49020]] free when cast during [[talent:125874]].
- [[talent:96254]]
  
  - Allows you to consume 2 stacks of [[spell:51124]] at once leading to considerably less wasting of procs.
- [[talent:96248]]
  
  - Sends out a [[spell:194913]] towards your facing that applies [[spell:50401]] to all enemies hit and refreshes [[talent:96214]].
- [[talent:96236]]
  
  - Required to interact with your Apex Talent Chosen of Frostbrood and summons the 4 horsemen when playing [[talent:123322]]Rider.

##### Class Tree

- [[talent:96174]]
  
  - Reduces the cooldown of [[spell:48707]] by 20 seconds and increases its duration and amount absorbed by 40%.
- [[talent:96194]] and [[talent:96176]]
  
  - Your raid cooldown that lasts for 6 seconds, reducing magic damage taken by anyone standing in it by 15%.
  
  
  
  - Talenting into [[spell:374383]] reduces the cooldown by 1 minute, down to 3 minutes, and increases the duration to 8 seconds.
- [[talent:126016]]
  
  - Reduces your magic damage taken by 5% and reduces the duration of harmful magic effects by 35%. While the reduced magic damage portion of [[talent:126016]] works against all magic damage, the reduced duration of harmful magic effects does not work on the vast majority of debuffs in the raid as that could simply break too many things.
- [[talent:126015]]
  
  - Gives you 1 extra charge of [[spell:48265]], [[spell:43265]], and [[spell:49576]].
- [[talent:96182]]
  
  - Reduces all damage taken by 35% when below 30% health, including the portion of the hit that takes you below 30%. For example, if you take a hit that takes you from 60% to 10%, the portion of the hit below 30% of your health is reduced by 35%
- [[talent:96180]]
  
  - Increases all absorbs on you by 30%, this is incredibly powerful as it increases the absorb of spells like [[spell:48707]] and [[spell:17]] and other similar abilities.

##### Runeforges

The tier set in Midnight Season 2 forces you into dual-wielding to take full advantage of the set.

- [[spell:53344]]
- [[spell:62158]]




### [[talent:123322]]Rider   Multi-Target

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### When to use this Spec

This is the build meant to played when there is any relevant second target at any point in the fight in The Venomous Abyss.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added**
  
  - [[talent:96239]]

- **Removed**
  
  - [[talent:96228]]

##### Runeforge

- [[spell:53344]]
- [[spell:62158]]




### [[talent:123324]] Deathbringer   Consistent Cleave

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODwMjZMDY2mZmZmZZmZkZMGDjBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODwMjZMDY2mZmZmZZmZkZMGDjBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

#### When to use this Spec

This build is only meant to be played when there is consistent aoe that lines up well with your Pillar timings and aoe is required on them.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added**
  
  - [[talent:123324]] Deathbringer
  - [[talent:96239]]

- **Removed**
  
  - [[talent:123322]]Rider
  - [[talent:96228]]

##### Runeforge

- [[spell:53344]]
- [[spell:62158]]





## Rotation

### Tier Set

Check out all the [Midnight Season 2 Tier Sets](<https://maxroll.gg/wow/resources/midnight-season-1-tier-sets>)!

- **2-Set**: Each time [[spell:196770]] damages at least 1 enemy, gain [[spell:1297365]] which grants 2% attack speed and 4% increased [[spell:435010]] damage for 10 seconds, stacking.
- **4-Set**: [[spell:196770]] deals damage 25% more frequently, and [[spell:1297365]] lasts 5 seconds longer.

### Single-Target



#### [[talent:123322]]Rider

##### Opener

- In the opener your goal is to get into [[spell:51271]] after using [[spell:279302]] to summon all of your [[talent:117663]] immediately to take full advantage of them being buffed by [[spell:51271]]. Below is an example of how your opener can look using the recommended  **Rider Single-Target** build.

:::rotation Example [[talent:123322]]Rider **Frost Death Knight** Single-Target Opener
```json
{
  "source_code": "JAbA8sgAAAAAAIgQQnLAAAgQ0ecAGQAf_GAFMQgQHhcAOAieRMBAAEAiuOQAVgUAf9BBBgQAAsPA5IAWBIkBDRAAW5DAOJFAMAgQ3_bBFBgQugGAEEgQJwXC2ZDHAYkMAA"
}
```
1. [[spell:47568]] · [[spell:51124]]
2. [[spell:49020]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:47568]] · [[spell:51124]]
4. [[spell:49020]]  [[spell:47568]] · [[spell:51124]]
5. [[spell:49020]]
6. [[spell:49143]]  [[spell:51124]]
7. [[spell:49020]]  [[spell:47568]]
8. [[spell:49020]]  [[spell:51124]]
9. [[spell:49020]]
10. [[spell:49143]]  [[spell:51124]]
11. [[spell:49020]]
:::

- As this is just an example, your opener does change based on when you have [[spell:51128]] or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends! This also extends the duration of your Horsemen by an additional 10 seconds.
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:279302]].
  
  - Recall it after the 15% [[spell:1265630]] buff has expired.
- Cast [[spell:49020]] if either of the following are true:
  
  - You have 2 [[spell:51124]] stacks.
  - You have 1 [[spell:51124]] stack and 3 Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]]
- Cast [[spell:49143]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:49020]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:49143]].
- Cast [[spell:49020]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].




#### [[talent:123324]] Deathbringer

##### Opener

- In the opener, you want to get into your cooldowns as fast as possible. After that your goal is to get off as many [[spell:51128]] empowered [[spell:49020]] and not waste [[spell:441416]]. Below is an example of how your opener can look using the recommended [[talent:123324]] Deathbringer **Single-Target** build.

:::rotation Example [[talent:123324]] Deathbringer **Frost Death Knight** Single-Target Opener
```json
{
  "source_code": "JcaAwjUCCBduAAAAH8kZm1yRDREACNitGAAAAQgQHhMAAAgQ6FxEAAQAI66AAAAAAEwXfQAAIMAA5IAWBUAAB0yFCIkBDRAAAAgACR7xB4COQxrBAAgQ89LAAAAADIE0BkFACZkGAAgAyoBAJ4CAB0AKJ4ACAI09FQEJBIEtHDAAAIEf_C"
}
```
1. [[spell:47568]] Off-GCD
2. [[spell:439843]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:51124]] · [[spell:441424]]
4. [[spell:49020]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
5. [[spell:49020]]  [[spell:47568]] · [[spell:51124]]
6. [[spell:49020]]  [[spell:51124]]
7. [[spell:49020]]
8. [[spell:49143]]  [[spell:51124]]
9. [[spell:49020]]
:::

- As this is just an example, your opener does change based on when you get a [[spell:51128]] proc from auto attacks or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends!
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:439843]].
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:279302]].
- Cast [[spell:49020]] if any of the following are true:
  
  - [[spell:441416]] is able to be cast.
    
    - If [[spell:439843]] is not your next global, wait for a [[spell:51128]] stack.
  - You have 2 stacks of [[spell:51128]].
  
  
  
  - You have 1 stack of [[spell:51128]] and 3 or more Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]].
- Cast [[spell:49143]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:49020]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:49020]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].

##### Notes

- [[talent:123324]] Deathbringer's interaction with [[spell:1265384]] is notable due to [[talent:135991@AJgBBA]] giving you 2 stacks of [[spell:441416]]. Start your cooldown sequence with [[spell:439843]] and spend the [[spell:441416]].





### Multi-Target



#### [[talent:123322]]Rider

##### Opener

- In the opener your goal is to get into [[spell:51271]] after using [[spell:279302]] to summon all of your [[talent:117663]] immediately to take full advantage of them being buffed by [[spell:51271]]. Below is an example of how your opener can look using the recommended [[talent:123322]] **Single-Target** build.

:::rotation Example [[talent:123322]]Rider **Frost Death Knight** Multi-Target Opener
```json
{
  "source_code": "JUbA8sgAAAAAAIgQQnLAAAgQ0ecAGQifpMAAAAABCdEyB4AH6FxEAAQAI6aAUwFAB81HEAACDAQOCgVAFAQAtchACZwQEAgVCBgTWBADAIUY5HwcEEgQuwGAEEgQJAYC6ZDHAokMAA"
}
```
1. [[spell:47568]] · [[spell:51124]]
2. [[spell:207230]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:47568]] · [[spell:51124]]
4. [[spell:207230]]  [[spell:47568]] · [[spell:51124]]
5. [[spell:207230]]
6. [[spell:194913]]  [[spell:51124]]
7. [[spell:207230]]  [[spell:47568]]
8. [[spell:207230]]  [[spell:51124]]
9. [[spell:207230]]
10. [[spell:194913]]  [[spell:51124]]
11. [[spell:207230]]
:::

- As this is just an example, your opener does change based on when you have [[spell:51128]] or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends! This also extends the duration of your Horsemen by an additional 10 seconds.
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:279302]].
  
  - Recall it after the 15% [[spell:1265630]] buff has expired.
- Cast [[spell:207230]] if either of the following are true:
  
  - You have 2 [[spell:51124]] stacks.
  - You have 1 [[spell:51124]] stack and 3 Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]]
- Cast [[spell:194913]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:207230]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:194913]].
- Cast [[spell:207230]]with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].

##### Notes

- [[spell:207230]] replaces [[spell:49020]] at 2 targets.
- [[spell:194913]] replaces [[spell:49143]] at 3 targets.




#### [[talent:123324]] Deathbringer

##### Opener

- In the opener, you want to get into your cooldowns as fast as possible. After that your goal is to get off as many [[spell:51128]] empowered [[spell:207230]] and not waste [[spell:441416]]. Below is an example of how your opener can look using the recommended [[talent:123324]] Deathbringer **Multi-Target** build.

:::rotation Example [[talent:123324]] Deathbringer **Frost Death Knight** Multi-Target Opener
```json
{
  "source_code": "JIaAwjUCCBduAAAAH8kZm1yRDREACNitGAAAAQgQHhMAAAgQ6FxEAAQAI66AAAAAAEwXfQAAIMAA5IAWBUAAB0yFCIkBDRAAAAgACR7xB4CHQxrBAAgQ-lSAugwACBdAZBgQGpBAAIgMaAQCuQAAClgSEEgQJADK-lyAAAAAAIUY5LA"
}
```
1. [[spell:47568]] Off-GCD
2. [[spell:439843]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:51124]] · [[spell:441424]]
4. [[spell:207230]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
5. [[spell:207230]]  [[spell:47568]] · [[spell:51124]]
6. [[spell:207230]]
7. [[spell:279302]]  [[spell:51124]]
8. [[spell:207230]]
9. [[spell:194913]]
:::

- As this is just an example, your opener does change based on when you get a [[spell:51128]] proc from auto attacks or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends!
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:439843]].
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:279302]].
- Cast [[spell:207230]] if either of the following are true:
  
  - You have 2 stacks of [[spell:51128]].
  
  
  
  - You have 1 stack of [[spell:51128]] and 3 or more Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]].
- Cast [[spell:49143]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:207230]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:49020]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].

##### Notes

- [[spell:207230]] replaces [[spell:49020]] at 2 targets.
- [[spell:194913]] replaces [[spell:49143]] at 3 targets.





## Deep Dive

### Anti-Magic Shell Runic Power

- [[spell:48707]] grants you up to 40 Runic Power based on the amount it absorbs. This is incredibly powerful as you can get quite starved on Runic Power so you end up in situations wanting to use this to your advantage as often as possible on bosses where [[spell:48707]] isn't specifically used for defensive purposes.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for all Bosses →**



### Nek'Zali

:::talents **Frost Death Knight** Talents for Nek'Zali in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Boss Tips

- After the pull, there are very good timings to watch for **Restless Amani** add spawns. You gain a significant amount of damage being able to advantage of [[talent:126017]] during your burst.
- [[spell:49576]] is usable on **Restless Amani** to reposition them and group them up better as they spawn very spread.
- Use a defensive after getting targeted by ‍[[spell:1287322]], and go to the edge of the room to drop a puddle.
- Beware of where the tank is when **Nek'zali** casts ‍[[spell:1284103]]. Do not be in between her and her target.




### Entombed Sentinels

:::talents **Frost Death Knight** Talents for Entombed Sentinels in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Boss Tips

- Keep an eye out for when the **Entombed Sentinels** reach 100 energy and cast ‍Vitriolic Stasis , as you don't want to just have popped cooldowns when that happens and be unable to deal any damage.
- When on the **Breath of Ula'teks**' side, make sure to instantly swap to the **Venom Coagulation**.
- Use a defensive when soaking [[spell:1288232]].
- Soak the [[spell:1284434]], you are extremely tanky!




### Lost Explorers

:::talents **Frost Death Knight** Talents for The Lost Explorers in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Boss Tips

- Use [[spell:48792]] if soaking a ‍[[spell:1291922]] with not many people in it to split the damage.
- Interrupt ‍[[spell:1286922]] from **Scrollsage Iku**.




### Vashnik

:::talents **Frost Death Knight** Talents for Vashnik in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Boss Tips

- [[spell:49576]] can and should be used to reposition all oozes on this fight. 
  
  - Only 1 add is immune and that is the first **Splitting Venom**. Once it dies and splits, it can be gripped.
- [[spell:48707]] can be used to avoid getting stacks when **Burning Venom** dies.




### Sszorak

:::talents **Frost Death Knight** Talents for Sszorak in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Boss Tips

- **Sszorak** takes increased damage during ‍[[spell:1286033]], make sure you have your cooldowns for this. Due to how bursty you are this is extremely important.
- [[spell:48265]] can be used to negate [[spell:1285419]]. **DO NOT DO THIS**. It can cause the mechanic to be buggy and potentially negate the knockback you cause and not negate the other persons movement and they will fly off of the platform.
- [[spell:48265]] should instead be used during [[spell:1285732]] to keep you hitting the boss during the [[spell:1286033]] damage phase. 
  
  - You need 1 [[spell:374968]] at any point to keep this at 100% uptime during the phase and ignore all mechanics during this time. It lasts 30 seconds.




### Twin Fangs

:::talents **Frost Death Knight** Talents for Twin Fangs in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### Boss Tips

- Help soak the ‍[[spell:1289201]] without getting so many stacks that you die. 
  
  - You can use [[spell:48707]] before walking into [[spell:1292505]] to not be affected by this slow while its on the floor under the [[spell:1289201]] you want to soak.




### Coiled Altar

:::talents **Frost** Death Knight Talents for The Coiled Altar in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

#### Phase 1

- Soak the [[spell:1283485]] you are assigned to.

#### Phase 2

- Use [[spell:49576]] on players that are affected by [[spell:1285640]] that are not in the stack.
  
  - [[spell:45524]] can also be used on players but should be a last resort as the slow lasts past the duration of the mind control.
  - If your group does not have enough damage to break them out quickly, [[talent:96186]] can be talented but doing this is a dps loss, but a very useful and powerful slow.
- Use [[spell:48707]] when affected by [[spell:1286895]].

#### Intermission

- Make sure you have all of your cooldowns for this phase, during [[spell:1304033]] **Zul'jan** takes 100% additional damage.

#### Phase 3

- [[spell:1285640]] returns, continue using [[spell:49576]] and on players that are not grouped up.




### Ula'tek

:::talents **Frost Death Knight** Talents for Ula'tek in The Venomous Abyss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

**This boss has not yet been tested, check back after the Race to World First for updates!**




### Nymrissa Wavecaller

:::talents **Frost Death Knight** Talents for Nymrissa Wavecaller in The Tidebound Grotto
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

#### Boss Tips

- Use [[spell:48707]] during [[spell:1260837]].
- Make sure [[spell:48265]] is up for when the bubble goes ‍[[spell:1258150]]!
- You can use [[spell:49576]] to help group up the **Bubblefin Shorerunners**.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as an **Frost** **Death Knight**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "JoAJFQAIkEDKBMQAEA"
}
```
**力量 ＞ 暴击 ≥ 急速 ＞ 精通 ≫ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

:::callout This is an Absolute BiS List
While these are the items that you should be aiming to acquire for your absolute Best in Slot, these items will not always be the best until you achieve this exact combination of items.

For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>) whenever you get what can be an upgrade!

:::

| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:251229@BgQAAcEACKgTBA]] into [[item:271474@DiQBAsPAnk7cVrTOC4UAdV9A]] | Catalyst of Voidscar Arena |
| Neck | [[item:268265@BERAAsPAM06wQrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:268226@BgQAAcEA5IgTBA]] into [[item:271472@DgQBAsPAXk7kjAOFgwXQ]] | Catalyst of Nymrissa Wavecaller |
| Cloak | [[item:268253@BgQAAsPA5IAWBA]] | Coiled Altar / Catalyst |
| Chest | Convert [[item:268222@BgQAAsPA5IAWBA]] into [[item:271477@DgQBAsPAJk7kjAYFgvXQ]] | Catalyst of Coiled Altar |
| Wrist | [[item:237834@FiQAAsPAaA80qKEDtO3WzSB]] | Crafted |
| Gloves | Convert [[item:268220@BgQAAcEA5IgTBA]] into [[item:271475@BgQBAsPA5IgTBw7FEA]] | Catalyst of The Twin Fangs |
| Belt | [[item:268259@BiQAAsPAM06kjAYF]] | Coiled Altar |
| Legs | [[item:271878@DARAAsPAhu7YhN5IAWB]] | Ula'tek |
| Boots | [[item:237828@HgQAAsPAaA8kSuTrqQ3WzSB]] | Crafted |
| Ring 1 | [[item:273792@DiQAAsPA1j7wQrjgC4UA]] | Altar of Fangs / The Great Vault |
| Ring 2 | [[item:158366@DiQAAsPA1j7wQrTcj4UA]] | Temple of Sethraliss / The Great Vault |
| Trinket 1 | [[item:270173@BgQAAsPA5IAWBA]] | Coiled Altar |
| Trinket 2 | [[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] | Ula'tek |
| Main-Hand | [[item:268209@RgQAAsPAgBNA5IAWBA]] | Coiled Altar |
| Off-Hand | [[item:268202@RARAAsPAOLPAXYTOCgVA]] | Ula'tek |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@BgQAAsPACKQQBA]] | Murder Row |
| Neck | [[item:251173@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:239037@BgQAAsPACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAsPACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251151@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:159409@BgQAAsPACKQQBA]] | King's Rest |
| Gloves | [[item:251214@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Belt | [[item:159418@BgQAAsPACKQQBA]] | King's Rest |
| Legs | [[item:273776@BgQAAsPACKQQBA]] | Altar of Fangs |
| Boots | [[item:159412@BgQAAsPACKQQBA]] | King's Rest |
| Ring | [[item:273792@BgQAAsPACKQQBA]] | Altar of Fangs |
| Ring | [[item:158366@BgQAAsPACKQQBA]] | Temple of Sethraliss |
| Passive Trinket | [[item:250228@BgQAAsPACKQQBA]] | Murder Row |
| On-Use Trinket | [[item:273797@BgQAAsPACKQQBA]] | Altar of Fangs |
| Weapon | [[item:158373@BgQAAsPACKQQBA]] | Temple of Sethraliss |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons and Raids.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270173@BgQAAsPA5IAWBA]] - Single + 2 Target with [[item:268209@RgQAAsPAgBNA5IAWBA]]  <br>[[item:270164@BgQAAsPA5IgTBA]] - 2 or more targets without the other set bonus  <br>[[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] |
| **A-Tier** | [[item:270165@BgQAAsPA5IgTBA]]  <br>[[item:250228@BgQAAsPACKgTBA]] |
| B-Tier | N/A |
| C-Tier | [[item:250238@AgQAAIoAOFA]]  <br>[[item:273797@BgQAAsPACKgTBA]] |
| **Junkyard** | [[item:193757@BgQAAsPACKgTBA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:270168@BgQAAsPA5IAWBA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]]  <br>[[item:270163@AgQAAkjAOFA]] |

### Embellishments

- [[item:251513@AgQAAcbNLFA]]
- [[item:251490]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 at max item level therefore it is not normally beneficial to equip crafted items outside of your 2x Embellishments. 
  
  - While you are gearing up and do not yet have 334 pieces of gear or Myth track items on some slots, you can use your Myth Dawncrest to craft 331 pieces with Crit and Haste.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Flask**
  
  - [[item:241326]]
  - [[item:241324]]
    
    - Which one you use depends on your stats, check Top Gear in Raidbots to figure out which is best for you!
- **Food**
  
  - [[item:255846]] or [[item:255845]]
    
    - [[item:242275]] or [[item:255847]] have no stamina but are the personal items of this.
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- Unique
  
  
  
  - Any of the following depending on your stats:
    
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240890]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@BAAAAwP]]  <br>[[item:275707@BAAAAsP]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977@BAAAAsP]] |
| Wrist | [[item:275707@BAAAAsP]] |
| Waist | [[item:275707@BAAAAsP]] |
| Legs | [[item:244641@BAAAAwP]] |
| Boots | [[item:243953@BAAAAwP]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Main-Hand | [[spell:53344]] |
| Off-Hand | [[spell:62158]] |

Speed Enchants are also viable in place of the Avoidance enchants, especially at higher item levels.

:::

:::column
:::gear **Frost Death Knight** Enchantments in Raids
```json
{
  "source_code": "IkFZ7DQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NARDIAiQgBNAAAgQOLP"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[spell:53344]] |  |
| 副手 | [[spell:62158]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAsP]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Frost** **Death Knight** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:107072]] -- Pandaren
  
  - Passively buffs your food buff by 100%. Goes well with [[item:242745]] as the hearty version does not disappear when you die!
- [[spell:59224]] and [[spell:65116]] --Dwarf
  
  - Can dispel Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds and is strong in Mythic+.
  
  
  
  - As well as having [[spell:20594]], [[spell:59224]] is a very strong racial bonus granting Critical Strike damage which makes this one of our better races along with Tauren as it has the same racial ability.

:::columns
:::column
:::simulation **Frost** **Death Knight** Race Sims
```json
{
  "source_code": "JUtAQ1xAfAAACewSyF2ZncXYMYHBpO_ZIVAFw7nBLlWbiVHbLYHBWxHaINgCAAAAx0laINgAAAAAA0WaINAJAAAAKYcaINACAAAAVY5aINwHAAggJI0dv52ch1GZphgdEYO8nh0AFAAAAAAdnh0AYAAAAsZ0qh0AJAAAAsEeqh0AGAAAAAEdrh0AcAAAAYv7ph0AbAAAA4bkmh0ABwELGE0a15GZhdgdE0BvNYJ8CRwRv52aKYHBWiBaINQJAAAAjNqaINwCAAAA4ndaINwIAAAAlydZINQAAAAAFq-aINgIAAAAUhOaINwAAAAAAR3aINQAaRXBQF2JrVXC2RwuusGSDQAAAIYBOl2ZoRXrcJgMOrWCSQ-AEFWesylAiylaINgHAAAAbeuZINwBAAAAqxuaINgFAAAA8FpaINQHAAAAg-saINAIAAAA08faINAF"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292364]] | 237,518.64 |
| 种族 31 [[spell:292363]] | 238,065.34 |
| 种族 10 | 239,988.77 |
| 种族 2 | 239,028.00 |
| 种族 36 | 239,384.16 |
| 种族 8 | 241,240.33 |
| 种族 31 [[spell:292360]] | 237,507.59 |
| 种族 5 | 237,008.00 |
| 种族 24 | 240,454.42 |
| 种族 9 | 240,097.17 |
| 种族 6 | 241,105.00 |
| 种族 28 | 239,547.84 |
| 种族 27 | 236,102.97 |
| 种族 31 [[spell:292359]] | 237,296.45 |
| 种族 31 [[spell:292362]] | 237,666.34 |
| 种族 37 | 240,269.55 |
| 种族 11 | 239,463.88 |
| 种族 35 | 235,378.58 |
| 种族 1 | 241,578.08 |
| 种族 34 | 238,497.31 |
| 种族 3 | 241,105.00 |
| 种族 31 [[spell:292361]] | 240,826.92 |
| 种族 4 [[spell:154797]] | 240,440.78 |
| 种族 4 [[spell:154796]] | 239,986.53 |
| 种族 30 | 236,446.42 |
| 种族 7 | 240,561.66 |
| 种族 22 | 240,197.94 |
| 种族 29 | 240,446.50 |
| 种族 32 | 239,612.81 |
:::

:::

:::

### Recommendation

For **Frost** in Raids, I would recommend Troll as it is extremely close to the highest output racial, and this raid in particular has a lot of burst phases where you can truly take advantage of this racial.

If you also play Mythic+ Dwarf is your best pick as it has the best utility option while providing close to the same damage.

If you also play **Unholy**,  Troll is one of the best racials for it, so it is the best all around pick for playing both specs.

## Macros

Discover recommended macros for an **Frost** **Death Knight** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
[[spell:51052]] - *Casts [[spell:51052]]* *at your Cursor position*.

```wow-macro
/cast [@cursor] Anti-Magic Zone
```

:::

:::details Mouseover Macros
[[spell:45524]] - *Casts ‍[[spell:45524]] at your mouseover if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Chains of Ice
```

[[spell:47528]] - *Casts [[spell:47528]]* *at your mouseover if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Mind Freeze
```

[[spell:49576]] - *Casts ‍[[spell:49576]] at your mouseover target if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Death Grip
```

[[spell:61999]] - *Casts [[spell:61999]] on your mouseover so you can use this on your frames.*

```wow-macro
/cast [@mouseover,help,dead][]Raise Ally
```

:::

:::details Focus Macros
Set Focus Mouseover - *This will set your focus to your mouseover.*

```wow-macro
/focus [@mouseover]
```

Focus [[spell:49576]] - *Casts [[spell:49576]] at your focus.*

```wow-macro
/cast [@focus] Death Grip
```

Focus [[spell:47528]] - *Casts [[spell:47528]] at your focus.*

```wow-macro
/cast [@focus] Mind Freeze
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Frost** **Death Knight**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Unholy_Raid_Interface-mxr-1024x635.webp>)

**Frost Death Knight** Interface in Raids

:::accordion
:::details Addons
- **Echo Raid Tools** -- Raid cooldowns and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Frost**

- All ability damage reduced by 10%.
- Melee damage reduced by 20%.
- [[spell:51271]] now increases Strength by 20% (was 30%).
- [[spell:49184]] damage increased by 100%.
- [[spell:47568]] damage increased by 30%.
- [[spell:194913]] damage increased by 30%.
- [[spell:435010]] damage increased by 30%.
- [[spell:55095]] damage increased by 100%.
- [[spell:196770]] damage increased by 40%.
- [[spell:207230]] damage increased by 20%.
- [[spell:49143]] damage increased by 25%. Does not affect Frostbane.
- [[spell:49020]] damage reduced by 12.5%.
- [[spell:1249658]] damage reduced by 20%.
- [[spell:1228433]] damage reduced by 30%.
- [[spell:279302]] damage reduced by 20%.
- [[spell:207200]] grants a shield equal to 35% of damage dealt (was 30%).

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer 
  
  - [[spell:441894]] now causes [[spell:55095]] to deal its damage 75% faster (was 100%).
  - [[talent:135992@AJgBBA]] now increases [[spell:49143]] damage by 35% (was 15%).
  - [[spell:439843]] cast and explosion damage reduced by 25%.
  - [[spell:441416]] damage reduced by 17%.
- [[talent:123322]]Rider of the Apocalypse
  
  - Whitemane's [[spell:444633]] damage reduced by 30%.

:::

:::

:::

:::

:::accordion
:::details Patch 12.0.5
**Death Knight**

- Chosen of Frostbrood (Rank 3) has been updated
  
  - When [[talent:96236]] is recalled, it now grants the full Haste bonus at 50% duration instead. The ability used to recall [[talent:96236]] is no longer on the global cooldown.

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer 
  
  - [[talent:135991@AJgBBA]] secondary effect has been redesigned
    
    - Casting [[talent:117659]] grants 1 stack of [[talent:117665@FJQAm4rBGEA]] with 100% first scythe and 100% second scythe effectiveness.
  - [[talent:117665@FJQAm4rBGEA]] has been updated 
    
    - After [[talent:117665@FJQAm4rBGEA]] explodes, your next 2 [[talent:96246]] or [[talent:96243]] cost 1 Rune and summon 2 scythes to strike the enemies. The rest of the effect remains the same.

:::

:::

:::

:::

:::accordion
:::details Patch 12.0.1
**Death Knight**

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer 
  
  - [[spell:441416]] first scythe damage increased by 30%.
  
  
  
  - [[spell:439843]] damage increased by 25%.
  
  
  
  - [[talent:135992@AJgBBA]] now increases the damage of [[spell:49143]] and [[spell:1228433]] by 15% (was 5%), and also has an additional effect – [[spell:439843]] grants 3 stacks of [[spell:377098]] if it is known.
  - [[spell:443560]] now makes [[spell:434711]] 100% more effective on the primary target, and now grants 8% increased Strength when no enemies are struck by [[spell:437161]] (was 5%).
- [[talent:123322]]Rider of the Apocalypse
  
  - All Horsemen damage reduced by 65%.
  - [[spell:444037]] now increases the damage of [[spell:55095]], [[spell:49143]], and [[spell:1228433]].
  - Trollbane's [[spell:49020]] now correctly becomes Frost when consuming a [[spell:51124]] with One-Handed weapons.
  
  
  
  - [[spell:444072]] now increases the damage of Runic Power abilities by 10% when you have 2 or more active Horsemen (was 20%).

:::

:::

**Frost**

- [[spell:49020]] damage increased by 15%.
- [[spell:49143]] damage reduced by 10%.
- [[spell:1228433]] damage reduced by 10%.
- [[spell:1249658]] and [[spell:279302]] cooldowns are no longer reset after an encounter.

:::

:::

:::accordion
:::details Patch 12.0
**Death Knight**

- New Talent: [[talent:136524]]
  
  - [[spell:61999]] costs 30 less Runic Power.
- New Talent: [[talent:136525]]
  
  - The cooldown of [[talent:96204]] is reduced by 30 seconds, and you receive 50% increased healing while its healing absorb is active.
- New Talent: [[talent:96189]]
  
  - While you are below 50% health, your Ghoul sacrifices 4% of its maximum health to heal you for 1% of your maximum health every second.
- [[talent:96200]] heal reduced to 20% of all damage taken in the last 5 seconds (was 25%).
- [[spell:43265]] damage increased by 130%.
- [[talent:96187]] now reduces the cooldown of Lichborne by 30 seconds (was reduces damage taken).
- [[talent:96198]] is now a 2-point talent.
- [[talent:96180]] is now a 2-point talent and has been moved to the first gate.
- [[talent:136526]] is now a choice talent against [[talent:96193]].
- [[spell:327574]] has been removed.

**Frost**

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer
  
  - New Talent: [[talent:135992@AJgBBA]]
    
    - Frost: [[talent:96245]] damage increased by 5%. [[spell:194913]] damage increased by 5%.
  - New Talent: [[talent:135991@AJgBBA]]
    
    - Frost: [[talent:117659]] deals 5% increased damage. Casting [[talent:96236]] grants 2 stacks of [[talent:117665@FJQAm4rBGEA]]with 100% first scythe and 100% second scythe effectiveness.
  - New Talent: [[talent:135993@AJgBBA]]
    
    - Frost: The effectiveness of [[talent:96195]]is increased by 50%.
  - [[talent:117658]] no longer causes enemies struck to deal 5% reduced Physical damage for 10 seconds.
- [[talent:123322]]Rider of the Apocalypse 
  
  - New Talent: [[talent:135999@AJgBBA]]
    
    - [[talent:125874]]summons forth Trollbane for 6 seconds.
  - New Talent: [[talent:135998@AJgBBA]]
    
    - Casting [[talent:125874]] or [[talent:96243]] orders Trollbane to cast his [[talent:96246]] or [[talent:96243]] alongside you at 100% effectiveness.
  - New Talent: [[talent:135997]] 
    
    - The abilities that Horsemen cast deal 5% increased damage.
  - Mograine's [[spell:43265]] damage increased by 50%.
  - Mograine's[[spell:43265]] now extends the duration of diseases on the targets by 1 second whenever it deals damage.
  - Trollbane's [[spell:45524]] no longer deals damage.
  - Fixed an issue causing [[talent:96245]] to not consume [[talent:96228]] debuff.

:::

:::

:::accordion
:::details Spec Changes
- [[talent:96246]] has been updated:
  
  - Two-Handed: A brutal attack that deals Physical and Frost damage.
  - Dual Wield: A brutal attack with both weapons that deals a total of Physical and Frost damage.
- [[talent:96224]] now has an additional effect – When [[talent:96223]] consumes the [[spell:50401]] stacks on your main target, it deals an additional 250% damage instead.
- [[talent:125877]] has been updated:
  
  - While [[talent:125874]] is active your auto-attack critical strikes increase its duration by 1 second, up to 4 seconds.
- All ability damage reduced by 19%.
- Auto-attack damage increased by 300%.
- [[talent:96223]] damage reduced by 10%.
- [[talent:96222]] secondary target damage reduced by 20%.
- [[talent:96238]] now causes Runic Power spending abilities to have a chance to additionally deal 30% of the damage dealt over 4 seconds.
- [[talent:96225]] effect is now instant and no longer has a projectile.

:::

:::

:::

:::

## FAQ

:::accordion
:::details Q: How do [[spell:51124]] Procs Work?
A: As a 2 Handed Obliteration **Frost Death Knight**, every auto attack critical strike grants you a stack of [[spell:51128]]

As a dual-wielding **Frost Death Knight**, every auto attack critical strike gives you a 30% chance to proc it, stacking up to 4 times meaning at worst you get a [[spell:51128]] after 4 auto attack critical strikes.

- 1 Crit = 30% Chance
- 2 Crits = 60% Chance
- 3 Crits = 90% Chance
- 4 Crits = 100% Chance

:::

:::

---

### Credits

Written By: **Miniaug**

Reviewed By: **Soda**

---

:::changelog 更新记录
**2026-08-12** Updated for patch 12.1

**2026-06-17** Updated for patch 12.0.7

**2026-04-22** Updated for patch 12.0.5

**2026-02-25** Updated for Midnight Launch!

**2026-02-10** Updated for patch 12.0.1

**2026-01-21** Updated for Midnight Pre-patch 12.0.0

**2025-10-07** Updated for patch 11.2.5

**2025-08-06** Updated for patch 11.2

**2025-06-18** Updated for patch 11.1.7

**2025-05-21** Updated for patch 11.1.5

**2025-02-25** Updated for patch 11.1.

**2024-12-18** Updated for patch 11.0.7.
BiS Updated

**2024-10-22** Updated for Patch 11.0.5.
Added new builds, updated Best in Slot gear, updated rotation and cooldown usage section to include Breath of Sindragosa.

**2024-09-08** Updated Best in Slot gear and removed references for talents and builds that are no longer played.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
