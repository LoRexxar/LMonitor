Welcome to the **Restoration Shaman** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 4/5 · Strong

Damage · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 4/5 · Strong

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Restoration Shaman** Mythic+ Best in Slot Gear
```json
{
  "source_code": "J4fAIiQA3_fABsHJEIICBAwJ5OgDtOggC4UABk-FEAQCBAg-sOwRBIBNYFQA5RCBCgQAAcRuDIYAPQABmUwDAMSDPgBuXQAgIEAAR8DA6lQLEshqJ0CBifRBtQQ84mQXsh2uDQICBAAIAPwJqOgDtOwt1sUABwHJEAACBAQB-BD3XQggIEAA1j7AC06AFIBCMU9ANIBBS0aCURgUfkBMAQVHMABKoOABIERXAcbAaRA9iUgfAMQDriCPVPAAIEAACKgTBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271483]] | [[item:240910]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240967]] |
| 肩部 | [[item:271481]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:244003]] |
| 腰部 | [[item:268216]] | [[item:240910]] |
| 腿部 | [[item:271482]] | [[item:240155]] |
| 脚部 | [[item:268258]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240910]] · [[item:245792]] · [[item:240167]] |
| 手部 | [[item:271484]] |  |
| 戒指一 | [[item:268252]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:251148]] | [[item:240914]] · [[item:243957]] |
| 饰品一 | [[item:270162]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:239656]] | [[item:245792]] · [[item:240167]] |
| 主手 | [[item:271092]] | [[item:243971]] |
| 副手 | [[item:251196]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Restoration Shaman**, you have a chance gain access to [[spell:1267068]] after casting [[spell:61295]], which replaces and is a more powerful version of [[spell:5394]].

**Rank 2** increases the healing of [[spell:1267068]] and  [[spell:5394]]. While **Rank 3** gives and additional use of [[spell:1267068]] any time you cast [[spell:378081]] or [[spell:443454]] and causes [[spell:1267068]] to not consume a stack of [[spell:5394]] when used.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-restosham2-mxr.webp>)

Stormstream Totem

:::

:::

### Core Changes

Below you will find a list of meaningful class changes going patch 12.1 to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree.**
  
  - New Talent: Swelling Tides
    
    - Casting [[spell:5394]] or [[spell:1267068]] extends all active [[spell:61295]] by 3 seconds.
  - [[talent:101923]] Cooldown has been decreased to 12 seconds while the duration remains 18 seconds.
  - [[talent:101923]] and [[spell:462603]] heal 6 targets, up from 5.

## Hero Talents

- [[talent:123380]] focuses on consistent single target and AoE healing by providing significant boosts to core healing abilities while also summoning [[talent:117485]] who mimic spells cast by the **Shaman**, while [[talent:123378]] grants an improved version of [[talent:101923]] and various ways for Totems to do extra healing. Currently, [[talent:123378]] tends to outperform [[talent:123380]] in most situations and is the recommended Hero Talent in dungeons.

:::tabs
:::tab [[talent:123378]]
- [[spell:444995]]
  
  - Summons a totem that maintains [[talent:101923]] around it.
  - [[spell:444995]] has a longer duration of 25 seconds, and lets you utilize [[spell:108287]] to move it and the [[talent:101923]] attached to it, making it more flexible than a regular [[talent:101923]].
- [[talent:117476]]
  
  - Every time you summon [[spell:444995]] you get 3 different element buffs that affect your next healing abilities.
    
    - **Water** - Makes your next [[spell:77472]] cleave an ally inside your [[spell:73920]].
    - **Air** - Cast time of your next healing spell is reduced by 40%.
    - **Earth** - Your next [[talent:127861]] will apply an empowered [[talent:101935]] to all targets hit.

:::

:::tab [[talent:123380]]
- [[talent:117485]]
  
  - Call an Ancestor to your side after casting [[spell:73685]] for 12 seconds.
  
  
  
  - When you cast any healing or damage ability, your Ancestors casts a similar one.
- [[talent:117491]]
  
  - This functions the same way as [[talent:127899]] but has a lower cooldown and empowers your next ability.
  - After casting [[spell:443454]], you also summon an Ancestor for 8 seconds.

:::

:::

## Talents

:::tabs
:::tab [[talent:123378]] Mythic+ Talents
:::talents **Restoration Shaman** Mythic+ Talents
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRz2yMDzY2YZGzMGMLzAAwMgZmBzMYmhxgB",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRz2yMDzY2YZGzMGMLzAAwMgZmBzMYmhxgB"
}
```
:::

### When to use this Spec

This is the default loadout going into any dungeon as it specializes in survivability and strong group healing. You will have to adjust the class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, dungeon specific talent loadouts are available in the Dungeons section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look, check out the Rotation and Deep Dive sections below.

#### Spec Tree

- [[spell:470076]]
  
  - Casts of [[spell:77472]] and [[spell:1064]] grant you a stacking buff that increases the initial healing of your next [[spell:61295]] by 30% per stack.
- [[spell:73685]]
  
  - Improves your next core healing ability.
- [[talent:127673]]
  
  - Great talent to improve the survivability of your party. Your core healing spells provide a 10% health increase.
- [[talent:101912]]
  
  - Your main throughput Cooldown. [[spell:1064]] and [[spell:77472]] are significantly empowered during it.
- [[talent:101937@FAQAPdhA]]
  
  - Casts of [[spell:61295]] may proc [[spell:114052]] for 7 seconds. Be sure to pay attention to these procs as [[spell:77472]] rises in priority while it is active.
- [[spell:382020]]
  
  - This talent makes [[spell:379]] a lot stronger. Make sure to have it up on yourself and another ally at all times while talented into [[spell:383010]].
- [[talent:101922]]
  
  - Causes [[spell:73920]] to do damage to enemies inside of it. Make sure to place it in melee to make the most use of both the healing and damage.
- [[talent:101902]]
  
  - Massively increases Mana regenerated while healing. If you are comfortable with Mana management and are looking for more healing instead, swap out [[talent:101902]] for [[talent:136582]] or [[talent:127679@FAQAOPvB]].

#### Class Tree

- [[spell:383010]]
  
  - You can have [[spell:379]] on yourself and an ally simultaneously. This allows you to focus more on healing others and while yourself through passive healing.
- [[spell:1217622]]
  
  - [[spell:974]] no longer loses charges when triggered and does more healing. This means [[spell:974]] will only have to be applied once at the beginning of a dungeon.
- [[talent:135591@AJwBCA]]
  
  - Apply [[spell:52127]], [[spell:974]], [[spell:382021]] and [[spell:457481]] with just one cast of [[spell:52127]].
- [[talent:127899]]
  
  - Makes your next [[spell:1064]] or [[spell:77472]] instant and cost no mana. This also grants a charge of [[spell:1267068]].
- [[spell:108287]]
  
  - This allows you to move all your totems, including [[spell:444995]]!

#### Hero Talents

- [[talent:117476]]
  
  - While the Air and Water Motes don't impact your gameplay a lot, the Earth Mote should be consumed by casting [[spell:77472]] at least once during each [[spell:444995]].
- [[talent:117479]]
  
  - Causes all of your healing Totems to fire off a [[spell:1064]] when summoned. This [[spell:1064]] has all the same interactions as your own casts of [[spell:1064]].
- [[talent:125824]]
  
  - A shield enchant that can be applied via [[talent:135591@AJwBCA]]. While this is a sizeable boost to your healing and you should look to equip a shield, if you don't have one you can talent [[talent:117463]] instead.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:1064]] and [[spell:77472]] have a chance to create [[spell:73920]] at their targets location for 8 seconds.
- **4-Set:** [[spell:73920]] creates a shield on 1 target inside of it every 1 second.

The 2-Set creates a significant amount of extra [[spell:73920]]. These have all of the properties of your casted [[spell:73920]] and trigger the effects of [[spell:462424]] and [[spell:383222]].

The 4-Set does not alter Gameplay in any way.

### Priority List

#### For Healing

1. Cast [[spell:444995]].
2. Cast [[spell:1267068]].
3. Cast Cast [[spell:462603]] if most of your party is inside your [[spell:444995]].
4. Cast [[spell:5394]] at 2 stacks.
5. Cast [[spell:73685]].
6. Cast [[spell:61295]] at 2 stacks.
7. Cast [[spell:5394]].
8. Cast [[spell:77472]] if in [[spell:114052]].
9. Cast [[spell:1064]] or [[spell:77472]] to consume [[spell:73685]] or [[talent:117476]].
10. Cast [[spell:61295]].
11. Cast [[spell:77472]] for spothealing.
12. Cast [[spell:1064]] for AoE healing.

Keep in mind healing is highly situational and following a strict priority list is not always the best way to keep your party alive.

#### For Damage

1. Cast [[spell:444995]] ontop of enemies if talented into [[talent:101922]].
2. Cast [[spell:188443]] if it will hit three enemies.
3. Maintain [[spell:188389]].
4. Cast [[spell:51505]].
5. Cast [[spell:188196]].

### Cooldowns

#### Ascendance

- [[spell:114052]] is your strongest healing cooldown. It does an initial burst of AoE healing and then provides a boost to [[spell:1064]] and [[spell:77472]] for 15 seconds. Line it up with periods of high incoming raid damage to make the best use of its relatively long duration.

#### Healing Tide Totem

- This is the alternative to [[spell:114052]]. It heals all allies within 40 yards. [[spell:108280]] has become a potent Cooldown in dungeons to use when your globals are tight and the HPS requirements are high, or during heavy movement.

#### Spirit Link Totem

- This totem is one of the most unique and powerful Cooldowns in the game. When placed and every second thereafter it redistributes your allies health to be the same percentage of maximum health. It also grants your allies a 15% damage reduction for whoever is within the radius as well as a significant heal with [[spell:462383]].
- [[spell:98008]] is an extremely powerful Cooldown to counter overwhelming damage on your party but it can also be used as a tank external or to keep individual players that are taking more damage than everyone else alive.

## Deep Dive

#### Call of the Ancestors

- Any time you cast a healing or damaging ability, each of your Ancestors will cast a corresponding one. For [[spell:77472]] they will cast [[spell:1223391]], for all other single target heals, they will cast [[spell:447415]] on your target. For any AoE heal (including totems such as [[talent:127863]]) [[spell:447433]]. [[spell:447419]] for single target damage abilities and [[spell:447425]] for your own [[spell:188443]].
- Try lining up [[spell:443454]] with incoming damage - or your own damage during healing downtime.

#### Unleash Life

- Increases the healing and reduces the cast time of your next [[spell:77472]], [[spell:1064]] or [[spell:61295]]. For [[talent:123380]], this is your main way of spawning [[talent:117485]].
- Avoid using [[spell:73685]] to buff [[spell:61295]] as it is by far the weakest of the 3 affected abilities. However, if playing [[talent:123380]], it is a higher priority to use [[spell:73685]] to spawn Ancestors. As [[spell:73685]] has a 20 second Cooldown and Ancestors spawned by it last 16 seconds you have very high uptime on them.
- As [[talent:123380]] [[spell:73685]] can also be used in healing downtime to spawn Ancestors to do damage.

#### Ascendance

- With Midnight [[spell:114052]] has been reworked. It now reduces the Mana costs of [[spell:77472]] and [[spell:1064]] by 25%. [[spell:77472]] casts cleave onto a secondary ally at 50% effectiveness and both of these hits are guaranteed to critical strike. [[spell:1064]] casts jump to an additional 3 allies while each consecutive jump for the entire [[spell:1064]] only does 10% less healing rather than the normal 30%.
- Through the two guaranteed critical strikes, [[spell:77472]] procs [[talent:101927]] a lot more often, making it a very powerful ability and your main healing tool during [[spell:114052]].
- The modifications to [[spell:1064]] also apply to [[talent:117479]], meaning you want to stack up as many stacks of [[spell:5394]] and [[spell:1267068]] as possible. If needed we can line up [[spell:378081]] with [[spell:114052]] as well to gain another use of [[spell:1267068]] and an instant [[spell:1064]] or [[spell:77472]].
- As our other abilities are not empowered by [[spell:114052]] anymore this means we want to use as many of them either before or after as with losing casts. [[spell:444995]] should be used ahead of  [[spell:114052]] so it won't have to be refreshed during it.
- Use [[spell:73685]] right before going into [[spell:114052]] to further empower [[spell:77472]]. Make sure to spend all [[spell:61295]] before this so they don't consume this buff and to increase the chance of having a [[spell:1267068]] to use during [[spell:114052]]. Casts of [[spell:61295]] while [[spell:114052]] is active should be kept to a minimum, however it is still worth using at 2 stacks to not lose out on a use.

#### Deluge

- If it is not possible to stay stacked inside [[spell:73920]], look to cast [[spell:61295]] primarily on ranged players to fully utilize [[spell:200076]].

#### Coalescing Water

- Any [[spell:77472]] or [[spell:1064]] casted by you will grant you a stack of [[spell:470076]].
- To make the most use out of this talent it is generally best to loosely alternate between [[spell:77472]]/[[spell:1064]] and [[spell:61295]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Restoration Shaman** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG"
}
```
:::

### Boss Tips

#### Rav'i

- Position yourself in a way to not get knocked into a bad spot by [[spell:1307915]].
- The highest damage intake will come when the boss starts [[spell:1298221]] and applying [[spell:1307700]] to players. At the same time you will have to soak [[spell:1306226]], which also does significant damage, you will want to cycle your defensives and throughput for these phases.

#### The Writhing Coil

- The majority of damage on this fight comes from [[spell:1299154]], a fairly long DoT. Pace your healing for the entire duration.
- The boss will [[spell:1300612]] and split into several smaller adds. These apply [[spell:1305367]] which can be dispelled with [[spell:383013]].
- [[spell:1299053]] needs to be broken as quickly as possible by breaking the [[spell:1287797]] tether. Use any kind of movement speed for this.

#### Zul'jan

- This fight revolves around [[spell:1300876]], which causes 4 beams that need to be intercepted by standing inside of them. Doing so will leave [[spell:1300894]] on players affected.
- [[spell:1300894]] can be removed by getting hit by any of the bosses physical abilities, causing [[spell:1301217]], the safest way to do it is by standing in [[spell:1301413]] when another player is targeted by it.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpents**.
  - [[spell:1289416]] and [[spell:1307567]] from **High Evolutionists**.

- Dangerous debuffs and damage to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can be removed with effects such as [[talent:127882]].
  - [[spell:1294849]] from **Rattling Writhe**. 
    
    - Does a lot of damage and can overlap with Hatchlings melee attacking players.
  - [[spell:1308512]] from **Blade of the Altar** and [[spell:1306852]] from **Ula'tek's Chosen** can overlap as they are often pulled together.
  - [[spell:1303366]] is a on on-death effect from **Living Venoms**. 
    
    - This can happend during the two debuffs mentioned above.

:::

:::tab Den of Nalorakk
:::talents **Restoration Shaman** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG"
}
```
:::

### Boss Tips

#### The Hoardmonger

- [[spell:1234681]] does a lot of damage to all players.
- [[spell:1234740]] will need to be soaked before they explode. Doing so leaves [[spell:1234846]] which can be dispelled with [[spell:383013]].
- The boss will leap for [[spell:1235129]], make sure to stay close to him to have an easier time dodging afterwards.

#### Sentinel of Winter

- Remain close to the boss and run against the pushback from [[spell:1235656]] to mitigate most of its damage.

#### Nalorakk

- Stand behind **Zul'jarra** during [[spell:1243569]] to benefit from her [[spell:1261776]].
- Position [[spell:1242860]] towards the edge of the Arena as you will have to intercept them soon.
- Once **Nalorakk** reaches 100 energy, he will start channeling [[spell:1243002]]. Move in between **Zul'jarra** and the **Echoes of Nalorakk** charging towards her. Each one of these leaves a stack of [[spell:1255577]] on the player soaking it, try spreading them out between the group.

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
    
    - Heals the Spirit based on damage done.
  - [[spell:1238801]] from **Starvation Effigy**.
    
    - If this cast goes off before the Totem is destroyed it will Curse players and reduce their maximum health, can be removed with [[talent:101964]].
  - [[spell:1296518]] from **Terra Rumbler**.
    
    - Inflicts damage while the shield lasts.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Roots all players. Stay close to the group to make it easier to break you out of it. Alternatively you can remove it with [[spell:58875]].
  - **Loyal Saberfang** will fixate players and melee attack them.
  - [[spell:1246957]] from Grizzled Warbringer.
    
    - Leaves a DoT on the entire party.
- Debuffs to be wary of:
  
  - [[spell:1238439]] from **Keen-Eyed Strikers**.
    
    - Leaves a stacking bleed.
  - [[spell:1239860]] from **Glacial Revenant.**
    
    - Debuffs a player with a magic dispel. You might have to deal with 2 of these at the same time, chose one to dispel and heal the other.

:::

:::tab Murder Row
:::talents **Restoration Shaman** Mythic+ Build in Murder Row
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjZMWWmZxGjZsMN2mZhJzwYDzwMz2MjRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjZMWWmZxGjZsMN2mZhJzwYDzwMz2MjRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- **Kystia** creates [[spell:1264095]] of herself that will need to be interrupted as soon as possible.
- **Nibbles** spits [[spell:1228198]] at players that should be dispelled.
- Once **Nibbles** is brought to 20% health he disappears for [[spell:1230304]] and causes [[spell:1214959]]. The boss is stunned during this and takes increased damage but also deal a lot of damage to players.

#### Zaen Bladesorrow

- Use [[spell:1214357]] to destroy barrels that are highlighted in green. On expiration, it deals a large amount of damage that will require defensives at higher key levels.
- Hide behind barrels when aimed at by [[spell:1218347]] to negate its damage.

#### Xanthuux the Annihilator

- Place [[spell:1214663]] near the boss to make cleaving it down easier for melee.
- [[spell:1295455]] requires you to spread out and does a lot of damage to the entire party. Halfway through this debuff the boss goes into [[spell:474197]] which causes high initial burst damage.

#### Lithiel Cinderfury

- Slightly spread out to avoid cleaving other players with [[spell:474457]]. Stay close enough for the Wild Imps to spawn near each other, making them easier to cleave and CC.
- Take [[spell:1214675]] to travel over [[spell:1217384]].

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:1294770]] from **Shivian Punisher.**
    
    - Inflicts a lot of party wide damage.
  - [[spell:1302007]] from **Felmaster Lucsei**.
    
    - A stacking DoT on the entire party that does very high damage.
  - [[spell:1215961]] from **Defiled Golem**.
    
    - Targets all players with a beam that must be kited to avoid damage. The beam also leaves Fel zones on the ground.
  - [[spell:1294824]] from **Defiled Golem**.
    
    - Does high party wide damage 3 times in succession.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216589]] from **Street Sneak**.
    
    - A hard hitting poison on the tank that also reduces their maximum Health. Can be dispelled with [[spell:383013]].
  - [[spell:1216300]] from **Row Hooligan**.
    
    - A Bleed that does damage over time.
  - [[spell:1294789]] from **Corrupted Warlock.**
    
    - A curse that does a lot of damage on expiration but can be dispelled.
  - [[spell:84533]] from **Corrupted Warlock.**
    
    - Does a lot of damage and heals the caster.

:::

:::tab The Blinding Vale
:::talents **Restoration Shaman** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG"
}
```
:::

### Boss Tips

#### Ikkuz the Light Hunter

- Position to not get knocked into [[spell:1236658]] by [[spell:1236746]]. You will get rooted afterwards. This is a magic dispel but can also be removed by [[spell:58875]].
- At 50% Health remaining the boss will go into a [[spell:1237073]] and start pulsing damage until defeated. Save your defensives and throughput for this phase as the damage intake will be much higher.

#### Lightblossom Trinity

- [[spell:1234753]] does a lof of damage to the entire party and creates patches that will later be hit by [[spell:1234850]], avoid standing between two patches.
- After [[spell:1234850]] the patches will be targeted by [[spell:1235564]]. These beams need to be intercepted by standing inside the beam, which does damage to the player soaking it.
- [[spell:1235640]] is a hard hitting bleed on one player. This can overlap with [[spell:1234753]] and should be mitigated with defensives.

#### Lightwarden Ruia

- The boss begins the fight as a [[spell:1239882]] and targets players with [[spell:1239824]], they will take a lot of damage and need to be spothealed. When this DoT expires it shoots out tornadoes that silence players hit by them.
- Once the boss transforms into a [[spell:1239885]] it starts targeting players with [[spell:1240210]] instead, which is a frontal that should be aimed away from other players and leaves a bleed on anyone hit.
- During the bear phase she also casts [[spell:1241058]], putting a bleed on the entire party.
- As soon as the boss transforms into a [[spell:1239883]] she starts channeling [[spell:1241067]] until the end of the fight. During this she keeps summoning Bears and Moonkins which mimic her previous abilities.

#### Ziekket

- The boss spawns 6 **Lightspawn Lashers** around him with [[spell:1246372]]. They cast [[spell:1247669]], which needs to be stopped with interrupts or CCs.
- The corpsed of **Lightspawn Lashers** can be destroyed with [[spell:1246607]], turning them into puddles of Sap. If they are not destroyed by the time the boss casts [[spell:1246372]] again they will respawn.
- [[spell:1246858]] creates Orbs in a circle around the boss. These need to be intercepted by players before reaching the boss. This leaves a stacking DoT that also increases damage and healing done by the player soaking them.

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
    
    - Channels a beam into 3 players and does damage around them.
  - [[spell:1271385]] from **Sporeblight Belcher**.
    
    - Does damage to the party.
  - [[spell:277802]] from **Thorny Saptor**.
    
    - Leaps behind a player and starts attack in a cone in front of it. This also leaves a short DoT on the targeted player.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Does damage and knocks back players at the end of the cast. This is especially dangerous when you are fighting on the bridge and can get knocked off.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Spits poison on all players, causing initial damage and leaving a poison DoT. This can be dispelled with [[spell:383013]].

- Dangerous debuffs to be wary of:
  
  - [[spell:1238084]] from **Lasher**.
    
    - A fast stacking debuff on the tank that needs to be dispelled.
  - [[spell:1216822]] from **Creeping Spindleweb**.
    
    - Damage over time that can be removed with [[talent:136567]].

:::

:::tab Voidscar Arena
:::talents **Restoration Shaman** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZmRzyyMzmZMbsYMzYwsMDAAzAmZGMzgZGGDG"
}
```
:::

### Boss Tips

#### Taz'Rah

- This encounter revolves around [[spell:1296889]], which will target players with [[spell:1222098]] and charge through them to new locations, leaving behind a heavy DoT. Baiting these in good positions is key to making the following mechanics easier to handle.
- Do not stand near [[spell:1296889]] as they will also Erupt during [[spell:1296963]].
- During [[spell:1300259]] the [[spell:1296889]] will shoot out Orbs that need to be dodged.

#### Atroxus

- [[spell:1226031]] does party wide damage and causes poison zones that need to be avoided.
- [[spell:1262497]] spawns a **Toxic Creeper** that does damage to the entire party while alive.

#### Charonus

- [[spell:1264191]] created 3 Singularities that will continuously pull players in and do damage.
- Position yourself away from other players in preparation for [[spell:1227197]]. This can be quite dangerous as it happens while [[spell:1264191]] is actively pulling you in.
- [[spell:1223298]] will target 3 players and do ramping damage to them. Kite these into [[spell:1264191]] to destroy both.
- One player will be targeted by [[spell:1222755]]. After a short delay, the boss shoots multiple fast-moving projectiles towards that player. These can be intercepted but deal heavy damage, so only Tanks should attempt this. Otherwise, simply avoid getting hit by them.

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:1298900]] from **Brutal Overseer**.
    
    - Shields the caster and does ramping party wide damage while it persists.
  - [[spell:1298917]] from **Aegyra the Unyielding**.
    
    - Tethers all players to a Spear which can be destroyed to break the tether and applies a debuff that will do damage to nearby players on expiration. Quickly spread out afterwards to avoid cleaving other players.
  - [[spell:1234855]] from **Chitigoth**.
    
    - Does high party wide damage during the channel.
  - [[spell:1239855]] from **Watchful Harrower**.
    
    - Targets one player with a circle that does damage split between everyone inside it on expiration.

- Dangerous debuffs to be wary of:
  
  - [[spell:1300138]] from **Watchful Harrower**.
    
    - Channels a beam into one player. This does damage in a circle around them.
  - [[spell:1252406]] from **Devouring Brutalizer**.
    
    - Does significant damage to the entire party.

:::

:::tab Kings' Rest
:::talents **Restoration Shaman** Mythic+ Build in King's Rest
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZMaWWmZ2MjZjFjZGDLzyMAAMDYmZwMDmZYMY",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZMaWWmZ2MjZjFjZGDLzyMAAMDYmZwMDmZYMY"
}
```
:::

### Boss Tips

#### The Golden Serpent

- 2 players get targeted with [[spell:265773]], a DoT that leaves a pool of [[spell:265914]] on expiration. Drop these away from the boss, as [[spell:265923]] spawns **Animated Gold** adds from the pools that must not reach the boss.
- [[spell:1311987]] is the highest damage intake on this fight. Rotate defensives and throughput to deal with this.

#### Mchimba the Embalmer

- The boss will target a player with [[spell:267618]]. This DoT does a lot of damage that will require defensives to be dealt with. On expiration the target is afflicted by [[spell:267626]]. Remove this debuff quickly by healing them above 90% Health.
- [[spell:267639]] is a beam targeting one player, this needs to be kited to avoid damage and leaves fire on the ground. Pre position towards the edges of the room to make dealing with the area denial easier in the long run.
- One player will get imprisoned in one of the four sarcophagi in the room by [[spell:267702]]. The player can rattle to show which one they are in. Free them by clicking on the correct one. Clicking on a wrong sarcophagus will spawn a **Half-finished Mummy**.

#### The Council of Tribes

- This encounter consists of 3 different bosses in a row, the order of which is different each week.
- **Kula** hits players with [[spell:266231]].
- **Aka'ali** targets a player with [[spell:266951]], which deals reduced damage for each player standing in the charge.
- **Zanazal** does damage with [[spell:1305810]] and spawns 3 different Totems with [[spell:267060]]. Pay attention to the **Thundering Totem** as it can Disrupt your spell casts.

#### King Dazar

- The fight starts with **King Dazar** and **Reban**. **Reban** casts [[spell:269231]] on players, attacking in a frontal cone after leaping.
- [[spell:1303115]] targets players with a red circle. Spread out to avoid cleaving other players. This often happens while you also have to avoid [[spell:1302945]].
- Once **Reban** is defeated the boss will mount **T'zala** whom he shares health with due to [[spell:1303523]]. This replaces [[spell:269231]] with [[spell:1303324]], which is functionally the same.
- [[spell:1303267]] puts a DoT on all players. Coordinate with your group on where to move to as this overlaps with [[spell:1302945]] which can cause players to outrange you.

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:1310754]] from **Animated Golem**.
    
    - Does damage every time the Golem lands a melee attack.
  - [[spell:269935]] from **Minion of Zul**.
    
    - This shield can be removed with [[spell:370]], killing it immediately.
  - [[spell:270293]] from **Purification Construct**.
    
    - Inflicts high damage to the party and leaves a patch of fire underneath the Construct, try to stay ahead of it towards the next room so you don't get cut off from your party.
  - [[spell:271555]] from **Interment Construct**.
    
    - Imprisons a player in on of the sarcophagi around the room. Free them by clicking on the correct one. While the player is imprisoned the Construct does ramping damage to everyone else with [[spell:271561]].
  - [[spell:269230]] from **Honored Raptor**.
    
    - Leaps towards a player and starts attack in a frontal cone.
  - [[spell:273361]] from **Shadow of Zul**.
    
    - Spawns a pool on the ground that will explode unless a player is actively standing in it. The player soaking it will take damage over time.
  - [[spell:272021]] from **Shadow of Zul**.
    
    - Targets 2 players with a debuff that does damage around them on expiration and spawns a **Minion of Zul** which needs to be [[spell:370]]. The damage taken from this increases with each subsequent application.

- Dangerous debuffs to be wary of:
  
  - [[spell:1306763]] from **Queen Patlaa**.
    
    - Applies a **Poison** debuff that inflicts shadow damage over time and reduces movement speed. Can be removed with [[spell:383013]] or effects such as [[spell:462817]].
  - [[spell:1297779]] from **Bloodsworn Assassin**.
    
    - Applies a **Bleed** debuff that slows the movement speed of a player and inflicts damage every second. Can also removed with [[spell:58875]] and [[spell:462817]].
  - [[spell:1301851]] from **Royal Berserker**.
    
    - Applies a **Bleed** debuff that inflicts damage over time.

:::

:::tab Ruby Life Pools
:::talents **Restoration Shaman** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZMa2WmZYGzGLmHYmxwysMDAAzAmZGMzgZGGDGA",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZMa2WmZYGzGLmHYmxwysMDAAzAmZGMzgZGGDGA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- [[spell:396044]] does damage to players and drops Hailbombs at their location.
- One player will get targeted by [[spell:372851]]. On expiration this drops a tornado that will suck players towards its center. Position away from Hailbombs to not get dragged into them.
- The boss will shield herself during [[spell:373680]]. This pulses ever increasing damage on the party as long as the shield persists. This is likely where you will need the most throughput.

#### Kokia Blazehoof

- [[spell:372863]] targets a player with a debuff. On expiration this spawns a **Blazebound Firestorm**. As long as this add is alive it will pulsate high party-wide damage.
- Aim [[spell:372107]] away from the **Blazebound Firestorm** and away from where you want to move the boss as it leaves fire on the ground.

#### Kyrakka and Erkhart Stormvein

- The encounter begins with boss bosses separated. **Kyrakka** remains in the air until brought down to 50% Health, upon which she lands and both bosses start fighting together.
- **Kyrakka** targets 2 players [[spell:381862]]. This debuff does fairly high damage over time and drops multiple fire pools upon expiration.
- [[spell:381517]] does damage over its duration and pushes both players and patches of fire away from **Kyrakka**.
- Pay attention to [[spell:381516]] as it it interrupt your spell casts and do a burst of damage.
- Dispel [[spell:381512]] from the tank immediately.

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
    
    - Inflicts very high damage to the entire party and causes debris to rain down from the ceiling.
  - [[spell:372047]] from **Defier Draghar**.
    
    - Does party-wide damage and shoots fire circles at the ground.
  - [[spell:373972]] from **Ashseer** Flamelasher.
    
    - Triggers a shield upon the **Ashseer** reaching 1 Health. This can be removed with [[spell:370]] to immediately kill the **Ashseer**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
    
    - A short DoT that explodes around the target upon expiration, knocking up both allies and enemies. This can be used to stop enemy casts.
- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
    
    - A heavy damage over time effect.
  - [[spell:1305233]] from **Infused Whelps.**
    
    - A stacking Magic debuff on the tank. This needs to be dispelled before reaching 20 stacks, otherwise the tank becomes stunned.
  - [[spell:392640]] from Thunderhead.
    
    - A Magic DoT on 2 players. Triggers [[spell:1310599]] on expiration. Stagger the dispel to avoid getting to 2 stacks.
  - [[spell:1306366]] from **Tempest Channeler** and **High Channeler Ryvali**.
    
    - Channels into a player, dealing heavy damage.
  - [[spell:1310355]] from **High Channeler Ryvali**.
    
    - Shields herself and starts doing party-wide damage as long as the shield persists. This can overlap with [[spell:1306366]], requiring strong defensives to survive.

:::

:::tab Temple of Sethraliss
:::talents **Restoration Shaman** Mythic+ Temple of Sethraliss
```json
{
  "source_code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZMa2WmZ2MjZjFjZGDLzyMAAMDYmZwMDmZYMY",
  "code": "CiQAvTCLxPa6EXhIkSAiNIkjqAAAAAAAAAYmZmltlZmZGjZGjhxyyML2YMjlpx2MLMZGGbYGmZ2mZMa2WmZ2MjZjFjZGDLzyMAAMDYmZwMDmZYMY"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- At any given time during the fight, one of the bosses will have [[spell:1310311]] on them, reducing their damage taken by 99% and inflicting damage to anyone attacking them. Swap to whichever boss does not have this buff.
- [[spell:1288864]] targets 3 players with a debuff that leaves a Tempest Zone on expiration, silencing players who touch it.
- **Aspix** shoots [[spell:1289059]], knocking all players back a great distance. Avoid being knocked into Tempest Zones. Immediately after, he uses [[spell:1288049]] to dash towards a player. This needs to be soaked to split the damage. Coordinate with your party where to get knocked to.

#### Merektha

- Move close to your party when targeted by [[spell:263958]] so they can break you free.
- Avoid getting hit by the boss when it moves around during [[spell:264206]].
- Keep moving with [[spell:1289109]] to avoid getting hit by Lightning Strikes continuously appearing under you.

#### Galvazzt

- This is a very simple boss consisting of only 2 mechanics and is mostly a healing and survivability check. Make sure to have all of your Cooldowns ready for this encounter.
- [[spell:1291618]] spawns 3 Spires which will channel beams into the boss, intercepting these beams does very high damage but is necessary to avoid empowering the boss.
- Afterwards the boss does a burst of damage with [[spell:1290531]].

#### Avatar of Sethraliss

- To beat this encounter the **Avatar** will have to reach full Health. However it can only be healed once all **Essence Defilers** have been defeated due to [[spell:1301199]].
- Don't soak [[spell:1300871]] as this will reduce your healing done by 50%.
- **Twisted Hexxer** applies [[spell:1302153]] to players. This is a fairly weak DoT that leaves a pool on the ground on expiration. Try dropping these on the edge of the room.

### Trash Tips

- Pay extra attention to these abilities:
  
  - [[spell:265966]] from **Sandfury Stonefist**.
    
    - Inflicts physical damage and knocks everyone back.
  - [[spell:1293464]] from **Agitated Nimbus**.
    
    - A stacking buff on enemies that can be removed with [[spell:370]]. Otherwise it will increase the damage of [[spell:265911]].
  - [[spell:1303486]] from **Orb Watcher**.
    
    - Does a burst of damage and leaves a DoT on the entire party.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
    
    - **Bleed** inflicting heavy physical damage. Can be removed with [[spell:20594]].
  - [[spell:1308100]] from **Shrouded Fang**.
    
    - Stuns the first target when attacking from stealth, can be removed with [[spell:383013]].
  - [[spell:1308148]] from **Poisonous Viper**.
    
    - A Poison DoT that can be removed with [[spell:383013]].
  - [[spell:1296045]] from **Imbued Stormcaller**.
    
    - A Magic DoT that stuns the target if not dispelled before expiration.

:::

:::

### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance

- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar

- +6 Affix
  
  - Lindormi's Guidance removed

- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Restoration Shaman**.

- Xal'atath's Bargain: Ascendant
  
  - You can use [[talent:127851]] for this affix.
- Xal'atath's Bargain: Voidbound
  
  - Make sure to target this and use your DPS abilities, if no healing is required.
- Xal'atath's Bargain: Oblivion
  
  - Utilize [[talent:127909]] and [[talent:127857]] to make it easier to soak these, without loosing uptime.
- Xal'atath's Bargain: Devour
  
  - [[talent:127885]] is great for dealing with this affix.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Restoration Shaman**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Restoration Shaman** Stat Priority in Mythic+
```json
{
  "source_code": "IoAJFUAIoQSMEEwABA"
}
```
**智力 ≫ 暴击 ＞ 全能 ≥ 急速 ＞ 精通**
:::

> The conclusion here is that you want to equip the highest item level generally.

Blizzard introduced Stat DRs that you need to be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful Leech is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/Screenshot-2026-02-21-165544-1-1024x405.png>)

**Restoration Shaman** Warcraftlogs

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | Catalyze [[item:268230@BgQAAgQACKgTBA]] into [[item:271483@DiQAAgQAnk74QrjgC4UA]] | Nek'Zali + Catalyst |
| Neck | [[item:268265@BkQAAgQA6z6cUrjgCgVA]] | Ula'tek |
| Shoulder | Catalyze [[item:268231@BgQAAgQACKAWBA]] into [[item:271481@DgQAAgQAXk7IoAYF]] | Coiled Altar + Catalyst |
| Cloak | [[item:239656@FgQAAgQAgA8ciqzt1sUA]] | Crafted |
| Chest | [[item:271876@DgQAAgQAjk7IoAYF]] | Ula'tek |
| Wrist | [[item:244584@FiQAAgQAgA8ciqjDtO3WzSB]] | Crafted |
| Gloves | [[item:271484@BgQAAgQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:249303@DiQAAgQAZbApPrjgCESA]] | Lightblinded Vanguard |
| Legs | Catalyze [[item:268237@BgQAAgQACKAWBA]] into [[item:271482@DgQBAgQAbo6IoAYFQzXQ]] | Coiled Altar + Catalyst |
| Boots | [[item:268258@DgQAAgQAxj7IoAOF]] | Lost Explorers |
| Ring 1 | [[item:268252@DiQAAgQA1j7IQrjgC4UA]] | Sszorak |
| Ring 2 | [[item:251148@DiQAAgQA1j7IRrjgCgVA]] | Den of Nalorakk |
| Trinket 1 | [[item:270162@BgQAAgQACKgTBA]] | Nek'Zali |
| Trinket 2 | [[item:270164@BgQAAgQACKgTBA]] | Lost Explorers |
| Weapon | [[item:271092@DgQAAgQADk7IoAYF]] | Ula'tek |
| Shield | [[item:251196@BgQAAgQACKgTBA]] | The Blinding Vale |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Neck | [[item:251234@BgQAAgQACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:251131@BgQAAgQACKQQBA]] | Murder Row |
| Cloak | [[item:251132@BgQAAgQACKQQBA]] | Murder Row |
| Chest | [[item:239046@BgQAAgQACKQQBA]] | Kings' Rest |
| Wrist | [[item:159380@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Gloves | [[item:251165@BgQAAgQACKQQBA]] | The Blinding Vale |
| Belt | [[item:251155@BgQAAgQACKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAgQACKQQBA]] | Temple of Sethralis |
| Boots | [[item:251125@BgQAAgQACKQQBA]] | Murder Row |
| Ring 1 | [[item:251136@BgQAAgQACKQQBA]] | Murder Row |
| Ring 2 | [[item:251148@BgQAAgQACKQQBA]] | Den of Nalorakk |
| Trinket 1 | [[item:250215@BgQAAgQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250214@BgQAAgQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:273780@BgQAAgQACKQQBA]] | Altar of Fangs |
| Shield | [[item:251196@BgQAAgQACKQQBA]] | The Blinding Vale |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves. Do note that some trinkets are better than others depending on the dungeon.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270162@BgQAAgQACKgTBA]]  <br>[[item:270164@BgQAAgQACKgTBA]] |
| **A-Tier** | [[item:270167@BgQAAgQACKgTBA]]   <br>[[item:250214@BgQAAgQACKgTBA]] |
| **B-Tier** | [[item:273649@BgQAAgQACKgTBA]]  <br>[[item:273796@BgQAAgQACKgTBA]]  <br>[[item:250215@BgQAAgQACKgTBA]] |
| **C-Tier** | [[item:270171@BgQAAgQACKgTBA]]  <br>[[item:270169@BgQAAgQACKAWBA]]  <br>[[item:193757@BgQAAgQACKgTBA]]  <br>[[item:250248@BgQAAgQACKgTBA]] |
| **Junkyard** | [[item:250255@BgQAAgQACKgTBA]]  <br>[[item:193748@BgQAAgQACKgTBA]]  <br>[[item:250254@BgQAAgQACKgTBA]] |

### Embellishments

- *Early on in the patch or if you struggle to find a good weapon to drop, you can craft a staff with [[item:245875]]. However, long term you want to end up with [[item:271092@DgQAAgQADk7IoAYF]] + a shield.*
- [[item:245875]] - Weapon only
  
  - Gives you a secondary stat depending on creature type healed or attacked. Healing Humanoids provides Mastery.
- [[item:244603]] - Jewellery
  
  - Chance to grant an ally Versatility. This does not grant you any power, however there are not a lot of alternatives here.
- [[item:240166]] - Armor only
  
  - Chance to empower yourself and an ally with Primary Stat. The main benefit of this is on yourself.

### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 at max item level, therefore it is not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Phials**
  
  - [[item:241326]]
- **Food**
  
  - [[item:255847]] *-- Personal Food*
  
  
  
  - [[item:266996]] -- Raidwide Feast
- Combat Potion
  
  - [[item:241308]] -- Use with your Cooldowns
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[talent:101935]] *--  Default*
  
  
  
  - [[item:243734]] -- If you play without Earthliving
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240910]]
  - [[item:240983]] *--* *Unique, use this as the default Diamond. Only one Diamond can be equipped*!
  
  
  
  - [[item:240967]] *--* *Unique,use this if you have 5 or more gem slots. Equip one of each gem colour to enhance your Diamond.*
    
    - [[item:240910]]
    - [[item:240914]]
    - [[item:240898]]
    - [[item:240890]]

### Enchantments

:::columns
:::column
| Helm | [[item:244005]]  <br>[[item:275707@BAAAAgQA]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAgQA]] |
| Belt | [[item:275707@BAAAAgQA]] |
| Legs | [[item:240133]] |
| Boots | [[item:243953]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:243971]] |

:::

:::column
:::gear **Restoration** Shaman Enchantments
```json
{
  "source_code": "JQFZIEQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEwA5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243971]] |  |
:::

:::

:::

> You can buy [[item:275707@BAAAAgQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt. It is highly recommended to prioritize item upgrades from your Great Vault before considering Sockets.

## Races

For min-maxing a **Restoration Shaman** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:69070]] -- Goblin
  
  - Does a short jump in the direction your character is facing.
  - Increases Haste by 1%.
- [[spell:20594]] -- Dwarf
  
  - Dispels Magic, Curse, Poison, Disease and Bleed debuffs without triggering a GCD. Very useful in various dungeons.
  - Increases Critical Strike Damage and Healing by 2%.
- [[spell:274738]] *-- Mag'har Orc*
  
  - 2 minute cooldown that grants a high amount of secondary stats.

### Recommendation:

It is recommended to play Dwarf as it provides one of the few possible ways to remove Bleeds and debuff types you can't otherwise dispel as a Restoration Shaman.

## Macros

Discover recommended macros for **Restoration Shaman** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Restoration Shaman** Raid Guide are available as mouseover macros for your convenience!

**[[spell:1064]]**

```wow-macro
/cast [@mouseover, help, nodead] Chain Heal; Chain Heal
```

**[[spell:61295]]**

```wow-macro
/cast [@mouseover, help, nodead] Riptide; Riptide
```

**[[spell:77472]]**

```wow-macro
/cast [@mouseover, help, nodead] Healing Wave; Healing Wave
```

**[[spell:73685]]**

```wow-macro
/cast [@mouseover, help, nodead] Unleash Life; Unleash Life
```

:::

:::details Recommended Macros
**[[spell:108287]]** at your cursor without confirmation.

```wow-macro
#showtooltip
/cast [@cursor] Totemic Projection
```

**[[talent:101923]]** at your cursor without confirmation. Also works for **[[spell:444995]].**

```wow-macro
#showtooltip
/cast [@cursor] Healing rain
```

**[[spell:98008]]** at your cursor without confirmation.

```wow-macro
#showtooltip
/cast [@cursor] Spirit Link Totem
```

**[[spell:77130]]** & **[[spell:370]]** **Mouseover Macro** - *macro if you wish to this macro makes it that if you target an enemy you purge if you target an ally you dispel. Save a keybind*

```wow-macro
/use [@mouseover, help, nodead] Purify Spirit; [harm] Purge; [noharm] Purify Spirit
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Restoration Shaman**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/RshamanGuideMidnigthMplusupdated-1024x475.png>)

**Restoration Shaman** Interface in Mythic+

:::accordion
:::details Addons
- **BigWigs** -- BossMods Addon
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **BetterCooldownManager** -- Cooldown Manager and Castbar
  
  - A cleaner version of the Cooldown Manager with the option to create extra Frames to track Abilities, Racials and Items. Also includes a cleaner Castbar and Resource trackers.
- **Unhalted Unit Frames** -- Unitframe Addon
  
  - Addon to replace your Unitframes (Player,Target,Focus,Boss...) with a more clean look.
  
  
  
  - Alternatively, you can also use BetterBlizzFrames.
- **Plater** *-- Advanced Nameplates* 
  
  - Cleaner and improved Nameplates for both enemy and allied units.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Hero Talents
  
  - Farseer
    
    - Chain Heal from Ancestors now bounces to up to 5 targets (was 3), loses 10% healing per target jump (was 30%), and had its jump distance increased to 20 yards (was 15 yards).
    - **Chain Heal from Ancestors healing increased by 50%.**
  - Totemic
    
    - Pulse Capacitor now increases the healing done by Surging Totem by 10% (was 25%).
    - **Surging Totem now increases the effectiveness of Healing Rain by 10% (was 20%).**
- Restoration
  
  - New Talent: Swelling Tides – Healing Stream Totem and Stormstream Totem extend the duration of your active Riptides by 3 seconds when cast.
  - **Healing Wave healing increased by 10%.**
  - **Unleash Life healing increased by 100%.**
  - **Healing Rain healing increased by 20% and now heals up to 6 targets in its area (was 5).**
  - **Healing Rain now has a 12 second cooldown and an 18 second duration. Recasting Healing Rain while one is already active will despawn the previous one. This cooldown change does not affect the Surging Totem's Healing Rain from the Totemic Hero Talents.**
  - **Riptide direct healing increased by 25% and its periodic healing increased by 100%.**
  - **Acid Rain damage increased by 50%, but now causes damage every 2 seconds (was 1 second).**
  - ***Midnight* Season 1 2-set bonus has been updated – Unleash Life's direct healing is increased by 50% (was 100%).**
  - **Earthen Accord now grants an additive +20% to the healing buff from Unleash Life, rather than a multiplicative increase.**
  - **Current Control now also reduces the mana cost of Chain Heal by 15%.**
  - **Wavespeaker’s Blessing has been moved up in the talent tree.**
  - **Calm Waters has been removed.**
- **Class** 
  
  - **Reactive Warding healing increased by 25%.**
  - **Ascendance has a new icon for all three specializations.**

:::

:::

## FAQ

:::accordion
:::details Q: How do [[spell:974]] and [[spell:1064]] interact?
A: Only the target that has [[spell:974]] receives increased healing regardless whether it's your initial [[spell:1064]] target or the last bounce

:::

:::

---

### Credits

Written By: Cere  
  
Reviewed By: Rycn

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1

**2026-06-17** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-02-21** Updated for patch 12.0.1

**2026-01-17** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-04** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-23** Updated for patch 11.1

**2025-01-05** Updated for patch 11.0.7.

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Guide Written for patch 11.0.2



:::
