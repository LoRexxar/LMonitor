Welcome to the **Discipline Priest** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 4/5 · Strong

Cooldown Strength · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 3/5 · Average

Mobility · 1/5 · Subpar



:::

:::

:::column
:::gear **Discipline Priest** Raid Best in Slot Gear
```json
{
  "source_code": "JQpAICQA3_fABIgJEIIEBAw74OA_sOgF2kjAYFQApfBBAERAAcVrBQBBMWTBUgUwkQgAIUAA1k7ACKgTBcbpDEgxJIBAJkgEwMQ1DEQ4XQAgIEAA8zaBkQQACnQIIthqDkjAOFAGVPQAffBBCgQAA8QAzgDWBEAIoOAhIEAAno6AYAcArB3t1sUABQMJEAACFAggCgVATfBBBAYLEIICBAwL5GQIBsHDBIW2DojEAgxVfQAAIEAAF4BAU1BDE09FNgBFYFQA0LCBBsHAF0weYlAwDQAIBAAdAPAGAPAAAAAAAAwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240892]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240892]] |
| 肩部 | [[item:271553]] | [[item:244021]] |
| 胸部 | [[item:271558]] | [[item:243977]] |
| 腰部 | [[item:268257]] | [[item:240892]] |
| 腿部 | [[item:271554]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:273792]] | [[item:240892]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:244015]] |
| 饰品一 | [[item:270167]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245876]] · [[item:245784]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Discipline Priest**, you have access to Master the Darkness, which makes your penance have a chance to transform your [[spell:17]] into [[spell:1253593]].

**Rank 2** and **Rank 3** both increase your Shadow damage and Atonement healing by 3% each.

**Rank** 4 makes your [[spell:8092]] upgrade your [[spell:17]] to [[spell:1253593]] and [[spell:1253593]] reflect 15% of the absorbed damage.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-discipline-mxr.webp>)

Master of Darkness

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103712]]
    
    - Your penance now also applies a dot.
  - [[talent:103718]]
    
    - Each successive Penance bolts during a channel increases its damage and healing.
- **Removed**
  
  - [[spell:34433]]
    
    - Not an active anymore, which results in less spikey bursts.
  - [[spell:314867]]
    
    - During your cooldowns you wont have acess to a shadow version of penance anymore.

## Hero Talents

:::tabs
:::tab [[talent:123288]]
- Every [[spell:8092]] opens a [[spell:447444]] that does a lot of damage and gives you the following buffs and benefits:
  
  - [[spell:585]] is transformed into [[spell:450405]] and its [[spell:81749]] healing is increased by an additional 100%.
  
  
  
  - [[spell:449880]]
    
    - Increases your [[spell:81749]] healing massively.
  - [[spell:451018]]
    
    - Increased Movement Speed.
  - When [[spell:447444]] ends it collapses and does a lot of damage via [[spell:448403]].

:::

:::tab [[talent:123290]]
- [[talent:123290]] greatly enhances your penance through various nodes:
  
  1. [[talent:117286@FAQAIdhA]]
     
     - Your Penance has 2 charges
  2. [[talent:117276@FAQAIdhA]]
     
     - Increases the first bolt of each Penance.
  3. [[talent:117290]]
     
     - Penance fires extra bolts at an enemy if you heal with it and if you damage with it it fires extra bolts to heal allies.

:::

:::

## Talents

:::tabs
:::tab General Raid Talents
:::talents **Discipline Priest** General Raid Talents
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### When to use this Spec

This is the default loadout going into any boss unless specified otherwise. You have to adjust your class talent tree based on the utility needed for each encounter. To make your life easier, boss-specific talent loadouts are available in the Raids section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

#### Spec Tree

- [[talent:103698]]
  
  - After each [[spell:47540]] your next [[spell:17]] or [[spell:585]] is empowered.

#### Class Tree

- [[spell:109186]]
  
  - The best recovery tool for Discipline Priests, because Flash Heal is your strongest direct heal outside of a friendly Penance. This talent helps significantly with mana management and mobility.
- [[spell:336897]]
  
  - When you cast [[spell:10060]] on an ally, you also gain it.
- [[spell:193063]]
  
  - In combination with [[spell:368276]] and [[spell:109186]], this talent provides a very easily accessible 10% damage reduction to yourself.
- [[talent:103835]]
  
  - Adds a new but weak defensive ability to the Priest class toolkit. However, when combined with [[spell:193063]], it could save your life!

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍[[spell:47540]] damage and healing increased by 20%. Casting ‍[[spell:47540]] reduces the cooldown of ‍[[spell:8092]] by 2 seconds.
- **4-Set:** After casting ‍[[spell:8092]], your next ‍[[spell:17]] or ‍[[spell:1253593]] absorbs 25% more damage.

### Priority List

Only follow this list **outside** of any ramp sequences.

1. Keep [[spell:589]] on your target.
2. Cast [[spell:8092]] on Cooldown.
3. Cast [[spell:47540]] on Cooldown.
4. Cast [[spell:1253593]] if at 2 stacks.
5. Cast [[spell:194509]] at 2 stacks.
6. Cast [[spell:585]].

### Cooldowns

Showcases of all the different cooldown sequences used by **Discipline Priests** in Raids.

#### Evangelism

:::rotation **Discipline Priest** evangelism ramp in raiding
```json
{
  "source_code": "IUEUJIUTCAAAAgQbhlmb0FWauBgQNgAABEADClNITEACMKwDCPAAAIQz3LAAAIAnfAAAAIAt5CAAAI0pebAAAAAACdq3GA"
}
```
1. [[spell:589]] maintain
2. [[spell:2061]]
3. [[spell:1253593]]
4. [[spell:246287]]
5. [[spell:194509]]
6. [[spell:8092]]
7. [[spell:47540]]
8. [[spell:450215]]
9. [[spell:450215]]
:::

#### Ultimate Penitence

:::rotation **Discipline Priest** ultimate penitence sequence in raiding
```json
{
  "source_code": "IkDEHIUDIAQABwgQNfvABgAnCw5HAAAAC0kbGAAAClNITAAAKkmbgQHalBSYpJHACQbuAAAACdq3GA"
}
```
1. [[spell:2061]]
2. [[spell:194509]]
3. [[spell:8092]]
4. [[spell:421453]]
5. [[spell:1253593]] in the air
6. [[spell:47540]]
7. [[spell:450215]]
:::

- **Make sure to target an enemy when casting this!**

## Deep Dive

#### Optimize using Power Word: Radiance

- Unless you consider your Raid's positioning in spread fights, you can't consistently achieve your 18-20 Atonement count. A simple way to increase your chance of having a higher Atonement count for your Ramps is to cast a [[spell:194509]] on a ranged player and another on a melee player. It is inadvisable to cast [[spell:194509]] on classes like Mages or Hunters, as they tend to be away from the raid, causing your [[spell:194509]] to not spread to 5 people.

#### Min maxing Power Infusion

- While [[spell:10060]] is **your** spell, the optimal usage is to disregard yourself and instead fully focus on your teammates. To achieve that, you need to see your party members' offensive cooldown uptime. It is recommended to simply communicate with them and ask for them to request at the exact time they want it!

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

:::tabs
:::tab Nek'Zali
:::talents **Discipline Priest** Nek'Zali talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- Dispel people affected with [[spell:1287322]] at the edge of the room!
- Do not be inbetween the boss and the tank when the boss casts [[spell:1284103]].

:::

:::tab Entombed Sentinels
:::talents **Discipline Priest** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- Dispel players affected with [[spell:1284471]].
- [[spell:1284590]] is neutralized harmlessly upon reaching exactly 4 stacks.

:::

:::tab Lost Explorers
:::talents **Discipline Priest** Lost Explorers talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- Dispel people affected with [[spell:1286921]].

:::

:::tab Vashnik
:::talents **Discipline Priest** Vashnik talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- External players affected with [[spell:1295224]]. While affected, they are immune to your regular healing.
- Use a personal defensive when affected by [[spell:1294994]].

:::

:::tab Sszorak
:::talents **Discipline Priest** Sszorak talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- External people with [[spell:1286987]].

:::

:::tab Twin Fangs
:::talents **Discipline Priest** Twin Fangs talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- Use a personal defensive when affected by [[spell:1290809]].

:::

:::tab Coiled Altar
:::talents **Discipline Priest** Coiled Altar talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.

:::

:::tab Ula'tek
:::talents **Discipline Priest** Ula'tek talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.

:::

:::tab Nymrissa Wavecaller
:::talents **Discipline Priest** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsMmxyMjBz8AmhZbmZmZmZAAAAAAAAAAYMWmBzMzwMjZgZamYwMDACgZb22AjNDAAjZmZMYGMzATwA"
}
```
:::

### Boss Tips

- Use a personal defensive when many [[spell:1257717]] get popped.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Discipline Priest**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Discipline Priest** Stat Priorities in Raid
```json
{
  "source_code": "IoAJFUAJxACKBQwABA"
}
```
**智力 ＞ 急速 ≫ 精通 ≥ 暴击 ＞ 全能**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- All secondary stats are affected by **diminishing returns**. [Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to learn more!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful Leech is for a Healer: Breakdown of Mythic Vorasius

![](<https://assets-ng.maxroll.gg/wordpress/6o58gMo-1024x362.png>)

Warcraftlogs

## Gear

:::tabs
:::tab Best in Slot
Due to the way stat weights work for **Discipline Priests**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@BARAAAQAWYTOCgVA]] | Ula'tek |
| Neck | [[item:268265@BERAAAQAX16wPrDj1kjAYFA]] | Ula'tek |
| Shoulder | [[item:239031@AgQAAIoAOFA]] (Catalyze to Tier) | Temple |
| Cloak | [[item:268253@BgQAAAQACKAWBA]] | Coiled Altar |
| Chest | [[item:251139@AgQAAIoAOFA]] (Catalyze to Tier) | Murder Row |
| Wrist | [[item:239648@FiQAAAQAno6gBwD_sO3WzSB]] | Crafting |
| Gloves | [[item:271556@BgQAAAQACKAWBA]] | Tier/Catalyst |
| Belt | [[item:268257@BiQAAAQA8z6IoAOF]] | Crafting |
| Legs | [[item:251160@AgQAAIoAOFA]] (Catalyze to Tier) | Den of Nalorakk |
| Boots | [[item:268255@DgQAAAQAPk7IoAYF]] | Coiled Altar |
| Ring 1 | [[item:273792@DiQAAAQAvk7wPrjgC4UA]] | Altar of Fangs |
| Ring 2 | [[item:252258@DiQAAAQAvk7wPrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270164@BgQAAAQA5IgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAAQA5IgTBA]] | Nymrissa |
| Weapon | [[item:271092@DgQAAAQAFk7IoAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FASAAAQA0B8gBwDAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Mythic+ from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251232@AgQAAIoABFA]] | Voidscar Arena |
| Neck | [[item:251173@AgQAAIoABFA]] | Den of Nalorakk |
| Shoulder | [[item:239031@AgQAA8rBBFA]] | Temple |
| Cloak | [[item:251190@AgQAAIoABFA]] | Blinding Vale |
| Chest | [[item:251139@AgQAAIoABFA]] | Murder Row |
| Wrist | [[item:251127@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:159247@AgQAAIoABFA]] | Temple |
| Belt | [[item:193691@AgQAAIoABFA]] | Ruby Life Pools |
| Legs | [[item:251160@AgQAAIoABFA]] | Den of Nalorakk |
| Boots | [[item:251219@AgQAAIoABFA]] | Voidscar Arena |
| Ring 1 | [[item:252258@DiQAAkGAvk7wPrjgCEUA]] | Voidscar Arena |
| Ring 2 | [[item:273792@DiQAAAQAvk7wPrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | Blinding Vale |
| Trinket 2 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Two-Hand Weapon | [[item:159636@AgQAAIoABFA]] | Tempel |
| One-Hand Weapon | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:251191@AgQAAIoABFA]] | Blinding Vale |

:::

:::

### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on each boss fight.

| Rank |  |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A-Tier** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:239664@BiQAAEQA6z6IyLdE]]
  
  - Very overtuned stat stick.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241288]]
  - [[item:241300]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAEEAaB]]
- **Sockets**
  
  - [[item:240892]]
  
  
  
  - [[item:240967]] *--* *Unique, use one of each gem colour to enhance your Eversong Diamond.*
    
    - [[item:240900]]
    - [[item:240916]]
    - [[item:240906]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@BAAAAEQA]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAEQA]] |
| Belt | [[item:275707@BAAAAEQA]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:244015@BAAAAAQA]] |
| Ring 2 | [[item:244015@BAAAAAQA]] |
| Weapon | [[item:243973@BAAAAAQA]] |

:::

:::column
:::gear **Discipline Priest** Enchantments
```json
{
  "source_code": "IQFZBEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAAT0AEoMRuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243987]] |  |
| 戒指二 | [[item:243987]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAEQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Discipline Priest** in Mythic Raiding, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:69070]] *-- Goblin* 
  
  - Jump forward, can be cast while falling or being knocked.
- [[spell:256948]] *--* *Void elf* 
  
  - Spawn a shadow traveling into your facing direction, activate again to teleport to it.
  - Maximum range of 100 yards.

### Recommendation:

It is highly recommended to play a Dracthyr! **Priests** can be pretty slow-moving, and the double jump extra mobility really helps in those sticky situations.

## Macros

Discover recommended macros for **Discipline Priest** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this Discipline Priest Raid Guide are available as mouseover macros for your convenience!

[[spell:47540]]

```wow-macro
/cast [@mouseover, help] Penance; Penance
```

[[spell:17]]

```wow-macro
/cast [@mouseover, help] Power Word: Shield; Power Word: Shield
```

[[spell:194509]]

```wow-macro
/cast [@mouseover, help] Power Word: Radiance; Power Word: Radiance
```

[[spell:139]]

```wow-macro
/cast [@mouseover, help] Renew; Renew
```

[[spell:2061]]

```wow-macro
/cast [@mouseover, help] Flash Heal; Flash Heal
```

[[spell:10060]]

```wow-macro
/cast [@mouseover,exists] Power Infusion; Power Infusion
```

[[spell:73325]]

```wow-macro
/cast [@mouseover, help] Leap of Faith; Leap of Faith
```

[[spell:33206]]

```wow-macro
/cast [@mouseover, help] Pain Suppression; Pain Suppression
```

:::

:::details Recommended Macros
If you press shift while using this macro you get the [[spell:121536]] automatically placed under you, skipping the control click.

```wow-macro
/cast [mod:shift, @player] Angelic Feather; Angelic Feather
```

Replace your [[spell:527]] macro if you wish. This macro makes it so that if you target an enemy you purge and if you target an ally you dispel, saving you a keybind.

```wow-macro
#showtooltip Purify
/use [@mouseover, help] Purify; [harm] Dispel Magic; [noharm] Purify
```

Your [[spell:32375]] instantly goes off when you press the button without having to confirm click, use with caution.

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

A nice little Priest only macro, if you know you know.

```wow-macro
/cast [nomod] Levitate
/cancelaura [mod:shift] Levitate
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Discipline Priest**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/e3V7I8v-1024x576.webp>)

**Discipline Priest** Raid

:::accordion
:::details Addons
- EllesmereUI -- Everything
  
  - Addon to upgrade Blizzards very own UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Discipline
  
  - Developers' notes: For Discipline in Curse of Ula'tek, our changes are aimed at reducing the spec's reliance on procs for effective healing, improving sources of consistent damage, and improving Hero talent balance. We felt the spec was too reliant on Shadow Mend and Void Shield procs for effective healing, so we're updating Shadow Mend to be a passive upgrade to Flash Heal and adding a deterministic way to gain access to Void Shield. Additionally, Smite contributes a low amount of damage despite being frequently cast, so we're increasing its damage and updating the talent tree for easier access to Greater Smite.
- New Talent: Grim Deliverance – Shadow Mend heals for 30% more and applies Atonement for an additional 4 seconds, but its cast time is increased by 0.5 seconds.
- Shadow Mend's chance to trigger is no longer based on Shadow Word: Pain damage and has been redesigned to a passive upgrade – Flash Heal is upgraded to Shadow Mend, a stronger heal with a higher mana cost.
- Apex Talent: Master the Darkness (Rank 3) has been updated – Mind Blast now upgrades your next Power Word: Shield to Void Shield. Void Shield's chance to trigger from Penance reduced to 15% (was 33%). Void Shield absorption reduced by 28%.
- Apex Talent: Master the Darkness can now accumulate up to 2 charges.
- All healing and absorption increased by 10%.
- Atonement heals for 32% of damage done (was 30%).
- Flash Heal healing increased by 25%.
- Smite damage increased by 40%.
- Inescapable Torment damage reduced by 30%.
- Penance no longer applies Atonement when cast on an ally.
  
  - *Developers' notes: We updated Penance to apply Atonement going into Midnight but have felt this has not been playing well as it causes too much friction between casting Penance on allies that need healing, allies that need Atonement applied, and enemies you want to deal damage to.*
- Ultimate Penitence damage and healing increased by 30%.
- Greater Smite duration increased to 4 seconds (was 2 seconds) and is now a 1-point talent.
- Hero Talents
  
  - Oracle
    
    - Unfolding Vision has been redesigned – When Power Word: Shield or Void Shield expires with absorption remaining, it jumps to a nearby injured ally instead. Can only happen once per shield.
  - Voidweaver
    
    - Void Blast damage increased by 25%.
    - Voidwraith damage increased by 30%.
    - Void Infusion now increases Atonement healing from Void Blast and Penance by 75% while Entropic Rift is active (was 50%).

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:33206]] as your own defensive cooldown.

:::

:::details Q: Why do I keep running out of mana?
A: You are missing to many global cooldowns, and don't have enough [[spell:314867]] uptime.

:::

:::

---

### Credits

Written By: **Rycn**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-07** Guide updated for patch 12.1

**2026-06-19** Guide updated for patch 12.0.7

**2026-05-01** Guide updated for patch 12.0.5

**2026-01-18** Guide updated for patch 12.0

**2025-10-07** Guide updated for patch 11.2.5

**2025-07-28** Guide updated for patch 11.2

**2025-06-18** Guide updated for patch 11.1.7

**2025-04-19** Guide updated for patch 11.1.5

**2025-02-24** Guide updated for patch 11.1

**2024-12-17** Guide updated for patch 11.0.7

**2024-10-20** Guide updated for patch 11.0.5

**2024-08-17** Guide Written for patch 11.0.2



:::
