欢迎使用《魔兽世界》12.1版本的**毁灭 术士** 大秘境攻略！本攻略涵盖了你了解自己角色所需的一切知识！如果你刚起步，正在从80级开始练级？快去看看练级攻略吧！

## 概述

:::columns
:::column
:::rating 大秘境
**单体** · 3/5 · 中等

范围伤害 · 4/5 · 强势

功能性 · 3/5 · 中等

生存能力 · 4/5 · 强势

机动性 · 2/5 · 较弱



:::

:::

:::column
:::gear **毁灭 术士** 大秘境 最佳配装
```json
{
  "source_code": "JkoAwX3CBc__BEgAmQggUEAAnk7AH16AYxYNCKAWBEQ6XQAAREAA6z6A6z6ACKAj1gVABgLJEIACFAwF5OggC4UA3W6AB0LJEIACBAQC5OQcj4UABECqDQICBAwJqOgHAPADtOwt1sUABkLJEIACBAQBqOggC4UAB89FF8AApEQRMgVABAiLzAAB8zaCzgxukQAAIUAABkIQTfBBBw9FEIICBAQ94OgEtOQA7xQAeqmANIBAC0gEYcW0DAACBAQBegAVfQQFMQQ3X0ADogVABQvIEIACBAwPNsHKleBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240967]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240890]] |
| 肩部 | [[item:271544]] | [[item:243991]] |
| 胸部 | [[item:271549]] | [[item:243977]] |
| 腰部 | [[item:239649]] | [[item:240908]] · [[item:240167]] · [[item:245790]] |
| 腿部 | [[item:271545]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:240167]] · [[item:245790]] |
| 手部 | [[item:271547]] |  |
| 戒指一 | [[item:268252]] | [[item:240914]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**巅峰天赋** 是 至暗之夜 中的一项新功能，是各专精天赋树的延伸。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为**毁灭 术士**，你可以使用**尼希尔姆余烬**，它使你的[[spell:29722]]有几率触发[[spell:1265884]]，对目标10码范围内的所有敌人造成范围伤害 影焰伤害。

**等级2** 使你的 **爆击** 和 **急速** 提升数秒，每当 [[spell:1265884]] 造成伤害时触发。而 **等级3** 使 [[talent:136835]]、[[talent:91592]] 和 [[talent:91582]] 能够以 50-60% 的效果触发 [[spell:1265884]]。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-destruction-mxr.webp>)

尼希尔姆余烬

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:91588]]
    
    - 从使目标受到多种法术伤害增加的减益效果改为[[talent:91591@FAQA28vA]]伤害放大器，同时让你在使用[[talent:91591@FAQA28vA]]时将[[spell:348]]扩散到附近的目标身上。
  - [[talent:91582]]
    
    - 从旧版本[[spell:295422]]（可随时使用，并在斩杀阶段提供一些收益）改为仅在斩杀期可用的法术，除非改动后的[[talent:126004]]触发。
  - [[talent:91474]]
    
    - 由[[spell:387569]]改动而来。
  - [[talent:126493]]
    
    - 你的[[spell:152108]]的新强化。
  - [[talent:91489]]
    
    - 将你的[[talent:91502]]变为1分30秒的冷却时间！
  
  
  
  - [[talent:136833]]
    
    - 现在由你的[[talent:134221]]或[[talent:128600]]召唤。
  - [[talent:128600]]
    
    - 现在只是一个被动天赋，可由使用[[talent:136835]]或[[talent:91582]]触发。
  - [[talent:128599]]
    
    - 被移到了顶点天赋类别，并失去了其潜在的[[spell:456946]]强化。
- **职业天赋树**
  
  - [[talent:136100]]
    
    - 一个出色的天赋，可以一次性对一群敌人施加[[spell:702]]、[[spell:334275]]或[[spell:1714]]。
  - [[talent:136101]]
    
    - 更多的[[talent:91466]]机动性！
  - [[talent:136108]] / [[talent:136738]]
    
    - 强大的新范围伤害诅咒，可以降低多个敌人的攻击速度或施法速度。
  - [[talent:136104]]
    
    - [[spell:40671]]的直接替代品。
- **已移除**
  
  - [[spell:215941]]
    
    - 这导致可用的[[spell:246985]]变少，同时你的[[spell:246985]]资源获取的随机性也降低了。
  - [[spell:196414]]
    
    - 现在[[talent:136835]]可以更自由地施放了。无需监控任何受影响的减益效果！
  
  
  
  - [[spell:387156]] / [[spell:387165]]
    
    - 这是对我们[[spell:246985]]生成的又一次打击，同时由于现在只与[[talent:134221]]或[[talent:128600]]配合，[[talent:136833]]的出现频率也会降低。

## 英雄天赋

- [[talent:123385]] 和 [[talent:123382]] 在单体目标上都可以使用，而 [[talent:123382]] 在总体上造成更多的范围伤害伤害。[[talent:123382]] 擅长应对分散的顺劈场面，而 [[talent:123385]] 拥有大量被动范围伤害，并且由于 [[talent:117452]] 能造成更多优先级伤害。

:::tabs
:::tab [[talent:123385]]
- 消耗一个 [[spell:246985]] 会开启 3 种不同 [[talent:117452]] 之一的循环。
  
  1. [[spell:431944]]
  2. [[spell:432815]]
  3. [[spell:432816]]
  4. 重新从第 1 步开始。

- 每个 [[spell:116858]]、[[spell:5740]] 或 [[talent:91582]] 的施放会使活跃的 [[talent:117452]] 的持续时间基准减少 1 秒。你的 [[talent:117452]] 减少 **1** 额外 1 秒——当你因 [[talent:117453]] 施放 [[spell:116858]] 时，以及若你已点出 [[talent:118838]] 天赋且 [[talent:91502]] 处于激活状态时再减少 1 秒。

- 同一时间只能存在 1 个 [[talent:117452]]，每个在其结束后会转变为相应的 **恶魔之艺**，该效果在你施放下一个 [[spell:116858]]、[[spell:5740]] 或 [[talent:91582]] 后触发：
  
  - [[spell:428524]]
    
    - 一只 **邪能领主** 扑向你的目标并施加 [[spell:434424]]，持续 15 秒。
  - [[spell:432794]]
    
    - 对你的目标造成伤害，并将你的下一个 [[spell:29722]] 变为 [[spell:434506]]，生成 2 个 [[spell:246985]]。
  - [[spell:432795]]
    
    - 召唤一个 **深渊领主**，使用 [[spell:434404]] 攻击你的目标，并将你的下一个 [[spell:116858]] 变为 [[spell:434635]]，造成大量 范围伤害 伤害。
- 此外，每当 **恶魔之艺** 处于激活状态时，你的下一个 [[spell:116858]]、[[spell:5740]] 或 [[talent:91582]] 将受益于 [[talent:117453]]。
- 你的 [[talent:91502]] 通过 [[talent:117428]] 得到进一步强化。
- [[talent:136092]]
  
  - 在消耗 [[spell:428524]]、[[spell:432794]] 或 [[spell:432795]] 时造成被动 范围伤害 伤害。
- [[talent:136091]]
  
  - 在消耗 [[spell:428524]]、[[spell:432794]] 或 [[spell:432795]] 时造成额外的单体伤害。
- [[talent:136090]]
  
  - 每当你消耗 [[spell:428524]]、[[spell:432794]] 或 [[spell:432795]] 时，每消耗一个 [[talent:136092]] 获得 2% 智力，最多叠加至 6%，持续 10 秒。

:::

:::tab [[talent:123382]]
- 你的 [[spell:348]] 会变为 [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]。
- [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] 没有施法时间，也没有 **面向**要求。
- 你可以使用一个冷却时间为 1 分钟的技能，名为 [[spell:442726]]。

- [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]可以叠加层数，并与不同天赋有多种巧妙的互动，这些天赋可以增加其叠加层数或带来其他收益。
  
  - 在伤害法术上消耗[[spell:246985]]会使[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]的层数增加1，并且由于[[talent:117434]]和[[talent:123310]]，有机会额外获得一层。
  - 施放[[spell:442726]]会使所有激活的[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]层数增加3，同时在其持续时间内，每层[[spell:116858]]、[[talent:91582]]或[[talent:91592]]会额外增加1层。
  
  
  
  - [[talent:117441]]使[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]在造成暴击时有几率增加一层。
  - 每当[[talent:117434]]造成伤害时，即使你当前没有点出[[talent:91485]]天赋，你也有机会通过[[spell:440055@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]获得[[talent:91485]]的层数。
- [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]有一个内置机制，会依次消耗其积累的层数以造成更多伤害。这个机制被称为 **堕落**.
  
  - 的 **堕落** [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] 的状态由以下条件触发： 
    
    - [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]每次获得一层时都有几率触发。
    - 如果[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]达到8层。
    - 如果[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]所在的目标生命值降至20%或已低于20%。
    - 当[[spell:442726]]生效时。
- [[talent:136095]]
  
  - 被动提高混乱之箭和火焰之雨的伤害，在[[spell:442726]]期间效果翻倍。
- [[talent:136094]]
  
  - [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]有几率赋予你8秒的[[spell:442726]]。
- [[talent:136093]]
  
  - [[spell:442726]]在使用时会提供更多急速，并使[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]的叠加层数额外增加2层。

:::

:::

## 天赋

:::tabs
:::tab [[talent:123385]]
:::talents [[talent:123385]] **毁灭 术士** 大秘境 专精
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCmZGzssMamZYbYZ2aswAAAjBDAwMzMDGzYMbAAAmZmZAAYGG",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCmZGzssMamZYbYZ2aswAAAjBDAwMzMDGzYMbAAAmZmZAAYGG"
}
```
:::

### 何时使用该专精

你可以在所有等级的 大秘境 中使用这个专精。[[talent:123385]] 尤其擅长优先级伤害，同时还能被动地对敌人进行顺劈。即使在大规模拉怪中，将 [[spell:246985]] 用于 [[spell:116858]] 而不是 [[talent:91592]] 通常也更有利，可以更快地击杀高血量的敌人。

[[spell:152108]] 和 [[talent:91591@FAQA28vA]] 配合 [[talent:91588]] 可以帮助你对多个敌人施加 [[spell:348]]。

### 改变游戏玩法的天赋

探索专精天赋树和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若想了解更多细节，请查看下方的循环和 **深入解析** 部分。

#### 专精树

- [[spell:205184]]
  
  - 在本补丁中得到了重做，它不再是一个减益效果，而是仅提高你的 [[talent:91591@FAQA28vA]] 伤害，并在使用时扩散 [[spell:348]]。
- [[spell:152108]]
  
  - 另一种造成即时伤害并同时刷新 [[spell:348]] 的方式，如果选择了相应天赋还会留下 [[talent:126493]]。
- [[talent:91494]]
  
  - 被动地施加 [[talent:91493]]，帮助你生成更多 [[spell:246985]]，同时提供被动顺劈。
- [[spell:1122]]
  
  - 你的爆发期主要冷却技能，它会受到 [[talent:126494]] 和 [[talent:91489]] 的强化。

#### 职业树

- [[talent:91439]]
  
  - 用于快速恢复宠物，无论是当前宠物死亡还是你被复活后。可以免去 [[spell:246985]] 的消耗，并大幅缩短召唤宠物的施法时间。
- [[talent:91460]]
  
  - 可开关的移动速度提升，使用时每秒消耗生命值。
- [[talent:91452]]
  
  - 冷却时间很短的快速自我治疗。可被 [[talent:136105]] 进一步强化。
- [[talent:91444]]
  
  - 以生命值为代价为你提供一个大型吸收护盾。生命值消耗会被 [[talent:91446]] 降低。你还可以将 [[talent:91446]] 换成 [[talent:91445]]，以获得更多潜在的 [[talent:91444]] 使用机会。
- [[talent:91466]]
  
  - 使你每 90 秒能够移动一段更远的距离。如果选择了 [[talent:136101]] 天赋，则可以使用两次。
- [[talent:91457]]
  
  - 范围伤害 用来控制一群敌人。
  - 与 [[talent:91458@FAQAvH2E]] 处于二选一节点，根据地下城或拉怪数量的不同，后者可能更有收益。
- [[talent:91469]]
  
  - 强化多个实用技能，主要与 [[spell:48020]]、[[spell:6262]]、[[spell:111771]] 和 [[spell:234153]] 配合使用。
- [[talent:91434]]
  
  - 对生存能力至关重要，因为它将你的 [[spell:6262]] 变为 [[spell:452930]]，后者在每场战斗中可以使用多次。
- [[talent:136738]] 或 [[talent:136108]]，取决于你正在对抗的首领。[[talent:136108]] 可以作为你的坦克的防御冷却技能。[[talent:136738]] 对于延缓重要的施法非常有益。

### 英雄天赋

- [[talent:118838]]
  
  - 表现优于[[talent:117445]]。
- [[talent:117449]]
  
  - 在[[spell:104773]]期间能恢复可观的生命值。
  - 适合与[[talent:91467]]搭配，以更频繁地使用。
- [[talent:117433]]
  
  - 增强你的[[spell:48020]]。
  - 如果你玩[[talent:91458@FAQAvH2E]]，可换成[[talent:118837]]以更频繁地干扰敌人。

:::

:::tab [[talent:123382]]
:::talents [[talent:123382]] **毁灭 术士** 大秘境 专精
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

### 何时使用该专精

如果你主要想造成大量 范围伤害 伤害，请使用这套专精。大规模 范围伤害 伤害潜力远高于 [[talent:123385]]。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 英雄天赋

**已将** [[talent:123385]] 更改为 [[talent:123382]]，欲了解更多信息请访问上方的 **英雄天赋** 部分。

- [[talent:117419]]
  
  - 合并你的 [[spell:702]] 和 [[spell:1714]]。
- [[talent:123310]] 
  
  - 表现优于 [[talent:117451]]。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** ‍[[spell:29722]] 伤害提高25%，并且[[spell:29722]]有10%的额外几率召唤一个 ‍[[spell:1265884]]。
- **4件套：** 被 ‍[[spell:1265884]] 伤害的目标在6秒内受到你的法术和技能的伤害提高6%。

### 单体目标

:::tabs
:::tab [[talent:123385]]
### 起手爆发

- 你的目标是在不浪费资源的前提下，尽可能多地消耗[[spell:246985]]，同时让相关技能保持在冷却中。

:::rotation [[talent:123385]] **毁灭 术士** 在 大秘境 中的单体开局
```json
{
  "source_code": "IIHTKIELSJAAAcAUyVGc1xGbAIkKGBQABggQiRQAHAxABgorDEQCgIEXQBAAAEgAOngDIoHyBUgFR4CKJT8AAAgA-MDgBIUCbQAQCEAIMAgQaQXCIQieIHAAAAAACpBd"
}
```
1. [[spell:152108]] 战前准备
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:116858]]
5. [[spell:17962]]
6. [[spell:246985]] >3 
   
   1. [[spell:116858]]  
      
      随后回到主循环
7. 
8. [[spell:29722]]
9. [[spell:116858]]
10. [[spell:29722]]
:::

- 始终施放 [[spell:348]]，除非它已经由 [[spell:6353]] 或 [[spell:152108]] 施加。
- 在使用[[spell:1122]]之后，使用你的主动饰品[[item:241288]]以及种族技能如[[spell:20572]]或[[spell:26297]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 保持目标身上的[[spell:348]]。
2. 如果[[spell:434636]]已激活，则施放[[spell:434635]]。
3. 如果[[spell:246985]]即将达到上限，则施放[[spell:116858]]。
4. 如果你的[[spell:246985]]低于3点且[[spell:433891]]已激活，则施放[[spell:434506]]。
5. 如果你有3层叠加或正在移动，则施放[[spell:17962]]。
6. 施放[[spell:17962]]以产生[[spell:246985]]。
7. 施放[[spell:29722]]以产生[[spell:246985]]。

:::

:::tab [[talent:123382]]
### 起手爆发

- 你的目标是在不浪费资源的前提下，尽可能多地消耗[[spell:246985]]，同时让相关技能保持在冷却中。

:::rotation [[talent:123382]] **毁灭 术士**在大秘境中的单体起手式
```json
{
  "source_code": "JoHTLIELSJAAAcAUyVGc1xGbAIkKGBQABggQiRQAHAxABgorDEQCgIEXQBAAAEgAOngDIYWwGUgFIoHyBUACRYDKJT8AAAgA-MDgBIUCbQAQCEAIMAgQaQXCIQieIHAAAAAACpBd"
}
```
1. [[spell:152108]] 战前准备
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:442726]]
5. [[spell:116858]]
6. [[spell:17962]]
7. [[spell:246985]] >3 
   
   1. [[spell:116858]]  
      
      随后回到主循环
8. 
9. [[spell:29722]]
10. [[spell:116858]]
11. [[spell:29722]]
:::

- 始终施放 [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]，除非它已经被 [[spell:6353]] 或 [[spell:152108]] 施加过。
- 在使用[[spell:1122]]之后，使用你的主动饰品[[item:241288]]以及种族技能如[[spell:20572]]或[[spell:26297]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 保持目标身上的[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]。
   
   - 施放[[spell:152108]]以维持[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]。
2. 如果[[spell:246985]]即将达到上限，则施放[[spell:116858]]。
3. 当你有3层堆叠时施放[[spell:17962]]。
4. 施放[[spell:17962]]以产生[[spell:246985]]。
5. 施放[[spell:29722]]以产生[[spell:246985]]。

:::

:::

### 范围伤害

:::tabs
:::tab [[talent:123385]]
### 起手爆发

- 这套开场会根据你的 [[spell:246985]] 产生情况而有很大变化。下面是在 4 个目标上的一种**可能**开场变化，前提是你使用推荐的 [[talent:123385]] **天赋** **专精**。

:::rotation [[talent:123385]]**毁灭 在 术士** 中的 范围伤害 开场
```json
{
  "source_code": "JAHqMIELSJAAAcAUyVGc1xGbAIgKGBAAAIgYEAAADEAiuOAAAAAACwFUAEgAOnAD8wmFAAAAClMxDAAAC4zMAGQBRQAQCEAKQAgQwlTABkQDFBAbBsCOCoiRAAAACwmFAAAACwmF"
}
```
1. [[spell:152108]] 战前准备
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:5740]]
5. [[spell:246985]] >3 
   
   1. [[spell:5740]]  
      
      随后回到主循环
6. 
7. [[spell:80240]]
8. [[spell:17962]]
9. [[spell:5740]]
10. [[spell:17962]]
11. [[spell:5740]]
12. [[spell:5740]]
:::

- 始终施放 [[spell:348]]，除非它已经由 [[spell:6353]] 或 [[spell:152108]] 施加。
- 在使用 [[spell:1122]] 之后，使用你的主动饰品、[[item:241288]]，以及像 [[spell:20572]] 或 [[spell:26297]] 这样的种族技能。

### 优先级列表

- 对持续时间超过 9 秒的目标保持 [[spell:348]]。
- 对次要目标施放 [[spell:80240]]。
- 如果你即将达到 [[spell:246985]] 上限，施放 [[spell:116858]] 或 [[spell:5740]]。
- 在冷却完毕时施放 [[spell:152108]]。
- 如果已选择该天赋，施放 [[talent:128599]]。
- 当你有3层堆叠时施放[[spell:17962]]。
- 施放[[spell:17962]]以产生[[spell:246985]]。
- 施放 [[spell:29722]] 以生成 [[spell:246985]]

:::

:::tab [[talent:123382]]
### 起手爆发

- 这套开场连招会因你的[[spell:246985]]生成情况而有很大变化。下面展示的是在 4 个目标情况下**其中一种**开场变体，前提是你使用推荐的[[talent:123382]] **天赋配装**。

:::rotation [[talent:123382]] **毁灭 术士** 范围伤害开场连招（大秘境）
```json
{
  "source_code": "JYHqNIELSJAAAcAUyVGc1xGbAIgKGBAAAIgYEAAADEAiuOAAAAAACwFUAEgAOXADMIkZBbQBUwDbWAAAAIUyEPAAAIgPzAYAFEBBAJQAcgBACAXOBAAANsEBsZRADRjKGBAAAIAbWAAAAIAbWA"
}
```
1. [[spell:152108]] 战前准备
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:442726]]
5. [[spell:5740]]
6. [[spell:246985]] >3 
   
   1. [[spell:5740]]  
      
      随后回到主循环
7. 
8. [[spell:80240]]
9. [[spell:17962]]
10. [[spell:5740]]
11. [[spell:17962]]
12. [[spell:5740]]
13. [[spell:5740]]
:::

- 始终施放 [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]，除非它已经被 [[spell:6353]] 或 [[spell:152108]] 施加过。
- 在使用[[spell:1122]]之后，使用你的主动饰品[[item:241288]]以及种族技能如[[spell:20572]]或[[spell:26297]]。

### 优先级列表

1. 对持续超过9秒的目标保持[[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]]。
2. 对次要目标施放 [[spell:80240]]。
3. 如果你即将达到 [[spell:246985]] 上限，施放 [[spell:116858]] 或 [[spell:5740]]。
4. 在冷却完毕时施放 [[spell:152108]]。
5. 施放[[talent:128599]]。
6. 当你有3层堆叠时施放[[spell:17962]]。
7. 施放[[spell:17962]]以产生[[spell:246985]]。
8. 施放 [[spell:29722]] 以生成 [[spell:246985]]

:::

:::

## 深入解析

### 我的灵魂碎片是如何运作的？

作为一名**毁灭 术士**，你的[[spell:246985]]与痛苦或恶魔学识不同。你每次施法不会生成 1 个完整的[[spell:246985]]，而是生成灵魂石碎片。

10 个灵魂石碎片组成 1 个完整的[[spell:246985]]，而你的所有法术会生成不同数量的灵魂石碎片，这还会受到潜在的暴击的影响。

- [[spell:348]]
  
  - 每次周期性伤害跳动时产生1个灵魂碎片残片，并有50%的几率在爆击时额外产生1个。
- [[spell:29722]]
  
  - 基础情况下产生2个灵魂碎片残片，且在爆击时额外产生1个。搭配[[talent:91481]]
- [[spell:17962]]
  
  - 可产生额外的碎片。产生5个灵魂碎片残片。
- [[talent:134221]]
  
  - 产生1个完整的[[spell:246985]]。
- [[talent:136833]]
  
  - 在8秒内每秒产生1个灵魂碎片残片。
- [[talent:91502]]
  
  - 在30秒内每秒产生1个灵魂碎片残片。
  - 作为[[talent:123385]]，它会在30秒后因[[talent:117428]]分裂成2个较小的地狱火，后者还会继续产生灵魂碎片残片，持续另外10秒。
- *[[talent:91493]] / [[talent:91494]]
  
  - 严格来说它们并不是产生源，而是在成功复制时增强[[spell:29722]]、[[spell:17962]]和[[talent:134221]]，使产生的灵魂碎片残片数量翻倍，即使受影响的[[talent:91493]]目标处于免疫状态也是如此。

### 最大化你的 浩劫

要在 [[spell:80240]] 激活期间最大化你的伤害，你需要尽可能多地把施法次数用于 [[spell:116858]] 或 [[spell:5740]]。为此，你应该在进入 [[spell:80240]] 窗口期时尽量满足以下条件：

- [[spell:246985]] 或 [[spell:246985]] 的资源收入较高。
- [[spell:17962]] 应接近最大层数。
- 刷新 [[spell:348]] / [[talent:117437@FAQAWdhA]]，以免它们在你的 [[spell:80240]] 窗口期内掉落。

下面是一个示例，展示了当你正确管理 [[spell:80240]] 窗口期时会发生什么。

:::rotation [[talent:123382]] **毁灭 术士** 浩劫 窗口期（团队副本）
```json
{
  "source_code": "IYZAA_gARjBAIQVYydWZ0BSMAIEHMbQRCgAptEgVXIwi7JQB0LwgJOwzoJAINcgINcQCCgQDrQkMAIkYEAAAAAgACwFUAEgAOPQANwgQmFsBBgAICAXOBAAACoiRBECB6hsPMAABaQXAY4iHAgjeIHAAAIgG0BAAAIgeIHA"
}
```
1. [[spell:6353]] 目标 1
2. [[spell:445468]] 目标 2
3. [[spell:1122]]  [[spell:20572]] · [[item:249346]]
4. [[spell:442726]]
5. [[spell:80240]]
6. [[spell:17962]]
7. [[spell:116858]]
8. [[spell:17962]]
9. [[spell:116858]]
10. [[spell:29722]]
11. [[spell:17962]]
12. [[spell:116858]]
13. [[spell:116858]]
14. [[spell:29722]]
15. [[spell:116858]]
:::

- **这不是一个固定的循环**；这只是如何在 [[spell:80240]] 窗口期内进行操作的一个示例。**暴击**、[[talent:126494]] 地狱火和 [[talent:91494@FAQAymeB]] 触发都可以增加你的 [[spell:246985]] 产生量，使你能够把更多 [[spell:246985]] 用于 [[spell:116858]] 或 [[spell:5740]]。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

**← 向下滚动查看更多副本 →**

:::tabs
:::tab 毒牙祭坛
:::talents **毁灭 术士** 大秘境 配置于 毒牙祭坛
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 纳洛拉克的洞穴
:::talents **毁灭 术士** 大秘境 配置于 纳洛拉克的洞穴
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 密谋小径
:::talents **毁灭 术士** 大秘境 配置于 密谋小径
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 夺目谷
:::talents **毁灭 术士** 大秘境 配置于 夺目谷
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 虚空之痕竞技场
:::talents **毁灭 术士** 大秘境 配置于 虚空之痕竞技场
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 诸王之眠
:::talents **毁灭 术士** 大秘境 配置于诸王之眠
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 红玉新生法池
:::talents **毁灭 术士** 大秘境 配置于 红玉新生法池
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::tab 塞塔里斯神庙
:::talents **毁灭 术士** 大秘境 配置于 塞塔里斯神庙
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

:::

:::

### 词缀

词缀系统在进入 **地心之战第一赛季** 时得到了重做，退役了大多数词缀，同时引入了新的有利有弊型词缀，并改变了这些词缀出现的钥石等级。

- +2词缀
  
  - 林多尔米的指引
- +5 词缀——每周轮换
  
  - 萨拉塔斯的交易：升腾
  - 萨拉塔斯的交易：虚空之缚
  
  
  
  - 萨拉塔斯的交易：吞噬
  - 萨拉塔斯的交易：脉冲星
- +6词缀
  
  - 移除林多尔米的指引。
- +7 词缀——每周交替出现
  
  - 残暴
  - 强韧
- +10 词缀 *——两个词缀同时存在。*
  
  - 残暴
  - 强韧
- +12词缀
  
  - 萨拉塔斯的诡计 *——替换+5词缀*

以下是作为 **毁灭 术士** 应对不同 大秘境 词缀的一些实用技巧。

- 萨拉塔斯的契约：晋升者
  
  - 对尽可能多的法球使用 [[talent:91452]]。
- 萨拉塔斯的契约：虚空缚束
  
  - 将你所有的伤害集中在 **虚空大使** 上！
- 萨拉塔斯的契约：吞噬
  
  - 这会对你施加一个大型治疗吸收效果。你可以使用你的 **小鬼** 的 [[spell:119905]] 来驱散自己。
- 萨拉塔斯的契约：脉冲星
  
  - 收集其他小队成员周围环绕的脉冲星！

## 属性优先级

了解你作为 **毁灭 术士** 在 大秘境 地城中获得最佳表现所需的次要属性优先级和第三属性。有关更详细的信息，请访问 **[属性与特征](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **毁灭 术士** 大秘境 属性优先级
```json
{
  "source_code": "HoAJFUAJgEDKBEwABA"
}
```
**智力 ＞ 急速 ＞ 暴击 ≥ 精通 ＞ 全能**
:::

:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **Avoidance -** 降低“范围伤害”技能伤害承受的优秀属性。
- **Leech -** 通过造成伤害提供额外治疗。你的宠物所造成的伤害治疗术，因此**Leech** 对你来说是一个极佳的第三属性，因为你的大部分伤害来自于你自己的法术。
- **Speed -**  较为小众的第三属性，但在特定情况下可能非常有用，过去也已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271874@DSRAAsQAnk7cUrDWMWjgCgVA]] | 乌拉特克 |
| 颈部 | [[item:268265@BERAAsQA6z6oPrjgCwYNYFA]] | 乌拉特克 |
| 肩部 | 将 [[item:239031@AgQAAIoAOFA]] 转化为 [[item:271544@DgQBAsQAXk7IoAOFwtlO]] | 塞塔里斯神庙 催化剂 |
| 披风 | [[item:268253@BgQAAsQACKAWBA]] | 盘卷祭坛 |
| 胸部 | [[item:271549@DgQAAsQAJk7E3IOF]] | 瓦什尼克 |
| 护腕 | [[item:239648@FiQAAsQAno64BwD_sO3WzSB]] | 制造业 |
| 手套 | 将 [[item:268243@AgQAAIoAYFA]] 转化为 [[item:271547@BgQBAsQACKAWBM9FEA]] | 盘卷祭坛 催化剂 |
| 腰带 | [[item:239649@FiQAAsQAno64BwDDtO3WzSB]] | 制造业 |
| 腿部 | [[item:271545@DgQAAsQAFo6IoAOF]] | 斯索拉克 |
| 靴子 | [[item:268255@DgQAAsQApk7IoAYF]] | 盘卷祭坛 |
| 戒指 1 | [[item:268252@DiQAAsQA1j7IRrjgC4UA]] | 斯索拉克 |
| 戒指 2 | [[item:158366@DiQAAsQA1j7IQrjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:250215@BgQAAsQACKgTBA]] | 密谋小径 |
| 饰品 2 | [[item:270164@BgQAAsQACKgTBA]] | 迷失的探险者 |
| 武器 | [[item:271092@DgQAAsQA_k7IoAYF]] | 乌拉特克 |
| 副手 | [[item:268197@BgQAAsQACKgTBA]] | 陵寝哨兵 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251199@BgQAAsQAxNSQBA]] | 夺目谷 |
| 颈部 | [[item:251234@BgQAAsQAxNSQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:239031@BgQAAsQAxNSQBA]] | 塞塔里斯神庙 |
| 披风 | [[item:193763@BgQAAsQA1NSQBA]] | 红玉新生法池 |
| 胸部 | [[item:239032@BgQAAsQA1NSQBA]] | 塞塔里斯神庙 |
| 护腕 | [[item:251154@BgQAAsQA1NSQBA]] | 纳洛拉克的洞穴 |
| 手套 | [[item:273773@BgQAAsQA1NSQBA]] | 毒牙祭坛 |
| 腰带 | [[item:251222@BgQAAsQA1NSQBA]] | 虚空之痕竞技场 |
| 腿部 | [[item:193750@BgQAAsQA1NSQBA]] | 红玉新生法池 |
| 靴子 | [[item:159259@BgQAAsQA5NSQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251136@BgQAAsQA1NSQBA]] | 密谋小径 |
| 戒指 2 | [[item:158366@BgQAAsQACKQQBA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:250215@BgQAAsQACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250214@BgQAAsQA1NSQBA]] | 夺目谷 |
| 武器 | [[item:160216@BgQAAsQA1NSQBA]] | 诸王之眠 |
| 副手 | [[item:273779@BgQAAsQA1NSQBA]] | 毒牙祭坛 |
| 双手 | [[item:193761@BgQAAsQA1NSQBA]] | 红玉新生法池 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:250215@BgQAAcEACKgTBA]]  <br>[[item:270164@BgQAAcEACKgTBA]]  <br>[[item:270161@BgQAAcEACKgTBA]]  <br>[[item:270167@BgQAAcEACKgTBA]] |
| **A级** | [[item:273796@BgQAAcEACKgTBA]]  <br>[[item:273649@BgQAAcEACKgTBA]]  <br>[[item:270169@BgQAAcEACKAWBA]]  <br>[[item:270168@BgQAAcEACKAWBA]] |
| **B级** | [[item:273794@BgQAAcEACKgTBA]]  <br>[[item:270170@BgQAAcEACKgTBA]]  <br>[[item:250214@BgQAAcEACKgTBA]]  <br>[[item:250259@BgQAAcEACKgTBA]]  <br>[[item:250224@BgQAAcEACKgTBA]] |
| **C级** | [[item:248583@BgQAAcEA0MSQBA]]  <br>[[item:274493@BgQAAcEA0MSQBA]]  <br>[[item:251792@BgQAAcEA0MSQBA]] |
| **垃圾级** | [[item:158368@BgQAAcEACKgTBA]]  <br>[[item:193757@BgQAAcEACKgTBA]] |

### 美化饰品

- 1x [[item:245875]]
  
  - 只能制作在你的主手或副手武器上。建议制作在主手/双手武器上，以便在初期获得更强力量。
- 1x [[item:240167]]
  
  - 最佳制作部位是**护腕**、**披风**、**靴子**或**腰带**，具体取决于你现有的装备。

或

- 2x [[item:240167]]
  
  - 最佳制作部位是**护腕**、**披风**、**靴子**或**腰带**，具体取决于你现有的装备。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **合剂**
  
  - [[item:241326]] *-- 最大化DPS。*
  
  
  
  - [[item:241320]] *-- DPS略低但生存能力更强。*
- **食物**
  
  - [[item:266996]]
  - [[item:242744]]
  - [[item:266985]]
- **战斗药水**
  
  - [[item:241309]]
- **治疗药水**
  
  - [[item:271884]] -- 一次大量爆发治疗
- 武器油
  
  - [[item:243734]] *-- 默认选择*
  - [[item:243738]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240967]] *-- 唯一*
    
    - [[item:240890]]
    - [[item:240898]]
    - [[item:240900]]
    - [[item:240906]]
    - [[item:240914]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@BAAAAsQA]]  <br>[[item:244007@BAAAAsQA]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAsQA]] |
| 胸部 | [[item:243977@BAAAAsQA]] |
| 护腕 | [[item:275707@BAAAAsQA]] |
| 腰部 | [[item:275707@BAAAAsQA]] |
| 腿部 | [[item:240133@BAAAAsQA]] |
| 靴子 | [[item:244009@BAAAAsQA]] |
| 戒指 1 | [[item:243957@BAAAAsQA]] |
| 戒指 2 | [[item:243957@BAAAAsQA]] |
| 武器 | [[item:244031@BAAAAsQA]] |

:::

:::column
:::gear **毁灭 术士** 团本中的附魔
```json
{
  "source_code": "JQFZLEQ9NCQAnk7ACAAAAsPNEEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYgS94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:244007]] | [[item:275707]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAsQA]]，为你的 **头盔**、**护腕** 和 **腰带** 添加插槽。

## 种族

对于追求 大秘境 中 **毁灭 术士** 极限优化的玩家来说，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族也同样可行。

- [[spell:65116]] -- 矮人
  
  - 无论目前还是历史上，都是大秘境中最强大的种族天赋之一。
  - 驱散魔法和流血负面效果。
- [[spell:58984]] -- 暗夜精灵
  
  - 同样也是历史上大秘境中最强大的种族天赋之一。
  - 使用场景
    
    - 跑过几乎任何怪物，然后施放 [[spell:58984]] 让它们重置。即使是对具有潜行侦测能力的怪物，只要你在 [[spell:58984]] 之前拉开足够的距离，也同样有效。
- [[spell:33702]] -- 兽人
  
  - 强大的输出种族天赋，得益于 [[spell:21563]] 以及与 [[spell:33702]] 相契合的 [[spell:1122]]。
  
  
  
  - 使你受到的眩晕持续时间缩短20%，在某些大秘境地下城中可能很有用。
- [[spell:20589]] -- 侏儒
  
  - 使自己从定身效果中解脱。
- [[spell:69070]] -- 地精
  
  - 朝角色面朝的方向进行一次小跳跃。
  - 在 [[spell:69070]] 动画期间，你会处于公共冷却状态，直到角色落地。
- [[spell:26297]] -- 巨魔
  
  - 强大的DPS种族天赋，但与 [[talent:91502]] 的契合度较差。
  - 使移动限制效果的持续时间缩短20%。

### 推荐

**矮人** 和 **暗夜精灵** 的种族技能对你的 大秘境 体验影响极大，如果你是认真想要用你的 **毁灭 术士** 冲击高层钥匙的玩家，就必须选择其中之一。

## 宏

了解 **毁灭 术士** 在 大秘境 地城中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:152108]]** -- *无需确认，直接在你的鼠标指针位置施放 [[spell:152108]]。*

```wow-macro
#showtooltip
/cast [@cursor] 大灾变
```

**[[spell:1122]]** - *在鼠标指针位置直接施放 [[spell:1122]]，无需选择目标区域。在 [[spell:196447]] 正在施放时无法使用。*

```wow-macro
#showtooltip
/cast [@cursor, nochanneling: Channel Demonfire] 召唤地狱火
```

**[[spell:5740]]** -- *施放 [[spell:5740]] 时无需确认点击，这可以为你节省宝贵时间，并提高你的 火焰之雨 每秒施法次数。*

```wow-macro
#showtooltip
/cast [@cursor] 火焰之雨
```

**[[spell:30283]]** -- *在鼠标光标位置施放[[spell:30283]]，无需确认。*

```wow-macro
#showtooltip
/cast [@cursor] 暗影之怒
```

:::

:::details 鼠标指向宏
**[[spell:348]]** -- *对鼠标悬停目标或当前目标施放 [[spell:348]]。*

```wow-macro
#showtooltip 献祭
/cast [@mouseover,exists] 献祭;献祭
```

**[[spell:80240]]** -- *如果鼠标悬停目标存在、未死亡且为敌对，则对其施放 [[spell:80240]]，否则对当前目标施放 浩劫*。

```wow-macro
#showtooltip
/cast [@mouseover,exists,nodead,harm] 浩劫;浩劫
```

**[[spell:702]]** -- *对鼠标悬停目标或当前目标使用* [*wow-spell id=702]虚弱诅咒[/wow-spell]。*

```wow-macro
#showtooltip 虚弱诅咒
/cast [known:328774] 诅咒增幅
/cast [@mouseover, exists, harm, nodead] 虚弱诅咒; 虚弱诅咒
```

**[[spell:1714]]** -- *对鼠标悬停目标或当前目标使用 [[spell:1714]]。。*

```wow-macro
#showtooltip 语言诅咒
/cast [known:328774] 诅咒增幅
/cast [@mouseover, exists, harm, nodead] 语言诅咒; 语言诅咒
```

**[[spell:334275]]** -- *对鼠标悬停目标或当前目标使用 [[spell:29539]]。*

```wow-macro
#showtooltip 疲劳诅咒
/cast [@mouseover, exists, harm, nodead] 疲劳诅咒;[@target] 疲劳诅咒
```

**[[spell:234153]]** -- *对你的鼠标指向目标或当前目标施放 [[spell:234153]]。*

```wow-macro
#showtooltip
/cast [@mouseover,exists] 吸取生命;吸取生命
```

**[[spell:710]]** -- *若鼠标指向目标存在，则对其施放 [[spell:710]]。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] 放逐术; [harm,nodead] 放逐术
```

:::

:::details 宠物宏
> 我们主要为宠物使用自定义宏，因为过去 [[spell:119898]] 的常规功能被证明并不可靠。

**宠物技能1宏** -- *施放你的主宠物技能，对每个宠物均作用于*你鼠标指向的目标。

```wow-macro
/cast [@mouseover]烧灼驱魔
/cast [@mouseover,exists] 法术封锁;法术封锁
/cast [@mouseover]受难
/cast [@mouseover,exists]魅惑;魅惑
/cast [@mouseover,exists]利斧投掷;利斧投掷
/cast [nopet,@mouseover,exists]恶魔掌控;[nopet]恶魔掌控
```

**焦点目标宠物技能** **1 宏** -- *为你的每只宠物对其焦点目标施放主要宠物技能。*

```wow-macro
/cast [@focus] 烧灼驱魔
/cast [@focus] 法术封锁
/cast [@focus] 受难
/cast [@focus] 魅惑
/cast [@focus] 利斧投掷
/cast [nopet,@focus] 恶魔掌控
```

**宠物技能** **2 宏** *-- 在需要时对你的鼠标指向目标施放第二个相关宠物技能。*

```wow-macro
/cast [@mouseover] 烧灼驱魔
/cast [@mouseover,exists] 吞噬魔法;吞噬魔法
/cast 暗影壁垒
/cast 魔刃风暴 
/cast [nopet,@mouseover] 恶魔掌控
```

**焦点宠物 技能** **2 宏** -- *对焦点目标施放第二个相关宠物技能，同时命令你的宠物攻击焦点目标。*

```wow-macro
/cast [@focus]烧灼驱魔;
/cast [@focus] 吞噬魔法;
/cast [@focus] 次级隐形术;
/cast 暗影壁垒;
/cast [nopet,@focus] 恶魔掌控
/petattack [@focus]
```

**[[spell:108503]] 与解散宠物** -- *如果你点出了该天赋，则施放 [[spell:108503]]。如果你没有天赋《牺牲魔典》，则会改为解散你的宠物。*

```wow-macro
#showtooltip
/run if not IsSpellKnown(108503) then PetDismiss(); end
/cast 牺牲魔典
```

:::

:::details 实用 宏
**[[spell:20707]]** 鼠标悬停 -- *对鼠标悬停目标施放 [[spell:20707]]。传统的 [@mouseover,exists] 宏在之前的一段时间里已失效，这是一个替代方案。*

```wow-macro
#showtooltip 灵魂石 
/target [@mouseover,help] 
/cast 灵魂石 
/targetlasttarget
```

**[[spell:5697]]** 自我施法 *-- 在不选定任何目标的情况下对自己施放[[spell:5697]]。当你暂时无法对任何目标进行输出时，依然可以用它来刷取饰品的触发/层数，非常实用。*

```wow-macro
#showtooltip
/cast [@player] 无尽呼吸
```

**[[talent:91457]] / [[spell:5484]]** 二选一 *-- 根据所选择的天赋，在[[talent:91457]]**和[[spell:5484]]之间自动切换。你也可以为其添加自己的宏条件，例如 @focus 或 @mouseover 等。*

```wow-macro
/cast [known:暗影之怒] 暗影之怒
/cast [known:恐惧嚎叫] 恐惧嚎叫
```

:::

:::

## 插件

下方是作者的**毁灭 术士**用户界面截图，展示了在大秘境地下城中使用了哪些插件以及如何使用它们来让你的游戏体验更加轻松。

![Destruction Warlock Mythic+ User Interface](<https://assets-ng.maxroll.gg/wordpress/xerwomythicplusui-midnight-mxr-1024x617.webp>)

大秘境 用户界面

:::accordion
:::details 插件
- **Unhalted Unit Frames** *-- 用户界面替换* 
  
  - 添加可高度自定义的玩家、目标和首领框体。
- **BetterCooldownManager** -- 冷却管理器增强
  
  - 为你的冷却管理器添加额外的自定义选项，同时提供资源等额外信息。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些小型插件旨在为特定的 团队副本 战斗触发警报消息、计时条、音效等。
- **Plater**  -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的负面效果监控、仇恨着色，并支持自定义脚本。
- **Details** -- 深度伤害统计
  
  - 最强大、最可靠、最漂亮的伤害统计插件。
- **RaidframeSettings** -- 小队/团队框体增强
  
  - 为默认的小队和团队框体添加额外的自定义选项。
- **LeatrixPlus** -- 生活质量与地图插件
  
  - 添加大量提升游戏体验的选项，以及更流畅的小地图等众多功能。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
- 术士
  
  - 吸取生命 的生命吸取量提高25%。
  - 泽夫里姆的韧性造成的治疗量提高25%。
  - 召唤恶魔传送门现在在冷却管理器中默认被归类为实用技能。
  - 修复了若干技能无法给予灵魂榨取的问题：枯萎
    
    - 黑化灵魂
    - 狱火箭
    - 灵魂诅咒
    - 邪恶收割
    - 毁灭化身的混乱之箭
    - 痛苦无常
    - 邪恶攫取
    - 邪恶恶魔犬的头部撞击和胆汁喷吐
    - 阴郁猎犬的阴郁斩击
    - 野生小鬼和小鬼帮主头的邪恶火焰箭
    - 小鬼领主的强力邪能箭
    - 恶魔守卫暴君的恶魔之火
  - 修复了若干技能错误地给予灵魂榨取的问题：军团打击
    
    - 狡诈残忍
    - 引导恶魔之火
  - 英雄天赋
    
    - **[[talent:123382]]**
      
      - *开发者注：我们正在更新黑化灵魂，为地狱召唤者提供一个更好的工具，将伤害集中于优先目标，从而提升英雄天赋树的整体灵活性，而不是仅在多目标场合表现出色。不过，我们将保持怨毒的功能不变，因此它仍然是地狱召唤者技能池中一个酷炫且具有影响力的工具。*
      - 黑化灵魂已被重新设计——如果目标身上带有你的枯萎，你的混乱之箭和暗影灼烧会使其层数增加1。每当枯萎获得一层时，都有几率发生崩塌，每1秒消耗一层，对其宿主造成暗焰伤害，直到只剩1层。黑化灵魂伤害提高45%。
      - 佩罗萨恩的印记已被重新设计——枯萎造成的伤害性爆击造成215%伤害，而非通常的200%。黑化灵魂造成的伤害性爆击造成225%伤害，而非通常的200%。
      - 枯萎伤害提高25%。
  - 痛苦
    
    - 新天赋：饕餮贪食——使吸取生命伤害提高10%，并且生命虹吸现在额外使腐蚀的伤害提高10%。黑暗收割的引导速度加快10%，伤害提高15%。
    - 新天赋：暴怒之殇——暗影箭、灵魂吸取和邪恶攫取的伤害提高10%，如果目标受到鬼影缠身影响，则提高20%。如果目标受到鬼影缠身影响，黑暗收割的伤害提高10%或20%。
    - 碎片不稳已被重新设计——暗影箭或灵魂吸取造成的伤害有20%的几率使你的下一个痛苦无常或腐蚀之种不消耗灵魂碎片并立即施放。
    - 鬼影缠身现在使你对目标造成的伤害提高16%，持续18秒（原为12%）。
    - 以下天赋已被移除：夜阑收益
      
      - 开发者注：夜阑收益在术士如何使用其夜幕方面并没有提供太多选择。无论目标数量多少，通常最好将其用于腐蚀之种。这可能会对那些受益于暗影箭或灵魂吸取的天赋产生不利影响。不过我们喜欢偶尔获得免费腐蚀之种的感觉，因此将这一功能合并到了碎片不稳中。作为夜阑收益的替代，我们引入了一个名为暴怒之殇的新天赋，作为痛苦获得额外优先伤害的另一种手段。
    - 零号病人
      
      - 开发者注：零号病人严重扭曲了腐蚀之种的伤害形态。腐蚀之种作为工具的具体用途是在多目标场合提供伤害，而能够提高优先伤害的能力稀释了它的特性定位。饕餮贪食是一个新天赋，与吸取生命、生命虹吸和黑暗收割之间共同的生命偷取主线相呼应。该天赋的意图是让大部分输出体现在生命虹吸和黑暗收割上，而对吸取生命的提升则较小，只是作为一点风味。
  - 恶魔学识
    
    - 暗影箭伤害提高45%。
    - 恶魔螺栓伤害提高55%。
    - 召唤阴郁猎犬的伤害提高35%。
    - **英雄天赋**
      
      - **[[talent:123385]]**
        
        - 混乱齐射伤害降低20%。
        - 求邪无止伤害降低20%。
        - 邪恶劈砍伤害降低20%。
        - 眼球爆炸伤害降低20%。
        - 克索诺斯之焰现在使火焰和你的恶魔造成的伤害提高3%（原为4%）。
  - 毁灭
    
    - 混乱之火已被重新设计——燃烧和暗影灼烧有100%的几率造成爆击，且其伤害会根据你的爆击几率而提高。
    - 所有伤害提高4.5%。
    - 灵魂之火伤害提高45%。
    - 混乱之箭伤害提高5%。
    - 浩劫现在使法术对被标记目标造成其50%的伤害（原为60%）。
    - 顶尖天赋：尼希拉姆余烬（等级1）的工具提示已更新，向玩家显示烧尽引发萨格拉斯的回响的百分比几率。
    - 暗影灼烧已作为可追踪的增益效果添加到冷却管理器中。
    - 混乱之火已从冷却管理器中移除。

:::

:::details 补丁12.0.1
- 术士
  
  - 英雄天赋
    
    - [[talent:123385]]
      
      - [[spell:434506]]伤害提高150%。
      - [[spell:434635]]伤害提高50%。此改动不影响PvP战斗。
    - [[talent:123382]]
      
      - [[spell:442726]]伤害提高230%。
      - 毁灭
        
        - [[talent:117434]]伤害提高20%。
        - [[talent:117437@FAQAWdhA]]伤害提高25%。
        - [[talent:136095]]现在使[[talent:136835]]伤害提高10%（原为8%），[[talent:91592]]伤害提高8%（原为4%）。
  
  
  
  - 毁灭
    
    - [[spell:29722]]伤害提高50%。
    - [[talent:91591]]伤害提高40%。此改动不影响PvP战斗。
    - [[talent:136835]]伤害提高10%。此改动不影响PvP战斗。
    - [[spell:434587]]伤害提高50%。
    - [[talent:134221@FAQAZwsB]]伤害提高40%。

:::

:::details 补丁12.0
- 术士
  
  - 英雄天赋
    
    - **[[talent:123385]]**
      
      - 新天赋：[[talent:136092]] – 每当 [[talent:117452]] 的持续时间被你的一个法术缩短时，你召唤一个恶魔之眼，最多3个。[[talent:136092]] 在消耗恶魔艺术时爆炸，对目标8码范围内的所有敌人造成 火焰 伤害。对超过8个目标之外的伤害降低。
      - 新天赋：[[talent:136091]] – 你的 [[talent:136092]] 现在在激活期间每1秒对主要目标的目标施放恶魔凝视。
      - 新天赋：[[talent:136090]] – 你的 [[talent:136092]] 观察战场并收集信息，在爆炸时传递给你，每个 [[talent:136092]] 使你的智力提高2%，持续10秒。
      - [[talent:117453]] 现在使 [[talent:136835]]、[[talent:91592]] 或 [[talent:91582]] 的伤害提高20%（原为100%）。
      - 眼球爆炸伤害降低30%。此改动不影响PvP战斗。
    - **[[talent:123382]]**
      
      - 新天赋：[[talent:136095]]
        
        - 毁灭：使 [[talent:136835]] 的伤害提高8%，[[talent:91592]] 提高4%。在 [[spell:442726]] 激活期间此效果翻倍。
    - 新天赋：[[talent:136094]] – [[talent:117437@FAQAWdhA]] 造成的周期性伤害有几率使你获得 [[spell:442726]]，持续8秒。
    - 新天赋：[[talent:136093]] – [[spell:442726]] 额外给予4% 急速 ，并且施放时使激活的 [[talent:117437@FAQAWdhA]] 的层数额外增加2层。
    - [[talent:117434]] 伤害提高30%。
    - [[talent:117437@FAQAWdhA]] 伤害提高20%。
  
  
  
  - 职业
    
    - 新天赋：[[talent:136107]] – 使目标的移动速度降低50%，持续12秒。
    - 新天赋：[[talent:136106]] – 强迫目标使用恶魔语说话，使所有法术的施法时间增加30%，持续1分钟。
    - 新天赋：[[talent:136108]] – 召唤一团令人窒息的暗影迷雾，笼罩目标及10码范围内的所有敌人，使其攻击间隔延长100%，爆击几率降低10%，持续12秒。
    - 新天赋：[[talent:136738]] – 召唤一团令人窒息的暗影迷雾，笼罩目标及10码范围内的所有敌人，使其所有法术的施法时间延长100%，持续12秒。
    - 新天赋：[[talent:136105]] – 使 [[talent:91452]] 的范围扩大10码，治疗量提高5%。
    - 新天赋：[[talent:136104]] – [[spell:234153]] 产生的治疗也会以400%的效果治疗你的主要恶魔。
    - 新天赋：[[talent:136100]] – 施放 [[talent:136107]]、[[talent:136106]] 或 [[spell:702]] 现在会诅咒目标10码范围内的所有敌人。
    - 新天赋：生命共享 – 吸取生命 产生的治疗也会以100%的效果治疗你的主要恶魔。
      
      - 作者注：该天赋已不存在。
    - 新天赋：[[talent:91431]] – [[spell:234153]] 现在引导速度加快 50%/100%，恢复生命值的速度加快50%/100%。
      
      - 作者注：此天赋为1点节点。若点出该天赋，[[spell:234153]] 引导速度始终加快100%。
    - 新天赋：[[talent:136101]] – 使 [[talent:91466]] 的施法时间缩短0.5秒，并且你现在可以在触发冷却前使用 [[talent:91466]] 两次。
    - 新天赋：[[talent:136569]] – 使你的 急速 提高3%。
    - 新天赋：[[talent:136568]] – 使你的 爆击几率 提高2%。
    - 新天赋：[[talent:136570]] – 使你的 吸血 提高2%。
    - 新天赋：[[talent:136103]] – 智力提高3%。
    - 新天赋：[[talent:136572]] – [[spell:6262]] 额外恢复5%的生命值。
    - 新天赋：[[talent:136573]] – [[spell:234153]] 现在会根据 700% 所造成伤害进行治疗，并现在赋予等同于所造成伤害10%的 [[talent:91441@FAQAIi1A]]。
      
      - 作者注：[[spell:234153]] 仅根据所造成伤害的200%进行治疗。
    - 新天赋：[[talent:136571]]– [[talent:91441@FAQAIi1A]] 现在赋予护盾，最高可达 15% 你最大生命值的比例。
      
      - 作者注：是5%。
    - 新天赋：[[talent:91451]] – 使 [[talent:91457]] 的冷却时间缩短15秒，并将其范围扩大2码。使 [[talent:91458]] 的冷却时间缩短 10秒 ，并且现在可额外恐惧5个敌人。
      
      - 作者注：[[talent:91458]] 的冷却时间仅缩短了5秒。
    - 许多天赋在天赋树中的位置发生了变化。
    - 已为全部3个专精实装了新的入门构建。
    - 以下天赋已被移除：
      
      - [[spell:339282]]
      - [[spell:328774]]
      - [[spell:386105]]
      - [[spell:264874]]
      - [[spell:386858]]
      - [[spell:452894]]
      - [[spell:274419]]
      - [[spell:1269991]]
      - [[spell:1270032]]
      - [[spell:405936]]
      - [[spell:215941]]
      - [[spell:405955]]
      - [[spell:387972]]
      - [[spell:386864]]
  - 毁灭
    
    - 新天赋：[[spell:1244266]] – 提高 智力 增加2%.
      
      - 作者注：该天赋已不存在。
    - 新天赋：[[talent:134219]] – 提高 精通 提高2%。
    - 新天赋：[[talent:91474]] – 使 [[talent:91493]] 的持续时间延长5秒，并使 [[talent:91493]] 的受创者所受伤害额外提高10%。
    - 新天赋：[[talent:126493@FAQAZwsB]] – [[spell:152108]] 现在会在原地留下一个 [[talent:126493@FAQAZwsB]]，在8秒内对其中的敌人造成 火焰 伤害。[[spell:348]]/[[talent:117437@FAQAWdhA]] 对 [[talent:126493@FAQAZwsB]] 内的敌人造成伤害提高20%。
    - 新天赋：[[talent:91583]] – 使 [[talent:136835]] 的伤害提高5%，且 [[talent:136835]] 现在有25%的几率使你的下一个 [[spell:29722]] 变为瞬发。
    - 新天赋：[[talent:91477]] – 使 [[talent:91592]] 造成伤害的速度提高25%/50%，并使你的 地狱火 的献祭造成伤害的速度提高10%/20%。
    - 新天赋：[[talent:91423]] – [[talent:91592]] 有20%的几率使你下一个 [[talent:91592]] 在8秒内的消耗降低100%。
    - 新天赋：[[talent:91489]] – 使 [[talent:91502]] 的冷却时间缩短30秒，并使你的 精通 提高3%。
    - 新天赋：[[talent:126003@FAQAZwsB]] – [[talent:128599@FAQAZwsB]] 额外发射2支箭。每支箭使命中的所有目标身上的 [[spell:348]] 剩余持续时间延长0.5秒。
    - 新天赋：[[talent:136834]] – 提高你的 爆击几率 的 毁灭 法术伤害提高3%/6%。
    - [[talent:91588]]已被重新设计——使[[talent:91591@FAQA28vA]]的伤害提高10%。[[talent:91591@FAQA28vA]]现在会在目标身上喷发 [[spell:348]]，并扩散至最多3个附近的敌人。
    - [[talent:91582]]已被重新设计——用暗影烈焰伤害轰击一个目标。只能对生命值低于20%的敌人使用。如果目标在5秒内死亡，则恢复1块灵魂碎片[[spell:246985]]。消耗1块[[spell:246985]]。无冷却时间。瞬发。
    - [[talent:91582]]的伤害提高100%。
    - [[talent:126004]]已被重新设计—— 爆击 由 [[talent:136835]]、[[talent:91591@FAQA28vA]] 或 [[spell:29722]] 造成的爆击有10%的几率使你在30秒内施放的下一个 [[talent:91582]] 不消耗 [[spell:246985]]，并且无视目标生命值均可使用。
    - [[talent:136833]]已被重新设计——施放[[talent:134221@FAQAZwsB]]会召唤一只暴怒魔。打开[[talent:128600]]时有几率改为召唤一只暴怒魔。
      
      - 召唤大恶魔：每1秒产生1块灵魂碎片，并以60%的效果对其召唤者目标施放[[talent:136835]]。持续8秒。
    - [[talent:128600]]现在是被动技能，并已被重新设计——[[talent:136835]]和[[talent:91582]]有10%的几率撕裂空间与时间的裂缝，开启一个随机传送门，对你的目标造成伤害。
    - [[talent:91589]]已被更新——使你的 法术的暴击伤害 的 毁灭 法术的伤害提高15%/30%。
    - [[talent:136835]]已被添加到 毁灭 天赋树中（原先在10级时习得）。
    - [[talent:136835]]的伤害降低18%。此改动不影响PvP战斗。
    - [[talent:91591@FAQA28vA]]的伤害降低22%。此改动不影响PvP战斗。
    - [[spell:29722]]的伤害降低10%。此改动不影响PvP战斗。
    - 暴怒魔的伤害提高30%。
    - [[talent:134221@FAQAZwsB]]的伤害提高400%，施法时间现在为3秒（原先为4秒）。
    - [[talent:91500]]现在是一个2点天赋，使你的 爆击几率 提升2%/4%。物理攻击命中你有20%/40%的几率使你的下一个 [[spell:29722]] 即时施法。此效果每6秒只能触发一次。
    - [[talent:91482@FAQAZwsB]] 现在是一个2点天赋，使 [[talent:136835]]、[[talent:91582]] 和 [[spell:29722]] 对受到影响的敌人造成提高3%/6%的伤害，这些目标受到 [[spell:348]]/[[talent:117437@FAQAWdhA]].
    - 许多天赋在天赋树中的位置发生了变化。
    - 以下天赋已被移除：
      
      - [[spell:456939]]
      - [[spell:387153]]
      - [[spell:456985]]
      - [[spell:456946]]
      - [[spell:457025]]
      - [[spell:457114]]
      - [[spell:387165]]
      - [[spell:387279]]
      - [[spell:387095]]
      - [[spell:364433]]
      - [[spell:387569]]

:::

:::

## 常见问题

:::accordion
:::details 问：我该使用哪只宠物？
**答：** 在大多数情况下使用[[spell:691]]。如果你不需要[[spell:132409]]或[[spell:388215]]，则改用[[spell:688]]来获取[[spell:212623]]。

:::

:::details 问：我什么时候应该用[[talent:91494]]而不是[[talent:91493]]？
**A:** 在副本中需要让 [[talent:91493]] 在确切时刻生效时，使用 [[talent:91493]] 会有所帮助。使用 [[talent:91494]] 可获得更高的整体伤害潜力。

:::

:::

---

### 致谢

作者：Xerwo  
  
审校：**Rycn**

:::changelog 更新记录
**2026-07-31** 更新至12.1版本

**2026-06-19** 更新至12.0.7版本。

**2026-04-22** 更新至12.0.5版本。

**2026-04-02** 更新了天赋配置和 embellishments。

**2026-02-05** 更新至12.0.1版本。

**2026-01-17** 更新至12.0版本。

**2025-12-02** 更新至11.2.7版本。

**2025-10-07** 更新至11.2.5版本。

**2025-09-07** 修正了天赋专精建议和说明。

**2025-07-30** 更新至11.2版本

**2025-06-16** 更新至11.1.7版本。

**2025-05-20** 更新了腐蚀和极速冲刺相关内容。

**2025-04-21** 更新至11.1.5版本。

**2025-02-07** 更新至11.1版本。

**2024-12-11** 更新至11.0.7版本。

**2024-10-23** 更新至11.0.5版本。

**2024-10-07** 更新至第一赛季。

**2024-08-17** 更新至11.0.2版本。

**2024-07-29** 攻略撰写于11.0.1前置版本。



:::
