欢迎来到《魔兽世界》12.1版本的**冰霜 死亡骑士** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始练级的新玩家吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体目标** · 3/5 · 一般

范围伤害 · 4/5 · 良好

功能性 · 3/5 · 视战斗而定

生存能力 · 5/5 · 优秀

机动性 · 4/5 · 良好



:::

:::

:::column
:::gear **冰霜** **死亡骑士** 最佳配装
```json
{
  "source_code": "J4oAgvPA3_fABIHJEIICFAwJ5OwVtOQOC4UAdV9ABk-FEAQEBAg-sOg-sOAj1kjAYFQAwRCBCgQBAcRuDEgJUI8FEEQdkUgEAkQASgCWB47FEEw4XQAgIUAOAljAYFQAGYCBCARAAE6uDYhNFEBGkfBBAgQAAEQQsFgChOAhIEAAaA8AiZ9A6z6A3WzSBEwckQAAIUQBhADvXQQAZfBBCCQAAUPuBECHOFQA5Z9ACiQEQUQME01HNIFDYFQAfFAD4MAA5IAWBUAAB0yFCEQ3XkhHgE7FEABCBAAYQXQIAFgqXQAEQEAAOLPAXYTOCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240890]] |
| 肩部 | [[item:271472]] | [[item:243991]] |
| 胸部 | [[item:271477]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240890]] |
| 腿部 | [[item:271878]] | [[item:244641]] |
| 脚部 | [[item:268260]] |  |
| 腕部 | [[item:237834]] | [[item:240890]] · [[item:245786]] · [[item:251490]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:268249]] | [[item:240890]] · [[item:243957]] |
| 戒指二 | [[item:251513]] | [[item:240890]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[spell:53344]] |
| 副手 | [[item:268202]] | [[spell:62158]] |
:::

:::

:::

## 至暗之夜 改动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 一名 **冰霜 死亡骑士**，你可以使用霜巢之眷，它会使[[spell:279302]]造成的伤害提高100%，并给予你15%的急速，持续12秒。

**2级**使[[spell:279302]]延长[[spell:51271]]的持续时间2/4秒，同时使力量[[talent:125875]]给予的数值提高8%，最高总计18%。

**3级** 给予你10%的冰霜被动伤害，并使[[spell:279302]]的伤害提高100%。此外，它还赋予你以50%效果召回[[spell:279302]]的能力。

- 对于[[talent:123324]] 死亡使者，这会给予你一层[[spell:441416]]。
- 对于[[talent:123322]]天启骑士，它会召唤你的天启骑士，持续10秒。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-frostdk-mxr.webp>)

霜巢之眷

:::

:::

### 核心改动

进入至暗之夜后，**冰霜 死亡骑士**由于在《地心之战》11.2版本中经历了重做，几乎没有任何非平衡性方面的改动。在本节中，我们将介绍你需要了解的**冰霜**相关改动。想要更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:96224]] 新增了一个效果，使 [[spell:1228433]] 会消耗 [[spell:50401]] 并对你的目标造成额外300%的伤害。
  - [[talent:125877]] 现在每次自动攻击爆击可使 [[spell:51271]] 的持续时间延长1秒，最多延长4秒。
- **职业天赋树**
  
  - [[talent:136524]]
    
    - 移除了 符文能量 的消耗需求（来自 [[spell:61999]]）！
  
  
  
  - [[talent:136525]]
    
    - 新天赋，可缩短 [[talent:96204]] 的冷却时间，并加快治疗吸收效果的消散速度。
  - [[talent:96187]]
    
    - [[spell:49039]] 不再是一个防御技能，生效期间只提供魅惑、恐惧和睡眠免疫，以及少量 吸血 。
  - 多个天赋的位置进行了调整，总体上更容易点出。

## 英雄天赋

- 作为一名 **冰霜 死亡骑士**，目前两个英雄天赋都可行，你可以根据战斗情况自由选择。[[talent:123322]]天启骑士 在以单体为主的战斗中更强，而 [[talent:123324]]死亡使者 在以范围伤害为核心的战斗中表现更好。



### [[talent:123324]] 死亡使者

##### 输出节点

- [[talent:117659]]
  
  - 爆炸会赋予你 2 层 [[talent:117665]]。
- [[talent:117633]]
  
  - 使你对主要目标造成的暗霜伤害提高最多 12%，对其击中的额外敌人提高最多 6%。
- [[spell:441894]]
  
  - [[talent:117665]]会刷新或施加[[spell:55095]]，并使其伤害更快生效。这在单体目标中极为强大，在范围伤害中甚至更强。
- [[talent:117640]]
  
  - 被 [[spell:59052]] 强化的 [[spell:49184]] 现在对主要目标造成的伤害提高 30%。
- [[talent:117631]] 与 [[talent:128235]] 对比
  
  - 当你按下 [[talent:117659]] 时，[[talent:117631]] 会赋予你一层 [[spell:51128]]，并根据目标已损失的生命值提高 [[talent:117659]] 的伤害
- [[talent:117658]]
  
  - 当 [[talent:117659]] 爆炸时，会对附近的敌人造成伤害。
- [[talent:117629]]
  
  - 一个不错的单体输出提升，会赋予你 力量 如果 [[talent:117659]] 爆炸且没有用 [[talent:117658]] 击中任何其他目标。
  
  
  
  - 使 [[talent:117633]] 在你的主要目标身上的效果提高 100%，如果 [[talent:117633]] 的两次命中都暴击了你的目标，则相当于 20% 的伤害提升。
- [[talent:135992@AJgBBA]]
  
  - 使[[spell:49143]]的伤害提高35%，[[spell:194913]]的伤害提高15%。
  - 当你施放 [[talent:117659]] 时，赋予你 3 层 [[spell:377098]]。
- [[spell:1265855@FJgDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBT3yEGEA]]
  
  - 使 [[talent:117659]] 的伤害提高 5%
  
  
  
  - 施放 [[spell:279302]] 会赋予你 2 层 [[talent:117665@FJQAm4rBGEA]]。

##### 防御节点

- [[talent:135993@AJgBBA]]
  
  - 使[[talent:96195]]的效果提高50%。

##### 输出选择节点

- [[talent:117654]] 对比 [[talent:128266]]
  
  - [[talent:117654]] 在这里永远是赢家，因为额外的 [[spell:194878]] 层数非常出色，可以让 [[spell:51124]] 和 [[spell:435010]] 触发更多。
  - [[talent:128266]] 与我们当前使用的天赋构筑没有任何协同，因为它会让 [[talent:117659]] 与 [[spell:51271]] 脱节。

##### 防御选择节点

- [[talent:117632]] 或 [[talent:123420]]
  
  - [[talent:117632]] 并不是一个值得考虑的天赋，因为它会施加一个随机的治疗吸收效果，在某些情况下可能极其有害。另一方面，[[talent:123420]] 非常强大，因为它是一个基于你使用技能的被动减伤。在你的冷却技能期间，由于你不断刷新它，这基本上相当于 10% 的魔法和物理伤害减免。
- [[talent:117646]] 或 [[talent:128234]]
  
  - [[talent:117646]] 在这里是明确的选择，因为 [[talent:128234]] 在 PvE 内容中真正关键的施法上并不生效。




### [[talent:123322]]天启骑士

##### 输出节点

- [[talent:117663]] - 每消耗一个 符文 ，你有10%的几率召唤下列天启四骑士之一：
  
  - [[spell:444248]]
    
    - 施放一个[[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]]，跟随他持续10秒。
      
      - 站在他的 ‍[[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] 中会使你的伤害和爆击提高5%。
  - [[spell:444251]]
    
    - [[spell:444633]] 是一种持续24秒的疾病，每次你对被感染的目标使用 [[spell:49020]] 或 [[spell:207230]] 时，它会扩散并获得1层。
  
  
  
  - [[spell:444254]]
    
    - 在他的持续时间内反复施放 [[spell:45524]]，该法术会被带有 [[talent:117660]] 的 [[spell:49020]] 或 [[spell:207230]] 打碎。
  - [[spell:444252]]
    
    - 使你的 力量提高5%，在纳兹格里姆激活期间，每消耗一个 符文 额外提高1%。
- [[talent:117638]] 
  
  - 施放 [[talent:125876]] 后召唤全部4名骑士持续20秒。
    
    - 如果已有骑士被召唤出来，则改为将当前持续时间延长20秒。
      
      - [[spell:444248]] 不会重新施放他的 [[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]]，但其他所有骑士都会重新施放他们的技能。
- [[talent:117641@FAQAuchA]]
  
  - 被动提高 [[spell:55095]]、[[spell:49143]] 和 [[spell:1228433]] 的伤害。
- [[talent:117651]]
  
  - 使 [[spell:49020]] 的伤害提高10%，并使 [[spell:196770]] 的持续时间延长2秒。
- [[talent:135999@AJgBBA]]
  
  - [[spell:51271]] 召唤 [[spell:444254]] 持续6秒。
- [[talent:135998@AJgBBA]]
  
  - 当她激活期间，施放 [[spell:49143]] 或 [[spell:207230]] 会命令 [[spell:444254]] 以100%的效果与你一同施放他的 [[spell:49143]] 或 [[spell:207230]]。
  
  
  
  - 如果你在《地心之战》第三赛季玩过[[talent:123322]]骑士 **冰霜** ，这会让你感到熟悉，因为它曾是你套装奖励的一部分。
- [[spell:1265971]]
  
  - 使骑士施放的技能伤害提高5%。

##### 进攻选择节点

- [[talent:117639]] 或 [[talent:123411]]
  
  - [[talent:117639]] 会在消耗 符文能量 时延长你的骑士持续时间，与 [[talent:135999@AJgBBA]] 和 [[talent:135998@AJgBBA]] 有协同效果，但当前使用的构筑与 [[talent:123411]] 有着惊人的协同，可以在爆发期间打出巨大的 [[spell:49143]] 和 [[spell:1228433]]。

##### 防御选择节点

- [[talent:123412]] 或 [[talent:117657]]
  
  - [[talent:117657]] 在团队副本中完全不起作用，所以你总是选择 [[talent:123412]]，这并不是坏事，因为它能大幅提升你的机动性，并允许你解除定身和减速效果。
- [[talent:117634]] 或 [[talent:123410]]
  
  - [[talent:117634]] 取决于 [[spell:48707]] 在战斗中的价值，因为它可能极其强力，让你可以预先免疫负面效果或随机吸收大量魔法伤害。另一方面，[[talent:123410]] 会给予你每名在场骑士 5% 的伤害减免，或在使用 [[talent:117638]] 的冷却期间提供 20% 的伤害减免。由于两者的价值都因情况而异，这里没有固定选择，完全取决于具体战斗。





## 天赋



### [[talent:123322]]Rider   纯单体目标

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 改变游戏玩法的天赋

探索专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行简要概述，如需更详细的了解，请查看下方的**循环和深入解析**章节。

##### 专精树

- [[talent:125874]] 和 [[talent:126017]]
  
  - [[talent:125874]] 是 **冰霜 死亡骑士's** 的主要冷却技能，并且当选择 [[talent:126017]] 天赋时，它会激活（一次免费的）[[spell:196770]]。
    
    - 选择 [[talent:126017]] 天赋会移除你单独施放 [[spell:196770]] 的能力。
- [[talent:96220@FAQAhlvA]]
  
  - 使你在 [[talent:125874]] 期间获得大量 [[spell:51128]] 增益，从而形成一个极高的爆发窗口，因为你可以在 [[talent:125874]] 期间不断地打出被 [[spell:51124]] 强化的巨型 [[spell:49020]]。
- [[talent:96225]] 和 [[talent:133364]]
  
  - 一个 [[spell:51128]] 和 符文能量 生成器，每消耗一个 [[spell:59052]]，[[talent:133364]] 的冷却时间就会缩短 6 秒。
  - 使你的 [[spell:49020]] 在 [[talent:125874]] 期间施放时免费。
- [[talent:96254]]
  
  - 允许你一次消耗 2 层 [[spell:51124]]，从而显著减少触发的浪费。
- [[talent:96248]]
  
  - 朝你面向的方向发出一个 [[spell:194913]]，对击中的所有敌人施加 [[spell:50401]]，并刷新 [[talent:96214]]。
- [[talent:96236]]
  
  - 需要与你的 Apex 天赋 霜巢之眷 并在游玩 [[talent:123322]] 时召唤四骑士骑士.

##### 职业树

- [[talent:96174]]
  
  - 使[[spell:48707]]的冷却时间缩短20秒，并使其持续时间和吸收量提高40%。
- [[talent:96194]]和[[talent:96176]]
  
  - 你的团队冷却技能，持续6秒，使站在其中的任何人所受魔法伤害降低15%。
  
  
  
  - 选择[[spell:374383]]天赋后，冷却时间缩短1分钟，降至3分钟，并且持续时间延长至8秒。
- [[talent:126016]]
  
  - 使你受到的魔法伤害降低5%，并使有害魔法效果的持续时间缩短35%。虽然[[talent:126016]]的魔法伤害减免部分对所有魔法伤害都有效，但有害魔法效果持续时间的缩短对团队副本中绝大多数减益效果都不起作用，否则会破坏太多机制。
- [[talent:126015]]
  
  - 使你的[[spell:48265]]、[[spell:43265]]和[[spell:49576]]额外获得1层充能。
- [[talent:96182]]
  
  - 当生命值低于30%时，使你受到的所有伤害降低35%，包括使你降到30%以下的那部分伤害。例如，如果你受到一次攻击，生命值从60%降到10%，那么使你生命值降到30%以下的那部分伤害将降低35%
- [[talent:96180]]
  
  - 使你身上的所有吸收效果提高30%，这非常强大，因为它能提高[[spell:48707]]和[[spell:17]]等法术以及类似技能的吸收量。

##### 符文熔铸

至暗之夜第二赛季的套装迫使你使用双持才能充分利用该套装。

- [[spell:53344]]
- [[spell:62158]]




### [[talent:123322]]Rider   多目标

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 何时使用该专精

这是在毒噬深渊中，战斗过程中任意时刻存在重要的第二目标时应该使用的构建。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[talent:96239]]

- **移除**
  
  - [[talent:96228]]

##### 符文熔铸

- [[spell:53344]]
- [[spell:62158]]




### [[talent:123324]] 死亡使者   稳定顺劈

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODwMjZMDY2mZmZmZZmZkZMGDjBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODwMjZMDY2mZmZmZZmZkZMGDjBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

#### 何时使用该专精

此构筑仅在存在持续的 范围伤害、且其节奏与你的支柱时机相吻合，并且需要对目标使用 范围伤害 时才应使用。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增**
  
  - [[talent:123324]] 死亡使者
  - [[talent:96239]]

- **移除**
  
  - [[talent:123322]]Rider
  - [[talent:96228]]

##### 符文熔铸

- [[spell:53344]]
- [[spell:62158]]





## 输出循环

### 套装

查看所有[至暗之夜第二赛季套装](<https://maxroll.gg/wow/resources/midnight-season-1-tier-sets>)！

- **2件套**：每次 [[spell:196770]] 对至少1个敌人造成伤害时，获得 [[spell:1297365]]，使攻击速度提高2%，[[spell:435010]] 伤害提高4%，持续10秒，可叠加。
- **4件套**：[[spell:196770]] 造成伤害的频率提高25%，[[spell:1297365]] 的持续时间延长5秒。

### 单体目标



#### [[talent:123322]]骑手

##### 起手爆发

- 在开场阶段，你的目标是在使用[[spell:279302]]后进入[[spell:51271]]，立即召唤你所有的[[talent:117663]]，以充分利用它们被[[spell:51271]]增益的效果。以下是一个示例，展示使用推荐的  **骑士 单目标** 构建时你的开场可以是什么样子。

:::rotation 示例 [[talent:123322]]骑士 **冰霜 死亡骑士** 单体开场
```json
{
  "source_code": "JAbA8sgAAAAAAIgQQnLAAAgQ0ecAGQAf_GAFMQgQHhcAOAieRMBAAEAiuOQAVgUAf9BBBgQAAsPA5IAWBIkBDRAAW5DAOJFAMAgQ3_bBFBgQugGAEEgQJwXC2ZDHAYkMAA"
}
```
1. [[spell:47568]] · [[spell:51124]]
2. [[spell:49020]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:47568]] · [[spell:51124]]
4. [[spell:49020]]  [[spell:47568]] · [[spell:51124]]
5. [[spell:49020]]
6. [[spell:49143]]  [[spell:51124]]
7. [[spell:49020]]  [[spell:47568]]
8. [[spell:49020]]  [[spell:51124]]
9. [[spell:49020]]
10. [[spell:49143]]  [[spell:51124]]
11. [[spell:49020]]
:::

- 由于这只是一个示例，你的开场循环会根据你是否拥有 [[spell:51128]] 而改变，所以不要盲目施放 [[spell:47568]]，除非你的下一次施法没有 [[spell:51128]]！
- 在这个开场之后，你仍然可以用 [[spell:1265384]] 召回 [[spell:279302]]，确保在 [[spell:51271]] 结束之前完成！这还会使你的天启四骑士的持续时间额外延长10秒。
  
  - 它不受公共冷却时间影响，所以你可以随时使用，并且 急速 增益会叠加到前一个的持续时间上。

标准优先级

- 如果你有2层充能，就施放 [[spell:47568]]。
- 施放 [[spell:51271]]。
- 将 [[spell:1249658]] 与 [[spell:51271]] 一起使用。
- 施放 [[spell:279302]]。
  
  - 在15%的 [[spell:1265630]] 增益效果消失后将其召回。
- 在满足以下任一条件时施放 [[spell:49020]]：
  
  - 你有2层 [[spell:51124]]。
  - 你有1层 [[spell:51124]] 并且有3个 符文 ，同时不在 [[spell:51271]] 中。
- 将 [[spell:49184]] 与 [[spell:59052]] 一起使用
- 施放 [[spell:49143]] 以避免 符文能量 溢出，只要你不是在为 [[spell:1249658]] 储存。
- 在 [[spell:51124]] 有1层时施放 [[spell:49020]]。
- 如果没有 [[spell:47568]] 或 [[spell:51124]]，则施放 符文能量.
- 施放 [[spell:49143]]。
- 在没有 [[spell:51124]] 的情况下施放 [[spell:49020]]，同时不在 [[spell:51271]] 中。
- 仅在没有 [[spell:59052]] 的情况下，且在 [[spell:51271]] 期间施放 [[spell:49184]]。
  
  - 这纯粹是为了在 [[spell:51271]] 期间产生一层 [[spell:51124]] **绝不** 在 [[spell:51271]] 之外这样做。




#### [[talent:123324]] 死亡使者

##### 起手爆发

- 在起手阶段，你要尽快进入你的冷却技能爆发。之后你的目标是尽可能多地打出 [[spell:51128]] 强化后的 [[spell:49020]]，并且不要浪费 [[spell:441416]]。下面是一个示例，展示使用推荐的 [[talent:123324]] 死亡使者 **单体** 构建时你的起手可以是什么样的。

:::rotation 示例[[talent:123324]] 死亡使者 **冰霜 死亡骑士** 单体起手
```json
{
  "source_code": "JcaAwjUCCBduAAAAH8kZm1yRDREACNitGAAAAQgQHhMAAAgQ6FxEAAQAI66AAAAAAEwXfQAAIMAA5IAWBUAAB0yFCIkBDRAAAAgACR7xB4COQxrBAAgQ89LAAAAADIE0BkFACZkGAAgAyoBAJ4CAB0AKJ4ACAI09FQEJBIEtHDAAAIEf_C"
}
```
1. [[spell:47568]] 不占公共冷却
2. [[spell:439843]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:51124]] · [[spell:441424]]
4. [[spell:49020]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
5. [[spell:49020]]  [[spell:47568]] · [[spell:51124]]
6. [[spell:49020]]  [[spell:51124]]
7. [[spell:49020]]
8. [[spell:49143]]  [[spell:51124]]
9. [[spell:49020]]
:::

- 由于这只是一个示例，你的开场手法确实会根据你的自动攻击是否触发了 [[spell:51128]] 而改变，所以不要盲目地施放 [[spell:47568]]，除非你的下一次施法没有 [[spell:51128]]！
- 在这套开局手法之后，你仍然可以用 [[spell:1265384]] 召回 [[spell:279302]]，请务必在 [[spell:51271]] 结束之前完成！
  
  - 它不受公共冷却时间影响，所以你可以随时使用，并且 急速 增益会叠加到前一个的持续时间上。

##### 标准优先级

- 如果你有2层充能，就施放 [[spell:47568]]。
- 施放[[spell:439843]]。
- 施放 [[spell:51271]]。
- 将 [[spell:1249658]] 与 [[spell:51271]] 一起使用。
- 施放 [[spell:279302]]。
- 在满足以下任一条件时施放[[spell:49020]]：
  
  - [[spell:441416]]当前可以施放。
    
    - 如果[[spell:439843]]不是你的下一个公共技能，则等待一层[[spell:51128]]。
  - 你拥有 2 层[[spell:51128]]。
  
  
  
  - 你拥有 1 层[[spell:51128]]以及 3 层或更多 符文 ，同时不在 [[spell:51271]] 中。
- 在[[spell:59052]]加持下施放[[spell:49184]]。
- 施放 [[spell:49143]] 以避免 符文能量 溢出，只要你不是在为 [[spell:1249658]] 储存。
- 在 [[spell:51124]] 有1层时施放 [[spell:49020]]。
- 如果没有 [[spell:47568]] 或 [[spell:51124]]，则施放 符文能量.
- 在没有 [[spell:51124]] 的情况下施放 [[spell:49020]]，同时不在 [[spell:51271]] 中。
- 仅在没有 [[spell:59052]] 的情况下，且在 [[spell:51271]] 期间施放 [[spell:49184]]。
  
  - 这纯粹是为了在 [[spell:51271]] 期间产生一层 [[spell:51124]] **绝不** 在 [[spell:51271]] 之外这样做。

##### 说明

- [[talent:123324]] 死亡使者 与 [[spell:1265384]] 的互动值得注意，因为 [[talent:135991@AJgBBA]] 会给你2层 [[spell:441416]]。以 [[spell:439843]] 开始你的冷却技能序列，然后消耗掉 [[spell:441416]]。





### 多目标



#### [[talent:123322]]骑手

##### 起手爆发

- 在开场阶段，你的目标是在使用 [[spell:279302]] 后立即进入 [[spell:51271]]，召唤你所有的 [[talent:117663]]，以充分利用它们被 [[spell:51271]] 增强的效果。下面是一个示例，展示你的开场连招在使用推荐的 [[talent:123322]] 时可以是怎样的 **单体目标** 构建时你的开场可以是什么样子。

:::rotation 示例 [[talent:123322]]骑士 **冰霜 死亡骑士** 多目标起手
```json
{
  "source_code": "JUbA8sgAAAAAAIgQQnLAAAgQ0ecAGQifpMAAAAABCdEyB4AH6FxEAAQAI6aAUwFAB81HEAACDAQOCgVAFAQAtchACZwQEAgVCBgTWBADAIUY5HwcEEgQuwGAEEgQJAYC6ZDHAokMAA"
}
```
1. [[spell:47568]] · [[spell:51124]]
2. [[spell:207230]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:47568]] · [[spell:51124]]
4. [[spell:207230]]  [[spell:47568]] · [[spell:51124]]
5. [[spell:207230]]
6. [[spell:194913]]  [[spell:51124]]
7. [[spell:207230]]  [[spell:47568]]
8. [[spell:207230]]  [[spell:51124]]
9. [[spell:207230]]
10. [[spell:194913]]  [[spell:51124]]
11. [[spell:207230]]
:::

- 由于这只是一个示例，你的开场循环会根据你是否拥有 [[spell:51128]] 而改变，所以不要盲目施放 [[spell:47568]]，除非你的下一次施法没有 [[spell:51128]]！
- 在这个开场之后，你仍然可以用 [[spell:1265384]] 召回 [[spell:279302]]，确保在 [[spell:51271]] 结束之前完成！这还会使你的天启四骑士的持续时间额外延长10秒。
  
  - 它不受公共冷却时间影响，所以你可以随时使用，并且 急速 增益会叠加到前一个的持续时间上。

##### 标准优先级

- 如果你有2层充能，就施放 [[spell:47568]]。
- 施放 [[spell:51271]]。
- 将 [[spell:1249658]] 与 [[spell:51271]] 一起使用。
- 施放 [[spell:279302]]。
  
  - 在15%的 [[spell:1265630]] 增益效果消失后将其召回。
- 在以下任一条件为真时施放 [[spell:207230]]：
  
  - 你有2层 [[spell:51124]]。
  - 你有1层 [[spell:51124]] 并且有3个 符文 ，同时不在 [[spell:51271]] 中。
- 将 [[spell:49184]] 与 [[spell:59052]] 一起使用
- 施放 [[spell:194913]] 以避免溢出 符文能量 溢出，只要你不是在为 [[spell:1249658]] 储存。
- 在拥有1层 [[spell:51124]] 时施放 [[spell:207230]]。
- 如果没有 [[spell:47568]] 或 [[spell:51124]]，则施放 符文能量.
- 施放 [[spell:194913]]。
- 在不处于 [[spell:51271]] 且没有 [[spell:51124]] 时施放 [[spell:207230]]。
- 仅在没有 [[spell:59052]] 的情况下，且在 [[spell:51271]] 期间施放 [[spell:49184]]。
  
  - 这纯粹是为了在 [[spell:51271]] 期间产生一层 [[spell:51124]] **绝不** 在 [[spell:51271]] 之外这样做。

##### 说明

- [[spell:207230]]在2个目标时替代[[spell:49020]]。
- [[spell:194913]]在3个目标时替代[[spell:49143]]。




#### [[talent:123324]] 死亡使者

##### 起手爆发

- 在起手阶段，你要尽快进入爆发冷却技能的循环。此后你的目标是在增益强化下施放尽可能多的 [[spell:51128]] 强化 [[spell:207230]]，并且不要浪费 [[spell:441416]]。下面是一个起手示例，使用推荐的 [[talent:123324]] 死亡使者 **多目标**构筑。

:::rotation 示例 [[talent:123324]] 死亡使者 **冰霜 死亡骑士** 多目标起手
```json
{
  "source_code": "JIaAwjUCCBduAAAAH8kZm1yRDREACNitGAAAAQgQHhMAAAgQ6FxEAAQAI66AAAAAAEwXfQAAIMAA5IAWBUAAB0yFCIkBDRAAAAgACR7xB4CHQxrBAAgQ-lSAugwACBdAZBgQGpBAAIgMaAQCuQAAClgSEEgQJADK-lyAAAAAAIUY5LA"
}
```
1. [[spell:47568]] 非公共冷却
2. [[spell:439843]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:51124]] · [[spell:441424]]
4. [[spell:207230]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
5. [[spell:207230]]  [[spell:47568]] · [[spell:51124]]
6. [[spell:207230]]
7. [[spell:279302]]  [[spell:51124]]
8. [[spell:207230]]
9. [[spell:194913]]
:::

- 由于这只是一个示例，你的开场手法确实会根据你的自动攻击是否触发了 [[spell:51128]] 而改变，所以不要盲目地施放 [[spell:47568]]，除非你的下一次施法没有 [[spell:51128]]！
- 在这套开局手法之后，你仍然可以用 [[spell:1265384]] 召回 [[spell:279302]]，请务必在 [[spell:51271]] 结束之前完成！
  
  - 它不受公共冷却时间影响，所以你可以随时使用，并且 急速 增益会叠加到前一个的持续时间上。

##### 标准优先级

- 如果你有2层充能，就施放 [[spell:47568]]。
- 施放[[spell:439843]]。
- 施放 [[spell:51271]]。
- 将 [[spell:1249658]] 与 [[spell:51271]] 一起使用。
- 施放 [[spell:279302]]。
- 在以下任一条件成立时施放 [[spell:207230]]：
  
  - 你拥有 2 层[[spell:51128]]。
  
  
  
  - 你拥有 1 层[[spell:51128]]以及 3 层或更多 符文 ，同时不在 [[spell:51271]] 中。
- 在[[spell:59052]]加持下施放[[spell:49184]]。
- 施放 [[spell:49143]] 以避免 符文能量 溢出，只要你不是在为 [[spell:1249658]] 储存。
- 在拥有 1 层 [[spell:51124]] 时施放 [[spell:207230]]。
- 如果没有 [[spell:47568]] 或 [[spell:51124]]，则施放 符文能量.
- 在没有 [[spell:51124]] 的情况下施放 [[spell:49020]]，同时不在 [[spell:51271]] 中。
- 仅在没有 [[spell:59052]] 的情况下，且在 [[spell:51271]] 期间施放 [[spell:49184]]。
  
  - 这纯粹是为了在 [[spell:51271]] 期间产生一层 [[spell:51124]] **绝不** 在 [[spell:51271]] 之外这样做。

##### 说明

- [[spell:207230]]在2个目标时替代[[spell:49020]]。
- [[spell:194913]]在3个目标时替代[[spell:49143]]。





## 深度解析

### 反魔法护罩 符文能量

- [[spell:48707]] 会根据其吸收的伤害量为你提供最多 40 点 符文能量。这非常强力，因为你的 符文能量 可能会十分匮乏，所以在 [[spell:48707]] 无需专门用于防御的Boss战中，你会希望尽可能频繁地利用这一点来为自己创造优势。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 左右滑动查看所有Boss →**



### 内克扎莉

:::talents **冰霜 死亡骑士** 毒煞深渊中内克扎莉的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 首领攻略技巧

- 开怪之后，要留意**躁动的阿曼尼** 小怪刷新的极佳时机。在爆发期能够利用[[talent:126017]]，你将获得大量的伤害收益。
- [[spell:49576]] 可以对**躁动的阿曼尼** 使用，因为它们刷新时非常分散，可以用它来重新定位并更好地聚拢它们。
- 被 [[spell:1287322]] 选为目标后使用一个减伤技能，并走到房间边缘放下水坑。
- 当 **内克扎莉** 施放 [[spell:1284103]] 时，注意坦克所在的位置，不要站在她与她的目标之间。




### 陵寝哨兵

:::talents **冰霜 死亡骑士** 毒煞深渊中陵寝哨兵的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 首领攻略技巧

- 留意 **陵寝哨兵** 达到100能量并施放 ‍刻毒停滞 的时机，因为你不会希望刚好交完冷却技能时遇到这种情况而无法输出任何伤害。
- 当你处于 **乌拉泰克之息** 一侧时，务必立刻换到 **毒液凝块**。
- 在吸收 [[spell:1288232]] 时使用一个减伤技能。
- 去吸收 [[spell:1284434]]，你非常坦！




### 迷失的探险者

:::talents **冰霜 死亡骑士** 毒煞深渊中迷失的探险者的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 首领攻略技巧

- 如果在分担伤害人数不多的‍[[spell:1291922]]中使用[[spell:48792]]来分担伤害。
- 打断来自的‍[[spell:1286922]] **书卷贤者伊库**.




### 瓦什尼克

:::talents **冰霜 死亡骑士** 毒砂之渊中瓦什尼克的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 首领攻略技巧

- [[spell:49576]] 在这场战斗中可以也应该被用来重新定位所有的软泥怪。
  
  - 只有1个小怪是免疫的，那就是第一个 **裂变毒液**。当它死亡并分裂后，就可以被拉动了。
- [[spell:48707]] 可以用来避免在 **燃烧剧毒** 死亡时叠加层数。




### 斯索拉克

:::talents **冰霜 死亡骑士** 毒煞深渊中斯索拉克的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYmxgZMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 首领攻略技巧

- **斯索拉克** ‍[[spell:1286033]]期间受到的伤害增加，请确保你为此留好你的冷却技能。由于你的爆发性极强，这一点极其重要。
- [[spell:48265]]可以用来抵消[[spell:1285419]]。 **千万不要这样做**。这可能导致该机制出现错误行为，可能抵消你造成的击退效果，却不会抵消另一个人的移动，那样他们会飞出平台。
- 相反，[[spell:48265]]应该在[[spell:1285732]]期间使用，以便在[[spell:1286033]]伤害阶段让你能够持续攻击首领。 
  
  - 你只需要在任意时刻保留1层[[spell:374968]]，即可在该阶段保持100%的覆盖时间，并在此期间无视所有机制。它持续30秒。




### 双牙

:::talents **冰霜 死亡骑士** 毒砂之渊中双牙的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKODYmZMjZAz2MzMzMbzMjMjxYYMGMzMzMzMzMDAAAAAAAAAgNzihBGY20QDbYmxMzADADAzMmBD"
}
```
:::

#### 首领攻略技巧

- 帮助分摊 ‍[[spell:1289201]]，但注意不要叠加过多层数导致死亡。 
  
  - 你可以在走进 [[spell:1292505]] 之前使用 [[spell:48707]]，这样在你要分摊的 [[spell:1289201]] 下方的减速效果残留地面时，就不会受到其影响。




### 盘绕祭坛

:::talents **冰霜** 死亡骑士 毒煞深渊中盘卷祭坛的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

#### 第一阶段

- 去吸收你被分配到的[[spell:1283485]]。

#### 第二阶段

- 对未聚集在一起且受到 [[spell:1285640]] 影响的玩家使用 [[spell:49576]]。
  
  - [[spell:45524]] 也可用于玩家，但应作为最后手段，因为减速效果会持续到精神控制结束后仍不消失。
  - 如果你的队伍伤害不足以迅速将其打破，可以选择 [[talent:96186]] 的天赋，但这样做会损失输出，不过它是一个非常实用且强力的减速技能。
- 在受到 [[spell:1286895]] 影响时使用 [[spell:48707]]。

#### 阶段转换

- 确保你在这个阶段保留所有冷却技能，在[[spell:1304033]]期间**祖尔加** 会受到100%的额外伤害。

#### 第三阶段

- [[spell:1285640]]回来了，继续使用[[spell:49576]]，并施放在没有集合在一起的玩家身上。




### 乌拉特克

:::talents **冰霜 死亡骑士** 毒噬深渊中乌拉特克的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

**这个首领尚未经过测试，请在世界首杀竞速赛结束后再来查看更新！**




### 尼姆瑞莎·唤波者

:::talents **冰霜 死亡骑士** 潮缚洞窟中尼姆瑞莎·唤波者的天赋
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAmZMjZAz2MzMzMLzMjMjxYYmBMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmZmZGYAYYmBYmBD"
}
```
:::

#### 首领攻略技巧

- 在[[spell:1260837]]期间使用[[spell:48707]]。
- 确保[[spell:48265]]已就绪，以备泡泡进入‍[[spell:1258150]]时使用！
- 你可以使用[[spell:49576]]来帮助聚拢 **泡泡鳍岸行者**.





## 属性优先级

了解你在**冰霜** **死亡骑士** 时作为 团队副本 职业所需的次要属性优先级，以及实现最佳表现所需的第三属性。欲了解更多详细信息，请访问 **[属性与数值](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority
```json
{
  "source_code": "JoAJFQAIkEDKBMQAEA"
}
```
**力量 ＞ 暴击 ≥ 急速 ＞ 精通 ≫ 全能**
:::

:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可降低“**范围效果**”技能受到的伤害。
- **吸血** - 通过造成伤害提供额外治疗。
- **加速** - 比较冷门的绿字属性，但可能非常有用，过去已被证明其实用价值，能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

:::callout 这是一份绝对 最佳配装 装备列表
虽然这些是你应该努力获取以达成绝对最佳配装（Best in Slot）的装备，但在你集齐这套完全相同的装备组合之前，它们并不一定总是最优选择。

为了准确判断应该装备哪件装备，每当你获得可能算是升级的装备时，都应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>) 进行模拟！

:::

|  |  | 获取地点 |
| --- | --- | --- |
| 头部 | 将[[item:251229@BgQAAcEACKgTBA]]转化为[[item:271474@DiQBAsPAnk7cVrTOC4UAdV9A]] | 虚空之痕竞技场的催化装置 |
| 项链 | [[item:268265@BERAAsPAM06wQrDj1kjAYFA]] | 乌拉特克 |
| 肩部 | 将[[item:268226@BgQAAcEA5IgTBA]]转化为[[item:271472@DgQBAsPAXk7kjAOFgwXQ]] | 尼姆瑞莎·唤波者的催化装置 |
| 披风 | [[item:268253@BgQAAsPA5IAWBA]] | 盘绕祭坛 / 催化装置 |
| 胸部 | 将[[item:268222@BgQAAsPA5IAWBA]]转化为[[item:271477@DgQBAsPAJk7kjAYFgvXQ]] | 盘绕祭坛的催化装置 |
| 腕部 | [[item:237834@FiQAAsPAaA80qKEDtO3WzSB]] | 制造装备 |
| 手套 | 将[[item:268220@BgQAAcEA5IgTBA]]转化为[[item:271475@BgQBAsPA5IgTBw7FEA]] | 双子毒牙的催化装置 |
| 腰带 | [[item:268259@BiQAAsPAM06kjAYF]] | 盘绕祭坛 |
| 腿部 | [[item:271878@DARAAsPAhu7YhN5IAWB]] | 乌拉特克 |
| 脚部 | [[item:237828@HgQAAsPAaA8kSuTrqQ3WzSB]] | 制造装备 |
| 戒指1 | [[item:273792@DiQAAsPA1j7wQrjgC4UA]] | 毒牙祭坛 / 巨型宝库 |
| 戒指2 | [[item:158366@DiQAAsPA1j7wQrTcj4UA]] | 塞塔里斯神庙 / 巨型宝库 |
| 饰品1 | [[item:270173@BgQAAsPA5IAWBA]] | 盘绕祭坛 |
| 饰品2 | [[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] | 乌拉特克 |
| 主手 | [[item:268209@RgQAAsPAgBNA5IAWBA]] | 盘绕祭坛 |
| 副手 | [[item:268202@RARAAsPAOLPAXYTOCgVA]] | 乌拉特克 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251126@BgQAAsPACKQQBA]] | 密谋小径 |
| 颈部 | [[item:251173@BgQAAsPACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | [[item:239037@BgQAAsPACKQQBA]] | 塞塔里斯神庙 |
| 披风 | [[item:193763@BgQAAsPACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251151@BgQAAsPACKQQBA]] | 纳洛拉克的洞穴 |
| 腕部 | [[item:159409@BgQAAsPACKQQBA]] | 诸王之眠 |
| 手部 | [[item:251214@BgQAAsPACKQQBA]] | 纳洛拉克的洞穴 |
| 腰部 | [[item:159418@BgQAAsPACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:273776@BgQAAsPACKQQBA]] | 毒牙祭坛 |
| 脚部 | [[item:159412@BgQAAsPACKQQBA]] | 诸王之眠 |
| 戒指 | [[item:273792@BgQAAsPACKQQBA]] | 毒牙祭坛 |
| 戒指 | [[item:158366@BgQAAsPACKQQBA]] | 塞塔里斯神庙 |
| 被动饰品 | [[item:250228@BgQAAsPACKQQBA]] | 密谋小径 |
| 主动使用饰品 | [[item:273797@BgQAAsPACKQQBA]] | 毒牙祭坛 |
| 武器 | [[item:158373@BgQAAsPACKQQBA]] | 塞塔里斯神庙 |





### 饰品

以下是从地下城和团本可获得的上位饰品排名。

| 等级 | 饰品 |
| --- | --- |
| S级 | [[item:270173@BgQAAsPA5IAWBA]] - 单体+双目标搭配[[item:268209@RgQAAsPAgBNA5IAWBA]]  <br>[[item:270164@BgQAAsPA5IgTBA]] - 2个或更多目标且没有另一套套装加成  <br>[[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] |
| **A级** | [[item:270165@BgQAAsPA5IgTBA]]  <br>[[item:250228@BgQAAsPACKgTBA]] |
| B级 | 不适用 |
| C级 | [[item:250238@AgQAAIoAOFA]]  <br>[[item:273797@BgQAAsPACKgTBA]] |
| **废品堆** | [[item:193757@BgQAAsPACKgTBA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:270168@BgQAAsPA5IAWBA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]]  <br>[[item:270163@AgQAAkjAOFA]] |

### 美化饰品

- [[item:251513@AgQAAcbNLFA]]
- [[item:251490]]

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备的最高物品等级为334，因此除了你的2件装饰（Embellishment）装备外，通常穿戴制造装备并无收益。
  
  - 在你还在配装阶段、部分部位还没有334等级装备或神话级（Myth track）装备时，可以使用你的神话晨岩来制造带有暴击和急速的331等级装备。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **合剂**
  
  - [[item:241326]]
  - [[item:241324]]
    
    - 使用哪一种取决于你的属性，请在 Raidbots 中使用 Top Gear 功能来找出最适合你的选择！
- **食物**
  
  - [[item:255846]] 或 [[item:255845]]
    
    - [[item:242275]] 或 [[item:255847]] 没有耐力加成，但属于此类的个人专属物品。
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240983]] -- 唯一
  
  
  
  - 根据你的属性选择以下任意一种：
    
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240890]]

### 附魔

:::columns
:::column
| 头部 | [[item:244007@BAAAAwP]]  <br>[[item:275707@BAAAAsP]] |
| --- | --- |
| 肩部 | [[item:243991]] |
| 胸部 | [[item:243977@BAAAAsP]] |
| 护腕 | [[item:275707@BAAAAsP]] |
| 腰部 | [[item:275707@BAAAAsP]] |
| 腿部 | [[item:244641@BAAAAwP]] |
| 脚部 | [[item:243953@BAAAAwP]] |
| 戒指1 | [[item:243957]] |
| 戒指2 | [[item:243957]] |
| 主手 | [[spell:53344]] |
| 副手 | [[spell:62158]] |

速度附魔也可以替代闪避附魔使用，尤其是在更高的装备等级下。

:::

:::column
:::gear **冰霜 死亡骑士** 团本中的附魔
```json
{
  "source_code": "IkFZ7DQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NARDIAiQgBNAAAgQOLP"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[spell:53344]] |  |
| 副手 | [[spell:62158]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@BAAAAsP]] 来为你的 **头盔**、**护腕** 和 **腰带** 添加插槽。

## 种族

为了对 **冰霜** **死亡骑士** 进行极致优化（min-maxing）时，不同的种族天赋可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族也同样可行。

- [[spell:107072]] -- 熊猫人
  
  - 被动使你的食物增益效果提高100%。与[[item:242745]]搭配极佳，因为丰盛版本在你死亡后不会消失！
- [[spell:59224]] 和 [[spell:65116]] --矮人
  
  - 可以驱散魔法以及流血减益效果。过去在某些有流血机制的首领战中很有用，并且在大秘境中表现强劲。
  
  
  
  - 除了拥有[[spell:20594]]之外，[[spell:59224]]还是一个极强的种族天赋，可提供暴击伤害，这使其与牛头人（拥有相同的种族技能）一同成为我们的优选种族之一。

:::columns
:::column
:::simulation **冰霜** **死亡骑士** 种族模拟
```json
{
  "source_code": "JUtAQ1xAfAAACewSyF2ZncXYMYHBpO_ZIVAFw7nBLlWbiVHbLYHBWxHaINgCAAAAx0laINgAAAAAA0WaINAJAAAAKYcaINACAAAAVY5aINwHAAggJI0dv52ch1GZphgdEYO8nh0AFAAAAAAdnh0AYAAAAsZ0qh0AJAAAAsEeqh0AGAAAAAEdrh0AcAAAAYv7ph0AbAAAA4bkmh0ABwELGE0a15GZhdgdE0BvNYJ8CRwRv52aKYHBWiBaINQJAAAAjNqaINwCAAAA4ndaINwIAAAAlydZINQAAAAAFq-aINgIAAAAUhOaINwAAAAAAR3aINQAaRXBQF2JrVXC2RwuusGSDQAAAIYBOl2ZoRXrcJgMOrWCSQ-AEFWesylAiylaINgHAAAAbeuZINwBAAAAqxuaINgFAAAA8FpaINQHAAAAg-saINAIAAAA08faINAF"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292364]] | 237,518.64 |
| 种族 31 [[spell:292363]] | 238,065.34 |
| 种族 10 | 239,988.77 |
| 种族 2 | 239,028.00 |
| 种族 36 | 239,384.16 |
| 种族 8 | 241,240.33 |
| 种族 31 [[spell:292360]] | 237,507.59 |
| 种族 5 | 237,008.00 |
| 种族 24 | 240,454.42 |
| 种族 9 | 240,097.17 |
| 种族 6 | 241,105.00 |
| 种族 28 | 239,547.84 |
| 种族 27 | 236,102.97 |
| 种族 31 [[spell:292359]] | 237,296.45 |
| 种族 31 [[spell:292362]] | 237,666.34 |
| 种族 37 | 240,269.55 |
| 种族 11 | 239,463.88 |
| 种族 35 | 235,378.58 |
| 种族 1 | 241,578.08 |
| 种族 34 | 238,497.31 |
| 种族 3 | 241,105.00 |
| 种族 31 [[spell:292361]] | 240,826.92 |
| 种族 4 [[spell:154797]] | 240,440.78 |
| 种族 4 [[spell:154796]] | 239,986.53 |
| 种族 30 | 236,446.42 |
| 种族 7 | 240,561.66 |
| 种族 22 | 240,197.94 |
| 种族 29 | 240,446.50 |
| 种族 32 | 239,612.81 |
:::

:::

:::

### 推荐

对于**冰霜** 在团本中，我会推荐巨魔，因为它与输出最高的种族天赋极为接近，而且这个团本尤其有许多爆发阶段，你可以真正发挥这个种族天赋的优势。

如果你还玩大秘境，矮人是你的最佳选择，因为它拥有最好的功能性选项，同时提供的伤害几乎相同。

如果你还玩**邪恶**，巨魔的种族天赋对它来说也是最好的之一，所以它是同时游玩两个专精的最佳全能选择。

## 宏

了解**冰霜** **死亡骑士**在团队副本战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
[[spell:51052]] - *在光标位置施放[[spell:51052]]* *。*

```wow-macro
/cast [@cursor] 反魔法领域
```

:::

:::details 鼠标指向宏
[[spell:45524]] - *如果鼠标悬停目标存在则对其施放 ⟍[[spell:45524]]，否则对你的当前目标施放*。

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] 寒冰锁链
```

[[spell:47528]] - *如果鼠标悬停目标存在则对其施放[[spell:47528]]* *，否则对你的当前目标施放*。

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] 心灵冰冻
```

[[spell:49576]] - *对鼠标悬停目标（如果存在）或你当前目标施放 ‍[[spell:49576]]*。

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] 死亡之握
```

[[spell:61999]] - *对鼠标悬停目标施放 [[spell:61999]]，这样你可以在团队框体上使用。*

```wow-macro
/cast [@mouseover,help,dead][]复活盟友
```

:::

:::details 焦点目标宏
鼠标悬停设置焦点 - *这会将你的焦点设为鼠标悬停目标。*

```wow-macro
/focus [@mouseover]
```

焦点 [[spell:49576]] - *对焦点目标施放 [[spell:49576]]。*

```wow-macro
/cast [@focus] 死亡之握
```

焦点 [[spell:47528]] - *对焦点目标施放 [[spell:47528]]。*

```wow-macro
/cast [@focus] 心灵冰冻
```

:::

:::

## 插件

下方是作者的 **冰霜** **死亡骑士** 用户界面截图，其中说明了使用了哪些插件，以及它们在团队副本中如何使用，从而让你的游戏体验更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/Unholy_Raid_Interface-mxr-1024x635.webp>)

**冰霜 死亡骑士** 团队副本中的界面

:::accordion
:::details 插件
- **回响 团队副本 工具** -- 团队副本 冷却等
  
  - 对团队玩家非常有用的插件，尤其是对团队副本团长和官员。
- **ElvUI** *-- 完整的用户界面替换* 
  
  - 一款以用户友好为核心设计的界面插件，附带标准界面所不具备的额外功能。
  - 你也可以选择使用 Shadowed Unit Frames (SUF) 搭配任意动作条插件，当然也可以使用原生界面。
- **BigWigs** *-- 通用首领模块* 
  
  - BigWigs 是一款首领战斗插件。它由许多独立的*战斗脚本*（即*首领模块*）组成；这些迷你插件专门为某一场特定的团队副本战斗提供警报信息、计时条、音效等提示。
- **Plater** -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有极其丰富的设置选项，开箱即用的减益效果监控、仇恨染色，并支持类似 WeakAuras 的脚本功能，还可通过 wago.io 和 WeakAuras-Companion 更新模块/脚本/配置文件。
- **Details** -- 强大的伤害统计器
  
  - 最强大、最可靠、最精美的伤害统计插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**冰霜**

- 所有技能伤害降低10%。
- 近战伤害降低20%。
- [[spell:51271]]现在使力量提高20%（原为30%）。
- [[spell:49184]]伤害提高100%。
- [[spell:47568]]伤害提高30%。
- [[spell:194913]]伤害提高30%。
- [[spell:435010]]伤害提高30%。
- [[spell:55095]]伤害提高100%。
- [[spell:196770]]伤害提高40%。
- [[spell:207230]]伤害提高20%。
- [[spell:49143]]伤害提高25%。不影响冰霜灾祸。
- [[spell:49020]]伤害降低12.5%。
- [[spell:1249658]]伤害降低20%。
- [[spell:1228433]]伤害降低30%。
- [[spell:279302]]伤害降低20%。
- [[spell:207200]]提供的护盾值相当于造成伤害的35%（原为30%）。

:::accordion
:::details 英雄天赋
- [[talent:123324]] 死亡使者 
  
  - [[spell:441894]] 现在使 [[spell:55095]] 的伤害生效速度加快75%（原为100%）。
  - [[talent:135992@AJgBBA]] 现在使 [[spell:49143]] 的伤害提高35%（原为15%）。
  - [[spell:439843]] 的施放和爆炸伤害降低25%。
  - [[spell:441416]] 的伤害降低17%。
- [[talent:123322]]天启骑士
  
  - 怀特迈恩的 [[spell:444633]] 伤害降低30%。

:::

:::

:::

:::

:::accordion
:::details 12.0.5 补丁
**死亡骑士**

- 霜巢之眷 （等级3）已更新
  
  - 当 [[talent:96236]] 被召回时，现在改为在50%的持续时间内给予完整的急速加成。用于召回 [[talent:96236]] 的技能不再受公共冷却时间影响。

:::accordion
:::details 英雄天赋
- [[talent:123324]] 死亡使者 
  
  - [[talent:135991@AJgBBA]] 的次级效果已被重新设计
    
    - 施放 [[talent:117659]] 会赋予 1 层 [[talent:117665@FJQAm4rBGEA]]，第一把镰刀 100% 生效，第二把镰刀 100% 生效。
  - [[talent:117665@FJQAm4rBGEA]] 已被更新 
    
    - [[talent:117665@FJQAm4rBGEA]] 爆炸后，你接下来的 2 次 [[talent:96246]] 或 [[talent:96243]] 只消耗 1 枚符文，并召唤 2 把镰刀打击敌人。其余效果保持不变。

:::

:::

:::

:::

:::accordion
:::details 补丁12.0.1
**死亡骑士**

:::accordion
:::details 英雄天赋
- [[talent:123324]] 死亡使者 
  
  - [[spell:441416]]的初次镰刀伤害提高30%。
  
  
  
  - [[spell:439843]]的伤害提高25%。
  
  
  
  - [[talent:135992@AJgBBA]]现在使[[spell:49143]]和[[spell:1228433]]的伤害提高15%（原为5%），并有额外效果——若已学会[[spell:439843]]，则给予3层[[spell:377098]]。
  - [[spell:443560]]现在使[[spell:434711]]对主要目标的效果提高100%，且当[[spell:437161]]未命中任何敌人时，现在给予8%的力量加成（原为5%）。
- [[talent:123322]]天启骑士
  
  - 所有骑士的伤害降低65%。
  - [[spell:444037]]现在提高[[spell:55095]]、[[spell:49143]]和[[spell:1228433]]的伤害。
  - 托尔贝恩的[[spell:49020]]在使用单手武器消耗[[spell:51124]]时，现在会正确变为冰霜。
  
  
  
  - 当你有2个或更多活跃的骑士时，[[spell:444072]]现在使符文能量技能的伤害提高10%（原为20%）。

:::

:::

**冰霜**

- [[spell:49020]] 伤害提高15%。
- [[spell:49143]] 伤害降低10%。
- [[spell:1228433]] 伤害降低10%。
- [[spell:1249658]] 和 [[spell:279302]] 的冷却时间在战斗结束后不再被重置。

:::

:::

:::accordion
:::details 补丁12.0
**死亡骑士**

- 新天赋：[[talent:136524]]
  
  - [[spell:61999]] 的符文能量消耗降低 30 点。
- 新天赋：[[talent:136525]]
  
  - [[talent:96204]] 的冷却时间缩短 30 秒，并且在其治疗吸收效果生效期间，你受到的治疗提高 50%。
- 新天赋：[[talent:96189]]
  
  - 当你的生命值低于 50% 时，你的食尸鬼每秒牺牲其最大生命值的 4%，为你恢复相当于你最大生命值 1% 的生命值。
- [[talent:96200]] 的治疗效果降低为过去 5 秒内所受全部伤害的 20%（原为 25%）。
- [[spell:43265]] 伤害提高 130%。
- [[talent:96187]] 现在使 巫妖之躯 的冷却时间缩短 30 秒（原为降低所受伤害）。
- [[talent:96198]] 现在是 2 点天赋。
- [[talent:96180]] 现在是 2 点天赋，并已移至第一个天赋节点门。
- [[talent:136526]] 现在与 [[talent:96193]] 构成二选一天赋。
- [[spell:327574]] 已被移除。

**冰霜**

:::accordion
:::details 英雄天赋
- [[talent:123324]] 死亡使者
  
  - 新天赋：[[talent:135992@AJgBBA]]
    
    - 冰霜：[[talent:96245]] 伤害提高 5%。[[spell:194913]] 伤害提高 5%。
  - 新天赋：[[talent:135991@AJgBBA]]
    
    - 冰霜：[[talent:117659]] 造成的伤害提高 5%。施放 [[talent:96236]] 会获得 2 层 [[talent:117665@FJQAm4rBGEA]]，第一镰和第二镰均以 100% 效果触发。
  - 新天赋：[[talent:135993@AJgBBA]]
    
    - 冰霜：[[talent:96195]] 的效果提高 50%。
  - [[talent:117658]] 不再使被击中的敌人造成的物理伤害降低 5%，持续 10 秒。
- [[talent:123322]]天启骑士 
  
  - 新天赋：[[talent:135999@AJgBBA]]
    
    - [[talent:125874]] 召唤托尔贝恩，持续 6 秒。
  - 新天赋：[[talent:135998@AJgBBA]]
    
    - 施放 [[talent:125874]] 或 [[talent:96243]] 会命令托尔贝恩与你一同施放他的 [[talent:96246]] 或 [[talent:96243]] ，效果为 100%。
  - 新天赋：[[talent:135997]] 
    
    - 天启四骑士施放的技能造成的伤害提高 5%。
  - 莫格莱尼的 [[spell:43265]] 伤害提高 50%。
  - 莫格莱尼的[[spell:43265]] 现在每次造成伤害时，使目标身上的疾病效果持续时间延长 1 秒。
  - 托尔贝恩的 [[spell:45524]] 不再造成伤害。
  - 修复了 [[talent:96245]] 无法消耗 [[talent:96228]] 减益效果的问题。

:::

:::

:::accordion
:::details 专精改动
- [[talent:96246]] 已更新：
  
  - 双手武器：一次残忍的攻击，造成物理伤害和 冰霜 伤害。
  - 双持武器：使用双武器进行一次残忍的攻击，共造成物理伤害和 冰霜 伤害。
- [[talent:96224]] 现在有一个额外效果——当 [[talent:96223]] 消耗掉主目标身上的 [[spell:50401]] 层数时，改为造成250%的额外伤害。
- [[talent:125877]] 已更新：
  
  - 在 [[talent:125874]] 激活期间，你的自动攻击造成暴击时，会使其持续时间延长1秒，最多延长4秒。
- 所有技能伤害降低19%。
- 自动攻击伤害提高300%。
- [[talent:96223]] 伤害降低10%。
- [[talent:96222]] 对次要目标的伤害降低20%。
- [[talent:96238]] 现在使消耗符文能量的技能有几率额外造成所造成伤害30%的伤害，在4秒内生效。
- [[talent:96225]] 效果现在是瞬发的，不再有弹道。

:::

:::

:::

:::

## 常见问题

:::accordion
:::details 问： [[spell:51124]] 的触发机制是如何运作的？
答：作为一名双手 湮没 **冰霜 死亡骑士**，你的每次自动攻击 暴击 都会为你提供一层 [[spell:51128]]

作为一名双持**冰霜 死亡骑士**，你的自动攻击爆击 有30%的几率触发它，最多可叠加4次，这意味着最坏情况下，你会在4次自动攻击[[spell:51128]]爆击之后获得。

- 1 次 暴击 = 30% 几率
- 2 次 暴击 = 60% 几率
- 3 次 暴击 = 90% 几率
- 4 次 暴击 = 100% 几率

:::

:::

---

### 致谢

作者：**Miniaug**

审核：**Soda**

---

:::changelog 更新记录
**2026-08-12** 更新至 12.1 版本

**2026-06-17** 更新至 12.0.7 版本

**2026-04-22** 更新至 12.0.5 版本

**2026-02-25** 更新至 至暗之夜 上线版本！

**2026-02-10** 更新至 12.0.1 版本

**2026-01-21** 更新至 至暗之夜 前夕版本 12.0.0

**2025-10-07** 更新至 11.2.5 版本

**2025-08-06** 更新至 11.2 版本

**2025-06-18** 更新至 11.1.7 版本

**2025-05-21** 更新至 11.1.5 版本

**2025-02-25** 更新至 11.1 版本。

**2024-12-18** 更新至 11.0.7 版本。
最佳配装 已更新

**2024-10-22** 更新至 11.0.5 版本。
新增了新的配装，更新了最佳装备（BiS），并在输出循环和冷却使用章节中加入了 冰龙吐息 相关内容。

**2024-09-08** 更新了最佳装备（BiS），并移除了已不再使用天赋和配装的相关内容。

**2024-08-17** 更新至 11.0.2 版本。

**2024-07-24** 攻略编写于前夕版本 11.0.1。



:::
