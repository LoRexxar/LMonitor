Welcome to the **Holy Priest** Raid guide for the World of Warcraft patch 12.1 This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 4/5 · Strong

Cooldown Strength · 3/5 · Average

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 1/5 · Subpar



:::

:::

:::column
:::gear **Holy Priest** Raid Best in Slot Gear
```json
{
  "source_code": "JEpAwbVABc__BEgAmQgAREAAvj7AJ16AC06ACKgF2gVABk-FEAQEBAgEtOg-sOggCwYNYFQABTCBCgQAAUTuDIoAOFQAGTCBCgQAAMSuDIoAOFQAATCBAiQAAwQADxgTBEgwJ4BBboaCeQw3XUAPA8QA8wHWBEAIoOAhIEAAeA8Ano6AM06A3WzSBEAxkQAAIEAACGQIg4paCIICBAQ94GgHF8GCAU9A6IBAEI1HNADDOFQAU1BDE09FNgBKYFQA0LCBCgQAAMQD4RTCAPAB4EAA0B8AeA8AA0RAMcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240969]] · [[item:240898]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240914]] · [[item:240890]] |
| 肩部 | [[item:271553]] | [[item:244021]] |
| 胸部 | [[item:271558]] | [[item:244003]] |
| 腰部 | [[item:271552]] | [[item:240908]] |
| 腿部 | [[item:271554]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240908]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:251136]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270162]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243971]] |
| 副手 | [[item:245769]] | [[item:245876]] · [[item:245790]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Holy Priest**, you have access to Benediction, which has a chance to transform your [[spell:2061]] into a more powerful version.

**Rank 2** and **Rank 3** increases all your healing by 12% and your [[spell:243241]] healing by 30%.

**Rank 4** guarantees Benediction procs and enhances with your [[spell:64843]] with [[spell:243241]] procs.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-holypriest-mxr.webp>)

Benediction

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103762]]
    
    - Your critical effects strike for 220%.
  
  
  
  - [[talent:103733]]
    
    - Empowers your [[talent:103775@FAQA1UwE]] massively, but removes [[talent:103766]].
- **Removed**
  
  - [[spell:391387]] 
    
    - This results in a lot lower [[talent:103748@FAQADh5A]] uptime.

## Hero Talents

- [[talent:123291]] focuses on big spikey healing output, while [[talent:123290]] focuses on enhancing your constant healing output and providing utility to the team.
- This guide recommends playing [[talent:123291]], and therefore only covers that Hero Talent option.

:::tabs
:::tab [[talent:123291]]
- When casting [[spell:120517]] you also periodically create more Halos that return to you. They are enhanced by the following nodes and grant you certain benefits:
  
  - [[talent:117284]]
    
    - Creates multiple [[spell:120517]].
  - [[talent:117279]]
    
    - Applies an increased healing taken buff to any ally hit by a [[spell:120517]] ring.
  - [[talent:117281]]
    
    - Massively increases the effectiveness of each [[spell:120517]].
  - [[talent:117305]]
    
    - [[spell:120517]] return to you after reaching max distance.

:::

:::tab [[talent:123290]]
- [[talent:123290]] enhances primairly your [[spell:33076]].
  
  - [[talent:117286]]
    
    - Gives you 2 stacks of [[spell:33076]].
  - [[talent:117282]]
    
    - Reduces the base cooldown of [[spell:33076]].
  - [[talent:117276]]
    
    - Instantly heals your [[spell:33076]] target by a good amount.

:::

:::

## Talents

:::tabs
:::tab General Raid Talents
:::talents **Holy Priest** Raid Talents
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### When to use this Spec

This is the default loadout going into any boss unless specified otherwise. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, boss-specific talent loadouts are available in the Raids section.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

#### Spec Tree

- [[spell:235587]]
  
  - This Talent grants you an additional charge of your healing Holy Words. This increases the value of the **Holy Priest's** core cooldown reduction mechanic, as you can now retain one charge for emergencies without losing value.
- [[spell:391124]]
  
  - Cheat death effect.
- [[spell:392988]]
  
  - Summons a Naaru after each Holy Word. The Naaru is empowered by each Holy Word you cast, but the empowerment only lasts for a short duration.
- [[talent:103733]]
  
  - Buffs your [[talent:103775@FAQA1UwE]] massively and also lets all Talents that affect [[talent:103766]] now apply also to [[talent:103775@FAQA1UwE]].

#### Class Tree

- [[spell:459559]]
  
  - Increases the range of your spells to 46 yards, which is a very powerful tool if used correctly. This allows you to reach allies even when the Raid is spread out.
- [[spell:109186]]
  
  - This talent significantly helps with mana management and mobility, providing you with an additional recovery tool while on the move.
- [[spell:336897]]
  
  - You also gain the effects of [[spell:10060]] when you cast it on an ally.
- [[spell:193063]]
  
  - In combination with [[spell:368276]] and [[spell:109186]], this talent provides you with an easily accessible 10% damage reduction.
- [[talent:103835]]
  
  - Adds a new but weak defensive ability to the **Priest** class toolkit. However, when combined with [[spell:193063]], it could save your life!

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Each target affected by your ‍Renew increases your Critical Strike chance by 2%, up to 6%.
- **4-Set:** ‍Renew healing increased by 10%. ‍Light's Resurgence now has a 100% chance to leave a ‍Renew on the first target ‍Prayer of Mending heals.

### Priority List

1. Cast [[spell:2050]] if at 2 charges.
2. Cast Benediction without [[talent:103868@FAgAHdhAKfwE]] active.
3. Cast [[spell:596]] if there is aoe healing to be done.
4. Cast [[spell:2050]].
5. Cast [[talent:103870]] on movement globals.
6. Cast [[spell:33076]] on movement globals.

### Cooldowns

#### Divine Hymn

- While this spell does not do the best numbers compared to other cooldowns, its real strength lies in its raid-wide increased healing taken buff that builds up during the channel. When combined with a powerful raid healing cooldown, [[talent:103755]] can be one of the strongest healing cooldowns there is.

#### Apotheosis

- Your strongest cooldown make sure to look up when to use this on each encounter.

## Deep Dive

#### Min maxing Power Infusion

- While [[spell:10060]] is your spell, the optimal usage is to prioritize your teammates' benefit over your own. To do this, communicate with your teammates so they can request it exactly when they need it.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomyss Abyss

The following tips are mainly applicable to Heroic Bosses. Mythic tips are released after our progression finishes.

:::tabs
:::tab Nek'Zali
:::talents **Holy Priest** Nek'Zali talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- Dispel people affected with [[spell:1287322]] at the edge of the room!
- Do not be inbetween the boss and the tank when the boss casts [[spell:1284103]].

:::

:::tab Entombed Sentinels
:::talents **Holy Priest** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- Dispel players affected with [[spell:1284471]].
- [[spell:1284590]] is neutralized harmlessly upon reaching exactly 4 stacks.

:::

:::tab Lost Explorers
:::talents **Holy Priest** Lost Explorers talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- Dispel people affected with [[spell:1286921]].

:::

:::tab Vashnik
:::talents **Holy Priest** Vashnik talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- External players affected with [[spell:1295224]]. While affected, they are immune to your regular healing.
- Use a personal defensive when affected by [[spell:1294994]].

:::

:::tab Sszorak
:::talents **Holy Priest** Sszorak talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- External people with [[spell:1286987]].

:::

:::tab Twin Fangs
:::talents **Holy Priest** Twin Fangs talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- Use a personal defensive when affected by [[spell:1290809]].

:::

:::tab Coiled Altar
:::talents **Holy Priest** Coiled Altar talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.

:::

:::tab Ula'tek
:::talents **Holy Priest** Ula'tek talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.

:::

:::tab Nymrissa Wavecaller
:::talents **Holy Priest** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CGQA14bH_XF5B_Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM",
  "code": "CGQA14bH/XF5B/Zp2PVV69Qa7yYAAAAAAAgZmlBjZmZYmZGLzMmBAAAwMsMDzMzMMDzAYmaAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBM"
}
```
:::

### Boss Tips

- Use a personal defensive when many [[spell:1257717]] get popped.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Holy Priest**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Holy Priest** Stat Priority in Raid
```json
{
  "source_code": "IoAJFUAIoEDJBMwABA"
}
```
**智力 ＞ 暴击 ≥ 全能 ≥ 精通 ＞ 急速**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- All secondary stats are affected by **diminishing returns**. [Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to learn more!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - Increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful Leech is for a Healer: Breakdown of Mythic Vorasius.

![](<https://assets-ng.maxroll.gg/wordpress/MyUb2Ci-1024x491.png>)

Warcraftlogs

## Gear

:::tabs
:::tab Best in Slot
Due to the way stat weights work for **Holy Priest**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DERAAEQAvj7kUrjAtOCKgF2gVA]] | Ula'tek |
| Neck | [[item:268265@BERAAEQAS06oPrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271553@DgQAAEQA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAEQACKAWBA]] | Coiled Altar |
| Chest | [[item:271558@DgQAAEQAjk7IoAOF]] | Tier/Catalyst |
| Wrist | [[item:239648@FiQAAEQAeA8ciqDDtO3WzSB]] | Crafting |
| Gloves | [[item:271556@BgQAAEQACKAWBA]] | Tier/Catalyst |
| Belt | [[item:271552@BiQAAEQAM06IoAOF]] | Tier/Catalyst |
| Legs | [[item:271554@DgQAAEQAbo6IoAOF]] | Tier/Catalyst |
| Boots | [[item:268255@DgQAAEQAPk7IoAYF]] | Coiled Altar |
| Ring 1 | [[item:158366@DiQAAEQA1j7wQrjgC4UA]] | Temple |
| Ring 2 | [[item:251136@DiQAAEQA1j7wQrjgC4UA]] | Murder Row |
| Trinket 1 | [[item:270162@BgQAAEQACKgTBA]] | Nek'Zali |
| Trinket 2 | [[item:270164@BgQAAEQACKgTBA]] | Lost Explorers |
| Weapon | [[item:271092@DgQAAEQADk7IoAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FgTAAEQA0B84BwDAAAAAAAAAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Raid from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@AgQAAIoABFA]] | The Blinding Vale |
| Neck | [[item:251234@AgQAAIoABFA]] | Voidscar Arena |
| Shoulder | [[item:251227@AgQAAIoABFA]] | Voidscar Arena |
| Cloak | [[item:251132@AgQAAIoABFA]] | Murder Row |
| Chest | [[item:239032@AgQAAIoABFA]] | Temple |
| Wrist | [[item:251154@AgQAAIoABFA]] | Den |
| Gloves | [[item:273773@AgQAAIoABFA]] | Altar of Fangs |
| Belt | [[item:159255@AgQAAIoABFA]] | Temple |
| Legs | [[item:159234@AgQAAIoABFA]] | King's Rest |
| Boots | [[item:159259@AgQAAIoABFA]] | Temple |
| Ring 1 | [[item:158366@DiQAAEQA1j7wQrjgCEUA]] | Temple |
| Ring 2 | [[item:251136@DiQAAEQA1j7wQrjgCEUA]] | Academy |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | Academy |
| Trinket 2 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Two-Hand Weapon | [[item:193761@AgQAAIoABFA]] | Ruby Life Pools |
| One-Hand Weapon | [[item:251225@AgQAAIoABFA]] | Voidscar Arena |
| Off-Hand | [[item:271681@AgQAAIoABFA]] | Den of Nalorakk |

:::

:::

### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on each boss fight.

| Rank |  |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A-Tier** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:239664@BiQAAEQA6z6IyLdE]]
  
  - Very overtuned stat stick.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241326]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241300]] *-- Recommended*
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAEEAaB]]
- **Sockets**
  
  - [[item:240908]]
  - [[item:240969]] *--* *Unique, use one of each gem colour to enhance your Eversong Diamond.*
    
    - [[item:240898]]
    - [[item:240914]]
    - [[item:240890]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@BAAAAEQA]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAEQA]] |
| Belt | [[item:275707@BAAAAEQA]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:243987@BAAAAEQA]] |
| Ring 2 | [[item:243987@BAAAAEQA]] |
| Weapon | [[item:244029@BAAAAEQA]] |

:::

:::column
:::gear **Holy Priest** Enchantments
```json
{
  "source_code": "IQFZBEQ9NCQAvj7ACAAAAktBEEQN5OAAAAAABkQDIgQ2GQQBQQwGqmAGA8gOYAAAT0AEoMRuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:243951]] | [[item:263897]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:263897]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:263897]] |  |
| 戒指一 | [[item:243987]] |  |
| 戒指二 | [[item:243987]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAEQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Holy Priest** in Mythic Raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:69070]] *-- Goblin* 
  
  - Jump forward, can be cast while falling or being knocked.
- [[spell:256948]] *--* *Void elf* 
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to it.
  - Maximum range of 100 yards.

### Recommendation

It is highly recommended to play a Dracthyr! **Priests** can be pretty slow-moving, and the double jump extra mobility really helps in those sticky situations.

## Macros

Discover recommended macros for **Holy Priest** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Holy Priest** Raid Guide are available as mouseover macros for your convenience!

[[spell:33076]]

```wow-macro
/cast [@mouseover, help] Prayer of Mending; Prayer of Mending
```

[[spell:2050]]

```wow-macro
/cast [@mouseover, help] Holy Word: Serenity; Holy Word: Serenity
```

[[spell:596]]

```wow-macro
/cast [@mouseover, help] Prayer of Healing; Prayer of Healing
```

[[spell:2061]]

```wow-macro
/cast [@mouseover, help] Flash Heal; Flash Heal
```

[[spell:10060]]

```wow-macro
/cast [@mouseover,exists] Power Infusion; Power Infusion
```

[[spell:73325]]

```wow-macro
/cast [@mouseover, help] Leap of Faith; Leap of Faith
```

[[spell:47788]]

```wow-macro
/cast [@mouseover, help] Guardian Spirit; Guardian Spirit
```

:::

:::details Recommended Macros
If you press shift while using this macro you get the [[spell:121536]] automatically placed under you, skipping the control click.

```wow-macro
/cast [mod:shift, @player] Angelic Feather; Angelic Feather
```

Replace your [[spell:527]] macro if you wish. This macro makes it so that if you target an enemy you purge and if you target an ally you dispel, saving you a keybind.

```wow-macro
#showtooltip Purify
/use [@mouseover, help] Purify; [harm] Dispel Magic; [noharm] Purify
```

Your [[spell:32375]] instantly goes off when you press the button without having to confirm click, use with caution.

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

A nice little **Priest** only macro, if you know you know.

```wow-macro
/cast [nomod] Levitate
/cancelaura [mod:shift] Levitate
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Holy Priest**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/xMsr1We-1-1024x576.webp>)

**Holy Priest** Raid User Interface

:::accordion
:::details Addons
- EllesmereUI -- Everything
  
  - Addon to upgrade Blizzards very own UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Holy
  
  - Divine Hymn has been updated – Now additionally grants Guardian Spirit while channeled.
    
    - *Developers' notes: We are adding a benefit to channeling Divine Hymn to make it easier to use. If you already have Guardian Spirit active on yourself, Divine Hymn will add 5 seconds to its duration. If Divine Hymn's channeling is ended early, it will remove whatever time is remaining from the amount that it added.*
  - Apex Talent: Benediction (Rank 3) has been updated – Apotheosis no longer upgrades Flash Heal to Benediction. Holy Word: Serenity now has a 100% chance to upgrade your next Flash Heal to Benediction.
  - Apex Talent: Benediction mana cost reduced by 30% and healing increased by 15%.
    
    - *Developers' notes: We want to address Benediction’s performance by spreading its availability beyond Apotheosis and Prayer of Mending. Additionally, we are increasing the throughput of Benediction, so its impact is felt and contributes more to Holy’s overall throughput. Lastly, we want to further lessen how expensive the rotation of Holy is by specifically targeting Flash Heal and Prayer of Healing.*
  - All healing increased by 16%.
  - Flash Heal mana cost reduced by 10%.
  - Prayer of Healing mana cost reduced by 10%.
  - Apotheosis now reduces the mana cost of Holy Words by 70% (was 50%).
- Hero Talents
  
  - Archon
    
    - Resonant Energy has been slightly redesigned – Creating a Halo increases healing done by 2% for 10 seconds, stacking up to 4 times.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:47788]] as a personal defensive cooldown.

:::

:::

---

### Credits

Written By: **Rycn**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-07** Guide Updated for 12.1

**2026-04-22** Guide Updated for 12.0.5

**2026-01-15** Guide Updated for 12.0

**2025-10-07** Guide Updated for 11.2.5

**2025-07-28** Guide Updated for 11.2

**2025-06-18** Guide updated for 11.1.7

**2025-04-21** Guide updated for 11.1.5

**2025-02-25** Guide updated for 11.1

**2024-12-17** Guide updated for 11.0.7

**2024-10-20** Guide updated for 11.0.5

**2024-10-11** Guide updated.

**2024-08-17** Guide Written for patch 11.0.2



:::
