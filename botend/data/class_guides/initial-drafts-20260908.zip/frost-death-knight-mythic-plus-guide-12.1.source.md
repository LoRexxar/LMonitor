Welcome to the **Frost Death Knight** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single Target** · 4/5 · Good

AoE · 4/5 · Good

Utility · 2/5 · Weak

Survivability · 5/5 · Excellent

Mobility · 2/5 · Weak



:::

:::

:::column
:::gear **Frost** **Death Knight** Best in Slot
```json
{
  "source_code": "JApAQvPA3_fABIHJEIICBAwJ5OwVtOQOC4UABk-FEAQEBAADtOADtOAj1kjAYFQAwRCBCgQAAcRuJMCA1FwDQUAAJk7AB4BI-eBBBM-FEAICFUTASATAGYCBCARAAE6uDYhNFEBYEE6AGgQAAoBwDkSuD0qKEcbNLFQAKE6AEmQFU0qKEwQrDUQFYMHJEAACBAQBLiAgtQQAdSQ94GwicIoAOFQAeqmAZIBGxNiTBEQXf0AMMgVAB8VAMgzAAkjAYFQBAEQLXIQAdfRGeASsXQAEIEAAgBdBhAUAqeBBQARAA4s8AchN5IAWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271474]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240908]] · [[item:240908]] |
| 肩部 | [[item:271472]] | [[item:243991]] |
| 胸部 | [[item:271477]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240908]] |
| 腿部 | [[item:271878]] | [[item:244641]] |
| 脚部 | [[item:237828]] | [[item:245786]] · [[item:244009]] · [[item:273069]] |
| 腕部 | [[item:237834]] | [[item:240908]] · [[item:245786]] · [[item:273069]] |
| 手部 | [[item:271475]] |  |
| 戒指一 | [[item:273792]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[spell:53344]] |
| 副手 | [[item:268202]] | [[spell:62158]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As a **Frost Death Knight**, you have access to Chosen of Frostbrood which causes [[spell:279302]] to deal 100% increased damage and give you 15% Haste for 12 seconds.

**Rank 2** causes [[spell:279302]] to extend the duration of [[spell:51271]] by 2/4 seconds as well as increasing the amount of Strength [[talent:125875]] gives by 8%, up to a total of 18%.

**Rank 3** gives you a passive 10% Frost damage and buffs the damage of [[spell:279302]] by 100%. Additionally it gives you the ability to recall [[spell:279302]] at 50% of its effectiveness.

- For [[talent:123324]] Deathbringer this gives you a stack of [[spell:441416]].
- For [[talent:123322]]Rider of the Apocalypse it summons your Horsemen for 10 seconds.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-frostdk-mxr.webp>)

Chosen of Frostbrood

:::

:::

### Core Changes

Going into Midnight, **Frost Death Knight** received very few non-balance related changes due to a rework in patch 11.2 in The War Within. In this section, we go over the few changes you need to know about for **Frost**. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:96224]] has an additional effect which causes [[spell:1228433]] to consume [[spell:50401]] and deal an additional 300% damage to your target.
  - [[talent:125877]] now increases the duration of [[spell:51271]] by 1 second per auto attack crit, up to a max of 4 seconds.
- **Class Tree**
  
  - [[talent:136524]]
    
    - Removes the Runic Power cost from [[spell:61999]]!
  
  
  
  - [[talent:136525]]
    
    - A new talent to reduce the cooldown of [[talent:96204]] and increases the speed that the healing absorb gets removed.
  - [[talent:96187]]
    
    - [[spell:49039]] is no longer a defensive cooldown and only provides charm, fear, and sleep immunity as well as a small amount of Leech while it is active.
  - Various talents have been moved around, generally being easier to get.

## Hero Talents

- As a **Frost Death Knight** [[talent:123324]] Deathbringer is currently your go-to Hero Talent for all aoe content. Currently it is better and more versatile than [[talent:123322]]Rider, but [[talent:123322]]Rider is very viable.



### [[talent:123324]] Deathbringer

##### Offensive Nodes

- [[talent:117659]]
  
  - The explosion grants you 2 stacks of [[talent:117665]].
- [[talent:117633]]
  
  - Makes you deal up to 12% increased Shadowfrost damage to your main target, and up to 6% to additional enemies that it hits.
- [[spell:441894]]
  
  - [[talent:117665]] refreshes or applies [[spell:55095]] and makes it do its' damage in half the duration. This is incredibly powerful in Single-Target and even stronger in AoE.
- [[talent:117640]]
  
  - [[spell:59052]] empowered [[spell:49184]] now deal 30% more damage to its main target.
- [[talent:117631]] vs [[talent:128235]]
  
  - [[talent:117631]] gives you a stack of [[spell:51128]] when you press [[talent:117659]] and increases the damage of [[talent:117659]] depending on your target's missing health
- [[talent:117658]]
  
  - When [[talent:117659]] explodes it deals damage to nearby enemies.
- [[talent:117629]]
  
  - A nice single target increase that grants you Strength if [[talent:117659]] explodes and does not hit any other targets with [[talent:117658]].
  
  
  
  - Increases [[talent:117633]] effectiveness by 100% on your main target, making it a 20% damage increase if both hits of [[talent:117633]] crit your target.
- [[talent:135992@AJgBBA]]
  
  - Increases the damage of [[spell:49143]] and [[spell:194913]] by 15%.
  - Grants you 3 stacks of [[spell:377098]] when you cast [[talent:117659]].
- [[spell:1265855@FJgDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBT3yEGEA]]
  
  - Increases the damage of [[talent:117659]] by 5%
  
  
  
  - Casting [[spell:279302]] gives you 2 stacks of [[talent:117665@FJQAm4rBGEA]].

##### Defensive Node

- [[talent:135993@AJgBBA]]
  
  - Increases the effectiveness of [[talent:96195]] by 50%.

##### Offensive Choice Node

- [[talent:117654]] vs [[talent:128266]]
  
  - [[talent:117654]] is always the winner here as extra stacks of [[spell:194878]] are quite good to allow for more [[spell:51124]] and [[spell:435010]] procs.
  - [[talent:128266]] has no synergy with the current talent builds that we play as it desyncs [[talent:117659]] from [[spell:51271]].

##### Defensive Choice Nodes

- [[talent:117632]] or [[talent:123420]]
  
  - [[talent:117632]] is not a good enough talent to consider as it puts up a random healing absorb which in some cases can be extremely detrimental. On the other side you have [[talent:123420]] which is incredibly strong as it is a passive damage reduction based on what abilities you use. During your cooldowns this is essentially a 10% magic and physical damage taken reduction as you are constantly refreshing them.
- [[talent:117646]] or [[talent:128234]]
  
  - [[talent:117646]] is the clear choice here as [[talent:128234]] does not work in PvE content on casts where it matters.




### [[talent:123322]]Rider of the Apocalypse

##### Offensive Nodes

- [[talent:117663]] - Each Rune spent gives you a 10% chance to summon one of the following Four Horsemen:
  
  - [[spell:444248]]
    
    - Puts up a [[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] that follows him for 10 seconds.
      
      - Standing in his ‍[[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] increases your damage and critical strike by 5%.
  - [[spell:444251]]
    
    - [[spell:444633]] is a disease with a 24 second duration that spreads and gains 1 stack every time you use [[spell:49020]] or [[spell:207230]] on the infected target.
  
  
  
  - [[spell:444254]]
    
    - Repeatedly casts [[spell:45524]] over his duration that gets shattered by [[spell:49020]] or [[spell:207230]] with [[talent:117660]].
  - [[spell:444252]]
    
    - Grants you 5% Strength, increasing by 1% for every Rune spent while Nazgrim is active.
- [[talent:117638]] 
  
  - Summons all 4 Horsemen for 20 seconds after casting [[talent:125876]].
    
    - If a Horsemen is already out, it extends the current duration by 20 seconds instead.
      
      - [[spell:444248]] does not recast his [[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] but all other Horsemen recast their abilities.
- [[talent:117641@FAQAuchA]]
  
  - Passively increases [[spell:55095]], [[spell:49143]], and [[spell:1228433]] damage.
- [[talent:117651]]
  
  - Increases [[spell:49020]] damage by 10% and increases the duration of [[spell:196770]] by 2 seconds.
- [[talent:135999@AJgBBA]]
  
  - [[spell:51271]] summons [[spell:444254]] for 6 seconds.
- [[talent:135998@AJgBBA]]
  
  - Casting [[spell:49143]] or [[spell:207230]] orders [[spell:444254]] to cast his [[spell:49143]] or [[spell:207230]] alongside you at 100% effectiveness while she is active.
  
  
  
  - If you played [[talent:123322]]Rider **Frost** in The War Within Season 3, this will be familiar as it was part of your set bonus.
- [[spell:1265971]]
  
  - Increases the damage of abilities cast by the Horsemen by 5%.

##### Offensive Choice Nodes

- [[talent:117639]] or [[talent:123411]]
  
  - [[talent:117639]] increases the duration of your Horsemen when spending Runic Power which has synergy with [[talent:135999@AJgBBA]] and [[talent:135998@AJgBBA]] but the build currently played has incredible synergy with [[talent:123411]] allowing for huge [[spell:49143]] and [[spell:1228433]] during your burst.

##### Defensive Choice Nodes

- [[talent:123412]] or [[talent:117657]]
  
  - [[talent:117657]] does not work at all in raids so you always choose [[talent:123412]] which is not a bad thing as this greatly increases your mobility and allows you to break roots and slows.
- [[talent:117634]] or [[talent:123410]]
  
  - [[talent:117634]] depends on the value of [[spell:48707]] during the fight as this can be incredibly potent allowing you to pre-immune debuffs or randomly absorb high amounts of magic damage. On the other hand, [[talent:123410]] grants you 5% damage reduction per Horsemen out or a 20% damage reduction during your cooldowns with [[talent:117638]]. Due to the situational value of both of these, there is no auto pick for this as it just depends on the fight.





## Talents



### [[talent:123324]] Deathbringer

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:125874]] and [[talent:126017]]
  
  - [[talent:125874]] is **Frost Death Knight's** major cooldown and when talented into [[talent:126017]] it activates (a free) [[spell:196770]].
    
    - Talenting into [[talent:126017]] removes your ability to cast [[spell:196770]] separately.
- [[talent:96220@FAQAhlvA]]
  
  - Allows you to gain a massive amount of [[spell:51128]] buffs during your [[talent:125874]], subsequently making it an incredibly high burst window as you can slam massive [[spell:51124]] empowered [[spell:49020]] constantly during [[talent:125874]].
- [[talent:96225]] and [[talent:133364]]
  
  - A [[spell:51128]] and Runic Power generator, with [[talent:133364]] reducing its cooldown by 6 seconds for every [[spell:59052]] consumed.
  - Makes your [[spell:49020]] free when cast during [[talent:125874]].
- [[talent:96254]]
  
  - Allows you to consume 2 stacks of [[spell:51124]] at once leading to considerably less wasting of procs.
- [[talent:96248]]
  
  - Sends out a [[spell:194913]] towards your facing that applies [[spell:50401]] to all enemies hit and refreshes [[talent:96214]].
- [[talent:96242]], [[talent:96229]], and [[talent:96229]]
  
  - All of these talents combined drastically increase your [[spell:196770]] damage which contributes a good amount of single-target damage and is a very noticeable portion of your AoE.
- [[talent:96236]]
  
  - Required to interact with your Apex Talent Chosen of Frostbrood.
- [[talent:96224]] and [[talent:96223]]
  
  - [[spell:49143]] now consumes 5 stacks of [[spell:50401]] to increase its damage by 115%, and [[talent:96223]] consumes them to deal 300% additional damage.
  - [[talent:96223]] has a ramping chance based on targets hit to proc and do cleave damage with your [[spell:49143]].

##### Class Tree

- [[talent:96174]]
  
  - Reduces the cooldown of [[spell:48707]] by 20 seconds and increases its duration and amount absorbed by 40%.
- [[talent:96194]] and [[talent:96176]]
  
  - Your raid cooldown that lasts for 6 seconds, reducing magic damage taken by anyone standing in it by 15%.
  
  
  
  - Talenting into [[spell:374383]] reduces the cooldown by 1 minute, down to 3 minutes, and increases the duration to 8 seconds.
- [[talent:126016]]
  
  - Reduces your magic damage taken by 5% and reduces the duration of harmful magic effects by 35%. While the reduced magic damage portion of [[talent:126016]] works against all magic damage, the reduced duration of harmful magic effects does not work on the vast majority of debuffs in the raid as that could simply break too many things.
- [[talent:126015]]
  
  - Gives you 1 extra charge of [[spell:48265]], [[spell:43265]], and [[spell:49576]].
- [[talent:96182]]
  
  - Reduces all damage taken by 35% when below 30% health, including the portion of the hit that takes you below 30%. For example, if you take a hit that takes you from 60% to 10%, the portion of the hit below 30% of your health is reduced by 35%
- [[talent:96180]]
  
  - Increases all absorbs on you by 30%, this is incredibly powerful as it increases the absorb of spells like [[spell:48707]] and [[spell:17]] and other similar abilities.

##### Runeforges

- Main-Hand Weapon
  
  - [[spell:332944]]
- Off-Hand Weapon
  
  - [[spell:53344]]




### [[talent:123322]]Rider

:::talents
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbzmZbGGLMsMz20QzYDzMMzAzAYYmBzMzAD",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbzmZbGGLMsMz20QzYDzMMzAzAYYmBzMzAD"
}
```
:::

#### When to use this Spec

This is the build you play in Mythic+ if you prefer to play [[talent:123322]]Rider of the Apocalypse.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- **Added**
  
  - [[talent:123322]]Rider of the Apocalypse

- **Removed**
  
  - [[talent:123324]] Deathbringer

##### Runeforges

- Main-Hand Weapon
  
  - [[spell:332944]]
- Off-Hand Weapon
  
  - [[spell:53344]]





## Rotation

### Tier Set

- **2-Set:** Each time [[spell:196770]] damages at least 1 enemy, gain [[spell:1297365]] which grants 2% attack speed and 4% increased [[spell:435010]] damage for 10 seconds, stacking.
- **4-Set**: [[spell:196770]] deals damage 25% more frequently, and [[spell:1297365]] lasts 5 seconds longer.

### Single-Target



#### [[talent:123324]] Deathbringer

##### Opener

- In the opener, you want to get into your cooldowns as fast as possible. After that your goal is to get off as many [[spell:51128]] empowered [[spell:49020]] and not waste [[spell:441416]].

:::rotation Example [[talent:123324]] Deathbringer **Frost Death Knight** Single-Target Opener
```json
{
  "source_code": "JcaAwjUCCBduAAAAH8kZm1yRDREACNitGAAAAQgQHhMAAAgQ6FxEAAQAI66AAAAAAEwXfQAAIMAA5IAWBUAAB0yFCIkBDRAAAAgACR7xB4COQxrBAAgQ89LAAAAADIE0BkFACZkGAAgAyoBAJ4CAB0AKJ4ACAI09FQEJBIEtHDAAAIEf_C"
}
```
1. [[spell:47568]] Off-GCD
2. [[spell:439843]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:51124]] · [[spell:441424]]
4. [[spell:49020]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
5. [[spell:49020]]  [[spell:47568]] · [[spell:51124]]
6. [[spell:49020]]  [[spell:51124]]
7. [[spell:49020]]
8. [[spell:49143]]  [[spell:51124]]
9. [[spell:49020]]
:::

- As this is just an example, your opener does change based on when you have [[spell:51128]] or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends!
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:439843]].
- Cast [[spell:279302]].
- Cast [[spell:49020]] if either of the following are true:
  
  - You have 2 stacks of [[spell:51128]].
  
  
  
  - You have 1 stack of [[spell:51128]] and 3 or more Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]].
- Cast [[spell:49143]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:49020]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:49020]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].




#### [[talent:123322]]Rider

##### Opener

- In the opener your goal is to get into [[spell:51271]] and using [[spell:279302]] to summon all of your [[talent:117663]] immediately to take full advantage of them being buffed by [[spell:51271]]. Below is an example of how your opener can look using the recommended [[talent:123322]] build.

:::rotation Example [[talent:123322]]Rider **Frost Death Knight** Single-Target Opener
```json
{
  "source_code": "JQbA8sgAAAAAAIgQQnLAAAgQ0ecAGQAf_GAFMQgQHhcAOAieRMBAAEAiuOQAVgVAf9BBAgwAAkjAYFQBAEQLXIgQGMEBAYlQA4kVAwAACd_vFkEAC5CbAQQAClAgJonNcAgRyAA"
}
```
1. [[spell:47568]] · [[spell:51124]]
2. [[spell:49020]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:47568]] · [[spell:51124]]
4. [[spell:49020]]  [[spell:47568]] · [[spell:51124]]
5. [[spell:49020]]
6. [[spell:49143]]  [[spell:51124]]
7. [[spell:49020]]  [[spell:47568]]
8. [[spell:49020]]  [[spell:51124]]
9. [[spell:49020]]
10. [[spell:49143]]  [[spell:51124]]
11. [[spell:49020]]
:::

- As this is just an example, your opener does change based on when you have [[spell:51128]] or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends! This also extends the duration of your Horsemen by an additional 10 seconds.
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:279302]].
- Cast [[spell:49020]] if either of the following are true:
  
  - You have 2 [[spell:51124]] stacks.
  - You have 1 [[spell:51124]] stack and 3 Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]]
- Cast [[spell:49143]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:49020]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:49143]].
- Cast [[spell:49020]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].

##### Notes

- Do your best to pool some Runes for [[spell:51271]]. While it is not always possible, taking advantage of your [[spell:51271]] window is the best thing you can do for maximum dps.





### AoE



#### [[talent:123324]] Deathbringer

##### Opener

- In the opener, you want to get into your cooldowns as fast as possible. After that your goal is to get off as many [[spell:51128]] empowered [[spell:49020]] and not waste [[spell:441416]].

:::rotation Example [[talent:123324]] Deathbringer **Frost Death Knight** AoE Opener
```json
{
  "source_code": "JgaAwjUCCBduAAAAH8kZm1yRDREACNitGAAAAQgQHhMAAAgQ6FxEAAQAI66AAAAAAEwXfQAAIMAA5IAWBUAAB0yFCIkBDRAAAAQACR7xB4CB-lSAogwACBdATBgQJQBEQxrBAAggaAgNCBASAIUY5LAAAAQACR7xAAAAC5XKDA"
}
```
1. [[spell:47568]] Off-GCD
2. [[spell:439843]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:51124]]
4. [[spell:207230]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
5. [[spell:207230]]  [[spell:47568]] · [[spell:51124]] · [[spell:441424]]
6. [[spell:207230]]  [[spell:51124]]
7. [[spell:207230]]
8. [[spell:194913]]  [[spell:51124]]
9. [[spell:207230]]
:::

- As this is just an example, your opener does change based on when you have [[spell:51128]] or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends! This also extends the duration of your Horsemen by an additional 10 seconds.
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you have 2 charges.
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:439843]].
- Cast [[spell:279302]] if [[spell:439843]] has exploded and you have used both stacks of [[spell:441416]].
  
  - Recall it after the 15% [[spell:1265630]] buff has expired.
- Cast [[spell:207230]] if either of the following are true:
  
  - You have 2 stacks of [[spell:51128]].
  
  
  
  - You have 1 stack of [[spell:51128]] and 3 or more Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]].
- Cast [[spell:49143]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:207230]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:207230]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].

##### Notes

- [[spell:207230]] replaces [[spell:49020]] at 2 targets.
- [[spell:194913]] replaces [[spell:49143]] at 3 targets.




#### [[talent:123322]]Riders

##### Opener

- In the opener your goal is to get into [[spell:51271]] and using [[spell:279302]] to summon all of your [[talent:117663]] immediately to take full advantage of them being buffed by [[spell:51271]]. Below is an example of how your opener can look using the recommended [[talent:123322]] build.

:::rotation Example [[talent:123322]]Riders **Frost Death Knight** AoE Opener
```json
{
  "source_code": "JUbA8sgAAAAAAIgQQnLAAAgQ0ecAGQifpMAAAAABCdEyB4AH6FxEAAQAI6aAUwFAB81HEAACDAQOCgVAFAQAtchACZwQEAgVCBgTWBADAIUY5HwcEEgQuwGAEEgQJAYC6ZDHAokMAA"
}
```
1. [[spell:47568]] · [[spell:51124]]
2. [[spell:207230]]  [[spell:51271]] · [[spell:1249658]] · [[item:241288]] · [[item:270175]]
3. [[spell:279302]]  [[spell:47568]] · [[spell:51124]]
4. [[spell:207230]]  [[spell:47568]] · [[spell:51124]]
5. [[spell:207230]]
6. [[spell:194913]]  [[spell:51124]]
7. [[spell:207230]]  [[spell:47568]]
8. [[spell:207230]]  [[spell:51124]]
9. [[spell:207230]]
10. [[spell:194913]]  [[spell:51124]]
11. [[spell:207230]]
:::

- As this is just an example, your opener does change based on when you have [[spell:51128]] or not, so don't blindly cast [[spell:47568]] unless you do not have a [[spell:51128]] for your next cast!
- After this opener, you still have the ability to recall [[spell:279302]] with [[spell:1265384]], make sure you do this before [[spell:51271]] ends! This also extends the duration of your Horsemen by an additional 10 seconds.
  
  - It is off the global cooldown so you can do this at any time, and the Haste buff adds to the duration of the previous one.

##### Standard Priority

- Cast [[spell:47568]] if you are about to cap at 2 charges or if you are out of Runes and Runic Power.
- Cast [[spell:51271]].
- Cast [[spell:1249658]] with [[spell:51271]].
- Cast [[spell:279302]].
- Cast [[spell:207230]] if either of the following are true:
  
  - You have 2 [[spell:51124]] stacks.
  - You have 1 [[spell:51124]] stack and 3 Runes while not in [[spell:51271]].
- Cast [[spell:49184]] with [[spell:59052]]
- Cast [[spell:194913]] to not cap on Runic Power as long as you are not saving for [[spell:1249658]].
- Cast [[spell:207230]] with 1 stack of [[spell:51124]].
- Cast [[spell:47568]] if you do not have [[spell:51124]] or Runic Power.
- Cast [[spell:194913]].
- Cast [[spell:207230]] with no [[spell:51124]] while not in [[spell:51271]].
- Cast [[spell:49184]] without [[spell:59052]] only during [[spell:51271]].
  
  - This is purely to generate a stack of [[spell:51124]] during [[spell:51271]] **never** be done outside of [[spell:51271]].

##### Notes

- [[spell:207230]] replaces [[spell:49020]] at 2 targets.
- [[spell:194913]] replaces [[spell:49143]] at 3 targets.





## Deep Dive

### Anti-Magic Shell Runic Power

- [[spell:48707]] grants you up to 40 Runic Power based on the amount it absorbs. This is incredibly powerful as you do get quite starved on Runic Power so you end up wanting to use this to your advantage as often as possible on bosses where [[spell:48707]] isn't specifically used for defensive purposes.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Frost Death Knight** Mythic+ Talents for Altar of Fangs
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### Rav'i

- Precast [[spell:48707]] on [[spell:1296220]].
- Dodge the [[spell:1296050]].
- Soak the puddles that spawn from [[spell:1306226]].

##### The Writhing Coil

- Precast [[spell:48707]] on [[spell:1299154]]
- Interrupt [[spell:1310358]] from the **Writhing Coil**.
- Break [[spell:1299053]] as fast as possible.
- Bait the [[spell:1299130]] towards the closest wall.

##### Zul'jan

- Soak one of the beams from [[spell:1300872]].
- Remove [[spell:1300894]] by soaking [[spell:1301413]].

#### Trash Tips

At the start of the dungeon in the library area you can activate a **Arcane Tome**, it provides your party with [[spell:1254550]].

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1294567]] from **Twinfang Harrower**
  - [[spell:1306668]] from **Twinfang Harrower**
    
    - [[spell:48707]] can be used to immune the breath and walk through it.
  - [[spell:1307567]] from **High Evolutionist**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294557]] from **Primal Serpent**.
  
  
  
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.
- **Pay extra attention to these casts:**
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  
  
  
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1294567]] from **Twinfang Harrower**.




### Den of Nalorakk

:::talents **Frost Death Knight** Mythic+ Talents for Den of Nalorakk
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Precast [[spell:48707]] on [[spell:1234846]].
- Soak the [[spell:1234740]] before they explode.
- Use a defensive on [[spell:1234681]].

##### Sentinel of Winter

- Precast [[spell:48707]] for either [[spell:1235548]] or [[spell:1235829]] to immune their debuffs.
- Interrupt [[spell:1235829]] from **Fractured Shivercore**.

##### Nalorakk

- Make sure you are on Zul'jarra to get [[spell:1261776]] during [[spell:1243569]].
- Intercept the **Echoes of Nalorakk** during [[spell:1243002]].

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1238687]] from **Spirit of Misery**.
  - [[spell:1238760]] from **Starvation Effigy**.
  - [[spell:1241463]] from **Avatar of Determination**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  
  
  
  - [[spell:1241463]] from **Avatar of Determination**.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  
  
  
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Frost Death Knight** Mythic+ Talents for Murder Row
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- In general you should hit **Nibbles** until Kystia Manaheart loses her shield.
- You can remove the **Mirror Images** with [[spell:49576]] and [[spell:207167]].
- Use your cooldowns during [[spell:1265412]] for maximum damage.

##### Zaen Bladesorrow

- Destroy the **Fel-infused Freight** with [[spell:1214357]].
- Hide behind a **Forbidden Freight** during [[spell:1218347]].

##### Xathuux the Annihilator

- Use [[spell:48707]] on [[spell:1214650]] to prevent the stacks for its duration.
- Precast [[spell:48707]] to prevent the dot from [[spell:1295452]].
- Stay on the boss if targeted by [[spell:1214663]].
- Use a defensive on [[spell:1295455]].

##### Lithiel Cinderfury

- Use [[spell:48707]] to walk through and immune [[spell:1217345]].
- If you do not have [[spell:48707]] available, wait for the boss to finish the cast [[spell:1217384]] before using [[spell:1214675]].
- Use your cooldowns after [[spell:474457]] to kill the **Wild imps** and get extra stacks of [[spell:377226]].
- Use a defensive on [[spell:474457]].
- Interrupt [[spell:474375]] from **Kystia Manaheart**.

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1297682]] or [[spell:1217973]] from **Corrupted Warlock**.
  - [[spell:1215872]] from **Defiled Golem**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1216571]] from **Felonious Mage**.
  
  
  
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.
- **Pay extra attention to these casts:**
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1216300]] from **Row Hooligan**.
  
  
  
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Frost Death Knight** Mythic+ Talents for The Blinding Vale
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Precast [[spell:48707]] to immune the DoT from [[spell:1234753]].
- Interrupt [[spell:1235616]] from **Kezkitt**.
- Intercept the [[spell:1235564]].
- Use a defensive if targeted by [[spell:1235640]].

##### Ikuzz the Light Hunter

- You can always break [[spell:1236658]] by alternating the precasting of [[spell:48707]] and using [[spell:212552]] after it is applied to you.
- Get away from the boss if targeted by [[spell:1237090]].
- Use a personal on [[spell:1236746]].

##### Lightwarden Ruia

- Interupt [[spell:1239821]] from **Lightwarden Ruia**.
- Use a defensive if targeted by [[spell:1240098]].
  
  - You can stack together with other people.
- Spread out during [[spell:1240210]], make sure not a single person is behind you to not cleave each other.

##### Ziekket

- Intercept the [[spell:1246858]] before they reach the boss.
- Use a defensive when targeted by [[spell:1246607]].

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  
  
  
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.
- **Pay extra attention to these casts:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  
  
  
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.
      
      - You can dispel it with [[talent:124941]].
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Frost Death Knight** Mythic+ Talents for Voidscar Arena
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Precast [[spell:48707]] when you are targeted with [[spell:1222098]].
  
  - Try to be as close to each other as it spawns the **Ethereal Shades**.
- Watch the **Ethereal Shades** during [[spell:1300259]].

##### Atroxus

- Precast [[spell:48707]] before the **Toxic Creeper** spawns to avoid [[spell:1222692]] for the duration of [[spell:48707]].
- Kill the **Toxic Creeper** as fast as possible.
- Use your cooldowns while the **Toxic Creeper** is alive.
- You can dispell [[spell:1222642]] and [[spell:1226031]] with [[talent:124941]].
- Use a defensive while the **Toxic Creeper** is alive.

##### Charonus

- Spread out and use both [[spell:48707]] and [[spell:48265]] for [[spell:1227197]] to avoid the DoT from it.
- Put the [[spell:1223298]] into the [[spell:1264191]].
- Spread out during [[spell:1227197]] and use a personal.
- Either hide behind the tank when targeted by [[spell:1222755]] or kite the projectile.

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1299905]] from **Voidtouched Magi**.
  - [[spell:1289260]] from **Agitated Voidscythe**.
  - [[spell:1252406]] from **Devouring Brutalizer**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  
  
  
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.
- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  
  
  
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### King's Rest

:::talents **Frost Death Knight** Mythic+ Talents for King's Rest
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Precast [[spell:48707]] when [[spell:265773]] is cast. 
  
  - This goes on 2 random players.
- Keep the **Animated Gold** away from the **Golden Serpent** with [[talent:124926]] and [[spell:119381]].
- It is adviced to use a defensive on [[spell:1311987]]**.**

##### Mchimba the Embalmer

- Precast [[spell:48707]] for [[spell:267618]]. This targets a random player but you have a chance to immune it.
- If you can not immune [[spell:267618]], use a defensive or spam [[spell:49998]] throughout its duration at higher key levels.
- [[spell:267639]] drops a puddle, place it in a good spot.
- Interrupt [[spell:267763]] from the **finished Mummy**.
- If necessary, use [[spell:48707]] to run over the fire pools.

##### The Council of Tribes

- Use a defensive on [[spell:266231]].
- Soak the [[spell:266951]].
- Interrupt [[spell:267273]] from **Zanazal the Wise**.
- Kill the **Explosive Totem** before it finishes [[spell:267077]].

##### Dazar, the first King

- Precast [[spell:48707]] to immune [[spell:1303267]].
- Dazar, the first King shares health with **T'zala** due to [[spell:1303519]].
  
  - T'zala spawns after **Dazar, the first King** reaches 80%.
- Interrupt [[spell:269369]] from **Reban**.

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:271640]] from **Shadow of Zul**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  
  
  
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.
- **Pay extra attention to these casts:**
  
  - [[spell:270003]] from **Animated Guardian**.
  
  
  
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1297918]] from **King A'akul**.
  
  
  
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Frost Death Knight** Mythic+ Talents for Ruby Life Pools
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- [[spell:373680]] happens on 66% and 33% boss health.
  
  - Plan your [[talent:124826]] usage accordingly to break the [[spell:372988]] as fast as possible.
- Put the [[spell:372851]] away from the group and use a defensive on it.
- Interrupt [[spell:372808]] from **Melidrussa Chillworn**.

##### Kokia Blazehoof

- Precast [[spell:48707]] on [[spell:373692]] from **Blazebound Firestorm**.
- Maximize your cleave damage on this boss.
- Use your cooldowns while the **Blazebound Firestorm** is alive and you are able to hit both it and the boss.
- Interrupt [[spell:373017]] from **Blazebound Firestorm.**
- Aim the [[spell:372819]] properly, do not waste too much space in the room.

##### Kyrakka and Erkhart Stormvein

- Go towards the edge of the room on expiration of [[spell:381602]] as it drops a [[spell:381868]].
- Use a defensive on  [[spell:381602]].
- [[spell:381517]] moves the [[spell:381868]].
  
  - [[spell:381517]] follows a counterclockwise pattern.
- Make sure to use your cooldowns when you can cleave both bosses.

#### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:392640]] from **Thunderhead**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.
- **Pay extra attention to these casts:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  
  
  
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.
- **Dangerous debuffs to be wary of:**
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  
  
  
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Frost Death Knight** Mythic+ Talents for Temple of Sethraliss
```json
{
  "source_code": "CuPAPMFb_SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA",
  "code": "CuPAPMFb/SlrF4ON4GtDAdVVKOAzMjZmZAz2MzMzMLmZkZMmZmZGYMzwMzMjZAAAAAAAAAYMbDMgFwywEyYBzMMzAzAYYmBYGYA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Precasting [[spell:48707]] works both when targeted by [[spell:1288457]] and [[spell:1288864]].
- Always hit the target that does not have [[spell:1289229]].
- [[spell:1288864]] puts down a puddle at the end.
- [[spell:1289059]] pushes you back, make sure to not pull any uncessary trash during the encounter.

##### Merektha

- Precasting works on [[spell:1293048]] and allows you to stand in [[spell:1291622]].
- You can dispell [[spell:267027]] from the **Toxic Viper**.
- You can remove [[spell:263958]] with [[spell:119381]].
- Use a defensive on [[spell:1293048]].

##### Galvazzt

- If you need to walk through [[spell:1289589]], use [[spell:48707]] before walking through it.
- Intercept each [[spell:265986]] from reaching the boss with atleast 1 player.
- Use a defensive whenever you are in danger.

##### Avatar of Sethraliss

- [[spell:48707]] works on many things on this boss. [[spell:1302153]], [[spell:1300877]], and [[spell:1302826]].
- Use a defensive on [[spell:1302153]], it also drops a puddle on the ground.
- Soak the [[spell:1300869]].
- Interrupt [[spell:1302158]] from **Twisted Hexxers**.

##### Trash Tips

- **Abilities you can pre-use [[spell:48707]] on:**
  
  - [[spell:1303486]] from **Orb Watcher**.
  - [[spell:1302153]] from **Twisted Watcher**.
- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1291262]] from **Storm Adept**.
  
  
  
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- **Pay extra attention to these casts:**
  
  - [[spell:272655]] from **Sand-Sworn Rider**.
- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  
  
  
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got revamped going into **The War Within Season 3** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +4 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Frost Death Knight**

- Xal'atath's Bargain: Ascendant
  
  - Hit as many orbs as possible with [[spell:207167]]
  - [[spell:49576]] the far orbs if they are by themselves.
- Xal'atath's Bargain: Voidbound
  
  - Focus and cleave off of this target as mobs take reduced damage while it is alive.
- Xal'atath's Bargain: Oblivion
  
  - Soak any orbs that are close in melee.
- Xal'atath's Bargain: Devour
  
  - Dispel this with [[talent:96178]] if you are playing it.
  - If you have taken a considerable amount of damage in the last few seconds, you can use 1 [[spell:49998]] to help out your healer.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Frost Death Knight**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "JoAJFQAIkEDKBMQAEA"
}
```
**力量 ＞ 暴击 ≥ 急速 ＞ 精通 ≫ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech** **-** Provides additional healing through damage dealing.
- **Speed -** Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

:::callout This is an Absolute BiS List
While these are the items that you should be aiming to acquire for your absolute Best in Slot, these items will not always be the best until you achieve this exact combination of items.

For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>) whenever you get what can be an upgrade!

:::

| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:251229@BgQAAcEACKgTBA]] into [[item:271474@DiQBAsPAnk7cVrTOC4UAdV9A]] | Catalyst of Voidscar Arena |
| Neck | [[item:268265@BERAAsPAM06wQrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:268226@BgQAAcEA5IgTBA]] into [[item:271472@DgQBAsPAXk7kjAOFgwXQ]] | Catalyst of Nymrissa Wavecaller |
| Cloak | [[item:268253@BgQAAsPA5IAWBA]] | Coiled Altar / Catalyst |
| Chest | Convert [[item:268222@BgQAAsPA5IAWBA]] into [[item:271477@DgQBAsPAJk7kjAYFgvXQ]] | Catalyst of Coiled Altar |
| Wrist | [[item:237834@FiQAAsPAaA80qKEDtO3WzSB]] | Crafted |
| Gloves | Convert [[item:268220@BgQAAcEA5IgTBA]] into [[item:271475@BgQBAsPA5IgTBw7FEA]] | Catalyst of The Twin Fangs |
| Belt | [[item:268259@BiQAAsPAM06kjAYF]] | Coiled Altar |
| Legs | [[item:271878@DARAAsPAhu7YhN5IAWB]] | Ula'tek |
| Boots | [[item:237828@HgQAAsPAaA8kSuTrqQ3WzSB]] | Crafted |
| Ring 1 | [[item:273792@DiQAAsPA1j7wQrjgC4UA]] | Altar of Fangs / The Great Vault |
| Ring 2 | [[item:158366@DiQAAsPA1j7wQrTcj4UA]] | Temple of Sethraliss / The Great Vault |
| Trinket 1 | [[item:270173@BgQAAsPA5IAWBA]] | Coiled Altar |
| Trinket 2 | [[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] | Ula'tek |
| Main-Hand | [[item:268209@RgQAAsPAgBNA5IAWBA]] | Coiled Altar |
| Off-Hand | [[item:268202@RARAAsPAOLPAXYTOCgVA]] | Ula'tek |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@BgQAAsPACKQQBA]] | Murder Row |
| Neck | [[item:251173@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:239037@BgQAAsPACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAsPACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251151@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:159409@BgQAAsPACKQQBA]] | King's Rest |
| Gloves | [[item:251214@BgQAAsPACKQQBA]] | Den of Nalorakk |
| Belt | [[item:159418@BgQAAsPACKQQBA]] | King's Rest |
| Legs | [[item:273776@BgQAAsPACKQQBA]] | Altar of Fangs |
| Boots | [[item:159412@BgQAAsPACKQQBA]] | King's Rest |
| Ring | [[item:273792@BgQAAsPACKQQBA]] | Altar of Fangs |
| Ring | [[item:158366@BgQAAsPACKQQBA]] | Temple of Sethraliss |
| Passive Trinket | [[item:250228@BgQAAsPACKQQBA]] | Murder Row |
| On-Use Trinket | [[item:273797@BgQAAsPACKQQBA]] | Altar of Fangs |
| Weapon | [[item:158373@BgQAAsPACKQQBA]] | Temple of Sethraliss |





### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on the mythic+ dungeon.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270173@BgQAAsPA5IAWBA]] - Single + 2 Target with [[item:268209@RgQAAsPAgBNA5IAWBA]]  <br>[[item:270164@BgQAAsPA5IgTBA]] - 2 or more targets without the other set bonus  <br>[[item:270175@BgwAAsPA5IAWBUAAB0yFCA]] |
| **A-Tier** | [[item:270165@BgQAAsPA5IgTBA]]  <br>[[item:250228@BgQAAsPACKgTBA]] |
| B-Tier | N/A |
| C-Tier | [[item:250238@AgQAAIoAOFA]]  <br>[[item:273797@BgQAAsPACKgTBA]] |
| **Junkyard** | [[item:193757@BgQAAsPACKgTBA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:270168@BgQAAsPA5IAWBA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]]  <br>[[item:270163@AgQAAkjAOFA]] |

### Embellishments

- [[item:251513@AgQAAcbNLFA]]
- [[item:251490]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 at max item level therefore it is not normally beneficial to equip crafted items outside of your 2x Embellishments. 
  
  - While you are gearing up and do not yet have 334 pieces of gear or Myth track items on some slots, you can use your Myth Dawncrest to craft 331 pieces with Crit or one of Haste and Mastery depending on your stats.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]]
  
  
  
  - [[item:241324]]
    
    - Which one you use depends on your stats, check Top Gear in Raidbots to figure out which is best for you!
- **Food**
  
  - [[item:255846]] or [[item:255845]]
    
    - [[item:242275]] or [[item:255847]] have no stamina but are the personal items of this.
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- Unique
  
  
  
  - Any of the following depending on your stats:
    
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240890]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@BAAAAwP]]  <br>[[item:275707@BAAAAsP]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977@BAAAAsP]] |
| Wrist | [[item:275707@BAAAAsP]] |
| Waist | [[item:275707@BAAAAsP]] |
| Legs | [[item:244641@BAAAAwP]] |
| Boots | [[item:243953@BAAAAwP]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Main-Hand | [[spell:53344]] |
| Off-Hand | [[spell:62158]] |

Speed Enchants are also viable in place of the Avoidance enchants, especially at higher item levels.

:::

:::column
:::gear **Frost Death Knight** Enchantments in Raids
```json
{
  "source_code": "IkFZ7DQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NARDIAiQgBNAAAgQOLP"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[spell:53344]] |  |
| 副手 | [[spell:62158]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAsP]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Frost Death Knight** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:59224]] and [[spell:65116]] --Dwarf
  
  - Can dispel Magic and Bleed debuffs.
  
  
  
  - As well as having [[spell:20594]], [[spell:59224]] is a very strong racial bonus granting Critical Strike damage which makes this one of our better races along with Tauren as it has the same racial ability.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases:
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].

:::columns
:::column
:::simulation **Frost** **Death Knight** Race Sims
```json
{
  "source_code": "JUtAQ1xAfAAACewSyF2ZncXYMYHBpO_ZIVAFw7nBLlWbiVHbLYHBWxHaINgCAAAAx0laINgAAAAAA0WaINAJAAAAKYcaINACAAAAVY5aINwHAAggJI0dv52ch1GZphgdEYO8nh0AFAAAAAAdnh0AYAAAAsZ0qh0AJAAAAsEeqh0AGAAAAAEdrh0AcAAAAYv7ph0AbAAAA4bkmh0ABwELGE0a15GZhdgdE0BvNYJ8CRwRv52aKYHBWiBaINQJAAAAjNqaINwCAAAA4ndaINwIAAAAlydZINQAAAAAFq-aINgIAAAAUhOaINwAAAAAAR3aINQAaRXBQF2JrVXC2RwuusGSDQAAAIYBOl2ZoRXrcJgMOrWCSQ-AEFWesylAiylaINgHAAAAbeuZINwBAAAAqxuaINgFAAAA8FpaINQHAAAAg-saINAIAAAA08faINAF"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292364]] | 237,518.64 |
| 种族 31 [[spell:292363]] | 238,065.34 |
| 种族 10 | 239,988.77 |
| 种族 2 | 239,028.00 |
| 种族 36 | 239,384.16 |
| 种族 8 | 241,240.33 |
| 种族 31 [[spell:292360]] | 237,507.59 |
| 种族 5 | 237,008.00 |
| 种族 24 | 240,454.42 |
| 种族 9 | 240,097.17 |
| 种族 6 | 241,105.00 |
| 种族 28 | 239,547.84 |
| 种族 27 | 236,102.97 |
| 种族 31 [[spell:292359]] | 237,296.45 |
| 种族 31 [[spell:292362]] | 237,666.34 |
| 种族 37 | 240,269.55 |
| 种族 11 | 239,463.88 |
| 种族 35 | 235,378.58 |
| 种族 1 | 241,578.08 |
| 种族 34 | 238,497.31 |
| 种族 3 | 241,105.00 |
| 种族 31 [[spell:292361]] | 240,826.92 |
| 种族 4 [[spell:154797]] | 240,440.78 |
| 种族 4 [[spell:154796]] | 239,986.53 |
| 种族 30 | 236,446.42 |
| 种族 7 | 240,561.66 |
| 种族 22 | 240,197.94 |
| 种族 29 | 240,446.50 |
| 种族 32 | 239,612.81 |
:::

:::

:::

### Recommendation

For **Frost** in Mythic+, I would recommend Dwarf as it is currently one of the best output racials for both **Frost** and **Unholy** as well as having the overall most useful utility ability as well.

## Macros

Discover recommended macros for **Frost Death Knight** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
[[spell:51052]] - *Casts [[spell:51052]]* *at your Cursor position*.

```wow-macro
/cast [@cursor] Anti-Magic Zone
```

[[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]] - *Casts [[spell:43265]] at your cursor position.*

```wow-macro
/cast [@cursor] Death and Decay
```

*If you do not like [[spell:43265@FJQDhBVAK7SAuchAiKAAKunADqrAlwvAN1TAecNB12TAxaOAuzwBvzwBGEA]]* *on your cursor you can replace [@cursor] with [@player] and it will instead put it at your feet. Having either of these is important as it removes the targeting reticle and allows you to get it out faster.*

```wow-macro
/cast [@player] Death and Decay
```

:::

:::details Mouseover Macros
[[spell:45524]] - *Casts ‍[[spell:45524]] at your mouseover if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Chains of Ice
```

[[spell:47528]] - *Casts [[spell:47528]]* *at your mouseover if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Mind Freeze
```

[[spell:49576]] - *Casts ‍[[spell:49576]] at your mouseover target if it exists or your target*.

```wow-macro
/cast [@mouseover,exists,harm][@target,exists,harm] Death Grip
```

[[spell:61999]] - *Casts [[spell:61999]] on your mouseover so you can use this on your frames.*

```wow-macro
/cast [@mouseover,help,dead][]Raise Ally
```

:::

:::details Focus Macros
Set Focus Mouseover - *This will set your focus to your mouseover.*

```wow-macro
/focus [@mouseover]
```

Focus [[spell:49576]] - *Casts [[spell:49576]] at your focus.*

```wow-macro
/cast [@focus] Death Grip
```

Focus [[spell:47528]] - *Casts [[spell:47528]] at your focus.*

```wow-macro
/cast [@focus] Mind Freeze
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Frost Death Knight**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Unholy Death Knight Interface in Mythic+](<https://assets-ng.maxroll.gg/wordpress/Unholy_dungeon-mxr-1024x626.webp>)

**Frost Death Knight** Interface in Mythic+

:::accordion
:::details Addons
- **Echo Raid Tools** -- Raid cooldowns and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **ElvUI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Frost**

- All ability damage reduced by 10%.
- Melee damage reduced by 20%.
- [[spell:51271]] now increases Strength by 20% (was 30%).
- [[spell:49184]] damage increased by 100%.
- [[spell:47568]] damage increased by 30%.
- [[spell:194913]] damage increased by 30%.
- [[spell:435010]] damage increased by 30%.
- [[spell:55095]] damage increased by 100%.
- [[spell:196770]] damage increased by 40%.
- [[spell:207230]] damage increased by 20%.
- [[spell:49143]] damage increased by 25%. Does not affect Frostbane.
- [[spell:49020]] damage reduced by 12.5%.
- [[spell:1249658]] damage reduced by 20%.
- [[spell:1228433]] damage reduced by 30%.
- [[spell:279302]] damage reduced by 20%.
- [[spell:207200]] grants a shield equal to 35% of damage dealt (was 30%).

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer 
  
  - [[spell:441894]] now causes [[spell:55095]] to deal its damage 75% faster (was 100%).
  - [[talent:135992@AJgBBA]] now increases [[spell:49143]] damage by 35% (was 15%).
  - [[spell:439843]] cast and explosion damage reduced by 25%.
  - [[spell:441416]] damage reduced by 17%.
- [[talent:123322]]Rider of the Apocalypse
  
  - Whitemane's [[spell:444633]] damage reduced by 30%.

:::

:::

:::

:::

:::accordion
:::details Patch 12.0.5
**Death Knight**

- Chosen of Frostbrood (Rank 3) has been updated
  
  - When [[talent:96236]] is recalled, it now grants the full Haste bonus at 50% duration instead. The ability used to recall [[talent:96236]] is no longer on the global cooldown.

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer 
  
  - [[talent:135991@AJgBBA]] secondary effect has been redesigned
    
    - Casting [[talent:117659]] grants 1 stack of [[talent:117665@FJQAm4rBGEA]] with 100% first scythe and 100% second scythe effectiveness.
  - [[talent:117665@FJQAm4rBGEA]] has been updated 
    
    - After [[talent:117665@FJQAm4rBGEA]] explodes, your next 2 [[talent:96246]] or [[talent:96243]] cost 1 Rune and summon 2 scythes to strike the enemies. The rest of the effect remains the same.

:::

:::

:::

:::

:::accordion
:::details Patch 12.0.1
**Death Knight**

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer 
  
  - [[spell:441416]] first scythe damage increased by 30%.
  
  
  
  - [[spell:439843]] damage increased by 25%.
  
  
  
  - [[talent:135992@AJgBBA]] now increases the damage of [[spell:49143]] and [[spell:1228433]] by 15% (was 5%), and also has an additional effect – [[spell:439843]] grants 3 stacks of [[spell:377098]] if it is known.
  - [[spell:443560]] now makes [[spell:434711]] 100% more effective on the primary target, and now grants 8% increased Strength when no enemies are struck by [[spell:437161]] (was 5%).
- [[talent:123322]]Rider of the Apocalypse
  
  - All Horsemen damage reduced by 65%.
  - [[spell:444037]] now increases the damage of [[spell:55095]], [[spell:49143]], and [[spell:1228433]].
  - Trollbane's [[spell:49020]] now correctly becomes Frost when consuming a [[spell:51124]] with One-Handed weapons.
  
  
  
  - [[spell:444072]] now increases the damage of Runic Power abilities by 10% when you have 2 or more active Horsemen (was 20%).

:::

:::

**Frost**

- [[spell:49020]] damage increased by 15%.
- [[spell:49143]] damage reduced by 10%.
- [[spell:1228433]] damage reduced by 10%.
- [[spell:1249658]] and [[spell:279302]] cooldowns are no longer reset after an encounter.

:::

:::

:::accordion
:::details Patch 12.0
**Death Knight**

- New Talent: [[talent:136524]]
  
  - [[spell:61999]] costs 30 less Runic Power.
- New Talent: [[talent:136525]]
  
  - The cooldown of [[talent:96204]] is reduced by 30 seconds, and you receive 50% increased healing while its healing absorb is active.
- New Talent: [[talent:96189]]
  
  - While you are below 50% health, your Ghoul sacrifices 4% of its maximum health to heal you for 1% of your maximum health every second.
- [[talent:96200]] heal reduced to 20% of all damage taken in the last 5 seconds (was 25%).
- [[spell:43265]] damage increased by 130%.
- [[talent:96187]] now reduces the cooldown of Lichborne by 30 seconds (was reduces damage taken).
- [[talent:96198]] is now a 2-point talent.
- [[talent:96180]] is now a 2-point talent and has been moved to the first gate.
- [[talent:136526]] is now a choice talent against [[talent:96193]].
- [[spell:327574]] has been removed.

**Frost**

:::accordion
:::details Hero Talents
- [[talent:123324]] Deathbringer
  
  - New Talent: [[talent:135992@AJgBBA]]
    
    - Frost: [[talent:96245]] damage increased by 5%. [[spell:194913]] damage increased by 5%.
  - New Talent: [[talent:135991@AJgBBA]]
    
    - Frost: [[talent:117659]] deals 5% increased damage. Casting [[talent:96236]] grants 2 stacks of [[talent:117665@FJQAm4rBGEA]]with 100% first scythe and 100% second scythe effectiveness.
  - New Talent: [[talent:135993@AJgBBA]]
    
    - Frost: The effectiveness of [[talent:96195]]is increased by 50%.
  - [[talent:117658]] no longer causes enemies struck to deal 5% reduced Physical damage for 10 seconds.
- [[talent:123322]]Rider of the Apocalypse 
  
  - New Talent: [[talent:135999@AJgBBA]]
    
    - [[talent:125874]]summons forth Trollbane for 6 seconds.
  - New Talent: [[talent:135998@AJgBBA]]
    
    - Casting [[talent:125874]] or [[talent:96243]] orders Trollbane to cast his [[talent:96246]] or [[talent:96243]] alongside you at 100% effectiveness.
  - New Talent: [[talent:135997]] 
    
    - The abilities that Horsemen cast deal 5% increased damage.
  - Mograine's [[spell:43265]] damage increased by 50%.
  - Mograine's[[spell:43265]] now extends the duration of diseases on the targets by 1 second whenever it deals damage.
  - Trollbane's [[spell:45524]] no longer deals damage.
  - Fixed an issue causing [[talent:96245]] to not consume [[talent:96228]] debuff.

:::

:::

:::accordion
:::details Spec Changes
- [[talent:96246]] has been updated:
  
  - Two-Handed: A brutal attack that deals Physical and Frost damage.
  - Dual Wield: A brutal attack with both weapons that deals a total of Physical and Frost damage.
- [[talent:96224]] now has an additional effect – When [[talent:96223]] consumes the [[spell:50401]] stacks on your main target, it deals an additional 250% damage instead.
- [[talent:125877]] has been updated:
  
  - While [[talent:125874]] is active your auto-attack critical strikes increase its duration by 1 second, up to 4 seconds.
- All ability damage reduced by 19%.
- Auto-attack damage increased by 300%.
- [[talent:96223]] damage reduced by 10%.
- [[talent:96222]] secondary target damage reduced by 20%.
- [[talent:96238]] now causes Runic Power spending abilities to have a chance to additionally deal 30% of the damage dealt over 4 seconds.
- [[talent:96225]] effect is now instant and no longer has a projectile.

:::

:::

:::

:::

## FAQ

:::accordion
:::details Q: How do [[spell:51124]] Procs Work?
A: As a 2 Handed Obliteration **Frost Death Knight**, every auto attack critical strike grants you a stack of [[spell:51128]]

As a dual-wielding **Frost Death Knight**, every auto attack critical strike gives you a 30% chance to proc it, stacking up to 4 times meaning at worst you get a [[spell:51128]] after 4 auto attack critical strikes.

- 1 Crit = 30% Chance
- 2 Crits = 60% Chance
- 3 Crits = 90% Chance
- 4 Crits = 100% Chance

:::

:::

---

### Credits

Written By: **Miniaug**

Reviewed By: **Verb**

:::changelog 更新记录
**2026-08-12** Updated for patch 12.1

**2026-06-17** Updated for patch 12.0.7

**2026-04-22** Updated for patch 12.0.5

**2026-02-25** Updated for Midnight Launch!

**2026-02-10** Upated for patch 12.0.1

**2026-01-21** Updated for Midnight Pre-patch 12.0.0

**2025-10-08** Updated for patch 11.2.5

**2025-08-06** Updated for patch 11.2

**2025-06-19** Updated for patch 11.1.7

**2025-05-21** Updated for patch 11.1.5

**2025-02-25** Updated for patch 11.1.

**2024-12-18** Updated for patch 11.0.7.
BiS Updated

**2024-10-22** Updated for Patch 11.0.5.
Added new builds, updated Best in Slot gear, updated rotation and cooldown usage section to include Breath of Sindragosa.

**2024-09-08** Updated Best in Slot gear.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
