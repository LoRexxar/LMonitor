Welcome to the **Havoc Demon Hunter** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Havoc Demon Hunter** Mythic+ Best in Slot
```json
{
  "source_code": "JQpAIGkA3_fABMgJEIIEBAwJ5OADtOggCchNYFQApfBBAERAAcVrJQBXMWDWBEwrkQgAIUAAXk7ACKgTBY9FEEAtJIBAJkgEogcpDEA4XQAgIEAAFkEDYFQAwmQIMF6uDIoAYFQwXQQAf5mACgQAAEPuFUEMBA2uDQICBAQrqQgHAHwakdbNLFQAySCBAgQAAIoAOFQAZfBBCiQAAUPuB4RBSggnqJgOSAAGf9BBAgwAAEwYcUAABo0FCEQXBIRACBBWBEQ3XkhTIE7FEEgfEMQuFAJUBARoDYACBAgHAPwA5OApqQwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240908]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240908]] |
| 肩部 | [[item:271535]] | [[item:243991]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240908]] |
| 腿部 | [[item:271536]] | [[item:244641]] |
| 脚部 | [[item:159327]] | [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240908]] · [[item:273069]] · [[item:245790]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268249]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:243971]] |
| 副手 | [[item:237840]] | [[item:245790]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Havoc Demon Hunter**, you have access to Eternal Hunt, which empowers your [[spell:198013]], lowers the cooldown and increases the target cap of [[spell:370965]], and gives you a guaranteed reset of your [[spell:188499]] after casting [[spell:198013]].

- **Rank 1** causes [[spell:370965]] to empower your next [[spell:198013]], doubling it's damage and increasing it's area of effect.
- **Rank 2** gives [[spell:370965]] 15/30 sec reduced cooldown, makes it do 15/30% more damage and it's DoT effect can apply to 2/4 extra targets.
- **Rank 3** Increases [[spell:188499]] damage by 20%, and will cause it to reset it's own cooldown the first time it's cast after fully channeling [[spell:198013]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-havoc-mxr.webp>)

Eternal Hunt

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:370965]]
    
    - Previously in the Class Tree, this ability has been moved to the Spec Tree.
  - [[spell:342817]]
    
    - Previously an active ability, [[spell:342817]] has been reworked into a passive effect when [[spell:188499]] strikes 3 or more targets.
- **Class Tree**
  
  - [[spell:213241]]
    
    - Now generates 15 fury and no longer has a chance to reset, which results in slower fury generation overall.
  
  
  
  - [[spell:1266316]] /[[spell:1266496]]
    
    - Causes [[spell:472649]] to remove 1 Disease/Curse effect respectively.
  
  
  
  - [[spell:1266307]]
    
    - Gives 1 additional charge of [[spell:198589]]. Gives great defensive power when combined with [[spell:205411]] from the Spec Tree.
  
  
  
  - [[spell:1266329]]
    
    - 15% reduced magic damage taken for 12s after interrupting. Situational, but this is a great defensive tool in situations where are taking magic damage, and interrupting is available.
- **Removed**
  
  - [[spell:196555]]
    
    - The removal of [[spell:196555]] has a negative impact on survivability, but is compensated by the new combination of [[spell:1266307]] and [[spell:205411]].
  
  
  
  - [[spell:204513]]
    
    - Previously a baseline ability, [[spell:204513]] has been made unique to the Vengeance spec.
  
  
  
  - [[spell:389815]]
    
    - Previously a capstone in the Class Tree, [[spell:389815]] has been made unique to the Vengeance spec.
  
  
  
  - [[spell:211881]]
    
    - The removal of this ability was "compensated" by [[spell:1266296]], a talent node in the Class Tree. This makes the primary target of [[spell:179057]] stunned for an additional 2 sec.
  
  
  
  - [[spell:258925]]
    
    - [[spell:258925]] was a talent option in the Spec Tree for some on demand AoE burst, which is now removed.
  
  
  
  - [[spell:162243]]
    
    - Previously offered as a choice node with [[spell:203555]]. The choice node is removed entirely, and [[spell:203555]] is now baseline.

## Hero Talents

- [[talent:123330]] and [[talent:123329]] are the Hero Talent tree options for Havoc Demon Hunter.[[talent:123329]] is currently ahead of [[talent:123330]] in both AoE and Single-Target scenarios, except if you are looking for funnel damage.

### [[talent:123329]]

#### Hero Talent overview

- The [[talent:123329]] hero talent tree is generally more passive than [[talent:123330]]. In addition to it's normal benefits, casting [[spell:191427]] transforms [[spell:198013]] into [[spell:452497]] and [[spell:258920]] into [[spell:452487]] empowering them, causing them to trigger a [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]] the first time they are cast.
- At the same time, the tree has talents like [[spell:452414@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]], [[spell:452408@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] and [[spell:452410@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] that significantly increase your output out of [[spell:191427]].
- [[talent:123329]] is generally considered easier to play compared to [[talent:123330]], which is something worth considering since it might give you more room to focus on more important stuff than damage, such as mechanics and living.
- Make sure to put [[spell:258920]] and [[spell:198013]] on cooldown before using [[spell:191427]] as [[talent:117509]] resets those abilities.

#### Patch 12.0

- Patch 12.0 introduced 3 new talent nodes to the [[talent:123329]] hero talent tree:
  
  1. [[spell:1272364]]. Fire damage increased by 5%. Effect is doubled while in [[spell:213410]].
  2. [[spell:1272405@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]. [[spell:258920]] has a 25% chance to reignite after it expires.
  3. [[spell:1272453]]. Instantly trigger a [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]] when you enter [[spell:213410]].

### [[talent:123330]]

#### Hero Talent overview

- With [[talent:117512]], consuming 6 soul fragments makes your [[spell:185123]] ability become [[spell:442294]]. After casting [[spell:442294]], your next [[spell:162794]]/[[spell:201427]] and [[spell:188499]]/[[spell:210152]] are enhanced.
  
  1. When [[spell:188499]] is enhanced, it will trigger [[spell:442718]] on cast, which will cast 3 additional glaive slashes to nearby targets. If [[spell:188499]] is cast after [[spell:162794]], it will cast 6 slashes instead.
  2. When [[spell:162794]] is enhanced it applies [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]. If [[spell:162794]] is cast after [[spell:188499]], it will apply 1 additional stack of [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]].

- Additionally, after consuming both enhancements you gain Thrill of the Fight, increasing the damage of your next [[spell:442294]] by 30% and increasing Haste by 6% for 30 sec.

#### Patch 12.0

- Patch 12.0 introduced 3 new talent nodes to the [[talent:123330]] hero talent tree:
  
  1. [[spell:1272143]]. [[spell:370965]] shatters 1 soul fragment. Additionally [[spell:188499]] and [[spell:162794]] have a 15% chance to shatter 1 soul fragment.
  2. [[spell:1272138]]. The damage of [[spell:442294]] is increased by 20%, and all other Physical-only damage is increased by 10%. This will also increase the damage of [[spell:474339]].
  3. [[spell:1272153]]. This doubles the amount of glaives triggered when [[spell:188499]] is cast 2nd. It also allows [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] to stack up to 3 times, and [[spell:162794]] will apply an additional stack when cast 2nd.

## Talents

### [[talent:123329]] M+ Build

:::talents [[talent:123329]] **Havoc Demon Hunter** Mythic+  Build
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

- These are some default M+ talents for [[talent:123329]]. Fairly well rounded, which gives a good balance between aoe and single target DPS.

### [[talent:123330]] Alternative

:::talents [[talent:123330]] **Havoc Demon Hunter** Mythic+  Build
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

- The [[talent:123330]] variant will provide you some of the best funnel damage in the game to destroy priority targets. This however comes at the cost of less AOE damage.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:258860]]
  
  - Does massive damage in a frontal cone and causes [[spell:162794]] and [[spell:188499]] to deal additional Chaos damage to affected enemies.

- [[talent:112955]]
  
  - Every time you cast [[spell:198013]] the cooldown is reduced by 2.5 seconds, up to 10 seconds max.

- [[spell:388108]]
  
  - Hitting a target before it hits you increases your critical strike chance by 10%, this is reset on every hostile target by casting [[spell:198793]].

- [[spell:370965]]
  
  - This strong offensive Cooldown puts a major DoT on your target and up to 5 targets in your path.

- [[spell:390197]] + [[spell:427775]]
  
  - The combination of these talents gives a high potential for AoE damage, and if talented it is very important to keep your [[spell:258920]] on cooldown at all times, but especially in AoE scenarios.

#### Class Tree

- [[spell:196718]] 
  
  - This group-wide defensive cooldown creates a zone of [[spell:196718]] at the **Havoc Demon Hunter's** location, granting all allies within it a 15% chance to avoid all damage from incoming attacks. This chance is doubled when not in a raid.

#### Hero Talents

- [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]]
  
  - Empowers your next [[spell:201427]] and [[spell:210152]] after entering [[spell:213410]] to explode around you.  
    When entering [[spell:213410]] with [[spell:162264]] it additionally empowers your [[spell:190232]] and [[spell:258920]] to do the same.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:188499]], [[spell:162794]], and [[talent:112956]] deal 12% increased damage.
- **4-Set:** [[talent:112956]] now applies and benefits from the effects of [[talent:112955]], has 25% increased initial strike damage, and has 2 seconds of increased duration.

### Single-Target

#### [[talent:123329]]

##### Opener

- The **Havoc Demon Hunter's** opener is very complex and it is important that you do it in this exact order to maximize your damage output.

:::rotation **Havoc Demon Hunter** single-target opener in Mythic+
```json
{
  "source_code": "IoHPNI0d7LAAAcAUyVGc1xGbAkwD0AQABwprDAAAAAgQVkaBFgAB9VQCQQALznACEgON2gAAEMtEBABKBIUiIMAAAIE25JQB2QA60EgFQAgQHeuBFABKTLxAAAAAAIUknbA"
}
```
1. [[spell:195447]] Prepull
2. [[spell:195447]]  [[item:241308]]
3. [[spell:370965]]
4. [[spell:198013]]
5. [[spell:258860]]
6. [[spell:210152]]
7. [[spell:210152]]
8. [[spell:201427]]  [[spell:198793]]
9. [[spell:162264]]
10. [[spell:210152]]
11. [[spell:452487]]
12. [[spell:201427]]
13. [[spell:452497]]
:::

- If you are talented into [[spell:427641]], you will have to make sure to use [[spell:213241]] or [[spell:195072]] in order to trigger your [[spell:427641]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

- Cast [[spell:258920]] on cooldown with [[spell:427775]] talented
- Cast [[spell:198013]] on cooldown
- Cast [[spell:258860]] on cooldown, combine with [[spell:198013]] when possible
- Cast [[spell:198793]] on cooldown, or with important damage events
- Cast [[spell:370965]] on cooldown
- Cast [[spell:210152]]
- Cast [[spell:201427]]
- Cast [[spell:188499]]
- Cast [[spell:162794]]
- Cast [[spell:232893]]

### AoE

#### [[talent:123329]]

##### Opener

- Below, you see an example of how your opener looks like using the recommended **AoE talent spec**.

:::rotation **Havoc Demon Hunter** AoE opener in Mythic+
```json
{
  "source_code": "IoHPNI0d7LAAAcAUyVGc1xGbAkwD0AQABwprDAAAAAgQVkaBFgAB9VQCQQALznACEgON2gAAEMtEBABKBIUiIMAAAIE25JQB2QA60EgFQAgQHeuBFABKTLxAAAAAAIUknbA"
}
```
1. [[spell:195447]] Prepull
2. [[spell:195447]]  [[item:241308]]
3. [[spell:370965]]
4. [[spell:198013]]
5. [[spell:258860]]
6. [[spell:210152]]
7. [[spell:210152]]
8. [[spell:201427]]  [[spell:198793]]
9. [[spell:162264]]
10. [[spell:210152]]
11. [[spell:452487]]
12. [[spell:201427]]
13. [[spell:452497]]
:::

##### Multi-Target Priority List

- Cast [[spell:258920]] on cooldown with [[spell:427775]] talented
- Cast [[spell:198013]] on cooldown
- Cast [[spell:258860]] on cooldown, combine with [[spell:198013]] when possible
- Cast [[spell:198793]] on cooldown, or with important damage events
- Cast [[spell:370965]] on cooldown
- Cast [[spell:210152]]
- Cast [[spell:201427]]
- Cast [[spell:188499]]
- Cast [[spell:162794]]
- Cast [[spell:232893]]

## Deep dive

### Dead or Alive

The most important part of doing damage and being a useful part of your Raid group is staying alive. With movement being a core part of your damage rotation you NEED to always be aware of your surroundings. Do not [[spell:195072]] or [[spell:198793]] into frontal abilities or area of effect zones.

You cannot do damage while you are dead and neither can you stop abilities from going through.

Being able to execute the perfect rotation isn't going to help you if you are lying dead on the floor or if you need externals/healing that your group would need otherwise.

### Immolation Aura

When you have [[spell:390197]] + [[spell:427775]] talented it is important to manage your [[spell:258920]] charges properly as it is the biggest portion of your damage breakdown in AoE scenarios. When you are about to overcap on charges but you don't have [[spell:195072]] charges ready to spend on [[spell:427640]] uptime just use your [[spell:258920]] charges and ignore [[spell:427640]].

**Never** overcap on [[spell:258920]] charges, no matter what!

### Initiative Windows

Another important part of your damage is managing your [[spell:388108]] windows properly. Remember that every single hostile enemy procs [[spell:388108]] and [[spell:198793]] also resets it on EVERY hostile enemy.

You can optimize this by staying out of range of some enemies to proc[[spell:388108]] again later.

### Spreading The Hunt

When casting [[spell:370965]] it is important to make sure you afflict as many enemies as possible with the DoT component of the ability. This can be tricky since it is applied to enemies that are in your path when you charge with [[spell:370965]]. A trick to help with this is that you can actually still apply this DoT after the cast/charge of [[spell:370965]] is over. This means that you can cast [[spell:370965]], and after it's done you can walk through enemies to apply this dot component to them, and if you are quick you can even cast [[spell:195072]] AFTER [[spell:370965]], and it will still apply the DoT to the enemies you [[spell:195072]] through.

### Haste ?!

Even though **Haste** Sims pretty poorly on paper, it is a great stat for multi target scenarios as it smooths your gameplay out by a lot.

**Haste** increases the amount of [[spell:258920]] charges you have as it decreases the recharge time and helps with Fury generation as well as helping you fit more abilities into your [[spell:213410]] windows.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

### Altar of Fangs

:::talents **Havoc Demon Hunter** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[spell:198793]].

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Den of Nalorakk

:::talents **Havoc Demon Hunter** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:115877]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Murder Row

:::talents **Havoc Demon Hunter** Mythic+ Build in Murder Row
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Can be dispelled with [[spell:1266496]].

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### The Blinding Vale

:::talents **Havoc Demon Hunter** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Voidscar Arena

:::talents **Havoc Demon Hunter** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Kings' Rest

:::talents **Havoc Demon Hunter** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Ruby Life Pools

:::talents **Havoc Demon Hunter** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- [[spell:381516]] interrupts spellcasting when cast, luckily you can not get interrupted by this as a **Havoc Demon Hunter**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Temple of Sethraliss

:::talents **Havoc Demon Hunter** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

#### Pre Dungeon Start

- Always use **[[spell:191427]]** and **[[item:241308]]** before the key starts.

### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes *-- Rotates on a weekly basis*.
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affixes
  
  - Lindormi's Guidance removed.
- +7 Affixes *-- Alternates between each other on a weekly basis*.
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified

- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*.

Following you get some useful tips for handling different Mythic+ Affixes as a **Havoc Demon Hunter**.

- Xal'atath's Bargain: Ascendant
  
  - [[spell:179057]] as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - The **Void Emissary** usually is on the tank, make sure to cleave it down or main target it if it doesnt die fast enough.
- Xal'atath's Bargain: Devour
  
  - [[spell:472649]] with [[spell:1266316]] /[[spell:1266496]] talented can be used to dispell yourself.
- Xal'atath's Bargain: Pulsar
  
  - Use your mobility to help your teammates out by clearing your own and others' orbs.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Havoc Demon Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Havoc Demon Hunter** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFMAIxQCKBEQABA"
}
```
**敏捷 ＞ 暴击 ＞ 精通 ＞ 急速 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAEkAnk7wQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAEkAX16wQrjgCwYNYFA]] | Ula'tek |
| Shoulder | Convert [[item:268246@BgQAAEkACKgTBA]]  <br>into [[item:271535@DgQBAEkAXk7IoAOFg1XQ]] | Vashnik Catalysted |
| Cloak | [[item:268253@BgQAAEkACKgTBA]] | Coiled Altar |
| Chest | Convert [[item:239048@BgQAAEkACKgTBA]]  <br>into [[item:271540@DgQBAEkAJk7IoAOFAylO]] | King's Rest Catalysted |
| Wrist | [[item:244576@FiRAAEkAtqC5BwDDtOAAAAAcbNLF]] | Crafted |
| Gloves | [[item:271538@BgQAAEkACKgTBA]] | Entombed Sentinels |
| Belt | [[item:268256@BiQAAEkAM06IoAYF]] | Coiled Altar |
| Legs | Convert [[item:268225@BgQAAEkACKAWBA]]  <br>into [[item:271536@DgQBAEkAhu7IoAYFQwXQ]] | Coiled Altar Catalysted |
| Boots | [[item:159327@DgQAAEkAxj7IoAOF]] | Temple of Sethraliss |
| Ring 1 | [[item:268249@DiQAAEkA1j7wQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAEkA1j7wQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270175@BgwAAEkACKAWBUAABo0FCA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAEkACKAWBA]] | Coiled Altar |
| Weapon | [[item:268209@DgQAAEkADk7IoAYF]] & [[item:237840@HgQAAEkAeA8MQuDpqQ3WzSB]] | Coiled Altar & Crafted |

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239033@DiQAAEkAnk7wQrjgCEUA]] | Temple of Sethraliss |
| Neck | [[item:251234@BkQAAEkAX16wQrjgCEUA]] | Voidscar Arena |
| Shoulder | [[item:251223@DgQAAEkAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:251132@BgQAAEkACKQQBA]] | Murder Row |
| Chest | [[item:239048@DgQAAEkAJk7IoABF]] | Kings' Rest |
| Wrist | [[item:251183@BiQAAEkAM06IoABF]] | The Blinding Vale |
| Gloves | [[item:159312@BgQAAEkACKQQBA]] | Kings' Rest |
| Belt | [[item:159317@BiQAAEkAM06IoABF]] | Temple of Sethraliss |
| Legs | [[item:251130@DgQAAEkAhu7IoABF]] | Murder Row |
| Boots | [[item:159327@DgQAAEkAxj7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@DiQAAEkA1j7wQrjgCEUA]] | Temple of Sethraliss |
| Ring 2 | [[item:251136@DiQAAEkA1j7wQrjgCEUA]] | Murder Row |
| Trinket 1 | [[item:250215@BgQAAEkACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250228@BgQAAEkACKQQBA]] | Murder Row |
| Weapon | [[item:251186@DgQAAEkADk7IoABF]] & [[item:251231@DgQAAEkADk7IoABF]] | The Blinding Vale & Voidscar Arena |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons and Raids.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAEkACKAWBUAABo0FCA]]  <br>[[item:270173@BgQAAEkACKAWBA]]  <br>[[item:270168@BgQAAEkACKAWBA]]  <br>[[item:270164@BgQAAEkACKgTBA]] |
| **A-Tier** | [[item:250215@BgQAAEkACKgTBA]]  <br>[[item:270166@BgQAAEkACKgTBA]]  <br>[[item:270165@BgQAAEkACKgTBA]] |
| **B-Tier** | [[item:159617@BgQAAEkACKgTBA]]  <br>[[item:250259@BgQAAEkACKgTBA]]  <br>[[item:250228@BgQAAEkACKgTBA]]  <br>[[item:250225@BgQAAEkACKgTBA]]  <br>[[item:193757@BgQAAEkACKgTBA]] (Trained) |
| **C-Tier** | [[item:250214@BgQAAEkACKgTBA]]  <br>[[item:273796@BgQAAEkACKgTBA]]  <br>[[item:158374@BgQAAEkACKgTBA]]  <br>[[item:273797@BgQAAEkACKgTBA]] |
| **Junkyard** | [[item:193757@BgQAAEkACKgTBA]] (Untrained) |

### Embellishments

- [[item:273060]] is currently the most powerful embellish. This can however only be crafted on weapons, so depending on what items your character might have/need crafting 1 or 2 weapons with this embellishment will likely be the best option.
- [[item:273069]] is the 2nd strongest embellishment, and can be crafted on normal armor pieces. This makes for a more versatile embellishment since it can go on any slot, and you might be able to craft in an item slot that benefits your character more.
- [[item:240167]] Similar to [[item:273069]], but seems to output slightly lower DPS numbers.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241326]] *-- maximum DPS.***
  
  
  
  - **[[item:241320]] *-- less DPS but more survivability.***
- **Food**
  
  - **[[item:242273@BQAAAEkAaB]]**
- **Combat Potion**
  
  - **[[item:241288]]**
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon
  
  - **[[item:243734]]**
- **Augment Rune**
  
  - **[[item:259085@BQAAAEkAaB]]**
- **Sockets**
  
  - **[[item:240908]]**
  - **[[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].***
    
    - **[[item:240898]]**
    - **[[item:240914]]**
    - **[[item:240890]]**

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAEkAZbAB]] & [[item:275707@DAAAAEkAnk7A]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAEkA]] |
| Chest | [[item:243977@BAAAAEkA]] |
| Wrist | [[item:275707@DAAAAEkAnk7A]] |
| Waist | [[item:275707@DAAAAEkAnk7A]] |
| Legs | [[item:244641@BAAAAEkA]] |
| Boots | [[item:243953@BAAAAEkA]] |
| Ring 1 | [[item:243957@BAAAAEkA]] |
| Ring 2 | [[item:243957@BAAAAEkA]] |
| Weapon | 2x [[item:243971@BAAAAEkA]] |

:::

:::column
:::gear **Havoc Demon Hunter** Enchantments in Raid
```json
{
  "source_code": "IwFZBJQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NAREIgyA5OAAAAAABMQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243971]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAEkAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Havoc Demon Hunter** in raiding, different racial traits can provide combat benefits to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Nightelf
  
  - Can be used to drop aggro, and sometimes avoid certain mechanics altogether.
  - Has limited uses in Raid, but can be very useful in Mythic+.
- [[spell:202719]] -- Bloodelf
  
  - Removes 1 beneficial effect from hostile targets around you.
  - Generates 15 Fury.
- [[spell:256948]] -- Voidelf
  
  - Tear a rift in space. Reactivate this ability to teleport through the rift.

### Recommendation

It does not really matter which Race you chose for **Havoc Demon Hunter**, as dps differences are marginal, it is however advised to go Blood Elf for raid as it is usually ever so slightly higher dps, and Night Elf for M+ as it provides the superior utility for this type of content with the correct use of  [[spell:58984]]. Remember if you are Blood Elf, [[spell:202719]] might come in handy in some situations where you need a quick AoE purge, or it can be used to gain 15 Fury while you are fury starved or out of range of any target in combat.

## Macros

Discover recommended macros for **Havoc Demon Hunter** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**@Cursor [[spell:191427]] Macro - *Uses your [[spell:191427]] at your cursor's location***

```wow-macro
#showtooltip
/cast [@Cursor] Metamorphosis
```

**@Cursor [[spell:207684]] Macro - *Uses your [[spell:207684]] at your cursor's location***

```wow-macro
#showtooltip
/cast [@Cursor] Sigil of Misery
```

:::

:::details Mouseover Macros
**@Mouseover [[spell:217832]]** **Macro - *Casts [[spell:217832]]*** on your ***Mouseover target if you have one, casts it on your current target if you don't have a Mouseover.***

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Imprison
```

**@Mouseover [[spell:195439]]** **Macro - *Interrupts your Mouseover target if you have one, Interrupts your current target if you don't have a Mouseover.***

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Disrupt
```

:::

:::details General Macros
**@Player [[spell:191427]] Macro - *Uses your [[spell:191427]] at your current location***

```wow-macro
#showtooltip
/cast [@Player] Metamorphosis
```

**@Focus [[spell:195439]] Macro - *Uses your [[spell:195439]] at your focus target***

```wow-macro
#showtooltip
/cast [@focus] Disrupt
```

**Set focus Macro - *Sets your Mouseover target as focus if you have one, sets your target as focus if you don't have a Mouseover.***

```wow-macro
/focus [@mouseover,exists][]
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Havoc Demon Hunter**.

![](<https://assets-ng.maxroll.gg/wordpress/Skjermbilde-2026-08-08-020134-1024x575.png>)

Verb's UI for **Havoc Demon Hunter**

Addons can be very helpful both inside and outside of combat. Some of the addons listed below are often considered most essential to any high end player.

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI** -- All rounder UI addon
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**DEMON HUNTER**

- Havoc
  
  - Developers' notes: The following changes to Fury generation are a small overall increase, paced more smoothly and relying less heavily on Immolation Aura's talent effects.
  - Demon Blades, Blade Dance, and Chaos Strike now require equipped Warglaives, Axes, Swords, and Fist Weapons.
  - New Talent: Never Say Die – Damage increased by 3% while above 50% Health. Leech increased by 5% while below 50% Health.
  - Trail of Ruin has been updated – Damage is now applied immediately, rather than as a damage over time effect over 4 seconds.
  - Serrated Glaive has been updated – Effect is now a buff on the Demon Hunter with a 12 second duration, rather than a debuff on enemy targets with a 15 second duration.
  - Blade Dance damage increased by 6%.
  - Death Sweep damage increased by 6%.
  - Chaos Strike damage increased by 6%.
  - Annihilation damage increased by 6%.
  - The Hunt damage increased by 12%.
  - Immolation Aura damage reduced by 8%.
  - Essence Break initial damage increased by 49%.
  - Burning Hatred now causes Immolation Aura to generate an additional 30 Fury (was 40).
  - Demon Blades now generates 10-16 Fury per attack (was 8-15).
  - Blind Fury now causes Eye Beam to generate 10/20 Fury per second (was 15/30 Fury).
  - Inertia now increases damage by 12% for 6 seconds (was 18% for 5 seconds).
  - Inner Demon has moved and is now a choice node option with Chaos Theory (was a choice node option with Chaotic Transformation).
  - Dash of Chaos has been removed.

:::

:::

## FAQ

:::accordion
:::details Q: Is it worth holding my [[talent:112939]] for X?
A: It is almost never worth holding your Eye Beam for specific points unless you hold it for less than 3-4 seconds. You are better off just using your [[spell:198013]], [[spell:258860]] and [[spell:198793]] on cooldown.

:::

:::

---

### Credits

Written By: **Verb**

Reviewed by: **Tief**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1

**2026-06-19** Updated for patch 12.0.7

**2026-02-10** Updated for patch 12.0.1

**2026-01-10** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7

**2025-10-09** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2.0

**2025-06-19** Updated for patch 11.1.7

**2025-02-25** Updated for patch 11.1.0

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
