欢迎来到魔兽世界 12.1 版本的 **增辉 唤魔师** 团队副本 攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从 80 级开始练级吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 5/5 · 极佳

生存能力 · 5/5 · 极佳

机动性 · 5/5 · 极佳



:::

:::

:::column
:::gear **增辉 唤魔师** 团队副本最佳配装
```json
{
  "source_code": "JAoAwDVwFc__BEQjkQggIEAAnk7AX16ACKgTBEQ6XQAAREAAE06AE06AMWjgCgVABsIJEIACBAwF5OggCgVABQgJEIAEBAQC5OggCwYNYFQAefBBAiQB0UwQAwYCvQQBqmwLIk8FEEgPAkSAvgjTBEAa7OAhIEAAYA8AnoaAkxyt1sUAB4IJEAACBAQB_AS2XQggAEAA3jbAeQhTBEgnqJQAkmAEFICBU9RGuAwVdwABdfRDYQBWBEA9iQQA2BwPBYHTYFQAJA8AEgQAAgXZDQqKEcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271499]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240900]] |
| 腿部 | [[item:271500]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:244009]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] | [[item:222584]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为 **增辉** 你可以使用 分身，在施放 [[spell:403631]] 之后召唤一个自己的分身来协助你。

**等级1：** [[spell:403631]]召唤一个你的复制，持续20秒，它会施放[[talent:115498@FAgARegBviiB]]、[[spell:357208]]和[[talent:115502@FAgARegBviiB]]。

**等级2 - (1/2)：** 每当你延长[[talent:115496@FAQAviiB]]时，你也会以50%的比例延长你的复制。

**等级2 - (2/2)：** 每当你延长[[talent:115496@FAQAviiB]]时，你也会以100%的比例延长你的复制。

**等级3：** 当你的复制处于激活状态时，你的[[talent:115496@FAQAviiB]]提供100%的额外属性，并且[[talent:115502@FAgARegBviiB]]和[[talent:115498@FAgARegBviiB]]造成的伤害提高25%。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-augmentation-mxr.webp>)

复制

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精树**
  
  - [[talent:115496@FAQAviiB]]
    
    - 现在会以你团队/小队中的所有输出玩家为目标，因此定向增益主要通过 [[talent:115675@FAQAmxkB]] 来实现，以利用其被动效果。
  - [[spell:459725]]
    
    - 经过改动后，提升 [[spell:357208]] 的等级不再提供更高的伤害加成，所以现在你通常只需以 1 级施放它。
    - 在 12.0.5 版本中，它被 [[talent:126305]] 完全取代。
- **职业树**
  
  - [[talent:115617]]
    
    - 此前是一个 **增辉** 专属天赋，现已移入 唤魔师 职业树，让你在使用 [[spell:357210]] 时更加安全！
  - [[talent:115669]]
    
    - 已作为独立法术被移除，现在与 [[talent:115613]] 绑定，效果有所减弱。
- **移动**
  
  - [[talent:115690]] 
    
    - 它从 职业树 中被移除，并转移到输出 专精树 中以取代冷却缩减天赋，这意味着你现在必须在那里投入天赋点才能拥有打断技能，而不再只是拥有一个冷却时间更长的打断。

## 英雄天赋

- [[talent:123331]] 在持续的大型 范围伤害 场合下表现更佳，而 [[talent:123334]] 在其他所有场合都是更强的选择。



### [[talent:123334]]

- [[talent:117552]] 使 [[spell:370553]] 成为强大的进攻性爆发技能，提高你的 急速 以及冷却恢复速度。
  
  - 这些增益提供的 急速、移动速度和冷却恢复速度加成会在 30 秒持续时间内每秒降低 1%。
  - 总计可使技能的冷却时间缩短 4.65 秒。
  - 选择 [[talent:135742]] 后，每 6 秒获得一次 [[talent:115520]]。
- [[talent:117545]] 使普通的 [[spell:358267]] 变成瞬间位移。
  
  - 注意，这个效果有短暂延迟。
  - 目前该效果只有在地面上或接近地面时才会触发；如果你在空中的位置过高，它就会变回普通的 [[spell:358267]]。

- 只要掌握好时机，[[talent:117532]] 可以在你用尽其他手段时作为一个小型防御冷却技能使用。

在 12.0 版本中，暴风雪 移除了原本的《地心之战》第三赛季套装，并新增了 3 个英雄天赋点。

- [[talent:135743]]
  
  - [[talent:115665]]的冷却时间缩短30秒
- [[talent:135742]]
  
  - 使[[spell:361469]]得到提升。
- [[talent:135741@FJQAnxzENIA]]
  
  - [[talent:117551@FJQAnxzENIA]]的最大伤害或治疗效果提高40%。




### [[talent:123331]]

- [[talent:122279]]
  
  - [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]]和[[talent:115502]]会将你的下一个[[talent:115498]]变为[[talent:122279]]，可打击多个目标，或在目标少于3个时对每个目标造成更高的伤害。
  - [[talent:122279]]最多可叠加2层，这意味着你可以连续施放两个强化技能。
- [[talent:117533]] 
  
  - 会施加于你施放[[talent:122279]]的目标身上。
  
  
  
  - [[talent:117533]]不具有传染（pandemic）机制，因此你可以连续施放两个[[talent:122279]]而不会损失减益效果的持续时间。
  
  
  
  - 这也能使[[talent:117550]]收益最大化，并根据你战斗目标的数量，将[[talent:115536]]的冷却时间缩短至60-90秒的区间内。

- [[talent:120123]]
  
  - 恢复一层 [[spell:358267]]。
  
  
  
  - 在 **12.0 版本** 中被削弱为只恢复一层而非两层，因此在某些战斗中 [[talent:117540]] 现在可以是更可行的选择。

- [[talent:117538]]
  
  - 使你的[[talent:115536]]始终朝向你的角色前方，并且现在可以被操控方向。
  - 这也会使[[talent:115536]]飞行完整的持续时间，除非你再次按下该技能提前取消它。
  - 注意不要连续敲击你的[[talent:115536]]按键，因为你可能会在它命中目标之前就将其取消，而冷却时间却照常进入。我建议使用带有 /cast !亘古吐息 的宏来施放它，使其无法被取消，并在其他技能的宏中加入 /cancelaura 亘古吐息，以获得更流畅的游戏体验。

在 12.0 版本中，暴风雪 移除了原本的《地心之战》第三赛季套装，并新增了 3 个英雄天赋点。

- [[talent:136053]]
  
  - 在[[talent:115536@FAQARegB]]的飞行期间，2名龙希尔突击队员会与你一同飞行，并用龙焰打击附近的敌人，最多8次。
- [[talent:136052@AJQD]]
  
  - [[talent:122279]]会额外命中1个目标。
- [[talent:136051]]
  
  - 精粹技能造成15%的额外伤害。





## 天赋



### [[talent:123334]]

:::talents [[talent:123334]] **增辉 唤魔师** 团本天赋
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 何时使用该专精

几乎在所有场合都会使用。

#### 改变游戏玩法的天赋

探索专精和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行简明概述，如需更详细的了解，请查看下方的**输出循环**和**深度解析**章节。

##### 专精树

- [[talent:115496]]
  
  - 你作为 增辉 唤魔师 的玩法核心在于优化并延长这个增益。
- [[talent:115675]]
  
  - 一个循环法术，为你的目标提供 爆击 几率以及一些额外伤害输出。
  
  
  
  - 有几率通过 [[talent:115523]] 施放 [[talent:115520]]。
- [[talent:115536]]
  
  - 你的主要进攻冷却技能，会对被你的吐息命中的目标施加一个持续约10秒的减益效果，该效果会统计在这段时间内盟友受到你的 [[talent:115496@FAQAviiB]] 造成的伤害，并在减益效果到期时根据该伤害造成爆发性伤害。
- [[talent:115520]]
  
  - 使一次 [[talent:115498]] 的施放不消耗精华，与 [[talent:115688]] 和 [[talent:115506]] 有重大协同效果。
- [[talent:126304@FAQAviiB]] 与 [[talent:115527@FAQAviiB]]
  
  - 这些天赋强化你的 [[talent:115536@FAgARegBviiB]] 时段，分别使 [[talent:115498@FAgARegBviiB]] 和 [[spell:390386]] 在 15 秒内精华消耗降低。
- [[talent:115706]]
  
  - 你的 [[talent:115496]] 获得增益的目标会根据其在 [[talent:115536]] 期间造成的伤害获得一个护盾。
- [[talent:115528]]
  
  - [[talent:115498@FAgARegBviiB]] 有25%的几率形成一个微粒，接触该微粒的盟友会获得下方列出的增益效果。
    
    - [[talent:115515]]
    - [[talent:115495]]
    - [[spell:413984]]
  - 当点出 [[talent:115528]] 天赋时，几率提升至35%，并且 [[talent:115675@FAQAmxkB]] 会被加入增益池。
- [[talent:115533]]
  
  - 一个引导法术，使你的冷却技能以更快的速度恢复，通常通过后续天赋 [[talent:115686]] 被"变成被动"，该天赋直接提供总计10%的冷却缩减。

##### 职业树

- [[talent:115596]]
  
  - 一个移动技能，可以让你抓起一名友方玩家，并迅速将对方和你自己转移到另一个位置，常用于解除移动限制效果。
- [[talent:115661]]
  
  - 用于为我和最近的 4 名盟友降低 范围伤害 伤害，在 至暗之夜 全职业防御技能精简的背景下非常有影响力。
- [[talent:115665]]
  
  - 用于激活 [[talent:117552]]
  - 通常与 [[talent:115502@FAgARegBviiB]] 一起使用。
- [[talent:115658]]
  
  - [[talent:116103]] 为一名友方治疗者提供增益。
- [[talent:125610]]
  
  - 一个非常出色的功能性技能，可在高强度移动阶段为治疗者提供帮助，在需要扩大你自身法术施法距离的某些情况下也可能非常重要。这是一个与 [[talent:115666]] 的选择节点，你的团队可能会需要它。




### [[talent:123331]]

:::talents [[talent:123331]] **增辉 唤魔师**在团本中的天赋
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MmZmZbmZGM8AzMLzYMMDAAAAAAAAmZYMDGTNmZmBAAAAzYGjZmlxMDMzmxwsMDLjhZWGGMz0I2wMjZmZGAD",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MmZmZbmZGM8AzMLzYMMDAAAAAAAAmZYMDGTNmZmBAAAAzYGjZmlxMDMzmxwsMDLjhZWGGMz0I2wMjZmZGAD"
}
```
:::

#### 何时使用该专精

可以在大秘境中使用，但在团本中的表现明显不如[[talent:123334]]。

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

##### 专精树

- **新增** 
  
  - [[talent:115686]]
- **移除** 
  
  - [[talent:115531]]

##### 职业天赋树

- **无改动**

##### 英雄天赋

已将 [[talent:123334]] 切换为 [[talent:123331]]。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:408092]] 的冷却时间缩短10秒。
- **4件套：** [[spell:408092]] 会放大你的 [[talent:115685]] 效果，持续8秒，使回响伤害从15%提高到45%。

### 单体目标



#### [[talent:123334]]

##### 起手爆发

:::rotation [[talent:123334]] **增辉 唤魔师 团队副本 起手**
```json
{
  "source_code": "JsGSNIAkHYAABEAiuOAAAAAAC8tPGUhBY-KKGAgACl3pFAAABk1HEAACBAggCgVACg1cFAAAC4_CGAAACFfLGIEOAAg_BoRCmwiQYegBAAAAAIEmHYA"
}
```
1. [[spell:395152]]  [[item:241288]]
2. [[spell:409311]]
3. [[spell:409311]]
4. [[spell:403631]]  [[spell:370553]] · [[item:270169]]
5. [[spell:357208]]
6. [[spell:396286]]
7. [[spell:404977]]
8. [[spell:409311]]
9. [[spell:409311]]
10. [[spell:396286]]
11. [[spell:357208]]
12. [[spell:395160]]
13. [[spell:395160]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[talent:115496]] *- 若为刷新，请在剩余时间不多于 5.5 秒时开始施放。*
2. 施放 [[talent:115675]] - *在拥有 2 层充能时。*
3. 施放 [[talent:115665]] *- 在推荐配装下对 [[spell:396286]] 使用，更多技巧请查看“深度剖析”章节。*
4. 施放 [[spell:403631]]
5. 施放 [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] *- 1 级*
6. 施放 [[spell:396286]] *1 级*
7. 施放 [[spell:404977]] *- 在战斗中尽可能频繁地使用，以让优先级列表中更靠前的技能尽快恢复就绪。*
8. 施放 [[spell:395160]] - *在拥有 **2** 层 [[spell:396187]] 时。*
9. 施放 [[talent:115675]] *- 在拥有 1 层充能时*。
10. 施放 [[spell:395160]]
11. 施放 [[talent:117551@AJQDCA]]




#### [[talent:123331]]

##### 起手爆发

:::rotation [[talent:123331]] **增辉 唤魔师** 在 团队副本 中的起手
```json
{
  "source_code": "JcESJIAkHYAABEAiuOAAAAAAC8tPGUhB08KKGAQACl3pFAAACg1cBYAI-vgBAAgQYegBBwCLCh5BGAAAAAgQYegB"
}
```
1. [[spell:395152]]  [[item:241288]]
2. [[spell:409311]]
3. [[spell:409311]]
4. [[spell:403631]]  [[spell:370553]]
5. [[spell:357208]]
6. [[spell:396286]]
7. [[spell:395160]]
8. [[spell:395160]]
9. [[spell:395160]]
:::

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 施放 [[talent:115496]] *- 若为刷新，请在剩余时间不多于 5.5 秒时施放。*
2. 施放 [[talent:115675]] - *在拥有 2 层充能时。*
3. 施放 [[spell:403631]]
4. 施放 [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] *- 1 级*
5. 施放 [[spell:396286]] 1 级 *-- 在可用时使用* [[talent:115665]]
6. 施放 [[spell:395160]] - *在拥有 **2** 层 [[spell:396187]] 时。*
7. 施放 [[talent:115675]] *- 在拥有 1 层充能时*。
8. 施放 [[spell:395160]]
9. 施放 [[spell:361469]]





## 深度解析

### 扭转天平 的使用

- [[talent:123334]]
  
  - 在这个英雄专精中，[[talent:115665]] 与 [[talent:117552]] 绑定，应在冷却结束后立即使用，以最大化增益的覆盖时间。
  - 使用 [[talent:126305]] 构筑时，如果冷却时间能够对齐，就将其用于 [[spell:396286]]；否则直接使用 /cancelaura 扭转天平 宏立即取消它，让冷却开始倒转。
  - 使用 [[talent:115531]] 构筑时，理想情况是与 [[spell:357208@FJACNLZBaugBLsgBRegBZIjBsNjB6zwB7zwBNIA]] 一起使用以获得瞬发 [[talent:115657]] 的收益，但如果冷却时间对不上，就使用 /cancelaura 扭转天平 宏立即取消它。
- [[talent:123331]]
  
  - 这个英雄专精中它并非核心技能，仅在移动时用于瞬发强化施法，或更快施放 [[spell:396286]]。

### 变换流沙 和 先知先觉

- [[spell:413984]] 是一个 **增辉 唤魔师** [[spell:406380]] 效果，它是一个 全能 增益，在你施放 **强化** 法术（[[spell:357208]] 或 [[talent:115502@FAgARegBviiB]]）后给予队友。
- 会施加给附近尚未拥有 [[spell:413984]] 增益的最近 DPS 玩家（优先你的 [[talent:115496@FAQAviiB]] 目标，但在 至暗之夜 的加持下，这几乎总是覆盖你小队/团队中的每一名 DPS 玩家。）
- 随着 黑檀之力 的改动，（就近）目标选择以及将 [[spell:413984]] 和 [[talent:115675@FAQAmxkB]] 指向在任何情况下造成伤害最高的玩家，是 增辉 除你自身（简单的）循环之外仅存的主要优化手段。
- 在团队副本中，非常高端的全优化玩法仍然需要提前规划你的 [[talent:115675@FAQAmxkB]] 目标，理想情况下在施放强化法术时尽量站在处于爆发冷却窗口的玩家附近，以便让他们获得你的 [[spell:413984]] 增益，但尤其是就近目标选择在战斗中并不总能实现；不过在开怪时，你应始终尽量站在爆发最高的职业旁边。
- 在许多情况下，直接用 [[talent:115675@FAQAmxkB]] 永久锁定你队伍中表现最好的 DPS 玩家也是完全可行的！

### 营救

- [[spell:370665]] 是你作为一名 **唤魔师** 的重要工具，要最佳地使用它需要对战斗有敏锐的洞察，尤其是在团队副本中，它常常能把你机动性较差的队友从困境中拯救出来。
- **12.0 补丁** 包含以下改动：
  
  - [[spell:370888]] 已重做——[[spell:370665]] 使移动速度提高 100%，并允许在移动中施法，持续 3 秒。
  
  
  
  - 这意味着 [[spell:370665]] 不再附带防御冷却，但作为移动能力变得更加强力了！

### 悬空

- 在战斗中正确地管理和把握 [[spell:358267]] 的使用时机，以便在处理机制的同时打出更多施法，这才是你在 DPS 上看到最大差异的地方，因为对 **增辉 唤魔师**.
- 在 [[spell:358267]] 增益即将结束时开始施放 [[talent:115498]] 之类的法术，仍然可以让你在移动中完成该次施法。记住这一点，以便从每次 [[spell:358267]] 的使用中获得更多收益！
- 请确保在你的界面上追踪 [[spell:358267]] 的覆盖时间和层数。要真正熟练地运用这个技能，因为它是 **唤魔师**.
- 有了 **12.0版本** [[spell:358267]] 现在可以在正常施法期间使用（主要是 [[spell:361469]] 和 [[talent:115498@FAQARegB]] 用于 **增辉**）而不会打断施法。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents [[talent:123331]] **增辉 唤魔师** 团队副本 流派，适用于 内克扎莉
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 切勿在 [[spell:1284103]] 期间站在首领与你方坦克之间！
- 提前站在 **不安分的阿曼尼** 的尸体上方，紧接在 [[spell:1294742]] 之前，以便更轻松地协调清理它们。




### 陵寝哨兵

:::talents [[talent:123334]] **增辉 唤魔师** 团队副本 流派，适用于 陵寝哨兵
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 每当[[spell:1284434]]出现时，要积极上去踩踏，如果连续吸收大量伤害，请使用一个防御冷却技能。
- 分散站位，准备在首领能量达到100时解决[[spell:1284590]]，这是这场战斗的关键机制，也是导致团灭的主要原因，所以一定要高度专注！
- 开怪时以及在[[spell:1284590]]被解决之后，你都可以对两个首领同时使用[[talent:115536@FAQARegB]]。




### 迷失的探险者

:::talents [[talent:123334]] **增辉 唤魔师** 团队副本 流派的迷失探险者
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 留意 [[spell:1296062]] 的施放，并检查它们被射向哪个方向。
- 你可以移除 **流血** 减益：这是承受 [[spell:1291934]] 后获得的效果，可用 [[talent:115602]] 移除。因此可以先承受多次，再为自己驱散，也可以留意层数较高的其他玩家。
- 务必注意，别过早触发 **弹力蘑菇** （由 [[spell:1292105]] 产生）；应等到 [[spell:1296235]] 即将到来时再触发，否则它们会在短时间后消失。




### 瓦什尼克

:::talents [[talent:123334]] **增辉 唤魔师** 团队副本 流派的瓦什尼克
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 提前为 [[spell:1281907]] 分散站位以减少混乱，并尽量不要朝近战区域射击。
- 当 **燃烧毒液** 爆炸时使用一个防御冷却技能。
- 积极为受到 [[spell:1295224]] 影响的玩家吸收伤害。




### 斯索拉克

:::talents [[talent:123331]] **增辉 唤魔师** 团队副本 流派，适用于 斯索拉克
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 请记住，你可以用 [[spell:358733]] 轻松取消 [[spell:1285419]] 和 [[spell:1287008]] 的击退效果。
- [[talent:115666]] 在 [[spell:1285732]] 期间使用效果极佳，可帮助你的团队优化输出。
- 每当 [[spell:1305959]] 发生时一定要集中注意力，如果你被点名，准确知道该去哪里至关重要。
- 你可以用 [[spell:365585]] 或 [[talent:115602]] 驱散任何被 [[spell:1287072]] 命中的人。




### 双牙

:::talents [[talent:123331]] **增辉 唤魔师** 团队副本 流派的双牙
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 在整个战斗中密切关注你的 [[spell:1290336]] 层数。
- 如果被 [[spell:1291478]] 点名，不要过度移动；如果实在必须移动，尽量沿着直线方向移动。
- 随时留意 [[spell:1290956]] 掀起的波浪，它们可能让你措手不及，尤其是在 [[spell:1290516]] 的击退期间。
- 当 **维克苏尔** 潜入地下并在场地中央现身施放 [[spell:1294293]] 时，观察他周围指示旋转方向的小绿球，以决定你应该向左还是向右躲避（你应该“逆着”旋转方向躲避。）




### 盘绕祭坛

:::talents [[talent:123331]] **增辉 唤魔师** 团队副本 蛇盘祭坛配装
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 需要时协助移动和集合 [[spell:1282403]]。
- 每次 [[spell:1285643]] 后检查你是否被任何生成的幽灵盯上，如果被盯上，一定要专注于将其引导到预定的坦克顺劈位置以摆脱它。
- 打断 [[spell:1286399]]，来自 **怨毒缠魂者**.
- 如果被 [[spell:1286895]] 点名，使用 [[talent:115613]]，并记得之后拾取你的灵魂！




### 乌拉特克

:::talents [[talent:123334]] **增辉 唤魔师** 团队副本 流派，适用于 乌拉特克
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 击败愤怒的上古巨蛇。




### 尼姆瑞莎·唤波者

:::talents [[talent:123334]] **增辉 唤魔师** 团队副本 流派配置，适用于 尼姆瑞莎·唤波者
```json
{
  "source_code": "CGcB282ha6SMH_EjNYLtBJiO_MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB",
  "code": "CGcB282ha6SMH/EjNYLtBJiO/MMzMbzMzgBzMLzYmZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmZxYYWmxCLDGDzwMTjYBjxMzMDgB"
}
```
:::

#### 首领攻略技巧

- 在[[spell:1281393]]被清除时，在可用时轮换使用[[spell:363916]]和[[spell:374227]]。





## 属性优先级

了解你作为 **增辉 唤魔师** 在 团队副本 首领战中的次要属性优先级以及获得最佳表现所需的第三属性。欲了解更多详细信息，请访问 **[属性与数值](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。



### [[talent:123334]]

:::priority [[talent:123334]] 增辉 唤魔师  团本属性优先级
```json
{
  "source_code": "JoAJFUQMgQCKBEgAEA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＝ 急速 ≫ 全能**
:::




### [[talent:123331]]

:::priority [[talent:123331]] 增辉 唤魔师 团本属性优先级
```json
{
  "source_code": "IoAJFUAIkEDKBMABBA"
}
```
**智力 ＞ 暴击 ≥ 急速 ≫ 精通 ＞ 全能**
:::





:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 一个极好的属性，可以减少"**范围性**"技能受到的伤害。
- **吸血** - 通过造成伤害提供额外治疗。你的大部分伤害来自被增益的玩家，因此它并不理想。
- **速度** - 非常实用的小众第三属性，过去已被证明非常有用，能让应对某些机制变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271501@DiQAAEcBnk7cVrjgC4UA]] | 套装 / 催化剂 |
| 颈部 | [[item:268265@BERAAsbBE06QQrDj1IoAYFA]] | 乌拉特克 |
| 肩部 | 催化剂 [[item:268231@AgQAAIoAYFA]]  <br>转化为 [[item:271499@DgQAAEcBXk7IoAYF]] | 盘绕祭坛 / 催化剂 |
| 背部 | [[item:268253@BgQAAsbBCKAWBA]] | 盘绕祭坛 |
| 胸部 | [[item:271876@DARAAsbBJk7IoAMWDWB]] | 乌拉特克 |
| 腕部 | [[item:244584@FiQAAsbBYA8ciqDBtO3WzSB]] | 制造业 |
| 手部 | [[item:271502@BgQAAEcBCKgTBA]] | 套装 / 催化剂 |
| 腰部 | [[item:268254@BiQAAEcBE06IoAOF]] | 瓦什尼克 |
| 腿部 | 催化剂 [[item:268237@AgQAAIoAYFA]]  <br>转化为 [[item:271500@DgQAAEcBFo6IoAYF]] | 盘绕祭坛 / 催化剂 |
| 脚部 | [[item:268233@DgQAAsbBpk7IoAOF]] | 斯索拉克 |
| 戒指 1 | [[item:268249@DCQAAEcB3j7QQrjTBA]] | 瓦什尼克 |
| 戒指 2 | [[item:158366@DiQAAEcB3j7QQrjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:270164@BgQAAsbBCKgTBA]] | 迷途的探险者 |
| 饰品 2 | [[item:270167@BgQAAEcBCKgTBA]] | 毒牙祭坛 |
| 武器 | [[item:271092@DgQAAsbB_k7IoAYF]] | 乌拉特克 |
| 副手 | [[item:245769@FgQAAsbB4V2QqK0t1sUA]] | 制造业 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:239035@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 项链 | [[item:251234@BgQAAsbBCKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:239049@BgQAAsbBCKQQBA]] | 诸王之眠 |
| 披风 | [[item:251132@BgQAAsbBCKQQBA]] | 密谋小径 |
| 胸部 | [[item:251233@BgQAAsbBCKQQBA]] | 虚空之痕竞技场 |
| 护腕 | [[item:159380@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 手套 | [[item:193752@BgQAAsbBCKQQBA]] | 红玉新生法池 |
| 腰带 | [[item:251155@BgQAAsbBCKQQBA]] | 纳洛拉克的洞穴 |
| 腿部 | [[item:159375@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:159388@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251136@BgQAAsbBCKQQBA]] | 密谋小径 |
| 戒指 2 | [[item:158366@BgQAAsbBCKQQBA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:250224@BgQAAsbBCKQQBA]] | 虚空之痕竞技场 |
| 饰品 2 | [[item:273796@BgQAAsbBCKQQBA]] | 毒牙祭坛 |
| 武器 | [[item:193761@BgQAAsbBCKQQBA]] | 红玉新生法池 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270167@AgQAAIoAOFA]] |
| **A级** | [[item:270164@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **B级** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **C级** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **垃圾级** | [[item:158368@AgQAAIoAOFA]] |

### 美化效果 / 制造业

- 拿到你的前 4 个 [[item:274476]] 后，建议制作 [[item:245770@CARAAgBwDAAcbNLF]]，这是非常高效利用你的史诗纹章的方式！

对于末期游戏最优化的制造装备，你应该准备：

- 1个 [[item:240167]]
  
  - 最适合制造的部位是 **护腕**、**披风、靴子** 或 **腰带**，取决于你现有的装备情况。

- 1个 [[item:273060]]
  
  - 如果你使用制造的武器或副手物品，这是一个极佳的装饰强化。

#### 剩余的火花

- 制造装备最高装等为331，而普通装备最高装等为334。因此，除非你在该部位没有其他高装等装备可用，否则在2个装饰强化之外装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

- **不要** 使用属性权重模拟（Stat Weights Sims），它们只影响你个人的伤害，因此你不会得到有意义的结果。
- 只使用 Top Gear 和 Droptimizer。
- RDPS 或“团队副本 DPS”指的是你整个队伍造成的伤害。之所以这样做，是因为 增辉 是一个为其他输出提供增益的辅助专精，因此模拟需要它们参与运作。由于这一点以及下文提到的若干因素，模拟无法单独输出 增辉 唤魔师 的个人贡献，只能提供对比结果。幸运的是，优化装备或天赋选择所需的仅仅是对比结果。

## 消耗品

- **药剂**
  
  - [[item:241322]] *—— 最高DPS。*
- **食物**
  
  - [[item:255845]]
  - [[item:255846]]
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]] *—— 一次大量的治疗爆发 - 12.1的升级版本*
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240983]] *- 你的装备上只能镶嵌一颗永歌钻石。*
  - [[item:240900]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707]]  <br>[[item:244007]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAsbB]] |
| 胸部 | [[item:243977@BAAAAsbB]] |
| 护腕 | [[item:275707]] |
| 腰带 | [[item:275707]] |
| 腿部 | [[item:240133@BAAAAsbB]] |
| 靴子 | [[item:244009@BAAAAsbB]] |
| 戒指1 | [[item:243959]] |
| 戒指2 | [[item:243959]] |
| 武器 | [[item:244031@BAAAAEcB]] |

:::

:::column
:::gear **增辉 唤魔师** 团本中的附魔
```json
{
  "source_code": "JQFZBXQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB3jbCYgy94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买[[item:275707]]，为你的**头盔**、**护腕**和**腰带**添加插槽。

## 宏

查看 **增辉 唤魔师** 在 团队副本 战斗中推荐的宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[talent:115536]] -- *无需确认，直接在鼠标位置施放 [[talent:115536]]。***

```wow-macro
#showtooltip 
/cast [@cursor] 亘古吐息(青铜龙)
```

:::

:::details 鼠标指向宏
**[[talent:115675]] -- *对鼠标悬停目标或当前目标使用 [[talent:115675]]*。**

```wow-macro
#showtooltip 先知先觉
/cast [@mouseover,help,nodead][] 先知先觉
```

**[[talent:115602]] -- *对鼠标悬停目标或当前目标使用 [[talent:115602]]*。**

```wow-macro
#showtooltip 灼烧之焰(红龙)
/cast [@mouseover,help,nodead][] 灼烧之焰(红龙)
```

[[talent:115666]] 和 **[[talent:125610]] -- *对鼠标悬停目标使用 [[talent:115666]]* 或 *[[talent:125610]]*。**

```wow-macro
#showtooltip
/cast [known:374968] 时间螺旋; [@mouseover] 空间悖论
```

**[[talent:115508]] -- *对鼠标悬停目标或当前目标使用 [[talent:115508]]*。**

```wow-macro
#showtooltip 炽火龙鳞
/cast [@mouseover,help,nodead][] 炽火龙鳞
```

:::

:::details 通用与取消光环宏
**[[spell:403264]]** ***-- 省去手动施放 [[spell:403264]] 的需要，并且如果你使用 [[talent:123331]]**，可以提前取消 [[talent:115536@FAgARegBviiB]]**。***

```wow-macro
#showtooltip 喷发
/cast [nostance:1] 黑龙协调
/cancelaura 亘古吐息
/cast 喷发
```

**[[talent:115665]]** 取消光环宏 -- *第一次按下施放 [[talent:115665]]，第二次按下取消该增益。*

```wow-macro
/cancelaura 扭转天平(青铜龙)
/cast 扭转天平(青铜龙)
```

:::

:::details 实用 宏
**[[spell:370665]] 鼠标指向宏 -- *在鼠标所指位置施放 [[spell:370665]]*，以你的焦点目标为起点，鼠标光标处为终点。**

```wow-macro
#showtooltip 营救
/tar [@focus]
/cast [@cursor] 营救
/targetlasttarget
```

**[[spell:370665]] 鼠标指向宏 -- *在鼠标所指位置施放 [[spell:370665]]*，以你的当前目标为起点，鼠标光标处为终点。**

```wow-macro
#showtooltip 
/cast [@cursor] 营救
```

:::

:::

## 插件

下方是作者的 增辉 唤魔师 **用户界面截图**，其中标明了所使用的插件以及它们在团队副本中如何帮助你更轻松地游戏。

![Augmentation Evoker Interface in Raids](<https://assets-ng.maxroll.gg/wordpress/AugmentationRaidMidnightUI-1-1024x617.webp>)

**增辉 唤魔师** 团队副本界面

:::accordion
:::details 插件
- **BetterCooldownManager / BCDM** *--* 冷却管理器自定义插件
  
  - 为冷却管理器提供额外的自定义选项。
- **Unhalted Unit Frames / UUF** *-- 单位框体插件* 
  
  - 为玩家、目标和首领框体提供自定义选项。
  - 另外，你也可以使用 ElvUI
- Plater -- 高级姓名板插件
  
  - Plater 是一款拥有海量设置选项的姓名板插件，开箱即用，支持减益效果监控和仇恨着色。
- **Details** -- 深度伤害统计插件
  
  - 最强大、最可靠、最漂亮的伤害统计插件。
- **BigWigs** *-- 通用首领模块插件* 
  
  - BigWigs 是一款首领战斗插件。它由许多独立的*战斗脚本*（或称*首领模块*）组成；这些小型插件旨在为某个特定的 团队副本 战斗触发警报信息、计时条、音效等内容。
- **Bartender4** -- 动作条插件
  
  - 替代默认动作条，提供更多自定义选项和额外功能。
- **RaidFrameSettings / RFS** -- 暴风雪 团队副本 框体自定义插件
  
  - 为默认的 暴风雪 团队框体提供额外的自定义选项。
- **NorskenUI** *-- 集换肤、便利功能与特性于一身*
  
  - 众多"整合型"插件之一，包含多项便利性改进、界面换肤以及其他实用功能。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**唤魔师**

- 万应灵药 治疗效果提高25%

**英雄天赋**

- **[[talent:123333]]**
  
  - *开发者说明：群龙之首的冷却缩减机制强烈促使玩家将轰炸效果分散施加到多个目标上。我们认为这种玩法单独来看并不直观，此外还会引发一些不健康的行为，例如 prematurely 打断毁灭以及囤积群体裂解/喷发。此次重新设计旨在保留该天赋的 多目标侧重，同时解决这些问题。我们将提高鳞长的部分范围伤害来源，以补偿新的群龙之首所提供的冷却缩减的降低。*
  
  
  
  - 群龙之首已被重新设计——群体裂解/大规模喷发每命中一个目标，会使深呼吸/亘古吐息的剩余冷却时间缩短0.5秒/1秒。
  - 特遣动员的火翼伤害提高40%。
  - 战术机动的持续伤害提高40%。

**增辉**

- *开发者说明：由双生施放的雷霆风暴所带来的额外控制能力，对地下城游戏体验的扭曲程度超出了预期，并且由于触发时机不受控制，在某些情况下可能令人沮丧。*
- 顶尖天赋：双生 – 你的双生施放的 地壳激变 不再将敌人击到空中。
- 所有技能和宠物伤害提高 3%。
- 活化烈焰 治疗效果提高 25%。
- 青翠之拥 治疗效果提高 25%。
- 翡翠之花 治疗效果提高 25%。
- 驳斥命运 治疗效果提高 25%。
- 熔火血脉 治疗效果提高 25%。
- *至暗之夜* 第一赛季 2 件套加成不再延长 喷发 对 黑檀之力 的延长时长。
- **英雄天赋**
  
  - **[[talent:123334]]**
    
    - 双重时机已更新 - 黑檀之力 暴击时所给予的额外属性现在持续 15 秒（受 精通：时光旅行者 修改），若 黑檀之力 在双重时机已激活时再次施加，则会延长其持续时间。双重时机与 先知先觉 的联动机制不变。
  
  
  
  - **[[talent:123333]]**
    
    - 群龙之首 现在每击中一个目标可使 亘古吐息 的冷却时间缩短 1.5 秒（原为 1 秒）。

:::

:::

:::accordion
:::details 12.0.5 补丁
**唤魔师**

- 新技能：战斗幻象 – 激活后，当你未施放 火焰吐息 和振翅等龙类法术时，自动变回你的幻象形态。
  
  - 会使你暂时变形为龙希尔的全技能列表：深呼吸、梦境外飞、亘古吐息、火焰吐息、永恒之涌、梦境之息、地壳激变、悬空、空间悖论、营救、微风、青翠之拥（未点梦境分身天赋时）以及振翅。
  - 许多过去会强制变形为龙希尔的技能，现在在幻象形态下有了调整后的视觉效果。
  - 激活期间，战斗幻象还会对龙希尔形态应用摄像机高度覆盖，以防止在形态之间切换时摄像机剧烈调整。
- 拆解 伤害提高 300%。
- 青铜的祝福现在可以施放于不在你小队或团队中的友好玩家，与 奥术 智力等其他群体增益类似。
- 修复了 双生护卫 在 营救 开始时而非落地时施加加成的问题。

- 增辉
  
  - 新天赋：威力地狱火——烈焰祝福的伤害提高40%，且你的延长黑檀之力的效果同样会延长烈焰祝福。
  - 烈焰祝福现在会正确地始终应用于施法的唤魔师，不再应用于宠物。
  - 愈复甲质有了新的图标。
  - 熔火余烬已被移除。
  - **[[talent:123334]]**
    
    - 新天赋：时光发电机——活化烈焰的施法时间缩短0.2秒，且在非瞬发施法时造成的伤害或治疗量提高50%。
    - 能量循环已被移除。

:::

:::

:::accordion
:::details 补丁12.0.1
**唤魔师**

- [[spell:357208]]的总伤害（即时伤害和周期性伤害）现在在所有蓄力等级以及所有影响火焰吐息的天赋组合下都应保持一致。
- [[talent:115663]]治疗效果提高60%。

- **增辉**
  
  - [[spell:395152]]不再可以通过取消光环来取消。
  - [[spell:395152]]的延长范围现在与[[spell:395152]]的施放范围一致。
  - [[spell:361021]]现在如果冷却时间被延长，将动态更新其持续时间。
  - [[spell:361021]]和[[talent:115675]]已更新，可正确检测所有主要爆发冷却技能，并且不再于坦克或治疗专精上激活。
  - [[talent:115655]]治疗效果提高50%。
  - [[spell:355913]]治疗效果提高50%。

:::

:::

:::accordion
:::details 补丁12.0
**唤魔师**

- **[[talent:123334]]**
  
  - 新天赋：[[talent:135743]]——[[talent:115665]]的冷却时间缩短30秒。
  - 新天赋：[[talent:135741@AJQDCA]]——[[talent:117551@AJQDCA]]的最大伤害或治疗量提高40%，最高可达350%。
  - 新天赋：[[talent:135742]]——[[talent:117552@AJQDCA]]每6秒赋予一次[[spell:392268]]。
  - 新天赋：[[talent:117544@AJQDCA]]——[[talent:115675]]冷却时间缩短2秒，并额外赋予1%的爆击几率。
  - [[talent:117539@AJQDCA]]已被重新设计——现在使[[talent:115675]]的持续时间延长15%。
  - 命运之线已被移除。
- **[[talent:123333]]**
  
  - 新天赋：[[talent:136053]]——在[[talent:115536@FAQARegB]]或[[spell:357210]]期间飞行时，一支龙希尔小队会协助你，用烈焰打击敌人，最多8次对附近敌人造成火焰伤害。
  - 新天赋：[[talent:136052@AJQD]]——[[talent:117536]]或[[talent:122279]]额外攻击1个目标。
  - 新天赋：[[talent:136051]]——精粹技能造成的伤害提高15%。
  - [[talent:120123]]现在赋予一层[[spell:358267]]，而不是赋予全部层数。
- 职业
  
  - 新天赋：[[talent:115617]]——在[[talent:115536@FAQARegB]]或[[spell:357210]]期间飞行时，你原本会受到的伤害的100%改为在10秒内逐渐承受。
  - 新天赋：[[talent:136560]]——[[spell:358733]]的速度和高度提高10%。
  - 新天赋：[[talent:115620]]——你的[[spell:361469]]和[[spell:367979]]对你自身的效果提高30%。
  - [[talent:115595]]已被重新设计——[[talent:115596]]使移动速度提高100%，并允许在移动中施法，持续3秒。
  - [[talent:115669]]已被重新设计——现在会强化[[talent:115613]]，使其在8秒内治疗你，治疗量等于其所减免的伤害量。
  - [[talent:115616]]已被重新设计为被动效果——[[spell:357208]]会吞噬敌人的吸收护盾，并对其造成额外的冰霜法术伤害。
  - [[spell:362969]]伤害提高50%。
  - [[talent:115657]]现在在激活期间会改变[[spell:361469]]的图标。
  - 修复了[[spell:357208]]在玩家死亡并在其激活期间复活后可能引到敌人的问题。
  - 若干天赋在天赋树中的位置发生了变动。
  - 以下天赋已被移除：
    
    - [[spell:375577]]
    - [[talent:115645]]（移至增辉和湮灭天赋树
- 增辉
  
  - 新天赋：[[talent:115528]]——[[talent:115531]]现在可以赋予盟友[[talent:115675]]，且触发几率提高10%。
  - 新天赋：[[talent:115493]]——[[talent:115522]]治疗量提高100%，冷却时间缩短1分钟。
  - [[talent:115511]]已被重新设计——[[talent:115508]]不再损失层数，且造成的伤害提高20%。
  - [[talent:126304]]已被重新设计——[[talent:115536@FAQARegB]]使你接下来6次[[talent:115498@FAQARegB]]的精粹消耗减少1点。
  - [[talent:126305]]已被重新设计——受到[[spell:357208]]持续伤害效果影响的敌人，受到你的黑系法术的伤害提高25%。
  - [[talent:115690]]现在在增辉专精天赋树中学习（原为职业天赋）。
  - [[talent:115496]]现在赋予8%的主属性（原为5%）。
  - [[talent:115496]]现在应用于100码内所有造成伤害的盟友。
  - [[talent:115496]]现在在应用于2名以上其他盟友时会分割其效果，且不再限制最多2次施放。
  - [[spell:409560]]现在当[[talent:115496]]应用于2名以上盟友时会降低其效果。
  - [[talent:115536@FAQARegB]]的[[spell:409560]]减益效果现在对所有盟友可见，并在光环提示信息中标明其累积的伤害量。
  - [[talent:115536@FAQARegB]]现在累积15%的伤害（原为10%）。
  - 所有法术和技能伤害降低23%。
  - 宠物和仆从造成的伤害降低15%。
  - [[talent:115522]]治疗量提高100%。
  - [[talent:115510]]吸收量提高30%。
  - [[talent:115495]]现在仅以你和1名附近盟友为目标（原为所有拥有[[talent:115496]]的盟友）。新增了火焰精灵的新视觉效果以代表该祝福。
  - [[talent:115495]]伤害提高至350%法术强度（原为88%法术强度）。
  - [[talent:115688]]现在使[[talent:115498@FAQARegB]]的伤害提高20%。
  - 冷却时间管理器已更新，以反映增辉的改动，现在可用于追踪目标身上[[spell:357208]]、[[talent:115536@FAQARegB]]和[[talent:117533@AJQDCA]]的持续时间。
  - 若干天赋在天赋树中的位置发生了变动。
  - 以下天赋已被移除：
    
    - [[spell:371016]]
    
    
    
    - [[talent:115620]]*（移至**职业**天赋树）*
    
    
    
    - [[spell:1219236]]
    - [[talent:115617]]*（移至**职业**天赋树）*

:::

:::

## 常见问题

:::accordion
:::details 问：你会围绕 [[spell:408004]] 来操作吗？
会的，你应该尝试抢取 [[talent:115520]] 以获得 [[talent:115506]]，因为多数情况下尝试这样做你并不会损失什么。

例如，如果你剩下2个 [[talent:115520]] 和6点精华，你会想

- 施放 [[talent:115498]]，配合 [[talent:115520]]
- 施放 [[talent:115498]]，配合 [[talent:115520]]
- 施放 [[talent:115498]]  
  施放 [[spell:361469]]，尝试抢取 [[talent:115520]] 以延长 [[talent:115506]]

:::

:::

---

### 致谢

作者：**fraggo**

审校：**Ftm**

---

:::changelog 更新记录
**2026-08-06** 已更新至 12.1 版本

**2026-06-16** 已更新至 12.0.7 版本

**2026-04-21** 已更新至 12.0.5 版本

**2026-02-22** 已更新至 至暗之夜 上线版本

**2026-02-10** 已更新至 12.0.1 版本

**2026-01-15** 已更新至 12.0 版本

**2025-12-02** 已更新至 11.2.7 版本

**2025-10-07** 已更新至 11.2.5 版本

**2025-08-04** 已更新至 11.2 版本

**2025-06-17** 已更新至 11.1.7 版本

**2025-04-21** 已更新至 11.1.5 版本

**2025-02-18** 已更新至 11.1 版本。

**2024-12-17** 已更新至 11.0.7 版本。

**2024-10-23** 已更新至 11.0.5 版本。

**2024-08-17** 已更新至 11.0.2 版本。

**2024-07-24** 攻略撰写于 11.0.1 前夕版本。



:::
