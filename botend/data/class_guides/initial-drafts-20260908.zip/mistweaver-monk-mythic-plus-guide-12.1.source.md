Welcome to the **Mistweaver Monk** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 70? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 4/5 · Strong

Damage · 3/5 · Average

Utility · 3/5 · Average

Survivability · 3/5 · Average

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Mistweaver Monk** Mythic+ Best in Slot Gear
```json
{
  "source_code": "J4oAwDlDBc__BEwAmQggQEAAvj7AX16ACKwF2gVABk-FEAQEBAg-sOg-sOAj1IoAYFQAdSCBCgQAAUTuDIoAOFQAiSCBCgQAAkQuDIoAOFQAgfBBAiQByQhgCgVAB4ZCtQwGqmQLEU-FF0CAP0QLsA2uDQIIBAwJqOQGAHgYAAQBBwyt1sUABAKJEAACBAQBUBC3XQggIEAAvkbAkUgEEAYL-IBAEQ1HZADAX1BDE09FNgBEYFQA0LSB-xQB5OQOB8AWJA8AEASAAMHwDkBwDAAAAAAAAcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240890]] |
| 肩部 | [[item:271517]] | [[item:244021]] |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240890]] |
| 腿部 | [[item:271518]] | [[item:240155]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240890]] · [[item:240167]] · [[item:245785]] |
| 手部 | [[item:271520]] |  |
| 戒指一 | [[item:268252]] | [[item:240890]] · [[item:244015]] |
| 戒指二 | [[item:273792]] | [[item:240890]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245875]] · [[item:245785]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Mistweaver Monk**, you have access to Spiritfont, which makes your [[talent:124985@FAQAv7eB]] and [[spell:116670]] have a chance to to cause your next [[talent:124922@FAQAv7eB]] to channel [[talent:124933@FAQAIbrB]] onto 5 allies at 20% effectiveness for 8 sec.

**Rank 2** increases the damage of  [[talent:124985@FAQAv7eB]] and healing of [[talent:124922@FAQAv7eB]]. **Rank 3** makes [[talent:124921@FAQAv7eB]] active Spiritfont it applies shields from [[talent:124913]] at 30% effectiveness.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-mistweaver-mxr.webp>)

**Spiritfont**

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:124913]]
    
    - Now increases the cast speed of [[talent:124922@FAQAv7eB]] by 30% for the whole duration while your [[talent:124915]] is active.
  - [[talent:124907]]
    
    - Increases the healing by your [[spell:115151]] on your lowest health  % ally by 500%.
  - [[talent:128221@AJgCBA]]
    
    - Now only heals 5 allies for a certain amount, it no longer increases the output of [[spell:115151]].
  - [[talent:124908@FAQAv7eB]]
    
    - Now buffs a stat by 8% and no longer has a duration when used, the buffs stays until you empowered a different ability.
- **Class Tree**
  
  - [[talent:136519@AJgCBA]]
    
    - After casting [[talent:124985@FAQAv7eB]] your next [[spell:116670]] is instant.
  - [[talent:124958@FAQAIbrB]]
    
    - Summons a [[talent:133997@FAQAIbrB]] whenever you use [[talent:124921@FAgAv7eBHUwA]] so you never have to replace your statue during a fight.
- **Removed**
  
  - [[talent:134029]] 
    
    - Is now removed and is embedded into [[talent:124968@FAQA18eB]] as a choice node, but only the redirection of harmful magical effects on you, back to the caster. Resulting in you losing a defensive ability.

## Hero Talents

- [[talent:125045]] gives you another cooldown [[talent:125062]], which offers very strong healing and damage for a 1.5 min cooldown. It also offers you great talent nodes such as [[talent:125055]] that lowers the cooldown of some of your abilities. [[talent:125045]] also enhances your other spells and gives you some utility as well.
- [[talent:125044]] focuses more on increasing your DPS output and has chances of being a strong choice if you wanna do high DPS if they change back to how it worked before.
- But overall [[talent:125045]] is the stronger choice for Mythic+ for now.



### [[talent:125044]]

- [[talent:125033]] stores "vitality", up to a certain amount, from 10% of your damage, and 20% of your healing, with overhealing at a reduced amount. Casting [[spell:116680]] activates [[talent:125033]] for 10 seconds, making your spells draw out the amount of vitality stored, to deal 40% additional damage or healing over 8 seconds on the targets.
  
  - Through [[talent:125039]] which makes [[talent:125033]] have a chance of spreading to a nearby target, by dealing damage or healing. You also deal 10% more damage and healing to targets you healed with [[talent:125033]].
- [[talent:125038]] makes your [[talent:126499]] increases all vitality store by 25% for 10 seconds.
- [[talent:125034]] enables [[talent:125033]] through your single target abilities to draw vitality to deal damage.
- [[talent:125036]] gives your [[talent:124921]] another charge.
- [[talent:125029]] makes your single target abilities deal 15% more damage in a line in front of you.




### [[talent:125045]]

- You gain the ability [[talent:136562@AJgCBA]] on a 1.5 min cooldown, this is a very strong cooldown for healing, you may move while channeling.
  
  - You can recast this ability during its duration, to have all the August Celestials assist at 200% increased effectiveness, it will do it automatically if not used before the end of the cast.
- [[talent:135959@AJgCBA]] gives you 75% reduced cooldown time on [[spell:115151]], [[spell:107428]], [[talent:124875]] after casting [[talent:124921@FAgAv7eBHUwA]].
- [[talent:135958@AJgCBA]] gives you 10% haste each time you trigger [[talent:135959@AJgCBA]].





## Talents



### [[talent:125045]]

:::talents **Mistweaver Monk** Mythic+ Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### When to use this Spec

This is the default loadout going into any dungeon. You have to adjust the class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, Dungeon specific talent loadouts are available in the Dungeons section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[talent:124882]]
  
  - The buff from casting [[talent:124881]] or [[talent:124921@FAgAaCDBv7eB]] which makes your [[spell:117952]],  [[spell:100780]], [[spell:100784]] and [[spell:107428]] heal up to 5 injured allies for  an additional 160% of the damage done for 15 seconds, split evenly. You also gain 5% stamina while this buff is up.
- [[talent:124892]]
  
  - [[spell:107428]] and [[spell:124682]] applies [[spell:115151]] with a 6 second duration to random ally. Giving you extra [[spell:115151]] for free basically, and you get a lot of them with this spec due to casting [[spell:107428]] on cooldown.

##### Class Tree

- [[talent:136519@FJQADihBKEA]]
  
  - Making your [[spell:116670]] be instant cast after you cast [[talent:124985@FAQAv7eB]].
- [[talent:124949]]
  
  - When you heal an ally lower than 35% hp, you gain a nice 10% healing increase for the next 4 seconds.

##### Hero Talents

- [[talent:125055]] gives you 75% reduced cooldown time on [[spell:115151]], [[talent:128221]], [[spell:116849]] and [[spell:116680]] whenever you consume stacks of  [[talent:124904]], the duration is increased depending on how many clouds you consumed.
- [[talent:125060]] makes your next [[talent:124922]] cast time be reduced by 50% and give 5 allies a small absorb shield.
- [[talent:125049@AJgCBA]] gives you a [[talent:124870]] for the whole duration of your Celestial.
- [[talent:135958@AJgCBA]] gives you 10% haste each time you trigger [[talent:135959@AJgCBA]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: [[talent:124985@FAQAv7eB]] deals 30% increased damage and [[talent:128221@AJgCBA]]'s healing is increased by 100%.
- **4-Set**: [[talent:124985@FAQAv7eB]] and [[talent:128221@AJgCBA]] have a chance to reset their cooldown when cast as well as 100% mana cost reduction.

### Priority List

#### General rotation

1. Apply [[spell:8647]] to all enemies by doing any damage to them.
2. Cast [[talent:124921@FAgAaCDBv7eB]] and use [[spell:322101]] or [[spell:107428]]  for the Versatility buff, then cast [[spell:117952]].
3. Spin to win with [[spell:107270]] if there are 4+ enemies and you can heal the damage intake with it.
4. Cast [[spell:115151]] so you never reach 3 stacks.
5. Cast [[spell:399491]] or [[spell:116670]] for spot and group healing.
6. Cast [[spell:116680]] and use it on either [[spell:107428]] or [[spell:322101]] for damage, or [[spell:124682]] for instant cast spot heal.
7. Cast [[spell:107428]] on cooldown.
8. Cast [[spell:100784]] when you have any stacks of [[spell:116645]].
9. Cast [[spell:100780]] to gain [[spell:116645]] stacks.
10. Cast [[spell:322101]] for strong self-healing and damage.
11. Cast [[spell:116670]] to heal an ally and the party.
12. Cast [[talent:124933@FAgATycATycA]] if someone is in need of serious spot heal for a longer duration.

#### For Damage

1. Cast [[talent:124921@FAgAaCDBv7eB]].
2. Cast [[spell:107428]]
3. Cast [[spell:100784]] on cooldown.
4. Cast [[spell:100780]].
5. Cast [[spell:101546]] if there are 4 or more enemies.

### Cooldowns

#### Invoke Chi-Ji, the Red Crane

- Your main healing cooldown as a **Mistweaver Monk** summons an effigy of Chi-Ji, that shields allies with [[talent:124913]], and your cast time of [[spell:124682]] now becomes an instant cast. 
  
  - [[talent:124913]] gives a shield to 5 allies, and also makes your [[spell:124682]] apply an extra HoT and 10% heal increase with [[spell:358560]].
  - [[talent:124894]] reduces the cooldown down to 1 min , but decreases duration to 12 sec.

#### Thunder Focus Tea

- Use [[spell:116680]] on [[spell:107428]] for a cooldown reset or you can also use it on [[talent:124922]] for an instant cast spot heal if necessary.

#### Life Cocoon

- A high absorb external, [[spell:116849]], can be a lifesaver for both allies and yourself. You can use it before a high-damage event to save some personal cooldowns on your allies, or so you can entirely focus on healing the rest of the group.

## Deep Dive

#### Spin to win or Ancient Teachings for healing?

1. If there are 7+ enemies, then spin to win with [[spell:107270]] if you have talented [[talent:134001]] for the most healing.
2. On 4-6 enemies then keep casting [[spell:107270]] for damage, but only if you can heal through the damage intake.
3. If there are 1-3 enemies then [[talent:124882]] is by far more healing and damage.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Mistweaver Monk** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[talent:124937]]




### Den of Nalorakk

:::talents **Mistweaver Monk** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]].
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:124937]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Mistweaver Monk** Mythic+ Build in Murder Row
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Mistweaver Monk** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots by shapeshifting.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscare Arena

:::talents **Mistweaver Monk** Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Mistweaver Monk** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Mistweaver Monk** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Mistweaver Monk** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAgxwyMLjZx2MmZ2WgllZYYmNLzMWYmpZMDYwAsMzMzwshZwyMBAAAAQAWsNLbzyMDAAMYMAzAGgFZMD"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got adjusted going into **Midnight Season 1** making it more beginner friendly:

- +2 Affixes
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  
  
  
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed
- +7 Affix -- Alternates between each other on a weekly basis
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  
  
  
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Discipline Priest**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:8122]] to interrupt as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - There is nothing special you can do to help with this affix.
- Xal'atath's Bargain: Oblivion
  
  - Keep an eye behind you and collect any orbs that fly into melee range. Make sure to intercept them before they hit any enemies.
- Xal'atath's Bargain: Devour
  
  - You can remove all debuffs at once with [[spell:32375]]. If [[talent:124919]]is on cooldown make sure to instantly single dispel one healing absorb debuff!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Mistweaver Monk**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Mistweaver Monk** Stat Priority in Mythic+
```json
{
  "source_code": "JoAJFUAJgEDKBEQADA"
}
```
**智力 ＞ 急速 ＞ 暴击 ＞ 精通 ≥ 全能**
:::

> The conclusion here is that you want to equip the highest item level generally.

Blizzard introduced Stat DRs that you need to be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful Leech is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/mistweaverLEECHraid-ezgif.com-png-to-webp-converter-1024x428.webp>)

**Mistweaver Monk** healing breakdown from Warcraftlogs

## Gear



### Best in Slot

Due to the way stat weights work for **Mistweaver Monk**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAkGAvj7cVrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAkGA6z6oPrDj1IoAYFA]] | Ula'tel |
| Shoulder | [[item:271517@DgQAAkGA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAkGACKAWBA]] | Coiled Altar |
| Chest | [[item:271522@DgQAAkGAJk7IoAOF]] | Tier/Catalyst |
| Wrist | [[item:244576@FCSAAkGAno6kBwj-sOAAAAAAAA3WzSB]] | Crafting |
| Gloves | [[item:271520@BgQAAkGACKgTBA]] | Tier/Catalyst |
| Belt | [[item:268256@BiQAAkGA6z6IoAYF]] | Coiled Altar |
| Legs | [[item:271518@DgQAAkGAbo6IoAOF]] | Coiled Altar |
| Boots | [[item:268261@DgQAAkGAPk7IoAOF]] | Twin Fangs |
| Ring 1 | [[item:268252@DiQAAkGAvk7oPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:273792@DiQAAkGAvk7oPrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270164@BgQAAkGACKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAkGACKgTBA]] | Nymrissa |
| Weapon | [[item:271092@DgQAAkGAFk7kjAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FASAAkGAzB8kBwDAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Raids from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@BgQAAkGACKQQBA]] | Altar of Fangs |
| Neck | [[item:273781@BgQAAkGACKQQBA]] | Altar of Fangs |
| Shoulder | [[item:273774@BgQAAkGACKQQBA]] | Altar of Fangs |
| Cloak | [[item:193763@BgQAAkGACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@BgQAAkGACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251135@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:251124@BgQAAkGACKQQBA]] | Murder Row |
| Belt | [[item:159301@BgQAAkGACKQQBA]] | King's Rest |
| Legs | [[item:251130@BgQAAkGACKQQBA]] | Murder Row |
| Boots | [[item:251153@AgQAAIoABFA]] | Den of Nalorakk |
| Ring 1 | [[item:273792@BgQAAkGACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:159459@AgQAAIoABFA]] | King's Rest |
| Trinket 1 | [[item:250215@BgQAAkGACKQQBA]] | Murder Row |
| Trinket 2 | [[item:273649@AgQAAIoABFA]] | King's Rest |
| Two-Hand Weapon | [[item:159636@AgQAAIoABFA]] | Tempel |
| One-Hand Weapon | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:273779@BgQAAkGACKQQBA]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A-Tier** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]] |
| **B-Tier** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]][[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:240167]]
  
  - Very strong stat stick, that also empowers your allies.

### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241288]]
  
  
  
  - [[item:241300]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240890]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@DAAAAkGAvj7A]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:243977@BAAAA4QA]] |
| Wrist | [[item:275707@DAAAAkGAvj7A]] |
| Belt | [[item:275707@DAAAAkGAvj7A]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:244015@BAAAAkG]] |
| Ring 2 | [[item:244015@BAAAAkG]] |
| Weapon | [[item:243973@BAAAAkG]] |

:::

:::column
:::gear **Restoration Druid** Enchantments
```json
{
  "source_code": "JQFZOEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAAv0AEo8SuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Mistweaver Monk** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Night Elf
  
  - Turns you invisible, any action, movement, or suffering any damage breaks this effect.
- [[spell:65116]] -- Dwarf
  
  - Removes all magic, bleed, poison, and disease effects and reduces physical damage taken.
- [[spell:274738]] *-- Mag'har Orc*
  
  - 2 minute cooldown that gives you a high amount of secondary stats.

### Recommendation:

For this coming patch, Mag'har Orc is going to be a very good choice due to their racial [[spell:274738]], on a 2 min cooldown, which grants you a massive amount of one secondary stat for 15 sec, now choosing one of your 2 highest secondary stats, you can treat this as a smaller cooldown by itself to enhance your output even outside of your cooldowns.

## Macros

Discover recommended macros for **Mistweaver Monk** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Mistweaver Monk** Mythic+ Guide are available as mouseover macros for your convenience!

**[[spell:116670]]**

```wow-macro
/cast [@mouseover, help] Vivify; Vivify
```

**[[spell:124682]]**

```wow-macro
/cast [@mouseover, help] Enveloping Mist; Enveloping Mist
```

**[[spell:115151]]**

```wow-macro
/cast [@mouseover, help] Renewing Mist; Renewing Mist
```

**[[spell:115175]]**

```wow-macro
/cast [@mouseover, help] Soothing Mist; Soothing Mist
```

**[[spell:399491]]**

```wow-macro
/cast [@mouseover, help] Sheilun's Gift; Sheilun's Gift
```

**[[spell:116849]]**

```wow-macro
/cast [@mouseover, help] Life Cocoon; Life Cocoon
```

**[[spell:115450]]**

```wow-macro
/cast [@mouseover, help] Detox; Detox
```

:::

:::details Recommended Macros
**Makes you spinn faster with [[spell:107270]]**

```wow-macro
#showtooltip
/cast !Spinning Crane Kick
```

**Your [[spell:116844]] instantly goes off when you press the button without having to confirm click, use with caution.**

```wow-macro
#showtooltip
/cast [@cursor] Ring of Peace
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Mistweaver Monk**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![Mistweaver Monk User Interface in Mythic+](<https://assets-ng.maxroll.gg/wordpress/mistweavermui-ezgif.com-optiwebp-1024x614.webp>)

**Mistweaver Monk Mythic+**

:::accordion
:::details Addons
- **Shadowed Unit Frames** --- Party/Raidframe Addon
  
  - Simplistic addon to replace your Unitframes and other UI Elements with a more clean look.
- **Vuhdo** --- Party/Raidframe Addon
  
  - Addon to replace your Unitframes.
- **Plater** --- Nameplate Addon
  
  - Plater is a nameplate addon with an extraordinary amount of settings out of the box. Debuff tracking, threat coloring, support for scripting similar to WeakAuras + the WeakAuras-Companion for Mod/Script/Profile updates.
- **BigWigs** -- BossMods Addon
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific raid encounter.
- **Details** --- Damage Meter
  
  - Shows you Damage/Healing throughout the encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- **Mistweaver**

- New Talent: Vital Expenditure – Soothing Mist's healing is increased by 300%, but its mana cost is increased by 200%. Choice node with Dancing Mists.
- Dance of the Wind has been updated – Your physical damage taken is reduced by 10% and an additional 10% every 4 seconds until you receive a physical attack, stacking up to 4.
- All healing reduced by 3%.
- Mastery: Gust of Mist healing increased by 50%.
- Spinning Crane Kick damage decreased by 7%.
- Way of the Crane now transfers 280% of damage done (was 340%).
- Jadefire Teachings now increases Ancient Teaching's transfer amount by 320% (was 270%).
- Morning Breeze effectiveness reduced by 60%.
  
  - *Developers' notes: Morning Breeze’s value is being adjusted down in accordance with the Mastery: Gust of Mist increases in Curse of Ula'tek. This should leave the talent’s effectiveness at a similar overall level.*
- Fixed an issue that caused Temple Training’s Spinning Crane Kick damage increase to apply to Mistweaver.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:116849]] as your own defensive cooldown.

:::

:::details Q: Why do I keep running out of mana?
A: You need to make good use of [[spell:115869]], and you may be casting too many [[spell:124682]].

:::

:::

---

### Credits

Written By: **Velo**

Reviewed By: **Rycn**

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1

**2026-06-23** Updated for patch 12.0.7

**2026-04-22** Updated for patch 12.0.5

**2026-02-22** Updated for patch 12.0.1

**2026-01-14** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-08** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-22** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5



:::
