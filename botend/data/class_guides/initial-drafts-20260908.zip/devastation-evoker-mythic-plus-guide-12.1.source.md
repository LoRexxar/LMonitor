Welcome to the **Devastation Evoker** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 2/5 · Weak

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Devastation Evoker** Mythic+ Best in Slot
```json
{
  "source_code": "JAoAwD1uFc__BEQjkQggIEAAnk7AX16ACKgTBEQ6XQAAREAAE06AE06AMWjgCgVABsIJEIACBAwF5OggCgVABQgJEIAEBAQC5OggCwYNYFQAefBBAiQB0UwQAwYCvQQBqmwLIk8FEEgPAkSAvgjTBEAa7OAhIEAAYA8AnoaAkxyt1sUAB4IJEAACBAQB_AS2XQggAEAA1jbAeQhTBEgnqJQAkmAEFICBU9RGuQAhtkBDE09FNwAFYFQA0LCBBYHA_EgdMhVABkAwDQACBAAelNApqQwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271499]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240900]] |
| 腿部 | [[item:271500]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:244009]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:273796]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] | [[item:222584]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Devastation** you have access to Rising Fury, which grants you a stacking Haste buff and more damage during and after [[talent:115643@FAQA4AcB]].

**Rank 1:** While [[talent:115643@FAQA4AcB]] is active you gain [[spell:1271687]] every 6s, which grants 4% Haste stacking up to 5 times.

**Rank 2 - (1/2):** At 5 stacks of [[spell:1271687]] all damage dealt is increased by 8%.

**Rank 2 - (2/2):** At 5 stacks of [[spell:1271687]] all damage dealt is increased by 15%.

**Rank 3:** When [[talent:115643@FAQA4AcB]] ends, [[spell:1271687]] persists for 4s per stack and [[talent:115643@FAQA4AcB]] becomes [[spell:1292321]]. [[spell:1292321]] may be cast 4 times before [[talent:115643@FAQA4AcB]] finishes its cooldown.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-devastation-mxr.webp>)

Rising Fury

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115579]]
    
    - A new AoE focused talent that upgrades your next [[spell:362969]] to a more powerful version after casting [[talent:115581]].
    - Greatly enhanced by the Season 1 Tier set, making it a core rotational spell in all situations.
  - [[talent:115623]]
    
    - Allows you to cast [[spell:357210]] again within 18 sec of the initial cast.
    - Has strong synergy with [[talent:115639]] and [[talent:117550@AJQD]] as [[talent:123333]].
- **Class Tree**
  
  - [[talent:115617]]
    
    - Previously an **Augmentation** only talent that got moved to the Evoker class tree, makes you safer while using [[spell:357210]]!
  - [[talent:115669]]
    
    - Removed as a separate spell and is now tied with [[talent:115613]] as a less powerful effect.
- **Removed**
  
  - [[spell:370962]]
    
    - [[spell:357211]] now deals more damage but costs 3 Essence to cast unless you have [[talent:115638]] active.
  - [[spell:368847]]
    
    - Doesn't exist as a separate spell anymore and only procs from [[talent:115584]].
  - [[spell:370452]]
    
    - Doesn't exist as a separate spell anymore as it was changed to a passive [[talent:115627]].

## Hero Talents

- [[talent:123333]] is stronger than [[talent:123336]] in every scenario apart from long duration AoE situations.

:::tabs
:::tab [[talent:123333]]
[[talent:123333]] hero talents mostly revolve around the two key spells: [[spell:436335]] and [[spell:357210]].

#### Mass Disintegrate

- [[spell:357208]] and [[spell:359073]] change your next [[spell:356995]] cast into a [[spell:436335]] which either hits up to 3-4 targets or deals increased damage to less targets.

- [[spell:434300@FJQBJHXBknYBNLZB7zwB8zwBNA]]
  
  - Is another [[talent:123333]] talent that is tied to [[spell:436335]].
  - Places a debuff on your target which triggers bombardments as you and your allies attack it.
  - Further improved by [[spell:441206@FJQBJHXBknYBNLZB7zwB8zwBNA]] and [[talent:117525]].

#### Deep Breath

- The other ability that is heavily enhanced by the [[talent:123333]] talent tree.

- [[talent:117518]]
  
  - [[spell:357210]] now causes enemies to take 20% increased damage from [[spell:434300@FJQBJHXBknYBNLZB7zwB8zwBNA]], [[spell:356995]] and [[spell:357211]].
- [[talent:120123]]
  
  - [[spell:357210]] gives you back one charge of [[spell:358267]]. This is a massive mobility boost as you use [[spell:357210]] very often with the new [[talent:115623]] talent.
- [[talent:117538]]
  
  - [[spell:357210]] can now be steered and canceled mid-flight and it inflicts  an additional 12 second damage over time effect.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:136053]]
  
  - While flying during [[spell:357210]] 2 Dracthyr Commandos fly along you and damage nearby enemies with Pyres up to 8 times.
  - You should have at least some flight-time so the Commandos have a chance to shoot out their spells.
- [[talent:136052@AJQD]]
  
  - [[talent:117536]] hits 1 additional target.
- [[talent:136051]]
  
  - Essence abilities deal 15% additional damage.

:::

:::tab [[talent:123336]]
In Midnight, [[spell:443328]], the previous signature ability of [[talent:123336]] has been removed and the gameplay is instead focused around [[spell:357208]].

#### Fire Breath

The spell interacts or is enhanced by the majority of talents in the Hero Talent tree.

- [[talent:117547@AJQD]]
  
  - [[spell:357208]] gains an additional charge.
- [[talent:123416]]
  
  - [[spell:357208]] cooldown is reduced by 5 seconds.
- [[talent:117543@AJQD]]
  
  - [[spell:357208]] reaches its maximum empower level 20% faster.
- [[talent:117542@AJQD]]
  
  - [[spell:357208]] damage over time lasts 4 seconds longer.
- [[talent:128713]]
  
  - [[spell:357208]] damage over time is increased by 30%.
- [[talent:117520@AJQD]]
  
  - [[spell:357208]] deals its damage 15% more often.
- [[talent:136055@AJQD]]
  
  - [[spell:357208]] has a 50% chance to generate [[spell:359565]]
- [[talent:117519@AJQD]]
  
  - [[spell:356995]] and [[spell:357211]] casts consume [[spell:357208]] duration from enemies which triggers damage on them.

##### Other noteworthy talents

- [[talent:117546]]
  
  - Increases your Critical strike chance on targets above 50% health by 10%, this is quite the large damage increase so try to target high health targets whenever appropriate.

You have a choice between the following defensive talents:

- [[talent:117528]]
  
  - With the removal of [[spell:374348]] as a separate spell this now applies [[spell:363916]] at 50% effectiveness, this means it is a 15% damage reduction cooldown with a slight healing effect. You should pick this talent out of the two most of the time.
- [[talent:123405]]
  
  - A small chance of getting healed by 30% of damage taken, on average this ends up healing you for around 5% of your total damage taken, this can sometimes be a good choice if you are the squishiest target in your group.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:136055@AJQD]]
  
  - 50% chance to proc [[spell:359565]] after casting [[spell:357208]]
- [[talent:136056@AJQD]]
  
  - Consuming [[spell:359565]] deals damage to your target.
- [[talent:136054]]
  
  - [[talent:136056@AJQD]] does damage to up to 2 additional targets.

:::

:::

## Talents

:::tabs
:::tab [[talent:123336]] All-Rounder
:::talents [[talent:123336]] **Devastation Evoker** All-Rounder talents in **Mythic+**
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZwMjZGzMwwYMTjZmJjx2MzMzwYmZGwMzMGzMmZGMDMjZgFwSwMMhsBWGmBYmZY",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZwMjZGzMwwYMTjZmJjx2MzMzwYmZGwMzMGzMmZGMDMjZgFwSwMMhsBWGmBYmZY"
}
```
:::

### When to use this Spec

Use this spec if you want to try out [[talent:123336]] in Mythic+ even though it will perform worse than [[talent:123333]]!

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[talent:115579]]
  
  - A new rotational ability, a buffed up Azure Strike cast after every [[talent:115581@FAQANvbB]].
- [[talent:115647]] 
  
  - Your AoE essence spender.
- [[talent:115581]] 
  
  - Your spec-specific Empower spell, enhanced by [[talent:115632]].
  - This has additional cleave synergy with [[talent:115636]].
- [[talent:115643]] 
  
  - Your main DPS cooldown that is enhanced by [[talent:115642]] and [[talent:115640]].
- [[talent:115624]]
  
  - [[spell:357208]] damage ticks have a chance to make your next [[spell:361469]] instant cast. Especially useful for optimizing damage while moving.
- [[talent:115683]] 
  
  - Makes [[spell:356995]] and [[spell:357211]] reduce the cooldown of your Empower spells.
- [[talent:115622]]
  
  - Increases the damage of your Red spells by 25% on targets affected by [[spell:357208]].

#### Class Tree

- [[talent:115602]] 
  
  - An ability unique to Evokers that allows you to dispel Bleed debuffs in addition to other types.
- [[talent:115657]]
  
  - Allows you to shoot an additional [[spell:361469]] per Empower rank after every [[spell:357208]] cast for free cleave damage. These additional [[spell:361469]] can also proc [[spell:396187]] from automatically healing your allies if there are not enough enemies to hit while also potentially getting [[talent:115654]] value. Also has great synergy with [[talent:115584]].
- [[talent:115617]] and [[talent:115656]] 
  
  - These are great talents for M+ tied to [[spell:357210]], allowing you to have another defensive against large hits in boss fights or a long duration AoE stun when fighting trash mobs.

:::

:::tab [[talent:123333]] All-Rounder
:::talents [[talent:123333]] **Devastation Evoker** All-Rounder Talents in **Mythic+**
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### When to use this Spec

This is the default Mythic+ talent build for all key levels.

### Talent Adjustments

Listing all the changes within Class and Spec tree compared to the default build.

### Spec Tree

**[[talent:115579]]**

- **You should pick an extra point in [[talent:115591]]** **instead of this until you acquire the Season 1 Tier set.**

- **Added** 
  
  - [[talent:115639]]
  
  
  
  - [[talent:115638]]
  - [[talent:115623]]
    
    - Picked talents with [[talent:123333]] synergy.
- **Removed** 
  
  - [[talent:115586]]
  
  
  
  - [[talent:115622]]
  - [[talent:115633]]
    
    - Removed talents with [[talent:123336]] synergy.

### Hero Talents

Switched [[talent:123336]] to [[talent:123333]].

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:1265802]] damage is increased by 50% and it always casts as if you had reached maximum empower level.
- **4-Set:** [[talent:115683]] reduces the remaining cooldown of your [[spell:357208]] and [[spell:359073]] by an additional 0.1 sec each time the effect occurs. [[spell:359073]] deals 10% increased damage.

### Single-Target

:::tabs
:::tab [[talent:123336]]
#### Opener Rotation

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123336]] **Devastation Evoker** single-target opener in Mythic+
```json
{
  "source_code": "JMZAwlgA9PYBHAlclBXdsxGAC8SuFAQACl3pFAAACEqeBYAb4kZBAIQAI66AAAAAAEAhtQAAIEAACKgTBIwgyFAIBYAWAWgQLD1EAAQD3lGdoBCVpVmcgMXZ0BgUVAQBx4SXAAEAC0_gFAAACMocFAAACgTmFA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]  [[spell:370553]]
3. [[spell:359073]]
4. [[spell:366904]]  [[item:241288]] · [[item:273796]]
5. [[spell:356995]]
6. [[spell:356995]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]]
   4. [[spell:359073]]
   5. [[spell:366904]]
7. [[spell:361469]]
8. [[spell:356995]]
9. [[spell:366904]]
:::

#### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:357208]] if it's not up on the target *- Rank 1*
2. Cast [[spell:359073]] *- Rank 1*.
3. Cast [[spell:356995]] until you are not capped on Essence or [[spell:357208]] runs out on your target
4. Cast [[talent:115579]] - with Season 1 Tier set
5. Cast [[spell:1292321]]
6. Cast [[spell:361469]] - *if you have [[spell:375801]].*
7. Cast [[spell:356995]] until you have no more Essence to cast it or [[spell:357208]] runs out on your target
8. Cast [[spell:361469]].

:::

:::tab [[talent:123333]]
#### Opener Rotation

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123333]] **Devastation Evoker** single-target opener in Mythic+.
```json
{
  "source_code": "JcaAw7jCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogxboaAAAAAANgAWASgQLD1EAAQD3lGdoBCVpVmcgMXZ0BgUVAAKCMocFAQACdeUTAQEvxAAC0_gBMIODKXBAEgQnH1EAAgQfXWB"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]]
7. [[spell:436335]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]]  [[spell:1266151]]
   4. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:356995]]  [[spell:1266151]]
10. [[spell:353759]]
:::

- Check below for the Dragonrage window priority after the initial opener.

#### Dragonrage Priority List

This is a general priority for your Dragonrage window.

1. Cast [[spell:357210]] *- with no [[talent:117518@AJQD]] up on the target or [[talent:115623]]* *is about to run out.*
2. Cast [[spell:359073]] *- Rank 1*.
3. Cast [[spell:357208]] *- Rank 1*.
4. Cast [[spell:356995]] until you are not capped on Essence.
5. Cast [[talent:115579]] - with Season 1 Tier set
6. Cast [[spell:361469]] to proc [[spell:396187]] *- if you have either [[spell:375801]] or [[spell:369939]].*
7. Cast [[spell:356995]] until you have no more Essence to cast it.
8. Cast [[spell:362969]] to proc [[spell:396187]].

#### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:357210]] *- with no [[talent:117518@AJQD]] up on the target or [[talent:115623]] is about to run out.*
2. Cast [[spell:359073]] *- Rank 1*.
3. Cast [[spell:357208]] *- Rank 1*.
4. Cast [[spell:356995]] until you are not capped on Essence.
5. Cast [[talent:115579]] *- **with Season 1*** Tier set
6. Cast [[spell:1292321]]
7. Cast [[spell:361469]] *- if you have 2 stacks of [[spell:375801]] or a single one that is about to run out.*
8. Cast [[spell:356995]] until you have no more Essence to cast it.
9. Cast [[spell:361469]] until you have enough Essence to cast [[spell:356995]].

:::

:::

### Multi-Target

:::tabs
:::tab [[talent:123336]]
#### 2 Target Opener

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123336]] **Devastation Evoker** 2 target opener in Mythic+
```json
{
  "source_code": "JUcAYzgA9PYBHAlclBXdsxGACgTmFAgABgorDAAAAAQAE2CBAgQAAIoAOFgAvkbBAEgQ5daBAAgAhqXAGEALMAgADKXAMEgBYBYBCtMUTAAANcXa0hGIUlWZyByclRHASVBABEDIIQVYydWZ0BiM-4AAJkFB9PYEZ5DIAA0gyVACUFmcnVGdgIDACgTmFA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:366904]]  [[item:241288]] · [[item:273796]]
3. [[spell:375087]]  [[spell:370553]]
4. [[spell:359073]]
5. [[spell:366904]]
6. [[spell:356995]]
7. [[spell:356995]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]] Target 2
   4. [[spell:356995]] Target 2
   5. [[spell:366904]]
8. [[spell:361469]]
9. [[spell:356995]]
10. [[spell:356995]] Target 2
11. [[spell:356995]] Target 2
12. [[spell:366904]]
:::

- On 2 targets your opener and rotation is very similar to single target apart from the fact that you want to ideally always deplete Fire Breath from both targets with [[talent:117519@AJQD]] before casting another one.

#### 3+ Target Opener

:::rotation [[talent:123336]] **Devastation Evoker** 3+ target opener in Mythic+
```json
{
  "source_code": "JEaAYvgA9PYBHAlclBXdsxGACgTmFAgABgorDAAAAAQAE2CBAgQAAIoAOFgAvkbBAEgQ5daBAAgAhqXAGEALQAgQbNXBBwSDIgFgEI0yQNBAA0wdpRHagQValJHIzVGdAYVFA0wOAIQBJBhA9PYBAExRoAgA4kZBAAgQbNXB"
}
```
1. [[spell:361469]] Prepull
2. [[spell:366904]]  [[item:241288]] · [[item:273796]]
3. [[spell:375087]]  [[spell:370553]]
4. [[spell:359073]]
5. [[spell:366904]]
6. [[spell:357211]]
7. [[spell:357211]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:357211]]
   4. [[spell:366904]]
8. [[spell:361469]]
9. [[spell:357211]]
10. [[spell:366904]]
11. [[spell:357211]]
:::

- On 3+ targets your opener and priority is changed to include [[spell:357211]] as the Essence spender, otherwise same rules apply.
- If damage on the secondary targets is irrelevant as often is the case you should keep using the single-target priority list and focus on damaging the main target.

#### 3+ Target Priority List

1. Cast [[spell:357208]] if it's not up on the target *- Rank 1*
2. Cast [[spell:359073]]
3. Cast [[spell:357211]] until you are not capped on Essence or [[spell:357208]] runs out on your target
4. Cast [[talent:115579]] - with Season 1 Tier set
5. Cast [[spell:1292321]]
6. Cast [[spell:361469]] *- if you have either [[spell:375801]] or [[spell:369939]].*
7. Cast [[spell:357211]] until you have no more Essence to cast it.
8. Cast [[spell:362969]].

:::

:::tab [[talent:123333]]
#### 2 Target Opener

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123333]] **Devastation Evoker** 2 target opener in Mythic+
```json
{
  "source_code": "JcbAw7jCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogzboaAAAgAVhJ3ZlRHIxAgNQAAXyAIBCtMUTAAANcXa0hGIUlWZyByclRHASVBAoIwgyVAABI05RNBAR8HDAIQ_DGwk4MocFAQACdeUTAAAC9dZFA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]] Target 1
7. [[spell:436335]] Target 2 
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]]  [[spell:1266151]]
   4. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:356995]]  [[spell:1266151]]
10. [[spell:353759]]
:::

- On 2 targets as a **[[talent:123333]],** the only difference from single-target is that in the opener you should choose different targets with each of the two consecutive [[talent:117536]] following your first two empower spells to apply [[talent:117533]] to both. This way you get more value out of [[talent:117525]] as it extends both bombardments.

#### 3+ Targets Opener

:::rotation [[talent:123333]] **Devastation Evoker** 3+ target opener in Mythic+
```json
{
  "source_code": "JccAw7zCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogzboaAAAgAVhJ3ZlRHIxAgNQAAXyAYBCtMUTAAANcXa0hGIUlWZyByclRHAWVBAQwClGAAANEIFBI05RNBARcIDAIQ_DGQbaJCA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]] Target 1
7. [[spell:436335]] Target 2 
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:431148]]
   4. [[spell:359073]]  [[spell:1266151]]
   5. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:431148]]
10. [[spell:359073]]  [[spell:1266151]]
11. [[spell:353759]]
:::

- **Always use** [[spell:436335]] after Empower spells even if you are fighting higher target counts.

#### 3+ Target Priority List

1. Cast [[spell:357210]] *- with no [[talent:117518@AJQD]] up on the targets or [[talent:115623]]* *is about to run out.*
2. Cast [[spell:359073]] *- Empower according to target count.*
3. Cast [[spell:357208]] *- Empower according to target count.*
4. Cast [[spell:357211]] as Essence spender
5. Cast [[talent:115579]] - with Season 1 Tier set
6. Cast [[spell:1292321]]
7. Cast [[spell:361469]] *- if you have either [[spell:375801]] or [[spell:369939]].*
8. Cast [[spell:362969]] until you have enough Essence for your spender.

:::

:::

## Deep Dive

### Empower spells

#### Fire Breath

[[talent:123336]]

- Always cast Rank 1 in almost any situation because of [[talent:117519@AJQD]] and [[talent:115622]]

[[talent:123333]]

- Use mostly with Rank 1 Empower on single target as you want to have the DoT effect up all the time for [[spell:375801]] procs and [[spell:386283]] synergy.
- Using [[spell:357208]] with a higher Empower rank shortens the damage over time effect in favor of more direct damage. You want to utilize this when your target isn't going to live much longer.
- Ranking up [[spell:357208]] more in AoE situations is also generally recommended, as [[spell:375777]] shortens the cooldown of the spell much more with [[spell:357211]] spam and you would be overwriting your pre-existing DoT effect and wasting damage otherwise. In addition, you get better value from [[talent:115657]].

#### Eternity Surge

- Deciding what rank to use [[spell:359073]] on is very straightforward as it only increases the targets hit by 1 for each rank (or 2 with [[spell:375757]]).
- Rank 1-4: **1/2/3/4** or **2/4/6/8** with[[spell:375757]] targets hit.
- Especially on [[talent:123336]] it's often not worth it to cast this at a higher rank even against more targets because you could be using that time to cast more [[spell:357211]] instead.

In general, you should hold both Empower spells when [[spell:375087]] is about to come off cooldown for proper [[talent:115642]] extensions.

### Disintegrate Mechanics

- Baseline [[spell:356995]] has a cast duration of **two** global cooldowns and **four damage ticks** occur within this time frame.
- Utilizing the **Pandemic** mechanic you can start a new cast of [[spell:356995]] after the **3rd damage tick** has occurred, which transfers the remaining duration and 4th damage tick of the previous cast to the next one.
- This is how you spell queue [[spell:356995]], minimizing downtime and enabling you to use up Essence slightly faster to prevent overcapping.
- Because of this, you would ideally have **[[spell:356995]] ticks** shown on your cast bar so you can **re-cast** at proper timing.

### Using Rescue

- [[spell:370665]] is a great part of your toolkit as an **Evoker**, using it optimally requires fight awareness, especially in raids it can often save your less mobile allies from sticky situations.
- **12.0 Patch** has this change: 
  
  - [[spell:370888]] has been redesigned – [[spell:370665]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  
  
  
  - Means that [[spell:370665]] no longer has a defensive cooldown tied to it but is even more potent as a movement ability!

### Using Hover

- Managing and timing your [[spell:358267]] uses correctly in combat to get more casts in while dealing with mechanics is where you see the biggest difference in your DPS as the actual rotational optimization is not that complex for **Devastation Evoker**.
- Starting a cast of a spell, such as [[spell:356995]] at the very end of a [[spell:358267]] buff still lets you finish that specific cast while moving, even if the buff runs out
- Make sure you are tracking your uptime and charges of [[spell:358267]] well on your UI and get really comfortable with utilizing this ability, as it is the most significant unique strength of an **Evoker**.
- With the **patch 12.0** [[spell:358267]] can now be used during normal casts (mostly [[spell:361469]] and [[spell:356995]] on **Devastation**) without interrupting them.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Altar of Fangs
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### Rav'i

- Use [[spell:363916]] or be ready to health potion if needed whenever you get the [[spell:1296220]] debuff.
- Look out for the waves that the boss shoots out with [[spell:1296058]], these have a clear indicator in front of the boss during the cast.
- You can [[spell:374227]] either [[spell:1307894]] or [[spell:1296220]] in this fight.

#### The Writhing Coil

- The boss always follows up [[spell:1299130]] with a [[spell:1300044]] frontal cone so try to stay close to the boss for easier dodging.
- You can break [[spell:1287797]] from [[spell:1299053]] easily with [[spell:370665]] every time. This is also a good timing to use a defensive cooldown.
- Consider holding [[spell:357210]] for the **Uncoiled Writhe** AoE phase as it is way more impactful there compared to single-target, it should line-up quite naturally though with one use in each phase.
- [[spell:1310358]] requires three single-target kicks during the normal phase so coordinate these with your group, during the **Uncoiled Writhe** phase you can use AoE stops for the casts.

#### Zul'jan

- You should soak one of the lanes for [[spell:1300876]] every time it happens and clear it later with [[spell:1301413]] - use [[spell:363916]] when clearing your debuff.
- Dodge [[spell:1301111]], they are quite fast and bounce around from the walls.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Always stop this cast!
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use [[spell:363916]] or [[spell:374227]] for this.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use [[spell:363916]] or [[spell:374227]] for this.
  - [[spell:1303366]] from Living Venom
    
    - They explode on death, use [[spell:363916]] or [[spell:374227]] for this.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with [[spell:357210]] or [[spell:370665]] if your healer doesn't dispel you.

:::

:::tab Den of Nalorakk
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Den of Nalorakk
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Use either [[spell:363916]] or [[spell:374227]] for every [[spell:1234681]].
- Coordinate with your group to soak [[spell:1234740]], you can also dispel the [[spell:1234846]] with either [[spell:365585]] or [[talent:115602]].
- Try to stay close to the boss as this makes the [[spell:1234021]] cone much easier to dodge.

#### Sentinel of Winter

- The healer can always instantly dispel only one of the two [[spell:1235549]] debuffs so be prepared to use a defensive cooldown or health potion as needed.
- Whenever the **Fractured Shivercores** spawn take the ranged one in focus target and remember to kick it.
- The adds also spawn a soak circle as they die, try to be active with helping soak these if you are nearby!
- Pre-position yourself for [[spell:1235623]] as the tornadoes spawns under players and you don't want them near the snow piles.
- You can use [[spell:374227]] for the [[spell:1235656]].

#### Nalorakk

- Time the use of your Obsidian Scales precisely for [[spell:1243569]] as then it also covers the following [[spell:1242860]].
- [[spell:1242860]] spawns an image your group has to soak later on so position them nicely.
- Help your group soak the charging bears during [[spell:1243002]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - This can be dispelled with [[spell:357210]] or [[spell:370665]]
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - If your tank and healer aren't handling these you can kill each with just one [[spell:362969]].
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Prioritize killing the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Murder Row
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- The fight rotates between killing **Nibbles** and then having a 20 second burst window on **Kystia Manaheart** , try to pool some damage for this as **Nibbles** is getting low.
- [[spell:1253811]] is aimed at the tank and rotates to a random direction, stay close to the boss for easier dodging.
- Try to bait [[spell:474240]] so the boss doesn't move too much as it jumps to an random player.
- Help stop the **Mirror Images** that cast [[spell:1264106]], you can use your interrupt or other stops.

#### Zaen Bladesorrow

- Use a defensive when targeted by [[spell:1217123]] and hit a green barrel with it if one is up.
- Pre-position and "claim" a barrel to hide behind for [[spell:734276]] slightly ahead of time to prevent any confusion.

#### Xathuux the Annihilator

- Place [[spell:1214637]] close to the boss if targeted by it for more efficient cleaving.
- [[spell:474197]] increases the damage taken of the boss for 15 seconds, try to optimize your dps timings for this.
- [[spell:1295453]] and [[spell:474197]] are usually casted in quick succession dealing heavy damage, rotate defensive cooldowns for this.

#### Lithiel Cinderfury

- Use a defensive for [[spell:474462]] and do a tight spread with your group to help with handling the adds that spawn after.
- As the boss jumps away to cast [[spell:1217345]] you need to time the use of [[spell:1214675]] to jump over it.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
    
    - This deals heavy damage, use defensive cooldowns as needed and be ready with your health potion.
  - [[spell:1294824]] from **Defiled Golem**.
    
    - Use [[spell:374227]] for this.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - You can dispel every second cast with [[spell:374251]], if there is no dispel available use [[spell:363916]] and [[spell:374227]] if targeted.

:::

:::tab The Blinding Vale
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for The Blinding Vale
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Pre-position near a flower to soak it during [[spell:1235564]].
- Try to move the boss as little as possible when targeted by [[spell:1235640]] and rotate defensives for the following [[spell:1261011]].
- Interrupt [[spell:1235616]].

#### Ikuzz the Light Hunter

- If you don't have [[spell:357210]] or [[spell:370665]] ready for a dispel, position yourself under the boss after [[spell:1236746]] to cleave down the roots.
- Group up during [[spell:1236709]] to help out the healer.
- Save defensive cooldowns for when the boss is under 50% health as it gains [[spell:1237073]].

#### Lightwarden Ruia

- You can either stack on other players with [[spell:1239824]] or run out and aim  away from the boss.
- Spread out around the boss during the [[spell:1239885]] as each player gets targeted by [[spell:1240257]].
- Try to have defensive and offensive cooldowns ready for the last [[spell:1239883]] phase as this is by far the most difficult part of the fight.

#### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- The boss spawns light orbs around the arena with [[spell:1246858]], intercept them as they try to reach the boss and you will receive a stacking DoT debuff that increases your damage done - use a defensive cooldown if you get multiple stacks.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.
    - You can dispel this with either [[talent:115602]] or [[spell:365585]].

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Voidscar Arena
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### Taz'Rah

- Move around the arena with your group to bait and run away from the [[spell:1296967]] for easier dodging after [[spell:1300259]].
- Use [[talent:115661]] for [[spell:1300259]] when available.
- Use [[talent:115613@FAQAMZbB]] or be ready to top yourself off with a healing potion for [[spell:1222100]].

#### Atroxus

- Stay close to the boss to dodge [[spell:1222721]] easily.
- Use [[talent:115661]] for [[spell:1262497]] when available.
- Focus down **Toxic Creeper** as soon as he spawns and use [[talent:115613@FAQAMZbB]].
- If someone stands in a poison pool you can dispel the debuff from them.

#### Charonus

- Rotate [[talent:115613@FAQAMZbB]] and [[talent:115661]] for each [[spell:1227197]].
- You can strafe to dodge [[spell:1227247]] while playing at max range with [[spell:358267]] up.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - If your tank and healer aren't handling these you can kill each with just one [[spell:362969]].
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
    
    - Focus him down and use defensives for this.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Kings' Rest
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Place the puddle you spawn as [[spell:1306736]] expires next to others for more efficient cleaving as they spawn adds later. You can also use a defensive cooldown when you get targeted by this.

- Use [[talent:115661]] for [[spell:1311987]] when available.

#### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by [[spell:267618]].
- Position yourself on an edge when targeted by [[spell:267639]] as it leaves behind a puddle.

#### The Council of Tribes

- You can dispel the [[spell:266231]] bleed with [[talent:115602]].
- Group soak the [[spell:267494]].
- During the last phase focus down the **Explosive Totem** first after each [[spell:267060]] cast.

#### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** but only with **T'zala** who appears when **King Dazar** drops below 80%.
- Rotate [[spell:363916]] and [[spell:374227]] for each [[spell:1303267]] cast.
- Don't stay too far away during [[spell:1303324]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected by standing behind the shield.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at player locations so group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Ruby Life Pools
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- [[spell:396044]] spawns under players so don't place it in a bad spot.
- Don't damage [[spell:373046]] too fast and let your tank pick them up.
- Use a defensive cooldown if targeted by [[spell:372851]].

#### Kokia Blazehoof

- Interrupt **Blazebound Firestorm** when it casts [[spell:373017]].
- Rotate [[spell:363916]] and [[spell:374227]] for each [[spell:384823]] cast.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

#### Kyrakka and Erkhart Stormvein

- Try to position yourself relatively close to **Kyrakka** whenever it lands as it can be difficult to dodge the [[spell:381525]] otherwise.
- If you get targeted by [[spell:381602]] use a defensive cooldown when available. As it expires it spawn fire pools in the ground that move around with [[spell:381517]] so be mindful of your positioning.
- Look out for [[spell:381516]] and stop your cast accordingly.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.
    
    - Use a defensive or be ready to health potion when you get this debuff.

:::

:::tab Temple of Sethraliss
:::talents [[talent:123333]] **Devastation Evoker** Mythic+ Build for Temple of Sethraliss
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMwwYMTjZmpZM2mxMzMzMzMzAmZmxYmxMzADMzMjNYZMLNWmZYyMZDsNMDmZMGGA"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Pay attention to which boss has [[spell:1310311]] buff and damage the other one, this swaps between them every 33% health intervals.
- Get back to the boss after [[spell:1289062]] knock to soak [[spell:1288092]] - you also need to run out after the soak, consider using [[talent:115596]] to help out slower party members.
- Use [[talent:115661]] for [[spell:1288092]] when available.
- [[spell:1288864]] puddles linger for a long time so place them nicely to always have space to get knocked back by [[spell:1289062]].

#### Merektha

- Get close to the boss before the end of [[spell:1290031]] so your group has easier time handling them.
- Use a defensive cooldown for each [[spell:1293048]] cast.
- Interrupt [[spell:267027]] during the intermission.

#### Galvazzt

- You should soak a pillar most waves, coordinate your defensives for when your healer has less healing.
- Use [[talent:115661]] for [[spell:1290531]] when available.

#### Avatar of Sethraliss

- When targeted by [[spell:1302153]] it spawns a puddle as it expires so considering your positioning.
- Rotate [[spell:363916]] and [[spell:374227]] when soaking [[spell:1300869]]
- Interrupt **Twisted Hexxers**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
    
    - You can dispel this with [[talent:115602]] when needed.
  - [[spell:1308148]] from **Poisonous Viper**.
    
    - You can dispel this with [[spell:365585]].

:::

:::

### Affixes

The Affix system had some minor changes going from **The War Within** to **Midnight** but stays largely the same:

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotate on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix 
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  
  
  
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following are some useful tips for handling different Mythic+ Affixes as an **Devastation Evoker**.

- Xal'atath's Bargain: Ascendant
  
  - You can use [[spell:368970]], [[spell:357214]] or [[spell:371032]] (while hitting other targets) on these.
- Xal'atath's Bargain: Voidbound
  
  - Should be focused down as fast as possible, use [[spell:368432]].
- Xal'atath's Bargain: Devour
  
  - Use [[spell:365585]] and [[spell:374251]] to help with this affix as needed.
- Xal'atath's Bargain: Pulsar
  
  - You should be looking to trigger/solve as many of these as possible as you are often free to move around with [[spell:358267]].

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Devastation Evoker**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Devastation Evoker** Mythic+ Stat Priority
```json
{
  "source_code": "JoAJFUAIxQCKBMgABA"
}
```
**智力 ＞ 暴击 ≥ 精通 ＝ 急速 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271501@DiQAAsbBnk7cVrjgC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAsbBE06QQrDj1IoAYFA]] | Ula'tek |
| Shoulder | Catalyst [[item:268231@AgQAAIoAYFA]]  <br>into [[item:271499@DgQAAsbBXk7IoAYF]] | Coiled Altar / Catalyst |
| Cloak | [[item:268253@BgQAAsbBCKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DARAAsbBJk7IoAMWDWB]] | Ula'tek |
| Wrist | [[item:244584@FiQAAsbBYA8ciqDBtO3WzSB]] | Crafting |
| Gloves | [[item:271502@BgQAAsbBCKgTBA]] | Tier / Catalyst |
| Belt | [[item:268254@BiQAAsbBE06IoAOF]] | Vashnik |
| Legs | Catalyst [[item:268237@AgQAAIoAYFA]]  <br>into [[item:271500@DgQAAsbBFo6IoAYF]] | Coiled Altar / Catalyst |
| Boots | [[item:268233@DgQAAsbBpk7IoAOF]] | Sszorak |
| Ring 1 | [[item:268249@DCQAAsbB1j7QQrjTBA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAsbB1j7QQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAsbBCKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:273796@BgQAAsbBCKgTBA]] | Altar of Fangs |
| Weapon | [[item:271092@DgQAAsbB_k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@FgQAAsbB4V2QqK0t1sUA]] | Crafting |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAAsbBCKQQBA]] | King's Rest |
| Cloak | [[item:251132@BgQAAsbBCKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAAsbBCKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAAsbBCKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAsbBCKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250224@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Trinket 2 | [[item:273796@BgQAAsbBCKQQBA]] | Altar of Fangs |
| Weapon | [[item:193761@BgQAAsbBCKQQBA]] | Ruby Life Pools |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]] |
| **A-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270161@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **C-Tier** | [[item:250259@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]] |

### Embellishments

- With your first 4 [[item:274476]] it is recommended to craft [[item:245770@CARAAgBwDAAcbNLF]] as it is very efficient usage of your mythic crests!

- 1x [[item:240167]]
  
  - The optimal slot to craft on is **Wrist**, **Back, Boots** or **Waist** depending on your available gear.

- 1x [[item:273060]]
  
  - Great embellishment if you are using a crafted weapon or off-hand.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore it is not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]]
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] *-- a big burst of healing - upgraded version from 12.1*
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *- You can only have one Eversong Diamond socketed in your gear.*
  
  
  
  - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:275707]]  <br>[[item:244007]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsbB]] |
| Chest | [[item:243977@BAAAAsbB]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:240133@BAAAAsbB]] |
| Boots | [[item:244009@BAAAAsbB]] |
| Ring 1 | [[item:243957@BAAAAsbB]] |
| Ring 2 | [[item:243957@BAAAAsbB]] |
| Weapon | [[item:244031]] |

:::

:::column
:::gear **Devastation Evoker** Enchantments in Mythic+
```json
{
  "source_code": "JQFZ7WQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYgS94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Macros

Discover recommended macros for Devastation Evokers during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:357210]]** -- *Allows you to cast [[spell:357210]] with one button press, aimed at your cursor, instead of first aiming it with the ground template and then activating it.* ***When playing Scalecommander you won't need this anymore because of [[talent:117538]]!***

```wow-macro
#showtooltip 
/cast [@cursor] Deep Breath
```

:::

:::details Mouseover Macros
**[[spell:365585]]** -- *Casts [[spell:365585]] on your mouseover or target.*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Expunge
```

**[[spell:374251]]** -- *Casts [[spell:374251]] on your mouseover target.*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Cauterizing Flame(Red)
```

**[[spell:406732]]** / **[[spell:374968]]** *--* *Casts [[spell:406732]] on your mouseover target or [[spell:374968]]* *depending on your talent choice.*

```wow-macro
#showtooltip [known:Spatial Paradox] Spatial Paradox; Time Spiral
/cast [@mouseover, help, nodead, known:Spatial Paradox] Spatial Paradox
/cast [known:Time Spiral] Time Spiral
```

**[[spell:360995]]** -- *Casts [[spell:360995]] on your mouseover target.*

```wow-macro
#showtooltip 
/cast [@mouseover,help,nodead][] Verdant Embrace
```

:::

:::details Rescue Macros
> These macros make [[spell:370665]] easier to use.

**Cast on Player** [[spell:370665]] Macro -- *This macro makes [[spell:370665]] move your friendly target to your location, requiring you to press the macro button and then mouse-click on your unit frames on the chosen target.*

```wow-macro
#showtooltip
/cast [@player] Rescue
```

**Cast on Cursor [[spell:370665]] Macro** -- *This macro makes [[spell:370665]] move you and your friendly target to your cursor's location, requiring you to first choose the unit, aim with your cursor and then press the macro button.*

```wow-macro
#showtooltip
/cast [@cursor] Rescue
```

:::

:::details Utility Macros
**[[spell:358734]]** -- *Activates or cancels the Evoker double-jump / slow fall ability [[spell:358734]]*, *I recommend keybinding it to mouse scroll wheel down for easy knockback canceling and mobility usage.*

```wow-macro
#showtooltip Glide
/cancelaura Glide
/use Glide
/script UIErrorsFrame:Clear()
```

**[[spell:360995]]**, **[[spell:361469]]** and  **[[spell:355913]]** Self-heal Macros -- *It is also possible to use a self-target key modifier but I recommend keybinding these for easy self-healing without needing to target yourself.*

```wow-macro
#showtooltip 
/cast [@player] Verdant Embrace
```

```wow-macro
#showtooltip 
/cast [@player] Living Flame
```

```wow-macro
#showtooltip 
/cast [@player] Emerald Blossom
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Devastation Evoker**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Devastation Evoker Interface in Mythic+](<https://assets-ng.maxroll.gg/wordpress/DevastationDungeonMidnightUI-1024x617.webp>)

**Devastation Evoker** Interface in Mythic+

:::accordion
:::details Addons
- **BetterCooldownManager / BCDM** *--* Cooldown Manager customization
  
  - Provides additional customization to the Cooldown Manager.
- **Unhalted Unit Frames / UUF** *-- Unit frame addon* 
  
  - Adds custom player, target and boss frame customization.
  - Alternatively, you can also use ElvUI
- Plater -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking and threat coloring.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Bartender4** -- Action Bar addon
  
  - Replacement for the default action bars, allowing more customization and extra options.
- **RaidFrameSettings / RFS** -- Blizzard Raid frames customization
  
  - Provides additional customization to the default Blizzard raid frames.
- **NorskenUI** *-- Collection of Skinning, QoL and Features.*
  
  - One of the many "collection" addons available with multiple quality of life improvements, UI skinning and other useful functionalities.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Evoker**

- Panacea healing increased by 25%

**Hero Talents**

- **[[talent:123333]]**
  
  - *Developers’ notes: Wingleader’s cooldown reduction mechanic strongly incentivized spreading Bombardment applications across multiple targets. We feel that this gameplay is unintuitive in isolation, and additionally creates unhealthy behaviors such as Disintegrate clipping and Mass Disintegrate/Eruption pooling. This redesign is intended to retain the multitarget focus of the talent, while addressing those issues. We are increasing some of Scalecommander’s sources of area damage to compensate for the lessened cooldown reduction the new Wingleader will provide.*
  
  
  
  - Wingleader has been redesigned – Mass Disintegrate/Mass Eruption reduces the remaining cooldown of Deep Breath/Breath of Eons by 0.5 seconds/1 second for each target struck.
  - Command Squadron’s Pyre damage increased by 40%.
  - Maneuverability’s damage over time increased by 40%.

**Devastation**

- *Developers' notes: Devastation's Apex talent, while powerful, hasn't been as gameplay-affecting as we had hoped. We've redesigned the Rank 3 effect to override Dragonrage with a limited number of uses of a new, powerful spell, Unbound Flame, once Dragonrage is over. Additionally, Rising Fury and Risen Fury have been streamlined into one buff effect.*
- Apex Talent: Rising Fury (Rank 3) has been redesigned – When Dragonrage ends, Rising Fury persists for 4 seconds per stack, and Dragonrage becomes Unbound Flame. Unbound Flame may be cast 4 times before Dragonrage finishes its cooldown.
  
  - Unbound Flame – Exhale destructive flame, critically striking for Fire damage to your target and nearby enemies. Damage reduced beyond 5 targets. Causes 1 Essence Burst. Instant cast and 25-yard range.
- Tyranny has been updated – Now interacts with Unbound Flame, causing Unbound Flame to always gain the maximum benefit of Mastery: Giantkiller regardless of the targets' health.
- Deep Breath damage increased by 30%.
- Pyre damage increased by 10%.
- Disintegrate damage increased by 40%.
- Living Flame damage increased by 50% and healing increased by 25%.
- Verdant Embrace healing increased by 25%.
- Emerald Blossom healing increased by 25%.
- Shattering Stars that are released from an Eternity Surge due to Scintillation are now subject to Scintillation's 40% effectiveness multiplier.
- Risen Fury has been removed.
- **Hero Talents**
  
  - **[[talent:123336]]**
    
    - Twin Flame damage and healing reduced by 20%.
    - Fixed an issue where Twin Flame was not scaling with Mastery.
  
  
  
  - **[[talent:123333]]**
    
    - Wingleader now reduces the cooldown of Deep Breath by 1 second per target struck (was 0.5 seconds).

:::

:::

:::accordion
:::details Patch 12.0.5
**Evoker**

- New Ability: Battle Visage – Activate to automatically assume your Visage whenever you are not casting draconic spells such as Fire Breath and Soar.
  
  - Full list of abilities that temporarily shift you to Dracthyr: Deep Breath, Dream Flight, Breath of Eons, Fire Breath, Eternity Surge, Dream Breath, Upheaval, Hover, Spatial Paradox, Rescue, Zephyr, Verdant Embrace (without Dream Simulacrum talented), and Soar.
  - Many abilities that used to force a shift to Dracthyr have adjusted visual treatments for Visage form.
  - While active, Battle Visage also applies a camera height override to Dracthyr form to prevent the camera from adjusting rapidly when shifting between forms.
- Unravel damage increased by 300%.
- Blessing of the Bronze is now castable on friendly players who are not in your party or raid group, similar to other group buffs like Arcane Intellect.
- Fixed an issue where Twin Guardian was applying its bonus at the start of Rescue rather than upon landing.

:::

:::

:::accordion
:::details Patch 12.0.1
**Evoker**

- [[spell:357208]] total damage, instant and periodic, should now be consistent at all Empower ranks, with all combinations of Fire Breath-affecting talents.
- [[talent:115663]] healing increased by 60%.
- **Devastation**
  
  - [[spell:356995]] damage increased by 32%.
  
  
  
  - [[talent:115655]] healing increased by 50%.
  - [[spell:355913]] healing increased by 50%.

- **Hero Talents**
  
  - **[[talent:123336]]**
    
    - [[talent:117519@AJQD]] now deals [[spell:357208]] damage at 115% effectiveness (was 150%).
    - [[talent:117519@AJQD]] now causes Pyre to consume 4 seconds of [[spell:357208]] (was 10 seconds) and 1 second of [[spell:357208]] from [[spell:356995]] damage (was 2 seconds).
  
  
  
  - **[[talent:123333]]**
    
    - ***Developers' notes: We're reducing the number of times [[spell:357210]] is available through [[talent:117550@AJQD]] for [[talent:123333]] to lessen the amount of time spent airborne which can be difficult to play. We're offsetting the damage losses with buffs to other [[talent:123333]] talents.***
    - **[[talent:117550@AJQD]] now causes [[talent:117533@AJQD]] to reduce the cooldown of [[spell:357210]] by 0.5 seconds (was 1 second), up to 1.5 seconds (was 3 seconds).**
    - **[[talent:117549]] increases Black spell damage by 30% (was 20%).**
    - **[[talent:136051]] now increases Essence ability damage by 25% (was 15%).**

:::

:::

:::accordion
:::details Patch 12.0
**Evoker**

- **[[talent:123333]]**
  
  - New Talent: [[talent:136053]] – While flying during [[talent:115536@FAQARegB]] or [[spell:357210]] you are assisted by a squadron of Dracthyr who assault enemies with Pyre, dealing Fire damage to nearby enemies up to 8 times.
  - New Talent: [[talent:136052@AJQD]] – [[talent:117536]] or [[talent:122279]] strikes 1 additional target.
  - New Talent: [[talent:136051]] – Essence abilities deal 15% more damage.
  - [[talent:120123]] now grants a charge of [[spell:358267]] instead of granting full charges.
  - **Devastation**
    
    - [[talent:117518@AJQD]] and the damage effect from [[talent:117538@AJQD]] now extends its duration when [[spell:357210]] is cast multiple times while the effect is active.
    - [[spell:356995]] icon now changes while [[talent:117536]] is active.
- **[[talent:123336]]**
  
  - New Talent: [[talent:123416]] – [[spell:357208]] cooldown is reduced by 5 seconds.
  - New Talent: [[talent:117542@AJQD]] – [[spell:357208]] damage over time lasts 4 seconds longer.
  - New Talent: [[talent:136055@AJQDBA]] – [[spell:355936]] and [[spell:357208]] have a 50% chance to generate [[spell:359565]].
  - New Talent: [[talent:136056@AJQD]] – Consuming [[spell:359565]] fires a twin flame, healing or damaging your target for 390% Spell Power.
  - New Talent: [[talent:136054]] – [[talent:136056@AJQD]] bounces to up to 2 additional targets.
  - [[talent:117543@AJQD]] has been redesigned – [[spell:357208]] reaches its maximum empower level 20% faster.
  - The following talents have been removed:
    
    - [[spell:443328]]
    - [[spell:444140]]
    - [[spell:444081]]
  - Devastation
    
    - New Talent: [[talent:117547@AJQD]] – [[spell:357208]] gains an additional charge.
    - [[talent:117519@AJQD]] has been redesigned – [[spell:356995]] damage consumes 2 seconds of [[spell:357208]] from enemies it damages, detonating it for 150% of the amount consumed. [[spell:357211]] consumes 10 seconds of [[spell:357208]] from enemies it damages, detonating it for 150% of the amount consumed.
- Class
  
  - New Talent: [[talent:115617]] – While flying during [[talent:115536@FAQARegB]] or  [[spell:357210]], 100% of damage you would take is instead dealt over 10 seconds.
  - New Talent: [[talent:136560]] – [[spell:358733]] speed and height increased by 10%.
  - New Talent: [[talent:115620]] – Your [[spell:361469]] and [[spell:367979]] are 30% more effective on yourself.
  - [[talent:115595]] has been redesigned – [[talent:115596]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  - [[talent:115669]] has been redesigned – Now upgrades [[talent:115613]], causing it to heal you over 8 seconds equal to the amount of damage it reduced.
  - [[talent:115616]] has been redesigned as a passive effect – [[spell:357208]] consumes absorb shields from enemies, dealing additional Spellfrost damage to them.
  - [[spell:362969]] damage increased by 50%.
  - [[talent:115657]] now changes the icon for [[spell:361469]] while active.
  - Fixed an issue where [[spell:357208]] could engage enemies if the player died and resurrected while it was active.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - [[spell:375577]]
    - [[talent:115645]] *(moved to the Augmentation and Devastation talent trees)*
- Devastation
  
  - New Talent: [[talent:115626]] – Increases [[spell:1265804]] damage by 35%. [[spell:1265804]] are exhaled at all of your [[talent:115581]] targets.
  - New Talent: [[talent:115579]] – [[talent:115581]] upgrades your next [[spell:362969]] to [[talent:115579]], damaging all nearby enemies and dealing 75% additional damage.
  - New Talent: [[talent:115623]] – [[spell:357210]] deals 20% increased damage and can be cast again within 18 seconds of being used. [[talent:115610]] will be available after the second cast if talented. In PvP, [[spell:357210]] damage is instead reduced by 20%.
  - [[spell:370452]] has been redesigned as a passive named [[talent:115627]] – [[talent:115581]] releases a [[spell:1265804]] at your target that deals 50% more damage per empower level reached.
  - [[talent:115641]] has been redesigned – Increases the critical strike chance of your spells by 2%/4%.
  - [[talent:115585]] has been redesigned – Now increases the damage of [[spell:361469]] by 10% and reduces its cast time by 0.3 seconds.
  - [[talent:115638]] has been redesigned – Deep Breath reduces the Essence cost of your next 4 [[spell:356995]] or [[spell:357211]] by 1. Stacks up to 8 times.
  - [[talent:115622]] has been redesigned – Enemies affected by [[spell:357208]] damage over time effect take 25% increased damage from your Red spells.
  - [[talent:115647]] damage increased by 20%.
  - [[talent:115628]] increases the damage of [[spell:357211]] by 2% per stack (was 5%).
  - [[talent:115584]] now activates after casting 6 [[spell:357211]] (was 9).
  - [[spell:369372]] no longer increases the damage of [[spell:356995]] and [[spell:357211]].
  - [[spell:369372]] damage increased by 25%.
  - [[talent:115580]] now also increases the damage of [[spell:362969]].
  - [[talent:115632]] now only affects [[talent:115581]].
  - [[talent:115642]] effect now diminishes by 25% per empower spell cast during [[spell:375087]].
  - [[talent:115645]] is now learned in the Devastation specialization tree (was a class talent).
  - [[talent:136056@AJQD]] is now considered a Red spell.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - [[spell:386342]]
    - [[spell:370962]]
    - [[spell:368847]]
    - [[spell:386336]]
    - [[spell:371016]]
    - [[spell:386405]] *(moved to the class talent tree)*
    - [[spell:370783]]

:::

:::

---

## FAQ

:::accordion
:::details Q: Why do I feel so squishy even though you rated Devastation 4/5 on Survivability?
**A:** You have a vast arsenal of defensive tools but most of them are proactive so you have to anticipate the damage intake and use one of your many available options to mitigate it!

:::

:::

---

### Credits

Written By: **fraggo**

Reviewed by: **Ftm**

---

:::changelog 更新记录
**2026-08-06** Updated for 12.1

**2026-06-16** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-22** Updated for Midnight launch.

**2026-02-10** Updated for patch 12.0.1

**2026-01-15** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-04** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-25** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5

**2024-08-01** Guide Written for patch 11.0



:::
