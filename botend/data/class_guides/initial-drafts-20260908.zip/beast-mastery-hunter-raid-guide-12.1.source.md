Welcome to the **Beast Mastery Hunter** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 2/5 · Weak

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Beast Mastery Hunter** Raid Best in Slot
```json
{
  "source_code": "JwrAo2PA3_PABQIJEIIKBAwJ5OwVtOgNycBN8Vjg1YbNOFQApfBBAESAAQQrDQQCawDZ1wYNYFQACSCBCASAAcRuF8CC-VTgBUBBEYSBVAZC5OgX1wYNYYTOCgVABU2uDQICBAAGAPwJqOgAtOwt1sUABMIJFoCBhubB_wTf1IYNYFQAJfBBCARAAEPuFUBOOFQAot7AECVAAciqDgBwBAIdZJCAjcbN2-CYwsXM2UzY1YbNRDzSBEQhkQAAgEAABgLP7VTg14UABk9FEIIGBAQ94GgNBgBAkFgFQIW2DIIIZYBPeVDZ1kjAOFQAf9BBAgQAAUgrAQVEMgoTBEQ3XQAAQEAAeVDG2gVAB86FEIAGBAQB5OgNycBNMWDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271492]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271490]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:244581]] | [[item:240898]] · [[item:245784]] · [[item:240167]] |
| 腿部 | [[item:271491]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271493]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268207]] | [[item:243973]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Beast Mastery Hunter**, you have access to Nature's Ally.

- **Rank 1**: Gives you [[spell:1273043]].
- **Rank 2**: The first and the second talent point in **Rank 2** increases damage done by your pets by 5% and makes [[spell:19574]] strike 2 additional targets. This means that after spending 2 talent points in **Rank 2** you end up getting 10% increased damage done by your pets and [[spell:19574]] striking 4 additional targets.
- **Rank 3**: Enables [[spell:1273126]], greatly increases the power of [[talent:126408]] if used correctly.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-beastmastery-mxr.webp>)

Nature's Ally

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:19574]]
    
    - **Beast Mastery Hunter's** main cooldown. It no longer gets its cooldown reduced by [[spell:217200]], however it now has a flat 30 seconds cooldown when talented into [[spell:231548]].
  - [[spell:217200]]
    
    - Functionality has changed quite a bit. [[spell:217200]] no longer generates [[spell:272795]]. Additional [[spell:217200]] will now reapply and add to the new  [[spell:217200]], very similar to how [[spell:12654]] works.
  
  
  
  - [[spell:1272099]]
    
    - Is no a longer useable cooldown but instead applies a powerful DoT when you press [[spell:19574]].
  - [[spell:321014]]
    
    - Redesigned, less passive focus regen but more of its generation tied into [[spell:217200]].
- **Class Tree**
  
  - [[spell:257284]]
    
    - Now gives a passive 3% damage increase to its target but is no longer tied to enemy health being > 80%. This makes [[spell:257284]] a really strong raidbuff on single enemies.
  - [[spell:1258509]] 
    
    - New functionallity for [[spell:19577]] wich makes it a short AoE stun.
  - [[spell:472729]]
    
    - Choice node for [[spell:109248]], makes enemies get dragged to binding shot's center on stun. This talent is no longer locked behind [[talent:123347]] since it has been move to the class talent tree.
  - [[spell:272679]]
    
    - Functionality has changed. Instead of being an on use defensive it's now a passive 3% damage reduction.
  - [[spell:53480]]
    
    - Functionality has changed, it's now an external that can be used on any friendly target. It works very similar to how [[spell:6940]] works, but instead of it fading on your own health going low it fades on pet health going below 25%. Choicenode with [[spell:1272094]].

- **Removed**
  
  - [[spell:359844]] 
    
    - This was **Beast Mastery Hunter** major cooldown, a lot of its functionality was moved into [[spell:19574]].
  - [[spell:53351]]
    
    - [[talent:123348]] still gains [[spell:466932]]
  
  
  
  - [[spell:2643]] 
    
    - Basically just replaced with Cast [[spell:1264359]]. A stronger hitting AoE spell but now has a cooldown.
  
  
  
  - [[spell:212431]] 
    
    - This was very rarely used, no major change.
  - [[spell:186387]]
    
    - Removing this lost **Beast Mastery Hunter** one of its few ways to access knockback, this leaves **Beast Mastery Hunter** with no knocks and very limited utility.
  
  
  
  - [[spell:213691]]
    
    - Removing this lost **Beast Mastery Hunter** one of its few utility cooldowns.
  
  
  
  - [[spell:236776]] and [[spell:462031]] 
    
    - Removing this lost **Beast Mastery Hunter** one of its few ways to access knockback, this leaves **Beast Mastery Hunter** with no knocks and very limited utility.

## Hero Talents

- Patch 12.0 brought about some talent and tuning changes for [[talent:123347]] and a partial revamp for the [[talent:123348]] hero tree. [[talent:123348]] and [[talent:123347]] is very close in terms of damage on Single-Target. [[talent:123347]] is a tiny bit ahead on Single-Target while [[talent:123348]] has better defensive power. [[talent:123348]] is currently the stronger of the two in pure AoE Raid senarios.

:::tabs
:::tab [[talent:123348]]
- [[talent:123348]] gains [[spell:466932]] since [[spell:53351]] was removed in 12.0.
  
  - Just like [[spell:53351]] you can only use [[spell:466932]] whenever your target is at a certain HP threshold.
  
  
  
  - Also since Beast Mastery Hunter's gained access to [[spell:343248]] there are mainly two ways to reset [[spell:466932]] cooldown. [[talent:117565@AJwA]] enables your primary rotation spells [[spell:217200]] and [[spell:34026]] to proc [[spell:343248]]
- [[talent:132888@AJwA]] is allowing for [[talent:117584]] periodic dot to be applied to every target hit by [[talent:117571@AJwA]] as well as granting you [[talent:126403]] while talented and hitting 2 or more enemies.
- Your capstone [[talent:117590@AJwA]], gives you a proc of [[spell:343248]]  and fires 2 extra [[spell:466932]] when casted.
  
  - You get [[talent:117590@AJwA]] for 10 seconds after casting [[spell:19574]]
- There is now only a single defensive node in the tree since [[talent:117556]] has been removed in 11.2. [[talent:123779]] still remains.

- [[spell:1264289@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - 10% Chance to summon a Dark Hound instead of a [[spell:120679]]
- [[spell:1264290@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - [[spell:19574]] now also summons a Dark Hound  
    After [[spell:19574]] is used its transformed into [[spell:392060]]
- [[spell:1264291]]
  
  - Fire 2 additional [[spell:466932]] during [[talent:117590@AJwA]] barrage.
  - [[spell:115939]] and [[spell:378207]] damage increased by 10%.
- [[spell:1264690@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - [[spell:34026]] Causes your Dark Hound to Shadow Thrash, dealing AoE damage.

With Patch 12.0, Blizzard removed following Hero talent.

- [[spell:467941@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]

:::

:::tab [[talent:123347]]
- Every 30 seconds gain [[talent:117588]]
  
  - This will summon one of three Beasts 
    
    - The Wyvern will give you up-to 10% increased damage for you and your pet for up to 19 seconds.
    - The Bear will initially leap in and [[spell:471999]] up-to 8 nearby enemies and then auto attack your current target.
    - The Boar will charge your target 1 time dealing a large amount of damage to your primary target and a lesser amount to nearby enemies.
  - Consuming [[talent:117588]] will also increase the damage of your next [[spell:34026]] and reduce the duration of [[spell:217200]] by 6 seconds.
- [[talent:126402]] has had even more power baked into it with [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]] being added.
- New to patch 12.0 [[talent:117559@AJwA]] has been reworked to be a 2% damage buff to pets as well as a 10% increased damage to [[spell:217200]].
- [[talent:117564]] has been updated in 12.0, [[talent:126488]] now summons a Turtle to aid you, further increasing its damage reduction effect by 10%.

- [[spell:1264781]]
  
  - Auto shot/auto attacks grant 2 Focus to you and your pet. Auto shot/auto attack damage increased by 25%
- [[spell:1264774]]
  
  - Mastery is increased by 3%.
- [[spell:1264797]]
  
  - Hogstrider further increases the damage of [[spell:193455]] by 10% and it now stacks up to 3 additional times.
- [[spell:1264792]]
  
  - The damage bonus from your Wyvern now lasts an additional 2 seconds.
- [[spell:472524]]
  
  - The damage of your Bear's [[spell:471999]] is increased by 15%
- [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]]
  
  - Casting [[talent:126402]] grants [[talent:117588]] and causes your next [[spell:34026]] to rouse the nearby wildlife into a Stampede, charging your target and dealing heavy Physical damage over 7 seconds.
- [[spell:1268705]]
  
  - The duration of [[spell:53271]] is increased by 2 seconds and it increases the movement speed of its target by 20%.

With Patch 12.0, Blizzard removed the following Hero talents.

- [[spell:472539]]
- [[spell:472729]]
  
  - Author's Note: Talent moved to class talent tree.
- [[spell:472743]]

:::

:::

## Talents

:::tabs
:::tab [[[talent:123347]]  Single-Target](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>)
:::talents [[talent:123347]] **Beast Mastery Hunter** Single-Target talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### When to use this Spec

Use this spec if you're fighting a singular enemy for an extended period of the fight.

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look, check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:267116]]
  
  - Large single-target and AoE increase since your pet-summon will summon an additional secondary pet, this pet will also cast [[talent:126408]].
- [[talent:126439]]
  
  - Alot of talents weave in to this, buffing the beast to be powerful. [[talent:132188@FAgA8PvA8h4A]] is a must take node because for this as well.
- [[talent:126402@FAQA8h4A]]
  
  - Combined with [[talent:132188@FAgA8PvA8h4A]] and [[talent:117590@AJwA]] for [[talent:123348]] and [[spell:472741@FJACWANAxtSA3chAJunA_zwBA0wB47vEr3yEDA]] for [[talent:123347]] is our only major damage cooldown.

#### Class Tree

- [[talent:126470]]
  
  - A large survivability increase since you gain an extra charge of [[talent:126488]]. This together with [[spell:388039]] will make up for a big majority of your Defensive capabilities.
- [[spell:53480]]
  
  - Give you and external defensive cooldown, choice node with [[spell:1272094]] so it comes with the cost of losing 3% passive damage reduction to take this talent.
- [[spell:459517]]
  
  - Grants [[spell:5384]] and [[spell:186265]] the capability to dispel yourself from Poision and Disease debuffs. Situational but extremely useful to help yourself and your group when helpful.
- [[spell:109248]], [[spell:19577]] and [[spell:19801]] depending on the boss you're fighting. Pick wisely whats needed on every encounter.

:::

:::tab [[talent:123348]] [Single-Target](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>)
:::talents [[talent:123348]] **Beast Mastery Hunter** Single-Target talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azsMwAGwMsBZsAAgZMjZWMDzYmxMMzYYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbAYA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azsMwAGwMsBZsAAgZMjZWMDzYmxMMzYYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbAYA"
}
```
:::

### When to use this Spec

Use this spec if you prefer playing [[talent:123348]] instead of [[talent:123347]].

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Hero Talents

**Changed** [[talent:123347]] to [[talent:123348]] for more info visit the **Hero Talent** section above.

:::

:::tab [[[[talent:123347]]](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>) Situational Cleave](<https://backend.maxroll.gg/wow/embed-tools/talents=C2PAwfFTUTNkWyNfrTAtHLMp0ZzYgBAYYDyYBAAzw2YmtZGmxMDDzMGzMmZmZGzwMzYGzghmBAAAAAMDAAAjZGYmBIgZBsB>)
:::talents [[talent:123347]] **Beast Mastery Hunter** Situational Cleave talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### When to use this Spec

Use this spec if you're fighting 2 or more enemies for short periods of the fight.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[spell:1264359]]
  - [[spell:115939]]
  - [[spell:378207]]
  - [[spell:459552]]
  - [[spell:378209]] x 2
  - [[talent:126413]]

- **Removed**
  
  - [[spell:1265051]]
  - [[spell:385810]] x 2
  - [[spell:459730]]
  - [[spell:1232739]]
  - [[spell:120679]]
  - [[spell:378743]]

:::

:::tab [[talent:123348]] Raid Cleave
:::talents [[talent:123348]] **Beast Mastery Hunter** Cleave talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azsMwAGwMsBZsAAgZGzMziZYGmxMjZmZYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azsMwAGwMsBZsAAgZGzMziZYGmxMjZmZYGzMjZmZYmZMjZwYaGAAAAwMAAAMGzMMzACDzCYbA"
}
```
:::

### When to use this Spec

Use this spec if you're fighting 2 or more enemies for an extended period of the fight.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[spell:1264359]]
  
  
  
  - [[spell:115939]]
  
  
  
  - [[spell:378207]]
  - [[spell:1217524]]

- **Removed**
  
  - [[spell:1265051]] x2
  - [[talent:126418]]
  - [[talent:126400]]

#### Hero Talents

**Changed** [[talent:123347]] to [[talent:123348]] for more info visit the **Hero Talent** section above.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:126440]] causes your pets to [[spell:201754]] one additional time at 50% effectiveness.
- **4-Set:** [[spell:201754]] causes your next  [[spell:193455]] to either benefit from [[spell:115939]] at 20% effectiveness, or strike your primary target for 15% additional damage, stacking up to 4 times

### Single-Target

:::tabs
:::tab [[talent:123347]]
### Opener

- The goal of your opener is to simply cast as many [[talent:126408]] as possible. Since Focus management will be an issue you will also weave in some [[talent:126440]].
- Note that before every pull you want to mare sure to use [[spell:257284]] on the priority target/boss and to [[spell:34477]] prefered tank!

:::rotation **Beast Mastery Hunter** Single-Target opener in Raids
```json
{
  "source_code": "IcFTHIEcQNAAAcwbuBCc1xGbAIk6ECQABkwFsAwACxFUAAAABwprDEgFAFwXfQQAIEAA9DQOCgVACZHTBUBCAIk6yQDAMAgQqTI"
}
```
1. [[spell:217200]] on pull
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:19574]]
5. [[spell:34026]]
6. [[spell:217200]]
7. [[spell:34026]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] before using [[talent:126402@FAgA8PvA8h4A]].
- Make sure to NEVER cap on [[talent:126408]] and [[talent:126440]], plan around this and make sure to have [[spell:1273126]] for every [[talent:126408]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:19574]].
2. Cast [[talent:126408]] if [[spell:1273126]] is active.
3. Cast [[talent:126440]].
4. Cast [[spell:193455]].

:::

:::tab [[talent:123348]]
### Opener

- The goal of your opener is to simply cast as many [[talent:117584]] and [[talent:126408]] as possible while still maintaining [[spell:1273126]].
- Note that before every pull you want to mare sure to use [[spell:257284]] on the priority target/boss and to [[spell:34477]] prefered tank!

:::rotation **Beast Mastery Hunter** Single-Target opener in Raids
```json
{
  "source_code": "IcZAMxgQy_xBAAwBv5GIwVHbsBgQqTIABEAQCBHUDAAAAMgQcBFAAAQAc6aAOwDAB81HEAACBAQOCgVACZHTBkSGyAg8BkUHQkgQ-ACAYA4ACx3-FAQAp4TMAgi6ECAAAAAACx3-FA"
}
```
1. [[spell:466930]] on pull
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:19574]]
5. [[spell:34026]]
6. [[spell:466930]]
7. [[spell:34026]]
8. [[spell:217200]]
9. [[spell:34026]]
10. [[spell:466930]]  
    
    1. [[spell:392060]]
    2. [[spell:466930]]
    3. [[spell:34026]]
11. [[spell:34026]]
12. [[spell:392060]]
:::

- Use your active trinkets, [[item:241308]] and racials like [[spell:20572]] or [[spell:26297]] before using [[talent:126402@FAgA8PvA8h4A]].
- Make sure to NEVER cap on [[talent:126408]] and [[talent:126440]], plan around this and make sure to have [[spell:1273126]] for every [[talent:126408]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:19574]]. (Make sure to spend all [[spell:466930]] before)
2. Cast [[spell:466930]] in [[talent:117590@AJwA]] window.
3. Cast [[talent:126408]] if [[spell:1273126]] is active.
4. Cast [[spell:392060]]. Make sure to use this before it times out.
5. Cast [[spell:466930]].
6. Cast [[talent:126440]].
7. Cast [[spell:193455]].

:::

:::

### AoE

:::tabs
:::tab [[talent:123347]]
### Opener

- Note that most Raid encounters are Single-Target on pull, this is only for scenarios with multiple targets. Make sure to use the Single-Target openers when there is only one enemy.
- The goal of your opener is to simply cast as many [[talent:126408]] as possible. Since Focus management will be an issue you will also weave in some [[talent:126440]].
- Note that before every pull you want to mare sure to use [[spell:257284]] on the priority target/boss and to [[spell:34477]] prefered tank!

:::rotation **Beast Mastery Hunter** AoE opener in Raids
```json
{
  "source_code": "JcHiLIEcQNAAAcwbuBCc1xGbAI05KNBAAAwACxFUAAAABwprDAQAIA0XfQQAIEAA9DQOCgVACZHTAEQAIIk6EGwBAAQCDBAAmBBAE968CAAAAAgQnr0EAAAAAIk6EC"
}
```
1. [[spell:217200]] on pull
2. [[spell:1264359]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
3. [[spell:19574]]
4. [[spell:34026]]
5. [[spell:217200]]
6. [[spell:34026]]
7. [[spell:217200]]
8. [[spell:34026]]
9. [[spell:193455]]
10. [[spell:1264359]]
11. [[spell:34026]]
:::

- Use your active trinkets, [[item:241308]], and racials like [[spell:20572]] or [[spell:26297]] before using [[talent:126402]].
- Make sure to NEVER cap on [[talent:126408]] and [[talent:126440]], plan around this and make sure to have [[spell:1273126]] for every [[talent:126408]].

### Priority List

1. Cast [[spell:19574]].
2. Cast [[spell:1264359]].
3. Cast [[talent:126408]] if [[spell:1273126]] is active.
4. Cast [[talent:126440]].
5. Cast [[spell:193455]].

:::

:::tab [[talent:123348]]
### Opener

- Note that most Raid encounters are Single-Target on pull, this is only for scenarios with multiple targets. Make sure to use the Single-Target openers when there is only one enemy.
- The goal of your opener is to simply cast as many [[talent:117584]] and [[talent:126408]] as possible while still maintaining [[spell:1273126]].
- Note that before every pull you want to mare sure to use [[spell:257284]] on the priority target/boss and to [[spell:34477]] prefered tank!

:::rotation **Beast Mastery Hunter** AoE opener in Raids
```json
{
  "source_code": "I8aAM5gQy_xBAAwBv5GIwVHbsBgQqTIABEAQCBHUDAAAAMgQcBFAAAQAc6aAOAEAB81HEAACBAQOCgVACduSTUgKEYHTBcQG6Ag8BEVHQkgS-ACAYAIBCx3-FAQAp4TMAERWAoeDLiy5KNBAAAAACx3-FA"
}
```
1. [[spell:466930]] on pull
2. [[spell:34026]]
3. [[spell:217200]]  [[spell:20572]] · [[item:241308]] · [[item:270175]]
4. [[spell:1264359]]
5. [[spell:19574]]
6. [[spell:34026]]
7. [[spell:466930]]
8. [[spell:34026]]
9. [[spell:217200]]
10. [[spell:34026]]
11. [[spell:466930]]  
    
    1. [[spell:392060]]
    2. [[spell:466930]]
    3. [[spell:34026]]
    4. [[spell:1264359]]
12. [[spell:34026]]
13. [[spell:1264359]]
14. [[spell:392060]]
:::

- Use your active trinkets, [[item:241308]]], and racials like [[spell:20572]] or [[spell:26297]] before using [[talent:126402]].
- Make sure to NEVER cap on [[talent:126408]] and [[talent:126440]], plan around this and make sure to have [[spell:1273126]] for every [[talent:126408]].

### Priority List

1. Cast [[talent:117584]] if  [[spell:115939]] is about to fall off to maximize value from [[talent:132888@AJwA]].
2. Cast [[spell:19574]].
3. Cast [[spell:1264359]].
4. Cast [[spell:466930]] in [[talent:117590@AJwA]] window.
5. Cast [[talent:126408]] if [[spell:1273126]] is active.
6. Cast [[talent:126440]].
7. Cast [[spell:466930]].
8. Cast [[spell:392060]]. Make sure to use this before it times out.
9. Cast [[spell:193455]].

:::

:::

## Deep Dive

### Maximizing your damage output during Bestial Wrath

- Ensure you are going into [[spell:19574]] with at least 1 charge of [[talent:126408]], but having 2 is best.
- Make sure you don't focus starve yourself by weaving in [[talent:126440]] during this window and not letting it over-cap on charges.
- Try to line this damage window up with either of the buffs provided by [[talent:126411]]. These are quite large and [[talent:126402]] windows are further buffed by these.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Beast Mastery Hunter** Nek'Zali talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

- Utilize [[talent:135711]], [[talent:128412@FAQANQzE]] and [[talent:126457]] to make sure the **Restless Amani** do not reach the middle.
- Make sure to use a defensive when targeted by [[spell:1287426]] and move away from the group to be dispelled near the edges of the room.
- Make sure to have [[spell:257284]] up on the boss.

:::

:::tab Entombed Sentinels
:::talents **Beast Mastery Hunter** Entombed Sentinels talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### Boss Tips

- When on the side with **Breath of Ula'tek**, swap to the **Venom Coagulation** as soon as it spawns.
- Make sure to soak [[spell:1288232]] when on the side with **Blood of Ula'tek**.

:::

:::tab Lost Explorers
:::talents **Beast Mastery Hunter** Lost Explorers talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

- If you pick up the **Disgusting Fish** make sure to use it on one of the turtles who has not been affected by the fish before.
- Use a defensive if you are going to soak many crates spawned by **Trader Gebbo's** [[spell:1291933]].
- Interrupt **Scrollsage Iku's** [[spell:1286921]].
- If you are the only Hunter, just make sure to have [[spell:257284]] up on the one of the bosses
  
  - With two or more Hunters, decide one who keeps it on what boss.

:::

:::tab Vashnik
:::talents **Beast Mastery Hunter** Vashnik talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### Boss Tips

- Make sure to kill the three types of adds boss spawns: **Clotting Venom, Shrouded Venom and Burning Venom**. It is important to not let them reach the middle of the room, you can use [[talent:128412]] and [[talent:135711]] on all but **Clotting Venom**. Be careful to not kill the Burning Venom adds in quick succession to not overlap the [[spell:1285979]] explosions.
- Try to not hit your allies when debuffed by [[spell:1281907]].
- If you are the only Hunter, prioritize having [[spell:257284]] up on the **Concentrated Void** add that your team is currently killing until both are dealt with, otherwise keep it on the boss.
  
  - With two or more Hunters, decide one who always keeps it on the boss and one who puts it on adds.

:::

:::tab Sszorak
:::talents **Beast Mastery Hunter** Sszorak talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### Boss Tips

- If you are caught away from your raid when debuffed by [[spell:1285419]] and can't connect with another player you can use [[spell:781]] to not fly off the platform.
- Use a defensive when afflicted with [[spell:1305959]] and place the [[spell:1287008]] away from the raid.
- When talented into [[talent:126452]] you can use [[spell:5384]] to dispel [[spell:1287072]] from yourself.
- If you are the only Hunter, make sure to have [[spell:257284]] on the boss.

:::

:::tab Twin Fangs
:::talents **Beast Mastery Hunter** Twin Fangs talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMegZmZZmhZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMegZmZZmhZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

### Boss Tips

- Soak [[spell:1289993]] but make sure to not soak too many to not die from [[spell:1290336]].
- Kill the **Spawn of Vexhul** as quickly as possible.
- Soak [[spell:1290516]] to get rid of [[spell:1290336]] stacks.
  
  - If you are three or more Hunters, you all just cover one target each.

:::

:::tab Coiled Altar
:::talents **Beast Mastery Hunter** Coiled Altar talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMMmZ5BmhZMzYGmZMmZMzMmZmhZmxMmBjpZAAAAAzAAAwYMzwMzMbEGmFw2AwA"
}
```
:::

Soak [[spell:1283489]], you can use [[spell:781]] to quickly position yourself again after but be careful of [[spell:1282403]] in your path.  
When talented into [[talent:126452]] you can use [[spell:5384]] to dispel [[spell:1282287]] from yourself.  
Interrupt [[spell:1286399]] from **Spiteful Coulcoiler** and kill them.  
Be careful to avoid the **Manifestations of Dread** which are fixating you.   
Pick up your **Soul Fragments** to get rid of the [[spell:1286837]] after being hit by [[spell:1310882]].

:::

:::tab Ula'tek
:::talents **Beast Mastery Hunter** Ula'tek talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

### Boss Tips

- Since this boss was not tested it's tips will be added after the RWF.

:::

:::tab Nymrissa Wavecaller
:::talents **Beast Mastery Hunter** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "C2PAe4d-yQ5lSoc6yFim_XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw",
  "code": "C2PAe4d+yQ5lSoc6yFim/XEz3azYGzMDLwGmZ2M0M2AAwMmZmZxMmZmZGzMYmxMDzMmZmhZmxMmBjpZAAAAAAAAwYMzwMzMbEGmFw2Aw"
}
```
:::

Kill the murloc adds which spawn from the edges of the arena. You can use [[talent:128412]], [[talent:135711]] and [[talent:126457]] to make sure they do not reach the middle.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Beast Mastery Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Beast Mastery Hunter** Stat Priorities in Raid
```json
{
  "source_code": "IoAJFMQMgQCKEEgAEA"
}
```
**敏捷 ≫ 精通 ＞ 暴击 ＝ 急速 ≫ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is an awful tertiary for you since most of your damage is coming from your pets.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
In patch 12.1 when you catalyst an item it will keep its stats and cantrip effects which means you can have the perfect stats on your tier set slots. You should keep using the tier pieces you get from tier tokens until you have enough ‍[[item:274707]] charges to catalyst the items with better stats.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271492@DiSAA0PAnk7cVrjNycBN8Vjg1YbNOFA]] | The Twin Fangs / Catalyst |
| Neck | [[item:268265@BESAA0PAE06QQrjNycBNkVDj1gVA]] | Ula'tek |
| Shoulder | [[item:271490@DASAA0PAXk7YjMXQjf1EYNYF]] | The Lost Explorers / Catalyst |
| Cloak | [[item:268253@BARAA0PAeVDG2gVA]] | The Coiled Altar |
| Chest | [[item:271876@DASAA0PAJk74VNMWDG2kjAYF]] | Ula'tek |
| Wrist | [[item:244584@FCVAA0PAno6gBwDBtOZJCAjcbN2-CYwsXM2UzY1YbNRDzSB]] | Crafted |
| Gloves | [[item:271493@BASAA0PA2IzF0sXNBWjTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:244581@FiQAA0PAYA8ciqjAtO3WzSB]] | Crafted |
| Legs | [[item:271491@DASAA0PAhu7YjMXQTf1IYNYF]] | Sszorak / Catalyst |
| Boots | [[item:268233@DARAA0PAxj7YjMXQjTB]] | Sszorak |
| Ring 1 | [[item:249920@DkQAA0PA3j7IQrjAtOCKQIB]] | Vashnik The Malignant |
| Ring 2 | [[item:252258@DCSAA0PA1j7QQrjNy4VNkVTOC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270175@BgQAA0PA5IAWBA]] | Ula'tek |
| Trinket 2 | [[item:270164@BgQAA0PA5IgTBA]] | The Lost Exploreres |
| Weapon | [[item:268207@DgRAA0PAFk7YjMXQDj1gVA]] | Ula'tek |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251220@BgQAA0PACKQQBA]] | Voidscar Arena |
| Neck | [[item:251142@AgQAAIoABFA]] | Murder Row |
| Shoulder | [[item:239049@AgQAAIoABFA]] | Kings' Rest |
| Cloak | [[item:251190@AgQAAIoABFA]] | The Blinding Vale |
| Chest | [[item:273789@BgQAA0PACKQQBA]] | Altar of Fangs |
| Wrist | [[item:251200@BgQAA0PACKQQBA]] | The Blinding Vale |
| Gloves | [[item:160213@BgQAA0PACKQQBA]] | Kings' Rest |
| Belt | [[item:251228@BgQAA0PACKQQBA]] | Voidscar Arena |
| Legs | [[item:159375@BgQAA0PACKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAA0PACKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:252258@BgQAA0PACKQQBA]] | Voidscar Arena |
| Ring 2 | [[item:273792@BgQAA0PACKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:273796@BgQAA0PACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAA0PACKQQBA]] | Murder Row |
| Weapon | [[item:273784@BgQAA0PACKQQBA]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.. Do note that some trinkets are better than others depending on each boss fight.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAA0PA5IAWBA]]  <br>[[item:270164@BgQAA0PA5IgTBA]]  <br>[[item:270173@BgQAA0PA5IgTBA]] |
| **A-Tier** | [[item:270165@BgQAA8PACKgTBA]]  <br>[[item:273796@BgQAA8PACKgTBA]]  <br>[[item:250215@BgQAA8PACKgTBA]]  <br>[[item:159617@BgQAA8PACKgTBA]] |
| **B-Tier** | [[item:246304@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:273797@BgQAA8PACKgTBA]]  <br>[[item:250228@BgQAA8PACKgTBA]]  <br>[[item:193757@BgQAA8PACKgTBA]] *--* *Make sure to upgrade it after needs*  <br>[[item:270166@BgQAA8PACKgTBA]]  <br>[[item:274493@BgQAA8PACKQQBA]] -- Can't get higher than Hero track |
| C-Tier | [[item:251787@BAQAA8PAUEA]] *-- Fears you after the effect ends, make sure to let your healers know you will need a dispel*  <br>[[item:250225@BgQAA8PACKgTBA]]  <br>[[item:248583@BgQAA8PACKAFBA]] *-- Can't get higher than Hero track*  <br>[[item:251783@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:251792@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:265657@BgQAA8PACKAFBA]] *-- Can't get higher than Hero track*  <br>[[item:246307@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:250214@BgQAA8PACKgTBA]] *-- Need to stand in the light beam to gain maximum value*  <br>[[item:270168@BgQAA8PACKAWBA]] -- Situationally can be good for big on demand damage |
| Junkyard | [[item:250259@BgQAA8PACKgTBA]]  <br>[[item:274496@BgQAA8PACKQQBA]]  <br>[[item:274497@BgQAA8PACKQQBA]]  <br>[[item:158374@BgQAA8PACKgTBA]]  <br>[[item:246306@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:246305@BgQAA8PAi8SHBA]] *-- Takes up an embellishment slot*   <br>[[item:241340@BgQAA8PAi8SHBA]]  <br>[[item:251782@BAwAA8PAUEQBAEgNXIA]] *-- Can't get higher than Hero track*  <br>[[item:251785@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:251784@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:251790@BAQAA8PAUEA]] *-- Can't get higher than Hero track*  <br>[[item:252957@BgQAA8PACKAFBA]] *-- Can't get higher than Hero track* |

### Embellishments

- [[item:240167]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.
  - Early on in progression it can even in some cases be valuable to craft this on a high value stat piece like head/chest.
- [[spell:1230076]] Can be very valuable for early progression.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:245933]] *-- maximum DPS.*
  
  
  
  - [[item:245926]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:242272]]
  
  
  
  - [[item:255845]]
- **Weapon Oil**
  
  - [[item:243734]] *-- default*
  
  
  
  - [[item:243738]]
- **Combat Potion**
  
  - [[item:241308]] *-- default*
  - [[item:241288]] -- situational, sim it if you think it's close
- Health Potion
  
  - [[item:271884]] -- a big burst of healing
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- Unique
  
  
  
  - If you are short of Mastery, stack these.
    
    - [[item:240896]]
  
  
  
  - Else use a combination of these gems.
    
    - [[item:240892]]
    - [[item:240898]]
    - [[item:240908]]
    - [[item:240918]]

### Enchantments

:::columns
:::column
:::columns
:::column
| Head | [[item:275707]]  <br>[[item:244007@DAAAA0PAZbAB]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAA0P]] |
| Chest | [[item:243977@BAAAA0P]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:244641@BAAAA0P]] |
| Boots | [[item:243953@BAAAA0P]] |
| Ring 1 | [[item:243957@BAAAA0P]] |
| Ring 2 | [[item:243957@BAAAA0P]] |
| Weapon | [[item:243973@BAAAA0P]] |

:::

:::

:::

:::column
:::gear **Beast Mastery Hunter** Enchantments in Raids
```json
{
  "source_code": "IQFZ9DQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NABK1j7AAAAAAEQB5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Beast Mastery Hunter** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial
  - Reduce the duration of movement-impairing effects by 20%. This was only useful once in the recent history of progression raiding but is still worth something.
- [[spell:33702]] *-- Orc* 
  
  - Strong racial for damage because of both [[spell:21563]] and [[spell:33702]] which lines up with [[talent:126397]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.
- [[spell:274738]] -- Mag'Har Orc
  
  - Strong damage racial that lines up well with [[talent:126397]] or every other [[spell:321530]].

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial, which in Hunter's case would be Pandaren,Mechagnome(Scales with fight time, since it needs time to reach max effect) and Orc. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in one of the latest Race to World Firsts by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Beast Mastery Hunter** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
[[talent:135711]]**[[talent:126449]]** -- *Casts [[talent:135711]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Binding Shot
```

**[[talent:126457]]** - *Uses [[talent:126457]] on your cursor position without confirmation.*

```wow-macro
#showtooltip Tar Trap
/cast [@cursor] Tar Trap
```

:::

:::details Mouseover Macros
**[[spell:217200]]** -- *Casts [[talent:126440]] on your mouseover or target.*

```wow-macro
#showtooltip
/cast [@mouseover] Barbed Shot
```

**[[spell:19801]]t]** -- *Casts [[spell:19801]] on your mouseover target.*

```wow-macro
#showtooltip
/cast [@mouseover] Tranquilizing Shot
```

**[[talent:126471]]** -- *Casts [[talent:126471]]* *on your mouseover target*.

```wow-macro
#showtooltip
/cast [@mouseover] Concussive Shot
```

:::

:::details Pet Macros
> We're mainly using custom macros for Pets because pets don't cast their own abilities reliably enough and doing it yourself is a DPS gain.

**[[talent:126408]]** **pet attack** -- *Casts [[talent:126408]] and your pets basic attack at your target.*

```wow-macro
#showtooltip Kill Command
/petattack
/cast Kill Command
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[spell:1264359]]** **pet attack** -- *Casts [[spell:1264359]]* *and your pets basic attack at your target.*

```wow-macro
#showtooltip Wild Thrash
/petattack
/cast Wild Thrash
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[talent:126440]]** **pet attack** *-- Casts [[talent:126440]]* *and your pets basic attack at your target.*

```wow-macro
#showtooltip Barbed Shot
/petattack
/cast Barbed Shot
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

**[[spell:193455]]** **pet attack** -- *Casts [[spell:193455]]* *and your pets basic attack at your target.*

```wow-macro
#showtooltip Cobra Shot
/cast Cobra Shot
/cast [@pettarget]Claw
/cast [@pettarget]Bite
/cast [@pettarget]Smack
```

:::

:::details Utility Macros
**[[talent:126352]] focus** -- *Casts [[talent:126352]] at your focus target or your current target if your focus target doesn't exist.*

```wow-macro
#showtooltip Counter Shot
/cast [@focus,exists,harm,nodead][] Counter Shot
```

**[[spell:186265]]** cancelaura -- *Casts [[spell:186265]] and allows you to immediately cancel it upon pressing it again.*

```wow-macro
#showtooltip
/cast Aspect of the Turtle
/cancelaura Aspect of the Turtle
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Beast Mastery Hunter**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Maxroll-2-1024x618.jpg>)

**Beast Mastery Hunter** Interface in Raids

:::accordion
:::details Addons
- **RaidframeSettings** -- Party/Raidframe enhancement
  
  - Adds extra customization to your default party and raidframes.
- **Unhalted Unit Frames *-- User Interface replacement*** 
  
  - **Adds custom Player,Target and Bossframes with more customization.**
- **BetterCooldownManager** -- CooldownManager enhancement
  
  - Adds extra customization to your cooldownmanager while also providing additional information like resources etc.
- **BigWigs *-- Generic Boss Mod***  
  
  - **BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.**
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for custom scripting.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Hunter
  
  - Hero Talents
    
    - **[[talent:123348]]**
      
      - **Bleak Arrows damage increased by 300%.**
      
      
      
      - **Withering Fire's Black Arrow damage reduced by 40%.**
      - **Fixed an issue where Through The Eyes was not properly increasing Withering Fire's damage.**
  
  
  
  - **Beast Mastery** ***Developers' notes: Beast Mastery Hunters felt a bit weak outside of Bestial Wrath damage windows, so we're increasing their steady-state damage by boosting Kill Command, Cobra Shot, and Barbed Shot. We're increasing the duration of Beast Cleave to 10 seconds, so you should be able to maintain 100% uptime in area damage situations as long as you are using Wild Thrash when it is available.***
    
    - **Heart of the Pack renamed to Razor Sharp and has been redesigned – Increases the damage of your pet's Bite, Claw, and Smack by 100%.**
    - **Piercing Fangs has been redesigned – Kill Command critical damage increased by 15%.**
    - **Bloody Frenzy has been updated – Now reduces Barbed Shot's periodic rate increase by 33% (was 50%).**
    - **Kill Cleave has been updated – Kill Command now only cleaves 20% of its damage during Beast Cleave (was 40%).**
    - **Auto Shot damage increased by 720%.**
    - **Barbed Shot damage increased by 10%.**
    - **Kill Command damage increased by 20%.**
    - **Cobra Shot damage increased by 25%.**
    - **Beast Cleave now causes your pets to strike nearby enemies for 55% of the damage dealt (was 40%).**
    - **Beast Cleave duration increased to 10 seconds (was 8 seconds) and can no longer be cancelled.**
    - **Serpentine Strikes now increases Cobra Shot’s critical strike damage by 20% (was 50%).**
    - **Cobra Senses now increases Cobra Shot’s damage by 10% (was 35%).**
    - **Dire Beast summons can now be tracked on the Cooldown Manager.**
    - **Wild Instincts has been removed.**
    - **Hero Talents:**
      
      - **[[talent:123348]]**
        
        - **Dark Hound summons can now be tracked on the Cooldown Manager.**
      - **[[talent:123347]]**
        
        - **Hogstrider now increases the damage of your next Cobra Shot by 100% (was 200%).**
        - **Hoof and Blade now increases the bonus Cobra Shot damage from Hogstrider by 25% (was 50%).**

:::

:::details Patch 12.0.1
- Hunter
  
  - Hero Talents
    
    - **[[talent:123348]]**
      
      - Shadow Thrash now deals Shadow damage, but its damage has been reduced by 30%.
      - Blighted Quiver now increases Beast Cleave and Kill Cleave effectiveness by 5% (was 10%).
    - **[[talent:123347]]**
      
      - Boar area damage increased by 200%.
      - Pack Mentality now grants 4 seconds of cooldown reduction to Barbed Shot (was 6 seconds) and increases Kill Command’s damage by 25% (was 50%).
    - Beast Mastery
      
      - All damage dealt by the hunter and their pets reduced by 12%.
      - Apex Talent: Nature’s Ally now increases the damage of Cobra Shot and Barbed Shot by 15% (was 30%).

:::

:::

:::accordion
:::details Patch 12.0
- Hunter
  
  - Hero Talents
    
    - **[[talent:123348]]**
      
      - New Talent: Corpsecaller - When summoning a Dire Beast, you have a 10% chance to instead summon a Dark Hound.
      - New Talent: Wailing Dead - Bestial Wrath summons a Dark Hound. For 15 seconds after casting Beastial Wrath, Bestial Wrath is replaced with Wailing Arrow.  
        Wailing Arrow: Fire an enchanted arrow, dealing Shadow damage to your target and additional Shadow damage to all enemies within 8 yards of your target. Non-Player targets struck by a Wailing Arrow have their spellcasting interrupted and are silenced for 1 second. Grants Deathblow.
      - New Talent: Blighted Quiver - You fire 2 additional Black Arrows during Withering Fire's barrage. Beast Cleave and Kill Cleave damage increased by 10%.
      - New Talent: Pact of the Hollow - Kill Command causes your Dark Hound to Shadow Thrash, dealing moderate Shadow damage to up to 8 nearby enemies.
      - Black Arrow has been updated – Periodic damage increased substantially and is no longer a rolling periodic.
      - Soul Drinker has been updated – Now causes Kill Command and Barbed Shot to have a chance to grant Deathblow. Now causes Aimed Shot and Rapid Fire to have an increased chance to grant Deathblow.
      - Bleak Arrows has been updated – No longer has a chance to grant Deathblow. Now increases auto shot damage by 100%.
      - Banshee's Mark has been updated – Now increases the critical strike damage of Bleak Powder and Black Arrow by 10%.
      - The Bell Tolls has been updated – Now increases pet damage by 6% and Dire Beast damage by 10%.
      - Through the Eyes has been updated – Now causes Black Arrow to deal 20% increased damage to enemies affected by Black Arrow's periodic damage.
      - Withering Fire has been updated – Now activates from Bestial Wrath and no longer periodically grants Deathblow. Duration reduced to 10 seconds.
      - Black Arrow now grants the Black Arrow ability and no longer replaces Kill Shot.
      - The following talents have been removed:
        
        - Phantom Pain
    - **[[talent:123347]]**
      
      - New Talent: Lethal Barbs – Your auto shot/auto attacks grant 2 Focus to you and your pet. Auto shot/auto attack damage increased by 25%.
      - New Talent: Sharpened Fangs – Your Mastery is increased by 3%.
      - New Talent: Hoof and Blade – Hogstrider further increases the damage of Cobra Shot by 10% and it now stacks up to 3 additional times.
      - New Talent: Wyvern's Gaze – The damage bonus from your Wyvern now lasts an additional 2 seconds.
      - New Talent: Sharpened Claws – The damage of your Bear's Rend Flesh is increased by 15%.
      - New Talent: Stampede! – Casting Bestial Wrath grants Howl of the Pack Leader and causes your next Kill Command to rouse the nearby wildlife into a Stampede, charging your target and dealing heavy Physical damage over 7 seconds.
      - New Talent: Masterful Call – The duration of Master's Call is increased by 2 seconds and it increases the movement speed of its target by 20%.
      - Pack Mentality has been updated –  Barbed Shot cooldown reduction reduced to 6 seconds (was 10 seconds).
      - Hogstrider has been updated – Now grants Cobra Shot a 200% damage increase regardless of the number of targets struck by your Boar. Number of targets struck by the Boar now increases the number additional targets struck by Cobra Shot.
      - Ursine Fury has been updated – When your Bear is summoned, it is joined by 2 Dire Beasts.
      - No Mercy has been updated – Your Bleed effects deal 10% increased damage.
      - Shell Cover has been updated – Survival of the Fittest now summons a Turtle to aid you, further increasing its damage reduction effect by 10%.
      - Howl of the Pack Leader has been updated –Boar now charges once per summon (was 3 times). Boar charge primary and secondary target damage increased by 300%.
      - Bear base damage and stat scalings reduced by 40%.
      - Wyvern's Cry no longer gets bonus initial stacks when applied (was granting a starting point of 15 stacks).
      - Wyvern's Cry now stacks to a maximum of 10 (was 25).
      - Wyvern's Cry duration reduced to 12 seconds (was 15 seconds).
      - Better Together has been updated – Now increases pet damage by 2% (was 5%) and increases Barbed Shot damage by 10% (was 20%).
      - Fury of the Wyvern duration extension reduced to 0.5 seconds and extension cap reduced to 5 seconds.
      - The following talents have been removed:
        
        - Envenomed Fangs
        - Horsehair Tether (moved to Class talent tree)
        - Lead from the Front
    - Class
      
      - New Talent: Precision Strikes – Auto attack and auto shot damage increased by 25%.
      - New Talent: Moment of Opportunity – When a trap triggers, gain 30% movement speed for 3 seconds.
      - New Talent: Shell Wall – Damage taken during Aspect of the Turtle is reduced by an additional 20%.
      - New Talent: Cold Feet – When your Freezing Trap breaks, the victim's movement speed is reduced by 70% for 4 seconds.
      - New Talent: Combat Experience – Agility increased by 3%.
      - New Talent: Improved Snaring – Wing Clip slows an additional 25%. Concussive Shot slows an additional 10%.
      - New Talent: Horsehair Tether – When an enemy is stunned by Binding Shot, it is dragged to Binding Shot's center.
      - New Talent: Roar of Sacrifice – Instructs your pet to protect a friendly target, reducing their damage taken by 15%, but 50% of all damage taken by that target is transferred to your pet. Lasts 10 seconds or until your pet's health drops below 25%.
      - New Talent: Guardian's Hide – Your pet protects you at all times, reducing the damage you take by 3%. Your pet receives 100% of the damage it mitigates.
      - Hunter's Mark has been updated – Now increases the target's damage taken by 3% (was 5% above 80% health).
      - Fortitude of the Bear has been updated – Now passive. Reduces all damage taken by 3%.
      - Lone Survivor has been updated – Now increases Survival of the Fittest's duration by 2 seconds (was 4 seconds).
    - Beast Mastery
      
      - New Talent: The Beast Within – Reduces the cooldown of Bestial Wrath by 60 seconds.
      - New Talent: Wild Thrash – Command your pet(s) to thrash all enemies within 10 yards, dealing Physical damage to them. Damage is increased by 300% if Wild Thrash hits 2 or more enemies. Deals reduced damage beyond 8 targets.
      - New Talent: Frenzy – Increases pet attack speed by 20%/40%.
      - New Talent: Jagged Wounds – All bleed damage dealt by you and your pets increased by 10%.
      - New Talent: Heart of the Pack – Summoning a Dire Beast grants 0.5% Haste for 8 seconds.
      - Solitary Companion has returned – Your pet damage is increased by 35% and your pet's size is increased by 10%.
      - Thrill of the Hunt has been redesigned – Barbed Shot critical strike chance increased by 5%/10%. Cobra Shot critical strike chance increased by 15%/30%.
      - Training Expert has been redesigned – Now increases pet damage by 3%/6%.
      - Brutal Companion has been redesigned – Barbed Shot has a 25% chance to cause your pet to use its special attack and deal 50% bonus damage.
      - Thundering Hooves has been redesigned – Stomp damage increased by 30%. Bestial Wrath commands all active pets to Stomp at 200% effectiveness.
      - Serpentine Strikes has been redesigned – Now additionally causes Cobra Shot to refund 10 Focus when it critically strikes.
      - Bloody Frenzy has been redesigned – When you use Bloodshed, your Barbed Shot damage over time happens 100% faster for 12 seconds.
      - Wild Instincts has been redesigned – Whenever your primary pet (and only your primary pet) uses Stomp, you will fire a free Barbed Shot at a target not already affected by Barbed Shot. This Barbed Shot cannot cause another Stomp.
      - Pack Tactics has been redesigned – Barbed Shot now instantly grants 25 Focus. Passive Focus generation increased by 75%.
      - Barbed Shot has been updated – Barbed Shot's bleed is now a rolling periodic. Damage reduced by 20%.
      - Dire Frenzy has been updated – Now increases Dire Beast damage by 10%/20% (was 30%/60%).
      - War Orders has been updated – Now reduces Kill Commands cooldown by 3 seconds.
      - Stomp has been updated – No longer deals a separate damage event to its primary target. Damage increased by 200%.
      - Bloodshed has been updated – Bestial Wrath provokes your pets to tear into your target, causing your target to bleed for heavy damage over 12 seconds.
      - Huntmaster's Call has been updated – Fenryr's Ravenous Leap damage reduced by 50%.
      - Kill Command damage increased by 2%.
      - Kill Cleave's Kill Command damage reduced to 40% (was 80%).
      - Beast Cleave now activates when you use Wild Thrash, rather than from Multi-Shot.
      - Beast Cleave duration increased to 8 seconds (was 6 seconds).
      - Beast Cleave pet melee attack damage reduced to 40% (was 80%).
      - Bestial Wrath initial damage increased substantially and now increases player and pet damage by 20% (was 30%).
      - Bite damage increased by 50%.
      - Claw damage increased by 50%.
      - Smack damage increased by 50%.
      - Scent of Blood is no longer a 2-point talent.
      - Starter Build has been updated.
    - Many talents have changed positions in the talent tree.
    - The following talents have been removed:
      
      - Barbed Wrath
      - Hunter's Prey
      - Multi-Shot
      - Poisoned Barbs
      - Serpentine Rhythm
      - Wild Call

:::

:::

## FAQ

:::accordion
:::details Q:  Why is my [[spell:115939]] uptime low?
A: Make sure to not overspend your Focus by casting to many [[spell:193455]], it's important to manage your focus so you can use your [[spell:1264359]] on cooldown.

:::

:::

---

### Credits

Written By: **Charmie**

Reviewd by: **Rycn**

---

:::changelog 更新记录
**2026-08-07** Updated for patch 12.1.

**2026-06-17** Updated for patch 12.0.7.

**2026-04-26** Updated for patch 12.0.5.

**2026-02-22** Updated for patch 12.0.1.

**2026-01-18** Updated for Midnight 12.0

**2025-12-01** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2

**2025-06-16** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-26** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-11-25** Updated Single-Target talents for certain bosses.

**2024-10-21** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
