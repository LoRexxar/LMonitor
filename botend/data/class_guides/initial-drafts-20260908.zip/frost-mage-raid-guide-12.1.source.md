Welcome to the **Frost Mage** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 2/5 · Weak

Survivability · 3/5 · Average

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Frost Mage** Raid Best in Slot
```json
{
  "source_code": "JsqAQCEA3_fABIgJEIIEBAwJ5OwVtOggCYhNYFQApfBBAERAAQQrDQQAUAFj1gVABoMJEIACBAwF5OggC4UAB8cCPAQCN8AEJTCBAiQByUgHAscCeQQBqmwDc99FEIAGBAQ84OAG24VN5IAWBEAIoOAgIVQMIb7LjVT0wAwIgBTWiwgN3Wjt1sUAB0MJEAAIFAwe1EYNYYTOCgVATfBBBk9FEIICBAQ94mwlc4UAB4paCIIIRIBR2IjX1YbNnWiTBEAVfQAAIEAAFwICnF9AVwAGdfBBAgRAAUhhIQvIEEQ1A8TAGjCWBEQCAPAAAFAA2WgkscbNZJCD2scNAMySBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271562]] | [[item:243991]] |
| 胸部 | [[item:271567]] | [[item:243977]] |
| 腰部 | [[item:271561]] | [[item:240900]] |
| 腿部 | [[item:271563]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:243953]] |
| 腕部 | [[item:239648]] | [[item:240900]] |
| 手部 | [[item:271565]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:250215]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex Talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As a **Frost Mage**, you have access to Hand of Frost, which gives you a chance to summon a [[spell:1262935]] that deals frost damage and applies [[spell:1221389]] stacks.

**Rank 2** increases your chance to summon a [[spell:1262935]] and also your spell damage by dealing damage with it. While **Rank 3** grants your [[talent:80216]] an additional charge, increases its damage and allows it to summon 4 [[spell:1262935]] over its duration.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-frostmage-mxr.webp>)

Hand of Frost

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:1246769]]
    
    - New passive that changes your mastery and how you interact with your rotation.
  
  
  
  - [[talent:80251]]
    
    - Now built-in together with [[talent:80216]] and is available right after it.
  - [[talent:134180]]
    
    - Gives you an additional charge of [[talent:80181]] and [[talent:80176]] which improves you  survivability greatly.
  
  
  
  - [[talent:134406]]
    
    - [[talent:134406]] is back!
- **Class Tree**
  
  - [[talent:134182]]
    
    - Restores you some health when you drop low and casts [[talent:80174]]. One of the weakest passive defensives but still something and has an interesting concept.
  
  
  
  - [[talent:136581]]
    
    - Casts [[talent:80140]] a second time on its own but adds a cooldown to it.
  - [[talent:136576]]
    
    - Allows your [[talent:80175]] to be casted on yourself automatically whenever you use it on another friendly target.
  - [[talent:134185]]
    
    - Improves your [[talent:80176]] and makes it a much stronger defensive ability.
- **Removed**
  
  - [[spell:76613]]
    
    - Mastery being reworked results in a big change of the way you play the spec and changes many interactions within it.
  - [[spell:12472]]
    
    - Major cooldown being removed leaves you only with [[talent:80216]] as your only offensive ability that you can manage throughout encounters.
  - [[spell:385305]]
    
    - Same as your mastery, this concept was also reworked and changes many interactions.
  
  
  
  - [[spell:382440]]
    
    - One of the greatest abilities Mage ever had and its removal affects all aspects like damage, utility or survivability.
  - [[spell:414660]]
    
    - Great personal and party defensive ability, combined with [[talent:80147]], made this a very strong spell overall. Its removal together with [[spell:382440]] and removed damage reduction from [[talent:80183]] and [[talent:115877]] results in a much weaker defensive state of Mage coming into Midnight.
  - [[spell:157981]]
    
    - One of the strongest utility spells is also gone, doesn't affect you much directly, but makes you quite a bit more useless in any meaningful content of the game.

## Hero Talents

- [[talent:123339]] is the main hero talent used in both single and AoE scenarios as it currently outperforms [[talent:123342]].

:::tabs
:::tab [[talent:123339]]
- Main feature of the [[talent:123339]] hero talent tree is the addition of a new passive spell, [[spell:443722]], and your interaction with it. [[spell:443722]] is a projectile that deals frost damage and shoots automatically into your target.

- You can trigger it with a variety of ways: 
  
  - [[talent:117266@AJACCA]] makes [[talent:80241]] to conjure a [[spell:443722]] for every 2 [[spell:1221389]] stacks [[spell:1246769]] from its primary target.
  - [[talent:117264@AJACCA]] allows your [[talent:80242]] to conjure up to 4 [[spell:443722]] when damaging enemies.
  - [[talent:135920@AJACCA]] makes your [[talent:134406]] to have a chance to conjure a [[spell:443722]] alongside its [[spell:31707]].
  - [[talent:135946@AJACCA]] causes [[talent:80244]] to conjure 2 [[spell:443722]].
  
  
  
  - Due to [[talent:117265@AJACCA]] you have a chance to conjure a burst of [[spell:443722]] when conjuring one or more of them.
  - [[talent:117257@AJACCA]] makes your [[talent:80216]] to generate 1 [[spell:443722]] each time it does damage to one or more enemies. Additionally, for 10 seconds after casting [[talent:80216]], your chance to conjure an additional [[spell:443722]] is increased.

- On top of that, there are a bunch of passive interactions that grant you some additional damage, cooldown reductions and other stuff:
  
  - [[talent:135919@AJACCA]] makes your direct damage from [[spell:443722]] to have a chance to apply 1 stack of [[spell:1221389]].
  - [[talent:135918@AJACCA]] causes [[talent:80241]] to shatter 1 additional stack of [[spell:1221389]] and increases Shatter damage.
  - [[talent:128267@AJACCA]] increases damage of your [[spell:116]] and [[talent:134421]] and makes your [[spell:199786]] to conjure 2 additional [[spell:443722]].
  - [[talent:117258@AJACCA]] reduces the cooldown of [[talent:80242]] with each direct damage from [[spell:443722]].
  - [[talent:117261@AJACCA]] increases [[talent:80216]] damage and your chance to gain [[talent:80244]] from [[spell:116]].
  - [[talent:117259@AJACCA]] makes direct damage of your [[spell:443722]] to also deal damage to nearby enemies.

:::

:::tab [[talent:123342]]
- [[talent:123342]] hero talent tree revolves around passively gaining additional damage from your spells by transforming your [[spell:116]] to [[spell:431044]], making [[talent:80243]] deal frostfire damage with [[talent:117241@FAQA8chA]] and causing [[talent:80251]] to also call down a [[spell:153561]] alongside other passive damage increase talent nodes. To top it off, you also gain [[talent:135922@AJACCA]] passive that makes frostfire damage to also apply ignite, dealing additional damage over 9 seconds.

- At last, the only thing that actively interacts with your gameplay is the [[talent:117244@AJACCA]] talent node. It causes your Frostfire spells to have a chance for your next [[spell:431044]] to be instant cast, deal increased damage and explode to nearby enemies.
  
  - On top of it, you may also gain it by casting [[spell:199786]] due to [[talent:117235@FAQA8chA]].

:::

:::

## Talents

:::tabs
:::tab [[talent:123339]] Single Target
:::talents [[talent:123339]] **Frost Mage** single target talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMmxMLmZmZmxMQAAgZmZWWmZaDAAAAAA2AYbZMjZwsMPgxMsAAAwMLAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMmxMLmZmZmxMQAAgZmZWWmZaDAAAAAA2AYbZMjZwsMPgxMsAAAwMLAzwYAzghB"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[talent:80227]]
  
  - Causes your next [[talent:80241]] to deal Shatter damage equal to 4 stacks of [[spell:1221389]] and not consume [[spell:1221389]] stacks.
- [[talent:136182]]
  
  - Generates an [[spell:148012]] every 6 seconds. Upon generating 5 [[spell:148012]], [[spell:116]] transforms to a [[spell:199786]] for its next cast.
- [[talent:134407]]
  
  - Casting [[spell:199786]] grants you [[talent:80227]].
- [[talent:80250]]
  
  - When [[talent:80241]] Shatters a stack of [[spell:1221389]], the cooldown of [[talent:80216]] is reduced by 0.1 seconds.
- [[talent:80248]]
  
  - Consuming [[talent:80244]] has a chance to cause your next [[talent:80241]] to Shatter additional stacks of [[spell:1221389]].
- [[talent:80237]]
  
  - [[talent:80242]] grants you [[talent:80244]].

#### Class Tree

- [[talent:80141]]
  
  - Grants you a damage taken reduction by 70% for 6 seconds instead of immunity from [[talent:80181]].
- [[talent:80174]]
  
  - Returns you to your current location and health when cast a second time, or after 10 seconds. Effect negated by long distance or death. Very versatile spell and should be used both for improving your survivability and movement.
- [[talent:80163]]
  
  - Teleports you forward, unaffected by the global cooldown and castable while casting.
- [[talent:115877@FAgAVVdBvFbA]]
  
  - Makes you invisible and untargetable for 20 seconds, removing all threat. Any action taken cancels this effect. Increases your movement speed, additionally with [[talent:80170@FAQAvFbA]], becomes a decent movement speed boost.
- [[talent:134185]]
  
  - Makes [[talent:80176]] to reduce your physical damage taken and absorbs an additional amount of your maximum health. Additionally, gains you an extra charge.

### Hero Talents

- [[talent:117262]]
  
  - Much more useful utility node compared to the other option.
- [[talent:117263@AJACCA]]
  
  - Better survivability option than the other talent.
- [[talent:135920@AJACCA]]
  
  - Outperforms [[talent:135946@AJACCA]].

:::

:::tab [[talent:123339]] Cleave
:::talents [[talent:123339]] **Frost Mage** cleave talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### When to use this Spec

Use this spec if you're fighting up to 2 enemies.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[talent:80226]]
  - [[talent:80214]]
  - [[talent:136839]]
- **Removed**
  
  - [[talent:80247]]
  - [[talent:134408]]
  - [[talent:134406]]

### Hero Talents

- **Added**
  
  - [[talent:135946@AJACCA]]
- **Removed**
  
  - [[talent:135920@AJACCA]]

:::

:::tab [[talent:123339]] AoE
:::talents [[talent:123339]] **Frost Mage** cleave talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZGmxMQAAgZmZWWmZaDAAAAAAWAYbZMjZwsNMmZsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZGmxMQAAgZmZWWmZaDAAAAAAWAYbZMjZwsNMmZsAAAwMbAzwYAzghB"
}
```
:::

### When to use this Spec

Use this spec if you're fighting 3 or more enemies.

### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

#### Spec Tree

- **Added**
  
  - [[talent:80226]]
  - [[talent:80214]]
  - [[talent:134416]]
  - [[talent:128077]]
  - [[talent:136839]]
- **Removed**
  
  - [[talent:80247]]
  - [[talent:80245]]
  - [[talent:134418]]
  
  
  
  - [[talent:134408]]
  - [[talent:134406]]

### Hero Talents

- **Added**
  
  - [[talent:135946@AJACCA]]
- **Removed**
  
  - [[talent:135920@AJACCA]]

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Each stack of [[spell:1221389]] Shattered has a 4% chance to generate an [[spell:148012]]. [[spell:199786]] damage increased by 20%.
- **4-Set:** Casting [[spell:199786]] has a chance to rapidly generate 5 [[spell:148012]] over 1 second. [[spell:1246769]] damage increased by 5%.

### Single-Target and Cleave

:::tabs
:::tab [[talent:123339]]
### Opener

- Your goal is to start rolling your major cooldowns as soon as possible while also simultaneously spending your procs such as [[talent:80227]] and [[talent:80243]] with [[talent:80244]]. Below, you can see an example of how your opener may look like using our recommended ‍[[talent:123339]] talent build:

:::rotation **Frost Mage** Single-Target and Cleave opener in Raid
```json
{
  "source_code": "IAFoJIEdAAAAAcAUyV2YhNHdCEAiuOAAAAAACFeOBAAAC1NIDAAAAAgA3bXAUgg6KFQAcggAG5aFUAgAFoBJCcvdAAAACpGDDA"
}
```
1. [[spell:116]] Precast [[item:241288]] · [[spell:80353]]
2. [[spell:205021]]
3. [[spell:30455]]
4. [[spell:84714]]
5. [[spell:44614]]
6. [[spell:30455]]
7. [[spell:30455]]
8. [[spell:30455]]
9. [[spell:199786]]
:::

- Opener may slightly vary depending on your procs.
- Always keep an eye on your [[spell:190447]] or [[spell:112965]] procs and make sure to spend them and not overcap.
- Keep in mind that [[spell:1221389]] stacks are capped at 20 so try to never waste them as shattering them is one of your primary source of damage.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:80243]] if you have [[talent:80244]] proc and [[talent:80248]] is not active.
2. Cast [[talent:80241]] if you have 2 stacks of [[spell:112965]].
3. Cast [[talent:80242]] on cooldown.
4. Cast [[spell:199786]] on cooldown.
5. Cast [[talent:80241]] if you have [[spell:112965]] active or your target has 6 or more stacks of [[spell:1221389]].
6. Cast [[talent:80243]] on cooldown.
7. Cast [[talent:80216]] on cooldown.
   
   - Although its priority is very low and used mainly to apply [[spell:1221389]] stacks, it still does significant amount of damage by itself. Thus, if the fight is about to end, you want to priorotise casting [[talent:80216]] over anything else to maximise amount of casts of it.
8. Cast [[spell:116]].

:::

:::

### AoE

:::tabs
:::tab [[talent:123339]]
### Opener

- Below, you can see an example of how your opener looks like using the recommended **[[talent:123339]]** spec in AoE with 5 enemies:

:::rotation **Frost Mage** AoE opener in Raid
```json
{
  "source_code": "IkFoKIElnLAAAcAUyV2YhNHdCEAiuOAAAAAACFeOBAAACYkrAAAACpuSBAQAIgQ3gMQAckgFIIw92FAFEoGDFQBACVwRoAAACcvdAAAACcvd"
}
```
1. [[spell:190356]] Precast [[item:241288]] · [[spell:80353]]
2. [[spell:44614]]
3. [[spell:84714]]
4. [[spell:205021]]
5. [[spell:44614]]
6. [[spell:30455]]
7. [[spell:199786]]
8. [[spell:190356]]
9. [[spell:30455]]
10. [[spell:30455]]
:::

- AoE for [[talent:123339]] is considered to be a fight with 3+ targets.
- AoE rotation is pretty much the same as single target and cleave with the only exception of adding [[talent:134421]] into your priority list.

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:190356]] on cooldown if [[spell:270233]] is active.
2. Cast [[talent:80243]] if you have [[talent:80244]] proc and [[talent:80248]] is not active.
3. Cast [[talent:80241]] if you have 2 stacks of [[spell:112965]].
4. Cast [[talent:80242]] on cooldown.
5. Cast [[spell:199786]] on cooldown.
6. Cast [[talent:80241]] if you have [[spell:112965]] active or your target has 6 or more stacks of [[spell:1221389]].
7. Cast [[talent:80243]] on cooldown.
8. Cast [[talent:80216]] on cooldown.
   
   - Although its priority is very low and used mainly to apply [[spell:1221389]] stacks, it still does significant amount of damage by itself. Thus, if the fight is about to end, you want to priorotise casting [[talent:80216]] over anything else to maximise amount of casts of it.
9. Cast [[spell:116]].

:::

:::

## Deep Dive

### Freeze and Shatter

Due to a new [[spell:1246752]], gameplay loop is going to revolve around accumulating [[spell:1221389]] stacks with [[spell:116]] and [[talent:80243]] and [[spell:1246769]] them with [[talent:80241]]. Since we also don't have any major cooldowns anymore, maintaining a proper rotation without overcapping [[spell:1221389]] stacks and wasting our other procs is going to be very crucial to have a solid output.

### Min-maxing Cleave

Because of how easy it is to overcap [[spell:1221389]] stacks, it is a damage gain to try and spread it across your targets so you can clear multiple of them with each cast of [[spell:30455]]. This way you can spend 12 stacks of [[spell:1221389]] at a time instead of usual 6, for example.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Frost Mage** Nek'Zali talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.

:::

:::tab Entombed Sentinels
:::talents **Frost Mage** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Important to know that [[spell:1284434]] may also spawn on the opposite boss, so try not to stand between them and be careful whenever [[spell:1284434]] spawn.
- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].

:::

:::tab Lost Explorers
:::talents **Frost Mage** Lost Explorers talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Pay attention to [[spell:1296062]] casts to have an easier time dodging them.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed after being used once.

:::

:::tab Vashnik
:::talents **Frost Mage** Vashnik talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.

:::

:::tab Sszorak
:::talents **Frost Mage** Sszorak talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMmxMLmZmZmxMQAAgZmZWWmZaDAAAAAA2AYbZMjZwsMPgxMsAAAwMLAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMmxMLmZmZmxMQAAgZmZWWmZaDAAAAAA2AYbZMjZwsMPgxMsAAAwMLAzwYAzghB"
}
```
:::

### Boss Tips

- In case you fail to find a partner to deal with [[spell:1285419]], keep in mind that you can also negate it with a [[talent:80163]] or [[talent:80174]].
- Very important to keep an eye on the [[spell:1305959]] timer and, whenever it's close, scan the platform ahead of time to see where you will need to place it.
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.

:::

:::tab Twin Fangs
:::talents **Frost Mage** Twin Fangs talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.

:::

:::tab Coiled Altar
:::talents **Frost Mage** Coiled Altar talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].

:::

:::tab Ula'tek
:::talents **Frost Mage** Ula'tek talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents **Frost Mage** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB",
  "code": "CCEAmxqme2NN7ABQRxXf6C8R0ZmNjlZmZWYmZiZMzMzMzMLmZmxMmBCAAMzMzyyMTbAAAAAAwGAbLjZMDmthxMsAAAwMbAzwYAzghB"
}
```
:::

### Boss Tips

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle, so position accordingly or be ready to negate the knockback with [[talent:80163]] or [[talent:80174]].
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Frost Mage**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Frost Mage** Stat Priorities in Raid
```json
{
  "source_code": "IoAJFUAIxQCKEMABEA"
}
```
**智力 ≫ 暴击 ≥ 精通 ≫ 急速 ≫ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DCRAAAEAnk7cVrjgCYhNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAAEAE06QQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271562@DgQAAAEAXk7IoAOF]] | Tier / Catalyst |
| Cloak | [[item:268253@BgRAAAEAYYjX1kjAYFA]] | The Coiled Altar |
| Chest | [[item:271567@DgQAAAEAJk7IoAOF]] | Tier / Catalyst |
| Wrist | [[item:239648@BiUAAAEAE06Y7LjVT0wAwIgBTWiwgN3Wjt1sUA]] | Crafting |
| Gloves | Convert [[item:268243@AgQAAIoAYFA]]  <br>into [[item:271565@BASAA4DA7VTg1ghNCKAWBA]] | Catalyst of The Coiled Altar |
| Belt | [[item:271561@BiQAAAEAE06IoAOF]] | Catalyst |
| Legs | [[item:271563@DgQAAAEAFo6IoAOF]] | Tier / Catalyst |
| Boots | [[item:268255@DgRAAAEAxj7ghNeVTOCgVA]] | The Coiled Altar |
| Ring 1 | [[item:268249@DiQAAAEA1j7QQrjgC4UA]] | Vashnik the Malignant |
| Ring 2 | [[item:158366@DCSAAAEA1j7QQrjNy4VN2Wzpl4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAAEACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:250215@BgQAAAEACKgTBA]] | Murder Row |
| Main-hand | [[item:271092@DgQAAAEA_k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@BAUAAAEA2-yY1ENM3WTWiwgNLXDAjsUA]] | Crafting |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251232@AgQAAIoABFA]] | Voidscar Arena |
| Neck | [[item:251234@AgQAAIoABFA]] | Voidscar Arena |
| Shoulder | [[item:239031@AgQAAIoABFA]] | Temple of Sethraliss |
| Cloak | [[item:251190@BgQAAAEACKQQBA]] | The Blinding Vale |
| Chest | [[item:239032@AgQAAIoABFA]] | Temple of Sethraliss |
| Wrist | [[item:251154@AgQAAIoABFA]] | Den of Nalorakk |
| Gloves | [[item:273773@AgQAAIoABFA]] | Altar of Fangs |
| Belt | [[item:159255@AgQAAIoABFA]] | Temple of Sethraliss |
| Legs | [[item:193750@AgQAAIoABFA]] | Ruby Life Pools |
| Boots | [[item:251137@AgQAAIoABFA]] | Murder Row |
| Ring 1 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Ring 2 | [[item:158366@AgQAAIoABFA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | The Blinding Vale |
| Trinket 2 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Weapon | [[item:159636@AgQAAIoABFA]] | Temple of Sethraliss |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **B-Tier** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]] |
| **C-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Only crafted on your **weapon** or **off-hand**.
- 1x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists** or **Cloak** depending on your available gear.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]] -- default
- Combat Potion
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] -- default
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- *unique, can use only one*
  
  
  
  - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAAEAZbAB]]  <br>[[item:275707@BAAAAAE]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAAE]] |
| Chest | [[item:243977@BAAAAAE]] |
| Wrist | [[item:275707@BAAAAAE]] |
| Waist | [[item:275707@BAAAAAE]] |
| Legs | [[item:240133@BAAAAAE]] |
| Boots | [[item:243953@BAAAAAE]] |
| Ring 1 | [[item:243957@BAAAAAE]] |
| Ring 2 | [[item:243957@BAAAAAE]] |
| Weapon | [[item:244031@BAAAAAE]] |

:::

:::column
:::gear **Frost Mage** Enchantments in Raid
```json
{
  "source_code": "IQFZABQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAAEAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Frost Mage** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial.
  - Reduce the duration of movement-impairing effects by 20%. This was only useful once in the recent history of progression raiding but is still worth noting.
- [[spell:33702]] *-- Orc* 
  
  - Strong DPS racial.
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the latest Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Frost Mages** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**Cursor [[spell:190356]] --** *Casts [[spell:190356]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Blizzard
```

:::

:::details Mouseover Macros
**Mouseover [[spell:475]] -** *Uses [[spell:475]] on your mouseover, your target if there are no targets under your cursor or, lastly, yourself*.

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][exists,nodead][@player] Remove Curse
```

:::

:::details Utility Macros
**Cancel [[spell:342245]] --** *Cancels your [[spell:342245]] buff in case you used it poorly - on low health or in bad position.*

```wow-macro
#showtooltip Alter Time
/cancelaura Alter Time
```

**[[spell:1953]] during [[spell:45438]] --** *Cancels your [[spell:45438]] and immediately [[spell:1953]]. Useful when you've used [[spell:45438]] in a void zone and it's not gone by the end of it.*

```wow-macro
#showtooltip
/cancelaura Ice Block
/cast Blink
```

**[[spell:116]] --** *Cancels your [[spell:45438]] if you try to cast [[spell:116]], can replace your usual keybind with it to have an easier time cancelling your [[spell:45438]], normal keybind for it usually takes a global to happen but with cancelaura macro you can do it instantly. Additionally, [nochanneling] part allows you to spam the keybind during channeling casts like [[spell:382440]] and not interrupt it until the cast is done.*

```wow-macro
#showtooltip Frostbolt
/cancelaura Ice Block
/cast [nochanneling] Frostbolt
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Frost Mage**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Frost-Raid-UI-1024x616.png>)

**Frost Mage** Interface in Raids

:::accordion
:::details Addons
- **EllesmereUI** *-- Unit frames, nameplates, cooldown manager replacement, and many more* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - This is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- *Developers' notes: We've made some adjustments to Mage defensives with the goal of improving Mage survivability as a whole. To accomplish this, we are unifying the functionality of Improved Barrier to give all specs an additional charge of their Barrier spell, plus one “rider” effect that is spec-specific.*
- New Talent: Improved Warding – Damage taken from area of effect attacks reduced by 4%.
- Improved Prismatic Barrier has been redesigned – Prismatic Barrier gains an additional charge and further reduces magic damage taken by 5%.
- Improved Blazing Barrier has been redesigned – Blazing Barrier gains an additional charge and cauterizes your wounds, healing you for 15% of the damage it absorbs.
- Improved Ice Barrier has been redesigned – Ice Barrier gains an additional charge and reduces your physical damage taken by 10%.
- Temporal Realignment has been updated – Now immediately heals 20% of your health and heals an additional 30% over 6 seconds.
- Frost
  
  - Glacial Bulwark has been updated – No longer grants an additional charge of Ice Barrier.
  - Splitting Ice has been updated – Flurry and Frostbolt effectiveness against the second target reduced to 50% (was 80%).
  - Fractured Frost has been updated – Ice Lance effectiveness against the second target reduced to 50% (was 100%).
  - All ability and pet damage increased by 7%.
  - Apex Talent: Hand of Frost (Rank 2) now grants 0.5%/1% increased spell damage (was 1%/2%).
    
    - *Developers' notes: Hand of Frost in combination with Frost's Hero Talents was providing more burst than we'd like.*

:::

:::

:::accordion
:::details Patch 12.0.1
- Mage
  
  - Hero Talents
    
    - [[talent:123342]]
      
      - Flash Freezeburn has been updated – Glacial Spike cleave percentage reduced to 25% (was 50%).
      - Frostfire Empowerment damage bonus reduced to 60% (was 80%).
      - Frostfire Bolt damage reduced by 20%.
      - Isothermic Core's Meteor now Shatters 1 Freezing stack (was 2).
      - Duality's Pyroblast damage increased by 100%.
      - Molten Chill Ignite effectiveness increased to 30% (was 15%).
    - [[talent:123339]]
      
      - Controlled Instincts damage effectiveness increased to 60% (was 40%).
      - Frost Splinter damage increased by 20%.
  - Frost
    
    - Developers' notes: We're reducing the power of Frostbolt and Flurry to help Ice Lance and Shatter continue to be the rotational priority. We're moving some of that lost power into Ice Lance and Shatter to mitigate the throughput impact of these changes in low-target scenarios. We're also tamping down Frostfire's performance in AOE, since it has been overperforming.
    - All damage dealt increased by 5%.
    - Ice Lance damage increased by 25%.
    - Shatter primary target damage increased by 54%.
    - Flurry damage reduced by 28%.
    - Frostbolt damage reduced by 15%.
    - Frozen Orb damage reduced by 20%.
    - Glacial Assault chance to trigger reduced to 12% (was 25%).
    - Splitting Ice now causes Flurry and Frostbolt to strike an additional target at 80% effectiveness (was 100%).
    - Comet Storm now Shatters 1 Freezing stack per Missile (was 2).
    - Icicles visual effects now automatically hide and reappear based on whether you're in combat or not.
    - Fixed an issue that caused all Water Elemental glyphs to not be properly applied to the Water Elemental spell.

:::

:::

:::accordion
:::details Patch 12.0
- Mage
  
  - New Talent: Improved Conjuration – Mirror Image's cooldown is reduced by 30 seconds/60 seconds.
  - New Talent: Time Walk – Alter Time resets the cooldown of Blink and Shimmer when you return to your original location.
  - New Talent: Spatial Manipulation – Blink gains an additional charge.
  - New Talent: Temporal Realignment – Upon dropping below 25% health, your past self corrects your timeline, casting Alter Time and instantly returning 50% of your maximum health.
  - New Talent: Improved Ice Barrier – Ice Barrier's absorb is increased by 5% of your maximum health and it now reduces your physical damage taken by 10%. Frost Mage only.
  - New Talent: Improved Blazing Barrier – Blazing Barrier's damage is increased by 200% and it now cauterizes your wounds, healing you for 15% of the damage it absorbs. Fire Mage only.
  - New Talent: Charm of Aegwynn – The critical strike damage of your spells is increased by 5%.
  - New Talent: Charm of Medivh – Mastery increased by 3%.
  - New Talent: Improved Blink – Blink's cooldown is reduced by 2 seconds.
  - New Talent: Permafrost Bauble - The cooldown of Ice Block and Ice Cold is reduced by 30 seconds.
  - New Talent: Master of Escape – Reduces the cooldown of Greater Invisibility by 45 seconds.
  - New Talent: Brainstorm – Hot Streak, Clearcasting, and Brain Freeze increase your Intellect by 1% for 8 seconds. Multiple applications may overlap.
  - New Talent: Improved Spellsteal – Spellsteal repeats its effect after 4 seconds, but it now has a cooldown of 4 seconds.
  - New Talent: Improved Counterspell – Counterspell prevents casting for an additional 1 second.
  - New Talent: Improved Remove Curse – Casting Remove Curse on a friendly target also casts it on yourself, but its cooldown is increased by 20 seconds.
  - New Talent: Mana Confluence – Your mana costs are reduced by 5%.
  - New Talent: Reflection – After casting Blink, it is replaced with Reflection for 8 seconds.Reflection: Teleports you back to where you last Blinked. Castable while casting and unaffected by the global cooldown.
  - Master of Time has been updated – Reduces Alter Time cooldown by 5 seconds/10 seconds. No longer grants an additional charge of Blink/Shimmer after casting Alter Time.
  - Overflowing Energy has been updated – Now increases the critical strike chance of Arcane Barrage, Fireball, and Frostbolt only. Now grants 20% increased Fireball critical strike chance per stack (was 10%).
  - Quick Witted has been updated – Counterspell's cooldown is reduced by 5 seconds.
  - Time Manipulation has been updated – Now reduces the cooldown of your loss of control spells by 5 seconds.
  - Incantation of Swiftness has been updated – Invisibility now increases your movement speed by 20%/40% for 6 seconds.
  - Mirror Image has been updated – No longer reduces the damage you take. Tooltip now correctly communicates its threat reduction effect.
  - Mirror Image duration reduced to 15 seconds (was 40 seconds).
  - All Barrier spells have had their cooldowns increased to 30 seconds (was 25 seconds).
  - Barrier spells now have a reduced global cooldown and now shield you for 25% of your maximum health (was 20%).
  - Blink cooldown increased to 15 seconds inherently.
  - Shimmer cooldown increased to 30 seconds (was 25 seconds) and no longer has 2 charges inherently.
  - Greater Invisibility no longer reduces damage you take by 60%.
  - Counterspell cooldown increased to 25 seconds (was 24 seconds).
  - Cone of Cold cooldown increased to 25 seconds (was 12 seconds) and now applies Chilled.
  - Ice Nova now replaces Cone of Cold when talented.
  - Flow of Time is now a 1-point talent.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Accumulative Shielding
    
    
    
    - Blast Wave
    - Displacement
    - Diverted Energy
    - Frigid Winds
    - Ice Floes *(moved to the Frost talent tree)*
    - Incanter's Flow
    - Mass Barrier
    - Reabsorption
    
    
    
    - Reduplication
    - Rigid Ice
    - Shifting Power
    - Slow
    - Supernova
    - Tempest Barrier
    - Temporal Velocity
    - Volatile Destruction
  - Hero Talents
    
    - [[talent:123342]]
      
      - New Talent: Duality – Casting Glacial Spike also casts a Pyroblast, dealing moderate Fire damage.
      - New Talent: Molten Chill – Your Frostfire spells apply Ignite, dealing an additional 15% of their damage over 9 seconds.
      - New Talent: Elemental Conduit – Comet Storm, Glacial Spike, Pyroblast, and Meteor now apply Ignite. Your Haste is increased by 8%.
      - New Talent: Heat Sink – Flurry now deals Frostfire damage and its damage is increased by 10%.
      - New Talent: Dualcasting Adept – Your Fire spells deal 20% increased critical strike damage. Shatter and Blizzard damage increased by 10%.
      - New Talent: Blast Radius – Comet Storm damage increased by 20%. Meteor damage increased by 20%.
      - Flash Freezeburn has been redesigned – Glacial Spike damage increased by 25% and it now explodes on impact, dealing 50% of its damage to up to 5 nearby enemies. Additionally, Glacial Spike now grants Frostfire Empowerment.
      - Frostfire Infusion has been updated – Frostfire Bolt has an additional 5% chance to grant Brain Freeze. The damage of your Frost and Fire spells are increased by 4%.
      - Severe Temperatures has been updated – Frostfire Empowerment stacks 1 additional time and it causes Frostfire Bolt to explode for an additional 20% of its damage.
      - Frostfire Empowerment has been updated – Now triggered from casting Frostfire spells (was Frostfire spell damage).
      - Isothermic Core's Meteor and Comet Storm damage increased by 35%.
      - Isothermic Core tooltip updated to show the actual damage values of the Meteor/Comet Storms summoned and is now conditionalized based on your specialization.
      - Frostfire Bolt cast time reduced to 1.75 seconds (was 2 seconds).
      - Frostfire Bolt direct damage increased by 95%.
      - Frostfire Bolt periodic damage increased by 123%.
      - Frostfire Bolt's tooltip now has two specialization specific versions that only can be seen and selected by Frost or Fire. They now override only Frostbolt or Fireball based on your specialization.
      - Several talents have changed positions in the talent tree.
      - The following talents have been removed:
        
        - Excess Fire
        - Excess Frost
        - Frostfire Mastery
      - Flame and Frost has been updated – Now triggers from Ice Block and Ice Cold (was Cold Snap).
      - Dualcasting Adept has been updated – Now increases Shatter damage (was Ice Lance damage).
      - Meteors summoned via Isothermic Core now Shatters up to 2 stacks of Freezing.
      - Frostfire Empowerment no longer affects Glacial Spike.
    - [[talent:123339]]
      
      - New Talent: Attuned Familiar – Your Water Elemental has a 50% chance to conjure a Splinter alongside its Waterbolt.
      - New Talent: Infused Splinters – Direct damage from Frost Splinters have a 15% chance to apply 1 stack of Freezing.
      - New Talent: Polished Focus – Ice Lance Shatters 1 additional stack of Freezing. Shatter damage increased by 15%.
      - New Talent: Archmage's Wrath – Ray of Frost damage increased by 20%. Your chance to gain Brain Freeze from Frostbolt is increased by 5%
      - Splinterstorm has been redesigned – Each time Ray of Frost damages one or more enemies, it conjures 1 Frost Splinter. For 10 seconds after casting Ray of Frost, your chance to conjure an additional Frost Splinter is increased to 100%.
      - Look Again has been redesigned – While in combat, Blink summons a Mirror Image at your previous location.
      - Augury Abounds has been redesigned – Conjuring one or more Splinter has a 10% chance to conjure a burst of 8 Splinters.
      - Shifting Shards has been updated – Gaining Brain Freeze conjures 2 Frost Splinters.
      - Force of Will has been updated – Ice Lance conjures a Frost Splinter for every 2 Freezing stacks Shattered from its primary target.
      - Signature Spell has been updated – Frostbolt and Blizzard damage increased by 15%. Glacial Spike conjures 2 additional Frost Splinters.
      - Spellfrost Teachings has been updated – Frozen Orb cooldown reduction reduced to 0.25 seconds (was 0.5 seconds).
      - Splintering Sorcery has been updated – Splinters no longer apply a damage over time effect.
      - Controlled Instincts has been updated – Splinter cleave percentage increased to 30% (was 20%). No longer requires your target to have been recently damaged by Blizzard.
      - Splinters will now prefer targeting enemies that you have recently targeted with your spells.
      - When more than 1 Splinter is generated in a single event, Splinters will now fire on a delayed cadence, similar to how Splinterstorm used to function.
      - Reactive Barrier absorb amount reduced to 25% (was 50%).
      - Embedded Splinters are no longer tracked on nameplates.
      - Several talents have changed positions in the talent tree.
      - The following talents have been removed:
        
        - Unerring Proficiency
        - Volatile Magic
      - Splintering Sorcery has been updated – Casting Frostbolt or Flurry conjures a Frost Splinter.
  - Frost
    
    - New Passive Ability: Shatter – Damage from Frostbolt and Flurry applies Freezing to their targets. Stacks up to 20 times. Damage from Ice Lance shatters your enemies, consuming 4 stacks of Freezing and dealing Frost damage for each stack removed.
    - New Passive Ability: Winter's End – When an enemy affected by Freezing dies, it explodes, dealing Frost damage to nearby enemies for each stack of Freezing it had. Damage reduced beyond 5 targets. Learned at level 40.
    - Mastery has been redesigned and renamed Freeze and Shatter – Now increases the damage of spells that Freeze your enemies and increases the damage of spells that Shatter.
    - New Talent: Improved Shatter – Shatter damage has a 50% increased chance to critically strike.
    - New Talent: Icicles – Frost crystallizes around you, generating an Icicle every 6 seconds. Upon generating 5 Icicles, Frostbolt upgrades to Glacial Spike for its next cast. Icicles generate rapidly out of combat. Icicle generation is increased by Haste.
    - New Talent: Glacial Bulwark – Ice Block and Frost Barrier now have an additional charge.
    - New Talent: Summon Water Elemental – Summons a Water Elemental to follow and fight for you.
      
      - Waterbolt damage increased by 100%.
      
      
      
      - Water Jet damage increased by 100% and no longer grants Brain Freeze.
    - New Talent: Cone of Frost – Cone of Cold/Ice Nova now applies 3 stack of Freezing to up to 5 enemies.
    - New Talent: Crystalline Refraction – Ray of Frost generates 2 stacks of Fingers of Frost over its duration.
    - New Talent: Heart of Ice – Ice Lance shatters 1 additional stack of Freezing.
    - New Talent: Rimecaster – Frostbolt and Glacial Spike damage increased by 10%/20%.
    - New Talent: Glaciate – When Ice Lance shatters a stack of Freezing, the cooldown of Ray of Frost is reduced by 0.1 second.
    - New Talent: Frigid Focus – Ray of Frost damage increased by 30%.
    - New Talent: Improved Flurry – Flurry fires 1 additional missile.
    - New Talent: Glacial Chill – Glacial Spike damage increased by 5% and it now applies 2 additional stacks of Freezing.
    - New Talent: Glacial Shatter – Glacial Spike no longer applies Freezing and it now Shatters 5 stacks of Freezing.
    - New Talent: White Out – Ice Lance reduces the cooldown of Frozen Orb by 0.5 seconds, increased by 0.1 second for each stack of Freezing Shattered.
    - Ice Lance has been updated - Now Shatters 4 stacks of Freezing.
    - Permafrost Lances has been updated – Now increases Shatter damage by 10% for the duration of Frozen Orb (was Ice Lance damage).
    - Glacial Attunement has been updated – Now increases Flurry and Blizzard damage (was Flurry and Ice Lance).
    - Fingers of Frost has been updated – No longer triggers from Frozen Orb inherently. Now causes your next Ice Lance to Shatter the maximum number of Freezing stacks Ice Lance is capable of Shattering without consuming Freezing stacks.
    - Everlasting Frost has been redesigned – Casting Frozen Orb grants 1 stack of Fingers of Frost. Damaging one or more enemies with Frozen Orb has a 3% chance to grant Fingers of Frost.
    - Deep Shatter has been updated – Shatter's critical strike damage is increased by 50% of your critical strike chance.
    - Hailstones has been updated – The time it takes to generate an Icicle is reduced by 1 second.
    - Wintertide has been redesigned – Frozen Orb has a 100% chance to grant Brain Freeze.
    - Glacial Assault has been updated – Damage increased by 260% and no longer applies a damage received bonus. Now applies 1 stack of Freezing. No longer affects Comet Storm.
    - Freezing Winds has been redesigned – Shattering enemies inside your Blizzard increases Shatter's area damage by 15%.
    - Winter's Blessing has been updated – Now grants 3% Haste and grants 5% additional Haste from all Haste sources.
    - Splitting Ice has been updated – Your Flurry and Frostbolt spells strike 1 additional target at 100% effectiveness.
    - Ray of Frost has been updated – Damage increased by 66% and damage tick rate improved to 0.5 seconds (was 1 second). Each time Ray of Frost deals damage, it applies a stack of Freezing. No longer grants Fingers of Frost inherently.
    - Ray of Frost duration reduced to 4 seconds, tick rate reduced to 0.5 seconds (was 5 second duration, 0.625 seconds tick rate).
    - Freezing Rain has been updated – Now increases Blizzard damage by 20% (was 60%).
    - Comet Storm has been updated – Casting Ray of Frost replaces your Ray of Frost with Comet Storm, calling down a series of 7 icy comets on and around your target, that deals Frost damage to all enemies within 8 yards of its impacts. Each Comet Shatters 2 stacks of Freezing. Comet Storm damage increased by 88%.
    - Flash Freeze has been updated – Casting Glacial Spike has a 100% chance to grant you Fingers of Frost.
    - Frostbite has been updated – When Frostbolt critically strikes, it applies 1 additional stack of Freezing. Now causes Shatter to deal damage to nearby enemies, damage reduced beyond 5 enemies.
    - Piercing Cold has been updated – Now increases Flurry and Frostbolt critical strike damage.
    - Fractured Frost has been redesigned – Your Ice Lance strikes 1 additional target at 100% effectiveness, preferring enemies with more Freezing stacks.
    - Thermal Void has been redesigned – Consuming Brain Freeze has a 100% chance to cause your next Ice Lance to Shatter 4 additional stacks of Freezing.
    - Lonely Winter has been redesigned – Spell damage increased by 3%.
    - Blizzard and Cold Snap are now located in the Frost talent tree (was learned automatically when specialized as Frost).
    - Ice Floes is now a passive ability and moved to the Frost talent tree (was in the class tree).
    - Ice Lance now replaces Fire Blast upon activating the Frost Mage specialization.
    - Ice Lance damage increased by 102%.
    - Frostbolt damage increased by 200%.
    - Frostbolt cast time reduced to 1.75 seconds (was 2 seconds).
    - Flurry damage increased by 181% and it now has a new icon.
    - Frozen Orb damage increased by 800% and no longer grants Fingers of Frost when cast.
    - Frozen Orb now slowly follows its target shortly after being cast.
    - Blizzard damage increased by 305%.
    - Blizzard now has an additional talent option to cast Blizzard at your target.
    - Glacial Spike damage increased by 100%.
    - Haste now reduces the cooldown of Flurry, Frozen Orb, and Ray of Frost.
    - Cold Snap is now a Frost spell.
    - Many talents have changed positions in the talent tree.
    - The Starter Build has been updated.
    - The following talents have been removed:
      
      - Bone Chilling
      
      
      
      - Chain Reaction
      - Coldest Snap
      - Cold Front
      - Cryopathy
      - Death's Chill
      - Glacial Spike *(effect moved to the Icicles talent)*
      - Ice Caller
      - Icy Veins
      - Slick Ice
      - Splintering Cold
      - Subzero

:::

:::

## FAQ

:::accordion
:::details Q: Why is my [[spell:135029]] always on cooldown?
**A:** [[spell:135029]] is by default on auto-cast and is used off cooldown by your water elemental pet. Right click on it on the pet bar to turn it off. Don't forget to press it manually afterwards when you need it.

:::

:::

---

### Credits

Written By: **Wexi**

Reviewed By: **Xerwo**

---

:::changelog 更新记录
**2026-08-03** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-21** Updated for patch 12.0.1.

**2026-01-16** Updated for patch 12.0.



:::
