Welcome to the **Devourer Demon Hunter** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Devourer Demon Hunter** Mythic+ Best in Slot
```json
{
  "source_code": "J8pAQicB3_fABMgJEIIGBAw74OA_sOAZ1chNCKAWBEQ6XQAAZEAAX1aCWQAj1UgFI9KJEIACFAwM5OggC4UAXV9ABQbCSAQCJIBKXU9ABA-FEAIEBAQBNVQNAAbCjgQBqOQAPAPSBfBBBk1uDQAMBAwD5OAGAPAAjY7LgBzt1wgNbWySBEAY7OggIEAAYA8A8z6A3WzSBEgskQAAIUAACKgTBo8FEEQ2XQggQEAA13AsBcBEB4paCIYFUAgtJQBGnF9AAgQAAUAIIQ1HEUBDE09FNwALYFQA0LCBCgQAA8TuFsJOBM7FEIACBAwP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240892]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240892]] |
| 肩部 | [[item:271535]] | [[item:244019]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240892]] |
| 腿部 | [[item:271536]] | [[item:240133]] |
| 脚部 | [[item:244569]] | [[item:243983]] · [[item:245784]] |
| 腕部 | [[item:244576]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268211]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Devourer Demon Hunter**, you have access to Midnight, which enables [[talent:132281@FAgAMyuE2VvE]] to be an actually pressable button, the first Rank makes it so [[talent:132281@FAgAMyuE2VvE]] always crits, which synergizes very well with talents like [[talent:136691]].

**Rank 2** increases all cosmic damage you deal by 6% and increases the damage of [[talent:132281@FAgAMyuE2VvE]] furthermore since it always critically strikes anyway  
  
Rank 3 enables the use of [[talent:132281@FAgAMyuE2VvE]] as soon as you enter [[talent:132282]] and grants you an additional 5 souls when you enter [[talent:132282]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-devourer-mxr.webp>)

Midnight

:::

:::

## Hero Talents

- [[talent:134251]] and [[talent:136623]] are the new Hero Talent tree options.[[talent:134251]] is currently slighty ahead of [[talent:136623]] in both AoE and Single-Target scenarios.

:::tabs
:::tab [[talent:134251]]
- The [[talent:134253]] talent tree evolves around generating and spending [[talent:135667@FAQAF6zA]] stacks.
- [[talent:135672]], [[talent:135670]] increase haste and reduce damage taken by 2% capped at 3 stacks.
- [[talent:135673@AJADCA]] grants one stack of [[talent:135667]], make sure to spend stacks before casting [[spell:1213649]] to avoid overcapping. This especially tends to happen whenever you enter [[talent:132282]], as people tend to [[spell:1213649]] to get it on cooldown as soon as possible.

:::

:::tab [[talent:136623]]
- The [[talent:136623]] talent tree is generally evolving about being in melee a lot more than the [[talent:134251]] talent tree as it turns the first [[talent:134272@FAQAiVwE]] and [[spell:1239123]] you cast into big [[talent:136613@FAgAtByAOSOB]] explosions around you.
- It is a bit counter intuitive with traits like [[talent:136615]] and [[talent:136608]] as you generally want to be in [[talent:132282]] for as long as possible but it massively increases the damage outside of it.

:::

:::

## Talents

:::tabs
:::tab [[talent:134251]]
:::talents [[talent:134251]] **Devourer Demon Hunter** Mythic+  Build
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

#### Spec Tree

- [[talent:132282]]
  
  - Entering [[talent:132282]] after collecting 50 souls (35 if talented into [[talent:134331]]) enhance your Consume and Reap, also Fury is slowly being drained the longer you stay in [[talent:132282]], [[spell:1242157]] now grants fury instead of spending it.
- [[talent:132281@FAQAMyuE]]
  
  - Every 30 souls that are collected during [[talent:132282]] grants access to a cast of [[talent:132281@FAQAMyuE]] doing massive damage to your main target and around it, additionally fury drain is significantly slowed during it.

- [[talent:133106]]
  
  - Resets your [[spell:1226019]] after casting [[spell:1213649]].
- [[talent:133110]]
  
  - [[spell:1213649]] deals significantly more damage if you only hit one target, avoid hitting off targets if you do not want to.
- [[talent:132287]]
  
  - [[spell:1226019]] turns into [[talent:132287]] after fully channeling a [[spell:1213649]], massively increasing the damage and adding a frontal AoE component to it.
- [[talent:133512]]
  
  - Allowing you to stay [[talent:132282]] significantly longer and increases your haste with every soul you collect.

#### Class Tree

- [[spell:196718]] 
  
  - This group-wide defensive cooldown creates a zone of [[spell:196718]] at the **Devourer Demon Hunter's** location, granting all allies within it a 15% chance to avoid all damage from incoming attacks.

#### Hero Talents

- [[talent:135667]]
  
  - Consume has a 35% chance to grant you a stack of voidfall, after 3 stacks your next reap does massive aoe damage around it.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Harvesting 4 or more ‍Soul Fragments with ‍Reap has a 20% chance to cause your next ‍Consume to be instant cast and explode in a ‍Soulburst, dealing Cosmic damage to nearby enemies.
- **4-Set:** ‍Soulburst generates 8 ‍Soul Fragments and grants ‍Moment of Craving. ‍Reap deals 20% increased damage.

### Single-Target

:::tabs
:::tab [[talent:134251]]
### Opener

- The **Devourer Demon Hunter's** opener is rather easy, you just spam consumes untill 100 fury, dump it with Void ray and finish with an eradicate, repeat this untill you can enter [[talent:132282]].

:::rotation **Devourer Demon Hunter** single-target opener in Mythic+
```json
{
  "source_code": "JoZAwLXCC5jOHAAAXUlb0lGbgQDIhZXYpxWYixWZgM3b1x2cBI0I1KBAAIEg6cAAAAAACJGtSAAAkIVZwVWY0BCdol2cgMXZxVXZuNWZgUnb0lGbsBSNwAyUvVHbzBgQFRpEAAAACEwZRPAAIEAACKgTBEAiuOAABgUBWBAAZgFBeIaAsADACJGtSAAAAAgQKRpE"
}
```
1. [[spell:473662]] Until 4 available souls [[spell:1226019]]
2. [[spell:473728]]
3. [[spell:1225826]] Repeat this sequence untill 50 Souls
4. [[spell:1217605]]  [[item:250215]] · [[item:241288]]
5. [[spell:1226019]]
6. [[spell:473728]]
7. [[spell:1221150]]
8. [[spell:1225826]]
9. [[spell:1217610]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

- Enter [[talent:132282]] after reaching 50 souls
- Cast [[spell:1213649]] in [[talent:132282]] on cooldown.
- Cast [[talent:132281@FAQAMyuE]]
- Cast [[talent:132287]]
- Cast [[spell:1213649]] outside of [[talent:132282]]
- Cast [[spell:1226019]] if you are at 4. souls to fish for Tier proccs.
- Cast [[spell:1226019]] if you are at 3 stacks of [[talent:135667]].
- Cast [[spell:1217610]]
- Cast [[spell:473662]]

:::

:::

### AoE

:::tabs
:::tab [[talent:134251]]
### Opener

- The **Devourer Demon Hunter's** opener is rather easy, you just spam consumes untill 100 fury, dump it with Void ray and finish with an eradicate, repeat this untill you can enter [[talent:132282]].

:::rotation **Devourer Demon Hunter** AoE opener in Mythic+
```json
{
  "source_code": "JoZAwLXCC5jOHAAAXUlb0lGbgQDIhZXYpxWYixWZgM3b1x2cBI0I1KBAAIEg6cAAAAAACJGtSAAAkIVZwVWY0BCdol2cgMXZxVXZuNWZgUnb0lGbsBSNwAyUvVHbzBgQFRpEAAAACEwZRPAAIEAACKgTBEAiuOAABgUBWBAAZgFBeIaAsADACJGtSAAAAAgQKRpE"
}
```
1. [[spell:473662]] Until 4 available souls [[spell:1226019]]
2. [[spell:473728]]
3. [[spell:1225826]] Repeat this sequence untill 50 Souls
4. [[spell:1217605]]  [[item:250215]] · [[item:241288]]
5. [[spell:1226019]]
6. [[spell:473728]]
7. [[spell:1221150]]
8. [[spell:1225826]]
9. [[spell:1217610]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

- Enter [[talent:132282]] after reaching 50 souls
- Cast [[spell:1213649]] in [[talent:132282]] on cooldown.
- Cast [[talent:132281@FAQAMyuE]]
- Cast [[talent:132287]]
- Cast [[spell:1213649]] outside of [[talent:132282]]
- Cast [[spell:1226019]] if you are at 4. souls to fish for Tier proccs.
- Cast [[spell:1226019]] if you are at 3 stacks of [[talent:135667]].
- Cast [[spell:1217610]]
- Cast [[spell:473662]]

:::

:::

## Deep dive

### Dead or Alive

The most important part of doing damage and being a useful part of your group is staying alive. With movement being a core part of your damage rotation you NEED to always be aware of your surroundings. Do not [[spell:1234796]], [[spell:1245412]] or [[spell:198793]] into frontal abilities or area of effect zones.

You cannot do damage while you are dead and neither can you stop abilities from going through.

Being able to execute the perfect rotation isn't going to help you if you are lying dead on the floor or if you need externals/healing that your tank would need otherwise.

### Making the most out of Soul Fragment 's

Always remember that Soul Fragment management is a crucial part of maximizing your DPS as **Devourer Demon Hunter**, staying in [[talent:132282]] for as long as possible should be your goal.  
THIS BEING SAID: There are 3 ways of collecting souls,

1. Casting [[spell:1226019]]
2. Auto collecting by too many being on the floor
3. Running over them  
   People tend to forget the second and third way which makes them waste massive amounts of fury and overcap a ton in [[talent:132282]] wasting significant amounts of uptime.  
   Even if it sounds alluring that your reap or eradicate damage is increased by the amount of souls you collect, it is sometimes smart to pick them up by hand to squeeze in another [[talent:132281@FAQAMyuE]] faster to not waste cooldown of [[talent:132278]] or squeezing in another [[talent:132281@FAQAMyuE]] at the end of meta while spamming [[spell:1217610]]'s and running over souls to gain fury and not waste globals on a non soul spawning ability like reap.  
   It also takes some time for the souls to hit you after casting reap as they are collected, walking towards them can help.

### Haste ?!

Even though **Haste** Sims pretty poorly on paper, it is a great stat for multi target scenarios as it smooths your gameplay out by a lot.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

:::tabs
:::tab Altar of Fangs
:::talents **Devourer Demon Hunter** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

#### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

#### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.

:::

:::tab Den of Nalorakk
:::talents **Devourer Demon Hunter** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

#### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

#### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
  
  
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Devourer Demon Hunter** Mythic+ Build in Murder Row
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

#### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

#### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

#### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Devourer Demon Hunter** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

#### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

#### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

#### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscar Arena
:::talents **Devourer Demon Hunter** Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

#### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

#### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents **Devourer Demon Hunter** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

#### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

#### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

#### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents **Devourer Demon Hunter** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

#### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

#### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Devourer Demon Hunter** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA",
  "code": "CicBIo1c2KfIEsPoy9fznypG4BA2MmZmZmZmBzMAAAAAAALzYMYGAAAAAAAEMjBzMzMzMzMzwMLmxYRLLMzMzs12MzMAmxAQAjBjZA"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

#### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

#### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

#### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Devourer Demon Hunter**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:132289]] as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - The **Void Emissary** usually is on the tank, make sure to cleave it down or main target it if it doesnt die fast enough.
- Xal'atath's Bargain: Oblivion
  
  - Collect all orbs that are flying into melee.
- Xal'atath's Bargain: Devour

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Devourer Demon Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Devourer Demon Hunter** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUQMkACKBMQABA"
}
```
**智力 ＞ 精通 ≥ 急速 ＞ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAgcBvj7wPrDZ1chNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAgcBX16wPrDZ1wYNYFA]] | Ula'tek |
| Shoulder | [[item:271535@DAQBAgcBzk74UAXV9A]] | Tier |
| Cloak | [[item:268253@BAQAAgcBYFA]] | The Coiled Altar |
| Chest | [[item:271540@DAQBAgcBJk74UAXU9A]] | Tier |
| Wrist | [[item:244576@DiQAAgcBYA8wPrzt1sUA]] | Crafting |
| Gloves | [[item:271538@BAQBAgcBOFgyXQA]] | Tier |
| Belt | [[item:268256@BiQAAgcB8z6QWNYF]] | The Coiled Altar |
| Legs | [[item:271536@DAQBAgcBFo6gVABfBB]] | Tier |
| Boots | [[item:244569@FATAAgcBPk7gBwDAjY7LgBzt1wgNbWySBA]] | Crafting |
| Ring 1 | [[item:268249@DiQAAgcB1j7wPrDZ14UA]] | Vashnik |
| Ring 2 | [[item:158366@DCRAAgcB1j7wPrjt1IoAOFA]] | Temple of Sehtraliss |
| Trinket 1 | [[item:250215@BgQAAgcBCKgTBA]] | Murder Row |
| Trinket 2 | [[item:270164@BAQAAgcBOFA]] | The Lost Explorers |
| Weapon | [[item:271092@DAQAAgcB_k7gVA]] & [[item:268211@DAQAAgcB_k7gVA]] | Ulatek & The Coiled Altar |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251140@BgQAA0QACKQQBA]] | Murder Row |
| Neck | [[item:251173@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAA0QACKQQBA]] | Voidcar Arena |
| Cloak | [[item:251132@BgQAA0QACKQQBA]] | Murder Row |
| Chest | [[item:251159@BgQAA0QACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:251135@BgQAA0QACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgRAA0QA2IjX1caJBFA]] | Murder Row |
| Belt | [[item:159317@BgQAA0QACKQQBA]] | Temple of Sethraliss |
| Legs | [[item:251130@BgQAA0QACKQQBA]] | Murder Row |
| Boots | [[item:159327@DgQAA0QApk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:273792@BgQAA0QACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:252258@BASAA0QAkVjNy4VNWiSQBA]] | Voidscar Arena |
| Trinket 1 | [[item:250215@BgQAA0QACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAA0QACKQQBA]] | The Blinding Vale |
| Weapon | 2x [[item:273778@AgQAAIoAOFA]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A-Tier** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B-Tier** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C-Tier** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **Junkyard** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### Embellishments

- 1x [[item:251513@DiQAAgcBvk7wPrjIv0RA]]
  
  - Best overall choice of stat budget.
- [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241322]] *-- maximum DPS.***
  
  
  
  - **[[item:241320]] *-- less DPS but more survivability.***
- **Food**
  
  - **[[item:242272]]**
  - **[[item:255845]]**
- **Combat Potion**
  
  - **[[item:241288]]**
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - **[[item:243734]] *-- default***
  - **[[item:243738]]**
- **Augment Rune**
  
  - **[[item:259085@AQAAAoF]]**
- **Sockets**
  
  - **[[item:240967]] *-- Unique***
    
    - **[[item:240890]]**
    - **[[item:240898]]**
    - **[[item:240906]]**
    - **[[item:240914]]**

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAAsQA]]  <br>[[item:244007@BAAAAsQA]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsQA]] |
| Chest | [[item:243977@BAAAAsQA]] |
| Wrist | [[item:275707@BAAAAsQA]] |
| Waist | [[item:275707@BAAAAsQA]] |
| Legs | [[item:240133@BAAAAsQA]] |
| Boots | [[item:244009@BAAAAsQA]] |
| Ring 1 | [[item:243957@BAAAAsQA]] |
| Ring 2 | [[item:243957@BAAAAsQA]] |
| Weapon | [[item:244031@BAAAAsQA]] |

:::

:::column
:::gear **Devourer Demon Hunter** Enchantments in Mythic+
```json
{
  "source_code": "JwFZIXQ9NGQAnk7ACAAAAsPNEEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYEBCo8TuDAAAAAQA_k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:244007]] | [[item:275707]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAsQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Devourer Demon Hunter** in Mythic+, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Nightelf
  
  - Provides nothing in Raid, but can be useful in Mythic+ in very niche situations.
- [[spell:202719]] -- Bloodelf
  
  - Removes 1 beneficial effect from hostile targets around you.
  - Generates 15 Fury.
- [[spell:256948]] -- Voidelf
  
  - Tear a rift in space. Reactivate this ability to teleport through the rift.

### Recommendation

It does not really matter which Race you chose for **Devourer Demon Hunter**, as both provide about the same DPS benefits, it is however advised to go Bloodelf as [[spell:202719]] might come in handy in some situations where you need a quick AoE purge and can be used to gain 15 Fury while you are out of range of any target in combat.

## Macros

Discover recommended macros for **Devourer Demon Hunter** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**@Cursor [[spell:1234796]] Macro - *Uses your [[spell:1234796]] at your cursor's location***

```wow-macro
/cast [@Cursor] Shift
```

**@Cursor [[spell:207684]] Macro - *Uses your [[spell:207684]] at your cursor's location***

```wow-macro
/cast [@Cursor] Sigil of Misery
```

:::

:::details Mouseover Macros
**@Mouseover Interrupt Macro - *Interrupts your Mouseover target if you have one, Interrupts your current target if you don't have a Mouseover.***

```wow-macro
/cast [@mouseover,harm,nodead][] Disrupt
```

**@Mouseover [[spell:217832]] Macro** **-** *[[spell:217832]]*'s ***your Mouseover target if you have one, [[spell:217832]]***'s ***your current target if you don't have a Mouseover.***

```wow-macro
/cast [@mouseover,harm,nodead] [] Imprison
```

**@Mouseover [[spell:1234195]] Macro - *Stuns your Mouseover target if you have one, stuns your current target if you don't have a Mouseover.***

```wow-macro
/cast [@mouseover,harm,nodead] [] Void Nova
```

:::

:::details General Macros
**@Player [[spell:207684]] Macro - *Uses your [[spell:207684]] at your current location***

```wow-macro
/cast [@Player] Sigil of Misery
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Devourer Demon Hunter**, outlining which addons are used and how they are utilized in Mythic+ to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/nicememesuimidnight-1024x681.png>)

**Devourer Demon Hunter** Interface in Mythic+

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
Demon Hunters can now equip daggers.

- *Developers' notes: This will allow Devourer Demon Hunters to acquire and use daggers with Intelligence on them.*

**Devourer**

- *Developers' notes: We're reducing the scaling of Devourer's Mastery: Monster Within to help other stats to compete and compensating with an overall ability damage buff. Between that and a few more targeted changes, we expect damage during Void Metamorphosis to be slightly reduced while damage outside of Metamorphosis is significantly increased.*
- Mastery: Monster Within has been updated – Bonus damage during Void Metamorphosis reduced by 66%.
- All ability damage increased by 32%.
- Collapsing Star damage increased by 12%.
- Eradicate damage reduced by 6% and secondary target damage reduced by 15%.
- Consume damage increased by 60% (does not affect Devour).
- Void Metamorphosis now increases Void Ray damage by 40% (was 67%).
- Impending Apocalypse now causes each Collapsing Star to grant 20% increased damage to the next one (was 30%).
- Hungering Slash now properly gives a temporary charge of Vengeful Retreat rather than giving a free cast and also resetting its cooldown.
- Hero Talents
  
  - Annihilator
    
    - Otherworldly Focus now increases Collapsing Star and Voidfall Meteor damage against a single target by 30% (was 35%).
    - Final Hour now causes Voidfall bonuses to persist for 6 seconds (was 8 seconds).

:::

:::

## FAQ

:::accordion
:::details Q: How do i avoid missing Collapsing Stars?
A: Make sure to pre-plan accordingly, since you lose all your souls if you cancel your cast.  
1. Position properly before the cast, move out of any swirly and make sure u dont have to move  
2. Target the highest or atleast a high health target so it does not die before u finish the cast  
3. !!!DO NOT SPAM THE BUTTON!!! as it tends to bug it out for ping reasons

You rather lose a global than cancelling a Collapsing star cast by mistake.

:::

:::

---

### Credits

Written By: **Nicememes**

Reviewed By: **Verb**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1

**2026-06-22** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-01-20** Updated for patch 12.0



:::
