欢迎来到魔兽世界12.1版本**守护 德鲁伊** 大秘境攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚入门、从80级开始练级的新手吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 大秘境
**单体** · 3/5 · 中等

范围伤害 · 3/5 · 中等

功能性 · 5/5 · 优秀

生存能力 · 4/5 · 强

机动性 · 2/5 · 弱



:::

:::

:::column
:::gear **守护 德鲁伊 大秘境 最佳装备（Best in Slot）**
```json
{
  "source_code": "JUoAwDEaAc__AEwAmQggQEAAvj7AX16ACKwF2gVABk-FEAQEBAg_sOg_sOAj1kjAYFQAmSCBCgQBAUTuDIoAOFwVVPQArGgE4EAAJk7ACKgTBEA4XQAgIUQNUIoAYFQAnGgHMUAAhubBPAXwXQQAZt7AGgQAAYBwDciqDEPuDIoALFQAgt7AEWRF44PrDcbNLFQApSCBAgQBAEwV8QP1DEg6XQgAJEAAvk7A-zaADEAGMEw4uJgRVAAFU9BBAgQAFkDBB8VEMABWBEQ3X0AGAhVABc7FEIACBAQP5OggCgVA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271526]] | [[item:244021]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240894]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245782]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**守护 德鲁伊**，你可以使用野性守护，当你使用[[spell:77758]]和[[spell:33917]]时，有几率召唤一个守护之魂来攻击你的目标。

**等级2** 使你的精通和[[talent:103191]]伤害提高。 **等级3** 重置你的 [[spell:77758]] 和 [[spell:33917]] 的冷却时间，每当你触发一次 野性守护。此外，你还会获得一次使用机会：野性守护在每次 [[talent:103201]] 之后，你可以按需将其激活。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-guardian-mxr.webp>)

野性守护

:::

:::

### 核心改动

以下为你整理从《地心之战》到 至暗之夜 的重要职业改动，帮你保持信息更新。如果想更详细地了解 **全部** 改动，请查看我们的 **本补丁改动** 部分。

- 专精天赋树
  
  - 新技能 [[talent:135336]]
    
    - 对目标施加一个持续 8 秒的 DOT，你每次施放 [[spell:33917]] 都会使其延长 1 秒。
    - 它取代了 [[spell:8921]]，这使得同时拉多组怪变得困难得多。因此，不推荐在 大秘境 中选择该天赋。
  
  
  
  - 新被动 [[talent:135490]]
    
    - 使 [[spell:33917]] 获得第二层充能。
    - 当在 80 点或以上怒气施放时，[[talent:103202]] 触发 [[talent:103190]] 的几率翻倍。
    - 这大幅提升了怒气生成，并因为有更多高影响力的按键，减少了填充技能 [[talent:103301]] 的施放次数。
  - 新被动 [[talent:103222]]
    
    - 允许 [[talent:103202]] 最多消耗额外 50% 的怒气，并造成最多 100% 的额外伤害。
    - 在怒气较高时施放会提升 [[talent:103202]] 的效果。
    - 与 [[talent:135490]] 一起，强烈促使你只在 80 点以上怒气时才施放 [[talent:103202]]。
  - 新技能 [[talent:114701]]
    
    - 重置 [[spell:77758]] 的冷却时间，并允许其在 12 秒内额外叠加 5 次。
    - 结束时，多余的 [[spell:77758]] 层数会立即造成其伤害。
  
  
  
  - [[talent:114700]] 
    
    - 天赋树中的位置得到调整，即使玩 [[talent:123301]] 也更容易选择它
  - [[talent:114698]]
    
    - 现在最多可叠加 4 次，这是一项很好的体验优化。
- **职业天赋树**
  
  - [[talent:103309@AJwCCA]] 经过了重做。它现在是一个 2 分钟冷却的技能，其效果取决于你当前的形态：
    
    - 在人类形态下，它对目标及其周围最多 5 名盟友施放强化的 [[talent:103283]]。
    - 在 [[spell:768]] 形态下，它对你的目标施加强化的 [[spell:274837]]——一个高伤害的单体流血效果。
    - 在 [[talent:103286@AJwCCA]] 形态下，它在 8 秒内对你周围 40 码范围内的敌人造成 范围伤害 伤害，类似于 [[spell:191034]]。
- **已移除**
  
  - [[spell:400222]] 
    
    - 没有这个天赋，[[talent:103305]] 变成一个纯粹的防御性怒气消耗技能，不造成任何伤害。
  - [[spell:135288]]
    
    - [[talent:103202]] 不再有免费触发，加上 [[spell:400222]] 的移除，意味着你现在必须消耗怒气施放 [[talent:103202]] 来主动输出伤害。

## 英雄天赋

- 至臻天赋的改动加上第二赛季的新套装奖励进一步强化了 [[talent:123295]] 的玩法循环，使得卡CD按下 [[spell:77758]] 的价值更高。[[talent:123301]] 也相差不远，但它需要更复杂的循环，且输出提升微乎其微。因此，我们推荐在M+中游玩 [[talent:123295]]。

:::tabs
:::tab [[talent:123301]]
- [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 当它触发时，[[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 会在20秒内或直至使用前替换你的 [[spell:6807]]。
- [[talent:117218]]
  
  - 生命值的提升仅在 [[spell:22842]] 增益存在期间生效。
- [[talent:117220]] + [[talent:117216]]
  
  - [[talent:117220]] 会施加于所有被 [[spell:441602@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 命中的目标，并为你提供10%的伤害减免。
  - 通过这一天赋组合，[[talent:117216]] 只需按正常循环操作即可被动延长该流血效果和伤害减免。
- [[talent:117207]]
  
  - [[spell:441685]] 在你变出 [[spell:5487]] 时提供生命值和护甲，例如为了使用 [[talent:103309@AJwCCA]] 而变形时。
    
    - 当你变回 [[spell:5487]] 时，该增益会被取消。
  
  
  
  - [[talent:103298]] 和 [[talent:103305]] 在脱离 [[spell:5487]] 后均不会消失。
- [[spell:441835@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 该提示文字具有误导性，每个受到初始伤害命中的目标都有25%的几率触发 [[spell:441583@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]。这意味着在大规模拉怪时，你很可能会在每次施放技能后都获得一次触发。

12.0版本新增了3个英雄天赋。

- [[talent:135980@FJQA-thBLIA]] 使你的自动攻击触发 [[talent:117206@FAQAychA]] 的几率提高 30%。
- [[talent:117219@AJwCCA]] 使受到 [[talent:117220]] 影响的目标受到你的其他流血效果（例如 [[talent:103277@FAQAKFjB]]、[[talent:103300]] 和 [[spell:77758]]）的伤害提高 15%。
- [[talent:135979@AJwCCA]] 可以从你的单体近战技能中随机触发，造成物理伤害并产生 5 点怒气。

:::

:::tab [[talent:123295]]
- [[spell:424058@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 这使得将所有敌人拉入 [[talent:114700]] 区域内坦克变得非常重要。
- [[talent:117204]]
  
  - 只要敌人处于你的 [[talent:114700]] 区域内，该效果就会持续刷新，这意味着在其结束后或敌人走出区域后，效果还会再持续6秒。
- [[talent:117192]] 
  
  - 由于 [[spell:8921@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 几乎常驻于敌人身上，这是一个非常实用的被动减速。
- [[talent:117183]] + [[talent:117177]]
  
  - 这一天赋组合使 [[spell:77758]] 能够为 [[talent:114700]] 提供冷却缩减，大幅提高其使用频率。
- [[talent:117176]]
  
  - 触发的 [[spell:211545@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]] 没有内置冷却时间，并且还会对命中的目标施加 [[talent:117204]]。
- [[spell:424113@FJQDQBVAHCmAb3mAychAHcmAMunAZa4AU8BByNwA6UJBKFjB1zwB3zwBLIA]]
  
  - 你身上的 [[talent:114700]] 增益并不依赖于该区域，即使你离开地上的区域，它依然会为你提供治疗和精通加成。
  - 其他收益（如上文提到的天赋）仅在敌人处于该区域内时生效。

12.0版本新增了3个英雄天赋。

- [[talent:135978@AJwCCA]] 使 [[spell:77758]] 有几率向你的目标施放一个 [[talent:103278]]。
- [[talent:135977@AJwCCA]] 使 [[talent:114700]] 将你造成的 奥术 伤害提高10%。
- [[talent:135976@FJQA-thBLIA]]
  
  - 使 [[talent:103191]] 的伤害提高10%
  - 使 [[talent:114700]] 对你的主要目标造成的伤害提高30%

:::

:::

## 天赋

:::tabs
:::tab [[talent:123295]]
:::talents **守护 德鲁伊** [[talent:123295]] 大秘境
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 何时使用此专精

除非另有说明，这是任何 大秘境 地牢的默认配置。你需要根据地下城所需的工具技能来调整职业天赋树。为了方便起见，特定地下城的天赋配置可在 **地城** 部分查看。

### 改变游戏玩法的天赋

探索专精和职业天赋树中所有会显著改变你游戏方式的天赋。本节将简要概述这些天赋及其应用；如需更详细的了解，请查看下方的循环和深入解析部分。

#### 专精树

- [[spell:377811]]
  
  - 使你额外获得一层 [[spell:22842]] 充能，并根据你已损失的生命值提高治疗量。这对冷却管理和额外治疗都非常出色。
- [[spell:204053]]
  
  - 使维持 [[spell:77758]] 层数的同时也能提高你造成的伤害，并提供防御价值。
- [[spell:393414]]
  
  - 当你消耗怒气时，会为 [[spell:102558]] 提供冷却缩减

#### 职业树

- [[talent:103309@AJwCCA]]：
  
  - 在单目标战斗中使用它之前，请确保先切换到[[spell:768]]，以施放[[spell:274837]]。
- [[spell:377847]]
  
  - 该技能冷却时间为120秒，当你的生命值降至45%以下时会触发一个[[spell:22842]]。需要注意的是，它会覆盖当前任何已激活的[[spell:22842]]，同样也可能被任何新施加的[[spell:22842]]所覆盖。
    
    - 留意冷却时间并避免重叠使用非常重要。
    - [[talent:128586]]可将冷却时间缩短至90秒

:::

:::tab [[talent:123301]]
:::talents **守护 德鲁伊** [[talent:123301]] 大秘境
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgFMzAsYGMgNLGgZmZ2gB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgFMzAsYGMgNLGgZmZ2gB"
}
```
:::

### 何时使用此专精

这是大秘境构建的[[talent:123301]]版本。

### 天赋调整

列出与默认构筑相比，职业树和专精树内的所有改动。

#### 英雄天赋

**已将**更改为[[talent:123301]]。欲了解更多信息，请访问上方的**英雄天赋**部分。

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:77758]]有20%的几率使你的下一个[[spell:33917]]造成100%的额外伤害。
- **4件套：** [[spell:77758]]召唤3根尖刺，每根刺穿一个目标造成自然伤害，并对附近最多5个敌人造成额外自然伤害，同时使[[spell:102558]]的持续时间延长0.5秒，最多延长5秒。

:::tabs
:::tab [[talent:123301]]
### 起手爆发

- 起手的目标是尽快施放[[spell:192081]]，以便尽早启动主动防御。随后，消耗[[talent:117206]]的触发效果，并让产生怒气的技能保持在冷却中。

:::rotation **守护 德鲁伊** [[talent:123301]] 起手（大秘境）
```json
{
  "source_code": "IgYAIlgQZLCAAAAABIUWKAAAAIkvvEQAPwgQi0xAFgABeCZAQwQABwprJAREggQfECQB2wQUuLAAZYTCWwMACVQvGUkAOAFUBcIYCsdbCIzFCcwZCw4eCkphDQxHEI3ADoTlEoUMGUPDHcPDHEiLTsgA"
}
```
1. [[spell:8921]]  [[spell:2649]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:33917]]  [[spell:192081]]
7. [[spell:77758]]
8. [[spell:33917]]
9. [[spell:441605]]
:::

### 优先级列表

请务必牢记这份清单，除非某些首领或场景需要你保留这里列出的一些技能

1. 冷却好了就使用 [[talent:114700]] 和 [[spell:102558]]。
2. 确保 [[spell:192081]] 始终保持至少 1 层在滚动。根据预期的承伤量，你可能需要叠到更高层数。
3. 使用 [[talent:117206]]。
4. 在怒气高于 80 时使用 [[talent:103202]]，以充分利用 [[talent:135490]]。
5. 保持 [[spell:77758]] 好了就开。
6. 保持 [[spell:33917]] 好了就开。
7. 使用 [[spell:8921]] 作为填充技能。

:::

:::tab [[talent:123295]]
### 起手爆发

- 起手的目标是尽快施放 [[spell:192081]]，以便尽早让主动防御开始运转。

:::rotation **守护 德鲁伊** [[talent:123301]] 起手（大秘境）
```json
{
  "source_code": "IkFSJIU2iAAAAAQACllCAAAAC57LBEwDMIkIdMQBIQgnQGAEMEQAc6aCQEBII0HhAUgNMEl7CAQG2gSfECAAAAAAC53GGA"
}
```
1. [[spell:8921]]  [[spell:2649]]
2. [[spell:77758]]
3. [[spell:204066]]
4. [[spell:102558]]  [[item:241308]]
5. [[spell:77758]]
6. [[spell:33917]]  [[spell:192081]]
7. [[spell:77758]]
8. [[spell:33917]]
9. [[spell:400254]]
:::

### 优先级列表

请务必牢记这份清单，除非某些首领或场景需要你保留这里列出的一些技能

1. 冷却好了就使用 [[talent:114700]] 和 [[spell:102558]]。
2. 确保 [[spell:192081]] 始终保持至少 1 层在滚动。根据预期的承伤量，你可能需要叠到更高层数。
3. 保持 [[spell:77758]] 好了就开。
4. 保持 [[spell:33917]] 好了就开。
5. 在怒气高于 80 时使用 [[talent:103202]]，以充分利用 [[talent:135490]]。
6. 使用 [[spell:8921]] 作为填充技能。

:::

:::

### 防御技能冷却

- [[spell:22812]]
  
  - 这是你冷却时间较短的首选防御技能。在走进首领、小怪或任何会造成伤害的目标时开启它从来都不是坏主意，而且由于冷却时间短，它是你在需要减伤时第一个按下的防御技能。
- [[spell:61336]]
  
  - 你最强大（提供 50% 伤害减免）但也是持续时间最短的防御技能，持续 6 秒。谨慎选择使用时机，但也不要囤着两层充能不用。留一层充能应对紧急情况总是好的，但囤着两层就是很大的浪费。
- [[spell:22842]] 
  
  - 你的强力自我治疗技能。你可以主动或反应性地使用它，唯一重要的是你要尽可能发挥它的全部潜力。不要仅仅因为它冷却好了就随便使用，如果你只受到少量伤害的话。是的，这个技能冷却时间很短，但如果你倾向于在任何受伤时都用它，你可能会在承受一次坦克大额伤害后发现没有任何充能。总的来说，在任何坦克机制之后或聚怪时使用它是最佳选择，因为它能帮助你在其他防御技能和 [[spell:192081]] 生效之前把血量拉起来。
- [[spell:192081]] 
  
  - 你的主动减伤和怒气消耗技能。更多详情请查看 **深度解析**。

### 化身：乌索克的守护者

- [[spell:102558]] 或 [[spell:50334]] 有很多用途，既可以作为输出冷却技能，也可以作为防御冷却技能。因此，通常情况下冷却好了就用。只有在特殊情况下才需要保留它，因为留着不用会让你损失大量收益。
  
  1. 它是一个强力的防御技能，可以帮你扛过一波伤害爆发。
  2. 保留它会导致 [[spell:393414]] 的冷却缩减进一步被浪费，所以一定要记得按这个按键。
  3. 它的进攻性收益也不容小觑。

## 深度解析

这篇深度解析讲解了 **守护 德鲁伊的** 生存能力**方面**

### 铁鬃的优化

[[spell:192081]]是你的怒气消耗技能和主动减伤。按下后会在 7 秒（若有 [[talent:135568]] 则为 9 秒）内基于你的敏捷提高你的护甲。需要注意的是，多次施放 [[spell:192081]] 会相互重叠并叠加，但持续时间不会增加、刷新或延长。

- 1. [[spell:192081]] 在第 0 秒按下
- 2. [[spell:192081]] 在第 3 秒
- 3. [[spell:192081]] 在第 5 秒
  
  - 现在你拥有 3 层 [[spell:192081]]，三层的持续时间各不相同，会像下方时间轴图标所示的那样在不同时间结束。
- 12 秒后，你将不再拥有任何 [[spell:192081]] 层数，尽管你在战斗的前 5 秒里按了 3 次。
- 理解 守护 德鲁伊 的主动减伤机制至关重要，因为你的护甲值以及相应的伤害减免会随着当前生效的 [[spell:192081]] 层数不断变化。

这里有一张图片展示 [[spell:192081]] 的运作方式。

:::timeline **守护 德鲁伊** 团队副本 铁鬃的优化
```json
{
  "source_code": "HYFu2Z3_UAQAEww_eAAAHAQndi4AAoAA_DHAFAADA8Pg_3AAUAABCEl7CAAACEl7CMQBGAQBFYABNAQBZAwBF0AOKAgAR5uAMAgAR5uAUAQA"
}
```
总时长：20 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 0 秒 | [[spell:192081]] | 上轨 |
| 3 秒 | [[spell:192081]] | 上轨 |
| 5 秒 | [[spell:192081]] | 上轨 |
| 7 秒 | [[spell:192081]] | 下轨 |
| 10 秒 | [[spell:192081]] | 下轨 |
| 12 秒 | [[spell:192081]] | 下轨 |
| 13 秒 | [[spell:192081]] | 上轨 |
| 20 秒 | [[spell:192081]] | 下轨 |
:::

### 铁鬃 护甲

- [[spell:192081]] 护甲正在减少你受到的物理伤害，在大多数情况下这只是近战挥击。流血和魔法 DOT 不受护甲影响。
- 物理伤害减免有 85% 的硬上限。这相当于同时保持约 7-8 层 [[spell:192081]]（有 [[spell:360827]] 时约 4 层），因此达到该数值后再无脑刷 [[spell:192081]] 是无用的。
- 然而，由于护甲缩放机制，持续保持 1 层 [[spell:192081]] 比瞬间用掉 3 层然后没有任何层数拥有更高的整体防御价值。你叠加的护甲越多，每一层新增护甲的效果就越低。
- 因为你的物理伤害减免很高，所以在应对魔法伤害、流血和其他 DOT 时会吃力得多。对于这些伤害，正确使用 [[spell:22842]] 非常重要。

### 狂暴回复

- [[spell:22842]] 是你作为守护 德鲁伊 唯一的自疗技能，对保命非常重要。
- 一般来说，[[spell:22842]] 的冷却时间相对较短，只有36秒（受急速影响降低），这让你很容易一受到伤害就想按它。这往往会导致问题：之后你受到的伤害太大，治疗者无法覆盖，或者你需要一种快速回血的方式。使用它时，留意接下来可能发生的情况非常重要。
- 此外，你还需要决定如何使用 [[spell:22842]]：是主动使用，在应对机制前保持满血；还是在机制之后被动使用，把自己奶回安全血线。通常，这完全取决于你当前面对的战斗所造成的伤害量。如何抉择来自于游戏经验和临场判断。
- 当你使用 [[spell:377811]] 时，你有2层 [[spell:22842]]，一般来说最好始终保留一层以备紧急情况，另一层则更自由地使用，这样就不会浪费冷却回复。
- 关于 [[spell:22842]] 的注意事项：
  
  - [[spell:377847]] 不会消耗你的 [[spell:22842]] 的层数，但如果你在它触发前一刻按下，会覆盖掉当前的那个 + 如果你使用 [[spell:22842]]，而它在你的触发效果覆盖了你之前按下的那个之后触发，基本上就浪费了大量价值。
  - [[spell:102558]] 会返还 [[spell:22842]] 的全部两层，并使其在持续时间内完全没有冷却。记住这一点，它可能会救你一命。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 地下城

**← 滚动查看更多 地下城→**

:::tabs
:::tab 毒牙祭坛
:::talents **守护 德鲁伊** 大秘境 毒牙祭坛
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 拉维

- 房间中散布着3个腐肉堆，确保在boss能量降到0%之前将他拉到其中一个没有发红光的腐肉堆旁，以便他[[spell:1296216]]在其中。
- 在[[spell:1296216]]期间，注意地面上的[[spell:1307703]]，如有需要请进行吸收。

#### 扭缠盘蛇

- boss会对你施放[[spell:1298949]]，造成物理伤害并将你轻微击退。
- 打断[[spell:1310358]]。
- 在[[spell:1299053]]期间，尽可能快且远地远离boss。

#### 祖尔加

- 每当boss施放[[spell:1300872]]时，务必站在他与[[spell:1300894]]之间进行吸收。
- 躲避[[spell:1283832]]所产生的任何斧头。
- [[spell:1301350]]是一个0.5秒的快速施法，造成物理伤害，是本场战斗的坦克重击技能。
- 当队友被[[spell:1301413]]锁定时，移动到boss与被锁定玩家之间的直线上，这会减少你的队友所受到的伤害。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1294557]] - 原始毒蛇
  - [[spell:1307567]] - 乌拉特克神选者

- 额外注意这些施法：
  
  - [[spell:1306911]] - 仪式首领
  - [[spell:1294845]] - 振响的扭缠蛇
  - [[spell:1294934]] - 晋升之蛇

:::

:::tab 纳洛拉克的洞穴
:::talents **守护 德鲁伊** 大秘境 纳洛拉克的洞穴
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 囤宝狂人

- 每当boss施放[[spell:1234233]]时，他会在地面上召唤[[spell:1234740]]，务必帮助你的队伍进行吸收。

#### 寒冬哨卫

- 在boss施放[[spell:1235783]]之后，将他拉到一个被召唤的小怪身上，并打断[[spell:1235829]]。

#### 纳洛拉克

- 当首领开始施放 [[spell:1243569]] 时，确保你站在 祖尔加拉 提供的 [[spell:1243856]] 中。施法结束后，首领会立即接一个 [[spell:1297797]]，在他面前生成一个大圈。作为坦克，走进圈中吸收这一击。
- 在 [[spell:1243002]] 期间，跑向任何试图接近 祖尔加拉 的 纳洛拉克的回响，用你的角色触碰它以阻止其靠近她。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1297696]] - 地语看护者
  - [[spell:1309919]] - 酷寒重殴者
  - [[spell:263607]] - 雷缚秘法师
  - [[spell:9532]] - 神灵代言人纳尼亚

- 请格外注意以下施法：
  
  - [[spell:1238687]] - 饥渴之灵

:::

:::tab 密谋小径
:::talents **守护 德鲁伊** 大秘境 密谋小径
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 凯斯媞亚·魔力之心

- 咬咬 会对施放一个正面锥形 [[spell:1253811]]，请务必不要把它的方向对准你的队友；在引导/施法结束前，你也可以向侧面跑开躲避。
- 凯斯媞亚 会不时施放多个 [[spell:1264095]]，它们会施放 [[spell:1264106]]，你可以通过打断或眩晕来取消它们的施法。

#### 赞恩·刃悲

- 首领会对你施放 [[spell:1222795]]，造成物理伤害并在你身上留下一个持续伤害 [[spell:474515]]。
- 当你被 [[spell:474545]] 点名时，尝试躲在房间里的木桶后面。

#### 歼灭者萨祖克斯

- [[spell:1214781]] 是这场战斗中主要的坦克重击机制，它是一个正面锥形技能，不要把它对准你的小队，它会给你留下一层使你受到的治疗效果降低80%、持续8秒的减益。
- 在 [[spell:1214637]] 之后，尽量在首领的斧头附近拉住他。
- 在 [[spell:1223533]] 期间，尽量沿着房间边缘风筝他，以减少 [[spell:474231]] 的扩散。

#### 利希尔·烬怒

- 首领将使用[[spell:1220899]]，你需要在这场战斗的全程中风筝这只地狱火。
- 尽可能打断[[spell:474375]]。
- 每当[[spell:474408]]出现时，就要抓住它的仇恨。
- 当首领召唤[[spell:1214675]]时，等待它完成[[spell:1217345]]的施法后再进入传送门。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1216570]] - 凶邪的法师
  - [[spell:1201554]] - 诱惑的萨亚德
  - [[spell:1214922]] - 愤怒卫士掠夺者
  - [[spell:1214980]] - 邪能祈求者

- 请格外注意以下施法：
  
  - [[spell:1216529]] - 受贿的队长

:::

:::tab 夺目谷
:::talents **守护 德鲁伊** 大秘境 夺目谷
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 光明众花

- 确保对全部三个首领保持仇恨，并尽可能把它们聚在一起，以便进行顺劈和高效输出，因为它们共享同一个生命值池。
- 梅提克 会对你施放 [[spell:1234753]]，这是战斗中坦克伤害的主要来源。
- 尽量打断 科兹齐特 施放的 [[spell:1235616]]。
- 科兹齐特 还会施放 [[spell:1235564]]，需要你站在三朵光蕊花之一中来分摊伤害。

#### 圣光猎手伊库兹

- 每次首领施放 [[spell:1236746]] 时，务必确保自己不被击退到地上的任何树根中。如果你被击退远离团队，请尽快归位，因为该技能发生 4 秒后所有人都会被定身。你需要与团队集合在一起，以便尽快顺劈清理树根。

#### 护光者鲁伊亚

- 这个首领有3个不同的阶段，它总是以枭兽阶段开始。
- 在这个阶段你只需要打断[[spell:1239821]]并躲避由[[spell:1239824]]创造的[[spell:1239830]]。
- 在下一阶段，熊形态 由于 [[spell:1272265]]，他的近战攻击变得更加危险。此外，如果你被 [[spell:1240210]] 选为目标，请确保不要过多移动，这样你和你的队友会更容易躲避。
- 最后一个阶段在40%时开始，此时首领进入哈拉尼尔形态并引导[[spell:1241067]]，快速连发施放它的所有技能。

#### 兹欧凯特

- 每次首领施放 [[spell:1246372]] 时，它会在自己脚下召唤小怪，务必尽快拉住这些小怪的仇恨。
- [[spell:1246858]] 之后会有法球飞向首领，去吸收这些法球，不要让任何一颗碰到首领。
- 此外，首领在战斗中还会使用 [[spell:1247685]] 作为坦克重击技能，造成魔法伤害，将你击退，并给你留下一个流血效果，每秒造成物理伤害，持续 10 秒。
- 当小怪死亡后，你需要调整首领的站位，使其用以你为目标的 [[spell:1246607]] 技能命中所有小怪。当小怪被命中时，它们会被彻底移出战斗；如果没有被命中，下次首领施放 [[spell:1246372]] 时，它们会与新召唤的小怪一起复活。

### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:1301834]] - 光耀播法者
  - [[spell:1238294]] - 光羽瓣翼鸟

- 请格外注意以下施法：
  
  - [[spell:1237855]] - 翠绿林地守护者

:::

:::tab 虚空之痕竞技场
:::talents **守护 德鲁伊** 大秘境 虚空之痕竞技场
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 塔兹拉尔

- 每当首领施放 [[spell:1296889]] 时，务必确保你的 [[spell:1222098]] 不要与其他人的重叠。
- 它还会对你施放 [[spell:1297017]]，造成大量魔法伤害并将你击退。
- 每次 [[spell:1300259]] 之后，务必躲避法球。

#### 阿特洛苏斯

- [[spell:1222642]]是这场战斗中的坦克重击机制，它造成魔法伤害，并留下一个持续10秒的减益效果，使你受到更多魔法伤害。
- 每当首领施放[[spell:1262497]]时，它会召唤一个剧毒蠕行者，它会锁定你，尽量将这个剧毒蠕行者与首领一起风筝，以最大化顺劈输出。

#### 煞戎努斯

- 首领会对着你施放 [[spell:1311923]]，这是一个持续5秒的施法，此时尽量不要过多移动，以便队友能够躲避。
- 偶尔首领会用 [[spell:1222755]] 点名你的一名队友。作为坦克，你的职责是站在首领与被点名玩家之间，在弹射物到达队友之前将其拦截。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1299938]] - 虚触法师
  - [[spell:1298899]] - 被统御的斗士
  - [[spell:1249621]] - 暴怒的三叶虫
  - [[spell:1233398]] - 千噬兽尖啸者

- 请格外注意这些施法：
  
  - [[spell:1300243]] - 贪噬残虐者

:::

:::tab 诸王之眠
:::talents **守护德鲁伊** 大秘境诸王之眠
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 黄金风蛇

- 首领会用 [[spell:265910]] 打你，造成物理伤害。
- 在首领施放 [[spell:265923]] 之后，如有需要务必风筝它，以免小怪接近它。

#### 殓尸者姆沁巴

- 每当首领施放其主要技能 [[spell:267702]] 时，注意房间两侧的墓穴，点击正在摇晃的那个，因为你的队友之一会被关在里面。

#### 部族议会

- 征服者阿卡阿里 会对我们使用 [[spell:266237]]，将你击退，并使你随后10秒内受到的物理伤害提高200%。
- 帮助队友分担 [[spell:266939]]。
- 在与 智者扎纳扎尔 的战斗中打断 [[spell:267273]]。
- 在他施放 [[spell:267060]] 之后，试着把他拉到爆炸图腾上面。

#### 始皇达萨

- 由于 [[spell:268586]] 和 [[spell:1303267]]，这个首领会对坦克造成大量伤害，所以务必使用你的防御技能。
- 在整个战斗中尽可能躲开 [[spell:1302945]]。
- 当 莱班 激活时，务必尽可能打断 [[spell:269369]]。
- 提扎拉 在激活时也会开始对你施放 [[spell:1303488]]，为这场战斗又增加了一层坦克伤害。

### 小怪攻略

- 本地下城中需要打断的重要技能有：
  
  - [[spell:1294815]] - 复活的妖术师
  - [[spell:270920]] - 瓦西女王
  - [[spell:270901]] - 姆巴拉侍臣
  - [[spell:270492]] - 幽灵妖术 牧师

- 请格外注意以下施法：
  
  - [[spell:1297918]] - 阿阿库尔王
  - [[spell:1302028]] - 幽灵蛮兵
  - [[spell:270514]] - 幽灵蛮兵
  - [[spell:1309385]] - 祖尔的暗影

:::

:::tab 红玉新生法池
:::talents **守护 德鲁伊** 大秘境 红玉新生法池
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 梅莉杜莎·寒妆

- 首领会对着你施放[[spell:372808]]，这是一个可打断的施法，因此务必在冷却时就打断它；如果你或队友无法打断，请开启减伤技能。
- 首领偶尔还会施放[[spell:396044]]，施法结束后，将首领带离地面上的圆圈。
- 当首领生命值降至66%和33%时会施放[[spell:373037]]，务必拉住刷新的小怪的仇恨。

#### 柯姬雅·焰蹄

- 该首领的主要坦克机制是[[spell:372858]]，这是一个持续3秒的施法。
- 务必始终将首领拉在[[spell:372863]]所产生的炎缚火焰风暴旁边进行坦克。

#### 基拉卡与厄克哈特·风脉

- 首领会通过[[spell:381512]]对你施加一个负面效果，使你受到的下一次[[spell:381512]]伤害提高，因此请提前与你的治疗沟通好，每次你被此机制命中时他都必须为你驱散。
- 每当巨龙基拉卡落地后，请离开[[spell:381525]]。

### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:372743]] - 闪霜织寒者
  - [[spell:384197]] - 拜荒织烬者
  - [[spell:392576]] - 暴风引导者

- 需要格外注意以下施法：
  
  - [[spell:372730]] - 原始主宰
  - [[spell:372047]] - 亵渎者德拉加尔
  - [[spell:392394]] - 烈焰之咽
  - [[spell:392395]] - 雷霆之颅

:::

:::tab 塞塔里斯神庙
:::talents **守护 德鲁伊** 大秘境 塞塔里斯神庙
```json
{
  "source_code": "CiGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB",
  "code": "CiGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAAAAAAgZmxsMmZMziZZGMLbDMMMaimZmlZmZmZZMDAAAAAAzMbzAW2mZwYWGATNzysMzMDAgNMzAsYGMgNLGgZmZWgB"
}
```
:::

### 首领攻略技巧

#### 阿德里斯和阿斯匹克斯

- 每当阿斯匹克斯施放[[spell:1310712]]时，确保不要与队友站在一起。
- 阿德里斯会用[[spell:1288049]]聚焦你的一名队友，尽量帮忙分担这个技能，以分摊伤害并减轻对被点名队友的整体影响。
- 它还会施放[[spell:1288428]]，使其在8秒内造成更多近战伤害，如有必要请使用你的防御技能。

#### 米利克萨

- 首领会周期性地施放[[spell:1290797]]，这是一个坦克重击技能，命中时造成物理伤害，并留下一个持续7秒、每秒跳一次自然伤害的持续伤害效果。
- 在[[spell:264206]]期间，务必迅速对所有被召唤的小怪建立仇恨。

#### 加瓦兹特

- 在这场战斗中，你唯一要做的就是每次[[spell:1309525]]施放后移动首领的位置，因为它会在首领脚下召唤一个[[spell:1291815]]。

#### 塞塔里斯的化身

- 务必抢到堕落守护者的仇恨，它们偶尔会对你施放[[spell:1300803]]。此外，你也可以把它拉到精华污染者上面。

### 小怪攻略

- 本地下城中需要重点打断的技能有：
  
  - [[spell:1293307]] - 无信征服者
  - [[spell:9532]] - 灌注能量的唤雷者
  - [[spell:13729]] - 扭曲的妖术师

- 请格外注意以下施法：
  
  - [[spell:1291468]] - 沙怒石拳战士
  - [[spell:1308546]] - 宝珠守望者

:::

:::

### 词缀

- +2词缀
  
  - 林多尔米的指引
- +5 词缀——每周轮换
  
  - 萨拉塔斯的交易：升腾
  - 萨拉塔斯的交易：虚空之缚
  
  
  
  - 萨拉塔斯的交易：吞噬
  - 萨拉塔斯的交易：脉冲星
- +6词缀
  
  - 移除林多尔米的指引。
- +7 词缀——每周交替出现
  
  - 残暴
  - 强韧
- +10 词缀 *——两个词缀同时存在。*
  
  - 残暴
  - 强韧
- +12词缀
  
  - 萨拉塔斯的诡计 *——替换+5词缀*

以下是为 **守护 德鲁伊**应对不同 大秘境 词缀提供的一些实用技巧。

- 萨拉塔斯的交易：升腾者
  
  - [[talent:103316]] 尽可能多地获取法球。
- 萨拉塔斯的交易：虚空缚誓
  
  - 的 **虚空大使** 会跟随你；让它保持在近战范围内以进行顺劈，并在其可用时以它为目标。
- 萨拉塔斯的交易：吞噬
  
  - 每当该效果施加到你身上时，就对自己使用 [[talent:103293]]。

## 属性优先级

作为 **守护 德鲁伊**，请了解你的次要属性优先级以及发挥最佳表现所需的第三属性。如需更详细的信息，请访问 **[属性与数值](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **守护 德鲁伊** 大秘境 属性
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

> **在大多数情况下，物品等级更高的装备更好。 想要准确了解应该装备什么物品，你应该使用[Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"属性优先级"只是一个起点，很容易会因你的个人装备而发生变化。**

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **闪避** - 可有效降低“**范围伤害**”技能所造成的伤害。
- **吸血** - 通过造成伤害提供额外治疗。
- **加速** - 小众的第三属性，但可能非常有用，过去也曾多次证明其价值。它能让应对某些机制变得轻松许多。

总体而言，**吸血**对坦克来说非常强力，尤其是在范围伤害环境中，它可能是你所能拥有的最好属性。  
**闪避**很好用，但大多数时候坦克并不难在典型的范围伤害技能下存活。

## 装备

:::tabs
:::tab 最佳配装
| 槽位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | 乌拉特克 |
| 颈部 | [[item:268265@BERAAgGA-z64PrDj1kjAYFA]] | 乌拉特克 |
| 肩部 | 将 [[item:251223@DgQAAgGAJk7IoAOF]]   <br> 转换为 [[item:271526@DgQBAgGA1k7IoAOFwVVP]] | 虚空之痕竞技场 催化剂 |
| 披风 | [[item:268253@BgQAAgGACKAWBA]] | 盘卷祭坛 |
| 胸部 | [[item:271531@DgQAAgGAJk7IoAOF]] | 瓦什尼克套装徽记 |
| 护腕 | [[item:244576@FiQAAgGAWA8ciqj_sO3WzSB]] | 制造业 |
| 手套 | 将 [[item:251124@BgQAAgGACKgTBA]]   <br> 转换为 [[item:271529@BgQBAgGACKgTBQP1DA]] | 密谋小径 催化剂 |
| 腰带 | [[item:268256@BiQAAgGA-z6IoAYF]] | 盘卷祭坛 |
| 腿部 | 将 [[item:268225@DgQAAgGAhu7IoAYF]]   <br> 转换为 [[item:271527@DgQAAgGAhu7IoAOF]] | 盘卷祭坛 催化剂 |
| 靴子 | [[item:244569@HgQAAgGAWA8ciqT84OCKwSB]] | 制造业 |
| 戒指1 | [[item:268266@DkQAAgGAvk74Prj_sOCKgTB]] | 尼姆瑞莎·唤波者 |
| 戒指2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | 诸王之眠 |
| 饰品1 | [[item:270164@BgQAAgGACKgTBA]] | 迷失的探险者 |
| 饰品2 | [[item:270175@BgQAAgGACKAWBA]] | 乌拉特克 |
| 武器 | [[item:268215@DgQAAgGA9k7IoAYF]] | 乌拉特克 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:273791@BgQAAgGACKQQBA]] | 毒牙祭坛 |
| 颈部 | [[item:251173@BgQAAgGACKQQBA]] | 纳洛拉克的洞穴 |
| 肩部 | 兑换 [[item:251223@BgQAAgGACKQQBA]] | 虚空之痕竞技场 |
| 披风 | [[item:193763@BgQAAgGACKQQBA]] | 红玉新生法池 |
| 胸部 | [[item:251226@BgQAAgGACKQQBA]] | 虚空之痕竞技场 |
| 护腕 | [[item:251135@BgQAAgGACKQQBA]] | 密谋小径 |
| 手套 | [[item:251124@BgQAAgGACKQQBA]] | 密谋小径 |
| 腰带 | [[item:159301@BgQAAgGACKQQBA]] | 诸王之眠 |
| 腿部 | [[item:159313@BgQAAgGACKQQBA]] | 诸王之眠 |
| 鞋子 | [[item:251153@BgQAAgGACKQQBA]] | 纳洛拉克的洞穴 |
| 戒指 1 | [[item:273792@BgQAAgGACKQQBA]] | 毒牙祭坛 |
| 戒指 2 | [[item:159459@BgQAAgGACKQQBA]] | 诸王之眠 |
| 饰品 1 | [[item:250228@BgQAAgGACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250215@BgQAAgGACKQQBA]] | 密谋小径 |
| 武器 | [[item:158370@BgQAAgGACKQQBA]] | 塞塔里斯神庙 |

:::

:::

### 饰品

以下是从地下城和团队副本中可获得的后毕业阶段饰品的排名。请注意，上文推荐的饰品是以伤害最优为目标的；如果你不在乎伤害、只想活下去，建议使用类似 [[item:270160@BgQAAIEACKgTBA]] 这样的饰品。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270175@BgQAAgGACKAWBA]] |
| **A级** | [[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270165@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B级** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C级** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:270173@BgQAAgGACKAWBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **垃圾级** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### 美化饰品

- 2 个 [[item:240167]] 是你的最佳毕业选择。
  
  - 为你和你的队友提供随机主属性触发效果。
  - 最好制作在护腕和靴子上；不过，它也可以制作在任何一件护甲部位上。

在赛季初期，或者当你无法获得 334 或 344 装等的武器时，一个不错的选择是制作一把 331 装等的武器[[item:245876]]，而不是用 [[item:240167]] 制作散件。一旦你能获得 334 或 344 的武器，这个选择相比 2 个 [[item:240167]] 就会失去价值。

- [[item:245876]]
  
  - 被动提供次要属性 ，具体取决于你正在与之作战的怪物类型。
  - 必须制作在武器上。

#### 剩余的火花

- 制造业装备为 331 装等，而普通装备的最高装等为 334；因此，除了 2 件装饰品之外，装备制造业装备会有少量损失，除非你在该部位没有其他高装等的装备可用。

#### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药水（瓶）**
  
  - [[item:241324]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241308]]
- **治疗药水**
  
  - [[item:271884]]
- **武器磨刀石/涂油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@BQAAAgGAaB]]
- **宝石插槽**
  
  - [[item:240967]] *—— 唯一，每种颜色的宝石各用一颗，以强化你的亵渎石。*
    
    - [[item:240910]]
    - [[item:240914]]
    - [[item:240890]]
    - [[item:240900]]

### 附魔

:::columns
:::column
| 头部 | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwQA]] |
| 胸部 | [[item:243977@BAAAAwQA]] |
| 护腕 | [[item:275707@BAAAAIE]] |
| 腰带 | [[item:275707@BAAAAIE]] |
| 腿部 | [[item:244641@BAAAAIE]] |
| 靴子 | [[item:243983@BAAAAwQA]] |
| 戒指1 | [[item:244015@BAAAAIE]] |
| 戒指2 | [[item:244015@BAAAAIE]] |
| 武器 | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **守护 德鲁伊** **大秘境**
```json
{
  "source_code": "IQFZoBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *你可以从宏伟宝库商人处购买[[item:275707@BAAAAIE]] ，为你的头盔、护腕和腰带添加插槽。*

## 种族

如果想要将**守护 德鲁伊** 在大秘境地下城中发挥到极致，不同的种族特性可以为你的角色带来巨大的收益。如果这不是你的首要目标，选择一个符合你个人风格的种族也同样可行。

- [[spell:255654]] *-- 高岭牛头人*
  
  - [[spell:255654]]可用于眩晕一组敌人，即使在眩晕递减期间也有效，因为它被判定为击倒效果，因此在那些情况下非常有用。
  
  
  
  - 拥有[[spell:255659]]和[[spell:255658]]等强大的生存被动技能
- [[spell:287712]] -- 库尔提拉斯人
  
  - [[spell:287712]]可以被移动，用于把敌人击退出危险位置。
  
  
  
  - 凭借[[spell:291628]]和[[spell:291417]]，拥有非常优秀的防御被动。
- [[spell:20549]] -- 牛头人
  
  - [[spell:20549]]可以很强，因为你没有其他手段来眩晕敌人。遗憾的是，它最多只能命中5个目标，所以要记住这一点。
  
  
  
  - 除此之外，你还获得不错的被动效果[[spell:20550]]、[[spell:154743]]和[[spell:20551]]。
- [[spell:26297]] *-- 巨魔* 
  
  - 巨魔是目前爆发伤害的最佳选择，因为你可以在化身期间使用[[spell:26297]]来获得额外的急速，但如果想提高生存能力，与其他选项相比这是最差的选择。

#### 推荐

- **高岭牛头人** 和**库尔提拉斯人** 的种族技能在**DPS**方面并非整体最优，但其技能对你的大秘境体验以及作为**守护 德鲁伊**的生存能力有相当不错的影响。
- **暗夜精灵** 对DPS非常有优势，而且在任何大秘境中，作为**守护 德鲁伊**，在某些跳怪环节中也很有用，但在生存能力方面提供的收益并不多。

## 宏

了解**守护 德鲁伊**的推荐宏，适用于大秘境，并观看一段关于为你的角色制作简单宏的快速视频攻略。

[**宏导入指南视频**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details 嘲讽宏
嘲讽宏 --- *此宏会对你的当前目标或鼠标悬停目标施放[[spell:2649]]（在拉怪时非常方便）*

```wow-macro
#showtooltip 低吼
/cast [@mouseover,exists,harm][@target,exists,harm] 低吼
```

首领1嘲讽 --- *对首领1施放[[spell:2649]]*

```wow-macro
/cast [@boss1] 低吼
```

2号首领嘲讽 --- *对2号首领施放[[spell:2649]]*

```wow-macro
/cast [@boss2] 低吼
```

:::

:::details 鼠标指向宏
鼠标指向乌索尔旋风/群体缠绕 *--- 如果已点出相应天赋，则对鼠标位置施放[[spell:102793]]* *，并对鼠标指向目标施放[[spell:102359]]；如果没有可用的鼠标指向目标，则改为对当前目标施放。*

```wow-macro
/cast [@cursor] 乌索尔旋风
/cast [@mouseover,exists] [] 群体缠绕
```

鼠标指向[[spell:2782]] *--- 如果没有可用的鼠标指向目标则对当前目标施放，如果没有目标则对你自己施放。*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] 清除腐蚀
```

鼠标指向愈合 --- *对鼠标指向目标或你自己施放[[spell:16561]]。*

```wow-macro
#showtooltip 愈合
/cast [@mouseover,exists][] 愈合
```

鼠标指向[[spell:29166]]

```wow-macro
/cast  [@mouseover] 激活
```

鼠标指向野性冲锋 *--- 对鼠标指向目标或当前目标施放[[spell:16979]]。*

```wow-macro
#showtooltip 野性冲锋
/cast [@Mouseover][] 野性冲锋
```

鼠标指向安抚 *--- 对鼠标指向目标或当前目标施放[[spell:2908]]。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] 安抚
```

鼠标指向战斗复活 --- *这使你可以将[[spell:20484]]*以鼠标指向方式用在你的团队框体上

```wow-macro
#showtooltip
/cast [@mouseover,help,dead][] 复生
```

:::

:::details 焦点目标宏
焦点打断 --- *对焦点目标施放 [[spell:106839]]*

```wow-macro
/cast [@focus] 迎头痛击
```

鼠标指向焦点 --- *此宏将鼠标指向的目标设为焦点*

```wow-macro
/focus [@mouseover]
```

:::

:::details 实用宏
取消保护之手的取消光环宏 --- *这条宏会取消你身上的[[spell:1022]]，与圣骑士组队时非常有用*

```wow-macro
/cancelaura 保护祝福
```

:::

:::

## 插件

下方是作者为其 **守护 德鲁伊**，概述了使用哪些插件以及如何在大秘境中利用它们让你的游戏生活更轻松。

![](<https://assets-ng.maxroll.gg/wordpress/pala-1-1024x623.png>)

**守护 德鲁伊** 用户界面

:::accordion
:::details 插件
- EllesmereUI
  
  - 一款以易用性为核心设计的用户界面，附带标准界面中不包含的额外功能。
- **BigWigs** 
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些迷你插件旨在为某一个特定的 团队副本 战斗触发警报消息、计时条、音效等内容。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
#### 德鲁伊

- 厚实毛皮的吸收量提高25%。
- 野性之心 强化的 野性成长 治疗量提高25%。
- 撕碎和 猎豹形态 横扫 伤害提高10%。

- 艾露恩钦选者
  
  - 天涯共银辉 – 明月普照 现在使你从对受影响敌人造成的伤害中吸取 12%（原为 10%）。

#### 守护

- 血腥之毛已重新设计——铁鬃有几率使你的下一个重殴、摧折或毁灭免费施放。重殴、摧折或毁灭有几率使你的下一个铁鬃免费施放。
- 顶尖天赋：野性守护已重新设计——
  
  - 等级1：消耗怒气有10%的几率唤醒一个守护之魂，持续8秒，当你施放痛击或裂伤时它会攻击附近的一名敌人。
  - 等级2：裂伤、毁灭、摧折和重殴在12秒内造成额外的20%/40%自然伤害。你的精通提高3%/6%。
  - 等级3：当一个灵魂被唤醒时，痛击和裂伤的冷却时间将会重置，并且在该灵魂陪伴你期间它们造成的伤害提高30%。灵魂每次攻击时，你额外产生8点怒气。在施放狂暴或化身：乌索克的守护者后，获得1层野性守护：
    
    - 野性守护：你的下一次毁灭、摧折或重殴施放必定唤醒一个灵魂。
- 所有伤害提高8%。
- 荆棘吸收量提高25%。
- 野火之后的治疗的回复效果提高25%。
- 明月普照的治疗效果提高25%。
- 朔望使明月普照的冷却时间缩短20秒（原为每使用一次奥术技能缩短3秒）。
- 乌索克的狂怒现在提供一个相当于痛击和重殴伤害35%的吸收护盾（原为30%）。
- 艾露恩之眷现在为你回复奥术所造成伤害的18%（原为15%）。
- 修复了梦境指引被回春赋能所施放的愈合法术错误消耗的问题。

:::

:::

## 常见问题

:::accordion
:::details 问： 为什么我会随机被秒杀？
答：你很可能按下了会解除形态的技能，从而离开了 [[spell:5487]]。最常见的错误是在没有 [[spell:158497]] 触发效果时使用 [[spell:339]] 或 [[spell:8936]]。

:::

:::

---

### 致谢

作者：Tief

审校：**Meeres**

---

:::changelog 更新记录
**2026-08-08** 已更新至 12.1 版本

**2026-06-21** 已更新至 12.0.7 版本

**2026-04-26** 已更新至 12.0.5 版本

**2026-02-22** 已更新至 12.0.1 版本

**2026-01-18** 已更新至 12.0 版本

**2025-12-01** 已更新至 11.2.7 版本

**2025-10-06** 已更新至 11.2.5 版本

**2025-07-28** 已更新至 11.2 版本

**2025-06-18** 已更新至 11.1.7 版本

**2025-04-20** 已更新至 11.1.5 版本

**2025-02-25** 已更新至 11.1 版本

**2024-12-17** 已更新至 11.0.7 版本

**2024-10-27** 已更新至 11.0.5 版本

**2024-08-17** 已更新至 11.0.2 版本

**2024-07-28** 攻略写于 11.0 版本。



:::
