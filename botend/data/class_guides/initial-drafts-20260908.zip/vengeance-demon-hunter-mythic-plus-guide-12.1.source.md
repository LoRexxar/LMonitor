Welcome to the **Vengeance Demon Hunter** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Vengeance Demon Hunter** Mythic+ BIS
```json
{
  "source_code": "J8fAwTVRCc__BEQskQggYUAAvj7AX16AkVzF2IoAYFwAmQQApfBBAkQAAQRrDQRrDIoAYFQAvSCBCgQAAUTuDIoAOFQA0SCBCgQAAkQuDIoAOFQAgfBBAiQABATACRQAwmgHEE6uJ8ACRU9AB0CAp0APYB2uDQAABAgFAPgJqOwSBEgskQAAIEAAFgFMcfBBCiQAA8SuDQRrDUgEIMubCojEAQAVfkBMA0VEMABWBEQ3X0AGEiVABE7FEIAABAQP5OAWBEAEhOgBAEAA9k7AVA8AkqCBLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271537]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240916]] · [[item:240916]] |
| 肩部 | [[item:271535]] | [[item:244021]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240916]] |
| 腿部 | [[item:271536]] | [[item:244641]] |
| 脚部 | [[item:251153]] | [[item:244009]] |
| 腕部 | [[item:244576]] | [[item:245782]] · [[item:240166]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268252]] | [[item:240916]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240916]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:237840]] | [[item:244029]] · [[item:245781]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As  **Vengeance Demon Hunter**, you have access to Untethered Rage, which grants a chance per soul fragment consumed by [[spell:228477]] and [[spell:247454]] to give you a free [[spell:187827]] use.

**Rank 2** increases the damage of [[spell:228477]] and [[spell:247454]] and grants them a chance to consume an extra soul. While **Rank 3** enables that every consumed soul that did not trigger a free [[spell:187827]] gives you a stacking Agility buff and increases the chance of proccing a free [[spell:187827]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-vengeance-mxr.webp>)

Untethered Rage

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:112894]]
    
    - Big AoE damage cooldown that grants souls and was moved from Class Tree to Spec tree.
  - [[talent:112907]]
    
    - [[talent:112907]] was turned from an AoE soul spender to a small AoE cooldown that synergizes with [[talent:112870]] and grants you a big shield.
  - [[talent:112899]]
    
    - Turns your [[spell:187827]] in an actual damage cooldown now, as it increases the damage of all your main rotational abilities by 20% inside of [[spell:187827]].
  - [[talent:112870]]
    
    - Grants you a fancy shield whenever you press [[talent:112907]].

- **Class Tree**
  
  - [[talent:112838]]
    
    - Decreases magic damage taken whenever you interrupt a spell.
  - [[talent:136501@FAQAF6zA]]
    
    - Significantly increases the damage of your [[talent:112908@FAQA_ROB]].
  - [[talent:117758@FAQAF6zA]]
    
    - [[spell:189110]] now grants you a small temporarily shield that decays over time.
  - [[talent:112837@AJADBA]] & [[talent:136502@AJADBA]]
    
    - Allows you to pick a choice node where [[spell:195447]] either clears a curse or a disease effect of you.
  - [[talent:136500]]
    
    - Insane talent that makes you go very fast while gliding.
- **Removed**
  
  - [[spell:321453]]
    
    - You no longer have the ability to enter [[spell:187827]] when casting [[talent:112908@FAQA_ROB]] which turns this into a pure damage cooldown now.

## Hero Talents

- For average Mythic+ I'd normally recommend [[talent:134253]], since it is very easy to play and has a low skill ceiling and significantly helps with snap threat and making ur team happy.

:::tabs
:::tab [[talent:134253]]
- The [[talent:134253]] talent tree evolves around generating and spending [[talent:135667@FAQAF6zA]] stacks:
  
  - [[spell:225919]] has a 35% chance to grant 1 stack of [[talent:135667@FAQAF6zA]]
  - [[talent:135664@AJADBA]] makes using [[spell:227255]] or [[spell:228477]] after reaching 3 stacks consume all of them and call down 3 meteors that deal big AOE damage.
  - With [[talent:135671@FAQAF6zA]], the meteors additionally cause their targets to take 25% additional damage for 8 seconds.
  - [[talent:135660@FAQAF6zA]] reduces [[spell:187827]] cooldown by 10 seconds after every third meteor that is called down.
- [[talent:135672]] and [[talent:135670]] increase haste and reduce damage taken by 2% for each active stack of [[talent:135667@FAQAF6zA]].
  
  - [[talent:135663@FAQAF6zA]] makes this effect last for 8 seconds after being consumed.
- This results in gameplay that revolves around constantly building [[talent:135667@FAQAF6zA]] stacks with [[spell:225919]] and consuming them with [[spell:227255]] or [[spell:228477]].
  
  - While this happens naturally by doing normal rotation, it is important to consume [[talent:135667@FAQAF6zA]] stacks as early as possible, to not overcap them.

:::

:::tab [[talent:123328]]
- Consuming 20 [[spell:203981]] or casting [[spell:389815]] converts your next [[spell:204157]] into [[spell:442294]].
  
  - This enhances your next [[spell:225919]] and [[spell:228477]]. The enhanced ability you cast first deals 10% increased damage, and the second deals 20% increased damage.
  
  
  
  - Quite simply casting [[spell:225919]] > [[spell:228477]] is the priority of empowerments after using [[spell:442294]].
- The second enhanced ability from using [[spell:442294]] shatters an additional [[spell:203795]] through [[talent:117511]], this allows you to get [[spell:442294]] back faster by consuming more [[spell:203795]].
- [[talent:117500]] is a debuff that causes the target to take 7% increased damage for 20 seconds from an enhanced [[spell:225919]] from [[spell:442294]]. 
  
  - If cast after [[spell:228477]], [[talent:117500]] is increased to 14%.
  - [[talent:117500]] also stacks and can be increased from 7% to 14% by doing a second set of empowerments starting with [[spell:225919]] > [[spell:228477]].
  
  
  
  - Additionally while [[talent:117500]] is up, [[talent:117494]] gives your melee attacks additional damage and has a chance to shatter a [[spell:203795]].
- [[talent:123047]] gives [[talent:112853]] a way of generating **Fury** as it resets the cooldown of [[spell:213241]].
- [[talent:123046]] is extremely strong as it allows you to have incredible amounts of absorbs because you how many [[spell:203795]] you currently consume.
- [[talent:117516]] is a passive buff you get from consuming both enhancements from [[spell:442294]] that gives 6% increased haste.

:::

:::

## Talents

:::tabs
:::tab [[talent:134253]]
:::talents **Vengeance Demon Hunter** [[talent:134253]] Build in Mythic +
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **[Deep Dive](<https://maxroll.gg/wow/class-guides/vengeance-demon-hunter-raid-guide#deep-dive-header>)** sections below.

#### Spec Tree

- [[talent:112893]]
  
  - A debuff that makes you heal for 8% or 16% with [[spell:389985]] of the damage done. This works exactly like Leech.
- [[spell:336639]]
  
  - Gives [[spell:204021]] a lot higher uptime, making it very strong.
- [[spell:212084]]
  
  - Big damage frontal cone ability that also heals you.
- [[spell:202137]]
  
  - AoE silence in an 8 yard radius.
- [[spell:227255]]
  
  - Small 25 seconds AoE cooldown to generate snap threat that consumes souls.
  - Applies [[talent:112893]].
- [[spell:389732]]
  
  - Makes [[spell:204021]] a 45 second cooldown instead of 1 minute and gives it an additional charge. Damage reduction uptime from [[spell:204021]] becomes a lot higher with this, allowing you to cycle defensives more easily.

#### Class Tree

- [[spell:204909]]
  
  - A 2 point node that gives 5% Leech per point and 5% additional Leech when [[spell:187827]] is active.
- [[spell:179057]]
  
  - A very potent 45 seconds cooldown AoE stun.
- [[spell:202140]]
  
  - Your AoE disorientation that CC's mobs for 15 seconds.
  - Also acts as a stop, or interrupt by canceling a mob's cast.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍Sigil of Flame's damage over time is increased by 50%. ‍Soul Cleave increases the duration of ‍Sigil of Flame on your primary target by 2 seconds.
- **4-Set:** ‍Immolation Aura and ‍Sigil of Spite deal 100% increased damage against targets affected by your ‍Sigil of Flame.

### Single Target

:::tabs
:::tab [[talent:134253]]
### Opener

:::rotation Vengeance Demon Hunter [[talent:134253]] Single Target in Mythic+
```json
{
  "source_code": "IUFbKI0tyXAAAgAUyVGIDF2c0BgQ_J3AAAAAAIUf8lACIc3-CUAEEg8GJABB1zRCIEBKEQHPJABKea8AAAAAAIUf8NA"
}
```
1. [[spell:389815]] Pre Cast
2. [[spell:225919]]
3. [[spell:228477]]
4. [[spell:195447]]
5. [[spell:203720]]
6. [[spell:204021]]
7. [[spell:225919]]
8. [[spell:212084]]
9. [[spell:247454]]
10. [[spell:228477]]
:::

### Priority List

On Single Target, your goal is to generate as many [[spell:203981]] as possible.

1. Cast [[spell:389815]] off cooldown
2. Cast [[talent:112908@FAQA_ROB]] off cooldown.
3. Cast [[spell:204021]] off cooldown for DR and [[talent:112872]] damage.
4. Cast [[spell:227255]] off cooldown.
5. Cast [[spell:204513]] off cooldown.
6. Cast [[spell:195447]] off cooldown.
7. Cast [[spell:225919]]
8. Cast [[spell:189110]] if you are at 2 charges and do not need to save for movement.
9. Cast [[spell:228477]] as much as possible.
10. Cast [[spell:213241]] if you don't cap Fury.
11. Cast [[spell:195441]] as a filler or if you're far away from the target.

:::

:::

### AoE

:::tabs
:::tab [[talent:134253]]
### Opener

:::rotation Vengeance Demon Hunter [[talent:134253]] Aoe in Mythic+
```json
{
  "source_code": "IUFbKI0tyXAAAgAUyVGIDF2c0BgQ_J3AAAAAAIUf8lACIc3-CUAEEg8GJABB1zRCIEBKEQHPJABKea8AAAAAAIUf8NA"
}
```
1. [[spell:389815]] Pre Cast
2. [[spell:225919]]
3. [[spell:228477]]
4. [[spell:195447]]
5. [[spell:203720]]
6. [[spell:204021]]
7. [[spell:225919]]
8. [[spell:212084]]
9. [[spell:247454]]
10. [[spell:228477]]
:::

### Priority List

On AoE, your goal is to generate as many [[spell:203981]] as possible.

1. Cast [[spell:389815]] off cooldown
2. Cast [[talent:112908@FAQA_ROB]] off cooldown.
3. Cast [[spell:204021]] off cooldown for DR and [[talent:112872]] damage.
4. Cast [[spell:227255]] off cooldown.
5. Cast [[spell:204513]] off cooldown.
6. Cast [[spell:195447]] off cooldown.
7. Cast [[spell:225919]]
8. Cast [[spell:189110]] if you are at 2 charges and do not need to save for movement.
9. Cast [[spell:228477]] as much as possible.
10. Cast [[spell:213241]] if you don't cap Fury.
11. Cast [[spell:195441]] as a filler or if you're far away from the target.

:::

:::

### Defensive Cooldowns

- [[spell:187827]]
  
  - [[spell:187827]] is your biggest defensive cooldown, and you should learn to plan around [[spell:187827]] usage to have a smoother time mitigating incoming damage.

- [[spell:204021]] 
  
  - [[spell:204021]] gives you 40% damage reduction while applying a DoT to your target. Normally, you want to use this spell on cooldown as it does decent damage, and can buff your other fire damage spells with [[spell:212818]]. However, hold this spell if there is a tank buster or mechanic that does a lot of damage, and you need to save extra defensives to survive. With talents, it can be extended through [[spell:336639]] to last even longer than usual and have an additional charge as well as a shorter cooldown with [[spell:389732]].

- [[spell:196718]]
  
  - [[spell:196718]] lasts 8 seconds and causes all damage you or an ally takes while inside the darkness to have a 15% chance of being negated completely. This is not great compared to large single hits, but it is good for numerous small hits, such as melee attacks. If you're not saving it for something in particular, you should go ahead and use it almost on cooldown because of the defensive benefits.

### Offensive Cooldowns

- [[spell:389815]]
  
  - [[spell:389815]] deals a moderate amount of damage and generates 3 [[spell:203795]], allowing you to cast [[spell:227255]] more frequently.

## Deep Dive

### Sigils

- Sigils are **Demon Hunter** specific abilities that are placed on the ground and then have a delay of 2 seconds before having an effect within an 8-yard radius. 
  
  - Talenting into [[spell:209281]] brings that delay down to 1 second.
  - They generate 1 [[spell:204255]] with [[spell:395446]].
  
  
  
  - [[spell:389715]] increases the duration of your sigils by 2 seconds and their radius by 2 yards.
  - [[spell:389718]] reduces the cooldown of all your sigils by 15%.

### Cycling defensives on Vengea nce Demon Hunter

- Vengeance Demon Hunter's active mitigation [[spell:203720]] has very high uptime, meaning that as Vengeance Demon Hunter, you can utilize macros and bind [[spell:203720]] into your [[spell:225919]] ability without any defensive loss.
- For cycling defensives, while [[spell:203720]] is our most available active defensive, players should be trying to maximize the uptime of [[spell:187827]] > [[spell:204021]] > [[spell:203720]] in that order.
  
  - This does mean that you end up overlapping and layering [[spell:203720]] with other defensives. The main goal is to make sure that you're not capping [[spell:203720]] charges either.
- This type of gameplay sets Vengeance Demon Hunter apart from other tanks since it needs to be done frequently in high-level content, as taking damage with no defensive cooldown can spell disaster.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Bosses →**

:::tabs
:::tab Altar of Fangs
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

#### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

#### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.

:::

:::tab Den of Nalorakk
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

#### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

#### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
  
  
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

:::

:::tab Murder Row
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Murder Row
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

#### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

#### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

#### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

:::

:::tab The Blinding Vale
:::talents **Vengeance Demon Hunter**  Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

#### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

#### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

#### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

:::

:::tab Voidscare Arena
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

#### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

#### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

:::

:::tab Kings' Rest
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

#### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

#### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

#### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
  
  
  
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

:::

:::tab Ruby Life Pools
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.

#### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

#### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

:::

:::tab Temple of Sethraliss
:::talents **Vengeance Demon Hunter**  Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA",
  "code": "CWkAIo1c2KfIEsPoy9fznypG4BAMjZmZmhZmMzMYWMzMDmZMzYGzMzYwMzM2mZmtxwAAAAAAAIgZwGAAAAGYmZmZ2abmZGAAAAAgBA"
}
```
:::

### Boss Tips

#### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

#### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

#### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

#### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

:::

:::

### Affixes

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Vengeance Demon Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "HoAJFMAJoASMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 全能 ＞ 暴击 ＞ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

### Reasons for Stats

Haste is always the most sought after Stat as it gives a high amount of damage, as well as cdr on [[spell:203795]] generating abilities and [[spell:203720]], which gives a lot of survivability. In Mythic+ Critical Strike is usually very sought after as it increases your damage by a substantial amount and increases your parry, which when you are taking a lot of melee hits, equals a large amount of Damage Reduction.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary Stats

- **Avoidance** - Slightly reduces damage taken from area of effect attacks. This can be certain tank abilities a boss does,  as well as trash. Starts diminishing returns heavily at 20% (2000), but it has no cap.
- **Leech** - Causes a player to instantly return health from both outgoing damage and outgoing heals. Health returned is equal to your amount of Leech. For Example; 1 % of Leech gives health equal to 1% of damage and healing done.
- **Speed** - Increases movement speed.

In conclusion, **Leech** is what you should go for as a tank in Mythic+ in order to min-max survivability as it gives you the greatest benefit in Mythic+ over the other two tertiary stats.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAgGAvj7cVrjgCchNYFA]] | Ula'tek |
| Neck | [[item:271537@DCRBAUkAvj7cVrDZ1chNYFwAmQA]] | Ula'tek |
| Shoulder | [[item:271535@DAQAAUkA1k74UA]] | Tier |
| Cloak | [[item:268253@BAQAAUkAYFA]] | The Coiled Altar |
| Chest | [[item:271540@DAQAAUkAJk74UA]] | Tier |
| Wrist | [[item:244576@FAQAAUkAWA8YiqzSBA]] | Crafting |
| Gloves | [[item:271538@BAQAAUkAOFA]] | Tier |
| Belt | [[item:268256@BCQAAUkAU06gVA]] | The Coiled Altar |
| Legs | [[item:271536@DAQAAUkAhu7gVA]] | Tier |
| Boots | [[item:251153@DgQAAUkApk7IoAOF]] | Den of Nalorakk |
| Ring 1 | [[item:268252@DEQAAUkAvk7QRrDFtOOF]] | Sszorak |
| Ring 2 | [[item:159459@DkQAAgGAvk74Prj_sOCKgTB]] | Kings' Rest |
| Trinket 1 | [[item:270164@BgQAAgGACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270173@BAQAAUkAOFA]] | The Coiled Altar |
| Weapon | [[item:268209@DAQAAUkA9k7gVA]], [[item:237840@HAQAAUkA9k7UBwDpqQLF]] | The Coiled Altar, Crafting |

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@BgQAAgGACKQQBA]] | Altar of Fangs |
| Neck | [[item:251173@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Shoulder | [[item:251223@BgQAAgGACKQQBA]] | Voidscar Arena |
| Cloak | [[item:193763@BgQAAgGACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@BgQAAgGACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251135@BgQAAgGACKQQBA]] | Murder Row |
| Gloves | [[item:251124@BgQAAgGACKQQBA]] | Murder Row |
| Belt | [[item:159301@BgQAAgGACKQQBA]] | Kings' Rest |
| Legs | [[item:159313@BgQAAgGACKQQBA]] | Kings' Rest |
| Boots | [[item:251153@BgQAAgGACKQQBA]] | Den of Nalorakk |
| Ring 1 | [[item:273792@BgQAAgGACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:159459@BgQAAgGACKQQBA]] | Kings' Rest |
| Trinket 1 | [[item:250228@BgQAAgGACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250215@BgQAAgGACKQQBA]] | Murder Row |
| Weapon | 2x [[item:251143@AgQAAIoAOFA]] | Den of Nalorakk |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAgGACKgTBA]]  <br>[[item:270175@BgQAAgGACKAWBA]]  <br>[[item:270173@BgQAAgGACKAWBA]]  <br>[[item:270165@BgQAAgGACKgTBA]] |
| **A-Tier** | [[item:250215@BgQAAgGACKgTBA]]  <br>[[item:159617@BgQAAgGACKgTBA]]  <br>[[item:270160@BgQAAgGACKgTBA]]  <br>[[item:250228@BgQAAgGACKgTBA]] |
| **B-Tier** | [[item:270174@BgQAAgGACKgTBA]]  <br>[[item:250214@BgQAAgGACKgTBA]]  <br>[[item:250225@BgQAAgGACKgTBA]]  <br>[[item:250243@BgQAAgGACKgTBA]]  <br>[[item:159618@BgQAAgGACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAgGACKgTBA]]  <br>[[item:250259@BgQAAgGACKgTBA]]  <br>[[item:250244@BgQAAgGACKgTBA]]  <br>[[item:193757@BgQAAgGACKgTBA]]  <br>[[item:270168@BgQAAgGACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAgGACKgTBA]]  <br>[[item:273797@BgQAAgGACKgTBA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Best overall choice of stat budget.
- 1x [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241324]]**
- **Food**
  
  - **[[item:255845]]**
- **Combat Potion**
  
  - **[[item:241308]]**
- **Health Potion**
  
  - **[[item:271884]]**
- **Weapon Stone/Oil**
  
  - **[[item:243734]]**
- **Augment Rune**
  
  - **[[item:259085@AQAAAoF]]**
- **Sockets**
  
  - **[[item:240967]] *-- Unique, use one of each gem colour to enhance your Blasphemite.***
    
    - **[[item:240910]]**
    - **[[item:240914]]**
    - **[[item:240890]]**
    - **[[item:240900]]**

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAIE]] |
| Belt | [[item:275707@BAAAAIE]] |
| Legs | [[item:244641@BAAAAIE]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244015@BAAAAIE]] |
| Ring 2 | [[item:244015@BAAAAIE]] |
| Weapon | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **Vengeance Demon Hunter** **Mythic+**
```json
{
  "source_code": "JwFZFJQ9NGQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AERgAK9k7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
| 副手 | [[item:244029]] |  |
:::

:::

:::

> *You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

In this section of the Vengeance Demon Hunter Mythic+ Guide, we showcase and explain how impactful certain racials can be in World of Warcraft. As a **Demon Hunter**, you only have access to 3 races.

- [[spell:58984]] -- Nightelf
  
  - Provides nothing in Raid, but can be useful in Mythic+ in very niche situations.
- [[spell:202719]] -- Bloodelf
  
  - Removes 1 beneficial effect from hostile targets around you.
  - Generates 15 Fury.
- [[spell:256948]] -- Voidelf
  
  - Tear a rift in space. Reactivate this ability to teleport through the rift.

### Recommendation

I would personally recommend Night Elf because of its' powerful use cases in Mythic+ which you always prefer to an AoE dispel.

## Macros

Discover recommended macros for **Vengeance Demon Hunter** for Mythic+ and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
**Taunt at Mouseover** --- *Mouseover macro for [[spell:185245]] (Taunt) that allows you to get aggro easily from targets that just come into view or spawn without having to change target. If you have nothing over mouseover it taunts your primary target.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]Torment
```

Boss 1 Taunt --- *Casts [[spell:185245]]* *on Boss1*

```wow-macro
/cast [@boss1] Torment
```

Boss 2 Taunt --- *Casts [[spell:185245]]* *on Boss2*

```wow-macro
/cast [@boss2] Torment
```

:::

:::details Cursor Macros
***[[spell:202137]]** at cursor ---  This makes it much faster to quickly use [[spell:202137]] in any given scenario*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Silence
```

***[[spell:202138]]** at cursor ---  This makes it much faster to quickly use [[spell:202138]] in any given scenario*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Chains
```

***[[spell:202140]]** at cursor ---  This makes it much faster to quickly use [[spell:202140]] in any given scenario.*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Misery
```

***[[spell:204513]]** at cursor ---  This makes it much faster to quickly use [[spell:204513]] in any given scenario.*

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Flame
```

**[[spell:389815]]** at cursor ---  This makes it much faster to quickly use [[spell:389815]] in any given scenario.

```wow-macro
#showtooltip
/cast [@cursor] Sigil of Spite
```

**[[spell:189110]]** at cursor ---  This makes it much faster to quickly use [[spell:189110]] so that you can move around quicker and more effectively.

```wow-macro
#showtooltip
/cast [@cursor] Infernal Strike
```

:::

:::details Utility Macros
**Cancelaura macro** --- *Here is a very important macro that you want to fill with any buff that is an immunity that you would need to cancel in a given scenario. For example;  you used a paladin's [[spell:1022]] to get rid of a debuff quickly and need to cancel so that you can continue being the primary aggro target before your allies are tanking instead.*

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::details Player Macros
**[[spell:189110]] at Self**--- *Allows to instantly Infernal strike at the feet, which can be used to min-max a bit more damage since [[spell:189110]] is off the GCD. This should not be done that often but it has its use cases.*

```wow-macro
#showtooltip
/cast [@player] Infernal strike
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Vengeance Demon Hunter**, outlining which addons are used and how they are utilized in Mythic+ to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/nicememesuimidnight-2-1024x681.png>)

**Vengeance Demon Hunter** UI in Mythic+

:::accordion
:::details Addons
- [](<https://www.curseforge.com/wow/addons/shadowed-unit-frames>)BigWigs -- Generic Boss Mod
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific raid encounter.
- Plater -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for scripting similar to WeakAuras and wago.io + the WeakAuras-Companion for Mod/Script/Profile updates.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter for World of Warcraft.
- Echo Raid Tools -- Notes, Raid cooldowns, and more
  
  - Echo Raid Tools is a World of Warcraft addon designed by Echo Esports to enhance raiding efficiency. It offers "Echo Approved" WeakAuras for each raid boss accessible through an in-game Dungeon Journal interface, allowing easy import and customization.

:::

:::

:::accordion
:::details


:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**▶ DEMON HUNTER**

- Vengeance
  
  - Fracture and Soul Cleave now require equipped Warglaives, Axes, Swords, and Fist Weapons.
  - Sigil of Chains is now learned at level 35 and is no longer a talent.
  - Sigil of Chains cooldown reduced to 60 seconds (was 90 seconds).
  - Sigil of Chains no longer replaces Sigil of Misery.
  - Sigil of Silence now replaces Sigil of Misery when selected.
  - Improved Sigil of Misery no longer affects Sigil of Chains.
  - Improved Sigil of Misery now reduces the cooldown of Sigil of Silence by 15 seconds when Sigil of Silence is selected.
  - All damage increased by 5.5%.
  - Soul Cleave healing increased by 25%.
  - Fel Devastation healing increased by 25%.
  - Charred Warblades heals you for 5% of Fire damage you deal (was 4%).
  - Frailty causes you to heal for 10% of damage dealt to afflicted targets (was 8%).
  - Feast of Souls healing increased by 25%.
  - Revel in Pain causes 6% of your Fire damage to shield you (was 5%).
  - Several talents have changed locations in the talent tree.

:::

:::

## FAQ

:::accordion
:::details Q: How to get better at tanking?
The biggest tip I can give is to always figure out why you died in a given scenario and how you can improve. Tanking is tough, with constant opportunities to better use your externals, rotation, and defensives. Recording your gameplay and reviewing Warcraft Logs are great methods. Being good at tanking requires cognitive flexibility—focus on what you could have done better instead of blaming others. This mindset is more rewarding and healthier for becoming a better tank.

:::

:::

---

### Credits

Written by: **Nicememes**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1

**2026-06-22** Updated for patch 12.0.7

**2026-04-23** Updated for patch 12.0.5

**2026-01-20** Updated for patch 12.0.1



:::
