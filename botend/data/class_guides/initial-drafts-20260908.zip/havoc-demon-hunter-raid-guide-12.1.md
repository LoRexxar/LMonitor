欢迎阅读《魔兽世界》12.1版本 **浩劫 恶魔猎手** 团队副本 攻略！本攻略涵盖了你了解自己角色所需的一切内容！你是刚起步、从80级开始练级的新玩家吗？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体目标** · 4/5 · 强

范围伤害 · 4/5 · 强

功能性 · 3/5 · 一般

生存能力 · 5/5 · 优秀

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **浩劫 恶魔猎手**  团队副本 最佳配装（BiS）
```json
{
  "source_code": "JQpAIGkA3_fABMgJEIIEBAwJ5OADtOggCchNYFQApfBBAERAAcVrJQBXMWDWBEwrkQgAIUAAXk7ACKgTBY9FEEAtJIBAJkgEogcpDEA4XQAgIEAAFkEDYFQAwmQIMF6uDIoAYFQwXQQAf5mACgQAAEPuFUEMBA2uDQICBAQrqQgHAHwakdbNLFQAySCBAgQAAIoAOFQAZfBBCiQAAUPuB4RBSggnqJgOSAAGf9BBAgwAAEwYcUAABo0FCEQXBIRACBBWBEQ3XkhTIE7FEEgfEMQuFAJUBARoDYACBAgHAPwA5OApqQwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240908]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240908]] |
| 肩部 | [[item:271535]] | [[item:243991]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240908]] |
| 腿部 | [[item:271536]] | [[item:244641]] |
| 脚部 | [[item:159327]] | [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240908]] · [[item:273069]] · [[item:245790]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268249]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:243971]] |
| 副手 | [[item:237840]] | [[item:245790]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**顶尖天赋**的3级。

作为 **浩劫 恶魔猎手**，你可以使用 永恒狩猎，它会强化你的 [[spell:198013]]，降低 [[spell:370965]] 的冷却时间并提高其目标上限，并在施放 [[spell:198013]] 后使你的 [[spell:188499]] 必定重置。

- **第1级** 使 [[spell:370965]] 强化你的下一个 [[spell:198013]]，使其伤害翻倍并扩大其作用范围。
- **第2级** 使 [[spell:370965]] 的冷却时间缩短15/30秒，伤害提高15/30%，且其持续伤害效果可额外作用于2/4个目标。
- **第3级** 使 [[spell:188499]] 的伤害提高20%，并在完整引导 [[spell:198013]] 后首次施放该技能时重置其自身冷却时间。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-havoc-mxr.webp>)

永恒狩猎

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[spell:370965]]
    
    - 此技能原先在职业树中，现已被移至专精树。
  - [[spell:342817]]
    
    - 原先是一个主动技能，[[spell:342817]] 已被重做为被动效果，当 [[spell:188499]] 命中 3 个或更多目标时触发。
- **职业天赋树**
  
  - [[spell:213241]]
    
    - 现在产生15点怒火，不再有重置几率，整体导致怒火获取速度变慢。
  
  
  
  - [[spell:1266316]] /[[spell:1266496]]
    
    - 使 [[spell:472649]] 分别移除 1 个疾病/诅咒效果。
  
  
  
  - [[spell:1266307]]
    
    - 为 [[spell:198589]] 额外提供 1 层充能。与专精树中的 [[spell:205411]] 结合时能提供强大的防御能力。
  
  
  
  - [[spell:1266329]]
    
    - 打断后 12 秒内受到的魔法伤害降低 15%。属于情境性天赋，但在正受到魔法伤害且可以打断的场合，这是一个极佳的防御工具。
- **已移除**
  
  - [[spell:196555]]
    
    - [[spell:196555]] 的移除对生存能力有负面影响，但由 [[spell:1266307]] 和 [[spell:205411]] 的新组合所补偿。
  
  
  
  - [[spell:204513]]
    
    - 原先是一个基础技能，[[spell:204513]] 现已成为 复仇 专精独有。
  
  
  
  - [[spell:389815]]
    
    - 原先在职业树中是一个顶层天赋，[[spell:389815]] 现已成为 复仇 专精独有。
  
  
  
  - [[spell:211881]]
    
    - 此技能的移除由职业树中的天赋节点 [[spell:1266296]] "补偿"。该天赋使 [[spell:179057]] 的主要目标额外昏迷 2 秒。
  
  
  
  - [[spell:258925]]
    
    - [[spell:258925]] 原先是专精树中的一个天赋选项，可提供一些按需的 范围伤害 爆发，现已被移除。
  
  
  
  - [[spell:162243]]
    
    - 原先与 [[spell:203555]] 作为选择节点提供。该选择节点已被完全移除，[[spell:203555]] 现已成为基础技能。

## 英雄天赋

- [[talent:123330]] 和 [[talent:123329]] 是 浩劫 恶魔猎手 的英雄天赋树选项。除非你需要漏斗伤害，否则 [[talent:123329]] 目前在 范围伤害 和单体目标场景中均领先于 [[talent:123330]]。

:::tabs
:::tab [[talent:123329]]
### 英雄天赋概览

- [[talent:123329]]英雄天赋树通常比[[talent:123330]]更加被动。除了其常规收益外，施放[[spell:191427]]会将[[spell:198013]]变为[[spell:452497]]，并将[[spell:258920]]变为[[spell:452487]]，使它们得到强化，令它们在首次施放时触发[[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]]。
- 与此同时，该天赋树拥有[[spell:452414@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]、[[spell:452408@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]和[[spell:452410@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]等天赋，可以显著提高你在[[spell:191427]]之外的输出。
- [[talent:123329]]通常被认为比[[talent:123330]]更容易上手，这一点值得考虑，因为它可能会让你有更多精力专注于比伤害更重要的事情，比如处理机制和存活。
- 在使用[[spell:191427]]之前，确保[[spell:258920]]和[[spell:198013]]已经进入冷却，因为[[talent:117509]]会重置这些技能。

### 补丁 12.0

- 12.0版本为[[talent:123329]]英雄天赋树新增了3个天赋节点：
  
  1. [[spell:1272364]]。火焰伤害提高5%。处于[[spell:213410]]期间效果翻倍。
  2. [[spell:1272405@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]。[[spell:258920]]在结束后有25%的几率重新点燃。
  3. [[spell:1272453]]。当你进入[[spell:213410]]时，立即触发一次[[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]]。

:::

:::tab [[talent:123330]]
### 英雄天赋概览

- 使用[[talent:117512]]时，消耗6块灵魂残片会使你的[[spell:185123]]技能变为[[spell:442294]]。施放[[spell:442294]]后，你的下一个[[spell:162794]]/[[spell:201427]]和[[spell:188499]]/[[spell:210152]]会得到强化。
  
  1. 当[[spell:188499]]被强化时，施放它会触发[[spell:442718]]，对附近目标额外施放3次战刃斩击。如果在[[spell:162794]]之后施放[[spell:188499]]，则会施放6次斩击。
  2. 当[[spell:162794]]被强化时，它会施加[[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]。如果在[[spell:188499]]之后施放[[spell:162794]]，则会额外施加1层[[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]。

- 此外，在消耗两种强化效果后，你将获得“战斗快感”，使你下一个 [[spell:442294]] 的伤害提高 30%，并使急速提高 6%，持续 30 秒。

### 补丁 12.0

- 12.0 版本为 [[talent:123330]] 英雄天赋树新增了 3 个天赋节点：
  
  1. [[spell:1272143]]。[[spell:370965]] 会碎裂 1 块灵魂残片。此外，[[spell:188499]] 和 [[spell:162794]] 有 15% 的几率碎裂 1 块灵魂残片。
  2. [[spell:1272138]]。[[spell:442294]] 的伤害提高 20%，所有其他纯物理伤害提高 10%。这也会间接提升 [[spell:474339]] 的伤害。
  3. [[spell:1272153]]。该天赋使 [[spell:188499]] 第二次施放时触发的战刃数量翻倍。它还允许 [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] 最多叠加 3 层，并且 [[spell:162794]] 第二次施放时会额外施加一层。

:::

:::

## 天赋

:::tabs
:::tab [[talent:123329]] 单体
:::talents [[talent:123329]] **浩劫 恶魔猎手** 团队副本单体天赋
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZAzMz2MmZmZmZmMmZAAAAAAAzmZmtZgxyMzYZm5BmZWmZWGjB2mFzYY200wMjhNAAAAAAEAMzgBgAAADA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZAzMz2MmZmZmZmMmZAAAAAAAzmZmtZgxyMzYZm5BmZWmZWGjB2mFzYY200wMjhNAAAAAAEAMzgBgAAADA"
}
```
:::

- 这套天赋纯粹专注于最大化单体/优先目标的伤害。

:::

:::tab [[talent:123329]] 多目标
:::talents [[talent:123329]] **浩劫 恶魔猎手** 团本中的多目标天赋
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

- 这套天赋专注于造成大量的 范围伤害 伤害，这些伤害会在你自身和你的优先目标周围被动触发。对于任何存在多个目标的首领，或者有需要击杀的重要小怪的战斗来说，这是一个很好的选择。

:::

:::tab [[talent:123330]] 单体
:::talents [[talent:123330]] **浩劫 恶魔猎手** 团本中的单体天赋
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

- [[talent:123330]] 变体正是 浩劫 声名远扬的漏斗式伤害来源。当场上存在多个目标，而你主要关心对 1-2 个目标的优先伤害时，这一点尤其有用。

:::

:::

### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简明概述，如需更详细的内容，请查看下方的**输出循环**和**深入解析**部分。

#### 专精树

- [[spell:258860]]
  
  - 对正面锥形范围造成巨额伤害，并使 [[spell:162794]] 和 [[spell:188499]] 对受影响的敌人造成额外的混乱伤害。

- [[talent:112955]]
  
  - 每次你施放 [[spell:198013]] 时，其冷却时间缩短2.5秒，最多缩短10秒。

- [[spell:388108]]
  
  - 在敌方目标攻击你之前先命中它，可使你的爆击几率提高10%，施放 [[spell:198793]] 后该效果会在每个敌对目标身上重置。

- [[spell:370965]]
  
  - 这个强大的进攻冷却技能会对你的目标以及你路径上最多5个目标施加一个主要的持续伤害效果。

- [[spell:390197]] + [[spell:427775]]
  
  - 这些天赋的组合提供了高额范围伤害伤害的潜力，如果选择了相应天赋，让 [[spell:258920]] 始终处于冷却中就非常重要，尤其是在范围伤害场合下。

#### 职业树

- [[spell:196718]] 
  
  - 这个团队减伤技能会生成一片 [[spell:196718]] 区域，位置位于**浩劫 恶魔猎手's**所在处，使范围内所有盟友有 15% 的几率完全避免受到攻击伤害。非团队副本环境下，这一几率翻倍。

#### 英雄天赋

- [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]]
  
  - 进入 [[spell:213410]] 后，强化你的下一个 [[spell:201427]] 和 [[spell:210152]]，使其在你周围爆炸。  
    当携带 [[spell:162264]] 进入 [[spell:213410]] 时，它还会额外强化你的 [[spell:190232]] 和 [[spell:258920]]，产生相同效果。

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：** [[spell:188499]]、[[spell:162794]]和[[talent:112956]]造成的伤害提高12%。
- **4件套：** [[talent:112956]]现在可以施加并受益于 [[talent:112955]] 的效果，初始打击伤害提高25%，并且持续时间延长2秒。

### 单体目标

:::tabs
:::tab [[talent:123329]]
### 起手爆发

- **浩劫 恶魔猎手的**开场连招非常复杂，务必严格按照此顺序执行，以最大化你的伤害输出。

:::rotation **浩劫 恶魔猎手** 恶魔伤痕单体起手（团队副本）
```json
{
  "source_code": "IoHPNI0d7LAAAcAUyVGc1xGbAkwD0AQABwprDAAAAAgQVkaBFgAB9VQCQQALznACEgON2gAAEMtEBABKBIUiIMAAAIE25JQB2QA60EgFQAgQHeuBFABKTLxAAAAAAIUknbA"
}
```
1. [[spell:195447]] 战前准备
2. [[spell:195447]]  [[item:241308]]
3. [[spell:370965]]
4. [[spell:198013]]
5. [[spell:258860]]
6. [[spell:210152]]
7. [[spell:210152]]
8. [[spell:201427]]  [[spell:198793]]
9. [[spell:162264]]
10. [[spell:210152]]
11. [[spell:452487]]
12. [[spell:201427]]
13. [[spell:452497]]
:::

- 如果你选择了[[spell:427641]]天赋，就必须确保使用[[spell:213241]]或[[spell:195072]]来触发你的[[spell:427641]]。

### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

- 冷却完毕即施放 [[spell:198013]]
- 冷却完毕即施放 [[spell:198793]]，或在重要伤害事件时使用
- 冷却完毕即施放 [[spell:370965]]
- 保持冷却时施放 [[spell:210152]]
- 如果你不会使怒气溢出，则施放 [[spell:258920]]
- 施放 [[spell:201427]]
- 施放 [[spell:188499]]
- 施放 [[spell:162794]]
- 施放 [[spell:232893]]

:::

:::

### 多目标

:::tabs
:::tab [[talent:123329]]
### 起手爆发

- 下面是一个示例，展示使用推荐的**多目标天赋配置**时你的起手循环是什么样的。

:::rotation **浩劫 恶魔猎手** 恶魔伤痕范围伤害起手（团队副本）
```json
{
  "source_code": "IoHPNI0d7LAAAcAUyVGc1xGbAkwD0AQABwprDAAAAAgQVkaBFgAB9VQCQQALznACEgON2gAAEMtEBABKBIUiIMAAAIE25JQB2QA60EgFQAgQHeuBFABKTLxAAAAAAIUknbA"
}
```
1. [[spell:195447]] 战前准备
2. [[spell:195447]]  [[item:241308]]
3. [[spell:370965]]
4. [[spell:198013]]
5. [[spell:258860]]
6. [[spell:210152]]
7. [[spell:210152]]
8. [[spell:201427]]  [[spell:198793]]
9. [[spell:162264]]
10. [[spell:210152]]
11. [[spell:452487]]
12. [[spell:201427]]
13. [[spell:452497]]
:::

### 多目标优先级列表

- 在点出 [[spell:427775]] 天赋时，冷却完毕即施放 [[spell:258920]]
- 冷却完毕即施放 [[spell:198013]]
- 冷却完毕即施放 [[spell:198793]]，或在重要伤害事件时使用
- 冷却完毕即施放 [[spell:370965]]
- 施放 [[spell:210152]]
- 施放 [[spell:201427]]
- 施放 [[spell:188499]]
- 施放 [[spell:162794]]
- 施放 [[spell:232893]]

:::

:::

## 深度解析

### 生死一线

打出伤害并成为你团队副本队伍中有用一员的最重要部分就是活下来。由于移动是你输出循环的核心部分，你必须时刻注意周围环境。不要[[spell:195072]]或[[spell:198793]]进入正面技能或范围效果区域。

你死了就无法输出，也无法阻止敌方技能生效。

如果你躺在地上死去，或者需要消耗本可用于其他方面的团队减伤/治疗资源，那么即使你能打出完美的循环也毫无意义。

### 献祭光环

当你点出了[[spell:390197]] + [[spell:427775]]天赋时，正确管理你的[[spell:258920]]充能层数非常重要，因为在范围伤害场合中它占据你伤害构成的最大部分。当你即将溢出充能层数，但还没有准备好[[spell:195072]]层充能用于维持[[spell:427640]]的持续时间时，直接使用你的[[spell:258920]]充能，忽略[[spell:427640]]即可。

**绝对不要** 让 [[spell:258920]] 的充能溢出，无论如何都不行！

### 先发制人爆发窗口

你伤害的另一个重要部分是合理管理你的[[spell:388108]]窗口。请记住，每一个敌方单位都会触发[[spell:388108]]，而[[spell:198793]]也会对每一个敌方单位重置它。

你可以通过与部分敌人保持距离来优化这一点，以便稍后再次触发[[spell:388108]]。

### 铺开恶魔追击

施放 [[spell:370965]] 时，务必确保用该技能的 DoT 成分感染尽可能多的敌人。这一点可能比较棘手，因为它是施加在你用 [[spell:370965]] 冲锋时处于你路径上的敌人身上的。一个实用技巧是，在 [[spell:370965]] 的施放/冲锋结束之后，你其实仍然可以施加这个 DoT。这意味着你可以先施放 [[spell:370965]]，等它结束后，你可以穿过敌人来对其施加这个 dot 成分，而且如果你动作够快，你甚至可以在 [[spell:370965]] 之后再施放 [[spell:195072]]，它仍然会给被你 [[spell:195072]] 穿过的敌人施加 DoT。

### 急速?!

尽管 **急速** 在模拟数据纸面上表现很差，但在多目标场景中它是一个极佳的属性，因为它能让你的操作流畅许多。

**急速** 能够增加你拥有的 [[spell:258920]] 充能层数，因为它会缩短充能时间；同时也有助于 狂怒 的生成，并帮助你在 [[spell:213410]] 的窗口期内打出更多技能。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

以下提示主要适用于英雄和史诗难度的首领。

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **浩劫 恶魔猎手** 内克扎莉
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

### 首领攻略技巧

- 注意[[spell:1284103]]的计时条，切勿站在首领与其技能目标坦克之间。
- 提前观察小怪的尸体位置，以便更轻松地应对[[spell:1294742]]净化它们的减益效果。

:::

:::tab 陵寝哨兵
:::talents **浩劫 恶魔猎手** 陵寝哨兵
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

### 首领攻略技巧

- 需要注意的是，[[spell:1284434]]也可能出现在另一个首领身上，所以尽量不要站在两个首领之间，并在[[spell:1284434]]出现时保持警惕。
- 留意首领的能量值，当其接近100时务必分散站位，以便更轻松地度过中场阶段。
- 总体而言，注意自己的站位，尽量靠近首领输出，这样就不用担心[[spell:1284494]]和[[spell:1284503]]的层数叠加。

:::

:::tab 迷失的探险者
:::talents **浩劫 恶魔猎手** 迷途的探险者
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

### 首领攻略技巧

- 注意 [[spell:1296062]] 的施法，这样更容易躲避它们。
- 不要过量吸收 [[spell:1291934]]，因为它会给你施加一个可叠加的**流血**减益效果。
- 小心 [[spell:1292105]] 产生的蘑菇，因为它们在被使用一次后不久就会消失。

:::

:::tab 瓦什尼克
:::talents **浩劫 恶魔猎手** 瓦什尼克
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

### 首领攻略技巧

- 每当 [[spell:1281907]] 减益效果即将到来时，务必提前分散，并尽可能不要将它对准首领。
- 请记住，击杀 **燃烧毒液** 会给你叠加一层减益效果，所以要避免同时击杀它们。

:::

:::tab 斯索拉克
:::talents **浩劫 恶魔猎手** 斯索拉克
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

### 首领攻略技巧

- 如果你找不到搭档来处理 [[spell:1285419]]，请记住你也可以用 [[talent:80163]] 或 [[talent:80174]] 来化解它。
- 非常重要的是要留意 [[spell:1305959]] 的计时器，一旦临近，提前扫描平台，看看你需要把它放置在哪里。
- 如果你被 [[spell:1287072]] 击中，请使用防御冷却技能，因为它会给你叠加一层 **中毒** 减益效果。

:::

:::tab 双牙
:::talents **浩劫 恶魔猎手** 双牙
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

### 首领攻略技巧

- 在这场战斗中，拥有一个良好的负面效果监控手段极其重要，因为[[spell:1290336]]在达到一定层数后必定会致死，具体层数取决于难度。
- 当你成为[[spell:1291478]]的目标时，尽量不要到处乱跑。如果需要躲避什么，最好沿自己的直线移动。
- 别忘了吸收[[spell:1290516]]也会将你击退，所以在那期间要小心[[spell:1290956]]产生的波纹。
- 每当[[spell:1294293]]发生时，观察场地中央的**维克苏尔** ，你会发现有一些围绕他旋转的小球，它们指示了他施放光束的方向。

:::

:::tab 盘绕祭坛
:::talents **浩劫 恶魔猎手** 盘绕祭坛
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

### 首领攻略技巧

- 小心 [[spell:1282403]]，如果有需要，确保协助将它们移动到别处。
- 要格外注意 [[spell:1285643]] 之后刷新的幽灵，因为处理它们将是这个阶段最难的部分。
  
  - 即使你没有被幽灵点名，也请确保不要停留在它们附近，因为它们会被 [[spell:1286620]] 的正面劈砍清理掉，这是消灭它们的唯一办法。
- 每当你被 [[spell:1286895]] 点名时，使用一个防御冷却技能。

:::

:::tab 乌拉特克
:::talents **浩劫 恶魔猎手** 乌拉特克
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

:::

:::tab 尼姆瑞莎·唤波者
:::talents **浩劫 恶魔猎手** 尼姆瑞莎·唤波者
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

### 首领攻略技巧

- 请注意，在 [[spell:1258673]] 发生之后，[[spell:1258150]] 会把你击退远离中央，所以要提前站好位置，或者准备好用 [[spell:131347]] 来抵消击退效果。
- 每当 [[spell:1281393]] 被触发时，使用一个防御冷却技能。

:::

:::

值得一提的是，[[talent:123330]] 天赋在本层级表现非常出色，如果操作得当，它们在毒渊（The Venomous Abyss）的任何首领战上都能胜过任何 [[talent:123329]] 配置。不过，[[talent:123330]] 通常会带来一些额外的难度/不流畅感，并不适合所有人。[[talent:123329]] 能为你提供更多的按需爆发和 范围伤害 伤害，而 [[talent:123330]] 则能带来高额的单体输出，并借助场上额外目标获得的聚怪伤害。

推荐使用[[talent:123330]]天赋，因为你可以在每个首领战中使用这套天赋。请记住，你的团队可能有其他需求，更适合[[talent:123329]]的伤害模式，例如应对小怪出现时所需的范围伤害爆发伤害。

## 属性优先级

了解你作为  **的副属性优先级以及在 团队副本 首领战中达到最佳表现所需的第三属性浩劫 恶魔猎手**。如需更详细的信息，请访问 **[属性与数值](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 指南。

:::priority **浩劫 恶魔猎手** 团队副本 属性优先级
```json
{
  "source_code": "IoAJFMAIxQCKBEQABA"
}
```
**敏捷 ＞ 暴击 ＞ 精通 ＞ 急速 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 极佳的属性，可以降低"**范围伤害**"技能所造成的伤害。
- **吸血** - 通过造成伤害来提供额外治疗。
- **速度** - 较为冷门的第三属性，但可能有用，过去也已被证明有其价值。能让应对某些机制变得轻松许多。

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 位置 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAEkAnk7wQrjgCchNYFA]] | 乌拉特克 |
| 颈部 | [[item:268265@BERAAEkAX16wQrjgCwYNYFA]] | 乌拉特克 |
| 肩部 | 将 [[item:268246@BgQAAEkACKgTBA]]  <br>转化为 [[item:271535@DgQBAEkAXk7IoAOFg1XQ]] | Vashnik 已催化 |
| 披风 | [[item:268253@BgQAAEkACKgTBA]] | 盘绕祭坛 |
| 胸部 | 将 [[item:239048@BgQAAEkACKgTBA]]  <br>转化为 [[item:271540@DgQBAEkAJk7IoAOFAylO]] | 诸王之眠 已催化 |
| 手腕 | [[item:244576@FiRAAEkAtqC5BwDDtOAAAAAcbNLF]] | 制造装备 |
| 手套 | [[item:271538@BgQAAEkACKgTBA]] | 陵寝哨兵 |
| 腰带 | [[item:268256@BiQAAEkAM06IoAYF]] | 盘绕祭坛 |
| 腿部 | 将 [[item:268225@BgQAAEkACKAWBA]]  <br>转化为 [[item:271536@DgQBAEkAhu7IoAYFQwXQ]] | 盘绕祭坛已催化 |
| 脚部 | [[item:159327@DgQAAEkAxj7IoAOF]] | 塞塔里斯神庙 |
| 戒指1 | [[item:268249@DiQAAEkA1j7wQrjgC4UA]] | 瓦什尼克 |
| 戒指2 | [[item:158366@DiQAAEkA1j7wQrjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:270175@BgwAAEkACKAWBUAABo0FCA]] | 乌拉特克 |
| 饰品 2 | [[item:270173@BgQAAEkACKAWBA]] | 盘绕祭坛 |
| 武器 | [[item:268209@DgQAAEkADk7IoAYF]] & [[item:237840@HgQAAEkAeA8MQuDpqQ3WzSB]] | 盘绕祭坛与制造 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:239033@DiQAAEkAnk7wQrjgCEUA]] | 塞塔里斯神庙 |
| 项链 | [[item:251234@BkQAAEkAX16wQrjgCEUA]] | 虚空之痕竞技场 |
| 肩部 | [[item:251223@DgQAAEkAXk7IoABF]] | 虚空之痕竞技场 |
| 披风 | [[item:251132@BgQAAEkACKQQBA]] | 密谋小径 |
| 胸部 | [[item:239048@DgQAAEkAJk7IoABF]] | 诸王之眠 |
| 腕部 | [[item:251183@BiQAAEkAM06IoABF]] | 夺目谷 |
| 手套 | [[item:159312@BgQAAEkACKQQBA]] | 诸王之眠 |
| 腰带 | [[item:159317@BiQAAEkAM06IoABF]] | 塞塔里斯神庙 |
| 腿部 | [[item:251130@DgQAAEkAhu7IoABF]] | 密谋小径 |
| 靴子 | [[item:159327@DgQAAEkAxj7IoABF]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:158366@DiQAAEkA1j7wQrjgCEUA]] | 塞塔里斯神庙 |
| 戒指 2 | [[item:251136@DiQAAEkA1j7wQrjgCEUA]] | 密谋小径 |
| 饰品 1 | [[item:250215@BgQAAEkACKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250228@BgQAAEkACKQQBA]] | 密谋小径 |
| 武器 | [[item:251186@DgQAAEkADk7IoABF]] & [[item:251231@DgQAAEkADk7IoABF]] | 夺目谷 & 虚空之痕竞技场 |

:::

:::

### 饰品

以下是从地下城和团本可获得的上位饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgwAAEkACKAWBUAABo0FCA]]  <br>[[item:270173@BgQAAEkACKAWBA]]  <br>[[item:270168@BgQAAEkACKAWBA]]  <br>[[item:270164@BgQAAEkACKgTBA]] |
| **A级** | [[item:250215@BgQAAEkACKgTBA]]  <br>[[item:270166@BgQAAEkACKgTBA]]  <br>[[item:270165@BgQAAEkACKgTBA]] |
| **B级** | [[item:159617@BgQAAEkACKgTBA]]  <br>[[item:250259@BgQAAEkACKgTBA]]  <br>[[item:250228@BgQAAEkACKgTBA]]  <br>[[item:250225@BgQAAEkACKgTBA]]  <br>[[item:193757@BgQAAEkACKgTBA]]（已学习） |
| **C级** | [[item:250214@BgQAAEkACKgTBA]]  <br>[[item:273796@BgQAAEkACKgTBA]]  <br>[[item:158374@BgQAAEkACKgTBA]]  <br>[[item:273797@BgQAAEkACKgTBA]] |
| **垃圾级** | [[item:193757@BgQAAEkACKgTBA]]（未学习） |

### 美化饰品

- [[item:273060]] 是目前最强大的美化装饰。但它只能附在武器上，因此取决于你的角色拥有/需要制作哪些装备，制作 1 或 2 件带有该美化的武器很可能是最佳选择。
- [[item:273069]] 是第二强的美化，可以附在普通护甲部件上。由于可以放在任意部位，这让它的适用性更广，你或许还能把它制作在对角色收益更高的装备栏位上。
- [[item:240167]] 类似于 [[item:273069]]，但输出的 DPS 数值似乎略低一些。

#### 剩余的火花

- 制造装备的最高物品等级为331，而普通装备为334，因此，除了2件美化装备之外，装备其他制造装备会有轻微损失，除非你在该部位没有其他高物品等级装备可用。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - **[[item:241326]] *-- 最大化DPS。***
  
  
  
  - **[[item:241320]] *-- DPS略低但生存能力更强。***
- **食物**
  
  - **[[item:242273@BQAAAEkAaB]]**
- **战斗药水**
  
  - **[[item:241288]]**
- **治疗药水**
  
  - [[item:271884]] -- 一次大量的治疗爆发
- 武器
  
  - **[[item:243734]]**
- **强化符文**
  
  - **[[item:259085@BQAAAEkAaB]]**
- **宝石插槽**
  
  - **[[item:240908]]**
  - **[[item:240967]] *-- 唯一，每种颜色的宝石各用一颗来强化你的 [[item:240967]]。***
    
    - **[[item:240898]]**
    - **[[item:240914]]**
    - **[[item:240890]]**

### 附魔

:::columns
:::column
| 头部 | [[item:244007@DAAAAEkAZbAB]] & [[item:275707@DAAAAEkAnk7A]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAEkA]] |
| 胸部 | [[item:243977@BAAAAEkA]] |
| 护腕 | [[item:275707@DAAAAEkAnk7A]] |
| 腰部 | [[item:275707@DAAAAEkAnk7A]] |
| 腿部 | [[item:244641@BAAAAEkA]] |
| 靴子 | [[item:243953@BAAAAEkA]] |
| 戒指 1 | [[item:243957@BAAAAEkA]] |
| 戒指 2 | [[item:243957@BAAAAEkA]] |
| 武器 | 2x [[item:243971@BAAAAEkA]] |

:::

:::column
:::gear **浩劫 恶魔猎手** 团队副本中的附魔
```json
{
  "source_code": "IwFZBJQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NAREIgyA5OAAAAAABMQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243971]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707@DAAAAEkAnk7A]]，为你的 **头盔**、**护腕** & **腰带**添加插槽。

## 种族

若要追求 **浩劫 恶魔猎手** 团本中的极致优化，不同的种族特长可以为你的角色提供战斗收益。如果这不是你的首要目标，选择一个符合你风格的种族同样可行。

- [[spell:58984]] -- 暗夜精灵
  
  - 可用于消除仇恨，有时甚至可以完全规避某些机制。
  - 在 团队副本 中用途有限，但在 大秘境 中可能非常有用。
- [[spell:202719]] -- 血精灵
  
  - 移除你周围敌对目标身上的1个增益效果。
  - 产生15点 狂怒。
- [[spell:256948]] -- 虚空精灵
  
  - 在空间中撕开一道裂隙。再次激活该技能即可穿越裂隙传送。

### 推荐

对于 **浩劫 恶魔猎手** 来说，选择哪个种族其实并不重要，因为DPS差异微乎其微。不过建议团本选 鲜血 精灵，因为其DPS通常略高一点；而M+则推荐暗夜精灵，只要正确使用 [[spell:58984]]，它能为这类内容提供更出色的功能性。记住，如果你是 鲜血 精灵，[[spell:202719]] 在某些需要快速 范围伤害 驱散的情况下可能会派上用场，或者在怒气匮乏、战斗中远离所有目标时，可以用它来获得15点 狂怒。

## 宏

了解 **浩劫 恶魔猎手** 在 团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**@光标 [[spell:191427]] 宏 - *在光标所在位置使用你的 [[spell:191427]]***

```wow-macro
#showtooltip
/cast [@Cursor] 恶魔变形
```

**@Cursor [[spell:207684]] 宏 - *在你的鼠标指针位置使用你的 [[spell:207684]]***

```wow-macro
#showtooltip
/cast [@Cursor] 悲苦咒符
```

:::

:::details 鼠标指向宏
**@鼠标指向 [[spell:217832]]** **宏 - *如果你有鼠标指向目标，则对其施放 [[spell:217832]]***；如果没有鼠标指向目标，则对当前目标施放。

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] 禁锢
```

**@鼠标指向 [[spell:195439]]** **宏 - *如果你有鼠标指向目标，则打断该目标；如果没有鼠标指向目标，则打断当前目标。***

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] 瓦解
```

:::

:::details 通用宏
**@玩家 [[spell:191427]] 宏 - *在你当前所在位置使用你的 [[spell:191427]]***

```wow-macro
#showtooltip
/cast [@Player] 恶魔变形
```

**@焦点 [[spell:195439]] 宏 - *对焦点目标使用你的 [[spell:195439]]***

```wow-macro
#showtooltip
/cast [@focus] 瓦解
```

**设置焦点宏 - *如果你有鼠标指向目标，则将其设为焦点；如果没有鼠标指向目标，则将当前目标设为焦点。***

```wow-macro
/focus [@mouseover,exists][]
```

:::

:::

## 插件

下面是作者的 **浩劫 恶魔猎手**.

![](<https://assets-ng.maxroll.gg/wordpress/Skjermbilde-2026-08-08-020134-1024x575.png>)

Verb 的 **浩劫 恶魔猎手**

插件无论在战斗内外都非常有用。以下列出的插件通常被认为是任何团队副本玩家最必备的。

:::accordion
:::details 插件
- **MRT** -- 记事、团队副本 冷却时间等
  
  - 对团队副本玩家非常有用的插件，尤其是对 团队副本 指挥和官员而言。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一个首领战斗插件。它由许多独立的战斗脚本（即首领模块）组成；这些微型插件旨在为某场特定的 团队副本 战斗触发警报信息、计时条、音效等。
- **EllesmereUI** -- 全能型界面插件
  
  - 一款以用户友好为核心设计的界面，附带标准界面所不具备的额外功能。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**恶魔猎手**

- 浩劫
  
  - 开发者说明：以下对 狂怒 生成的改动是一次小幅的整体提升，节奏更加平滑，并降低了对 献祭光环 天赋效果的依赖。
  - 恶魔之刃、刃舞 和 混乱打击 现在需要装备战刃、斧、剑和拳套。
  - 新天赋：不死不休——生命值高于50%时伤害提高3%。生命值低于50%时吸血提高5%。
  - 毁灭之痕已更新——伤害现在立即生效，不再是持续4秒的持续伤害效果。
  - 锯齿战刃已更新——效果现在是施加于 恶魔猎手 身上的持续12秒增益，而不再是施加于敌方目标身上持续15秒的减益。
  - 刃舞 伤害提高6%。
  - 死亡横扫 伤害提高6%。
  - 混乱打击 伤害提高6%。
  - 毁灭 伤害提高6%。
  - 恶魔追击 伤害提高12%。
  - 献祭光环 伤害降低8%。
  - 精华破碎 初始伤害提高49%。
  - 燃烧之恨现在使 献祭光环 额外产生30点 狂怒（原为40点）。
  - 恶魔之刃 现在每次攻击产生10-16点 狂怒（原为8-15点）。
  - 盲眼 狂怒 现在使 眼棱 每秒产生10/20点 狂怒（原为15/30点 狂怒）。
  - 冲撞惯性 现在使伤害提高12%，持续6秒（原为提高18%，持续5秒）。
  - 内心恶魔已移位，现在是与混沌理论构成选择节点（原为与混沌变身构成选择节点）。
  - 混沌冲刺已被移除。

:::

:::

## 常见问题

:::accordion
:::details 问：为了X而留着[[talent:112939]]值得吗？
答：除非你只保留不到3-4秒，否则几乎不值得为了特定时机而留着眼棱。最好的做法还是直接让[[spell:198013]]、[[spell:258860]]和[[spell:198793]]冷却好了就用。

:::

:::

---

### 致谢

作者：**Verb**

审校：**Tief**

---

:::changelog 更新记录
**2026-08-08** 已更新至12.1版本

**2026-06-19** 已更新至12.0.7版本

**2026-02-10** 已更新至12.0.1版本

**2026-01-09** 已更新至12.0版本

**2025-12-03** 已更新至11.2.7版本

**2025-10-09** 已更新至11.2.5版本

**2025-08-03** 已更新至11.2.0版本

**2025-06-19** 已更新至11.1.7版本

**2025-02-25** 已更新至11.1.0版本

**2024-12-17** 已更新至11.0.7版本

**2024-10-23** 已更新至11.0.5版本

**2024-08-17** 已更新至11.0.2版本。

**2024-07-24** 攻略写于11.0.1前置版本。



:::
