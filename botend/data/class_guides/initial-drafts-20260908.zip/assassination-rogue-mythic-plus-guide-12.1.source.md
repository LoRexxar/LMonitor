Welcome to the **Assassination Rogue** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 2/5 · Weak

AoE · 5/5 · Strong

Utility · 2/5 · Weak

Survivability · 4/5 · Strong

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Assassination Rogue** Mythic+ Best in Slot
```json
{
  "source_code": "JUpAwT1ABc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOA_sOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADQgt7AECSAAkBwDYiqDIQrDAQBBwiIvsUABcJJEAACBAQBmBC3XQggIEAA1jbAKWgEAkdFSAgCBwGJOFQAf9BBAgwAAEQacUAABo0FCEAWBIRAChBWBEA24PAAFwAEOFQA1LSBECQBBQIHYFQANE6AGgQBESyA5OApqQgIvsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240892]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270168]] |  |
| 背部 | [[item:260312]] |  |
| 主手 | [[item:271093]] | [[item:243973]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Assassination Rogue**, you have access to Implacable, which increases your [[spell:32645]] damage by 10%, and and [[spell:32645]]  restores 2 energy per Combo Point.

**Rank 2** increases your Nature and Bleed damage by 20%.

While **Rank 3** makes your [[spell:192759]] build 6 Combo Points.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-assassination-mxr.webp>)

Implacable

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

The spec talent tree had a lot of changes.

- **Spec Tree**
  
  - [[talent:117139]]
    
    - Is no longer a dot, instead, applies both of your [[spell:703]] and your [[spell:1943]] on 2 nearby enemies.
  
  
  
  - [[talent:112660]] / [[talent:134835]].
    
    - Both of these are fairly strong. [[talent:112660]] is a decent amp, especially in aoe, while [[talent:134835]] is great at Combo Point generation.
  - [[talent:117130]]
    
    - Haste buff after your [[talent:112663]] expires.
  - [[talent:112672]]
    
    - Is its own talent now.
  - [[talent:112511]]
    
    - Extra amp during your [[talent:112662]].
  - [[talent:112667]]
    
    - Crit buff on finisher.
  
  
  
  - [[talent:112673]]
    
    - Was changed, now increases [[spell:703]] duration by 6s.
- **Class Tree**
  
  - [[talent:112636]]
    
    - Increases agility by 3%.
  
  
  
  - [[talent:112639]]
    
    - No longer a button, now it procs from your generators and increases your next finisher crit by 10%.
  - [[talent:112644]]
    
    - Extra attack speed from your [[spell:5171]].
- **Removed**
  
  - [[spell:324073]]
  
  
  
  - [[spell:455143]]
  - [[spell:170882]]
  - [[spell:341534]]
  - [[spell:455131]]
  - [[spell:400783]]
  - [[spell:381802]]
  - [[spell:394983]]
  - [[spell:255989]]
  - [[spell:200806]]
  - [[spell:340078]]
  - [[spell:273488]]
  - [[spell:381634]]

## Hero Talents



### [[talent:123375]]

- Your [[spell:703]] marks your target with 3 stacks of [[talent:117733]]. 
  
  - You can only have 1 [[talent:117733]] active.
  - Consume a stack of [[talent:117733]] by using a 5 Combo Point or more finisher.
  - You can only apply the [[talent:117733]] with [[spell:703]]

- After consuming the last stack of [[talent:117733]], or if a mob dies while the [[talent:117733]] is active, you gain [[talent:117739]].
  
  - When [[talent:117739]] is up, always make sure your next finisher is an [[spell:32645]] with 7 Combo Points.
  
  
  
  - When you consume [[talent:117739]], you apply [[talent:117733]] on the mob you have targetted.

Additionally, there are a few more capstones in the tree that are important.

- [[talent:117707]]
- [[talent:117732]].
- [[talent:126029]]
  
  - A defensive node that makes [[talent:112657]] even stronger. [[talent:117703]] is also interesting but much more fight specific.
- [[talent:136020]]
  
  - Passive crit bonus.
- [[talent:136019]]
  
  - A little bit of extra flavor every time you apply mark, but realistically not a big thing.
- [[talent:136018@AJAB]]
  
  - Adds a bit of extra damage in aoe or cleave scenarios, ignoring your main target.
- [[spell:457055]]
  
  - A bit of extra funnel on your main target.




### [[talent:123371]]

- Much like in the [[talent:123375]] tree, every 5 Combo Point or more finisher that you use has a chance to flip a coin.
  
  - Landing on [[spell:452923]] increases your damage by 10%. Additional flips landing on [[spell:452923]] increase damage by 2%. Stacking
  - Landing on [[spell:452538]] does Cosmic damage. Additional flips increase [[spell:452538]] damage by 10%. *Stacking*
- [[talent:117724]]
  
  - Every 7 coin flips, you gain a 4% agility buff, plus:
    
    - Both [[spell:452923]] and [[spell:452923]] bonuses increase by 50%.
    - Coin flips are 15% more likely to match the same flip as the previous one.

Neither of these flips offer much in terms of gameplay, and you could do without tracking any of them, but there is some minmaxing you can do with the talents in the Fatebound tree.

- [[talent:117736]].
  
  - Rolling both flips after you use your [[talent:112662]].
- [[talent:117717]]
  
  - Makes your [[talent:112672]] hit 5% harder.
- [[talent:136025]]
  
  - Passive crit.
- [[talent:136026]]
- [[talent:136024]]





## Talents



### [[talent:123375]]

:::talents [[talent:123375]] **Assassination Rogue** Mythic+ Standard Build
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:112672]]
  
  - One of the strongest talents in your kit. Similar to [[spell:13877]], but instead cleaves from your target with the debuff..
- [[spell:360194]]
  
  - Your big cooldown. Increases the damage of your [[spell:703]], [[spell:1943]], and Lethal Poisons on your target by 100%, while allowing for your Lethal Poisons to stack twice.
- [[talent:112649]]
  
  - Helps with building up your Combo Points for a finisher which is another reason why Crit is a good stat for you.
- [[talent:112668]]
  
  - Agility amplifier that gives a lot of power
- [[talent:117131]]
  
  - Enables the use of an additional lethal poison.

##### Class Tree

- [[talent:112648]]
- [[talent:114737]] / [[talent:112632]]
  
  - If you are learning a key, and especially in lower levels, I recommend playing [[talent:114737]] as it allows for mistakes and its less punishable. [[talent:112632]] is simply required at higher key levels to live certain mechanics.

#### Hero Talents

- [[talent:117706]]
  
  - Significantly better than [[talent:126030]].
- [[talent:117720]]
  
  - This is very useful when you have to move around. Meanwhile the alternative, [[talent:126027]], doesn't offer much, unless you have a tight skip in your route.
- [[talent:126029]]
  
  - A very nice addition to our kit that makes [[talent:112657]] stronger in Dungeons.
  - [[talent:117703]] can also be decent if you need a longer [[talent:112585]] for a specific mechanic.

#### Poisons

1. This build uses the following Poisons: 
   
   - [[talent:112676]]
   - [[spell:381664]]
   
   
   
   - [[spell:5761]]




### [[talent:123371]] Variation

:::talents [[talent:123371]] **Assassination Rogue** Mythic+ Build
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhNjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhNjFzMYmZMGA"
}
```
:::

#### Talent Adjustments

Fatebound variation.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:32645]] damage increased by 10% and it increases your damage dealt by 3%.
- **4-Set:** [[spell:2818]] increases your bleed damage on the target by 10%. Auto-attacks to targets with your [[spell:381664]] deal 3% increased damage per stack. [[spell:8679]] hits a second time.

### Single-Target



#### [[talent:123375]]

##### Opener

- Your goal is to keep [[spell:32645]]. Below, you see an example of how your opener looks when using the recommended **Single Target** talent spec

:::rotation [[talent:123375]] **Assassination Rogue** single-target opener in Raids
```json
{
  "source_code": "J0GELI0vCAQABggQxUQAHwAACd5BJgQEQkAIQIQAc66ABkBTB81HEAADCAAWCKQBAEgSXIgQF-XAYABACJwfFEQCMI09wLQBIEBGkETBAAAAAAgQF-H"
}
```
1. [[spell:703]]
2. [[spell:1329]]
3. [[spell:1943]]
4. [[spell:1329]]
5. [[spell:703]]  [[item:241308]] · [[item:270175]]
6. [[spell:32645]]
7. [[spell:360194]]
8. [[spell:192759]]
9. [[spell:32645]]
10. [[spell:1329]]
11. [[spell:32645]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. [[spell:703]] first global to apply [[talent:117733@AJAB]].
2. Keep up [[spell:1943]] and [[spell:703]] throughout the fight.
   
   1. Do not overwrite your [[talent:112673]] and instead apply [[spell:703]] as soon as the buffed one expires.
3. Always [[spell:32645]] at 7 Combo Points with [[talent:117739]] up.
4. Be ready to refresh your bleeds before your [[spell:360194]] and [[spell:385627]] come off cooldown, start preparing for them once they have approximately 8 seconds remaining on their cooldown.
5. Press [[spell:1329]] if not at 5 Combo Points.




#### [[talent:123371]]

##### Opener

- Your goal is to keep [[spell:32645]] and [[spell:5938]] up for the entire duration of your cooldowns. Below, you see an example of how your opener looks when using the recommended **Single Target** talent spec.
- *This is one variation of the* [[talent:123371]] opener, more on this under the **Deep Dive** section.

:::rotation [[talent:123371]] **Assassination Rogue** single-target opener in Raids
```json
{
  "source_code": "J0GELI0vCAQABggQxUQAHwAACd5BJgQEQkAIQIQAc66ABkBTB81HEAADCAAWCKQBAEgSXIgQF-XAYABACJwfFEQCMI09wLQBIEBGkETBAAAAAAgQF-H"
}
```
1. [[spell:703]]
2. [[spell:1329]]
3. [[spell:1943]]
4. [[spell:1329]]
5. [[spell:703]]  [[item:241308]] · [[item:270175]]
6. [[spell:32645]]
7. [[spell:360194]]
8. [[spell:192759]]
9. [[spell:32645]]
10. [[spell:1329]]
11. [[spell:32645]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:1943]] and [[spell:703]] throughout the fight.
   
   - Do not overwrite your [[talent:112673]] and instead apply [[spell:703]] as soon as the buffed one expires.
2. Be ready to use your [[spell:360194]] and [[spell:385627]] as soon as they come off cooldown, start preparing for them once they have approximately 8 seconds remaining on their cooldown.
3. [[spell:32645]] with 5 Combo Points.
4. Press [[spell:1329]] if not at 5 Combo Points.





### AoE



#### [[talent:123375]]

##### Opener

- In your opener, your goal is to spread your DoTs up every mob with your [[talent:117139]] before using your cooldowns on a mob with high hp.

:::rotation [[talent:123375]] **Assassination Rogue** AoE opener in M+
```json
{
  "source_code": "IEFEKI0vCAQABggQLocAHwAACd5BJgQEYAy-HMBAAIwMUBQDKQQNUlBLIU4fAEQAsIkA_VAAAAAACdP8CA"
}
```
1. [[spell:703]]
2. [[spell:51723]]
3. [[spell:1943]]
4. [[spell:703]]
5. [[spell:1247227]] 3T
6. [[spell:1247227]] 5T
7. [[spell:51723]]
8. [[spell:32645]]
9. [[spell:360194]]
10. [[spell:192759]]
:::

##### Priority List

1. Spread your [[spell:703]] and [[spell:1943]] on all mobs with [[talent:117139]].
   
   - Minimum of 5 [[spell:1943]] to at least get max stacks of [[talent:112668]].
2. [[spell:32645]] to apply [[spell:421975]].
3. Keep up [[spell:1943]] and [[spell:703]] throughout the fight on all enemies that are going to live its duration. [[spell:1943]] has priority.
4. Use [[spell:51723]] as your builder on 3 enemies or more.
5. Use [[spell:32645]] if every DoT is up.




#### [[talent:123371]]

##### Opener

- In your opener, your goal is to spread your DoTs up every mob with your [[talent:117139]] before using your cooldowns on a mob with high hp.

:::rotation [[talent:123371]] **Assassination Rogue** AoE opener in M+
```json
{
  "source_code": "IEFEKI0vCAQABggQLocAHwAACd5BJgQEYAy-HMBAAIwMUBQDKQQNUlBLIU4fAEQAsIkA_VAAAAAACdP8CA"
}
```
1. [[spell:703]]
2. [[spell:51723]]
3. [[spell:1943]]
4. [[spell:703]]
5. [[spell:1247227]] 3T
6. [[spell:1247227]] 5T
7. [[spell:51723]]
8. [[spell:32645]]
9. [[spell:360194]]
10. [[spell:192759]]
:::

##### Priority List

1. Spread your [[spell:703]] and [[spell:1943]] on all mobs with [[talent:117139]].
   
   - Minimum of 5 [[spell:1943]] to at least get max stacks of [[talent:112668]].
2. [[spell:32645]] to apply [[spell:421975]].
3. Keep up [[spell:1943]] and [[spell:703]] throughout the fight on all enemies that are going to live its duration. [[spell:1943]] has priority.
4. Use [[spell:51723]] as your builder on 3 enemies or more.
5. Use [[spell:32645]] if every DoT is up.





## Deep Dive

### When to Refresh Your Garrote and Rupture

- With [[spell:169629]] removed from **Assassination Rogues**, you are no longer able to snapshot your bleeds, with the exception of [[spell:703]] with [[talent:112673]]. Because of this, you need to follow a few rules when refreshing [[spell:703]].
  
  - If your current [[spell:703]] is buffed with [[talent:112673]], do not overwrite it and leave it to expire before applying it again.
  - If your current [[spell:703]] is not buffed with [[talent:112673]], you do not have cooldowns running, and it has less than 5.2s left on it, refresh it.
- With [[spell:1943]] being a Combo Point based finisher, it uses a flexible pandemic. This means that regardless of how many Combo Points the current [[spell:1943]] on your target was used with, the pandemic is calculated with the Combo Points of the new cast of [[spell:1943]]. The list below are the rules to follow for optimal refreshing:
  
  - If you currently have 5 Combo Points, you can safely refresh your [[spell:1943]] at 7.2s or less.
  - If you currently have 6 Combo Points, you can safely refresh your [[spell:1943]] at 8.4s or less.
  - 1: 2.4s
  - 2: 3.6s
  - 3: 4.8s
  - 4: 6s
  - 7: 9.6s
  - 8: 10.8s
  - 9: 12s
  - 10: 13.2s

### Maximizing Your Deathmark and Kingsbane window.

- [[spell:32645]] needs to have 100% uptime during your cooldowns.

Outside of your Opener, your 2 minute cooldown usage is very similar, this is the most important rule to follow when setting up for [[spell:360194]]:

1. Always refresh your bleeds before using [[spell:360194]] if they have 18 seconds or less at the moment that you press it. In particular:
   
   - Refresh your [[spell:1943]] at 6+ Combo Points.
   
   
   
   - [[spell:1329]] to 6 Combo Points then [[spell:32645]] before pressing your [[spell:360194]].

:::rotation **Assassination Rogue** Mythic+ Cooldown Usage mid-boss fight.
```json
{
  "source_code": "IQFEKI0lHAQABggQ_KQAHwAACFTBugAAsEQAc66AAAAAAIUh_FwBMAgQC8XBhggQ3DfBxUBGkETBAAAAAAgQxUA"
}
```
1. [[spell:1943]]
2. [[spell:703]]
3. [[spell:1329]]
4. [[spell:1329]]  [[item:241308]]
5. [[spell:32645]]
6. [[spell:360194]]
7. [[spell:192759]]
8. [[spell:32645]]
9. [[spell:1329]]
10. [[spell:1329]]
:::

- **This is not a fixed rotation**; This is just one example of how to play during your [[spell:360194]] window. Critical hits can potentially alter the ability usage.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Assassination Rogue** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- **Pay extra attention to these casts:**
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[spell:1856]].




### Den of Nalorakk

:::talents **Assassination Rogue** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with [[spell:1856]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Assassination Rogue** Mythic+ Build in Murder Row
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- **Pay extra attention to these casts:**
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Assassination Rogue** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Assassination Rogue** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- **Pay extra attention to these casts:**
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.




### Kings' Rest

:::talents **Assassination Rogue** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- **Pay extra attention to these casts:**
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Assassination Rogue** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- **Pay extra attention to these casts:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Assassination Rogue** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA",
  "code": "COQAxSGv8NzbxeTO653C6Eg9HbmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMzYmxMDmxMjxAsMzyYhxMmlGz22wkthhFjFzMYmZMGA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- **Pay extra attention to these casts:**
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Assassination Rogue**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Assassination Rogue** Stats in Mythic+
```json
{
  "source_code": "JoAJFMQMgQCKBMQABA"
}
```
**敏捷 ＞ 精通 ≥ 暴击 ＞ 急速 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271508@DwQAAMQAXk74kgC4UA]] | The Lost Explorers / Catalyst |
| Cloak | [[item:251190@BgQAAMQACKgTBA]] | The Blinding Vale |
| Chest | [[item:271513@DgQAAMQAJk7IoAOF]] | Vashnik the Malignant / Catalyst |
| Wrist | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | Crafting |
| Gloves | [[item:271511@BgQAAMQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:268256@BiQAAMQAS06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]] into [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268261@DgQAAMQAPk7IoAOF]] | The Twin Fangs |
| Ring 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:268249@DiQAAMQA1j7oQrjgC4UA]] | Vashnik the Malignant |
| Trinket 1 | [[item:270175@BwgAAMQAYJoAFAQAKdhA]] | Ula'tek |
| Trinket 2 | [[item:270168@BgQAAMQACKAWBA]] | Ula'tek |
| Weapon | [[item:271093@DgQAAMQADk7IoAYF]] | Ula'tek |
| Weapon | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | Crafting |

Assassination Rogue BiS list in Mythic+




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | Altar of Fangs |
| Neck | [[item:273781@BiQAAMQAH16IoABF]] | Altar of Fangs |
| Shoulder | [[item:251223@DgQAAMQAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:251190@BgQAAMQACKQQBA]] | The Blinding Vale |
| Chest | [[item:251159@DgQAAMQAJk7IoABF]] | Den of Nalorakk |
| Wrist | [[item:251135@BiQAAMQAU06IoABF]] | Murder Row |
| Gloves | [[item:251124@BgQAAMQACKQQBA]] | Murder Row |
| Belt | [[item:159317@BiQAAMQAE06IoABF]] | Temple of Sethraliss |
| Legs | [[item:251130@DgQAAMQAhu7IoABF]] | Murder Row |
| Boots | [[item:159327@DgQAAMQAPk7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@DiQAAMQA1j7wPrjgCEUA]] | Temple of Sethraliss |
| Ring 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:250215@BgQAAMQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250259@BgQAAMQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAMQACKAWBUAABo0FCA]] |
| **A-Tier** | [[item:270168@BgQAAMQACKAWBA]]  <br>[[item:270173@AgQAAIoAYFA]] |
| **B-Tier** | [[item:270164@AgQAA8rBOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **Junkyard** | [[item:270166@AgQAAIoAOFA]]  <br>[[item:159617@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]] |

### Embellishments

- [[item:273059]]
- [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:245933]] *-- maximum DPS*.
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240898]]
  
  
  
  - [[item:240914]] x1
  - [[item:240906]] x1
  - [[item:240890]] x1
  - [[item:240966]] *-- Unique, use one of each gem color to enhance your [[item:240966]].*
- *Always consult a sim before changing your gems.*

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAMQAnk7A]] - [[item:243949]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAMQA]] |
| Cloak |  |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@DAAAAMQAnk7A]] |
| Waist | [[item:275707@DAAAAMQAnk7A]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:243957@BAAAAMQA]] |
| Ring 2 | [[item:243957@BAAAAMQA]] |
| Weapon | [[item:243973@BAAAAMQA]] |
| Weapon | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **Assassination Rogue** Enchantments in Mythic+
```json
{
  "source_code": "JwFZDEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCoUQuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAMQAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing as an **Assassination Rogue** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
  - You can also re-stealth during trash, but **not** during boss fights.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial but lines up poorly with [[talent:112662]]
- [[spell:33702]] *-- Orc* 
  
  - Strong racial for damage that very competitive now since it scales with level and lines up with your [[talent:112662]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.
- [[spell:255669]] -- Void Elf
  
  - Decent passive trait.
- [[spell:312923]] -- Mechagnome
  
  - Fairly strong passive trait that scales with level, hence why it's so strong now.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Assassination Rogue**.

## Macros

Discover recommended macros for **Assassination Rogues** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
**[[spell:703]]** -- *Casts [[spell:703]] on your mouseover or target.*

```wow-macro
#showtooltip Garrote
/cast [@mouseover,exists] Garrote;Garrote
```

**[[spell:1943]]** -- *Casts [[spell:1943]] on your mouseover target if it exists, is not dead and is hostile, else Rupture is cast on your target*.

```wow-macro
#showtooltip
/cast [@mouseover,exists,nodead,harm] Rupture;Rupture
```

*Sets your **focus** and **places a marker** on them when you mouseover a mob. This is great for letting you teammates know what you are planning on using your* **[[spell:1766]]** *on**.***

```wow-macro
/focus [@mouseover][]
/run SetRaidTarget("mouseover",6)
```

**[[spell:36554]]** *on your mouseover target*

```wow-macro
#showtooltip Shadowstep
/cast [@mouseover] Shadowstep
```

*Mouseover* **[[spell:1766]]** *if you prefer that over focus target.*

```wow-macro
#showicon Kick
/cast [target=mouseover] Kick
```

:::

:::details Focus Macros
**[[spell:36554]] + [[spell:1766]]** *on your focus mob. This macro is used as a "ranged" [[spell:1766]].*

```wow-macro
/cast [@focus] Shadowstep
/cast [@focus] Kick
```

**[[spell:1766]]** *your focus target*

```wow-macro
#Show Kick
/cast [target=focus] Kick
```

*Cast* **[[talent:112631]]** *on your focus*

```wow-macro
#showicon Gouge
/cast [target=focus] Gouge
```

*Focus* **[[spell:408]]** *for extra CC*

```wow-macro
#showicon Kidney Shot
/cast [@focus] Kidney Shot
```

*Focus* **[[spell:1833]]**

```wow-macro
#showicon Cheap Shot
/cast [@focus] Cheap Shot
```

---

:::

:::details Utility Macros
**[[spell:360194]]** + **[[spell:10060]]** **Macro** - *Replace "Rycn-Tarrenmill" and "Give PI plz" with the priest you are getting the PI from and what they tell you their PI macro triggers from.*

```wow-macro
#show Deathmark
/w Rycn-TarrenMill Give PI plz
/cast Deathmark
```

*On this macro you can replace the names with the tanks in your group to make using* **[[talent:112574]]** *much easier.*

```wow-macro
#show Tricks of the Trade
/cast [@Meeresdh] Tricks of the Trade
/cast [@Meeresmana] Tricks of the Trade
/cast [@Méèrès] Tricks of the Trade
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Assassination Rogue**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://i.gyazo.com/737a316d3f0b0d850b3ce2b4b3e1f6af.jpg>)

**Assassination Rogue** Interface

:::accordion
:::details Addons
- **Ellesmere UI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Class
  
  - Thistle Tea is now a choice talent – Players may now choose between the existing version, which casts automatically at low Energy in addition to being usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds). Duration remains unchanged in PvP combat.
- Hero Talents
  
  - Fatebound
    
    - Deal Fate now has a 60% chance to grant an extra combo point when you Seal Fate (was 100%).
  - Deathstalker
    
    - Fixed an issue that caused Unshakable Drive's bonus to multiply with each stack.
    - Fixed an issue that often caused Unshakable Drive to remove more than one stack per ability use.
- Assassination
  
  - Developers' notes We're making some updates to Assassination's Energy economy in Curse of Ula'tek. We aren't happy with how the Rank 1 Implacable apex talent is playing – it's unintuitive for optimal play to intentionally let Envenom drop. We're updating its design so refreshing Envenom late is consistently the best way to play and giving it consistent Energy recovery value. We're also making some changes aimed at increasing talent build options.
  - New Talent: Unstable Toxin – Envenom damage increased by 18%, but its duration is reduced by 2 seconds.
  - Apex Talent: Implacable (Rank 1) has been updated – Envenom damage increased by 10%. Envenom now restores 2 Energy per combo point spent.
  - Apex Talent: Implacable (Rank 3) – Implacable Strike damage increased by 15%.
  - Internal Bleeding has been updated – Now triggers from casting Kidney Shot and Rupture, rather than also being applied when copying Ruptures with Crimson Tempest. Damage increased by 10%.
  - Iron Wire has been updated – Garrotes applied from stealth or during the Improved Garrote window now silence the target for 5 seconds. Damage reduction behavior unchanged.
  - Dashing Scoundrel has been updated – Envenom's effect now also increases the critical strike chance of your weapon poisons by 10% (was 5%). Your Energy generation is increased by 4% for each lethal poison on your weapons.
  - All damage dealt increased by 20%.
  - Deathmark increases the damage of your Rupture, Garrote, and Lethal Poisons by 75% (was 100%).
  - Kingsbane damage reduced by 15%.
  - Shrouded Suffocation increases Garrote damage by 30% (was 20%).
  - Avulsion increases Rupture damage by 25% (was 20%).
  - Motivated Murderer Energy increased to 30% (was 20%).
  - Rapid Injection damage bonus increased to 20%/40% (was 15%/30%).
  - Venomous Wounds generates more Energy when multiple targets are affected by your bleeds.
  - Blindside's chance to trigger reduced to 10% (was 15%), and 20% when the target is at low health (was 30%).
  - Poison Bomb's visual has been adjusted to make other important visuals on top of it easier to see.
  - Lethality and Cold Blooded-Killer now work correctly with the strikes dealt by Implacable (Rank 3).
  - Several talents have changed positions in the talent tree.
  - Deadly Momentum has been removed.

:::

:::

## FAQ

:::accordion
:::details


:::

:::

---

### Credits

Written By: **Perfecto**

Reviewed By: **Verb**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-10** Updated for patch 12.0.1.

**2026-01-13** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-07-29** Updated for patch 11.2.

**2025-06-19** Updated for patch 11.1.7.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-14** Updated for patch 11.1.

**2024-12-16** Updated for patch 11.0.7.

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
