Welcome to the **Arms Warrior** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 3/5 · Average

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Arms Warrior** Mythic+ Best in Slot
```json
{
  "source_code": "JwsAwj3RAc__AEAYkQggoAAANk7AH16A8Vjg1YjM2WjgCEQ6XQAApAAAE06AU06AMWDZ1ghNeVjgCEgXkQgAgAAA7j7A-VTg1YjMCKQAjRCBCASBAkQuDoXNCWDG2IoAYFgvXQQAjfBBACSAAoQrDghNeVjt1IoAYFQAGYCBBAEEju7AWYTDThJBhOgAAFAApk7A2-yY1ENMWJCD2cbNHXDAjsUABoQoDAISBAg-sOgLdAAA2GxHcEGJEAAIFAweNwIWOFgTVPQAil9ACCSAAUPuDoQrDQWN2ITA6ShTBEAgtQgUYAAGf9BBAghAAkwjcUAABc1FCEQXBQBAA0AFYEQ3XQAAYEQDOgEWBEQtXQgAYAAAFk7AYYjX1IoA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271456]] | [[item:240967]] · [[item:243981]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240916]] |
| 肩部 | [[item:271454]] | [[item:243963]] |
| 胸部 | [[item:271459]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240906]] |
| 腿部 | [[item:271878]] | [[item:244643]] |
| 脚部 | [[item:237828]] | [[item:244009]] |
| 腕部 | [[item:237834]] | [[item:240890]] |
| 手部 | [[item:271457]] |  |
| 戒指一 | [[item:252258]] | [[item:240906]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268213]] | [[item:243973]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Arms Warrior**, you have access to [[spell:1269394]], which gives your single-target abilities a chance to upgrade your next [[spell:1464]] to be a [[spell:1269383]]. This [[spell:1269383]] gives you a [[spell:1269394]] buff that causes your attacks to penetrate 3% armor per stack for 30 seconds.

**Rank 2** causes your [[spell:1269394]] buff to additionally increase your [[talent:112122]] and [[talent:112147]] damage by 2.5%/5% per stack.

**Rank 3** causes your [[spell:1269383]] to increase the damage you deal to enemies affected by your next [[talent:112144]] by an additional 3%, stacking up to 5 times.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-arms-mxr.webp>)

Master of Warfare

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- Mastery changed from [[spell:262111]] to [[spell:1258398]].

- **Spec Tree**
  
  - [[talent:114739]] or [[talent:114641]] 
    
    - On a choice node, we can choose a talent to significantly boost our 2-target damage.
  - [[talent:135942]]
    
    - Works well with [[talent:114641]] and especially [[talent:114739]].
  - [[talent:135940]]
    
    - [[talent:135940]] can now be applied by [[spell:163201@FJQCVBVAZdhAKunA_NEBj0wBk0wBX3yEeOzE1PNBBA]], or by [[talent:112147]] and [[talent:112122]] if they critically strike, through [[talent:135941]].
  - [[talent:112311]]
    
    - [[talent:112311]] is still applied by [[talent:112122]], but is no longer triggered at 30% health, instead is now triggered whenever you use an [[spell:163201@FJQC1PNBVBVAZdhAKunA_NEBj0wBk0wBX3yEeOzEBA]], dealing more consistent damage in Midnight.
  - [[talent:135939]] or [[talent:135938]] Choice Node
    
    - We can empower our [[talent:112144]], either getting more [[talent:112147]] casts which is very powerful in AoE, or getting more [[talent:112123]] through [[talent:112134]] that can be powerful in single-target.
  - [[talent:136702@AJQA]]
    
    - [[talent:136702@AJQA]] is now cast on your target and now has the effects of Merciless Bonegrinder baseline, increasing [[talent:112147]] damage by 50% while active.
- **Class Tree**
  
  - [[talent:134031@AJQABA]]
    
    - Can provide a massive survivability boost if you are taking frequent big hits and utilizing your [[talent:114644]].
    - The offensive part of the talent provides only a small damage increase, making this talent sometimes a damage loss to pick compared to alternatives.
  - [[talent:136627]]
    
    - Now additionally increases the movement speed of allies within 12y(or 24y) by 30% for 4 seconds!
  - [[talent:134033]]
    
    - Improves all your shout abilities.
- **Removed**
  
  - [[spell:384318]]
  
  
  
  - [[spell:383762]]

## Hero Talents

- [[talent:123393]] is a viable option for AoE, but [[talent:123390]] being significantly stronger on single-target makes it the recommended option.



### [[talent:123393]]

- [[talent:117415]]
  
  - Gets significantly buffed by [[spell:440989@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]], [[talent:136071@AJQA]] and [[talent:136073]].
- [[talent:119856@AJQA]] and [[talent:136072@AJQA]]
  
  - [[talent:135597]] and [[spell:262115]] deals a lot of damage, especially in AoE situations common in Mythic+.
- [[talent:117390]]
  
  - Your [[talent:117415]] gets its cooldown reduced, making it a bit tricky to line up with your other cooldowns sometimes.

#### New in 12.0 Midnight

- [[talent:136073]]
  
  - Applies [[talent:135940]] to all targets hit by [[talent:117415]].
- [[talent:136072@AJQA]]
  
  - Further emphasizes [[talent:123393]] bleed damage that was already increased from [[talent:119856@AJQA]].
- [[talent:136071@AJQA]]
  
  - Increases your burst damage significantly with [[talent:117415]].




### [[talent:123390]]

- [[talent:117411]]
  
  - [[spell:445579]] deals significant damage and grants the [[spell:445584]] buff.
- [[talent:117407]]
  
  - Getting a [[spell:444775@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]] proc or using [[talent:112314]] applies [[spell:445836]].
- [[talent:117385]]
  
  - Every third [[spell:445579]] procs a [[talent:112126@AJQA]].
- [[spell:444774@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]] and [[spell:444779@FJwBVBVAZdhAKunAf__A_NEBj0wBk0wBBA]]
  
  - [[talent:112123]] deals a lot of damage when playing [[talent:123390]].
- [[talent:117417]]
  
  - Consuming [[talent:112126@AJQA]] reduces the cooldown of [[talent:112314@AJQA]] based on how many stacks of  [[spell:445584]] you have.

#### New in 12.0 Midnight

- [[talent:136076]]
  
  - [[talent:112314@AJQA]] gives you a haste buff.
- [[talent:136075]]
  
  - Increases the duration of [[spell:445584]].
- [[talent:136074@AJQA]]
  
  - In The War Within [[talent:136074@AJQA]] was in the Class tree, but now it is a Hero talent.





## Talents



### [[talent:123390]] Talents

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[talent:112147]]
  
  - [[talent:112147]] becomes your primary damage-dealing ability in AoE situations.
- [[talent:112144]]
  
  - With [[talent:135942]], [[talent:112144]] applies [[spell:260708]].
- [[talent:136703@AJQA]]
  
  - Your primary big DPS cooldown.

##### Class Tree

- [[talent:135597]]
  
  - Deals damage over time, applied to enemies with [[talent:112147]].
- [[talent:134032@AJQA]]
  
  - You get to use your cooldowns significantly more often with this talent, and it puts some value on the act of simply spending rage by itself.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **Jade Warlord's Dominion (2pc):** [[talent:112122]] and [[spell:163201]] damage increased by 10% and when you [[spell:1464]] a target, [[spell:1464]] also deals additional damage to enemies within 8yds of it with . Deals reduced damage beyond 5 targets.
- **Jade Warlord's Dominion (4pc):** [[talent:112123@FAQANNA]] damage increased by 15%. [[talent:112122]] and [[talent:112123@FAQANNA]] increase the damage of your next [[spell:1464]] by 20%, stacking up to 5 times.

### Single-Target



#### [[talent:123390]]

##### Pre-Execute Phase

###### Opener

- Use a [[talent:112126@AJQA]] in the opener to get an additional strike on your first [[talent:112314@AJQA]] because of [[talent:117385]], that will also trigger an additional [[talent:112122]] through [[talent:136074@AJQA]].

:::rotation **Arms Warrior** [[talent:123390]] Opener
```json
{
  "source_code": "IIDDGIEZAUQAIIUTDkACAFBAEAAAAEgQ2QaAAAgQB2nABcBKCdgeDAAAAAgQGAD"
}
```
1. [[spell:100]]
2. [[spell:845]]
3. [[spell:262161]]  [[spell:107574]]
4. [[spell:163201]]
5. [[spell:227847]]
6. [[spell:12294]]
:::

###### Pre-Execute Priority List

This is a general priority you aim to maintain when fighting a single target pre-execute.

1. Use [[talent:112147@FAQAEMA]] to apply [[talent:135597]], or refresh [[talent:135597]] if you are just about to use [[talent:112144]] and [[talent:135597]] would run out during [[talent:112144]].
2. Use [[talent:136703@AJQA]] if [[talent:112144]] is ready ready in less than ~8 seconds, or if [[talent:112144]] debuff is up.
   
   - [[talent:112144]] itself does not deal a lot of initial damage, so in many situations it can be good to only use [[talent:136703@AJQA]] once [[talent:112144]] is already applied and you are about to use your first GCD within the [[talent:112144]] debuff, like shown above in the Opener.
3. Use [[spell:163201]] with [[talent:112126@AJQA]] if you have 2 stacks, or if it's about to run out.
4. Use [[talent:112144@FAQA43zE]] on cooldown.
5. Use [[talent:112314@AJQA]] on cooldown. 
   
   - Only bad time to use it is if [[talent:112144]]  has less than ~4 seconds remaining cooldown and you end up delaying [[talent:112144]].
   - Use [[talent:112198]] while channeling [[talent:112314@AJQA]].
6. Use [[spell:1269383]].
7. Use [[talent:112122]] on cooldown.
8. Use [[spell:163201]] with [[talent:112126@AJQA]].
9. Use [[talent:112123@FAQANNA]] on cooldown.
10. Use [[talent:112147@FAQAEMA]] to refresh [[talent:135597]] if it has less than 6 seconds remaining.
11. Use [[spell:1464]].

##### Execute Phase

###### Cooldowns

:::rotation **Arms Warrior** [[talent:123390]] Execute Cooldowns
```json
{
  "source_code": "IIbAYegQB2nAFJQCVBVAZdhAKunA_NEBj0wBk0wBX3yEeOzE1PNBBAAAAopJAgUEAQAAAAQACZDpBAAACdgeDAAAiyDAWiIAEYAM"
}
```
1. [[spell:163201]]
2. [[spell:163201]]
3. [[spell:262161]]  [[spell:107574]]
4. [[spell:227847]]
5. [[spell:163201]]
6. [[spell:163201]]
7. [[spell:12294]]
:::

###### Execute Priority List

This is a general priority you aim to maintain when fighting a single target in execute.

1. Use [[talent:136703@AJQA]] if [[talent:112144]] is ready ready in less than ~8 seconds, or if [[talent:112144]] debuff is up.
   
   - [[talent:112144]] itself does not deal a lot of initial damage, so in many situations it can be good to only use [[talent:136703@AJQA]] once [[talent:112144]] is already applied and you are about to use your first GCD within the [[talent:112144]] debuff, like shown above in the Cooldowns.
2. Use [[talent:112144]] on cooldown.
3. Use [[talent:112314@AJQA]] if you have 2x [[talent:112318]].
   
   - Only bad time to use it is if [[talent:112144]]  has less than ~4 seconds remaining cooldown and you end up delaying [[talent:112144]].
   - Use [[talent:112198]] while channeling [[talent:112314@AJQA]].
4. Use [[spell:163201]] with [[talent:112126@AJQA]] if you have 2 stacks.
5. Use [[spell:1269383]].
6. Use [[spell:163201]] if you will use [[talent:112314@AJQA]] in less than 3 seconds or if you have [[talent:112126@AJQA]].
7. Use [[talent:112123@FAQANNA]] if you have less than 50 rage.
8. Use [[talent:112122]] if you have 2x [[talent:112318]].
9. Use [[spell:163201@FJQCVBVAZdhAKunA_NEBj0wBk0wBX3yEeOzE1PNBBA]].
10. Use [[talent:112215]].





### 2-Target

- The single-target priority lists apply when fighting 2 targets, with the addition of wanting to have as high uptime of [[spell:260708]] as possible.
  
  - [[talent:112144]] will apply [[spell:260708]] if you have [[talent:135942]] talented. 
    
    - [[spell:260708]] has a cap of 18, so only use [[spell:260708]]  if you have 6 or less stacks left.
- Use [[talent:112147]] instead of [[spell:1464]] as a filler when possible.
- In the Execute-Phase, Use [[talent:112123@FAQANNA]] if you have less than 50 rage, or if you have 2x [[talent:123770@AJQA]], at that same position in the priority list as listed above in the single-target section

### AoE



#### [[talent:123390]]

##### Opener and Cooldowns

:::rotation [[talent:123390]] **Arms Warrior** Opener / Cooldowns
```json
{
  "source_code": "IIFKKIEZ6PAAAAAACRWAGABAAIUTDEQCoEgQ2QaAAAgQBzoAB8ACCFYfJgABHoXBf0gJMAgQYzRAfwCAChNHAAAAAAgQNNA"
}
```
1. [[spell:260708]]
2. [[spell:100]]
3. [[spell:845]]  [[spell:107574]]
4. [[spell:167105]]
5. [[spell:163201]]
6. [[spell:227847]]
7. [[spell:845]]
8. [[spell:7384]]
9. [[spell:7384]]
10. [[spell:845]]
:::

##### AoE Priority List

This is a general priority you aim to maintain when fighting at least 3 enemies.

1. Use [[talent:112147@FAQAEMA]] to apply [[talent:135597]].
2. Use [[spell:260708]] if you have less than 7 stacks.
3. Use [[talent:136703@AJQA]] if [[talent:112144]] is ready or is ready in a few seconds.
4. Use [[spell:163201]] with [[talent:112126@AJQA]] if you have 2 stacks, or if it's about to run out.
5. Use [[talent:112144]] on cooldown.
6. Use [[talent:112314@AJQA]] on cooldown.
   
   - Only bad time to use it in AoE is if [[talent:112144]]  has less than ~4 seconds remaining cooldown and you end up delaying [[talent:112144]].
   - Use [[talent:112198]] while channeling [[talent:112314@AJQA]].
7. Use [[talent:112147@FAQAEMA]] on cooldown.
8. Use [[spell:163201]] with [[talent:112126@AJQA]] or with very high rage.
9. Use [[talent:112123@FAQANNA]] on cooldown.
10. Use [[spell:163201]].
11. Use [[talent:112122]] on cooldown.
12. Use [[spell:1464]].
13. Use [[talent:112215]] on cooldown.





## Deep dive

### Generating more Rage

If you are new to **Arms Warrior** you should skip this section since even when rage-starved it is a lot of effort for a minimal gain, and if done poorly it is a big DPS loss.

Becoming rage-starved should be a rare occurrence, but can happen sometimes if you are holding onto cooldowns, playing an AoE focused talent build on single-target, or if your group does not have [[spell:462854]]. Consider these ideas to be a last priority, if the choice is between doing this or doing nothing.

:::accordion
:::details Charge for Rage
Rage comes primarily from [[spell:6603]], but another way to get Rage is from [[spell:100]]. [[spell:100]] can only be used from range, and [[spell:6603]] can only happen in melee, but if you time it correctly you can walk, [[spell:6544]] or [[spell:3411]] out of melee and [[spell:100]] back in without delaying your auto attacks at all.

A well timed [[spell:100]] also happens just as you used an attack, and part of the time you spend walking out you are in a global cooldown, although you still have some time spent not attacking.

:::columns
:::column
:::columns
:::column
![Arms Warrior Charging for Raids and Mythic+](<https://assets-ng.maxroll.gg/wordpress/ezgif-2-02cd546dc2.webp>)

:::

:::

:::

:::

:::

:::details Using Parry Attack Speed for Rage
When you successfully [[spell:3127]] your swing timer is sped up and your next [[spell:6603]] lands sooner. Since **Arms Warriors** have [[spell:118038]] this can be used together with an [[spell:3411]] on the tank, making you intercept all the melee attacks that would otherwise go on the tank and parrying them. It is important that you are facing the mobs while you do this, since you can only parry attacks from enemies in front of you.

Because [[spell:118038]] is your main defensive cooldown you might want it for a defensive purpose, but if you have [[spell:3411]] talented and use [[spell:118038]] to survive, you might as well throw in an [[spell:3411]] on the tank. When in AoE scenarios using [[spell:118038]] paired with [[spell:3411]] on the tank gives you practically infinite Rage.

:::columns
:::column
![Arms Warrior Parry Attack Speed for Raid and Mythic+](<https://assets-ng.maxroll.gg/wordpress/parry-speed.webp>)

:::

:::

The green bar is the auto-attack swing timer, and as [[spell:118038]] and [[spell:3411]] is used it starts skipping forward.

Shown below is a useful macro to [[spell:3411]] on your target's target, which is usually the tank. Ensure that you have [[spell:118038]] ready before pressing this, since if you do not have it ready it is most likely an instant death.

```wow-macro
#showtooltip Intervene
/cast Die by the Sword
/cast [@targettarget,help] Intervene
```

:::

:::

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### Rav'i

- You can reflect [[spell:1297876]], which if not avoided can be the majority of your damage taken in this fight.
- If playing with [[talent:112215]], make sure to use it when **Rav'i** casts [[spell:1296216]].

##### The Writhing Coil

- The small snakes and the big snake share a health pool, so any damage you do to the small snakes will have the big snake come back at lower health. When the big snake goes away and the small snakes spawn, it's a good time to use cooldowns. The first small snakes spawn 53 seconds into the fight, the next set comes 90 seconds later.
- You can reflect [[spell:1299189]], which if not avoided can be the majority of your damage taken in this fight.
- [[spell:1310358]] has to be interrupted 3 times in a row when there is 1 snake, ideally coordinate with your team to get all 3 interrupts and don't accidentally waste your kicks trying to get the same cast.
- [[spell:1310358]] is also cast when there are multiple snakes, although the multiple snakes are not doing 3 each.

##### Zul'jan

- Use [[talent:112253@AJQA]] to reduce damage taken during [[spell:1300886]].
- Use [[talent:114643]] or [[talent:112121]] when soaking [[spell:1301508]].

#### Trash Tips

- You can reflect [[spell:1294568]] from **Twinfang Harrower**.
- You can reflect [[spell:1289416]] from **High Evolutionist.**




### Den of Nalorakk

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- You can deflect [[spell:1234846]] from the toxic mushrooms.
- Use [[talent:112121]] or  [[talent:114644]] when **The Hoardmonger** casts [[spell:1234681]] or [[spell:1235125]].

##### Sentinel of Winter

- Interrupt [[spell:1235829]] cast by **Fractured Shivercore.**
- Soak [[spell:1263590]] when you defeat the **Fractured Shivercore**.
- The defeated **Fractured Shivercore** leave behind a [[spell:1234314]] that you can stand in to not get pushed back by [[spell:1235656]].

##### Nalorakk

- Try to place [[spell:1242887]] next to where your teammates place theirs, ideally all in one side or corner of the room. That way it is easier to soak them when they come to life to chase **Zul'jarra** when **Nalorakk** casts [[spell:1243002]].
- Hide behind the shield during [[spell:1243569]]. You know you are safe if you got the debuff  [[spell:1261781]].

#### Trash Tips

- You can reflect [[spell:1241214]] from **Earthwhisper Tender**.
- You can reflect [[spell:1246687]] from **Stormbound Mystic** and **Loa Speaker Nanea.**




### Murder Row

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- You can deflect [[spell:1230298]].
- Have DPS cooldowns ready for when **Kystia** casts [[spell:1214959]]. It's also a good time to use defensive cooldowns.

##### Zaen Bladesorrow

- If targeted, use your [[spell:1214352]] to clear green glowing [[spell:1201553]].
- When **Zaen** casts [[spell:474483]] it's a good time to use a defensive cooldown.

##### Xathuux the Annihilator

- Focus damage on the **Legion Axe** from [[spell:1214663]], as you take significant and increasing damage from [[spell:1214650]] while it is alive. They spawn just under 1 minute apart from each other.
- Be careful to not step on the [[spell:474234]].

##### Lithiel Cinderfury

- Normally almost all damage you take in this fight is the passive [[spell:1216945]]. Therefore if you take any additional damage at all, such as casts going through from imps, or stacking on someone else with [[spell:474457]] that's the time to send a defensive cooldown.
- Try to have the imps defeated before you have to use the Gateway.

#### Trash Tips

- You can reflect [[spell:1217633]] cast by **Massive Felwyrm**.




### The Blinding Vale

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- You can reflect [[spell:1235616]] from **Kezkitt.**
- Intercept the [[spell:1235574]] to stop it from hitting the **Lightblossom Seed.**
- Watch your health when **Meittik** casts [[spell:1276586]]. It's a good time to use a defensive cooldown.

##### Ikuuz the Light Hunter

- Use defensive cooldowns when **Ikuuz** casts[[spell:1236715]].
- You can break roots with [[talent:117392]] and [[talent:112284@AJQABA]] if you play [[talent:123389]].

##### Lightwarden Ruia

- [[spell:1240098]] fall fast, be quick to dodge.
- You can pixel-stack with [[spell:1239824]] and not get hit by [[spell:1239830]].

##### Ziekket

- Don't let the globules go into the boss, it will explode in a [[spell:1247039]], very likely to cause a wipe.
- Soaking a globule gives you [[spell:1247052]], increasing damage done but also giving you a DoT dealing significant damage.

#### Trash Tips

- You can reflect [[spell:1238063]] from **Radiant Spellsower.**
- Make sure to interrupt [[spell:1238294]] cast by **Lightfeather Petalwing.** If you don't it is likely to cause a wipe, as the party will get disoriented.




### Voidscar Arena

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### Taz'Rah

- [[spell:1222103]] deals significant initial damage and puts a DoT on you.
- Be ready to use a defensive or health pot if not full hp when [[spell:1300259]] is cast, it deals significant AoE damage. It also spawns a lot of little orbs that you have to dodge or take even more damage.

##### Atroxus

- The **Toxic Creeper** deals high damage with [[spell:1222692]]. Swap to it instantly and maybe even hold DPS cooldowns for it.
- Use defensive cooldowns if the **Toxic Creeper** is still alive when **Atroxus** casts [[spell:1300351]].

##### Charonus

- Your main damage taken in this fight comes from [[spell:1264188]].
- The most dangerous moments in the encounter is when you get targeted by abilities that overlap with the background damage of the [[spell:1264188]], and that is when you should use defensive cooldowns.
  
  - [[spell:1300372]] deal significant damage and puts a DoT on you.
  
  
  
  - If you don't clear your orb quickly you take increasing damage from [[spell:1287450]].

#### Trash Tips

- You can reflect [[spell:1311754]] from **Raj'kess the Spellstorm.**




### Kings' Rest

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Use defensive cooldowns when **The Golden Serpent** casts [[spell:1311988]].
- Don't let the **Animated Gold** reach the boss or he will get [[spell:265991]].

##### Mchimba the Embalmer

- Interrupt the **Half-Finished Mummy** cast [[spell:267763]].
- Be quick to release your friends when they get [[spell:267702]]. You will know where they are if the Tomb is shaking, and if you are the one targeted then use [[spell:267764]] to alert your friends of your position.

##### The Council of Tribes

- Make sure to help soak [[spell:1310761]]. It's a good time to use a defensive cooldown.
- Interrupt [[spell:267273]].
- Kill the **Torrent, Thundering** and **Explosive Totems.**

##### Dazar, The First King

- Interrupt [[spell:269369]] by **Reban**.
- **Reban** spawns a few seconds into the fight, and **T'zala** spawns when **Dazar** has 80% remaining health. T'zala and **Dazar** share a health pool.
- Most of your damage taken in this encounter comes from [[spell:1303267]], making it a good time to use defensive cooldowns.

#### Trash Tips

- Interrupt [[spell:270920]] by **Queen Wasi.**
- Interrupt [[spell:270901]] by **Seneschai M'bara**.




### Ruby Life Pools

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Interrupt [[spell:372808]].
- It can be good to stack with teammates when **Melissa** casts [[spell:396044]], so that the [[spell:384022]] spawn on top of eachother and are easier to dodge.
- Place [[spell:372851]] away from the boss and your teammates ideally.
- You take increasing damage while the [[spell:373680]] shield holds.

##### Kokia Blazehoof

- [[spell:372863]] spawns a **Blazebound Firestorm**.
- Interrupt [[spell:373017]] by **Blazebound Firestorm**.
- Try to aim [[spell:372107]] in a way that it wont explode near your team, and also ideally in a way that the fire doesn't bother you later.

##### Kyrakka and Erkhart Stormvein

- Use defensive cooldowns when affected by [[spell:381862]] in last phase as it targets 1 extra player and puts more stress on your healer, and be mindful of where you place the pool.

#### Trash Tips

- You can reflect [[spell:384194]] from **Primalist Cinderweaver.**
- You can reflect [[spell:371984]] from **Flashfrost Chillwewaver**.
- Use a stop when **Aashseer Flamelasher** casts [[spell:1305865]].
- Use a defensive when **Primal Juggernaut** casts [[spell:1305201]].




### Temple of Sethraliss

:::talents **Arms Warrior** [[talent:123390]] Mythic+ Talents
```json
{
  "source_code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM",
  "code": "CeEAYyB6EulQT7kdp2SXeCVBkhZmZmFzYmZGAAAghphZGzMWmZmZGmxMDAAAAgxyMDMhxy2ALgBMDTIDsBmZYsMYWmZbAmZAwMM"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Make sure you are targeting the boss without the [[spell:1289229]] shield. That one is immune to damage, and who has the shield is alternating throughout the fight.
- [[spell:1289062]] knocks you back quickly and far, spam charge as it goes off. Don't get knocked into a [[spell:1288864]] as they silence you.

##### Merektha

- If you get targeted by [[spell:1290031]] go close to the other person targeted, preferably you both meet up at the boss.
- Use a [[talent:112242]] or [[talent:134254]] to clear the debuff from teammates affected by [[spell:1290031]].
- Watch out when **Merekhta** [[spell:264206]] across the battlefield, getting hit causes significant damage and stuns you.

##### Galvazzt

- Use defensives when soaking [[spell:266923]]. Don't let the beams hit and energize the boss, if he reaches 100 energy he can cast [[spell:266512]] likely causing a wipe.

##### Avatar of Sethraliss

- Soak the corruption from [[spell:1300869]] so that **The Avatar of Sethraliss** can [[spell:1302895]]. This is better soaked by damage dealers than tanks or healers, since there is a penalty to healing done, and increased physical damage taken if you soak.
- Interrupt [[spell:1302158]] cast by **Twisted Hexxer.**
- Spread with [[spell:1302153]].
- **Faithless Tormentors** fixate your healer, stun and slow them when needed.

#### Trash Tips

- You can reflect [[spell:1291262]] from **Storm Adept** and **Imbued Stormcaller**.
- You can reflect [[spell:1310683]] from **Brood Tender**.





### Affixes

The Affix system got revamped going into **The War Within** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear. These affixes have been further iterated on through The War Within and going into Midnight.

- +2 Affix
  
  - [[spell:1284818]]
- +5 Affixes *-- Rotates on a weekly basis*.
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes *-- Alternates between each other on a weekly basis*.
  
  - [[spell:1284818]] removed.
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as an **Arms Warrior**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Arms Warrior** Stat Priority in Mythic+
```json
{
  "source_code": "IgAHEQCIxgiABEA"
}
```
**急速 ＝ 暴击 ＞ 精通 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271456@DiCAAcEANk7cUrDf1IYN2Ijt1IoA]] | The Twin Fangs |
| Neck | [[item:268265@BkCAAcEAE06QRrDj1QWNYYjX1IoA]] | Ula'tek |
| Shoulder | [[item:271454@DACAAcEA7j74XNBWjNyIoA]] | The Lost Explorers |
| Cloak | [[item:268253@BgRAAcEAYYjX1IoAYFA]] | The Coiled Altar |
| Chest | [[item:271459@DASBAcEAJk7oXNCWDG2IoAYFgvXQ]] | The Coiled Altar + Catalyst |
| Wrist | [[item:237834@BiUAAcEA6z6Y7LjVT0wYlIMYzt1YbNHXDAjsUA]] | Blacksmithing |
| Gloves | [[item:271457@BASBAcEA7VTg1YjMCKgTB4U1DA]] | Den of Nalorakk + Catalyst |
| Belt | [[item:268259@BCSAAcEAK06ghNeVjt1IoAYF]] | The Coiled Altar |
| Legs | [[item:271878@DACAAcEAju7YhNYYjX1IoA]] | Ula'tek |
| Boots | [[item:237828@DAUAAcEApk7Y7LjVT0wYlIMYzt1ccNAMySB]] | Blacksmithing |
| Ring 1 | [[item:252258@DCSAAcEA1j7oQrDZ1YjMeVjgC4UA]] | Voidscar Arena |
| Ring 2 | [[item:273792@DCSAAcEA1j7oQrDZ1YjMeVjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270175@BghAAcEAYYjX1IoAFAQAXdhA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgBAAcEAYYjX1IoA]] | The Coiled Altar |
| Weapon | [[item:268213@DABAAcEAFk7ghNeVDA]] | The Coiled Altar |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@DARAAcEANk74iMeVTQB]] | Murder Row |
| Neck | [[item:273781@BiRAAcEAX16QWNuIjX1EUA]] | Altar of Fangs |
| Shoulder | [[item:251138@DARAAcEA7j74iMeVTQB]] | Murder Row |
| Cloak | [[item:193763@BARAAcEAuIjX1EUA]] | Ruby Life Pools |
| Chest | [[item:193753@AgQAAIoABFA]] | Ruby Life Pools |
| Wrist | [[item:251133@BARAAcEAuIjX1EUA]] | Murder Row |
| Gloves | [[item:159413@BARAAcEAuIjX1EUA]] | Kings' Rest |
| Belt | [[item:159418@BARAAcEAuIjX1EUA]] | Kings' Rest |
| Legs | [[item:273776@DARAAcEAju74iMeVTQB]] | Altar of Fangs |
| Boots | [[item:159412@DARAAcEApk74iMeVTQB]] | Kings' Rest |
| Ring 1 | [[item:273792@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | Altar of Fangs |
| Ring 2 | [[item:251136@DiRAAcEA1j7QRrDZ14iMeVTQBA]] | Murder Row |
| Trinket 1 | [[item:273796@BARAAcEAuIjX1EUA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BARAAcEAuIjX1EUA]] | Murder Row |
| Weapon | [[item:273782@DARAAcEAFk74iMeVTQB]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons and Raids.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgQAAIoAYFA]]  <br>[[item:270164@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270165@AgQAAIoAOFA]] |
| **B-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250229@AgQAAIoAOFA]]  <br>[[item:250228@AgQAAIoAOFA]]  <br>[[item:273797@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:250238@AgQAAIoAOFA]] |
| **C-Tier** | [[item:250245@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:193762@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:270163@AgQAAIoAOFA]]  <br>[[item:158367@AgQAAIoAOFA]] *-- Great for AoE, Junkyard for single-target.* |
| **Junkyard** |  |

:::simulation **Arms Warrior** Mythic+ AoE Trinket Simulation
```json
{
  "source_code": "IMtBcZSAF2CBBARAAcEA2IDg0EUAA4WmpkUAEqTFAA8DrpSSBaiTvByUlRnOgoVdsdiap52JzByR1lGbs9Gdp5WZgQVZjhmbpFXdl11HEEACBEFKYYTQBAwUJiSSB0lMTAAHBB4KJFwnqJgM3BAFnTHKJFwg6cHAUQtankUAfJTPAgBYTwSSB0N920DAUAqMpkUAirTFAwRM-XSSBUX0DIzZAQh82qSSBglMSBAFEDTJJFgf6gCAUUicpkUADqTFAQh1dbSSBMpOVAAFnoLKJFwURIFK2ITQBAwnVbSSBUoOoAAFwYSKJFAd6UBAUo5EqkUAUJTPAQBpM1SSBUlMTAACvcqK6wRAQ4UAAA9i2wRAUgVAAQC_u4spBgBWBAgpuuSS2ogAY4UAAATYqkkL7GAFYFAAjOuL64XAU4UAAE-IqojfBwhTBAwT-aSSBIzRCQhTBAwtawiMvDAFOFAA-OlL6cRAY4UAAM2FrkkN7GAGOFAAzK4KJZjfBQhTBAwcYliO9GAFOFAAoi6KyMUAU4UAAIWCsoD0BQhTBAwGggiOoGAFOFAAxuhK64pAU4UAAEaVpIT5BQhTBAQIUiiMKJAIYFAAxYnJJdw_"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| [[item:273797]] | 694,678.88 |
| [[item:273796]] | 698,032.94 |
| [[item:270173]] | 690,325.19 |
| [[item:270173]] | 702,468.06 |
| [[item:158367]] | 689,998.44 |
| [[item:273795]] | 685,741.25 |
| [[item:270175]] | 704,822.00 |
| [[item:193757]] | 693,034.00 |
| [[item:193762]] | 679,907.06 |
| [[item:250229]] | 699,247.12 |
| [[item:270168]] | 676,620.25 |
| [[item:250238]] | 694,050.31 |
| [[item:250243]] | 683,485.38 |
| [[item:250259]] | 691,106.44 |
| [[item:270163]] | 683,353.94 |
| [[item:250245]] | 692,835.00 |
| [[item:250228]] | 696,633.62 |
| [[item:270164]] | 709,834.25 |
| [[item:270165]] | 698,994.94 |
| [[item:273795]] | 686,269.00 |
| [[item:270175]] | 716,738.25 |
| [[item:270173]] | 703,210.38 |
| [[item:273797]] | 697,875.00 |
| [[item:270173]] | 716,346.19 |
| [[item:193757]] | 696,894.06 |
| [[item:193762]] | 682,980.94 |
| [[item:273796]] | 704,939.44 |
| [[item:270164]] | 714,043.88 |
| [[item:250228]] | 700,790.19 |
| [[item:250229]] | 702,507.19 |
| [[item:250259]] | 693,639.19 |
| [[item:250238]] | 703,114.50 |
| [[item:270165]] | 704,662.12 |
| [[item:250243]] | 688,641.69 |
| [[item:250245]] | 696,763.06 |
| [[item:158367]] | 693,594.06 |
| [[item:270163]] | 690,498.06 |
| [[item:270168]] | 681,827.06 |
:::

### Embellishments

- For initial gearing, unless you already have a Mythic weapon or a Very Rare Maze-Roa Heroic, going for a crafted weapon with [[item:273060]] is by far the best option.
- For an end-game BiS setup we craft either [[item:240167]] or [[item:273069]] embellishments, with the 2 options being incredibly close when you account for the benefit that [[item:240167]] brings to an ally. Recommended slots are wrist and feet/hands/shoulder.  *-- In the past cloak would be a likely slot, but this tier the raid drops a higher item level 344 Cloak that we prefer to use.*

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]] or
  
  
  
  - [[item:241326]]
- **Food**
  
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]] *-- Best for the BiS setup.*
  
  
  
  - [[item:241308]] *-- Sometimes superior, depending on your character. Simulationcraft can help you decide, check out our [Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>).*
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Temporary Enchant**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, can only use one. Combine with different color gems to maximize the bonus effect.*
  - [[item:240890]]
  - [[item:240906]]
  - [[item:240900]]
  - [[item:240916]]

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707]] |
| --- | --- |
| Shoulders | [[item:244021]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:244643]] |
| Boots | [[item:243983]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:244015]] |
| Weapon | [[item:243973]] |

:::

:::column
:::gear **Arms Warrior** Enchantments for Mythic+
```json
{
  "source_code": "IQFZHBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwo7mAGA8gOYAAB1jbCYgS94OAAAAAABUQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244643]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing an **Arms Warrior** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:20589]] -- Gnome
  
  - Root and Snare dispel.
- [[spell:58984]] -- Night Elf
  
  - Drop combat in order to avoid spells being targeted at you.
- [[spell:20594]] -- Dwarf
  
  - Removes all Poison, Disease, Curse, Magic, and Bleed simultaneously.
- [[spell:69179]] -- Blood Elf
  
  - Dispels 1 beneficial effect from all nearby enemies at the same time.
- [[spell:256948]] -- Void Elf
  
  - Activate to spawn a shadow traveling in the direction you are facing. Activate again to teleport to it.
  - Maximum range of 100 yards.

:::simulation **Arms Warrior** Mythic+ AoE Races Simulation
```json
{
  "source_code": "IUtAQ2xAfAAACSwRv52aKYHB06PLJNgFAAAAZ3rLJNQHAAAAX44LJNQAjAPPGsUatJWdstgdEExctk0AgAAAA0kOvk0AiAAAAwRpuk0AlAAAAsETvk0AfAAACewSyF2ZncXYMYHBvWhLJVAFoUAUhdya1lgdEE19NIBVGE0a15GZhdgdE0-2tk0AeAAAAwsDtkAc8lgQ39mbzFWbklGC2Rwaj0SSDQAAAI4AEFWesylArZmLJAB8VWgTpdGa01KXCk5zuk0AHAAAAU-yuk0ADAAAAE3cwk0AKAAAA8BEuk0ABAAAAwZmvk0AkAAAAgKNuk0ACAAAAYquuk0ALAAAAkS3tk0AIAAAAwdUuk0AFAAAAAOQtk0AYAAAA0kivk0AJAAAAsHnuk0AGAAAAYabwk0AcAAAAc5Hvk0AbAAAA886tk0AjAAAAMeftk0BZA"
}
```
| 方案 | 模拟数值 |
| --- | --- |
| 种族 31 [[spell:292362]] | 708,587.25 |
| 种族 22 | 715,741.56 |
| 种族 29 | 719,073.44 |
| 种族 31 [[spell:292363]] | 710,449.06 |
| 种族 32 | 717,732.81 |
| 种族 34 | 715,345.75 |
| 种族 37 | 718,020.69 |
| 种族 31 [[spell:292364]] | 713,050.94 |
| 种族 31 [[spell:292361]] | 716,661.06 |
| 种族 31 [[spell:292359]] | 712,126.81 |
| 种族 30 | 708,844.75 |
| 种族 31 [[spell:292360]] | 709,174.69 |
| 种族 4 [[spell:154796]] | 714,342.69 |
| 种族 4 [[spell:154797]] | 716,025.56 |
| 种族 7 | 715,966.31 |
| 种族 3 | 722,743.06 |
| 种族 10 | 712,961.94 |
| 种族 1 | 719,257.75 |
| 种族 36 | 713,546.50 |
| 种族 2 | 715,690.38 |
| 种族 11 | 712,146.56 |
| 种族 8 | 714,013.75 |
| 种族 5 | 709,646.00 |
| 种族 24 | 719,012.81 |
| 种族 9 | 715,207.69 |
| 种族 6 | 722,650.38 |
| 种族 28 | 717,305.44 |
| 种族 27 | 712,380.94 |
| 种族 35 | 710,622.19 |
:::

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Arms Warrior**.

## Macros

Discover recommended macros for **Arms Warrior** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:376079]] Macro** *--- Champion's Spear is cast on your cursor.*

```wow-macro
/cast [@cursor] Champion's Spear
```

**[[spell:6544]] Macro** *--- Leap on your cursor without the extra mouse click.*

```wow-macro
/cast [@cursor] Heroic Leap
```

:::

:::details Mouseover Macros
**[[spell:163201]] Macro** *--- If your mouse is over an enemy then Execute it, otherwise Execute your target. This macro is useful to Execute a nearby low HP mob while still targeting the boss.*

```wow-macro
/cast [@mouseover, harm, nodead][harm,nodead] Execute
```

***[[spell:3411]] Macro*** *--- Intervene a friendly player your mouse is over.*

```wow-macro
/cast [@mouseover,help] Intervene
```

**[[spell:100]] Macro** *--- Charge your target, unless your mouse is over another enemy, then it targets that enemy and uses Charge.*

```wow-macro
/target [@mouseover, harm, nodead]
/cast Charge
```

:::

:::details Convenience Macros
**[[spell:386208]] and [[talent:112184]] Macro** *--- With this you can swap stances using only 1 keybind.*

```wow-macro
/cast [stance:2] Defensive Stance; stance[:3] Battle Stance
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Arms Warrior**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Revvez Midnight Arms Warrior UI](<https://assets-ng.maxroll.gg/wordpress/UIArmsEllesmere-1024x576.png>)

Revvez **Arms Warrior** UI

:::accordion
:::details Addons
- **MRT *-- Notes, Raid cooldowns, and more*** 
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **Ellesmere UI** *-- User Interface replacement* 
  
  - EllesmereUI is a fully modular UI suite designed for players who want complete control over their interface without sacrificing performance or simplicity. Every element is built from the ground up to be lightweight, responsive, and easy to configure.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
### Warrior

- *Developers' notes: Rend is an iconic and core Warrior ability with a different relationship to each spec. Our approach to Rend in Midnight hasn't worked out as we hoped, so we're making changes to how each spec applies and interacts with Rend in Curse of Ula'tek.*
- The Rend ability is now exclusive to Arms, has returned to being a single-target ability, and its Rage cost is reduced to 10. Cleave will apply Rend to all targets if the Warrior knows Rend.
- New Talent (Fury): Storm of Blood – Whirlwind applies Rend to all targets. Crashing Thunder causes Storm of Blood to also apply to Thunder Clap for Mountain Thane.
- New Talent (Protection): Blood and Thunder – Thunder Clap applies Rend to all targets.
- Thunder Clap no longer innately applies Rend if known.
- Javelineer has a new icon.
- Hero Talents
  
  - Colossus
  - Developers' notes: Demolish's variable cooldown has proven to be more frustrating than interesting, so we're changing it to align closely with Colossus Smash, enabling Arms Colossus Warriors to coordinate their use for maximum devastation.
  - No Stranger to Pain has been updated – Damage prevented by each use of Ignore Pain increased by 30% (was 20%).
  - Dominance of the Colossus has been updated – Enemies damaged by Demolish deal 20% reduced damage to you for 10 seconds (was 10%) and no longer reduces the cooldown of Demolish.
  - Demolish cooldown reduced to 30 seconds (was 45 seconds).
- Arms
  
  - Developers' notes: Arms’ AOE damage profile is dominated by Cleave, and we’d like to spread the damage across more abilities. We’re updating Dreadnaught to be purely AOE damage which will allow us to tune it solely for AOE. This should help Arms’ AOE rotation not feel so dominated by Cleave and help give Slayer better options for AOE.
  - Tactical Edge has been redesigned – Colossus Smash immediately grants 1 use of Sudden Death.
    
    - *Developers' notes: We feel like the original design’s effect was difficult to feel and eroded the uniqueness of Tactician. We think this design will be much more rotationally impactful and provide some additional interactions for Slayer and Execute-focused builds.*
  - Ravager has been updated:
    
    - Ravager damage increased by 50%.
    - Ravager no longer increases Cleave and Whirlwind damage while active. Ravager now causes all enemies it damages to take 50% increased damage from your Bleeds for 12 seconds.
    - Ravager's duration is no longer reduced by Haste.
    - *Developers' notes: Ravager is a unique ability and we want Ravager itself and its positioning to be important, but the current design puts more emphasis on its value as an AOE damage amp rather than Ravager itself. We're redesigning Ravager slightly to address this, as well as to increase Ravager's value in all combat situations.*
  - Bloodletting has been updated – Your abilities have a 5% increased chance to critically strike targets affected by Rend. If you know Rend, Mortal Strike inflicts Rend on targets below 35% health. Deep Wounds lasts 33% longer.
  - Broad Strokes has been updated – Colossus Smash now grants 6 stacks of Sweeping Strikes on use.
    
    - *Developers' notes: Stacks of Sweeping Strikes from the Sweeping Strikes ability and Broad Strokes will stack normally, regardless of the order in which they were used.*
  - Dreadnaught has been updated – Dreadnaught damage increased by 100% and no longer damages your Overpower target.
  - Melee auto-attack damage increased by 100%.
  - Cleave damage reduced by 10%.
  - Execute damage reduced by 15%.
  - Ignore Pain absorb increased by 25%.
  - Sweeping Strikes now displays the number of active Sweeping Strikes charges.
  - Powerful Momentum now increases Sweeping Strikes chain damage by 20% (was 25%).
  - *Midnight* Season 1 2-set bonus now increases Colossus Smash damage by 3% (was 5%).
  - Several talents have changed locations in the talent tree.
  - Improved Sweeping Strikes has been removed.
  - **Hero Talents** 
    
    - Colossus
      
      - Tide of Battle increases the damage of Overpower and Execute (was Overpower only).
    - Slayer
      
      - Slayer's Dominance has been updated – Chance to trigger a Slayer's strike increased to 25% (was 15%).
      - Opportunist grants 20% damage and 20% critical strike damage to your next Overpower (was 10% for both)..

:::

:::details Patch 12.0.5
### Warrior

- Rend radius increased to 10 yards (was 8 yards).
- Wrecking Throw will now be highlighted when the Warrior targets a unit with an active Absorb shield.
- Shattering Throw will now be highlighted when the Warrior targets a unit with an active Immunity effect, or a Mage’s Ice Wall.
- Arms
  
  - Mortal Wounds now triggers from Mortal Strike and Slam (was Mortal Strike and Cleave).
  - Crushing Combo removes the cooldown from your next 2 uses of Cleave (was 3).
  - Colossus
    
    - Practiced Strikes now increases Mortal Strike and Slam damage by 15% and Cleave and Whirlwind damage by 15%.
    - Demolish’s area of effect strike radius increased to 10 yards (was 8 yards).
    - Dominance of the Colossus reduces the cooldown of Demolish by 5 seconds when you would gain a stack of Colossal Might and are already at max stacks (was 2 seconds).
  - Slayer
    
    - Reap the Storm has been updated – When Cleave hits 3 or more targets you have a 20% chance to unleash a flurry of steel, striking all nearby enemies for high Physical damage and applying Overwhelmed.
    - Unrelenting Onslaught now also increases damage dealt by Bladestorm by 20%.

:::

:::details Patch 12.0.1
### Warrior

- Hero Talents
  
  - Colossus
  
  
  
  - Developers' notes: We want Demolish to feel satisfying to use even at low or no Colossal Might stacks, so we’re moving some of the Colossal Might damage into the ability’s baseline damage.
    
    - Demolish damage increased by 65%.
    - Colossal Might increases damage of your next Demolish by 5% per stack (was 10%).
    - Arms
      
      - Practices Strikes damage bonus increased to 20% (was 15%).
      - Arterial Bleed damage bonus reduced to 3% per stack (was 5%).
  
  
  
  - Slayer
    
    - Imminent Demise now has an additional effect – Sudden Death has a 100% chance to trigger Reap the Storm.
    - Slayer’s Strike damage reduced by 10%.
    - Reap the Storm damage reduced by 20%.
    - Arms
      
      - Culling Cyclone bonus damage increased to 20% (was 10%).
      - Slayer's Malice bonus damage reduced to 15% (was 20%).
      - Reap the Storm’s chance to trigger reduced to 20% (was 15%).
- Class
  
  - Deep Wounds damage reduced by 30%.
- Arms
  
  - Cleave damage increased by 32%.
  
  
  
  - Bladestorm damage increased by 30%.
  
  
  
  - Mortal Strike damage reduced by 20%.
  
  
  
  - Execute damage reduced by 20%.
  
  
  
  - Dreadnaught damage reduced by 60%.
  
  
  
  - Barbaric Training now affects Slam, Whirlwind, and Cleave (was Slam, Whirlwind, and Thunder Clap).
  
  
  
  - Master Tactician now increases Tactician's chance to trigger by 5% (was 10%).
  
  
  
  - Battlelord now also reduces the Rage cost of your next Heroic Strike by 33%.

:::

:::details Patch 12.0
### Warrior

- Hero Talents
  
  - Colossus
    
    - New Talent: Decimator – Demolish's final strike applies Deep Wounds to all targets at 100% effectiveness.
    - New Talent: Cut to the Bone
      
      - Arms: Mortal Strike critical strikes increase your Rend and Deep Wounds damage by 25% for 8 seconds.
    - New Talent: Celeritous Conclusion
    - Arms: Demolish's final strike grants 10% Haste for 10 seconds and increases the critical strike chance of your next Mortal Strike by 100%.
    - Demolish now makes the Warrior immune to movement forces during the channel.
    - Arms
      
      - Practiced Strikes now affects Slam.Practiced Strikes' Mortal Strike, Cleave, and Slam damage increased by 15% (was 20%).
      - Tide of Battle's Colossal Might increases damage of Overpower by 3% per stack (was 5%).
  
  
  
  - Slayer
    
    - New Talent: Violent Euphoria – Bladestorm puts you into a battle trance, granting you 15% Haste for 8 seconds after you stop Bladestorming.
    - New Talent: Deadly Focus – Executioner's duration is increased by 6 seconds.
    - New Talent: Unhinged
      
      - Arms: Every 2 strikes of Bladestorm, you automatically cast a Mortal Strike at your target or random nearby enemy, dealing 100% of normal damage.
    - Slayer's Dominance has been updated – Your attacks have a 15% chance to trigger a Slayer's Strike. Slayer's Strike now grants you a stack of Executioner, increasing your Execute damage by 3% for 12 seconds. Multiple stacks of Executioner may overlap.
    - Show No Mercy has been updated – Executioner also increases your Execute critical strike chance and critical strike damage by 3% per stack.
    - Unrelenting Onslaught has been updated – Using Sudden Death causes you to both reduce the cooldown of Bladestorm by 5 seconds and apply 1 stack of Overwhelmed to your primary target for each stack of Executioner you have.
    - Opportunist's effect now stacks up to 2 times.
    - Overwhelming Blades' Overwhelmed debuff now stacks 5 times (was 10).
    - Slayer's Malice now affects Execute in addition to Overpower and Raging Blow, but the damage increase is reduced to 20% (was 30%).
    - Slayer's Strike damage increased by 100%.
    - Reap the Storm damage increased by 100% and its chance to trigger increased to 25% (was 20%).
    - **Arms** 
      
      - Opportunist's damage and critical strike damage of next Overpower reduced to 10% (was 25%).
- Class
  
  - New Talent: Resonant Voice – The duration of your shouts is increased by 20%.
  - New Talent: Retaliation – When you take any damage from an enemy within melee range, you have a chance to strike that enemy for Physical damage.
  - New Talent: Stance Mastery – Your stances have additional effects.
    
    - Battle Stance: Increases the critical strike damage of your abilities by 3%.
    - Berserker Stance: Increases your auto-attack speed by 3%.
    - Defensive Stance: When an attack deals 20% or more of your maximum health in damage, that damage is reduced by 15%.
  - New Talent: Battlefield Commander – Your Shout abilities have additional effects.
    
    - Battle Shout: Grants you an additional 3% attack power.
    - Rallying Cry: Grants an additional 2% health and duration increased by 3 seconds.
    - Piercing Howl: Radius increased by 100%.
    - Berserker Shout: Radius increased by 100%.
    - Intimidating Shout: Cooldown reduced by 15 seconds.
  - New Talent: Anger Management – Every 20 Rage you spend reduces the remaining cooldown on Avatar, Colossus Smash, Recklessness, and Shield Wall by 1 second.
  - New Talent: Field Dressing – Healing received increased by 3% and all self-healing increased by an additional 10%.
  - New Talent: Fearless – Cooldown of Berserker Rage is reduced by 50% and Berserker Rage removes all movement speed-impairing effects.
  - New Talent: Javelineer – Range of your thrown abilities is increased by 5 yards. Damage dealt by Champion's Spear, Shattering Throw, and Wrecking Throw increased by 20%. Shattering Throw and Wrecking Throw silence non-players for 3 seconds.
  - New Arms and Fury Talent: Interpose – Run at high speed toward a target location near your allies, taking 30% of all damage dealt to allies within 3 yards for 8 seconds or until you take at least 20% of your max health in damage from this effect.
  - New Arms and Fury Talent: Rend – Lash out with your weapon, striking all targets within 8 yards for Physical damage and wounding them for additional Bleed damage over 15 seconds.
  - Champion's Spear has been redesigned – Throw a spear at the target location, chaining all enemies in the area to the spear's location and dealing Physical damage instantly and additional Physical damage over 6 seconds. While the spear is active, activating this ability will cause you to leap to the spear, slamming down to deal Physical damage to all targets. All damage dealt reduced beyond 5 targets. Generates 10 Rage.
  - Intimidating Shout now reduces the movement speed of all targets by 70% and causes all enemies other than your primary target in range to flee. Was previously 8 targets.
  - Rallying Cry has been updated – Health granted is increased by 50% when not in a raid.
  - Honed Reflexes now reduces cooldowns by 10% (was 5%) and has an additional effect – Successfully interrupting an enemy increases the damage you deal to them by 5% for 10 seconds.
  - Piercing Howl now also spurs all allies within 12 yards, increasing their movement speed by 30% for 4 seconds.
  - Barbaric Training now increases damage dealt by 10% and critical strike damage by 5% for Slam, Whirlwind, Thunder Clap, Raging Blow, and Revenge.
  - Shattering Throw and Wrecking Throw range reduced to 25 yards (was 30 yards).
  - Thunder Clap damage increased by 150% and applies Rend to all targets if talented.
  - Shield Slam damage increased by 140%.
  - Second Wind healing while you are below 35% health increased by 100%.
  - Crushing Force is now a 1-point talent.
  - Many talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Avatar *(moved to each specialization's talent tree)*
    - Berserker's Torment
    - Blademaster's Torment
    - Cacophonous Roar
    - Challenger's Might
    - Concussive Blows
    - Immovable Object
    - Menace
    - Piercing Challenge
    - Seismic Reverberation
    - Thunderous Roar
    - Thunderous Words
    - Titan's Torment
    - Unstoppable Force
    - Uproar
    - Warlord's Torment
- Arms
  
  - New Talent: Brute Force – Slam has a 10% increased chance to trigger Tactician.
  - New Talent: Efficiency – Slam's Rage cost is reduced by 25%.
  - New Talent: Just Warming Up – Colossus Smash generates 15 Rage.
  - New Talent: Broad Strokes – Colossus Smash grants you Sweeping Strikes.
  - New Talent: Powerful Momentum – Damage dealt to nearby targets by Sweeping Strikes is increased by 25%.
  - New Talent: Press the Advantage – Colossus Smash causes your next 3 Mortal Strikes to be guaranteed to trigger Tactician.
  - New Talent: Crushing Combo – Colossus Smash causes your next 3 Cleaves within 20 seconds to trigger no cooldown.
  - New Talent: Master Tactician – Tactician has a 10% increased chance to trigger.
  - New Talent: Deep Wounds – Execute inflicts Deep Wounds on the target, causing high damage over 6 seconds.
  - New Talent: Mortal Wounds – You inflict Deep Wounds on targets that you critically strike with Mortal Strike or Cleave.
  - New Talent: Fatality – Mortal Strike has a high chance to apply a Fatal Mark to your target, stacking up to 5 times. Your next Execute on a target with a Fatal Mark causes the Fatal Mark to deal additional Physical damage per stack.
  - New Talent: Mass Execution – Cleave and Whirlwind deal 25% increased damage to targets below 35% health.
  - New Talent: Overpowering Finish – Overpower deals 25% increased damage to targets below 35% health.
  - Avatar moved to Arms specialization tree and has been updated – Transform into a colossus, increasing all damage you deal by 20% and reducing damage you take from area of effect attacks by 5% for 20 seconds.
  - Mastery: Master of Arms has been redesigned – While wielding a two-handed weapon, you deal Mastery% additional damage.
  - Sweeping Strikes has been redesigned – Your next 12 damaging single-target abilities within 30 seconds hit 1 additional target within 8 yards for 75% damage. 30 second cooldown.
  - Improved Sweeping Strikes has been redesigned – Sweeping Strikes affects 6 additional damaging single-target abilities.
  - Collateral Damage has been redesigned – When an ability used during Sweeping Strikes damages a second target, your next Cleave or Whirlwind deals 25% increased damage, stacking up to 3 times.
  - Tactician has been redesigned – You have a 30% chance to gain a charge of Overpower when you use an attack that has a Rage cost. This effect applies even if that ability's Rage cost has been reduced to zero.
  - Martial Prowess has been updated– Overpower and Slam increase the damage of your next Mortal Strike by 5%, stacking up to 3 times.
  - Ravager has been updated – Additional effect: Cleave and Whirlwind deal 50% increased damage while Ravager is active. Ravager is now thrown at your target.
  - Battlelord has been updated – Overpower has a 35% chance to reset the cooldown of Mortal Strike.
  - Colossus Smash has been updated – Smash the ground and shatter the armor of all enemies within 10 yards, dealing Physical damage and increasing damage you deal to them by 30% for 10 seconds. Deals reduced damage beyond 8 targets.
  - Fueled By Violence now heals for Bleed damage from Rend and Deep Wounds.
  - Fervor of Battle now requires 3 targets to trigger Slam and Slam's damage is increased by 50%.
  - Sharpened Blades has been updated – Now a 2-point talent. Mortal Strike, Cleave, and Execute damage increased by 5% and critical strike damage increased by 5%.
  - Ignore Pain has been updated – Fight through the pain, ignoring 50% of damage taken for 12 seconds or until a certain amount of damage is taken. 20 second cooldown. Rage cost removed and amount ignored per use increased by 100%. Triggers a global cooldown.
  - Strength of Arms is now a 2-point talent. Each point grants 5% damage, critical strike chance, and critical strike damage to Overpower and Slam.
  - Executioner's Precision now buffs the Warrior's next Mortal Strike, rather than applying a debuff to the target.
  - Bloodletting now increases the duration of Rend and Deep Wounds Bleeds by 33%, and Mortal Strike applies Rend if the target is below 35% if Rend is talented.
  - Critical Thinking now increases Execute critical strike chance by 5% and refunds 10% of Rage spent on Execute per point.
  - Auto-attack damage increased by 150%.
  - Thunder Clap damage decreased by 20%.
  - Whirlwind damage increased by 10%.
  - Dreadnaught damage increased by 180%.
  - Bloodborne now increases critical strike damage of bleed effects in addition to normal damage.
  - Many talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Anger Management *(moved to the class talent tree)*
    - Blunt Instruments
    - Exhilarating Blows
    - Finishing Blows
    - In for the Kill
    - Juggernaut
    - Merciless Bonegrinder
    - Rend *(moved to the class talent tree)*
    - Spiteful Serenity
    - Skullsplitter
    - Storm of Swords
    - Storm Wall
    - Test of Might
    - Warbreaker *(Warbreaker's effects added to Colossus Smash)*

:::

:::details Patch 11.2
### Warrior

- The global cooldown of Hamstring is now 0.75 seconds (was 1.5 seconds).
- Fixed an issue where Berserker Rage was able to remove Scatter Shot.
- Berserker Rage’s tooltip has been slightly adjusted to indicate it only works on certain Incapacitate effects.

#### Arms

- All ability damage increased by 5%.
- Bladestorm damage increased by 15%.

:::

:::details Patch 11.1
### Warrior

- *Developers' notes: We feel that Warriors are in a good place overall, however, there are a few places we'd like to make improvements to each spec, and to the class as a whole. Warrior survivability in particular has been a weak point, and Endurance Training competing against powerful throughput nodes in the bottom of the Warrior tree makes it difficult to talent into. We’re combining Endurance Training and Reinforced Plates to put the choice in the second tier, which has more choice against other utility and survival nodes and thus be easier to spend points on. The Weapon Specialization nodes have been increased to 2 points to keep the tree structure and overall talent build costs similar, and the nodes have been rearranged slightly to make the choice about how to access Avatar more distinct for each spec.*
- Reinforced Plates is now a 2-point talent that grants 5% Stamina and 5% Armor per point.
- Overwhelming Rage is now a 1-point talent that increases maximum Rage by 30.
- Two-Handed Weapon Specialization (Arms) is now a 2-point talent that grants 3% damage and 2% reduction of damage from area-of-effect attacks while wielding a 2-hand weapon per point.
- Dual Wield Specialization (Fury) is now a 2-point talent that grants 3% damage and 2% movement speed while dual-wielding per point.
- One-Handed Weapon Specialization (Protection) is now a 2-point talent that grants 3% damage and 2% Leech per point.
- Thunderous Words increases your Bleed damage by 20% on affected targets (was 30%).
- Cruel Strikes, Wild Strikes, and the Weapon Specialization nodes have changed positions in the tree.
- Endurance Training has been removed.

#### Arms

- All ability damage reduced by 5%.
- Mortal Strike damage increased by 66%.
- Cleave damage increased by 26%.
- Overpower damage increased by 44%.
- Dreadnaught damage increased by 44%.
- Execute damage increased by 32%.
- Slam damage increased by 45%.
- Whirlwind damage increased by 40%.
- Martial Prowess' Overpower now increases the damage of your next Mortal Strike or Cleave by 15% per stack, up to 2 (was 30%).
- *Developers' notes: Arms Warriors should always feel good about using Mortal Strike when it's available, so we're moving damage from the Overpower buff into Mortal Strike and Cleave baseline to open up more rotational and build options.*
- Bloodborne increases Bleed effect damage by 5/10% (was 7.5/15%).
- Bloodsurge now causes damage from Deep Wounds to have a chance to generate 5 Rage.
- Colossus Smash and Warbreaker have new visuals.
- Warbreaker’s area of effect is now centered around a point slightly in front of the Warrior, to better align with the new visuals.

#### Colossus

- Demolish damage increased by 30%.
- Practiced Strikes increases Mortal Strike and Cleave damage by 20% (was 15%).
- Arterial Bleed increases Rend and Deep Wounds damage by 5% per stack of Colossal Might (was 3%).
- Colossal Might is no longer applied by Execute.
- *Developers' notes: Using your hard-hitting rotational ability regularly is core to the Colossus playstyle, and Execute applying Colossal Might pushed Colossus away from that during Execute phases.*
- Fixed an issue causing Demolish's animation to not correctly play sometimes.

#### Slayer

- Opportunist increases the damage and critical strike damage of your next Overpower by 25% (was 20%).
- Cleave will only trigger Reap the Storm if 3 or more targets are hit.
- Imminent Demise and Death Drive now correctly require the Sudden Death talent to be taken to function.
- *Developers' notes: This was an oversight during implementation. Slayers are expected to talent into Sudden Death.*

:::

:::details Patch 11.0.5
### Warrior

- [[talent:112223]] now deals reduced damage beyond 5 targets (was 8).
- [[talent:112247]] icon has been updated.

#### Slayer

- [[spell:445836]] now stacks up to 10 times (was 12).

#### Arms

- [[talent:112139]] radius increased to 10 yards (was 8 yards).
- [[talent:112139]] now deals reduced damage beyond 5 targets.

:::

:::details Patch 11.0.2
### Warrior

- [[spell:23922]] damage increased by 8%.
- [[talent:112217]] now heals for 2% of your max health (was 3.5%).

#### Arms

- [[talent:112122]] damage decreased by 15%.
- [[talent:112123]] damage decreased by 20%.
- [[talent:112121]] now heals for 5% of maximum health (was 8%).

:::

:::details Patch 11.0
### Warrior

- All talent trees have had many talents move locations or have had their pathing updated.
- [[talent:118850]] has been redesigned – Cooldown of [[talent:112128]], [[talent:112264]], [[spell:871]], [[spell:6552]], [[talent:112186]], [[talent:112253]], and [[talent:112198]] reduced by 5%.
- [[talent:112190]] gains an additional effect – While you are below 35% health, restores 1.0% health every 1 second. The amount restored increases the closer you are to death (max 2%).
- [[spell:18499]] is now learned at level 12.
- [[spell:1464]] damage increased by 130%. Arms [[spell:1464]] damage bonus reduced to 50% (was 75%).
- [[spell:227847]] damage increased by 70%.
- [[spell:228920]] damage decreased by 10%.
- [[spell:280721]] can now stack 2 times.
- [[spell:6343]] Rage cost reduced to 20 (was 30) and now applies [[talent:112136]] by default if it is known.
- [[spell:215571]] now refunds 10% Rage for Arms and Fury, and 25% Rage for Protection.
- [[talent:112242]] no longer generates Rage on cast.
- [[talent:112247]] generates 10 Rage on cast (was 20).
- [[talent:112223]] no longer generates Rage on cast.
- [[talent:112223]] now deals reduced damage beyond 8 targets. The tooltip will reflect this change in a future update.
- [[talent:112222]] now causes [[talent:112223]]’s Bleed effect to increase damage targets take from all the Warrior’s bleed effects, rather than passively increasing it all the time.
- [[talent:112289]] now deals reduced damage beyond 8 targets. The tooltip will reflect this change in a future update.
- [[talent:112221]] now reduces the cooldown of [[talent:112223]] by 45 seconds (was 30 seconds).
- [[talent:112180]] now causes you to deal 25% increased critical strike damage to targets chained to your Spear.
- [[talent:112246]] now increases all damage dealt by [[talent:112247]] (was only initial damage).
- The visual for [[talent:112242]] will now properly match its radius, both with and without the [[talent:112241]] talent. Impact visual has also been updated.
- The visual for [[talent:112223]] has been adjusted.
- Fixed an issue that caused [[talent:112188]] to increase maximum health by 15% instead of the intended 10%.

##### The following talents have been removed

- Titanic Throw
- Sonic Boom
- Blood and Thunder

#### Arms

- New Talent: [[talent:114733]] – [[spell:7384]] generates 8 Rage when used on a target below 35% health.
- [[talent:112201]] has been redesigned for Arms – Now grants 10% damage and 10% critical damage to [[spell:1464]], [[talent:112147]], and [[spell:1680]].
- [[talent:112119]] has been redesigned – Now grants [[spell:1680]] or [[talent:112147]] a 30% chance to make your next [[spell:1680]] or [[talent:112147]] cost 100% less Rage.
- [[talent:112313]] has been redesigned – Every other time [[spell:227847]] or [[spell:228920]] deal damage, you automatically cast a [[spell:12294]] at your target or random nearby enemy.
- [[talent:114639]] has been redesigned – When an enemy dies while affected by your [[spell:227847]], all damage you deal is increased by 5% for the remainder of the [[spell:227847]] and for 2 seconds afterwards. When an enemy dies while affected by your [[spell:228920]], its duration is extended by 2 seconds. These effects can trigger a maximum of 3 times per use of [[spell:227847]] or [[spell:228920]].
- [[talent:112229]] has been redesigned – Activating [[talent:112232]] grants 8 seconds of Sweeping Strikes and while [[talent:112232]] is active the cooldown of [[talent:112147]] is reduced by 1.5 seconds.
- [[talent:112119]] has been redesigned – [[talent:112147]] and [[spell:1680]] have a 30% chance to make your next [[talent:112147]] or [[spell:1680]] cost 100% less Rage.
- All ability damage increased by 43%.
- [[spell:163201]] damage increased by 15%.
- [[spell:1464]] damage increased by 20%.
- [[talent:112147]] now replaces [[spell:1680]].
- [[talent:112147]] cooldown reduced to 4.5 seconds (was 6 seconds).
- [[talent:112147]] damage increased by 5%.
- [[spell:7384]] damage increased by 55%.
- Rage generated from auto-attacks reduced by 16%.
- [[spell:1680]] base Rage cost reduced to 20 (was 30).
- [[spell:1680]] damage reduced by 33%.
- [[talent:112136]] base Rage cost reduced to 20 (was 30).
- [[talent:114738]] Rage cost reduced to 20 (was 40).
- [[talent:114740]] no longer increases damage dealt by [[spell:7384]].
- [[talent:112124]] now also triggers from [[talent:112147]].
- [[talent:112218]] now also triggers from [[talent:112147]].
- [[talent:114739]]'s damage bonus now applies to [[talent:112147]] as well as [[spell:1680]].
- [[talent:112228]] no longer triggers from [[talent:112144]]. Duration of Recklessness buff increased by 50% and bonus Rage generation reduced to 25% (was 100%).
- [[talent:112142]]'s Haste bonus now lasts as long as [[talent:112144]] does.
- [[talent:112131]] increases number of [[spell:7384]] charges by 1.
- [[talent:112137]] no longer increases number of [[spell:7384]] charges.
- [[talent:112137]] damage reduced by 58%.
- [[talent:119096]] no longer causes [[spell:7384]] to generates 8 Rage when used on a target below 35% health.
- [[talent:119096]] now also increases [[spell:7384]] damage by 15%.
- [[talent:112134]] chance to reset cooldown of [[spell:7384]] per Rage spent reduced to 1% (was 1.3%).
- [[talent:112309]] increase to Tactician's chance to reset cooldown of [[spell:7384]] per Rage spent reduced to 0.5% (was 0.6%).
- [[talent:112315]]'s Versatility bonus increased to 2% (was 1%).
- [[talent:112133]] now accelerates Rend's Bleed baseline.
- [[talent:119138]] is now a choice node with [[spell:227847]]. All existing [[spell:227847]] sub-talents have been updated to work with both [[spell:228920]] and [[spell:227847]].
- [[talent:112314]] no longer generates Rage on cast.
- [[talent:112209]] now increases [[spell:12294]] damage by 5% and [[spell:12294]] critical strike damage by 5% per point (was [[spell:1464]] damage and critical strike chance).
- [[talent:112317]] now restores 10% of Rage spent on Execute per point (was 5%).
- [[talent:112228]] tooltip updated with detailed information. No functional changes.

##### The following talents have been removed:

- Tide of Blood has been removed, its effects have been added to [[spell:260643]]
- Reaping Swings
- Hurricane

:::

:::

## FAQ

:::accordion
:::details Q: Why am I running out of rage?
A: You may be using rage-spending abilities too much and not prioritizing  [[spell:7384]] enough, however:

- If your group does not have [[spell:462854]] then you are far more likely to have Rage issues, and it is to be expected.
- Most AoE builds have you rage-starving on single-target, especially if playing [[talent:123393]].

:::

:::

---

### Credits

Written By: **Revvez**

Reviewed by: **Meeres**

:::changelog 更新记录
**2026-07-28** Updated for patch 12.1.

**2026-03-16** Updated BiS list.
Updated talent builds.
Updated Trinket and Races simulations.

**2026-02-19** Updated for patch 12.0.1.
Updated almost every part of the guide.

**2026-01-18** Updated for patch 12.0.

**2025-12-02** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-09-10** Updated trinket simulations.
Updated race simulations.

**2025-08-03** Updated for patch 11.2.
Updated BiS list.
Updated trinket simulations.
Updated race simulations.

**2025-06-24** Updated for patch 11.1.7.
Updated BiS list.

**2025-04-21** Updated for patch 11.1.5.
Updated BiS list.
Updated trinket simulations.

**2025-02-23** Updated for patch 11.1.

**2024-12-17** Updated for patch 11.0.7.
Updated BiS list.
Updated simulations.

**2024-10-22** Updated for patch 11.0.5.

**2024-09-09** Updated Simulations.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
