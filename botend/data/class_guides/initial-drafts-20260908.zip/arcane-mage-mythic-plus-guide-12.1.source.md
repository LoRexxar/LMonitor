Welcome to the **Arcane Mage** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Arcane Mage** Mythic+ Best in Slot
```json
{
  "source_code": "JgqAQ6DA3_fABIgJEIIEBAwJ5OwVtOggCYhNYFQApfBBAERAAYQrDYQAUAFj1gVABoMJEIACBAwF5OggC4UAB8cCPAQCN8AFJTCBAiQABITBeAwyJ4BBboaCPQ23XQgAQEAAxj7AYYjgCgVABACqDIIOBAAGAHQYsZ7LMYzt1sZJ2WDAjAGMLFQANTCBAASBAsXNBWTCwAz0XQQAj7mACiRAAUPuBMDL2IDg0YbNOFQAqfBBZYBDkVjLyUwfYQ1HEAACBAQBMgwZRPQFMgR3XQAAQEAAJUFDBQvIEEg0A0TADzGWBEQCAPAAAFAA2-yY1ENM3WTWiwgNLXDAjsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240902]] · [[item:240902]] |
| 肩部 | [[item:271562]] | [[item:243991]] |
| 胸部 | [[item:271567]] | [[item:243977]] |
| 腰部 | [[item:271561]] | [[item:240902]] |
| 腿部 | [[item:271563]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243953]] |
| 腕部 | [[item:239648]] | [[item:240902]] · [[item:245784]] |
| 手部 | [[item:271565]] |  |
| 戒指一 | [[item:159459]] | [[item:240902]] · [[item:243957]] |
| 戒指二 | [[item:268266]] | [[item:240902]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:250215]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:245769]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Arcane Mage**, you have access to Prismatic Bolt, which grants you a chance to replace your [[spell:30451]] with [[spell:1295924]] whenever you consume [[talent:134028@FAQAMi4A]] stacks.

**Rank 2** makes your [[spell:1295924]] grant you [[spell:79684]] and increases damage done by [[spell:5143]]. While **Rank 3** increases the chance of gaining [[spell:1295924]] from consuming [[talent:134028@FAQAMi4A]] stacks. Additionally, it also increases damage done by [[spell:44425]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-arcane-mxr.webp>)

Prismatic Bolt

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:126509@FAQA9chA]]
    
    - New filler spell.
  - [[talent:126524]]
    
    - Reworked and no longer grants intellect.
  - [[talent:134028@FAgA2fOBMi4A]]
    
    - Used to be called [[spell:332769]], now has a new name and many more interactions with the spec.
  - [[talent:126516]]
    
    - No longer refunds [[spell:36032]] and has a different condition to proc.
  - [[talent:137084]]
    
    - Reworked to be a passive haste increase.
- **Class Tree**
  
  - [[talent:134182]]
    
    - Restores you some health when you drop low and casts [[talent:80174]]. One of the weakest passive defensives but still something and has an interesting concept.
  
  
  
  - [[talent:136581]]
    
    - Casts [[talent:80140]] a second time on its own but adds a cooldown to it.
  - [[talent:136576]]
    
    - Allows your [[talent:80175]] to be casted on yourself automatically whenever you use it on another friendly target.
  - [[talent:134194]]
    
    - Improves your [[talent:80180]] and makes it a much stronger defensive ability.
- **Removed**
  
  - [[spell:383783]]
    
    - Its removal completely changes how you play the spec.
  - [[spell:382440]]
    
    - One of the greatest abilities **Mage** ever had and it being removed will affect all aspects like damage, utility or survivability.
  
  
  
  - [[spell:414660]]
    
    - Great personal and party defensive ability that in combination with [[talent:80147]] was a very strong spell overall. Its removal together with [[spell:382440]] and removed damage reduction from [[talent:80183]] and [[talent:115877]] results in a much weaker defensive state of **Mage** coming into Midnight.
  - [[spell:157981]]
    
    - One of the strongest utility spells also gone, doesn't affect you much directly but makes you quite a bit more useless in any meaningful content of the game.

## Hero Talents

- [[talent:123341]] is the main hero talent used in both single and AoE scenarios.



### [[talent:123341]]

- [[talent:123341]] hero talent tree mainly revolves around [[talent:117250@AJAC]] and [[talent:117255@AJAC]]. They both interact with you and each other, granting additional damage, haste buffs and even gives you new ways to proc [[spell:79684]].

- [[talent:117250@AJAC]] have a chance to proc after casting a damaging spell. They increase your spell damage and stack up to 5.
  
  - Thanks to [[talent:135926@AJAC]] and [[talent:135925@AJAC]], casting [[spell:44425]] and [[spell:5143]] can summon a Meteorite. When a Meteorite lands, you have a chance to gain [[spell:79684]].

- When casting [[talent:126519@AJAC]], you summon an [[spell:448659@FJAC9chAbfuAUkuALunAEdTAD0wBE0wBN3yEIA]] aiding you in battle casting random arcane and fire spells. 
  
  - With [[talent:117248@AJAC]], when [[spell:448659@FJAC9chAbfuAUkuALunAEdTAD0wBE0wBN3yEIA]] is summoned, it consumes all your [[talent:117250@AJAC]], increasing your spell damage during [[talent:126519@AJAC]] and causing [[spell:448659@FJAC9chAbfuAUkuALunAEdTAD0wBE0wBN3yEIA]] to cast an exceptional arcane or fire spell over its duration.
  - Additionally, after [[spell:448659@FJAC9chAbfuAUkuALunAEdTAD0wBE0wBN3yEIA]] expires, due to [[talent:117246]], you will gain a [[spell:1260277]] for 10 seconds.

- On top of that, you will also gain multiple of other buffs such as [[talent:117249@AJAC]] that grants you [[spell:451038]] after [[talent:126519@AJAC]] ends, [[talent:117256@AJAC]] that grants you stacking haste each time you cast [[spell:30451]] or [[spell:44425]] and few other minor buffs.




### [[talent:123339]]

- Main feature of the [[talent:123339]] hero talent tree is the addition of a new passive spell, [[spell:443763]], and your interaction with it. [[spell:443763]] is a projectile that deals arcane damage and shoots automatically into your target.

- You can trigger it with a variety of ways: 
  
  - [[talent:117266@AJAC]] makes [[spell:44425]] conjure an [[spell:443763]] for every 5 [[spell:384452]] stacks consumed.
  - [[talent:117264@AJAC]] allows your [[talent:128689]] to conjure an [[spell:443763]], up to 2. Additionally, also increases damage of the [[talent:128689]].
  - [[talent:135920@AJAC]] makes your [[talent:126539]] to have a chance to conjure an [[spell:443763]] alongside its Arcane Assault.
  - [[talent:135946@AJAC]] causes gaining [[spell:79684]] to conjure 2 [[spell:443763]].
  
  
  
  - Due to [[talent:117265@AJAC]] you have a chance to conjure a burst of [[spell:443763]] when conjuring one or more of them.
  - [[talent:117257@AJAC]] makes your [[talent:126519@AJAC]] to generate 8 [[spell:443763]]. Additionally, during [[talent:126519@AJAC]], your chance to conjure an additional [[spell:443763]] is increased.

- On top of that, there are a bunch of passive interactions that grant you some additional damage, cooldown reductions and other stuff:
  
  - [[talent:135919@AJAC]] makes your direct damage from [[spell:443763]] to have a chance to grant 1 stack of [[spell:384452]].
  - [[talent:135918@AJAC]] causes casting [[spell:44425]] while at 20 or more [[spell:384452]] stacks to refund 5 [[spell:384452]] stacks. Additionally, also increases [[spell:44425]] damage.
  - [[talent:128267@AJAC]] increases damage of your [[spell:30451]] and [[talent:126509@FAQA9chA]] and makes casting [[talent:126538]] to conjure [[spell:443763]].
  - [[talent:117258@AJAC]] reduces the cooldown of [[talent:128689]] with each direct damage hit from [[spell:443763]].
  - [[talent:117261@AJAC]] increases [[talent:126519@AJAC]] damage and your chance to gain [[spell:79684]].
  - [[talent:117259@AJAC]] makes direct damage of your [[spell:443763]] to also deal damage to nearby enemies.





## Talents



### [[talent:123341]] Mythic+ Build

:::talents [[talent:123341]] **Arcane Mage** Mythic+ Build
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:134028]]
  
  - Each wave of [[talent:126537]] increases the damage of [[spell:44425]].
- [[talent:126523]]
  
  - [[spell:30451]] generates an additional [[spell:36032]].
- [[talent:126544]]
  
  - Gives you a chance to shoot an additional [[talent:128689]] for each stack of [[talent:134028@FAgA2fOBMi4A]].
- [[talent:126542]]
  
  - Grants your [[talent:126537]] a chance to grant you an [[spell:36032]].

##### Class Tree

- [[talent:80141]]
  
  - Grants you a damage taken reduction by 70% for 6 seconds instead of immunity from [[talent:80181]].
- [[talent:80174]]
  
  - Returns you to your current location and health when cast a second time, or after 10 seconds. Effect negated by long distance or death. Very versatile spell and should be used both for improving your survivability and movement.
- [[talent:80163]]
  
  - Teleports you forward, unaffected by the global cooldown and castable while casting.
- [[talent:115877@FAgAVVdBvFbA]]
  
  - Makes you invisible and untargetable for 20 seconds, removing all threat. Any action taken cancels this effect. Increases your movement speed, additionally with [[talent:80170@FAQAvFbA]], can become a decent movement speed boost.
- [[talent:134194]]
  
  - Makes [[spell:235450]] to further reduce your magical damage taken and duration of harmful Magic effects. Additionally, gains you an extra charge.
- [[talent:80183]]
  
  - Creates 3 copies of you nearby for 15 seconds. While active, you generate significantly reduced threat. Taking direct damage will cause one of the copies to dissipate.
- [[talent:125819]]
  
  - Enemies in a 12 yard cone in front of you take fire damage and are disoriented for 4 seconds. Damage will cancel the effect.

#### Hero Talents

- [[talent:117253@AJAC]]
  
  - Currently outperforms the other option.
- [[talent:117252@AJAC]]
  
  - Better survivability node.
- [[talent:117254]]
  
  - Both options are fairly useless; pick whichever one fits your needs.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:126537]] fires 1 additional Missile and deals 20% increased damage.
- **4-Set:** ‍Each wave of [[talent:126537]] increases the damage of your next [[spell:30451]],  [[talent:126509]], or [[spell:1295924]] by 5%, up to 40%.

### Single-Target & Cleave



#### [[talent:123341]]

##### Opener

- The goal of the opener is to enter your [[talent:126519@AJAC]] as soon as possible. Below, you can see an example of how your opener may look like using our recommended ‍‍‍[[talent:123341]] talent build:

:::rotation **Arcane Mage** Single-Target & Cleave opener in Mythic+
```json
{
  "source_code": "JEGiKI082BAAAcAUyV2YhNHdCEAnuOAAAAAACFeOBAAACpBWCAQAOggJTWQBWQQitGwBQAgQjfOBBkACCdBFBcQGIEBIkQjxTAAAAAgQXQB"
}
```
1. [[spell:30451]] Precast [[item:241308]] · [[spell:80353]]
2. [[spell:153626]]
3. [[spell:365350]]
4. [[spell:44425]]
5. [[spell:321507]]
6. [[spell:5143]]
7. [[spell:5143]]
8. [[spell:44425]]
9. [[spell:1295924]]
10. [[spell:5143]]
:::

- Once you enter [[talent:126519@AJAC]] nothing special changes, you just have to follow the general priority list of abilities and follow your rotation.

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:126519@AJAC]] on cooldown.
2. Cast [[talent:126538]] on cooldown. 
   
   - Every time you cast it during [[talent:126519@AJAC]] window, make sure to cast [[spell:44425]] right before using [[talent:126538]].
3. Cast [[talent:126537]] if you have less than 12 stacks of [[talent:134028]].
4. Cast [[spell:44425]] if you have [[spell:451038]].
5. Cast [[spell:1295924]].
6. Cast [[spell:44425]] if you have 4 [[spell:36032]] and either
   
   - have 25 stacks of [[talent:134028@FAQAMi4A]].
   - have 10 or more stacks of [[talent:134028@FAQAMi4A]] and have both [[spell:79684]] and [[talent:135698]] available.
   - fighting 2 or more enemies, have [[talent:134028@FAQAMi4A]] stacks between 12 and 18 and either
     
     - have [[spell:79684]].
     - have [[spell:153626]] ready.
7. Cast [[spell:153626]] if you have less than 3 [[spell:36032]].
8. Cast [[spell:30451]]





## Deep dive

### Managing major cooldowns

Make sure to always have [[talent:126519@AJAC]] be paired with [[talent:126538]]. As long as you are casting both of them on cooldown, they should always naturally line up together. Additionally, try yout best to enter burn windows with close to maximum amount of [[talent:134028@FAgA2fOBMi4A]] stacks. That means that you will either have to hold your [[spell:44425]] for a few seconds or delay your cooldowns for a bit to get back to high [[talent:134028@FAgA2fOBMi4A]] stacks.

### Clipping Arcane Missiles

You never clip your [[talent:126537]] due to how strong they are with [[talent:126542]] talent except when [[spell:451038]] window is coming up, then you stop the channeling just to not waste any free [[spell:44425]]. That is unless your [[talent:126537]] are [[spell:1244329]], then you just finish casting it and proceed to spamming [[spell:44425]] right after.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Arcane Mage** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[talent:80180]] with [[talent:80157]].




### Den of Nalorakk

:::talents **Arcane Mage** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with a [[talent:115877]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Arcane Mage** Mythic+ Build in Murder Row
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Arcane Mage** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Keep in mind that you can also remove roots with a [[talent:115877]].
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **ArcaneMage** Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Arcane Mage** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Arcane Mage** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Arcane Mage** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ",
  "code": "C6DAmxqme2NN7ABQRxXf6C8R0NzwYZmZmFMzQzMmBAAwAAmZmmlllZmZmZZZmJ2AAYBmZG2sMjZWmxYmZmZYhZMjZAAGAAgZmFMzAzMAYYmZ"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system stays the same going into **Midnight** with the only exception of adding [[spell:1284818]] to the lower keys.

- +2 Affix 
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Alternates between each other on a weekly basis, is always the opposite of the +7 Affix
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as an **Arcane Mage**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:125819]] and [[talent:125818]] are all great tools for this affix.
- Xal'atath's Bargain: Voidbound
  
  - Important to kill this instantly as it reduces damage taken for all nearby enemies, also plan your cooldowns around this affix so you're not forced to swap target during your [[talent:126538]].
- Xal'atath's Bargain: Pulsar
  
  - Use your mobility to help your teammates if needed.
- Xal'atath's Bargain: Devour
  
  - Make sure to [[talent:80175]] yourself every time this affix goes off.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as an **Arcane Mage**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Arcane Mage** AoE Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUAJxACKEEwABA"
}
```
**智力 ≫ 急速 ＞ 精通 ≥ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. **Leech** is a great stat tertiary stat to have, especially on AoE.
- **Speed** **-** Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DCRAA4DAnk7cVrjgCYhNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAA4DAG06YQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271562@DgQAA4DAXk7IoAOF]] | Tier / Catalyst |
| Cloak | [[item:268253@BARAA4DAYYjgCgVA]] | The Coiled Alter |
| Chest | [[item:271567@DgQAA4DAJk7IoAOF]] | Tier / Catalyst |
| Wrist | [[item:239648@DiTAA4DAYA8YQrjtvwgN3WzmlYbNAMCYwsUA]] | Crafting |
| Gloves | Convert [[item:268243@AgQAAIoAYFA]]  <br>into [[item:271565@BASAA4DA7VTg1ghNCKAWBA]] | Catalyst of The Coiled Altar |
| Belt | [[item:271561@BiQAA4DAG06IoAOF]] | Catalyst |
| Legs | [[item:271563@DgQAA4DAbo6IoAOF]] | Tier / Catalyst |
| Boots | [[item:268255@DARAA4DAxj7ghNCKAWB]] | The Coiled Alter |
| Ring 1 | [[item:159459@DiRAA4DA1j7YQrjNyAIN2WjTBA]] | Kings' Rest |
| Ring 2 | [[item:268266@DiRAA4DA1j7YQrDZ14iMCKgTBA]] | Nymrissa Wavecaller |
| Trinket 1 | [[item:270164@BgQAA4DACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:250215@BgQAA4DACKgTBA]] | Murder Row |
| Main-hand | [[item:271092@DgQAA4DA9k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@BAUAA4DA2-yY1ENM3WTWiwgNLXDAjsUA]] | Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@BARAA4DAyIDg0EUA]] | The Blinding Vale |
| Neck | [[item:273781@BgRAA4DAkVjMyAINBFA]] | Altar of Fangs |
| Shoulder | [[item:239031@BARAA4DAyIDg0EUA]] | Temple of Sethraliss |
| Cloak | [[item:251190@BARAA4DAyIDg0EUA]] | The Blinding Vale |
| Chest | [[item:239032@BARAA4DAyIDg0EUA]] | Temple of Sethraliss |
| Wrist | [[item:251127@BARAA4DAyIDg0EUA]] | Murder Row |
| Gloves | [[item:251129@BARAA4DAyIDg0EUA]] | Murder Row |
| Belt | [[item:159255@BARAA4DAyIDg0EUA]] | Temple of Sethraliss |
| Legs | [[item:193750@BARAA4DAyIDg0EUA]] | Ruby Life Pools |
| Boots | [[item:251219@BARAA4DAyIDg0EUA]] | Voidscar Arena |
| Ring 1 | [[item:252258@BgRAA4DAkVjMyAINBFA]] | Voidscar Arena |
| Ring 2 | [[item:273792@BgRAA4DAkVjMyAINBFA]] | Altar of Fangs |
| Trinket 1 | [[item:250215@BARAA4DAyIDg0EUA]] | Murder Row |
| Trinket 2 | [[item:250224@BARAA4DAyIDg0EUA]] | Voidscar Arena |
| Main-hand | [[item:273778@BARAA4DAyIDg0EUA]] | Altar of Fangs |
| Off-hand | [[item:159667@BARAA4DAyIDg0EUA]] | Kings' Rest |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270167@AgQAAIoAOFA]]  <br>[[item:273796@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250259@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273794@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270161@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |
| **Junkyard** | [[item:273649@AgQAAIoAOFA]]  <br>[[item:158368@AgQAAIoAOFA]] |

### Embellishments

- 1x [[item:273060]]
  
  - Only crafted on your **weapon** or **off-hand**.
- 1x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists** or **Cloak** depending on your available gear.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]] -- default
- Combat Potion
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] -- default
- Augment Rune
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] -- *Unique, can only use one*
  - [[item:240902]]

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAAEAZbAB]]  <br>[[item:275707@BAAAAAE]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAA4D]] |
| Chest | [[item:243977@BAAAAAE]] |
| Wrist | [[item:275707@BAAAAAE]] |
| Waist | [[item:275707@BAAAAAE]] |
| Legs | [[item:240155@BAAAA4D]] |
| Boots | [[item:243953@BAAAA4D]] |
| Ring 1 | [[item:243957@BAAAA4D]] |
| Ring 2 | [[item:243957@BAAAA4D]] |
| Weapon | [[item:244029@BAAAAAE]] |

:::

:::column
:::gear **Arcane Mage** Enchantments in Mythic+
```json
{
  "source_code": "IQFZ-AQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQwGqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAAEAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing an **Arcane Mage** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
- [[spell:312924]] -- Mechagnome
  
  - Works the same way as [[spell:55342]] in terms of threat.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Arcane Mage**.

## Macros

Discover recommended macros for **Arcane Mage** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
**[[spell:475]]**

```wow-macro
#showtooltip
/cast [@mouseover] Remove Curse
```

**[[spell:118]]**

```wow-macro
#showtooltip
/cast [@mouseover] Polymorph
```

:::

:::details Recommended Macros
**[[spell:108978]] cancelaura --** *must have macro for whenever your [[spell:108978]] can put you back to lower hp than you currently have.*

```wow-macro
#showtooltip
/cancelaura Alter Time
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Arcane Mage**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Arcane-Mythic-UI-1024x616.png>)

**Arcane Mage** Mythic+ User Interface

:::accordion
:::details Addons
- **EllesmereUI** *-- Unit frames, nameplates, cooldown manager replacement, and many more* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **LittleWigs** *-- Generic Boss Mod* 
  
  - This is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger +alert messages, timer bars, sounds, and so forth, for one specific boss encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- *Developers' notes: We've made some adjustments to Mage defensives with the goal of improving Mage survivability as a whole. To accomplish this, we are unifying the functionality of Improved Barrier to give all specs an additional charge of their Barrier spell, plus one “rider” effect that is spec-specific.*
- New Talent: Improved Warding – Damage taken from area of effect attacks reduced by 4%.
- Improved Prismatic Barrier has been redesigned – Prismatic Barrier gains an additional charge and further reduces magic damage taken by 5%.
- Improved Blazing Barrier has been redesigned – Blazing Barrier gains an additional charge and cauterizes your wounds, healing you for 15% of the damage it absorbs.
- Improved Ice Barrier has been redesigned – Ice Barrier gains an additional charge and reduces your physical damage taken by 10%.
- Temporal Realignment has been updated – Now immediately heals 20% of your health and heals an additional 30% over 6 seconds.
- Hero Talents
  
  - Spellslinger
    
    - Spellfrost Teachings's tooltip has been adjusted for clarity. Functionality unchanged.
  - Sunfury
    
    - Developers' notes: We're redesigning Rondurmancy to lean into making your 3 orbs better, rather than giving you 5 orbs, to align more closely with the inspirations for Sunfury and reduce visual clutter on your character. We're also uncapping Mana Cascade to match other "applications may overlap" effects.
    - Rondurmancy has been redesigned – Your chance to generate a Spellfire Sphere is increased by 6%/12%. Spellfire Spheres grant an additional 1% spell damage.
    - Ashes of Inspiration has been redesigned – Each time your Phoenix casts a spell, gain 1 stack of Mana Cascade. Exceptional Spells grant 1 additional stack.
    - Memory of Al'ar has been updated – Combustion and Arcane Surge no longer cause the Mage to gain twice as many stacks of Mana Cascade.
    - Spellfire Spheres orb generation chance reduced to 6% for Arcane Mages and 12% for Fire Mages (was 12% and 25%).
    - Mana Cascade no longer has a stack cap.
    - Mana Cascade is now also gained when the Mage casts Arcane Pulse or Prismatic Bolt.
    - Fixed an issue for Arcane that caused Mana Cascade to be gained from some unintended spells.
- Arcane
  
  - Developers’ notes: We love the orb-slingin’ playstyle of Spellslinger Mage, and want to preserve the distinct difference in game feel between the two hero specializations. However, Orb Mastery overtaking Clearcasting usage and pushing Arcane Missiles out of the rotation has shown to have a negative impact on overall talent selection and excitement. These changes are aimed at keeping Arcane Orb as a powerful highlight of the Spellslinger playstyle, while allowing Arcane Missiles to remain an integral part of Arcane Mage’s identity. Additionally, the new defensive talent Refractive Images is intended to provide Arcane Mages with a unique survivability benefit to complement Frost’s Cold Snap / Glacial Bulwark, and Fire’s Cauterize.
  - *We're also redesigning Arcane Mage's Apex Talent to provide a more exciting visual moment and a greater impact on your talent build and rotation. Arcane Pulse has also been redesigned to focus its identity as a significant area damage event and a way to quickly regain charges in AOE.*
  - New Apex Talent: Prismatic Bolt
    
    - Rank 1: Arcane Barrage has a 1% chance per Arcane Salvo stack consumed to trigger Prismatic Bolt. Prismatic Bolt devastates the target with overwhelming energy, dealing Arcane damage to your target and reduced Arcane damage to nearby enemies. Damage reduced beyond 5 targets. Generates 4 Arcane Charges. Not affected by Arcane Blast talents or effects and does not scale its damage or mana cost with Arcane Charges.
    - Rank 2: Prismatic Bolt has a 50%/100% chance to grant Clearcasting. Arcane Missiles damage increased by 15%/30%.
    - Rank 3: Arcane Salvo grants an additional 1% chance to trigger Prismatic Bolt. Arcane Barrage damage increased by 15%.
  - New Talent: Refractive Images – 10% of damage you would take is instead dealt over 8 seconds. Casting Mirror Image increases this effect to 30% for 15 seconds.
  - Arcane Pulse has been redesigned – Cast time reduced to 2 seconds (was 2.25 seconds). Radius increased to 8 yards (was 2 yards). Now has a 15-second cooldown, generates 1 Arcane Charge for each enemy struck, and costs 10% of base mana. No longer has its cast time, radius, mana cost, or cast speed affected by Arcane Charges.
  - Orb Mastery has been redesigned – Casting Arcane Orb fires 2 additional orbs at 50% effectiveness.
  - Expanded Mind has been updated – Casting Arcane Orb grants 1 stack of Arcane Salvo (was 2). Casting Prismatic Bolt now grants 4 stacks of Arcane Salvo.
  - Arcane Blast damage increased by 20%.
  - Impetus no longer affects Arcane Pulse.
  - Prodigious Savant no longer affects Arcane Pulse.
  - Amplification moved below Presence of Mind / Slipstream in the talent tree.
  - Improved Clearcasting moved above Arcane Pulse in the talent tree, where Amplification was previously located.
  - Fixed an issue with how the tooltip calculated Clearcasting’s chance to occur with different talent selections. Clearcasting’s functionality is unchanged.
  - Touch of the Archmage has been removed.
  - Hero Talents
    
    - Spellslinger
      
      - Polished Focus has been updated – Casting Arcane Barrage while at 20 or more Arcane Salvo stacks refunds 3 Arcane Salvo stacks (was 5).
      - Splintering Orbs damage bonus to Arcane Orb increased to 50% (was 10%).
    - Sunfury
      
      - Glorious Incandescence now summons a Meteorite for every 5 stacks of Arcane Salvo consumed (was 6 stacks).
      - Fixed an issue that prevented Meteorites from granting Clearcasting.

:::

:::

:::accordion
:::details Patch 12.0.1
- Mage
  
  - Hero Talents
    
    - [[talent:123340]]
      
      - Arcane Phoenix area spell damage increased by 50%.
      - Burden of Power has been updated – Arcane Blast and Arcane Pulse damage bonus reduced to 5% (was 15%).
      - Codex of the Sunstriders now grants 1% increased spell damage during Arcane Surge (was 2%).
      - Arcane Soul duration reduced to 4 seconds (was 6 seconds).
      - Ashes of Inspiration Haste reduced to 15% (was 20%) and duration reduced to 6 seconds (was 10 seconds).
      - Sunfury Execution now grants Arcane Barrage 5% increased damage during Touch of the Magi (was 15%).
      - Glorious Incandescence now summons a Meteor for every 6 stacks of Arcane Salvo consumed (was 5).
    - [[talent:123344]]
      
      - Infused Splinters has been updated – Chance to grant Arcane Salvo increased to 25% (was 15%).
      - Controlled Instincts has been updated – Cleave percentage increased to 60% (was 40%).
      - Splintering Orbs has been updated – Arcane Orb damage bonus increased to 35% (was 25%). Now conjures 2 Arcane Splinters per target hit (was 1).
      - Arcane Splinter damage increased by 116%.
      - Signature Spell now increases Arcane Pulse and Arcane Blast damage by 25% (was 15%).
      - Polished Focus now increases Arcane Barrage damage by 25% (was 15%).
  - Arcane
    
    - Developers' notes: We’re looking to reduce Sunfury Arcane’s single target damage through the hero talent tree as well as Arcane’s baseline power. Spellslinger will be getting some buffs to compensate for the baseline ability reductions. Arcane’s AOE damage is further behind than we’d like and we will be making some targeted adjustments to increase their output in dungeon content.
    - Touch of the Archmage has been updated – Damage taken during Touch of the Magi reduced to 15% (was 20%). Rune primary target damage bonus reduced to 75% (was 100%).
    - Arcing Cleave now strikes additional targets for 60% of initial damage (was 40%)
    - Arcane Orb damage increased by 92%.
    - Arcane Pulse damage increased by 10%.
    - Arcane Surge damage increased by 25%.
    - Arcane Barrage damage reduced by 28%.
    - Arcane Missiles damage reduced by 28%.
    - Arcane Blast damage reduced by 28%.
    - Arcane Explosion damage reduced by 20%.
    - Expanded Mind now additionally causes Arcane Orb to grant 2 stacks of Arcane Salvo.
    - Resonance now increases Arcane Barrage's damage by 8% for each target beyond the first (was 5%).

:::

:::

:::accordion
:::details Patch 12.0
- Mage
  
  - New Talent: Improved Conjuration – Mirror Image's cooldown is reduced by 30 seconds/60 seconds.
  - New Talent: Time Walk – Alter Time resets the cooldown of Blink and Shimmer when you return to your original location.
  - New Talent: Spatial Manipulation – Blink gains an additional charge.
  - New Talent: Temporal Realignment – Upon dropping below 25% health, your past self corrects your timeline, casting Alter Time and instantly returning 50% of your maximum health.
  - New Talent: Improved Ice Barrier – Ice Barrier's absorb is increased by 5% of your maximum health and it now reduces your physical damage taken by 10%. Frost Mage only.
  - New Talent: Improved Blazing Barrier – Blazing Barrier's damage is increased by 200% and it now cauterizes your wounds, healing you for 15% of the damage it absorbs. Fire Mage only.
  - New Talent: Charm of Aegwynn – The critical strike damage of your spells is increased by 5%.
  - New Talent: Charm of Medivh – Mastery increased by 3%.
  - New Talent: Improved Blink – Blink's cooldown is reduced by 2 seconds.
  - New Talent: Permafrost Bauble - The cooldown of Ice Block and Ice Cold is reduced by 30 seconds.
  - New Talent: Master of Escape – Reduces the cooldown of Greater Invisibility by 45 seconds.
  - New Talent: Brainstorm – Hot Streak, Clearcasting, and Brain Freeze increase your Intellect by 1% for 8 seconds. Multiple applications may overlap.
  - New Talent: Improved Spellsteal – Spellsteal repeats its effect after 4 seconds, but it now has a cooldown of 4 seconds.
  - New Talent: Improved Counterspell – Counterspell prevents casting for an additional 1 second.
  - New Talent: Improved Remove Curse – Casting Remove Curse on a friendly target also casts it on yourself, but its cooldown is increased by 20 seconds.
  - New Talent: Mana Confluence – Your mana costs are reduced by 5%.
  - New Talent: Reflection – After casting Blink, it is replaced with Reflection for 8 seconds.Reflection: Teleports you back to where you last Blinked. Castable while casting and unaffected by the global cooldown.
  - Master of Time has been updated – Reduces Alter Time cooldown by 5 seconds/10 seconds. No longer grants an additional charge of Blink/Shimmer after casting Alter Time.
  - Overflowing Energy has been updated – Now increases the critical strike chance of Arcane Barrage, Fireball, and Frostbolt only. Now grants 20% increased Fireball critical strike chance per stack (was 10%).
  - Quick Witted has been updated – Counterspell's cooldown is reduced by 5 seconds.
  - Time Manipulation has been updated – Now reduces the cooldown of your loss of control spells by 5 seconds.
  - Incantation of Swiftness has been updated – Invisibility now increases your movement speed by 20%/40% for 6 seconds.
  - Mirror Image has been updated – No longer reduces the damage you take. Tooltip now correctly communicates its threat reduction effect.
  - Mirror Image duration reduced to 15 seconds (was 40 seconds).
  - All Barrier spells have had their cooldowns increased to 30 seconds (was 25 seconds).
  - Barrier spells now have a reduced global cooldown and now shield you for 25% of your maximum health (was 20%).
  - Blink cooldown increased to 15 seconds inherently.
  - Shimmer cooldown increased to 30 seconds (was 25 seconds) and no longer has 2 charges inherently.
  - Greater Invisibility no longer reduces damage you take by 60%.
  - Counterspell cooldown increased to 25 seconds (was 24 seconds).
  - Cone of Cold cooldown increased to 25 seconds (was 12 seconds) and now applies Chilled.
  - Ice Nova now replaces Cone of Cold when talented.
  - Flow of Time is now a 1-point talent.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - Accumulative Shielding
    
    
    
    - Blast Wave
    - Displacement
    - Diverted Energy
    - Frigid Winds
    - Ice Floes *(moved to the Frost talent tree)*
    - Incanter's Flow
    - Mass Barrier
    - Reabsorption
    
    
    
    - Reduplication
    - Rigid Ice
    - Shifting Power
    - Slow
    - Supernova
    - Tempest Barrier
    - Temporal Velocity
    - Volatile Destruction
  - Hero Talents
    
    - [[talent:123340]]
      
      - New Talent: Ashes of Inspiration – When your Arcane Phoenix expires, it grants you Lesser Time Warp for 10 seconds.Lesser Time Warp: Warp the flow of time, increasing your Haste by 20%.
      - New Talent: Spellfire Salvo – Arcane Salvo can stack 5 additional times. Meteorite damage increased by 15%.
      - New Talent: Pyrocosm – Each wave of Arcane Missiles has a 10% chance to summon a Meteorite. When a Meteorite lands, you have a 5% chance to gain Clearcasting.
      - New Talent: Explosive Potential – After casting Arcane Surge, your next Blink will cause a Blast Wave at your previous location, dealing Fire damage, knocking enemies back 8 yards, and slowing them by 70% for 6 seconds.
      - New Talent: Time Twist – The cooldown of Alter Time is reduced by 10 seconds.
      - Codex of the Sunstriders has been redesigned – When your Arcane Phoenix is summoned, it consumes all your Spellfire Spheres. Each Sphere consumed increases your spell damage during Arcane Surge by 2% and causes your Arcane Phoenix to cast an exceptional Arcane or Fire spell over its duration.
      - Merely a Setback has been redesigned – The bonuses provided by your Barrier spells persist an additional 8 seconds after your Barrier is removed. Additionally, Cauterize no longer deals damage to you.
      - Glorious Incandescence has been updated – Now Arcane Barrage summons 1 Meteor for every 5 Arcane Salvo stacks consumed.
        
        - Tooltip updated to better reflect the damage value of Meteorites.
      - Memory of Al'ar has been updated – No longer extends the duration of Arcane Soul based on the number of exceptional spells cast. Base duration of Arcane Soul increased to 6 seconds (was 2 seconds). Arcane Soul has been updated – Now grants 5 Arcane Salvo stacks per cast and Arcane Salvo is not consumed by casting Arcane Barrage (was increased Arcane Barrage damage per cast).
      - Sunfury Execution has been updated – Now causes Arcane Barrage to deal 15% increased damage to enemies affected by your Touch of the Magi.
      - Burden of Power has been updated – Now increases Arcane Blast and Arcane Pulse damage by 15%.
      - Savor the Moment has been updated – Now grants 0.4 seconds of Arcane Surge duration per Orb (was 0.5 seconds).
      - Several talents have changed positions in the talent tree.
      - Ignite the Future has been removed.
    - [[talent:123344]]
      
      - New Talent: Attuned Familiar – Your Arcane Familiar has a 50% chance to conjure a Splinter alongside its Arcane Assault.
      - New Talent: Infused Splinters – Direct damage from Arcane Splinters have a 15% chance to grant 1 stack of Arcane Salvo.Arcane Salvo: Increases the damage of your next Arcane Barrage by 3%.
      - New Talent: Polished Focus – Casting Arcane Barrage while at 20 or more Arcane Salvo stacks refunds 5 Arcane Salvo stacks. Arcane Barrage damage increased by 15%.
      - New Talent: Archmage's Wrath – Arcane Surge damage increased by 30%. Your chance to gain Clearcasting is increased by 3%.
      - Splinterstorm has been redesigned – Casting Arcane Surge generates 8 Arcane Splinters. During Arcane Surge, your chance to conjure an additional Arcane Splinter is increased to 100%.
      - Look Again has been redesigned – While in combat, Blink summons a Mirror Image at your previous location.
      - Augury Abounds has been redesigned – Conjuring one or more Splinter has a 10% chance to conjure a burst of 8 Splinters.
      - Shifting Shards has been updated – Gaining Clearcasting conjures 2 Arcane Splinters.
      - Force of Will has been updated – Casting Arcane Barrage conjures an Arcane Splinter for every 5 Arcane Salvo stacks consumed.
      - Signature Spell has been updated – Arcane Blast and Arcane Pulse damage increased by 15%. Casting Touch of the Magi conjures 4 Arcane Splinters.
      - Spellfrost Teachings has been updated – Arcane Orb and Frozen Orb cooldown reduction reduced to 0.25 seconds (was 0.5 seconds).
      - Splintering Sorcery has been updated – Splinters no longer apply a damage over time effect.
      - Controlled Instincts has been updated – Splinter cleave percentage increased to 30% (was 20%). No longer requires your target to have been recently damaged by Arcane Orb.
      - Splinters will now prefer targeting enemies that you have recently targeted with your spells.
      - When more than 1 Splinter is generated in a single event, Splinters will now fire on a delayed cadence, similar to how Splinterstorm used to function.
      - Reactive Barrier absorb amount reduced to 25% (was 50%).
      - Embedded Splinters are no longer tracked on nameplates.
      - Several talents have changed positions in the talent tree.
      - The following talents have been removed:
        
        - Unerring Proficiency
        - Volatile Magic
      - Splintering Orbs has been updated – Now causes Arcane Orb to generate 2 Arcane Splinters (was 4).
  - Arcane
    
    - New Talent: Arcane Salvo – Each wave of Arcane Missiles increases the damage of Arcane Barrage by 3%, up to 60%.
    - New Talent: Focusing Crystal – Each wave of Arcane Missiles has a 50% chance to grant 1 additional stack of Arcane Salvo.
    - New Talent: Arcane Singularity – Arcane Salvo damage bonus increased by 2%/4%.
    - New Talent: Arcane Pulse – Replaces Arcane Explosion. A pulse of Arcane magic erupts from underneath your target, dealing Arcane damage to all enemies within 2 yards. Damage reduced beyond 5 targets. Each Arcane Charge increases damage, radius, and mana cost.
    - New Talent: Charged Missiles – Each wave of Arcane Missiles will consume an Arcane Charge to increase its damage by 40%.
    - New Talent: Orb Mastery – Casting Arcane Orb while you have Clearcasting causes you to fire 2 additional Arcane Orbs at 100% effectiveness. Casting Arcane Orb now consumes Clearcasting.
    - New Talent: Aegwynn's Technique – Casting Touch of the Magi grants Clearcasting.
    - New Talent: Overflowing Insight – The damage of Arcane Blast and Arcane Pulse are increased by 15%, but their mana costs are increased by 25%.
    - New Talent: Expanded Mind – Casting Arcane Blast or Arcane Pulse grants 2 stacks of Arcane Salvo.
    - New Talent: Overpowered Missiles – Gaining Clearcasting has a 25% chance to cause your next Arcane Missiles to be Overpowered, causing it to deal 100% increased damage, generate maximum stacks of Arcane Salvo, and strike 3 additional targets at 50% effectiveness.
    - New Talent: Intuition – Upon reaching maximum stacks of Arcane Salvo, your next Arcane Barrage deals 25% increased damage.
    - Aether Attunement has been updated – Now a 2-point talent. Arcane Missiles hits 2/4 additional targets at 50% effectiveness.
    - Orb Barrage has been updated – Now causes Arcane Barrage to have a 4% chance per Arcane Salvo stack to launch Arcane Orb.
    - Reverberate has been updated – Arcane Pulse has a 50% chance to repeat its explosion at 30% effectiveness.
    - Arcane Tempo has been updated – Now grants 2% Haste passively. No longer a stacking aura.
    - Surging Urge renamed to Mana Bomb and has been updated – Arcane Surge's damage is increased by an additional 50% based on your mana spent.
    - Improved Prismatic Barrier is now located in the Class talent tree (was learned automatically when specialized as Arcane).
    - Arcane Orb and Mana Adept are now located in the Arcane talent tree (was learned automatically when specialized as Arcane).
    - Mana Adept has been updated – Now grants 2% of your maximum mana (was 1.5%).
    - All damage dealt increased by 15%.
    - Arcane Orb damage increased by 20%.
    - Arcane Barrage now replaces Fire Blast upon activating the Arcane specialization.
    - Arcane Barrage damage increased by 100%.
    - Resonance's Arcane Barrage damage increased by 5% per target beyond the first (was 12%).
    - Arcane Blast now replaces Frostbolt upon activating the Arcane specialization.
    - Arcane Blast no longer has increased Clearcasting chance.
    - Arcane Blast damage increased by 80%.
    - Clearcasting's chance to trigger increased to 12%.
    - Illuminated Thoughts now increases Clearcasting's chance to trigger by 3% (was 5%).
    - Clearcasting's overlay now communicates how many charges of Clearcasting you have.
    - Evocation no longer grants Clearcasting or stacking Intellect bonus.
    - High Voltage chance to trigger increased to 30%. No longer increases chance on failure. Now increases Arcane Missiles damage by 20%.
    - Impetus now causes Arcane Pulse and Arcane Blast to generate 1 additional Arcane Charge. No longer grants spell damage.
    - Concentrated Power no longer affects Arcane Explosion.
    - Arcane Surge damage increased by 20% and now deals reduced damage beyond 8 targets (was 5).
    - Amplification's Arcane Missiles now fires 2 additional missiles (was 3).
    - Arcane Missiles now dynamically retargets during multi-target casts.
    - Arcane Missiles tooltip updated to reflect talent-based behavior.
    - Arcane Missiles damage increased by 125%.
    - Touch of the Magi's icon, sound, and visual effects have been updated.
    - Several talents have changed positions in the talent tree.
    - The following talents have been removed:
      
      - Aether Fragment
      
      
      
      - Arcane Bombardment
      - Arcane Debilitation
      - Arcane Harmony
      - Big Brained
      - Improved Touch of the Magi
      - Intuition
      - Leydrinker
      - Leysight
      - Magi's Spark
      - Nether Munitions
      - Nether Precision
      - Static Cloud
      - Time Loop

:::

:::

## FAQ

:::accordion
:::details Q: Why is my [[spell:321507]] small?
A: You probably aren't playing around your burns properly, check out the [Rotation](<https://maxroll.gg/wow/class-guides/arcane-mage-mythic-plus-guide#rotation-header>) section.

:::

:::

---

### Credits

Written By: **Wexi**

Reviewed By: **Xerwo**

:::changelog 更新记录
**2026-08-03** Updated for patch 12.1.

**2026-06-16** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-22** Updated for patch 12.0.1.

**2026-01-16** Updated for patch 12.0.



:::
