Welcome to the **Destruction Warlock** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 2/5 · Weak



:::

:::

:::column
:::gear **Destruction Warlock** Mythic+ Best in Slot
```json
{
  "source_code": "JkoAwX3CBc__BEgAmQggUEAAnk7AH16AYxYNCKAWBEQ6XQAAREAA6z6A6z6ACKAj1gVABgLJEIACFAwF5OggC4UA3W6AB0LJEIACBAQC5OQcj4UABECqDQICBAwJqOgHAPADtOwt1sUABkLJEIACBAQBqOggC4UAB89FF8AApEQRMgVABAiLzAAB8zaCzgxukQAAIUAABkIQTfBBBw9FEIICBAQ94OgEtOQA7xQAeqmANIBAC0gEYcW0DAACBAQBegAVfQQFMQQ3X0ADogVABQvIEIACBAwPNsHKleBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240967]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240890]] |
| 肩部 | [[item:271544]] | [[item:243991]] |
| 胸部 | [[item:271549]] | [[item:243977]] |
| 腰部 | [[item:239649]] | [[item:240908]] · [[item:240167]] · [[item:245790]] |
| 腿部 | [[item:271545]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:240167]] · [[item:245790]] |
| 手部 | [[item:271547]] |  |
| 戒指一 | [[item:268252]] | [[item:240914]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that serve as an extension of each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Destruction Warlock**, you have access to **Embers of Nihilam**, which gives your [[spell:29722]] a chance to proc [[spell:1265884]], which deals AoE Shadowflame damage to all enemies within 10 yards of your target.

**Rank 2** increases your **Crit** and **Haste** for a couple of seconds whenever [[spell:1265884]] deals damage. While **Rank 3** enables [[talent:136835]], [[talent:91592]] and [[talent:91582]] to proc [[spell:1265884]] at 50-60% effectiveness.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-destruction-mxr.webp>)

Embers of Nihilam

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:91588]]
    
    - Changed from a target debuff that increases damage from various spells to a [[talent:91591@FAQA28vA]] damage amplifier while letting you spread your [[spell:348]] to nearby targets upon using [[talent:91591@FAQA28vA]].
  - [[talent:91582]]
    
    - Changed from its old version [[spell:295422]], which was usable at all times with some benefits during execute, to an execute-only spell unless the changed [[talent:126004]] procs.
  - [[talent:91474]]
    
    - Changed from [[spell:387569]].
  - [[talent:126493]]
    
    - New enhancement for your [[spell:152108]].
  - [[talent:91489]]
    
    - Turns your [[talent:91502]] into a 1 minute and 30 seconds cooldown!
  
  
  
  - [[talent:136833]]
    
    - Now summoned by either your [[talent:134221]] or [[talent:128600]].
  - [[talent:128600]]
    
    - Now only a passive talent that can proc from using [[talent:136835]] or [[talent:91582]].
  - [[talent:128599]]
    
    - Got moved to the capstone talent category and lost its potential [[spell:456946]] enhancement.
- **Class Tree**
  
  - [[talent:136100]]
    
    - Great talent to apply [[spell:702]], [[spell:334275]] or [[spell:1714]] to a group of enemies at once.
  - [[talent:136101]]
    
    - More [[talent:91466]] mobility!
  - [[talent:136108]] / [[talent:136738]]
    
    - Powerful new AoE curses to slow down multiple enemies' attack or castspeed.
  - [[talent:136104]]
    
    - Direct [[spell:40671]] replacement.
- **Removed**
  
  - [[spell:215941]]
    
    - This results in fewer available [[spell:246985]] and less randomness in your [[spell:246985]] economy.
  - [[spell:196414]]
    
    - [[talent:136835]] can be cast more freely now. No need to monitor any affected debuffs!
  
  
  
  - [[spell:387156]] / [[spell:387165]]
    
    - Another hit to our [[spell:246985]] generation and also causes less frequent spawns of [[talent:136833]] since it only works with [[talent:134221]] or [[talent:128600]] now.

## Hero Talents

- [[talent:123385]] and [[talent:123382]] are both playable on single-target, while [[talent:123382]] does overall more AoE damage. [[talent:123382]] excels in spread out cleave while [[talent:123385]] has a lot of passive AoE and more priority damage due to [[talent:117452]].



### [[talent:123385]]

- Spending a [[spell:246985]] starts a cycle of one of 3 different [[talent:117452]]. 
  
  1. [[spell:431944]]
  2. [[spell:432815]]
  3. [[spell:432816]]
  4. Starts on 1. again.

- The duration of an active [[talent:117452]] is reduced by 1 second per [[spell:116858]], [[spell:5740]] or [[talent:91582]] cast baseline. Your [[talent:117452]] is reduced by **1** additional second when you cast [[spell:116858]] because of [[talent:117453]] as well as another second if you're talented into [[talent:118838]] and your [[talent:91502]] is active.

- Only 1 [[talent:117452]] can be up at a time, and each turns into their respective **Demonic Art** after it expires, which is triggered after you cast your next [[spell:116858]], [[spell:5740]] or [[talent:91582]]:
  
  - [[spell:428524]]
    
    - A **Fel Lord** jumps at your target and applies [[spell:434424]] for 15 seconds.
  - [[spell:432794]]
    
    - Deals damage to your target and turns your next [[spell:29722]] into [[spell:434506]], which generates 2 [[spell:246985]].
  - [[spell:432795]]
    
    - Summons a **Pit Lord** that attacks your target with [[spell:434404]] and turns your next [[spell:116858]] into [[spell:434635]] which deals a large amount of AoE damage.
- Additionally, whenever a **Demonic Art** is active, your next [[spell:116858]], [[spell:5740]] or [[talent:91582]] benefits from [[talent:117453]].
- Your [[talent:91502]] is further empowered through [[talent:117428]].
- [[talent:136092]]
  
  - Passive AoE damage when consuming [[spell:428524]], [[spell:432794]] or [[spell:432795]].
- [[talent:136091]]
  
  - Additional single-target damage when consuming [[spell:428524]], [[spell:432794]] or [[spell:432795]].
- [[talent:136090]]
  
  - Every time you consume [[spell:428524]], [[spell:432794]] or [[spell:432795]]. You gain 2% intellect per consumed [[talent:136092]] up to 6% for 10 seconds.




### [[talent:123382]]

- Your [[spell:348]] is turned into [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]].
- [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] has no cast time or **FACING** requirement.
- You have access to a 1 minute cooldown called [[spell:442726]].

- [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] can stack up and has multiple neat interactions with different talents which can increase its stack count or have other benefits.
  
  - Spending [[spell:246985]] on damaging spells increases the stacks of [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] by 1 and has a chance to gain an additional stack due to [[talent:117434]] and [[talent:123310]].
  - Casting [[spell:442726]] increases all active [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] stacks by 3 while each [[spell:116858]], [[talent:91582]] or [[talent:91592]] adds 1 additional stack during its duration.
  
  
  
  - [[talent:117441]] gives [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] the chance to add a stack whenever it crits.
  - Whenever [[talent:117434]] deals damage you have a chance to gain [[talent:91485]] stacks through [[spell:440055@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] even if you are not currently talented into [[talent:91485]].
- [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] has a built-in mechanic which consumes its' accumulated stacks one after another for more damage. This mechanic is called **Corrupted**.
  
  - The **Corrupted** state of [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] is triggered by the following: 
    
    - Chance whenever [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] gains a stack.
    - If [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] reaches 8 stacks.
    - If the target [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] is on reaches 20% or is below 20% already.
    - When [[spell:442726]] is up.
- [[talent:136095]]
  
  - Passive damage increase to Chaos Bolt and Rain of Fire which is doubled during [[spell:442726]].
- [[talent:136094]]
  
  - [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] has a chance to grant you 8 seconds of [[spell:442726]].
- [[talent:136093]]
  
  - [[spell:442726]] grants more haste and increases [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] stack size upon use by an additional 2 stacks.





## Talents



### [[talent:123385]]

:::talents [[talent:123385]] **Destruction Warlock** Mythic+ Spec
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCmZGzssMamZYbYZ2aswAAAjBDAwMzMDGzYMbAAAmZmZAAYGG",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCmZGzssMamZYbYZ2aswAAAjBDAwMzMDGzYMbAAAmZmZAAYGG"
}
```
:::

#### When to use this Spec

You can use this Spec at all levels of Mythic+ keys. [[talent:123385]] in particular shines in priority damage while simultaneously cleaving enemies passively. Even in big pulls it's often more beneficial to spend your [[spell:246985]] on [[spell:116858]] instead of [[talent:91592]] to bring down high-health enemies quicker.

[[spell:152108]] and [[talent:91591@FAQA28vA]] with [[talent:91588]] help you to apply [[spell:348]] on multiple enemies.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[spell:205184]]
  
  - Got reworked in this patch, it's not a debuff anymore but rather only increases your [[talent:91591@FAQA28vA]] damage and spreads [[spell:348]] upon use.
- [[spell:152108]]
  
  - Another way of dealing upfront damage and refreshing [[spell:348]] at the same time and leaves behind [[talent:126493]] if talented.
- [[talent:91494]]
  
  - Applies [[talent:91493]] passively, helping you generate more [[spell:246985]] while providing passive cleave.
- [[spell:1122]]
  
  - Your main cooldown for burst windows, this is enhanced by [[talent:126494]] and [[talent:91489]].

##### Class Tree

- [[talent:91439]]
  
  - Used as a quick pet recovery either if your current pet dies or you got resurrected. Skips the [[spell:246985]] cost and significantly reduces the cast time for the summoned pet.
- [[talent:91460]]
  
  - Toggleable movement speed increase that costs health per second to use.
- [[talent:91452]]
  
  - Quick selfheal of a short cooldown. Further enhanced by [[talent:136105]].
- [[talent:91444]]
  
  - Provides you with a big absorb shield at the cost of your heatlh. Health cost is reduced by [[talent:91446]]. You can also change [[talent:91446]] to [[talent:91445]] to have access to more potential [[talent:91444]] uses.
- [[talent:91466]]
  
  - Enables you to travel a larger distance once every 90 seconds. You are able to use it twice if [[talent:136101]] is talented.
- [[talent:91457]]
  
  - AoE stun to control a group of enemies.
  - On a choice node with [[talent:91458@FAQAvH2E]] which can be more beneficial depending on the dungeons or the amount of pulls you are doing.
- [[talent:91469]]
  
  - Enhances multiple utility spells, mainly used together with [[spell:48020]], [[spell:6262]], [[spell:111771]] and [[spell:234153]].
- [[talent:91434]]
  
  - Massive for survivability since it alters your [[spell:6262]] to [[spell:452930]], which is useable multiple times per combat.
- [[talent:136738]] or [[talent:136108]] depending on the boss you're fighting. [[talent:136108]] be used as a defensive cooldown for your tank. [[talent:136738]] can be very beneficial for slowing down important casts.

#### Hero Talents

- [[talent:118838]]
  
  - Outperforms [[talent:117445]].
- [[talent:117449]]
  
  - Decent health recovery during [[spell:104773]].
  - Good to pair with [[talent:91467]] for more frequent uses.
- [[talent:117433]]
  
  - Enhances your [[spell:48020]].
  - Swap to [[talent:118837]] if you play [[talent:91458@FAQAvH2E]] to disrupt enemies more often.




### [[talent:123382]]

:::talents [[talent:123382]] **Destruction Warlock** Mythic+ Spec
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::

#### When to use this Spec

Use this spec if you predominantly want to deal a lot of AoE damage. The mass AoE damage potential is a lot higher than with [[talent:123385]].

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Hero Talents

**Changed** [[talent:123385]] to [[talent:123382]] for more info visit the **Hero Talent** section above.

- [[talent:117419]]
  
  - Combines your [[spell:702]] and [[spell:1714]].
- [[talent:123310]] 
  
  - Outperforms [[talent:117451]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍[[spell:29722]] damage increased by 25% and [[spell:29722]] has a 10% increased chance to evoke an ‍[[spell:1265884]].
- **4-Set:** Targets damaged by ‍[[spell:1265884]] take 6% increased damage from your spells and abilities for 6 seconds.

### Single-Target



#### [[talent:123385]]

##### Opener

- Your goal is to spend as many [[spell:246985]] as possible without wasting resources while also keeping relevant abilities on cooldown.

:::rotation [[talent:123385]] **Destruction Warlock** single-target opener in Mythic+
```json
{
  "source_code": "IIHTKIELSJAAAcAUyVGc1xGbAIkKGBQABggQiRQAHAxABgorDEQCgIEXQBAAAEgAOngDIoHyBUgFR4CKJT8AAAgA-MDgBIUCbQAQCEAIMAgQaQXCIQieIHAAAAAACpBd"
}
```
1. [[spell:152108]] Prepull
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:116858]]
5. [[spell:17962]]
6. [[spell:246985]] >3 
   
   1. [[spell:116858]]  
      
      随后回到主循环
7. 
8. [[spell:29722]]
9. [[spell:116858]]
10. [[spell:29722]]
:::

- Always cast [[spell:348]] unless it was already applied by either [[spell:6353]] or [[spell:152108]].
- Use your active trinkets, [[item:241288]] and racials like [[spell:20572]] or [[spell:26297]] after using [[spell:1122]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:348]] on your target.
2. Cast [[spell:434635]] if [[spell:434636]] is up.
3. Cast [[spell:116858]] if you are capping on [[spell:246985]].
4. Cast [[spell:434506]] if you are below 3 [[spell:246985]] and [[spell:433891]] is up.
5. Cast [[spell:17962]] if you have 3 stacks or you're moving.
6. Cast [[spell:17962]] to generate [[spell:246985]].
7. Cast [[spell:29722]] to generate [[spell:246985]].




#### [[talent:123382]]

##### Opener

- Your goal is to spend as many [[spell:246985]] as possible without wasting resources while also keeping relevant abilities on cooldown.

:::rotation [[talent:123382]] **Destruction Warlock** single-target opener in Mythic+
```json
{
  "source_code": "JoHTLIELSJAAAcAUyVGc1xGbAIkKGBQABggQiRQAHAxABgorDEQCgIEXQBAAAEgAOngDIYWwGUgFIoHyBUACRYDKJT8AAAgA-MDgBIUCbQAQCEAIMAgQaQXCIQieIHAAAAAACpBd"
}
```
1. [[spell:152108]] Prepull
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:442726]]
5. [[spell:116858]]
6. [[spell:17962]]
7. [[spell:246985]] >3 
   
   1. [[spell:116858]]  
      
      随后回到主循环
8. 
9. [[spell:29722]]
10. [[spell:116858]]
11. [[spell:29722]]
:::

- Always cast [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] unless it was already applied by either [[spell:6353]] or [[spell:152108]].
- Use your active trinkets, [[item:241288]] and racials like [[spell:20572]] or [[spell:26297]] after using [[spell:1122]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] on your target.
   
   - Cast [[spell:152108]] to keep up [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]].
2. Cast [[spell:116858]] if you are capping on [[spell:246985]].
3. Cast [[spell:17962]] if you have 3 stacks.
4. Cast [[spell:17962]] to generate [[spell:246985]].
5. Cast [[spell:29722]] to generate [[spell:246985]].





### AoE



#### [[talent:123385]]

##### Opener

- This opener can vary by a lot depending on your [[spell:246985]] generation. Below you see **one** variation of an opener on 4 targets assuming that you're playing the recommended [[talent:123385]] **talent** **spec**.

:::rotation [[talent:123385]] **Destruction Warlock** AoE opener in Mythic+
```json
{
  "source_code": "JAHqMIELSJAAAcAUyVGc1xGbAIgKGBAAAIgYEAAADEAiuOAAAAAACwFUAEgAOnAD8wmFAAAAClMxDAAAC4zMAGQBRQAQCEAKQAgQwlTABkQDFBAbBsCOCoiRAAAACwmFAAAACwmF"
}
```
1. [[spell:152108]] Prepull
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:5740]]
5. [[spell:246985]] >3 
   
   1. [[spell:5740]]  
      
      随后回到主循环
6. 
7. [[spell:80240]]
8. [[spell:17962]]
9. [[spell:5740]]
10. [[spell:17962]]
11. [[spell:5740]]
12. [[spell:5740]]
:::

- Always cast [[spell:348]] unless it was already applied by either [[spell:6353]] or [[spell:152108]].
- Use your active trinkets, [[item:241288]], and racials like [[spell:20572]] or [[spell:26297]] after using [[spell:1122]].

##### Priority List

- Keep up [[spell:348]] on targets that last over 9 seconds.
- Cast [[spell:80240]] on a secondary target.
- Cast [[spell:116858]] or [[spell:5740]] if you are about to cap on [[spell:246985]].
- Cast [[spell:152108]] on cooldown.
- Cast [[talent:128599]] if talented.
- Cast [[spell:17962]] if you have 3 stacks.
- Cast [[spell:17962]] to generate [[spell:246985]].
- Cast [[spell:29722]] to generate [[spell:246985]]




#### [[talent:123382]]

##### Opener

- This opener can vary by a lot depending on your [[spell:246985]] generation. Below you see **one** variation of an opener on 4 targets assuming that you're playing the recommended [[talent:123382]] **talent spec**.

:::rotation [[talent:123382]] **Destruction Warlock** AoE opener in Mythic+
```json
{
  "source_code": "JYHqNIELSJAAAcAUyVGc1xGbAIgKGBAAAIgYEAAADEAiuOAAAAAACwFUAEgAOXADMIkZBbQBUwDbWAAAAIUyEPAAAIgPzAYAFEBBAJQAcgBACAXOBAAANsEBsZRADRjKGBAAAIAbWAAAAIAbWA"
}
```
1. [[spell:152108]] Prepull
2. [[spell:17962]]
3. [[spell:1122]]  [[item:241288]] · [[spell:20572]] · [[item:249346]]
4. [[spell:442726]]
5. [[spell:5740]]
6. [[spell:246985]] >3 
   
   1. [[spell:5740]]  
      
      随后回到主循环
7. 
8. [[spell:80240]]
9. [[spell:17962]]
10. [[spell:5740]]
11. [[spell:17962]]
12. [[spell:5740]]
13. [[spell:5740]]
:::

- Always cast [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] unless it was already applied by either [[spell:6353]] or [[spell:152108]].
- Use your active trinkets, [[item:241288]] and racials like [[spell:20572]] or [[spell:26297]] after using [[spell:1122]].

##### Priority List

1. Keep up [[spell:445465@FJACk2SAWdhALunAFQvADm4APjmAg0wBi0wBJIA]] on targets that last over 9 seconds.
2. Cast [[spell:80240]] on a secondary target.
3. Cast [[spell:116858]] or [[spell:5740]] if you are about to cap on [[spell:246985]].
4. Cast [[spell:152108]] on cooldown.
5. Cast [[talent:128599]].
6. Cast [[spell:17962]] if you have 3 stacks.
7. Cast [[spell:17962]] to generate [[spell:246985]].
8. Cast [[spell:29722]] to generate [[spell:246985]]





## Deep dive

### How do my Soul Shards work?

As a **Destruction Warlock**, your [[spell:246985]] behave differently compared to Affliction or Demonology. You don't generate 1 full [[spell:246985]] per cast, but rather Soul Shard Fragments.

10 Soul Shard Fragments build 1 full [[spell:246985]] and all your spells generate a different amount of Soul Shard Fragments, which is also influenced by potential Critical Strikes.

- [[spell:348]]
  
  - Generates 1 Soul Shard Fragment each DoT tick with a 50% to generate an additional one on Critical Strikes.
- [[spell:29722]]
  
  - Generates 2 Soul Shard Fragments and an additional one on Critical Strikes baseline. Generates additional Shards with [[talent:91481]]
- [[spell:17962]]
  
  - Generates 5 Soul Shard Fragments.
- [[talent:134221]]
  
  - Generates 1 full  [[spell:246985]].
- [[talent:136833]]
  
  - Generates 1 Soul Shard Fragment every second for 8 seconds.
- [[talent:91502]]
  
  - Generates 1 Soul Shard Fragment every second for 30 seconds.
  - As [[talent:123385]] it breaks down into 2 smaller Infernals after 30 seconds due to [[talent:117428]] which also generate Soul Shard Fragments   for another 10 seconds.
- *[[talent:91493]] / [[talent:91494]]
  
  - These are technically not generators but enhance [[spell:29722]], [[spell:17962]], and [[talent:134221]] on successful duplicates, doubling the amount Soul Shard Fragments generated, even if the afflicted [[talent:91493]] target is immune.

### Maximizing your Havoc

To maximize your damage while [[spell:80240]] is active you need to spend as many casts on [[spell:116858]] or [[spell:5740]] as possible. For this to happen you should enter the [[spell:80240]] window with as many of the following conditions as possible:

- A high amount of [[spell:246985]] or [[spell:246985]] income.
- [[spell:17962]] should be close to max stacks.
- Refresh [[spell:348]] / [[talent:117437@FAQAWdhA]] so they don't drop off during your [[spell:80240]] window.

Below is an example of what happens when you correctly manage your [[spell:80240]] window.

:::rotation [[talent:123382]] **Destruction Warlock** Havoc window in Raid
```json
{
  "source_code": "IYZAA_gARjBAIQVYydWZ0BSMAIEHMbQRCgAptEgVXIwi7JQB0LwgJOwzoJAINcgINcQCCgQDrQkMAIkYEAAAAAgACwFUAEgAOPQANwgQmFsBBgAICAXOBAAACoiRBECB6hsPMAABaQXAY4iHAgjeIHAAAIgG0BAAAIgeIHA"
}
```
1. [[spell:6353]] Target 1
2. [[spell:445468]] Target 2
3. [[spell:1122]]  [[spell:20572]] · [[item:249346]]
4. [[spell:442726]]
5. [[spell:80240]]
6. [[spell:17962]]
7. [[spell:116858]]
8. [[spell:17962]]
9. [[spell:116858]]
10. [[spell:29722]]
11. [[spell:17962]]
12. [[spell:116858]]
13. [[spell:116858]]
14. [[spell:29722]]
15. [[spell:116858]]
:::

- **This is not a fixed rotation**; This is just one example of how to play during your [[spell:80240]] window. **Critical hits**, [[talent:126494]] Infernals and [[talent:91494@FAQAymeB]] procs can increase your [[spell:246985]] generation, allowing you to spend more [[spell:246985]] on [[spell:116858]] or [[spell:5740]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Destruction Warlock** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### Den of Nalorakk

:::talents **Destruction Warlock** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### Murder Row

:::talents **Destruction Warlock** Mythic+ Build in Murder Row
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### The Blinding Vale

:::talents **Destruction Warlock** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### Voidscar Arena

:::talents **Destruction Warlock** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### Kings' Rest

:::talents **Destruction Warlock** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### Ruby Life Pools

:::talents **Destruction Warlock** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::




### Temple of Sethraliss

:::talents **Destruction Warlock** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CuQAUgGY_myp-zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw",
  "code": "CuQAUgGY/myp+zpUCockSq2z5zMjZGNbmx2MzYWmNzMzsYmZZZMAAYGjZmZxCMwsY0YGAzWsxAAAjBDAAmZwYGjZDAAwMzMDAAzw"
}
```
:::





### Affixes

The Affix system got revamped going into **The War Within Season 1**, retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Destruction Warlock**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[talent:91452]] on as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - Focus all your damage on the **Void Emissary**!
- Xal'atath's Bargain: Devour
  
  - This applies a big heal absorb to you. You can use your **Imp's** [[spell:119905]] to dispel yourself.
- Xal'atath's Bargain: Pulsar
  
  - Collect the orbiting pulsars around other group members!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Destruction Warlock**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Destruction Warlock** Mythic+ Stat Priorities
```json
{
  "source_code": "HoAJFUAJgEDKBEwABA"
}
```
**智力 ＞ 急速 ＞ 暴击 ≥ 精通 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DSRAAsQAnk7cUrDWMWjgCgVA]] | Ula'tek |
| Neck | [[item:268265@BERAAsQA6z6oPrjgCwYNYFA]] | Ula'tek |
| Shoulder | Convert [[item:239031@AgQAAIoAOFA]] into [[item:271544@DgQBAsQAXk7IoAOFwtlO]] | Catalyst of Temple of Sethraliss |
| Cloak | [[item:268253@BgQAAsQACKAWBA]] | The Coiled Altar |
| Chest | [[item:271549@DgQAAsQAJk7E3IOF]] | Vashnik |
| Wrist | [[item:239648@FiQAAsQAno64BwD_sO3WzSB]] | Crafting |
| Gloves | Convert [[item:268243@AgQAAIoAYFA]] into [[item:271547@BgQBAsQACKAWBM9FEA]] | Catalyst of The Coiled Altar |
| Belt | [[item:239649@FiQAAsQAno64BwDDtO3WzSB]] | Crafting |
| Legs | [[item:271545@DgQAAsQAFo6IoAOF]] | Sszorak |
| Boots | [[item:268255@DgQAAsQApk7IoAYF]] | The Coiled Altar |
| Ring 1 | [[item:268252@DiQAAsQA1j7IRrjgC4UA]] | Sszorak |
| Ring 2 | [[item:158366@DiQAAsQA1j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250215@BgQAAsQACKgTBA]] | Murder Row |
| Trinket 2 | [[item:270164@BgQAAsQACKgTBA]] | The Lost Explorers |
| Weapon | [[item:271092@DgQAAsQA_k7IoAYF]] | Ula'tek |
| Offhand | [[item:268197@BgQAAsQACKgTBA]] | Entombed Sentinels |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@BgQAAsQAxNSQBA]] | The Blinding Vale |
| Neck | [[item:251234@BgQAAsQAxNSQBA]] | Voidscar Arena |
| Shoulder | [[item:239031@BgQAAsQAxNSQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAsQA1NSQBA]] | Ruby Life Pools |
| Chest | [[item:239032@BgQAAsQA1NSQBA]] | Temple of Sethraliss |
| Wrist | [[item:251154@BgQAAsQA1NSQBA]] | Den of Nalorakk |
| Gloves | [[item:273773@BgQAAsQA1NSQBA]] | Altar of Fangs |
| Belt | [[item:251222@BgQAAsQA1NSQBA]] | Voidscar Arena |
| Legs | [[item:193750@BgQAAsQA1NSQBA]] | Ruby Life Pools |
| Boots | [[item:159259@BgQAAsQA5NSQBA]] | Temple of Sethralis |
| Ring 1 | [[item:251136@BgQAAsQA1NSQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAsQACKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250215@BgQAAsQACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250214@BgQAAsQA1NSQBA]] | The Blinding Vale |
| Weapon | [[item:160216@BgQAAsQA1NSQBA]] | Kings' Rest |
| Offhand | [[item:273779@BgQAAsQA1NSQBA]] | Altar of Fangs |
| Two-Hand | [[item:193761@BgQAAsQA1NSQBA]] | Ruby Life Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:250215@BgQAAcEACKgTBA]]  <br>[[item:270164@BgQAAcEACKgTBA]]  <br>[[item:270161@BgQAAcEACKgTBA]]  <br>[[item:270167@BgQAAcEACKgTBA]] |
| **A-Tier** | [[item:273796@BgQAAcEACKgTBA]]  <br>[[item:273649@BgQAAcEACKgTBA]]  <br>[[item:270169@BgQAAcEACKAWBA]]  <br>[[item:270168@BgQAAcEACKAWBA]] |
| **B-Tier** | [[item:273794@BgQAAcEACKgTBA]]  <br>[[item:270170@BgQAAcEACKgTBA]]  <br>[[item:250214@BgQAAcEACKgTBA]]  <br>[[item:250259@BgQAAcEACKgTBA]]  <br>[[item:250224@BgQAAcEACKgTBA]] |
| **C-Tier** | [[item:248583@BgQAAcEA0MSQBA]]  <br>[[item:274493@BgQAAcEA0MSQBA]]  <br>[[item:251792@BgQAAcEA0MSQBA]] |
| **Junkyard** | [[item:158368@BgQAAcEACKgTBA]]  <br>[[item:193757@BgQAAcEACKgTBA]] |

### Embellishments

- 1x [[item:245875]]
  
  - Only crafted on your main hand or off-hand weapon. Craft it on your main hand / two hand for more power early on.
- 1x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 2x [[item:240167]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Flasks**
  
  - [[item:241326]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266996]]
  - [[item:242744]]
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241309]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]] *-- default*
  - [[item:243738]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique*
    
    - [[item:240890]]
    - [[item:240898]]
    - [[item:240900]]
    - [[item:240906]]
    - [[item:240914]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAAsQA]]  <br>[[item:244007@BAAAAsQA]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsQA]] |
| Chest | [[item:243977@BAAAAsQA]] |
| Wrist | [[item:275707@BAAAAsQA]] |
| Waist | [[item:275707@BAAAAsQA]] |
| Legs | [[item:240133@BAAAAsQA]] |
| Boots | [[item:244009@BAAAAsQA]] |
| Ring 1 | [[item:243957@BAAAAsQA]] |
| Ring 2 | [[item:243957@BAAAAsQA]] |
| Weapon | [[item:244031@BAAAAsQA]] |

:::

:::column
:::gear **Destruction Warlock** Enchantments in Raids
```json
{
  "source_code": "JQFZLEQ9NCQAnk7ACAAAAsPNEEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYgS94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:244007]] | [[item:275707]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAsQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Destruction Warlock** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:33702]] -- Orc
  
  - Strong racial for damage both because of [[spell:21563]] and [[spell:33702]] which lines up with [[spell:1122]].
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] -- Troll
  
  - Strong DPS racial but lines up poorly with [[talent:91502]].
  - Reduce the duration of movement imparing effects by 20%.

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Destruction Warlock**.

## Macros

Discover recommended macros for **Destruction Warlocks** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:152108]]** -- *Casts [[spell:152108]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Cataclysm
```

**[[spell:1122]]** - *Uses [[spell:1122]] on your cursor position without reticle. Can't be used while [[spell:196447]] is being cast.*

```wow-macro
#showtooltip
/cast [@cursor, nochanneling: Channel Demonfire] Summon Infernal
```

**[[spell:5740]]** -- *Casts [[spell:5740]] without confirmation click which can save you valuable time and increases your Rain of Fire casts per second.*

```wow-macro
#showtooltip
/cast [@cursor] Rain of Fire
```

**[[spell:30283]]** -- *Casts [[spell:30283]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Shadowfury
```

:::

:::details Mouseover Macros
**[[spell:348]]** -- *Casts [[spell:348]] on your mouseover or target.*

```wow-macro
#showtooltip Immolate
/cast [@mouseover,exists] Immolate;Immolate
```

**[[spell:80240]]** -- *Casts [[spell:80240]] on your mouseover target if it exists, isn't dead and is hostile, else Havoc is cast on your target*.

```wow-macro
#showtooltip
/cast [@mouseover,exists,nodead,harm] Havoc;Havoc
```

**[[spell:702]]** -- *Uses* [*wow-spell id=702]Curse of Weakness[/wow-spell] on your mouseover target or target.*

```wow-macro
#showtooltip Curse of Weakness
/cast [known:328774] Amplify Curse
/cast [@mouseover, exists, harm, nodead] Curse of Weakness; Curse of Weakness
```

**[[spell:1714]]** -- *Uses [[spell:1714]] on your mouseover target or target..*

```wow-macro
#showtooltip Curse of Tongues
/cast [known:328774] Amplify Curse
/cast [@mouseover, exists, harm, nodead] Curse of Tongues; Curse of Tongues
```

**[[spell:334275]]** -- *Uses [[spell:29539]] on your mouseover target or target.*

```wow-macro
#showtooltip Curse of Exhaustion
/cast [@mouseover, exists, harm, nodead] Curse of Exhaustion;[@target] Curse of Exhaustion
```

**[[spell:234153]]** -- *Uses [[spell:234153]] on your mouseover target or target.*

```wow-macro
#showtooltip
/cast [@mouseover,exists] Drain Life;Drain Life
```

**[[spell:710]]** -- *Casts [[spell:710]] on your mouseover target if it exists.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] Banish; [harm,nodead] Banish
```

:::

:::details Pet Macros
> We're mainly using custom macros for Pets because the normal functionality of [[spell:119898]] proved unreliable in the past.

**Pet Ability 1 Macro** -- *Casts your main pet abilities for each pet on* your mouseover target.

```wow-macro
/cast [@mouseover]Singe Magic
/cast [@mouseover,exists] Spell Lock;Spell Lock
/cast [@mouseover]Suffering
/cast [@mouseover,exists]Seduce;Seduce
/cast [@mouseover,exists]Axe Toss;Axe Toss
/cast [nopet,@mouseover,exists]Command Demon;[nopet]Command Demon
```

**Focus Pet Ability** **1 Macro** -- *Casts your main pet abilities for each pet on your focus target.*

```wow-macro
/cast [@focus] Singe Magic
/cast [@focus] Spell Lock
/cast [@focus] Suffering
/cast [@focus] Seduce
/cast [@focus] Axe Toss
/cast [nopet,@focus] Command Demon
```

**Pet Ability** **2 Macro** *-- Casts your second relevant pet ability on your mouseover target if needed.*

```wow-macro
/cast [@mouseover] Singe Magic
/cast [@mouseover,exists] Devour Magic;Devour Magic
/cast Shadow Bulwark
/cast Felstorm 
/cast [nopet,@mouseover] Command Demon
```

**Focus Pet Ability** **2 Macro** -- *Casts the second relevant Pet ability on your focus target, and also sends your pet to attack your focus.*

```wow-macro
/cast [@focus]Singe Magic;
/cast [@focus] Devour Magic;
/cast [@focus] Lesser Invisibility;
/cast Shadow Bulwark;
/cast [nopet,@focus] Command Demon
/petattack [@focus]
```

**[[spell:108503]] & dismiss pet** -- *Casts [[spell:108503]] if you specced into it. If you don't have Grimoire of Sacrifice talented it dismisses your pet instead.*

```wow-macro
showtooltip
/run if not IsSpellKnown(108503) then PetDismiss(); end
/cast Grimoire of Sacrifice
```

:::

:::details Utility Macros
**[[spell:20707]]** Mouseover -- *Casts [[spell:20707]] on your mouseover. Conventional [@mouseover,exists] macros got broken a while ago, this is a workaround for it.*

```wow-macro
#showtooltip Soulstone 
/target [@mouseover,help] 
/cast Soulstone 
/targetlasttarget
```

**[[spell:5697]]** Selftcast *-- Casts [[spell:5697]] on yourself without targeting anything. Useful for situations where you're not able to DPS anything to still fish for trinket procs/stacks.*

```wow-macro
#showtooltip
/cast [@player] Unending Breath
```

**[[talent:91457]] / [[spell:5484]]** choice *-- Swaps between [[talent:91457]]* *and [[spell:5484]] depending on which talent got picked. Useful to add your own macro conditions like @focus or @mouseover etc.*

```wow-macro
/cast [known:Shadowfury] Shadowfury
/cast [known:Howl of Terror] Howl of Terror
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Destruction Warlock**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Destruction Warlock Mythic+ User Interface](<https://assets-ng.maxroll.gg/wordpress/xerwomythicplusui-midnight-mxr-1024x617.webp>)

**Destruction Warlock** Mythic+ User Interface

:::accordion
:::details Addons
- **Unhalted Unit Frames** *-- User Interface replacement* 
  
  - Adds custom Player,Target and Bossframes with more customization.
- **BetterCooldownManager** -- CooldownManager enhancement
  
  - Adds extra customization to your cooldownmanager while also providing additional information like resources etc.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring, and support for custom scripting.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **RaidframeSettings** -- Party/Raidframe enhancement
  
  - Adds extra customization to your default party and raidframes.
- **LeatrixPlus** -- QoL and Map addon
  
  - Adds lots of quality of life options as well as a smoother mini map, among other things.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Warlock
  
  - Drain Life health drain increased by 25%.
  - Zevrim's Resilience healing increased by 25%.
  - Summon Demonic Gateway is now a Utility spell by default in the Cooldown Manager.
  - Fixed an issue where several abilities would not grant Soul Leech:Wither
    
    - Blackened Soul
    - Infernal Bolt
    - Soul Anathema
    - Wicked Reaping
    - Avatar of Destruction’s Chaos Bolt
    - Unstable Affliction
    - Malefic Grasp
    - Vilefiend’s Headbutt and Bile Spit
    - Gloomhound’s Gloom Slash
    - Wild Imp and Imp Gang Boss’s Fel Firebolt
    - Imp Lord’s Greater Felbolt
    - Demonic Tyrant’s Demonfire
  - Fixed an issue where several abilities erroneously granted Soul Leech:Legion Strike
    
    - Cunning Cruelty
    - Channel Demonfire
  - Hero Talents
    
    - **[[talent:123382]]**
      
      - *Developers' notes: We're updating Blackened Soul to give Hellcaller a better tool for focusing damage into a priority target, increasing the overall flexibility of the hero talent tree rather than have it only excel in situations where multiple targets are present. However, we are keeping the functionality of Malevolence the same, so it remains a cool and impactful tool in Hellcaller's toolkit.*
      - Blackened Soul has been redesigned – If the target is afflicted with your Wither, your Chaos Bolt and Shadowburn increase its stack count by 1. Each time Wither gains a stack it has a chance to collapse, consuming a stack every 1 second to deal Shadowflame damage to its host until 1 stack remains. Blackened Soul damage increased by 45%.
      - Mark of Peroth'arn has been redesigned – Damaging critical strikes dealt by Wither deal 215% damage instead of the usual 200%. Damaging critical strikes dealt by Blackened Soul deal 225% damage instead of the usual 200%.
      - Wither damage increased by 25%.
  - Affliction
    
    - New Talent: Hedonic Gorging – Increases Drain Life damage by 10% and Siphon Life now increases the damage of Corruption by an additional 10%. Dark Harvest channels 10% faster and deals 15% increased damage.
    - New Talent: Impetuous Wrath – Shadow Bolt, Drain Soul, and Malefic Grasp damage increased by 10% or 20% if the target is affected by Haunt. Dark Harvest damage increased by 10% or 20% if the target is affected by Haunt.
    - Shard Instability has been redesigned – Damage dealt by Shadow Bolt or Drain Soul has a 20% chance to make your next Unstable Affliction or Seed of Corruption cost no Soul Shards and cast instantly.
    - Haunt now increases your damage dealt to the target by 16% for 18 seconds (was 12%).
    - The following talents have been removed:Nocturnal Yield
      
      - Developers' notes: Nocturnal Yield doesn’t offer much choice when it comes to how a Warlock chooses to spend their Nightfall. Instead, it is usually best spent on Seed of Corruption, regardless of target count. This can have adverse effects on talents that benefit from Shadow Bolt or Drain Soul. We like the feeling of occasional free Seeds of Corruption though and are merging that functionality into Shard Instability. In place of Nocturnal Yield, we are introducing a new talent called Impetuous Wrath that will serve as another means of Affliction accessing additional priority damage.
    - Patient Zero
      
      - Developers' notes: Patient Zero warps the damage profile of Seed of Corruption heavily. The specific use-case for Seed of Corruption as a tool is to supply damage in multi-target situations and having the ability to increase priority damage dilutes its identity. Hedonic Gorging is a new talent that hooks into the common throughline of health leech between Drain Life, Siphon Life, and Dark Harvest. The intention for this talent is for most of the throughput to reside in Siphon Life and Dark Harvest while the increase to Drain Life is meant to be smaller and a bit of flavor.
  - Demonology
    
    - Shadow Bolt damage increased by 45%.
    - Demonbolt damage increased by 55%.
    - Summon Gloomhound damage increased by 35%.
    - **Hero Talents**
      
      - **[[talent:123385]]**
        
        - Chaos Salvo damage reduced by 20%.
        - Felseeker damage reduced by 20%.
        - Wicked Cleave damage reduced by 20%.
        - Eye Explosion damage reduced by 20%.
        - Flames of Xoroth now increases Fire damage and damage dealt by your demons by 3% (was 4%).
  - Destruction
    
    - Conflagration of Chaos has been redesigned – Conflagrate and Shadowburn have a 100% chance to critically strike, and their damage is increased by your critical strike chance.
    - All damage increased by 4.5%.
    - Soul Fire damage increased by 45%.
    - Chaos Bolt damage increased by 5%.
    - Havoc now causes spells to deal 50% of their damage to the marked target (was 60%).
    - Apex Talent: Embers of Nihilam (Rank 1) tooltip has been updated to show players the percent chance of Incinerate evoking an Echo of Sargeras.
    - Shadowburn added as a tracked buff in the Cooldown Manager.
    - Conflagration of Chaos has been removed from the Cooldown Manager.

:::

:::details Patch 12.0.1
- Warlock
  
  - Hero Talents
    
    - [[talent:123385]]
      
      - [[spell:434506]] damage increased by 150%.
      - [[spell:434635]] damage increased by 50%. This change does not affect PvP combat.
    - [[talent:123382]]
      
      - [[spell:442726]] damage increased by 230%.
      - Destruction
        
        - [[talent:117434]] damage increased by 20%.
        - [[talent:117437@FAQAWdhA]] damage increased by 25%.
        - [[talent:136095]] now increases [[talent:136835]] damage by 10% (was 8%) and [[talent:91592]] damage by 8% (was 4%).
  
  
  
  - Destruction
    
    - [[spell:29722]] damage increased by 50%.
    - [[talent:91591]] damage increased by 40%. This change does not affect PvP combat.
    - [[talent:136835]] damage increased by 10%. This change does not affect PvP combat.
    - [[spell:434587]] damage increased by 50%.
    - [[talent:134221@FAQAZwsB]] damage increased by 40%.

:::

:::details Patch 12.0
- Warlock
  
  - Hero Talents
    
    - **[[talent:123385]]**
      
      - New Talent: [[talent:136092]] – You summon a Diabolic Oculus, up to 3, each time the duration of [[talent:117452]] is reduced by one of your spells. [[talent:136092]] explode when consuming Demonic Art, dealing Fire damage to all enemies within 8 yards of the target. Damage reduced beyond 8 targets.
      - New Talent: [[talent:136091]] – Your [[talent:136092]] now cast Diabolic Gaze at your primary's target every 1 second while active.
      - New Talent: [[talent:136090]] – Your [[talent:136092]] observe the battlefield and collect information that is imparted to you upon being exploded, each [[talent:136092]] increasing your Intellect by 2% for 10 seconds.
      - [[talent:117453]] now increases the damage of [[talent:136835]], [[talent:91592]], or [[talent:91582]] by 20% (was 100%).
      - Eye Explosion damage reduced by 30%. This change does not affect PvP combat.
    - **[[talent:123382]]**
      
      - New Talent: [[talent:136095]]
        
        - Destruction: Increases the damage of [[talent:136835]] by 8% and [[talent:91592]] by 4%. This effect is doubled while [[spell:442726]] is active.
    - New Talent: [[talent:136094]] – Periodic damage dealt by [[talent:117437@FAQAWdhA]] has a chance to grant [[spell:442726]] for 8 seconds.
    - New Talent: [[talent:136093]] – [[spell:442726]] grants an additional 4% Haste and when cast increases the stack count of active [[talent:117437@FAQAWdhA]] by an additional 2 stacks.
    - [[talent:117434]] damage increased by 30%.
    - [[talent:117437@FAQAWdhA]] damage increased by 20%.
  
  
  
  - Class
    
    - New Talent: [[talent:136107]] – Reduces the target's movement speed by 50% for 12 seconds.
    - New Talent: [[talent:136106]] – Forces the target to speak in Demonic, increasing the casting time of all spells by 30% for 1 minute.
    - New Talent: [[talent:136108]] – Call forth a cloud of cloying shadow mist that envelopes the target and all enemies within 10 yards, increasing the time between their attacks by 100% and reducing their critical strike chance by 10% for 12 seconds.
    - New Talent: [[talent:136738]] – Call forth a cloud of cloying shadow mist that envelopes the target and all enemies within 10 yards, increasing their casting time of all spells by 100% for 12 seconds.
    - New Talent: [[talent:136105]] – Increases the range of [[talent:91452]] by 10 yards and the amount it heals by 5%.
    - New Talent: [[talent:136104]] – Healing done by [[spell:234153]] also heals your primary demon at 400% effectiveness.
    - New Talent: [[talent:136100]] – Casting [[talent:136107]], [[talent:136106]], or [[spell:702]] now curses all enemies within 10 yards of the target.
    - New Talent: Shared Vitality – Healing done by Drain Life also heals your primary demon at 100% effectiveness.
      
      - Author Note: This talent doesn't exist anymore.
    - New Talent: [[talent:91431]] – [[spell:234153]] now channels 50%/100% faster and restores health 50%/100% faster.
      
      - Author Note: This talent is 1 point node. [[spell:234153]] always channels 100% faster if talented.
    - New Talent: [[talent:136101]] – Reduces the cast time of [[talent:91466]] by 0.5 seconds and you can now use [[talent:91466]] twice before triggering a cooldown.
    - New Talent: [[talent:136569]] – Increases your Haste by 3%.
    - New Talent: [[talent:136568]] – Increases your Critical Strike chance by 2%.
    - New Talent: [[talent:136570]] – Increases your Leech by 2%.
    - New Talent: [[talent:136103]] – Increases Intellect by 3%.
    - New Talent: [[talent:136572]] – [[spell:6262]] restore 5% additional health.
    - New Talent: [[talent:136573]] – [[spell:234153]] now heals for 700% of damage dealt and now grants [[talent:91441@FAQAIi1A]] equal to 10% of damage dealt.
      
      - Author Note: [[spell:234153]] only heals for 200% of the damage dealtt.
    - New Talent: [[talent:136571]]– [[talent:91441@FAQAIi1A]] now grants shields up to 15% of your maximum health.
      
      - Author Note: It's 5%.
    - New Talent: [[talent:91451]] – Reduces the cooldown of [[talent:91457]] by 15 seconds and increases its radius by 2 yards. Reduces the cooldown of [[talent:91458]] by 10 seconds and it now fears 5 additional enemies.
      
      - Author Note: [[talent:91458]] cooldown is reduced by only 5 seconds.
    - Many talents have changed positions in the talent tree.
    - New starter builds have been implemented for all 3 specializations.
    - The following talents have been removed:
      
      - [[spell:339282]]
      - [[spell:328774]]
      - [[spell:386105]]
      - [[spell:264874]]
      - [[spell:386858]]
      - [[spell:452894]]
      - [[spell:274419]]
      - [[spell:1269991]]
      - [[spell:1270032]]
      - [[spell:405936]]
      - [[spell:215941]]
      - [[spell:405955]]
      - [[spell:387972]]
      - [[spell:386864]]
  - Destruction
    
    - New Talent: [[spell:1244266]] – Increases Intellect by 2%.
      
      - Author's Note: Talent doesn't exist anymore.
    - New Talent: [[talent:134219]] – Increases Mastery by 2%.
    - New Talent: [[talent:91474]] – Increases the duration of [[talent:91493]] by 5 seconds and increases the damage [[talent:91493]] victims are dealt by an additional 10%.
    - New Talent: [[talent:126493@FAQAZwsB]] – [[spell:152108]] now leaves behind a [[talent:126493@FAQAZwsB]] that deals Fire damage to enemies within it over 8 seconds. [[spell:348]]/[[talent:117437@FAQAWdhA]] deals 20% increased damage to enemies within the [[talent:126493@FAQAZwsB]].
    - New Talent: [[talent:91583]] – Increases [[talent:136835]] damage by 5% and [[talent:136835]] now has a 25% chance to make your next [[spell:29722]] instant.
    - New Talent: [[talent:91477]] – Increases how quickly [[talent:91592]] deals damage by 25%/50% and how quickly your Infernal's Immolation deals damage by 10%/20%.
    - New Talent: [[talent:91423]] – [[talent:91592]] has a 20% chance to reduce the cost of your next [[talent:91592]] within 8 seconds by 100%.
    - New Talent: [[talent:91489]] – Reduces the cooldown of [[talent:91502]] by 30 seconds and increases your Mastery by 3%.
    - New Talent: [[talent:126003@FAQAZwsB]] – [[talent:128599@FAQAZwsB]] fires an additional 2 bolts. Each bolt increases the remaining duration of [[spell:348]] on all targets hit by 0.5 seconds.
    - New Talent: [[talent:136834]] – Increases the critical strike chance of your Destruction spells by 3%/6%.
    - [[talent:91588]] has been redesigned – Increases [[talent:91591@FAQA28vA]] damage by 10%. [[talent:91591@FAQA28vA]] now erupts the target's [[spell:348]], spreading it up to 3 nearby enemies.
    - [[talent:91582]] has been redesigned – Blasts a target for Shadowflame damage. Only usable on enemies that have less than 20% health. Restores 1 Soul Shard[[spell:246985]] if the target dies within 5 seconds. Costs 1 [[spell:246985]]. No cooldown. Instant.
    - [[talent:91582]] damage increased by 100%.
    - [[talent:126004]] has been redesigned – Critical strikes dealt by [[talent:136835]], [[talent:91591@FAQA28vA]], or [[spell:29722]] have a 10% chance to make your next cast of [[talent:91582]] within 30 seconds cost no [[spell:246985]] and usable on any target regardless of health.
    - [[talent:136833]] has been redesigned – Casting [[talent:134221@FAQAZwsB]] summons an Overfiend. Opening a [[talent:128600]] has a chance to summon an Overfiend instead.
      
      - Summon Overfiend: Generates 1 Soul Shard Fragment every 1 second and casts [[talent:136835]] at 60% effectiveness at its summoner's target. Lasts 8 seconds.
    - [[talent:128600]] is now passive and has been redesigned – [[talent:136835]] and [[talent:91582]] have a 10% chance to rip open a hole in space and time, opening a random portal that damages your target.
    - [[talent:91589]] has been updated – Increases the critical strike damage of your Destruction spells by 15%/30%.
    - [[talent:136835]] has been added to the Destruction talent tree (was learned at level 10).
    - [[talent:136835]] damage reduced by 18%. This change does not affect PvP combat.
    - [[talent:91591@FAQA28vA]] damage reduced by 22%. This change does not affect PvP combat.
    - [[spell:29722]] damage reduced by 10%. This change does not affect PvP combat.
    - Overfiend damage increased by 30%.
    - [[talent:134221@FAQAZwsB]] damage increased by 400% and cast time is now 3 seconds (was 4 seconds).
    - [[talent:91500]] is now a 2-point talent that increases your critical strike chance by 2%/4%. Physical attacks against you have a 20%/40% chance to make your next [[spell:29722]] Instant cast. This effect can only occur once every 6 seconds.
    - [[talent:91482@FAQAZwsB]] is now a 2-point talent that causes [[talent:136835]], [[talent:91582]], and [[spell:29722]] to deal 3%/6% increased damage to targets afflicted by [[spell:348]]/[[talent:117437@FAQAWdhA]].
    - Many talents have changed positions in the talent tree.
    - The following talents have been removed:
      
      - [[spell:456939]]
      - [[spell:387153]]
      - [[spell:456985]]
      - [[spell:456946]]
      - [[spell:457025]]
      - [[spell:457114]]
      - [[spell:387165]]
      - [[spell:387279]]
      - [[spell:387095]]
      - [[spell:364433]]
      - [[spell:387569]]

:::

:::

## FAQ

:::accordion
:::details Q: Which Pet do i use?
**A:** Use [[spell:691]] for most situations. If you don't need [[spell:132409]] or  [[spell:388215]], use [[spell:688]] for [[spell:212623]] instead.

:::

:::details Q: When do i use [[talent:91494]] over [[talent:91493]]?
**A:** Use [[talent:91493]] when it's beneficial to have [[talent:91493]] at an exact moment in the dungeon. [[talent:91494]] for more overall damage potential.

:::

:::

---

### Credits

Written By: Xerwo  
  
Reviewed By: **Rycn**

:::changelog 更新记录
**2026-07-31** Updated for patch 12.1

**2026-06-19** Updated for patch 12.0.7.

**2026-04-22** Updated for patch 12.0.5.

**2026-04-02** Updated talent setups and embellishments.

**2026-02-05** Updated for patch 12.0.1.

**2026-01-17** Updated for patch 12.0.

**2025-12-02** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-09-07** Fixed talent spec suggestions and explanation.

**2025-07-30** Updated for patch 11.2

**2025-06-16** Updated for patch 11.1.7.

**2025-05-20** Updated for corruptions and turbo boost.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-07** Updated for patch 11.1.

**2024-12-11** Updated for patch 11.0.7.

**2024-10-23** Updated for patch 11.0.5.

**2024-10-07** Updated for Season 1.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
