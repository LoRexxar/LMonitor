Welcome to the **Shadow Priest** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 3/5 · Strong

AoE · 4/5 · Strong

Utility · 2/5 · Weak

Survivability · 2/5 · Average

Mobility · 1/5 · Subpar



:::

:::

:::column
:::gear **Shadow Priest** Raid Best in Slot
```json
{
  "source_code": "IsfAwjlABc__BEgAmQggQEAAnk7A8z6A5IgF2gVABk-FEAIEBAwVtOQOCwYNYFQABTCBCgQAAcRuDkjAOFQAGTCBCgQAAkQuDkjAOFQAwg6AAiQAAwPrDcbNLFQACngHIUgqDUQLE89FFwDAp0APMACqDQYALxAwDYiqBMXBzgBxkQAAIEAAFADIcfBBCiQAAUPuB4RBSAQ2CJBAccW0DAACBAggB4HBU9RG8QQ3XkBDcQvIEIAEBAQBBgHAXEg1oU6FEAACBAQOC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240892]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] |
| 肩部 | [[item:271553]] | [[item:243991]] |
| 胸部 | [[item:271558]] | [[item:243977]] |
| 腰部 | [[item:239664]] | [[item:240892]] |
| 腿部 | [[item:271554]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:244009]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:245783]] · [[item:240166]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:268252]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:250215]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Shadow Priest**, you have access to **Void Apparitions**, which conjures [[talent:103792]] on an **Idol** activation.

**Rank 2** gives a 15/30% chance for your [[talent:103792]] to become [[spell:1264104]], increasing its damage done by 50% and releasing a [[spell:1264177]].

While **Rank 3** gives your [[talent:115448]] 100% chance to activate an effect of one of your **Idols**.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/imagzqde.png>)

Void Apparitions

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115448]]
    
    - Replaces the old Shadow Crash, requires a target to be casted and dots targets between you and the target casted on, on top of an area around it.
  - [[talent:103674]]
    
    - Now has [[spell:1240401]] instead of [[spell:1264177]] as a replacement spell throughout its duration.
    - The duration of [[talent:103674]] can't be extended anymore.
  
  
  
  - [[talent:103799]]
    
    - Our new way to extend our DoTs on targets. On few target count, it won't be enough to extend your DoTs and you'll be required to do it manually.
  - [[spell:120644]]/[[spell:263165]]
    
    - They have been removed from the class and spec tree and baked into hero talents.
- **Removed**
  
  - [[spell:391109]]
    
    - The removal of it leaves us only with [[talent:103674]] as our main cooldown.
  
  
  
  - [[spell:132603]]
    
    - Our pets in general have been baked into passives that trigger on execute or on cooldown presses.

## Hero Talents



### [[talent:123289]]

[[talent:123289]] grants you the [[talent:117300@FAQAJdhA]] ability that combined with [[talent:117284]] creates a total of three halos that further synergise with some of the hero talents.

- [[talent:117302@FAQAJdhA]] grants you [[spell:391403]] for every [[talent:117300@FAQAJdhA]].
- [[talent:117279@FAQAJdhA]] increases the damage taken by targets hit by [[talent:117300@FAQAJdhA]].
- [[talent:125085]] extends the duration of your [[talent:103674]] if active or stores up to 6 extra seconds for the next one.




### [[talent:123287]]

[[talent:123287]] grants you the [[talent:117287@AJQBCA]] ability that summons an [[spell:447444]] that does damage around your target, this rift explodes at the end of its duration doing damage to enemies in it and it has further synergies with some of the hero talents.

- [[spell:447444]] transforms your [[spell:8092]] into [[talent:117306]], making it do more damage and generate more insanity.
- Each [[talent:103808]] you cast empowers your rift's size and damage by 20%.
- [[talent:123845@AJQBCA]] allows you to use [[talent:117287@AJQBCA]] while moving.
- [[talent:103864@FJQAJdhAFIA]] does significantly more damage with [[talent:117271@FJQAJdhAFIA]].





## Talents



### [[talent:123289]]

:::talents [[talent:123289]] **Shadow Priest** Raid Build
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### When to use this Spec

This is your generic talent page that works in most situations.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:115448]]
  
  - Applies [[spell:34914]] to up to 6 targets and has two charges.
- [[talent:103809]] or [[talent:136811]]
  
  - Important choice node deciding between ease of play or throughput.
- [[talent:103806]]
  
  - The main way to do AoE damage as a shadow priest combined with the DoTs themselves.
- [[talent:103792]]
  
  - Another source of sustained damage synergizing with many other talents in the tree.
- [[talent:103786]] or [[talent:115671]]
  
  - Important talent choice as it changes the cost of your [[talent:103808]].
- [[talent:103782]], [[talent:103817]], [[talent:103781]] and [[talent:103787]]
  
  - Although mainly passive, it is important to acknowledge all your idol talents as they will synergize with your Apex Talents.

##### Class Tree

- [[talent:103833]]
  
  - Important part of priest's execute phase, maximizing it's uptime is a significant part of getting the most out of the spec.
- [[talent:103819]]
  
  - Increases the range of most of your spells.
- [[talent:103834]]
  
  - Your two minute cooldown that you always combine with [[talent:103674]]
  
  
  
  - [[talent:134284]] allows you to [[talent:103834]] someone else and still get the full value of it yourself so having a good macro for it is important.
- [[talent:103864]]
  
  - Your execute button. It can be used any time as a filler spell when moving.
- [[talent:134849]] with [[talent:103835]] and [[talent:134846@FAQAKLbB]]
  
  - Two strong defensive abilities.




### [[talent:123287]]

:::talents [[talent:123287]] **Shadow Priest** Raid Build
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMjZGAAAAAAAAAAAAMLmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMjZGAAAAAAAAAAAAMLmxMbzMMz2MzYG2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB"
}
```
:::

#### When to use this Spec

Use this spec if you like to play [[talent:123287]] over [[talent:123289]], [[talent:123287]] also shines in stacked AoE.

##### Hero Talents

Changed [[talent:123289]] to [[talent:123287]] for more info visit the **Hero Talent** section above.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:115448]]'s cooldown is reduced by 3 seconds and its damage is increased by 100%.
- **4-Set:** ‍[[talent:115448]] has a 100% chance to grant a free use of  [[spell:1242189]] at 100% effectiveness.

### Single-Target



#### [[talent:123289]]

##### Opener

- Your goal of your opener is to spend all charges and use all of your relevant abilities as efficiently as possible without overcaping your **Insanity**.
- Below you can find an example of how your opener should look like:

:::rotation [[talent:123289]] **Shadow Priest** Single-Target opener in Raid
```json
{
  "source_code": "J0GEKIEnfAQABwgQQorEFgABNJQAHwAAC1D9JABCEddABEBCCls9BkBQEIETnAAAAIkpDCAAAEAiuOQAcwTAnF9AAgQAAIoAOFgQr5RBBQBDC1D9SUACow5HAAAAAAgQrjfB"
}
```
1. [[spell:8092]]
2. [[spell:1227280]]
3. [[spell:589]]
4. [[spell:1242173]]
5. [[spell:120644]]
6. [[spell:194249]]  [[spell:10060]] · [[spell:33702]] · [[item:241288]] · [[item:250215]]
7. [[spell:335467]]
8. [[spell:1242173]]
9. [[spell:8092]]
10. [[spell:391403]]
:::

- Use your active trinkets, [[item:241308]], [[talent:103834]] and racials like [[spell:20572]] or [[spell:26297]] after using [[talent:103674]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:34914]] and [[spell:589]] on your target.
   
   - You can keep it through [[talent:115448]], extend it through [[talent:103799]] or apply it manually.
2. Cast [[spell:120644]]
3. Cast [[talent:103674]]
4. Cast [[talent:103834]]
5. Keep up [[talent:103808]] on the target.
6. Cast [[spell:1242173]]
7. Cast [[spell:32379]] if the target is below 20%
8. Cast [[spell:8092]]
9. Cast [[spell:391403]]
10. Cast [[spell:15407]]




#### [[talent:123287]]

##### Opener

- Your goal of your opener is to spend all charges and use all of your relevant abilities as efficiently as possible without overcaping your **Insanity**.
- Below you can find an example of how your opener should look like:

:::rotation [[talent:123287]] **Shadow Priest** Single-Target opener in Mythic+
```json
{
  "source_code": "JUHELIEnfAQABwgQQorEFgABNJQAHABAC1_AEEQCMI0phbQBIgwaeUQBIEBEE0D9JADBJbfAxAEBCx0JAAAACZ6gAAAABgorDEALcFwZRPAAIEAACKgTBIUP0LBAAAAACtmHFA"
}
```
1. [[spell:8092]]
2. [[spell:1227280]]
3. [[spell:589]]
4. [[spell:263165]]
5. [[spell:450983]]
6. [[spell:335467]]
7. [[spell:450983]]
8. [[spell:1242173]]
9. [[spell:194249]]  [[spell:10060]] · [[spell:33702]] · [[item:241288]] · [[item:250215]]
10. [[spell:1242173]]
11. [[spell:335467]]
:::

- Use your active trinkets, [[item:241308]], [[talent:103834]] and racials like [[spell:20572]] or [[spell:26297]] after using [[talent:103674]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Keep up [[spell:34914]] and [[spell:589]] on your target.
   
   - You can keep it through [[talent:115448]], extend it through [[talent:103799]] or apply it manually.
2. Cast [[talent:103674]]
3. Cast [[talent:103834]]
4. Keep up [[talent:103808]] on the target.
5. Cast [[spell:1242173]]
6. Cast [[spell:450983]]
7. Cast [[spell:32379]] if the target is below 20%
8. Cast [[talent:117287@AJQBCA]]
9. Cast [[spell:8092]]
10. Cast [[spell:15407]]





### AoE

As a **Shadow Priest**, the majority of our AoE consists of your DoTs damage and [[talent:103806]], therefore your Single-Target rotation is your AoE rotation.

- Your number one priority is to keep your [[spell:34914]] on any target that you want to significantly damage.
  
  - This also gives you flexibility on which target you want your throughput directed.
- When playing [[talent:136811]], you have to made decisions on how many and which targets you want to use [[spell:589]] as you want a balance between DoTing the important targets but also starting to do your damage through [[talent:103806]].

## Deep Dive

### Mastery: Shadow Weaving and Shadow Word: Madness

The **Shadow Priest's** mastery is very important to play around. It makes it so that every DoT you have on the target increases your damage done by your mastery %, which makes your mastery management vital. [[spell:34914]] and [[spell:589]] are up on the target nearly 100% of the time, this leaves you with the task of maintaining [[talent:103808]] on the target. Having as high uptime as possible on [[talent:103808]] is crucial to dealing the highest possible damage. During your [[talent:103674]] you gain the maximum effect of your mastery no matter the DoTs on the target.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Shadow Priest** Nek'Zali talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.




### Entombed Sentinels

:::talents **Shadow Priest** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Important to know that [[spell:1284434]] may also spawn on the opposite boss, so try not to stand between them and be careful whenever [[spell:1284434]] spawn.
- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].




### Lost Explorers

:::talents **Shadow Priest** Lost Explorers talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Pay attention to [[spell:1296062]] casts to have an easier time dodging them.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed after being used once.




### Vashnik

:::talents **Shadow Priest** Vashnik talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.




### Sszorak

:::talents **Shadow Priest** Sszorak talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDzAAAAAAAAAAAAwMLmxMbzMGz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Very important to keep an eye on the [[spell:1305959]] timer and, whenever it's close, scan the platform ahead of time to see where you will need to place it.
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.




### Twin Fangs

:::talents **Shadow Priest** Twin Fangs talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.




### Coiled Altar

:::talents **Shadow Priest** Coiled Altar talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].




### Ula'tek

:::talents **Shadow Priest** Ula'tek talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::




### Nymrissa Wavecaller

:::talents **Shadow Priest** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CKQA14bH_XF5B_Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG",
  "code": "CKQA14bH/XF5B/Zp2PVV69Qa7OMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDG"
}
```
:::

#### Boss Tips

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle.
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid as a  **Shadow Priest**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Shadow Priest** Raid Stat Priorities
```json
{
  "source_code": "IoAJFUQMkACKBIQABA"
}
```
**智力 ＞ 精通 ＝ 急速 ＞ 暴击 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DCRAAIQAnk7wPrTOCYhNYFA]] | Ula'tek |
| Neck | [[item:268265@BCRAAIQAX16kjAMWDWB]] | Ula'tek |
| Shoulder | [[item:271553@DgQAAIQAXk7kjAOF]] | The Lost Explorers or Catalyst |
| Cloak | [[item:268253@BgQAAIQA5IgTBA]] | The Coiled Altar |
| Chest | [[item:271558@DgQAAIQAJk7kjAOF]] | Vashnik or Catalyst |
| Wrist | [[item:239648@FiQAAIQAXA8YiqD_sO3WzSB]] | Crafting |
| Gloves | [[item:271556@BgQAAIQA5IgTBA]] | Entombed Sentinels or Catalyst |
| Belt | [[item:239664@BiQAAIQA8z6cbNLF]] | Crafting |
| Legs | [[item:271554@DgQAAIQAFo6kjAOF]] | Sszorak or Catalyst |
| Boots | [[item:268255@DgQAAIQApk7kjAOF]] | The Coiled Altar |
| Ring 1 | [[item:268252@DiQAAIQA1j7wPrTOC4UA]] | Sszorak |
| Ring 2 | [[item:268249@DiQAAIQA1j7wPrTOC4UA]] | Vashnik |
| Trinket 1 | [[item:250215@BgQAAIQACKgTBA]] | Murder Row |
| Trinket 2 | [[item:270164@BgQAAIQA5IgTBA]] | The Lost Explorers |
| Main Hand | [[item:271092@DARAAIQAFk7kjAXYDWB]] | Ula'tek |
| Off Hand | [[item:268197@BgQAAIQA5IgTBA]] | Entombed Sentinels |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@AgQAAIoABFA]] | The Blinding Vale |
| Neck | [[item:251142@AgQAAIoABFA]] | Murder Row |
| Shoulder | [[item:271553@AgQAAkjABFA]] | Tier / Catalyst |
| Cloak | [[item:251190@AgQAAIoABFA]] | The Blinding Vale |
| Chest | [[item:271558@AgQAAkjABFA]] | Tier / Catalyst |
| Wrist | [[item:239648@FiQAAIQAXA8YiqD_sO3WzSB]] | Crafting |
| Gloves | [[item:271556@AgQAAIoABFA]] | Tier / Catalyst |
| Belt | [[item:239664@BiQAAIQA8z6cbNLF]] | Crafting |
| Legs | [[item:271554@AgQAAkjABFA]] | Tier / Catalyst |
| Boots | [[item:251137@AgQAAIoABFA]] | Murder Row |
| Ring 1 | [[item:251136@AgQAAIoABFA]] | Murder Row |
| Ring 2 | [[item:252258@AgQAAIoABFA]] | Voidscar Arena |
| Trinket 1 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Trinket 2 | [[item:250224@AgQAAIoABFA]] | Voidscar Arena |
| Main Hand | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off Hand | [[item:251191@AgQAAIoABFA]] | The Blinding Vale |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:250215@BgQAAIQACKgTBA]]  <br>[[item:270164@BgQAAIQA5IgTBA]]  <br>[[item:273796@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270170@AgQAAkjAOFA]]  <br>[[item:250214@AgQAAIoABFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAkjAYFA]] |
| **B-Tier** | [[item:270161@AgQAAkjAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C-Tier** | [[item:251792@AAQAAEUA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:273794@AgQAAIoAOFA]]  <br>[[item:251785@AAQAAEUA]] |
| **Junkyard** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:158368@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |

### Embellishments

- 1x [[item:245875]]
  
  - Only crafted on your main hand or off-hand weapon. Craft it on your main hand for more power early on or on your off-hand for long-term BiS.
- 1x [[item:240166]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 2x [[item:240166]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak**, **Boots** or **Waist** depending on your available gear.

or

- 1x [[item:240166]]
  
  - The optimal slots to craft on are **Wrists**, **Cloak** or **Boots** depending on your available gear.
- [[item:239664]]

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266996]]
  - [[item:242744]]
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241288]]
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon Oil
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique*
    
    - [[item:240892]]
    - [[item:240900]]
    - [[item:240906]]

### Enchantments

:::columns
:::column
| Head | [[item:244007]]  <br>[[item:275707@BAAAAIQA]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAIQA]] |
| Waist | [[item:275707@BAAAAIQA]] |
| Legs | [[item:240133]] |
| Boots | [[item:244009]] |
| Ring 1 | [[item:243957@BAAAAIQA]] |
| Ring 2 | [[item:243957@BAAAAIQA]] |
| Weapon | [[item:243973]] |

:::

:::column
:::gear **Shadow Priest** Enchantments in Raid
```json
{
  "source_code": "JQFWCEQ5NDQA7TDBCAAAAcSuDEwF5OAAAAQBTUACEUgqJABApoDGAQQ94mAGRgAKJk7AAAAAAEQB5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 背部 | [[item:243977]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAIQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Shadow Priest** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:274738]] *-- Mag'har Orc* 
  
  - Strong racial for damage because of [[spell:274738]] which lines up with [[talent:103674]].
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.

:::columns
:::column


:::

:::

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the latest Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Shadow Priests** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:32375]] -- *Casts [[spell:32375]] on your cursor without confirmation.***

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

:::

:::details Mouseover Macros
**[[spell:34914]]** -- *Casts [[spell:34914]] on your mouseover or target.*

```wow-macro
#showtooltip 
/cast [@mouseover,exists] [] Vampiric Touch
```

**[[spell:213634]]** -- *Casts[[spell:213634]] on your mouseover or target.*

```wow-macro
#showtooltip 
/cast [@mouseover,exists] [] Purify Disease
```

:::

:::details Utility Macros
**Angelic Feather on player - *Uses your [[spell:121536]]* on your feet.**

```wow-macro
#showtooltip
/cast [@player] Angelic Feather
```

**Cancelaura *[[spell:47585]]* - *Cancels your [[spell:47585]]* without having to wait a gcd.**

```wow-macro
#showtooltip Dispersion
/cast Dispersion
/cancelaura Dispersion
```

**This macro prevents you from cancelling your Void Torrent if accidentally press it twice**

```wow-macro
#showtooltip
/stopmacro [channeling:Void Torrent]
/cast [known:Void Torrent] Void Torrent
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Shadow Priest**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/WoWSqnopnonononononcrnShot_022626_165503-1024x614.png>)

**Shadow Priest** Interface in Raids

:::accordion
:::details Addons
- **HealthBarColo *-- Player, Target and Focus Frame replacement*** 
  
  - Adds custom Player, Target and Focus frames with options to remove secondary recourses.
- **BetterCooldownManager** -- CooldownManager enhancement
  
  - Adds extra customization to your cooldown manager while also providing additional information like resources etc.
- **UnhaltedUnitFrames** -- User Interface Replacement
  
  - Adds custom Boss frames with more customization.
- **BigWigs** -- Generic Boss Mod
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat colouring, and support for custom scripting.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **Quartz** -- Cast Bars replacement
  
  - Adds custom Cast Bars with more customization.

:::

:::

## Changes this Patch

:::accordion
:::details **Patch 12.**1
- *Developers' notes: For Shadow in Curses of Ula'tek, we're intending to improve Voidform gameplay and are adding an additional source of multi-target damage to reduce the spec's reliance on Psychic Link in AoE situations. For Voidform, we're updating Void Volley to be a limited use ability that can be used a set number of times during Voidform which leaves more room in the rotation while giving you the chance to use it at its most opportune moment. We've also updated Voidform support talents to have more noticeable effects to align with our goals.*
- New Talent: Shadeburst – Shadowy Apparitions that float towards your primary target explode, dealing Shadow damage to all enemies within 8 yards. Damage reduced beyond 5 targets.
- Improved Voidform has been redesigned – Voidform increases your spell damage by an additional 5% and grants 2 additional uses of Void Volley.
- Ancient Madness has been redesigned – Shadow Word: Madness increases your Haste during Voidform by 2% and increases its duration by 1.5 seconds, stacking up to 5 times. When Voidform ends, the Haste lingers and decays over 10 seconds.
- All ability damage done increased by 8%.
- Void Volley damage reduced by 10%.
- Voidform now grants 3 uses of Void Volley instead of Void Volley having a cooldown during Voidform.
- Power Word: Shield absorb increased by 25%.
- Idol of N'Zoth now generates 2 Insanity (was 4) at 50 stacks and 6 Insanity (was 12) at 100 stacks.
  
  - *Developers' notes: Insanity generation from this talent has been high relative to other passive sources, and we've been feeling there's too much Insanity being generated overall to where it can become difficult to spend Insanity and keep up with rotational procs. We're bringing the Insanity generation of this talent down to help balance the Insanity economy.*
- Fixed an issue causing Tentacle Slam to apply extra stacks of Horrific Visions when talented for Maddening Tentacles and Idol of N'Zoth.
- Fixed an issue causing Improved Voidform to generate Insanity when casting Voidform.
- Phantom Menace has been removed.
- Hero Talents
  
  - Archon
    
    - Focused Outburst has been redesigned – Void Volley deals 5% increased damage and Shadow Word: Madness casts during Voidform unleash a Void Volley at your target at 25% effectiveness.
    - Resonant Energy has been slightly redesigned – Creating a Halo increases your spell damage by 2% for 10 seconds, stacking up to 4 times.

:::

:::

## FAQ

:::accordion
:::details Why do I keep dying?
Make sure to always pre-use your [[spell:586]] and [[spell:193063]] when you don’t have your [[spell:19236]] or [[spell:47585]] ready.

:::

:::

---

### Credits

Written By: **Soda**

Reviewed By: **Meeres**

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1.

**2026-02-24** Updated for patch 12.0.1.

**2026-01-20** Updated for patch 12.0.



:::
