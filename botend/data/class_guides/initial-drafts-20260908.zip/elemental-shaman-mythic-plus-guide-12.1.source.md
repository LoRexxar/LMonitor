Welcome to the **Elemental Shaman** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 5/5 · Excellent

Utility · 4/5 · Strong

Survivability · 3/5 · Average

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Elemental Shaman** Mythic+ Best in Slot
```json
{
  "source_code": "I8fAQbQA3_fABsHJEIICBAwJ5OwVtOQOC4UABk-FEAQEBAA_sOA_sOQOCwYNYFQA5RCBCgQAAcRuJMCJEYCBCARAAkQuD0AIQ49FEAICFQTBDBgeJ8CBFoaCPgQyXQQA-QQ84mwDIg2uDEwcEgBwBEGL3WzSBEAfkQAAIEAAFwDBZfRBRSQ94GgHFIBCil9ABATCSAggBMKBU9RGwAwVdwADog6AEEQzMo6AYAcCaRA9iUweI9TuDkjAYFQAmfBBAgQAAkjAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271483]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271481]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240892]] |
| 腿部 | [[item:271482]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271484]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:239656]] | [[item:240167]] · [[item:245784]] |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:268262]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Elemental Shaman**, you have access to Feedback Loop, which increases your [[spell:168534]] damage.

**Rank 2** increases your crit chance and makes your [[talent:101853]] increase your spell critical strike damage.

**Rank 3** gives your [[spell:168534]] a 25% chance to proc again.

:::

:::column
:::group
Feedback Loop

![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-elemental-mxr.webp>)

:::

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:101883@FAQAt6TB]]
    
    - Makes your [[spell:13729]] AoE.
  - [[talent:101884]]
    
    - Makes your [[talent:127873@FAQAt6TB]] AoE after you cast [[talent:101883@FAQAt6TB]].
- **Class Tree**
  
  - [[talent:127868@AJwB]]
    
    - Makes your [[talent:127871@FJgAWRpEigdBHA]] lose no charges and heal for more.
  
  
  
  - [[talent:135591@AJwB]]
    
    - Passive Intellect gain and auto casts all your imbues and shields.
- **Removed**
  
  - [[spell:378270@FJwCcBVAQdhALunAWJpA02tAt6TBa0wBb0wB8-SAYecBcusEHA]]
    
    - Removes the random [[spell:114049]] procs.
  
  
  
  - [[spell:210714]]
  - [[spell:336215]]
  - [[spell:375982]]

## Hero Talents



### [[talent:123377]]

- In Midnight there were 3 talents added to the hero tree:
  
  - [[talent:135990]] - Gain intellect based on how many ancestors you have up.
  - [[talent:135989@AJwB]] - Cast times of [[talent:127873@FAQAt6TB]], [[talent:127861]] and [[spell:8004]] are reduced.
  - [[talent:135988@AJwB]] - Increases the chance of [[spell:77756]] to proc.
- [[spell:443450@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - Ancestors spawn when you use [[talent:117491@FAQAQdhA]] or [[talent:101859@AJwB]].
  
  
  
  - These Ancestors cast spells depending on what you cast. 
    
    - If you cast any ST spell the Ancestor casts a [[spell:51505]] on your target.
    - If you cast any AoE spell the Ancestor casts a [[spell:188443]] on your target.
- [[talent:117459]] or [[talent:123632@FAQAQdhA]]
  
  - [[talent:117459]]
    
    - Your Ancestor's spells are more powerful.
  - [[talent:123632@FAQAQdhA]]
    
    - You have a chance to call another Ancestor for a short amount of time when they despawn.
- [[talent:117481]] or [[talent:123630@FAQAQdhA]]
  
  - [[talent:117481]]
    
    - Ancestors last longer.
  - [[talent:123630@FAQAQdhA]]
    
    - Certain spells have an additional chance to call an Ancestor to your side for a small period of time.
- When an Ancestor despawns they cast an [[spell:117014]] on a nearby target thanks to [[spell:443446@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]. This [[spell:117014]] does give you the Critical strike, Haste or Mastery as well.
- The rest of this tree are passives that don't affect your gameplay much.
  
  - [[spell:443448@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - Increases your maximum Maelstrom.
  - [[spell:443447@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - Increases the damage of your spenders.
  - [[spell:443418@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - [[spell:51505]] gains 1 additional charge and deals increased damage.




### [[talent:123376]]

- In Midnight there were 3 talents added to the hero tree:
  
  - [[talent:135987@AJwB]] - Increases [[talent:101864]] by 2 seconds and makes your [[talent:101859@AJwB]] give you 10 maelstrom.
  - [[talent:135986]] - Passive nature damage increase.
  - [[talent:135985@AJwB]] - After casting [[talent:101860]] you gain a stack of [[talent:117489@FAQAQdhA]].
- [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - Your [[spell:188196]] has a chance to turn to [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] after you spend Maelstrom
- [[talent:117482@FAQAQdhA]]
  
  - Casting [[talent:117489@FAQAQdhA]] grants a stack of [[talent:101859@AJwB]].
- [[talent:117470]] or [[talent:128225@FAQAQdhA]]
  
  - [[talent:117470]]
    
    - [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] grants you extra Mastery.
  - [[talent:128225@FAQAQdhA]]
    
    - [[spell:188196]], [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]], and [[spell:188443]] have a chance to cause an additional Overload.
- [[spell:454026@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - Reduces the cooldown of [[talent:101859]].
- [[spell:455123@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - Casting [[spell:454009@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] applies [[spell:210689]] to your target.
- The rest of this tree are passives that wont effect your gameplay much.
  
  - [[spell:454391@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - Spending Maelstrom grants you Haste.
  - [[spell:454919@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - Increases the damage of your ‍Earthquake and ‍Chain Lightning.
  - [[spell:454021@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
    
    - Increases the critical strike chance and damage of your nature spells by 5%.





## Talents



### [[talent:123376]]

:::talents [[talent:123376]] **Elemental Shaman** talents in Mythic+
```json
{
  "source_code": "CaQAzgeAFxuEqbGMnx9WPPTYVCAAAAzMbLzMzYML2mhZMzAAAAA2Mz2mZmhNDLMbzMN0MbAwsMzMjx2iJMzsNWmZmZMsMLzYxMzYmFAgBwMzMjhhBA",
  "code": "CaQAzgeAFxuEqbGMnx9WPPTYVCAAAAzMbLzMzYML2mhZMzAAAAA2Mz2mZmhNDLMbzMN0MbAwsMzMjx2iJMzsNWmZmZMsMLzYxMzYmFAgBwMzMjhhBA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[spell:392714]]
  
  - Empowers your next 2 [[spell:188196]] or [[spell:188443]] and makes them instant cast.
- [[talent:101860]]
  
  - 3 min cooldown. Increases your [[spell:168534]] damage by 150% and your spells proc 1 additional [[spell:168534]].

##### Class Tree

- [[spell:79206]]
  
  - Allows you to cast while moving for 15 sec, which can save you a lot of DPS you might lose otherwise in certain scenarios.
- [[spell:378081]]
  
  - Makes your next nature cast instant.

##### Hero Talents

- [[talent:117482@FAQAQdhA]]
  
  - Casting [[talent:117489@FAQAQdhA]] grants a stack of [[talent:101859@AJwB]].
- [[talent:117486@FAQAQdhA]]
  
  - Reduces the cooldown of [[talent:101859]] by 15 seconds.




### [[talent:123377]]

:::talents [[talent:123377]] **Elemental Shaman** talents in Mythic+
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[spell:392714]]
  
  - Empowers your next 2 [[spell:188196]] or [[spell:188443]].
- [[talent:101860]]
  
  - 3 min cooldown. Increases your [[spell:168534]] damage by 150% and your spells proc 1 additional [[spell:168534]].

##### Class Tree

- [[spell:79206]]
  
  - Allows you to cast while moving for 15 sec, which can save you a lot of DPS you might lose otherwise in certain scenarios.
- [[spell:378081]]
  
  - Makes your next nature cast instant. When playing [[talent:123377]], it becomes [[spell:448861@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]] and summons Ancestor as well.

##### Hero Talents

- [[spell:443450@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]]
  
  - Ancestors spawn when you cast [[talent:101859@AJwB]] and [[spell:448861@FJwCcBVAQdhALunAWJpA02tAt6TBYguAa0wBb0wB8-SAYecBHA]].
- [[talent:117472@FAQAQdhA]]
  
  - When an Ancestor despawns, it will cast an [[talent:127924@FAgAg_wBxkM]], which grants you the Critical strike, Haste, or Mastery as well.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[talent:101854]], [[talent:127924]] and [[talent:101855]] damage increased by 25%.
- **4-Set:** ‍When [[talent:101859@AJwB]] or [[talent:101860]] fade, your next 2 [[spell:9532]], [[talent:127856@FAQAt6TB]]or [[talent:127873@FAQAt6TB]]deal 25% increased damage and cause your next [[talent:101855]] [[talent:101854]] or [[talent:127924]] to cost 100% less Maelstrom.

### Single-Target



#### [[talent:123376]]

##### Opener

:::rotation [[talent:123376]] **Elemental Shaman** single-target opener in Mythic+
```json
{
  "source_code": "IwEaHIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAABIgzFgADCJYvBEAEIIUMJHwBQAgQ51uBBkQFQgCJfLAAAAAACRy3CA"
}
```
1. [[spell:392714]] Prepull [[item:241308]] · [[item:249346]]
2. [[spell:114050]]
3. [[spell:51505]]
4. [[spell:454009]]
5. [[spell:51505]]
6. [[spell:188196]]
7. [[spell:188196]]
:::

- Use [[talent:127924@FAQAxkM]] as soon as possible.

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:392714]] on cooldown.
2. Cast [[talent:101860]] on cooldown.
3. Cast [[talent:127924@FAQAxkM]] when:
   
   1. You have [[talent:136714]] active.
   2. You are close to overcapping Maelstrom.
4. Cast [[talent:117489@FAQAQdhA]] with [[talent:136714]].
5. Cast [[spell:51505]].
6. Cast [[spell:188196]].




#### [[talent:123377]]

:::rotation [[talent:123377]] **Elemental Shaman** single-target opener in Mythic +
```json
{
  "source_code": "IgEfHIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAACAAAAIkPEbQAMwgQC2bAFgABxkcAHwAACNcACBBA"
}
```
1. [[spell:392714]] Prepull [[item:241308]] ·
2. [[spell:443454]]
3. [[spell:114050]]
4. [[spell:51505]]
5. [[spell:65987]]
6. [[spell:51505]]
7. [[spell:65987]]
:::

1. Cast [[spell:392714]] on cooldown.
2. Cast [[talent:101860]] on cooldown.
3. Cast [[talent:117491@FAQAQdhA]] on cooldown.
4. Cast [[talent:101854]] / [[talent:127924@FAQA51uB]] when:
   
   - You have [[talent:101879]] active.
   - You are close to overcapping Maelstrom.
5. Cast [[spell:51505]].
6. Cast [[spell:188196]].
7. Cast [[talent:135718@FAQAt6TB]] on the move.





### AoE



#### [[talent:123376]]

##### Opener

:::rotation **[[talent:123376]] Elemental Shaman** Multi Target opener in Mythic+
```json
{
  "source_code": "IQEaGIkC-XAAAcAUyVGc1xGbCEAnuOAAAAAABIgzFgADCJYvBEAEMIUetbQBIQgGvEwBwAgQa8CAAAAAAIkpuEA"
}
```
1. [[spell:392714]] Prepull [[item:241308]] · [[item:249346]]
2. [[spell:114050]]
3. [[spell:454009]]
4. [[spell:12058]]
5. [[spell:12058]]
6. [[spell:77478]]
:::

- In the opener your goal is to cast as many [[talent:101855@FAgAQdhAWkcA]] and [[talent:127856@FAQAt6TB]] as possible.

##### Multi-Target Priority List

1. Cast [[spell:392714]] on cooldown.
2. Cast [[talent:101860]] on cooldown.
3. Cast [[talent:117489@FAQAQdhA]] on a target without [[talent:101889@FAgAQdhA51uB]].
4. Cast [[talent:127925@FAQAQdhA]].
5. Cast [[talent:127856@FAQAt6TB]].
6. Cast [[talent:135718@FAQAt6TB]].




#### [[talent:123377]]

:::rotation [[talent:123377]] **Elemental Shaman** single-target opener in Mythic +
```json
{
  "source_code": "IcYAodgQK4fBAAwBQJXZwVHbsJQAc66AAAAAAEgAOXACALUJscQRCsAXQFAUXIwi7JgVSKAtdLQr-UgGNcwGNcAvvEAmHXAnLLxBAAAAC5DxGAQAIggg9GQAEhgQa8SAHwEgCIEvvEAAAcQamBCcy92YAIUMJHAGsAgQ6GPAAAAAAIkGvA"
}
```
1. [[spell:392714]] Prepull [[item:241308]] · [[item:249346]]
2. [[spell:470053]]
3. [[spell:443454]]
4. [[spell:114050]]
5. [[spell:12058]]  
   
   1. [[spell:77756]] if proc
   2. [[spell:51505]]
6. [[spell:61882]]
7. [[spell:12058]]
:::

1. Cast [[spell:392714]].
2. Cast [[talent:117491@FAQAQdhA]].
3. Cast [[talent:101860]].
4. Cast [[talent:127925@FAQAQdhA]] when you are close to overcapping Maelstrom.
5. Cast [[talent:101883@FAQAt6TB]].
6. Cast [[spell:51505]] when:
   
   1. You have a [[spell:77756]] proc.
   2. You have [[talent:101884]].
7. Cast [[talent:127856@FAQAt6TB]].
8. Cast [[talent:135718@FAQAt6TB]] only while moving.





## Deep dive

### Lightning Rod

[[talent:127924@FAwAg_wB51uBxkM]], [[talent:101854]], [[talent:101855@FAgAQdhAWkcA]], and  [[talent:117489@FAQAQdhA]] applies [[talent:101889@FAgAQdhA51uB]] which duplicates a lot of you [[talent:127856@FAQAt6TB]], [[spell:188196]], and [[talent:117489@FAQAQdhA]] damage on to the targets affected by [[talent:101889@FAgAQdhA51uB]].

[[talent:127924@FAwAg_wB51uBxkM]] and [[talent:101854]] will always apply [[talent:101889@FAgAQdhA51uB]] to your target.

[[talent:101855@FAgAQdhAWkcA]] prioritizes your target, but if your target already has [[talent:101889@FAgAQdhA51uB]], it will apply it to a nearby enemy instead.

Most of the time you don't have to care about [[talent:101889@FAgAQdhA51uB]] as on Single-Target it will just get applied to your target, while on AoE your [[talent:101855@FAgAQdhAWkcA]] will automatically apply to other targets, however, on AoE you need to think about how you use [[talent:117489@FAQAQdhA]]. Whenever you cast it you want to try to cast on a target that doesn't have [[talent:101889@FAgAQdhA51uB]] or is about to fall off. If there's a priority target without [[talent:101889@FAgAQdhA51uB]] you can also try to apply it to that target.

### Understanding Maelstrom

Maelstrom is an essential resource to play around. Due to our mastery, [[spell:168534]] you will generate Maelstrom randomly and you have to be ready so that you don't overcap. This is why it's important to spend as soon as you can.

In some AoE scenarios, you will be playing [[talent:101893]] which reduces the chance of overcapping.

When you are playing, try to think how much your spells will generate ahead of time and learn to understand how much you will have in one or two globals from now, so you can plan your rotation ahead of time.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Elementalent Shaman** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips

##### 




### Den of Nalorakk

:::talents **Elemental Shaman** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips




### Murder Row

:::talents **Elemental Shaman** Mythic+ Build in Murder Row
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips




### The Blinding Vale

:::talents **Elemental Shaman** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips




### Voidscar Arena

:::talents **Enhancement Shaman** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips




### Kings' Rest

:::talents **Elemental Shaman** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips




### Ruby Life Pools

:::talents **Elemental Shaman** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips




### Temple of Sethraliss

:::talents **Elemental Shaman** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA",
  "code": "CaQAvTCLxPa6EXhIkSAiNIkjqAAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMz2ipNmZMWmxMjhFLzMLDjZmFAwMMAmZMMMA"
}
```
:::

#### Boss Tips





### Affixes

The Affix system got revamped going into **The War Within Season 1,** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix *--* 
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as an **Elemental Shaman**.

- Xal'atath's Bargain: Ascendant
  
  - You can use [[spell:51490]] or [[spell:192058]] on these.
- Xal'atath's Bargain: Voidbound
  
  - Should be focused down as fast as possible.
- Xal'atath's Bargain: Devour
  
  - [[spell:383013]] is great for dealing with this affix.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as an **Elemental Shaman**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Elemental Shaman** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFUQMkACKBEQAEA"
}
```
**智力 ＞ 精通 ＞ 急速 ＞ 暴击 ≫ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271483@DiQAAYQAnk7cVrTOC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAYQA8z6wPrTOCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271481@DgQAAYQAXk7kjAOF]] | Tier / Catalyst |
| Cloak | [[item:239656@FgQAAYQAno6gBwzt1sUA]] | Crafting |
| Chest | [[item:271876@DARAAYQAJk7kjAMWDWB]] | Tier / Catalyst |
| Wrist | [[item:244584@DiQAAYQAYA8wPrzt1sUA]] | Crafting |
| Gloves | [[item:271484@BgQAAYQA5IgTBA]] | Tier / Catalyst |
| Belt | [[item:268254@BiQAAYQA8z6kjAOF]] | Vashnik |
| Legs | [[item:271482@DgQAAYQAFo6kjAOF]] | Tier / Catalyst |
| Boots | [[item:268233@DgQAAYQAxj7kjAOF]] | Sszorak |
| Ring 1 | [[item:268249@DiQAAYQA1j7wPrTOC4UA]] | Vashnik |
| Ring 2 | [[item:252258@DiQAAYQA1j7wPrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270164@BgQAAYQA5IgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAYQA5IgTBA]] | Nymrissa Wavecaller |
| Main-Hand | [[item:271092@DgQAAYQA_k7kjAYF]] | Ula'tek |
| Off-Hand | [[item:268262@BgQAAYQA5IgTBA]] | Nymrissa Wavecaller |




### Farmable Alternatives

Below, you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251220@AgQAAIoABFA]] | Voidscar Arena |
| Neck | [[item:251142@AgQAAIoABFA]] | Murder Row |
| Shoulder | [[item:239049@AgQAAIoABFA]] | Kings' Rest |
| Cloak | [[item:251190@AgQAAIoABFA]] | The Blinding Vale |
| Chest | [[item:251233@AgQAAIoABFA]] | Voidscar Arena |
| Wrist | [[item:251200@AgQAAIoABFA]] | The Blinding Vale |
| Gloves | [[item:160213@AgQAAIoABFA]] | Kings' Rest |
| Belt | [[item:251228@AgQAAIoABFA]] | Voidscar Arena |
| Legs | [[item:159375@AgQAAIoABFA]] | Temple of Sethraliss |
| Boots | [[item:159388@AgQAAIoABFA]] | Temple of Sethraliss |
| Ring 1 | [[item:252258@AgQAAIoABFA]] | Voidscar Arena |
| Ring 2 | [[item:273792@AgQAAIoABFA]] | Altar of Fangs |
| Trinket 1 | [[item:273649@AgQAAIoABFA]] | Kings' Rest |
| Trinket 2 | [[item:250224@AgQAAIoABFA]] | Voidscar Arena |
| Main-Hand | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:251150@AgQAAIoABFA]] | Den of Nalorakk |





### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on the mythic+ dungeon.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270167@BgQAAYQA5IgTBA]]  <br>[[item:270164@BgQAAYQA5IgTBA]] |
| **A-Tier** | [[item:273649@AgQAAIoABFA]]  <br>[[item:270169]]  <br>[[item:250215@AgQAAIoABFA]] |
| **B-Tier** | [[item:250224@AgQAAIoABFA]] |
| **C-Tier** | [[item:193757@AgQAAIoABFA]] |
| **Junkyard** | [[item:250259@AgQAAIoABFA]]  <br>[[item:158368@AgQAAIoABFA]] |

### Embellishments

- 2x [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]]
  - [[item:241322]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]] *-- default*
  - [[spell:318038]] if you are specced into it.
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240892]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAAYQA]]  <br>[[item:244007]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAYQA]] |
| Waist | [[item:275707@BAAAAYQA]] |
| Legs | [[item:240133@BAAAAYQA]] |
| Boots | [[item:243953@BAAAAYQA]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Weapon | [[item:244031]] |

:::

:::column
:::gear **Elemental Shaman** Enchantments in Raid
```json
{
  "source_code": "IQFZGEQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEwP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAYQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing an **Elemental Shaman** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
  - 2% Critical Strike Damage increase.
- [[spell:33702]] -- Orc
  
  - Strong DPS racial but it doesn't line up with [[talent:101860]].
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] -- Troll
  
  - Strong DPS racial and great to combine with [[talent:101860]].
  - Reduce the duration of movement impairing effects by 20%.

### Recommendation

**Dwarf** is the strongest option for Mythic+ as an **Elemental Shaman**. If you are trying to push higher key levels it is by far the best.

## Macros

Discover recommended macros for Elemental Shamans during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:61882]]** -- *Casts [[spell:61882]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Earthquake
```

**[[spell:192077]] --** *Casts [[spell:192077]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Wind Rush Totem
```

**[[spell:108287]]** -- *Casts [[spell:108287]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Totemic Projection
```

:::

:::details Mouseover Macros
**[[spell:188389]]** -- *Casts [[spell:188389]] on your mouseover target.*

```wow-macro
#showtooltip Flame Shock
/cast [@mouseover, exists] Flame Shock; Flame Shock
```

**Focus Mouseover** -- *Puts whatever you mouseover on focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Utility Macros
**[[spell:51514]]**  -- *Casts [[spell:51514]] on your mouseover or target.*

```wow-macro
#showtooltip Hex
/cast [@mouseover, exists] Hex; Hex
```

**[[spell:8004]]** *-- Casts [[spell:8004]]* quickly on an ally by mouseovering or targeting.

```wow-macro
#showtooltip Healing surge
/cast [@mouseover, exists] Healing surge; Healing surge
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Elemental Shaman**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![Elemental Shaman Mythic+](<https://assets-ng.maxroll.gg/wordpress/wolf-ele-2-1024x681.webp>)

**Elemental Shaman** Mythic+ User Interface

:::accordion
:::details Addons
- **LittleWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring.
- **EllesmereUI**

:::

:::

## Changes this Patch

:::accordion
:::details **Patch 12.1**
**Hero Talents**

- Farseer
  
  - Developers' notes: In a previous tuning hotfix for Elemental Shaman, Farseer Spirits received a small change so they scale with the Elemental Fury talent. We are changing several other places where they weren't scaling the same as the Shaman's abilities.
  - Chain Lightning now hits up to 5 targets (was 3).
  - Lava Burst now also increases damage by a percent equal to your critical strike chance.

**Elemental**

- *Developers' notes: Elemental Shaman have higher burst during their Ascendance window with the changes in Midnight than we would like. We don’t want Ascendance to stop being a noticeable damage amplifier, but the combination of effects that boosted your Elemental Overload damage from both Ascendance and Apex talents all compounded with each other. We’re spreading a lot more damage into your spells to deal consistently higher damage while still getting a nice spike during Ascendance.*
- Power of the Maelstrom has been redesigned – Lightning Bolt and Chain Lightning have a 15% chance to cause your next Lava Burst to deal 20% increased damage, stacking up to 2 times. Lava Burst consumes one stack at a time.
  
  - *Developers' notes: Supercharge and Power of the Maelstrom both were extra, random Elemental Overloads. We feel that the other changes will make your damage more consistent, while still allowing other parts of your talent tree to still increase the quantity or power of Elemental Overload spells.*
- Stormkeeper has been updated – No longer causes Lightning Bolt to generate an additional Elemental Overload.
- Lava Burst damage increased by 30%. This does not apply to PvP combat.
- Lightning Bolt damage increased by 30%. This does not apply to PvP combat.
- Chain Lightning damage increased by 60%.
- Flame Shock damage increased by 60%.
- Tempest direct damage reduced by 20%.
- Healing Surge healing increased by 25%.
- Earth Shield healing increased by 25%.
- Healing Stream Totem healing increased by 25%.
- Ascendance now increases the damage of Elemental Overload by 30% (was 75%).
- Bonus Lava Bursts when activating Ascendance are now 50% of their normal value (was 100%).
- Molten Wrath now increases the damage of Lava Burst by 10% (was 15%).
- Apex Talent: Feedback Loop (Rank 1) now increases Elemental Overload damage by 10% (was 35%) and also increases Elemental damage done by 10%.
- Apex Talent: Feedback Loop (Rank 2) now grants 15%/30% critical damage bonus (was 25%/50%).
- Elemental Blast casts from Fusion of the Elements now only grant 40% of the normal duration of the Elemental Blast stat buffs (was 100%).
- Fixed an issue that caused Voltaic Blaze to not be properly affected by Elemental Fury's critical damage bonus.
- Fixed an issue that caused Elemental Resonance to not affect periodic Elemental damage.
- Fixed an issue where Apex Talent: Feedback Loop (Rank 2) did not properly increase the critical damage of several Elemental Shaman spells.
- Hero Talents
  
  - Farseer
    
    - Ancestors’ Lava Burst damage reduced by 20%.
    - Ancestors’ Chain Lightning damage reduced by 20%.
  - Stormbringer
    
    - Supercharge has been redesigned – Lightning Bolt, Chain Lightning, and Tempest overloads deal 10% additional damage.

:::

:::

:::accordion
:::details **Patch 12.0**.1
- **All damage reduced by 5%.**
- **Lightning Bolt damage reduced by 10%.**
- **Healing Surge healing increased by 130%.**
- **Healing Stream Totem healing increased by 50%.**
- **Earth Shield healing increased by 50%.**

:::

:::

:::accordion
:::details **Patch 12.0**
- **Hero Talents** 
  
  - Farseer
    
    - New Talent:  **Ancestral Influence – Your Intellect is increased by 1% for each Ancestor active.**
    
    
    
    - **New Talent: Windspeaker Elemental: The cast times of Healing Surge, Chain Heal, and Lava Burst are reduced by 10%.**
    
    
    
    - **New Talent: Mystic Knowledge Elemental: Increases the chance for Lava Surge to occur by 20%.**
    
    
    
    - **Elemental Reverb increases Lava Burst damage by 10% (was 20%).**
    
    
    
    - **All Ancestor healing reduced by 40%.**
    
    
    
    - **Elemental Call of the Ancestors has been updated – Stormkeeper calls an Ancestor to your side for 8 seconds.**
- **Routine Communication can now trigger from Flame Shock and Voltaic Blaze.**
- **Offering from Beyond now reduces the cooldown of Stormkeeper by 3 seconds when an Ancestor is called (was reduces the cooldown of Fire/Storm Elemental by 5 seconds).**
  
  - **Stormbringer** 
    
    - **New Talent: Natural Gift – Nature damage is increased by 2%.**
    - **New Talent: Descending Skies – Ascendance upgrades your next Lightning Bolt to Tempest.**
    - **New Talent: Stormwell Elemental: Storm Elemental lasts 2 seconds longer, and Stormkeeper generates 10 Maelstrom.**
  - **Elemental Tempest's chance to occur has been redesigned – No longer triggers based on total Maelstrom spent and now has a 0.3% chance occur per Maelstrom spent.**
  - **Tempest single target damage increased by 25%.**
  - **Arc Discharge has been redesigned – Now causes Tempest to grant a stack of Stormkeeper.**
  - **Rolling Thunder has been redesigned – Now reduces the cooldown of Stormkeeper by 15 seconds.**
  - **Awakening Storms has been redesigned – Now increases the chance to gain Tempest by an additional 0.3% per Maelstrom spent.**

:::

:::

## FAQ

:::accordion
:::details Q: Which [[spell:61882]] is recommended to pick?
**A:** In general the one you position with your mouse is better as you can drop it ahead of mobs if they are being moved, while the one that drops on your target may be nicer to play.

:::

:::

---

### Credits

Written By: **Stove**

Reviewed By: **Rycn**

:::changelog 更新记录
**2026-08-07** Updated for patch 12.1

**2026-06-23** Updated for patch 12.0.7

**2026-04-25** Updated for patch 12.0.5

**2026-02-24** Updated for patch 12.0.1

**2026-01-17** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7

**2025-10-08** Updated for patch 11.2.5

**2025-08-06** Updated for patch 11.2

**2025-06-18** Updated for patch 11.1.7

**2025-04-23** Updated for patch 11.1.5

**2025-02-23** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
