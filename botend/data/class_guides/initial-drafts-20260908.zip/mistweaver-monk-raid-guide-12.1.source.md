Welcome to the **Mistweaver Monk** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Overall Healing** · 2/5 · Weak

Cooldown Strength · 2/5 · Weak

Utility · 2/5 · Weak

Survivability · 3/5 · Average

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Mistweaver Monk** Raid Best in Slot Gear
```json
{
  "source_code": "J4oAwDlDBc__BEwAmQggQEAAvj7AX16ACKwF2gVABk-FEAQEBAg-sOg-sOAj1IoAYFQAdSCBCgQAAUTuDIoAOFQAiSCBCgQAAkQuDIoAOFQAgfBBAiQByQhgCgVAB4ZCtQwGqmQLEU-FF0CAP0QLsA2uDQIIBAwJqOQGAHgYAAQBBwyt1sUABAKJEAACBAQBUBC3XQggIEAAvkbAkUgEEAYL-IBAEQ1HZADAX1BDE09FNgBEYFQA0LSB-xQB5OQOB8AWJA8AEASAAMHwDkBwDAAAAAAAAcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240890]] · [[item:240890]] |
| 肩部 | [[item:271517]] | [[item:244021]] |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240890]] |
| 腿部 | [[item:271518]] | [[item:240155]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240890]] · [[item:240167]] · [[item:245785]] |
| 手部 | [[item:271520]] |  |
| 戒指一 | [[item:268252]] | [[item:240890]] · [[item:244015]] |
| 戒指二 | [[item:273792]] | [[item:240890]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245875]] · [[item:245785]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Mistweaver Monk**, you have access to Spiritfont, which makes your [[talent:124985@FAQAv7eB]] and [[spell:116670]] have a chance to to cause your next [[talent:124922@FAQAv7eB]] to channel [[talent:124933@FAQAIbrB]] onto 5 allies at 20% effectiveness for 8 sec.

**Rank 2** increases the damage of  [[talent:124985@FAQAv7eB]] and healing of [[talent:124922@FAQAv7eB]]. **Rank 3** makes [[talent:124921@FAQAv7eB]] active Spiritfont it applies shields from [[talent:124913]] at 30% effectiveness.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-mistweaver-mxr.webp>)

**Spiritfont**

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:124913]]
    
    - Now increases the cast speed of [[talent:124922@FAQAv7eB]] by 30% for the whole duration while your [[talent:124915]] is active.
  - [[talent:124907]]
    
    - Increases the healing by your [[spell:115151]] on your lowest health  % ally by 500%.
  - [[talent:128221@AJgCBA]]
    
    - Now only heals 5 allies for a certain amount, it no longer increases the output of [[spell:115151]].
  - [[talent:124908@FAQAv7eB]]
    
    - Now buffs a stat by 8% and no longer has a duration when used, the buffs stays until you empowered a different ability.
- **Class Tree**
  
  - [[talent:136519@AJgCBA]]
    
    - After casting [[talent:124985@FAQAv7eB]] your next [[spell:116670]] is instant.
  - [[talent:124958@FAQAIbrB]]
    
    - Summons a [[talent:133997@FAQAIbrB]] whenever you use [[talent:124921@FAgAv7eBHUwA]] so you never have to replace your statue during a fight.
- **Removed**
  
  - [[talent:134029]] 
    
    - Is now removed and is embedded into [[talent:124968@FAQA18eB]] as a choice node, but only the redirection of harmful magical effects on you, back to the caster. Resulting in you losing a defensive ability.

## Hero Talents

- [[talent:125045]] gives you another cooldown [[talent:125062]], which offers very strong healing and damage for a 1.5 min cooldown. It also offers you great talent nodes such as [[talent:125055@AJgCBA]] that lowers the cooldown of some of your abilities. [[talent:125045]] also enhances your other spells and gives you some utility as well.
- [[talent:125044]] focuses more on increasing giving you another stack of [[talent:124921]] and making it the enabler for [[talent:125033]] which splashes out the healing you have gathered in your Vitality resource that you will see as a buff.
- But overall [[talent:125045]] is the stronger choice for Raid, so this guide will focus mainly on [[talent:125045]]  as the Hero Talent choice.



### [[talent:125045]]

- You gain the ability [[talent:136562@AJgCBA]] on a 1.5 min cooldown, this is a very strong cooldown for healing, you may move while channeling.
  
  - You can recast this ability during its duration, to have all the August Celestials assist at 200% increased effectiveness, it will do it automatically if not used before the end of the cast.
- [[talent:135959@AJgCBA]] gives you 75% reduced cooldown time on [[spell:115151]], [[spell:107428]], [[talent:124875]] after casting [[talent:124921@FAgAv7eBHUwA]].
- [[talent:135958@AJgCBA]] gives you 10% haste each time you trigger [[talent:135959@AJgCBA]].




### [[talent:125044]]

- [[talent:125033]] stores "vitality", up to a certain amount, from 10% of your damage, and 30% of your healing, with overhealing at a reduced amount. Casting [[spell:116680]] activates [[talent:125033]] for 10 seconds, making your spells draw out the amount of vitality stored, to deal 40% additional healing over 8 seconds on the targets.
  
  - Through [[talent:125039]] which makes [[talent:125033]] have a chance of spreading to a nearby target, by dealing damage or healing. You also deal 20% more damage and healing to targets you healed with [[talent:125033]].
- [[talent:125034]] enables [[talent:125033]] through your single target abilities to draw vitality to deal damage.
- [[talent:125036]] gives your [[talent:124921]] another charge.





## Talents



### [[talent:128221]] Build

:::talents **Mistweaver Monk** Rushing Wind Kick Raid Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### When to use this Spec

This is the baseline build for **Mistweaver Monk**, focusing on casting many [[talent:128221]] to extend the duration of your HoT's with [[talent:124899]] and increasing the healing of [[spell:115151]] by 150% for 4 sec.

#### Gameplay Altering Talents

- Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[talent:124895]]
  
  - Causing your Chi Cocoons from [[talent:124913]] to now apply [[talent:124922@FAQAv7eB]] for 4 seconds when expired or consumed. It also increases the [[spell:343737]] from your [[talent:124915]] by 500%.
- [[talent:128221]]
  
  - Transforms your [[talent:124985@FAQAv7eB]] into [[talent:128221]], dealing damage to enemies in a cone in front of you, but more importantly it gives you [[spell:467341]] buff for 4 sec, increasing [[talent:124888]] healing by 50%.
- [[talent:124899]]
  
  - The core talent for this build, that makes your [[talent:128221]] heals all allies with your [[spell:115151]] and [[spell:124682]] and extends those effects by 4 sec, up to 100% of their original duration.

##### Class Tree

- [[talent:124866]]
  
  - Making [[spell:115450]] also dispel all Poison and Disease effects.
- [[talent:136519@FJQADihBKEA]]
  
  - Making your [[spell:116670]] be instant cast after you cast [[talent:124985@FAQAv7eB]].
- [[talent:124949]]
  
  - When you heal an ally lower than 35% hp you gain a nice 10% healing increase for the next 4 seconds.
- [[talent:124960]]
  
  - Passive magic absorbs that refreshes every 3 seconds to a maximum of 10% of your max health.

##### Hero Talents

- [[talent:125055]] gives you 75% reduced cooldown time on [[spell:115151]], [[talent:128221]], [[spell:116849]] and [[spell:116680]] whenever you consume stacks of  [[talent:124904]], the duration is increased depending on how many clouds you consumed.
- [[talent:125060]] makes your next [[talent:124922]] cast time be reduced by 50% and give 5 allies a small absorb shield.
- [[talent:125049@AJgCBA]] gives you a [[talent:124870]] for the whole duration of your Celestial.
- [[talent:135958@AJgCBA]] gives you 10% haste each time you trigger [[talent:135959@AJgCBA]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set**: [[talent:124985@FAQAv7eB]] deals 30% increased damage and [[talent:128221@AJgCBA]]'s healing is increased by 100%.
- **4-Set**: [[talent:124985@FAQAv7eB]] and [[talent:128221@AJgCBA]] have a chance to reset their cooldown when cast as well as 100% mana cost reduction.

### Priority List



#### [[talent:128221]]Build

1. Cast [[spell:115151]] so you never reach 3 stacks.
2. Cast [[talent:128221]] on cooldown, which extends your HoT durations through [[talent:124899]].
3. Cast [[spell:116680]] on [[spell:115151]] to gain Haste through[[spell:388491]].
4. Cast [[spell:124682]] when you have [[talent:125060]].
5. Cast [[spell:116670]] to heal an ally and the raid.
6. Cast [[spell:100780]] to gain [[spell:116645]] stacks.





#### For Damage

1. Cast [[talent:128221]]on cooldown.
2. Cast [[spell:100784]] on cooldown.
3. Cast [[spell:100780]].
4. Cast [[spell:101546]] if there are 4 or more enemies.

### Cooldowns

#### Celestial Conduit

- This is a strong healing cooldown that you can channel while moving, use it when you need a lot of healing as it deals increased healing based on targets hit.

#### Invoke Yu'lon, the Jade Serpent

- Your main healing cooldown as **Mistweaver Monk**, which heals allies, reduces the Mana cost of your [[spell:124682]] by 50%, and paired with other talent nodes also gives you:
  
  - [[talent:124913]] that gives a shield to 5 allies and your [[spell:124682]] applies an extra HoT and 10% heal increase with [[spell:358560]].
  - Causing your Chi Cocoons from [[talent:124913]] to now apply [[talent:124922@FAQAv7eB]] for 4 seconds when expired or consumed. It also increases the [[spell:343737]] from your [[talent:124915]] by 500%.

- You may cast more or less ‍[[spell:124682]], but you really wanna cast [[spell:116670]] for when you need the big burst healing, use your [[talent:128221]] on cooldown even during the ramp mainly to not let the buff run out.

:::rotation **Mistweaver Monk** Yu'lon ramp in Raids
```json
{
  "source_code": "H0ELGIUnEHAAAAAACh8xBgAKBI0zBHAAAIkRqTQBWArCnHAAAMgMtMDACtWIHAAALUmdlJXegQDIzV2YAIkvHHAAAkgZvJHIiVnczRH"
}
```
1. [[spell:115869]]
2. [[spell:116680]]  [[spell:115151]]
3. [[spell:322118]]
4. [[spell:124682]] 2-3
5. [[spell:467307]] every 4 sec
6. [[spell:116670]] for burst
:::

#### Revival

- To maximize [[spell:115310]], check for crucial magic, poison, or disease dispels in the encounter. Pairing it with 3 out of 4 buffs from [[spell:400089]] boosts healing by a good amount. Its instant cast is ideal for heavy movement phases.

#### Thunder Focus Tea with Secret Infusion

- Using [[spell:116680]] with [[spell:388491]] provides both the empowerment and a 15% secondary stat buff, depending on the next spell cast. Generally use [[spell:115151]] 8% haste from [[talent:124908@FAQAv7eB]].

#### Life Cocoon

- A high absorb external which can be a lifesaver for both other allies and yourself. Use it to save allies from dying, or combine it with [[spell:322118]] because of the talent [[spell:388548]] that will grant [[spell:115151]] and [[spell:124682]] on the target for increased total healing output.

## Deep Dive

#### Min maxing Spiritfont

- You can wait with casting [[talent:124922@FAQAv7eB]] since you can stack your Spiritfont and trigger it for when you need extra healing, or for example pair 2 stacks together with [[talent:124915]].

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomyss Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Mistweaver Monk** Nek'Zali Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1287322]] at the edge of the room!
- Do not be inbetween the boss and the tank when the boss casts [[spell:1284103]].




### Entombed Sentinels

:::talents **Mistweaver Monk** Entombed Sentinels Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- Dispel players affected with [[spell:1284471]].
- [[spell:1284590]] is neutralized harmlessly upon reaching exactly 4 stacks.




### Lost Explorers

:::talents **Mistweaver Monk** Lost Explorers Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- Dispel people affected with [[spell:1286921]].




### Vashnik

:::talents **Mistweaver Monk** Vashnik Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- External players affected with [[spell:1295224]]. While affected, they are immune to your regular healing.
- Use a personal defensive when affected by [[spell:1294994]].




### Sszorak

:::talents **Mistweaver Monk** Sszorak Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- Use [[talent:124875]] on people with [[spell:1286987]].
- Use your movement abilities to counter [[spell:1285419]].




### Twin Fangs

:::talents **Mistweaver Monk** Twin FangsTalents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- Use a personal defensive when affected by [[spell:1290809]].




### Coiled Altar

:::talents **Mistweaver Monk** Coiled Altar Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.




### Ula'tek

:::talents **Mistweaver Monk** Ula'tek Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- These Boss tips will be provided after the Race to World First is concluded.




### Nymrissa Wavecaller

:::talents **Mistweaver Monk** Nymrissa Wavecaller Talents
```json
{
  "source_code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB",
  "code": "C6QAI2iUD8dsJPIMmzPPH0Bl8BAAAAAAAghFLzAbWMjZ2WmxGmZGmZZbZmxCzMNjZADGMsMzMzwsNYwiJAAAAwsNtNLzsMLWmllZbmBAAGwMzgZAjhxiMmB"
}
```
:::

#### Boss Tips

- Use a personal defensive when many [[spell:1257717]] get popped.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Mistweaver Monk**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Mistweaver Monk** Stat Priority in Raid
```json
{
  "source_code": "JoAJFUAJgEDKBEQADA"
}
```
**智力 ＞ 急速 ＞ 暴击 ＞ 精通 ≥ 全能**
:::

> The Conclusion here is that you want to equip the highest item level generally.

- Blizzard introduced Stat drs, which you should be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you shouldn't consider this stat when choosing between two items.

- Here is a showcase of how powerful Leech is for a Healer: Breakdown of Mythic Fyrakk

![](<https://assets-ng.maxroll.gg/wordpress/mistweaverLEECHraid-ezgif.com-png-to-webp-converter-1024x428.webp>)

**Mistweaver Monk** healing breakdown from Warcraftlogs

## Gear



### Best in Slot

Due to the way stat weights work for **Mistweaver Monk**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAkGAvj7cVrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAkGA6z6oPrDj1IoAYFA]] | Ula'tel |
| Shoulder | [[item:271517@DgQAAkGA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAkGACKAWBA]] | Coiled Altar |
| Chest | [[item:271522@DgQAAkGAJk7IoAOF]] | Tier/Catalyst |
| Wrist | [[item:244576@FCSAAkGAno6kBwj-sOAAAAAAAA3WzSB]] | Crafting |
| Gloves | [[item:271520@BgQAAkGACKgTBA]] | Tier/Catalyst |
| Belt | [[item:268256@BiQAAkGA6z6IoAYF]] | Coiled Altar |
| Legs | [[item:271518@DgQAAkGAbo6IoAOF]] | Coiled Altar |
| Boots | [[item:268261@DgQAAkGAPk7IoAOF]] | Twin Fangs |
| Ring 1 | [[item:268252@DiQAAkGAvk7oPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:273792@DiQAAkGAvk7oPrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270164@BgQAAkGACKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:270167@BgQAAkGACKgTBA]] | Nymrissa |
| Weapon | [[item:271092@DgQAAkGAFk7kjAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FASAAkGAzB8kBwDAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Raids from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@BgQAAkGACKQQBA]] | Altar of Fangs |
| Neck | [[item:273781@BgQAAkGACKQQBA]] | Altar of Fangs |
| Shoulder | [[item:273774@BgQAAkGACKQQBA]] | Altar of Fangs |
| Cloak | [[item:193763@BgQAAkGACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@BgQAAkGACKQQBA]] | Voidscar Arena |
| Wrist | [[item:251135@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:251124@BgQAAkGACKQQBA]] | Murder Row |
| Belt | [[item:159301@BgQAAkGACKQQBA]] | King's Rest |
| Legs | [[item:251130@BgQAAkGACKQQBA]] | Murder Row |
| Boots | [[item:251153@AgQAAIoABFA]] | Den of Nalorakk |
| Ring 1 | [[item:273792@BgQAAkGACKQQBA]] | Altar of Fangs |
| Ring 2 | [[item:159459@AgQAAIoABFA]] | King's Rest |
| Trinket 1 | [[item:250215@BgQAAkGACKQQBA]] | Murder Row |
| Trinket 2 | [[item:273649@AgQAAIoABFA]] | King's Rest |
| Two-Hand Weapon | [[item:159636@AgQAAIoABFA]] | Tempel |
| One-Hand Weapon | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:273779@BgQAAkGACKQQBA]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]] |
| **A-Tier** | [[item:270162@AgQAAIoAOFA]]  <br>[[item:250215@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]] |
| **B-Tier** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]][[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:240167]]
  
  - Very strong stat stick, that also empowers your allies.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241288]]
  
  
  
  - [[item:241300]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240890]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@DAAAAkGAvj7A]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:243977@BAAAA4QA]] |
| Wrist | [[item:275707@DAAAAkGAvj7A]] |
| Belt | [[item:275707@DAAAAkGAvj7A]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:244015@BAAAAkG]] |
| Ring 2 | [[item:244015@BAAAAkG]] |
| Weapon | [[item:243973@BAAAAkG]] |

:::

:::column
:::gear **Restoration Druid** Enchantments
```json
{
  "source_code": "JQFZOEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAAv0AEo8SuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For **Mistweaver Monk** there's some slight variance between races, but some have some potentially useful racials that could be good in certain raid encounters.

- [[spell:274738]] *-- Mag'har Orc*
  
  - 2 minute cooldown that gives you a high amount of secondary stats.
- [[spell:65116]] -- Dwarf
  
  - Can dispel Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:28730]] *-- Blood Elf* 
  
  - 2 minute cooldown that gives you some mana back and rarely can be used to dispel enemies.
- [[spell:58984]] *-- Night Elf* 
  
  - In raid rarely used, but you can use this racial to ignore certain targeted mechanics.
- [[spell:20577]] *-- Undead*
  
  - Famously used in certain encounters, this racial can be used on corpses that are Humanoid or Undead to regenerate 7% of your health and Mana every 2 sec for 10 sec.

### Recommendation:

Unless you are really min-maxing, you should play whatever you want, whether it's lore or aesthetics. However, Dwarf with their [[spell:65116]] helped out on Tindral Sageswift & Fyrakk the Blazing in the Amirdrassil Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned. And on Fyrakk the Blazing, [[spell:20577]] could be used in Phase 2 on the smaller Undead adds that spawned.   
  
But, Mag'har Orc is not as good as previously but still a choice go for due to their racial [[spell:274738]], on a 2 min cooldown, which grants you a amount of one secondary stat for 15 sec, now choosing one of your 2 highest secondary stats. This combinded with the [[talent:124895]] talent making [[talent:124915]] also a 2 min cooldown, a great combination.   
I therefore suggest playing Mag'har Orc for the upcoming raid.

## Macros

Discover recommended macros for **Mistweaver Monk** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Mistweaver Monk** Mythic+ Guide are available as mouseover macros for your convenience!

**[[spell:116670]]**

```wow-macro
/cast [@mouseover, help] Vivify; Vivify
```

**[[spell:124682]]**

```wow-macro
/cast [@mouseover, help] Enveloping Mist; Enveloping Mist
```

**[[spell:115151]]**

```wow-macro
/cast [@mouseover, help] Renewing Mist; Renewing Mist
```

**[[spell:115175]]**

```wow-macro
/cast [@mouseover, help] Soothing Mist; Soothing Mist
```

**[[spell:399491]]**

```wow-macro
/cast [@mouseover, help] Sheilun's Gift; Sheilun's Gift
```

**[[spell:116849]]**

```wow-macro
/cast [@mouseover, help] Life Cocoon; Life Cocoon
```

**[[spell:115450]]**

```wow-macro
/cast [@mouseover, help] Detox; Detox
```

:::

:::details Recommended Macros
**Makes you spinn faster with [[spell:107270]]**

```wow-macro
#showtooltip
/cast !Spinning Crane Kick
```

**Your [[spell:116844]] instantly goes off when you press the button without having to confirm click, use with caution.**

```wow-macro
#showtooltip
/cast [@cursor] Ring of Peace
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Mistweaver Monk**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![Mistweaver Monk User Interface in Raids](<https://assets-ng.maxroll.gg/wordpress/mistweaverraidui-ezgif.com-png-to-webp-converter-1024x614.webp>)

Mistweaver Monk Interface in Raids

:::accordion
:::details Addons
- **Shadowed Unit Frames** --- Party/Raidframe Addon
  
  - Simplistic addon to replace your Unitframes and other UI Elements with a more clean look.
- **Vuhdo** --- Party/Raidframe Addon
  
  - Addon to replace your Unitframes.
- **Plater** --- Nameplate Addon
  
  - Plater is a nameplate addon with an extraordinary amount of settings out of the box. Debuff tracking, threat coloring, support for scripting similar to WeakAuras + the WeakAuras-Companion for Mod/Script/Profile updates.
- **BigWigs** -- BossMods Addon
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific raid encounter.
- **Details** --- Damage Meter
  
  - Shows you Damage/Healing throughout the encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- **Mistweaver**

- New Talent: Vital Expenditure – Soothing Mist's healing is increased by 300%, but its mana cost is increased by 200%. Choice node with Dancing Mists.
- Dance of the Wind has been updated – Your physical damage taken is reduced by 10% and an additional 10% every 4 seconds until you receive a physical attack, stacking up to 4.
- All healing reduced by 3%.
- Mastery: Gust of Mist healing increased by 50%.
- Spinning Crane Kick damage decreased by 7%.
- Way of the Crane now transfers 280% of damage done (was 340%).
- Jadefire Teachings now increases Ancient Teaching's transfer amount by 320% (was 270%).
- Morning Breeze effectiveness reduced by 60%.
  
  - *Developers' notes: Morning Breeze’s value is being adjusted down in accordance with the Mastery: Gust of Mist increases in Curse of Ula'tek. This should leave the talent’s effectiveness at a similar overall level.*
- Fixed an issue that caused Temple Training’s Spinning Crane Kick damage increase to apply to Mistweaver.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[talent:124875]] as a personal defensive cooldown.

:::

:::details Q: Why do I keep running out of mana?
A: You need to make good use of [[spell:115869]], and you may be casting too many [[spell:124682]].

:::

:::

---

### Credits

Written By: **Velo**

Reviewed By: **Rycn**

---

:::changelog 更新记录
**2026-08-09** Updated for patch 12.1

**2026-06-23** Updated for patch 12.0.7

**2026-04-22** Updated for patch 12.0.5

**2026-02-22** Updated for patch 12.0.1

**2026-01-14** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-08** Updated for patch 11.2.5

**2025-08-02** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-22** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5



:::
