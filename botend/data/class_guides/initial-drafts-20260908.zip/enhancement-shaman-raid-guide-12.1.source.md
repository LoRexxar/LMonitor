Welcome to the **Enhancement Shaman** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 4/5 · Strong



:::

:::

:::column
:::gear **Enhancement Shaman** Raid Best in Slot
```json
{
  "source_code": "IgoAQfQA3_fABsHJEIICBAwJ5OwVtOQOC4UABk-FEAQEBAA_sOA_sOQOCwYNYFQA5RCBCgQAAcRuJMCJEYCBCARAAkQuD0AIQ49FEAICFQTBDBgeJ8CBhubCPgQyXQQA-QQ84mwDIg2uDEwcEgBwBEGL3WzSBEAfkQAAIEAAFwDBZfRBRSQ94GgHFIBBildBwkgEAIYAji0XfQAAIMAA5IAWBUAAB40FCEQXBIRAChBWBEAKoOABBMNDqOAGAnAYAEbCBCwPBALQYFQAYV9ACgQAA8TuDIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271483]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240892]] · [[item:240892]] |
| 肩部 | [[item:271481]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240892]] |
| 腿部 | [[item:271482]] | [[item:244641]] |
| 脚部 | [[item:268233]] | [[item:243953]] |
| 腕部 | [[item:244584]] | [[item:240892]] · [[item:245784]] |
| 手部 | [[item:271484]] |  |
| 戒指一 | [[item:268249]] | [[item:240892]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:239656]] | [[item:240167]] · [[item:245784]] |
| 主手 | [[item:268209]] | [[item:244031]] |
| 副手 | [[item:251224]] | [[item:244031]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Enhancement Shaman**, you have access to Storm Unleashed, which can proc to make your next [[talent:101840]] ignore its cooldown.

**Rank 2** makes your spenders and weapon imbuements do more damage.

**Rank 3** makes your [[talent:101840]] electrecute an area, doing damage to any enemy that stands inside it.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-enhancement-mxr.webp>)

Storm Unleashed

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:127868@AJwB]]
  
  
  
  - Makes your [[talent:127871@FJgAWRpEigdBHA]] lose no charges and heal for more.
  
  
  
  - [[talent:135591@AJwB]]
    
    - Passive Intellect gain and auto casts all your imbues and shields.
- **Class Tree**
  
  - [[talent:127868@AJwB]]
    
    - Makes your [[talent:127871@FJgAWRpEigdBHA]] lose no charges and heal for more.
  
  
  
  - [[talent:135591@AJwB]]
    
    - Passive Intellect gain and auto casts all your imbues and shields.
- **Removed**
  
  - [[spell:375982]]
  
  
  
  - [[spell:117014]]
  - [[spell:179400]]
  - [[spell:262624]]

## Hero Talents

:::tabs
:::tab [[talent:123381]]
- In Midnight there have been 3 new talents added to the hero tree:
  
  - [[talent:135987@AJwBBA]]
    
    - Passive damage increase to your [[spell:65986]].
  - [[talent:135986]]
    
    - Passive nature damage increase
  - [[talent:135985@AJwBBA]]
    
    - Gives you a [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] after using your [[talent:114291]] or get a proc from [[talent:101816]].
- [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - Your ‍Lightning Bolt has a chance to turn into ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] after spending [[spell:187880]].
  - The main idea of this Hero Tree is to cycle through as much [[spell:187880]] as possible and cast as many ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] as possible.
- [[talent:117482]]
  
  - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] causes your next [[spell:188443]] or [[spell:188196]] to be instant cast, deal increased damage.
- [[talent:117470]] or [[talent:128225]]
  
  - [[talent:117470]] 
    
    - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] grants Mastery for a few seconds.
  - [[talent:128225]]
    
    - [[spell:188196]], [[spell:188443]], and [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] have a chance to refund [[spell:187880]] stacks.
- [[spell:454026@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] also summons a Nature [[spell:51533]].
- [[spell:455123@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - Casting ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]  applies ‍[[spell:210689@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] to your target.
- The rest of this tree are passives that do not affect your gameplay much.
  
  - [[spell:454391@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - Spending [[spell:187880]] grants you Haste.
  - [[spell:454919@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - Increases the damage of your ‍[[spell:187874]] and ‍[[spell:188443]].
  - [[spell:454021@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - Increases the critical strike chance and damage of your Nature spells.

:::

:::tab [[talent:123379]]
- In Midnight there have been 3 new talents added to the hero tree:
  
  - [[talent:135984@AJwBBA]]
    
    - Passive increase to [[talent:135593]] and each time you spend your [[spell:65986]] you get an extend on your [[talent:101809]].
  - [[talent:135983]]
    
    - Passive mastery increase
  - [[talent:135982@AJwBBA]]
    
    - Buffs your first [[talent:135593]] after using [[spell:444995]].
- [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - Summons a totem that pulses a large amount of damage every 6 sec, reduced by Haste.
- [[spell:445024@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - After summoning your [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] your next:
    
    - [[spell:188196]], [[spell:188443]], or [[spell:394150]] unleashes **Surging Bolts** at your [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]].
    - Your next [[spell:60103]] or [[spell:333974]] grants you [[spell:201900]] for 6 sec.
- [[spell:445034@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
  
  - [[spell:60103]] has a chance to summon a **Searing Totem** that shoots Searing Bolts at a nearby enemy
    
    - [[spell:196840]] empowered by [[spell:334195]], [[spell:60103]] and [[spell:333974]] makes your **Searing Totem** shoot a Searing Volley at  nearby enemies.
- The rest of this is passive and does not affect your gameplay much.
  
  - [[spell:445025@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - [[spell:188196]], [[spell:188443]], and [[spell:394150]] has a chance to empower your totem and deal extra damage.
  - [[spell:445028@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
    
    - Increases the chance of [[spell:33757]] to be triggered by, and its damage.
    - When [[spell:318038]] triggers from [[spell:33757]] attacks, it has a chance to trigger a whirl of flame around the target, dealing its damage to all nearby enemies.
  - [[spell:445029@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] or [[talent:125823]]
    
    - [[spell:445029@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
      
      - While [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] is active, you deal 3% increased damage and healing.
    - [[talent:125823]]
      
      - [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] deals more damage during [[spell:114051]].
  - [[spell:445036@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] or [[talent:125822@FAQARdhA]]
    
    - [[talent:117478@FAQARdhA]]
      
      - Increases your **Searing Totems**' critical strike chance, and its critical strike damage.
    - [[talent:125822@FAQARdhA]]
      
      - Casting [[spell:197214]] causes your [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] to create a tremor.
  - [[spell:445032@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] or [[talent:125824@FAQARdhA]]
    
    - [[talent:117463@FAQARdhA]]
      
      - Increases the damage of your [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]].
    - [[talent:125824@FAQARdhA]]
      
      - Increases the critical strike chance of your [[spell:318038]] and its critical strike damage.

:::

:::

## Talents

:::tabs
:::tab [[talent:123381]]
:::talents [[talent:123381]] **Enhancement Shaman** Single-Target talents in Raids
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYjZGsMzMz8AGGzAAMDjZGmJwMDGMG"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:210853]]
  
  - Causes [[spell:17364]] and [[spell:60103]] to have a 100% chance to generate 1 stack of [[spell:187880]].
- [[talent:101825]]
  
  - Stormstrike now has 2 charges.
  - [[spell:201845]] now also causes your next [[spell:17364]] to deal 25% additional damage as Nature damage, stacking up 2 times.
- [[talent:101814]]
  
  - 20% chance to refund any [[spell:187880]] spent.
  - Generate 2 [[spell:187880]] every sec while in [[talent:114291]].
- [[talent:101813]]
  
  - [[spell:188196]] and [[talent:127856]] deals 20% increased damage.
  - While [[talent:114291]] or [[talent:101824@FAQAQSfB]] is active, [[spell:115356]] automatically consumes up to 5 [[spell:187880]] to cast a [[spell:188196]] or [[talent:127856]], whichever was most recently casted.
  - As of 11.2, automatically cast [[talent:117489@FAgAo3tAHldB]], consuming up to 10 [[talent:101804@FAQAHldB]].

#### Hero Talents

- [[talent:117489]]
  
  - Your ‍Lightning Bolt turns into ‍[[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]]
- [[talent:128225]]
  
  - [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]], [[spell:188443]], and [[spell:188196]] has a 35% chance to refund 2 [[spell:187880]] stacks.

:::

:::tab [[talent:123379]]
:::talents [[talent:123379]] **Enhancement Shaman** Single-Target talents in Raids
```json
{
  "source_code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMjZmZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZC2AYWmxMGLLzYhZmNWmZmZYYMDAwMAjZmYmBAGD",
  "code": "CeQAvTCLxPa6EXhIkSAiNIkjqMzMjZmZmZmZmZmZGzAAAAAAAAAgFYDmxiGbDgZC2AYWmxMGLLzYhZmNWmZmZYYMDAwMAjZmYmBAGD"
}
```
:::

#### Spec Tree

- [[talent:101841]] together with [[talent:101828]] deals massive AoE damage.
- [[talent:101813]]
  
  - [[spell:188196]] and [[talent:127856]] deals 20% increased damage.
  - While [[talent:114291]] or [[talent:101824@FAQAQSfB]] is active, [[spell:115356]] automatically consumes up to 5 [[spell:187880]] to cast a [[spell:188196]] or [[talent:127856]], whichever was most recently casted.
- [[talent:101809]]
  
  - Proc that massively empowers your [[spell:60103]].

#### Hero Talents

- [[talent:117476@FAQARdhA]]
  
  - After using [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]], your next [[spell:60103]] will trigger [[spell:201900]].
- [[talent:135984@AJwBBA]]
  
  - Extension of [[talent:101809]] and passive damage increase.

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍[[spell:470053]] causes your primary target to erupt in a [[talent:136176]] every 2 seconds for 6 seconds. [[talent:136176]] deals 200% increased damage to the primary target of your [[spell:470053]].
- **4-Set: ‍**[[talent:136176]] reduces the cooldown of [[talent:101840@FAQAVwxE]] by 2 seconds and increases the damage of your next [[talent:101840@FAQAVwxE]] by 8%, stacking up to 5 times.

### Single-Target

:::tabs
:::tab [[talent:123381]]
### Opener

- Your goal is to use your [[spell:470057]] and then use your burst with [[spell:114049]] and continue your rotation from there.

:::rotation **Enhancement Shaman** [[talent:123381]] single-target opener in Raids
```json
{
  "source_code": "I0CcFIUKscAAAAAACNYvBAAAAEQAc66AAAAAAIk4dLQBIgCnCHAAAAAACxpwBA"
}
```
1. [[spell:470057]]
2. [[spell:114051]]  [[item:241308]]
3. [[spell:187874]]
4. [[spell:115356]]
5. [[spell:115356]]
:::

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:101840]] during [[talent:114291@FAgAb2dB51uB]].
2. Cast [[spell:115356]] during [[talent:114291@FAgAb2dB51uB]].
3. Cast [[talent:101824@FAgAQSfB3HAB]].
4. Cast [[talent:114291@FAgAb2dB51uB]].
5. Cast [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] at 9+ [[spell:187880]].
6. Cast [[spell:188196]] at 9+ [[spell:187880]].
7. Cast [[talent:101840]]
8. Cast [[spell:17364]] if you have 2 charges.
9. Cast [[spell:60103]]
10. Cast [[spell:17364]].
11. Cast [[spell:470057]].
12. Cast [[spell:196840]].

:::

:::tab [[talent:123379]]
### Opener

:::rotation **Enhancement Shaman** [[talent:123379]] single-target opener in Raids
```json
{
  "source_code": "I0F2HIUKscAAAAAAC588GUkAKUmUBMFUBcaLBE1FCQwZCk4eCUHFDoRDHwRDH8vhScQAAEQAc66AAEQMMAW3FAQAIQgXCkAEIcs6AEQAoI0_VKBAAAAACds6"
}
```
1. [[spell:470057]]
2. [[spell:455630]]  [[item:241308]]
3. [[spell:384352]]
4. [[spell:197214]]
5. [[spell:60103]]
6. [[spell:1218047]]
7. [[spell:60103]]
:::

- Always cast [[spell:60103]] during [[spell:201900]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wB_boEHEA]].
2. Cast [[spell:384352]].
3. Cast [[spell:1218047]] at 10 [[spell:187880]] if  is about to run out.
4. Cast [[spell:188196]] at 10 [[spell:187880]].
5. Cast [[spell:470411]] if it is not up on your target.
6. Cast [[spell:60103]]
7. Cast [[spell:17364]].
8. Cast [[spell:188196]] at 9+ [[spell:187880]].
9. Cast [[spell:196840]].

:::

:::

### Multi-Target

:::tabs
:::tab [[talent:123381]]
### Opener

- Your goal is to use your [[spell:470057]] and then use your burst with [[spell:114049]] and continue your rotation from there.

:::rotation **Enhancement Shaman** 2+ Target opener in Raids
```json
{
  "source_code": "I0CcFIUKscAAAAAACNYvBAAAAEQAc66AAAAAAIk4dLQBIgCnCHAAAAAACxpwBA"
}
```
1. [[spell:470057]]
2. [[spell:114051]]  [[item:241308]]
3. [[spell:187874]]
4. [[spell:115356]]
5. [[spell:115356]]
:::

- [[talent:101840]] spends your [[spell:65986]] and does good damage itself so make sure to use it as much as possible in your [[spell:114051]] or [[spell:384352]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[talent:101840]] during [[talent:114291@FAgAb2dB51uB]].
2. Cast [[spell:115356]] during [[talent:114291@FAgAb2dB51uB]].
3. Cast [[talent:101824@FAgAQSfB3HAB]].
4. Cast [[talent:114291@FAgAb2dB51uB]].
5. Cast [[spell:454009@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]] at 9+ [[spell:187880]].
6. Cast [[spell:188196]] at 9+ [[spell:187880]].
7. Cast [[talent:101840]]
8. Cast [[spell:17364]] if you have 2 charges.
9. Cast [[spell:60103]]
10. Cast [[spell:17364]].
11. Cast [[spell:470057]].
12. Cast [[spell:196840]].

:::

:::tab [[talent:123379]]
### Opener

:::rotation **Enhancement Shaman** [[talent:123379]] multi-target opener in Raids
```json
{
  "source_code": "I0F2HIUKscAAAAAAC588GUkAKUmUBMFUBcaLBE1FCQwZCk4eCUHFDoRDHwRDH8vhScQAAEQAc66AAEQMMAW3FAQAIQgXCkAEIcs6AEQAoI0_VKBAAAAACds6"
}
```
1. [[spell:470057]]
2. [[spell:455630]]  [[item:241308]]
3. [[spell:384352]]
4. [[spell:197214]]
5. [[spell:60103]]
6. [[spell:1218047]]
7. [[spell:60103]]
:::

- Make sure you spread [[spell:470411]] before casting [[talent:101830@AJwBBA]].
- Fill with [[talent:101840@FAQAr1dB]] during [[talent:114291@FAgAb2dB51uB]].

### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wB_boEHEA]].
2. Cast [[spell:384352]].
3. Cast [[spell:1218047]] at 10 [[spell:187880]] if  is about to run out.
4. Cast [[spell:188196]] at 10 [[spell:187880]].
5. Cast [[spell:470411]] if it is not up on your target.
6. Cast [[spell:60103]]
7. Cast [[spell:17364]].
8. Cast [[spell:188196]] at 9+ [[spell:187880]].
9. Cast [[spell:196840]].

:::

:::

## Deep Dive

### Using Chain Lightning vs. Lightning Bolt

Using your [[spell:188443]] becomes better at 2 or more targets. If there is a priority target that needs to die use [[spell:188196]] on it instead.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents [[talent:123379]] **Enhancement Shaman** Nek'Zali talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Entombed Sentinels
:::talents [[talent:123379]] **Enhancement Shaman** Entombed Sentinels talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Lost Explorers
:::talents [[talent:123379]] **Enhancement Shaman** Lost Explorers talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Vashnik
:::talents [[talent:123379]] **Enhancement Shaman Vashnik** talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Sszorak
:::talents [[talent:123379]] **Enhancement Shaman** Sszorak talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Twin Fangs
:::talents [[talent:123379]] **Enhancement Shaman** Twin Fangs talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Coiled Altar
:::talents [[talent:123379]] **Enhancement Shaman** Coiled Altar talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Ula'tek
:::talents [[talent:123379]] **Enhancement Shaman** Ula'tek talents in Raids
```json
{
  "source_code": "CeQAx6A1Q-GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA",
  "code": "CeQAx6A1Q+GD0hGLZqug7opVfMzMzgZmZmZmhZmZAAAAAAAAAsBYzMG2ILwMM0gFAmlZMjxyyM2YmZbsMzMzwwYGAgZYMzYGBmZwgxA"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents [[talent:123379]] **Enhancement Shaman** Nymrissa Wavecaller talents in Raids
```json
{
  "source_code": "CeQAzgeAFxuEqbGMnx9WPPTYVOzMzYMzMzMzMMzYAAAAAAAAAshNstNjZmtFNLbDzwMTDWAYWmxMGLLzAzMGLzMzMjhxMAAzwYmhZiZmZGMYMA",
  "code": "CeQAzgeAFxuEqbGMnx9WPPTYVOzMzYMzMzMzMMzYAAAAAAAAAshNstNjZmtFNLbDzwMTDWAYWmxMGLLzAzMGLzMzMjhxMAAzwYmhZiZmZGMYMA"
}
```
:::

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Enhancement Shaman**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Enhancement Shaman** Stat Priorities in Raid
```json
{
  "source_code": "HoAJFMAJxACKBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 精通 ＞ 暴击 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271483@DiQAAYQAnk7cVrTOC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAYQA8z6wPrTOCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271481@DgQAAYQAXk7kjAOF]] | Tier / Catalyst |
| Cloak | [[item:239656@FgQAAYQAno6gBwzt1sUA]] | Crafting |
| Chest | [[item:271876@DARAAYQAJk7kjAMWDWB]] | Tier / Catalyst |
| Wrist | [[item:244584@DiQAAYQAYA8wPrzt1sUA]] | Crafting |
| Gloves | [[item:271484@BgQAAYQA5IgTBA]] | Tier / Catalyst |
| Belt | [[item:268254@BiQAAYQA8z6kjAOF]] | Vashnik |
| Legs | [[item:271482@DgQAAYQAFo6kjAOF]] | Tier / Catalyst |
| Boots | [[item:268233@DgQAAYQAxj7kjAOF]] | Sszorak |
| Ring 1 | [[item:268249@DiQAAYQA1j7wPrTOC4UA]] | Vashnik |
| Ring 2 | [[item:252258@DiQAAYQA1j7wPrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270175@AgwAAkjAYFQBAEgTXIA]] | Ula'tek |
| Trinket 2 | [[item:270173@AgQAAIoAYFA]] | Coiled Altar |
| Main-Hand | [[item:268209@AgQAAIoAYFA]] | Ula'tek |
| Off-Hand | [[item:251224@AgQAAIoAOFA]] | The Blinding Vale |

:::

:::tab Farmable Alternatives
Below, you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251220@AgQAAIoABFA]] | Voidscar Arena |
| Neck | [[item:251142@AgQAAIoABFA]] | Murder Row |
| Shoulder | [[item:239049@AgQAAIoABFA]] | Kings' Rest |
| Cloak | [[item:251190@AgQAAIoABFA]] | The Blinding Vale |
| Chest | [[item:251233@AgQAAIoABFA]] | Voidscar Arena |
| Wrist | [[item:251200@AgQAAIoABFA]] | The Blinding Vale |
| Gloves | [[item:160213@AgQAAIoABFA]] | Kings' Rest |
| Belt | [[item:251228@AgQAAIoABFA]] | Voidscar Arena |
| Legs | [[item:159375@AgQAAIoABFA]] | Temple of Sethraliss |
| Boots | [[item:159388@AgQAAIoABFA]] | Temple of Sethraliss |
| Ring 1 | [[item:252258@AgQAAIoABFA]] | Voidscar Arena |
| Ring 2 | [[item:273792@AgQAAIoABFA]] | Altar of Fangs |
| Trinket 1 | [[item:250225@AgQAAIoABFA]] | Voidscar Arena |
| Trinket 2 | [[item:273796@AgQAAIoABFA]] | Altar of Fangs |
| Main-Hand | [[item:251224@AgQAAIoAOFA]] | Den of Nalorakk |
| Off-Hand | [[item:251224@AgQAAIoAOFA]] | Den of Nalorakk |

:::

:::

### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on each boss fight.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270173@AgQAAIoAYFA]]  <br>[[item:270175@AgwAAkjAYFQBAEgTXIA]]  <br>[[item:273796@AgQAAIoABFA]] |
| **A-Tier** | [[item:270164@BgQAAYQA5IgTBA]] |
| **B-Tier** | [[item:250225@AgQAAIoABFA]]  <br>[[item:250215@AgQAAIoABFA]] |
| **C-Tier** | [[item:193757@AgQAAIoABFA]] |
| **Junkyard** | [[item:273797@AgQAAIoABFA]] |

### Embellishments

- 2x [[item:240166]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]]
  - [[item:241322]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[spell:33757]]
  
  
  
  - [[spell:318038]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240892]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@BAAAAYQA]]  <br>[[item:244007]] |
| --- | --- |
| Shoulders | [[item:243991]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAYQA]] |
| Waist | [[item:275707@BAAAAYQA]] |
| Legs | [[item:244641]] |
| Boots | [[item:243953@BAAAAYQA]] |
| Ring 1 | [[item:243957]] |
| Ring 2 | [[item:243957]] |
| Main Hand | [[item:244031]] |
| Off Hand | [[item:244031]] |

:::

:::column
:::gear **Enhancement Shaman** Enchantments in Raid
```json
{
  "source_code": "IwFZHEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NAREIgyP5OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
| 副手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAYQA]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Enhancement Shaman** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Strong DPS racial that lines up poorly with [[spell:114051]].
  - Reduce the duration of movement-impairing effects by 20%.
- [[spell:33702]] *-- Orc* 
  
  - Good DPS racial that lines up with [[spell:114051]].
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:274738]] *-- Mag'har Orc* 
  
  - Good DPS racial that lines up with [[spell:114051]].
  - Reduces the duration of poisons, diseases and curses by 10%.
- [[spell:287712]] -- Kul'Tiran
  
  - Stuns your target for 3 sec and knocks them back, not the coolest for raiding
  - 1% Versatility which makes this race decent for DPS.

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses.

If there is a good use of any races utility, it's always recommended to play it, but Mag'har Orc is the overall best DPS racial currently. I prefer Goblin as its a small dps loss and [[spell:69070]] can save you from some bad situations.

## Macros

Discover recommended macros for **Enhancement** Shamans during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:108287]]** -- *Casts [[spell:108287]] on your cursor without confirmation.*

```wow-macro
#showtooltip
/cast [@cursor] Totemic Projection
```

**[[spell:192077]] -- *Casts [[spell:192077]] on your cursor without confirmation.***

```wow-macro
#showtooltip
/cast [@cursor] Wind Rush Totem
```

:::

:::details Mouseover Macros
**[[spell:188389]]** -- *Casts [[spell:188389]] on your mouseover target.*

```wow-macro
#showtooltip Flame Shock
/cast [@mouseover, exists] Flame Shock; Flame Shock
```

**Focus Mouseover** -- *Puts whatever you mouseover on focus*

```wow-macro
/focus mouseover
```

:::

:::details Utility Macros
**[[spell:51514]]**  -- *Casts [[spell:51514]] on your mouseover or target.*

```wow-macro
#showtooltip Hex
/cast [@mouseover, exists] Hex; Hex
```

**[[spell:8004]]** *-- Casts [[spell:8004]]* quickly on an ally by mouseovering or targeting.

```wow-macro
#showtooltip Healing surge
/cast [@mouseover, exists] Healing surge; Healing surge
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Enhancement Shaman**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![Enhancement Shaman Raid](<https://assets-ng.maxroll.gg/wordpress/wolf-enha-raid-1-1024x681.webp>)

**Enhancement Shaman** Interface in Raids

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **EllesmereUI***-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater**  -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring.

:::

:::

## Changes this Patch

:::accordion
:::details **Patch 12.**1
*Developers' notes: We’re happy with Enhancement Shaman’s gameplay going into Curse of Ula’tek. Our goal with these changes is to preserve that gameplay while improving performance outside of cooldown windows, where damage can feel weak. Strong interactions between Windfury procs and Maelstrom Weapon generation were making it difficult for the downtime between cooldowns to breathe.*

- Melee damage increased by 15%.
- Lightning Bolt damage increased by 20%.
- Chain Lightning damage increased by 20%.
- Lava Lash damage increased by 15%.
- Stormstrike damage increased by 15%.
- Doom Winds now increases the chance of Windfury Weapon activating by 50% (was 100%).
- Healing Surge healing increased by 25%.
- Earth Shield healing increased by 25%.
- Healing Stream Totem healing increased by 25%.
- Fixed an issue causing the Elemental Tempo to incorrectly increase the damage of Stormstrike and Windstrike.

**Hero Talents**

- Stormbringer
  
  - Tempest main target damage reduced by 10%.
  - Tempest secondary target damage reduced by 30%.
  - Fixed an issue where a single Arc Discharge effect could increase the damage of multiple Chain Lightning spell casts, such as from Thorim's Invocation and Ride the Lightning.
- Totemic
  
  - Surging Totem Tremor damage reduced by 15%.
  - Surging Totem Surging Bolt damage reduced by 10%.
  - Fixed an issue where Surging Bolts from Surging Totem that were created from casting Chain Lightning were all sent to the last target hit by Chain Lightning, rather than the primary target of Chain Lightning.

:::

:::

:::accordion
:::details **Patch 12.0**
- **Enhancement Tempest has been updated – Each Maelstrom Weapon spent has a 2% chance to upgrade your next Lightning Bolt to Tempest.**
- **Tempest single target damage increased by 15%.**
- **Tempest secondary target damage reduced by 25%.**
- **Awakening Storm has been updated – Stormstrike has a small chance to upgrade your next Lightning Bolt to Tempest.**
- **Rolling Thunder now causes Doom Winds to summon a Nature Feral Spirit for 12 seconds.**
- **Arc Discharge now only affects Chain Lightning and now increases its damage by 20% (was additionally affecting Lightning Bolt with 40% increased damage).**
- **Totemic New Talent: Totemic Momentum Enhancement: Each Maelstrom Weapon spent increases the duration of an active Hot Hand by 0.2 seconds.**
- **Enhancement New Talent: Surge Catalyst – After casting Surging Totem, your next Lava Lash casts again at 150% effectiveness.**
- **New Talent: Elemental Attunement – Mastery increased by 2%.**
- **Lively Totems has been updated – Lava Lash and Voltaic Blaze cause your Searing Totems to shoot a Searing Volley.**
- **Whirling Elements has been updated – Earth: Now causes your next Sundering to deal 100% increased damage and summons a Searing Totem.**
- **Fire: Lava Lash grants you Hot Hand for 8 seconds (was 6 seconds). Fire Nova no longer grants you Hot Hand.**
- **Surging Totem Tremor damage increased by 115%.**
- **Surging Totem cooldown increased to 65 seconds.**
- **Surging Bolt damage increased by 75%.**
- **Splitstream now casts a Sundering at 80% effectiveness (was 50%).**
- **Earthsurge now causes a Tremor at 125% effectiveness (was 100%).**

:::

:::

## FAQ

:::accordion
:::details Q: When is [[talent:123379]] / [[talent:123381]] played?
A: [[talent:123379]] currently is the more cleave focused hero tree where you are not as focused on [[talent:114291]], and instead you focus on [[talent:101809]] and your [[spell:455630@FJgClJVATBVAn2SARdhAEcmAJunA1RxAa0wBc0wBo3tAHEA]].

[[talent:123381]] is currently better on ST and more consistent AoE, such as Mythic+. You focus a lot on spending [[talent:101804@FAQAHldB]] to trigger more [[talent:117489@FAgAo3tAHldB]].

:::

:::

---

### Credits

Written By: **Stove**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-07** Updated for patch 12.1

**2026-02-23** Updated for patch 12.0.7

**2026-01-15** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7

**2025-10-08** Updated for patch 11.2.5



:::
