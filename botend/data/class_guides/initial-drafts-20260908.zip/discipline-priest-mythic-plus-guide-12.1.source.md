Welcome to the **Discipline Priest** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 4/5 · Strong

Damage · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 1/5 · Subpar



:::

:::

:::column
:::gear **Discipline Priest** Mythic+ Best in Slot Gear
```json
{
  "source_code": "JQpAICQA3_fABIgJEIIEBAw74OA_sOgF2kjAYFQApfBBAERAAcVrBQBBMWTBUgUwkQgAIUAA1k7ACKgTBcbpDEgxJIBAJkgEwMQ1DEQ4XQAgIEAA8zaBkQQACnQIIthqDkjAOFAGVPQAffBBCgQAA8QAzgDWBEAIoOAhIEAAno6AYAcArB3t1sUABQMJEAACFAggCgVATfBBBAYLEIICBAwL5GQIBsHDBIW2DojEAgxVfQAAIEAAF4BAS1BDE09FNgBKYFQA0LCBCgQAAUQD7hVCAPABgEAA0B8AYA8AAAAAAAAA3WzSBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240892]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240892]] |
| 肩部 | [[item:271553]] | [[item:244021]] |
| 胸部 | [[item:271558]] | [[item:243977]] |
| 腰部 | [[item:268257]] | [[item:240892]] |
| 腿部 | [[item:271554]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240892]] · [[item:240167]] · [[item:245784]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:273792]] | [[item:240892]] · [[item:244015]] |
| 戒指二 | [[item:252258]] | [[item:240892]] · [[item:244015]] |
| 饰品一 | [[item:270167]] |  |
| 饰品二 | [[item:270162]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243973]] |
| 副手 | [[item:245769]] | [[item:245876]] · [[item:245784]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Discipline Priest**, you have access to Master the Darkness, which makes your penance have a chance to transform your [[spell:17]] into [[spell:1253593]].

**Rank 2** and **Rank 3** both increase your Shadow damage and Atonement healing by 3% each.

**Rank** 4 makes [[spell:1253593]] reflect 25% of the absorbed damage.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-discipline-mxr.webp>)

Master of Darkness

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103712]]
    
    - Your penance now also applies a dot.
  - [[talent:103718]]
    
    - Each successive Penance bolt during a channel increases its damage and healing.
- **Removed**
  
  - [[spell:34433]]
    
    - Not an active anymore, which results in less spikey bursts.
  - [[spell:314867]]
    
    - During your cooldowns you wont have acess to a shadow version of penance anymore.

## Hero Talents



### [[talent:123288]]

- Every [[spell:8092]] opens a [[spell:447444]] that does a lot of damage and gives you the following buffs and benefits:
  
  - [[spell:585]] is transformed into [[spell:450405]] and its [[spell:81749]] healing is increased by an additional 100%.
  
  
  
  - [[spell:449880]]
    
    - Increases your [[spell:81749]] healing massively.
  - [[spell:451018]]
    
    - Increased Movement Speed.
  - When [[spell:447444]] ends it collapses and does a lot of damage via [[spell:448403]].




### [[talent:123290]]

- [[talent:123290]] greatly enhances your penance through various nodes:
  
  1. [[talent:117286@FAQAIdhA]]
     
     - Your Penance has 2 charges
  2. [[talent:117276@FAQAIdhA]]
     
     - Increases the first bolt of each Penance.
  3. [[talent:117290]]
     
     - Penance fires extra bolts at an enemy if you heal with it and if you damage with it it fires extra bolts to heal allies.





## Talents



### General

:::talents **Discipline Priest** General Mythic+ Talents
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### When to use this Spec

This is your default loadout going into any dungeon as it specializes in survivability. You have to adjust the class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, Dungeon specific talent loadouts are available in the Dungeons section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[talent:103698]]
  
  - Allows you to cast a very powerful [[spell:17]] after each [[spell:47540]].
- [[spell:373180]]
  
  - Provides a new burst tool, as it transforms each [[spell:194509]] into an output cooldown.
- [[spell:373035]]
  
  - This talent grants an extra charge of [[spell:33206]] and reduces its cooldown with each cast of [[spell:17]]. This allows more frequent use of [[spell:33206]], greatly easing difficult encounters.

##### Class Tree

- [[spell:459559]]
  
  - Increases the range of your spells to 46 yards, giving you a significant advantage. This allows you to outrange certain Mythic+ mechanics or continue healing your teammates even if the party spreads out.
- [[spell:109186]]
  
  - The best recovery tool for Discipline Priests, because Flash Heal is your strongest direct heal outside of a friendly Penance. This talent helps significantly with mana management and mobility.
- [[spell:336897]]
  
  - You also gain the effects of [[spell:10060]] when you cast it on an ally.
- [[spell:193063]]
  
  - In combination with [[spell:368276]] and [[spell:109186]], this talent provides you with an easily accessible 10% damage reduction.
- [[talent:103835]]
  
  - Adds a new but weak defensive ability to the Priest class toolkit. Together with [[spell:193063]], it builds a reliable life insurance for yourself!





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** ‍[[spell:47540]] damage and healing increased by 20%. Casting ‍[[spell:47540]] reduces the cooldown of ‍[[spell:8092]] by 2 seconds.
- **4-Set:** After casting ‍[[spell:8092]], your next ‍[[spell:17]] or ‍[[spell:1253593]] absorbs 25% more damage.

### Priority List

1. Keep [[spell:589]] on your target.
2. Cast [[spell:8092]] on Cooldown.
3. Cast [[spell:47540]] on Cooldown.
4. Cast [[spell:1253593]] if at 2 stacks.
5. Cast [[spell:194509]] at 2 stacks.
6. Cast [[spell:585]].

### Cooldowns

#### Ultimate Penitence

- This is your strongest button to counter any situation as long as you target an enemy. This can also be used as a defensive to survive a oneshot mechanic and heal your group for a substantial amount.

## Deep Dive

### Min maxing Power Infusion

- While [[spell:10060]] is **your** spell, the optimal usage is to disregard yourself and instead fully focus on your teammates. To achieve that, you need to see your party members' offensive cooldown uptime. It is recommended to simply communicate with them and ask for them to request at the exact time they want it!

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Discipline Priest** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[spell:586]].




### Den of Nalorakk

:::talents **Discipline Priest** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]].
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
  
  
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Discipline Priest** Mythic+ Build in Murder Row
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Discipline Priest** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Discipline Priest** Mythic+ Build in Voidscar Arena
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Discipline Priest** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Discipline Priest** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Discipline Priest** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CCQA14bH_XF5B_Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM",
  "code": "CCQA14bH/XF5B/Zp2PVV69Qa7CDsYGWYMmZGmZzsNzMzMzMDAAAAAAAAAghZZGMzMDzYmxgpZiBYmFMEGzyAMGsAAAjZGjBzAMzMTwM"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got adjusted going into **Midnight Season 1** making it more beginner friendly:

- +2 Affixes
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  
  
  
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed
- +7 Affix -- Alternates between each other on a weekly basis
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  
  
  
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Discipline Priest**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:8122]] to interrupt as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - There is nothing special you can do to help with this affix.
- Xal'atath's Bargain: Oblivion
  
  - Keep an eye behind you and collect any orbs that fly into melee range. Make sure to intercept them before they hit any enemies.
- Xal'atath's Bargain: Devour
  
  - You can remove all debuffs at once with [[spell:32375]]. If [[spell:32375]] is on cooldown make sure to instantly single dispel one healing absorb debuff!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Discipline Priest**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "IoAJFUAJxACKBQwABA"
}
```
**智力 ＞ 急速 ≫ 精通 ≥ 暴击 ＞ 全能**
:::

> The conclusion here is that you want to equip the highest item level generally.

All secondary stats are affected by **diminishing returns**. [Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to learn more!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful Leech is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/6o58gMo-1024x362.png>)

Warcraftlogs

## Gear



### Best in Slot

Due to the way stat weights work for **Discipline Priests**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@BARAAAQAWYTOCgVA]] | Ula'tek |
| Neck | [[item:268265@BERAAAQAX16wPrDj1kjAYFA]] | Ula'tek |
| Shoulder | [[item:239031@AgQAAIoAOFA]] (Catalyze to Tier) | Temple |
| Cloak | [[item:268253@BgQAAAQACKAWBA]] | Coiled Altar |
| Chest | [[item:251139@AgQAAIoAOFA]] (Catalyze to Tier) | Murder Row |
| Wrist | [[item:239648@FiQAAAQAno6gBwD_sO3WzSB]] | Crafting |
| Gloves | [[item:271556@BgQAAAQACKAWBA]] | Tier/Catalyst |
| Belt | [[item:268257@BiQAAAQA8z6IoAOF]] | Crafting |
| Legs | [[item:251160@AgQAAIoAOFA]] (Catalyze to Tier) | Den of Nalorakk |
| Boots | [[item:268255@DgQAAAQAPk7IoAYF]] | Coiled Altar |
| Ring 1 | [[item:273792@DiQAAAQAvk7wPrjgC4UA]] | Altar of Fangs |
| Ring 2 | [[item:252258@DiQAAAQAvk7wPrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270162@BgQAAAQACKgTBA]] | Nek'Zali |
| Trinket 2 | [[item:270167@BgQAAAQA5IgTBA]] | Nymrissa |
| Weapon | [[item:271092@DgQAAAQAFk7IoAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FASAAAQA0B8gBwDAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Mythic+ from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251232@AgQAAIoABFA]] | Voidscar Arena |
| Neck | [[item:251173@AgQAAIoABFA]] | Den of Nalorakk |
| Shoulder | [[item:239031@AgQAA8rBBFA]] | Temple |
| Cloak | [[item:251190@AgQAAIoABFA]] | Blinding Vale |
| Chest | [[item:251139@AgQAAIoABFA]] | Murder Row |
| Wrist | [[item:251127@AgQAAIoABFA]] | Murder Row |
| Gloves | [[item:159247@AgQAAIoABFA]] | Temple |
| Belt | [[item:193691@AgQAAIoABFA]] | Ruby Life Pools |
| Legs | [[item:251160@AgQAAIoABFA]] | Den of Nalorakk |
| Boots | [[item:251219@AgQAAIoABFA]] | Voidscar Arena |
| Ring 1 | [[item:252258@DiQAAkGAvk7wPrjgCEUA]] | Voidscar Arena |
| Ring 2 | [[item:273792@DiQAAAQAvk7wPrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | Blinding Vale |
| Trinket 2 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Two-Hand Weapon | [[item:159636@AgQAAIoABFA]] | Tempel |
| One-Hand Weapon | [[item:273778@AgQAAIoABFA]] | Altar of Fangs |
| Off-Hand | [[item:251191@AgQAAIoABFA]] | Blinding Vale |





### Trinkets

Below you can find active and passive rankings of available trinkets. Do note that some trinkets are better than others depending on each boss fight.

| Rank |  |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]]  <br>[[item:270162@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:245876]] 
  
  - Very strong stat stick that gives you a high amount of a secondary stat depending on what target you hit.
- [[item:240167]]
  
  - Very strong stat stick.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241288]]
  - [[item:241300]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAEEAaB]]
- **Sockets**
  
  - [[item:240892]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@BAAAAAQA]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:243977]] |
| Wrist | [[item:275707@BAAAAAQA]] |
| Belt | [[item:275707@BAAAAAQA]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:244015@BAAAAAQA]] |
| Ring 2 | [[item:244015@BAAAAAQA]] |
| Weapon | [[item:243973@BAAAAAQA]] |

:::

:::column
:::gear **Discipline Priest** Enchantments
```json
{
  "source_code": "IQFZAEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAAv0AEo8SuDAAAAAQAFk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:243973]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAAQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Discipline Priest** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:20594]] -- Dwarf
  
  - Removes all magic, bleed, poison, and disease effects and reduces physical damage taken.
  -
- [[spell:58984]] -- Night Elf
  
  - Turns you invisible, any action, taking damage, or moving breaks this effect.
  - Use-cases:
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].

### Recommendation:

It is highly recommended to play a Dwarf this season! The higher the keys you run, the more essential [[spell:65116]] becomes in certain dungeons, such as Tempel of Sethraliss and others.

## Macros

Discover recommended macros for **Discipline Priest** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this Discipline Priest Raid Guide are available as mouseover macros for your convenience!

[[spell:47540]]

```wow-macro
/cast [@mouseover, help] Penance; Penance
```

[[spell:17]]

```wow-macro
/cast [@mouseover, help] Power Word: Shield; Power Word: Shield
```

[[spell:194509]]

```wow-macro
/cast [@mouseover, help] Power Word: Radiance; Power Word: Radiance
```

[[spell:139]]

```wow-macro
/cast [@mouseover, help] Renew; Renew
```

[[spell:2061]]

```wow-macro
/cast [@mouseover, help] Flash Heal; Flash Heal
```

[[spell:10060]]

```wow-macro
/cast [@mouseover,exists] Power Infusion; Power Infusion
```

[[spell:73325]]

```wow-macro
/cast [@mouseover, help] Leap of Faith; Leap of Faith
```

[[spell:33206]]

```wow-macro
/cast [@mouseover, help] Pain Suppression; Pain Suppression
```

:::

:::details Recommended Macros
If you press shift while using this macro you get the [[spell:121536]] automatically placed under you, skipping the control click.

```wow-macro
/cast [mod:shift, @player] Angelic Feather; Angelic Feather
```

Replace your [[spell:527]] macro if you wish. This macro makes it so that if you target an enemy you purge and if you target an ally you dispel, saving you a keybind.

```wow-macro
#showtooltip Purify
/use [@mouseover, help] Purify; [harm] Dispel Magic; [noharm] Purify
```

Your [[spell:32375]] instantly goes off when you press the button without having to confirm click, use with caution.

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

A nice little Priest only macro, if you know you know.

```wow-macro
/cast [nomod] Levitate
/cancelaura [mod:shift] Levitate
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Discipline Priest**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/e3V7I8v-1024x576.webp>)

**Discipline Priest** Mythic+

:::accordion
:::details Addons
- EllesmereUI -- Everything
  
  - Addon to upgrade Blizzards very own UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Discipline
  
  - Developers' notes: For Discipline in Curse of Ula'tek, our changes are aimed at reducing the spec's reliance on procs for effective healing, improving sources of consistent damage, and improving Hero talent balance. We felt the spec was too reliant on Shadow Mend and Void Shield procs for effective healing, so we're updating Shadow Mend to be a passive upgrade to Flash Heal and adding a deterministic way to gain access to Void Shield. Additionally, Smite contributes a low amount of damage despite being frequently cast, so we're increasing its damage and updating the talent tree for easier access to Greater Smite.
- New Talent: Grim Deliverance – Shadow Mend heals for 30% more and applies Atonement for an additional 4 seconds, but its cast time is increased by 0.5 seconds.
- Shadow Mend's chance to trigger is no longer based on Shadow Word: Pain damage and has been redesigned to a passive upgrade – Flash Heal is upgraded to Shadow Mend, a stronger heal with a higher mana cost.
- Apex Talent: Master the Darkness (Rank 3) has been updated – Mind Blast now upgrades your next Power Word: Shield to Void Shield. Void Shield's chance to trigger from Penance reduced to 15% (was 33%). Void Shield absorption reduced by 28%.
- Apex Talent: Master the Darkness can now accumulate up to 2 charges.
- All healing and absorption increased by 10%.
- Atonement heals for 32% of damage done (was 30%).
- Flash Heal healing increased by 25%.
- Smite damage increased by 40%.
- Inescapable Torment damage reduced by 30%.
- Penance no longer applies Atonement when cast on an ally.
  
  - *Developers' notes: We updated Penance to apply Atonement going into Midnight but have felt this has not been playing well as it causes too much friction between casting Penance on allies that need healing, allies that need Atonement applied, and enemies you want to deal damage to.*
- Ultimate Penitence damage and healing increased by 30%.
- Greater Smite duration increased to 4 seconds (was 2 seconds) and is now a 1-point talent.
- Hero Talents
  
  - Oracle
    
    - Unfolding Vision has been redesigned – When Power Word: Shield or Void Shield expires with absorption remaining, it jumps to a nearby injured ally instead. Can only happen once per shield.
  - Voidweaver
    
    - Void Blast damage increased by 25%.
    - Voidwraith damage increased by 30%.
    - Void Infusion now increases Atonement healing from Void Blast and Penance by 75% while Entropic Rift is active (was 50%).

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:33206]] as your own defensive cooldown.

:::

:::details Q: Why do I keep running out of mana?
A: You are missing to many global cooldowns, and don't have enough [[spell:314867]] uptime.

:::

:::

---

### Credits

Written By: **Rycn**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-07** Guide Updated for patch 12.1

**2026-06-19** Guide Updated for patch 12.0.7

**2026-05-01** Guide Updated for patch 12.0.5

**2026-01-18** Guide Updated for patch 12.0

**2025-10-07** Guide Updated for patch 11.2.5

**2025-07-29** Guide Updated for patch 11.2

**2025-06-18** Guide Updated for patch 11.1.7

**2025-04-21** Guide Updated for patch 11.1.5

**2025-02-24** Guide Updated for patch 11.1

**2024-12-17** Guide Updated for patch 11.0.7

**2024-10-20** Guide Updated for patch 11.0.5

**2024-10-12** Guide Updated.

**2024-08-22** Adjusted Embellishments in BiS Paperdoll to align with recommended Embellishments in the Gear Section.

**2024-08-17** Guide Written for patch 11.0.2



:::
