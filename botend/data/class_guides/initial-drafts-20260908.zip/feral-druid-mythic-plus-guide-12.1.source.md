Welcome to the **Feral Druid** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 3/5 · Average

Utility · 5/5 · Strong

Survivability · 5/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Feral Druid** Bis List Mythic+
```json
{
  "source_code": "JgoAwz1ZAc__AEwAmQggQEAAnk7AH16A5IwF2gVABk-FEAQEBAgEtOg-sOAj1kjAYFQAmSCBCgQAAcRuDkjAOFQArSCBCgQAAkQuDkjAOFQAgfBBAiQAAoQrDkjAYFQAnSSBeQQo7mwDAl1uDYAIBAAGAPwJqOQ84OAAFEAI3WzSBEAY7OAhVsBBC0qLbAAGpSCBAgQAAUAYgk9FEIICBAQ94GAJFIBCil9AZIBACGwkE01HFADACGQgA8VAMAwAFwAIFAQAxchAB09FF4RBMTztXQgAIEAAwqCBWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240967]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240914]] · [[item:240890]] |
| 肩部 | [[item:271526]] | [[item:243991]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240906]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245784]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:273072]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Feral Druid**, you gain access to **Unseen Predator**. This ability provides a chance to trigger an **Unseen Attack** [[spell:1263903]] or [[spell:1263840]].

**Rank 2** gives you 15% damage buff for 5sec whenever  you trigger an **Unseen Attack**.  
**Rank 3:** your [[spell:5217]] now forces your **next 2 generators** to proc an **Unseen Attack**.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-feral-mxr.webp>)

Unseen Predator

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103309@AJwCBA]].
    
    - Now it gives you something depending on the form you are on.
  
  
  
  - [[talent:123794]]
    
    - Amplifies the effect of Mark of the Wild.
- **Class Tree**
  
  - [[talent:103149]]
    
    - Nice talent to do even more Prio Damage on the main target.
  - [[talent:103156]]
    
    - Has big potential.
  - [[talent:134211]] & [[talent:103174]]
    
    - Empower even more [[talent:103175]] to be stronger in ST or become a powerful AoE ability.
  - [[talent:134212]]
    
    - Designed for ST, sadly a bit undertuned right now as you will never pick it in the optimal setup.
  - [[talent:114771]]
    
    - Decent passive that increase either [[spell:1822]] or [[spell:5221]]/[[spell:106785]].
  - [[talent:103164]]
    
    - Have a chance to gain 5 combo points.
  - [[talent:103157]]
    
    - More bleeds damage 10%.
- **Removed**
  
  - [[spell:202028]].
    
    - From doing a lot of damage by itself to just being a [[spell:319439]] trigger, we will miss it for sure.
  - [[spell:319439]].
    
    - We used to have it for years, I think it's nice to finally have it gone. It was annoying in AoE, felt fine on ST. Overall a good change. Does it make the gameplay easier? I guess a tiny bit for newer player to pick up the spec.
  - [[spell:106830]].
    
    - Was mainly a [[spell:319439]] trigger spell.
  - [[spell:108238]].
    
    - Now we have a passive instead ([[talent:128581]]), less control but fewer keybinds.
  - [[spell:391891]].

## Hero Talents

- Both [[talent:123296]] and [[talent:123297]] are very close on single-target to each other.
- On the other hand [[talent:123297]] is a bit ahead for any AoE encounter.
- [[talent:123296]] damage breakdown is more towards bleeds whereas [[talent:123297]] is more focus on [[spell:22568]] damage overall.

### [[talent:123296]]

- Your [[spell:1079]] and [[spell:1822]] have a chance to grow [[spell:439528]] on any affected target.

- Every vine does a DoT effect and debuffs the target with [[talent:117227]].

- Whenever you [[spell:22568]] a target with a vine, you trigger the effect of [[talent:117232]], which also triggers the effect when the vine expires.

- [[talent:117233]] is a good damage boost to all your abilities and is stronger the more mobs you are fighting.

- A nice little passive to [[talent:123296]] is [[talent:117230]], which give you more vine overall.

With Patch 12.0, Blizzard removed our The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:135973@AJwCBA]]
- [[talent:117232@AJwCBA]]
- [[talent:135975@AJwCBA]]

### [[talent:123297]]

- Your auto-attacks have a chance to make your next [[spell:22568]] become [[talent:117206]].
  
  - An empowered [[spell:22568]] that deals damage in an arc in front of you, so make sure to always face as many enemies as possible.

- [[talent:117220]] is applied to every target hit by [[talent:117206]]. 
  
  - [[talent:117220]] can be extended with [[talent:117216]].

- [[talent:117219]] is a nice auto-attack speed boost which procs [[talent:103187]] and [[talent:117206]] more often.

- [[talent:103298]] can be cast in Cat Form with [[talent:117210]].
  
  - You also gain 10% maximum health during the duration with [[talent:117218]].

With Patch 12.0, Blizzard removed our The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:135980@AJwCBA]]
- [[talent:135979@AJwCBA]]
- [[talent:117219@AJwCBA]]

## Talents

### [[talent:123296]]

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### When to use this Spec

Use this spec in higher Mythic+ keys. [[talent:117226]] performs better when enemies stay alive for longer periods of time.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[spell:5217]]
  
  - Increase the damage of all your attacks for their **full** duration.
- [[talent:134211]]
  
  - Does a really strong AoE burst.
- [[spell:391881]]
  
  - Every [[spell:1079]] tick, you have a chance to make your next [[spell:22568]] free and deal the maximum damage.
- [[spell:285381]]
  
  - Applies [[spell:1079]] in AoE.
- [[spell:16864]]
  
  - Your auto attacks have a chance to cause your next [[spell:5221]] or [[spell:213764]] to cost 0 energy.
  
  
  
  - You want [[spell:236068]] up as well to boost its efficacy further.
- [[spell:323764]]
  
  - Use this to cast a bunch of powerful spells on your target.

#### Hero Talents

- [[talent:117233]] 
  
  - Your default pick since [[talent:117234]] is more focused on single-target.
- [[talent:117230]]
  
  - Outperforms [[talent:117229]] in Mythic+.
- [[talent:135974]]
  
  - Does good damage, try to [[spell:22568]] mobs affected by it if you don't lose prio damage.

### [[talent:123297]]

:::talents [[talent:123297]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstAmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstAmZAWYwAAYmBzshB"
}
```
:::

#### When to use this Spec

Use this spec in the low to high Mythic+ keys.[[spell:22568]] will be most of your damage.

#### Talent Adjustments

Listing all the changes within the Class and Spec tree compared to the default build.

##### Spec Tree

- Added
  
  - Nothing.

- Removed
  
  - Nothing.

##### Hero Talents

**Changed** [[talent:123296]] to [[talent:123297]] for more info visit the **Hero Talent** section above.

- [[spell:441824@FJgCzchA1IEARBVA16SAHcmAJunA8QwA9UJB1zwB2zwBLEA]]
  
  - [[talent:117219]] is also fine, it is more single-target but requires you perfect melee uptime which can be rough in real practice.
- [[talent:117213@FJQAfqvELEA]]
  
  - Increase our [[talent:134211]] damage by a lot.
- [[talent:117210]]
  
  - [[talent:117209]] is just worse in every aspect.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** When [[talent:103162]] ends, you deal 10% increased damage for 1 sec for each combo point spent during it..
- **4-Set:** ‍[[talent:103162]] last 10 sec longer.

### Single-Target

#### [[talent:123296]] & [[talent:123297]]

##### Opener

- Your goal as a **Feral Druid** is to cast as many [[spell:22568]] as possible without wasting uptime on your bleeds like [[spell:1079]] and [[spell:1822]]. Below, you can see an example of how your opener looks using the recommended **Mythic+** talent spec.

:::rotation **Feral Druid** Single target opener in Mythic+
```json
{
  "source_code": "I4EeKIwXUAAAAIgHHAAACIQYUAgAHHaACVZMEAAAAAgQ3UwBoAgA0CPBAAgQogFABEABCVWAyQAAAoEEAA"
}
```
1. [[spell:5215]]
2. [[spell:1822]]  [[spell:5217]] · [[spell:106951]]
3. [[spell:274837]]
4. [[spell:1079]]
5. [[spell:323764]]
6. [[spell:22568]]
7. [[spell:5221]]
8. [[spell:22568]]
9. [[spell:5221]]
10. [[spell:22568]]
:::

###### Priority List

This is a general priority you aim to maintain throughout the fight as **Feral Druid**.

1. Cast [[spell:106951]].
2. Cast [[spell:5217]].
3. Cast [[spell:323764]].
4. Cast [[talent:103175]].
5. Keep [[spell:1079]] up.
6. Cast [[spell:22568]].
7. Keep [[spell:1822]] up.
8. Cast [[spell:5221]].

### AoE

#### [[talent:123296]] & [[talent:123297]]

##### Opener

- Below, you can see an example of how your opener looks like as **Feral Druid** using the recommended **mythic+** talent spec.

:::rotation **Feral Druid** Multi target opener in Mythic+
```json
{
  "source_code": "IkFOLIwXUAAAAIgHHAAACIUYBwAKCdLPFAAAC9p-SAQAagTxaRAAAIAtwTAAAIEKYBQABUBCQESoBAAAdgBKhEaAAAAAAIQxaRA"
}
```
1. [[spell:5215]]
2. [[spell:1822]]  [[spell:5217]] · [[spell:343223]]
3. [[spell:1243807]]
4. [[spell:285381]]
5. [[spell:323764]]
6. [[spell:22568]]
7. [[spell:22568]]
8. [[spell:106785]]
9. [[spell:22568]]
10. [[spell:106785]]
11. [[spell:285381]]
:::

###### Priority List

1. Cast [[spell:106951]].
2. Cast [[spell:5217]].
3. Cast [[spell:323764]].
4. Cast [[talent:134211]]
5. Keep [[spell:1079]] up with [[spell:285381]].
6. Cast [[spell:22568]].
7. Keep [[spell:1822]] up on most targets.
8. Cast [[talent:103301@FAQAzchA]].

## Deep dive

### Snapshot

***What is snapshotting?***

The term "snapshotting" refers to a game mechanic where certain abilities capture (or "snapshot") the buffs at the moment they are cast and retain those buffs for their duration.

This is particularly relevant for Damage over Time (DoT) abilities (Bleed for **Feral Druid**), as they continue to deal damage based on the buffs present when they were applied, even if those stats or buffs change or expire.

- **[[spell:5217]]**: Applying [[spell:1079]] or [[spell:1822]] while [[spell:5217]] is active ensures that the bleed benefits from the increased damage throughout the **entire** duration.

- **[[spell:231052]]**: Applying [[spell:1822]] from stealth increases the damage for the **entire** duration.

#### Circle of Life and Death

The **[[spell:400320]]** talent modifies the duration of your DoTs, reducing their overall duration by 20% but increasing their tick rate. Here’s how it affects your DoTs:

- **[[spell:1822]]**: Reduced to **12 seconds**.
- **[[spell:1079]]**: Reduced to 1**9 seconds**.
- **[[spell:155625]]**: Reduced to **14.4 seconds**.

With these new durations, the Pandemic thresholds adjust accordingly:

- **[[spell:1822]]:** You can refresh [[spell:1822]] when there are up to **3.6 seconds** (30% of 12 seconds) remaining, adding this time to the new [[spell:1822]].
- **[[spell:1079]]**: You can refresh [[spell:1079]] when there are up to **5.7 seconds** (30% of 19 seconds) remaining, adding this time to the new [[spell:1079]].
- **[[spell:155625]]:** You can refresh [[spell:155625]] when there are up to **4.3 seconds** (30% of 14.4 seconds) remaining, adding this time to the new [[spell:155625]].

#### Practical Application with Circle of Life and Death

1. **[[spell:1822]]**: If it has 3 seconds left, refreshing it adds the remaining **3 seconds** to the new **12 seconds** duration, making the new duration **15 seconds**.
2. **[[spell:1079]]**: If it has 5 seconds left, refreshing it adds the remaining **5 seconds** to the new **19 seconds** duration, making the new duration **24 seconds**.
3. **[[spell:155625]]**: If it has 4 seconds left, refreshing it adds the remaining **4 seconds** to the new **14.4 seconds duration**, making the new duration **18.4 seconds**.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

### Altar of Fangs

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as shifting into another form.

### Den of Nalorakk

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Prioritize interrupting the one not in melee of the boss since you have a range interrupt.
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root by shifting into another form.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

### Murder Row

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

### The Blinding Vale

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
  
  - Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

### Voidscare arena

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

### Kings' Rest

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

### Ruby Life Pools

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

### Temple of Sethraliss

:::talents [[talent:123296]] **Feral Druid** Mythic+
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLz2MzMz2MLNLzstBmZAWYwAAYmBzshB"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Feral Druid**.

- Xal'atath's Bargain: Ascendant
  
  - Use any of your CCs on as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - Focus all your damage on the **Void Emissary**!
- Xal'atath's Bargain: Devour
  
  - This applies a big heal absorb to you.
- Xal'atath's Bargain: Pulsar
  
  - Collect the orbiting pulsars around other group members!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Feral Druid**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Feral Druid** Mythic+ Stat Priorities
```json
{
  "source_code": "HoAJFMAIxQCKEEQABA"
}
```
**敏捷 ≫ 暴击 ＞ 精通 ＞ 急速 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing. The damage of your pets does not heal you thus **Leech** is a great tertiary for you since most of your damage is coming from your own spells.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAcGAnk7cUrTOCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAcGAS06oPrDj1kjAYFA]] | Ula'tek |
| Shoulder | [[item:271526@DgQAAcGAXk7kjAOF]] | Catalyst |
| Cloak | [[item:268253@BgQAAcGA5IgTBA]] | The Coiled Altar |
| Chest | [[item:271531@DgQAAcGAJk7kjAOF]] | Catalyst |
| Wrist | [[item:244576@FCSAAcGAYA8ciqjAtOAAAAAAAA3WzSB]] | Crafting |
| Gloves | [[item:271529@BgQAAcGA5IgTBA]] | Catalyst |
| Belt | [[item:268256@BiQAAcGAK06kjAYF]] | The Coiled Altar |
| Legs | [[item:249312@DgQAAcGAhu7IoAhE]] | The Coiled Altar / Catalyst |
| Boots | [[item:244569@HASAAcGAYA8ciqT84OAAAAAAAA3WzSB]] | Crafted |
| Ring 1 | [[item:268249@DiQAAcGA1j7IQrTOC4UA]] | Vashnik |
| Ring 2 | [[item:252258@DiQAAcGA1j7IQrjgC4UA]] | Voidscar Arena |
| Trinket 1 | [[item:270173@BgQAAcGACKAWBA]] | The Coiled Altar |
| Trinket 2 | [[item:270175@BgwAAcGACKAWBUAABEzFCA]] | Ula'tek |
| Weapon | [[item:268215@DgQAAcGAwqCZhNYF]] | Ula'tek |

Feral Druid BiS list in Raids

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271528@AgQAAkjABFA]] | Catalyst |
| Neck | [[item:251142@BiQAAcGAC06IoABF]] | Murder Row |
| Shoulder | [[item:271526@DgQAAcGAXk7kjABF]] | Catalyst |
| Cloak | [[item:251132@DgQAAcGANk7IoABF]] | Murder Row |
| Chest | [[item:271531@DgQAAcGAJk7kjABF]] | Catalyst |
| Wrist | [[item:244576@FCSAAcGAYA8ciqjAtOAAAAAAAA3WjPB]] | Crafted |
| Gloves | [[item:271529@BgQAAcGA5IQQBA]] | Catalyst |
| Belt | [[item:159317@BiQAAcGAC06IoABF]] | Temple of Sethraliss |
| Legs | [[item:271527@DgQAAcGAhu7kjABF]] | Catalyst |
| Boots | [[item:244569@HASAAcGAYA8ciqT84OAAAAAAAA3WjPB]] | Crafted |
| Ring 1 | [[item:252258@DiQAAcGA1j7IQrjgCEUA]] | Voidscar Arena |
| Ring 2 | [[item:273792@CiQAAUPujAtOCKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:273796@BgQAAcGACKQQBA]] | Altar of Fangs |
| Trinket 2 | [[item:250228@BgQAAcGACKQQBA]] | Murder Row |
| Weapon | [[item:273783@DgQAAcGAwqCJoABF]] | Altar of Fangs |

Feral Druid alternative

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAAcGACKgTBA]]  <br>[[item:270173@BgQAAcGACKgTBA]]  <br>[[item:270164@BgQAAcGACKgTBA]] |
| **A-Tier** | [[item:273796@BgQAAcGACKgTBA]]  <br>[[item:270165@BgQAAcGACKgTBA]]  <br>[[item:250228@BgQAAcGACKgTBA]] |
| **B-Tier** | [[item:250215@BgQAAcGACKgTBA]]  <br>[[item:159617@BgQAAcGACKgTBA]]  <br>[[item:250225@BgQAAcGACKgTBA]] |
| **C-Tier** | [[item:270166@BgQAAcGACKgTBA]]  <br>[[item:250214@BgQAAcGACKgTBA]] |
| **Junkyard** | [[item:250259@BgQAAcGACKgTBA]]  <br>[[item:273797@BgQAAcGACKgTBA]]  <br>[[item:193757@BgQAAcGACKgTBA]] |

### Embellishments

- [[item:240167]] x2

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241322]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255846]] *-- Feast*
  
  
  
  - [[item:242747]] -- personal food which lacks the stamina bonus that feasts provide
- Combat Potion
  
  - [[item:241308]] -- *Grants agility*
  
  
  
  - [[item:241289]] -- Grants secondary stats, currently the recommended choice
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].*
    
    - [[item:240908]] *-- Main gem.*
    - [[item:240900]]
    - [[item:240918]]
    - [[item:240892]]

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAcGANk7A]]  <br>[[item:243949]] |
| --- | --- |
| Shoulder | [[item:244019@BAAAAMQA]] |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@BAAAAcG]] |
| Waist | [[item:275707@BAAAAcG]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:244015@BAAAAMQA]] |
| Ring 2 | [[item:244015@BAAAAMQA]] |
| Weapon | [[item:273072@BAAAAcG]] |

Feral Druid Enchantments in Raids

:::

:::column
:::gear **Feral Druid** Enchantments in Raids
```json
{
  "source_code": "IQFZnBQ9NCQA7TDBCAAAA0QuDEwM5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAAv0AEo8SuDAAAAAQAwqCB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243981]] |
| 肩部 | [[item:244019]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:273072]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAcG]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Feral Druid** in Mythic+, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Night Elf
  
  - One of the most broken racials in Mythic+ as you can use it on any cast targetting you and most of the time make the mob recast or cancel it complety.
  - Does work with [[spell:390772]]**.**
  
  
  
  - Use-cases:
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
- [[spell:20549]] *-- Tauren* 
  
  - Can be used to stun 5 enemies.
  - [[spell:154743]] 2% critical strike damage.
  - Also, [[spell:20550]] gives you extra health to survive unavoidable damage.

### Recommendation

**Night Elf is the best overall racial, it has such a big impact on your Mythic+ experience that you need to use the strength of [[spell:58984]] if you're serious about pushing keys with your Feral Druid.**

## Macros

Discover recommended macros for **Feral Druid** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:102793]]** -- *Casts [[spell:102793]] on your cursor without confirmation.*

```wow-macro
#showtooltip Ursol's Vortex
/cast [@cursor] Ursol's Vortex
```

:::

:::details Mouseover Macros
**Set focus macro - *Put focus on mouseover.***

```wow-macro
/focus [@mouseover,exists,nodead] []
```

**[[spell:20484]]** -- *Casts [[spell:20484]] on your mouseover or target.*

```wow-macro
#showtooltip Rebirth
/use [@mouseover,exists][] Rebirth
```

:::

:::details Focus Macros
**Focus kick macro - *Cast your [[spell:106839]]* *on your focus*.**

```wow-macro
#showtooltip Skull Bash
/cast [@focus, exists] Skull Bash
```

:::

:::details Utility Macros
**Macro to avoid canceling [[talent:103177]] - *You casts only [[spell:22568]] when [[talent:103177]] is done channeling.***

```wow-macro
#showtooltip Ferocious Bite
/startattack
/cast [nochanneling:Convoke the Spirits] Ferocious Bite
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Feral Druid**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/INTERFACE-midnight-v2-maxroll-2-1024x683.png>)

:::accordion
:::details Addons
- **LittleWigs** -- Generic Boss Mod
  
  - LittleWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI-- *UI addon*** 
  
  - EllesmereUI is a BIG addon that contain many modules, you can make your whole UI with it.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**DRUID**

- Class
  
  - Matted Fur absorb increased by 25%.
  - Heart of the Wild empowered Wild Growth healing increased by 25%.
- Feral
- Developers’ notes: Feral updates in Curse of Ula’tek are aimed at talent diversity. We’d like Chomp to be stronger for players who enjoy it, and we’re adjusting some other talents to get their power closer and open up more build options.
- Saber Jaws damage bonus increased to 60% per point (was 50%).
- Focused Frenzy damage bonus reduced to 15% (was 20%).
- Rip and Tear damage bonus increased to 20% (was 15%).
- Chomp damage increased by 30%.
- Apex Predator’s Craving base chance to trigger reduced to 4% (was 5%).
- Rejuvenation healing increased by 25%.
- Wild Growth healing increased by 25%.
- Regrowth healing increased by 25%.

:::

:::details Patch 12.0.1
**DRUID**

- Hero Talents
  
  - Wildstalker
    
    - Bloodseeker Vines grow at an increased rate when multiple targets are afflicted by your bleeds.
    - Rampancy causes Bursting Growths to have a 30% chance to trigger (was 20%).
    - Patient Custodian increases bleed damage by 8% (was 6%).
    - Fixed an issue that caused Patient Custodian to not increase Bloodseeker Vine damage.
- Class
  
  - Matted Fur absorption increased by 100%.
  - Matted Fur lasts 15 seconds (was 8 seconds).
  - Regrowth direct healing reduced by 15%.
  - Wild Growth healing increased by 25%.
- Feral
  
  - All attack damage increased by 8%.
  - Cat form Swipe damage increased by 20%.
  - Focused Frenzy increases the damage of Feral Frenzy by 20% (was 40%).
  - Wild Growth healing increased by 100%.
  - Rejuvenation healing increased by 100%.

:::

:::details Patch 12.0
- DRUID
  
  - Hero Talents
  - Druid of the Claw
    
    - New Talent: Limb from Limb – Your auto-attacks are 30% more likely to make your next Ferocious Bite/Maul to become Ravage.
    - New Talent: Twin Claw – You have a 16%/18% chance to follow up any single target melee ability or Raze with a Twin Claw, dealing High Physical damage and generating 3 Energy/5 Rage.
    - New Talent: Exacerbating Wounds – Your Dreadful Wounds increase the damage afflicted enemies take from your Bleed damage over time effects by 8%/15%.
    - Strike for the Heart has been updated –Feral: Shred, Swipe, and Rake damage increased by 10% and their critical strike chance is increased by 8%.
    - Guardian: Mangle damage increased by 20% and its critical strike chance is increased by 10%. Mangle heals you for 5% of maximum health.
    - Tear Down the Mighty has been updated –Feral: Damage dealt by Chomp and Frantic Frenzy increased by 25%.
    - Guardian: The cooldown of Sundering Roar is reduced by 15 seconds.
    - Claw Rampage has been updated – The chance for Ravage to be triggered reduced to 20% (was 25%). Attacks during Berserk only have one chance to grant Ravage (was one per target hit).
    - Ravage has been updated – Your auto-attacks are 15% more likely to make your next attack a Ravage.
    - Empowered Shapeshifting increases the damage and Shred and Swipe by 10% (was 6%).
    - The Ruthless Aggression/Killing Strikes choice talent has changed position.
  - Wildstalker
    
    - New Talent: Green Thumb – The rate at which Bloodseeker Vines/Symbiotic Blooms grow is increased by 20%.
    - New Talent: Rampancy – Bloodseeker Vines/Symbiotic Blooms have a 20% chance to trigger Bursting Growth every 2 seconds at 100% effectiveness.
    - New Talent: Patient Custodian – Your Bleeds and other damage over time/heal over time effects are 6% more effective.
    - Bloodseeker Vines damage reduced by 15%.
    - Bursting Growth damage reduced by 20%.
    - Vigorous Creepers causes Bloodseeker Vines to increase damage victims take from you by 4% (was 6%).
    - Bursting Growth has changed position.
  - Feral
    
    - Twin Claw damage increased by 20%.
    - Ravage damage to its primary target reduced by 20%.
    - Dreadful Wound damage reduced by 20%.
    - Strike for the Heart increases Shred, Swipe, and Rake critical strike chance by 5% (was 8%).
    - Ursine Potential's increase to Mangle and Swipe damage in Bear Form is now 50% (was 300%).

:::

:::details Patch 11.2
- DRUID
  
  - Lycara’s Meditation replaced with Lycara’s Inspiration – You gain a bonus while in each form inspired by the breadth of your Druidic knowledge:
    
    - No Form: 4% Magic Damage
    - Bear Form: 5% Movement Speed
    - Cat Form: 4% Stamina
    
    
    
    - Moonkin Form: 3% Avoidance
  
  
  
  - Maim now has a 30 second cooldown (was 20 seconds).
  
  
  
  - Bear Form’s threat generation multiplier has been reduced for Balance, Feral, and Restoration Druids.
  
  
  
  - Druid of the Claw
    
    - Empowered Shapeshifting causes Bear Form to reduce magic damage taken by 6% (was 4%).
  
  
  
  - Wildstalker
    
    - Symbiotic Blooms and Bursting Growth healing increased by 30%.
    - Thriving Growth's base chance for Symbiotic Blooms to grow increased by 30%. Rate at which this increases with larger target counts slightly reduced.
    - Twin Sprouts' chance to generate an additional Bloodseeker Vine or Symbiotic Bloom increased to 30% (was 20%).
    - Vigorous Creepers causes Bloodseeker Vines to increase damage targets take from you by 6% (was 5%).
  
  
  
  - Feral
    
    - All ability damage increased by 8%.
    - Brutal Slash damage in Bear Form increased by 25%.
    - Lycara’s Teachings gives 6% Mastery while in Moonkin Form (was 2%).
    - Saber Jaws bonus to extra Ferocious Bite damage increased to 60/120% (was 40/80%). This change does not affect PvP combat.
    - Sabertooth causes Ferocious Bite to increase damage taken from your bleeds and other periodic effects by 5% per combo point (was 3%).

:::

:::details Patch 11.0.2
- DRUID
  
  - Regrowth initial heal increased by 27% and its healing over time decreased by 3%.
  - Swiftmend healing increased by 38%.
  - Ironfur increases Armor by 112% of Agility (was 120%).
  
  
  
  - Feral
    
    - Melee auto-attack damage increased by 30%.
    - Rip damage increased by 15%.
    - Rake initial damage increased by 30% and periodic damage increased by 5%.
    - Shred initial damage increased by 30%.
    - Swipe initial damage increased by 30%.
    - Brutal Slash initial damage increased by 30%.
    - Thrash initial damage increased by 30% and periodic damage increased by 5%.
    - Lunar Inspiration Moonfire initial damage increased by 30%.
    - Primal Wrath direct damage increased by 20%.
    - Adaptive Swarm direct damage increased by 20%.
    - Rampant Ferocity's damage increased by up to 100% (was 50%) when players spend extra Energy on Ferocious Bite.
    - Taste For Blood increases Ferocious Bite damage by 12% (was 15%) and an additional 12% (was 15%) during Tiger's Fury.
    - Apex Predator's chance to proc against multiple targets increased slightly.
    - Berserk now increases all ability and auto-attack damage by 15% (was 10%).
    - Berserk: Frenzy now causes enemies to bleed for 150% of all direct damage dealt by combo point generating abilities (was 135%).
    - Incarnation reduces the Energy cost of all abilities by 25% (was 20%).
    - Ashamane's Guidance's effect now lasts 40 seconds after Incarnation ends (was 30 seconds).
    - Savage Fury increases your Haste by 10% (was 8%) and Energy recovery rate by 25% (was 20%).

:::

:::

## FAQ

:::accordion
:::details Q: Do I use my finishers at 4 or 5 combo points?
**A:** You want to always use your finishers at 5 combo points.

:::

:::

---

### Credits

Written By: **Maystine**

Reviewed By: **Meeres**

:::changelog 更新记录
**2026-08-06** updated for 12.1

**2026-06-22** updated for 12.0.7

**2026-04-24** updated 12.0.5

**2026-02-10** updated 12.0.1

**2026-01-19** updated 12.0

**2025-12-03** Updated for 11.2.7

**2025-10-08** Updated for 11.2.5

**2025-07-28** Updated for 11.2!

**2025-06-19** Some typo fixed

**2025-06-17** Updated for patch 11.1.7.

**2025-04-22** Updated for patch 11.1.5.



:::
