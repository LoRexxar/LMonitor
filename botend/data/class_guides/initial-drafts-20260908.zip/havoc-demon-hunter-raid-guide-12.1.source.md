Welcome to the **Havoc Demon Hunter** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 5/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Havoc Demon Hunter**  Raid Best in Slot
```json
{
  "source_code": "JQpAIGkA3_fABMgJEIIEBAwJ5OADtOggCchNYFQApfBBAERAAcVrJQBXMWDWBEwrkQgAIUAAXk7ACKgTBY9FEEAtJIBAJkgEogcpDEA4XQAgIEAAFkEDYFQAwmQIMF6uDIoAYFQwXQQAf5mACgQAAEPuFUEMBA2uDQICBAQrqQgHAHwakdbNLFQAySCBAgQAAIoAOFQAZfBBCiQAAUPuB4RBSggnqJgOSAAGf9BBAgwAAEwYcUAABo0FCEQXBIRACBBWBEQ3XkhTIE7FEEgfEMQuFAJUBARoDYACBAgHAPwA5OApqQwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240908]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240983]] · [[item:240908]] |
| 肩部 | [[item:271535]] | [[item:243991]] |
| 胸部 | [[item:271540]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240908]] |
| 腿部 | [[item:271536]] | [[item:244641]] |
| 脚部 | [[item:159327]] | [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240908]] · [[item:273069]] · [[item:245790]] |
| 手部 | [[item:271538]] |  |
| 戒指一 | [[item:268249]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:243971]] |
| 副手 | [[item:237840]] | [[item:245790]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Havoc Demon Hunter**, you have access to Eternal Hunt, which empowers your [[spell:198013]], lowers the cooldown and increases the target cap of [[spell:370965]], and gives you a guaranteed reset of your [[spell:188499]] after casting [[spell:198013]].

- **Rank 1** causes [[spell:370965]] to empower your next [[spell:198013]], doubling it's damage and increasing it's area of effect.
- **Rank 2** gives [[spell:370965]] 15/30 sec reduced cooldown, makes it do 15/30% more damage and it's DoT effect can apply to 2/4 extra targets.
- **Rank 3** Increases [[spell:188499]] damage by 20%, and will cause it to reset it's own cooldown the first time it's cast after fully channeling [[spell:198013]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-havoc-mxr.webp>)

Eternal Hunt

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:370965]]
    
    - Previously in the Class Tree, this ability has been moved to the Spec Tree.
  - [[spell:342817]]
    
    - Previously an active ability, [[spell:342817]] has been reworked into a passive effect when [[spell:188499]] strikes 3 or more targets.
- **Class Tree**
  
  - [[spell:213241]]
    
    - Now generates 15 fury and no longer has a chance to reset, which results in slower fury generation overall.
  
  
  
  - [[spell:1266316]] /[[spell:1266496]]
    
    - Causes [[spell:472649]] to remove 1 Disease/Curse effect respectively.
  
  
  
  - [[spell:1266307]]
    
    - Gives 1 additional charge of [[spell:198589]]. Gives great defensive power when combined with [[spell:205411]] from the Spec Tree.
  
  
  
  - [[spell:1266329]]
    
    - 15% reduced magic damage taken for 12s after interrupting. Situational, but this is a great defensive tool in situations where are taking magic damage, and interrupting is available.
- **Removed**
  
  - [[spell:196555]]
    
    - The removal of [[spell:196555]] has a negative impact on survivability, but is compensated by the new combination of [[spell:1266307]] and [[spell:205411]].
  
  
  
  - [[spell:204513]]
    
    - Previously a baseline ability, [[spell:204513]] has been made unique to the Vengeance spec.
  
  
  
  - [[spell:389815]]
    
    - Previously a capstone in the Class Tree, [[spell:389815]] has been made unique to the Vengeance spec.
  
  
  
  - [[spell:211881]]
    
    - The removal of this ability was "compensated" by [[spell:1266296]], a talent node in the Class Tree. This makes the primary target of [[spell:179057]] stunned for an additional 2 sec.
  
  
  
  - [[spell:258925]]
    
    - [[spell:258925]] was a talent option in the Spec Tree for some on demand AoE burst, which is now removed.
  
  
  
  - [[spell:162243]]
    
    - Previously offered as a choice node with [[spell:203555]]. The choice node is removed entirely, and [[spell:203555]] is now baseline.

## Hero Talents

- [[talent:123330]] and [[talent:123329]] are the Hero Talent tree options for Havoc Demon Hunter.[[talent:123329]] is currently ahead of [[talent:123330]] in both AoE and Single-Target scenarios, except if you are looking for funnel damage.



### [[talent:123329]]

#### Hero Talent overview

- The [[talent:123329]] hero talent tree is generally more passive than [[talent:123330]]. In addition to it's normal benefits, casting [[spell:191427]] transforms [[spell:198013]] into [[spell:452497]] and [[spell:258920]] into [[spell:452487]] empowering them, causing them to trigger a [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]] the first time they are cast.
- At the same time, the tree has talents like [[spell:452414@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]], [[spell:452408@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] and [[spell:452410@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] that significantly increase your output out of [[spell:191427]].
- [[talent:123329]] is generally considered easier to play compared to [[talent:123330]], which is something worth considering since it might give you more room to focus on more important stuff than damage, such as mechanics and living.
- Make sure to put [[spell:258920]] and [[spell:198013]] on cooldown before using [[spell:191427]] as [[talent:117509]] resets those abilities.

#### Patch 12.0

- Patch 12.0 introduced 3 new talent nodes to the [[talent:123329]] hero talent tree:
  
  1. [[spell:1272364]]. Fire damage increased by 5%. Effect is doubled while in [[spell:213410]].
  2. [[spell:1272405@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]. [[spell:258920]] has a 25% chance to reignite after it expires.
  3. [[spell:1272453]]. Instantly trigger a [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]] when you enter [[spell:213410]].




### [[talent:123330]]

#### Hero Talent overview

- With [[talent:117512]], consuming 6 soul fragments makes your [[spell:185123]] ability become [[spell:442294]]. After casting [[spell:442294]], your next [[spell:162794]]/[[spell:201427]] and [[spell:188499]]/[[spell:210152]] are enhanced.
  
  1. When [[spell:188499]] is enhanced, it will trigger [[spell:442718]] on cast, which will cast 3 additional glaive slashes to nearby targets. If [[spell:188499]] is cast after [[spell:162794]], it will cast 6 slashes instead.
  2. When [[spell:162794]] is enhanced it applies [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]]. If [[spell:162794]] is cast after [[spell:188499]], it will apply 1 additional stack of [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]].

- Additionally, after consuming both enhancements you gain Thrill of the Fight, increasing the damage of your next [[spell:442294]] by 30% and increasing Haste by 6% for 30 sec.

#### Patch 12.0

- Patch 12.0 introduced 3 new talent nodes to the [[talent:123330]] hero talent tree:
  
  1. [[spell:1272143]]. [[spell:370965]] shatters 1 soul fragment. Additionally [[spell:188499]] and [[spell:162794]] have a 15% chance to shatter 1 soul fragment.
  2. [[spell:1272138]]. The damage of [[spell:442294]] is increased by 20%, and all other Physical-only damage is increased by 10%. This will also indirectly increase the damage of [[spell:474339]].
  3. [[spell:1272153]]. This doubles the amount of glaives triggered when [[spell:188499]] is cast 2nd. It also allows [[spell:442624@FJwDE6zAgsrAJunAFIwA5NOBSOOBMNtAy9DB8rrAOayAxzwByzwB73yEjsxAnC2AMA]] to stack up to 3 times, and [[spell:162794]] will apply an additional stack when cast 2nd.





## Talents



### [[talent:123329]] Single-Target

:::talents [[talent:123329]] **Havoc Demon Hunter** Single-Target talents in Raids
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZAzMz2MmZmZmZmMmZAAAAAAAzmZmtZgxyMzYZm5BmZWmZWGjB2mFzYY200wMjhNAAAAAAEAMzgBgAAADA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZAzMz2MmZmZmZmMmZAAAAAAAzmZmtZgxyMzYZm5BmZWmZWGjB2mFzYY200wMjhNAAAAAAEAMzgBgAAADA"
}
```
:::

- These talents are purely focused on maximizing single target/priority target damage.




### [[talent:123329]] Multi-Target

:::talents [[talent:123329]] **Havoc Demon Hunter** Multi-Target talents in Raids
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

- These talents are focused on dealing massive amounts of AoE damage, which happens passively around you and your priority target. A good choice for any bosses where there are multiple targets, or there are important adds that needs to be killed.




### [[talent:123330]] Single-Target

:::talents [[talent:123330]] **Havoc Demon Hunter** Single-Target talents in Raids
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

- The [[talent:123330]] variant is what supplies Havoc with it's renowned funnel damage. This is especially useful when multiple targets are present and you mostly care about priority damage on 1-2 targets.





### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:258860]]
  
  - Does massive damage in a frontal cone and causes [[spell:162794]] and [[spell:188499]] to deal additional Chaos damage to affected enemies.

- [[talent:112955]]
  
  - Every time you cast [[spell:198013]] the cooldown is reduced by 2.5 seconds, up to 10 seconds max.

- [[spell:388108]]
  
  - Hitting a target before it hits you increases your critical strike chance by 10%, this is reset on every hostile target by casting [[spell:198793]].

- [[spell:370965]]
  
  - This strong offensive Cooldown puts a major DoT on your target and up to 5 targets in your path.

- [[spell:390197]] + [[spell:427775]]
  
  - The combination of these talents gives a high potential for AoE damage, and if talented it is very important to keep your [[spell:258920]] on cooldown at all times, but especially in AoE scenarios.

#### Class Tree

- [[spell:196718]] 
  
  - This group-wide defensive cooldown creates a zone of [[spell:196718]] at the **Havoc Demon Hunter's** location, granting all allies within it a 15% chance to avoid all damage from incoming attacks. This chance is doubled when not in a raid.

#### Hero Talents

- [[talent:117514@FAQBE6zAQZyAtByAOSOBjsxA]]
  
  - Empowers your next [[spell:201427]] and [[spell:210152]] after entering [[spell:213410]] to explode around you.  
    When entering [[spell:213410]] with [[spell:162264]] it additionally empowers your [[spell:190232]] and [[spell:258920]] to do the same.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:188499]], [[spell:162794]], and [[talent:112956]] deal 12% increased damage.
- **4-Set:** [[talent:112956]] now applies and benefits from the effects of [[talent:112955]], has 25% increased initial strike damage, and has 2 seconds of increased duration.

### Single-Target



#### [[talent:123329]]

##### Opener

- The **Havoc Demon Hunter's** opener is very complex and it is important that you do it in this exact order to maximize your damage output.

:::rotation **Havoc Demon Hunter** Fel Scarred Single-target opener in Raids
```json
{
  "source_code": "IoHPNI0d7LAAAcAUyVGc1xGbAkwD0AQABwprDAAAAAgQVkaBFgAB9VQCQQALznACEgON2gAAEMtEBABKBIUiIMAAAIE25JQB2QA60EgFQAgQHeuBFABKTLxAAAAAAIUknbA"
}
```
1. [[spell:195447]] Prepull
2. [[spell:195447]]  [[item:241308]]
3. [[spell:370965]]
4. [[spell:198013]]
5. [[spell:258860]]
6. [[spell:210152]]
7. [[spell:210152]]
8. [[spell:201427]]  [[spell:198793]]
9. [[spell:162264]]
10. [[spell:210152]]
11. [[spell:452487]]
12. [[spell:201427]]
13. [[spell:452497]]
:::

- If you are talented into [[spell:427641]], you will have to make sure to use [[spell:213241]] or [[spell:195072]] in order to trigger your [[spell:427641]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

- Cast [[spell:198013]] on cooldown
- Cast [[spell:198793]] on cooldown, or with important damage events
- Cast [[spell:370965]] on cooldown
- Cast [[spell:210152]] on cooldown
- Cast [[spell:258920]] if you won't overcap on fury
- Cast [[spell:201427]]
- Cast [[spell:188499]]
- Cast [[spell:162794]]
- Cast [[spell:232893]]





### Multi-Target



#### [[talent:123329]]

##### Opener

- Below, you see an example of how your opener looks like using the recommended **Multi-Target talent spec**.

:::rotation **Havoc Demon Hunter** Fel Scarred AoE opener in Raids
```json
{
  "source_code": "IoHPNI0d7LAAAcAUyVGc1xGbAkwD0AQABwprDAAAAAgQVkaBFgAB9VQCQQALznACEgON2gAAEMtEBABKBIUiIMAAAIE25JQB2QA60EgFQAgQHeuBFABKTLxAAAAAAIUknbA"
}
```
1. [[spell:195447]] Prepull
2. [[spell:195447]]  [[item:241308]]
3. [[spell:370965]]
4. [[spell:198013]]
5. [[spell:258860]]
6. [[spell:210152]]
7. [[spell:210152]]
8. [[spell:201427]]  [[spell:198793]]
9. [[spell:162264]]
10. [[spell:210152]]
11. [[spell:452487]]
12. [[spell:201427]]
13. [[spell:452497]]
:::

##### Multi-Target Priority List

- Cast [[spell:258920]] on cooldown with [[spell:427775]] talented
- Cast [[spell:198013]] on cooldown
- Cast [[spell:198793]] on cooldown, or with important damage events
- Cast [[spell:370965]] on cooldown
- Cast [[spell:210152]]
- Cast [[spell:201427]]
- Cast [[spell:188499]]
- Cast [[spell:162794]]
- Cast [[spell:232893]]





## Deep Dive

### Dead or Alive

The most important part of doing damage and being a useful part of your Raid group is staying alive. With movement being a core part of your damage rotation you NEED to always be aware of your surroundings. Do not [[spell:195072]] or [[spell:198793]] into frontal abilities or area of effect zones.

You cannot do damage while you are dead and neither can you stop abilities from going through.

Being able to execute the perfect rotation isn't going to help you if you are lying dead on the floor or if you need externals/healing that your group would need otherwise.

### Immolation Aura

When you have [[spell:390197]] + [[spell:427775]] talented it is important to manage your [[spell:258920]] charges properly as it is the biggest portion of your damage breakdown in AoE scenarios. When you are about to overcap on charges but you don't have [[spell:195072]] charges ready to spend on [[spell:427640]] uptime just use your [[spell:258920]] charges and ignore [[spell:427640]].

**Never** overcap on [[spell:258920]] charges, no matter what!

### Initiative Windows

Another important part of your damage is managing your [[spell:388108]] windows properly. Remember that every single hostile enemy procs [[spell:388108]] and [[spell:198793]] also resets it on EVERY hostile enemy.

You can optimize this by staying out of range of some enemies to proc[[spell:388108]] again later.

### Spreading The Hunt

When casting [[spell:370965]] it is important to make sure you afflict as many enemies as possible with the DoT component of the ability. This can be tricky since it is applied to enemies that are in your path when you charge with [[spell:370965]]. A trick to help with this is that you can actually still apply this DoT after the cast/charge of [[spell:370965]] is over. This means that you can cast [[spell:370965]], and after it's done you can walk through enemies to apply this dot component to them, and if you are quick you can even cast [[spell:195072]] AFTER [[spell:370965]], and it will still apply the DoT to the enemies you [[spell:195072]] through.

### Haste ?!

Even though **Haste** Sims pretty poorly on paper, it is a great stat for multi target scenarios as it smooths your gameplay out by a lot.

**Haste** increases the amount of [[spell:258920]] charges you have as it decreases the recharge time and helps with Fury generation as well as helping you fit more abilities into your [[spell:213410]] windows.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to Heroic and Mythic Bosses.

**← Scroll for more Bosses →**



### Nek'Zali

:::talents **Havoc Demon Hunter** Nek'Zali
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.




### Entombed Sentinels

:::talents **Havoc Demon Hunter** Entombed Sentinels
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

#### Boss Tips

- Important to know that [[spell:1284434]] may also spawn on the opposite boss, so try not to stand between them and be careful whenever [[spell:1284434]] spawn.
- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].




### Lost Explorers

:::talents **Havoc Demon Hunter** Lost Explorers
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

#### Boss Tips

- Pay attention to [[spell:1296062]] casts to have an easier time dodging them.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed shortly after being used once.




### Vashnik

:::talents **Havoc Demon Hunter** Vashnik
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

#### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.




### Sszorak

:::talents **Havoc Demon Hunter** Sszorak
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

#### Boss Tips

- In case you fail to find a partner to deal with [[spell:1285419]], keep in mind that you can also negate it with a [[talent:80163]] or [[talent:80174]].
- Very important to keep an eye on the [[spell:1305959]] timer and, whenever it's close, scan the platform ahead of time to see where you will need to place it.
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.




### Twin Fangs

:::talents **Havoc Demon Hunter** Twin Fangs
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

#### Boss Tips

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.




### Coiled Altar

:::talents **Havoc Demon Hunter** Coiled Altar
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::

#### Boss Tips

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].




### Ula'tek

:::talents **Havoc Demon Hunter** Ula'tek
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZGMzMz2MmZmZGzkxMDAAAAAAY2MmlZYmZ2mZGLzMmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA"
}
```
:::




### Nymrissa Wavecaller

:::talents **Havoc Demon Hunter** Nymrissa Wavecaller
```json
{
  "source_code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
  "code": "CGkAIo1c2KfIEsPoy9fznypG4ZmZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM"
}
```
:::

#### Boss Tips

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle, so position accordingly or be ready to negate the knockback with [[spell:131347]].
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.





It's worth noting that the [[talent:123330]] talents are performing well this tier, and in the right hands they can outperform any [[talent:123329]] setup on any boss in The Venomous Abyss. However, [[talent:123330]] generally comes with some added difficulty/clunkyness and is not for everyone. [[talent:123329]] will provide you with more on demand burst, and aoe damage, while [[talent:123330]] will give you high Single-Target dps paired with the funnel it gains from any extra targets present.

The [[talent:123330]] talents are recommended because you can play these talents on every boss. Keep in mind that your raid might have other needs that are more suited for [[talent:123329]]'s damage profile, such as aoe burst damage for add spawns.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Havoc Demon Hunter**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Havoc Demon Hunter** Raid Stat Priorities
```json
{
  "source_code": "IoAJFMAIxQCKBEQABA"
}
```
**敏捷 ＞ 暴击 ＞ 精通 ＞ 急速 ＞ 全能**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be useful, and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAEkAnk7wQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAEkAX16wQrjgCwYNYFA]] | Ula'tek |
| Shoulder | Convert [[item:268246@BgQAAEkACKgTBA]]  <br>into [[item:271535@DgQBAEkAXk7IoAOFg1XQ]] | Vashnik Catalysted |
| Cloak | [[item:268253@BgQAAEkACKgTBA]] | Coiled Altar |
| Chest | Convert [[item:239048@BgQAAEkACKgTBA]]  <br>into [[item:271540@DgQBAEkAJk7IoAOFAylO]] | King's Rest Catalysted |
| Wrist | [[item:244576@FiRAAEkAtqC5BwDDtOAAAAAcbNLF]] | Crafted |
| Gloves | [[item:271538@BgQAAEkACKgTBA]] | Entombed Sentinels |
| Belt | [[item:268256@BiQAAEkAM06IoAYF]] | Coiled Altar |
| Legs | Convert [[item:268225@BgQAAEkACKAWBA]]  <br>into [[item:271536@DgQBAEkAhu7IoAYFQwXQ]] | Coiled Altar Catalysted |
| Boots | [[item:159327@DgQAAEkAxj7IoAOF]] | Temple of Sethraliss |
| Ring 1 | [[item:268249@DiQAAEkA1j7wQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAEkA1j7wQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270175@BgwAAEkACKAWBUAABo0FCA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAEkACKAWBA]] | Coiled Altar |
| Weapon | [[item:268209@DgQAAEkADk7IoAYF]] & [[item:237840@HgQAAEkAeA8MQuDpqQ3WzSB]] | Coiled Altar & Crafted |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239033@DiQAAEkAnk7wQrjgCEUA]] | Temple of Sethraliss |
| Neck | [[item:251234@BkQAAEkAX16wQrjgCEUA]] | Voidscar Arena |
| Shoulder | [[item:251223@DgQAAEkAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:251132@BgQAAEkACKQQBA]] | Murder Row |
| Chest | [[item:239048@DgQAAEkAJk7IoABF]] | Kings' Rest |
| Wrist | [[item:251183@BiQAAEkAM06IoABF]] | The Blinding Vale |
| Gloves | [[item:159312@BgQAAEkACKQQBA]] | Kings' Rest |
| Belt | [[item:159317@BiQAAEkAM06IoABF]] | Temple of Sethraliss |
| Legs | [[item:251130@DgQAAEkAhu7IoABF]] | Murder Row |
| Boots | [[item:159327@DgQAAEkAxj7IoABF]] | Temple of Sethraliss |
| Ring 1 | [[item:158366@DiQAAEkA1j7wQrjgCEUA]] | Temple of Sethraliss |
| Ring 2 | [[item:251136@DiQAAEkA1j7wQrjgCEUA]] | Murder Row |
| Trinket 1 | [[item:250215@BgQAAEkACKQQBA]] | Murder Row |
| Trinket 2 | [[item:250228@BgQAAEkACKQQBA]] | Murder Row |
| Weapon | [[item:251186@DgQAAEkADk7IoABF]] & [[item:251231@DgQAAEkADk7IoABF]] | The Blinding Vale & Voidscar Arena |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons and Raids.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAEkACKAWBUAABo0FCA]]  <br>[[item:270173@BgQAAEkACKAWBA]]  <br>[[item:270168@BgQAAEkACKAWBA]]  <br>[[item:270164@BgQAAEkACKgTBA]] |
| **A-Tier** | [[item:250215@BgQAAEkACKgTBA]]  <br>[[item:270166@BgQAAEkACKgTBA]]  <br>[[item:270165@BgQAAEkACKgTBA]] |
| **B-Tier** | [[item:159617@BgQAAEkACKgTBA]]  <br>[[item:250259@BgQAAEkACKgTBA]]  <br>[[item:250228@BgQAAEkACKgTBA]]  <br>[[item:250225@BgQAAEkACKgTBA]]  <br>[[item:193757@BgQAAEkACKgTBA]] (Trained) |
| **C-Tier** | [[item:250214@BgQAAEkACKgTBA]]  <br>[[item:273796@BgQAAEkACKgTBA]]  <br>[[item:158374@BgQAAEkACKgTBA]]  <br>[[item:273797@BgQAAEkACKgTBA]] |
| **Junkyard** | [[item:193757@BgQAAEkACKgTBA]] (Untrained) |

### Embellishments

- [[item:273060]] is currently the most powerful embellish. This can however only be crafted on weapons, so depending on what items your character might have/need crafting 1 or 2 weapons with this embellishment will likely be the best option.
- [[item:273069]] is the 2nd strongest embellishment, and can be crafted on normal armor pieces. This makes for a more versatile embellishment since it can go on any slot, and you might be able to craft in an item slot that benefits your character more.
- [[item:240167]] Similar to [[item:273069]], but seems to output slightly lower DPS numbers.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - **[[item:241326]] *-- maximum DPS.***
  
  
  
  - **[[item:241320]] *-- less DPS but more survivability.***
- **Food**
  
  - **[[item:242273@BQAAAEkAaB]]**
- **Combat Potion**
  
  - **[[item:241288]]**
- **Health Potion**
  
  - [[item:271884]] -- a big burst of healing
- Weapon
  
  - **[[item:243734]]**
- **Augment Rune**
  
  - **[[item:259085@BQAAAEkAaB]]**
- **Sockets**
  
  - **[[item:240908]]**
  - **[[item:240967]] *-- Unique, use one of each gem color to enhance your [[item:240967]].***
    
    - **[[item:240898]]**
    - **[[item:240914]]**
    - **[[item:240890]]**

### Enchantments

:::columns
:::column
| Head | [[item:244007@DAAAAEkAZbAB]] & [[item:275707@DAAAAEkAnk7A]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAEkA]] |
| Chest | [[item:243977@BAAAAEkA]] |
| Wrist | [[item:275707@DAAAAEkAnk7A]] |
| Waist | [[item:275707@DAAAAEkAnk7A]] |
| Legs | [[item:244641@BAAAAEkA]] |
| Boots | [[item:243953@BAAAAEkA]] |
| Ring 1 | [[item:243957@BAAAAEkA]] |
| Ring 2 | [[item:243957@BAAAAEkA]] |
| Weapon | 2x [[item:243971@BAAAAEkA]] |

:::

:::column
:::gear **Havoc Demon Hunter** Enchantments in Raid
```json
{
  "source_code": "IwFZBJQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGEEPuJgQEYAQ9NAREIgyA5OAAAAAABMQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243971]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAEkAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing a **Havoc Demon Hunter** in raiding, different racial traits can provide combat benefits to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:58984]] -- Nightelf
  
  - Can be used to drop aggro, and sometimes avoid certain mechanics altogether.
  - Has limited uses in Raid, but can be very useful in Mythic+.
- [[spell:202719]] -- Bloodelf
  
  - Removes 1 beneficial effect from hostile targets around you.
  - Generates 15 Fury.
- [[spell:256948]] -- Voidelf
  
  - Tear a rift in space. Reactivate this ability to teleport through the rift.

### Recommendation

It does not really matter which Race you chose for **Havoc Demon Hunter**, as dps differences are marginal, it is however advised to go Blood Elf for raid as it is usually ever so slightly higher dps, and Night Elf for M+ as it provides the superior utility for this type of content with the correct use of  [[spell:58984]]. Remember if you are Blood Elf, [[spell:202719]] might come in handy in some situations where you need a quick AoE purge, or it can be used to gain 15 Fury while you are fury starved or out of range of any target in combat.

## Macros

Discover recommended macros for **Havoc Demon Hunter** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**@Cursor [[spell:191427]] Macro - *Uses your [[spell:191427]] at your cursor's location***

```wow-macro
#showtooltip
/cast [@Cursor] Metamorphosis
```

**@Cursor [[spell:207684]] Macro - *Uses your [[spell:207684]] at your cursor's location***

```wow-macro
#showtooltip
/cast [@Cursor] Sigil of Misery
```

:::

:::details Mouseover Macros
**@Mouseover [[spell:217832]]** **Macro - *Casts [[spell:217832]]*** on your ***Mouseover target if you have one, casts it on your current target if you don't have a Mouseover.***

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Imprison
```

**@Mouseover [[spell:195439]]** **Macro - *Interrupts your Mouseover target if you have one, Interrupts your current target if you don't have a Mouseover.***

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][] Disrupt
```

:::

:::details General Macros
**@Player [[spell:191427]] Macro - *Uses your [[spell:191427]] at your current location***

```wow-macro
#showtooltip
/cast [@Player] Metamorphosis
```

**@Focus [[spell:195439]] Macro - *Uses your [[spell:195439]] at your focus target***

```wow-macro
#showtooltip
/cast [@focus] Disrupt
```

**Set focus Macro - *Sets your Mouseover target as focus if you have one, sets your target as focus if you don't have a Mouseover.***

```wow-macro
/focus [@mouseover,exists][]
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Havoc Demon Hunter**.

![](<https://assets-ng.maxroll.gg/wordpress/Skjermbilde-2026-08-08-020134-1024x575.png>)

Verb's UI for **Havoc Demon Hunter**

Addons can be very helpful both inside and outside of combat. The addons listed below are often considered most essential to any raider.

:::accordion
:::details Addons
- **MRT** -- Notes, Raid cooldowns, and more
  
  - Helpful addon for Raiders, especially for Raid leaders and officers.
- **BigWigs** *-- Generic Boss Mod*  
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **EllesmereUI** -- All rounder UI addon
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**DEMON HUNTER**

- Havoc
  
  - Developers' notes: The following changes to Fury generation are a small overall increase, paced more smoothly and relying less heavily on Immolation Aura's talent effects.
  - Demon Blades, Blade Dance, and Chaos Strike now require equipped Warglaives, Axes, Swords, and Fist Weapons.
  - New Talent: Never Say Die – Damage increased by 3% while above 50% Health. Leech increased by 5% while below 50% Health.
  - Trail of Ruin has been updated – Damage is now applied immediately, rather than as a damage over time effect over 4 seconds.
  - Serrated Glaive has been updated – Effect is now a buff on the Demon Hunter with a 12 second duration, rather than a debuff on enemy targets with a 15 second duration.
  - Blade Dance damage increased by 6%.
  - Death Sweep damage increased by 6%.
  - Chaos Strike damage increased by 6%.
  - Annihilation damage increased by 6%.
  - The Hunt damage increased by 12%.
  - Immolation Aura damage reduced by 8%.
  - Essence Break initial damage increased by 49%.
  - Burning Hatred now causes Immolation Aura to generate an additional 30 Fury (was 40).
  - Demon Blades now generates 10-16 Fury per attack (was 8-15).
  - Blind Fury now causes Eye Beam to generate 10/20 Fury per second (was 15/30 Fury).
  - Inertia now increases damage by 12% for 6 seconds (was 18% for 5 seconds).
  - Inner Demon has moved and is now a choice node option with Chaos Theory (was a choice node option with Chaotic Transformation).
  - Dash of Chaos has been removed.

:::

:::

## FAQ

:::accordion
:::details Q: Is it worth holding my [[talent:112939]] for X?
A: It is almost never worth holding your Eye Beam for specific points unless you hold it for less than 3-4 seconds. You are better off just using your [[spell:198013]], [[spell:258860]] and [[spell:198793]] on cooldown.

:::

:::

---

### Credits

Written By: **Verb**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1

**2026-06-19** Updated for patch 12.0.7

**2026-02-10** Updated for patch 12.0.1

**2026-01-09** Updated for patch 12.0

**2025-12-03** Updated for patch 11.2.7

**2025-10-09** Updated for patch 11.2.5

**2025-08-03** Updated for patch 11.2.0

**2025-06-19** Updated for patch 11.1.7

**2025-02-25** Updated for patch 11.1.0

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
