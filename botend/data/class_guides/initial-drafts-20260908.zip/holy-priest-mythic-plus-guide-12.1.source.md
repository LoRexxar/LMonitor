Welcome to the **Holy Priest** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 3/5 · Average

Damage · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 2/5 · Weak

Mobility · 1/5 · Subpar



:::

:::

:::column
:::gear **Holy Priest** Mythic+ Best in Slot Gear
```json
{
  "source_code": "JcpAwbVABc__BEgAmQgAREAAvj7AJ16AC06ACKgF2gVABk-FEAQEBAgEtOg-sOggCwYNYFQABTCBCgQAAUTuDIoAOFQAGTCBCgQAAMSuDIoAOFQAATCBAiQAAwQADxgTBEgwB4BDFAwGqWgHUIgbCEw3XUwPA8QA_gMWBEAIoOAhIEAAeA8Ano6AM06A3WzSBEAxkQAAIUAACKAWBM9FEEgnqJggIEAA1j7AM0aBIBRAAU9ACajEAghUfQAAIEAAFMJAU1BDE09FNgBKYFQA0LCBCgQAAMQD7RTCAPAB4EAA0B8AeA8AA0RAMcbNLFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240969]] · [[item:240898]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240914]] · [[item:240890]] |
| 肩部 | [[item:271553]] | [[item:244021]] |
| 胸部 | [[item:271558]] | [[item:244003]] |
| 腰部 | [[item:271552]] | [[item:240908]] |
| 腿部 | [[item:271554]] | [[item:240155]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240908]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271556]] |  |
| 戒指一 | [[item:158366]] | [[item:240908]] · [[item:243957]] |
| 戒指二 | [[item:251136]] | [[item:240908]] · [[item:243957]] |
| 饰品一 | [[item:270162]] |  |
| 饰品二 | [[item:270164]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:243971]] |
| 副手 | [[item:245769]] | [[item:245876]] · [[item:245790]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Holy Priest**, you have access to Benediction, which has a chance to transform your [[spell:2061]] into a more powerful version.

**Rank 2** and **Rank 3** increases all your healing by 12% and your [[spell:243241]] healing by 30%.

**Rank 4** guarantees Benediction procs and enhances with your [[spell:64843]] with [[spell:243241]] procs.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-holypriest-mxr.webp>)

Benediction

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look at **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:103762]]
    
    - Your critical effects strike for 220%.
  
  
  
  - [[talent:103733]]
    
    - Empowers your [[talent:103775@FAQA1UwE]] massively, but removes [[talent:103766]].
- **Removed**
  
  - [[spell:391387]] 
    
    - This results in a lot lower [[talent:103748@FAQADh5A]] uptime.

## Hero Talents

- [[talent:123291]] focuses on big spikey healing output, while [[talent:123290]] focuses on enhancing your constant healing output and providing utility to the team.
- This Guide recommends playing [[talent:123292]], and therefore only covers that Hero Talent option.



### [[talent:123291]]

- When casting [[spell:120517]] you also periodically create more Halos that return to you. They are enhanced by the following nodes and grant you certain benefits:
  
  - [[talent:117284]]
    
    - Creates multiple [[spell:120517]].
  - [[talent:117279]]
    
    - Applies an increased healing taken buff to any ally hit by a [[spell:120517]] ring.
  - [[talent:117281]]
    
    - Massively increases the effectiveness of each [[spell:120517]].
  - [[talent:117305]]
    
    - [[spell:120517]] return to you after reaching max distance.




### [[talent:123290]]

- [[talent:123290]] enhances primairly your [[spell:33076]].
  
  - [[talent:117286]]
    
    - Gives you 2 stacks of [[spell:33076]].
  - [[talent:117282]]
    
    - Reduces the base cooldown of [[spell:33076]].
  - [[talent:117276]]
    
    - Instantly heals your [[spell:33076]] target by a good amount.





## Talents



### General Talent Build

:::talents **Holy Priest** Mythic+ Talents
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### When to use this Spec

This is the default loadout going into any dungeon. You need to adjust class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, dungeon specific talent loadouts are available in the Dungeon section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look, check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:390994]] 
  
  - This crucial talent restores harmony to the flow of your healing rotation as it allows [[spell:33076]] and [[spell:14914]] to reduce
- [[spell:372616]]
  
  - The talent significantly increases the amount of [[spell:14914]] you can cast during a dungeon and offers a way to keep up your damage while moving, since the extra [[spell:14914]] are instant.
- [[spell:372307]]
  
  - Transforms [[spell:14914]] into your most powerful damage spell in any scenario, allowing you to add meaningful damage in AoE pulls.
- [[spell:235587]]
  
  - Enables you to prepare effectively for critical moments by granting you an additional charge of your healing Holy Words. This greatly enhances the value of the **Holy Priest's** core cooldown reduction mechanic, as you can now retain one charge for emergencies.
- [[spell:200209]]
  
  - Enables you to use [[spell:47788]] more frequently, greatly easing difficult encounters.
- [[spell:392988]]
  
  - Rewards you for planning ahead with your Holy Words. The Naaru is empowered by each Holy Word you cast, but the empowerment only lasts for a short duration.

##### Class Tree

- [[spell:109186]]
  
  - This talent significantly helps with mana management and mobility, providing you with an additional recovery tool while on the move.
- [[spell:336897]]
  
  - You also gain the effects of [[spell:10060]] when you cast it on an ally.
- [[spell:193063]]
  
  - In combination with [[spell:368276]] and [[spell:109186]], this talent provides you with an easily accessible 10% damage reduction.
- [[talent:103835]]
  
  - Adds a new but weak defensive ability to the Priest class toolkit. However, when combined with [[spell:193063]], it could save your life!





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** Each target affected by your ‍[[spell:139]] increases your Critical Strike chance by 2%, up to 6%.
- **4-Set:** ‍[[spell:139]] healing increased by 10%. ‍[[talent:103779]] now has a 100% chance to leave a ‍[[spell:139]] on the first target ‍[[spell:33076]] heals.

### Priority List

#### For Healing

1. Cast [[spell:33076]] on Cooldown.
2. Cast [[spell:2050]] if at 2 charges.
3. Cast [[spell:2050]] if people require enough single target.
4. Cast [[spell:23455]] on Cooldown.
5. Cast [[spell:2061]] to reduce the Cooldown of  [[spell:2050]].

#### For Damage

1. Cast [[spell:14914]] on Cooldown
2. Cast [[spell:88625]] on Cooldown
3. Cast [[spell:585]]

### Cooldowns

#### Divine Hymn

- With the recent changes to [[spell:64843]] scaling within dungeons, it has become a potent cooldown. Maximizing this cooldown is all about making use of the increased healing taken buff on the group afterwards!

#### Apotheosis

- [[spell:200183]] is your biggest output cooldown for both damage and healing. Use it as often as possible to reset the cooldowns of your Holy Words and save Mana. During [[spell:200183]], prioritize casting [[spell:2061]], as it reduces the cooldown of [[spell:2050]] the most.

## Deep Dive

### Optimizing Power Infusion

- While [[spell:10060]] is your spell, the optimal usage is to prioritize your teammates' benefit over your own. To achieve this, track your party members' offensive cooldown uptime. It is recommended to simply communicate with your teammates and ask them to request it at the exact time they need it.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Holy Priest** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.




### Den of Nalorakk

:::talents **Holy Priest** Mythic+ Build in Den of Nalorakk
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]].
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
  
  
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.




### Murder Row

:::talents **Holy Priest** Mythic+ Build in Murder Row
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.




### The Blinding Vale

:::talents **Holy Priest** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.




### Voidscar Arena

:::talents **Holy Priest** Mythic+ Build in Voidscare Arena
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.




### Kings' Rest

:::talents **Holy Priest** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.




### Ruby Life Pools

:::talents **Holy Priest** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.




### Temple of Sethraliss

:::talents **Holy Priest** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA",
  "code": "CGQAeZKRuNSooft8tRxtaN5SHxYAAAAAAAbGzYWGzwMjhZYsMzMzAAAAYMzyMYmZGmxMDgZKAmZBDhxsMAjBWMzMA0MmZMGMDwMzMwA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.





### Affixes

The Affix system got adjusted going into **Midnight Season 1,** making it more beginner friendly:

- +2 Affix
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  
  
  
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
- +6 Affix
  
  - [[spell:1284818]] removed
- +7 Affix -- Alternates between each other on a weekly basis
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes -- Both affixes are present
  
  - Tyrannical
  
  
  
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Holy Priest**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:8122]] or [[spell:32375]] to interrupt as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - There is nothing special you can do to help with this affix.
- Xal'atath's Bargain: Devour
  
  - You can remove all debuffs at once with [[spell:32375]]. If [[spell:32375]] is on cooldown make sure to instantly single dispel one healing absorb debuff!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Holy Priest**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority
```json
{
  "source_code": "IoAJFUAIoEDJBMwABA"
}
```
**智力 ＞ 暴击 ≥ 全能 ≥ 精通 ＞ 急速**
:::

> The conclusion here is that you want to equip the highest item level generally.

All secondary stats are affected by **diminishing returns**. [Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to learn more!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful Leech is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/MyUb2Ci-1024x491.png>)

Warcraftlogs

## Gear



### Best in Slot

Due to the way stat weights work for **Holy Priest**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271874@DERAAEQAvj7kUrjAtOCKgF2gVA]] | Ula'tek |
| Neck | [[item:268265@BERAAEQAS06oPrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271553@DgQAAEQA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAEQACKAWBA]] | Coiled Altar |
| Chest | [[item:271558@DgQAAEQAjk7IoAOF]] | Tier/Catalyst |
| Wrist | [[item:239648@FiQAAEQAeA8ciqDDtO3WzSB]] | Crafting |
| Gloves | [[item:271556@BgQAAEQACKAWBA]] | Tier/Catalyst |
| Belt | [[item:271552@BiQAAEQAM06IoAOF]] | Tier/Catalyst |
| Legs | [[item:159234@AgQAA8rBOFA]] (Catalyze to Tier) | King's Rest |
| Boots | [[item:268255@DgQAAEQAPk7IoAYF]] | Coiled Altar |
| Ring 1 | [[item:158366@DiQAAEQA1j7wQrjgC4UA]] | Temple |
| Ring 2 | [[item:251136@DiQAAEQA1j7wQrjgC4UA]] | Murder Row |
| Trinket 1 | [[item:270162@BgQAAEQACKgTBA]] | Nek'Zali |
| Trinket 2 | [[item:270164@BgQAAEQACKgTBA]] | Lost Explorers |
| Weapon | [[item:271092@DgQAAEQADk7IoAYF]] | Ula'tek |
| Off-Hand | [[item:245769@FgTAAEQA0B84BwDAAAAAAAAAAAAAAAwt1sUA]] | Crafting |

#### Authors Note:

This list shows the best items for healing in Mythic+ from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251199@AgQAAIoABFA]] | The Blinding Vale |
| Neck | [[item:251234@AgQAAIoABFA]] | Voidscar Arena |
| Shoulder | [[item:251227@AgQAAIoABFA]] | Voidscar Arena |
| Cloak | [[item:251132@AgQAAIoABFA]] | Murder Row |
| Chest | [[item:239032@AgQAAIoABFA]] | Temple |
| Wrist | [[item:251154@AgQAAIoABFA]] | Den |
| Gloves | [[item:273773@AgQAAIoABFA]] | Altar of Fangs |
| Belt | [[item:159255@AgQAAIoABFA]] | Temple |
| Legs | [[item:159234@AgQAA8rBOFA]] | King's Rest |
| Boots | [[item:159259@AgQAAIoABFA]] | Temple |
| Ring 1 | [[item:158366@DiQAAEQA1j7wQrjgCEUA]] | Temple |
| Ring 2 | [[item:251136@DiQAAEQA1j7wQrjgCEUA]] | Academy |
| Trinket 1 | [[item:250214@AgQAAIoABFA]] | Academy |
| Trinket 2 | [[item:250215@AgQAAIoABFA]] | Murder Row |
| Two-Hand Weapon | [[item:193761@AgQAAIoABFA]] | Ruby Life Pools |
| One-Hand Weapon | [[item:251225@AgQAAIoABFA]] | Voidscar Arena |
| Off-Hand | [[item:271681@AgQAAIoABFA]] | Den of Nalorakk |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank |  |
| --- | --- |
| S-Tier | [[item:270164@BgQAAkGACKgTBA]]  <br>[[item:270167@BgQAAkGACKgTBA]]  <br>[[item:270162@AgQAAIoAOFA]] |
| **A-Tier** | [[item:270169@AgQAAIoAYFA]]  <br>[[item:248583@AgQAAIoABFA]]  <br>[[item:251792@AgQAAkjABFA]]  <br>[[item:274493@AgQAAkjABFA]]  <br>[[item:250215@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250214@AgQAAIoAOFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]] |
| **C-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:251789@AgQAAkjABFA]]  <br>[[item:274495@AAQAAEUA]] |
| **Junkyard** | [[item:193748@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]]  <br>[[item:250248@AgQAAIoAOFA]]  <br>[[item:250254@AgQAAIoAOFA]]  <br>[[item:250255@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270171@AgQAAIoAOFA]]  <br>[[item:264701@AAQAAEUA]]  <br>[[item:274494@AAQAAEUA]] |

### Embellishments

- [[item:240167]] 
  
  - Allows you to buff yourself and your party with main stat!
- [[item:245876]]
  
  - Very good stat stick, secondaries depend on the type of enemy.

### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear in that slot.

## Consumables

- **Phials**
  
  - [[item:241326]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]] *-- Recommended*
  - [[item:241300]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@BQAAAEEAaB]]
- **Sockets**
  
  - [[item:240910]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:275707@BAAAAEQA]]  <br>[[item:243951]] |
| --- | --- |
| Shoulders | [[item:244021@BAAAAkG]] |
| Chest | [[item:223692]] |
| Wrist | [[item:275707@BAAAAEQA]] |
| Belt | [[item:275707@BAAAAEQA]] |
| Legs | [[item:240155@BAAAAkG]] |
| Boots | [[item:243983@BAAAAkG]] |
| Ring 1 | [[item:243957@BAAAAEQA]] |
| Ring 2 | [[item:243957@BAAAAEQA]] |
| Weapon | [[item:243971@BAAAAEQA]] |

:::

:::column
:::gear **Holy Priest** Enchantments
```json
{
  "source_code": "JQFZBEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABMSDIgw-0QQBQQwGqmAGA8gOYAAB1jbCYgS94OAAAAAABMQuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:244003]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@BAAAAEQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Holy Priest** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  
  - Removes all magic, bleed, poison, and disease effects and reduces physical damage taken.
- [[spell:58984]] -- Night Elf
  
  - Turns you invisible, any action, taking damage, or moving breaks this effect.
  - Use-cases:
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].

### Recommendation

It is highly recommended to play a Dwarf this season! The higher the keys you run, the more essential [[spell:65116]] becomes in certain dungeons, such as Windrunner Spire and others.

## Macros

Discover recommended macros for **Holy Priest** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this **Holy Priest** Mythic+ Guide are available as mouseover macros for your convenience!

[[spell:33076]]

```wow-macro
/cast [@mouseover, help] Prayer of Mending; Prayer of Mending
```

[[spell:2050]]

```wow-macro
/cast [@mouseover, help] Holy Word: Serenity; Holy Word: Serenity
```

[[spell:2061]]

```wow-macro
/cast [@mouseover, help] Flash Heal; Flash Heal
```

[[spell:10060]]

```wow-macro
/cast [@mouseover,exists] Power Infusion; Power Infusion
```

[[spell:73325]]

```wow-macro
/cast [@mouseover, help] Leap of Faith; Leap of Faith
```

[[spell:47788]]

```wow-macro
/cast [@mouseover, help] Guardian Spirit; Guardian Spirit
```

:::

:::details Recommended Macros
If you press shift while using this macro you get the [[spell:121536]] automatically placed under you, skipping the control click.

```wow-macro
/cast [mod:shift, @player] Angelic Feather; Angelic Feather
```

Replace your [[spell:527]] macro if you wish. This macro makes it so that if you target an enemy you purge and if you target an ally you dispel, saving you a keybind.

```wow-macro
#showtooltip Purify
/use [@mouseover, help] Purify; [harm] Dispel Magic; [noharm] Purify
```

Your [[spell:34861]] instantly goes off when you press the button without having to confirm click, use with caution

```wow-macro
#showtooltip
/cast [@cursor] Holy Word: Sanctify
```

Your [[spell:32375]] instantly goes off when you press the button without having to confirm click, use with caution.

```wow-macro
#showtooltip
/cast [@cursor] Mass Dispel
```

A nice little Priest only macro, if you know you know.

```wow-macro
/cast [nomod] Levitate
/cancelaura [mod:shift] Levitate
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Holy Priest**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/xMsr1We-1024x576.webp>)

**Holy Priest** Mythic+

:::accordion
:::details Addons
- EllesmereUI -- Everything
  
  - Addon to upgrade Blizzards very own UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Holy
  
  - Divine Hymn has been updated – Now additionally grants Guardian Spirit while channeled.
    
    - *Developers' notes: We are adding a benefit to channeling Divine Hymn to make it easier to use. If you already have Guardian Spirit active on yourself, Divine Hymn will add 5 seconds to its duration. If Divine Hymn's channeling is ended early, it will remove whatever time is remaining from the amount that it added.*
  - Apex Talent: Benediction (Rank 3) has been updated – Apotheosis no longer upgrades Flash Heal to Benediction. Holy Word: Serenity now has a 100% chance to upgrade your next Flash Heal to Benediction.
  - Apex Talent: Benediction mana cost reduced by 30% and healing increased by 15%.
    
    - *Developers' notes: We want to address Benediction’s performance by spreading its availability beyond Apotheosis and Prayer of Mending. Additionally, we are increasing the throughput of Benediction, so its impact is felt and contributes more to Holy’s overall throughput. Lastly, we want to further lessen how expensive the rotation of Holy is by specifically targeting Flash Heal and Prayer of Healing.*
  - All healing increased by 16%.
  - Flash Heal mana cost reduced by 10%.
  - Prayer of Healing mana cost reduced by 10%.
  - Apotheosis now reduces the mana cost of Holy Words by 70% (was 50%).
- Hero Talents
  
  - Archon
    
    - Resonant Energy has been slightly redesigned – Creating a Halo increases healing done by 2% for 10 seconds, stacking up to 4 times.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Start using [[spell:47788]] as a personal defensive cooldown.

:::

:::

---

### Credits

Written By: **Rycn**

Reviewed By: **Ftm**

---

:::changelog 更新记录
**2026-08-08** Guide updaed for patch 12.1

**2026-04-22** Guide updaed for patch 12.0.5

**2026-01-15** Guide updaed for patch 12.0

**2025-10-07** Guide updaed for patch 11.2.5

**2025-07-29** Guide updaed for patch 11.2

**2025-06-18** Guide updated for patch 11.1.7

**2025-04-22** Guide updated for patch 11.1.5

**2025-02-25** Guide updated for patch 11.1

**2024-12-17** Guide updated for patch 11.0.7

**2024-10-20** Guide updated for patch 11.0.5

**2024-10-12** Guide updated.

**2024-08-17** Guide Written for patch 11.0.2



:::
