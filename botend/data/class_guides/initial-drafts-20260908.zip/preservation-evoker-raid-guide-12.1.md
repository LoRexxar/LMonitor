欢迎阅读**恩护 唤魔师**《魔兽世界》12.1.0 版本团队副本攻略！本攻略涵盖了理解该角色所需的全部知识。如果你刚刚开始，正在从 80 级升级，请先查看升级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**综合治疗** · 5/5 · 优秀

冷却技能强度 · 5/5 · 优秀

功能性 · 4/5 · 强力

生存能力 · 3/5 · 一般

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **恩护 唤魔师** 团队副本 最佳配装（BiS）
```json
{
  "source_code": "J4oAIybB3_fAB0IJEIICBAw74OwVtOggC4UABk-FEAQEBAgAtOgABIBiMWDWBEwikQgAIUAA1k7ACKAWBc8FEEABmQgAQEAAJk7AMWTAUQRATU9AAiQB3UgRAwYCyQwGqWgMQ18FEEQY7OgBgEAAeA8Ano6APk7AAUQAkcbNLFQAot7AEiQEbggAtOQBVghjkQAAIEAAF4EBZfRBmSw94GgHFIBCeqmABgbHSQAVfkBMAcVHMQQ3X0AGogVABQvIEIACBAQPJgMLBc-FEAACBAggC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271499]] | [[item:244021]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:251155]] | [[item:240898]] |
| 腿部 | [[item:271500]] | [[item:240155]] |
| 脚部 | [[item:244577]] | [[item:245790]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:244584]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270167]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:268263]] |  |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁1级。
- 第二个和第三个天赋点解锁并强化2级。
- 第四个天赋点解锁**巅峰天赋**的3级。

作为**恩护 唤魔师**，你可以使用[[spell:1256577]]，它使你的精华技能有几率将你的下一个[[spell:366155]]变为强化版本。

**第2级**的这个英雄天赋使你所有的 [[spell:367364]] 增益效果获得一个根据其所受伤害进行治疗的效果。而 **第3级**则使你的 [[spell:355936]] 有100%的几率强化你的下一个回溯，并且其初始治疗量提高125%

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-preservation-mxr.webp>)

麦琳瑟拉的祝福

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[spell:373267]]
    
    - 这个天赋过去可以因通过复制的[[spell:360995]]命中施加而拥有多重生效。这已不再可行，也移除了进行大型生命联结叠加的能力。
  - [[spell:1242031]]
    
    - 一个新天赋，与我们的套装效果协同良好，因为每次你按下 [[spell:360995]] 时都会获得一个额外的 [[spell:364343]]，带来大量收益。
  - [[spell:373834]]
    
    - 这个天赋被改动后不再与 [[spell:360995]] 有任何交互，这使得该技能的使用更加自由，不再与增益 [[spell:355936]] 绑定。
- **职业天赋树**
  
  - [[spell:374348]]
    
    - 这个技能从一个主动按钮被改动，现在被整合进你的 [[spell:363916]] 中，整体上弱了很多。
  - [[spell:410352]]
    
    - 这个新天赋是应对超大伤害打击和潜在一击致命的不错的特殊防御选项。
  - [[spell:370889]]
    
    - 这个天赋过去提供吸收护盾，现在为你和你的盟友提供移动施法效果。
  
  
  
  - [[spell:370665]]
    
    - 这个天赋新增了移除你和你的盟友身上移动限制效果的效果。
- **已移除**
  
  - [[spell:367226]] 
    
    - 这个能力从来不是我们在团队副本中治疗的主要部分，但当你没有其他选择、需要用一点小治疗填补空缺时，它是一个不错的填充手段。尤其是在你的团队被分成多个小组的场景中
  - [[spell:370960]]
    
    - 这个能力通常与[[spell:373267]]搭配使用，并将治疗效果复制到团队中的大多数人身上。
  - [[spell:443328]]
    
    - 这个英雄天赋能力在上个资料片中构成了我们大量的爆发治疗。它的移除夺走了我们大部分的一键为全团提供大量爆发治疗的手段。

## 英雄天赋

- [[talent:123335]] 会强化你的许多治疗技能，并将 [[talent:115665]] 变成一个强力的冷却技能。
- [[talent:123332]] 同样会强化你的许多治疗技能，并使你获得 2 层 [[spell:363922]] 和 [[spell:357208]] 的充能。此外，它还使 [[spell:360995]] 和 [[spell:355913]] 消耗你的一部分 [[spell:363922]] 持续治疗效果来造成额外治疗。
- 总体而言，我推荐游玩 [[talent:123332]]，因为它目前非常强力，能为你的治疗技能提供大量增益。该构筑将围绕你的巅峰天赋展开，并从套装效果中持续获得收益。因此本攻略将专注于这套构筑的玩法。

:::tabs
:::tab [[talent:123332]]
- [[spell:1264269]]
  
  - [[spell:363922]] 和 [[spell:357208]] 现在额外增加一层充能。
- [[talent:117534]]
  
  - [[spell:358267]]、[[spell:357210]] 和 [[spell:359816]] 的飞行速度提高 40%，[[spell:358267]] 的飞行距离也提高 40%。
- [[talent:117546]]
  
  - 暴击几率 对生命值高于 50% 的目标提高
- [[spell:1264365]]
  
  - [[spell:357208]] 的冷却时间缩短 5 秒。
- [[spell:1264321]]
  
  - [[spell:357208]] 的持续伤害效果延长 4 秒，[[spell:363922]] 的持续治疗效果延长 6 秒。
- [[spell:1218447]]
  
  - [[spell:363922]] 和 [[spell:357208]] 更频繁地造成伤害和治疗

- [[talent:117543]]
  
  - [[spell:363922]] 和 [[spell:357208]] 现在能更快达到最高蓄力等级。
- [[talent:123767]]
  
  - [[spell:357208]] 的持续伤害和 [[spell:355936]] 的持续治疗量提高。
- [[talent:117517]]
  
  - [[spell:361469]] 有额外几率使你获得 [[spell:369297]]，触发条件是它们爆击.
- [[talent:117528]]
  
  - 在情况需要时，你可以将 [[talent:115669]] 作为施加给队友的外部减伤技能。
- [[spell:1265993]]
  
  - [[spell:363922]] 和 [[spell:357208]] 有 50% 的几率赋予 [[spell:359565]]。
- [[spell:1265979]]
  
  - 消耗 [[spell:359565]] 时，会对目标造成额外的爆发治疗。
- [[spell:1265992]]
  
  - [[spell:1265979]] 最多额外弹跳至两个目标。
- [[talent:117519]]
  
  - 对带有 [[talent:115542]] 的目标施放 [[spell:355913]] 或 [[spell:360995]] 时，现在会消耗一部分持续治疗效果，产生额外治疗。

:::

:::tab [[talent:123335]]
- [[talent:117551]]‍ 
  
  - 使你的 [[spell:361469]] 变为 [[spell:431442]]，这是一个青铜龙法术，会为你提供 [[talent:115543]] 的层数，并会重复你在过去5秒内对目标造成的伤害或治疗的15%。
- ‍[[talent:117545]] 将你普通的 ‍悬空 变为 [[spell:1953]]
  
  - 这目前只在你位于或靠近固体地面时生效，如果你在空中太高处，它就会像普通 [[spell:358267]] 一样运作。请小心，因为它有一个短暂的延迟。
- [[talent:117552]]
  
  - 将你的 [[talent:115665]] 变成一个强大的冷却技能，提高 急速、移动速度以及冷却恢复速率30%，在 [[talent:117552]] 的30秒持续时间内每秒递减1%。
- [[spell:1260484]]
  
  - [[talent:115665]] 的冷却时间缩短30秒。
- [[talent:117522@AJQDBA]]
  
  - [[spell:360995]] 在8秒内额外治疗60%。
- [[talent:117532]]
  
  - 如果时机把握得当，当你用尽其他所有技能时，[[talent:117532]] 可以作为一个非常强力的次级防御冷却技能。
- [[spell:431715]]
  
  - [[spell:373861]] 法力消耗降低15%，冷却时间缩短4秒。
- [[talent:117548@AJQDBA]]
  
  - 你每存在一个由 [[spell:360995]] 施加的持续治疗效果即可获得急速，最多3层。
- [[talent:117529]]
  
  - [[spell:355936]] 和 [[spell:357208]] 在 暴击 时持续时间延长2秒，最长可达12秒。
- [[talent:126310]]
  
  - 你施放强化法术时，其冷却时间最多缩短6秒。
- [[spell:1260647]]
  
  - 强化 [[spell:431442]]，使其造成的伤害和治疗最多提高40%。
- [[talent:117539@AJQDBA]]
  
  - [[spell:364343]] 持续时间延长10%。
- [[talent:117526]] 
  
  - 你每次施放强化法术时，最多3个被你命中的目标会额外被施放一层 [[talent:117551]]‍。

:::

:::

## 天赋

:::tabs
:::tab [[talent:123332]]
:::talents **恩护 唤魔师** 时空守卫 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 何时使用该专精

这是进入任何战斗所使用的 [[talent:123332]] 配装。你需要根据战斗所需的实用技能来调整职业天赋树。为了让你更轻松，针对各个首领的特定天赋配装可在 团队副本 部分找到。

### 改变游戏玩法的天赋

探索专精和职业天赋树中显著改变你游戏方式的所有天赋。本节将简明概述这些天赋及其应用，如需更详细的了解，请查看下方的循环和深度解析部分。

#### 专精树

- [[spell:363534]]
  
  - 治疗术 过去 5 秒内所受伤害的 33%。
- [[spell:357170]]
  
  - 你的外部冷却技能会将在接下来 8 秒内所受的伤害延迟结算 50%。
- [[spell:370537]]
  
  - 复制并储存你接下来的3个治疗法术。以下法术顺序是推荐你在 [[spell:355936]] 使用时复制的技能。[[spell:373861]] [[spell:364343]]
- [[talent:115573]]
  
  - 变身为 深呼吸 并飞过你的盟友以治疗他们，并为他们施加一个持续15秒的持续治疗效果。
- [[spell:1242031]]
  
  - 这个天赋为你提供额外的 [[spell:364343]]，并与你的套装在你施放 [[spell:360995]] 时放置的 [[spell:355913]] 产生协同效果

#### 职业树

- [[spell:374227]]
  
  - 使20码内所有盟友受到的范围伤害效果伤害降低20%，持续8秒，同时移动速度提高30%。
- [[spell:370553]]
  
  - 使你的下一个强化法术以最高等级瞬发施放。并通过你的英雄天赋[[spell:431695]]为你提供大量[[spell:359565]]增益效果
- [[spell:374251]]
  
  - 独特的驱散技能，除了毒、诅咒和疾病之外，还能移除流血效果。
- [[spell:374968]]
  
  - 为你和你的盟友提供一次主要移动冷却技能的免费充能，对你自己而言，该技能为 [[spell:358267]]。

#### 英雄天赋

- [[talent:117532]]
  
  - 如果时机把握得当，[[talent:117532]] 在你用尽其他所有技能时可以作为一个非常强力的次要防御冷却技能。
- [[talent:126310]]
  
  - 你的蓄力法术在施放时会最多缩短6秒。这使你的 [[spell:355936]] 自然地与 [[spell:373861]] 对齐，并允许你复制更多的 [[spell:1256581]]

:::

:::

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套**：消耗 [[spell:369297]] 会向你的目标，或其满血时附近一名受伤的目标，以100%效果释放一个 [[spell:361469]]。
- **4件套**：绿系法术恢复的生命值提高5%，且 [[spell:360995]] 有100%几率赋予 [[spell:369297]]

:::tabs
:::tab [[talent:123332]]
### 优先级列表

#### 治疗方面

1. 如果没有触发 [[spell:1256581]]，施放1级 [[spell:355936]]
2. 在当前没有 [[spell:364343]] 存在时施放 [[spell:360995]] 以获取 [[spell:369297]]
3. 施放 [[spell:373861]] 以施加 [[spell:364343]]。
4. 如果有任意 [[spell:364343]] 即将结束时，施放 [[spell:1256581]]。
5. 在任何 [[spell:364343]] 结束之前施放 [[spell:366155]]。
6. 如果你有 [[spell:369297]] 触发，施放 [[spell:355913]] 以从 [[spell:1242031]] 中获益
7. 将能量花费在 [[spell:364343]] 上。
8. 施放 [[spell:1256581]]
9. 施放 [[spell:366155]]
10. 施放 [[spell:360995]] 可立即进行目标治疗
11. 施放 [[spell:361469]] 或 [[spell:382266]] 以获取 [[spell:369297]]，从而免费施放能触发 [[spell:1242031]] 的 [[spell:355913]]。

#### 输出方面

1. 在冷却完毕时施放 [[spell:382266]]。
2. 施放 [[spell:361469]]。

### 冷却技能

#### 梦境飞行

- 飞过你的盟友并施加持续治疗以及直接治疗，在此期间你免疫任何移动限制和失控效果，你可以用它来进行战斗中的位移、解除定身，或单纯作为一个不错的治疗冷却技能，小心不要飞进正面攻击范围或其他可能害死你的首领机制中！

#### 时间膨胀

- [[spell:357170]] 是 whenever 有盟友陷入危险时的首选外部减伤。

#### 静滞

- [[spell:370537]] 是团本中一个强大的冷却技能，能提供显著的实用价值。在使用该技能时，你应默认复制 2 层 [[spell:355936]] 和 [[spell:373861]]。
- 此外，只要战斗中合适，你可以花费大量时间来准备一个存有2-3次[[spell:373861]]充能的[[spell:370537]]，以便用[[spell:364343]]覆盖团队中的大多数人。这些回响可以用于[[spell:355936]]、[[spell:366155]]或[[spell:360995]]
  
  - 每当战斗早期有治疗需求时，请在开怪前完成这一操作。

#### 扭转天平

- [[spell:370553]] 与[[spell:355936]]配合使用时可提供极佳的按需爆发治疗，或者也可以用于施放[[spell:382266]]而无需花费时间引导至最高等级。

#### 回溯

- [[spell:363534]] 是 唤魔师 迄今为止最强大的冷却技能，几乎可以凭一己之力挽救任何危险局面。由于其冷却时间极长，最好仔细规划使用时机。

:::

:::

## 深度解析

#### 回溯 的极限优化

- 你受到的伤害越高，[[spell:363534]]的治疗量就越多。尽量延迟使用它，使你的团队受到尽可能多的伤害，但如果有人生命值降至30%以下，则立即施放。不要因为贪用这个冷却技能而让任何人死亡！

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

:::tabs
:::tab 内克扎莉
:::talents **恩护 唤魔师** 内克扎莉 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 在房间边缘驱散中了 [[spell:1287322]] 的队友！
- 当首领施放 [[spell:1284103]] 时，不要站在首领和坦克之间。

:::

:::tab 陵寝哨兵
:::talents **恩护 唤魔师** 陵寝哨兵 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 驱散受到[[spell:1284471]]影响的玩家。
- [[spell:1284590]] 在恰好叠到4层时会无害地被中和。

:::

:::tab 迷失的探险者
:::talents **恩护 唤魔师** Lost Explorers 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 驱散受到[[spell:1286921]]影响的人。

:::

:::tab 瓦什尼克
:::talents **恩护 唤魔师** 瓦什尼克 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 对受到 [[spell:1295224]] 影响的玩家使用单体技能（外部增益）。在受影响期间，他们免疫你的常规治疗。
- 受到 [[spell:1294994]] 影响时请使用个人减伤。

:::

:::tab 斯索拉克
:::talents **恩护 唤魔师** 斯索拉克 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 对受到 [[spell:1286987]] 影响的玩家使用单体技能（外部增益）。

:::

:::tab 双牙
:::talents **恩护 唤魔师** 双牙 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 防御技能
  
  - 在受到[[spell:1290809]]影响时使用个人防御技能。

:::

:::tab 盘绕祭坛
:::talents **恩护 唤魔师** 盘绕祭坛天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。

:::

:::tab 乌拉特克
:::talents **恩护 唤魔师** 乌拉特克 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 这些首领攻略技巧将在世界首杀竞速赛结束后提供。

:::

:::tab 尼姆瑞莎·唤波者
:::talents **恩护 唤魔师** 尼姆瑞莎·唤波者 团队副本 天赋
```json
{
  "source_code": "CybB282ha6SMH_EjNYLtBJiO_AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB",
  "code": "CybB282ha6SMH/EjNYLtBJiO/AAAAAAYmZ2MDGmZMbGmZmlZAAAmxMmBjZkZmBAAAYmZmMjZGzyMzAgZMzYmlNWswwMzMN0sZYzwYmBzMjB"
}
```
:::

### 首领攻略技巧

- 当大量 [[spell:1257717]] 被触发时，使用个人防御技能。

:::

:::

## 属性优先级

了解你作为 **恩护 唤魔师** 在 团队副本 首领战中获得最佳表现所需的次要属性优先级和第三属性。欲了解更多详细信息，请访问 **[属性与属性值](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **恩护 唤魔师** 团队副本 属性优先级
```json
{
  "source_code": "IoAJFUQMgQCKBEQABA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> 此处的结论是，你通常应当装备装等最高的装备。

- 暴风雪 引入了属性收益递减机制，你应当对此有所了解。想了解它们是什么以及为什么需要关注，请点击[这里](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) 查看我们详细的属性递减机制资源帖！

### 第三属性

- **闪避** - 降低你受到的 范围伤害 效果伤害。
- **吸血** - 将你造成的一部分伤害和治疗量转化为对你的治疗。（不包括自我治疗）
- **加速** - 提高移动速度。（可与其他移动速度技能叠加）

唯一需要你考虑选择较低装等装备的情况，是当它带有 **吸血** 或 **闪避** 时。**加速** 锦上添花，但在两件装备之间做选择时不应考虑该属性。

- 下面展示 **吸血** 对治疗者来说有多强大：

![](<https://assets-ng.maxroll.gg/wordpress/PresEvokerBreakdown-1024x342.png>)

**恩护 唤魔师** 来自 Warcraftlogs 的治疗统计

## 装备

:::tabs
:::tab 最佳配装
| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271501@DiQAAwbBvj7cVrjgC4UA]] | 套装 / 催化 |
| 项链 | [[item:268265@BERAAwbBC06IQrjgCwYNYFA]] | 乌拉特克 |
| 肩部 | [[item:268231@DgQAAwbB1k7IoAYF]] 催化为 [[item:271499@DgQBAwbB1k7IoAYFwxXQ]] | 盘蛇祭坛 |
| 披风 | [[item:268253@BgQAAwbBCKAWBA]] | 盘蛇祭坛 |
| 胸部 | [[item:271876@DARAAwbBJk7wYNCKAWB]] | 乌拉特克 |
| 腕部 | [[item:244584@FiQAAwbBeA8ciqjAtO3WzSB]] | 制造装备 |
| 手套 | [[item:271502@BgQAAwbBCKgTBA]] | 套装 / 催化 |
| 腰带 | [[item:251155@BiQAAwbBC06IoAOF]] | 纳洛拉克的洞穴 |
| 腿部 | [[item:268237@DgQAAwbBbo6IoAYF]] 催化为 [[item:271500@DgQBAwbBbo6IoAYFQzXQ]] | 盘蛇祭坛 |
| 脚部 | [[item:244577@HASAAwbBeA8ciqzD5OAAAAAAAA3WzSB]] | 制造装备 |
| 戒指 1 | [[item:268249@DiQAAwbB3j7IQrjgC4UA]] | 瓦什尼克 |
| 戒指 2 | [[item:158366@DiQAAwbB3j7IQrjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:270164@BgQAAwbBCKgTBA]] | 迷失的探险者 |
| 饰品 2 | [[item:270167@BgQAAwbBCKgTBA]] | 尼姆瑞莎·唤波者 |
| 单手武器 | [[item:271092@DgQAAwbB9k7IoAYF]] | 乌拉特克 |
| 副手 | [[item:268263@BgQAAwbBCKgTBA]] | 尼姆瑞莎·唤波者 |

:::

:::tab 可刷取的替代装备
下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取位置 |
| --- | --- | --- |
| 头部 | [[item:239035@BgQAAwbBCKQQBA]] | 塞塔里斯神庙 |
| 项链 | [[item:251234@BgQAAwbBCKQQBA]] | 虚空之痕竞技场 |
| 肩部 | [[item:239049@BgQAAwbBCKQQBA]] | 诸王之眠 |
| 披风 | [[item:251132@BgQAAwbBCKQQBA]] | 密谋小径 |
| 胸部 | [[item:251233@BgQAAwbBCKQQBA]] | 虚空之痕竞技场 |
| 护腕 | [[item:159380@BgQAAwbBCKQQBA]] | 塞塔里斯神庙 |
| 手套 | [[item:193752@BgQAAwbBCKQQBA]] | 红玉新生法池 |
| 腰带 | [[item:251155@BgQAAwbBCKQQBA]] | 纳洛拉克的洞穴 |
| 腿部 | [[item:159375@BgQAAwbBCKQQBA]] | 塞塔里斯神庙 |
| 靴子 | [[item:159388@BgQAAwbBCKQQBA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251136@BgQAAwbBCKQQBA]] | 密谋小径 |
| 戒指 2 | [[item:158366@BgQAAwbBCKQQBA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:250215@BgQAAwbBCKQQBA]] | 密谋小径 |
| 饰品 2 | [[item:250214@BgQAAwbBCKQQBA]] | 夺目谷 |
| 双手武器 | [[item:193761@BgQAAwbBCKQQBA]] | 红玉新生法池 |

:::

:::

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270164@BgQAAEEACKgTBA]]  <br>[[item:270167@BgQAAEEACKgTBA]] |
| **A级** | [[item:250214@BgQAAEEACKgTBA]]  <br>[[item:270162@BgQAAEEACKgTBA]]  <br>[[item:250215@BgQAAEEACKgTBA]] |
| **B级** | [[item:273649@BgQAAEEACKgTBA]]  <br>[[item:270171@BgQAAEEACKgTBA]]  <br>[[item:270169@BgQAAwbBCKAWBA]]  <br>[[item:273794@BgQAAEEACKgTBA]]  <br>[[item:273796@BgQAAEEACKgTBA]] |
| **C级** | [[item:250254@BgQAAEEACKgTBA]]  <br>[[item:250224@BgQAAEEACKgTBA]]  <br>[[item:193748@BgQAAEEACKgTBA]]  <br>[[item:193757@BgQAAEEACKgTBA]] |
| **垃圾级** | [[item:250248@BgQAAEEACKgTBA]]  <br>[[item:250259@BgQAAEEACKgTBA]]  <br>[[item:250255@BgQAAEEACKgTBA]] |

### 美化饰品

- [[item:240167]] 2件
  
  - 一种可以附加在任意制造业制造护甲上的通用美化装饰。通常建议将带有 [[item:240167]] 的美化装饰制作在披风和护腕部位，因为制造业制造的物品物品等级较低，而这两个部位的属性数值最少。由于披风部位有一个 344 等级的物品，通常的披风制造改为制作在靴子部位。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

## 消耗品

- **合剂**
  
  - [[item:241322]]
- **食物**
  
  - [[item:255845]]
- **战斗药水**
  
  - [[item:241300]]
  - [[item:241288]] —— 推荐
- 治疗药水
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240898]]
  - [[item:240983]]

### 附魔

:::columns
:::column
| 头部 | [[item:243951@DAAAAwbBZbAB]]  <br>[[item:275707]] |
| --- | --- |
| 肩部 | [[item:244021@BAAAAwbB]] |
| 胸部 | [[item:243977@BAAAAwbB]] |
| 护腕 | [[item:275707]] |
| 腰带 | [[item:275707]] |
| 腿部 | [[item:240155@BAAAAwbB]] |
| 脚部 | [[item:243983@BAAAAwbB]] |
| 戒指 1 | [[item:243959@BAAAAwbB]] |
| 戒指 2 | [[item:243959@BAAAAwbB]] |
| 武器 | [[item:244031@BAAAAwbB]] |

:::

:::column
:::gear **恩护 唤魔师** 附魔
```json
{
  "source_code": "JQFZ8WQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> 你可以从宏伟宝库商人处购买 [[item:275707]] 来为你的头盔、护腕和腰带添加插槽。

## 宏

了解**恩护 唤魔师**在团队副本战斗中的推荐宏，并观看一段关于如何为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
为方便起见，本**恩护 唤魔师** 团队副本攻略中的所有技能均以鼠标指向宏的形式提供！

**[[spell:355913]]**

```wow-macro
/cast [@mouseover, help] 翡翠之花; 翡翠之花
```

**[[spell:364343]]**

```wow-macro
/cast [@mouseover, help] 回响; 回响
```

**[[spell:360823]]**

```wow-macro
/cast [@mouseover, help] 自然平衡; 自然平衡
```

**[[spell:374251]]**

```wow-macro
/cast [@mouseover, help] 灼烧之焰; 灼烧之焰
```

**[[spell:366155]]**

```wow-macro
/cast [@mouseover, help] 逆转 ; 逆转
```

**[[spell:360995@FJQBKHXBOLZB2vYB7zwB-zwBNEA]]**

```wow-macro
/cast [@mouseover, help] 青翠之拥; 青翠之拥
```

:::

:::details 推荐宏
**[[spell:370665]] 指定玩家的宏** --- *将 PLAYERNAME 替换为你的小队成员之一。*

```wow-macro
/cast [@PLAYERNAME, @Cursor] 营救
```

:::

:::

## 插件

下面是作者的**恩护 唤魔师**用户界面截图，其中说明了使用了哪些插件，以及如何在团队副本中利用它们来让你的游戏体验更轻松。

![](<https://assets-ng.maxroll.gg/wordpress/euiEvoker-1-1024x576.png>)

恩护 唤魔师 团队中的界面

:::accordion
:::details 插件
- **EllesmereUI**—— 全套界面替换插件
  
  - 整个界面由 Ellesmere ui 打造，它控制团队框架、伤害统计、姓名板、动作条和冷却管理器。此外还增添了许多实用的小功能，并且高度可自定义

:::

:::

## 本次版本改动

:::accordion
:::details 12.1.0 版本
**唤魔师**

- 恩护
  
  - 顶尖天赋：麦琳瑟拉的祝福 已更新——现在使 梦境吐息 的所有治疗效果提高60%（原为250%，且此前仅作用于其瞬时治疗）。
  - 魔法之泉已更新——现在还会使 梦境吐息 和 火焰吐息 的蓄力时间缩短20%。
  - 梦境吐息 瞬时治疗效果降低50%。
  - 梦境吐息 周期性治疗效果提高118%。
  - 时光屏障吸收量提高30%。
  - 内焰使周期性治疗效果提高50%（原为60%）。
  - 灵魂明晰使 梦境吐息 的冷却时间缩短6秒（原为10秒）。
  - 飘絮幼苗的治疗量现在也会被泰坦之赐提高。
  - 修复了可能导致 时间膨胀 在死亡时无法清除其储存伤害的问题。
  - 修复了 吞噬烈焰 的治疗量不会受到宽限期或类似效果加成的问题。
  - 英雄天赋
    
    - 塑焰者
      
      - 肺活猛增 使 梦境吐息 的治疗效果提高20%（原为30%）。
      - 烈焰导体 使爆击几率提高10%（原为15%）。不影响 湮灭 唤魔师。
      - 迅雷咆哮 使 火焰吐息 和 梦境吐息 造成伤害的频率提高15%（原为20%）。不影响 湮灭 唤魔师。
      - 飘絮幼苗现在可以触发 吞噬烈焰。
      - 在天赋点出 吞噬烈焰 时，翡翠之花 和飘絮幼苗现在会优先治疗带有 梦境吐息 激活状态的受伤盟友。
      - 吞噬烈焰 的治疗量为消耗量的240%（原为200%）。
      - 修复了 吞噬烈焰 的治疗部分无法爆击治疗的问题。
      - 孪生烈焰 伤害和治疗量降低20%。
      - 修复了 孪生烈焰 不会随精通成长的问题。

:::

:::

## 常见问题

:::accordion
:::details 问：为什么我的法力值会用完？
答：你施放了太多[[spell:355913]]和[[spell:373861]]。

:::

:::details 问：为什么在没有大招（冷却技能）的情况下队友会死？
答：你需要更好地利用[[spell:364343]]的铺场衔接[[spell:366155]]。

:::

:::details 问：我应该把[[spell:364343]]和什么法术搭配使用？
答：一般来说保持[[spell:366155]]，然后用[[spell:355936]]进行大额治疗。

:::

:::

---

### 致谢

作者：**Ftmjgtde**

审校：**Rycn**

---

:::changelog 更新记录
**2026-08-09** 已更新至12.1.0版本

**2026-06-16** 已更新至12.0.7版本

**2026-04-25** 已更新至12.0.5版本

**2026-02-21** 已更新至12.0.1版本

**2026-01-18** 已更新至12.0版本



:::
