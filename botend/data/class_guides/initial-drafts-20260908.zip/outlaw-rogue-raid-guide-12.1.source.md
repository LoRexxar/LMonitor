Welcome to the **Outlaw Rogue** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 3/5 · Average

Utility · 3/5 · Average

Survivability · 4/5 · Excellent

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Outlaw Rogue** Raid Best in Slot
```json
{
  "source_code": "JMpAwTFBBc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOgCtOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADLgt7AECSAAkBwDYiqBYGAAUQAsIyLLFQAXSCBAgQAAUgZsw9FEIICBAQ94Og-smQOEAYLRIBAKEAbk4UAB81HEAACDAQApxRBAEgSXIQAdFgEBIENYFQAYfBBAAQAA4UABEbCCCQIBIIHYFQANE6AGgQBCSyA5OApqQgIvsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240906]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240906]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240890]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268209]] | [[item:244001]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Outlaw Rogue**, you have access to Gravedigger, which makes your [[spell:315341]] have a  45% to apply 2 stacks of its 6% buff.

**Rank 2** makes your 5 Combo Points or more [[spell:2098]] deal extra damage as physical

While **Rank 3** makes your [[spell:2098]] have a 12% chance to grant you 1 stack. At 6 stacks, your next [[spell:315341]] costs no energy, and generates 6 Combo Points, and resets its cooldown.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-outlaw-mxr.webp>)

Gravedigger

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:112552]]
    
    - Resets the Cooldown of your [[spell:13750]], [[spell:315341]], [[spell:13877]], [[spell:271896]] and [[talent:117148@FAgARRgB7PvA]].
  
  
  
  - [[talent:112557]]
    
    - Interesting new talent that increases the crit of your [[spell:315341]] through your auto attacks. Stacking.
  - [[talent:112541]] / [[talent:135732]]
    
    - Gives your [[spell:13750]] a bit of burst which the spec is lacking, or makes it last longer.
  - [[talent:112554]]
    
    - The old Bonus from [[spell:193316]] added in the tree.
  - [[talent:112529]]
    
    - Interesting talent that can help a bit with downtime but nothing significant.
- **Class Tree**
  
  - [[talent:112636]]
    
    - Increases agility by 3%.
  
  
  
  - [[talent:112639]]
    
    - No longer a button, now it procs from your generators and increases your next finisher crit by 10%.
  - [[talent:112644]]
    
    - Extra attack speed from your [[spell:5171]].
- **Removed**
  
  - [[spell:424044]]
  
  
  
  - This, along with [[spell:423703]] is the biggest change to the tree. You no longer play around Stealth windows.
  - [[spell:341542]]
  - [[spell:341546]]
  - [[spell:423703]]
  - [[spell:108216]]
  - [[spell:354897]]
  - [[spell:196937]]
  - [[spell:209423]]
  - [[spell:382746]]
  - [[spell:381985]]
  - [[spell:344363]]
  - [[spell:381988]]
  - [[spell:341540]]
  - [[spell:455143]]
  - [[spell:170882]]
  - [[spell:341534]]
  - [[spell:455131]].

## Hero Talents

:::tabs
:::tab [[talent:123371]]
- Every 5 Combo Point or more finisher that you use has a chance to flip a coin.
  
  - Landing on [[spell:452923]] increases your damage by 10%. Additional flips landing on [[spell:452923]] increase damage by 2%. Stacking
  - Landing on [[spell:452538]] does Cosmic damage. Additional flips increase [[spell:452538]] damage by 10%. *Stacking*
- [[talent:117724]]
  
  - Every 7 coin flips, you gain a 4% agility buff, plus:
    
    - Both [[spell:452923]] and [[spell:452923]] bonuses increase by 50%.
    - Coin flips are 15% more likely to match the same flip as the previous one.

Neither of these flips offer much in terms of gameplay, and you could do without tracking any of them, but there is some minmaxing you can do with the talents in the Fatebound tree.

- [[talent:117736]].
  
  - Rolling both flips after you use your [[spell:13750]].
- [[talent:117717]]
  
  - Makes your [[spell:13877]] hit 6% harder.
- [[talent:136025]]
  
  - Passive crit.
- [[talent:136026]]
- [[talent:136024]]

:::

:::tab [[talent:123372]]
- Makes your [[spell:8676]] and [[spell:1752]] hit your target with an [[talent:117737]]. *10sec duration, 15sec Cooldown.*
  
  - [[talent:117737]] applies [[spell:441224]], making the target take 8% more damage from you and being unable to parry, which is pretty nice. Especially on bosses where you have to sit on front of the boss for extended periods of time.
  - [[talent:117737]] also applies 1 stack of [[spell:441786]] as a buff on you.
    
    - At 4 stacks of [[spell:441786]], your next [[spell:2098]] becomes [[talent:117712]].
  - [[talent:117712]] hits your target as if your [[spell:2098]] had an extra 5 Combo Points.

- [[talent:120130]]
  
  - This is a pretty nice defensive that adds some tankyness to your kit.
- [[talent:117708]]
  
  - This is a synergistic talent in the tree that outside of being a flat % buff on your finishers, works with [[talent:117725]] and [[talent:117712]].
- [[talent:117731]]
  
  - This is a pretty nice quality of life talent.
- [[talent:117725]]
  
  - [[talent:117708]] has pretty good uptime so a flat damage buff on your cleave is decent.
- [[talent:117715]]
  
  - Unfortunate that [[talent:117149]] is the ability that triggers this for Outlaw, but a significant talent for the spec nonetheless.
- [[talent:136023]]
- [[talent:136022]]
- [[talent:136021@AJABBA]]

:::

:::

## Talents

:::tabs
:::tab RECOMMENDED - [[talent:123372]] ST
:::talents [[talent:123372]] **Outlaw Rogue** Single-Target talents in Raids
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

**25%~ Haste requirement.**

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- [[spell:381989]]
  
  - This talent allows you to extend your [[spell:193316]] by 30 seconds.
- [[talent:112529]]
  
  - A bit of extra cooldown reduction if you have downtime.
- [[talent:112535]]
  
  - Synergistic ability that boosts your damage through the tier set, plus giving you some extra energy.
- [[talent:112542]]
  
  - Pivotal talent for keeping up your Stage 2 of [[spell:193316]] or above.

#### Hero Talents

- [[talent:125140]]
  
  - This is one of the better mobility talents to have when you have to cover a large amount of space.
- [[talent:125139]]
  
  - We pick this talent since Outlaw doesn't like playing [[spell:170882]].

:::

:::tab [[talent:123372]] Cleave
:::talents [[talent:123372]] **Outlaw Rogue** Cleave talents in Raids
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

#### Spec Tree

- **Added** 
  
  - [[talent:112556]]
  - [[talent:112554]]
- **Removed**
  
  - [[talent:112537]]
  - [[talent:112551]]

#### Class Tree

#### Hero Talents

- [[talent:125140]]
  
  - This is one of the better mobility talents to have when you have to cover a large amount of space.
- [[talent:125139]]
  
  - We pick this talent since Outlaw doesn't like playing [[spell:170882]].

:::

:::

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:2098]] damage increased by 15%.
- **4-Set:** [[spell:1752]] and [[spell:8676]] have a 12% chance to cause your next [[spell:2098]] to be free and deal damage as if you spent the maximum combo points.

### Single-Target

:::tabs
:::tab [[talent:123374]]
### Opener

:::rotation **Outlaw Rogue** opener on Single Target as [[talent:123374]]
```json
{
  "source_code": "J0FEKIkt1AQABgnAkMvAAEgQlQdBAAgQFYCBAAAABEAnuOAAAAAACJDCBcAYAIE2GAAAAYAdvBiNDBFAC08zEAAAC1-fTEQHJwBNAAgQFYCBAAAAAIQzPTA"
}
```
1. [[spell:13750]]
2. [[spell:193316]]  [[spell:381989]]
3. [[spell:271877]]  [[item:241308]]
4. [[spell:2098]]
5. [[spell:1752]] to 6CP
6. [[spell:315341]]
7. [[spell:1277933]]
8. [[spell:1752]]
9. [[spell:271877]]
10. [[spell:315341]]
:::

### Priority List

1. Cast [[spell:193316]] if you are on stage 1 or have no buff.
2. Use [[spell:381989]] at stage 2 or higher.
3. Cast [[spell:13750]] on cooldown with 2 or less Combo Points.
4. Cast [[spell:315341]] with 6 Combo Points or more.
5. Cast [[talent:112552]] if [[spell:315341]], [[spell:13750]] are on cooldown.
6. Cast [[spell:271877]] on low energy.
7. Cast [[spell:2098]] at 5 or more Combo Points.
8. Cast [[spell:185763]] with [[spell:195627]] buff at 3 or less Combo Points or at 6 stacks of [[spell:195627]].
   
   - Cast [[spell:185763]] with [[spell:195627]] buff at 1 or less Combo Point or at 6 stacks of [[spell:195627]] while stage [[spell:1214934]] or above is active.
   - With 3 stacks of [[spell:195627]], use [[spell:185763]] above 1 Combo Point, and below at 4 Combo Points with stage [[spell:1214934]] or above active.
9. Cast [[spell:1752]] at 5 or less Combo Points.

:::

:::tab [[talent:123372]]
### Opener

:::rotation **Outlaw Rogue** opener on Single Target as [[talent:123372]]
```json
{
  "source_code": "JcGSIIkt1AAAAcAcyVGc1xGbAI0MU4yDAgoAkMvAAAgQYbAAAAgB09GI2MEUBEAnuOAAAAAAC08zEAAACVAHEIBdFwBYgkkRg42bgIXZzVGdAIk6JDAAAAAAC1-fTA"
}
```
1. [[spell:13750]] prepull
2. [[spell:5171]] prepull
3. [[spell:193316]]
4. [[spell:1752]] to 6CP [[item:241308]]
5. [[spell:315341]]
6. [[spell:1752]] to 6CP IF no reset
7. [[spell:51690]]
8. [[spell:1277933]]
:::

### Priory list

1. Cast [[spell:193316]] at stage 1 or have no buff.
2. Use [[spell:381989]] at stage 3 or higher.
3. Cast [[spell:315341]] with 6 Combo Points or more.
4. Cast [[talent:117148@FAgARRgB7PvA]] on cooldown with [[spell:470347]].
5. Cast [[spell:13750]] on cooldown with 2 or less Combo Points.
6. Cast [[talent:112552]] if [[spell:315341]], [[spell:13750]] and [[talent:117148@FAgARRgB7PvA]] are on cooldown.
7. Cast [[spell:271877]] on low energy.
8. Cast [[spell:2098]] at 6 or more Combo Points.
9. Cast [[spell:185763]] with [[spell:195627]] buff at 3 or less Combo Points or at 6 stacks of [[spell:195627]].
10. Cast [[spell:1752]] at 5 or less Combo Points.

:::

:::

### Multi-Target

For multitarget, your rotation barely changes, but there are a few things to note

- [[spell:13877]] cleaves from around your character, so always try to position yourself closer to mobs when possible.
- Keeping [[spell:13877]] active is the highest priority with 2 or more targets.
- Remember to always [[spell:13877]] prepull if you are going to be cleaving.
- When you have [[spell:381878]] talented, you use your [[spell:13877]] as the highest priority builder at 5 or more targets

## Deep Dive

#### Roll the Bones , how it works, and how to play it optimally.

1. Generally, they made this ability much simpler. Right now, every time you press [[spell:193316]], you a chance to get 4 different stages of buffs, with each stage above 1 giving you the previous buff(s), plus the current one. For example
   
   - Stage 1: [[spell:1214933]]
   - Stage 2: [[spell:1214934]]
   - Stage 3: [[spell:1214935]]
   - Stage 4: [[spell:1214937]]
2. So if you have [[spell:1214934]], you will always have [[spell:1214933]]. If you have [[spell:1214935]], you will have the previous 2, etc.
3. You always want to stay at or above Stage 2 or Stage 3 as Trickster.

#### For Keep It Rolling , you will want to use it as soon as possible on Stage 2 or above or Stage 3 as Trickster .

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

The following tips are mainly applicable to Heroic Bosses. Mythic tips are released after our progression concludes.

**← Scroll for more Bosses →**

:::tabs
:::tab Nek'Zali
:::talents **Outlaw Rogue** Nez'Kali Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

### Boss Tips

- Keep an eye on the [[spell:1284103]] timer and make sure to never stand between the boss and your tank that the ability is targeted at.
- Try to look at corpses of the adds ahead of time to have an easier time reacting to the [[spell:1294742]] debuff that cleanses them.

:::

:::tab Entombed Sentinels
:::talents **Outlaw Rogue** Entombed Sentinels Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

### Boss Tips

- Keep an eye on the boss's energy and make sure to spread out whenever it is close to reaching 100 to have an easier time during the intermission.
- In general, be mindful of your positioning and play closer to the boss so you don't have to worry about the stacks of [[spell:1284494]] and [[spell:1284503]].
- Look at your raid frames and use your [[spell:195457]] in the intermission to clear the stacking buff.

:::

:::tab Lost Explorers
:::talents **Outlaw Rogue** Lost Explorers Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZMzMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

### Boss Tips

- Pay attention to [[spell:1296062]], try to bait them on the outside of the room.
- Do not oversoak [[spell:1291934]] as it applies a stacking **Bleed** debuff on you.
- Be careful around mushrooms from [[spell:1292105]] as they are consumed after being used once.

:::

:::tab Vashnik
:::talents **Outlaw Rogue** Vashnik Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

### Boss Tips

- Always pre-spread whenever it's time for the [[spell:1281907]] debuff and try not to aim it at the boss if possible.
- Keep in mind that killing **Burning Venoms** applies a stacking debuff on you, so you want to avoid killing them at the same time.

:::

:::tab Sszorak
:::talents **Outlaw Rogue** Sszorak Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

### Boss Tips

- In case you fail to find a partner to deal with [[spell:1285419]], keep in mind that you can also negate it with [[spell:195457]] or [[spell:31224]].
- Use a defensive cooldown if you are hit with [[spell:1287072]] as it applies a stacking **Poison** debuff on you.

:::

:::tab Twin Fangs
:::talents **Outlaw Rogue** Twin Fangs Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

- Extremely important to have a good way of tracking your debuffs in this fight due to [[spell:1290336]] guaranteed killing you at a certain amount of stacks, depending on the difficulty.
- Try not to run around too much whenever you are targeted with a [[spell:1291478]]. Preferably, move in your line if you need to dodge something.
- Don't forget that soaking [[spell:1290516]] also knocks you back, so watch out for waves from [[spell:1290956]] during it.
- Whenever [[spell:1294293]] happens, look at the **Vexhul** in the middle of the arena, and you will notice small orbs rotating around him that will indicate the direction of the beam that he casts.

:::

:::tab Coiled Altar
:::talents **Outlaw Rogue** Coiled Altar Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZmZmtZmZmZMmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

- Watch out for  [[spell:1282403]] and make sure to help with moving them around if needed.
- Pay extra attention to the ghosts that spawn after [[spell:1285643]], as dealing with them is going to be the hardest part of the phase.
  
  - Even if you avoided getting targeted by the ghost, make sure not to stay near them as they are going to get cleaved down by the [[spell:1286620]] frontal due to that being the only way of getting rid of them.
- Use a defensive cooldown whenever you are targeted with a [[spell:1286895]].

:::

:::tab Ula'tek
:::talents **Outlaw Rogue** Ula'tek Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

:::

:::tab Nymrissa Wavecaller
:::talents **Outlaw Rogue** Nymrissa Wavecaller Talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MMzMjZmtZmZMzMzsAmZZaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA"
}
```
:::

- Keep in mind that right after [[spell:1258673]] happens, [[spell:1258150]] will knock you away from the middle, so position accordingly or be ready to negate the knockback with [[spell:195457]].
- Use a defensive cooldown whenever [[spell:1281393]] are being popped.

:::

:::

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as an **Outlaw Rogue**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Outlaw Rogue** Stat Priorities in Raid
```json
{
  "source_code": "JoAJFMAJggSMBEQABA"
}
```
**敏捷 ＞ 急速 ＞ 暴击 ＞ 全能 ＞ 精通**
:::

> 25% Haste minimum. After that, crit becomes better.
> 
> 
> 
> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.

- All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear

:::tabs
:::tab Best in Slot
| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271508@DwQAAQQAXk74kgC4UA]] | The Lost Explorers / Catalyst |
| Cloak | [[item:268248@BAQAAQQAOFA]] | Nez'Kali the Soulcoiler |
| Chest | [[item:271513@DgQAAMQAJk7IoAOF]] | Vashnik the Malignant / Catalyst |
| Wrist | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | Crafting |
| Gloves | [[item:271511@BgQAAMQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:268256@BiQAAQQAS06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]] into [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268261@DAQAAMQAPk74UA]] | The Twin Fangs |
| Ring 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:268252@DiQAAQQA1j7oPrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270175@BgwAAQQACKAWBUAABo0FCA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAQQACKAWBA]] | Altar of Fangs |
| Weapon | [[item:268209@DgQAAQQADk7IoAYF]] | Altar of Fangs |
| Weapon | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | Crafting |

Outlaw Rogue BiS list in Raids

:::

:::tab Farmable Alternatives
Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | Altar of Fangs |
| Neck | [[item:273781@BiQAAMQAH16IoABF]] | Altar of Fangs |
| Shoulder | [[item:251223@DgQAAMQAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:193763@BgQAAMQACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@DgQAAQQAJk7IoABF]] | Voidscar Arena |
| Wrist | [[item:251135@BiQAAMQAU06IoABF]] | Murder Row |
| Gloves | [[item:251124@BgQAAMQACKQQBA]] | Murder Row |
| Belt | [[item:251189@BiQAAQQAK06IoABF]] | The Blinding Vale |
| Legs | [[item:159313@DgQAAQQAhu7IoABF]] | King's Rest |
| Boots | [[item:251153@DgQAAQQAPk7IoABF]] | Den of Nalorakk |
| Ring 1 | [[item:251148@DiQAAQQA1j7oPrjgCEUA]] | Den of Nalorakke |
| Ring 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:159617@BgQAAQQACKQQBA]] | King's Rest |
| Trinket 2 | [[item:250259@BgQAAMQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:193767@DgQAAQQADk7IoABF]] | Ruby Life Pools |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |

:::

:::

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAQQACKAWBUAABo0FCA]][[item:270173@BgQAAQQACKAWBA]] |
| **A-Tier** | [[item:270164@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |
| **B-Tier** | [[item:159617@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:270166@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C-Tier** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273796@AgQAAIoAOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **Junkyard** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |

### Embellishments

- [[item:240166]]
- [[item:273059]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level therefore it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS*.
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240898]]
  
  
  
  - [[item:240914]] x1
  - [[item:240906]] x1
  - [[item:240890]] x1
  - [[item:240966]] *-- Unique, use one of each gem color to enhance your [[item:240966]].*
- *Running a sim is advised for optimal stats.*

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAMQAnk7A]] - [[item:243949]] |
| --- | --- |
| Shoulder | [[item:243991]] |
| Cloak |  |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@DAAAAMQAnk7A]] |
| Waist | [[item:275707@DAAAAMQAnk7A]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:243957@BAAAAMQA]] |
| Ring 2 | [[item:243957@BAAAAMQA]] |
| Weapon | [[item:244001@BAAAAQQA]] |
| Weapon | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **Outlaw Rogue** Enchantments in Raids
```json
{
  "source_code": "JwFZEEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCoESuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244001]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAMQAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing an **Outlaw Rogue** in raiding, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Dispels Magic and Bleed debuffs. Has been useful in the past on some bosses with Bleeds.
- [[spell:154743]] -- Tauren
  
  - Similar to Dwarf in terms of DPS, but you don't get to have [[spell:65116]].
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:26297]] *-- Troll* 
  
  - Fairly weak DPS racial on a 3min cooldown.
  - Reduce the duration of movement-impairing effects by 20%. This was only useful once in the recent history of progression raiding but is still worth noting.
- [[spell:33702]] *-- Orc* 
  
  - 20% reduced stun duration on you which can be useful in some situations.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate it again to teleport to it.
  - Maximum range of 100 yards.
- [[spell:312923]] -- Mechagnome
  
  - Fairly strong passive trait that scales with level, hence why it's so strong now

:::columns
:::column


:::

:::

### Recommendation

In general, it's safe to say that if you care about min-maxing your DPS, you should go with the highest DPS racial. That being said, the story is a bit different if it's about progression raiding. Some help out massively to speed up the progression on certain bosses. Notably, Dwarf with their [[spell:65116]] helped out on **Tindral Sageswift** and **Fyrakk the Blazing** in the latest Race to World First by having easy access to dispelling yourself at crucial points of the fights mentioned.

## Macros

Discover recommended macros for **Outlaw Rogues** during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
*Sets a market when you mouseover a mob. This is great for letting you teammates know what you are planning on using your* **[[spell:1766]]** *on.*

```wow-macro
/focus [@mouseover][]
/run SetRaidTarget("mouseover",6)
```

*Mouseover* **[[spell:1766]]** *if you prefer that over focus target.*

```wow-macro
#showtooltip Kick
/cast [target=mouseover] Kick
```

**[[spell:195457]]** *on Cursor*

```wow-macro
#showtooltip Grappling Hook
/cast [@cursor] Grappling Hook
```

:::

:::details Focus Macros
**[[spell:1766]]** *your focus target*

```wow-macro
#Showtooltip Kick
/cast [target=focus] Kick
```

*Cast* **[[talent:112631]]** *on your focus*

```wow-macro
#showtooltipGouge
/cast [target=focus] Gouge
```

*Focus* **[[spell:408]]** *for extra CC*

```wow-macro
#showtooltip Kidney Shot
/cast [@focus] Kidney Shot
```

*Focus* **Cheap Shot**

```wow-macro
#showtooltip Cheap Shot
/cast [@focus] Cheap Shot
```

:::

:::details Utility Macros
*On this macro you can replace the names with the tanks in your group to make using* **[[talent:112574]] *much easier.***

```wow-macro
#showtooltip Tricks of the Trade
/cast [@Meeresdh] Tricks of the Trade
/cast [@Meeresmana] Tricks of the Trade
/cast [@Méèrès] Tricks of the Trade
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Outlaw Rogue**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![](<https://i.gyazo.com/d97025dda622df7bbb24a134b36349b9.jpg>)

**Outlaw Rogue** Interface

:::accordion
:::details Addons
- **Ellesmere UI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**ROGUE**

- Class
  
  - Thistle Tea is now a choice talent – Players may now choose between the existing version, which casts automatically at low Energy in addition to being usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds). Duration remains unchanged in PvP combat.

- Outlaw
  
  - Developers' notes: The changes to Outlaw in Curse of Ula'tek are intended to improve talent build diversity and flexibility. We've increased the power of some underperforming talents and pulled back some that could feel "locked in". Killing Spree's damage has been increased significantly because the damage it did wasn't sufficiently stronger than using other abilities during its channel would have been. The talent should now increase your overall damage about as much as other comparable talents.
  - Killing Spree has been updated – Duration no longer increases from spending combo points beyond your maximum. Each combo point spent beyond your maximum increases damage by 15%.
  - Adrenaline Rush now speeds up the execution of Killing Spree by 20%, the same rate it increases the speed of your other attacks.
  - Killing Spree prefers targets that are not immune to damage or taking less than 5% physical damage.
  - Killing Spree damage increased by 60%. Does not affect PvP combat.
  - Killing Spree shots have a higher chance to target your selected target if they're valid.
    
    - *Developers’ notes: Much of Killing Spree’s value is the combo points it generates, so when players can spend more combo points on Killing Spree than their maximum, such as through Supercharger, the value of those extra points is diminished. Killing Spree’s duration now maxes out at the time required to generate maximum combo points, and any extra combo points spent increase the damage of the ability by a proportional amount.*
  - Improved Between the Eyes has been updated – Causes Between the Eyes critical strikes to deal 2.5 times normal damage (was 3 times).
  - Fast Action has been updated – Now reduces the cooldown of Between the Eyes by 8 seconds (was 5 seconds) and increases the damage bonus from each Between the Eyes stack by 1%.
  - All damage increased by 9%. Does not affect PvP combat.
  - Heavy Hitter increases the damage of attacks that generate combo points by 15%/30% (was 10%/20%).
  - Zero In value per stack reduced to 2% (was 3%).
    
    - *Developers' notes: We don't want players to feel obligated to use off-hand daggers to maximize the value of this talent. Zero In now has a 30% chance to not proc if triggered by a weapon with 1.8 Speed, giving it the same proc rate when attacking with daggers vs. other one-handed weapons.*
  - Audacity now also increases Ambush damage by 80%.
  - Hidden Opportunity's chance for Ambush to grant Opportunity increased to 100% of the chance for Sinister Strike to grant Opportunity (was 80%).
  - Hidden Opportunity also reduces Ambush's Energy cost by 5.
    
    - *Developers’ notes: Audacity and Hidden Opportunity are not as strong as other talent options, so we’re adding some effects to them to make them more competitive.*
  - Summarily Dispatched increases Dispatch damage by 15%/30% (was 10%/20%).
  - New connectors have been added in the talent tree between Ruthlessness and Find an Opening, and between the Flickering Steel choice node and Grand Melee.

:::

:::

## FAQ

:::accordion
:::details Q: Why is my damage so low?
**A:** One of the most common mistakes as an **Outlaw Rogue** is simply not pressing globals as soon as possible. Outlaw is a very high APM spec, and due to abilities like [[spell:79096]] and [[spell:1214937]], simply having uptime and using abilities is important. Building muscle memory with the spec, either by playing a lot of Mythic+, or hitting the dummy fixes that.

:::

:::

---

### Credits

Written By: **Perfecto**

Reviewed By: **Verb**

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-17** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-10** Updated for patch 12.0.1.

**2025-12-03** Updated for patch 12.0

**2025-10-07** Updated for patch 11.2.5.

**2025-07-29** Updated for patch 11.2.

**2025-06-19** Updated for patch 11.1.7.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-14** Updated for patch 11.1.

**2024-12-16** Updated for patch 11.0.7.

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-24** Guide Written for the pre-patch 11.0.1.



:::
