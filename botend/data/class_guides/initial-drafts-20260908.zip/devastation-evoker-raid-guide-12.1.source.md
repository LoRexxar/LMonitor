Welcome to the **Devastation Evoker** Raid guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Raid
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Devastation Evoker** Raid Best in Slot
```json
{
  "source_code": "JAoAwD1uFc__BEQjkQggIEAAnk7AX16ACKgTBEQ6XQAAREAAE06AE06AMWjgCgVABsIJEIACBAwF5OggCgVABQgJEIAEBAQC5OggCwYNYFQAefBBAiQB0UwQAwYCvQQBqmwLIk8FEEgPAkSAvgjTBEAa7OAhIEAAYA8AnoaAkxyt1sUAB4IJEAACBAQB_AS2XQggAEAA1jbAeQhTBEgnqJQAkmAEFICBU9RGuQAhtkBDE09FNwAFYFQA0LCBBYHA_EgdMhVABkAwDQACBAAelNApqQwt1sUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271501]] | [[item:240983]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271499]] | [[item:243991]] |
| 胸部 | [[item:271876]] | [[item:243977]] |
| 腰部 | [[item:268254]] | [[item:240900]] |
| 腿部 | [[item:271500]] | [[item:240133]] |
| 脚部 | [[item:268233]] | [[item:244009]] |
| 腕部 | [[item:244584]] | [[item:240900]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271502]] |  |
| 戒指一 | [[item:268249]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:273796]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244031]] |
| 副手 | [[item:245769]] | [[item:222584]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Devastation** you have access to Rising Fury, which grants you a stacking Haste buff and more damage during and after [[talent:115643@FAQA4AcB]].

**Rank 1:** While [[talent:115643@FAQA4AcB]] is active you gain [[spell:1271687]] every 6s, which grants 4% Haste stacking up to 5 times.

**Rank 2 - (1/2):** At 5 stacks of [[spell:1271687]] all damage dealt is increased by 8%.

**Rank 2 - (2/2):** At 5 stacks of [[spell:1271687]] all damage dealt is increased by 15%.

**Rank 3:** When [[talent:115643@FAQA4AcB]] ends, [[spell:1271687]] persists for 4s per stack and [[talent:115643@FAQA4AcB]] becomes [[spell:1292321]]. [[spell:1292321]] may be cast 4 times before [[talent:115643@FAQA4AcB]] finishes its cooldown.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-devastation-mxr.webp>)

Rising Fury

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:115579]]
    
    - A new AoE focused talent that upgrades your next [[spell:362969]] to a more powerful version after casting [[talent:115581]].
    - Greatly enhanced by the Season 1 Tier set, making it a core rotational spell in all situations.
  - [[talent:115623]]
    
    - Allows you to cast [[spell:357210]] again within 18 sec of the initial cast.
    - Has strong synergy with [[talent:115639]] and [[talent:117550@AJQD]] as [[talent:123333]].
- **Class Tree**
  
  - [[talent:115617]]
    
    - Previously an **Augmentation** only talent that got moved to the Evoker class tree, makes you safer while using [[spell:357210]]!
  - [[talent:115669]]
    
    - Removed as a separate spell and is now tied with [[talent:115613]] as a less powerful effect.
- **Removed**
  
  - [[spell:370962]]
    
    - [[spell:357211]] now deals more damage but costs 3 Essence to cast unless you have [[talent:115638]] active.
  - [[spell:368847]]
    
    - Doesn't exist as a separate spell anymore and only procs from [[talent:115584]].
  - [[spell:370452]]
    
    - Doesn't exist as a separate spell anymore as it was changed to a passive [[talent:115627]].

## Hero Talents

- [[talent:123333]] is stronger than [[talent:123336]] in every scenario apart from long duration AoE situations.



### [[talent:123333]]

[[talent:123333]] hero talents mostly revolve around the two key spells: [[spell:436335]] and [[spell:357210]].

#### Mass Disintegrate

- [[spell:357208]] and [[spell:359073]] change your next [[spell:356995]] cast into a [[spell:436335]] which either hits up to 3-4 targets or deals increased damage to less targets.

- [[spell:434300@FJQBJHXBknYBNLZB7zwB8zwBNA]]
  
  - Is another [[talent:123333]] talent that is tied to [[spell:436335]].
  - Places a debuff on your target which triggers bombardments as you and your allies attack it.
  - Further improved by [[spell:441206@FJQBJHXBknYBNLZB7zwB8zwBNA]] and [[talent:117525]].

#### Deep Breath

- The other ability that is heavily enhanced by the [[talent:123333]] talent tree.

- [[talent:117518]]
  
  - [[spell:357210]] now causes enemies to take 20% increased damage from [[spell:434300@FJQBJHXBknYBNLZB7zwB8zwBNA]], [[spell:356995]] and [[spell:357211]].
- [[talent:120123]]
  
  - [[spell:357210]] gives you back one charge of [[spell:358267]]. This is a massive mobility boost as you use [[spell:357210]] very often with the new [[talent:115623]] talent.
- [[talent:117538]]
  
  - [[spell:357210]] can now be steered and canceled mid-flight and it inflicts an additional 12 second damage over time effect.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:136053]]
  
  - While flying during [[spell:357210]] 2 Dracthyr Commandos fly along you and damage nearby enemies with Pyres up to 8 times.
  - You should have at least some flight-time so the Commandos have a chance to shoot out their spells.
- [[talent:136052@AJQD]]
  
  - [[talent:117536]] hits 1 additional target.
- [[talent:136051]]
  
  - Essence abilities deal 15% additional damage.




### [[talent:123336]]

In Midnight, [[spell:443328]], the previous signature ability of [[talent:123336]] has been removed and the gameplay is instead focused around [[spell:357208]].

#### Fire Breath

The spell interacts or is enhanced by the majority of talents in the Hero Talent tree.

- [[talent:117547@AJQD]]
  
  - [[spell:357208]] gains an additional charge.
- [[talent:123416]]
  
  - [[spell:357208]] cooldown is reduced by 5 seconds.
- [[talent:117543@AJQD]]
  
  - [[spell:357208]] reaches its maximum empower level 20% faster.
- [[talent:117542@AJQD]]
  
  - [[spell:357208]] damage over time lasts 4 seconds longer.
- [[talent:128713]]
  
  - [[spell:357208]] damage over time is increased by 30%.
- [[talent:117520@AJQD]]
  
  - [[spell:357208]] deals its damage 15% more often.
- [[talent:136055@AJQD]]
  
  - [[spell:357208]] has a 50% chance to generate [[spell:359565]]
- [[talent:117519@AJQD]]
  
  - [[spell:356995]] and [[spell:357211]] casts consume [[spell:357208]] duration from enemies which triggers damage on them.

##### Other noteworthy talents

- [[talent:117546]]
  
  - Increases your Critical strike chance on targets above 50% health by 10%, this is quite the large damage increase so try to target high health targets whenever appropriate.

You have a choice between the following defensive talents:

- [[talent:117528]]
  
  - With the removal of [[spell:374348]] as a separate spell this now applies [[spell:363916]] at 50% effectiveness, this means it is a 15% damage reduction cooldown with a slight healing effect. You should pick this talent out of the two most of the time.
- [[talent:123405]]
  
  - A small chance of getting healed by 30% of damage taken, on average this ends up healing you for around 5% of your total damage taken, this can sometimes be a good choice if you are the squishiest target in your group.

With Patch 12.0, Blizzard removed the original The War Within Season 3 Sets and added 3 additional Hero Talent points.

- [[talent:136055@AJQD]]
  
  - 50% chance to proc [[spell:359565]] after casting [[spell:357208]]
- [[talent:136056@AJQD]]
  
  - Consuming [[spell:359565]] deals damage to your target.
- [[talent:136054]]
  
  - [[talent:136056@AJQD]] does damage to up to 2 additional targets.





## Talents



### [[talent:123336]] Single-Target

:::talents [[talent:123336]] **Devastation Evoker** Single-Target talents in Raids
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZGmZYGzMMGYMTjZmJjx2YmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZGmZYGzMMGYMTjZmJjx2YmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM"
}
```
:::

#### When to use this Spec

This is the default [[talent:123336]] Single-Target build for raiding.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- **[[talent:115579]]**
  
  - A new rotational ability, a buffed up Azure Strike cast after every [[talent:115581@FAQANvbB]].
  - **You should pick [[talent:115582]]** **instead of this until you acquire the Season 1 tier set.**
- [[talent:115647]] 
  
  - Your AoE essence spender.
- [[talent:115581]] 
  
  - Your spec-specific Empower spell, enhanced by [[talent:115632]].
  - This has additional cleave synergy with [[talent:115636]].
- [[talent:115643]] 
  
  - Your main DPS cooldown that is enhanced by [[talent:115642]] and [[talent:115640]].
- [[talent:115624]]
  
  - [[spell:357208]] damage ticks have a chance to make your next [[spell:361469]] instant cast. Especially useful for optimizing damage while moving.
- [[talent:115683]] 
  
  - Makes [[spell:356995]] and [[spell:357211]] reduce the cooldown of your Empower spells.
- [[talent:115622]]
  
  - Increases the damage of your Red spells by 25% on targets affected by [[spell:357208]].

##### Class Tree

- [[talent:115654]]
  
  - Often picked for a small DPS increase, stacks up from passive healing, and active off-healing. You can use your healing spells during downtime to gain some damage.
- [[talent:115595]]
  
  - In Midnight the defensive absorb shield was removed from this talent and instead it now gives yourself and your [[talent:115596]] target an additional short buff that increases movement speed by 100% allows spells to be cast while moving
- [[talent:115657]]
  
  - Allows you to shoot an additional [[spell:361469]] per Empower rank after every [[spell:357208]] cast for free cleave damage. These additional [[spell:361469]] can also proc [[spell:396187]] from automatically healing your allies if there are not enough enemies to hit while also potentially getting [[talent:115654]] value.
- [[talent:125610]]
  
  - A great utility tool to help out a healer during periods of heavy movement, can also be very important for increasing the range of your own spells in certain situations where it is needed. This is a choice node with [[talent:115666]] which might also be needed by your raid.




### [[talent:123336]] Multi-Target

:::talents [[talent:123336]] **Devastation Evoker** Multi-Target talents in Raids
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZwMDzYmhxAjZaMzMZM2mZmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZwMDzYmhxAjZaMzMZM2mZmZGmZmZGwMmxYmZbmZwMwMmBWALBzwEyGYZYAMzMM"
}
```
:::

#### When to use this Spec

Use this build for fights with cleave or AoE when playing [[talent:123336]].

#### Talent Adjustments

Listing all the changes within Class and Spec tree compared to the [[talent:123336]] Single-Target build.

##### Spec Tree

**[[talent:115579]]**

- **You should pick [[talent:115627]]** **instead of this until you acquire the Season 1 tier set.**

- **Added** 
  
  - [[talent:115632]]
    
    - Makes [[spell:359073]] hit 2 targets per rank.
    - Has additional cleave synergy with [[talent:115636]].
  - [[talent:115591]] 2 points
    
    - More AoE damage with [[talent:115647]]
    - If it's only a 2 target fight you can spec these points back into [[talent:115641]] and [[talent:115582]].
- **Removed** 
  
  - [[talent:115641]] 1 point
    
    - Losing 2% Critical strike chance
  - [[talent:115627]]
    
    - Minor single-target damage loss.
  - [[talent:115582]]
    
    - Minor damage loss because of more Essence capping.




### [[talent:123333]] Single-Target

:::talents [[talent:123333]] **Devastation Evoker** Single-Target talents in Raids
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### When to use this Spec

This is the default [[talent:123333]] Single-Target build for raiding.

#### Talent Adjustments

Listing all the changes within Class and Spec tree compared to the [[talent:123336]] Single-Target build.

##### Spec Tree

**[[talent:115579]]**

- **You should pick [[talent:115627]]** **instead of this until you acquire the Season 1 tier set.**

- **Added** 
  
  - [[talent:115639]]
  - [[talent:115638]]
  - [[talent:115623]]
    
    - Picked talents with [[talent:123333]] synergy.
- **Removed** 
  
  - [[talent:115586]]
  - [[talent:115622]]
  - [[talent:115633]]
    
    - Removed talents with [[talent:123336]] synergy.

##### Hero Talents

Switched [[talent:123336]] to [[talent:123333]].




### [[talent:123333]] Multi-Target

:::talents [[talent:123333]] **Devastation Evoker** Multi-Target talents in Raids
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### When to use this Spec

Use this build for fights with cleave or AoE when playing [[talent:123333]].

#### Talent Adjustments

Listing all the changes within Class and Spec tree compared to the [[talent:123333]] Single-Target build.

##### Spec Tree

**[[talent:115579]]**

- **You should pick [[talent:115627]]** **instead of this until you acquire the Season 1 tier set.**

- **Added** 
  
  - [[talent:115632]]
    
    - Makes [[spell:359073]] hit 2 targets per rank.
    - Has additional cleave synergy with [[talent:115636]].
- **Removed** 
  
  - [[talent:115627]]
    
    - A small single-target damage loss in favor of cleave damage.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:1265802]] damage is increased by 50% and it always casts as if you had reached maximum empower level.
- **4-Set:** [[talent:115683]] reduces the remaining cooldown of your [[spell:357208]] and [[spell:359073]] by an additional 0.1 sec each time the effect occurs. [[spell:359073]] deals 10% increased damage.

### Single-Target



#### [[talent:123336]]

##### Opener Rotation

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123336]] **Devastation Evoker** single-target opener in Raid
```json
{
  "source_code": "JMZAwlgA9PYBHAlclBXdsxGAC8SuFAQACl3pFAAACEqeBYAb4kZBAIQAI66AAAAAAEAhtQAAIEAACKgTBIwgyFAIBYAWAWgQLD1EAAQD3lGdoBCVpVmcgMXZ0BgUVAQBx4SXAAEAC0_gFAAACMocFAAACgTmFA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]  [[spell:370553]]
3. [[spell:359073]]
4. [[spell:366904]]  [[item:241288]] · [[item:273796]]
5. [[spell:356995]]
6. [[spell:356995]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]]
   4. [[spell:359073]]
   5. [[spell:366904]]
7. [[spell:361469]]
8. [[spell:356995]]
9. [[spell:366904]]
:::

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:357208]] if it's not up on the target *- Rank 1*
2. Cast [[spell:359073]] *- Rank 1*.
3. Cast [[spell:356995]] until you are not capped on Essence or [[spell:357208]] runs out on your target
4. Cast [[talent:115579]] - with Season 1 Tier set
5. Cast [[spell:1292321]]
6. Cast [[spell:361469]] - *if you have [[spell:375801]].*
7. Cast [[spell:356995]] until you have no more Essence to cast it or [[spell:357208]] runs out on your target
8. Cast [[spell:361469]].




#### [[talent:123333]]

##### Opener Rotation

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123333]] **Devastation Evoker** single-target opener in Raid
```json
{
  "source_code": "JcaAw7jCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogxboaAAAAAANgAWASgQLD1EAAQD3lGdoBCVpVmcgMXZ0BgUVAAKCMocFAQACdeUTAQEvxAAC0_gBMIODKXBAEgQnH1EAAgQfXWB"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]]
7. [[spell:436335]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]]  [[spell:1266151]]
   4. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:356995]]  [[spell:1266151]]
10. [[spell:353759]]
:::

- Check below for the Dragonrage window priority after the initial opener.

##### Dragonrage Priority List

This is a general priority for your Dragonrage window.

1. Cast [[spell:357210]] *- with no [[talent:117518@AJQD]] up on the target or [[talent:115623]]* *is about to run out.*
2. Cast [[spell:359073]] *- Rank 1*.
3. Cast [[spell:357208]] *- Rank 1*.
4. Cast [[spell:356995]] until you are not capped on Essence.
5. Cast [[talent:115579]] - with Season 1 Tier set
6. Cast [[spell:361469]] to proc [[spell:396187]] *- if you have either [[spell:375801]] or [[spell:369939]].*
7. Cast [[spell:356995]] until you have no more Essence to cast it.
8. Cast [[spell:362969]] to proc [[spell:396187]].

##### Priority List

This is a general priority you aim to maintain throughout the fight.

1. Cast [[spell:357210]] *- with no [[talent:117518@AJQD]] up on the target or [[talent:115623]] is about to run out.*
2. Cast [[spell:359073]] *- Rank 1*.
3. Cast [[spell:357208]] *- Rank 1*.
4. Cast [[spell:356995]] until you are not capped on Essence.
5. Cast [[talent:115579]] *- **with Season 1*** Tier set
6. Cast [[spell:1292321]]
7. Cast [[spell:361469]] *- if you have 2 stacks of [[spell:375801]] or a single one that is about to run out.*
8. Cast [[spell:356995]] until you have no more Essence to cast it.
9. Cast [[spell:361469]] until you have enough Essence to cast [[spell:356995]].





### Multi-Target



#### [[talent:123336]]

##### 2 Target Opener

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123336]] **Devastation Evoker** 2 target opener in Raid
```json
{
  "source_code": "JUcAYzgA9PYBHAlclBXdsxGACgTmFAgABgorDAAAAAQAE2CBAgQAAIoAOFgAvkbBAEgQ5daBAAgAhqXAGEALMAgADKXAMEgBYBYBCtMUTAAANcXa0hGIUlWZyByclRHASVBABEDIIQVYydWZ0BiM-4AAJkFB9PYEZ5DIAA0gyVACUFmcnVGdgIDACgTmFA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:366904]]  [[item:241288]] · [[item:273796]]
3. [[spell:375087]]  [[spell:370553]]
4. [[spell:359073]]
5. [[spell:366904]]
6. [[spell:356995]]
7. [[spell:356995]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]] Target 2
   4. [[spell:356995]] Target 2
   5. [[spell:366904]]
8. [[spell:361469]]
9. [[spell:356995]]
10. [[spell:356995]] Target 2
11. [[spell:356995]] Target 2
12. [[spell:366904]]
:::

- On 2 targets your opener and rotation is very similar to single target apart from the fact that you want to ideally always deplete Fire Breath from both targets with [[talent:117519@AJQD]] before casting another one.

##### 3+ Target Opener

:::rotation [[talent:123336]] **Devastation Evoker** 3+ target opener in Raid
```json
{
  "source_code": "JEaAYvgA9PYBHAlclBXdsxGACgTmFAgABgorDAAAAAQAE2CBAgQAAIoAOFgAvkbBAEgQ5daBAAgAhqXAGEALQAgQbNXBBwSDIgFgEI0yQNBAA0wdpRHagQValJHIzVGdAYVFA0wOAIQBJBhA9PYBAExRoAgA4kZBAAgQbNXB"
}
```
1. [[spell:361469]] Prepull
2. [[spell:366904]]  [[item:241288]] · [[item:273796]]
3. [[spell:375087]]  [[spell:370553]]
4. [[spell:359073]]
5. [[spell:366904]]
6. [[spell:357211]]
7. [[spell:357211]]  
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:357211]]
   4. [[spell:366904]]
8. [[spell:361469]]
9. [[spell:357211]]
10. [[spell:366904]]
11. [[spell:357211]]
:::

- On 3+ targets your opener and priority is changed to include [[spell:357211]] as the Essence spender, otherwise same rules apply.
- If damage on the secondary targets is irrelevant as often is the case you should keep using the single-target priority list and focus on damaging the main target.

##### 3+ Target Priority List

1. Cast [[spell:357208]] if it's not up on the target *- Rank 1*
2. Cast [[spell:359073]]
3. Cast [[spell:357211]] until you are not capped on Essence or [[spell:357208]] runs out on your target
4. Cast [[talent:115579]] - with Season 1 Tier set
5. Cast [[spell:1292321]]
6. Cast [[spell:361469]] *- if you have either [[spell:375801]] or [[spell:369939]].*
7. Cast [[spell:357211]] until you have no more Essence to cast it.
8. Cast [[spell:362969]].




#### [[talent:123333]]

##### 2 Target Opener

- The goal of the opener is to maximize your [[spell:375087]] window and extend it with [[spell:375797]] while trying to avoid overcapping on Essence or [[spell:396187]].

:::rotation [[talent:123333]] **Devastation Evoker** 2 target opener in Raid
```json
{
  "source_code": "JcbAw7jCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogzboaAAAgAVhJ3ZlRHIxAgNQAAXyAIBCtMUTAAANcXa0hGIUlWZyByclRHASVBAoIwgyVAABI05RNBAR8HDAIQ_DGwk4MocFAQACdeUTAAAC9dZFA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]] Target 1
7. [[spell:436335]] Target 2 
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:356995]]  [[spell:1266151]]
   4. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:356995]]  [[spell:1266151]]
10. [[spell:353759]]
:::

- On 2 targets as a **[[talent:123333]],** the only difference from single-target is that in the opener you should choose different targets with each of the two consecutive [[talent:117536]] following your first two empower spells to apply [[talent:117533]] to both. This way you get more value out of [[talent:117525]] as it extends both bombardments.

##### 4+ Targets Opener

:::rotation [[talent:123333]] **Devastation Evoker** 4+ target opener in Raid
```json
{
  "source_code": "JccAw7zCC0_gFcAUyVGc1xGbAIwL5WAAAIQo6VAAAI03lVAAAAwACl3pFAAABgorDAAAAAQAE2CBAgQAAIoAOFgA4kZAogzboaAAAgAVhJ3ZlRHIxAgNQAAXyAYBCtMUTAAANcXa0hGIUlWZyByclRHAWVBAQwClGAAANEIFBI05RNBARcIDAIQ_DGQbaJCA"
}
```
1. [[spell:361469]] Prepull
2. [[spell:375087]]
3. [[spell:359073]]
4. [[spell:353759]]  [[spell:370553]] · [[item:241288]] · [[item:273796]]
5. [[spell:366904]]
6. [[spell:436335]] Target 1
7. [[spell:436335]] Target 2 
   
   1. [[spell:1265867]] with Tier set
   2. [[spell:1265867]] with Tier set
   3. [[spell:431148]]
   4. [[spell:359073]]  [[spell:1266151]]
   5. [[spell:353759]]
8. [[spell:361469]]
9. [[spell:431148]]
10. [[spell:359073]]  [[spell:1266151]]
11. [[spell:353759]]
:::

- **Always use** [[spell:436335]] after Empower spells even if you are fighting higher target counts.

##### 4+ Target Priority List

1. Cast [[spell:357210]] *- with no [[talent:117518@AJQD]] up on the targets or [[talent:115623]] is about to run out.*
2. Cast [[spell:359073]] *- Empower according to target count.*
3. Cast [[spell:357208]] *- Empower according to target count.*
4. Cast [[spell:357211]] as Essence spender
5. Cast [[talent:115579]] - with Season 1 Tier set
6. Cast [[spell:1292321]]
7. Cast [[spell:361469]] *- if you have either [[spell:375801]] or [[spell:369939]].*
8. Cast [[spell:362969]] until you have enough Essence for your spender.





## Deep Dive

### Empower spells

#### Fire Breath

[[talent:123336]]

- Always cast Rank 1 in almost any situation because of [[talent:117519@AJQD]] and [[talent:115622]]

[[talent:123333]]

- Use mostly with Rank 1 Empower on single target as you want to have the DoT effect up all the time for [[spell:375801]] procs and [[spell:386283]] synergy.
- Using [[spell:357208]] with a higher Empower rank shortens the damage over time effect in favor of more direct damage, you want to utilize this when your target isn't going to live much longer.
- Ranking up [[spell:357208]] more in AoE situations is also generally recommended as [[spell:375777]] shortens the cooldown of the spell much more with [[spell:357211]] spam and you would be overwriting your pre-existing DoT effect and wasting damage otherwise. In addition, you get better value from [[talent:115657]].

#### Eternity Surge

- Deciding what rank to use [[spell:359073]] on is very straightforward as it only increases the targets hit by 1 for each rank (or 2 with [[spell:375757]]).
- Rank 1-4: **1/2/3/4** or **2/4/6/8** with[[spell:375757]] targets hit.
- Especially on [[talent:123336]] it's often not worth it to cast this at a higher rank even against more targets because you could be using that time to cast more [[spell:357211]] instead.

In general, you should hold both Empower spells when [[spell:375087]] is about to come off cooldown for proper [[talent:115642]] extensions.

### Disintegrate Mechanics

- Baseline [[spell:356995]] has a cast duration of **two** global cooldowns and **four damage ticks** occur within this time frame.
- Utilizing the **Pandemic** mechanic you can start a new cast of [[spell:356995]] after the **3rd damage tick** has occurred which transfers the **remaining duration** and **4th damage tick** of the **previous cast** to the **next** one.
- This is how you spell queue [[spell:356995]], minimizing downtime and enabling you to use up Essence slightly faster to prevent **overcapping**.
- Because of this you would ideally have **[[spell:356995]] ticks** shown on your cast bar so you can **re-cast** at proper timing.

### Using Rescue

- [[spell:370665]] is a great part of your toolkit as an **Evoker**, using it optimally requires fight awareness, especially in raids it can often save your less mobile allies from sticky situations.
- **12.0 Patch** has this change: 
  
  - [[spell:370888]] has been redesigned – [[spell:370665]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  - Means that [[spell:370665]] no longer has a defensive cooldown tied to it but is even more potent as a movement ability!

### Using Hover

- Managing and timing your [[spell:358267]] casts correctly in combat to get more casts in while dealing with mechanics is where you see the biggest difference in your DPS as the actual rotational optimization is not that complex for **Devastation Evoker**.
- Starting a cast of a spell such as [[spell:356995]] at the very end of a [[spell:358267]] buff still lets you finish that specific cast while moving even if the buff runs out during the cast, keep this in mind to get more benefit from each use of [[spell:358267]]!
- Track your uptime and charges of [[spell:358267]] well on your UI and get really comfortable with utilizing this ability as it is the most significant unique strength of an **Evoker**.
- With the **patch 12.0** [[spell:358267]] can now be used during normal casts (mostly [[spell:361469]] and [[spell:356995]] on **Devastation**) without interrupting them.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## The Venomous Abyss

**← Scroll for more Bosses →**



### Nek'Zali

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Nek'Zali
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Do not stand between the boss and your tank during [[spell:1284103]]!
- Pre-position on top of **Restless Amani** corpses slightly before [[spell:1294742]] to easier coordinate the clearing of them.




### Entombed Sentinels

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Entombed Sentinels
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Be active with stomping on [[spell:1284434]] whenever they spawn, use a defensive cooldown if soaking a lot in a row.
- Spread out and prepare to solve [[spell:1284590]] when the bosses reach 100 energy, this is the key mechanic of the fight and main wipe cause so really focus on this!




### Lost Explorers

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Lost Explorers
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Keep track of the [[spell:1296062]] casts and check which direction they are being shot at.
- You can dispel the **Bleed** debuff from soaking [[spell:1291934]] with [[talent:115602]] so try to soak a bunch and dispel yourself afterwards or look out for other players with high stacks.
- Be very careful not to trigger the **Bouncy Mushrooms** from [[spell:1292105]] too early before the [[spell:1296235]] as this makes them disappear after a short while.




### Vashnik

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Vashnik
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Pre-spread for [[spell:1281907]] for less confusion and try not to shoot towards the melee camp.
- Use a defensive cooldown when the **Burning Venoms** explode.
- Be active with soaking any player afflicted with [[spell:1295224]].




### Sszorak

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Sszorak
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZGMDzYmhxAjZaMzMNjx2wMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Remember that you can easily cancel the knockbacks from [[spell:1285419]] and [[spell:1287008]] with [[spell:358733]].
- [[talent:115666]] is great during [[spell:1285732]] for your raid to optimize dps.
- Really focus on [[spell:1305959]] whenever it happens, it's crucial to know exactly where to go if you get targeted.
- You can dispel anyone hit by [[spell:1287072]] with either [[spell:365585]] or [[talent:115602]].




### Twin Fangs

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Twin Fangs
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Keep good track of your [[spell:1290336]] stacks throughout the fight.
- Considering slightly holding/pooling [[spell:353759]] and [[spell:436336]] for when the adds spawn from [[spell:1291397]].
- Don't move around too much if targeted by [[spell:1291478]] and try to move along the line if absolutely needed.
- Look out for the waves from  [[spell:1290956]] whenever they are up, they can catch you off-guard especially during the knockback from [[spell:1290516]].
- When **Vexhul** submerges and appears in the middle of the arena to cast [[spell:1294293]] look at the small green orbs around him that indicate the rotation direction to determine if you should dodge left or right (you should dodge "against" the rotation.)




### Coiled Altar

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Coiled Altar
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Help out with moving and stacking up [[spell:1282403]] as needed.
- After each [[spell:1285643]] check if you get fixated by any of the spawned ghosts and if you do, really focus on maneuvering it to the intended tank cleave spot for getting rid of it.
- Interrupt the [[spell:1286399]] from **Spiteful Soulcoilers**.
- Use [[talent:115613]] if targeted by [[spell:1286895]] and remember to pick-up your souls afterwards!




### Ula'tek

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Ula'tek
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Defeat the angry ancient snake.




### Nymrissa Wavecaller

:::talents [[talent:123331]] **Devastation Evoker** Raid build for Nymrissa Wavecaller
```json
{
  "source_code": "CubB282ha6SMH_EjNYLtBJiO_AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD",
  "code": "CubB282ha6SMH/EjNYLtBJiO/AAAAAAAAAAAAjZgZYGzMMGYMTjZmpZM2mxMzMzMzMzAmxMGzMbzMDMwYG2glxs0YZmhJzkFw2wAzMzMDD"
}
```
:::

#### Boss Tips

- Rotate [[spell:363916]] and [[spell:374227]] when available for when [[spell:1281393]] are cleared.





## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Raid boss fights as a **Devastation Evoker**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Devastation Evoker** Stat Priorities in Raid
```json
{
  "source_code": "JoAJFUAIxQCKBMgABA"
}
```
**智力 ＞ 暴击 ≥ 精通 ＝ 急速 ＞ 全能**
:::

:::callout Higher Item Level Items are Better in Most Scenarios
For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)!

A static "**Stat Priority**" is just a starting point and can easily shift depending on your current gear.

:::

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271501@DiQAAsbBnk7cVrjgC4UA]] | Tier / Catalyst |
| Neck | [[item:268265@BERAAsbBE06QQrDj1IoAYFA]] | Ula'tek |
| Shoulder | Catalyst [[item:268231@AgQAAIoAYFA]]  <br>into [[item:271499@DgQAAsbBXk7IoAYF]] | Coiled Altar / Catalyst |
| Cloak | [[item:268253@BgQAAsbBCKAWBA]] | Coiled Altar |
| Chest | [[item:271876@DARAAsbBJk7IoAMWDWB]] | Ula'tek |
| Wrist | [[item:244584@FiQAAsbBYA8ciqDBtO3WzSB]] | Crafting |
| Gloves | [[item:271502@BgQAAsbBCKgTBA]] | Tier / Catalyst |
| Belt | [[item:268254@BiQAAsbBE06IoAOF]] | Vashnik |
| Legs | Catalyst [[item:268237@AgQAAIoAYFA]]  <br>into [[item:271500@DgQAAsbBFo6IoAYF]] | Coiled Altar / Catalyst |
| Boots | [[item:268233@DgQAAsbBpk7IoAOF]] | Sszorak |
| Ring 1 | [[item:268249@DCQAAsbB1j7QQrjTBA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAsbB1j7QQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAsbBCKgTBA]] | Lost Explorers |
| Trinket 2 | [[item:273796@BgQAAsbBCKgTBA]] | Altar of Fangs |
| Weapon | [[item:271092@DgQAAsbB_k7IoAYF]] | Ula'tek |
| Off-hand | [[item:245769@FgQAAsbB4V2QqK0t1sUA]] | Crafting |




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239035@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Neck | [[item:251234@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Shoulder | [[item:239049@BgQAAsbBCKQQBA]] | King's Rest |
| Cloak | [[item:251132@BgQAAsbBCKQQBA]] | Murder Row |
| Chest | [[item:251233@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Wrist | [[item:159380@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:193752@BgQAAsbBCKQQBA]] | Ruby Life Pools |
| Belt | [[item:251155@BgQAAsbBCKQQBA]] | Den of Nalorakk |
| Legs | [[item:159375@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Boots | [[item:159388@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Ring 1 | [[item:251136@BgQAAsbBCKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAsbBCKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250224@BgQAAsbBCKQQBA]] | Voidscar Arena |
| Trinket 2 | [[item:273796@BgQAAsbBCKQQBA]] | Altar of Fangs |
| Weapon | [[item:193761@BgQAAsbBCKQQBA]] | Ruby Life Pools |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@AgQAAIoAOFA]] |
| **A-Tier** | [[item:273796@AgQAAIoAOFA]]  <br>[[item:270167@AgQAAIoAOFA]]  <br>[[item:250224@AgQAAIoAOFA]] |
| **B-Tier** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273649@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |
| **C-Tier** | [[item:270161@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]]  <br>[[item:270170@AgQAAIoAOFA]]  <br>[[item:270169@AgQAAIoAYFA]]  <br>[[item:270168@AgQAAIoAYFA]]  <br>[[item:193757@AgQAAIoAOFA]]  <br>[[item:273794@AgQAAIoAOFA]] |
| **Junkyard** | [[item:158368@AgQAAIoAOFA]] |

### Embellishments

- With your first 4 [[item:274476]] it is recommended to craft [[item:245770@CARAAgBwDAAcbNLF]] as it is very efficient usage of your mythic crests!

- 1x [[item:240167]]
  
  - The optimal slot to craft on is **Wrist**, **Back, Boots** or **Waist** depending on your available gear.

- 1x [[item:273060]]
  
  - Great embellishment if you are using a crafted weapon or off-hand.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore it is not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS.*
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:255845]]
  - [[item:255846]]
- **Combat Potion**
  
  - [[item:241288]]
- **Health Potion**
  
  - [[item:271884]] *-- a big burst of healing - upgraded version from 12.1*
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *- You can only have one Eversong Diamond socketed in your gear.*
  
  
  
  - [[item:240900]]

### Enchantments

:::columns
:::column
| Head | [[item:275707]]  <br>[[item:244007]] |
| --- | --- |
| Shoulder | [[item:243991@BAAAAsbB]] |
| Chest | [[item:243977@BAAAAsbB]] |
| Wrist | [[item:275707]] |
| Waist | [[item:275707]] |
| Legs | [[item:240133@BAAAAsbB]] |
| Boots | [[item:244009@BAAAAsbB]] |
| Ring 1 | [[item:243957@BAAAAsbB]] |
| Ring 2 | [[item:243957@BAAAAsbB]] |
| Weapon | [[item:244031]] |

:::

:::column
:::gear **Devastation Evoker** Enchantments in Raids
```json
{
  "source_code": "JQFZ7WQ9NCQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGAkiOYAAB1jbCYgS94OAAAAAAB8TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244031]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Macros

Discover recommended macros for Devastation Evokers during Raid encounters and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Cursor Macros
**[[spell:357210]]** -- *Allows you to cast [[spell:357210]] with one button press, aimed at your cursor, instead of first aiming it with the ground template and then activating it.* ***When playing Scalecommander you won't need this anymore because of [[talent:117538]]!***

```wow-macro
#showtooltip 
/cast [@cursor] Deep Breath
```

:::

:::details Mouseover Macros
**[[spell:365585]]** -- *Casts [[spell:365585]] on your mouseover or target.*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Expunge
```

**[[spell:374251]]** -- *Casts [[spell:374251]] on your mouseover target.*

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead][] Cauterizing Flame(Red)
```

**[[spell:406732]]** / **[[spell:374968]]** *--* *Casts [[spell:406732]] on your mouseover target or [[spell:374968]]* *depending on your talent choice.*

```wow-macro
#showtooltip [known:Spatial Paradox] Spatial Paradox; Time Spiral
/cast [@mouseover, help, nodead, known:Spatial Paradox] Spatial Paradox
/cast [known:Time Spiral] Time Spiral
```

**[[spell:360995]]** -- *Casts [[spell:360995]] on your mouseover target.*

```wow-macro
#showtooltip 
/cast [@mouseover,help,nodead][] Verdant Embrace
```

:::

:::details Rescue Macros
> These macros make [[spell:370665]] easier to use.

**Cast on Player** [[spell:370665]] Macro -- *This macro makes [[spell:370665]] move your friendly target to your location, requiring you to press the macro button and then mouse-click on your unit frames on the chosen target.*

```wow-macro
#showtooltip
/cast [@player] Rescue
```

**Cast on Cursor [[spell:370665]] Macro** -- *This macro makes [[spell:370665]] move you and your friendly target to your cursor's location, requiring you to first choose the unit, aim with your cursor and then press the macro button.*

```wow-macro
#showtooltip
/cast [@cursor] Rescue
```

:::

:::details Utility Macros
**[[spell:358734]]** -- *Activates or cancels the Evoker double-jump / slow fall ability [[spell:358734]]*, *I recommend keybinding it to mouse scroll wheel down for easy knockback canceling and mobility usage.*

```wow-macro
#showtooltip Glide
/cancelaura Glide
/use Glide
/script UIErrorsFrame:Clear()
```

**[[spell:360995]]**, **[[spell:361469]]** and  **[[spell:355913]]** Self-heal Macros -- *It is also possible to use a self-target key modifier but I recommend keybinding these for easy self-healing without needing to target yourself.*

```wow-macro
#showtooltip 
/cast [@player] Verdant Embrace
```

```wow-macro
#showtooltip 
/cast [@player] Living Flame
```

```wow-macro
#showtooltip 
/cast [@player] Emerald Blossom
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Devastation Evoker**, outlining which addons are used and how they are utilized in Raids to make your life easier.

![Devastation Evoker Interface in Raids](<https://assets-ng.maxroll.gg/wordpress/DevastationRaidMidnightUI-1-1024x616.webp>)

**Devastation Evoker** Interface in Raids

:::accordion
:::details Addons
- **BetterCooldownManager / BCDM** *--* Cooldown Manager customization
  
  - Provides additional customization to the Cooldown Manager.
- **Unhalted Unit Frames / UUF** *-- Unit frame addon* 
  
  - Adds custom player, target and boss frame customization.
  - Alternatively, you can also use ElvUI
- Plater -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking and threat coloring.
- **Details** -- In-depth Damage Meter
  
  - Most powerful, reliable, handsome, damage meter.
- **BigWigs** *-- Generic Boss Mod* 
  
  - BigWigs is a boss encounter add-on. It consists of many individual *encounter scripts*, or *boss modules*; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Bartender4** -- Action Bar addon
  
  - Replacement for the default action bars, allowing more customization and extra options.
- **RaidFrameSettings / RFS** -- Blizzard Raid frames customization
  
  - Provides additional customization to the default Blizzard raid frames.
- **NorskenUI** *-- Collection of Skinning, QoL and Features.*
  
  - One of the many "collection" addons available with multiple quality of life improvements, UI skinning and other useful functionalities.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**Evoker**

- Panacea healing increased by 25%

**Hero Talents**

- **[[talent:123333]]**
  
  - *Developers’ notes: Wingleader’s cooldown reduction mechanic strongly incentivized spreading Bombardment applications across multiple targets. We feel that this gameplay is unintuitive in isolation, and additionally creates unhealthy behaviors such as Disintegrate clipping and Mass Disintegrate/Eruption pooling. This redesign is intended to retain the multitarget focus of the talent, while addressing those issues. We are increasing some of Scalecommander’s sources of area damage to compensate for the lessened cooldown reduction the new Wingleader will provide.*
  
  
  
  - Wingleader has been redesigned – Mass Disintegrate/Mass Eruption reduces the remaining cooldown of Deep Breath/Breath of Eons by 0.5 seconds/1 second for each target struck.
  - Command Squadron’s Pyre damage increased by 40%.
  - Maneuverability’s damage over time increased by 40%.

**Devastation**

- *Developers' notes: Devastation's Apex talent, while powerful, hasn't been as gameplay-affecting as we had hoped. We've redesigned the Rank 3 effect to override Dragonrage with a limited number of uses of a new, powerful spell, Unbound Flame, once Dragonrage is over. Additionally, Rising Fury and Risen Fury have been streamlined into one buff effect.*
- Apex Talent: Rising Fury (Rank 3) has been redesigned – When Dragonrage ends, Rising Fury persists for 4 seconds per stack, and Dragonrage becomes Unbound Flame. Unbound Flame may be cast 4 times before Dragonrage finishes its cooldown.
  
  - Unbound Flame – Exhale destructive flame, critically striking for Fire damage to your target and nearby enemies. Damage reduced beyond 5 targets. Causes 1 Essence Burst. Instant cast and 25-yard range.
- Tyranny has been updated – Now interacts with Unbound Flame, causing Unbound Flame to always gain the maximum benefit of Mastery: Giantkiller regardless of the targets' health.
- Deep Breath damage increased by 30%.
- Pyre damage increased by 10%.
- Disintegrate damage increased by 40%.
- Living Flame damage increased by 50% and healing increased by 25%.
- Verdant Embrace healing increased by 25%.
- Emerald Blossom healing increased by 25%.
- Shattering Stars that are released from an Eternity Surge due to Scintillation are now subject to Scintillation's 40% effectiveness multiplier.
- Risen Fury has been removed.
- **Hero Talents**
  
  - **[[talent:123336]]**
    
    - Twin Flame damage and healing reduced by 20%.
    - Fixed an issue where Twin Flame was not scaling with Mastery.
  
  
  
  - **[[talent:123333]]**
    
    - Wingleader now reduces the cooldown of Deep Breath by 1 second per target struck (was 0.5 seconds).

:::

:::

:::accordion
:::details Patch 12.0.5
**Evoker**

- New Ability: Battle Visage – Activate to automatically assume your Visage whenever you are not casting draconic spells such as Fire Breath and Soar.
  
  - Full list of abilities that temporarily shift you to Dracthyr: Deep Breath, Dream Flight, Breath of Eons, Fire Breath, Eternity Surge, Dream Breath, Upheaval, Hover, Spatial Paradox, Rescue, Zephyr, Verdant Embrace (without Dream Simulacrum talented), and Soar.
  - Many abilities that used to force a shift to Dracthyr have adjusted visual treatments for Visage form.
  - While active, Battle Visage also applies a camera height override to Dracthyr form to prevent the camera from adjusting rapidly when shifting between forms.
- Unravel damage increased by 300%.
- Blessing of the Bronze is now castable on friendly players who are not in your party or raid group, similar to other group buffs like Arcane Intellect.
- Fixed an issue where Twin Guardian was applying its bonus at the start of Rescue rather than upon landing.

:::

:::

:::accordion
:::details Patch 12.0.1
**Evoker**

- [[spell:357208]] total damage, instant and periodic, should now be consistent at all Empower ranks, with all combinations of Fire Breath-affecting talents.
- [[talent:115663]] healing increased by 60%.
- **Devastation**
  
  - [[spell:356995]] damage increased by 32%.
  
  
  
  - [[talent:115655]] healing increased by 50%.
  - [[spell:355913]] healing increased by 50%.

- **Hero Talents**
  
  - **[[talent:123336]]**
    
    - [[talent:117519@AJQD]] now deals [[spell:357208]] damage at 115% effectiveness (was 150%).
    - [[talent:117519@AJQD]] now causes Pyre to consume 4 seconds of [[spell:357208]] (was 10 seconds) and 1 second of [[spell:357208]] from [[spell:356995]] damage (was 2 seconds).
  
  
  
  - **[[talent:123333]]**
    
    - ***Developers' notes: We're reducing the number of times [[spell:357210]] is available through [[talent:117550@AJQD]] for [[talent:123333]] to lessen the amount of time spent airborne which can be difficult to play. We're offsetting the damage losses with buffs to other [[talent:123333]] talents.***
    - **[[talent:117550@AJQD]] now causes [[talent:117533@AJQD]] to reduce the cooldown of [[spell:357210]] by 0.5 seconds (was 1 second), up to 1.5 seconds (was 3 seconds).**
    - **[[talent:117549]] increases Black spell damage by 30% (was 20%).**
    - **[[talent:136051]] now increases Essence ability damage by 25% (was 15%).**

:::

:::

:::accordion
:::details Patch 12.0
**Evoker**

- **[[talent:123333]]**
  
  - New Talent: [[talent:136053]] – While flying during [[talent:115536@FAQARegB]] or [[spell:357210]] you are assisted by a squadron of Dracthyr who assault enemies with Pyre, dealing Fire damage to nearby enemies up to 8 times.
  - New Talent: [[talent:136052@AJQD]] – [[talent:117536]] or [[talent:122279]] strikes 1 additional target.
  - New Talent: [[talent:136051]] – Essence abilities deal 15% more damage.
  - [[talent:120123]] now grants a charge of [[spell:358267]] instead of granting full charges.
  - **Devastation**
    
    - [[talent:117518@AJQD]] and the damage effect from [[talent:117538@AJQD]] now extends its duration when [[spell:357210]] is cast multiple times while the effect is active.
    - [[spell:356995]] icon now changes while [[talent:117536]] is active.
- **[[talent:123336]]**
  
  - New Talent: [[talent:123416]] – [[spell:357208]] cooldown is reduced by 5 seconds.
  - New Talent: [[talent:117542@AJQD]] – [[spell:357208]] damage over time lasts 4 seconds longer.
  - New Talent: [[talent:136055@AJQDBA]] – [[spell:355936]] and [[spell:357208]] have a 50% chance to generate [[spell:359565]].
  - New Talent: [[talent:136056@AJQD]] – Consuming [[spell:359565]] fires a twin flame, healing or damaging your target for 390% Spell Power.
  - New Talent: [[talent:136054]] – [[talent:136056@AJQD]] bounces to up to 2 additional targets.
  - [[talent:117543@AJQD]] has been redesigned – [[spell:357208]] reaches its maximum empower level 20% faster.
  - The following talents have been removed:
    
    - [[spell:443328]]
    - [[spell:444140]]
    - [[spell:444081]]
  - Devastation
    
    - New Talent: [[talent:117547@AJQD]] – [[spell:357208]] gains an additional charge.
    - [[talent:117519@AJQD]] has been redesigned – [[spell:356995]] damage consumes 2 seconds of [[spell:357208]] from enemies it damages, detonating it for 150% of the amount consumed. [[spell:357211]] consumes 10 seconds of [[spell:357208]] from enemies it damages, detonating it for 150% of the amount consumed.
- Class
  
  - New Talent: [[talent:115617]] – While flying during [[talent:115536@FAQARegB]] or  [[spell:357210]], 100% of damage you would take is instead dealt over 10 seconds.
  - New Talent: [[talent:136560]] – [[spell:358733]] speed and height increased by 10%.
  - New Talent: [[talent:115620]] – Your [[spell:361469]] and [[spell:367979]] are 30% more effective on yourself.
  - [[talent:115595]] has been redesigned – [[talent:115596]] increases movement speed by 100% and allows spells to be cast while moving for 3 seconds.
  - [[talent:115669]] has been redesigned – Now upgrades [[talent:115613]], causing it to heal you over 8 seconds equal to the amount of damage it reduced.
  - [[talent:115616]] has been redesigned as a passive effect – [[spell:357208]] consumes absorb shields from enemies, dealing additional Spellfrost damage to them.
  - [[spell:362969]] damage increased by 50%.
  - [[talent:115657]] now changes the icon for [[spell:361469]] while active.
  - Fixed an issue where [[spell:357208]] could engage enemies if the player died and resurrected while it was active.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - [[spell:375577]]
    - [[talent:115645]] *(moved to the Augmentation and Devastation talent trees)*
- Devastation
  
  - New Talent: [[talent:115626]] – Increases [[spell:1265804]] damage by 35%. [[spell:1265804]] are exhaled at all of your [[talent:115581]] targets.
  - New Talent: [[talent:115579]] – [[talent:115581]] upgrades your next [[spell:362969]] to [[talent:115579]], damaging all nearby enemies and dealing 75% additional damage.
  - New Talent: [[talent:115623]] – [[spell:357210]] deals 20% increased damage and can be cast again within 18 seconds of being used. [[talent:115610]] will be available after the second cast if talented. In PvP, [[spell:357210]] damage is instead reduced by 20%.
  - [[spell:370452]] has been redesigned as a passive named [[talent:115627]] – [[talent:115581]] releases a [[spell:1265804]] at your target that deals 50% more damage per empower level reached.
  - [[talent:115641]] has been redesigned – Increases the critical strike chance of your spells by 2%/4%.
  - [[talent:115585]] has been redesigned – Now increases the damage of [[spell:361469]] by 10% and reduces its cast time by 0.3 seconds.
  - [[talent:115638]] has been redesigned – Deep Breath reduces the Essence cost of your next 4 [[spell:356995]] or [[spell:357211]] by 1. Stacks up to 8 times.
  - [[talent:115622]] has been redesigned – Enemies affected by [[spell:357208]] damage over time effect take 25% increased damage from your Red spells.
  - [[talent:115647]] damage increased by 20%.
  - [[talent:115628]] increases the damage of [[spell:357211]] by 2% per stack (was 5%).
  - [[talent:115584]] now activates after casting 6 [[spell:357211]] (was 9).
  - [[spell:369372]] no longer increases the damage of [[spell:356995]] and [[spell:357211]].
  - [[spell:369372]] damage increased by 25%.
  - [[talent:115580]] now also increases the damage of [[spell:362969]].
  - [[talent:115632]] now only affects [[talent:115581]].
  - [[talent:115642]] effect now diminishes by 25% per empower spell cast during [[spell:375087]].
  - [[talent:115645]] is now learned in the Devastation specialization tree (was a class talent).
  - [[talent:136056@AJQD]] is now considered a Red spell.
  - Several talents have changed positions in the talent tree.
  - The following talents have been removed:
    
    - [[spell:386342]]
    - [[spell:370962]]
    - [[spell:368847]]
    - [[spell:386336]]
    - [[spell:371016]]
    - [[spell:386405]] *(moved to the class talent tree)*
    - [[spell:370783]]

:::

:::

---

## FAQ

:::accordion
:::details Q: Why do I feel so squishy even though you rated Devastation 4/5 on Survivability?
**A:** You have a vast arsenal of defensive tools but most of them are proactive so you have to anticipate the damage intake and use one of your many available options to mitigate it!

:::

:::

---

### Credits

Written By: **fraggo**

Reviewed by: **Ftm**

---

:::changelog 更新记录
**2026-08-06** Updated for 12.1

**2026-06-16** Updated for patch 12.0.7

**2026-04-21** Updated for patch 12.0.5

**2026-02-22** Updated for Midnight launch.

**2026-02-10** Updated for patch 12.0.1

**2026-01-15** Updated for patch 12.0

**2025-12-02** Updated for patch 11.2.7

**2025-10-07** Updated for patch 11.2.5

**2025-08-04** Updated for patch 11.2

**2025-06-17** Updated for patch 11.1.7

**2025-04-21** Updated for patch 11.1.5

**2025-02-25** Updated for patch 11.1

**2024-12-17** Updated for patch 11.0.7

**2024-10-23** Updated for patch 11.0.5

**2024-08-17** Updated for patch 11.0.2

**2024-07-24** Guide Written for the pre-patch 11.0.1



:::
