Welcome to the **Outlaw Rogue** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**AoE** · 4/5 · Strong

Utility · 3/5 · Average

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent

Single Target · 4/5 · Strong



:::

:::

:::column
:::gear **Outlaw Rogue** Mythic+ Best in Slot
```json
{
  "source_code": "JMpAwTFBBc__BEwAmQggQEAAnk7AE06ACKwF2gVABk-FEAQEBAwRtOgCtOAj1IoAYFQAUSCBCwQAAcRuD4kgC4UABkJJEIACBAQC5OggC4UABA-FEAICBAgEBQEDYFQAVGgHQUAAhu7AB0DGBfBBBU-FEEAME8QuJADLgt7AECSAAkBwDYiqBYGAAUQAsIyLLFQAXSCBAgQAAUgZsw9FEIICBAQ94Og-smQOEAYLRIBAKEAbk4UAB81HEAACDAQApxRBAEgSXIQAdFgEBIENYFQAYfBBAAQAA4UABEbCCCQIBIIHYFQANE6AGgQBCSyA5OApqQgIvsUA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240900]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240967]] · [[item:240906]] |
| 肩部 | [[item:271508]] | [[item:243991]] |
| 胸部 | [[item:271513]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240914]] |
| 腿部 | [[item:271509]] | [[item:244641]] |
| 脚部 | [[item:268261]] | [[item:243983]] |
| 腕部 | [[item:244576]] | [[item:240906]] · [[item:245785]] · [[item:240166]] |
| 手部 | [[item:271511]] |  |
| 戒指一 | [[item:268252]] | [[item:240890]] · [[item:243957]] |
| 戒指二 | [[item:273792]] | [[item:240906]] · [[item:243957]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270173]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268209]] | [[item:244001]] |
| 副手 | [[item:237837]] | [[item:245785]] · [[item:243971]] · [[item:273060]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent points unlock and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As an **Outlaw Rogue**, you have access to Gravedigger, which makes your [[spell:315341]] have a  45% to apply 2 stacks of its 6% buff.

**Rank 2** makes your 5 Combo Points or more [[spell:2098]] deal extra damage as physical

While **Rank 3** makes your [[spell:2098]] have a 12% chance to grant you 1 stack. At 6 stacks, your next [[spell:315341]] costs no energy, and generates 6 Combo Points, and resets its cooldown.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-outlaw-mxr.webp>)

Gravedigger

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[talent:112552]]
    
    - Resets the Cooldown of your [[spell:13750]], [[spell:315341]], [[spell:13877]], [[spell:271896]] and [[talent:117148@FAgARRgB7PvA]].
  - [[talent:112557]]
    
    - Interesting new talent that increases the crit of your [[spell:315341]] through your auto attacks. Stacking.
  - [[talent:112541]] / [[talent:135732]]
    
    - Gives your [[spell:13750]] a bit of burst which the spec is lacking, or makes it last longer.
  - [[talent:112554]]
    
    - The old Bonus from [[spell:193316]] added in the tree.
  - [[talent:112529]]
    
    - Interesting talent that can help a bit with downtime but nothing significant.
- **Class Tree**
  
  - [[talent:112636]]
    
    - Increases agility by 3%.
  
  
  
  - [[talent:112639]]
    
    - No longer a button, now it procs from your generators and increases your next finisher crit by 10%.
  - [[talent:112644]]
    
    - Extra attack speed from your [[spell:5171]].
- **Removed**

- [[spell:424044]]
  
  - This, along with [[spell:423703]] is the biggest change to the tree. You no longer play around Stealth windows.
- [[spell:341542]]
- [[spell:341546]]
- [[spell:423703]]
- [[spell:108216]]
- [[spell:354897]]
- [[spell:196937]]
- [[spell:209423]]
- [[spell:382746]]
- [[spell:381985]]
- [[spell:344363]]
- [[spell:381988]]
- [[spell:341540]]
- [[spell:455143]]
- [[spell:170882]]
- [[spell:341534]]
- [[spell:455131]]

## Hero Talents



### [[talent:123371]]

- Every 5 Combo Point or more finisher that you use has a chance to flip a coin.
  
  - Landing on [[spell:452923]] increases your damage by 10%. Additional flips landing on [[spell:452923]] increase damage by 2%. Stacking
  - Landing on [[spell:452538]] does Cosmic damage. Additional flips increase [[spell:452538]] damage by 10%. *Stacking*
- [[talent:117724]]
  
  - Every 7 coin flips, you gain a 4% agility buff, plus:
    
    - Both [[spell:452923]] and [[spell:452923]] bonuses increase by 50%.
    - Coin flips are 15% more likely to match the same flip as the previous one.

Neither of these flips offer much in terms of gameplay, and you could do without tracking any of them, but there is some minmaxing you can do with the talents in the Fatebound tree.

- [[talent:117736]].
  
  - Rolling both flips after you use your [[spell:13750]].
- [[talent:117717]]
  
  - Makes your [[spell:13877]] hit 6% harder.
- [[talent:136025]]
  
  - Passive crit.
- [[talent:136026]]
- [[talent:136024]]




### [[talent:123372]]

- Makes your [[spell:8676]] and [[spell:1752]] hit your target with an [[talent:117737]]. *10sec duration, 15sec Cooldown.*
  
  - [[talent:117737]] applies [[spell:441224]], making the target take 8% more damage from you and being unable to parry, which is pretty nice. Especially on bosses where you have to sit on front of the boss for extended periods of time.
  - [[talent:117737]] also applies 1 stack of [[spell:441786]] as a buff on you.
    
    - At 4 stacks of [[spell:441786]], your next [[spell:2098]] becomes [[talent:117712]].
  - [[talent:117712]] hits your target as if your [[spell:2098]] had an extra 5 Combo Points.

- [[talent:120130]]
  
  - This is a pretty nice defensive that adds some tankyness to your kit.
- [[talent:117708]]
  
  - This is a synergistic talent in the tree that outside of being a flat % buff on your finishers, works with [[talent:117725]] and [[talent:117712]].
- [[talent:117731]]
  
  - This is a pretty nice quality of life talent.
- [[talent:117725]]
  
  - [[talent:117708]] has pretty good uptime so a flat damage buff on your cleave is decent.
- [[talent:117715]]
  
  - Unfortunate that [[talent:117149]] is the ability that triggers this for Outlaw, but a significant talent for the spec nonetheless.
- [[talent:136023]]
- [[talent:136022]]
- [[talent:136021@AJABBA]]





## Talents



### [[talent:123374]] [[spell:381989]]

:::talents
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAGDYgNYGjGzGgtJswAgZmZwA",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw22MzMMzMzsYmZ2GAAAAGDYgNYGjGzGgtJswAgZmZwA"
}
```
:::

**24%~ Haste requirement.**

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Spec Tree

- [[spell:381989]]
  
  - This talent allows you to extend your [[spell:193316]] by 30 seconds.
- [[talent:112529]]
  
  - A bit of extra cooldown reduction between packs or during downtime.
- [[talent:112556]]
  
  - Extending your cleave targets from 5 to 8, including main target.
- [[talent:112533]]
  
  - Pretty good builder during big packs even with the energy increase to it
- [[talent:112535]]
  
  - Synergistic ability that boosts your damage through the tier set, plus giving you some extra energy.
- [[talent:112542]]
  
  - Pivotal talent for keeping up your Stage 2 of [[spell:193316]] or above.

##### Hero Talents

- [[talent:125140]]
  
  - This is one of the better mobility talents to have when you have to cover a large amount of space.
- [[talent:125139]]
  
  - We pick this talent since Outlaw doesn't like playing [[spell:170882]].




### [[talent:123372]]

:::talents [[talent:123372]] **Outlaw Rogue** Single-Target talents in Raids
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the **Rotation** and **Deep Dive** sections below.

##### Hero Talents

- [[talent:125140]]
  
  - This is one of the better mobility talents to have when you have to cover a large amount of space.
- [[talent:125139]]
  
  - We pick this talent since Outlaw doesn't like playing [[spell:170882]].





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:2098]] damage increased by 15%.
- **4-Set:** [[spell:1752]] and [[spell:8676]] have a 12% chance to cause your next [[spell:2098]] to be free and deal damage as if you spent the maximum combo points.

### Single-Target



#### [[talent:123374]]

##### Opener

:::rotation **Outlaw Rogue** opener on Single Target as [[talent:123374]]
```json
{
  "source_code": "J0FEKIkt1AQABgnAkMvAAEgQlQdBAAgQFYCBAAAABEAnuOAAAAAACJDCBcAYAIE2GAAAAYAdvBiNDBFAC08zEAAAC1-fTEQHJwBNAAgQFYCBAAAAAIQzPTA"
}
```
1. [[spell:13750]]
2. [[spell:193316]]  [[spell:381989]]
3. [[spell:271877]]  [[item:241308]]
4. [[spell:2098]]
5. [[spell:1752]] to 6CP
6. [[spell:315341]]
7. [[spell:1277933]]
8. [[spell:1752]]
9. [[spell:271877]]
10. [[spell:315341]]
:::

##### Priority List

1. Cast [[spell:193316]] if you are on stage 1 or have no buff.
2. Use [[spell:381989]] at stage 2 or higher.
3. Cast [[spell:13750]] on cooldown with 2 or less Combo Points.
4. Cast [[spell:315341]] with 6 Combo Points or more.
5. Cast [[talent:112552]] if [[spell:315341]], [[spell:13750]] are on cooldown.
6. Cast [[spell:271877]] on low energy.
7. Cast [[spell:2098]] at 5 or more Combo Points.
8. Cast [[spell:185763]] with [[spell:195627]] buff at 3 or less Combo Points or at 6 stacks of [[spell:195627]].
   
   - Cast [[spell:185763]] with [[spell:195627]] buff at 1 or less Combo Point or at 6 stacks of [[spell:195627]] while stage [[spell:1214934]] or above is active.
   - With 3 stacks of [[spell:195627]], use [[spell:185763]] above 1 Combo Point, and below at 4 Combo Points with stage [[spell:1214934]] or above active.
9. Cast [[spell:1752]] at 5 or less Combo Points.




#### [[talent:123372]]

##### Opener

:::rotation **Outlaw Rogue** opener on Single Target as [[talent:123372]]
```json
{
  "source_code": "JcGSIIkt1AAAAcAcyVGc1xGbAI0MU4yDAgoAkMvAAAgQYbAAAAgB09GI2MEUBEAnuOAAAAAAC08zEAAACVAHEIBdFwBYgkkRg42bgIXZzVGdAIk6JDAAAAAAC1-fTA"
}
```
1. [[spell:13750]] prepull
2. [[spell:5171]] prepull
3. [[spell:193316]]
4. [[spell:1752]] to 6CP [[item:241308]]
5. [[spell:315341]]
6. [[spell:1752]] to 6CP IF no reset
7. [[spell:51690]]
8. [[spell:1277933]]
:::

##### Priory list

1. Cast [[spell:193316]] at stage 1 or have no buff.
2. Use [[spell:381989]] at stage 3 or higher.
3. Cast [[spell:315341]] with 6 Combo Points or more.
4. Cast [[talent:117148@FAgARRgB7PvA]] on cooldown with [[spell:470347]].
5. Cast [[spell:13750]] on cooldown with 2 or less Combo Points.
6. Cast [[talent:112552]] if [[spell:315341]], [[spell:13750]] and [[talent:117148@FAgARRgB7PvA]] are on cooldown.
7. Cast [[spell:271877]] on low energy.
8. Cast [[spell:2098]] at 6 or more Combo Points.
9. Cast [[spell:185763]] with [[spell:195627]] buff at 3 or less Combo Points or at 6 stacks of [[spell:195627]].
10. Cast [[spell:1752]] at 5 or less Combo Points.





### AoE

For multitarget, your rotation barely changes, but there are a few things to note

- [[spell:13877]] cleaves from around your character, so always try to position yourself closer to mobs when possible.
- Keeping [[spell:13877]] active is the highest priority with 2 or more targets.
- Remember to always [[spell:13877]] prepull if you are going to be cleaving.
- When you have [[spell:381878]] talented, you use your [[spell:13877]] as the highest priority builder at 5 or more targets

## Deep Dive

#### Roll the Bones , how it works, and how to play it optimally.

1. Generally, they made this ability much simpler. Right now, every time you press [[spell:193316]], you a chance to get 4 different stages of buffs, with each stage above 1 giving you the previous buff(s), plus the current one. For example
   
   - Stage 1: [[spell:1214933]]
   - Stage 2: [[spell:1214934]]
   - Stage 3: [[spell:1214935]]
   - Stage 4: [[spell:1214937]]
2. So if you have [[spell:1214934]], you will always have [[spell:1214933]]. If you have [[spell:1214935]], you will have the previous 2, etc.
3. You always want to stay at or above Stage 2.

#### For Keep It Rolling , you will want to use it as soon as possible on Stage 3 or above.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**



### Altar of Fangs

:::talents **Outlaw Rogue** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.
  
  - There is also an AoE phase that follows breaking the [[spell:1287797]], which also transfers all the damage done to the main body of the boss. That means that you definitely want to save your offensive cooldowns for this phase.
- Always be on the lookout for the [[spell:1310358]] cast and be ready to interrupt it, especially during **The Uncoiled Writhe** phase, where it can easily be forgotten.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.
- Whenever you dodge an [[spell:1301111]], keep in mind that it also bounces from the walls.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294557]] from **Primal Serpent**.
  - [[spell:1289416]] from **High Evolutionist**.
  - [[spell:1307567]] from **Ula'tek's Chosen**.

- **Pay extra attention to these casts:**
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1294567]] from **Twinfang Harrower**.
    
    - This can also be removed with a slow removal, such as [[spell:1856]].

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### Den of Nalorakk

:::talents **Outlaw Rogue** Mythic+ Build in Altar of Fangs
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]] and not getting a dispel from your healer.
- Don't forget to interrupt the adds that the boss spawns. 
  
  - Keep in mind that adds also leave a pool under them that will help you deal with the pushback of the [[spell:1235656]] cast.
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1241214]] and [[spell:1297696]] from **Earthwhisper Tender**.
  
  
  
  - [[spell:1309919]] from **Frigid Mauler**.
  - [[spell:1246687]] and [[spell:1297778]] from **Stormbound Mystic**.
  
  
  
  - [[spell:1290205]] from **Loa Speaker Nanea**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
    
    - Can remove the root with [[spell:1856]].
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### Murder Row

:::talents **Outlaw Rogue** Mythic+ Build in Murder Row
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1216571]] from **Felonious Mage**.
  - [[spell:1201554]] from **Seductive Sayaad**.
  - [[spell:1257877]] from **Influentual Reviewer**.
  - [[spell:1223204]] from **Unleashed Imp**.
  - [[spell:1214980]] from **Fel Invoker**.
  - [[spell:1214922]] from **Wrathguard Flayer**.

- **Pay extra attention to these casts:**
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### The Blinding Vale

:::talents **Outlaw Rogue** Mythic+ Build in The Blinding Vale
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Make sure to interrupt [[spell:1235616]].

##### Ikuzz the Light Hunter

- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1238232]] from **Leafy Grovecrawler**.
  - [[spell:1238294]] from **Lightfeather Petalwing**.
  - [[spell:1238063]] and [[spell:1301834]] from **Radiant Spellsower**.

- **Pay extra attention to these casts:**
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1238066]] from **Underbush Stalker**.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### Voidscar Arena

:::talents **Outlaw Rogue** Mythic+ Build in Algeth'ar AVoidscar Arena
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1228176]] from **Enthralled Shaman**.
  - [[spell:1299938]] from **Voidtouched Magi**.
  - [[spell:1298899]] from **Dominated Brawler**.
  
  
  
  - [[spell:1249621]] from **Angry Krolusk**.
  - [[spell:1233398]] from **Kilivore Screamer**.
  - [[spell:1310324]] from **Voidminder**.

- **Pay extra attention to these casts:**
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### Kings' Rest

:::talents **Outlaw Rogue** Mythic+ Build in Kings' Rest
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1294815]] and [[spell:269972]] from **Risen Hexer**.
  - [[spell:270901]] from **Seneschal M'bara**.
  - [[spell:1294972]] and [[spell:270920]] from **Queen Wasi**.
  
  
  
  - [[spell:267763]] from **Half-Finished Mummy**.
  - [[spell:1295125]] and [[spell:270492]] from **Phantom Hex Priest**.

- **Pay extra attention to these casts:**
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### Ruby Life Pools

:::talents **Outlaw Rogue** Mythic+ Build in Ruby Life Pools
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Make sure to interrupt **Blazebound Firestorm** whenever it casts [[spell:373017]].
- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:371984]] and [[spell:372743]] from **Flashfrost Chillweaver**.
  
  
  
  - [[spell:384194]] from **Primalist Cinderweaver**.
  - [[spell:1305955]] from **Blazebound Destroyer**.
  - [[spell:392576]] from **Tempest Channeler**.

- **Pay extra attention to these casts:**
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]




### Temple of Sethraliss

:::talents **Outlaw Rogue** Mythic+ Build in Temple of Sethraliss
```json
{
  "source_code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD",
  "code": "CSQAxSGv8NzbxeTO653C6Eg9HDgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAY22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAD"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.
- Interrupt [[spell:267027]] during the intermission.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.
- Interrupt **Twisted Hexxers**.

#### Trash Tips

- **Important abilities to interrupt in this dungeon are:**
  
  - [[spell:1291262]] from **Storm Adept**.
  - [[spell:1310683]] from **Brood Tender**.
  - [[spell:1293307]] from **Faithless Subjugator**.
  - [[spell:267027]] from **Toxic Viper**.
  - [[spell:268013]] from **Twisted Hexxer**.

- **Pay extra attention to these casts:**
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- **Dangerous debuffs to be wary of:**
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

##### Pre Key Prep

1. Use [[spell:13750]]
2. Use [[spell:51690]]
3. Key start -> Use [[spell:5171]]





### Affixes

The Affix system got revamped going into **The War Within Season 1** retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affixes *-- Rotates on a weekly basis*
  
  - [[spell:1284818]]
- +5 Affixes *-- Rotates of a weekly basis.*
  
  - [[spell:461916]]
  - [[spell:1272895]]+
  - [[spell:465051]]
  - [[spell:1272894]]
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- *Alternates on a weekly basis.*
  
  - Tyrannical
  
  
  
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as an **Outlaw Rogue**.

- Xal'atath's Bargain: Ascendant
  
  - You can use your [[talent:112572]] with [[talent:117740]] talented to gain the buff, but try to wait as much as possible to maximize the potential. Make sure to use on an enemy and **not** on one of the the orbs.
- Xal'atath's Bargain: Voidbound
  
  - Try to DPS the add down quickly when it spawns as it casts [[spell:462508]] and buffs nearby mobs. After it dies, you get a 20% crit chance for 20 seconds. This is a great time to use your cooldowns.
- Xal'atath's Bargain: Devour
  
  - You can use your [[item:241304]] if you drop too low.
  
  
  
  - [[talent:112585]] works on the debuff.
  - [[spell:185311]] can be useful to clear the healing absorb.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as an **Outlaw Rogue**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Outlaw Rogue** Mythic+ Stat Priorities
```json
{
  "source_code": "IoAJFMAIkgSMBEQABA"
}
```
**敏捷 ＞ 暴击 ＞ 急速 ＞ 全能 ＞ 精通**
:::

> **Higher Item level items are better in most scenarios.** For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "**Stat Priority**" is just a starting point and can easily shift depending on your individual gear.
> 
> **Haste is going to be significant better if you are not within the 24% threshold.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance -** Great stat to reduce the damage intake of "Area of Effect" abilities.
- **Leech -** Provides additional healing through damage dealing.
- **Speed -**  Niche tertiary that can be very useful and has been proven useful in the past. Makes playing certain mechanics a lot easier.

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271875@DCRAAMQAnk7QQrjgCchNYFA]] | Ula'tek |
| Neck | [[item:268265@BERAAMQAH16wPrDj1IoAYFA]] | Ula'tek |
| Shoulder | [[item:271508@DwQAAQQAXk74kgC4UA]] | The Lost Explorers / Catalyst |
| Cloak | [[item:268248@BAQAAQQAOFA]] | Nez'Kali the Soulcoiler |
| Chest | [[item:271513@DgQAAMQAJk7IoAOF]] | Vashnik the Malignant / Catalyst |
| Wrist | [[item:244576@FCSAAMQAZA8YiqjAtOAAAAAAAAi8ySB]] | Crafting |
| Gloves | [[item:271511@BgQAAMQACKgTBA]] | Entombed Sentinels / Catalyst |
| Belt | [[item:268256@BiQAAQQAS06IoAYF]] | The Coiled Altar |
| Legs | Convert [[item:268225@AgQAAIoAYFA]] into [[item:271509@DgQBAMQAhu7IoAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:268261@DAQAAMQAPk74UA]] | The Twin Fangs |
| Ring 1 | [[item:268252@DiQAAMQA1j7wPrjgC4UA]] | Sszorak |
| Ring 2 | [[item:268252@DiQAAQQA1j7oPrjgC4UA]] | Altar of Fangs |
| Trinket 1 | [[item:270175@BgwAAQQACKAWBUAABo0FCA]] | Ula'tek |
| Trinket 2 | [[item:270173@BgQAAQQACKAWBA]] | Altar of Fangs |
| Weapon | [[item:268209@DgQAAQQADk7IoAYF]] | Altar of Fangs |
| Weapon | [[item:237837@HgQAAMQAZA8MQuDpqQi8ySB]] | Crafting |

Outlaw Rogue BiS list in Mythic+




### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:273791@DiQAAMQAnk7oQrjgCEUA]] | Altar of Fangs |
| Neck | [[item:273781@BiQAAMQAH16IoABF]] | Altar of Fangs |
| Shoulder | [[item:251223@DgQAAMQAXk7IoABF]] | Voidscar Arena |
| Cloak | [[item:193763@BgQAAMQACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251226@DgQAAQQAJk7IoABF]] | Voidscar Arena |
| Wrist | [[item:251135@BiQAAMQAU06IoABF]] | Murder Row |
| Gloves | [[item:251124@BgQAAMQACKQQBA]] | Murder Row |
| Belt | [[item:251189@BiQAAQQAK06IoABF]] | The Blinding Vale |
| Legs | [[item:159313@DgQAAQQAhu7IoABF]] | King's Rest |
| Boots | [[item:251153@DgQAAQQAPk7IoABF]] | Den of Nalorakk |
| Ring 1 | [[item:251148@DiQAAQQA1j7oPrjgCEUA]] | Den of Nalorakke |
| Ring 2 | [[item:273792@DiQAAMQA1j7wQrjgCEUA]] | Altar of Fangs |
| Trinket 1 | [[item:159617@BgQAAQQACKQQBA]] | King's Rest |
| Trinket 2 | [[item:250259@BgQAAMQACKQQBA]] | The Blinding Vale |
| Weapon | [[item:193767@DgQAAQQADk7IoABF]] | Ruby Life Pools |
| Weapon | [[item:275070@DgQAAMQADk7IoABF]] | Altar of Fangs |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgwAAQQACKAWBUAABo0FCA]][[item:270173@BgQAAQQACKAWBA]] |
| **A-Tier** | [[item:270164@AgQAAIoAOFA]]  <br>[[item:270168@AgQAAIoAYFA]] |
| **B-Tier** | [[item:159617@AgQAAIoAOFA]]  <br>[[item:270165@AgQAAIoAOFA]]  <br>[[item:270166@AgQAAIoAOFA]]  <br>[[item:250259@AgQAAIoAOFA]] |
| **C-Tier** | [[item:250215@AgQAAIoAOFA]]  <br>[[item:273796@AgQAAIoAOFA]]  <br>[[item:250225@AgQAAIoAOFA]] |
| **Junkyard** | [[item:193757@AgQAAIoAOFA]]  <br>[[item:158374@AgQAAIoAOFA]]  <br>[[item:250214@AgQAAIoAOFA]] |

### Embellishments

- [[item:240166]]
- [[item:273059]]

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level therefore it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]] *-- maximum DPS*.
  
  
  
  - [[item:241320]] *-- less DPS but more survivability.*
- **Food**
  
  - [[item:266985]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240898]]
  
  
  
  - [[item:240914]] x1
  - [[item:240906]] x1
  - [[item:240890]] x1
  - [[item:240966]] *-- Unique, use one of each gem color to enhance your [[item:240966]].*
- *Running a sim is advised for optimal stats.*

### Enchantments

:::columns
:::column
| Head | [[item:275707@DAAAAMQAnk7A]]- [[item:243949]] |
| --- | --- |
| Shoulder | [[item:243991]] |
| Cloak |  |
| Chest | [[item:243977@BAAAAMQA]] |
| Wrist | [[item:275707@DAAAAMQAnk7A]] |
| Waist | [[item:275707@DAAAAMQAnk7A]] |
| Legs | [[item:244641@BAAAAMQA]] |
| Boots | [[item:244009@BAAAAMQA]] |
| Ring 1 | [[item:243957@BAAAAMQA]] |
| Ring 2 | [[item:243957@BAAAAMQA]] |
| Weapon | [[item:244001@BAAAAQQA]] |
| Weapon | [[item:243971@BAAAAMQA]] |

:::

:::column
:::gear **Outlaw Rogue** Enchantments in Mythic+
```json
{
  "source_code": "JwFZEEQ9NGQA7TDBCAAAAcSuDEwF5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAB1jbCYEBCoESuDAAAAAQADk7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:244007]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244001]] |  |
| 副手 | [[item:243971]] |  |
:::

:::

:::

> You buy [[item:275707@DAAAAMQAnk7A]] from the Great Vault Vendor to add sockets to your **Helm**, **Wrists** & **Waist**.

## Races

For min-maxing an **Outlaw Rogue** in Mythic+, different racial traits can provide a tremendous benefit to your character. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - One of the most potent racials in Mythic+ currently and historically.
  - Dispels Magic and Bleed debuffs.
- [[spell:58984]] -- Night Elf
  
  - Also one of the most potent racials in Mythic+ historically.
  - Use-cases
    
    - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]].
  - You can also re-stealth and get [[spell:108208]] during trash, but **not** during boss fights.
- [[spell:154743]] -- Tauren
  
  - Similar to Dwarf in terms of DPS, but you don't get to have [[spell:65116]].
- [[spell:33702]] *-- Orc* 
  
  - Strong racial for damage that scales with level, thus being competitive right now.
  
  
  
  - 20% reduced Stun duration on you which can be useful in some Mythic+ dungeons.
- [[spell:20589]] -- Gnome
  
  - Free yourself from roots.
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:312923]] -- Mechagnome
  
  - Fairly strong passive trait that scales with level, hence why it's so strong now

### Recommendation

**Dwarf** and **Night Elf** abilities have such a big impact on your Mythic+ experience that you need to use either of them if you're serious about pushing keys with your **Outlaw Rogue**.

## Macros

Discover recommended macros for Outlaw Rogues during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
*Sets a market when you mouseover a mob. This is great for letting you teammates know what you are planning on using your* **[[spell:1766]]** *on*

```wow-macro
/focus [@mouseover][]
/run SetRaidTarget("mouseover",6)
```

*Mouseover* **[[spell:1766]]** *if you prefer that over focus target*

```wow-macro
#showtooltip Kick
/cast [target=mouseover] Kick
```

**[[spell:195457]]** *on Cursor*

```wow-macro
#showtooltip Grappling Hook
/cast [@cursor] Grappling Hook
```

:::

:::details Focus Macros
**[[spell:1766]]** *your focus target*

```wow-macro
#Showtooltip Kick
/cast [target=focus] Kick
```

*Cast* **[[talent:112631]]** *on your focus*

```wow-macro
#showtooltipGouge
/cast [target=focus] Gouge
```

*Focus* **[[spell:408]]** *for extra CC*

```wow-macro
#showtooltip Kidney Shot
/cast [@focus] Kidney Shot
```

*Focus* **Cheap Shot**

```wow-macro
#showtooltip Cheap Shot
/cast [@focus] Cheap Shot
```

:::

:::details Utility Macros
*On this macro you can replace the names with the tanks in your group to make using* **[[talent:112574]] *much easier***

```wow-macro
#showtooltip Tricks of the Trade
/cast [@Meeresdh] Tricks of the Trade
/cast [@Meeresmana] Tricks of the Trade
/cast [@Méèrès] Tricks of the Trade
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Outlaw Rogue**, outlining which addons are used and how they are utilized in Mythic+ dungeons to make your life easier.

![](<https://i.gyazo.com/d97025dda622df7bbb24a134b36349b9.jpg>)

**Outlaw Rogue** Interface

:::accordion
:::details Addons
- **Ellesmere UI** *-- Full User Interface replacement* 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
**ROGUE**

- Class
  
  - Thistle Tea is now a choice talent – Players may now choose between the existing version, which casts automatically at low Energy in addition to being usable actively, and a new version that must be cast actively.
  - Atrophic Poison now reduces damage dealt by 4% (was 3%).
  - Atrophic Poison duration increased to 60 seconds (was 10 seconds). Duration remains unchanged in PvP combat.

- Outlaw
  
  - Developers' notes: The changes to Outlaw in Curse of Ula'tek are intended to improve talent build diversity and flexibility. We've increased the power of some underperforming talents and pulled back some that could feel "locked in". Killing Spree's damage has been increased significantly because the damage it did wasn't sufficiently stronger than using other abilities during its channel would have been. The talent should now increase your overall damage about as much as other comparable talents.
  - Killing Spree has been updated – Duration no longer increases from spending combo points beyond your maximum. Each combo point spent beyond your maximum increases damage by 15%.
  - Adrenaline Rush now speeds up the execution of Killing Spree by 20%, the same rate it increases the speed of your other attacks.
  - Killing Spree prefers targets that are not immune to damage or taking less than 5% physical damage.
  - Killing Spree damage increased by 60%. Does not affect PvP combat.
  - Killing Spree shots have a higher chance to target your selected target if they're valid.
    
    - *Developers’ notes: Much of Killing Spree’s value is the combo points it generates, so when players can spend more combo points on Killing Spree than their maximum, such as through Supercharger, the value of those extra points is diminished. Killing Spree’s duration now maxes out at the time required to generate maximum combo points, and any extra combo points spent increase the damage of the ability by a proportional amount.*
  - Improved Between the Eyes has been updated – Causes Between the Eyes critical strikes to deal 2.5 times normal damage (was 3 times).
  - Fast Action has been updated – Now reduces the cooldown of Between the Eyes by 8 seconds (was 5 seconds) and increases the damage bonus from each Between the Eyes stack by 1%.
  - All damage increased by 9%. Does not affect PvP combat.
  - Heavy Hitter increases the damage of attacks that generate combo points by 15%/30% (was 10%/20%).
  - Zero In value per stack reduced to 2% (was 3%).
    
    - *Developers' notes: We don't want players to feel obligated to use off-hand daggers to maximize the value of this talent. Zero In now has a 30% chance to not proc if triggered by a weapon with 1.8 Speed, giving it the same proc rate when attacking with daggers vs. other one-handed weapons.*
  - Audacity now also increases Ambush damage by 80%.
  - Hidden Opportunity's chance for Ambush to grant Opportunity increased to 100% of the chance for Sinister Strike to grant Opportunity (was 80%).
  - Hidden Opportunity also reduces Ambush's Energy cost by 5.
    
    - *Developers’ notes: Audacity and Hidden Opportunity are not as strong as other talent options, so we’re adding some effects to them to make them more competitive.*
  - Summarily Dispatched increases Dispatch damage by 15%/30% (was 10%/20%).
  - New connectors have been added in the talent tree between Ruthlessness and Find an Opening, and between the Flickering Steel choice node and Grand Melee.

:::

:::

## FAQ

:::accordion
:::details Q: Why is my damage so low?
**A:** One of the most common mistakes as an **Outlaw Rogue** is simply not pressing globals as soon as possible. Outlaw is a very high APM spec, and due to abilities like [[spell:79096]] and [[spell:1214937]], simply having uptime and using abilities is important. Building muscle memory with the spec, either by playing a lot of Mythic+, or hitting the dummy fixes that.

:::

:::

---

### Credits

Written By: **Perfecto**

Reviewed By: **Verb**

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.

**2026-06-17** Updated for patch 12.0.7.

**2026-04-21** Updated for patch 12.0.5.

**2026-02-10** Updated for patch 12.0.1.

**2026-01-13** Updated for patch 12.0.

**2025-12-03** Updated for patch 11.2.7.

**2025-10-07** Updated for patch 11.2.5.

**2025-07-29** Updated for patch 11.2.

**2025-06-19** Updated for patch 11.1.7.

**2025-04-21** Updated for patch 11.1.5.

**2025-02-14** Updated for patch 11.1.

**2024-12-16** Updated for patch 11.0.7.

**2024-10-24** Updated for patch 11.0.5.

**2024-08-17** Updated for patch 11.0.2.

**2024-07-29** Guide Written for the pre-patch 11.0.1.



:::
