Welcome to the **Holy Paladin** Mythic+ guide for the World of Warcraft patch 12.1.0! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Overall Healing** · 4/5 · Strong

Damage · 3/5 · Average

Utility · 4/5 · Strong

Survivability · 4/5 · Strong

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Holy Paladin** Mythic+ Best in Slot Gear
```json
{
  "source_code": "JsoAIGEA3_fABkGJEIICBAw74OwVtOggC4UABk-FEAQEBAgAtOgABIBNMWDWBEwZkQgAIEAA1kbCjAAbB8ACFAQCB8AKYFgvXQQAjfBBAiQB1AkgCgVABYgJEIAEBAwGqOgF2UQEARQoDYAIBAgHAPwJqOwD5OAAFEAJ3WzSBEgChOAhIExGIIQrDUQFcoGJEAACBAggBEJBZfRBjSw94GgHFIBFeqmACiQAuIBAEQ1HZADAS1BDE09FNgBEYFQAzeRBFDQPJYLLBY-FEAACBAggC4UA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240898]] · [[item:240898]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240898]] |
| 腿部 | [[item:271878]] | [[item:240155]] |
| 脚部 | [[item:237828]] | [[item:245790]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240898]] · [[item:245790]] · [[item:240167]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243959]] |
| 戒指二 | [[item:158366]] | [[item:240898]] · [[item:243959]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270162]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268211]] | [[item:244029]] |
| 副手 | [[item:268262]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhance Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Holy Paladin**, you have access to [[spell:1244878]], which automatically applies a beacon to low health allies, this beacon jumps around if other nearby allies drops low.

**Rank 2** makes the [[spell:1244878]] stronger by having additional 10% of your healing transfer into it and makes allies with your [[spell:1244878]] take 20% increased healing from you. While **Rank 3** enables the [[spell:1244878]] to grant an absorb shield every 8 seconds or whenever it jumps to a new ally.

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-holypala-mxr.webp>)

Beacon of the Savior

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:461287]]
    
    - This talent provides us with a good chunk of passive damage
  - [[spell:1277651]]
    
    - This talent used to empower our [[spell:25912]] after casting [[spell:375576]] or [[spell:31884]]. Now it is just a modifier on your beacons.
  - [[spell:1241714]]
    
    - Converts some of the healing from our spenders into absorbs. Not a very strong talent unless youre in a situation where your spells are overhealing a lot.
  - [[spell:248033]]
    
    - This talent now synergises very well with [[spell:1241358]]
  - [[spell:414273]]
    
    - [[spell:31884]] now amplifies your next 2 [[spell:82326]] casts.
- **Class Tree**
  
  - [[spell:1277443]]
    
    - This talent buffs our passive tankiness by a nice amount.
  - [[spell:1241945]] and [[spell:183416]]
    
    - These talents have been split apart and are now two seperate capstones. Dusk reduces our damage taken, and dawn redirects allies damage to you as long as youre at high hp, acting as a form of damage reduction for your allies.
  - [[spell:1265549]]
    
    - Provides a small burst of healing whenever a mob youve attacked dies. Good in situations where the is a lot of small mobs.
- **Removed**
  
  - [[spell:35395]]
    
    - This ability is now apart of [[spell:216331]] and is no longer a standalone ability. Limiting our holy power generation slightly.

## Hero Talents

- [[talent:123362]] focuses on healing and Cooldown strength, while [[talent:123359]] focuses on survivability and damage done.
- [[talent:123359]] and [[talent:123362]] are both quite competitive for Mythic+, but [[talent:123359]] offers slightly more damage and will be your default choice and the remainder of the guide will have that as its focus.

### [[talent:123359]]

- [[talent:117882]] rotates between [[spell:432472]] and [[spell:432459]] allowing you to buff both yourself and your target  with current Armament. These abilities replace [[spell:114165]] or [[spell:375576]]
  
  - While wielding [[spell:432472]] your spells and abilities have a chance to deal extra damage or healing.
  - With [[spell:432459]] up you get 15% max health absorb and an extra 2% absorb every 2 seconds.
  - [[talent:117877]], [[talent:117876]], [[talent:117885]] and [[talent:117874]] allow you to have higher uptime on Armaments.
  - Activating [[spell:31884]] summons another [[spell:432472]]. While [[spell:31884]] is active [[spell:432472]] echoes your Holy Power spenders.
  - Your active aura is 33% stronger on allies with Armaments thanks to [[talent:117886]].
- Few abilities are enhanced by the following nodes: 
  
  - [[talent:117887]] triggers a big burst of damage/healing around your target when [[spell:20271]] critically strikes.
  
  
  
  - [[talent:117881]] increases your armor by 5% and primary stat by extra 2% while imbued on your weapon.

### [[talent:123362]]

- After using [[spell:114165]] or [[spell:375576]] you can apply 2 [[spell:431377]] with your Holy Power spenders. While [[spell:31884]] or [[spell:216331]] is active you are linked with beam lines to all targets with [[spell:431377]] healing/damaging anything crossing them.
  
  - While [[spell:431377]] is active your Holy Power spenders are 3% stronger thanks to [[talent:117778]].
  - With [[talent:117691]] your haste is increased while [[spell:431377]] is active. This effect stacks.
- Your core spec abilities are enhanced by the following nodes:
  
  - [[spell:85673]] is replaced by [[spell:156322]] making it even stronger with extra HoT effect on top.
  - [[spell:20473]] and [[spell:85222]] are empowered with:
    
    - [[talent:117677@AJgA]] that increases critical strike chance by 5%.
    - [[talent:117669@AJgA]] which procs on critical strikes.
    - [[talent:117683@AJgA]] giving 15% chance to cast again at 30% effectiveness.

## Talents

### Default

:::talents **Holy Paladin** Mythic+ talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### When to use this Spec

This is the default loadout going into any dungeon as it specializes in healing for every situation. You have to adjust the class talent tree based on the utility needed for the affix and dungeon combo. To make your life easier, Dungeon specific talent loadouts are available in the Dungeons section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:200025]] or [[spell:156910]] 
  
  - [[spell:200025]] should be swapped to if the dungeon environment youre in is too bursty to be outhealed while running [[spell:156910]].
- [[spell:114165]] or [[spell:375576]]
  
  - On its own it is not as strong as it used to be, but as [[talent:123362]] they give us access to [[spell:431377]] which makes them very important. Ideally you want to use it with [[spell:31884]] to buff the already strong abilities.
- [[spell:157047]] + [[spell:461245]]
  
  - A combination of these 3 talents makes your beacons provide a huge amount of extra survivability on beacons targets. With well timed [[spell:200025]] this combo contributes to a large amount of your healing.

##### Class Tree

- [[spell:1277443]] and [[spell:402964]]
  
  - These are both talents that makes **Paladins** tanky even without a defensive cooldown up.
- [[spell:379391]]
  
  - There is nothing worse than missing a big cooldown by a few seconds and dying because of that. This talent allows you to use [[spell:114165]] or [[spell:304971]] even more often if needed. Perfect solution for some fights.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:53576]] Increases the healing of [[spell:19750]] by an additional 100% and the absorb from [[spell:218178]] by an additional 100%
- **4-Set:** [[spell:20271]] now has a 20% chance to grant [[spell:53576]]. [[spell:82326]] now has a 100% chance to grant [[spell:53576]] but its mana cost is increased by 50%.

### Priority List

In both of the following priority lists, the following rules apply:

- **DO NOT** overcap Holy Power. Your spenders are really strong, even if there isn't much to heal you can always use [[spell:53600]].
- Cast [[spell:20473]] as much as possible. It is the bread and butter of Holy Paladin.
- Spend your [[spell:53576]] buffs on [[spell:19750]] to refund [[spell:20473]] and since it is a quite large heal on its own

#### For Healing

##### Default

1. If talented cast [[spell:200025]] for Aoe healing if needed otherwise can skip it to save Mana.
2. Cast [[spell:114165]] on an enemy for Aoe healing or cast [[spell:375576]] on an ally for the same effect.
3. Spend Holy Power on [[spell:156322]] if at 5 Holy Power.
4. Cast [[spell:82326]] if you have mana for it. This is a very costly spell but extremely powerful
5. Cast [[spell:20473]].
6. Spend [[spell:53576]] on [[spell:19750]].
7. Spend Holy Power.
8. Cast [[spell:82326]] if you need immediate heal.
9. Cast [[spell:20271]].

#### For Damage

##### Single Target

1. If at 5 Holy Power and you dont need the holy power to heal, cast [[spell:53600]].
2. Cast [[spell:114165]] / [[spell:375576]].
3. Cast [[spell:20473]].
4. Cast [[spell:20271]].
5. Cast [[spell:53600]].

##### Aoe

1. If at 5 Holy Power and you dont need the holy power to heal, cast [[spell:53600]].
2. Cast [[spell:114165]] on an Ally for AoE damage or [[spell:375576]] on an enemy.
3. Cast [[spell:20271]].
4. Cast [[spell:20473]].
5. Cast [[spell:53600]].

### Cooldowns

#### Avenging Wrath

:::group
- An iconic paladin cooldown which now is very strong on its own thanks to[[talent:123362]]. Ideally you want to pair it up with other smaller cooldowns like [[spell:304971]] or [[spell:114165]] to increase their power. What makes this cooldown really unique is its flexibility. If you don't need it for extra healing it is completely fine to use it for damage to speed up a dungeon run.

:::

#### Divine Toll or Holy Prism

- Your main cooldown that should be used almost on CD because of how often it is available. Just like with [[spell:31884]] you can use it for both damage and healing depending on the situation.

#### Aura Mastery

- Mostly used with [[spell:465]] to provide one of the raid-wide damage reduction cooldowns. It's not as strong as it used to be but can still be a game changer against some mechanics. Make sure to use it proactively before damage events happen; otherwise, it might be a waste of a global cooldown.

## Deep Dive

### Understanding cooldown strength

- The main trick with Holy Paladin is to not overuse too many cooldowns on 1 mechanic and then end up having nothing left on the next one. Below you can find some of the most common cooldown usages that you need to know, all of them assume [[spell:200025]] being used on top:
  
  - Godlike -  [[spell:31884]] + [[spell:304971]].
  - Strong - [[spell:31884]]
  
  
  
  - Ok - [[spell:304971]]
  - Weak - [[spell:31821]]
- Avoid using [[spell:31884]] with [[spell:114165]] on fights that require very frequent AoE healing burst ( 20 seconds or less between mechanics) as it results in massive overkill.

### Min maxing Beacon of Virtue

- [[spell:200025]] is theoretically your strongest cooldown that can be further empowered by combining it with other cooldowns like [[spell:31884]], [[spell:304971]] / [[spell:114165]]. The combination of all these abilities together results in an ungodly amount of healing on beacon targets to get you through the hardest points of any fight.
- Another thing that is worth mentioning is the fact that you can pre-cast spells and still have them transfer healing through your beacons. Simply precast [[spell:82326]] or [[spell:19750]] followed by instant [[spell:200025]]. It's not game changing but provides some extra healing inside the virtue window.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons →**

### Altar of Fangs

:::talents **Holy Paladin** Mythic+ Altar of Fangs Terrace Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### Rav'i

- Watch your health whenever you get a [[spell:1296220]] debuff. Be ready to press a health potion or a small defensive if needed.
- Be always on the lookout whenever you need to dodge the [[spell:1296058]] frontal of the boss and pools on the ground after the [[spell:1307894]].
- During [[spell:1296216]], make sure to have every pool of [[spell:1306226]] soaked and press a personal during it, especially if it's a **Carrion Pile** with [[spell:1307703]].

##### The Writhing Coil

- Whenever you dodge a [[spell:1299940]], keep in mind that there is always a [[spell:1300044]] frontal cone right after, so you don't want to be too far from the boss when he finishes the charge.
- Keep an eye on the [[spell:1299053]] timing and be ready to break the [[spell:1287797]] as fast as you can.

##### Zul'jan

- Always help with soaking [[spell:1300876]], especially the first one, which happens very early into the fight.
  
  - Don't forget to drop the stacks via soaking [[spell:1301413]] frontal. Good time to press a defensive cooldown whenever you do it.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1306517]] from **Ritual Chieftain**.
  - [[spell:1306385]] from **High Evolutionist**.
    
    - Make sure to always stop this cast and never let it go through.
  - [[spell:1294849]] from **Rattling Writhe**.
    
    - Use a defensive cooldown during it.
  - [[spell:1308864]] from **Ascendant Serpent**.
    
    - Use a defensive cooldown during it.

- Dangerous debuffs to be wary of:
  
  - [[spell:1294567]] from **Twinfang Harrower**.

### Den of Nalorakk

:::talents **Holy Paladin** Mythic+ Den of Nalorakk Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Press a defensive cooldown for every cast of [[spell:1234681]].
- Always help with soaking [[spell:1234233]], but make sure not to overdo it because it also applies a stacking poison debuff on you every time you soak.
- Don't be too far from the boss to have an easier time dodging the [[spell:1234021]] frontal.

##### Sentinel of Winter

- Press a defensive cooldown whenever you are afflicted with a [[spell:1235549]].
- Be mindful of your positioning whenever [[spell:1235623]] is happening, as it spawns a tornado right under you, which doesn't leave the spawn location much.

##### Nalorakk

- Press a defensive cooldown whenever you are targeted with an [[spell:1242860]] or helping with soaking [[spell:1243011]].
- Keep an eye on the [[spell:1243569]] timer and be somewhere near the boss to be ready to get into the [[spell:1261776]] shield.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1238687]] from **Spirit of Hunger**.
  - [[spell:1241463]] from **Avatar of Determination**.
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to kill the totem as soon as possible.
  - [[spell:1246957]] from **Grizzled Warbringer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238440]] from **Keen-Eyed Striker**.
  - [[spell:1238760]] from **Spirit of Hunger**.
    
    - Swap to the totem as soon as possible.
  - [[spell:1239860]] from **Glacial Revenant**.

### Murder Row

:::talents **Holy Paladin** Mythic+ Murder Row Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Always target **Nibbles** first and make sure to have your offensive cooldowns ready for whenever you kill him to do increased damage to **Kystia Manaheart** afterwards.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:1253811]] frontal as it is always aimed at him.
- Keep an eye on the [[spell:474240]] timer and be close to the boss whenever it happens due to the boss jumping to a random player.
- Make sure to help with crowd controlling and interrupting adds casting [[spell:1264106]].

##### Zaen Bladesorrow

- Try to group up during [[spell:474478]] casts to have an easier time healing the damage and press defensive cooldowns whenever you are afflicted with a [[spell:1217123]].
- Keep an eye on the [[spell:734276]] timer and do your best to pre-position yourself near any barrel to "claim" it to have an easier time spreading behind them during an actual cast.

##### Xathuux the Annihilator

- Stay somewhere near the boss and bring an [[spell:1214637]] close to him whenever you are targeted by it.
- Try not to stay behind your tank to have an easier time dealing with a [[spell:473898]] frontal as it is always aimed at him.
- Do your best to line up offensive cooldowns with [[spell:474197]] as the boss takes increased damage during it.
- Use defensive cooldowns whenever [[spell:1295453]] happens.

##### Lithiel Cinderfury

- Keep in mind that the **Infernal** always takes reduced damage and is almost immune, so you should never target him.
- Spread around the boss and press a defensive cooldown whenever [[spell:474462]] happens.
- Be careful not to use [[spell:1214675]] instantly when the boss leaves you and wait for the [[spell:1217345]] to spawn and travel a bit first.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1297682]] from **Corrupted Warlock**.
  
  
  
  - [[spell:1302007]] from **Felmaster Lucsei**.
  - [[spell:1294824]] from **Defiled Golem**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1216300]] from **Row Hooligan**.
  - [[spell:1217633]] from **Massive Felwyrm**.
  - [[spell:1295426]] from **Wrathguard Flayer**.
  - [[spell:1217973]] from **Corrupted Warlock**.
    
    - Split the damage with your teammates or use big defensive cooldowns unless you are getting a **Curse** dispel.

### The Blinding Vale

:::talents **Holy Paladin** Mythic+  The Blinding Vale Talents
```json
{
  "source_code": "CGEA4Dpgf01ssY1iT-b8zUwvlDAAAMLAgZAAglxMYGzMzGjxYWGbzMLmpJmFjZmhhZLAYGAbgNWmxMLz2Mzs1AAAAswCwyGMmxMYAAMzwMGjGA",
  "code": "CGEA4Dpgf01ssY1iT+b8zUwvlDAAAMLAgZAAglxMYGzMzGjxYWGbzMLmpJmFjZmhhZLAYGAbgNWmxMLz2Mzs1AAAAswCwyGMmxMYAAMzwMGjGA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Position yourself near the flowers to be able to soak them immediately whenever [[spell:1235564]] happens.
- Don't stay too far from the boss in case you get targeted with a [[spell:1235640]].

##### Ikuzz the Light Hunter

- Position yourself under the boss whenever [[spell:1236746]] happens to cleave roots passively. If you find yourself far away from the boss, then make sure to use a defensive cooldown.
- Try to be grouped up during [[spell:1236709]] casts to have an easier time healing through it.
- Keep an eye on the [[spell:1253410]] timer and be ready to run away from the boss to avoid getting eaten.

##### Lightwarden Ruia

- Use a defensive cooldown if you are targeted with a [[spell:1239824]] and try not to aim at your teammates with it.
- Spread out around the boss during the [[spell:1239885]] phase to have an easier time dealing with [[spell:1240257]]. Don't be too far from the boss either, as it is a frontal cone and is easier to avoid the closer you are to the boss.
- Keep in mind that the last phase, whenever the boss uses [[spell:1239883]], is the hardest, and you might want to have your offensive and defensive cooldowns ready for it.

##### Ziekket

- Don't stand between the boss and dead **Lashers** as they are going to get cleansed with a [[spell:1246607]] frontal.
- Intercept the light orbs flying towards the boss, as they are going to grant you a [[spell:1247052]] stacking buff, which increases your damage done.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1238368]] from **Overgrown Hydra**.
  - [[spell:1271385]] from **Sporeblight Belcher**.
  - [[spell:1255205]] from **Virid Grovekeeper**.
    
    - Be careful, as this spell also knocks you.
  - [[spell:1250937]] from **Potatoad Matriarch**.
    
    - Applies a **Poison** debuff to every member of the group.

- Dangerous debuffs to be wary of:
  
  - [[spell:1238066]] from **Underbush Stalker**.

### Voidscar Arena

:::talents **Holy Paladin** Mythic+ Voidscar Arena Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Try to always group up with your teammates during this fight, as it is very easy to get separated during it.
- Use a defensive cooldown whenever you are hit with a [[spell:1222100]].

##### Atroxus

- Don't be too far from the boss to have an easier time dodging the [[spell:1222721]] frontal.
- Swap to the **Toxic Creeper** as soon as he spawns and press a defensive cooldown while it is alive.

##### Charonus

- Use a defensive cooldown whenever [[spell:1227197]] happens.
- Hide behind your tank if you are targeted with a [[spell:1227247]]. Additionally, you can also outrun it with a movement speed buff, but that is not recommended.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1246820]] from **Ruthless Totemcaller**.
    
    - This is an instant cast; make sure to swap to it to kill it as soon as possible.
  - [[spell:1299270]] from **Raj'kess the Spellstorm**.
  - [[spell:1234855]] from **Chitigoth**.
  - [[spell:1298900]] from **Brutal Overseer**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1252406]] from **Devouring Brutalizer**.

### Kings' Rest

:::talents **Holy Paladin** Mythic+ Kings' Rest Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- Keep in mind that by the end of the [[spell:1306736]] debuff, you will spawn a pool on the ground, which will later transform into an add that you need to kill. Try to spawn them close to each other for better cleave value.
  
  - [[spell:1306736]] debuff also hurts and is a good opportunity to use a defensive cooldown.
- Make sure to group up during the [[spell:1311987]] to have an easier time healing through it.

##### Mchimba the Embalmer

- Use a defensive cooldown whenever you are targeted by a [[spell:267618]] cast.
- Don't forget that [[spell:267874]] debuff also leaves a pool on the ground, so place it accordingly.

##### The Council of Tribes

- Use a defensive cooldown whenever you are afflicted with a [[spell:266231]] debuff.
- Don't be too far from the boss to have an easier time grouping up for the [[spell:267494]] soak.
- During the last phase, whenever [[spell:267060]] happens, make sure to swap to totems immediately and target **Explosive Totem** first.

##### Dazar, The First King

- Important to know that **King Dazar** does not share his health with **Reban** and only does it with **T'zala**, who appears whenever **King Dazar** drops below 80%.
- Use a defensive cooldown whenever [[spell:1303267]] happens.
- Don't stay too far away during [[spell:1303324]].

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:270003]] from **Animated Guardian**.
  - [[spell:269928]] from **Shadow-Borne Champion**.
    
    - Make sure your spells are not getting deflected.
  - [[spell:1296719]] from **King Rahu'ai**.
  - [[spell:1305982]] from **Queen Patlaa**.
    
    - This is baited at players, so make sure to group up and spawn them together.
  - [[spell:270293]] from **Purification Construct**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1297918]] from **King A'akul**.
  - [[spell:1306763]] from **Queen Patlaa**.
  - [[spell:1301851]] from **Royal Berserker**.
  - [[spell:1298304]] from **Shadow of Zul**.

### Ruby Life Pools

:::talents **Holy Paladin** Mythic+ Ruby Life Pools Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- Keep in mind that you leave a pool on the ground under you after [[spell:396044]] cast, so make sure to position yourself close to the group and don't spawn any awkward pools alone.
- Be mindful of your positioning whenever [[spell:373046]] happens to give your tank an easier time picking up aggro on the **Whelps**.

##### Kokia Blazehoof

- Use a defensive cooldown whenever [[spell:384823]] happens.
- Keep an eye on the timer of [[spell:372107]] and aim it properly. Aiming it at the closest wall will result in it exploding early, which will make it harder for you to dodge it.

##### Kyrakka and Erkhart Stormvein

- Be close to the boss to have an easier time dodging the [[spell:381525]] frontal.
- Use a defensive cooldown whenever you are afflicted with a [[spell:381602]] debuff. Keep in mind that it also spawns fire pools on the ground that are also getting pushed away with [[spell:381517]], so be mindful of where you are going to spawn them.
- Don't forget to stop casting whenever [[spell:381516]] happens to avoid getting interrupted.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:1305201]] from **Primal Juggernaut**.
  - [[spell:372047]] from **Defier Draghar**.
  - [[spell:385536]] from **Ashseer Flamelasher**.
    
    - Stop this cast as fast as possible.
  - [[spell:373692]] from **Blazebound Destroyer**.
  - [[spell:1306366]] from **Tempest Channeler**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1307205]] from **Earthbound Guardian**.
  - [[spell:373693]] from **Primalist Cinderweaver**.
  - [[spell:392640]] from **Thunderhead**.

### Temple of Sethraliss

:::talents **Holy Paladin** Mythic+ Temple of Sethraliss Talents
```json
{
  "source_code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB",
  "code": "CGEAo7SHLZA3aYychDLmrvpSfBAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsYmBABAMzsstYZmhN2GzgNgZMAAzMAMjxoB"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Keep in mind that there is only one boss taking damage actively at a time, due to the [[spell:1310311]] buff, which is swapped around every 33% health of the boss.
- Make sure to get back to the boss right after the knock of [[spell:1289062]] since there is always a [[spell:1288092]] cast following up right after that you need to soak.
- Don't forget that [[spell:1288864]] debuff also leaves a pool on the ground by the end of it.

##### Merektha

- Keep an eye on the [[spell:1290031]] timer and make sure to be close to the boss when it happens to have an easier time getting rid of it and cleaving the adds.
- Stack up and try to bait [[spell:1289602]] properly together as a group, as it leaves pools on the ground after the hit.
- Use a defensive cooldown whenever [[spell:1293048]] happens.

##### Galvazzt

- Make sure to soak all the pillars around the boss and use a defensive cooldown if needed.

##### Avatar of Sethraliss

- Use a defensive cooldown whenever you are afflicted with a [[spell:1302153]]. Keep in mind that it also leaves a pool on the ground.
- Help soaking [[spell:1300869]] once when it spawns.

#### Trash Tips

- Pay extra attention to these casts:
  
  - [[spell:272655]] from **Sand-Sworn Rider**.

- Dangerous debuffs to be wary of:
  
  - [[spell:1291399]] from **Barbed Krolusk**.
  - [[spell:1308148]] from **Poisonous Viper**.

### Affixes

The Affix system didnt change much going into **Midnight Season** 2 mostly just changing at which keystone levels affixes start at and adding a helper affix for routing at lower key levels.

- +2 Affix
  
  - [[spell:1284818]]
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - [[spell:1284818]] removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Holy Paladin**.

- Xal'atath's Bargain: Ascendant
  
  - Use [[spell:105421]] to interrupt as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - There is nothing special you can do to help with this affix. Just focus it down with other dps players.
- Xal'atath's Bargain: Devour
  
  - Make sure to instantly dispel a healing absorb debuff!

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Mythic+ dungeons as a **Holy Paladin**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Holy Paladin** Stat Priority in Mythic+
```json
{
  "source_code": "JoAJFUQMgQCKBEQABA"
}
```
**智力 ＞ 精通 ＞ 暴击 ＞ 急速 ＞ 全能**
:::

> The conclusion here is that you want to equip the highest item level generally.

Blizzard introduced Stat DRs that you need to be aware of. To get to know what those are and why you have to care about them click [here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>) to get to our detailed stat DR resource post!

### Tertiary

- **Avoidance** - Reduces damage taken from AoE effects.
- **Leech** - Returns a portion of your damage and healing done as healing to you. (Excludes self healing)
- **Speed** - increases movement speed. (Does stack with other movement speed abilities)

The only time you should think about picking a lower item level is if it has Leech or Avoidance. Speed is nice to have, but you should generally ignore that stat.

Here is a showcase of how powerful Leech is for a Healer:

![](<https://assets-ng.maxroll.gg/wordpress/HpalBreakdown-1024x572.png>)

Warcraftlogs

## Gear

### Best in Slot

Due to the way stat weights work for **Holy Paladin**, there isn't a strict best-in-slot list. Although it is theoretically possible to obtain items with all the correct Tertiaries, doing so requires extraordinary luck or several human lifespans because of the weekly reset system in World of Warcraft.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:271465@DiQAAEEAvj7cVrjgC4UA]] | Tier/Catalyst |
| Neck | [[item:268265@BERAAEEAC06IQrjgCwYNYFA]] | Ula'tek |
| Shoulder | [[item:271463@DgQAAEEA1k7IoAOF]] | Tier/Catalyst |
| Cloak | [[item:268253@BgQAAEEACKAWBA]] | Coiled Altar |
| Chest | [[item:268222@BgQAAEEACKAWBA]] Catalyst into [[item:271468@DgQBAEEAJk7IoAYFgvXQ]] | Coiled Altar |
| Wrist | [[item:237834@FiQAAEEAeA8ciqjAtO3WzSB]] | Crafted |
| Gloves | [[item:271466@BgQAAEEACKgTBA]] | Tier/Catalyst |
| Belt | [[item:268259@BiQAAEEAC06IoAYF]] | Coiled Altar |
| Legs | [[item:271878@DARAAEEAbo6YhNCKAWB]] | Ula'tek |
| Boots | [[item:237828@HASAAEEAeA8ciqzD5OAAAAAAAA3WzSB]] | Crafted |
| Ring 1 | [[item:268249@DiQAAEEA3j7IQrjgC4UA]] | Vashnik |
| Ring 2 | [[item:158366@DiQAAEEA3j7IQrjgC4UA]] | Temple of Sethraliss |
| Trinket 1 | [[item:270164@BgQAAEEACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270162@BgQAAEEACKgTBA]] | Nek'Zali |
| 1h Weapon | [[item:268211@DgQAAEEA9k7IoAYF]] | Coiled Altar |
| Off hand | [[item:268262@BgQAAEEACKgTBA]] | Nymrissa Wavecaller |

#### Authors Note:

This list shows the best items for healing in Mythic+ from all sources. Keep in mind that getting different tier pieces with Leech / Avoidance changes which off-piece is best for you. Likewise, any other non-trinket item with Leech / Avoidance replaces the one suggested here.

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:251126@BgQAAEEACKQQBA]] | Murder Row |
| Neck | [[item:251234@BgQAAEEACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:251138@BgQAAEEACKQQBA]] | Murder Row |
| Cloak | [[item:251132@BgQAAEEACKQQBA]] | Murder Row |
| Chest | [[item:251151@BgQAAEEACKQQBA]] | Den of Nalorakk |
| Wrist | [[item:159409@BgQAAEEACKQQBA]] | King's Rest |
| Gloves | [[item:159413@BgQAAEEACKQQBA]] | King's Rest |
| Belt | [[item:159418@BgQAAEEACKQQBA]] | King's Rest |
| Legs | [[item:273776@BgQAAEEACKQQBA]] | Altar of Fangs |
| Boots | [[item:159412@BgQAAEEACKQQBA]] | King's Rest |
| Ring 1 | [[item:251136@BgQAAEEACKQQBA]] | Murder Row |
| Ring 2 | [[item:158366@BgQAAEEACKQQBA]] | Temple of Sethraliss |
| Trinket 1 | [[item:250214@BgQAAEEACKQQBA]] | The Blinding Vale |
| Trinket 2 | [[item:273649@BgQAAEEACKQQBA]] | King's Rest |
| One-Hand Weapon | [[item:160216@BgQAAEEACKQQBA]] | King's Rest |
| Off-Hand | [[item:251150@BgQAAEEACKQQBA]] | Den of Nalorakk |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids, and Delves.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAEEACKgTBA]]  <br>[[item:270167@BgQAAEEACKgTBA]]  <br>[[item:270162@BgQAAEEACKgTBA]] |
| **A-Tier** | [[item:273649@BgQAAEEACKgTBA]]  <br>[[item:250214@BgQAAEEACKgTBA]] |
| **B-Tier** | [[item:270171@BgQAAEEACKgTBA]]  <br>[[item:270169@BgQAAEEACKAWBA]]  <br>[[item:273794@BgQAAEEACKgTBA]]  <br>[[item:273796@BgQAAEEACKgTBA]]  <br>[[item:250215@BgQAAEEACKgTBA]] |
| **C-Tier** | [[item:250254@BgQAAEEACKgTBA]]  <br>[[item:250224@BgQAAEEACKgTBA]]  <br>[[item:193748@BgQAAEEACKgTBA]]  <br>[[item:193757@BgQAAEEACKgTBA]] |
| **Junkyard** | [[item:250248@BgQAAEEACKgTBA]]  <br>[[item:250259@BgQAAEEACKgTBA]]  <br>[[item:250255@BgQAAEEACKgTBA]] |

### Embellishments

- [[item:240167]] 2x
  
  - A generic embellishment you can put on any crafted armorpiece, it is generally recommended to craft embellishments with [[item:240167]] on the cloak and wrists slots as crafted items are lower item level and these 2 slots have the lowest amounts of stats on them. Since the cloak slot has an item with increased item level the best in slot setup has moved the crafted item away from the cloak slot and onto the boots

### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's not beneficial to equip crafted items outside of your 2x embellishments unless you don't have access to other high item level gear on that slot.

## Consumables

- **Flask**
  
  - [[item:241322]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241300]]
  - [[item:241288]] -- Recommended
- Health Potion
  
  - [[item:271884]]
- **Weapon Oil**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240900]]
  
  
  
  - [[item:240983]]

### Enchantments

:::columns
:::column
| Helm | [[item:243951@DAAAAwbBZbAB]]  <br>[[item:275707]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwbB]] |
| Chest | [[item:243977@BAAAAwbB]] |
| Wrist | [[item:275707]] |
| Belt | [[item:275707]] |
| Legs | [[item:240155@BAAAAwbB]] |
| Boots | [[item:243983@BAAAAwbB]] |
| Ring 1 | [[item:243959@BAAAAwbB]] |
| Ring 2 | [[item:243959@BAAAAwbB]] |
| Weapon | [[item:244031@BAAAAwbB]] |

:::

:::column
:::gear **Holy Paladin** Enchantments
```json
{
  "source_code": "JQFZBBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQwGqmAGA8gOYAAB3jbCYgy94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240155]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243959]] |  |
| 戒指二 | [[item:243959]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> You buy [[item:275707]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.

## Races

For min-maxing a **Holy Paladin** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Removes all magic, bleed, poison, and disease effects and reduces physical damage taken

### Recommendation:

It is highly recommended you play a Dwarf this season! The higher the keys you run, the more essential [[spell:65116]] becomes in certain dungeons.

## Macros

Discover recommended macros for **Holy Paladin** during Mythic+ dungeons and watch a quick video guide on creating simple macros for your character.

**[Macro Import Guide Video](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details Mouseover Macros
All spells in this Holy Paladin Mythic+ Guide are available as mouseover macros for your convenience!

[[spell:20473]]

```wow-macro
#showtooltip
/cast [@mouseover,help,nodead] Holy Shock; [harm] Holy Shock ; Holy shock
```

[[spell:19750]]

```wow-macro
/cast [@mouseover,help,nodead] Flash of Light ; Flash of Light
```

[[spell:82326]]

```wow-macro
/cast [@mouseover,help,nodead] Holy Light ; Holy Light
```

[[spell:85673]]

```wow-macro
/cast [@mouseover,help,nodead] Word of Glory ; Word of Glory
```

[[spell:1022]]

```wow-macro
/cast [@mouseover,help,nodead] Blessing of Protection ; Blessing of Protection
```

[[spell:1044]]

```wow-macro
/cast [@mouseover,help,nodead] Blessing of Freedom ; Blessing of Freedom
```

[[spell:6940]]

```wow-macro
/cast [@mouseover,help,nodead] Blessing of Sacrifice ; Blessing of Sacrifice
```

[[spell:633]]

```wow-macro
/cast [@mouseover,help,nodead] Lay on Hands ; Lay on Hands
```

[[spell:4987]]

```wow-macro
/cast [@mouseover,help,nodead] Cleanse ; Cleanse
```

[[spell:114165]]

```wow-macro
/cast [@mouseover,help,nodead] Holy Prism; [harm] Holy Prism ; Holy Prism
```

[[spell:304971]]

```wow-macro
/cast [@mouseover,help,nodead] Divine Toll; [harm] Divine Toll ; Divine Toll
```

[[spell:391054]]

```wow-macro
/cast [@mouseover,help] Intercession
```

[[spell:7328]]

```wow-macro
/cast [@mouseover,help] Redemption
```

[[spell:53563]] + [[spell:200025]]

```wow-macro
/cast [@mouseover,help,nodead] Beacon of Light ; Beacon of Light
/cast [@mouseover,help,nodead] Beacon of Virtue ; Beacon of Virtue
```

[[spell:156910]]

```wow-macro
/cast [@mouseover,help,nodead] Beacon of Faith ; Beacon of Faith
```

:::

:::details Recommended Macros
With this macro, you never die midcast when trying to use your immunity.

```wow-macro
#showtooltip
/stopcasting
/cast Divine Shield
```

Sometimes you might have to cancel your immunity early.

```wow-macro
/cancelaura Divine Shield
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Holy Paladin**, outlining which addons are used and how they are utilized in Mythic+ Dungeons to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/euiHpal-1024x576.png>)

**Holy Paladin** Mythic+ User Interface

:::accordion
:::details Addons
- **EllesmereUI**-- Full UI Replacement Addon
  
  - The entire ui is made with Ellesmere ui and it controls raidframes, damage meter, nameplates, action bars and cooldown manager. Plus adds a lot of additional small quality of live features and is highly customizeable

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1.0
**PALADIN**

- Golden Path healing increased by 25%.
- Lightforged Blessing healing increased by 25%.
- Brought to Light healing increased by 25%.

- Holy
  
  - All healing increased by 19%.
  - Eternal Flame healing increased by 20%.
  - Word of Glory healing increased by 20%.
  - Holy Shock healing increased by 10%.
  - All damage increased by 20%.
  - Judgment damage increased by 25%.
  - Hammer of Wrath damage increased by 25%.
  - Avenging Crusader now transfers 55% of healing done (was 80%).
  - Pillar of Light's Beacon of Virtue healing increased by 50%.
  - Shield of the Righteous mana return increased by 25%.
  - Unworthy debuff now lasts for 18 seconds (was 15 seconds).
  - Ringing of the Heavens now casts Divine Toll at 200% effectiveness (was 100%).
  - Truth Prevails healing increased by 30%.
  - Saved by the Light absorb increased by 50%.
  - Tirion's Devotion now reduces the cooldown of Lay on Hands by 40% (was 30%).
  - Awakening now activates on a 15% chance (was 10%).
  - Glistening Radiance now absorbs 2% of max health, up to 6% (was 1%, up to 5%).
  - Overflowing Light now transfers 50% of Holy Shock's healing (was 30%).
  - Call of the Righteous now decreases the duration of Avenging Wrath by 3 seconds (was 4 seconds) and decreases the duration of Avenging Crusader by 2 seconds per point (was 2.5 seconds).

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Watch for your health when [[spell:6940]] is up or combine it with [[spell:642]].

:::

:::details Q: Why do I keep running out of mana?
A: You are using [[spell:82326]] too often.

:::

:::

---

### Credits

Written By: **Ftmjgtde**

Reviewed By: **Rycn**

---

:::changelog 更新记录
**2026-08-08** Updated for patch 12.1.0

**2026-06-16** Updated for patch 12.0.7

**2026-04-25** Updated for patch 12.0.5

**2026-02-21** Updated for patch 12.0.1

**2026-01-18** Updated for patch 12.0



:::
