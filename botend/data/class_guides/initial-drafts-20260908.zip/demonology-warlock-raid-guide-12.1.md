欢迎来到《魔兽世界》12.1版本的**恶魔学识 术士** 团队副本攻略！本攻略涵盖了你了解自己角色所需的一切内容！如果你刚起步，正在从80级开始升级？请查看升级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 5/5 · 优秀

范围伤害 · 4/5 · 强力

功能性 · 3/5 · 一般

生存能力 · 4/5 · 强力

机动性 · 3/5 · 一般



:::

:::

:::column
:::gear **恶魔学识 术士** 团队副本 最佳配装
```json
{
  "source_code": "IotAYrQA3_fABIgJEIIOBAw74OwVtOgF2gCAAWzX1cBNYYzf1gVABk-FEAQKBAABtOABtOAj1QWNoAQAcAPTYFQA4SCBCgRAAcRuD4XNBWjgC4UAB0LJEIAKBAQC5Oge1IYN2IzF0gCAOFQAhg6ACiTAAoBwDQQrDY7LMYzt1sZJAMCYwYbNLFQA5SSB1wQBqOQfuUDAE89FF8FRPk7AYYjX1IoAYFQAgg6ACCTAVgEIgBDAjYbNWJytBYEH7SCBAgRAAsXBLyCWBEA3XQgggEAA1jbA4SAZ1EgtcYjMOFQAeqmAZgBF2IjX1YbNFsLBU9RBAVBKEQYLFARAiUAIY09FEAACBAQBISA9iUwmI0TuDEwLAgRINgTpXQAAYEAA2IjX1IoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271874]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240900]] · [[item:240900]] |
| 肩部 | [[item:271544]] | [[item:243991]] |
| 胸部 | [[item:271549]] | [[item:243977]] |
| 腰部 | [[item:239649]] | [[item:240900]] · [[item:245786]] |
| 腿部 | [[item:271545]] | [[item:240133]] |
| 脚部 | [[item:268255]] | [[item:243983]] |
| 腕部 | [[item:239648]] | [[item:240900]] · [[item:245786]] |
| 手部 | [[item:271547]] |  |
| 戒指一 | [[item:268252]] | [[item:240900]] · [[item:243957]] |
| 戒指二 | [[item:158366]] | [[item:240900]] · [[item:243957]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:273796]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:271092]] | [[item:244029]] |
| 副手 | [[item:268197]] |  |
:::

:::

:::

## 至暗之夜 改动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**恶魔学识 术士**，你可以使用[[spell:1276163]]，它实质上是[[spell:267217]]的新版本。在施放[[talent:125850]]后的15秒内，你要尽可能多地施放[[talent:125834]]。

**2级**会延长你通过[[spell:1276163]]召唤出的恶魔的持续时间。而**3级**则使每次[[talent:125834]]返还1点[[spell:104756]]，让你在这15秒的窗口期内可以施放更多次。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-demoonology-mxr.webp>)

阿古斯支配

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:125836]]
    
    - 改为拥有15秒冷却时间，并且上限为6层[[spell:104317]]。
  
  
  
  - [[talent:125863]]
    
    - [[spell:453568]]产生的随机末日守卫被替换为一个2分钟冷却的技能。
  - [[talent:136725]] / [[talent:136726]] 
    
    - [[spell:111898]]的替代冷却技能，这使你可以额外使用一次[[spell:19647]] / [[spell:89808]]。
- **职业天赋树**
  
  - [[talent:136100]]
    
    - 绝佳天赋，可同时将[[spell:702]]、[[spell:334275]]或[[spell:1714]]施放到一群敌人身上。
  
  
  
  - [[talent:136101]]
    
    - 更多的[[talent:91466]]机动性！
  - [[talent:136108]] / [[talent:136738]]
    
    - 强力的新范围伤害诅咒，可降低多个敌人的攻击速度或施法速度。
  - [[talent:136104]]
    
    - [[spell:40671]]的直接替代。
- **已移除**
  
  - [[spell:215941]]
    
    - 这导致可用的[[spell:246985]]减少，你的[[spell:246985]]获取也更加稳定（随机性降低）。
  - [[spell:264057]]
    
    - 略微降低你的[[spell:246985]]生成速度。
  - [[spell:267211]] / [[spell:267171]]
    
    - 对按需范围伤害爆发是相当程度的削弱。

## 英雄天赋

- [[talent:123385]]和[[talent:123383]]的伤害曲线非常相似。使用[[talent:123385]]时，你通过[[spell:265187]]造成的爆发伤害会大幅增强，而[[talent:123383]]则强化[[talent:125836]]和范围伤害伤害。
- 目前[[talent:123385]]在几乎所有场景下表现都略胜一筹。



### [[talent:123385]]

- 消耗一个 [[spell:246985]] 会启动 3 种不同 [[spell:428514@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] 之一的循环。
  
  1. [[spell:431944@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]
  2. [[spell:432815@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]
  3. [[spell:432816@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]
  4. 重新从第 1 步开始。

- 同一时间只能存在 1 个 [[spell:428514@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]，每个到期后会转化为对应的 **恶魔艺术** ，该转化在你施放下一个 [[spell:246985]] 后触发：
  
  - [[spell:428524]]
    
    - 一个 邪能领主 跃向你的目标并施加 [[spell:434424]]，持续15秒。
  - [[spell:432794]]
    
    - 对目标造成伤害，并将你的下一个 [[spell:686]] 变为 [[spell:434506]]，产生 3 层 [[spell:246985]]。
  - [[spell:432795]]
    
    - 召唤一个深渊领主用 [[spell:434404]] 攻击你的目标，并将你的下一个 [[spell:105174]] 变为 [[spell:434635]]，后者会以 0 消耗 [[spell:104756]] 的代价召唤 3 个 [[spell:104317]]。
- 有了 [[spell:429581@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] 之后，你的 [[spell:265187]] 窗口期变得重要得多。
- [[talent:136092]]
  
  - 在消耗 [[spell:428524]]、[[spell:432794]] 或 [[spell:432795]] 时造成被动的 范围伤害 伤害。
- [[talent:136091]]
  
  - 在消耗 [[spell:428524]]、[[spell:432794]] 或 [[spell:432795]] 时造成额外的单体伤害。
- [[talent:136090]]
  
  - 每当你消耗 [[spell:428524]]、[[spell:432794]] 或 [[spell:432795]] 时，每消耗一个 [[talent:136092]] 就获得 2% 智力，持续 10 秒，最多叠加至 6%。




### [[talent:123383]]

- [[spell:449793]]会强化你的[[spell:105174]]，并使其施加[[talent:117444]]。
  
  - [[spell:449793]]
    
    - 每当你产生一个[[spell:104756]]时，都有几率给予你一个[[spell:449793]]。
    - [[spell:265187]]赋予你3层[[spell:104756]]和3层[[spell:449793]]。
  - [[talent:117444]]
    
    - [[spell:105174]]会对所有被命中的目标施加[[talent:117444]]。
    - 消耗一个[[spell:267102]]会对你的当前目标施加[[talent:117444]]。
  - [[talent:117420]]
    
    - 当你消耗一个[[spell:267102]]时，你的目标会受到[[talent:117420]]的折磨。
    - 在范围伤害场景中，切记不要对距离过远、无法从[[talent:117420]]的范围伤害伤害中受益的目标施放[[spell:264178]]。
  - [[talent:117435]]
    
    - 结合[[talent:125834]]，你现在每个[[spell:104317]]有15%的几率在施放[[talent:125836]]后获得[[spell:267102]]。
    - 确保在施放[[talent:125836]]之前，你的[[spell:267102]]层数处于较低水平。
  - [[talent:136098]]
    
    - 每消耗一个[[spell:449793]]，释放你内在[[spell:449614]]的几率都会提高，使其能够以[[spell:1269049]]攻击敌人。
  - [[talent:136097]]
    
    - 使你的精通提高4%。
    - 当恶魔实体在战斗中协助你时，此效果翻倍。
  - [[talent:136096]]
    
    - 使[[talent:136098]]的持续时间延长5秒，并使[[spell:1269049]]的伤害提高10%。





## 天赋



### [[talent:123386]] 团队副本 配装

:::talents [[talent:123386]] **恶魔学识 术士** 团本天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 何时使用该专精

如果是纯单体场景，请使用这套专精。

#### 改变游戏玩法的天赋

探索专精天赋树和职业天赋树中所有会显著改变你玩法的天赋。本节对这些天赋及其应用进行了简要概述，若想了解更多细节，请查看下方的循环和 **深入解析** 部分。

##### 专精树

- [[spell:104316]]
  
  - 你的核心技能之一，可通过众多天赋得到强化。
  
  
  
  - [[spell:205145]] 使你可以免费且无施法时间地施放 [[spell:104316]]。
  - [[talent:135314]] 会随你的 [[spell:104316]] 一同出现，因此让 [[spell:104316]] 保持冷却即用更加重要。
- [[spell:264130]]
  
  - 显著提升你的 [[spell:267102]] 获取量。
  - 使用前请确保身上有 2 层以上的 [[spell:279910]]。
- [[spell:265187]]
  
  - **恶魔学识** 的主要冷却技能，与该专精的大多数法术均有协同。
- [[talent:136725]] / [[talent:136726]]
  
  - 强力的 2 分钟冷却技能，是你伤害的重要组成部分，务必与 [[spell:265187]] 搭配使用。
- [[talent:125863]]
  
  - 另一个 2 分钟冷却技能，它不受 [[spell:265187]] 的增益影响，因此可以更自由地使用。
-

##### 职业树

- [[talent:91439]]
  
  - 用于快速复活宠物——无论是当前宠物死亡还是你被复活时。可跳过 [[spell:246985]] 的消耗，并大幅缩短召唤宠物的施法时间。
- [[talent:91460]]
  
  - 可开关的移动速度提升技能，使用时每秒消耗生命值。
- [[talent:91452]]
  
  - 短冷却的快速自我治疗，可被 [[talent:136105]] 进一步强化。
- [[talent:91444]]
  
  - 以消耗生命值为代价为你提供一个大型吸收护盾，生命值消耗可被 [[talent:91446]] 降低。你也可以将 [[talent:91446]] 换成 [[talent:91445]]，以获得更多 [[talent:91444]] 的潜在使用机会。
- [[talent:91466]]
  
  - 使你每 90 秒可以移动更远的距离。如果点出了 [[talent:136101]] 天赋，则可以使用两次。
- [[talent:91469]]
  
  - 强化多个实用技能，主要与 [[spell:48020]]、[[spell:6262]]、[[spell:111771]] 和 [[spell:234153]] 配合使用。
- [[talent:91434]]
  
  - 对生存能力至关重要，因为它使你的 [[spell:452930]] 在单次战斗中可以使用多次。





## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2 件套：** [[spell:104317]] 伤害提高 10%。[[spell:196277]] 伤害提高 20%。
- **4 件套：** 当能量耗尽时，[[spell:104317]] 有 20% 的几率扑向其目标，对主要目标以 250% 效果施放 [[spell:196277]]，对其他目标以 225% 效果施放。

### 单体目标



#### [[talent:123385]]

##### 起手爆发

> [[spell:89751]] 被默认设置为自动施放，因此不包含在任何起手与优先级列表中。

- 你的开场的目的是用 [[spell:265187]] 来强化并延长 [[spell:104316]] 和 [[talent:136726]]。
- 当你使用[[talent:125836]]且没有[[spell:267102]]时，你可以改为预施放[[spell:264178]]。

:::rotation [[talent:123385]] **恶魔学识 术士** 在团队副本  中的单体起手
```json
{
  "source_code": "I0CsGIgrCAACQJXZtMWYzRHAC4qAAAAACRieTAAAAAgA8dZAAAgAjvABAAgQWrZA"
}
```
1. [[spell:686]] 预读
2. [[spell:686]]
3. [[spell:1276452]]
4. [[spell:104316]]
5. [[spell:265187]]
6. [[spell:105174]]
:::

- 将你的主动饰品 [[item:241308]] 以及种族技能如 [[spell:20572]] 或 [[spell:26297]] 与 [[spell:265187]] 配合使用。
- 如果点了 [[talent:136731]] 天赋
  
  - 最好在开战前 8-10 秒预先施放 [[talent:136731]]，但务必确保事先拥有 2 层 [[spell:104317]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在 [[spell:265187]] 之前施放 [[spell:104316]] 和 [[talent:136726]]。
2. 在冷却完毕时施放 [[spell:104316]]。
3. 在冷却完毕时施放 [[talent:125863]]。
4. 如果已点出天赋，当你拥有2层以上[[spell:104317]]且[[spell:267102]]不超过2层时施放[[talent:136731]]。
5. 如果已点出天赋，当你拥有6层[[spell:104317]]时，在冷却结束即施放[[talent:125836]]。
6. 如果你即将超出 [[spell:104756]] 的上限，则施放 [[spell:105174]] / [[spell:434635]]。
7. 如果你的 [[spell:104756]] 低于 3 且 [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] 可用时，施放 [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]。
8. 如果你有 2 层以上的 [[spell:267102]]，施放 [[spell:264178]]。
9. 在拥有 3 层 [[spell:104756]] 时施放 [[spell:105174]]。
10. 施放 [[spell:686]] 以生成 [[spell:104756]]。




#### [[talent:123383]]

##### 起手爆发

> [[spell:89751]] 被默认设置为自动施放，因此不包含在任何起手与优先级列表中。

- 你的开场的目的是用 [[spell:265187]] 来强化并延长 [[spell:104316]] 和 [[talent:136726]]。
- 当你使用[[talent:125836]]且没有[[spell:267102]]时，你可以改为预施放[[spell:264178]]。

:::rotation [[talent:123383]] **恶魔学识 术士** 在团队副本  中的单体起手
```json
{
  "source_code": "I8CuGIgrCAACQJXZtMWYzRHACRieTAAAAAgA8dZAAAgAjvABAAgQWrZAAAAAAIk1aGA"
}
```
1. [[spell:686]] 预先施放
2. [[spell:1276452]]
3. [[spell:104316]]
4. [[spell:265187]]
5. [[spell:105174]]
6. [[spell:105174]]
:::

- 将你的主动饰品 [[item:241308]] 以及种族技能如 [[spell:20572]] 或 [[spell:26297]] 与 [[spell:265187]] 配合使用。
- 如果点了 [[talent:136731]] 天赋
  
  - 最好在开战前 8-10 秒预先施放 [[talent:136731]]，但务必确保事先拥有 2 层 [[spell:104317]]。

##### 优先级列表

这是你在整场战斗中力求维持的一般优先级。

1. 在 [[spell:265187]] 之前施放 [[spell:104316]] 和 [[talent:136726]]。
2. 在冷却完毕时施放 [[spell:104316]]。
3. 在冷却完毕时施放 [[talent:125863]]。
4. 如果已点出天赋，当你拥有2层以上[[spell:104317]]且[[spell:267102]]不超过2层时施放[[talent:136731]]。
5. 如果已点出天赋，当你拥有6层[[spell:104317]]时，在冷却结束即施放[[talent:125836]]。
6. 如果你即将超出 [[spell:105174]] 上限时施放 [[spell:104756]]。
7. 如果你有 2 层以上的 [[spell:267102]]，施放 [[spell:264178]]。
8. 在拥有 3 层 [[spell:104756]] 时施放 [[spell:105174]]。
9. 施放 [[spell:686]] 以生成 [[spell:104756]]。





### 范围伤害



#### [[talent:123385]]

##### 起手爆发

- 你的开场的目的是用 [[spell:265187]] 来强化并延长 [[spell:104316]] 和 [[talent:136726]]。
- 当你使用[[talent:125836]]且没有[[spell:267102]]时，你可以改为预施放[[spell:264178]]。

:::rotation [[talent:123385]] **恶魔学识 术士** 在团队副本中的范围伤害开局
```json
{
  "source_code": "I0CsGIgrCAACQJXZtMWYzRHAC4qAAAAACRieTAAAAAgA8dZAAAgAjvABAAgQWrZA"
}
```
1. [[spell:686]] 预读
2. [[spell:686]]
3. [[spell:1276452]]
4. [[spell:104316]]
5. [[spell:265187]]
6. [[spell:105174]]
:::

- 将你的主动饰品 [[item:241308]] 以及 [[spell:20572]] 或 [[spell:26297]] 等种族技能与 [[spell:265187]] 配合使用。

##### 优先级列表

1. 在 [[spell:265187]] 之前施放 [[spell:104316]] 和 [[talent:136726]]。
2. 在冷却完毕时施放 [[spell:104316]]。
3. 如果已点出天赋，当你拥有6层[[spell:104317]]时，在冷却结束即施放[[talent:125836]]。
4. 如果你即将超出 [[spell:104756]] 的上限，则施放 [[spell:105174]] / [[spell:434635]]。
5. 如果你的 [[spell:104756]] 低于 3 且 [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]] 可用时，施放 [[spell:433891@FJwBj2SAUdhALunADm4A_rRBg0wBh0wBJEA]]。
6. 如果你有 2 层以上的 [[spell:267102]]，施放 [[spell:264178]]。
7. 在4个及以上目标身上施放[[spell:196277]]，且拥有6层及以上[[spell:104317]]。
8. 当你拥有2层或更少的[[spell:267102]]层数时施放[[spell:264130]]。
9. 在拥有 3 层 [[spell:104756]] 时施放 [[spell:105174]]。
10. 施放 [[spell:686]] 以生成 [[spell:104756]]。




#### [[talent:123383]]

##### 起手爆发

- 你的开场的目的是用 [[spell:265187]] 来强化并延长 [[spell:104316]] 和 [[talent:136726]]。
- 当你使用[[talent:125836]]且没有[[spell:267102]]时，你可以改为预施放[[spell:264178]]。

:::rotation [[talent:123383]] **恶魔学识 术士** 范围伤害 起手式 在 团队副本
```json
{
  "source_code": "I8CuGIgrCAACQJXZtMWYzRHACRieTAAAAAgA8dZAAAgAjvABAAgQWrZAAAAAAIk1aGA"
}
```
1. [[spell:686]] 预先施放
2. [[spell:1276452]]
3. [[spell:104316]]
4. [[spell:265187]]
5. [[spell:105174]]
6. [[spell:105174]]
:::

- 将你的主动饰品 [[item:241308]] 以及 [[spell:20572]] 或 [[spell:26297]] 等种族技能与 [[spell:265187]] 配合使用。

##### 优先级列表

1. 在 [[spell:265187]] 之前施放 [[spell:104316]] 和 [[talent:136726]]。
2. 在冷却完毕时施放 [[spell:104316]]。
3. 如果已点出天赋，当你拥有6层[[spell:104317]]时，在冷却结束即施放[[talent:125836]]。
4. 如果你即将超出 [[spell:105174]] 上限时施放 [[spell:104756]]。
5. 如果你有 2 层以上的 [[spell:267102]]，施放 [[spell:264178]]。
6. 在有4个或更多目标且6层或更多[[spell:104317]]时施放[[spell:196277]]。
7. 当你只有2层或更少[[spell:267102]]层数时施放[[spell:264130]]。
8. 在拥有 3 层 [[spell:104756]] 时施放 [[spell:105174]]。
9. 施放 [[spell:686]] 以生成 [[spell:104756]]。





## 深度解析

### 内爆 循环

[[talent:125836]]是一个独特的法术，因此可能会让人感到困惑。以下是一些提示和技巧：

- 为获得最大伤害，务必在拥有 6 层 ‍[[spell:104317]] 时使用 [[talent:125836]]。

#### 执行

为了实现理想的 [[spell:196277]] 循环，请确保你至少有 2 层 [[spell:267102]]。在施放最后一个 [[spell:105174]] 后，等待 [[spell:104317]] 出现，或用一个填充技能占用一个公共冷却，然后再施放 [[spell:196277]]。

:::rotation **恶魔学识 术士** 团队副本 内爆循环
```json
{
  "source_code": "IQEmGIANZGAFTRXYyRHI3lGdoBCNrAyUoFmckNHACYtmBAAACI_BEAAAdwARAKgAuKAAAAgA16vAAAgA16vA"
}
```
1. [[spell:104756]] 以 4+ 灵魂碎片开局
2. [[spell:105174]]
3. [[spell:264178]]
4. [[spell:105174]]
5. [[spell:264178]]  
   
   1. [[spell:686]]
   2. [[spell:196277]]
6. [[spell:196277]]
:::

### 末日降临 的极限优化

当 [[talent:136729]] 到期时，会对目标及其 10 码范围内的所有敌人造成大量伤害。

- 单体
  
  - 为了确保 [[talent:136729]] 的覆盖率最大化，最好在手中保留至少 1 层 [[spell:264173]]，以避免 [[talent:136729]] 出现空档期。
  - 在此过程中，注意不要让 [[spell:264173]] 溢出，因为其最大充能层数为 4 层。
- 多目标
  
  - 在面对多个目标时，优先将 [[talent:136729]] 施放到不同目标上以制造更多爆炸。在大规模拉怪时，在每次 [[spell:264178]] 之间切换目标循环。

### 召唤恶魔暴君 机制

你的 [[talent:125850]] 是一只所谓的 **守护** 宠物，它与你名为 [[spell:30146]] 的主要宠物（战斗宠物）的工作方式略有不同。[[talent:125850]] 会以你的 [[spell:30146]] 所选定的目标为目标。

#### 守护 宠物属性更新

[[talent:125850]] 与许多其他 **守护者** 一样，会随 急速 等属性提升而动态更新，但有时更新速度非常缓慢。

:::timeline
```json
{
  "source_code": "HcCmuj4hIAgAB8PzAQAAIAgACN-CEAAABAgQhnTAAAgAAEgQt2aAAAAB"
}
```
总时长：8 秒

| 时间 | 动作 | 轨道 |
| --- | --- | --- |
| 1 秒 | [[spell:265187]] | 上轨 |
| 2 秒 | [[spell:80353]] | 上轨 |
| 4 秒 | [[spell:109997]] | 下轨 |
:::

[[spell:80353]] 在 0:02 施放，但你的 [[talent:125850]] 直到 0:04 才更新其 急速。所有属性和伤害提升都存在同样的问题。

**这只是一个机制不一致的例子，并非在所有情况下都准确！**

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**



### 内克扎莉

:::talents **恶魔学识 术士** 内克扎莉 团本天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 进入该阶段时，确保 [[spell:1271802]] 或 [[spell:1714]] 已在打断小怪身上生效。




### 陵寝哨兵

:::talents **恶魔学识 术士** 陵寝哨兵 团本天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 放置得当的 [[spell:48018]] 可以让你在首领之间快速移动。




### 迷失的探险者们

:::talents **恶魔学识 术士** 迷失的探险者在团本中的天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 将你的 [[spell:48018]] 放置在靠近中心的位置，这样你就可以选择传送到火焰圈上，而不必使用蘑菇。




### 瓦什尼克

:::talents **恶魔学识 术士** 瓦什尼克在团本中的天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 你可以在小怪刷新时保留 [[talent:125836]]，以便快速将其爆发击杀。
- 提前放置好你的 [[spell:111771]] 和 [[spell:48018]]，以便在各处小怪刷新点之间快速移动。




### 斯索拉克

:::talents **恶魔学识 术士** 斯索拉克 团本天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixYsMLzMzYGAYmxMzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 将 [[spell:48018]] 放在房间中部附近，以便在转阶段时保护自己免受击退和风的影响。




### 双牙

:::talents **恶魔学识 术士** 双蛇之牙在团本中的天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 务必及时切换目标并命令宠物攻击刷新的小怪，快速击杀它们，以减少你的团队所获得的层数。




### 盘绕祭坛

:::talents **恶魔学识 术士** 盘绕祭坛在团本中的天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZZmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 务必确保 [[talent:136726]] 和 [[talent:125850]] 已就绪，以应对阶段转换期间的伤害增幅。




### 乌拉特克

:::talents **恶魔学识 术士** 乌拉特克 团本天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 预先将你的[[spell:48018]]放置在近战范围附近，以便能够传送过去躲避波次。




### 尼姆瑞莎·唤波者

:::talents **恶魔学识 术士** 尼姆瑞莎·唤波者 团本天赋
```json
{
  "source_code": "CqQAUgGY_myp-zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG",
  "code": "CqQAUgGY/myp+zpUCockSq2z5zMzMzMNLMMzMmtBAAAAAAYsYGzYYBGmZb2ajmxixMjlZbmZGzAAzMGzMzMYmhZMzAAAMmZmZGGWmxAG"
}
```
:::

#### 首领攻略技巧

- 在阶段转换的安全区域放置一个[[spell:111771]]，这样你的团队就可以抵消首领的击退效果。





## 属性优先级

了解你的次要属性优先级，以及作为**恶魔学识 术士**在 团队副本 首领战斗中达到最佳表现所需的第三属性。欲了解更多详细信息，请访问 **[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)** 攻略。

:::priority **恶魔学识 术士** 在 团队副本 中的属性优先级
```json
{
  "source_code": "HoAJFUAJgEDKBEgABA"
}
```
**智力 ＞ 急速 ＞ 暴击 ＝ 精通 ＞ 全能**
:::

:::callout 在大多数情况下，装备等级更高的物品更好
要准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！

静态的“**属性优先级**”只是一个起点，并且很容易随着你当前的装备而发生变化。

:::

- 所有次要属性都会受到**收益递减**的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)**了解更多！

### 第三属性

- **闪避** - 一个极佳的属性，可以降低“**范围伤害**”技能所受到的伤害。
- **吸血** - 通过造成伤害提供额外的治疗。你的宠物造成的伤害不会为你回血，因此**吸血**对你来说是一个很差的第三属性，因为你的大部分伤害来自宠物。
- **加速** - 一个小众的第三属性，但可能非常有用，过去已被证明其实用性。能让某些机制的处理变得轻松许多。

## 装备



### 最佳配装

| 部位 | 物品 | 获取途径 |
| --- | --- | --- |
| 头部 | [[item:271874@DiTAAoQAvj7cVrjF2gCAAWzX1cBNYYzf1gVA]] | 乌拉特克 |
| 颈部 | [[item:268265@BkSAAoQAE06QQrDj1QWNoAwF0ghNYFA]] | 乌拉特克 |
| 肩部 | [[item:271544@DgRAAoQAXk74XNBWjgC4UA]] | 套装 |
| 披风 | [[item:268253@BgQAAoQACKAWBA]] | 盘卷祭坛 |
| 胸部 | [[item:271549@DgSAAoQAJk7oXNCWjNycBNoAgTB]] | 套装 |
| 护腕 | [[item:239648@BCTAAoQAE06Y7LgBDAjYbNWJyt1sUA]] | 制造 |
| 手套 | 将 [[item:268243@AgQAAIoAYFA]]  <br>转化为 [[item:271547@BgRAAoQA7VTg1IoAYFA]] | 盘卷祭坛的催化体 |
| 腰带 | [[item:239649@DiTAAoQAaA8QQrjtvwgN3WzmlAwIgBjt1sUA]] | 制造 |
| 腿部 | [[item:271545@DgSAAoQAFo60XNCWjNycBNoAgTB]] | 套装 |
| 战靴 | [[item:268255@DgRAAoQAPk7ghNeVjgCgVA]] | 盘卷祭坛 |
| 戒指 1 | [[item:268252@DCSAAoQA1j7QQrDZ1gCAXQjNy4UA]] | 斯索拉克 |
| 戒指 2 | [[item:158366@DCSAAoQA1j7QQrjNy4VN2WjgC4UA]] | 塞塔里斯神庙 |
| 饰品 1 | [[item:270164@BgRAAoQAoAwF0YjMOFA]] | 迷失的探险者 |
| 饰品 2 | [[item:273796@BgRAAoQA2IjX1IoAOFA]] | 毒牙祭坛 |
| 武器 | [[item:271092@DgRAAoQA9k7gCAXQDG2gVA]] | 乌拉特克 |
| 副手 | [[item:268197@BgRAAoQA2IjX1IoAOFA]] | 陵寝哨兵 |




### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:251199@AgQAAIoABFA]] | 夺目谷 |
| 颈部 | [[item:273781@AgQAAIoABFA]] | 毒牙祭坛 |
| 肩部 | [[item:239031@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 披风 | [[item:251132@AgQAAIoABFA]] | 密谋小径 |
| 胸部 | [[item:251139@AgQAAIoABFA]] | 密谋小径 |
| 护腕 | [[item:251127@AgQAAIoABFA]] | 密谋小径 |
| 手套 | [[item:159247@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 腰带 | [[item:251222@AgQAAIoABFA]] | 虚空之痕竞技场 |
| 腿部 | [[item:251160@AgQAAIoABFA]] | 纳洛拉克的洞穴 |
| 脚部 | [[item:159259@AgQAAIoABFA]] | 塞塔里斯神庙 |
| 戒指 1 | [[item:251136@AgQAAIoABFA]] | 密谋小径 |
| 戒指 2 | [[item:273792@AgQAAIoABFA]] | 毒牙祭坛 |
| 饰品 1 | [[item:273649@AgQAAIoABFA]] | 诸王之眠 |
| 饰品 2 | [[item:273794@AgQAAIoABFA]] | 毒牙祭坛 |
| 武器 | [[item:251123@AgQAAIoABFA]] | 密谋小径 |





### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:273796@BgQAAkQACKgTBA]]  <br>[[item:270164@BgQAAkQACKgTBA]]  <br>[[item:273649@BgQAAkQACKgTBA]]  <br>[[item:250215@BgQAAkQACKgTBA]] |
| **A级** | [[item:270167@BgQAAkQACKgTBA]]  <br>[[item:270168@BgQAAkQACKAWBA]]  <br>[[item:270169@BgQAAkQACKAWBA]] |
| **B级** | [[item:273794@BgQAAkQACKgTBA]]  <br>[[item:270170@BgQAAkQACKgTBA]]  <br>[[item:270161@BgQAAkQACKgTBA]] |
| **C级** | [[item:250259@BgQAAkQACKgTBA]]  <br>[[item:250214@BgQAAkQACKgTBA]]  <br>[[item:250224@BgQAAkQACKgTBA]]  <br>[[item:158368@BgQAAkQACKgTBA]]  <br>[[item:193757@BgQAAkQACKgTBA]] |
| **垃圾级** | [[item:251787@BAQAAsQATEA]]  <br>[[item:251792@BAQAAsQATEA]]  <br>[[item:251785@BAQAAsQATEA]]  <br>[[item:251784@BAQAAsQATEA]] |

### 美化饰品

- 2个 [[item:240166]]
  
  - 触发后提高你的主属性，同时还会为一名队友提供小幅增益。

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备在最高物品等级下为334-344，因此除非你在该部位没有其他高物品等级装备可用，否则除了2件美化装备之外装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **合剂**
  
  - [[item:241326]]
- **食物**
  
  - [[item:255846]]
- **战斗药水**
  
  - [[item:241288]]
- **治疗药水**
  
  - [[item:271884]] -- 一波大量的治疗
- 武器油
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240900]]
  
  
  
  - [[item:240983]] *-- 唯一*

### 附魔

:::columns
:::column
| 头部 | [[item:244007@DAAAAoQAZbAB]]  <br>[[item:275707]] |
| --- | --- |
| 肩部 | [[item:243991@BAAAAoQA]] |
| 胸部 | [[item:243977@BAAAAoQA]] |
| 腕部 | [[item:275707]] |
| 腰部 | [[item:275707]] |
| 腿部 | [[item:240133@BAAAAoQA]] |
| 脚部 | [[item:243953@BAAAAoQA]] |
| 戒指 1 | [[item:243957@BAAAAoQA]] |
| 戒指 2 | [[item:243957@BAAAAoQA]] |
| 武器 | [[item:244029@BAAAAoQA]] |

:::

:::column
:::gear **恶魔学识 术士** 团队副本 中的附魔
```json
{
  "source_code": "IQFZKEQ9NCQA7TDBCAAAA8OuDEwF5OAAAAAABkQDIgw-0QQBQQQBqmAGEEPuJgQEYAQ9NABK1j7AAAAAAEQP5OA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:243991]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:240133]] |  |
| 脚部 | [[item:243953]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *你需要从宏伟宝库商人处购买 [[item:275707]] 来为你的 **头部**、**腕部** & **腰部** 添加宝石插槽。*

## 种族

若要对**恶魔学识 术士** 进行副本团本的极限优化，不同的种族天赋可以为你的角色带来巨大的收益。如果这并非你的首要目标，选择一个符合你风格的种族同样可行。

- [[spell:65116]] -- 矮人
  
  - 驱散魔法和流血负面效果。过去在一些有流血机制的首领战中非常有用。
- [[spell:69070]] -- 地精
  
  - 朝角色面向的方向进行一次小跳跃。
  - 在你处于[[spell:69070]]动画期间，你会被置入公共冷却，直到角色落地。
- [[spell:26297]] *-- 巨魔* 
  
  - 强大的输出种族技能，但与[[spell:265187]]的配合较差。
  - 使移动限制效果的持续时间缩短20%。在近期的开荒团队副本历史中只派上过一次用场，但仍值得一提。
- [[spell:33702]] *-- 兽人* 
  
  - 凭借[[spell:21563]]和[[spell:33702]]两者，这是一个非常强力的伤害向种族技能，并且与[[spell:265187]]相契合。
  - 你受到的昏迷持续时间缩短20%，在某些情况下会很有用。
- [[spell:256948]] -- 虚空精灵
  
  - 放出一道朝你面向方向飞行的暗影，再次激活即可传送到其位置。
  - 最大距离为100码。

### 推荐

总的来说，可以肯定的是：如果你追求输出最大化，就应该选择输出最高的种族天赋。不过，如果是开荒团本，情况就有所不同了。有些种族天赋能极大加快特定首领的进度。值得注意的是，矮人凭借其 [[spell:65116]]，在最近的世界首杀竞速中，由于能在 **丁达尔·迅贤** 和 **火光之龙菲莱克** 的战斗关键节点轻松自我驱散，提供了巨大帮助。

## 宏

探索**恶魔学识 术士** 在团队副本 战斗中的推荐宏，并观看一段关于为你的角色创建简单宏的简短视频攻略。

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:30283]]** -- *在鼠标光标位置施放[[spell:30283]]，无需确认。*

```wow-macro
#showtooltip
/cast [@cursor] 暗影之怒
```

:::

:::details 鼠标指向宏
**[[spell:702]]** -- *在对你的鼠标指向目标或当前目标施放 [[spell:702]] 之前先使用 [[spell:328774]]。*

```wow-macro
#showtooltip 虚弱诅咒
/cast [@mouseover, exists, harm, nodead] 虚弱诅咒; 虚弱诅咒
```

**[[spell:1714]]** -- *在对你的鼠标指向目标或当前目标施放 [[spell:1714]] 之前先使用 [[spell:328774]]。.*

```wow-macro
#showtooltip 语言诅咒
/cast [@mouseover, exists, harm, nodead] 语言诅咒; 语言诅咒
```

**[[spell:334275]]** -- *在对你的鼠标指向目标或当前目标施放 [[spell:29539]] 之前先使用 [[spell:328774]]。*

```wow-macro
#showtooltip 疲劳诅咒
/cast [@mouseover, exists, harm, nodead] 疲劳诅咒;[@target] 疲劳诅咒
```

**[[spell:710]]** -- *若鼠标指向目标存在，则对其施放 [[spell:710]]。*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead,exists] 放逐术; [harm,nodead] 放逐术
```

**[[spell:5782]]** -- *对鼠标指向目标施放[[spell:5782]]（如果存在）。*

```wow-macro
#showtooltip
/cast [@mouseover,exists]恐惧;恐惧
```

**[[spell:20707]]** 鼠标指向 -- *对鼠标指向目标施放[[spell:20707]]。传统的 [@mouseover,exists] 宏在之前的一段时间里已经失效，这是针对该问题的一个替代方案。*

```wow-macro
#showtooltip 灵魂石 
/target [@mouseover,help] 
/cast 灵魂石 
/targetlasttarget
```

:::

:::details 宠物宏
> 我们主要为宠物使用自定义宏，因为过去 [[spell:119898]] 的常规功能被证明并不可靠。

**宠物技能1宏** -- *施放你的主宠物技能，对每个宠物均作用于*你鼠标指向的目标。

```wow-macro
/cast [@mouseover]烧灼驱魔
/cast [@mouseover,exists]法术封锁;法术封锁
/cast [@mouseover]受难
/cast [@mouseover,exists]魅惑;魅惑
/cast [@mouseover,exists]利斧投掷;利斧投掷
/cast [nopet,@mouseover,exists]恶魔掌控;[nopet]恶魔掌控
```

**焦点目标宠物技能** **1 宏** -- *为你的每只宠物对其焦点目标施放主要宠物技能。*

```wow-macro
/cast [@focus] 烧灼驱魔
/cast [@focus] 法术封锁
/cast [@focus] 受难
/cast [@focus] 魅惑
/cast [@focus] 利斧投掷
/cast [nopet,@focus] 恶魔掌控
```

**宠物技能** **2 宏** *-- 在需要时对你的鼠标指向目标施放第二个相关宠物技能。*

```wow-macro
/cast [@mouseover] 烧灼驱魔
/cast [@mouseover,exists] 吞噬魔法;吞噬魔法
/cast 暗影壁垒
/cast 魔刃风暴 
/cast [nopet,@mouseover] 恶魔掌控
```

**焦点宠物 技能** **2 宏** -- *对焦点目标施放第二个相关宠物技能，同时命令你的宠物攻击焦点目标。*

```wow-macro
/cast [@focus]烧灼驱魔;
/cast [@focus] 吞噬魔法;
/cast [@focus] 次级隐形术;
/cast 暗影壁垒;
/cast [nopet,@focus] 恶魔掌控
/petattack [@focus]
```

:::

:::details 实用 宏
**[[spell:5697]]** 自我施法 *-- 在不选定任何目标的情况下对自己施放[[spell:5697]]。当你暂时无法对任何目标进行输出时，依然可以用它来刷取饰品的触发/层数，非常实用。*

```wow-macro
#showtooltip
/cast [@player] 无尽呼吸
```

**[[talent:91457]] / [[spell:5484]]** 选择 *-- 根据所选天赋的不同，在 [[talent:91457]]* *和 [[spell:5484]] 之间切换。你可以方便地添加自己的宏条件，例如 @focus 或 @mouseover 等。*

```wow-macro
/cast [known:暗影之怒] 暗影之怒
/cast [known:恐惧嚎叫] 恐惧嚎叫
```

**全能合一 药水 --** *所有不同种类的伤害[[item:212265]]*，*如果你已死亡则使用[[item:212256]]**。*

```wow-macro
/use [@player,nodead] item:212971
/use [@player,nodead] item:212265
/use [@player,nodead] item:212970
/use [@player,nodead] item:212264
/use [@player,nodead] item:212969
/use [@player,nodead] item:212263
/use [@player,dead]怪诞之瓶
```

:::

:::

## 插件

下方是作者的 **恶魔学识 术士** 用户界面截图，其中说明了使用了哪些插件，以及它们在团队副本中如何为你提供便利。

![](<https://assets-ng.maxroll.gg/wordpress/DemomidnightraidUI-ezgif.com-png-to-webp-converter-2-1024x682.webp>)

**恶魔学识 术士** 团队副本界面

:::accordion
:::details 插件
- **MRT** -- 记事标记、团队副本冷却监控等功能
  
  - 对团队副本玩家非常有用的插件，尤其适合团队副本团长和官员。
- **ElvUI** *-- 整体用户界面替换* 
  
  - 一款以易用性为核心设计的用户界面，附带许多标准界面没有的额外功能。
  - 另外，你也可以使用 Shadowed Unit Frames (SUF) 加上任意一款动作条插件，当然也可以使用原生界面。
- **BigWigs** *-- 通用首领模块*  
  
  - BigWigs 是一款首领战插件。它由许多独立的战斗脚本（即首领模块）组成，这些小型插件旨在为某个特定的团队副本战斗触发警报信息、计时条、音效等。
- **EllesmereUI** -- 为冷却监控管理器提供额外的自定义选项
  
  - 一款以易用性为核心设计的用户界面，附带许多标准界面没有的额外功能。使用 EllesmereUI 时，你可以轻松禁用不需要的模块，只将其用作冷却监控管理器（CDM）。
- **Plater**  -- 高级姓名板
  
  - Plater 是一款姓名板插件，拥有海量的设置选项、开箱即用的负面效果监控、仇恨着色以及脚本支持。
- **Details** -- 深度伤害统计
  
  - 最强大、最可靠、最好看的伤害统计插件。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁12.0.1
- 术士
  
  - 英雄天赋
    
    - [[talent:123386]]
      
      - 狱火箭伤害提高150%。
      - 陨灭伤害提高50%。此改动不影响PvP战斗。
    - [[talent:123383]]
      
      - 邪能收割现在提高具现贪欲的灵魂横扫的伤害。
      - 共享容器现在提高2%精通（原为4%）。
      - 显化恶魔之魂的灵魂横扫伤害降低30%。此改动不影响PvP战斗。
      - 蚀魂之咒伤害降低40%。
      - 恶魔学识
        
        - 萨塔艾尔的意志现在使野生小鬼伤害提高35%（原为5%）。
        - 邪能收割现在使所有恶魔之魂伤害提高30%（原为10%）。
        - 恶魔之魂伤害降低3%。
        - 灵魂横扫伤害提高20%。
        - 邪能收割伤害提高100%。
        - 蚀魂之咒伤害提高50%。

:::

:::details 补丁12.0
- 术士
  
  - 新天赋：疲劳诅咒——使目标的移动速度降低50%，持续12秒。
  - 新天赋：语言诅咒——强迫目标使用恶魔语，使其所有法术的施法时间增加30%，持续1分钟。
  - 新天赋：虚弱灾厄——召出一团令人窒息的暗影迷雾，笼罩目标及其10码范围内的所有敌人，使其攻击间隔延长100%，爆击几率降低10%，持续12秒。
  - 新天赋：语言灾厄——召出一团令人窒息的暗影迷雾，笼罩目标及其10码范围内的所有敌人，使其所有法术的施法时间延长100%，持续12秒。
  - 新天赋：强化死亡缠绕——使死亡缠绕的范围扩大10码，治疗量提高5%。
  - 新天赋：狱火之益——吸取生命产生的治疗同时会以400%的效果治疗你的主要恶魔。
  - 新天赋：邪污巨口——施放疲劳诅咒、语言诅咒或虚弱诅咒时，现在会诅咒目标10码范围内的所有敌人。
  - 新天赋：生命共享——吸取生命产生的治疗同时会以100%的效果治疗你的主要恶魔。
  - 新天赋：血魔的贪婪——吸取生命的引导速度提高50%/100%，恢复生命值的速度提高50%/100%。
  - 新天赋：旅行常客——恶魔传送门的施法时间缩短0.5秒，并且你现在可以在触发冷却前使用两次恶魔传送门。
  - 新天赋：萨特契约——你的急速提高3%。
  - 新天赋：安尼赫兰契约——你的爆击几率提高2%。
  - 新天赋：纳斯雷兹姆契约——你的吸血提高2%。
  - 新天赋：艾瑞达契约——智力提高3%。
  - 新天赋：强效治疗石——治疗石额外恢复5%的生命值。
  - 新天赋：强效吸取生命——吸取生命现在按所造成伤害的700%进行治疗，并使你获得的灵魂吸取等于所造成伤害的10%。
  - 新天赋：强化灵魂——灵魂吸取现在提供的护盾最高可达你最大生命值的15%。
  - 新天赋：压迫黑暗——暗影之怒的冷却时间缩短15秒，半径扩大2码。恐惧嚎叫的冷却时间缩短10秒，并且现在可以额外恐惧5个敌人。
  - 许多天赋在天赋树中的位置发生了变化。
  - 已为全部3个专精实装新的入门构建。
  - 以下天赋已被移除：积攒的生命力
    
    - 诅咒增幅
    - 衰弱诅咒
    - 暗影之怒
    - 恶魔鼓舞
    - 恶魔战术
    - 生命之血
    - 精疲力尽契约
    - 语言契约
    - 索克雷萨的诡诈
    - 灵魂导管
    - 萨格莱技法
    - 萨特教诲
    - 狂怒仆从
  
  
  
  - 英雄天赋
    
    - [[talent:123386]]
      
      - 新天赋：天魔邪眼——每当敬魔仪式的持续时间被你的一个法术缩短时，召唤一个恶魔之眼，最多3个。天魔邪眼在吞噬恶魔艺术时爆炸，对目标8码范围内的所有敌人造成火焰伤害。超过8个目标后伤害降低。
      - 新天赋：致命凝视——你的天魔邪眼在激活期间每1秒对你的主要恶魔的目标施放恶魔凝视。
      - 新天赋：心灵之眼——你的天魔邪眼会观察战场并收集情报，在被引爆时传授给你，每个天魔邪眼使你的智力提高2%，持续10秒。
      - 兰考拉之触现在使古尔丹之手、混乱之箭、火焰之雨或暗影灼烧的伤害提高20%（原为100%）。
      - 魔眼爆炸的伤害降低30%。此改动不影响PvP战斗。
    - [[talent:123383]]
      
      - 新天赋：具现贪欲——每吞噬一个诱人灵魂，都有递增的几率释放你体内的恶魔之魂，使其攻击你的敌人，持续9秒。
      - 新天赋：灵魂横扫——用一只充满恶意的魔爪打击附近的敌人，对其目标造成暗影伤害，并对10码内的其他敌人造成暗影伤害。
      - 新天赋：共享容器——你的精通提高4%。当恶魔实体在战斗中协助你时，此效果翻倍。
      - 新天赋：无尽饥渴——具现贪欲的持续时间延长5秒，灵魂横扫的伤害提高10%。
      - 恶魔之魂已更新——现在一个恶魔实体栖居于你的灵魂之中，使你在获得灵魂碎片时能够检测其是否带有诱人灵魂。吞噬一个诱人灵魂会释放你的恶魔之魂，对目标10码范围内的所有敌人造成暗影伤害。超过8个目标后伤害降低。恶魔之魂的伤害提高100%。
      - 邪恶收割的伤害提高150%。
      - 蚀魂之咒的伤害提高50%。
  - 恶魔学识
    
    - 新天赋：邪恶智力——你的智力提高2%。
    - 新天赋：娴熟仪式——你的精通提高2%。
    - 新天赋：邪恶之力——你的主要恶魔造成的伤害提高5%/10%。
    - 新天赋：恶魔学识——古尔丹之手有8%/15%的几率产生一层恶魔之核。
    - 新天赋：地狱指挥官——你的恶魔每受你控制的一个恶魔影响，造成的伤害提高1%。
    - 新天赋：安托兰军备——你的恶魔暴君装备了在安托鲁斯锻造的护甲，护甲值提高10%。被召唤期间，你的恶魔暴君现在会以强力的近战攻击袭击敌人。
    - 新天赋：召唤末日守卫——召唤一个末日守卫协助你作战，持续12秒。吞噬一个恶魔之核会使召唤末日守卫的冷却时间缩短3秒。
    - 新天赋：邪能军备——你的恶魔卫士的魔刃风暴冷却时间缩短10秒，你的主要恶魔受到的伤害降低10%。
    - 新天赋：地狱火迅捷——当你的野生小鬼施放邪能火焰箭时，有10%的几率立即以200%的效果再次施放一发邪能火焰箭。
    - 新天赋：优势之手——古尔丹之手对其主要目标造成的伤害提高20%。
    - 新天赋：凋零之口——你的恐惧猎犬的獠牙涂有腐蚀性胆汁，使恐咬额外造成相当于所造成伤害50%的瘟疫伤害。
    - 新天赋：恶毒重组——恶魔之箭的伤害提高10%，并且吞噬一个恶魔之核有几率召唤一个野生小鬼。
    - 新天赋：暴君的祭品——你的恶魔暴君在激活期间也会强化你，使你的急速提高8%。
    - 新天赋：暴君统治——你的恶魔暴君持续时间延长5秒，被召唤时使你的恐惧猎犬的持续时间延长15秒。
    - 新天赋：魔典：小鬼领主——召唤一个小鬼领主协助你作战，持续20秒，被召唤时会移除你身上的1个有害效果。冷却期间变身为烧灼驱魔。
    - 新天赋：魔典：邪能破坏者——召唤一个邪能掠夺者协助你作战，持续20秒，被召唤时会打断其目标。冷却期间变身为法术封锁。
    - 新天赋：稳定传送门——你的召唤邪犬、魔典：小鬼领主和魔典：邪能破坏者的持续时间延长3秒。
    - 新天赋：强效魔刃风暴——你的恶魔卫士的魔刃风暴伤害提高20%，持续时间延长4秒。
    - 新天赋：地狱往返——能量虹吸和内爆每献祭2只野生小鬼就召唤1个小鬼帮主。以此方式召唤的野生小鬼获得不稳定的灵魂。不稳定的灵魂：造成的伤害提高100%，并且邪能火焰箭现在会弹跳至3个额外目标。
    - 召唤恶魔卫士已移至天赋树（原先在选择恶魔学识专精时自动习得）。
    - 恶魔卫士的伤害提高60%。
    - 古尔丹之手现在替换腐蚀术，并已移至天赋树（原先在选择恶魔学识专精时自动习得）。
    - 古尔丹之手已重新设计——召唤一颗满载野生小鬼的恶魔陨石，小鬼会蜂拥而出攻击目标。落地时对目标8码范围内的所有敌人造成暗影烈焰伤害，并召唤3只野生小鬼。
    - 古尔丹之手的伤害降低10%。
    - 野生小鬼的邪能火焰箭伤害提高35%。
    - 小鬼帮主已重新设计——古尔丹之手现在会强化它召唤的1只野生小鬼，使其造成的伤害提高100%。
    - 暗影符文已重新设计——暗影箭的施法时间缩短10%/20%，伤害提高15%/30%。
    - 召唤邪犬已重新设计——召唤恐惧猎犬还会召唤一只恶犬协助你作战，持续15秒。
    - 强化恶魔战术已更新——你的主要恶魔的爆击几率提高，数值为你爆击几率的50%。
    - 末日降临已更新——古尔丹之手使末日降临的持续时间缩短3秒。
    - 能量虹吸已更新——立即献祭最多2只野生小鬼，产生2层恶魔之核，使恶魔之箭额外造成30%伤害。
    - 内爆已更新——恶魔之力将你的6只野生小鬼吸向目标，然后使其猛烈爆炸，对8码范围内的所有敌人造成暗影烈焰伤害。30秒冷却。内爆的伤害提高500%。
    - 魔性征召已更新——召唤恐惧猎犬的灵魂碎片消耗减少1个/2个，施法时间缩短50%/100%。
    - 恶魔残暴已更新——你和你的恶魔造成的爆击伤害为230%，而非通常的200%。
    - 召唤恶魔暴君已更新——召唤一个恶魔暴君攻击你的目标，持续15秒。恶魔暴君造成的伤害每有一个野生小鬼和恐惧猎犬就提高10%。
    - 恶魔召唤大师已更新——精通提高3%，召唤恶魔暴君和召唤恶魔卫士的施法时间缩短0.5秒。
    - 末日降临弹幕已更新——向40码内的5个敌人射出一连串恶毒箭，对每个目标造成暗影伤害。
    - 地狱火之怨已更新——用邪能烈火灼烧目标的灵魂，每1秒造成火焰伤害。
    - 恶魔召唤大师现在是2点天赋。精通提高3%/6%，你的召唤恐惧猎犬和召唤恶魔暴君的施法时间缩短15%/30%。
    - 牺牲之魂现在是2点天赋。你已召唤的恶魔使暗影箭和恶魔之箭额外造成2%/4%伤害。
    - 若干天赋在天赋树中的位置发生了变化。
    - 以下天赋已被移除：灾怨轰炸
      
      - 鲜血祈愿
      - 恶魔力量
      - 末日降临永恒
      - 恐惧召唤
      - 邪能祈愿
      - 邪能撕裂
      - 邪恶祭品
      - 邪污巨口
      - 魔典：恶魔卫士
      - 不变的仇恨
      - 迫近的末日降临
      - 暗影祈愿
      - 暗影之触
      - 灵魂打击
      - 炮灰
      - 驯犬者的赌局
      - 暗影烈焰
      - 邪恶之口

:::

:::

## 常见问题

:::accordion
:::details Q: 为什么我的[[talent:125836]] 伤害这么低？
A: 请查看[ **深度解析**](<https://maxroll.gg/wow/class-guides/demonology-warlock-raid-guide#deep-dive-header>) 章节，了解有关此主题的更多信息。

:::

:::

---

### 致谢

作者：**Wolfdisco**

---

:::changelog 更新记录
**2026-08-04** 已更新至12.1版本

**2026-06-17** 已更新至12.0.7版本

**2026-04-21** 已更新至12.0.5版本

**2026-02-17** 已更新至12.0.1版本

**2026-01-18** 已更新至12.0版本

**2025-12-02** 已更新至11.2.7版本

**2025-10-07** 已更新至11.2.5版本

**2025-07-21** 已更新至11.2版本

**2025-06-17** 已更新至11.1.7版本

**2025-04-21** 已更新至11.1.5版本

**2025-02-20** 已更新至11.1版本

**2024-12-17** 已更新至11.0.7版本

**2024-10-18** 已更新至11.0.5版本

**2024-08-17** 已更新至11.0.2版本。

**2024-07-24** 本指南撰写于前置补丁11.0.1版本。



:::
