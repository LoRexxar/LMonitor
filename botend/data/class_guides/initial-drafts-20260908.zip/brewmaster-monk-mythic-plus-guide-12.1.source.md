Welcome to the **Brewmaster Monk** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 4/5 · Strong

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 4/5 · Strong

Mobility · 5/5 · Excellent



:::

:::

:::column
:::gear **Brewmaster Monk** Mythic+ Best in Slot
```json
{
  "source_code": "JgfAYyQA3_PAB8JJEIIEFAw74OgDtOQOCchNYFwAmQQApfBBAERAA4QrDUwFYxYNYFQAKU9ACgQAAUTuDIoAOFQAiSCBB8ADJk7A5EwDUUT1DAICBEgMF4BAeGgH8UAAhu7A5IAWBE8FEEASuJQAwAwDN8DCE5mAuADAYAKJEAACBAQBLBYeWPggIEAA1j7AO06A3WzSBEQNtOghIEAAfA8A1j7AhZdFYQwXf0gNMgVAB4VEMAhTBEA2XUAGFoIP3eBBCARAA0TuDIoAWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271519]] | [[item:240910]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240910]] · [[item:240910]] |
| 肩部 | [[item:251146]] | [[item:244021]] |
| 胸部 | [[item:271522]] | [[item:243977]] |
| 腰部 | [[item:251189]] | [[item:240910]] |
| 腿部 | [[item:271518]] | [[item:244641]] |
| 脚部 | [[item:159304]] | [[item:243983]] |
| 腕部 | [[item:159300]] | [[item:240910]] |
| 手部 | [[item:271520]] |  |
| 戒指一 | [[item:251513]] | [[item:240910]] · [[item:243957]] |
| 戒指二 | [[item:240949]] | [[item:240910]] · [[item:245791]] · [[item:243957]] · [[item:251489]] |
| 饰品一 | [[item:270175]] |  |
| 饰品二 | [[item:270174]] |  |
| 背部 | [[item:268248]] |  |
| 主手 | [[item:268215]] | [[item:244029]] |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Brewmaster Monk**, you have access to Bring Me Another, which gives you a 20% chance on your next Brew that you conusme, to give an Empty Barrel, which is then automatically consumed on your next [[spell:121253]] and does additional physical damage.

**Rank 2** makes your [[spell:121253]] cooldown reset and your next [[spell:121253]] costs 50% less energy. While on **Rank 3** drinking a [[spell:115203]] or [[spell:322507]] gives you a fresh keg which then, on consume, provides you with the buff [[spell:1265140]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-brewmaster-mxr.webp>)

Bring Me Another

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look of **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:400629]]
    
    - Before, every time you took damage you had a chance to spawn a Healing Sphere, now every time you use [[spell:109080]] you have a chance to spawn a Healing Sphere.
  
  
  
  - [[spell:196736]]
    
    - This got changed so your next [[spell:109080]] only buffs your next [[spell:121253]] or [[spell:100780]].
  - [[spell:1262659]]
    
    - Makes your fire & nature damage heal you for 50% of its damage.
  - [[spell:1263245]]
    
    - Provides us with an additional 5% Mastery during [[spell:132578]].
  - [[spell:1262017]]
    
    - After casting [[spell:325153]], your next 2 [[spell:121253]] are enhanced and summon a whirl of fire around the enemy.
  - [[spell:1262329]]
    
    - Allows us to reactivate [[spell:325153]] after its use throw 5 additional kegs at nearby enemies and reduce the cooldown of all our brews by 3 seconds.
  - [[spell:383707]]
    
    - On top of giving your [[spell:121253]] another charge, it also gives [[spell:121253]] now additional 10 yards range, which makes it great for pulling from further away.
  - [[spell:1263345]]
    
    - Drinking one of your brews provides you with more movement speed and auto-attack speed.

- **Class Tree**
  
  - [[spell:1266733]]
    
    - [[spell:119381]] now applies [[spell:116095]] to every enemy hit for 5 seconds.
  - [[spell:1243287]]
    
    - Now isn't an active button anymore and rather build into your [[spell:115203]] with the functionality of being able to transfer back magic debuffs back to your target whenever you press [[spell:115203]].
  - [[spell:1272452]]
    
    - Makes your next [[spell:115080]] heal you for 50% of its damage done.

- **Removed**
  
  - [[spell:122278]] 
    
    - This results in having less major defensive cooldowns against large tank hits.
  - [[spell:310454]]
    
    - The removal of [[spell:310454]] makes us not having an offensive cooldown anymore.
  - [[spell:389577]]

## Hero Talents

- [[talent:125028]] and ‍[[talent:125027]] are both very competitive with each other when it comes to damage output.
- [[talent:125028]] influences your gameplay with [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]], while [[talent:125027]] is almost fully passive.
- [[talent:125027]] is overall better for progressing keys in terms of damage and survivability, but [[talent:125028]] has smoother damage profile with [[talent:125028]] having more priority damage due to [[spell:450529@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]].
- In the talent section below you can find two different recommended talent builds for keys, one for [[talent:125027]] and one for [[talent:125028]], both are viable for either low key or high M+ progression.

### [[talent:125027]]

- [[talent:125069]]
  
  - Your auto-attacks have chance to generate [[spell:451021]].
  
  
  
  - Casting [[spell:121253]] will unleash all [[talent:125069]].
- [[spell:450989@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Reduces the cooldown of [[spell:132578]] by 25 seconds.
- [[spell:1272821@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]]
  
  - During [[spell:132578]] your next [[spell:115181]] will unleash 3x [[talent:125069]].

- [[talent:125027]] choice node picks are:
  
  - [[talent:125068]]
  - [[spell:1272844]]
  
  
  
  - [[talent:125064]]
    
    - This passive does not have a cooldown and can proc at any time.

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1262603@FJQESycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBS4yEpKzEKA]] 
  
  - Everytime you use [[spell:132578]] you will instantly gain 10 stacks of [[spell:450615]].

### [[talent:125028]]

- [[spell:450508@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Damage and effective healing are stored as Vitality.
  - During [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]] you don't generate any Vitality.
  - Important: Overhealing does not count as effective healing.
- [[talent:125035]] 
  
  - Important node to never waste any Vitality.
- [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Having 2 charges of [[spell:1241059]] makes it easy to hold/delay the use to optimize for damage and survivability.
- [[spell:451036@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - The extra shield and [[spell:115069]] reduction are strong defensively.
- [[spell:450529@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]]
  
  - Increases the damage enemies take by 20% while you are under the effect of [[spell:450567@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]].

In the 12.0 prepatch, you gain access to the new Hero Talent column but only have limited points to spend.

- [[spell:1239442]] 
  
  - Everytime you cast [[spell:1241059]] your next 2 [[spell:100780]] are enchanced and will trigger a [[spell:1239442]].
- [[spell:1271048]]
  
  - After every [[spell:121253]] your next [[spell:100780]] will trigger a [[spell:1239442]].

## Talents

### [[talent:125028]] Build

:::talents **Brewmaster Monk** Mythic+
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:124864]]
  
  - Shuffle doubles the effectiveness of [[spell:115069]].
- [[spell:400629]]
  
  - Gives your [[spell:109080]] a chance to spawn [[spell:115464]].
- [[talent:124857]]
  
  - This provides you with Mastery based on your stagger, one of the reasons why Mastery is not that highly ranked in stat priority.
- [[talent:124853]]
  
  - Makes [[spell:205523]] cleave and increases its value by a lot.

##### Class Tree

- [[talent:124950]]
  
  - [[spell:115546]] now increases the target’s movement speed by 50%.

### [[talent:125027]] Build

:::talents **Brewmaster Monk** Mythic+
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDGz2MPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAA2mlplZbmlBAY2mlmZmZjhFAmZYaMAAgBA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAwMbbGDGz2MPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAA2mlplZbmlBAY2mlmZmZjhFAmZYaMAAgBA"
}
```
:::

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section gives a concise overview of these talents and their applications but for a more detailed look check out the Rotation and **Deep Dive** sections below.

##### Spec Tree

- [[talent:124864]]
  
  - Shuffle doubles the effectiveness of [[spell:115069]].
- [[spell:400629]]
  
  - Gives your [[spell:109080]] a chance to spawn [[spell:115464]].
- [[spell:212935]]
  
  - Make sure to keep [[spell:115181]] on cooldown before casting [[spell:121253]] to get the cooldown reset from this talent.
- [[talent:124857]]
  
  - This provides you with Mastery based on your stagger, one of the reasons why Mastery is not that highly ranked in stat priority.
- [[spell:387230]]
  
  - Makes you have [[spell:205523]] more often which results in more uptime on [[spell:196736]] which then can be used for more single target damage or more cooldown reduction on your brews in AoE situations.

##### Class Tree

- [[talent:124950]]
  
  - [[spell:115546]] now increases the target’s movement speed by 50%.

## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:115181]] ignites your next [[spell:121253]], causing it to explode on contact, dealing additional Flamestrike damage to its primary target and reduced damage to additional targets.
- **4-Set:** Ingnited [[spell:121253]]'s cause enemies struck to take 8% increased damage from your Physical abilities, and leave a patch of flames on the ground, dealing Fire damage each second for 5 sec.

### Opener

- We want to gain a good amount of [[spell:322120]] through [[spell:121253]] and [[spell:205523]] while also getting our debuffs rolling.

:::rotation **Brewmaster Monks** Mythic+  AoE Opener
```json
{
  "source_code": "IUETIIUpZHAAAAQABwprDAAAAAgQtHcAQwAACBbiJgABqyYCIkAKQAgQhYPBFgCKwmYAAAAAAIUpZHA"
}
```
1. [[spell:121253]]  [[item:241308]]
2. [[spell:115181]]
3. [[spell:100784]]
4. [[spell:101546]]
5. [[spell:121253]]
6. [[spell:325153]]
7. [[spell:100784]]
8. [[spell:121253]]
:::

:::rotation **Brewmaster Monks** Mythic+ Single Target Opener
```json
{
  "source_code": "IUETIIUpZHAAAAQABwprDAAAAAgQwmYAQgAACxaDIQQ7BnAEJgCEAIUI2TgPoAA"
}
```
1. [[spell:121253]]  [[item:241308]]
2. [[spell:100784]]
3. [[spell:100780]]
4. [[spell:115181]]
5. [[spell:121253]]
6. [[spell:325153]]
7. [[spell:100784]]
8. [[spell:100780]]
:::

### Priority List

Make sure to keep this list in mind, unless some bosses or scenarios require you to hold some abilities listed here

1. Cast [[spell:121253]] on cooldown.
2. Cast [[spell:115181]].
3. Cast [[spell:100784]] on cooldown.
4. Cast [[spell:100780]] or [[spell:101546]] on 8+ targets.
5. Cast [[spell:325153]].
6. If talented, cast [[spell:123986]].
7. When the pull is about to end make sure to use [[spell:322109]] whenever possible.

### Defensive Cooldowns

- [[spell:1241059]]
  
  - Provides you with a smaller absorb shield & 30% damage reduction during its duration.
  
  
  
  - Has 2 charges with [[talent:125028]] talent [[spell:450892@FJwDSycAhWdA_chAFcmAMunAH30Ayi4AV07A2oOBnXPByTeA4fUB9FcAH0wBI0wBKA]].
- [[spell:243435]]
  
  - Crazy long cooldown of 4 minutes that gets reduced by [[spell:121253]].
  - Gives 20% max health and 20% damage reduction, which makes it your most well-rounded **defensive**.
  - Used mainly against big hits and early on so the cooldown reduction can start working on getting it back.

### Offensive Cooldowns

- [[talent:125001]]
  
  - Causes melee attacks of targets hit to 100% miss you for 3 seconds.
  - Throw a keg that amplifies all your damage with bonus fire damage. Pair with [[spell:101546]] on AoE.
- [[spell:322109]]
  
  - Clears up to 200% [[spell:115069]] when casted. [[spell:325095]] is very good to cast on cooldown for both damage and defensive value.
  - It also helps you to finish off dangerous mobs towards the end of a pull.

## Deep Dive

### Stagger

**Brewmaster Monks** rely on their [[spell:115069]] mechanic to passively reduce the damage they take which is an essential part of their damage mitigation.

#### Stagger Phases

Your [[spell:115069]] is split up into 3 different phases.

- [[spell:124275]]
  
  - Total [[spell:115069]] damage amount is equal to 1-29% of your maximum health.
- [[spell:124274]]
  
  - Total [[spell:115069]] damage amount is equal to 30-59% of your maximum health.
- [[spell:124273]]
  
  - Total [[spell:115069]] damage amount is equal to 60% or more of your maximum health.

Using [[spell:119582]] cleanses **50%** of the [[spell:115069]] damage thus reducing your [[spell:115069]] phase and serving as your main mitigation ability. [[spell:119582]] is best used right after receiving a lot of damage to cut the [[spell:115069]] damage in half.

### Managing Celestial Infusion & Purifying Brew

Juggling [[spell:1241059]] & [[spell:119582]] is your main task and gameplay when it comes to your survivability on **Brewmaster Monk**.

- [[spell:119582]] is your main tool to cleanse [[spell:115069]] like described above.
  
  - Important to note: [[spell:119582]] **is not on the global cooldown**, so it can be pressed while using any other ability.
- [[spell:1241059]] is your defensive tool.

Here are some tips and tricks on what to keep in mind when using them:

- [[spell:119582]] has a few rules you want to keep in mind when juggling your charges:
  
  - Avoid having both charges ready, you are wasting both defensive value and cooldown reduction value from your abilities.
  
  
  
  - Make sure you always get full cooldown reduction on this from [[spell:121253]].
- General rule on when to use [[spell:119582]] the most efficient way:
  
  - After a big hit so you get the most [[spell:115069]] value cleansed when it is new and at the highest point.
  - The other option is to almost fully cleanse yourself of any dangerous [[spell:115069]] after big hits, this is achieved by getting a very big stagger and then using 2 charges back to back.
- Overall, if you follow a natural flow of gameplay, you should use it quite frequently just to avoid [[spell:124273]] and not overcap charges.
- The biggest mistake you can make is to use all charges on cooldown and then end up with none when the [[spell:115069]] becomes dangerous.
- [[spell:1241059]] is more straightforward to use:
  
  - It's your most frequent active defensive and should be used on most mechanics whenever possible.
  - Try to not hold it for too long since you are wasting cooldown reduction, which results in more damage taken in the long run.
  - However, you have to hold it for dangerous tank mechanics in certain scenarios, so keep that in mind.

### Shuffle

**Brewmaster Monks** need [[spell:115069]] to live any mechanic and what enables it to a large extent is [[talent:124864]].

- [[talent:124864]] is passively generated by pressing [[spell:121253]], [[spell:101546]] and [[spell:205523]].
- If you don't stop pressing buttons, [[talent:124864]] should never drop and you don't need to pay any attention to it. But there are some scenarios where the buff might run out:
  
  - When mechanics force you out of range and you are unable to reach the boss you might end up dropping it, resulting in a lot more damage taken so watch out for that!
  - Starting combat with [[spell:121253]] and running in fast can result in death. Since [[talent:124864]] is triggered by the damage of [[spell:121253]] and not the cast, if you are faster than the keg flying, you might get hit without [[talent:124864]] up and you die.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

In the dungeon section below, we're only showing builds that play [[talent:125028]] but feel free to also use the recommended [[talent:125027]] build that you can find in the [talent](<https://maxroll.gg/wow/class-guides/brewmaster-monk-mythic-plus-guide#talents-header>) section. Both builds are completely viable for every dungeon.

### Altar of Fangs

:::talents **Brewmaster Monk** Mythic+ Altar of Fangs
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### Rav'i

- There are 3 Carrion Piles spread in the room, make sure to move the boss before he reaches 0% energy towards one of the three Carrion Piles that is not glowing red so he can [[spell:1296216]] in them.
- While [[spell:1296216]] look out for [[spell:1307703]] on the ground and soak them if needed.

##### The Writhing Coil

- The boss will cast [[spell:1298949]] at you, which deals physical damage and knocks you slightly back.
- Interrupt [[spell:1310358]].
- During [[spell:1299053]] run away from the boss as fast and far as possible.

##### Zul'jan

- Whenever the boss casts [[spell:1300872]] make sure to stand in between him and [[spell:1300894]] to soak it.
- Dodge any axes spawned by [[spell:1283832]].
- [[spell:1301350]] is a quick 0.5 second cast which deals physical damage and is the tank buster of the fight.
- When a teammate is targeted by [[spell:1301413]], move into the line between the boss and the targeted player. This reduces the damage your teammate takes.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] - Primal Serpent
  - [[spell:1307567]] - Ula'tek's Chosen

- Pay extra attention to these casts:
  
  - [[spell:1306911]] - Ritual Chieftain
  - [[spell:1294845]] - Rattling Writhe
  - [[spell:1294934]] - Ascendant Serpent

### Den of Nalorakk

:::talents **Brewmaster Monk** Mythic+ Den of Nalorakk
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Whenever the boss casts [[spell:1234233]] he will summon [[spell:1234740]] on the ground, make sure to help your group soak them.

##### Sentinal of Winter

- After the boss has casted [[spell:1235783]], drag him on top of a summoned add and kick [[spell:1235829]].

##### Nalorakk

- When the boss begins casting [[spell:1243569]], make sure you are standing in the [[spell:1243856]] provided by Zul'jarra. Once the cast finishes, the boss will immediately follow up with [[spell:1297797]], creating a large circle in front of him. As the tank, move into the circle to soak the hit.
- During [[spell:1243002]], run towards any Echo of Nalorakk that tries to reach Zul'jarra to stop it from reaching her by touching it with your character.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1297696]] - Earthwhisper Tender
  - [[spell:1309919]] - Frigid Mauler
  - [[spell:263607]] - Stormbound Mystic
  - [[spell:9532]] - Loa Speaker Nanea

- Pay extra attention to these casts:
  
  - [[spell:1238687]] - Spirit of Hunger

### Murder Row

:::talents **Brewmaster Monk** Mythic+ Murder Row
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Nibbles will cast a frontal cone [[spell:1253811]] on you, make sure to not aim this on top of your group, by the end of the cast you can also dodge it by running to the side.
- Kystia will occasionally cast multiple [[spell:1264095]] which cast [[spell:1264106]] that you can interrupt or stun to cancel their casts.

##### Zaen Bladesorrow

- The boss will cast [[spell:1222795]] at you, which deals physical damage and leaves a dot at you [[spell:474515]].
- When targeted by [[spell:474545]] try to hide behind barrels in the room.

##### Xathuux the Annihilator

- [[spell:1214781]] is the main tank buster mechanic of this fight, it is a frontal cone which you do not want to aim towards you group, it leaves debuff on you which reduces your healing taken by 80% for 8 sec.
- After [[spell:1214637]] try to tank the boss near his axe.
- During [[spell:1223533]] try to kite him alongside the edge of the room to minimize the spread of [[spell:474231]].

##### Lithiel Cinderfury

- The boss will use [[spell:1220899]] and you will need to kite this infernal for the entire duration of the fight.
- Interrupt [[spell:474375]] whenever possible.
- Grab threat on [[spell:474408]] whenever it is up.
- When the boss summons [[spell:1214675]] wait until it has also finished the cast [[spell:1217345]] before taking the gateway.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216570]] - Felonious Mage
  - [[spell:1201554]] - Seductive Sayaad
  - [[spell:1214922]] - Wrathguard Flayer
  - [[spell:1214980]] - Fel Invoker

- Pay extra attention to these casts:
  
  - [[spell:1216529]] - Bribed Captain

### The Blinding Vale

:::talents **Brewmaster Monk** Mythic+ The Blinding Vale
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Make sure to keep threat on all three bosses and position them together whenever possible to allow cleave and efficient damage since they all share the same healthpool.
- Meittik will cast [[spell:1234753]] at you, which is the main source of tank damage during the fight.
- Try to interrupt [[spell:1235616]] whenever possible, which is casted by Kezkitt.
- Kezkitt will also cast [[spell:1235564]], which requires you to stand inside one of the three Lightblossoms to soak the damage.

##### Ikuzz the Light Hunter

- Every time the boss casts [[spell:1236746]] make sure you don't get knocked into one of the roots on the ground. If you get knocked away from the group, make your way back quickly, as everyone will be rooted 4 seconds after the mechanic happens. You want to be stacked with the group so you can cleave down the roots as quickly as possible.

##### Lightwarden Ruia

- This boss has 3 different phases, he will always start in the Moonkin phase.
- In this phase you simply just kick [[spell:1239821]] and dodge [[spell:1239830]]'s created by [[spell:1239824]].
- In his next phase, the Bear form, his melee attacks become more dangerous due to [[spell:1272265]]. Also if targeted by [[spell:1240210]] make sure to not move too much so you and your teammates have an easier time dodging.
- The final phase starts at 40%, when the boss enters Haranir Form and channels [[spell:1241067]], casting all his abilities in a rapid flurry.

##### Ziekket

- Each time the boss casts [[spell:1246372]] he will summon adds beneath him, make sure to grab threat on those as quickly as possible.
- After [[spell:1246858]] the boss will have orbs coming towards him, soak these orbs and do not let any of them touch the boss.
- Additionally the boss will also use [[spell:1247685]] as tank buster mechanic this fight inflicting magic damage, knocking you back and leaving a bleed on you that deals physical damage every second for 10 seconds.
- When the adds die, you have to position the boss in a way that he will hit all of them with the [[spell:1246607]] ability that is targeted on you, completely removing that set of adds from the fight when they are getting it, if not getting hit, they will be revived the next time the boss casts [[spell:1246372]], alongside the newly summoned adds.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1301834]] - Radiant Spellsower
  - [[spell:1238294]] - Lightfeather Petalwing

- Pay extra attention to these casts:
  
  - [[spell:1237855]] - Virid Grovekeeper

### Voidscar Arena

:::talents **Brewmaster Monk** Mythic+ Voidscar Arena
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Whenever the boss casts [[spell:1296889]], make sure that you don't overlap your [[spell:1222098]] with others.
- He will also cast [[spell:1297017]] at you which deals huge magic damage and will knock you back.
- After every [[spell:1300259]] make sure to dodge orbs.

##### Atroxus

- [[spell:1222642]] is the tank buster mechanic of this fight, it deals magic damage and leaves a dot for 10 seconds which makes you suffer more magic damage.
- Each time the boss casts [[spell:1262497]] he will summon a Toxic Creeper which will fixate you, try to kite this Toxic Creeper alongside the boss for maximum amount of cleave.

##### Charonus

- The boss will cast [[spell:1311923]] at you, which is a 5 second long cast, try to not move too much with this so your teammates can dodge it.
- Ocassionally the boss will target one of your group members with [[spell:1222755]]. As the tank, your job is to position yourself between the boss and the targeted player, intercepting the projectiles before they can reach your teammate.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1299938]] - Voidtouched Magi
  - [[spell:1298899]] - Dominated Brawler
  - [[spell:1249621]] - Angry Krolusk
  - [[spell:1233398]] - Kilivore Screamer

- Pay extra attention to these casts:
  
  - [[spell:1300243]] - Devouring Brutalizer

### Kings' Rest

:::talents **Brewmaster Monk** Mythic+ Kings' Rest
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- The boss will hit you with [[spell:265910]] which deals physical damage.
- After the boss has casted [[spell:265923]] make sure to kite him if needed so adds do not reach him.

##### Mchimba the Embalmer

- Whenever the boss casts his main ability [[spell:267702]], watch out on the tombs as the sides of the room and click the one that is shaking since one of your party members will be inside of it.

##### The Council of Tribes

- Aka'ali the Conqueror will use [[spell:266237]] against use which knocks you back and makes you take 200% increased physical damage taken afterwards for 10 seconds.
- Help soaking [[spell:266939]] on your teammates.
- Interrupt [[spell:267273]] during the fight with Zanazal the Wise.
- After he has [[spell:267060]] try to move him on top of an explosive totem.

##### Dazar, The First King

- This boss can deal a lot of tank damage due to [[spell:268586]] and [[spell:1303267]] so make sure to use your defensive abilities.
- Dodge [[spell:1302945]] whenever possible throughout the encounter.
- While Reban is active, make sure to interrupt [[spell:269369]] whenever you can.
- T'zala will also start casting [[spell:1303488]] at you whenever he is active, adding another layer of tank damage in this fight.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] - Risen Hexer
  - [[spell:270920]] - Queen Wasi
  - [[spell:270901]] - Seneschal M'bara
  - [[spell:270492]] - Phantom Hex Priest

- Pay extra attention to these casts:
  
  - [[spell:1297918]] - King A'akul
  - [[spell:1302028]] - Ghostly Brute
  - [[spell:270514]] - Ghostly Brute
  - [[spell:1309385]] - Shadow of Zul

### Ruby Life Pools

:::talents **Brewmaster Monk** Mythic+ Ruby Life Pools
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- The boss will cast [[spell:372808]] at you, which is an interruptable cast, so make sure to interrupt it on cooldown and press defensives if you or your teammates cannot interrupt.
- Occasionally the boss will also cast [[spell:396044]], after the cast has finished, move him away from the circles on the ground.
- At 66% and 33% health the boss will cast [[spell:373037]], make sure to grab threat of the spawned adds.

##### Kokia Blazehoof

- This bosses main tank mechanic is [[spell:372858]], which is a 3 second long cast.
- Make sure to tank the boss always next to a Blazebound Firestorm spawned by [[spell:372863]].

##### Kyrakka and Erkhart Stormvein

- With [[spell:381512]] the boss will apply a debuff to you which makes you take increased damage by the next [[spell:381512]] so make sure to communicate with your healer beforehand that he has to dispell you every time you get hit by this mechanic.
- Whenever the dragon Kyrakka has landed move out of [[spell:381525]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:372743]] - Flashfrost Chillweaver
  - [[spell:384197]] - Primalist Cinderweaver
  - [[spell:392576]] - Tempest Channeler

- Pay extra attention to these casts:
  
  - [[spell:372730]] - Primal Juggernaut
  - [[spell:372047]] - Defier Draghar
  - [[spell:392394]] - Flamegullet
  - [[spell:392395]] - Thunderhead

### Temple of Sethraliss

:::talents **Brewmaster Monk** Mythic+ Temple of Sethraliss
```json
{
  "source_code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA",
  "code": "CyQAI2iUD8dsJPIMmzPPH0Bl8BAAAgZbzYGGzyMPwGzMjBAAAAAAYZBjYmBmhxmZwMzMDzGzMmZZYZ7B22mthZBAAWmlplZbmlBAY2mlmZmZhhNwMzMDTjBAAMA"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Whenever Aspix casts [[spell:1310712]] make sure to not stack with your teammates.
- Adderis will focus on of your teammates with [[spell:1288049]], try help soaking this ability to split the damage and reduce the overall impact on the targeted teammate.
- He will also cast [[spell:1288428]] which makes him deal more melee damage for 8 seconds, use your defensive cooldowns if necessary.

##### Merektha

- The boss periodically casts [[spell:1290797]], a tank buster ability, it deals physical damage on hit and leaves a dot that ticks nature damage every second for 7 seconds.
- During [[spell:264206]], make sure to quickly establish threat on all summoned adds.

##### Galvazzt

- The only thing you have to do on this fight is to move the boss after every [[spell:1309525]] cast since it summons a [[spell:1291815]] beneath him.

##### Avatar of Sethraliss

- Make sure to grab threat of the Corrupted Guardians which ocassionally will cast [[spell:1300803]] at you. Additionally, you can also move him on top of the Essence Defiler.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1293307]] - Faithless Subjugator
  - [[spell:9532]] - Imbued Stormcaller
  - [[spell:13729]] - Twisted Hexxer

- Pay extra attention to these casts:
  
  - [[spell:1291468]] - Sandfury Stonefist
  - [[spell:1308546]] - Orb Watcher

### Affixes

The Affix system got revamped going into The War Within Season 1 retiring most Affixes as well as introducing new kiss-curse ones while also changing on which key level these appear.

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Brewmaster Monk**.

- Xal'atath's Bargain: Ascendant
  
  - When orbs spawn use [[spell:116844]] to interrupt as many as possible.
  - Use [[spell:119381]] whenever needed.
- Xal'atath's Bargain: Voidbound
  
  - The **Void Emissary** follows you, keep it close to cleave and target it whenever its up.
  - Use [[spell:115080]] to deal a huge amount of damage to the **Void Emissary**.
- Xal'atath's Bargain: Devour
  
  - [[talent:124867]] yourself whenever its applied to yourself.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Dungeons as a **Brewmaster Monk**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Brewmaster Monk** Stat Priorities in Mythic+
```json
{
  "source_code": "HoAJFMAKgEDJBIQABA"
}
```
**敏捷 ＞ 全能 ＝ 暴击 ＞ 精通 ＞ 急速**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks, especially in AoE scenarios it can be by far the best stat you can have.  
**Avoidance** is great but most of the time tanks are not struggling to survive the typical Area of Effect abilities.

## Gear

### Overall BiS

| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:271875@BARAAwQACKwF2gVA]]  <br>into [[item:271519@DCRBAwQAvj74QrTOCchNYFwAmQA]] | Catalyst of Ula'tek |
| Neck | [[item:268265@BERAAwQAO064QrTOCwYNYFA]] | Ula'tek |
| Shoulder | [[item:251146@DgQAAwQA1k7IoAOF]] | Den of Nalorakk |
| Cloak | [[item:268248@BgQAAwQACKgTBA]] | Nek'zali the Soulcoiler |
| Chest | [[item:271522@DgQAAwQAJk7kjAOF]] | Vashink the Malignant |
| Wrist | [[item:159300@BiQAAwQAO06IoAOF]] | Kings' Rest |
| Gloves | [[item:271520@BgQAAwQA5IgTBA]] | Entombed Sentinals |
| Belt | [[item:251189@BiQAAwQAO06IoAOF]] | The Blinding Vale |
| Legs | Convert [[item:268225@BgQAAwQA5IAWBA]]  <br>into [[item:271518@DgQBAwQAhu7kjAYFQwXQ]] | Catalyst of The Coiled Altar |
| Boots | [[item:159304@DgQAAwQAPk7IoAOF]] | Kings' Rest |
| Ring 1 | [[item:251513@DiQAAwQA1j74Qrzt1sUA]] | Crafting |
| Ring 2 | [[item:240949@HiQAAwQAfA8UPuTYWPO06cbNLFA]] | Crafting |
| Trinket 1 | [[item:270175@BgQAAwQA5IAWBA]] | Ula'tek |
| Trinket 2 | [[item:270174@BgQAAwQA5IgTBA]] | Sszorak |
| Weapon | [[item:268215@DARAAwQA9k7IoAWYDWB]] | Ula'tek |

### Farmable Alternatives

Below you are presented with a good list of farmable alternatives that are obtainable outside of WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:193751@BgQAAwQACKQQBA]] | Ruby Life Pools |
| Neck | [[item:251234@BgQAAwQACKQQBA]] | Voidscar Arena |
| Shoulder | [[item:251146@BgQAAwQACKQQBA]] | Den of Nalorakk |
| Cloak | [[item:159288@BgQAAwQACKQQBA]] | Kings' Rest |
| Chest | [[item:251226@BgQAAwQACKQQBA]] | Voidscar Arena |
| Wrist | [[item:159300@BgQAAwQACKQQBA]] | Kings' Rest |
| Gloves | [[item:193758@BgQAAwQACKQQBA]] | Ruby Life Pools |
| Belt | [[item:251189@BgQAAwQACKQQBA]] | The Blinding Vale |
| Legs | [[item:251198@BgQAAwQACKQQBA]] | The Blinding Vale |
| Boots | [[item:159304@BgQAAwQACKQQBA]] | Kings' Rest |
| Ring 1 | [[item:251148@BgQAAwQACKQQBA]] | Den of Nalorakk |
| Ring 2 | [[item:251136@BgQAAwQACKQQBA]] | Murder Row |
| Trinket 1 | [[item:250244@BgQAAwQACKQQBA]] | Den of Nalorakk |
| Trinket 2 | [[item:250228@BgQAAwQACKQQBA]] | Murder Row |
| Weapon | [[item:251192@BgQAAwQACKQQBA]] | The Blinding Vale |

### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons, Raids and Delves. Do note that some trinkets are better than others depending on the mythic+ dungeon. In addition trinkets that are meant for DPS specialisations are nerfed by 33% but still provide better damage than tank specific trinkets.

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270175@BgQAAwQA5IAWBA]]  <br>[[item:270174@BgQAAwQA5IgTBA]] |
| **A-Tier** | [[item:270160@BgQAAwQA5IgTBA]]  <br>[[item:270173@BgQAAwQACKAWBA]]  <br>[[item:250244@BgQAAwQACKgTBA]]  <br>[[item:250215@BgQAAwQACKgTBA]]  <br>[[item:250228@BgQAAwQACKgTBA]] |
| **B-Tier** | [[item:270164@BgQAAwQA5IgTBA]]  <br>[[item:250243@BgQAAwQACKgTBA]]  <br>[[item:159617@BgQAAwQACKgTBA]]  <br>[[item:159618@BgQAAwQACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAwQACKgTBA]]  <br>[[item:250259@BgQAAwQACKgTBA]]  <br>[[item:250214@BgQAAwQACKgTBA]]  <br>[[item:193757@BgQAAwQACKgTBA]] |
| **Junkyard** | [[item:270165@BgQAAwQA5IgTBA]]  <br>[[item:250245@BgQAAwQACKgTBA]]  <br>[[item:250225@BgQAAwQACKgTBA]] |

### Embellishments

- [[item:251513@DiQAAwQA1j74Qrzt1sUA]]
  
  - Nice passive secondary stat buff.
- [[item:251489@BAAAAwQA]]
  
  - Doubles the stats all your gems provide and can be put on any item.

#### Remaining Sparks

- Crafted items are 331 item level and regular items are 334 on max item level, therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear on that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241326]]
- **Food**
  
  - [[item:266996]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stones**
  
  - [[item:243734]]
- **Augment Rune**
  
  - [[item:259085@AQAAAoF]]
- **Sockets**
  
  - [[item:240983]] *-- Unique, can only be used once.*
  - [[item:240914]]
  - [[item:240910]]

### Enchantments

:::columns
:::column
| Head | [[item:243949@DAAAAwQAZbAB]]  <br>[[item:275707@BAAAAwQA]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAwQA]] |
| Belt | [[item:275707@BAAAAwQA]] |
| Legs | [[item:244641@BAAAAwQA]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244017@BAAAAwQA]] |
| Ring 2 | [[item:244017@BAAAAwQA]] |
| Weapon | [[item:244029@BAAAAwQA]] |

:::

:::column
:::gear **Brewmaster Monk** Mythic+
```json
{
  "source_code": "IQFZMEQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAB1jbCYgS94OAAAAAAB0TuDA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:243957]] |  |
| 戒指二 | [[item:243957]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy ‍[[item:275707@BAAAAwQA]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Brewmaster Monk** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- Dwarf
  
  - Is very valuable because you can dispel yourself or remove dangerous bleed effects.
  - On top of that using Stoneform gives you 10% physical DR which can be used as a small extra 8 second personal when tanking.
  - Use-case examples:
    
    - **Kyrakka and Erkhart Stormvein (Ruby Life Pools) - [[spell:381512]]**
    - **Zaen Bladesorrow (Murder Row) - [[spell:1222795]]**
    - **Ziekket (The Blinding Vale) - [[spell:1247685]]**
- [[spell:58984]] -- Night Elf
  
  - Can be very useful when doing any kind of skip in Mythic+
  - Run past basically any mob and then cast [[spell:58984]] to make them reset. Even works on mobs that have stealth detection if you get enough distance before you [[spell:58984]]
- [[spell:69070]] -- Goblin
  
  - Do a small jump in the direction your character is facing.
  - While you're in the [[spell:69070]] animation you are placed on a global cooldown until your character lands.
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.
- [[spell:256948]] -- Void Elf
  
  - Spawn a shadow traveling into your facing direction, and activate again to teleport to the rift.
  - Maximum range of 100 yards.

### Recommendation

As a tank picking a racial for damage is most of the times such a small gain that it's not worth it. If you care about min-maxing your DPS go with the highest DPS racial.

That being said the recommended race for Mythic+ is either **Night Elf** or **Dwarf** both offer unique features one being more tactical with Night Elf skips and the other being more reliable when it comes to your survivability.

## Macros

Discover recommended macros for **Brewmaster Monk** for Mythic+ and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
Taunt Macro --- *This macro either casts [[spell:115546]]* at your target or your mouseover (very handy to pick up mobs)

```wow-macro
#showtooltip Provoke
/cast [@mouseover,exists,harm][@target,exists,harm] Provoke
```

Boss 1 Taunt --- *Casts* [[spell:115546]] on Boss1

```wow-macro
/cast [@boss1] Provoke
```

Boss 2 Taunt --- *Casts* [[spell:115546]] on Boss2

```wow-macro
/cast [@boss2] Provoke
```

:::

:::details Mouseover Macros
[[spell:116841]] --- *This macro either casts [[spell:116841]] at your target or your mouseover*

```wow-macro
#showtooltip Tiger's Lust
/cast [@mouseover,exists,noharm][@target,exists,noharm] Tiger's Lust
```

[[spell:115078]] --- *Casts [[spell:115078]]* at your mouseover target

```wow-macro
/show tooltip
/use [@mouseover] Paralysis
```

Mouseover Focus --- *This macro sets your mouseover as your focus*

```wow-macro
/focus [@mouseover]
```

:::

:::details Focus Macros
[[spell:115078]] --- *Casts [[spell:115078]]* at your focus target

```wow-macro
/show tooltip
/use [@focus] Paralysis
```

Focus [[spell:116705]] --- *Casts [[spell:116705]]* at your focus target

```wow-macro
#showtooltip Spear Hand Strike
/cast [@focus,harm,nodead][] Spear Hand Strike
```

:::

:::details Utility Macros
[[spell:116844]] Cursor --- *Casts [[spell:116844]]* *at your cursor position without confirmation.*

```wow-macro
/cast [@cursor] Ring of Peace
```

**All-In-One Potion --** *all the different damage [[item:191383]]*, *uses [[item:191374]]* *if you're dead.*

```wow-macro
/use item:191383
/use [@player,nodead] item:191914
/use item:191382
/use item:191914
/use [@player,nodead] item:191389
/use [@player,nodead] item:191388
/use [@player,nodead] item:191387
/use [@player,dead]Residual Neural Channeling Agent
```

Cancelaura BoP --- *This cancelaura's [[spell:1022]] on you, very useful to have when playing with a paladin*.

```wow-macro
/cancelaura Blessing of Protection
```

:::

:::

## Addons

Below, you see a screenshot of the author's User Interface for their **Brewmaster Monk**, outlining which addons are used and how they are utilized in Mythic+ to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/Monk-M-Interface-1024x606.jpeg>)

**Brewmaster Monk** Interface in Mythic +

:::accordion
:::details Addons
- **ElvUI *-- Full User Interface replacement*** 
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
  - Alternatively, you can also use Shadowed Unit Frames (SUF) and an action bar addon of your choice or of course the stock UI.
- **LittleWigs *-- Generic Boss Mod*** 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.
- **Plater** -- Advanced Nameplates
  
  - Plater is a nameplate addon with an extraordinary amount of settings, out of the box debuff tracking, threat coloring and a lot of customization options.
- **Details** -- In-depth Damage Meter
  
  - Makes your damage meter look more handsome.
- **MPlusTimer** -- Used to be a Weakaura, now it is an addon to skin your Mythic+ timer
  
  - Makes your Mythic+ timer look more compact and visualises information cleaner.
  - Alternatively, you can also use the addon with almost the exact same name "MythicPlusTimer", it really is just personal preference.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
#### Monk

- Chi Transfer now causes Touch of Death to heal you for 60% of damage it deals (was 50%).
- Vigorous Expulsion increases Expel Harm's healing by 6% (was 5%).
- Silent Sanctuary healing increased by 25%.

#### Brewmaster

- Stagger reduction from Staggering Strikes increased by 25%.
- Spirit of the Ox chance to generate a healing sphere increased by 20%.
- Celestial Brew and Celestial Infusion absorb increased by 150% and cooldown increased by 100%.
- Awakening Spirit's maximum absorb value increased by 25%.
- Vital Flame heals for 50% of Fire or Nature damage dealt (was 40%).
- The following buffs are now tracked in the Cooldown Manager: Fuel on the Fire, Hot Potato, Scorched, Crackling Jade Lightning, and August Blessing.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
A: Using defensives incorrectly and not managing [[spell:115069]] properly. Make sure to read the **Deep Dive** for more info!

:::

:::

---

### Credits

Written By: **Skövte**

Reviewed by: **Tief**

---

:::changelog 更新记录
**2026-08-11** Updated for Patch 12.1

**2026-06-16** Updated for Patch 12.0.7

**2026-04-21** Updated for Patch 12.0.5

**2026-02-26** Updated for Patch 12.0.1

**2026-01-20** Updated for Midnight 12.0

**2025-12-02** Updated for Patch 11.2.7

**2025-10-07** Updated for Patch 11.2.5

**2025-08-05** Updated for Patch 11.2



:::
