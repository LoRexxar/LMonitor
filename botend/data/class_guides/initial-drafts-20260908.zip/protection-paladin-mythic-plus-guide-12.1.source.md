Welcome to the **Protection Paladin** Mythic+ guide for the World of Warcraft patch 12.1! This guide covers everything you need to know to understand your character! Are you starting out and leveling up from 80? Check out the leveling guide!

## Overview

:::columns
:::column
:::rating Mythic+
**Single-Target** · 3/5 · Average

AoE · 4/5 · Strong

Utility · 5/5 · Excellent

Survivability · 4/5 · Strong

Mobility · 3/5 · Average



:::

:::

:::column
:::gear **Protection Paladin Mythic+ Best in Slot**
```json
{
  "source_code": "JQpAgLEA3_fABkGJEIICFAw74OwVtOggC4UAKX6ABk-FEAQEBAg_sOg_sOAj1kjAYFQAnRCBCgQBAUTuDEgJU0bpDEAbkUgEAkQASgCWB47FEEw4XQAgIUAOAIYAzAjBmQgAQEAAhu7AWYTOBEBdEE6AGgQAAUXZDciqD8QuDcbNLFQAKE6AEiQAAYBwBUBB-zaCVQmakQAAIUAACKgTB4U1DEg6XQgAJEAAvk7A-XAlBgBDBMubCYUFAQBVfQAAIEQB5QQAV1BDE09FNgBKYFQAxeBBCgQAA0TC5ySAkeBBAgQAAIoAOFA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271465]] | [[item:240983]] · [[item:243951]] |
| 项链 | [[item:268265]] | [[item:240894]] · [[item:240894]] |
| 肩部 | [[item:271463]] | [[item:244021]] |
| 胸部 | [[item:271468]] | [[item:243977]] |
| 腰部 | [[item:268259]] | [[item:240894]] |
| 腿部 | [[item:271878]] | [[item:244641]] |
| 脚部 | [[item:237828]] | [[item:222581]] · [[item:240167]] · [[item:243983]] |
| 腕部 | [[item:237834]] | [[item:240894]] · [[item:245782]] · [[item:240167]] |
| 手部 | [[item:271466]] |  |
| 戒指一 | [[item:268266]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 戒指二 | [[item:159459]] | [[item:240894]] · [[item:240894]] · [[item:244015]] |
| 饰品一 | [[item:270164]] |  |
| 饰品二 | [[item:270165]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268209]] | [[item:244029]] |
| 副手 | [[item:268196]] |  |
:::

:::

:::

## Midnight changes

### Apex Talents

:::columns
:::column
**Apex talents** are a new feature in Midnight that extend each Spec Talent Tree. You can allocate 4 talent points to reap the full benefits of these special talents.

- The first talent point unlocks Rank 1.
- The second and third talent point unlocks and enhances Rank 2.
- The fourth point unlocks Rank 3 of the **Apex Talent**.

As **Protection Paladin**, you have access to Glory of the Vanguard, which gives [[spell:275779]] a chance to grant [[spell:1268810]], that empowers your next [[talent:102471]] to deal additional AOE damage in a line between you and your target.

**Rank 2** increases damage done by [[spell:275779]] and makes consuming [[spell:1268810]] generate Holy Power. While **Rank 3** makes [[spell:53600]] deal more damage after consuming [[spell:1268810]], and causes [[talent:102471]] to always benefit from [[spell:1268810]] during [[talent:102448@FJQA41dBCEA]].

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-protpala-mxr.webp>)

Glory of the Vanguard

:::

:::

### Core Changes

Following you receive a list of meaningful class changes going from The War Within into Midnight to keep you updated. For a more detailed look at **all** changes, check out our **Changes This Patch** section.

- **Spec Tree**
  
  - [[spell:76671@FJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEA]] 
    
    - Does not provide damage reduction while standing in your [[spell:26573]] anymore, which allows you to move more freely. The only incentives to stay in [[spell:26573]] now are keeping the mobs in it for AOE damage, and 5% damage reduction from [[talent:102436]], which are not as crucial as damage reduction from [[spell:76671@FJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEA]] used to be.
    - Now allows you to block spells baseline. Basically includes the effect of [[spell:152261]], which was removed.
  
  
  
  - [[spell:1246481]]
    
    - Grants [[talent:102456]] a second charge. With other class changes that make defensive cooldowns more sparse, this talent is mandatory in any challenging content.
  - [[spell:1246488]]
    
    - New talent that makes your [[spell:275779]] chain to 2 additional targets for 50% damage.
- **Class Tree**
  
  - [[spell:1241288]]
    
    - Instead of being a separate spell, it now passively empowers [[spell:275779]] during [[talent:102448]] to deal more damage. Additionally, [[spell:1241958]] increases the damage done based on your target's missing health.
  - [[spell:1241945]]
    
    - Now reduces damage taken by up to 10%, increasing with your missing health.
  - [[spell:183416]]
    
    - Redirects 5% damage taken by your allies to you while you're above 85% HP, instead of boosting your holy power spending abilities
- Removed
  
  - Resolute Defender
    
    - Was reducing cooldown of [[talent:102445]] and [[spell:642]] when spending Holy Power.
    
    
    
    - Together with [[spell:204074]] rework, this results in the complete removal of the cooldown reduction aspect of Protection Paladin gameplay. All defensive and offensive cooldowns are now static, making their usage more predictable and easier to plan around.
  - [[spell:387174]]
    
    - Removes a short defensive cooldown from our toolkit.
  - [[spell:378974]] and [[spell:327193]]
    
    - These were almost always used on cooldown without greatly altering the rotation, resulting in 2 fire-and-forget buttons that did not make the rotation much more interesting.
  - [[spell:385724]] and [[spell:379043]] 
    
    - These changes remove the gameplay around maintaining 100% spell block chance for big magic hits.

## Hero Talents

- Both [[talent:123361]] and [[talent:123358]] are very competitive choices, with [[talent:123361]] having higher DPS output. Therefore, for Mythic+ as a Protection Paladin, we recommend [[talent:123361]].



### [[talent:123361]]

- As [[talent:123361]] you receive [[talent:117882]], which alternates between:
  
  - [[spell:432459]]: An absorb shield for 15% your maximum health, gaining an additional 2% absorb every 2 seconds for 20 seconds.
  - [[spell:432472]]: A damaging buff that has a chance to deal Holy damage to nearby enemies and lasts 20 seconds. The effect is increased on single-target and reduced when striking more than 5 targets.
- [[talent:117882]] has 2 charges and rotates from [[spell:432459]] to [[spell:432472]].
  
  - Both armaments can be cast on yourself or an ally. With [[talent:117873]], casting it on an ally also grants you the effect, and vice versa.
- [[talent:117875]]:
  
  - Activating [[spell:31884]] summons an additional [[spell:432472]].
  - This additional [[spell:432472]] deals extra damage by echoing your Holy Power abilities.
  - This makes [[spell:31884]] an even stronger cooldown.
- [[talent:117877]] can randomly trigger a [[talent:117882]] effect on a nearby ally.
- [[talent:117883]] increases the damage of [[talent:102430]] / [[talent:102431]] by 100% after casting a Holy Power ability.
- [[talent:117881]] is a buff to armor and primary stat that replaces weapon oils.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:136000]] makes your next 3 abilities after casting [[talent:117882]] summon a lesser version of it.
- [[talent:136002@AJgABA]] makes [[talent:136496@FJQAEdhACEA]] also trigger [[talent:136001@AJgABA]].
- [[talent:117887@AJgABA]] gives you a chance to gain [[talent:102453]] whenever your [[talent:117882]] absorb or do damage.




### [[talent:123358]]

- After casting [[talent:136496@FJQAEdhACEA]], it is replaced with [[spell:427453]] for 12 seconds. 
  
  - [[spell:427453]] costs 3 Holy Power and deals high AoE damage.
  
  
  
  - You should cast [[talent:136496@FJQAEdhACEA]] and then use [[spell:427453]] on cooldown.
- [[talent:117823]] triggers an [[spell:431398]] on a nearby target every 2 seconds, for 8 seconds after using [[spell:427453]].
- [[talent:117811@FAQAEdhA]] extends [[talent:117823]] by 1 second every time you cast:
  
  - [[talent:102430]] / [[talent:102431]]
  - [[spell:275779]] or [[talent:133481@AJgABA]]
- [[talent:117818@FAQAEdhA]] causes your [[spell:53600]] and [[spell:85673]] to call down an [[spell:431398]] on a nearby target. While [[talent:117823]] is active, this effect calls down **an additional** [[spell:431398]].
- [[talent:117815]] allows you to cast [[spell:427453]] for free after triggering [[spell:431398]] 60 times.
- [[talent:117822@FAQAEdhA]] makes [[spell:427453]] to:
  
  - Give you 12% haste for 6 seconds.
  - Grant [[spell:53600]].
  - Place a [[spell:26573]] under your target.
- [[talent:117810]] causes [[spell:431398]] critical strikes to cleave to another target and grants you 5% damage reduction for 8 seconds against affected mobs. This effect significantly increases the value of critical strike in cleave and AoE situations.
- [[talent:117858]] fixes a lot of mobility issues for Protection Paladin by providing a 2-second longer [[talent:102625]] and increasing your movement speed by an additional 30% for the first 3 seconds.

Patch 12.0 introduces 3 additional Hero Talents.

- [[talent:136005]] makes [[talent:136496@FJQAEdhACEA]] summon Divine Hammers that deal AOE damage around you for 8 seconds.
- [[talent:136004@FAQAEdhA]] makes your [[spell:431398]] to do increased critical strike damage and grant an additional stack of [[talent:117815@FAQAEdhA]] when it crits.
- A new choice node:
  
  - [[talent:136003]] makes [[talent:136003]] to be cast 2 additional times on your target.
  - [[talent:136184@FAQAEdhA]] increases [[spell:275779]] damage by 30%.





## Talents



### [[talent:123361]] Build

:::talents **Protection Paladin** M+ [[talent:123361]] Build
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### When to use this spec

This is the default build for Mythic+. You have to adjust the class talent tree based on the utility needed for the encounter. To make your life easier, dungeon-specific talent loadouts are available in the Dungeon section.

#### Gameplay Altering Talents

Discover all talents that significantly alter your gameplay within the Spec and Class Talent trees. This section provides a concise overview of these talents and their applications. For a more detailed look, check out the Rotation and Deep Dive sections below.

##### Spec Tree

- [[spell:204074]]
  
  - Reduces cooldown of [[talent:102448@FJgA41dBACNACEA]] by 50% and its duration by 40%, making it a 1-minute cooldown.
- [[spell:204018]]
  
  - Used to completely immune magic damage and prevent debuff applications on yourself or your allies.
- [[talent:102466]]
  
  - Grants [[talent:102456]] an additional charge.
- [[talent:102454]]
  
  - Enables [[spell:53600]] to consume up to 2 more Holy Power, increasing its damage done by 50% for each extra Holy Power.
- [[spell:182104]]
  
  - Makes your [[spell:85673]] free after 3 [[spell:53600]] casts, stacking up to 2 free uses.

##### Class Tree

- [[talent:102596]]
  
  - Allows the use of [[spell:642]] even when you have [[spell:25771]] debuff.

- [[talent:102603@FAQAqxH]]
  
  - Significantly increases uptime on your strongest defensive cooldowns - [[spell:31850]] and [[spell:642]].
- [[talent:136503]]
  
  - Casts a free [[spell:85673]] at 60% effectiveness when dropping below 25% health. This effect has a 1-minute cooldown.
- [[spell:223817]]
  
  - Holy Power spenders have a chance to make your next [[spell:85673]] or [[spell:53600]] free and deal 15% increased damage and healing.
- [[talent:102465@FJQAEdhACEA]]
  
  - Casts [[talent:102471]] on up to 5 targets, generating 1 Holy Power for every target hit.
  - Instantly casts an [[talent:102471]] every 5 seconds for 15 seconds via [[spell:384027]] (if talented).
  - Powerful burst for AoE threat, Holy Power generation, and utility.




### [[talent:123358]] Build

:::talents **Protection Paladin** M+ [[talent:123358]] **Build**
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzM2sswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzM2sswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### When to use this spec

This is the [[talent:123358]] version of the Mythic+ build. Use it if you prefer [[talent:123358]] playstyle.





## Rotation

### Tier Set

Check out all the [**Midnight Season 2 Tier Sets**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)!

- **2-Set:** [[spell:26573]] is 30% larger and enemies within your [[spell:26573]] are illuminated, increasing the chance for your abilities to critically strike them by 5%.
- **4-Set:** Enemies struck by [[spell:20271]] or [[spell:204019]] take 20% additional Holy damage. If they are struck by a critical strike, the additional damage is increased by 100%.

### Opener

- The goal of your opener as a **Protection Paladin** in Mythic+ is to get aggro of all enemies as fast as possible by doing burst AoE damage early on, while also generating and spending as much Holy Power as possible.



#### [[talent:123361]]

:::rotation **Protection Paladin** [[talent:123361]] Opener in Mythic+
```json
{
  "source_code": "IAcAQpgQLlpBAAACQJXZtAVdsxGAC18ZA0BEw7kAB0prDAAAAAgQMyHAFJwEWBVAN1ZA_tSAEdhAIgnAOunA0SGARINBTnNBsEQBMlTBbHNBXRWBWoXBM0wBP0wBkCcB41dBo3yECEgQT7FAFoEPYsbBAAAABIEYRDAAAI0v8FQFR4AAT3AJEMPHBYnVWAALAI00eBAAAAQACBW0"
}
```
1. [[spell:432459]] Pre-Pull
2. [[spell:26573]] Pre-Pull [[item:241309]] · [[spell:31884]]
3. [[spell:24275]]
4. [[spell:375576]]  [[spell:53600]]
5. [[spell:31935]]  [[spell:53600]]
6. [[spell:24275]]
7. [[spell:204019]]  [[spell:53600]]
8. [[spell:24275]]
9. [[spell:204019]]
10. [[spell:24275]]  [[spell:53600]]
:::

- Important thing to note when using [[spell:432472]] is that it cannot stack. This means that the [[spell:432472]] that spawns from [[spell:31884]] should be used first, and the normal cast one used later after the first one has run out. 
  
  - This can also occur with [[talent:117877]], so be careful and make sure you track this buff well.
  
  
  
  - Other than the above, use [[talent:117882]] off cooldown.




#### [[talent:123358]]

:::rotation **Protection Paladin** [[talent:123358]] Opener in Mythic+
```json
{
  "source_code": "IIaAwzGCC18ZAAAAIAlcl1CU1xGbCEQnuOAAAAAACxIfAUkATYFUB0UnB83KBQ0FCgAeC44eCQLZAEh0EMd2EwSAFwUOFsd0EcFZFYheFwQDH8QDHQKwFgX3FgeLTIQAChxuFAAAAEgQgFNAAAgQ_yHAFgFC9WoBFgABT7VAHQQAClgHEMPHJYXCWwCACNPHDAAAAEgQgFN"
}
```
1. [[spell:26573]] Pre-Pull [[item:241309]] · [[spell:31884]]
2. [[spell:375576]]  [[spell:53600]]
3. [[spell:31935]]
4. [[spell:427453]]
5. [[spell:24275]]  [[spell:53600]]
6. [[spell:204019]]
7. [[spell:24275]]
8. [[spell:204019]]  [[spell:53600]]
:::

- Cast [[talent:136496@FJQAEdhACEA]] on cooldown to be able to cast [[spell:427453]] as often as possible and keep high uptime on [[talent:117823]].





### Priority List



#### [[talent:123361]]

1. Use [[spell:31884]] with [[spell:375576]] on cooldown.
2. Use [[spell:53600]] at 3-5 Holy Power.
3. Use [[spell:31935]] during [[spell:31884]] or with a [[spell:1268810]] proc under 3 Holy Power.
4. Use [[spell:20271]] if you have 2 charges.
5. Consume 5 [[talent:117884]] stacks with [[spell:26573]].
6. Use [[spell:432472]] if the remaining cooldown on [[spell:31884]] is more than 20 seconds, and you don't already have a [[spell:432472]] active.
7. Use [[spell:204019]] at 3 stacks.
8. Use [[spell:31935]].
9. Use [[spell:26573]].
10. Use [[spell:20271]].
11. Use [[spell:204019]] as filler.




#### [[talent:123358]]

1. Use [[spell:31884]] with [[spell:375576]] on cooldown.
2. Use [[spell:427453]] if you do not already have [[talent:117822@FAQAEdhA]] buff.
3. Use [[spell:53600]] at 3-5 Holy Power.
4. Use [[spell:31935]] during [[spell:31884]] or with a [[spell:1268810]] proc under 3 Holy Power.
5. Use [[spell:20271]] if you have 2 charges.
6. Use [[talent:102431]] if you have 3 charges.
7. Use [[spell:31935]].
8. Use [[spell:26573]].
9. Use [[spell:20271]].
10. Use [[spell:204019]].





### Defensive Cooldowns

- [[spell:31850]]
  
  - Your primary defensive cooldown.
  
  
  
  - Includes a cheat death component, allowing survival against extreme hits.
- [[spell:86659]]
  
  - The biggest damage reduction ability in your toolkit.
  - Has 2 charges with [[talent:102466]].
- [[spell:204018]]
  
  - Grants immunity to magic damage and prevents the application of magic debuffs.
  
  
  
  - Can be used for yourself or for other players.
  - Does not cause you to lose threat while active, unlike [[spell:1022]].
- [[spell:642]]
  
  - If used appropriately, this is the most powerful defensive ability that allows you to be completely immune to some mechanics. For more details, check out the **Deep Dive**.
  - [[spell:204077]] allows you to keep threat of nearby enemies while [[spell:642]] is active.

## Deep Dive

### Utilizing Blessing of Protection and Blessing of Spellwarding

- Properly utilizing [[spell:1022]] and [[spell:204018]] allows you to **immune** dangerous mechanics entirely, even if they are not targeted at you.
- Both [[spell:1022]] and [[spell:204018]] share a cooldown.
- [[spell:1022]] can be used to make a player that is fixated by enemies immune to physical damage, allowing them to maintain uptime on the boss and focus on DPS or healing instead of kiting.
- It removes existing physical debuffs (e.g., bleeds) and stuns, and prevents new ones from being applied.
- [[spell:204018]], on the other hand, does not remove existing magical debuffs — it only prevents new ones from being applied while active.
- Clever use of [[spell:204018]] or [[spell:1022]] can save your teammates, often preventing wipes.
- Note that [[spell:1022]] causes threat loss for its duration. [[spell:204018]] does not have the same effect, so you can safely use it on yourself while actively tanking.

### Using Hand of Reckoning with Divine Shield and Blessing of Protection

- Using [[spell:62124]] right before or during the effect of [[spell:642]] or [[spell:1022]] allows you to keep threat of your target for the duration of [[spell:62124]].
- This leads to you being immune - **fully** in case of [[spell:642]], or against **physical damage** in case of [[spell:1022]] - while still tanking the boss. It allows you to achieve the effect of [[talent:102473]] on a single target without the need of talenting into it, but only for 3 seconds.
- In most typical boss fights, these 3 seconds are enough to cheese tank mechanics - for example, immune bursty tank hits or avoid tank debuff applications.
- To safely achieve this effect:
  
  1. Briefly before the tank mechanic (less than 3 seconds), use [[spell:62124]] on the boss.
  2. Use [[spell:642]] or [[spell:1022]]  on yourself.
  3. Wait for the boss to cast the mechanic you want to immune.
  4. Cancel [[spell:642]] or [[spell:1022]] before the effect of [[spell:62124]] expires using a following macro:

```wow-macro
/cancelaura Blessing of Protection  
/cancelaura Divine Shield
```

- Keep in mind that [[spell:1022]] will only immune **purely physical hits**. It will only negate the **physical part** of the damage on mechanics of mixed type, and will **not** work at all against magic damage.
- Note that you will only keep threat on the target affected by your [[spell:62124]], which makes this technique only applicable on single-target encounters.

### Understanding Mechanics

Rotational min-maxing is just one aspect of mastering a specialization, but there are numerous other key mechanics that influence your performance. Use the following guides to improve them.

- [Pandemic](<https://maxroll.gg/wow/resources/pandemic>)
- [Spell Queue Window](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [Stat Diminishing Returns](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## Dungeons

**← Scroll for more Dungeons→**



### Altar of Fangs

:::talents **Protection Paladin** Mythic+ Altar of Fangs
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### Rav'i

- There are 3 Carrion Piles spread in the room, make sure to move the boss before he reaches 0% energy towards one of the three Carrion Piles that is not glowing red so he can [[spell:1296216]] in them.
- While [[spell:1296216]] look out for [[spell:1307703]] on the ground and soak them if needed.

##### The Writhing Coil

- The boss will cast [[spell:1298949]] at you, which deals physical damage and knocks you slightly back.
- Interrupt [[spell:1310358]].
- During [[spell:1299053]] run away from the boss as fast and far as possible.

##### Zul'jan

- Whenever the boss casts [[spell:1300872]] make sure to stand in between him and [[spell:1300894]] to soak it.
- Dodge any axes spawned by [[spell:1283832]].
- [[spell:1301350]] is a quick 0.5 second cast which deals physical damage and is the tank buster of the fight.
- When a teammate is targeted by [[spell:1301413]], move into the line between the boss and the targeted player. This reduces the damage your teammate takes.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294557]] - Primal Serpent
  - [[spell:1307567]] - Ula'tek's Chosen

- Pay extra attention to these casts:
  
  - [[spell:1306911]] - Ritual Chieftain
  - [[spell:1294845]] - Rattling Writhe
  - [[spell:1294934]] - Ascendant Serpent




### Den of Nalorakk

:::talents **Protection Paladin** Mythic+ Den of Nalorakk
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### The Hoardmonger

- Whenever the boss casts [[spell:1234233]] he will summon [[spell:1234740]] on the ground, make sure to help your group soak them.

##### Sentinal of Winter

- After the boss has casted [[spell:1235783]], drag him on top of a summoned add and kick [[spell:1235829]].

##### Nalorakk

- When the boss begins casting [[spell:1243569]], make sure you are standing in the [[spell:1243856]] provided by Zul'jarra. Once the cast finishes, the boss will immediately follow up with [[spell:1297797]], creating a large circle in front of him. As the tank, move into the circle to soak the hit.
- During [[spell:1243002]], run towards any Echo of Nalorakk that tries to reach Zul'jarra to stop it from reaching her by touching it with your character.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1297696]] - Earthwhisper Tender
  - [[spell:1309919]] - Frigid Mauler
  - [[spell:263607]] - Stormbound Mystic
  - [[spell:9532]] - Loa Speaker Nanea

- Pay extra attention to these casts:
  
  - [[spell:1238687]] - Spirit of Hunger




### Murder Row

:::talents **Protection Paladin** Mythic+ Murder Row
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### Kystia Manaheart

- Nibbles will cast a frontal cone [[spell:1253811]] on you, make sure to not aim this on top of your group, by the end of the cast you can also dodge it by running to the side.
- Kystia will occasionally cast multiple [[spell:1264095]] which cast [[spell:1264106]] that you can interrupt or stun to cancel their casts.

##### Zaen Bladesorrow

- The boss will cast [[spell:1222795]] at you, which deals physical damage and leaves a dot at you [[spell:474515]].
- When targeted by [[spell:474545]] try to hide behind barrels in the room.

##### Xathuux the Annihilator

- [[spell:1214781]] is the main tank buster mechanic of this fight, it is a frontal cone which you do not want to aim towards you group, it leaves debuff on you which reduces your healing taken by 80% for 8 sec.
- After [[spell:1214637]] try to tank the boss near his axe.
- During [[spell:1223533]] try to kite him alongside the edge of the room to minimize the spread of [[spell:474231]].

##### Lithiel Cinderfury

- The boss will use [[spell:1220899]] and you will need to kite this infernal for the entire duration of the fight.
- Interrupt [[spell:474375]] whenever possible.
- Grab threat on [[spell:474408]] whenever it is up.
- When the boss summons [[spell:1214675]] wait until it has also finished the cast [[spell:1217345]] before taking the gateway.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1216570]] - Felonious Mage
  - [[spell:1201554]] - Seductive Sayaad
  - [[spell:1214922]] - Wrathguard Flayer
  - [[spell:1214980]] - Fel Invoker

- Pay extra attention to these casts:
  
  - [[spell:1216529]] - Bribed Captain




### The Blinding Vale

:::talents **Protection Paladin** Mythic+ The Blinding Vale
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### Lightblossom Trinity

- Make sure to keep threat on all three bosses and position them together whenever possible to allow cleave and efficient damage since they all share the same healthpool.
- Meittik will cast [[spell:1234753]] at you, which is the main source of tank damage during the fight.
- Try to interrupt [[spell:1235616]] whenever possible, which is cast by Kezkitt.
- Kezkitt will also cast [[spell:1235564]], which requires you to stand inside one of the three Lightblossoms to soak the damage.

##### Ikuzz the Light Hunter

- Every time the boss casts [[spell:1236746]] make sure you don't get knocked into one of the roots on the ground. If you get knocked away from the group, make your way back quickly, as everyone will be rooted 4 seconds after the mechanic happens. You want to be stacked with the group so you can cleave down the roots as quickly as possible.

##### Lightwarden Ruia

- This boss has 3 different phases, he will always start in the Moonkin phase.
- In this phase you simply just kick [[spell:1239821]] and dodge [[spell:1239830]]'s created by [[spell:1239824]].
- In his next phase, the Bear form, his melee attacks become more dangerous due to [[spell:1272265]]. Also if targeted by [[spell:1240210]] make sure to not move too much so you and your teammates have an easier time dodging.
- The final phase starts at 40%, when the boss enters Haranir Form and channels [[spell:1241067]], casting all his abilities in a rapid flurry.

##### Ziekket

- Each time the boss casts [[spell:1246372]] he will summon adds beneath him, make sure to grab threat on those as quickly as possible.
- After [[spell:1246858]] the boss will have orbs coming towards him, soak these orbs and do not let any of them touch the boss.
- Additionally the boss will also use [[spell:1247685]] as tank buster mechanic this fight inflicting magic damage, knocking you back and leaving a bleed on you that deals physical damage every second for 10 seconds.
- When the adds die, you have to position the boss in a way that he will hit all of them with the [[spell:1246607]] ability that is targeted on you, completely removing that set of adds from the fight when they are getting it, if not getting hit, they will be revived the next time the boss casts [[spell:1246372]], alongside the newly summoned adds.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1301834]] - Radiant Spellsower
  - [[spell:1238294]] - Lightfeather Petalwing

- Pay extra attention to these casts:
  
  - [[spell:1237855]] - Virid Grovekeeper




### Voidscar Arena

:::talents **Protection Paladin** Mythic+ Voidscar Arena
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### Taz'Rah

- Whenever the boss casts [[spell:1296889]], make sure that you don't overlap your [[spell:1222098]] with others.
- He will also cast [[spell:1297017]] at you which deals huge magic damage and will knock you back.
- After every [[spell:1300259]] make sure to dodge orbs.

##### Atroxus

- [[spell:1222642]] is the tank buster mechanic of this fight, it deals magic damage and leaves a dot for 10 seconds which makes you suffer more magic damage.
- Each time the boss casts [[spell:1262497]] he will summon a Toxic Creeper which will fixate you, try to kite this Toxic Creeper alongside the boss for maximum amount of cleave.

##### Charonus

- The boss will cast [[spell:1311923]] at you, which is a 5 second long cast, try to not move too much with this so your teammates can dodge it.
- Ocassionally the boss will target one of your group members with [[spell:1222755]]. As the tank, your job is to position yourself between the boss and the targeted player, intercepting the projectiles before they can reach your teammate.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1299938]] - Voidtouched Magi
  - [[spell:1298899]] - Dominated Brawler
  - [[spell:1249621]] - Angry Krolusk
  - [[spell:1233398]] - Kilivore Screamer

- Pay extra attention to these casts:
  
  - [[spell:1300243]] - Devouring Brutalizer




### Kings' Rest

:::talents **Protection Paladin** Mythic+ Kings' Rest
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### The Golden Serpent

- The boss will hit you with [[spell:265910]] which deals physical damage.
- After the boss has casted [[spell:265923]] make sure to kite him if needed so adds do not reach him.

##### Mchimba the Embalmer

- Whenever the boss casts his main ability [[spell:267702]], watch out on the tombs as the sides of the room and click the one that is shaking since one of your party members will be inside of it.

##### The Council of Tribes

- Aka'ali the Conqueror will use [[spell:266237]] against use which knocks you back and makes you take 200% increased physical damage taken afterwards for 10 seconds.
- Help soaking [[spell:266939]] on your teammates.
- Interrupt [[spell:267273]] during the fight with Zanazal the Wise.
- After he has [[spell:267060]] try to move him on top of an explosive totem.

##### Dazar, The First King

- This boss can deal a lot of tank damage due to [[spell:268586]] and [[spell:1303267]] so make sure to use your defensive abilities.
- Dodge [[spell:1302945]] whenever possible throughout the encounter.
- While Reban is active, make sure to interrupt [[spell:269369]] whenever you can.
- T'zala will also start casting [[spell:1303488]] at you whenever he is active, adding another layer of tank damage in this fight.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1294815]] - Risen Hexer
  - [[spell:270920]] - Queen Wasi
  - [[spell:270901]] - Seneschal M'bara
  - [[spell:270492]] - Phantom Hex Priest

- Pay extra attention to these casts:
  
  - [[spell:1297918]] - King A'akul
  - [[spell:1302028]] - Ghostly Brute
  - [[spell:270514]] - Ghostly Brute
  - [[spell:1309385]] - Shadow of Zul




### Ruby Life Pools

:::talents **Protection Paladin** Mythic+ Ruby Life Pools
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### Melidrussa Chillworn

- The boss will cast [[spell:372808]] at you, which is an interruptable cast, so make sure to interrupt it on cooldown and press defensives if you or your teammates cannot interrupt.
- Occasionally the boss will also cast [[spell:396044]], after the cast has finished, move him away from the circles on the ground.
- At 66% and 33% health the boss will cast [[spell:373037]], make sure to grab threat of the spawned adds.

##### Kokia Blazehoof

- This bosses main tank mechanic is [[spell:372858]], which is a 3 second long cast.
- Make sure to tank the boss always next to a Blazebound Firestorm spawned by [[spell:372863]].

##### Kyrakka and Erkhart Stormvein

- With [[spell:381512]] the boss will apply a debuff to you which makes you take increased damage by the next [[spell:381512]] so make sure to communicate with your healer beforehand that he has to dispell you every time you get hit by this mechanic.
- Whenever the dragon Kyrakka has landed move out of [[spell:381525]].

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:372743]] - Flashfrost Chillweaver
  - [[spell:384197]] - Primalist Cinderweaver
  - [[spell:392576]] - Tempest Channeler

- Pay extra attention to these casts:
  
  - [[spell:372730]] - Primal Juggernaut
  - [[spell:372047]] - Defier Draghar
  - [[spell:392394]] - Flamegullet
  - [[spell:392395]] - Thunderhead




### Temple of Sethraliss

:::talents **Protection Paladin** Mythic+ Temple of Sethraliss
```json
{
  "source_code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB",
  "code": "CKEAo7SHLZA3aYychDLmrvpSftZsNLjZMzMzMLbjxYWmlhBAYAAAAAAQTzMLzMmZYMaDADMAD2AAAzMtNzsNzMzy2SLzMWsswMAGjZYMAYmZbGgZGwYB"
}
```
:::

#### Boss Tips

##### Adderis and Aspix

- Whenever Aspix casts [[spell:1310712]] make sure to not stack with your teammates.
- Adderis will focus on of your teammates with [[spell:1288049]], try help soaking this ability to split the damage and reduce the overall impact on the targeted teammate.
- He will also cast [[spell:1288428]] which makes him deal more melee damage for 8 seconds, use your defensive cooldowns if necessary.

##### Merektha

- The boss periodically casts [[spell:1290797]], a tank buster ability, it deals physical damage on hit and leaves a dot that ticks nature damage every second for 7 seconds.
- During [[spell:264206]], make sure to quickly establish threat on all summoned adds.

##### Galvazzt

- The only thing you have to do on this fight is to move the boss after every [[spell:1309525]] cast since it summons a [[spell:1291815]] beneath him.

##### Avatar of Sethraliss

- Make sure to grab threat of the Corrupted Guardians which ocassionally will cast [[spell:1300803]] at you. Additionally, you can also move him on top of the Essence Defiler.

#### Trash Tips

- Important abilities to interrupt in this dungeon are:
  
  - [[spell:1293307]] - Faithless Subjugator
  - [[spell:9532]] - Imbued Stormcaller
  - [[spell:13729]] - Twisted Hexxer

- Pay extra attention to these casts:
  
  - [[spell:1291468]] - Sandfury Stonefist
  - [[spell:1308546]] - Orb Watcher





### Affixes

- +2 Affix
  
  - Lindormi's Guidance
- +5 Affixes -- Rotates on a weekly basis
  
  - Xal'atath's Bargain: Ascendant
  - Xal'atath's Bargain: Voidbound
  
  
  
  - Xal'atath's Bargain: Devour
  - Xal'atath's Bargain: Pulsar
- +6 Affix
  
  - Lindormi's Guidance removed.
- +7 Affixes -- Alternates between each other on a weekly basis
  
  - Tyrannical
  - Fortified
- +10 Affixes *-- Both affixes are present.*
  
  - Tyrannical
  - Fortified
- +12 Affix
  
  - Xal'atath's Guile *-- Replaces the +5 Affix*

Following you get some useful tips for handling different Mythic+ Affixes as a **Protection Paladin**.

- Xal'atath's Bargain: Ascendant
  
  - [[talent:102584]] as many orbs as possible.
- Xal'atath's Bargain: Voidbound
  
  - The Void Emissary follows you; keep it close to cleave and target it whenever it's up.
- Xal'atath's Bargain: Devour
  
  - [[talent:102476]] yourself whenever its applied to yourself.

## Stat Priority

Understand your secondary stat priority and the tertiary stats needed for optimal performance during Dungeons as a **Protection Paladin**. For more detailed information, visit the **[Stats and Attributes](<https://maxroll.gg/wow/resources/stats-and-attributes>)** guide.

:::priority **Protection Paladin** Stats in M+
```json
{
  "source_code": "JoAJFQAJoASMBEwAEA"
}
```
**力量 ＞ 急速 ＞ 全能 ≥ 暴击 ≫ 精通**
:::

> **Higher Item level items are better in most scenarios. For an accurate representation of what item to equip you should use [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)! A static "Stat Priority" is just a starting point and can easily shift depending on your individual gear.**

All secondary stats are affected by **diminishing returns**. **[Click here](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** to learn more!

### Tertiary

- **Avoidance** - Great stat to reduce the damage intake of "**Area of Effect**" abilities.
- **Leech** - Provides additional healing through damage dealing.
- **Speed** -  Niche tertiary that can be very useful and has been proven useful in the past. This makes managing certain mechanics a lot easier.

In general, **Leech** is really strong for tanks in Mythic+. It can be by far the best stat you can have and allows you to ‍Word of Glory yourself less, which frees up more globals for other things and allows you to do more damage!

## Gear



### Best in Slot

| Slot | Item | Location |
| --- | --- | --- |
| Head | Convert [[item:239050@CiQAA8OuzVtOCKgTBA]] into [[item:271465@DiQBAIEAvj7cVrjgC4UAKX6A]] | Catalyst of Kings' Rest |
| Neck | [[item:268265@BERAAIEA-z64PrDj1kjAYFA]] | Ula'tek |
| Shoulder | Convert [[item:239037@DgQAAIEA1k7IoAOF]]  <br>into [[item:271463@DgQBAIEA1k7IoAOFQvlO]] | Catalyst of Temple of Sethraliss |
| Cloak | [[item:268253@BgQAAIEACKAWBA]] | The Coiled Altar |
| Chest | Convert [[item:268222@DgQAAIEAJk7IoAYF]]  <br>into [[item:271468@DgQBAIEAJk7IoAYFgvXQ]] | Catalyst of The Coiled Altar |
| Wrist | [[item:237834@FiQAAIEAWA8ciqj_sO3WzSB]] | Crafting |
| Gloves | Convert [[item:251214@BgQAAIEACKgTBA]]  <br>into [[item:271466@BgQBAIEACKgTB4U1DA]] | Catalyst of Den of Nalorakk |
| Belt | [[item:268259@BiQAAIEA-z6IoAYF]] | The Coiled Altar |
| Legs | [[item:271878@DARAAIEAhu7YhN5IAWB]] | Ula'tek |
| Boots | [[item:237828@HgQAAIEA1V2ciqzD5O3WzSB]] | Crafting |
| Ring 1 | [[item:268266@DkQAAIEAvk74Prj_sOCKgTB]] | Nymrissa Wavecaller |
| Ring 2 | [[item:159459@DkQAAIEAvk74Prj_sOCKgTB]] | Kings' Rest |
| Trinket 1 | [[item:270164@BgQAAIEACKgTBA]] | The Lost Explorers |
| Trinket 2 | [[item:270165@BgQAAIEACKgTBA]] | Entombed Sentinels |
| Weapon | [[item:268209@DgQAAIEA9k7IoAYF]] | The Coiled Altar |
| Shield | [[item:268196@BgQAAIEACKgTBA]] | The Lost Explorers |




### Farmable Alternatives

Below, you will find a good list of farmable alternatives available outside WoW’s weekly lockout system. While replaced in time as you progress, these offer immediate character power.

| Slot | Item | Location |
| --- | --- | --- |
| Head | [[item:239050@BgQAAIEACKQQBA]] | Kings' Rest |
| Neck | [[item:251173@BgQAAIEACKQQBA]] | Den Of Nalorakk |
| Shoulder | [[item:239037@BgQAAIEACKQQBA]] | Temple of Sethraliss |
| Cloak | [[item:193763@BgQAAIEACKQQBA]] | Ruby Life Pools |
| Chest | [[item:251193@BgQAAIEACKQQBA]] | The Blinding Vale |
| Wrist | [[item:159425@BgQAAIEACKQQBA]] | Temple of Sethraliss |
| Gloves | [[item:251214@BgQAAIEACKQQBA]] | Den of Nalorakk |
| Belt | [[item:159418@BgQAAIEACKQQBA]] | Kings' Rest |
| Legs | [[item:273776@BgQAAIEACKQQBA]] | Altar of Fangs |
| Boots | [[item:273777@BgQAAIEACKQQBA]] | Altar of Fangs |
| Ring 1 | [[item:159459@BgQAAIEACKQQBA]] | Kings' Rest |
| Ring 2 | [[item:273792@BgQAAIEACKQQBA]] | Altar of Fangs |
| Trinket 1 | [[item:158367@BgQAAIEACKQQBA]] | Temple of Sethraliss |
| Trinket 2 | [[item:250228@BgQAAIEACKQQBA]] | Murder Row |
| Weapon | [[item:251195@BgQAAIEACKQQBA]] | The Blinding Vale |
| Shield | [[item:159664@BgQAAIEACKQQBA]] | Temple of Sethraliss |





### Trinkets

Below is a ranking of endgame trinkets obtainable from Dungeons & Raids. Do note that the trinkets recommended above are for optimal damage; if you do not care about your damage and only want to survive, it is recommended to use a trinket like [[item:270160@BgQAAIEACKgTBA]].

| Rank | Trinkets |
| --- | --- |
| S-Tier | [[item:270164@BgQAAIEACKgTBA]] |
| **A-Tier** | [[item:270165@BgQAAIEACKgTBA]]  <br>[[item:158367@BgQAAIEACKgTBA]]  <br>[[item:270174@BgQAAIEACKgTBA]]  <br>[[item:270160@BgQAAIEACKgTBA]]  <br>[[item:250228@BgQAAIEACKgTBA]] |
| **B-Tier** | [[item:270175@BgQAAIEACKAWBA]]  <br>[[item:250243@BgQAAIEACKgTBA]]  <br>[[item:159618@BgQAAIEACKgTBA]]  <br>[[item:250229@BgQAAIEACKgTBA]]  <br>[[item:193762@BgQAAIEACKgTBA]] |
| **C-Tier** | [[item:273796@BgQAAIEACKgTBA]]  <br>[[item:270173@BgQAAIEACKAWBA]]  <br>[[item:270163@BgQAAIEACKgTBA]]  <br>[[item:273795@BgQAAIEACKgTBA]]  <br>[[item:250259@BgQAAIEACKgTBA]]  <br>[[item:250244@BgQAAIEACKgTBA]]  <br>[[item:193757@BgQAAIEACKgTBA]]  <br>[[item:270168@BgQAAIEACKgTBA]] |
| **Junkyard** | [[item:250245@BgQAAIEACKgTBA]]  <br>[[item:250238@BgQAAIEACKgTBA]]  <br>[[item:273797@BgQAAIEACKgTBA]] |

### Embellishments

- 2x [[item:240167]] is your best in slots option.
  
  - Random main stat proc for you and your teammates.
  - Preferably on Wrists and Boots; however, it can be crafted on any armor piece.

A good option for early season or if you don't have access to a 334 or 344 weapon is crafting a 331 weapon[[item:245876]] instead of an offpiece with [[item:240167]]. As soon as you get access to a 334 or 344 weapon, this option loses value compared to 2x [[item:240167]].

- [[item:245876]]
  
  - Passively gives secondary stats depending on the mob type you're fighting.
  - Has to be crafted on a weapon.

#### Remaining Sparks

- Crafted items are 331 item level, and regular items are 334 on max item level; therefore, it's a small loss to equip crafted items outside of your 2x Embellishments unless you don't have access to other high item level gear in that slot.

#### Simcraft

To find the best combination of gear available to you or identify the best possible upgrades, visit our **[Simcraft guide](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)** to learn how to utilize Simcraft easily and effectively.

## Consumables

- **Phials**
  
  - [[item:241324]]
- **Food**
  
  - [[item:255845]]
- **Combat Potion**
  
  - [[item:241308]]
- **Health Potion**
  
  - [[item:271884]]
- **Weapon Stone/Oil**
  
  - [[talent:117881]] *-- as [[talent:123361]]*
  - [[item:243734]]-- as [[talent:123358]]
- **Augment Rune**
  
  - [[item:259085@BQAAAIEAaB]]
- **Sockets**
  
  - [[item:240983]] *-- Unique, can only be used once*
  - [[item:240894]]
  - [[item:240916]]

### Enchantments

:::columns
:::column
| Head | [[item:243951]]  <br>[[item:275707@BAAAAIE]] |
| --- | --- |
| Shoulder | [[item:244021@BAAAAwQA]] |
| Chest | [[item:243977@BAAAAwQA]] |
| Wrist | [[item:275707@BAAAAIE]] |
| Belt | [[item:275707@BAAAAIE]] |
| Legs | [[item:244641@BAAAAIE]] |
| Boots | [[item:243983@BAAAAwQA]] |
| Ring 1 | [[item:244015@BAAAAIE]] |
| Ring 2 | [[item:244015@BAAAAIE]] |
| Weapon | [[item:244029@BAAAAIE]] |

:::

:::column
:::gear **Protection Paladin** **Mythic+**
```json
{
  "source_code": "IQFZCBQ9NCQA7TDBCAAAA8OuDEQN5OAAAAAABkQDIgw-0QQBQQQo7mAGA8gOYAAAv0AEo8SuDAAAAAQA9k7A"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243951]] |
| 肩部 | [[item:244021]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:243983]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:244029]] |  |
:::

:::

:::

> *You buy [[item:275707@BAAAAIE]] from the Great Vault Vendor to add sockets to your Helm, Wrists and Belt.*

## Races

For min-maxing a **Protection Paladin** in Mythic+ Dungeons, different racial traits can provide a tremendous benefit to your characters. If this is not your top goal, picking a race that fits your style works just as well.

- [[spell:65116]] -- ***Dwarf***
  
  - [[spell:59224]] gives 2% crit damage and healing, which is very strong for **Protection Paladin**.
  
  
  
  - Valuable due to the fact that you can dispel yourself or remove dangerous bleed effects.
  - Gives 10% physical DR which can be like a small extra personal as a tank for 8 seconds.
- [[spell:20549]] -- Tauren
  
  - Strong AoE stun that can be used as a stop that lasts for 2 seconds.
  - [[spell:154743]] gives 2% crit damage and healing
- [[spell:25046]] -- Blood Elf
  
  - Strong racial to dispel or purge enemies, the value is very limited but sometimes can come in handy.

### Recommendation

It is recommended to almost always play Dwarf since they are the overall strongest offensive (tied with Tauren) race, as well as being the strongest defensively because of **[[spell:65116]]** ability to remove nasty debuffs.

## Macros

Discover recommended macros for **Protection Paladin** for Mythic+ and watch a quick video guide on creating simple macros for your character.

[**Macro Import Guide Video**](<https://youtu.be/nULDJcZgsJw>)

:::accordion
:::details Taunt Macros
**Taunt at Mouseover** --- *Mouseover macro for [[spell:62124]] (Taunt) that allows you to get aggro easily from targets that just come into view or spawn without having to change target. If you have no mouseover it taunts your primary target.*

```wow-macro
#showtooltip
/cast [@mouseover,harm,nodead][]Hand of Reckoning
```

Boss 1 Taunt --- *Casts [[spell:62124]]* on Boss1

```wow-macro
/cast [@boss1] Hand of Reckoning
```

Boss 2 Taunt --- *Casts [[spell:62124]]* on Boss2

```wow-macro
/cast [@boss2] Hand of Reckoning
```

:::

:::details Mouseover Macros
**Blessing of Freedom Mouseover** --- *Mouseover macro for Blessing of Freedom to use on allies (do not use this on yourself as it's less efficient than the next macro)*

```wow-macro
#showtooltip
/cast [@mouseover] Blessing of Freedom
```

**Blessing of Sacrifice Mouseover**--- *Mouseover macro for Blessing of Sacrifice that allows you to external someone quickly.*

```wow-macro
#showtooltip
/cast [@mouseover] Blessing of Sacrifice
```

**[[spell:85673]] Mouseover** --- *Mouseover macro to use Word of Glory on allies, as with Blessing of Freedom, do not use this on yourself as it is less efficient.*

```wow-macro
#showtooltip Word of Glory
/cast [@mouseover] Word of Glory
```

**Lay on Hands Mouseover** --- *Mouseover macro to use Lay on Hands on allies.*

```wow-macro
#showtooltip Lay on Hands
/cast [@mouseover] Lay on Hands
```

**Cleanse Toxins Mouseover** --- *Mouseover macro to use dispell on allies.*

```wow-macro
#showtooltip Cleanse Toxins
/cast [@mouseover] Cleanse Toxins
```

:::

:::details Focus Macros
**Focus Target Macro --- *Sets a mouseovered target as your focus target***

```wow-macro
/focus [@mouseover,exists]
```

**Focus Interupt** --- *This macro casts "Rebuke" or interrupt on* your focus target. It also interrupts your main target if your focus target is out of range or if you do not have a focus target. Very solid macro for general use play.

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] Rebuke
```

**Focus [[spell:31935]]** --- *Macro that puts your [[spell:31935]] on focus target if you need to kick or silence your focus target*

```wow-macro
#showtooltip
/cast [@focus,harm,nodead][] Avenger's Shield
```

:::

:::details Utility Macros
**Cancelaura macro** --- *Here is a very important macro that you want to fill with any buff that is an immunity that you would need to cancel in a given scenario. For example; [[spell:642]] Taunt fails and doesn't taunt so you need to cancel [[spell:642]], or you used [[spell:1022]] to get rid of a debuff quickly and need to cancel so that you can continue being the primary aggro target before your allies are tanking instead.* In the case of [[spell:204018]], sometimes certain mobs fail to do their primary threat ability on the tank if you are protected by [[spell:204018]], although this is rare.

```wow-macro
/cancelaura Blessing of Protection
/cancelaura Blessing of Spellwarding
/cancelaura Divine Shield
```

:::

:::details Player Macros
[[spell:85673]] at Self--- *This macro casts [[spell:85673]] on yourself which is very efficient when you want to use [[spell:85673]] as a self heal. I recommend using two binds for [[spell:85673]], just like Blessing of Freedom.*

```wow-macro
#showtooltip Word of Glory
/cast [@player] Word of Glory
```

**Blessing of Freedom on Self** --- *This macro puts Blessing of Freedom on yourself instantly, which is more efficient in terms of pressing faster than if you used a mouseover macro for yourself. In general, it is good to have two binds for Blessing of Freedom, one for mouseover and one for player (self) as it is a lot more efficient.*

```wow-macro
#showtooltip Blessing of Freedom
/cast [@player] Blessing of Freedom
```

**Lay on Hands Self** --- *This macro you should use in order to use Lay on Hands as a "self heal".*

```wow-macro
#showtooltip
/cast [@player] Lay on Hands
```

**Cleanse Toxins Self** --- *This macro you should use for dispelling yourself as it is more efficient.*

```wow-macro
#showtooltip Cleanse Toxins
/cast [@player] Cleanse Toxins
```

:::

:::

## Addons

Below is a screenshot of the author's User Interface for **Protection Paladin**, outlining which addons are used and how they are used to make your life easier.

![](<https://assets-ng.maxroll.gg/wordpress/pala-1024x623.png>)

**Protection Paladin** Interface

:::accordion
:::details Addons
- EllesmereUI
  
  - A user interface designed around user-friendliness with extra features that are not included in the standard UI.
- **BigWigs** 
  
  - BigWigs is a boss encounter add-on. It consists of many individual encounter scripts, or boss modules; mini add-ons that are designed to trigger alert messages, timer bars, sounds, and so forth, for one specific Raid encounter.

:::

:::

## Changes this Patch

:::accordion
:::details Patch 12.1
- Class
  
  - Golden Path healing increased by 25%.
  - Lightforged Blessing healing increased by 25%.
  - Brought to Light healing increased by 25%.
- **[[talent:123361]]**
  
  - Rite of Adjuration healing increased by 25%.
  - Divine Guidance redesigned — For each Holy Power ability cast, your next Consecration deals Holy damage immediately, split across all enemies. Up to 3 nearby allies are each healed for a percentage of the total damage.
  - Blessed Assurance now increases the damage and healing of your next Blessed Hammer or Hammer of the Righteous by 100% (was 200%).
- Protection
  
  - New Talent: Blessed Word — Word of Glory can no longer critically strike, but its healing is increased by your critical strike chance and 80% of its overhealing done to you instead shrouds you in Light, granting an absorb shield.
  - Improved Ardent Defender has been redesigned – Now increases maximum HP by 20% while active and no longer cancels remaining duration if fatal damage is sustained.
  - Seal of Reprisal has been redesigned – Blessed Hammer reduces enemy damage dealt to you by 10% for 8 seconds.
  - Masterwork has been updated – After casting a Holy Armament, your next 3 casts of Hammer of the Righteous/Blessed Hammer/Crusader Strike bestow a Lesser Armament of the same kind on a nearby ally.
  - Judgment damage increased by 51%.
  - Consecration damage increased by 100%.
  - Shield of the Righteous damage increased by 150%.
  - Hammer of the Righteous primary damage increased by 50%.
  - Avenging Wrath increases damage and healing done by 10%, and critical strike by 10%.
  - Avenger's Shield damage increased by 30%.
  - Lesser Weapon damage increased by 50%.
  - Hammer of Light damage reduced by 33%.
  - Empyrean Hammer damage reduced by 33%.
  - Hammer and Anvil damage reduced by 20%.
  - Divine Exaction's Divine Toll effectiveness reduced to 80% (was 150%).
  - Sentinel duration increased to 20 seconds.
  - Greater Judgment debuff now lasts for 18 seconds (was 15 seconds).
  - Guardian of Ancient Kings now has a 8 second initial cooldown.
  - Undying Embers heals you for 125% of damage dealt by Refining Fire (was 100%).
  - Bulwark of Order absorb increased to 75% of Avenger's Shield damage (was 60%).
  - Solace causes Consecration to heal you for 375% of damage it deals (was 300%).
  - Bulwark of Righteous Fury increases the damage of your next Shield of the Righteous by 10% per stack (was 20%).
  - Sacred Weapon and Holy Bulwark extend their duration when reapplied by the same caster.
  - Glory of the Vanguard now deals damage as a percentage of Avenger's Shield's initial damage.
  - Sentinel now inherits Avenging Wrath's critical strike bonus.
  - Valiant Crusade no longer cancels on death.
  - Reflection of Radiance’s chance to activate has been significantly reduced.
  - Improved Ardent Defender now applies a debuff to indicate when fatal damage has been sustained.
  - Hammer of Light, Divine Resonance, Sacrosanct Crusade, Bulwark of Order, Empyreal Ward, Strength in Adversity, and Seal of Reprisal can now be tracked with the Cooldown Manager.
  - Fixed an issue where Authoritative Rebuke was incorrectly reducing Rebuke’s cooldown from Avenger’s Shield casts.
  - Fixed an issue where Instrument of the Divine was causing Shield of the Righteous to extend Sentinel’s stacks by an incorrect amount.
  - Fixed an issue where Quickened Invocation was incorrectly reducing the cooldown of Holy Armaments.
  - Fixed an issue where abilities that knocked enemies into the air could cause Glory of the Vanguard to deal its damage additional times.
  - Fixed an issue where casting Hammer of Light in between direct casts of Consecration could allow Consecration to exceed its limit.
  - Many talents have changed position in the talent tree.
  - Sanctified Wrath has been removed.

:::

:::

## FAQ

:::accordion
:::details Q: Why do I keep dying?
The biggest tip I can give is to always figure out why you died in any given scenario and how you can improve. Tanking is tough, with constant opportunities to better use your externals, rotation, and defensives. Recording your gameplay and reviewing Warcraft Logs are great methods. Being good at tanking requires cognitive flexibility—focus on what you could have done better instead of blaming others. This mindset is more rewarding and healthier for becoming a better tank!

:::

:::

---

### Credits

Written By: **Tief**

Reviewed by: **Meeres**

---

:::changelog 更新记录
**2026-08-06** Updated for Patch 12.1

**2026-04-26** Updated for Patch 12.0.5

**2026-02-21** Updated for Patch 12.0.1

**2026-01-17** Updated for Patch 12.0

**2025-12-01** Updated for Patch 11.2.7

**2025-10-06** Updated for Patch 11.2.5

**2025-07-30** Updated for Patch 11.2

**2025-06-18** Updated for Patch 11.1.7

**2025-04-20** Updated for Patch 11.1.5

**2025-02-03** Updated for Patch 11.1

**2024-12-12** Updated for Patch 11.0.7.

**2024-10-27** Updated for Patch 11.0.5.

**2024-08-17** Updated for Patch 11.0.2.

**2024-07-28** Guide Written for patch 11.0.



:::
