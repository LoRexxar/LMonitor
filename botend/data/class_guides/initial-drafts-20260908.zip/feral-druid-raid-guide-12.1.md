欢迎来到《魔兽世界》12.1 版本  **野性 德鲁伊** 团队副本 攻略！本攻略涵盖了你需要了解的关于你的角色的一切！如果你刚刚起步、正从 80 级开始练级？请查看练级攻略！

## 概述

:::columns
:::column
:::rating 团队副本
**单体** · 3/5 · 一般

范围伤害 · 3/5 · 一般

功能性 · 5/5 · 强

生存能力 · 5/5 · 强

机动性 · 5/5 · 优秀



:::

:::

:::column
:::gear **野性 德鲁伊** 最佳配装 列表 团队副本
```json
{
  "source_code": "JgoAwz1ZAc__AEwAmQggQEAAnk7AH16A5IwF2gVABk-FEAQEBAgEtOg-sOAj1kjAYFQAmSCBCgQAAcRuDkjAOFQArSCBCgQAAkQuDkjAOFQAgfBBAiQAAoQrDkjAYFQAnSSBeQQo7mwDAl1uDYAIBAAGAPwJqOQ84OAAFEAI3WzSBEAY7OAhVsBBC0qLbAAGpSCBAgQAAUAYgk9FEIICBAQ94GAJFIBCil9AZIBACGwkE01HFADACGQgA8VAMAwAFwAIFAQAxchAB09FF4RBMTztXQgAIEAAwqCBWYDWBA"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:271875]] | [[item:240967]] · [[item:244007]] |
| 项链 | [[item:268265]] | [[item:240914]] · [[item:240890]] |
| 肩部 | [[item:271526]] | [[item:243991]] |
| 胸部 | [[item:271531]] | [[item:243977]] |
| 腰部 | [[item:268256]] | [[item:240906]] |
| 腿部 | [[item:271527]] | [[item:244641]] |
| 脚部 | [[item:244569]] | [[item:245784]] · [[item:240167]] · [[item:243953]] |
| 腕部 | [[item:244576]] | [[item:240898]] · [[item:245784]] · [[item:240167]] |
| 手部 | [[item:271529]] |  |
| 戒指一 | [[item:268249]] | [[item:240898]] · [[item:243957]] |
| 戒指二 | [[item:252258]] | [[item:240898]] · [[item:243957]] |
| 饰品一 | [[item:270173]] |  |
| 饰品二 | [[item:270175]] |  |
| 背部 | [[item:268253]] |  |
| 主手 | [[item:268215]] | [[item:273072]] |
:::

:::

:::

## 至暗之夜 变动

### 顶尖天赋

:::columns
:::column
**顶尖天赋** 是 至暗之夜 中的一个新功能，用于扩展每个专精天赋树。你可以分配 4 点天赋点来获得这些特殊天赋的全部收益。

- 第一个天赋点解锁第1级。
- 第二个和第三个天赋点解锁并强化第2级。
- 第四个天赋点解锁**顶尖天赋**的第3级。

作为**野性 德鲁伊**，你将获得 **无形捕食者**。该能力提供触发 **无形攻击** [[spell:1263903]] 或 [[spell:1263840]] 的几率。

**第 2 阶** 每当你触发一次 **无形攻击**，便使你获得 15% 伤害加成，持续 5 秒。  
**第 3 阶：** 你的 [[spell:5217]] 现在会强制你的 **接下来 2 个填充技能（产生资源技能）** 触发 **无形攻击**。

:::

:::column
![](<https://assets-ng.maxroll.gg/wordpress/apex-talent-feral-mxr.webp>)

无形捕食者

:::

:::

### 核心改动

以下为你列出从地心之战到 至暗之夜 的各项重要职业改动，帮助你保持信息更新。如果你想更详细地了解**所有**改动，请查看我们的**本版本改动**板块。

- **专精天赋树**
  
  - [[talent:103309@AJwCBA]].
    
    - 现在它会根据你所处的形态给予你不同的效果。
    - **在人形态下（未变身时）：** 使你获得 **强化的[[talent:103283]]**.
    - **在熊形态下：** 使你在20秒内获得20%的额外生命值。
  
  
  
  - [[talent:123794]]
    
    - 强化野性印记的效果。
- **职业天赋树**
  
  - [[talent:103149]]
    
    - 很好的天赋，可以对主要目标造成更多的优先伤害。
  - [[talent:103156]]
    
    - 潜力巨大。
  - [[talent:134211]] & [[talent:103174]]
    
    - 强化[[talent:103175]]使其在单体目标中更强，或成为强大的范围伤害技能。
  - [[talent:134212]]
    
    - 为单体目标设计，可惜目前数值有点偏低，因为在最优配置中你永远不会选择它。
  - [[talent:114771]]
    
    - 不错的被动，可以提升[[spell:1822]]或[[spell:5221]]/[[spell:106785]]。
  - [[talent:103164]]
    
    - 有几率获得5个连击点数。
  - [[talent:103157]]
    
    - 流血伤害提高10%。
- **已移除**
  
  - [[spell:202028]].
    
    - 从自身造成大量伤害到仅仅作为[[spell:319439]]的触发器，我们肯定会想念它的。
  - [[spell:319439]].
    
    - 我们已经拥有它很多年了，我认为它终于被移除是件好事。它在范围伤害中很烦人，在单体目标中感觉还不错。总的来说是个不错的改动。它让玩法更容易了吗？我觉得对新手入门这个专精来说稍微容易了一点点。
  - [[spell:106830]].
    
    - 主要是一个[[spell:319439]]触发技能。
  - [[spell:108238]].
    
    - 现在我们改为拥有一个被动技能（[[talent:128581]]），控制更少但键位绑定也更少了。
  - [[spell:391891]].

## 英雄天赋

- [[talent:123296]] 和 [[talent:123297]] 在单体方面表现非常接近，但 [[talent:123296]] 更胜一筹。
- 另一方面，在任何 范围伤害 战斗中，[[talent:123297]] 则略微领先。
- [[talent:123296]] 的伤害构成更偏向流血，而 [[talent:123297]] 整体上更侧重于 [[spell:22568]] 伤害。

### [[talent:123296]]

- 你的 [[spell:1079]] 和 [[spell:1822]] 有几率使任何受影响的目标身上长出 [[spell:439528]]。

- 每根藤蔓都会造成持续伤害效果，并使目标附加 [[talent:117227]] 减益。

- 每当你用藤蔓 [[spell:22568]] 一个目标时，你就会触发 [[talent:117232]] 的效果，藤蔓到期时也会触发该效果。

- [[talent:117233]] 能很好地提升你所有技能的伤害，你战斗的怪物越多，它的效果就越强。

- [[talent:123296]] 的一个不错的小被动是 [[talent:117230]]，它总体上能给你更多的藤蔓。

随着 12.0 版本的到来，暴风雪 移除了我们的地心之战第三赛季套装，并新增了 3 个英雄天赋点数。

- [[talent:135973@AJwCBA]]
- [[talent:117232@AJwCBA]]
- [[talent:135975@AJwCBA]]

### [[talent:123297]]

- 你的自动攻击有几率使你的下一个 [[spell:22568]] 变为 [[talent:117206]]。
  
  - 强化后的 [[spell:22568]] 会对你的前方弧形区域造成伤害，所以要确保始终面向尽可能多的敌人。

- [[talent:117220]] 会被施加到被 [[talent:117206]] 命中的每个目标身上。
  
  - [[talent:117220]] 可以通过 [[talent:117216]] 来延长。

- [[talent:117219]] 是一个不错的自动攻击速度提升，能让 [[talent:103187]] 和 [[talent:117206]] 更频繁地触发。

- [[talent:103298]] 可以在 猎豹形态 期间配合 [[talent:117210]] 施放。
  
  - 在此期间你还可以通过 [[talent:117218]] 获得10%的最大生命值加成。

在12.0版本中，暴风雪 移除了我们在地心之战第三赛季的套装，并新增了3个英雄天赋点数。

- [[talent:135980@AJwCBA]]
- [[talent:135979@AJwCBA]]
- [[talent:117219@AJwCBA]]

## 天赋

### [[talent:123296]] 单体

:::talents [[talent:123296]] **野性 德鲁伊** 团队副本单体
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### 何时使用该专精

在单体目标战斗中使用此专精。

#### 改变游戏玩法的天赋

了解专精和职业天赋树中所有会显著改变你玩法的天赋。本部分对这些天赋及其应用进行了简要概述，如需更详细的介绍，请查看下方循环和 **深度 俯冲** 章节。

##### 专精树

- [[spell:5217]]
  
  - 在其 **完整** 持续时间内提升你所有攻击的伤害。
- [[talent:103175]]
  
  - 你应该在尽可能多的目标上施放 [[talent:103175]]，以最大化 [[talent:103175]] 的数量。如果每个敌人身上都已有 [[talent:103175]]，甚至可以施放在友方目标上。
- [[spell:319439]]
  
  - 你需要在4秒内使用3种不同的产生连击点技能才能触发它。
  - 你的下3个终结技造成25%的额外伤害。
  - 如果你不喜欢玩 [[spell:319439]]，[[spell:391972]] 是一个替代选择。
- [[spell:16864]]
  
  - 你的自动攻击有几率使你的下一个 [[spell:5221]]、[[spell:106830]] 和/或 [[spell:213764]] / [[spell:202028]] 消耗0点能量。
  - 为了最大化此效果，你应该避免在 [[spell:202028]] 上使用，因为它消耗的能量远低于其他技能。
  - 你还应该保持 [[spell:236068]] 生效，以进一步提升其效果。
- [[talent:103177]]
  
  - 使用它对你的目标施放一连串强力法术。

#### 英雄天赋

- [[talent:117234]]
  
  - 由于 [[talent:117233]] 更偏向多目标，这是你的默认选择。
- [[talent:117229]]
  
  - [[talent:117230]] 更偏向多目标天赋，但在单体目标上也能发挥作用。

### [[talent:123297]] 单体目标

:::talents [[talent:123297]] **野性 德鲁伊** 团队副本单体目标
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCGGGzMqZMLmZmZMmZGAAAAAAADAAAgmZZWmZmBEYBmZGgFGMAAAmZDDA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCGGGzMqZMLmZmZMmZGAAAAAAADAAAgmZZWmZmBEYBmZGgFGMAAAmZDDA"
}
```
:::

#### 何时使用该专精

如果你希望伤害构成更侧重于 [[spell:22568]]，请在单体目标战斗中使用这套天赋。

#### 天赋调整

列出这套天赋与 [[talent:123296]] **单体目标** 构建相比，在职业树和专精树中的所有变化。

##### 专精树

- **新增**
  
  - [[talent:103173]]。

- **已移除**
  
  - [[talent:103170]].

##### 英雄天赋

**将** [[talent:123296]] 更换为 [[talent:123297]]，更多信息请查看上方的 **英雄天赋** 部分。

- [[talent:117219]]
  
  - 这是最佳的单体目标选择，但要求完美的近战覆盖时间，实战中可能较难做到。
- [[talent:117214]] 
  
  - 表现优于 [[talent:117213]]。
- [[talent:117210]]
  
  - [[talent:117209]] 在各方面都更差。

### [[talent:123297]] 顺劈

:::talents [[talent:123297]] **野性 德鲁伊** 团队副本小怪刷新
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAzMz2DYmZmxY2M2GbzYm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZGQgFYmZAWYwAAAYmNM",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAzMz2DYmZmxY2M2GbzYm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZGQgFYmZAWYwAAAYmNM"
}
```
:::

#### 何时使用该专精

在单体战斗中使用此天赋专精，当你需要处理刷新的小怪，又想顺劈它们同时不过多损失单体输出时选用。

#### 天赋调整

列出与[[talent:123297]] **单体**构筑相比，职业树和专精树中的所有改动。

##### 专精树

- **新增**
  
  - [[talent:103184]]
  - [[talent:103181]]
  - [[talent:134211]]

- **已移除**
  
  - [[talent:103185]]
  - [[talent:103174]]
  - [[talent:114771]]

##### 英雄天赋

**将** [[talent:123296]] 改为 [[talent:123297]]，更多信息请查看上方的**英雄天赋**部分。

- [[talent:117219]]
  
  - 这是最佳的单体选择，但要求完美的近战输出时间，实际操作中可能较难做到。
- [[talent:117214]] 
  
  - 表现优于 [[talent:117213]]。
- [[talent:117210]]
  
  - [[talent:117209]] 在各方面都更差。

### [[talent:123296]] 顺劈

:::talents [[talent:123296]] **野性 德鲁伊** 团战中刷新小怪
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### 何时使用该专精

在有add（小怪）刷新、你希望在不损失太多单体输出的情况下顺劈它们时，在单体战斗中使用此天赋。

#### 天赋调整

列出与[[talent:123296]] **单体**构筑相比，职业树和专精树中的所有改动。

##### 专精树

- **新增**
  
  - [[talent:103184]]
  - [[talent:103181]]
  - [[talent:134211]]

- **已移除**
  
  - [[talent:103185]]
  - [[talent:103174]]
  - [[talent:114771]]

#### 英雄天赋

- [[talent:117234]]
  
  - 你的默认选择，因为[[talent:117233]]更偏向多目标。
- [[talent:117229]]
  
  - [[talent:117230]]更多是一个多目标天赋，但在单体战斗中也能生效。

## 输出循环

### 套装

快来查看全部 [**至暗之夜 第二赛季套装**](<https://maxroll.gg/wow/resources/midnight-season-2-tier-sets>)吧！

- **2件套：**当[[talent:103162]]结束时，你在其期间每消耗一个连击点数，就会造成10%的额外伤害，持续1秒。
- **4件套：**‍[[talent:103162]]持续时间延长10秒。

### 单体目标

#### [[talent:123296]] & [[talent:123297]]

##### 起手爆发

- 作为一名**野性 德鲁伊**，你的目标是在不浪费[[spell:1079]]和[[spell:1822]]等流血效果持续时间的前提下，尽可能多地施放[[spell:22568]]。你可以在下方看到使用推荐的**团队副本单体**天赋时起手流程的示例。

:::rotation **野性 德鲁伊**在大秘境中的单体起手流程
```json
{
  "source_code": "I4EeKIwXUAAAAIgHHAAACIQYUAgAHHaACVZMEAAAAAgQ3UwBoAgA0CPBAAgQogFABEABCVWAyQAAAoEEAA"
}
```
1. [[spell:5215]]
2. [[spell:1822]]  [[spell:5217]] · [[spell:106951]]
3. [[spell:274837]]
4. [[spell:1079]]
5. [[spell:323764]]
6. [[spell:22568]]
7. [[spell:5221]]
8. [[spell:22568]]
9. [[spell:5221]]
10. [[spell:22568]]
:::

###### 优先级列表

这是你在整场战斗中应当尽量维持的一般优先级，作为**野性 德鲁伊**。

1. 施放 [[spell:106951]]。
2. 施放 [[spell:5217]]。
3. 施放 [[spell:323764]]。
4. 施放 [[talent:103175]]。
5. 保持 [[spell:1079]] 不消失。
6. 施放 [[spell:22568]]。
7. 保持 [[spell:1822]] 不消失。
8. 保持 [[spell:155625]] 不消失。
9. 施放 [[spell:5221]]。

### 范围伤害

#### [[talent:123296]] & [[talent:123297]]

##### 起手爆发

- 下面你可以看到作为 **野性 德鲁伊** 使用推荐的 **团队副本 顺劈**天赋配装时，你的开场手法示例。

:::rotation **野性 德鲁伊** 在 大秘境 中的多目标开场手法
```json
{
  "source_code": "IkFOLIwXUAAAAIgHHAAACIUYBwAKCdLPFAAAC9p-SAQAagTxaRAAAIAtwTAAAIEKYBQABUBCQESoBAAAdgBKhEaAAAAAAIQxaRA"
}
```
1. [[spell:5215]]
2. [[spell:1822]]  [[spell:5217]] · [[spell:343223]]
3. [[spell:1243807]]
4. [[spell:285381]]
5. [[spell:323764]]
6. [[spell:22568]]
7. [[spell:22568]]
8. [[spell:106785]]
9. [[spell:22568]]
10. [[spell:106785]]
11. [[spell:285381]]
:::

###### 优先级列表

1. 施放 [[spell:106951]]。
2. 施放 [[spell:5217]]。
3. 施放 [[spell:323764]]。
4. 施放 [[talent:134211]]
5. 配合 [[spell:285381]] 保持 [[spell:1079]] 不消失。
6. 施放 [[spell:22568]]。
7. 在大多数目标身上保持 [[spell:1822]] 不消失。
8. 在大多数目标身上保持 [[spell:155625]] 不消失。
9. 施放 [[talent:103301@FAQAzchA]]。

## 深入解析

### 快照

***什么是快照（snapshotting）？***

“快照”（snapshotting）一词指的是一种游戏机制：某些技能在施放的瞬间会捕获（即“快照”）当时的增益效果，并在其持续时间内保留这些增益。

这一点对于持续伤害（DoT）技能（**野性 德鲁伊**的流血效果）尤为关键，因为它们会按照施放时所存在的增益效果持续造成伤害，即使这些属性或增益后来发生变化或到期失效也是如此。

- **[[spell:5217]]**：在[[spell:5217]]生效期间施放[[spell:1079]]或[[spell:1822]]，可确保流血效果在**整个**持续时间内都受益于提高的伤害。

- **[[spell:231052]]**：在潜行状态下施放[[spell:1822]]可在**整个**持续时间内提高伤害。

#### 生死轮回

**[[spell:400320]]**天赋会修改你的DoT持续时间，使其总持续时间缩短20%，但提高了跳伤频率。以下是其对你DoT的影响：

- **[[spell:1822]]**：缩短至**12秒**。
- **[[spell:1079]]**：缩短至1**9秒**。
- **[[spell:155625]]**：缩短至**14.4秒**。

根据这些新的持续时间，传染阈值也会相应调整：

- **[[spell:1822]]：**当剩余时间不超过**3.6秒**（12秒的30%）时，你可以刷新[[spell:1822]]，这段时间会被加到新的[[spell:1822]]上。
- **[[spell:1079]]**：当剩余时间不超过**5.7秒**（19秒的30%）时，你可以刷新[[spell:1079]]，这段时间会被加到新的[[spell:1079]]上。
- **[[spell:155625]]：**当剩余时间不超过**4.3秒**（14.4秒的30%）时，你可以刷新[[spell:155625]]，这段时间会被加到新的[[spell:155625]]上。

#### 生死轮回的实战应用

1. **[[spell:1822]]**：如果剩余 3 秒时刷新，剩余的 **3 秒** 会加到新的 **12 秒**持续时间上，使新持续时间为 **15 秒**。
2. **[[spell:1079]]**：如果剩余 5 秒时刷新，剩余的 **5 秒** 会加到新的 **19 秒** 持续时间上，使新持续时间为 **24 秒**。
3. **[[spell:155625]]**：如果剩余 4 秒时刷新，剩余的 **4 秒** 会加到新的 **14.4 秒持续时间**上，使新持续时间为 **18.4 秒**。

### 理解机制

循环的精细优化只是精通一个专精的一个方面，还有许多其他关键机制会影响你的表现。请参考以下指南来提升这些方面。

- [时间窗口延长（Pandemic）机制](<https://maxroll.gg/wow/resources/pandemic>)
- [法术队列窗口](<https://maxroll.gg/wow/resources/spell-queue-window>)
- [属性收益递减](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)

## 剧毒深渊

**← 滚动查看更多首领 →**

### 内克扎莉

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAAjZYmZmZMmtlx2YbmZm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAAjZYmZmZMmtlx2YbmZm5BmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### 首领攻略技巧

- 可以通过击杀 **躁动的阿曼尼** 小怪来利用 [[talent:103156]]。

### 陵寝哨兵

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### 首领攻略技巧

- 留意 **陵寝哨兵** 的能量到达 100 的时机，避免在此之前交出你的爆发冷却技能。

### 迷失的探险者

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### 首领攻略技巧

- 确保把甲壳引离远程玩家，它只会出现在近战玩家身上。

### 瓦什尼克

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### 首领攻略技巧

- 不要试图过多地输出小怪，那不是你的强项。

### 斯索拉克

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### 首领攻略技巧

- 在风阶段期间，如果你的站位失误，可以使用 [[talent:103276]]。

### 双生利牙

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### 首领攻略技巧

- 逆着你看到的首领身上出现的球的方向移动，以躲避他射出的光束。

### 盘绕祭坛

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGziZmZGjZegBAAAAAAwAAAAIAYWmZrZbmlNYmZAWMDGAAzMAYA"
}
```
:::

#### 首领攻略技巧

- 每个阶段只使用一个[[talent:103162]]。

### 乌拉特克

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### 首领攻略技巧

- 乌拉特克在12.1的PTR服务器上并未出现，将在补丁上线和赛季开始时首次亮相。上文提供的天赋应该是一个不错的起点。
- 在即将到来的世界首杀竞速赛结束后，乌拉特克以及所有首领的更新将很快跟进。

### 尼姆瑞莎·唤波者

:::talents **野性 德鲁伊**
```json
{
  "source_code": "CeGA4vV1lPvoFlyB-BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA",
  "code": "CeGA4vV1lPvoFlyB+BZ6YBsKYDAAAAAgZMzGzMzMzY2MPw2YbGzMmZAAAAYJYYYMzomxsYmZmxYmZAAAAAAAMAAAAamlZZmZmZbmtmlZW2gZmBYhBDAgZGMzGGA"
}
```
:::

#### 首领攻略技巧

- 找到安全点来躲避波次！
- 协助处理[[talent:103287]]，避免鱼人进入中间区域。
- 不要下水游泳。

## 属性优先级

了解你的次要属性优先级，以及作为**野性 德鲁伊**参与团队副本时实现最佳表现所需的第三属性。欲了解更多详细信息，请访问**[属性与特质](<https://maxroll.gg/wow/resources/stats-and-attributes>)**指南。

:::priority **野性 德鲁伊** 团队副本属性优先级
```json
{
  "source_code": "HoAJFMAIxQCKEEQABA"
}
```
**敏捷 ≫ 暴击 ＞ 精通 ＞ 急速 ＞ 全能**
:::

> **在大多数情况下，物品等级更高的装备更好。** 为了准确判断应该装备哪件物品，你应该使用 [Simcraft](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)！静态的"**属性优先级**"只是一个起点，很容易根据你个人的装备情况而发生变化。

所有次要属性都受到 **收益递减** 的影响。**[点击此处](<https://maxroll.gg/wow/resources/stat-diminishing-returns>)** 了解更多！

### 第三属性

- **Avoidance -** 降低“范围伤害”技能伤害承受的优秀属性。
- **Leech -** 通过造成伤害提供额外治疗。你的宠物所造成的伤害治疗术，因此**Leech** 对你来说是一个极佳的第三属性，因为你的大部分伤害来自于你自己的法术。
- **Speed -**  较为小众的第三属性，但在特定情况下可能非常有用，过去也已被证明其实用价值。能让应对某些机制变得轻松许多。

## 装备

### 最佳配装

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271875@DCRAAcGAnk7cUrTOCchNYFA]] | 乌拉特克 |
| 项链 | [[item:268265@BERAAcGAS06oPrDj1kjAYFA]] | 乌拉特克 |
| 肩部 | [[item:271526@DgQAAcGAXk7kjAOF]] | 催化装置 |
| 披风 | [[item:268253@BgQAAcGA5IgTBA]] | 盘卷祭坛 |
| 胸部 | [[item:271531@DgQAAcGAJk7kjAOF]] | 催化装置 |
| 护腕 | [[item:244576@FCSAAcGAYA8ciqjAtOAAAAAAAA3WzSB]] | 制造业 |
| 手套 | [[item:271529@BgQAAcGA5IgTBA]] | 催化装置 |
| 腰带 | [[item:268256@BiQAAcGAK06kjAYF]] | 盘卷祭坛 |
| 腿部 | [[item:249312@DgQAAcGAhu7IoAhE]] | 盘卷祭坛 / 催化装置 |
| 脚部 | [[item:244569@HASAAcGAYA8ciqT84OAAAAAAAA3WzSB]] | 制造业 |
| 戒指1 | [[item:268249@DiQAAcGA1j7IQrTOC4UA]] | 瓦什尼克 |
| 戒指2 | [[item:252258@DiQAAcGA1j7IQrjgC4UA]] | 虚空之痕竞技场 |
| 饰品1 | [[item:270173@BgQAAcGACKAWBA]] | 盘卷祭坛 |
| 饰品2 | [[item:270175@BgwAAcGACKAWBUAABEzFCA]] | 乌拉特克 |
| 武器 | [[item:268215@DgQAAcGAwqCZhNYF]] | 乌拉特克 |

团队副本中的野性 德鲁伊 最佳配装列表

### 可刷取的替代装备

下面为你提供一份优质的可刷取替代装备清单，这些装备可以在魔兽世界的每周锁定系统之外获得。虽然随着你的进度推进最终会被替换，但它们能立即提升角色强度。

| 部位 | 物品 | 获取地点 |
| --- | --- | --- |
| 头部 | [[item:271528@AgQAAkjABFA]] | 催化装置 |
| 项链 | [[item:251142@BiQAAcGAC06IoABF]] | 密谋小径 |
| 肩部 | [[item:271526@DgQAAcGAXk7kjABF]] | 催化装置 |
| 披风 | [[item:251132@DgQAAcGANk7IoABF]] | 密谋小径 |
| 胸部 | [[item:271531@DgQAAcGAJk7kjABF]] | 催化装置 |
| 护腕 | [[item:244576@FCSAAcGAYA8ciqjAtOAAAAAAAA3WjPB]] | 制造业 |
| 手套 | [[item:271529@BgQAAcGA5IQQBA]] | 催化装置 |
| 腰带 | [[item:159317@BiQAAcGAC06IoABF]] | 塞塔里斯神庙 |
| 腿部 | [[item:271527@DgQAAcGAhu7kjABF]] | 催化装置 |
| 脚部 | [[item:244569@HASAAcGAYA8ciqT84OAAAAAAAA3WjPB]] | 制造业 |
| 戒指1 | [[item:252258@DiQAAcGA1j7IQrjgCEUA]] | 虚空之痕竞技场 |
| 戒指2 | [[item:273792@CiQAAUPujAtOCKQQBA]] | 毒牙祭坛 |
| 饰品1 | [[item:273796@BgQAAcGACKQQBA]] | 毒牙祭坛 |
| 饰品2 | [[item:250228@BgQAAcGACKQQBA]] | 密谋小径 |
| 武器 | [[item:273783@DgQAAcGAwqCJoABF]] | 毒牙祭坛 |

野性 德鲁伊 替代选择

### 饰品

以下是从地下城、团本和地下堡可获得的毕业饰品排名。

| 排名 | 饰品 |
| --- | --- |
| S级 | [[item:270175@BgQAAcGACKgTBA]]  <br>[[item:270173@BgQAAcGACKgTBA]]  <br>[[item:270164@BgQAAcGACKgTBA]] |
| **A级** | [[item:273796@BgQAAcGACKgTBA]]  <br>[[item:270165@BgQAAcGACKgTBA]]  <br>[[item:250228@BgQAAcGACKgTBA]] |
| **B级** | [[item:250215@BgQAAcGACKgTBA]]  <br>[[item:159617@BgQAAcGACKgTBA]]  <br>[[item:250225@BgQAAcGACKgTBA]] |
| **C级** | [[item:270166@BgQAAcGACKgTBA]]  <br>[[item:250214@BgQAAcGACKgTBA]] |
| **垃圾级** | [[item:250259@BgQAAcGACKgTBA]]  <br>[[item:273797@BgQAAcGACKgTBA]]  <br>[[item:193757@BgQAAcGACKgTBA]] |

### 美化饰品

- [[item:240167]] x2

#### 剩余的火花

- 制造装备的物品等级为331，而普通装备最高物品等级为334，因此，除非你在该部位没有其他高物品等级的装备可用，否则除了2件美化装备之外，装备制造装备并无收益。

### Simcraft（模拟器）

要找到你当前可获得的最佳装备组合，或确定最优的升级方向，请访问我们的**[Simcraft 指南](<https://maxroll.gg/wow/resources/simulationcraft-and-raidbots-guide>)**，学习如何轻松高效地使用 Simcraft。

## 消耗品

- **药瓶**
  
  - [[item:241322]] *——输出最大化。*
  
  
  
  - [[item:241320]] *——伤害略低，但生存能力更强。*
- **食物**
  
  - [[item:255846]] *——大餐*
  
  
  
  - [[item:242747]] —— 个人食物，缺少大餐提供的耐力加成
- 战斗药水
  
  - [[item:241308]] —— *提供敏捷*
  
  
  
  - [[item:241289]] —— 提供次要属性，目前推荐的选择
- 治疗药水
  
  - [[item:271884]]
- **武器油**
  
  - [[item:243734]]
- **强化符文**
  
  - [[item:259085@AQAAAoF]]
- **宝石插槽**
  
  - [[item:240967]] *——唯一装备，每种颜色的宝石各镶嵌一颗，以强化你的[[item:240967]]。*
    
    - [[item:240908]] *——主宝石。*
    - [[item:240900]]
    - [[item:240918]]
    - [[item:240892]]

### 附魔

:::columns
:::column
| 头部 | [[item:275707@DAAAAcGANk7A]]  <br>[[item:243949]] |
| --- | --- |
| 肩部 | [[item:244019@BAAAAMQA]] |
| 胸部 | [[item:243977@BAAAAMQA]] |
| 手腕 | [[item:275707@BAAAAcG]] |
| 腰部 | [[item:275707@BAAAAcG]] |
| 腿部 | [[item:244641@BAAAAMQA]] |
| 脚部 | [[item:244009@BAAAAMQA]] |
| 戒指1 | [[item:244015@BAAAAMQA]] |
| 戒指2 | [[item:244015@BAAAAMQA]] |
| 武器 | [[item:273072@BAAAAcG]] |

野性 德鲁伊 团队副本中的附魔

:::

:::column
:::gear **野性 德鲁伊 团队副本中的附魔**
```json
{
  "source_code": "IQFZnBQ9NCQA7TDBCAAAA0QuDEwM5OAAAAAABkQDIgw-0QQBQQQo7mAGAkiOYAAAv0AEo8SuDAAAAAQAwqCB"
}
```
| 部位 | 推荐装备 | 宝石与强化 |
| --- | --- | --- |
| 头部 | [[item:275707]] | [[item:243981]] |
| 肩部 | [[item:244019]] |  |
| 胸部 | [[item:243977]] |  |
| 腰部 | [[item:275707]] |  |
| 腿部 | [[item:244641]] |  |
| 脚部 | [[item:244009]] |  |
| 腕部 | [[item:275707]] |  |
| 戒指一 | [[item:244015]] |  |
| 戒指二 | [[item:244015]] |  |
| 主手 | [[item:273072]] |  |
:::

:::

:::

> 你可以从巨型保险库商人处购买[[item:275707@BAAAAcG]]，为你的**头部**、**护腕**和**腰带**添加插槽。

## 种族

对于在团队副本中极限优化 **野性 德鲁伊** 来说，不同的种族特性可以为你的角色带来巨大的收益。如果这并非你的首要目标，选择一个符合你风格的种族也同样可行。

- [[spell:58984]] ——暗夜精灵
  
  - 大秘境中最强大的种族天赋之一，但在任何团队副本战斗中几乎毫无用处。
  - 确实可以与[[spell:390772]]**配合使用。**
- [[spell:20549]] *——牛头人*
  
  - 可用于击晕5个敌人。
  - [[spell:154743]] 2% 爆击伤害。
  - 此外，[[spell:20550]]还为你提供额外生命值，帮助你扛住不可避免的伤害。

### 推荐

**暗夜精灵或牛头人是在团队副本环境中野性 德鲁伊的最佳种族。**

## 宏

了解**野性 德鲁伊在团队副本期间推荐的宏命令，并观看一段关于为你的角色创建简单宏的快速视频攻略。**

**[宏导入指南视频](<https://youtu.be/nULDJcZgsJw>)**

:::accordion
:::details 鼠标指向宏
**[[spell:102793]]** —— *无需确认，直接在你的鼠标指针位置施放[[spell:102793]]。*

```wow-macro
#showtooltip 乌索尔旋风
/cast [@cursor] 乌索尔旋风
```

:::

:::details 鼠标指向宏
**设置焦点宏 —— *将鼠标悬停目标设为焦点*。**

```wow-macro
/focus [@mouseover,exists,nodead] []
```

**[[spell:20484]]** —— *对鼠标悬停目标或当前目标施放[[spell:20484]]。*

```wow-macro
#showtooltip 复生
/use [@mouseover,exists][] 复生
```

:::

:::details 焦点宏
**焦点打断宏 - *对你的焦点目标施放[[spell:106839]]* 。**

```wow-macro
#showtooltip 迎头痛击
/cast [@focus, exists] 迎头痛击
```

:::

:::details 实用 宏
**避免取消[[talent:103177]]的宏 - *只有在[[talent:103177]]引导完毕后才会施放[[spell:22568]]。***

```wow-macro
#showtooltip 凶猛撕咬
/startattack
/cast [nochanneling:Convoke the Spirits] 凶猛撕咬
```

:::

:::

## 插件

下面是作者的野性 德鲁伊用户界面截图，其中标注了所使用的插件以及如何在团队副本中利用它们来让你的游戏体验更加轻松。

![](<https://assets-ng.maxroll.gg/wordpress/INTERFACE-midnight-v2-maxroll-3-1024x683.png>)

:::accordion
:::details 插件
- **BigWigs** *-- 通用首领模块* 
  
  - BigWigs 是一个首领战斗插件。它由许多独立的 *战斗脚本*，或者 *首领模块*组成；这些迷你插件旨在为某一个特定的 团队副本 战斗触发警报消息、计时条、音效等等。
- **EllesmereUI**-- *UI 插件* 
  
  - EllesmereUI 是一个大型的插件，包含许多模块，你可以用它来搭建你的整个 UI。

:::

:::

## 本次版本改动

:::accordion
:::details 补丁 12.1
**德鲁伊**

- 职业
  
  - 缠结毛皮的吸收量提高25%。
  - 野性之心强化的野性成长治疗量提高25%。
- 野性
- 开发者备注：我们在乌拉泰克之咒中对野性的调整旨在提升天赋多样性。我们希望撕咬对喜欢它的玩家来说更加强力，同时也在调整其他一些天赋，使它们的强度更为接近，并开放更多的配装选择。
- 利刃之颚的伤害加成提高至每点60%（原为50%）。
- 专注狂乱的伤害加成降低至15%（原为20%）。
- 割裂与撕扯的伤害加成提高至20%（原为15%）。
- 撕咬的伤害提高30%。
- 顶级掠食者的渴望的基础触发几率降低至4%（原为5%）。
- 回春术的治疗量提高25%。
- 野性成长的治疗量提高25%。
- 愈合的治疗量提高25%。

:::

:::details 补丁12.0.1
**德鲁伊**

- 英雄天赋
  
  - 荒野追猎者
    
    - 当多个目标受到你的流血效果影响时，血 seek者藤蔓的生长速度加快。
    - 狂蔓生长使爆发性生长有30%的几率触发（原为20%）。
    - 耐心守护者使流血伤害提高8%（原为6%）。
    - 修复了耐心守护者未能提高血seek者藤蔓伤害的问题。
- 职业
  
  - 缠结毛皮的吸收量提高100%。
  - 缠结毛皮持续15秒（原为8秒）。
  - 愈合的直接治疗量降低15%。
  - 野性成长的治疗量提高25%。
- 野性
  
  - 所有攻击伤害提高8%。
  - 猎豹形态 横扫的伤害提高20%。
  - 专注狂乱使野性狂乱的伤害提高20%（原为40%）。
  - 野性成长的治疗量提高100%。
  - 回春术的治疗量提高100%。

:::

:::details 补丁12.0
- 德鲁伊
  
  - 英雄天赋
  - 利爪德鲁伊
    
    - 新天赋：肢体撕裂 – 你的自动攻击有30%的更高几率使你的下一个凶猛撕咬/痛击变为毁灭。
    - 新天赋：双重爪击 – 你有16%/18%的几率在任意单体近战技能或夷平之后使用双重爪击进行追击，造成高额物理伤害并产生3点能量/5点怒气。
    - 新天赋：创伤加剧 – 你的可怖伤口使受影响的敌人受到你的流血持续伤害效果的伤害提高8%/15%。
    - 直击要害已更新 –野性：撕碎、横扫和斜掠的伤害提高10%，其爆击几率提高8%。
    - 守护：裂伤的伤害提高20%，其爆击几率提高10%。裂伤为你恢复5%的最大生命值。
    - 撕咬巨物已更新 –野性：撕咬和疯狂狂乱造成的伤害提高25%。
    - 守护：碎甲咆哮的冷却时间缩短15秒。
    - 爪击狂暴已更新 – 毁灭的触发几率降低至20%（原为25%）。狂暴期间的攻击只有一次几率授予毁灭（原为每个被击中的目标一次）。
    - 毁灭已更新 – 你的自动攻击有15%的更高几率使你的下一次攻击变为毁灭。
    - 强化变形使伤害以及撕碎和横扫提高10%（原为6%）。
    - 无情攻击/杀戮打击选择天赋的位置已改变。
  - 荒野追猎者
    
    - 新天赋：园艺高手 – 血seek者藤蔓/共生之花的生长速度提高20%。
    - 新天赋：狂蔓生长 – 血seek者藤蔓/共生之花每2秒有20%的几率以100%效果触发爆裂增生。
    - 新天赋：耐心守护者 – 你的流血和其他持续伤害/持续治疗效果的效果提高6%。
    - 血seek者藤蔓的伤害降低15%。
    - 爆裂增生的伤害降低20%。
    - 茁壮植被使血seek者藤蔓令受害者受到你的伤害提高4%（原为6%）。
    - 爆裂增生的位置已改变。
  - 野性
    
    - 双重爪击的伤害提高20%。
    - 毁灭对其主要目标的伤害降低20%。
    - 恐惧创痕的伤害降低20%。
    - 直击要害使撕碎、横扫和斜掠的爆击几率提高5%（原为8%）。
    - 熊之潜能对熊形态中裂伤和横扫伤害的提升现在为50%（原为300%）。

:::

:::details 11.2版本
- 德鲁伊
  
  - 莱卡拉的冥想替换为莱卡拉的启发——你在每种形态下都会因广博的德鲁伊知识而获得加成：
    
    - 无形态：4% 法术伤害
    - 熊形态：5% 移动速度
    - 猎豹形态：4% 耐力
    
    
    
    - 枭兽形态：3% 闪避
  
  
  
  - 割裂（Maim）现在有 30 秒冷却时间（原为 20 秒）。
  
  
  
  - 熊形态对平衡、野性和恢复德鲁伊的威胁值产生倍率已降低。
  
  
  
  - 利爪德鲁伊
    
    - 强化变形使熊形态受到的魔法伤害降低 6%（原为 4%）。
  
  
  
  - 荒野追猎者
    
    - 共生之花和爆裂增生的治疗量提高 30%。
    - 茁壮成长的共生之花生长基础几率提高 30%。该几率随目标数量增多而提升的速度略微降低。
    - 孪生幼苗额外生成一株血藤或共栖荣花的几率提高至 30%（原为 20%）。
    - 茁壮植被使血藤令目标受到来自你的伤害提高 6%（原为 5%）。
  
  
  
  - 野性
    
    - 所有技能伤害提高 8%。
    - 野性冲锋（Brutal Slash）在熊形态形态下的伤害提高 25%。
    - 莱卡拉的教诲在枭兽形态形态下提供 6% 精通（原为 2%）。
    - 剑齿利颚对额外凶猛撕咬伤害的加成提高至 60/120%（原为 40/80%）。此改动不影响 PvP 战斗。
    - 剑齿虎使凶猛撕咬令目标受到你的流血和其他周期性效果的伤害每连击点提高 5%（原为 3%）。

:::

:::details 11.0.2补丁
- 德鲁伊
  
  - 愈合初始治疗量提高 27%，持续治疗效果降低 3%。
  - 迅捷治愈治疗量提高 38%。
  - 铁鬃的护甲加成为敏捷的 112%（原为 120%）。
  
  
  
  - 野性
    
    - 近战自动攻击伤害提高 30%。
    - 割裂伤害提高 15%。
    - 斜掠初始伤害提高 30%，周期性伤害提高 5%。
    - 撕碎初始伤害提高 30%。
    - 横扫初始伤害提高 30%。
    - 野性冲锋（Brutal Slash）初始伤害提高 30%。
    - 痛击初始伤害提高 30%，周期性伤害提高 5%。
    - 月之灵感的月火术初始伤害提高 30%。
    - 原始之怒直接伤害提高 20%。
    - 适应性虫群直接伤害提高 20%。
    - 当玩家在凶猛撕咬上消耗额外能量时，狂暴凶猛的伤害最高提高 100%（原为 50%）。
    - 嗜血鲜血使凶猛撕咬伤害提高 12%（原为 15%），在猛虎狂怒期间额外提高 12%（原为 15%）。
    - 顶点捕食者对多个目标触发下次免费凶猛撕咬的几率略微提高。
    - 狂暴现在使所有技能和自动攻击伤害提高 15%（原为 10%）。
    - 狂暴：狂乱现在使敌人因连击点生成技能造成的所有直接伤害而流血，数值为其 150%（原为 135%）。
    - 化身使所有技能的能量消耗降低 25%（原为 20%）。
    - 阿莎曼的指引的效果现在在化身结束后持续 40 秒（原为 30 秒）。
    - 野蛮狂怒使你的急速提高 10%（原为 8%），能量回复速度提高 25%（原为 20%）。

:::

:::

## 常见问题

:::accordion
:::details 问：我应该在 4 个还是 5 个连击点时使用终结技？
**答：** 你应当始终在 5 个连击点时使用终结技。

:::

:::

---

### 致谢

作者：**Maystine**

审阅者： **深**

---

:::changelog 更新记录
**2026-08-06** 更新至 12.1

**2026-06-22** 更新至 12.0.7

**2026-04-24** 更新至 12.0.5

**2026-02-10** 更新至 12.0.1

**2026-01-19** 更新至 12.0

**2025-12-03** 更新至 11.2.7

**2025-10-08** 更新至 11.2.5

**2025-07-28** 更新至 11.2！

**2025-06-17** 更新至 11.1.7 版本。

**2025-04-22** 更新至 11.1.5 版本。



:::
